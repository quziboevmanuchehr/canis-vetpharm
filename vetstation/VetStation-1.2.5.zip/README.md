# VetStation — Narkose-Zentralstation (Windows-Kiosk)

Eine **IDEXX-artige Narkose-Zentralstation**: erkennt mehrere Narkose-Monitore/Narkosegeräte über LAN,
ordnet Monitor + Kapnograf (+ Narkose) per Patienten-ID demselben Patienten zu, überwacht **mehrere
Patienten in getrennten Fenstern**, erkennt Narkosezwischenfälle (EKG, Atmung/Kapno, Kreislauf) in
Echtzeit und nennt sofort **Injektion (mL) + optimale Geräteeinstellung** zur Stabilisierung —
**read-only, mehrere Tierarten, Windows 10/11**.

> Die komplette **klinische Logik und das Design** stammen aus der bestehenden Web-App
> (canis-vetpharm / canis-anaesthesie) und werden **wiederverwendet, nicht neu erfunden**. Nur die
> Datenquelle wechselt von manueller Eingabe auf **Live**.

⚠️ **Entscheidungs-/Trainingshilfe — kein zugelassener Patientenmonitor-Ersatz.** Nur anzeigen &
empfehlen; der Tierarzt entscheidet und handelt. Die App sendet **niemals** Befehle an Geräte.

---

## Schnellstart am Praxis-PC (C:\VetStation) — nur Doppelklick, nichts tippen

Auf dem Praxis-PC liegt die Installation in **C:\VetStation**. Alles Nötige ist eine
**Doppelklick-Datei** direkt in diesem Ordner (die beiden mit ★ auch im **Startmenü unter
„VetStation"**):

| Doppelklick-Datei in `C:\VetStation` | Wofür |
|---|---|
| `START-VetStation.bat` | VetStation starten (Bridge + Vollbild-Kiosk, echte Geräte) |
| `START-TESTMODUS.bat` | Demo/Test **ohne** Geräte: Simulator mit zwei Patienten |
| `INSTALLIEREN.bat` | **installieren _und_ aktualisieren** in einem: beendet die laufende Station, kopiert, startet neu und **prüft nach**, ob wirklich der neue Stand läuft. Holt sich die Adminrechte selbst. Die Konfiguration `bridge\config\devices.json` bleibt erhalten. |
| ★ `NETZWERK-EINRICHTEN.bat` | feste IP **192.168.0.99** setzen — holt sich die Adminrechte selbst |
| ★ `GERAETE-PRUEFEN.bat` | sucht die Geräte **selbst** im ganzen Netz und sagt im Klartext, **wo das Problem liegt** |
| ★ `FIREWALL-FREIGEBEN.bat` | Datenports freigeben und doppelte Altregeln aufräumen — fehlt die Freigabe, verwirft Windows die Vitaldaten **lautlos** |
| ★ `NEUSTART.bat` | Station beenden und neu starten (nach Update oder Konfig-Änderung) |
| ★ `INTERNET-EINRICHTEN.bat` | **nur wenn der PC am Praxis-/Hausnetz hängt** (Router, WLAN-Verstärker): trägt **IPv4-Gateway + DNS** nach, **ohne** die feste IP anzufassen — die Geräteverbindung bleibt unberührt. Nötig, wenn Update/Fern-Live/klinische Daten nicht laden oder nur über IPv6 laufen. Im isolierten Gerätenetz nicht nötig. |

> **Wo liegt das Problem?** Die Station beantwortet das jetzt selbst — beim Hochfahren
> (PC-Adresse + Firewall, ~1 s) und auf Klick unter **Admin ▸ Netzwerk & Geräte ▸ „Netzwerk jetzt
> durchsuchen"**: jede Adresse `.1`–`.254` wird angesprochen, jeder Fund **mit Begründung**
> eingestuft, und oben steht in **einem Satz**, woran es liegt. Details:
> [docs/BEFUNDBERICHT-2026-07-21.md](docs/BEFUNDBERICHT-2026-07-21.md).

Im **Testmodus** liefert der Simulator zwei Patienten (Hund 22 kg + Katze 4.2 kg, je Monitor +
Kapno). Über das Dropdown „Szenario (Test)" pro Patient Zwischenfälle schalten (Bradykardie/tief,
MAP 50, VES+SpO₂↓, Apnoe, Bronchospasmus, Kammerflimmern …). Die Oberfläche läuft unter
**http://127.0.0.1:8770** (der Kiosk öffnet sie automatisch).

**Falls doch einmal getippt werden muss:** PowerShell startet immer in `C:\WINDOWS\system32` —
deshalb **nie** einen relativen Pfad wie `kiosk\launch-kiosk.ps1` eingeben, sondern **immer den
vollständigen Pfad in Anführungszeichen**:
```powershell
powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\launch-kiosk.ps1"
```
Autostart/Watchdog richtet `INSTALLIEREN.bat` mit ein. Nur wenn er getrennt gesetzt werden soll:
PowerShell per **Rechtsklick → „Als Administrator ausführen"** öffnen und eingeben
```powershell
powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\install-autostart.ps1"
```
Details in [kiosk/assigned-access.md](kiosk/assigned-access.md).

### Nur Entwickler-PC (D:\VetStation)

Voraussetzung: **Node.js 18+** (hier v24 vorhanden). Keine weiteren Abhängigkeiten (`npm install` nicht nötig).
Diese Befehle gelten **ausschließlich** für den Entwickler-PC — auf dem Praxis-PC gibt es weder
Laufwerk `D:` noch `node`/`npm` im PATH.

```bash
cd D:\VetStation
node bridge/src/index.js        # startet Bridge + UI auf http://127.0.0.1:8770
node tools/smoke-test.js        # Klinik-Selbsttest: 17 Prüfungen (Brain-Regeln + mL-Dosen je Tierart)
```

---

## 🔌 Geräte anschließen & Verbindung testen (uMEC12 Vet · Veta 5 Plus · LifeVet 10C)

**Aufbau:** PC + Monitor + Narkosegerät in **denselben** Gigabit-Switch (eigenes, isoliertes Netz),
gleicher IP-Bereich. **Verbindliche Werte:**

| Gerät | IP | Subnetzmaske | Hinweis |
|---|---|---|---|
| PC (VetStation) | `192.168.0.99` | `255.255.255.0` | **kein** Gateway eintragen |
| uMEC12 Vet Monitor | `192.168.0.50` | `255.255.255.0` | Adresstyp **MANUELL** (nicht DHCP) |
| LifeVet / 2. Gerät | `192.168.0.51` | `255.255.255.0` | Adresstyp **MANUELL** |

> **Läuft es stattdessen über einen WLAN-Verstärker (z. B. TP-Link) am Hausnetz?** Das funktioniert,
> hat aber zwei Eigenheiten, die am 22.07.2026 in der Praxis genau so aufgetreten sind:
> 1. **Der Router vergibt die Adressen per DHCP.** Der Monitor lag deshalb nicht auf `.50`, sondern
>    auf `.51` — die fest eingetragene Geräte-IP zeigte ins Leere. Seit 0.7.2 steht in
>    `bridge\config\devices.json` bei `host` das Wort **`auto`**: die Station spricht dann das
>    Gerät an, das sie tatsächlich per Hersteller-MAC im Netz findet, egal welche Adresse es hat.
> 2. **Der PC hat kein IPv4-Gateway** (die feste IP wird bewusst ohne gesetzt). Gerätedaten laufen
>    davon unberührt. Ob Update/Fern-Live gehen, hing am 22.07.2026 allein an der **IPv6**-Verbindung
>    des Kabelrouters — die funktionierte, ist aber ein einzelnes Bein. `INTERNET-EINRICHTEN.bat`
>    stellt die Station auf beide (ändert die feste IP **nicht**).
>
> Sauberer bleibt trotzdem der eigene Switch: dort kann kein Handy per DHCP die Geräte-Adresse
> wegschnappen.

Die feste PC-IP `192.168.0.99` setzt am Praxis-PC **`NETZWERK-EINRICHTEN.bat`** in `C:\VetStation`
(einfach doppelklicken, die UAC-Abfrage für die Adminrechte bestätigen) — auch im Startmenü unter
„VetStation".

**Verbindung prüfen — sagt im Klartext, was klappt und was fehlt:**
In `C:\VetStation` die Datei **`GERAETE-PRUEFEN.bat`** doppelklicken (ebenfalls im Startmenü unter
„VetStation"). Sie sucht die Geräte automatisch (ARP) und lauscht anschließend auf Daten.

Der Check zeigt deine **PC-IP** (= „Serveradresse" am Gerät), findet Mindray-Geräte per MAC,
testet Ping + Datenports (3502/4601/5000/24105/2575), macht einen **HL7-Handshake** und meldet
`✓ HL7 ERKANNT [HR=… SpO2=… …]` — oder nennt die genaue Ursache + nächsten Schritt. **Nur lesen.**

Soll **eine bestimmte Geräte-IP** direkt geprüft werden, gibt es dafür keine Doppelklick-Datei;
dann in PowerShell mit **vollständigen Pfaden in Anführungszeichen** eingeben:
```powershell
& "C:\VetStation\node\node.exe" "C:\VetStation\tools\geraete-check.js" 192.168.0.50
```

**Am Gerät die Datenausgabe aktivieren** (uMEC12 / LifeVet): Hauptmenü → Wartung →
Benutzer-Wartung (Passwort `888888`) → Netzwerk → IP-Adresstyp **MANUELL**, IP `192.168.0.50`
(2. Gerät `192.168.0.51`), Subnetzmaske `255.255.255.0`; unter **Gateway-Kommunikationseinst.**
als Ziel **`192.168.0.99`, Port `3502`** (bei HL7-/EMR-Kommunikation Port `4601`), Protokoll HL7,
„Real Data Send" EIN. (Veta 5 Plus hat keinen offenen Datenausgang → Kapno-Werte kommen über den
Monitor bzw. via BeneLink.) Details: [docs/MINDRAY-HL7.md](docs/MINDRAY-HL7.md), [docs/LAN-SETUP.md](docs/LAN-SETUP.md).

**Ohne echte Geräte prüfen:** in `C:\VetStation` **`START-TESTMODUS.bat`** doppelklicken — die
Station läuft dann mit dem Simulator (zwei Demo-Patienten), ohne dass ein Gerät angeschlossen ist.

### Nur Entwickler-PC (D:\VetStation)
Selbsttest der ganzen Kette (Adapter-Code mit echtem HL7, ohne Geräte):
```bash
cd D:\VetStation
node tools/drei-geraete-test.js    # simuliert alle 3 Gerätetypen (echtes HL7) durch den Adapter-Code
node tools/geraete-check.js 192.168.0.50   # eine Geräte-IP direkt prüfen
```

---

## 💿 Installieren & Aktualisieren (andere PCs)

**Erstinstallation auf einem neuen PC (Win10/11):**
`VetStation-Setup.exe` (~26 MB, enthält portables Node — Ziel-PC braucht **nichts** extra)
auf USB-Stick/Netzlaufwerk kopieren → am neuen PC **doppelklicken** → fertig (Installation nach
`C:\VetStation`, Start-Menü + Autostart). Wird stattdessen der **Ordner** `VetStation` kopiert
(z. B. aus `VetStation-Setup.zip`): darin **`INSTALLIEREN.bat` doppelklicken** — es holt sich die
Adminrechte selbst (UAC-Abfrage bestätigen). Danach `NETZWERK-EINRICHTEN.bat` für die feste IP.

**Aktualisieren eines vorhandenen PCs — dieselbe Datei:**
`INSTALLIEREN.bat` doppelklicken. Es **beendet die laufende Station** (sonst bliebe der alte Code
im Speicher), kopiert, startet neu und **prüft über `/api/version` nach**, ob wirklich der neue
Stand läuft. Stimmt es nicht, sagt es das deutlich statt „fertig" zu melden.

**Späteres Update — ein Klick, ohne USB:**
In der Station **Admin ▸ 🔄 Aktualisieren** → „Update laden & anwenden". Die Station lädt das
Paket, prüft die **sha256-Prüfsumme**, legt es bereit und wendet es beim **nächsten Start** an
(`launch-kiosk.ps1` → `Apply-StagedUpdate`; Konfiguration `devices.json` + `data\` bleiben erhalten).

### Nur Entwickler-PC (D:\VetStation) — neues Release veröffentlichen

**Ein Doppelklick: `SETUP-BAUEN.bat`.** Es fährt erst alle Selbsttests (und baut **kein** Setup,
wenn einer fehlschlägt), dann das Paket, dann `dist\VetStation-Setup.exe` — mit **IExpress**,
das in jedem Windows steckt. **Inno Setup wird nicht mehr gebraucht**; vorher ließ sich die
Setup.exe nur damit bauen und war deshalb dauerhaft auf 0.5.2 eingefroren.

Vorher die Version **nur an einer Stelle** hochzählen: `package.json` (Wurzel). `bridge/package.json`,
`updater/version.json` und die Inno-`AppVersion` müssen dazu passen — `tools/version-test.js`
erzwingt das und schlägt sonst fehl.

Von Hand ginge auch:
```powershell
powershell -ExecutionPolicy Bypass -File "D:\VetStation\installer\make-dist.ps1"        # Paket + portables Node
powershell -ExecutionPolicy Bypass -File "D:\VetStation\installer\make-setup-exe.ps1"   # Setup.exe (IExpress)
# Inno-Variante bleibt gepflegt, ist aber optional:
& "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe" "D:\VetStation\installer\vetstation-setup.iss"
# Update-Zip (App-Dateien OHNE node\ und data\) + Prüfsumme:
Get-FileHash "D:\VetStation\dist\VetStation-Setup.zip" -Algorithm SHA256
```
Dann Zip nach `canis-vetpharm/vetstation/` legen und `vetstation-version.json` (Repo-Root)
auf die neue `app`-Version + `zipUrl` + `sha256` setzen → alle Stationen sehen das Update.

---

## 📡 Fern-Live — Monitor & Werte über das Internet ansehen

Der Praxis-PC schreibt die Live-Werte **und die Empfehlungen** zusätzlich ins Internet, sodass sie
in der Web-App **von zu Hause** zu sehen sind — Kurven, EKG-Befund, Narkosegerät, Alarme und das
druckbare Narkoseprotokoll inbegriffen.

- **Zugang:** über ein **Praxis-Konto** (E-Mail/Passwort, Google oder Microsoft). Beide Seiten —
  Station und Web-App — melden sich mit **demselben** Konto an; die Daten liegen unter dessen
  Kennung und sind für niemanden sonst lesbar.
  *Den früheren Zugangscode `?live=<code>` gibt es seit 1.0.0 **nicht mehr**: drei Prüfungen am
  27.07.2026 fanden daran vier Wege zu fremden Patientendaten — unter anderem, dass zwei Praxen
  ohne eigene `devices.json` denselben Beispielcode und damit denselben Datenknoten benutzt
  hätten.*
- **Anmelden:** im Kiosk unter **Admin → 📡 Fern-Live**.
  Vollständige Anleitung: **[docs/FERN-LIVE.md](docs/FERN-LIVE.md)**, Regeln: [installer/firebase-rtdb-rules.json](installer/firebase-rtdb-rules.json).
- **Read-only:** fern kann niemand ein Gerät bedienen.
- **Testen ohne Firebase (Viewer):** `…/canis-anaesthesie/?livedemo=1` — zwei Säle: `?livedemo=2`.

### 🏥 Mehrere OP-Säle (ab 1.1.0)

Mehrere Praxis-PCs im selben Praxis-Konto sehen einander: am Kiosk als **Streifen unten am
Bildschirm**, in der Fern-Ansicht als **Tafel mit einer Karte je Saal**. Einzurichten ist nur der
Saalname und die Anmeldung — kein Server, keine IP-Liste, keine Portfreigabe nach außen.

Fremde Säle sind **reine Ansicht**: kein Koppeln, kein Setzen, keine Kurven, und ein fremder
Patient kommt nie ins eigene PDF. Anleitung, Grenzen und Fehlersuche:
**[docs/MEHRERE-SAELE.md](docs/MEHRERE-SAELE.md)**.

### 🔎 Die Station sucht von selbst (ab 1.1.0)

Etwa 20 s nach dem Start sieht die Station einmal im eigenen Netz nach und trägt gefundene
Monitore/Narkosegeräte **selbst ein** — ohne Neustart, ohne dass jemand eine IP kennen muss.
Weitere Praxis-PCs werden erkannt und im Klartext gemeldet. **Während einer laufenden Narkose wird
nie gesucht.** Ein Eintrag, der zwar antwortet, aber kein HL7 spricht, wird nach 90 s wieder
abgeschaltet und vermerkt — geraten wird nichts. Abschalten: `"erstsuche": { "enabled": false }`.

**Nur Entwickler-PC (D:\VetStation)** — Publisher-Test (auf dem Praxis-PC gibt es kein `npm`):
```bash
cd D:\VetStation
npm run test:cloud                    # entspricht:
node tools/cloud-test.js
node tools/cloud-integration-test.js
```

---

## 💉 Verabreichte Medikamente im Narkoseprotokoll (ab 1.2.3)

**Eine Empfehlung ist keine Gabe.** Die App rechnet laufend Narkosemittel und Notfallmedikamente
aus — Dosis in mg und mL, für dieses Tier, dieses Gewicht. Davon kommt **nichts** ins Protokoll.
Der Tierarzt kann jede Empfehlung übergehen: ein anderes Mittel, eine andere Dosis, gar nichts.

Protokolliert wird ausschließlich, was er selbst bestätigt — der Klick auf **„○ als gegeben"**.
Den gibt es an allen drei Stellen, an denen Wirkstoffe stehen:

| Wo | Was gebucht wird |
|---|---|
| **Injektionsnarkose** → Einleitung / Nachdosierung / Sedierung | die ganze Kombination, jede Komponente mit mg und mL |
| **Injektionsnarkose** → Antagonisten | Atipamezol / Naloxon / Flumazenil, mit Dosis und Weg |
| **Medikamente** (Dosis-Rechner) | einzelnes Mittel, Dosis, Applikationsweg |

Der Eintrag geht sofort mit Uhrzeit an die Station (`MSG.MED` → `registry.medikamentGabe`) und
steht damit

* im dauerhaften Protokoll (`bridge/data/protokoll.json`, überlebt F5 und Neustart),
* im **PDF-Ausdruck** als eigener Abschnitt *„Verabreichte Medikamente / Narkosemittel"* und als
  eigene Zeile im Verlauf — der Messverlauf wird bei langen Narkosen ausgedünnt, **eine Gabe nie**,
* in der **Fern-Ansicht** (Web-App) als eigene Karte, im Verlauf und auf dem Ausdruck.

Direkt nach einer Gabe schreibt die Station eine Messzeile — genau dafür ist ein Narkoseprotokoll
da: was hat sich danach geändert.

**Zurücknehmen löscht nicht.** Wer das Häkchen wieder entfernt, erzeugt eine zweite Zeile
(„zurückgenommen", durchgestrichen). Dasselbe gilt für „✕ zurücksetzen": das räumt die
Markierungen weg, nicht die Dokumentation. Ein Protokoll, aus dem sich Zeilen entfernen lassen,
wäre als Dokument wertlos — genau deshalb macht auch die Datenbankregel jede Zeile unveränderlich.

Wächter: `node tools/gaben-protokoll-test.js` — prüft unter anderem, dass **jeder** Buchungsaufruf
in einem Klick-Handler sitzt. Entstünde je ein Aufruf aus einer Empfehlungs- oder Renderfunktion,
würde die App wieder Vorschläge protokollieren, und es fiele niemandem auf.

## ↩ Aus jedem Fenster führt ein Weg zurück (ab 1.2.3)

Der Praxis-PC fährt Edge mit `--kiosk`: **kein Zurück-Pfeil, keine Adresszeile, keine Reiter.**
Alles, was sich vor die Arbeitsfläche legt, muss seinen Rückweg deshalb selbst mitbringen.

* **PDF-Protokoll** — wird nicht mehr blind gespeichert (und damit im PDF-Betrachter geöffnet,
  aus dem es kein Zurück gab), sondern **in der Station angezeigt**: Kopfzeile mit
  „← Zurück zum Dashboard", „‹ Voriger / Nächster ›" zwischen den Patienten, Drucken, Speichern.
* **Anästhesie-App** — eine Verlaufsleiste **← Zurück / Weiter →** neben den Reitern
  (auch `Alt+←` / `Alt+→`). Sie merkt Ansicht **und** gewählten Zwischenfall; ein Sprung aus dem
  Monitor, dem Beatmungsberater oder dem Notfall-Dock ist **ein** Eintrag, nicht zwei.
* **Geräte-, Export- und Admin-Fenster** — `Esc` schließt; der Admin-Knopf heißt jetzt
  „← Zurück" statt „✕".
* **Web-App** — „Protokoll drucken" zeigt das fertige Blatt erst als Vorschau mit
  „← Zurück zur Ansicht" (und blättert bei einer Verlegung zwischen ein-Saal- und
  beide-Säle-Blatt), statt sofort in den Druckdialog zu springen. Das Anmeldefenster hat einen
  Ausgang „← Zurück zur App (ohne Anmeldung)" — es lag vorher als Vollbild ohne Ausweg über der
  Narkose-App.

---

## Was die Station aus einem Gerät liest (seit 0.7.3 vollständig)

Bis 0.7.2 wurden **nur Zahlen** übernommen, deren Code zufällig in einer festen Tabelle stand.
Jeder **Textwert** wurde stillschweigend verworfen — ohne eine einzige Logzeile. Genau deshalb kam
am Praxis-PC am 22.07.2026 „nichts an", obwohl der Monitor sendete: Tierart, Gewicht und die
Klartext-Alarme des Geräts sind Textwerte.

| Was das Gerät schickt | bis 0.7.2 | seit 0.7.3 |
|---|---|---|
| Patienten-ID | ✅ | ✅ |
| Name, Geburtsdatum, Geschlecht | ✗ verworfen | ✅ (bleibt **lokal**, geht nie ins Internet) |
| **Tierart** („Hund") | ✗ verworfen | ✅ → Normwerte & Dosen |
| **Gewicht** (15,0 kg) | ✗ verworfen | ✅ → mL-Mengen (streng geprüft, lb/g werden umgerechnet) |
| Vitalwerte | nur bekannte Codes | ✅ + IEEE-11073-Nomenklatur |
| **Einheiten** | ignoriert | ✅ kPa→mmHg, °F→°C; unbekannte Einheit → Wert wird **nicht** verwendet |
| **Alarmstufe** des Geräts (OBX-8) | ✗ | ✅ „Gerät meldet: Herzfrequenz zu hoch" |
| **Klartextmeldungen** („EKG-Ableitung ab") | ✗ verworfen | ✅ im Fenster und im Geräte-Menü |
| alle übrigen Werte | ✗ verworfen | ✅ **Geräte-Menü ▸ „Alle Werte vom Gerät"** |

**Grundsatz:** Was die Station nicht deuten kann, verschweigt sie nicht mehr — sie zeigt es
unverändert an. Und was sie nicht weiß, erfindet sie nicht:

- Ein Patient **ohne einen einzigen Messwert** steht nicht mehr grün auf „stabil", sondern grau auf
  **„KEINE WERTE"**. (Das war die gefährlichste Falschaussage der Oberfläche.)
- Fehlt das **Gewicht**, erscheinen **keine mL-Mengen** mehr (vorher wurde still mit 10 kg
  gerechnet), sondern die Aufforderung, es einzutragen.
- Fehlt die **Tierart**, steht „Tierart ?" statt eines stillen „Hund".

**Zwischenfall-Erkennung ohne Narkosegerät:** Die Kreuzregeln R4/R5 setzen die Verdampfer-Einstellung
voraus — die liefert ein Monitor nicht. Hängt nur der Monitor an der Station, trug ein Befund deshalb
**keine Maßnahme**. Jetzt liefert jeder Befund Sofortmaßnahme, Geräte-Korrektur, geordnete
Schrittfolge und die fertige **mL-Menge** (art- und gewichtsgenau) aus der bestehenden Wissensbasis.

## Was v1 kann (live verifiziert)
- **Auto-Discovery** mehrerer Geräte (Modell + Rolle + Status active/standby/offline).
- **Patienten-Zuordnung**: Monitor + Kapno mit gleicher Patienten-ID → ein Datensatz zusammengeführt
  (sonst Tierart+Gewicht; manuelles Koppeln als Fallback).
- **Mehrere Tierarten**: Hund, Katze, Kaninchen, Meerschwein, Chinchilla, Degu, Frettchen, Reptil —
  mit artspezifischen Normwerten, Dosen (mg/kg → mL) und Geräteeinstellungen.
- **Live-Monitorbild** pro Patient (EKG/Pleth/Kapno-Kurven, große Vitalzahlen HF/SpO₂/EtCO₂/NIBP/AF/Temp),
  lokal synthetisiert aus Vitalwerten (sehr RAM-schonend).
- **„Brain"-Kreuz-Analyse** live: priorisierte Zwischenfälle mit (1) Sofortmaßnahme,
  (2) Geräte-Korrektur („Iso von X auf Soll Y senken"), (3) **Injektion mit fertiger mL-Menge**.
- **Zwei-Fenster-/Split-View** mit „gefährlichste Warnung nach oben".
- **Geräte-Soll-Vergleich** (Iso/O₂/System/APL) mit ⚠-Abweichung.
- **Admin-Bereich (PIN)**: Verbesserungsvorschläge, Verbindungs-/Fehler-Log, Feedback (hilfreich/nicht
  passend), fehlende Inhalte, anonymisierter **Ein-Klick-Export** (§14).
- **Klinische Daten aktualisieren sich zur Laufzeit** vom Live-canis-vetpharm (Pull + lokaler Fallback).

## Noch offen (dokumentiert)
- **Echte Geräte-Adapter** (Mindray uMEC12 Vet / Veta 5 Plus, Eickemeyer LifeVet 10C): **Gerüst vorhanden**,
  Parser **blockiert bis zum Protokoll** von Eickemeyer/Mindray → siehe [docs/DEVICE-ADAPTERS.md](docs/DEVICE-ADAPTERS.md).
  Bis dahin decken **Simulator** und **Playback** (VitalRecorder/VSCapture) den Test ab.
- **Tauri-MSI + signiertes Auto-Update**: Gerüst in [tauri-shell/](tauri-shell/README.md) (benötigt Rust-Toolchain).

---

## Projektstruktur
```
bridge/        Schicht 1: Acquisition-Bridge (Node, read-only) — WebSocket + Geräte-Adapter
  src/wsserver.js        abhängigkeitsfreier WebSocket-Server (RFC 6455)
  src/model.js           normalisiertes Frame-/ingest-Modell (§5)
  src/registry.js        Auto-Discovery + Status + Steuerung
  src/matching.js        Patienten-Zusammenführung (§6)
  src/adapters/          simulator, playback, mindray (STUB), lifevet (STUB)
ui/            Schicht 2/3: Kiosk-UI (reused Engine + Design)
  index.html, app.js     Zentralstation, Split-View, Live-Feed
  engine/                dose, device-target, brain (R1..R6), waveforms  ← wiederverwendete Web-Logik
  views/admin.js         Admin-/Selbstdiagnose (§14)
  vendor/                lokale Kopien (glass.css, vetpharm-ui.js, anaes-data.js) als Offline-Fallback
kiosk/         Appliance: launch/watchdog/autostart (Edge-WebView2-Kiosk)
tauri-shell/   Produktions-Packaging (MSI + Auto-Update) — Gerüst, benötigt Rust
updater/       App-Update-Kanal (klinische Daten laufen automatisch)
tools/         smoke-test.js (Klinik-Selbsttest)
docs/          Architektur, Geräte-Adapter, Kiosk-Setup, QA, Roadmap
```

## Sicherheit / Recht (§10, nicht verhandelbar)
- **Strikt read-only** — es werden nie Befehle an Geräte gesendet.
- **Isoliertes Geräte-Netz** (eigener Switch), Patientendaten bleiben **lokal** auf dem PC.
- Als **Trainings-/Entscheidungshilfe** gekennzeichnet, kein zugelassener Monitor-Ersatz.

Siehe [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) für die 3-Schichten-Architektur und die Wiederverwendungs-Strategie.
