<#
  make-dist.ps1 - Baut auf DIESEM (Entwickler-)PC ein fertiges, kopierbares Paket
  `dist\VetStation\`, das **portables Node** enthaelt, sodass auf dem Ziel-PC NICHTS extra
  installiert werden muss. Das Paket auf USB-Stick/Netz kopieren und dort `Install-VetStation.ps1`
  ausfuehren (oder `START-VetStation.bat` doppelklicken).

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\make-dist.ps1
  Optional: -NodeVersion 20.18.1   -OutDir <pfad>
#>
param(
  [string]$NodeVersion = '20.18.1',
  [string]$OutDir = "$PSScriptRoot\..\dist"
)
$ErrorActionPreference = 'Stop'
$Root  = Split-Path $PSScriptRoot -Parent
$Stage = Join-Path $OutDir 'VetStation'

Write-Host "== VetStation-Paket bauen =="

# Bereits heruntergeladenes portables Node retten, BEVOR der Stage-Ordner geloescht wird.
# Sonst steht das Paket ohne node.exe da, wenn der Download spaeter fehlschlaegt (offline).
$savedNode = $null
$oldNode = Join-Path $Stage 'node\node.exe'
if (Test-Path $oldNode) {
  $savedNode = Join-Path $env:TEMP 'vetstation-node-cache.exe'
  Copy-Item $oldNode $savedNode -Force
  Write-Host "Vorhandenes node.exe zwischengespeichert (Fallback bei Offline-Build)."
}

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Stage | Out-Null

# 1) App-Dateien kopieren (ohne .git, node_modules, data, dist)
Write-Host "Kopiere App-Dateien ..."
# bridge\data MUSS ausgeschlossen bleiben (Befund 27.07.2026): dort liegen patient-akte.json und
# protokoll.json, also PATIENTENDATEN. Bis hierher wurden sie mitkopiert und landeten damit im
# Update-Paket, das auf einer oeffentlichen Webseite veroeffentlicht wird. Aufgefallen ist es nur,
# weil die Paketpruefung erweitert wurde; im Ernstfall waeren es echte Patientenakten gewesen.
# Ausserdem wuerde ein Update sonst die Betriebsdaten des Kunden ueberschreiben.
# /XF '.git' zusaetzlich zu /XD (Befund 27.07.2026): /XD schliesst nur ORDNER aus. In einem
# Git-Arbeitsbaum ist ".git" aber eine DATEI mit einem Zeiger. Genau so eine Datei landete auf der
# Praxis-Station, und der Updater hielt die Installation daraufhin fuer ein Git-Checkout und rief
# "git pull" auf -> "fatal: not a git repository: (NULL)". Das Update war damit unmoeglich.
# devices.json (NICHT die .example): NEU AUSGESCHLOSSEN am 31.07.2026, und zwar vorsorglich.
# Bisher entstand diese Datei nur, wenn ein Mensch sie anlegte, auf einem Entwicklerrechner also
# praktisch nie. Seit 1.1.0 schreibt die Station sie SELBST (bridge/src/erstsuche.js traegt
# gefundene Geraete ein). Damit kann sie ab jetzt in JEDEM Arbeitsbaum auftauchen, in dem die
# Bridge einmal gelaufen ist, und sie enthaelt die Geraeteadressen und den Saalnamen einer
# konkreten Praxis. Beides gehoert nicht in ein Paket, das oeffentlich auf GitHub Pages liegt,
# und ein Update wuerde damit ausserdem die Konfiguration des Kunden ueberschreiben.
# Dieselbe Sorte Fehler wie bridge/data (siehe oben); diesmal vor dem Ernstfall geschlossen.
robocopy $Root $Stage /E /XD (Join-Path $Root '.git') (Join-Path $Root 'node_modules') (Join-Path $Root 'data') (Join-Path $Root 'bridge\data') (Join-Path $Root 'dist') /XF '*.log' '.git' 'devices.json' /NFL /NDL /NJH /NJS /NP | Out-Null

# 2) Portables Node holen und als node\node.exe ablegen
$nodeDir = Join-Path $Stage 'node'
New-Item -ItemType Directory -Force -Path $nodeDir | Out-Null
$zipName = "node-v$NodeVersion-win-x64"
$zipUrl  = "https://nodejs.org/dist/v$NodeVersion/$zipName.zip"
$zipPath = Join-Path $env:TEMP "$zipName.zip"
Write-Host "Lade portables Node $NodeVersion ..."
try {
  Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing
  $tmp = Join-Path $env:TEMP "vetstation-node"
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive -Path $zipPath -DestinationPath $tmp -Force
  Copy-Item (Join-Path $tmp "$zipName\node.exe") (Join-Path $nodeDir 'node.exe') -Force
  Write-Host "node.exe eingebettet."
} catch {
  Write-Warning "Node-Download fehlgeschlagen ($($_.Exception.Message))."
  if ($savedNode -and (Test-Path $savedNode)) {
    Copy-Item $savedNode (Join-Path $nodeDir 'node.exe') -Force
    Write-Host "Zwischengespeichertes node.exe wiederhergestellt - Paket bleibt lauffaehig."
  } else {
    Write-Warning "Kein Fallback vorhanden. Bitte node.exe manuell nach $nodeDir kopieren."
  }
}
if (-not (Test-Path (Join-Path $nodeDir 'node.exe'))) {
  throw "ABBRUCH: node\node.exe fehlt im Paket - der Ziel-PC koennte VetStation nicht starten."
}

# 3) Doppelklick-Starter + Installer-Starter ins Paket
@"
@echo off
title VetStation
REM VetStation starten (ECHTE Geraete). Fuer Dauerbetrieb: Install-VetStation.ps1 ausfuehren.
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
REM Nur im FEHLERFALL anhalten. Sonst schliesst sich das Fenster in derselben Sekunde und der
REM Tierarzt sieht Meldungen wie "Node.js nicht gefunden" oder "Bridge nicht erreichbar" nie.
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo     Netzwerk/Geraete pruefen: GERAETE-PRUEFEN.bat doppelklicken.
  echo.
  pause
)
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-VetStation.bat')

@"
@echo off
REM DEMO/TEST OHNE Geraete: schaltet den Simulator zu (zwei Demo-Patienten Hund+Katze).
set VETSTATION_SIM=1
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-TESTMODUS.bat')

@"
@echo off
title VetStation - installieren / aktualisieren
REM EIN Doppelklick fuer BEIDES: Neuinstallation UND Update eines vorhandenen PCs.
REM Der Installer holt sich die Adminrechte selbst (UAC-Abfrage bestaetigen).
REM
REM Er beendet zuerst die laufende Station (sonst bliebe nach dem Update der ALTE Code im
REM Speicher - genau das ist am 21.07.2026 passiert), kopiert, startet neu und PRUEFT NACH,
REM ob wirklich der neue Stand laeuft. Die Konfiguration bridge\config\devices.json bleibt erhalten.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\Install-VetStation.ps1"
if errorlevel 1 (
  echo.
  echo *** Die Installation ist nicht sauber durchgelaufen - Meldung oben lesen. ***
  echo.
)
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'INSTALLIEREN.bat')

# NEUSTART: es gab bisher KEINEN vorgesehenen Weg, die Station neu zu starten. Weil der Prozess
# erhoeht laeuft, liess er sich nicht einmal im Task-Manager beenden (Befund 2.9).
@"
@echo off
title VetStation - neu starten
REM Beendet die laufende Station (auch wenn sie mit erhoehten Rechten laeuft) und startet sie neu.
REM Noetig nach einem Update, nach Aenderungen an bridge\config\devices.json und wenn ein
REM Datenport von einer zweiten Instanz belegt ist.
echo Beende VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\stop-kiosk.ps1"
REM ZWEITE SICHERUNG (02.08.2026): erst weiter, wenn Port 8770 wirklich frei ist.
REM stop-kiosk.ps1 wartet seit 1.2.4 selbst auf seinen erhoehten Lauf (-Wait). Diese Zeile ist
REM der Guertel zum Hosentraeger: solange die alte Bridge noch horcht, wuerde das Update ueber
REM laufende Dateien geschrieben, und der neue Start saehe die alte Station und taete nichts.
REM Hoechstens 15 Sekunden - danach laeuft es trotzdem weiter und meldet sich unten.
powershell -NoProfile -ExecutionPolicy Bypass -Command "for(`$i=0; `$i -lt 30; `$i++){ `$b=@(Get-NetTCPConnection -LocalPort 8770 -State Listen -ErrorAction SilentlyContinue); if(-not `$b){ break }; Start-Sleep -Milliseconds 500 }"
echo Starte VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo.
  pause
)
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'NEUSTART.bat')

# BEFUND EXPORTIEREN: schreibt EINE Textdatei mit allem, was zur Ferndiagnose noetig ist.
# Ohne sie muss man den Zustand eines fremden PCs muehsam zusammenfragen.
@"
@echo off
title VetStation - Befund exportieren
REM Schreibt eine Textdatei mit Version, IP, Firewall, Geraetesuche, Empfang und Urteil.
REM Diese Datei kann man weitergeben - oder am anderen PC von Claude einlesen lassen.
REM Patienten-Kennungen werden dabei unkenntlich gemacht, Vitalwerte sind NICHT enthalten.
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\befund-export.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\befund-export.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'BEFUND-EXPORTIEREN.bat')

# AUF USB KOPIEREN: ganzes Projekt (Setup + Quellcode + Git) auf einen anderen Datentraeger.
@"
@echo off
title VetStation - auf externe Platte / USB kopieren
REM Legt Setup, Update-Paket UND den vollstaendigen Quellcode inkl. Git-Historie auf einen
REM anderen Datentraeger, damit an einem ANDEREN PC weitergearbeitet werden kann.
REM Ziel aendern:  AUF-USB-KOPIEREN.bat E:\VetStation
cd /d "%~dp0"
set ZIEL=%~1
if "%ZIEL%"=="" set ZIEL=G:\Manu\VetStation
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\auf-usb-kopieren.ps1" -Ziel "%ZIEL%"
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'AUF-USB-KOPIEREN.bat')

# FIREWALL: fehlt eine Freigabe, verwirft Windows die Vitaldaten LAUTLOS (Befund 2.6).
@"
@echo off
title VetStation - Firewall freigeben
REM Gibt die Geraete-Datenports frei und raeumt doppelte Altregeln frueherer Installationen auf.
REM Mehrfaches Ausfuehren schadet nicht - das Ergebnis ist immer genau eine Regel je Port.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-firewall.ps1"
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'FIREWALL-FREIGEBEN.bat')

# 3b) Netzwerk + Geraetepruefung als DOPPELKLICK-Dateien.
#     Grund: In PowerShell startet der Nutzer in C:\Windows\System32 - ein RELATIVER Pfad
#     ("-File installer\set-static-ip.ps1") schlaegt dort fehl. Diese .bat benutzen IMMER
#     ihren eigenen Ordner (%~dp0) und sind damit vom Startverzeichnis unabhaengig.
@"
@echo off
title VetStation - Netzwerk einrichten
REM Setzt die feste IP 192.168.0.99 fuer das isolierte Geraete-Netz (Ziel im Monitor).
REM Einfach DOPPELKLICKEN. Adminrechte holt sich das Skript selbst (UAC bestaetigen).
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-static-ip.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'NETZWERK-EINRICHTEN.bat')

# INTERNET EINRICHTEN: Gegenstueck zu NETZWERK-EINRICHTEN.bat. Die feste IP wird bewusst OHNE
# Gateway gesetzt (isoliertes Geraetenetz). Haengt der PC aber ueber einen Verstaerker am
# Praxis-/Hausnetz, sind damit Update, Fern-Live und die klinischen Daten still tot, waehrend die
# Geraetedaten voellig normal laufen (Befund 22.07.2026). Diese Datei traegt Gateway + DNS nach,
# ohne die IP anzufassen.
@"
@echo off
title VetStation - Internet einrichten (Update + Fern-Live)
REM Traegt Standardgateway und DNS nach, OHNE die feste Geraete-IP zu aendern.
REM Noetig, wenn der PC ueber einen Verstaerker/Switch am Praxis- oder Hausnetz haengt:
REM dann laufen die Geraetedaten zwar, aber Update, Fern-Live und die klinischen Daten
REM kommen nicht ins Internet - ohne dass irgendwo ein Fehler erscheint.
REM Im ISOLIERTEN Geraetenetz (eigener Switch, kein Router) wird diese Datei NICHT gebraucht.
REM Einfach DOPPELKLICKEN. Adminrechte holt sich das Skript selbst (UAC bestaetigen).
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-internet.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'INTERNET-EINRICHTEN.bat')

@"
@echo off
title VetStation - Geraete pruefen
REM Prueft, ob Monitor/Kapnograf Daten senden. Benutzt das mitgelieferte portable Node -
REM auf dem Praxis-PC gibt es KEIN npm, deshalb NICHT "npm run check" verwenden.
REM Optional laesst sich eine Geraete-IP mitgeben:  GERAETE-PRUEFEN.bat 192.168.0.50
REM Ohne Parameter sucht das Programm die Geraete selbst (MAC-Suche + Lauschphase).
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\geraete-check.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\geraete-check.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'GERAETE-PRUEFEN.bat')

# Geschwindigkeit der Fern-Uebertragung messen (beantwortet "kommt das wirklich schnell an?").
@"
@echo off
title VetStation - Geschwindigkeit der Fern-Uebertragung messen
REM Misst, wie lange ein Wertepaket vom Praxis-PC bis zur Cloud-Datenbank braucht.
REM Die zweite Haelfte der Strecke (Datenbank -> Zuhause) steht in der Web-App unter
REM "Fern-Live" -> "Verbindung & Geschwindigkeit".
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\fern-messen.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\fern-messen.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'GESCHWINDIGKEIT-MESSEN.bat')

# 4) Volles Paket zippen (Ordner-Kopie fuer USB-Stick / Netzlaufwerk)
$zipOut = Join-Path $OutDir 'VetStation-Setup.zip'
if (Test-Path $zipOut) { Remove-Item $zipOut -Force }
Compress-Archive -Path $Stage -DestinationPath $zipOut

# 4b) UPDATE-PAKET fuer den In-App-Updater (Admin -> Aktualisieren).
#     WARUM HIER UND NICHT VON HAND: dieser Schritt war bisher ein reiner Handgriff und wurde
#     deshalb bei 0.6.0 prompt vergessen - es gab eine neue Setup.exe, aber kein Update-Paket,
#     mit dem eine bereits laufende Station haette nachziehen koennen.
#     node\ und data\ MUESSEN draussen bleiben: mit node\ waeren es 27 MB statt gut 0,7 MB,
#     und data\ enthaelt die Betriebsdaten des Kunden.
$ver = (Get-Content (Join-Path $Root 'package.json') -Raw | ConvertFrom-Json).version
$updZip = Join-Path $OutDir ("VetStation-$ver.zip")
if (Test-Path $updZip) { Remove-Item $updZip -Force }
$inhalt = Get-ChildItem -LiteralPath $Stage -Force | Where-Object { $_.Name -ne 'node' -and $_.Name -ne 'data' }
Compress-Archive -Path $inhalt.FullName -DestinationPath $updZip
$sha = (Get-FileHash -LiteralPath $updZip -Algorithm SHA256).Hash.ToLower()
$updKb = [math]::Round((Get-Item $updZip).Length / 1KB, 0)
if ((Get-Item $updZip).Length -gt 5MB) {
  Write-Warning "Update-Paket ist $updKb KB gross - vermutlich ist node\ mit hineingeraten. Bitte pruefen."
}

# 5) SELBSTSCHUTZ: Beobachtet am 21.07.2026 - nach einem Lauf war die QUELLE
#    installer\make-dist.ps1 verschwunden (die Kopie im Stage blieb intakt, kein
#    Virenscanner-Fund). Ursache noch nicht abschliessend geklaert; da die Datei beim
#    Kopieren nach $Stage noch vorhanden war, laesst sich der Verlust hier sicher heilen.
#    Ohne diesen Block landet die Loeschung beim naechsten `git add -A` unbemerkt im Commit
#    (genau das ist in 0.5.1 passiert).
#
#    STAND DER UNTERSUCHUNG (0.6.0): einzeln nachgestellt wurden robocopy, Compress-Archive und
#    Remove-Item auf einer Kopie - KEINER dieser Schritte loescht die Quelle. Im Paket gibt es
#    auch keine Verknuepfungspunkte (Junctions), denen Remove-Item -Recurse folgen koennte.
#    Der Verlust tritt also nur im Zusammenspiel auf und bleibt vorerst unerklaert.
#    WICHTIG UND BEWUSST SO: wiederhergestellt wird aus $Stage, und dorthin wurde die Datei in
#    GENAU DIESEM Lauf kopiert. Die Heilung kann deshalb nie einen alten Stand zurueckspielen -
#    sie stellt immer exakt den Inhalt wieder her, mit dem der Lauf begonnen hat.
$selbst  = $PSCommandPath
$imStage = Join-Path $Stage 'installer\make-dist.ps1'
if ($selbst -and -not (Test-Path -LiteralPath $selbst) -and (Test-Path -LiteralPath $imStage)) {
  Copy-Item -LiteralPath $imStage -Destination $selbst -Force
  Write-Warning "make-dist.ps1 war nach dem Lauf verschwunden und wurde aus dem Paket wiederhergestellt."
}

Write-Host ""
Write-Host "FERTIG (Version $ver):"
Write-Host "  Ordner:        $Stage"
Write-Host "  Volles Zip:    $zipOut"
Write-Host "  Update-Paket:  $updZip  ($updKb KB)"
Write-Host "  sha256:        $sha"
Write-Host ""
Write-Host "Auf den Ziel-PC kopieren -> INSTALLIEREN.bat (als Admin) oder START-VetStation.bat (Test)."
Write-Host "Fuer den In-App-Update-Kanal: Update-Paket + sha256 im Manifest vetstation-version.json"
Write-Host "veroeffentlichen (siehe README, Abschnitt 'neues Release veroeffentlichen')."
