/*
 * dose.js — Dosisberechnung (mg/kg -> mL), 1:1 aus der Web-App (index.html calc/parseConc/doseLine).
 * Liefert fuer einen Zwischenfall die fertigen Injektionen inkl. mL nach Gewicht/Tierart.
 * Laeuft im Browser (VS.dose) und in Node (module.exports) fuer Tests.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.VS = root.VS || {}; root.VS.dose = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // "20 mg/ml", "5 mcg/ml", "1 g/ml", "20 IU/ml" -> mg pro mL (U/mL bleibt fuer Einheiten-Praeparate).
  function parseConc(s) {
    if (!s) return null;
    var m = String(s).replace(',', '.').match(/([0-9]*\.?[0-9]+)\s*(mg|mcg|µg|g|iu|u|units?)\s*\/\s*ml/i);
    if (!m) return null;
    var v = parseFloat(m[1]); var u = m[2].toLowerCase();
    if (u === 'g') v = v * 1000;
    if (u === 'mcg' || u === 'µg') v = v / 1000;
    return v;
  }

  /*
   * parseConcEinheit(text, einheit) — die Zahl aus der Konzentration, die WIRKLICH zur
   * Dosiseinheit gehoert.
   *
   * WARUM (Befund 17.08.2026, nachgerechnet): parseConc() liefert immer mg/mL. Bei
   * Magnesiumsulfat steht "500 mg/mL (50 %) = 4 mEq/mL" und parseConc nimmt die 500, waehrend
   * die Dosis in mEq/kg angegeben ist — 500/4 = 125, die Spritzenmenge war 125-fach zu klein.
   * parseConc() bleibt unveraendert, weil sie exportiert ist und Tests sie in mg erwarten.
   * Ohne passende Angabe kommt null zurueck: dann steht KEINE Milliliterzahl da.
   */
  function parseConcEinheit(s, einheit) {
    if (!s || !einheit) return null;
    var re = new RegExp('([0-9]*\\.?[0-9]+)\\s*' + einheit + '\\s*\\/\\s*ml', 'i');
    var m = String(s).replace(',', '.').match(re);
    return m ? parseFloat(m[1]) : null;
  }

  /*
   * konzentrationNurStamm(text) — nennt die Angabe NUR die Stammloesung und verlangt Verduennen?
   * Gleiche Regel und gleiche Begruendung wie in ui/app/index.html (Befund 18.08.2026): steht nur
   * EINE Konzentration da und daneben "verduennen", ist es die Stammloesung, und eine daraus
   * gerechnete Milliliterzahl waere das Volumen des Konzentrats. Bei Kaliumchlorid steht in
   * derselben Zeile "NIE unverduennt". Zwei Angaben (z. B. "0,05 mg/mL (aus 0,5 mg/mL
   * verduennt)") sind dagegen in Ordnung: die erste ist das Ziel der Verduennung.
   */
  function konzentrationNurStamm(s){
    if(!s) return false;
    var t=String(s);
    if(!/verd(ü|ue)nn|unverd/i.test(t)) return false;
    /* "unverduennt" enthaelt "verduennt" - sonst gaelte "NIE unverduennt" als Herkunft. */
    var o=t.replace(/unverd(ü|ue)nnt/gi, " ");
    /* Herkunft der Gebrauchsloesung: "(aus 0,5 mg/mL verduennt)", auch mit inneren Klammern. */
    return !/\baus\b[\s\S]{0,60}?[0-9][\s\S]{0,60}?verd(ü|ue)nnt/i.test(o);
  }
  // d = { low, high, unit, conc }, w = kg -> { amtLo, amtHi, amtUnit, mlLo, mlHi, takt }
  function calc(d, w) {
    var lo = d.low, hi = (d.high != null ? d.high : d.low);
    var unit = (d.unit || 'mg/kg').toLowerCase();
    /*
     * Zeitbezug mitfuehren (17.08.2026): Raten wie mcg/kg/min und mmol/kg/h verloren hier ihr
     * "/min" bzw. "/h", und die gerechnete Zahl stand danach wie eine einmalige Gesamtmenge da.
     * Der Zusatz gehoert an die Einheit UND an die Milliliterzahl.
     */
    var takt = /\/\s*min\b/.test(unit) ? '/min' : (/\/\s*(h|std)\b/.test(unit) ? '/h' : '');
    /*
     * mEq und mmol sind eigene Einheiten, nicht mg — ohne diese Zweige fielen sie in den
     * mg-Zweig am Ende. mcg zuerst, weil "mcg" auch in "mcg/kg/min" steckt.
     */
    var perKg = /mcg|µg/.test(unit) ? 'mcg'
              : /meq/.test(unit) ? 'mEq'
              : /mmol/.test(unit) ? 'mmol'
              : (/(^|[^a-z])(iu|u|units?)([^a-z]|$)/.test(unit) ? 'U' : 'mg');
    if (lo == null) {
      return { amtLo: null, amtHi: null, amtUnit: perKg + takt, mlLo: null, mlHi: null, takt: takt };
    }
    var amtLo = lo * w, amtHi = hi * w;
    var mlLo = null, mlHi = null;
    if (perKg === 'mEq' || perKg === 'mmol') {
      var cE = parseConcEinheit(d.conc, perKg);
      if (cE) { mlLo = amtLo / cE; mlHi = amtHi / cE; }
    } else {
      var conc = parseConc(d.conc);
      if (conc) {
        var mgLo = perKg === 'mcg' ? amtLo / 1000 : amtLo;
        var mgHi = perKg === 'mcg' ? amtHi / 1000 : amtHi;
        mlLo = mgLo / conc; mlHi = mgHi / conc;
      }
    }
    /* Form B: nur die Stammloesung genannt -> keine Milliliterzahl (siehe oben). */
    var nurStamm = konzentrationNurStamm(d.conc);
    if (nurStamm) { mlLo = null; mlHi = null; }
    return { amtLo: amtLo, amtHi: amtHi, amtUnit: perKg + takt, mlLo: mlLo, mlHi: mlHi,
      takt: takt, nurStamm: nurStamm };
  }

  function drugById(ANAES, id) { return (ANAES.drugs || []).find(function (d) { return d.id === id; }); }

  // Vial-Konzentration ist ARTUNABHAENGIG (Eigenschaft der Ampulle) -> aus irgendeinem
  // Arteintrag desselben Medikaments uebernehmen, damit mL auch bei fehlender Art-conc rechenbar ist.
  function anyConc(d) {
    if (!d || !d.species) return null;
    for (var k in d.species) { var s = d.species[k]; if (s && s.conc) return s.conc; }
    return null;
  }

  // Fertige Injektionen fuer einen Zwischenfall (Notfall-Medikamente), nach Art+Gewicht.
  // WICHTIG (Sicherheit): der Inzident-Ref traegt eine HUND-zentrische Notfalldosis. Fuer andere
  // Arten (z.B. Kaninchen-Atropin 0,1–0,5 statt 0,02–0,04) MUSS die artspezifische Dosis gewinnen,
  // sonst massive Unterdosierung. Der Hund behaelt die (verifizierte) inzident-spezifische Ref-Dosis.
  function injectionsFor(ANAES, incidentId, sp, wt) {
    var inc = (ANAES.incidents || []).find(function (i) { return i.id === incidentId; });
    if (!inc || !inc.drugs) return [];
    return inc.drugs.map(function (ref) {
      var d = drugById(ANAES, ref.id);
      var spd = (d && d.species && d.species[sp]) || {};
      var hasSpd = spd.low != null;
      var concFallback = spd.conc || ref.conc || anyConc(d);
      var dose, refFallback = false, speciesDose = false;
      if (sp === 'hund') {
        // Referenzart Hund: inzident-spezifische Ref-Dosis behalten (verifiziert), sonst Artdosis.
        dose = { low: ref.low != null ? ref.low : spd.low, high: ref.high != null ? ref.high : spd.high,
          unit: ref.unit || spd.unit || 'mg/kg', conc: spd.conc || ref.conc };
        speciesDose = ref.low == null && hasSpd;
      } else if (hasSpd) {
        // Andere Art MIT hinterlegter Dosis: IMMER die artspezifische Dosis (nie Hund-mg/kg).
        dose = { low: spd.low, high: spd.high != null ? spd.high : spd.low,
          unit: spd.unit || 'mg/kg', conc: concFallback };
        speciesDose = true;
      } else {
        // Andere Art OHNE hinterlegte Dosis: Hund-Referenz nur als Notbehelf – deutlich kennzeichnen.
        dose = { low: ref.low, high: ref.high, unit: ref.unit || 'mg/kg', conc: concFallback };
        refFallback = ref.low != null;
      }
      var c = calc(dose, wt);
      var caution = spd.caution || '';
      if (refFallback) caution = ('⚠ Keine artspezifische Dosis für diese Tierart hinterlegt – HUND-Referenz. Dosis am Exoten-Formulary (Carpenter/BSAVA) prüfen. ' + caution).trim();
      return {
        id: ref.id, name: d ? d.name : ref.id, icon: d ? d.icon : '💉',
        route: (speciesDose && spd.route) || ref.route || spd.route || '',
        note: ref.note || '',
        indication: spd.indication || '',
        caution: caution,
        unitPerKg: dose.unit,
        amtLo: c.amtLo, amtHi: c.amtHi, amtUnit: c.amtUnit,
        mlLo: c.mlLo, mlHi: c.mlHi, takt: c.takt,   // takt: "/min" bzw. "/h" bei Raten, sonst ""
        conc: dose.conc,
        available: dose.low != null,
        speciesDose: speciesDose,     // true = artspezifische Dosis verwendet
        refFallback: refFallback,     // true = Hund-Referenz mangels Artdaten (unbestätigt!)
      };
    });
  }

  // Einzeldosis eines Medikaments fuer Art+Gewicht (fuer Medikamenten-Nachschlag).
  function doseFor(ANAES, drugId, sp, wt) {
    var d = drugById(ANAES, drugId);
    if (!d) return null;
    var spd = d.species && d.species[sp];
    if (!spd) return { drug: d, available: false };
    // conc art-unabhaengig fallbacken, damit mL auch ohne Art-conc rechenbar ist.
    var dose = spd.conc ? spd : Object.assign({}, spd, { conc: anyConc(d) });
    var c = calc(dose, wt);
    return { drug: d, spd: spd, available: spd.low != null, calc: c };
  }

  function fmt(n) {
    if (n == null || isNaN(n)) return '–';
    if (n >= 100) return Math.round(n).toString();
    if (n >= 10) return (Math.round(n * 10) / 10).toString();
    if (n >= 1) return (Math.round(n * 100) / 100).toString();
    return (Math.round(n * 1000) / 1000).toString();
  }
  function fmtRange(a, b) { a = fmt(a); b = fmt(b); return a === b ? a : a + '–' + b; }

  return { parseConc: parseConc, parseConcEinheit: parseConcEinheit, calc: calc, injectionsFor: injectionsFor, doseFor: doseFor, fmt: fmt, fmtRange: fmtRange, drugById: drugById };
});
