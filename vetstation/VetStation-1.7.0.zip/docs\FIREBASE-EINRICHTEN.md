# Firebase einrichten — die Schritte, die nur Sie tun können

Alles Übrige an VetStation 1.2.0 ist gebaut, veröffentlicht und nachgemessen. Was hier steht, geht
**nur über Ihr eigenes Google-Konto** und lässt sich deshalb nicht automatisieren: die Firebase-CLI
verlangt eine Anmeldung im Browser, und Sicherheitsregeln werden in der Konsole veröffentlicht.

> **Reihenfolge einhalten.** Schritt 1 vor Schritt 2. Meldet sich eine Station am Praxis-Konto an,
> bevor die Regeln stehen, weist die Datenbank jeden Mehrsaal-Schreibvorgang ab — und `cloud.js`
> schaltet die Fern-Übertragung nach drei Ablehnungen von selbst dauerhaft ab.

---

## Schritt 1 — Datenbankregeln veröffentlichen  ⚠ zwingend

Ohne diesen Schritt funktioniert **kein** Mehrsaal-Betrieb: die Zweige `tafel/`, `saele/` und
`verbund/` existieren in den heute veröffentlichten Regeln vermutlich noch nicht.

1. [Firebase-Konsole](https://console.firebase.google.com/) → Projekt **vet-station**
2. **Realtime Database → Regeln**
3. Den gesamten Inhalt von [`installer/firebase-rtdb-rules.json`](../installer/firebase-rtdb-rules.json)
   einfügen (Kommentare dürfen drinbleiben, Firebase versteht sie)
4. **Veröffentlichen**

Die Datei ist vorher geprüft — `node tools/firebase-regeln-test.js` bestätigt Form, Mandanten­trennung
und dass genau die Felder verlangt werden, die die Station auch schreibt.

**Was dabei zu wissen ist, bevor Sie klicken.** Der Kopf der Regeldatei nennt selbst eine Annahme,
die sich im Regel-Simulator nicht prüfen lässt: dass alle Vorkommen von `{".sv":"timestamp"}` in
*einem* atomaren Schreibvorgang auf denselben Wert aufgelöst werden. Träfe sie nicht zu, würde die
Datenbank ab dem Moment des Veröffentlichens **jeden** Schreibvorgang **jeder** Praxis ablehnen.
Deshalb: veröffentlichen, wenn Sie danach kurz hinsehen können — nicht kurz vor einer Narkose.

**Woran Sie sehen, dass es geklappt hat:** nach Schritt 2 im Admin-Bereich unter *Fern-Live* steht
„angemeldet" und die Zahl der Schreibvorgänge wächst. In der Konsole erscheint unter
`live/<Ihre-Kennung>/tafel/` ein Zweig je OP-Saal.

**Wenn etwas schiefgeht:** die vorherige Fassung steht in der Konsole unter *Regeln → Verlauf* und
lässt sich mit einem Klick zurücknehmen.

### Firestore (nur für das Archiv)
Dieselbe Konsole → **Firestore → Regeln** → Inhalt von
[`installer/firestore-rules.txt`](../installer/firestore-rules.txt). Ohne diesen Schritt fällt
**nur** das Verlaufsarchiv aus; die Live-Übertragung läuft davon unberührt.

---

## Schritt 2 — Station am Praxis-Konto anmelden

Gemessen am 01.08.2026: die laufende Station ist **nicht** angemeldet (`/api/cloud` meldet
`angemeldet: false`, 0 Schreibvorgänge). Solange das so ist, verlässt kein Wert den Praxis-PC.

Admin-Bereich → **📡 Fern-Live** → mit dem Praxis-Konto anmelden. Jeder weitere OP-Saal meldet sich
mit **demselben** Konto an — mehr ist für den Verbund nicht einzurichten.

---

## Schritt 3 — Firewall  ⚠ nach jedem Update auf 1.2.0

`FIREWALL-FREIGEBEN.bat` doppelklicken. In 1.2.0 sind zwei Geräteports dazugekommen (5510 für das
LifeVet M, 2528 für den Midmark-Monitor); ohne Freigabe verwirft Windows dort ankommende Vitaldaten
**lautlos**. Die Station sagt es Ihnen inzwischen selbst — der Admin-Bereich liest jetzt auch, ob
eine Regel zwar existiert, aber abgeschaltet ist.

---

## Schritt 4 (freiwillig) — Web-App zusätzlich unter `vet-station.web.app`

**Nicht nötig für den Betrieb.** GitHub Pages liefert die Web-App bereits, und der Update-Kanal
läuft darüber. Diese zweite Adresse behebt nur ein Anmelde-Problem: auf `github.io` ist
`vet-station.firebaseapp.com` eine *fremde* Adresse, und moderne Browser trennen deren Speicher ab —
eine Anmeldung per Weiterleitung kommt dann leer zurück (nachgemessen 29.07.2026). Unter
`vet-station.web.app` gehört die Anmeldung zur selben Adresse und funktioniert auf jedem Gerät.

1. Node.js von [nodejs.org](https://nodejs.org) installieren (LTS) — auf diesem PC ist keines
2. Im Web-Repo `canis-vetpharm` **`VEROEFFENTLICHEN-firebase.bat`** doppelklicken
3. Der Browser öffnet sich einmalig für die Firebase-Anmeldung
4. Danach läuft die App zusätzlich unter `https://vet-station.web.app/canis-anaesthesie/`

---

## Was bereits erledigt ist

| | Stand |
|---|---|
| Update-Kanal | **1.2.0 live** — Manifest, Paket und Prüfsumme geprüft; eine Station würde es annehmen |
| Web-App (GitHub Pages) | **veröffentlicht**, zeigt die Geräte aller OP-Säle |
| Quellcode auf GitHub | **`quziboevmanuchehr/VetStation`, privat** |
| Setup.exe | `dist/VetStation-Setup.exe`, 28 MB, Version 1.2.0 |
| Selbsttests | 49 Dateien grün |

Siehe auch: [FERN-LIVE.md](FERN-LIVE.md) · [MEHRERE-SAELE.md](MEHRERE-SAELE.md) ·
[GERAETE-KATALOG.md](GERAETE-KATALOG.md)
