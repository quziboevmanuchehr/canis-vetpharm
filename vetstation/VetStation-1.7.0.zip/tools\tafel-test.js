'use strict';
/*
 * tafel-test.js — sichert den kleinen gemeinsamen Saal-Zustand ab (bridge/src/tafel.js, ab 1.1.0).
 *
 * Was hier NIE wieder passieren darf:
 *   • Ein Satz, den tafel.js baut, wird von installer/firebase-rtdb-rules.json ABGEWIESEN. Er liegt
 *     im selben atomaren 1-Hz-Koerper wie die Vitalwerte; faellt er, faellt alles, und cloud.js
 *     schaltet nach drei Treffern die Fern-Uebertragung dauerhaft ab. Deshalb liest dieser Test die
 *     Regeldatei und haelt Pflichtfelder und Laengengrenzen gegen den Code (Abschnitt 12).
 *   • Eine Kachel bleibt als KARTEILEICHE stehen, nachdem ihr Patient weg ist. Der Leser beurteilt
 *     die Frische am SAAL (meta.sv), und altMs ist im alten Objekt eingefroren — die Leiche erscheint
 *     dauerhaft als "1,2 s alt", mit plausiblen, unveraenderlichen Vitalwerten, in der Tafel jeder
 *     Web-Ansicht und im Nachbarstreifen. Dasselbe gilt fuer eine Geraetezeile.
 *   • Ein Saal, dessen Uhr VORgeht, gilt dauerhaft als brandaktuell (Alter 0). Negatives Alter muss
 *     "Alter unbekannt" ergeben, niemals 0 — und es darf keine ZAEHLUNG entscheiden.
 *   • Zwei Stationen errechnen aus DERSELBEN Eingabe verschiedene Spiegelnamen — dann flackert der
 *     Kopf der ausgelieferten Web-App im Sekundentakt.
 *   • Eine Einzelplatzpraxis haengt wegen des liegengebliebenen Knotens eines ausgemusterten PCs
 *     dauerhaft im Mehrsaal-Modus und verliert in der alten Ansicht Kurven und Verlauf.
 *   • Die Station erklaert sich durch ihren EIGENEN Schreibvorgang zur fremden 1.0.3.
 *   • Der Saalkopf meldet einen Alarm, den keine geschriebene Kachel traegt.
 *   • Der Herzschlag eines Saals haengt an einer Wertaenderung. Dann meldet die Fern-Ansicht einen
 *     GESUNDEN Saal als offline, weil das Geraet ab Werk nur alle ~30 s sendet.
 *   • Ein abgerissener Kapnograph ist fern nicht als abgerissen erkennbar (er verschwindet aus der
 *     Patientenliste, weil die Registry ihn nach 90 s ausfiltert).
 *
 * Laeuft OHNE Netz, ohne Datenbank und ohne Uhr: tafel.js besteht ausschliesslich aus reinen
 * Funktionen, und die Zeit ist immer ein Argument. Geprueft wird das unten nicht nur am Quelltext,
 * sondern am VERHALTEN — ohne uebergebene Uhr muss jede Funktion "unbekannt" liefern.
 *
 * Start: node tools/tafel-test.js      (laeuft auch in `node tools/alle-tests.js`)
 */
const fs = require('fs');
const path = require('path');
const T = require('../bridge/src/tafel');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

// Feste Uhr. Alle Alterungen entstehen unten durch RECHNEN, nicht durch Warten.
const T0 = 1800000000000;
const SID_A = 'st7f3a91c2b45d';
const SID_B = 'stb1c2d3e4f506';
const SID_TOT = 'stdeadbeef0000';

/*
 * Kommentare aus einer Quelle entfernen — fuer JS und fuer die kommentierte Regeldatei.
 *
 * ZEICHENWEISE MIT TEXTERKENNUNG, weil ein '//' innerhalb eines Ausdrucks kein Kommentar ist. Als
 * Textgrenze gelten " ' UND ` (Befund A5). Frueher zaehlte nur das doppelte Anfuehrungszeichen: ein
 * '//' in einem EINFACH zitierten Text begann damit einen Kommentar, und der Rest der Zeile fiel
 * weg. cloud.js hat vier solche Zeilen (drei googleapis-Adressen und die Adresse der Web-App), und
 * hinter jeder liess sich ein zweites Vorkommen der gemeinsamen Spiegel-Zeichenkette verstecken, das
 * die Zaehlung in Abschnitt 8 nicht mehr sah — nachgemessen: 0 statt 1, Test blieb gruen. Was zwei
 * Fassungen dieser Zeichenkette anrichten, steht bei tafel.SPIEGEL_NAME_MEHRSAAL.
 *
 * DIE TEXTERKENNUNG WIRD AN JEDEM ZEILENENDE ZURUECKGESETZT. Grund: ein Anfuehrungszeichen steht
 * auch INNERHALB eines regulaeren Ausdrucks (tafel.js filtert < > & " ' \ und ` in einer einzigen
 * Zeichenklasse), und diese Datei ist kein JS-Zerleger. Ohne Ruecksetzung liefe so eine Zeile als
 * offener Text durch den halben Quelltext. Mit Ruecksetzung bleibt der Irrtum auf SEINE Zeile
 * beschraenkt — und er wirkt in die sichere Richtung: im Zweifel bleibt Text STEHEN, die Zaehlung
 * findet also eher ein Vorkommen zu viel (Test wird rot) als eines zu wenig (Test bleibt gruen).
 * Der Preis, ehrlich benannt: ein MEHRZEILIGER Schablonentext mit '//' darin wuerde falsch gekuerzt.
 * Abschnitt 14 prueft nach, dass keine der drei gelesenen Dateien Code verliert.
 */
function ohneKommentare(t) {
  const zeilen = String(t == null ? '' : t).split('\n');
  let out = '';
  let imBlock = false;
  for (let z = 0; z < zeilen.length; z++) {
    const zeile = zeilen[z];
    let i = 0;
    let marke = '';                                   // welches Anfuehrungszeichen den Text oeffnete
    while (i < zeile.length) {
      const c = zeile[i];
      if (imBlock) {
        if (c === '*' && zeile[i + 1] === '/') { imBlock = false; i += 2; continue; }
        i++; continue;
      }
      if (marke) {
        if (c === '\\') { out += c + (zeile[i + 1] || ''); i += 2; continue; }
        if (c === marke) marke = '';
        out += c; i++; continue;
      }
      if (c === '"' || c === '\'' || c === '`') { marke = c; out += c; i++; continue; }
      if (c === '/' && zeile[i + 1] === '/') break;   // Zeilenkommentar: Rest der Zeile faellt weg
      if (c === '/' && zeile[i + 1] === '*') { imBlock = true; i += 2; continue; }
      out += c; i++;
    }
    if (z < zeilen.length - 1) out += '\n';
  }
  return out;
}

/*
 * Aus einem .validate-Ausdruck die Liste der erzwungenen Kinder ziehen.
 *
 * ALLE hasChildren-Aufrufe, nicht nur der erste (Befund A4). Dieselbe Verschaerfung laesst sich als
 * zwei Aufrufe schreiben: "hasChildren(['sid']) && hasChildren(['ts'])" erzwingt genau dasselbe wie
 * hasChildren(['sid','ts']). Wer nur den ersten liest, sieht sie nicht — nachgemessen blieb der Test
 * dabei gruen, waehrend der aermste Kopf (T.tafelSatz({sid}) traegt kein ts) von der Regel abgewiesen
 * worden waere. Das kostet nicht das Feld, sondern den ganzen atomaren 1-Hz-Koerper samt Vitalwerten,
 * und nach drei Takten die Fern-Uebertragung der Praxis.
 *
 * NICHT ANWENDBAR AUF /live/$praxis: dort steht eine ODER-Verknuepfung von hasChildren (meta ODER
 * tafel ODER saele ODER verbund), also KEINE Pflichtfeldliste. Wer sie als Liste liest, meldet fuer
 * jeden gesunden Schreibvorgang "verbund fehlt". Diese Funktion wird deshalb nur auf die vier
 * Ebenen angewandt, fuer die tafel.PFLICHTFELDER einen Eintrag fuehrt.
 */
function pflichtAus(v) {
  const raus = [];
  const suche = /hasChildren\(\s*\[([^\]]*)\]\s*\)/g;
  let m;
  while ((m = suche.exec(String(v == null ? '' : v))) !== null) {
    m[1].split(',').map((s) => s.trim().replace(/^['"]|['"]$/g, '')).filter(Boolean)
      .forEach((f) => { if (raus.indexOf(f) < 0) raus.push(f); });
  }
  return raus;
}

const quelleTafel = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'tafel.js'), 'utf8');
const codeTafel = quelleTafel.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\n)[ \t]*\/\/[^\n]*/g, '$1');

console.log('VetStation — Tafel (kleiner Saal-Zustand fuer mehrere OP-Saele)\n');

/* ---------------- 1) Reinheit: keine Uhr, kein Zufall, kein require ---------------- */
console.log('Reine Funktionen (Grundlage fuer jede Pruefbarkeit):');
{
  ok('tafel.js fragt nie selbst die Uhr ab', !/Date\s*\.\s*now/.test(codeTafel));
  ok('tafel.js benutzt keinen Zufall', !/Math\s*\.\s*random/.test(codeTafel));
  ok('tafel.js laedt kein fs, kein net, kein Fremdpaket', !/require\s*\(/.test(codeTafel));
  /*
   * Frueher stand hier /jetzt/.test(code) — das ist fuer JEDE Fassung wahr, auch fuer eine, die
   * heimlich Date.now() benutzt (Befund B9). Geprueft wird jetzt das Verhalten: OHNE Uhr darf keine
   * Funktion eine Dauer erfinden. Eine Fassung mit eigener Uhr liefert hier Zahlen statt "unbekannt".
   */
  const ohneUhrKachel = T.uebersichtSatz({ ts: T0, vitals: { hr: 70 }, alarms: [], devices: [] }, null, undefined);
  const ohneUhrZeile = T.geraeteSatz({ model: 'X', lastTs: T0 }, undefined);
  ok('ohne uebergebene Uhr erfindet keine Funktion eine Dauer',
    !('altMs' in ohneUhrKachel) && !('altMs' in ohneUhrZeile)
    && T.alterMs(T0, undefined) === null
    && T.herzschlagFaellig({ letzter: T0, patientenZahl: 1 }) === false
    && T.modusAus({ eigeneSid: SID_A, tafelGelesen: true, flachGelesen: true }).modus === 'F0',
    JSON.stringify([ohneUhrKachel.altMs, ohneUhrZeile.altMs]));
}

/* ---------------- 2) Alterungsstufen als ZUSTANDSWECHSEL bei uebergebener Uhr ---------------- */
console.log('\nAlterungsstufen wandern mit der uebergebenen Uhr (12 s / 60 s / 12 h):');
{
  const ts = T0;                     // Zeitpunkt des letzten Datenpakets
  const stufe = (versatz) => T.altersStufe(T.alterMs(ts, ts + versatz));
  ok('0 ms          -> live', stufe(0) === 'live', stufe(0));
  ok('11,999 s      -> live', stufe(11999) === 'live', stufe(11999));
  ok('genau 12 s    -> alt (keine neuen Daten)', stufe(12000) === 'alt', stufe(12000));
  ok('59,999 s      -> alt', stufe(59999) === 'alt', stufe(59999));
  ok('genau 60 s    -> offline (Zahlen werden ersetzt)', stufe(60000) === 'offline', stufe(60000));
  ok('11 h 59 min   -> offline', stufe(11 * 3600000 + 59 * 60000) === 'offline', stufe(11 * 3600000));
  ok('genau 12 h    -> weg (Karte verschwindet)', stufe(12 * 3600000) === 'weg', stufe(12 * 3600000));
  // Derselbe unveraenderte Datensatz wechselt seinen Zustand ALLEIN durch die Uhr.
  const kette = [0, 12000, 60000, 12 * 3600000].map(stufe).join('>');
  ok('ein unveraenderter Datensatz durchlaeuft live>alt>offline>weg',
    kette === 'live>alt>offline>weg', kette);
  ok('Alter ohne Zeitstempel ist unbekannt', T.alterMs(null, T0) === null);
  ok('Alter 0 ms ist erlaubt und heisst nicht "unbekannt"', T.alterMs(T0, T0) === 0);
}

/* ---------------- 3) Vorlaufende Uhr: ANZEIGE ja, ZAEHLUNG nie (N16, Befund B3) ---------------- */
console.log('\nEine fremde Uhr, die VORgeht, darf die ANZEIGE beeinflussen, nie eine ZAEHLUNG (N16/B3):');
{
  const zukunft = T0 + 120000;       // Nachbar-sv liegt 120 s in der Zukunft
  ok('alterMs wird null, nicht 0', T.alterMs(zukunft, T0) === null, String(T.alterMs(zukunft, T0)));
  ok('die Stufe heisst "unbekannt"', T.altersStufe(T.alterMs(zukunft, T0)) === 'unbekannt');
  ok('ein Saal mit vorlaufender Uhr bleibt in der ANZEIGE (sv setzt der Server)',
    T.istFrisch({ sv: zukunft }, T0) === true);
  ok('fuer die ZAEHLUNG gilt er NICHT als frisch — sein Alter ist unbekannt',
    T.istZaehlbar({ sv: zukunft, instanz: 'aaaa000011112222' }, T0) === false);
  ok('120 s in der VERGANGENHEIT ist weder zeigbar noch zaehlbar',
    T.istFrisch({ sv: T0 - 120000 }, T0) === false
    && T.istZaehlbar({ sv: T0 - 120000, instanz: 'aaaa000011112222' }, T0) === false);
  ok('59 s alt ist frisch und zaehlbar',
    T.istFrisch({ sv: T0 - 59000 }, T0) === true
    && T.istZaehlbar({ sv: T0 - 59000, instanz: 'aaaa000011112222' }, T0) === true);
  ok('61 s alt ist nicht mehr frisch', T.istFrisch({ sv: T0 - 61000 }, T0) === false);
  ok('voelliger Uhrenunsinn (13 h in der Zukunft) gilt nicht einmal in der Anzeige als frisch',
    T.istFrisch({ sv: T0 + 13 * 3600000 }, T0) === false);
  /*
   * Der Rueckfall auf ts ist fuer die ANZEIGE erlaubt und fuer die ZAEHLUNG nicht: ts ist eine Zahl,
   * die der Schreiber frei waehlt. Nachgemessen war sonst ein Knoten ohne sv mit ts = jetzt + 11 h
   * elf Stunden lang ein "lebender OP-Saal" im Nachbarstreifen jedes anderen Saals (Befund B3).
   */
  const nurTs = { instanz: 'bbbb000011112222', ts: T0 + 11 * 3600000 };
  ok('ein Knoten OHNE Serverzeit zaehlt nie mit, egal wie sein ts aussieht',
    T.istZaehlbar(nurTs, T0) === false && T.istZaehlbar(nurTs, T0 + 6 * 3600000) === false
    && T.istZaehlbar({ instanz: 'bbbb000011112222', ts: T0 - 1000 }, T0) === false);
  // Und der Weg in die Kachel/Geraetezeile
  const k = T.uebersichtSatz({ patientKey: 'sw_hund_22', ts: zukunft, vitals: { hr: 80 } }, null, T0);
  ok('Kachel eines Saals mit vorlaufender Uhr: altMs fehlt, statt 0 zu behaupten',
    !('altMs' in k) && k.ts === zukunft, JSON.stringify(k));
  const g = T.geraeteSatz({ model: 'UMEC12', lastTs: zukunft }, T0);
  ok('Geraetezeile mit vorlaufender Uhr: altMs fehlt, statt 0 zu behaupten', !('altMs' in g));
  const s = T.tafelSatz({ sid: SID_A, jetzt: T0, geraete: { a: g } });
  ok('Saalkopf uebernimmt "unbekannt" statt 0', !('altMs' in s), JSON.stringify(s));
}

/* ---------------- 4) Groesse der Kacheln ---------------- */
console.log('\nGroesse der Kacheln (jede geht jede Sekunde an jede offene Ansicht):');
const patVoll = {
  patientKey: 'sw_hund_22', patientId: '12345', patientName: 'Bello',
  species: 'hund', weightKg: 22,
  vitals: {
    hr: 96, spo2: 97, etco2: 38, fico2: 0, af: 14, sys: 112, dia: 64, map: 78,
    temp: 37.8, ekgRhythm: 'sinus', pleth: null, paw: null, capnoShape: null,
  },
  alarms: [{ id: 'x' }],
  devices: [
    { deviceId: 'lifevet', model: 'LifeVet 10C', ip: '192.168.0.51' },
    { deviceId: 'umec12', model: 'UMEC12', ip: '192.168.0.52' },
  ],
  ts: T0,
};
{
  const k = T.uebersichtSatz(patVoll, { pri: 2, top: { title: 'MAP grenzwertig' } }, T0 + 1200);
  const gr = Buffer.byteLength(JSON.stringify(k));
  ok('vollstaendig belegte Kachel bleibt unter 400 Byte (' + gr + ')', gr < 400, gr + ' Byte');
  ok('altMs ist die DAUER seit dem letzten Paket (1200 ms)', k.altMs === 1200, String(k.altMs));
  ok('ts ist der Zeitpunkt des Patienten', k.ts === T0);
  ok('pri und Befundtitel stehen drin', k.pri === 2 && k.top === 'MAP grenzwertig', JSON.stringify([k.pri, k.top]));
  ok('al zaehlt die Alarme', k.al === 1);
  ok('dev zaehlt die Geraete', k.dev === 2);
  ok('dv nennt hoechstens zwei Geraete', Array.isArray(k.dv) && k.dv.length === 2, JSON.stringify(k.dv));
  ok('dv hat die Form deviceId@ip', k.dv[0] === 'lifevet@192.168.0.51', k.dv[0]);

  // Ein Saal mit NUR einem Monitor: die leeren Messfelder fehlen ganz.
  const mager = T.uebersichtSatz({
    patientKey: 'sw_katze_4', species: 'katze', weightKg: 4,
    vitals: { hr: 180, spo2: 96 }, alarms: [], devices: [{ deviceId: 'umec12', ip: '10.0.0.9' }], ts: T0,
  }, null, T0 + 500);
  const grM = Buffer.byteLength(JSON.stringify(mager));
  ok('Kachel ohne Kapnograf/Temperatur ist deutlich kleiner (' + grM + ')', grM < 200, grM + ' Byte');
  const fehlt = ['et', 'fi', 'af', 'sys', 'dia', 'map', 't', 'rh', 'pid', 'n'].filter((f) => f in mager);
  ok('leere Felder fehlen ganz statt als null zu kosten', fehlt.length === 0, fehlt.join(','));
  ok('die Kachel wird als GANZES Objekt geschrieben — ein fehlendes Feld ist eindeutig',
    mager.hr === 180 && mager.dev === 1);

  // Kappung und Zeichenfilter: dieser Text landet auf dem Kiosk eines FREMDEN Saals.
  const boese = T.uebersichtSatz({
    patientKey: 'x',
    patientName: '<img src=x onerror="alert(1)">Bello & Co, ein sehr langer Tiername ohne Ende',
    species: 'hund"><b>', vitals: { ekgRhythm: 'sinus & <script>' },
    alarms: [], devices: [], ts: T0,
  }, '<b>Befund</b> mit sehr langem Titel, der die Grenze von vierzig Zeichen deutlich reisst', T0);
  const alleTexte = [boese.n, boese.a, boese.rh, boese.top].join('|');
  ok('kein <, >, &, " oder \' in irgendeinem Textfeld', !/[<>&"']/.test(alleTexte), alleTexte);
  ok('jedes Textfeld ist auf 40 Zeichen gekuerzt',
    boese.n.length <= 40 && boese.top.length <= 40, boese.n.length + '/' + boese.top.length);

  // dv muss stabil sein: mergePatients sortiert die Geraeteliste nach Sendezeit.
  const umgedreht = Object.assign({}, patVoll, { devices: patVoll.devices.slice().reverse() });
  const k2 = T.uebersichtSatz(umgedreht, null, T0 + 1200);
  ok('dv ist unabhaengig von der Geraetereihenfolge (kein Flackern je Sekunde)',
    JSON.stringify(k2.dv) === JSON.stringify(k.dv), JSON.stringify(k2.dv));

  /*
   * BEFUND B7: dv kuerzte die Adresse auf 24 Zeichen, geraeteSatz auf 40 — zwei Grenzen fuer
   * denselben Wert. Nachgemessen ergaben zwei VERSCHIEDENE Geraete an zwei verschiedenen
   * IPv6-Adressen denselben Eintrag 'monitor@2001:0db8:85a3:0000:0000', und die
   * Doppelempfangserkennung meldete einen Aufbaufehler, den es nicht gab.
   */
  const ip6a = '2001:0db8:85a3:0000:0000:8a2e:0370:7334';
  const ip6b = '2001:0db8:85a3:0000:0000:8a2e:0370:9999';
  const zwei = T.uebersichtSatz({
    patientKey: 'v6', vitals: {}, alarms: [], ts: T0,
    devices: [{ deviceId: 'monitor', ip: ip6a }, { deviceId: 'monitor', ip: ip6b }],
  }, null, T0);
  ok('zwei Geraete an zwei IPv6-Adressen bleiben in dv unterscheidbar (B7)',
    zwei.dv.length === 2 && zwei.dv[0] !== zwei.dv[1], JSON.stringify(zwei.dv));
  ok('dv und Geraetezeile benutzen DIESELBE Adressgrenze (B7)',
    T.geraeteSatz({ model: 'X', ip: ip6a }, T0).ip === ip6a
    && T.uebersichtSatz({ patientKey: 'v6', vitals: {}, alarms: [], ts: T0, devices: [{ deviceId: 'd', ip: ip6a }] }, null, T0)
      .dv[0] === 'd@' + ip6a,
    T.geraeteSatz({ model: 'X', ip: ip6a }, T0).ip);

  // Der Befund kommt in zwei Formen aus cloud.js — beide muessen gehen.
  const nurTitel = T.uebersichtSatz(patVoll, 'MAP grenzwertig', T0);
  ok('befundTitel als reine Zeichenkette wird angenommen', nurTitel.top === 'MAP grenzwertig');
  ok('ohne Prioritaet fehlt pri (statt als 0 einen ruhigen Patienten zu behaupten)',
    !('pri' in nurTitel), JSON.stringify(nurTitel.pri));
  const ohneBefund = T.uebersichtSatz(patVoll, null, T0);
  ok('ohne Befund fehlen pri UND top', !('pri' in ohneBefund) && !('top' in ohneBefund));

  const ohneTs = T.uebersichtSatz({ patientKey: 'y', vitals: { hr: 70 }, alarms: [], devices: [] }, null, T0);
  ok('Patient ohne Zeitstempel: weder ts noch altMs werden behauptet',
    !('altMs' in ohneTs) && !('ts' in ohneTs) && ohneTs.al === 0 && ohneTs.dev === 0, JSON.stringify(ohneTs));
  ok('FiCO2 0 ist ein Messwert und bleibt drin', T.uebersichtSatz(
    { patientKey: 'z', vitals: { fico2: 0 }, alarms: [], devices: [], ts: T0 }, null, T0).fi === 0);
}

/* ---------------- 5) Geraetezeile (N13): der abgerissene Kapnograph ---------------- */
console.log('\nGeraetezeile je Geraet — sonst ist ein abgerissener Kapnograph fern unsichtbar (N13):');
{
  const monitor = {
    deviceId: 'umec12-a', model: 'UMEC12', role: 'monitor', status: 'active',
    ip: '192.168.0.52', port: 4601, transport: 'hl7-tcp', taktMs: 1000, werteAnzahl: 6,
    seitMs: 800, lastTs: T0 - 800, manualKey: 'sw_hund_22',
  };
  const kapnoAb = {
    deviceId: 'lifevet-a', model: 'LifeVet 10C', role: 'capno', status: 'offline',
    ip: '192.168.0.51', port: 3502, transport: 'hl7-tcp', taktMs: 30000, werteAnzahl: 0,
    seitMs: 95000, lastTs: T0 - 95000, patientKey: 'sw_hund_22',
  };
  const zM = T.geraeteSatz(monitor, T0);
  const zK = T.geraeteSatz(kapnoAb, T0);
  ok('Monitor: alle Felder aus getDevices() stehen fern zur Verfuegung',
    zM.model === 'UMEC12' && zM.role === 'monitor' && zM.status === 'active'
    && zM.ip === '192.168.0.52' && zM.port === 4601 && zM.transport === 'hl7-tcp'
    && zM.taktMs === 1000 && zM.werteAnzahl === 6, JSON.stringify(zM));
  ok('Monitor: altMs aus lastTs und uebergebener Uhr', zM.altMs === 800, String(zM.altMs));
  ok('abgerissener Kapnograph: altMs 95 s', zK.altMs === 95000, String(zK.altMs));
  ok('abgerissener Kapnograph ist fern als abgerissen erkennbar',
    T.altersStufe(zK.altMs) === 'offline' && zK.status === 'offline',
    T.altersStufe(zK.altMs) + '/' + zK.status);
  ok('die Zeile bindet das Geraet an den Patientenschluessel', zK.patientKey === 'sw_hund_22');
  ok('manualKey wird als Rueckfall genommen', zM.patientKey === 'sw_hund_22');
  // Punkt UND Schrägstrich fallen weg — sonst schriebe eine verbastelte Geraete-ID in einen
  // fremden Saalzweig. Dieselbe Regel wie cloud.sanitizeKey.
  ok('patientKey wird als Datenbankschluessel gekappt',
    T.geraeteSatz({ model: 'X', patientKey: '../fremd/saal' }, T0).patientKey === '___fremd_saal',
    T.geraeteSatz({ model: 'X', patientKey: '../fremd/saal' }, T0).patientKey);
  /*
   * NACHGEMESSEN an den echten Formen (30.07.2026): registry.getDevices() fuehrt patientId und
   * manualKey, aber KEIN patientKey. Ohne die Abbildung aus dem Ergebnis von mergePatients() haette
   * die Geraetezeile also keine Verbindung zu ihrer Kachel — die Frage "an welchem Patienten haengt
   * dieser Kapnograph?" waere fern unbeantwortbar, und genau darum geht es bei N13.
   */
  const echtePatienten = [{
    patientKey: 'id:12345',
    devices: [{ deviceId: 'lifevet-a', model: 'LifeVet 10C' }, { deviceId: 'umec12-a', model: 'UMEC12' }],
  }];
  const abb = T.keysJeGeraet(echtePatienten);
  ok('keysJeGeraet liest die Zuordnung aus dem Ergebnis von mergePatients',
    abb['lifevet-a'] === 'id:12345' && abb['umec12-a'] === 'id:12345', JSON.stringify(abb));
  const ohneKey = { deviceId: 'lifevet-a', model: 'LifeVet 10C', status: 'offline', lastTs: T0 - 95000 };
  ok('ohne Abbildung fehlt der Bezug (und faellt auf, statt falsch zu raten)',
    !('patientKey' in T.geraeteSatz(ohneKey, T0)));
  ok('mit Abbildung traegt die Zeile denselben Schluessel wie die Kachel',
    T.geraeteSatz(ohneKey, T0, abb).patientKey === 'id_12345',
    String(T.geraeteSatz(ohneKey, T0, abb).patientKey));
  // Dieselbe Kappungsregel wie cloud.sanitizeKey — sonst zeigte die Zeile auf einen Pfad, den es
  // unter tafel/<sid>/uebersicht/ nicht gibt.
  ok('der Schluessel entsteht nach derselben Regel wie der Kachelpfad',
    T.schluessel('id:12345') === 'id_12345'
    && T.tafelPfade({ sid: SID_A, uebersicht: { 'id:12345': { hr: 1 } } })
      .pfade['tafel/' + SID_A + '/uebersicht/id_12345'] != null);
  ok('ohne lastTs greift seitMs als Rueckfall',
    T.geraeteSatz({ model: 'X', seitMs: 4200 }, T0).altMs === 4200);
  ok('negatives seitMs bleibt "unbekannt"',
    !('altMs' in T.geraeteSatz({ model: 'X', seitMs: -5 }, T0)));
  ok('ein Geraet ganz ohne Patient bekommt trotzdem eine Zeile',
    T.geraeteSatz({ deviceId: 'frei', model: 'Frei', status: 'standby', lastTs: T0 - 3000 }, T0).altMs === 3000);

  /*
   * DER KERN VON N13: derselbe Bestand aus BEIDEN Quellen. In der Patientenliste steht nur noch ein
   * Geraet (die Registry filtert das seit 90 s stumme heraus), in den Geraetezeilen stehen beide.
   * Ohne die Zeilen koennte der Tierarzt in Saal 1 nicht unterscheiden zwischen "in Saal 2 haengt
   * kein Kapnograph" und "in Saal 2 ist der Kapnograph abgerissen".
   */
  const kachel = T.uebersichtSatz({
    patientKey: 'sw_hund_22', vitals: { hr: 96 }, alarms: [],
    devices: [{ deviceId: 'umec12-a', ip: '192.168.0.52' }], ts: T0 - 800,
  }, null, T0);
  const kopf = T.tafelSatz({
    sid: SID_A, name: 'Praxis OP 2', jetzt: T0,
    uebersicht: { sw_hund_22: kachel }, geraete: { 'umec12-a': zM, 'lifevet-a': zK },
  });
  ok('die Kachel sieht nur noch EIN Geraet', kachel.dev === 1);
  /*
   * Frueher stand hier Object.keys({a: zM, b: zK}).length === 2 — eine Tautologie ueber ein im Test
   * selbst gebautes Objekt, an der tafel.js gar nicht beteiligt war (Befund B9). Geprueft wird jetzt,
   * was wirklich in die Datenbank geht: ZWEI Geraetepfade, EIN Kachelpfad.
   */
  const wege = T.tafelPfade({
    sid: SID_A, meta: kopf,
    uebersicht: { sw_hund_22: kachel }, geraete: { 'umec12-a': zM, 'lifevet-a': zK }, vorher: null,
  });
  const geraetePfade = Object.keys(wege.pfade).filter((k) => k.indexOf('/geraete/') > 0).sort();
  const kachelPfade = Object.keys(wege.pfade).filter((k) => k.indexOf('/uebersicht/') > 0);
  ok('geschrieben werden BEIDE Geraetezeilen, aber nur EINE Kachel',
    geraetePfade.join(' ') === ['tafel/' + SID_A + '/geraete/lifevet-a', 'tafel/' + SID_A + '/geraete/umec12-a'].join(' ')
    && kachelPfade.length === 1 && kopf.count === 1,
    geraetePfade.join(' ') + ' | ' + kachelPfade.join(' '));
  ok('der Saalkopf gilt als lebendig (juengste Geraetedaten 800 ms)', kopf.altMs === 800, String(kopf.altMs));
}

/* ---------------- 6) Saalkopf ---------------- */
console.log('\nSaalkopf tafel/<sid>/meta:');
{
  const k1 = T.uebersichtSatz(patVoll, { pri: 2.4, top: 'MAP grenzwertig' }, T0);
  const k2 = T.uebersichtSatz({
    patientKey: 'sw_katze_4', vitals: { hr: 200 }, alarms: [{ a: 1 }, { b: 2 }],
    devices: [{ deviceId: 'x', ip: '10.0.0.1' }], ts: T0 - 2500,
  }, { pri: 4.1, top: 'Tachykardie' }, T0);
  const kopf = T.tafelSatz({
    sid: SID_A, name: 'Praxis OP 1', bv: '1.1.0', instanz: '9c1f4ab27e0d3f56',
    jetzt: T0, uebersicht: { sw_hund_22: k1, sw_katze_4: k2 },
    taktMs: 200, kurven: true, sq: 17, sv: { '.sv': 'timestamp' },
  });
  ok('sid, Name, Fassung und Instanz stehen im Kopf',
    kopf.sid === SID_A && kopf.name === 'Praxis OP 1' && kopf.v === T.TAFEL_V
    && kopf.instanz === '9c1f4ab27e0d3f56', JSON.stringify(kopf));
  ok('Patientenzahl kommt aus den uebergebenen Kacheln', kopf.count === 2);
  ok('hoechste Prioritaet ueber alle eigenen Patienten', kopf.pri === 4.1, String(kopf.pri));
  ok('Alarmzahl ist die Summe', kopf.al === 3, String(kopf.al));
  ok('Alter der JUENGSTEN Geraetedaten (nicht der aeltesten)', kopf.altMs === 0, String(kopf.altMs));
  ok('Takt und Kurvenzusage stehen drin', kopf.taktMs === 200 && kopf.kurven === true);
  ok('Zaehler erfolgreicher Saalschreibvorgaenge steht drin', kopf.sq === 17);
  ok('der Serverplatzhalter wird unveraendert durchgetragen',
    kopf.sv && kopf.sv['.sv'] === 'timestamp', JSON.stringify(kopf.sv));
  /*
   * Die Regel fuer tafel/<sid>/meta.sv laesst NUR ein Fenster von 60 s um die Serverzeit zu. Eine
   * selbst gerechnete Zahl faellt dort durch und nimmt den ganzen atomaren Koerper samt Vitalwerten
   * mit — deshalb wird sie hier weggelassen, nicht durchgereicht.
   */
  ok('eine selbst gerechnete Zahl kommt NICHT als sv durch (die Regel wuerde den Koerper abweisen)',
    !('sv' in T.tafelSatz({ sid: SID_A, jetzt: T0, sv: T0 })),
    JSON.stringify(T.tafelSatz({ sid: SID_A, jetzt: T0, sv: T0 }).sv));
  ok('der Kopf bleibt klein (' + Buffer.byteLength(JSON.stringify(kopf)) + ' Byte)',
    Buffer.byteLength(JSON.stringify(kopf)) < 300, String(Buffer.byteLength(JSON.stringify(kopf))));
  ok('kein probe-Feld (N1: das Merkmal war unerfuellbar)', !('probe' in kopf));
  ok('Bauversion wird nicht geraten', !('bv' in T.tafelSatz({ sid: SID_A, jetzt: T0 })));
  ok('leerer Saal: keine Patienten, Alter unbekannt',
    (() => { const l = T.tafelSatz({ sid: SID_A, jetzt: T0 }); return l.count === 0 && l.al === 0 && !('altMs' in l); })());
  ok('instanz laesst nur Hexzeichen durch',
    T.tafelSatz({ sid: SID_A, jetzt: T0, instanz: '../x9F' }).instanz === '9f',
    String(T.tafelSatz({ sid: SID_A, jetzt: T0, instanz: '../x9F' }).instanz));
  ok('geordnetes Beenden wird als aus vermerkt',
    T.tafelSatz({ sid: SID_A, jetzt: T0, aus: T0 }).aus === T0);
  ok('doppelte Kennung ist im Kopf sichtbar (dop)',
    T.tafelSatz({ sid: SID_A, jetzt: T0, dop: true }).dop === 1);

  /*
   * BEFUND B5: der Deckel sass in tafelPfade, der Kopf rechnete ueber ALLE uebergebenen Kacheln.
   * Nachgemessen mit 14 Kacheln, darunter 'zz_notfall' mit Prioritaet 5 und drei Alarmen: der Kopf
   * meldete pri 5 und al 3 aus einer Kachel, die gar nicht geschrieben wurde — der Nachbarstreifen
   * zeigte einen Alarm, den es in keiner sichtbaren Kachel gab. Jetzt benutzen Kopf und Pfade
   * dieselbe Auswahl, und was abgeschnitten wurde, steht als Zahl im Kopf (N17).
   */
  const viele14 = {};
  for (let i = 0; i < 13; i++) viele14['p' + (i < 10 ? '0' : '') + i] = { pri: 1, al: 0, dev: 1, ts: T0, altMs: 10 };
  viele14.zz_notfall = { pri: 5, al: 3, dev: 1, ts: T0, altMs: 10 };
  const kopf14 = T.tafelSatz({ sid: SID_A, jetzt: T0, uebersicht: viele14 });
  const w14 = T.tafelPfade({ sid: SID_A, meta: kopf14, uebersicht: viele14, vorher: null });
  const geschrieben = Object.keys(w14.pfade)
    .filter((k) => k.indexOf('/uebersicht/') > 0)
    .map((k) => k.split('/uebersicht/')[1]);
  ok('bei 14 Kacheln werden 12 geschrieben und der Kopf zaehlt genau diese 12 (B5)',
    geschrieben.length === T.GRENZEN.kacheln && kopf14.count === geschrieben.length,
    kopf14.count + '/' + geschrieben.length);
  ok('der Kopf nennt keine Prioritaet, die in keiner geschriebenen Kachel steht (B5)',
    geschrieben.length > 0
    && kopf14.pri === Math.max.apply(null, geschrieben.map((k) => (viele14[k] || {}).pri)), String(kopf14.pri));
  ok('der Kopf nennt keinen Alarm, den keine geschriebene Kachel traegt (B5)',
    geschrieben.length > 0
    && kopf14.al === geschrieben.reduce((s, k) => s + ((viele14[k] || {}).al || 0), 0), String(kopf14.al));
  ok('was der Deckel abgeschnitten hat, steht als Zahl im Kopf (N17)',
    kopf14.ueber === 2 && kopf14.ueber === w14.ueber.uebersicht,
    kopf14.ueber + '/' + w14.ueber.uebersicht);
  ok('Kacheldeckel und Geraetedeckel werden getrennt ausgewiesen',
    (() => {
      const g20 = {};
      for (let i = 0; i < 20; i++) g20['g' + (i < 10 ? '0' : '') + i] = { altMs: 5 };
      const kg = T.tafelSatz({ sid: SID_A, jetzt: T0, uebersicht: viele14, geraete: g20 });
      return kg.ueber === 2 && kg.ueberG === 20 - T.GRENZEN.geraete;
    })());
  ok('ein vom Aufrufer mitgegebener count wird NICHT uebernommen (keine zweite Rechnung, B5)',
    T.tafelSatz({ sid: SID_A, jetzt: T0, uebersicht: { a: { al: 0 } }, count: 99 }).count === 1,
    String(T.tafelSatz({ sid: SID_A, jetzt: T0, uebersicht: { a: { al: 0 } }, count: 99 }).count));
}

/* ---------------- 7) Schreibpfade und null-Loeschung (N7) ---------------- */
console.log('\nSchreibpfade und ausdrueckliche null-Loeschung (N7):');
{
  const kachel = T.uebersichtSatz(patVoll, null, T0);
  const zeile = T.geraeteSatz({ deviceId: 'umec12-a', model: 'UMEC12', lastTs: T0 - 100 }, T0);
  const kopf = T.tafelSatz({ sid: SID_A, jetzt: T0, uebersicht: { sw_hund_22: kachel }, geraete: { 'umec12-a': zeile } });

  const r1 = T.tafelPfade({
    sid: SID_A, meta: kopf,
    uebersicht: { sw_hund_22: kachel },
    geraete: { 'umec12-a': zeile },
    vorher: null,
  });
  const p1 = Object.keys(r1.pfade).sort();
  ok('die drei Pfade heissen wortgenau wie im Datenmodell',
    p1.join(' ') === [
      'tafel/' + SID_A + '/geraete/umec12-a',
      'tafel/' + SID_A + '/meta',
      'tafel/' + SID_A + '/uebersicht/sw_hund_22',
    ].join(' '), p1.join(' '));
  ok('beim ersten Mal wird nichts geloescht',
    Object.keys(r1.pfade).every((k) => r1.pfade[k] !== null));
  ok('der Stand nennt, was geschrieben wurde',
    r1.stand.u.join(',') === 'sw_hund_22' && r1.stand.g.join(',') === 'umec12-a',
    JSON.stringify(r1.stand));

  // Zweite Runde: der Patientenschluessel wechselt (Patienten-ID wird nachgetragen) UND das Geraet
  // verschwindet aus der Registry. Beides muss ausdruecklich auf null gehen.
  const kachel2 = T.uebersichtSatz(Object.assign({}, patVoll, { patientKey: 'id_12345' }), null, T0 + 1000);
  const r2 = T.tafelPfade({
    sid: SID_A, meta: kopf,
    uebersicht: { id_12345: kachel2 },
    geraete: {},
    vorher: r1.stand,
  });
  const nulls = Object.keys(r2.pfade).filter((k) => r2.pfade[k] === null).sort();
  ok('genau EIN null-Pfad je verschwundenem Patienten',
    nulls.filter((k) => k.indexOf('/uebersicht/') > 0).length === 1, nulls.join(' '));
  ok('genau EIN null-Pfad je verschwundenem Geraet',
    nulls.filter((k) => k.indexOf('/geraete/') > 0).length === 1, nulls.join(' '));
  ok('die null-Pfade nennen die ALTEN Schluessel',
    nulls.join(' ') === [
      'tafel/' + SID_A + '/geraete/umec12-a',
      'tafel/' + SID_A + '/uebersicht/sw_hund_22',
    ].join(' '), nulls.join(' '));
  ok('der neue Schluessel wird im selben Koerper geschrieben',
    r2.pfade['tafel/' + SID_A + '/uebersicht/id_12345'] === kachel2);
  ok('der Stand fuehrt danach nur noch den neuen Schluessel',
    r2.stand.u.join(',') === 'id_12345' && r2.stand.g.length === 0, JSON.stringify(r2.stand));

  // Dritte Runde: unveraenderter Bestand -> kein einziges null (sonst flackert jede Kachel).
  const r3 = T.tafelPfade({ sid: SID_A, meta: kopf, uebersicht: { id_12345: kachel2 }, geraete: {}, vorher: r2.stand });
  ok('unveraenderter Bestand erzeugt kein null',
    Object.keys(r3.pfade).every((k) => r3.pfade[k] !== null));

  // Harte Sperre bei nicht ausgeschlossener Doppelkennung (N1).
  const rS = T.tafelPfade({ sid: SID_A, meta: kopf, uebersicht: { id_12345: kachel2 }, geraete: {}, vorher: r2.stand, nurMeta: true });
  ok('Sperre: nur der Kopf wird geschrieben, keine Patientendaten',
    Object.keys(rS.pfade).join(',') === 'tafel/' + SID_A + '/meta', Object.keys(rS.pfade).join(','));
  ok('Sperre: auch kein null (ein Zwilling wuerde sonst geloescht)',
    Object.keys(rS.pfade).every((k) => rS.pfade[k] !== null));
  ok('Sperre: das Gedaechtnis bleibt stehen, die Loeschung wird nachgeholt',
    rS.stand.u.join(',') === 'id_12345');

  // Formatsperre: eine unbrauchbare Kennung darf nie in einen Pfad geraten.
  let geworfen = false;
  try { T.tafelPfade({ sid: '../fremd', meta: kopf }); } catch (e) { geworfen = /Stationskennung/.test(e.message); }
  ok('eine Kennung mit Pfadsprung wird abgewiesen, nicht still uebersprungen', geworfen);
  /*
   * Der Kopf muss zu SEINEM Pfad gehoeren: die Regel verlangt child('sid').val() === $station. Ein
   * Kopf mit fremder Kennung weist den ganzen atomaren Koerper ab — hier faellt es beim ersten
   * Aufruf auf, in der Praxis erst nach drei Takten, und dann ist die Fern-Uebertragung aus.
   */
  let fremdKopf = false;
  try { T.tafelPfade({ sid: SID_B, meta: kopf }); } catch (e) { fremdKopf = /Kennung/.test(e.message); }
  ok('ein Kopf mit fremder sid darf nicht in einen anderen Saalpfad geschrieben werden', fremdKopf);

  ok('pruefeSid nimmt nur die feste Form',
    T.pruefeSid(SID_A)
    && !T.pruefeSid('ST7F3A91C2B45D') && !T.pruefeSid('st7f3a91c2b45') && !T.pruefeSid('st7f3a91c2b45d/x'));

  // Deckel (N17): stabile Auswahl, sichtbarer Rest.
  const viele = {};
  for (let i = 0; i < 20; i++) viele['p' + (i < 10 ? '0' : '') + i] = { hr: 60 + i, al: 0, dev: 1, ts: T0, altMs: 10 };
  const rD = T.tafelPfade({ sid: SID_A, meta: kopf, uebersicht: viele, geraete: {}, vorher: null });
  const gezeigt = Object.keys(rD.pfade).filter((k) => k.indexOf('/uebersicht/') > 0);
  ok('hoechstens 12 Kacheln je Saal', gezeigt.length === T.GRENZEN.kacheln, String(gezeigt.length));
  ok('der abgeschnittene Rest ist eine Zahl, kein Schweigen', rD.ueber.uebersicht === 8, String(rD.ueber.uebersicht));
  const rD2 = T.tafelPfade({ sid: SID_A, meta: kopf, uebersicht: viele, geraete: {}, vorher: rD.stand });
  ok('die Auswahl ist bei unveraendertem Bestand dieselbe (kein Erscheinen/Verschwinden)',
    Object.keys(rD2.pfade).filter((k) => rD2.pfade[k] === null).length === 0);
  // Dieselben Kacheln in anderer Reihenfolge uebergeben -> derselbe Koerper. Sonst haengt der Inhalt
  // daran, in welcher Reihenfolge die Registry ihre Geraete gerade gemeldet hat.
  const andersHerum = {};
  Object.keys(viele).reverse().forEach((k) => { andersHerum[k] = viele[k]; });
  ok('die Auswahl haengt nicht an der Reihenfolge der Eingabe',
    JSON.stringify(T.tafelPfade({ sid: SID_A, uebersicht: andersHerum, vorher: null }).pfade)
    === JSON.stringify(T.tafelPfade({ sid: SID_A, uebersicht: viele, vorher: null }).pfade));
  // Und zwei Rohschluessel, die auf denselben Datenbankschluessel fallen, ergeben immer dasselbe.
  ok('kollidierende Rohschluessel loesen sich immer gleich auf',
    JSON.stringify(T.tafelPfade({ sid: SID_A, uebersicht: { 'a/b': { hr: 1 }, 'a:b': { hr: 2 } } }).pfade)
    === JSON.stringify(T.tafelPfade({ sid: SID_A, uebersicht: { 'a:b': { hr: 2 }, 'a/b': { hr: 1 } } }).pfade));
}

/* ---------------- 8) saalName: Determinismus und Beglaubigung ---------------- */
console.log('\nsaalName — alle Schreiber muessen dasselbe errechnen:');
{
  const A = { sid: SID_A, name: 'Praxis OP 1', instanz: 'aaaa000011112222', sv: T0 - 500 };
  const B = { sid: SID_B, name: 'Praxis OP 2', instanz: 'bbbb000011112222', sv: T0 - 900 };
  const alt = { sid: SID_TOT, name: 'Alter Empfangs-PC', instanz: 'cccc000011112222', sv: T0 - 3 * 3600000 };
  const nurA = { [SID_A]: A };
  const AundB = { [SID_A]: A, [SID_B]: B };
  const BundA = { [SID_B]: B, [SID_A]: A };

  ok('ein Saal -> sein eigener Name', T.saalName(nurA, T0) === 'Praxis OP 1', String(T.saalName(nurA, T0)));
  ok('zwei Saele -> die feste gemeinsame Zeichenkette',
    T.saalName(AundB, T0) === T.SPIEGEL_NAME_MEHRSAAL, String(T.saalName(AundB, T0)));
  ok('zwei verschiedene Reihenfolgen ergeben dieselbe Zeichenkette',
    T.saalName(AundB, T0) === T.saalName(BundA, T0));
  ok('der liegengebliebene Knoten eines ausgemusterten PCs zaehlt nicht mit',
    T.saalName({ [SID_A]: A, [SID_TOT]: alt }, T0) === 'Praxis OP 1',
    String(T.saalName({ [SID_A]: A, [SID_TOT]: alt }, T0)));
  ok('ein Eintrag ohne instanz-Feld zaehlt nicht mit',
    T.saalName({ [SID_A]: A, [SID_B]: { sid: SID_B, name: 'Rest', sv: T0 } }, T0) === 'Praxis OP 1');
  ok('kein zaehlbarer Eintrag -> kein Name (der Aufrufer nimmt dann den Ersatznamen)',
    T.saalName({ [SID_TOT]: alt }, T0) === null);
  ok('frischeSaele sortiert stabil nach Saalname',
    T.frischeSaele(BundA, T0).map((e) => e.sid).join(',') === T.frischeSaele(AundB, T0).map((e) => e.sid).join(','),
    T.frischeSaele(BundA, T0).map((e) => e.sid).join(','));
  /*
   * BEFUND B6: die Listenform nahm das sid-FELD unveraendert, weil kein Schluessel dagegenstand.
   * Nachgemessen wurde damit ein Nachbarsaal mit untergeschobenem sid-Feld von modusAus als "der
   * eigene" weggeworfen — zwei laufende Saele ergaben saele=1 und F2-solo, und in F2-solo spiegelt
   * die Station Kurven UND Protokoll unter ihrem eigenen Namen (N8: toedlich). Die Listenform wird
   * deshalb gar nicht mehr angenommen.
   */
  let listeAbgewiesen = false;
  try { T.frischeSaele([A, B], T0); } catch (e) { listeAbgewiesen = /Abbildung/.test(e.message); }
  ok('eine LISTE wird abgewiesen — nur der Schluessel beweist, wo ein Eintrag zu Hause ist (B6)',
    listeAbgewiesen);
  let saalNameListe = false;
  try { T.saalName([A, B], T0); } catch (e) { saalNameListe = /Abbildung/.test(e.message); }
  ok('saalName nimmt ebenfalls nur die Abbildung', saalNameListe);
  ok('ein Eintrag gehoert dorthin, wo er LIEGT — der Schluessel gewinnt ueber das sid-Feld',
    T.frischeSaele({ [SID_B]: { sid: SID_A, name: 'Untergeschoben', instanz: 'dddd000011112222', sv: T0 } }, T0)[0].sid === SID_B);
  /*
   * Frueher hiess diese Pruefung "die gemeinsame Zeichenkette steht nur an EINER Stelle im Code",
   * verglich aber nur einen Teilstring und eine Laenge (Befund B9). Jetzt werden die Vorkommen im
   * Quelltext wirklich gezaehlt — in tafel.js UND in cloud.js, denn dort entsteht der Schaden: zwei
   * Fassungen dieser Zeichenkette lassen den Kopf der Web-App im Sekundentakt flackern.
   */
  const codeCloud = ohneKommentare(fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'cloud.js'), 'utf8'));
  const zaehle = (heu, nadel) => heu.split(nadel).length - 1;
  const vorkommen = zaehle(ohneKommentare(quelleTafel), T.SPIEGEL_NAME_MEHRSAAL) + zaehle(codeCloud, T.SPIEGEL_NAME_MEHRSAAL);
  ok('die gemeinsame Zeichenkette steht in tafel.js und cloud.js zusammen genau EINMAL',
    vorkommen === 1, String(vorkommen));
  ok('auch der Ersatzname fuer einen namenlosen Saal steht nur einmal',
    zaehle(ohneKommentare(quelleTafel), T.SPIEGEL_NAME_UNBENANNT) + zaehle(codeCloud, T.SPIEGEL_NAME_UNBENANNT) === 1);
}

/* ---------------- 9) modusAus: alle Faelle ---------------- */
console.log('\nmodusAus — welcher Kompatibilitaetsmodus gilt (N5, N4, B1-B4):');
{
  const eigen = { sid: SID_A, name: 'Praxis OP 1', instanz: '9c1f4ab27e0d3f56' };
  const nachbar = { sid: SID_B, name: 'Praxis OP 2', instanz: 'bbbb000011112222', sv: T0 - 700 };
  const ausgemustert = { sid: SID_TOT, name: 'Alter PC', instanz: 'cccc000011112222', sv: T0 - 4 * 3600000 };
  const basis = { eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, tafelGelesen: true, flachGelesen: true };
  const mit = (x) => T.modusAus(Object.assign({}, basis, x));

  // F0
  const f0 = T.modusAus({ eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0 });
  ok('F0 solange Tafel und flaches meta nicht gelesen sind', f0.modus === 'F0', f0.modus);
  ok('F0 schreibt NICHTS flach',
    !f0.flach.meta && !f0.flach.station && !f0.flach.qs && !f0.flach.patienten && !f0.flach.protokoll);
  /*
   * BEFUND B2: frueher durfte der allererste Schreibvorgang "die technischen meta-Felder (sv, v)"
   * mitnehmen. Damit entstand ein frisches flaches meta OHNE qs-Kind — und genau das ist unten der
   * Beweis fuer eine fremde 1.0.3. Die Station erklaerte sich im naechsten Takt selbst zur 1.0.3.
   * Dieselbe Ausnahme haette auf einem leeren Konto ausserdem ein meta ohne station/ts erzeugt, das
   * die Bestandsregel hasChildren(['station','ts']) abweist (Befund B1).
   */
  const f0e = T.modusAus({ eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, erstschreibvorgang: true });
  ok('F0 raeumt auch beim ALLERERSTEN Schreibvorgang kein Recht auf die flache Ebene ein (B2)',
    f0e.modus === 'F0' && f0e.flach.meta === false && f0e.flach.qs === false && f0e.flach.station === false,
    JSON.stringify(f0e.flach));
  ok('unbrauchbare eigene Kennung ergibt F0, nie einen Schreibvorgang',
    (() => { const r = T.modusAus({ eigeneSid: 'x', jetzt: T0, tafelGelesen: true, flachGelesen: true }); return r.modus === 'F0' && !r.flach.meta; })());

  // F1: eine 1.0.3 lief schon, als wir starteten -> frisches flaches meta ohne jedes qs-Kind
  const f1a = mit({ flachMeta: { station: 'Praxis OP 1', ts: T0 - 400, sv: T0 - 400, v: 3 }, tafelEintraege: {} });
  ok('F1: frisches flaches meta ohne qs-Kind ist der Beweis', f1a.modus === 'F1', f1a.modus + ' ' + f1a.grund);
  ok('F1 schreibt gar nichts flach — auch kein null und kein qs',
    !f1a.flach.meta && !f1a.flach.station && !f1a.flach.qs && !f1a.flach.patienten
    && !f1a.flach.kurven && !f1a.flach.protokoll);
  ok('F1 sagt im Klartext, was der Tierarzt tun soll', /Fassung 1\.0\.3/.test(f1a.grund) && /aktualisieren/.test(f1a.grund));

  // F1: das Vollbild einer 1.0.3 hat den ganzen meta-Knoten ersetzt -> unser qs-Kind ist weg
  const f1b = mit({
    flachMeta: { station: 'Praxis OP 1', sv: T0 - 200, v: 3, qs: { [SID_B]: T0 - 300 } },
    qsGeschrieben: true, tafelEintraege: { [SID_B]: nachbar },
  });
  ok('F1: unser eigenes qs-Kind ist verschwunden — auch das ist der Beweis', f1b.modus === 'F1', f1b.modus);
  /*
   * Ein qs-Wert ist eine frei gewaehlte Zahl (die Regel verlangt dort nichts). Wuerde ein Wert AUS
   * DER ZUKUNFT als frisch gelten, koennte er dauerhaft eine lebende 1.1.0-Station vortaeuschen und
   * damit den Beweis unterdruecken — die Richtung, in der wir einer laufenden 1.0.3 ihre Ebene
   * ueberschreiben. Deshalb wird die Frische der qs-Kinder STRENG beurteilt (Befund B3).
   */
  const qsZukunft = mit({
    flachMeta: { station: 'Praxis OP 1', sv: T0 - 400, v: 3, qs: { [SID_B]: T0 + 90000 } },
    tafelEintraege: {},
  });
  ok('ein qs-Kind aus der ZUKUNFT unterdrueckt den Beweis nicht (B3)', qsZukunft.modus === 'F1', qsZukunft.modus);

  // F2-solo
  const f2s = mit({
    flachMeta: { station: 'Praxis OP 1', sv: T0 - 800, v: 3, qs: { [SID_A]: T0 - 800 } },
    qsGeschrieben: true, tafelEintraege: {},
  });
  ok('F2-solo wenn nur diese Station frisch ist', f2s.modus === 'F2-solo', f2s.modus);
  ok('F2-solo spiegelt alles, einschliesslich Kurven und Protokoll',
    f2s.flach.meta && f2s.flach.station && f2s.flach.patienten && f2s.flach.kurven && f2s.flach.protokoll);
  ok('F2-solo schreibt den eigenen Saalnamen', f2s.spiegelMeta.station === 'Praxis OP 1', String(f2s.spiegelMeta.station));
  ok('F2-solo sagt der alten Ansicht kurven=true', f2s.spiegelMeta.kurven === true);
  ok('wer meta schreiben darf, darf auch qs schreiben — sonst beweist er sich selbst als 1.0.3 (B2)',
    f2s.flach.qs === true, JSON.stringify(f2s.flach));

  // Der ausdruecklich verlangte Fall: alter PC-Knoten liegt noch da, ist aber nicht frisch
  const f2alt = mit({
    flachMeta: { station: 'Praxis OP 1', sv: T0 - 900, qs: { [SID_A]: T0 - 900 } },
    qsGeschrieben: true,
    tafelEintraege: { [SID_A]: Object.assign({ sv: T0 - 900 }, eigen), [SID_TOT]: ausgemustert },
  });
  ok('ein liegengebliebener Knoten macht aus einer Einzelplatzpraxis KEINEN Mehrsaal-Betrieb',
    f2alt.modus === 'F2-solo' && f2alt.saele === 1, f2alt.modus + '/' + f2alt.saele);
  ok('sie behaelt damit Kurven und Verlauf in der alten Ansicht', f2alt.flach.kurven === true);

  /*
   * BEFUND B3, nachgemessen: der eigene PC geht 5 h nach (leere CMOS-Batterie), der Tafelknoten des
   * ausgemusterten Empfangs-PCs traegt ein sv von vor 4 h SERVERZEIT. Sein Alter ist damit aus
   * unserer Sicht negativ. Frueher galt er deshalb als frisch -> F2-multi, kurven=false: die
   * Einzelplatzpraxis verlor in der alten Ansicht Kurven und Verlauf, genau der Schaden aus N5.
   */
  const jetztFalsch = T0 - 5 * 3600000;
  const nachgehend = T.modusAus({
    eigeneSid: SID_A, eigenSatz: eigen, jetzt: jetztFalsch, tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'Praxis OP 1', sv: jetztFalsch - 500, qs: { [SID_A]: jetztFalsch - 500 } },
    qsGeschrieben: true,
    tafelEintraege: { [SID_TOT]: ausgemustert },
  });
  ok('eine nachgehende eigene Uhr macht aus der Einzelplatzpraxis keinen Mehrsaal-Betrieb (B3)',
    nachgehend.modus === 'F2-solo' && nachgehend.saele === 1 && nachgehend.flach.kurven === true,
    nachgehend.modus + '/' + nachgehend.saele);
  ok('fuer die ANZEIGE bleibt derselbe Knoten sichtbar, aber mit Alter "unbekannt"',
    T.frischeSaele({ [SID_TOT]: ausgemustert }, jetztFalsch, { anzeige: true }).length === 1
    && T.frischeSaele({ [SID_TOT]: ausgemustert }, jetztFalsch, { anzeige: true })[0].stufe === 'unbekannt',
    JSON.stringify(T.frischeSaele({ [SID_TOT]: ausgemustert }, jetztFalsch, { anzeige: true })));
  const nurTsKnoten = { sid: SID_B, name: 'Angeblich', instanz: 'bbbb000011112222', ts: T0 + 11 * 3600000 };
  ok('ein Knoten OHNE Serverzeit mit ts weit in der Zukunft entscheidet keinen Modus (B3)',
    mit({ flachMeta: null, tafelEintraege: { [SID_B]: nurTsKnoten } }).saele === 1,
    String(mit({ flachMeta: null, tafelEintraege: { [SID_B]: nurTsKnoten } }).saele));

  // F2-multi
  const f2m = mit({
    flachMeta: { station: 'x', sv: T0 - 600, qs: { [SID_A]: T0 - 600, [SID_B]: T0 - 700 } },
    qsGeschrieben: true,
    tafelEintraege: { [SID_A]: Object.assign({ sv: T0 - 600 }, eigen), [SID_B]: nachbar },
  });
  ok('F2-multi sobald ein zweiter Saal frisch ist', f2m.modus === 'F2-multi' && f2m.saele === 2,
    f2m.modus + '/' + f2m.saele);
  ok('F2-multi schreibt die feste gemeinsame Zeichenkette',
    f2m.spiegelMeta.station === T.SPIEGEL_NAME_MEHRSAAL, String(f2m.spiegelMeta.station));
  ok('F2-multi sagt ehrlich kurven=false und schreibt kein Protokoll flach',
    f2m.spiegelMeta.kurven === false && f2m.flach.protokoll === false);
  ok('der Spiegeltakt ist in beiden Unterfaellen derselbe (kein Flackern beim Wechsel)',
    f2m.spiegelMeta.taktMs === f2s.spiegelMeta.taktMs && f2m.spiegelMeta.taktMs === 1000);
  ok('die eigene Station zaehlt mit, auch wenn sie noch nicht in der gelesenen Tafel steht',
    mit({ flachMeta: null, tafelEintraege: { [SID_B]: nachbar } }).saele === 2);
  ok('ein untergeschobenes sid-Feld kann sich nicht als der eigene Saal ausgeben (B6)',
    mit({
      flachMeta: null,
      tafelEintraege: { [SID_B]: { sid: SID_A, name: 'Untergeschoben', instanz: 'dddd000011112222', sv: T0 } },
    }).saele === 2);

  /*
   * BEFUND B1: eine Station OHNE konfigurierten Namen lieferte flach.station=true ZUSAMMEN mit
   * spiegelMeta.station=null. Der Aufrufer schriebe damit meta/station=null — in der Datenbank ist
   * das kein leeres Feld, sondern eine LOESCHUNG. Das flache meta verlaere sein Kind 'station', die
   * Bestandsregel hasChildren(['station','ts']) wiese den ganzen Koerper ab, und der traegt im
   * 1-Hz-Takt auch die Vitalwerte.
   */
  const ohneNamen = T.modusAus({
    eigeneSid: SID_A, eigenSatz: { sid: SID_A, instanz: '9c1f4ab27e0d3f56' }, jetzt: T0,
    tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'alt', ts: T0 - 500, sv: T0 - 500, qs: { [SID_A]: T0 - 500 } },
    qsGeschrieben: true, tafelEintraege: {},
  });
  ok('ein Saal ohne Namen schreibt einen ausdruecklichen Ersatznamen, nie null (B1)',
    ohneNamen.flach.station === true && ohneNamen.spiegelMeta.station === T.SPIEGEL_NAME_UNBENANNT,
    String(ohneNamen.spiegelMeta.station));

  // N4/B4: der Latch haelt, bis die flache Ebene wirklich still ist
  const gehalten = mit({ jetzt: T0 + 30000, flachMeta: { sv: T0 - 5 * 60000, qs: {} }, tafelEintraege: {}, vorher: { fremdSeit: T0 } });
  ok('F1 haelt, auch wenn die flache Ebene still ist', gehalten.modus === 'F1', gehalten.modus);
  /*
   * BEFUND B4: 60 s Stille genuegten nicht. Der einzige dauerhafte Beweis fuer eine laufende 1.0.3
   * ist das Verschwinden unseres qs-Kindes, und das passiert nur im VOLLBILD-Takt der Gegenseite
   * (cloud.js:534-535; vollbildMs ist konfigurierbar, cloud.js:170). Bei 90 s Vollbild entstand ein
   * 90-s-Zyklus: Wipe -> F1 -> nach 60 s F2 -> wir schreiben -> das naechste Vollbild loescht uns.
   */
  ok('die Stille-Frist deckt auch ein Vollbild von 90 s ab (B4)', T.FREMD_STILLE_MS >= 3 * 90000,
    String(T.FREMD_STILLE_MS));
  const nach89 = mit({ jetzt: T0 + 89000, flachMeta: { sv: T0 - 5 * 60000, qs: {} }, tafelEintraege: {}, vorher: { fremdSeit: T0 } });
  ok('89 s nach dem Beweis gilt weiter F1 — ein 90-s-Vollbild darf uns nicht dazwischen erwischen (B4)',
    nach89.modus === 'F1', nach89.modus);
  const zurueck = mit({
    jetzt: T0 + T.FREMD_STILLE_MS, flachMeta: { sv: T0 - 5 * 60000, qs: {} },
    tafelEintraege: {}, vorher: { fremdSeit: T0 },
  });
  ok('nach der vollen Stille geht es zurueck nach F2 (N4: der Zustand ist in BEIDE Richtungen offen)',
    zurueck.modus === 'F2-solo', zurueck.modus);
  const wieder = mit({
    jetzt: T0 + 120000, flachMeta: { sv: T0 + 119000, qs: { [SID_A]: T0 + 60000 } },
    qsGeschrieben: true, tafelEintraege: {}, vorher: { fremdSeit: T0 },
  });
  ok('F1 ist JEDERZEIT wieder betretbar (N4), nicht nur einmal je Prozesslauf',
    wieder.modus === 'F1', wieder.modus);
  ok('der Zeitpunkt des Beweises kommt zurueck, damit der Aufrufer keinen Zustand raten muss',
    wieder.fremdSeit === T0 + 120000, String(wieder.fremdSeit));
  const uhrZurueck = mit({
    jetzt: T0 - 30000, flachMeta: { sv: T0 - 5 * 60000, qs: {} },
    tafelEintraege: {}, vorher: { fremdSeit: T0 },
  });
  ok('ein Uhrensprung nach hinten LOEST die Sperre nicht (F1 haelt)', uhrZurueck.modus === 'F1',
    uhrZurueck.modus);
  const vorlauf = mit({ flachMeta: { station: 'Praxis OP 1', sv: T0 + 90000, v: 3 }, tafelEintraege: {} });
  ok('eine 1.0.3 macht sich nicht durch eine vorlaufende Uhr unsichtbar', vorlauf.modus === 'F1',
    vorlauf.modus);
  ok('die Fassungsunterscheidung haengt NICHT an meta/v (das bleibt konstant 3)',
    mit({ flachMeta: { v: 3, sv: T0 - 500, qs: { [SID_A]: T0 - 500 } }, qsGeschrieben: true, tafelEintraege: {} })
      .modus === 'F2-solo');

  /*
   * RUECKKOPPLUNG (Befund B2): was diese Station nach ihren eigenen Rechten schreibt, liest sie im
   * naechsten Takt wieder ein. Daraus darf NIE der Beweis fuer eine fremde 1.0.3 werden. Der Test
   * baut das flache meta ausschliesslich aus dem, was das jeweilige Recht erlaubt — genau so, wie es
   * der Aufrufer tun muss.
   */
  const flachAus = (r, zeit) => {
    if (!r.flach.meta) return null;                    // nichts geschrieben -> nichts liegt da
    const m = { sv: zeit, v: 3 };
    if (r.flach.station) { m.station = r.spiegelMeta.station; m.ts = r.spiegelMeta.ts; }
    if (r.flach.qs) m.qs = { [SID_A]: zeit };
    return m;
  };
  const laeufe = [
    ['F0 (nichts gelesen)', T.modusAus({ eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, erstschreibvorgang: true })],
    ['F2-solo', f2s],
    ['F2-multi', f2m],
    ['F2-solo ohne Namen', ohneNamen],
  ];
  let rueckOk = true, rueckWer = '';
  laeufe.forEach(([wie, r]) => {
    const geschriebenes = flachAus(r, T0);
    const naechster = T.modusAus({
      eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0 + 1000, tafelGelesen: true, flachGelesen: true,
      flachMeta: geschriebenes, qsGeschrieben: r.flach.qs === true,
      tafelEintraege: r.modus === 'F2-multi' ? { [SID_B]: Object.assign({}, nachbar, { sv: T0 + 300 }) } : {},
    });
    if (naechster.modus === 'F1') { rueckOk = false; rueckWer = wie; }
  });
  ok('kein Takt, den diese Station selbst schreibt, macht sie im naechsten Takt zur fremden 1.0.3 (B2)',
    rueckOk, rueckWer);

  /*
   * VERTRAG MIT DER BESTANDSREGEL (Befund B1): wer meta flach schreiben darf, MUSS station und ts
   * mitschreiben koennen — hasChildren(['station','ts']) weist sonst den ganzen Koerper ab. Geprueft
   * ueber alle oben gerechneten Faelle auf einmal.
   */
  const alleLaeufe = [f0, f0e, f1a, f1b, qsZukunft, f2s, f2alt, f2m, ohneNamen, gehalten, nach89, zurueck, wieder, uhrZurueck, vorlauf, nachgehend];
  const verletzt = alleLaeufe.filter((r) => r.flach.meta && !(
    r.flach.station === true
    && typeof r.spiegelMeta.station === 'string' && r.spiegelMeta.station.length > 0
    && typeof r.spiegelMeta.ts === 'number'));
  ok('in JEDEM Modus, der meta flach schreiben darf, stehen station (Text) und ts (Zahl) bereit (B1)',
    verletzt.length === 0, verletzt.map((r) => r.modus).join(','));
  ok('das Recht qs gilt genau dann, wenn das Recht meta gilt (B2)',
    alleLaeufe.every((r) => r.flach.qs === r.flach.meta));
}

/* ---------------- 9b) Befund A1: das EIGENE qs-Kind gegen ein FREMDES ---------------- */
console.log('\nDas eigene qs-Kind darf die Station nicht zur fremden 1.0.3 machen (A1):');
{
  const eigen = { sid: SID_A, name: 'Praxis OP 1', instanz: '9c1f4ab27e0d3f56' };
  const nachbar = { sid: SID_B, name: 'Praxis OP 2', instanz: 'bbbb000011112222', sv: T0 - 700 };

  /*
   * Einzelplatzpraxis, KEINE 1.0.3 im Konto. Diese Station bespielt die flache Ebene selbst und setzt
   * ihr eigenes qs-Kind jede Sekunde. 'vorlauf' ist der Fehler der Serverzeitschaetzung: die
   * HTTP-Date-Kopfzeile hat 1 s Aufloesung und wird abgeschnitten, sie UNTERschaetzt die Serverzeit
   * also — das eigene qs liegt dann vor 'jetzt'.
   */
  const eigenesQs = (vorlauf) => T.modusAus({
    eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'Praxis OP 1', ts: T0 - 200, sv: T0 - 200, v: 3, qs: { [SID_A]: T0 + vorlauf } },
    qsGeschrieben: true, tafelEintraege: {},
  });
  ok('das eigene qs 200 ms ALT: F2-solo (das ging auch vorher)', eigenesQs(-200).modus === 'F2-solo',
    eigenesQs(-200).modus);
  ok('das eigene qs 300 ms in der ZUKUNFT: weiter F2-solo, nicht F1 (A1)',
    eigenesQs(300).modus === 'F2-solo', eigenesQs(300).modus + ' — ' + eigenesQs(300).grund);
  ok('auch bei 1200 ms Schaetzfehler gegen ein 1000 ms altes qs',
    eigenesQs(200).modus === 'F2-solo', eigenesQs(200).modus);
  ok('auch bei einer 30 s vorgehenden PC-Uhr im qs-Wert',
    eigenesQs(30000).modus === 'F2-solo', eigenesQs(30000).modus);
  /*
   * Das Fenster ist BEGRENZT, und zwar auf dieselben 60 s wie jedes andere Frischemass dieser Datei.
   * Ohne Grenze koennte ein liegengebliebenes eigenes Kind mit einem Fantasiewert den Beweis fuer
   * eine wirklich laufende 1.0.3 fuer immer unterdruecken.
   */
  ok('59,999 s Vorlauf gilt gerade noch als "unser Kind steht da"',
    eigenesQs(T.FRISCH_MS - 1).modus === 'F2-solo', eigenesQs(T.FRISCH_MS - 1).modus);
  ok('genau 60 s Vorlauf nicht mehr — das Fenster ist begrenzt',
    eigenesQs(T.FRISCH_MS).modus === 'F1', eigenesQs(T.FRISCH_MS).modus);
  ok('nach hinten gilt unveraendert dieselbe Grenze',
    eigenesQs(-(T.FRISCH_MS - 1)).modus === 'F2-solo' && eigenesQs(-T.FRISCH_MS).modus === 'F1',
    eigenesQs(-(T.FRISCH_MS - 1)).modus + '/' + eigenesQs(-T.FRISCH_MS).modus);

  /*
   * DIE ANDERE SEITE DER ASYMMETRIE. Bei einem FREMDEN qs-Kind bleibt es streng: dort lautet die
   * Frage "lebt dort eine Station ab 1.1.0?", und ein Wert aus der Zukunft wuerde eine solche
   * Station vortaeuschen und damit den Beweis fuer eine laufende 1.0.3 unterdruecken — die Richtung,
   * in der wir einer 1.0.3 ihre flache Ebene ueberschreiben. Eine Fassung, die BEIDE nachsichtig
   * behandelt, faellt genau hier durch.
   */
  const fremdesQs = (vorlauf) => T.modusAus({
    eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'x', ts: T0 - 200, sv: T0 - 200, v: 3, qs: { [SID_B]: T0 + vorlauf } },
    tafelEintraege: { [SID_B]: nachbar },
  });
  ok('ein FREMDES qs 300 ms in der Zukunft zaehlt NICHT — der Beweis bleibt stehen (A1)',
    fremdesQs(300).modus === 'F1', fremdesQs(300).modus);
  ok('dasselbe fremde qs 300 ms ALT zaehlt dagegen', fremdesQs(-300).modus === 'F2-multi',
    fremdesQs(-300).modus);

  /*
   * DER GEMESSENE VERLAUF aus Befund A1, nachgestellt: der Aufrufer schreibt qs mit einer PC-Uhr, die
   * 30 s vorgeht; meta/sv setzt die Datenbank selbst. Gemessen wurde damit F2-solo bei t+0 s, F1 bei
   * t+1 s, wieder F2-solo bei t+329 s ... — EIN gespiegelter Takt je 5,5 Minuten. Die ausgelieferte
   * Web-App 1.0.3 meldet sich dabei als "live" und zeigt bis zu 5,5 Minuten alte Vitalwerte neben
   * einer laufenden Narkose.
   */
  let fremdSeit = null, f1Takte = 0, gespiegelt = 0;
  const takte = 700;
  for (let i = 0; i < takte; i++) {
    const jetzt = T0 + i * 1000;
    const r = T.modusAus({
      eigeneSid: SID_A, eigenSatz: eigen, jetzt: jetzt, tafelGelesen: true, flachGelesen: true,
      flachMeta: {
        station: 'Praxis OP 1', ts: jetzt - 1000, sv: jetzt - 1000, v: 3,
        qs: { [SID_A]: jetzt - 1000 + 30000 },      // mit der 30 s vorgehenden PC-Uhr geschrieben
      },
      qsGeschrieben: true, tafelEintraege: {}, vorher: { fremdSeit: fremdSeit },
    });
    fremdSeit = r.fremdSeit;
    if (r.modus === 'F1') f1Takte++;
    if (r.flach.meta === true) gespiegelt++;
  }
  ok('700 Takte mit einer 30 s vorgehenden Uhr im eigenen qs: kein einziger F1-Takt (A1)',
    f1Takte === 0, f1Takte + ' von ' + takte);
  ok('der dauerhaft eingeschaltete Spiegel wird in JEDEM Takt bespielt, nicht in einem je 5,5 min',
    gespiegelt === takte, gespiegelt + ' von ' + takte);

  /*
   * WELCHEN WERT DER AUFRUFER ALS qs SCHREIBT, ENTSCHEIDET DAS MODUL (Befund A1, zweite Haelfte).
   * Bei meta.sv wird die Platzhalterpflicht geprueft (tafelSatz nimmt nur {".sv":"timestamp"}); beim
   * qs-Wert stand sie nirgends — weder Pruefung noch Kommentar. Genau darueber kam die PC-Uhr oben
   * ueberhaupt erst in den qs-Wert.
   */
  const f2 = eigenesQs(-200);
  ok('F2 liefert den qs-Wert fertig: der Serverplatzhalter, nie eine gerechnete Zahl (A1)',
    T.istServerZeitstempel(f2.spiegelQs.wert) === true, JSON.stringify(f2.spiegelQs));
  ok('und er geht unter den EIGENEN Schluessel, nie auf den ganzen qs-Knoten',
    f2.spiegelQs.sid === SID_A);
  const mitPcUhr = T.modusAus({
    eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'Praxis OP 1', ts: T0 - 200, sv: T0 - 200, v: 3, qs: { [SID_A]: T0 - 200 } },
    qsGeschrieben: true, tafelEintraege: {}, qsWert: T0 + 30000,
  });
  ok('eine uebergebene PC-Uhr wird GEPRUEFT und durch den Platzhalter ersetzt (A1)',
    T.istServerZeitstempel(mitPcUhr.spiegelQs.wert) === true, JSON.stringify(mitPcUhr.spiegelQs));
  ok('ein uebergebener Platzhalter geht unveraendert durch',
    T.modusAus({
      eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, tafelGelesen: true, flachGelesen: true,
      flachMeta: { station: 'P', ts: T0 - 200, sv: T0 - 200, qs: { [SID_A]: T0 - 200 } },
      qsGeschrieben: true, tafelEintraege: {}, qsWert: { '.sv': 'timestamp' },
    }).spiegelQs.wert['.sv'] === 'timestamp');
  ok('wer kein qs-Recht hat, bekommt auch keinen qs-Wert (F0 und F1)',
    T.modusAus({ eigeneSid: SID_A, jetzt: T0 }).spiegelQs.wert === null
    && fremdesQs(300).spiegelQs.wert === null,
    JSON.stringify(fremdesQs(300).spiegelQs));
}

/* ---------------- 9c) Befund A2: F1 darf sich nicht selbst festhalten ---------------- */
console.log('\nF1 haelt sich nicht selbst fest — auch nicht bei falsch verstandenem qsGeschrieben (A2):');
{
  const eigen = { sid: SID_A, name: 'Praxis OP 1', instanz: '9c1f4ab27e0d3f56' };
  const nachbar = { sid: SID_B, name: 'Praxis OP 2', instanz: 'bbbb000011112222' };
  /*
   * Nachgemessene Lage: zwei Stationen ab 1.1.0, die 1.0.3 ist laengst abgeschaltet. Station A sass
   * 5 min in F1 und hatte dort kein qs-Recht; Station B bespielt die flache Ebene weiter und setzt
   * ihr qs jede Sekunde. Der Aufrufer von A meldet qsGeschrieben nach der FALSCHEN Lesart dauerhaft
   * true ("wir schreiben in dieser Fassung ueberhaupt qs"). Mit dieser Lesart erneuerte sich F1 in
   * jedem Takt: bei +1 min, +6 min, +60 min und +600 min durchgehend F1 — A spiegelte ihre Patienten
   * nie wieder in die alte Fern-Ansicht.
   */
  let fremdSeit = T0;                 // A sitzt seit T0 in F1
  let eigenesQs = T0;                 // ihr letzter qs-Wert stammt von kurz davor und altert
  let zurueckBei = null, f1NachRueckkehr = 0, letzterModus = '';
  for (let i = 1; i <= 700; i++) {
    const jetzt = T0 + i * 1000;
    const kinder = { [SID_B]: jetzt - 300 };
    if (eigenesQs != null) kinder[SID_A] = eigenesQs;
    const r = T.modusAus({
      eigeneSid: SID_A, eigenSatz: eigen, jetzt: jetzt, tafelGelesen: true, flachGelesen: true,
      flachMeta: { station: 'x', ts: jetzt - 300, sv: jetzt - 300, v: 3, qs: kinder },
      qsGeschrieben: true,            // die falsche Lesart
      tafelEintraege: { [SID_B]: Object.assign({}, nachbar, { sv: jetzt - 300 }) },
      vorher: { fremdSeit: fremdSeit },
    });
    fremdSeit = r.fremdSeit;
    letzterModus = r.modus;
    if (r.flach.qs === true) eigenesQs = jetzt;      // nur MIT Recht wird wirklich geschrieben
    if (r.modus !== 'F1' && zurueckBei == null) zurueckBei = i;
    if (zurueckBei != null && r.modus === 'F1') f1NachRueckkehr++;
  }
  ok('A kommt nach der Stille-Frist zurueck, statt fuer immer in F1 zu bleiben (A2)',
    zurueckBei === T.FREMD_STILLE_MS / 1000, String(zurueckBei));
  ok('und sie bleibt zurueck — kein Rueckfall in 700 Takten', f1NachRueckkehr === 0,
    String(f1NachRueckkehr));
  ok('nach 700 Takten spiegelt sie im Mehrsaal-Modus weiter', letzterModus === 'F2-multi', letzterModus);

  /*
   * DIE GEGENRICHTUNG, damit die Sicherung keinen Beweis verschluckt: eine WIRKLICHE 1.0.3 faellt
   * weiter sofort auf. Ihr Vollbild ersetzt den ganzen meta-Knoten und loescht damit ALLE qs-Kinder
   * auf einmal, auch die der Nachbarn — dieser Beweisweg haengt an keiner Frist.
   */
  const echtesVollbild = T.modusAus({
    eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'Praxis 1.0.3', ts: T0 - 200, sv: T0 - 200, v: 3 },
    qsGeschrieben: true,
    tafelEintraege: { [SID_B]: Object.assign({}, nachbar, { sv: T0 - 300 }) },
    vorher: { fremdSeit: T0 - 10 * 60000 },
  });
  ok('ein echtes Vollbild einer 1.0.3 ergibt sofort F1, egal wie lange F1 zuletzt her ist',
    echtesVollbild.modus === 'F1', echtesVollbild.modus);
  /*
   * Und der zweite Beweisweg (nur UNSER Kind fehlt, das des Nachbarn steht) bleibt wirksam, sobald
   * wir wieder ein volles Frischefenster lang schreiben durften. Die beiden Faelle liegen genau eine
   * Sekunde auseinander — das ist die Kante, an der die Sicherung sitzt.
   */
  const nurUnseres = (seit) => T.modusAus({
    eigeneSid: SID_A, eigenSatz: eigen, jetzt: T0, tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'x', ts: T0 - 200, sv: T0 - 200, v: 3, qs: { [SID_B]: T0 - 300 } },
    qsGeschrieben: true,
    tafelEintraege: { [SID_B]: Object.assign({}, nachbar, { sv: T0 - 300 }) },
    vorher: { fremdSeit: seit },
  });
  const genug = T0 - (T.FREMD_STILLE_MS + T.FRISCH_MS);
  ok('lange genug in F2: unser fehlendes Kind beweist wieder ein fremdes Vollbild (B2 bleibt scharf)',
    nurUnseres(genug).modus === 'F1', nurUnseres(genug).modus);
  ok('eine Sekunde zu frueh: kein Beweis aus dem eigenen Schweigen (A2)',
    nurUnseres(genug + 1000).modus === 'F2-multi', nurUnseres(genug + 1000).modus);
}

/* ---------------- 9d) Befund A3: EIN Weg zum Spiegelnamen ---------------- */
console.log('\nsaalName() und modusAus() errechnen fuer meta/station DASSELBE (A3):');
{
  const eigen = { sid: SID_A, name: 'Praxis OP 1', instanz: '9c1f4ab27e0d3f56' };
  const nachbar = { sid: SID_B, name: 'Praxis OP 2', instanz: 'bbbb000011112222', sv: T0 - 700 };
  const ohneName = { sid: SID_A, instanz: '9c1f4ab27e0d3f56' };
  // Der Schreiber muss seinen eigenen Saal mitgeben — sonst rechnet er die Sicht eines Lesers.
  const alsSchreiber = (e) => ({ sid: e.sid, name: e.name, instanz: e.instanz });
  const modus = (karte, e) => T.modusAus({
    eigeneSid: SID_A, eigenSatz: e, jetzt: T0, tafelGelesen: true, flachGelesen: true,
    flachMeta: { station: 'x', ts: T0 - 300, sv: T0 - 300, v: 3, qs: { [SID_A]: T0 - 300 } },
    qsGeschrieben: true, tafelEintraege: karte,
  });
  /*
   * Der nachgemessene Fall: der EIGENE Tafelknoten traegt ein sv 800 ms VOR der eigenen
   * Uhrschaetzung. saalName() warf ihn aus der Zaehlung (istZaehlbar verlangt bekanntes Alter) und
   * lieferte 'Praxis OP 2' — den Namen des NACHBARN —, waehrend modusAus() SPIEGEL_NAME_MEHRSAAL
   * lieferte. Zwei Stationen, die dieses eine Feld ueber verschiedene Wege schreiben, lassen den Kopf
   * der ausgelieferten Web-App im Sekundentakt zwischen beiden Fassungen flackern.
   */
  const faelle = [
    ['eigener Knoten aus der Zukunft, dazu ein Nachbar',
      { [SID_A]: Object.assign({}, eigen, { sv: T0 + 800 }), [SID_B]: nachbar }, eigen],
    ['leere Tafel (erster Takt)', {}, eigen],
    ['nur der Nachbar steht da', { [SID_B]: nachbar }, eigen],
    ['eigener Knoten frisch und zaehlbar', { [SID_A]: Object.assign({}, eigen, { sv: T0 - 300 }) }, eigen],
    ['eigener Knoten frisch, dazu ein Nachbar',
      { [SID_A]: Object.assign({}, eigen, { sv: T0 - 300 }), [SID_B]: nachbar }, eigen],
    ['ausgemusterter Knoten liegt noch da',
      { [SID_TOT]: { sid: SID_TOT, name: 'Alter PC', instanz: 'cccc000011112222', sv: T0 - 4 * 3600000 } }, eigen],
    ['Saal ohne konfigurierten Namen', { [SID_B]: nachbar }, ohneName],
    ['untergeschobenes sid-Feld unter fremdem Schluessel',
      { [SID_B]: { sid: SID_A, name: 'Untergeschoben', instanz: 'dddd000011112222', sv: T0 } }, eigen],
  ];
  let ungleich = '';
  faelle.forEach(([wie, karte, e]) => {
    // null heisst "kein zaehlbarer Saal"; modusAus setzt dafuer den ausdruecklichen Ersatznamen ein.
    const ausSaalName = T.saalName(karte, T0, alsSchreiber(e)) || T.SPIEGEL_NAME_UNBENANNT;
    if (ausSaalName !== modus(karte, e).spiegelMeta.station) ungleich += wie + '; ';
  });
  ok('beide Wege liefern in allen ' + faelle.length + ' Lagen dieselbe Zeichenkette (A3)',
    ungleich === '', ungleich);
  const karteZukunft = { [SID_A]: Object.assign({}, eigen, { sv: T0 + 800 }), [SID_B]: nachbar };
  ok('und im gemessenen Fall ist das der Mehrsaal-Name, nicht der des Nachbarn',
    T.saalName(karteZukunft, T0, alsSchreiber(eigen)) === T.SPIEGEL_NAME_MEHRSAAL,
    String(T.saalName(karteZukunft, T0, alsSchreiber(eigen))));
  ok('der eigene Saal steht genau EINMAL in der Zaehlung, auch wenn er schon in der Tafel liegt',
    modus({ [SID_A]: Object.assign({}, eigen, { sv: T0 - 300 }) }, eigen).saele === 1);
  /*
   * OHNE den eigenen Saal ist saalName ausdruecklich die Sicht eines LESERS (Web-App, Nachbar-Kiosk):
   * nur das, was in der Datenbank steht. Das ist kein Widerspruch zu oben, sondern die andere Frage.
   */
  ok('ohne eigenen Saal bleibt saalName die Sicht eines reinen Lesers',
    T.saalName(karteZukunft, T0) === 'Praxis OP 2', String(T.saalName(karteZukunft, T0)));
}

/* ---------------- 9e) Befund A6: der Saalkopf im Sperrfall nurMeta ---------------- */
console.log('\nIm Sperrfall nurMeta behauptet der Kopf keine Kachel, die es nicht gibt (A6):');
{
  const kacheln = { 'sw_hund_22': { n: 'Rex', pri: 3, al: 2, altMs: 400 }, 'id_12345': { n: 'Mia', pri: 1, al: 0, altMs: 900 } };
  const zeilen = { 'monitor-1': { model: 'LifeVet', altMs: 400 } };
  const kopf = T.tafelSatz({ sid: SID_A, jetzt: T0, name: 'Praxis OP 1', uebersicht: kacheln, geraete: zeilen });
  ok('ohne Sperre zaehlt der Kopf die Kacheln, die auch geschrieben werden',
    kopf.count === 2 && kopf.pri === 3 && kopf.al === 2 && kopf.altMs === 400,
    JSON.stringify(kopf));
  const gesperrt = T.tafelPfade({ sid: SID_A, meta: kopf, uebersicht: kacheln, geraete: zeilen, nurMeta: true });
  const pfade = Object.keys(gesperrt.pfade);
  ok('die harte Sperre schreibt genau EINEN Pfad — den Kopf',
    pfade.length === 1 && pfade[0] === 'tafel/' + SID_A + '/meta', pfade.join(','));
  const geschrieben = gesperrt.pfade['tafel/' + SID_A + '/meta'];
  /*
   * Sonst zeigen der Nachbarstreifen und die Tafelkarte fuer diesen Saal Prioritaet 3 und zwei
   * Alarme, ohne dass in diesem Takt eine einzige Kachel dahinter geschrieben wurde — dieselbe
   * Aussage, die Befund B5 als Schaden benennt ("ein Alarm, den es in keiner Kachel gibt").
   */
  ok('der geschriebene Kopf zaehlt keine Kachel, keinen Alarm und keine Prioritaet (A6)',
    geschrieben.count === 0 && geschrieben.al === 0 && geschrieben.ueber === 0
    && geschrieben.ueberG === 0 && !('pri' in geschrieben) && !('altMs' in geschrieben),
    JSON.stringify(geschrieben));
  ok('die Pflichtfelder und die Kennzeichnung ueberstehen die Berichtigung',
    geschrieben.sid === SID_A && geschrieben.v === T.TAFEL_V && geschrieben.name === 'Praxis OP 1');
  ok('das Objekt des Aufrufers bleibt dabei unveraendert (es gehoert ihm)',
    kopf.count === 2 && kopf.pri === 3 && kopf.al === 2);
  ok('ohne Sperre wird der Kopf NICHT berichtigt — dort stimmt er ja',
    T.tafelPfade({ sid: SID_A, meta: kopf, uebersicht: kacheln, geraete: zeilen })
      .pfade['tafel/' + SID_A + '/meta'].count === 2);
  ok('und das Gedaechtnis bleibt im Sperrfall unangetastet (N1)',
    T.tafelPfade({ sid: SID_A, meta: kopf, uebersicht: kacheln, nurMeta: true, vorher: { u: ['weg_1'], g: [] } })
      .stand.u.join(',') === 'weg_1');
}

/* ---------------- 10) herzschlagFaellig (N6) ---------------- */
console.log('\nherzschlagFaellig — der Tafeltakt IST der Herzschlag eines Saals (N6):');
{
  ok('noch nie geschrieben -> faellig', T.herzschlagFaellig({ jetzt: T0, letzter: null, patientenZahl: 1 }) === true);
  ok('999 ms nach dem letzten Takt -> noch nicht faellig',
    T.herzschlagFaellig({ jetzt: T0 + 999, letzter: T0, patientenZahl: 1 }) === false);
  ok('genau 1000 ms -> faellig, OHNE dass sich ein Wert geaendert hat',
    T.herzschlagFaellig({ jetzt: T0 + 1000, letzter: T0, patientenZahl: 1 }) === true);
  ok('30 s Stille des Geraets unterbrechen den Herzschlag nicht',
    [1000, 2000, 3000, 30000].every((d) => T.herzschlagFaellig({ jetzt: T0 + d, letzter: T0, patientenZahl: 1 }) === true));
  /*
   * Frueher stand hier T.herzschlagFaellig.length === 1 — eine Aussage ueber die Stelligkeit, die
   * jede Fassung besteht, auch eine mit 'if (a.werteGleich) return false;' (Befund B9). Geprueft
   * wird jetzt, dass zusaetzliche Felder im Argument das Ergebnis NICHT veraendern.
   */
  const anhang = { werteGleich: true, geaendert: false, keys: [], nurHerzschlag: true, gleich: true };
  const gleichGeblieben = [
    [T0 + 999, 1], [T0 + 1000, 1], [T0 + 4999, 0], [T0 + 5000, 0], [T0 + 30000, 1], [T0 - 5000, 1],
  ].every(([j, p]) => T.herzschlagFaellig({ jetzt: j, letzter: T0, patientenZahl: p })
    === T.herzschlagFaellig(Object.assign({ jetzt: j, letzter: T0, patientenZahl: p }, anhang)));
  ok('zusaetzliche Felder im Argument aendern nichts — an einem Wert kann der Herzschlag nie haengen',
    gleichGeblieben);
  ok('leerer OP: 4999 ms -> noch nicht faellig',
    T.herzschlagFaellig({ jetzt: T0 + 4999, letzter: T0, patientenZahl: 0 }) === false);
  ok('leerer OP: 5000 ms -> faellig (Sparregel auf die neue Lage)',
    T.herzschlagFaellig({ jetzt: T0 + 5000, letzter: T0, patientenZahl: 0 }) === true);
  ok('die Patientenzahl entscheidet nur ueber 1 s gegen 5 s, nie ueber "gar nicht"',
    [0, 1, 5].every((p) => T.herzschlagFaellig({ jetzt: T0 + 5000, letzter: T0, patientenZahl: p }) === true));
  ok('Takt 1 s mit Patient, 5 s ohne',
    T.tafelTakt(1) === 1000 && T.tafelTakt(0) === 5000, T.tafelTakt(1) + '/' + T.tafelTakt(0));
  ok('der Takt ist einstellbar, aber nie unter 200 ms',
    T.tafelTakt(1, { tafelTaktMs: 50 }) === 200 && T.tafelTakt(1, { tafelTaktMs: 2000 }) === 2000);
  ok('zurueckgestellte Uhr macht faellig statt den Herzschlag anzuhalten',
    T.herzschlagFaellig({ jetzt: T0 - 5000, letzter: T0, patientenZahl: 1 }) === true);
  ok('ohne Uhr wird nichts entschieden', T.herzschlagFaellig({ letzter: T0 }) === false);
}

/* ---------------- 11) Gemeinsame Kappung (N9) ---------------- */
console.log('\nGemeinsame Kappung fuer JEDEN Snapshotwert (N9):');
{
  ok('Zeichenkette auf 200 gekuerzt', T.kappe('x'.repeat(500)).length === T.GRENZEN.wert);
  const grossesObjekt = {};
  for (let i = 0; i < 60; i++) grossesObjekt['f' + (i < 10 ? '0' : '') + i] = i;
  ok('Objekt auf 40 Felder gekuerzt', Object.keys(T.kappe(grossesObjekt)).length === T.GRENZEN.felder);
  const andereReihenfolge = {};
  Object.keys(grossesObjekt).reverse().forEach((k) => { andereReihenfolge[k] = grossesObjekt[k]; });
  ok('welche 40 Felder ueberleben, haengt NICHT an der Einfuegereihenfolge',
    JSON.stringify(T.kappe(grossesObjekt)) === JSON.stringify(T.kappe(andereReihenfolge)));
  ok('Liste auf 80 Eintraege gekuerzt', T.kappe(new Array(200).fill(1)).length === T.GRENZEN.liste);
  ok('NaN und Unendlich werden null', T.kappe(NaN) === null && T.kappe(Infinity) === null);
  ok('der Serverplatzhalter uebersteht die Kappung unveraendert',
    JSON.stringify(T.kappe({ '.sv': 'timestamp' })) === '{".sv":"timestamp"}');
  let tief = { a: 1 };
  for (let i = 0; i < 12; i++) tief = { a: tief };
  ok('zu tiefe Verschachtelung wird abgeschnitten', JSON.stringify(T.kappe(tief)).length < 60,
    String(JSON.stringify(T.kappe(tief)).length));
  ok('Freitext wird NICHT gefiltert, nur begrenzt (er ist Teil eines Dokuments)',
    T.kappe('Alarm: SpO2 < 90 %') === 'Alarm: SpO2 < 90 %');
  ok('Tafeltexte dagegen werden gefiltert', T.text('Alarm: SpO2 < 90 %') === 'Alarm: SpO2 90 %',
    String(T.text('Alarm: SpO2 < 90 %')));
  ok('der Schluesseldeckel steht in GRENZEN und wirkt (B8)',
    T.GRENZEN.schluessel === 200 && T.schluessel('k'.repeat(500)).length === T.GRENZEN.schluessel
    && T.schluessel('k'.repeat(500), 30).length === 30);
}

/* ---------------- 12) Vertrag gegen installer/firebase-rtdb-rules.json (B1, B8, N9) ---------------- */
console.log('\nVertrag mit der Regeldatei — ein abgewiesenes Feld kostet den ganzen 1-Hz-Koerper (B1/B8):');
{
  const regelPfad = path.join(__dirname, '..', 'installer', 'firebase-rtdb-rules.json');
  const R = JSON.parse(ohneKommentare(fs.readFileSync(regelPfad, 'utf8'))).rules.live.$praxis;
  const T$ = R.tafel.$station;
  const gleich = (a, b) => a.slice().sort().join(',') === b.slice().sort().join(',');
  const laenge = (v, marke) => {
    const m = new RegExp(marke + '\\.length\\s*<=\\s*(\\d+)').exec(String(v || ''));
    return m ? Number(m[1]) : null;
  };

  ok('PFLICHTFELDER.flachMeta ist wortgleich mit der Bestandsregel fuer meta',
    gleich(pflichtAus(R.meta['.validate']), T.PFLICHTFELDER.flachMeta),
    pflichtAus(R.meta['.validate']).join(',') + ' vs ' + T.PFLICHTFELDER.flachMeta.join(','));
  ok('PFLICHTFELDER.tafelMeta ist wortgleich mit der Regel fuer tafel/<sid>/meta',
    gleich(pflichtAus(T$.meta['.validate']), T.PFLICHTFELDER.tafelMeta),
    pflichtAus(T$.meta['.validate']).join(',') + ' vs ' + T.PFLICHTFELDER.tafelMeta.join(','));
  ok('PFLICHTFELDER.uebersicht ist wortgleich mit der Regel fuer tafel/<sid>/uebersicht/<key>',
    gleich(pflichtAus(T$.uebersicht.$key['.validate']), T.PFLICHTFELDER.uebersicht),
    pflichtAus(T$.uebersicht.$key['.validate']).join(',') + ' vs ' + T.PFLICHTFELDER.uebersicht.join(','));
  ok('PFLICHTFELDER.geraete ist wortgleich mit der Regel fuer tafel/<sid>/geraete/<id>',
    gleich(pflichtAus(T$.geraete.$geraet['.validate']), T.PFLICHTFELDER.geraete),
    pflichtAus(T$.geraete.$geraet['.validate']).join(',') + ' vs ' + T.PFLICHTFELDER.geraete.join(','));

  /*
   * BEFUND A4, zweite Haelfte: PFLICHTFELDER fuehrt genau VIER Ebenen. Ein hasChildren, das auf einer
   * ELTERNebene neu hinzukaeme (tafel/$station statt tafel/$station/meta), haette hier gar keinen
   * Gegenpart — es wuerde von keiner der vier Pruefungen oben beruehrt und faende nie statt. Ein
   * hasChildren(['meta']) auf tafel/$station etwa wiese jeden Koerper ab, der nur Kacheln
   * nachtraegt: der Delta-Weg schreibt tafel/<sid>/uebersicht/<key> ohne meta.
   */
  const elternebenen = {
    'tafel': R.tafel['.validate'],
    'tafel/$station': T$['.validate'],
    'tafel/$station/uebersicht': T$.uebersicht['.validate'],
    'tafel/$station/geraete': T$.geraete['.validate'],
  };
  const mitPflicht = Object.keys(elternebenen).filter((k) => pflichtAus(elternebenen[k]).length > 0);
  ok('keine Elternebene des tafel-Zweigs erzwingt Pflichtfelder — dafuer fuehrt PFLICHTFELDER keinen Eintrag (A4)',
    mitPflicht.length === 0, mitPflicht.join(','));

  /*
   * Und jetzt die andere Richtung: JEDES Pflichtfeld muss auch im aermsten denkbaren Datensatz
   * stehen — kein Name, keine Uhr, kein Patient, kein Geraet. Ein null zaehlt NICHT als gesetzt: in
   * der Realtime Database loescht es den Schluessel.
   */
  const nackt = {
    'tafel/<sid>/meta': T.tafelSatz({ sid: SID_A }),
    'tafel/<sid>/uebersicht/<key>': T.uebersichtSatz({}, null, undefined),
    'tafel/<sid>/geraete/<id>': T.geraeteSatz({}, undefined),
  };
  const fehlend = [];
  T.PFLICHTFELDER.tafelMeta.forEach((f) => { if (nackt['tafel/<sid>/meta'][f] == null) fehlend.push('meta.' + f); });
  T.PFLICHTFELDER.uebersicht.forEach((f) => { if (nackt['tafel/<sid>/uebersicht/<key>'][f] == null) fehlend.push('uebersicht.' + f); });
  T.PFLICHTFELDER.geraete.forEach((f) => { if (nackt['tafel/<sid>/geraete/<id>'][f] == null) fehlend.push('geraete.' + f); });
  ok('jedes Pflichtfeld steht auch im aermsten Datensatz (ohne Name, ohne Uhr, ohne Geraet)',
    fehlend.length === 0, fehlend.join(','));
  ok('der Saalkopf bindet sich an seinen Pfad (sid === $station, die Regel verlangt das)',
    /child\('sid'\)\.val\(\) === \$station/.test(T$.meta['.validate'])
    && nackt['tafel/<sid>/meta'].sid === SID_A);
  ok('ein Kachel-/Geraetesatz ist nie eine Zeichenkette (die Regel verlangt !newData.isString())',
    /!newData\.isString\(\)/.test(T$.uebersicht.$key['.validate'])
    && typeof nackt['tafel/<sid>/uebersicht/<key>'] === 'object'
    && typeof nackt['tafel/<sid>/geraete/<id>'] === 'object');

  // --- Laengengrenzen: keine Regelgrenze darf UNTER einer Kappung im Code liegen (N9, Befund B8).
  ok('die Regel laesst eine Stationskennung mindestens so lang zu wie pruefeSid (' + T.GRENZEN.sid + ')',
    laenge(T$['.validate'], '\\$station') >= T.GRENZEN.sid, String(laenge(T$['.validate'], '\\$station')));
  ok('der Kachelschluessel darf mindestens so lang sein wie tafel.schluessel() kappt',
    laenge(T$.uebersicht.$key['.validate'], '\\$key') >= T.GRENZEN.schluessel,
    String(laenge(T$.uebersicht.$key['.validate'], '\\$key')));
  ok('der Geraeteschluessel darf mindestens so lang sein wie tafel.schluessel() kappt (B8)',
    laenge(T$.geraete.$geraet['.validate'], '\\$geraet') >= T.GRENZEN.schluessel,
    String(laenge(T$.geraete.$geraet['.validate'], '\\$geraet')));
  const werteGrenzen = (JSON.stringify(R.tafel).match(/newData\.val\(\)\.length\s*<=\s*(\d+)/g) || [])
    .map((s) => Number(/(\d+)/.exec(s)[1]));
  const groessteKappung = Math.max(T.GRENZEN.wert, T.GRENZEN.tafelText, T.GRENZEN.adresse,
    T.GRENZEN.dvEintrag, T.GRENZEN.spiegelStation);
  ok('KEINE Wertgrenze im tafel-Zweig liegt unter der groessten Kappung im Code (' + groessteKappung + ')',
    werteGrenzen.length > 0 && Math.min.apply(null, werteGrenzen) >= groessteKappung,
    'kleinste Regelgrenze ' + Math.min.apply(null, werteGrenzen));
  // Der Spiegelname geht auf die FLACHE Ebene und faellt damit unter die Bestandsgrenze.
  const stationGrenze = laenge(R.meta.station['.validate'], 'newData\\.val\\(\\)');
  ok('beide Spiegelnamen passen in die Bestandsgrenze von meta/station (' + stationGrenze + ')',
    T.SPIEGEL_NAME_MEHRSAAL.length <= stationGrenze && T.SPIEGEL_NAME_UNBENANNT.length <= stationGrenze
    && T.GRENZEN.spiegelStation <= stationGrenze,
    T.SPIEGEL_NAME_MEHRSAAL.length + '/' + T.SPIEGEL_NAME_UNBENANNT.length);
  // sv ist neben sid die einzige Stelle, an der die Regel etwas ABWEIST statt zu begrenzen.
  ok('die Regel fuer sv verlangt ein Zeitfenster — deshalb geht nur der Platzhalter durch',
    /newData\.isNumber\(\) && newData\.val\(\) <= now/.test(T$.meta.sv['.validate'])
    && T.istServerZeitstempel({ '.sv': 'timestamp' }) === true
    && T.istServerZeitstempel(T0) === false);
}

/* ---------------- 13) Die Stationskennung: EINE Form in allen Dateien (B10) ---------------- */
console.log('\nForm der Stationskennung — drei Dateien duerfen sich nicht widersprechen (B10):');
{
  const sidQuelle = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'stationsid.js'), 'utf8');
  const m = /const SID_FORM = (\/[^\n]*\/);/.exec(sidQuelle);
  ok('SID_FORM steht in tafel.js und stationsid.js zeichengleich',
    !!m && m[1] === String(T.SID_FORM), (m ? m[1] : 'nicht gefunden') + ' vs ' + String(T.SID_FORM));
  /*
   * Der Suffixzweig (-<4hex>) ist der Rest der verworfenen Selbstumbenennung (N2 streicht
   * sidMitSuffix/eindeutigMachen). Er wird nur noch GELESEN — aus Nachsicht gegen eine
   * data/station-id.json aus einem 1.1.0-Vorabstand. tafel.js darf ihn deshalb annehmen, aber
   * niemals selbst eine Kennung bauen: diese Datei prueft Kennungen, sie erzeugt keine.
   */
  ok('tafel.js erzeugt selbst nie eine Kennung — es prueft nur (N2)',
    !/sidMitSuffix|eindeutigMachen|warDoppelt/.test(codeTafel)
    && !/sid\s*\+\s*['"]-/.test(codeTafel));
  ok('die Suffixform wird nur aus Nachsicht gelesen und ist als solche benannt',
    T.pruefeSid('st7f3a91c2b45d-0001') === true
    && /Nachsicht/.test(quelleTafel) && /N2/.test(quelleTafel));
  ok('eine zu lange Kennung faellt trotz passender Form durch',
    !T.pruefeSid('st7f3a91c2b45d-0001-0002-0003'));
}

/* ---------------- 14) Die Werkzeuge dieses Tests selbst (A4, A5) ---------------- */
console.log('\nDie Werkzeuge dieses Tests — eine Pruefung, die man umgehen kann, ist keine (A4/A5):');
{
  const H = '\'';                                     // einfaches Anfuehrungszeichen
  const S = '`';                                      // Schablonentext
  ok('ein "//" in einem EINFACH zitierten Text beginnt keinen Kommentar (A5)',
    ohneKommentare('const A = ' + H + 'https://x.example/a' + H + '; const MERKMAL = 1;').indexOf('MERKMAL') >= 0);
  ok('dasselbe in einem Schablonentext',
    ohneKommentare('const A = ' + S + 'https://x.example/a' + S + '; const MERKMAL = 1;').indexOf('MERKMAL') >= 0);
  ok('und weiterhin im doppelt zitierten Text',
    ohneKommentare('const A = "https://x.example/a"; const MERKMAL = 1;').indexOf('MERKMAL') >= 0);
  ok('ein echter Zeilenkommentar faellt weiter weg',
    ohneKommentare('const A = 1; // MERKMAL').indexOf('MERKMAL') < 0);
  ok('ein mehrzeiliger Blockkommentar faellt weiter weg',
    ohneKommentare('/* MERKMAL\n noch drin */ const B = 2;').indexOf('MERKMAL') < 0
    && ohneKommentare('/* MERKMAL\n noch drin */ const B = 2;').indexOf('const B') >= 0);
  /*
   * Der nachgemessene Weg aus Befund A5: ein zweites Vorkommen der gemeinsamen Zeichenkette,
   * angehaengt an eine Zeile mit einer einfach zitierten Adresse (cloud.js hat vier davon). Frueher
   * zaehlte der Test dort 0 und blieb gruen — waehrend zwei Fassungen dieser Zeichenkette den Kopf
   * der ausgelieferten Web-App im Sekundentakt flackern lassen.
   */
  const angriff = 'const IDENTITY = ' + H + 'https://identitytoolkit.googleapis.com/v1/x' + H
    + '; const X = ' + H + T.SPIEGEL_NAME_MEHRSAAL + H + ';';
  ok('ein zweites Vorkommen hinter einer solchen Zeile wird GEZAEHLT (A5)',
    ohneKommentare(angriff).split(T.SPIEGEL_NAME_MEHRSAAL).length - 1 === 1,
    ohneKommentare(angriff));
  /*
   * Gegenprobe in die andere Richtung: der Kuerzer darf keinen Code verschlucken. Gezaehlt werden die
   * Funktionsanfaenge am Zeilenanfang — sie stehen nur im Code, nie in einem Kommentarblock dieser
   * Dateien (der ist mit " * " eingerueckt).
   */
  const zaehleFn = (s) => (s.match(/\nfunction /g) || []).length;
  const rohCloud = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'cloud.js'), 'utf8');
  ok('ohneKommentare() verliert in tafel.js keine einzige Funktion',
    zaehleFn(quelleTafel) > 0 && zaehleFn(quelleTafel) === zaehleFn(ohneKommentare(quelleTafel)),
    zaehleFn(quelleTafel) + ' vs ' + zaehleFn(ohneKommentare(quelleTafel)));
  ok('und in cloud.js auch keine',
    zaehleFn(rohCloud) > 0 && zaehleFn(rohCloud) === zaehleFn(ohneKommentare(rohCloud)),
    zaehleFn(rohCloud) + ' vs ' + zaehleFn(ohneKommentare(rohCloud)));

  /*
   * BEFUND A4: dieselbe Verschaerfung, zweimal geschrieben. Als Liste faellt sie auf, als zwei
   * Aufrufe fiel sie frueher nicht auf — der Test blieb gruen, waehrend die Regel in der Praxis den
   * ganzen atomaren 1-Hz-Koerper samt Vitalwerten abgewiesen haette.
   */
  ok('pflichtAus liest die Listenform',
    pflichtAus('newData.hasChildren([' + H + 'sid' + H + ',' + H + 'ts' + H + '])').join(',') === 'sid,ts');
  ok('pflichtAus liest AUCH zwei getrennte Aufrufe (A4)',
    pflichtAus('newData.hasChildren([' + H + 'sid' + H + ']) && newData.hasChildren([' + H + 'ts' + H
      + ']) && newData.child(' + H + 'sid' + H + ').val() === $station').join(',') === 'sid,ts');
  ok('ohne hasChildren bleibt die Liste leer', pflichtAus('!newData.isString()').length === 0);
  ok('und der aermste Kopf traegt wirklich kein ts — deshalb waere die Verschaerfung toedlich',
    T.tafelSatz({ sid: SID_A }).ts === undefined, JSON.stringify(T.tafelSatz({ sid: SID_A })));
}

/* ---------------------------------------------------------------------------
 * NACHBARAUSWAHL NACH FRISCHE (Befund 01.08.2026)
 *
 * Bis hierher nahm cloud.js die alphabetisch ersten acht Stationskennungen. Eine Kennung ist eine
 * Zufallsfolge — alphabetisch heisst also willkuerlich. In einem Konto mit mehr als acht Kennungen
 * (der Knoten eines ausgemusterten PCs bleibt in der Datenbank stehen) konnte damit ein LAUFENDER
 * OP-Saal aus der Liste fallen, waehrend eine Karteileiche gelesen wurde. Fern war der Saal dann
 * unsichtbar, und nirgends stand ein Fehler.
 * --------------------------------------------------------------------------- */
console.log('\n== Nachbarauswahl: Frische schlaegt Alphabet ==');
{
  const bekannt = {
    stAAAA000000001: { sv: 1000 },      // alt = Karteileiche, aber alphabetisch vorn
    stAAAA000000002: { sv: 2000 },
    stZZZZ000000009: { sv: 9000 },      // frisch, aber alphabetisch hinten
  };
  const fremd = ['stZZZZ000000009', 'stAAAA000000001', 'stAAAA000000002'];
  const w = T.waehleNachbarn(fremd, bekannt, 2);
  ok('der FRISCHESTE Saal wird gelesen, obwohl er alphabetisch letzter ist',
    w.genommen[0] === 'stZZZZ000000009', JSON.stringify(w));
  ok('die aelteste Kennung faellt heraus', w.weggelassen.join() === 'stAAAA000000001', JSON.stringify(w));
  ok('nichts geht verloren: genommen + weggelassen = alle',
    w.genommen.length + w.weggelassen.length === fremd.length);

  /* Ein neu aufgestellter Saal hat naturgemaess noch keinen bekannten Zeitstempel. Wuerde er
   * deshalb hinten einsortiert, wuerde er NIE gelesen und damit nie entdeckt. */
  const w2 = T.waehleNachbarn(['stNEU0000000003'].concat(fremd), bekannt, 1);
  ok('ein noch nie gelesener Saal kommt zuerst dran (sonst wird er nie entdeckt)',
    w2.genommen[0] === 'stNEU0000000003', JSON.stringify(w2));

  const w3 = T.waehleNachbarn(['stBBBB000000001', 'stAAAA000000001'], { stBBBB000000001: { sv: 5 }, stAAAA000000001: { sv: 5 } }, 2);
  ok('bei gleichem Stand wird alphabetisch sortiert (vorhersagbar, testbar)',
    w3.genommen.join() === 'stAAAA000000001,stBBBB000000001', JSON.stringify(w3));
  ok('leere Eingabe stuerzt nicht ab', T.waehleNachbarn([], {}, 8).genommen.length === 0);
  ok('ohne Vorwissen bleibt die Reihenfolge alphabetisch (alle gleich neu)',
    T.waehleNachbarn(['stB0000000000002', 'stA0000000000001'], {}, 8).genommen.join() === 'stA0000000000001,stB0000000000002');
}


console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
