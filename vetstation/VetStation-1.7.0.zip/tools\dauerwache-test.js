'use strict';
/*
 * dauerwache-test.js — die Station hoert nie ganz auf, nach Geraeten zu schauen (Wunsch 02.08.2026).
 *
 * DER FEHLER, DEN DIESE DATEI FESTNAGELT:
 * Bis 1.2.3 setzte erstsuche.laufen() nach dem ERSTEN gelieferten Wert  this.fertig = true  und
 * plante keinen weiteren Lauf. Der Kommentar dazu ("ein laufender Betrieb braucht keine Suche")
 * stimmt fuer ein einzelnes Geraet — nur ist das nicht der Alltag. Der Nutzer hat den wirklichen
 * Fall beschrieben: Hausnetz mit LAN-Verteiler, Geraete kommen zu verschiedenen Zeiten dazu, teils
 * ueber Kabel, teils ueber WLAN. Im OP ist der Regelfall: erst haengt der Monitor, spaeter kommt
 * das Narkosegeraet. Mit der alten Regel wurde dieses zweite Geraet bis zum naechsten NEUSTART der
 * Station nie gefunden — ohne Fehler und ohne Meldung, denn die Station schrieb "es kommen Werte
 * an" und schwieg danach.
 *
 * Geprueft wird an der LAUFENDEN Klasse, nicht am Quelltext: eine Textpruefung faengt einen
 * vergessenen Aufruf nicht. Kein Netzverkehr, keine Uhr, keine echte devices.json.
 *
 * Start: node tools/dauerwache-test.js       (laeuft auch in `npm test`)
 */
const os = require('os');
const path = require('path');
const E = require('../bridge/src/erstsuche');

let pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e !== undefined ? '  -> ' + e : '')); }
}
const stumm = { info() {}, warn() {}, error() {} };

console.log('VetStation — Dauerwache: ein spaeter angestecktes Geraet wird trotzdem gefunden\n');

console.log(' 1) Die Zahlen sind benannt und plausibel');
ok('es gibt einen ruhigen Dauertakt', typeof E.WACHE_MS === 'number' && E.WACHE_MS > 0, String(E.WACHE_MS));
ok('der Dauertakt ist kurz genug, dass niemand vorsichtshalber neu startet (hoechstens 30 min)',
  E.WACHE_MS <= 30 * 60 * 1000, String(E.WACHE_MS));
ok('der Dauertakt ist lang genug, dass nicht dauernd am Hausnetz geklopft wird (mindestens 5 min)',
  E.WACHE_MS >= 5 * 60 * 1000, String(E.WACHE_MS));
ok('die eigene Netzlage wird oft nachgesehen (hoechstens 60 s — sie kostet nichts)',
  typeof E.NETZWACHE_MS === 'number' && E.NETZWACHE_MS <= 60000, String(E.NETZWACHE_MS));
ok('die gezielte Pruefung hat einen Deckel gegen Klopfstuerme',
  typeof E.SCHNELL_MAX === 'number' && E.SCHNELL_MAX > 0 && E.SCHNELL_MAX <= 16, String(E.SCHNELL_MAX));
ok('dieselbe Adresse wird nicht alle 30 s erneut angeklopft',
  typeof E.SCHNELL_SPERRE_MS === 'number' && E.SCHNELL_SPERRE_MS >= 30000, String(E.SCHNELL_SPERRE_MS));

/* Der Verbindungs-Assistent ist die Stelle, die als erste erfaehrt, dass eine Adresse neu im Netz
 * ist. Ohne den Melder waere die ganze Wache auf den langsamen Weg angewiesen. */
console.log('\n 2) Der Verbindungs-Assistent kann einen neuen Fund melden');
{
  const { ProbeAdapter } = require('../bridge/src/adapters/probe');
  const p = new ProbeAdapter({ id: 't', arpScan: false }, { log: stumm, emit() {} });
  ok('er hat einen Melder', typeof p.setzeGeraeteWaechter === 'function');
  let gerufen = null;
  p.setzeGeraeteWaechter((liste, warum) => { gerufen = { liste: liste, warum: warum }; });
  ok('und der Melder laesst sich setzen', typeof p.waechter === 'function');
  p.setzeGeraeteWaechter(null);
  ok('und wieder abnehmen (null ist gueltig, nicht ein stiller Fehler)', p.waechter === null);
  ok('unbenutzt bleibt er still', gerufen === null);
  if (typeof p.dispose === 'function') { try { p.dispose(); } catch (_) {} }
}

console.log('\n 3) Nach einem erfolgreichen Lauf endet die Suche NICHT');
const geplant = [];
const e = new E.Erstsuche({
  log: stumm,
  /*
   * Ein VERBUNDENES Geraet, dessen letztes Paket 5 Minuten her ist — genau die Lage, in der die
   * Suche bis 1.2.3 dauerhaft aufhoerte: der Monitor haengt und ist erkannt, gerade liegt kein
   * Tier darauf, und in diesem Moment steckt jemand das Narkosegeraet an.
   *
   * Warum nicht ein Geraet, das GERADE Werte liefert: dann greift die Narkose-Sperre, und die
   * Wiederholung wird aus einem anderen Grund geplant. Diese Unterscheidung hat der Test hier
   * selbst zutage gefoerdert — sie ist richtig so und wird deshalb weiter unten eigens geprueft.
   */
  registry: {
    getDevices: () => [{ deviceId: 'x', status: 'connected', lastTs: Date.now() - 5 * 60 * 1000 }],
    adapters: [],
  },
  scan: () => Promise.resolve({ hosts: [], geraete: [] }),
  kartenQuelle: () => [{ address: '192.168.0.5', netmask: '255.255.255.0' }],
  konfigPfad: path.join(os.tmpdir(), 'vs-wache-devices.json'),
  merkPfad: path.join(os.tmpdir(), 'vs-wache-merk.json'),
  nachbarnPfad: path.join(os.tmpdir(), 'vs-wache-nachbarn.json'),
});
/* Statt eines echten Zeitgebers nur mitschreiben, WAS geplant wurde. Ein Test, der 15 Minuten
 * wartet, ist kein Test. */
e._plane = (ms, warum) => { geplant.push({ ms: ms, warum: warum }); };

e.laufen().then(() => {
  ok('nach einem Lauf mit Werten ist "fertig" gesetzt', e.fertig === true);
  ok('ABER es ist trotzdem ein naechster Lauf geplant — die Suche endet nicht',
    geplant.length === 1, JSON.stringify(geplant));
  ok('und zwar im ruhigen Dauertakt',
    geplant.length === 1 && geplant[0].ms === E.WACHE_MS, JSON.stringify(geplant));
  ok('der Grund steht im Klartext dabei',
    geplant.length === 1 && /Dauerwache/i.test(geplant[0].warum || ''), JSON.stringify(geplant));

  console.log('\n 4) Die gezielte Pruefung einzelner Adressen');
  return e.schnellpruefung([], 'test');
}).then((r) => {
  ok('bei leerer Liste sagt sie sauber ab, statt still nichts zu tun', !!(r && r.grund === 'keine Adresse'));
  /* 203.0.113.0/24 ist der fuer Dokumentation reservierte Bereich (RFC 5737) — dort antwortet
   * nichts, und der Test klopft damit an keinem echten Geraet an. */
  return e.schnellpruefung([{ ip: '203.0.113.199' }], 'test');
}).then((r) => {
  /* DIE WICHTIGSTE PRUEFUNG DIESER DATEI: die gezielte Pruefung darf waehrend einer Narkose NICHT
   * gesperrt sein. Sie kostet acht kurze Verbindungsversuche; der grosse Suchlauf oeffnet 250.
   * Und das spaeter angesteckte Narkosegeraet ist genau der Fall, fuer den es sie gibt — ein
   * Weg, der ausgerechnet waehrend der Narkose schweigt, wuerde seinen Zweck verfehlen. */
  ok('sie lehnt NICHT mit der Narkose-Sperre ab (dafuer ist sie zu klein)',
    !!r && !/Patient|Narkose/i.test(r.grund || ''), JSON.stringify(r));
  ok('sie merkt sich die gepruefte Adresse gegen Dauerklopfen',
    e._schnellGeprueft('203.0.113.199') === true);
  ok('eine nie gepruefte Adresse gilt nicht als geprueft',
    e._schnellGeprueft('203.0.113.1') === false);
  return e.schnellpruefung([{ ip: '203.0.113.199' }], 'test');
}).then((r) => {
  ok('dieselbe Adresse wird gleich danach nicht noch einmal angeklopft',
    !!r && /kuerzlich/i.test(r.grund || ''), JSON.stringify(r));

  console.log('\n 5) Der Statusbericht sagt, dass gewacht wird');
  const s = e.status();
  ok('der Bericht nennt die Dauerwache', !!(s && s.wache && s.wache.aktiv === true),
    JSON.stringify(s && s.wache));
  ok('und den geltenden Takt', !!(s && s.wache && s.wache.taktMs === E.WACHE_MS),
    JSON.stringify(s && s.wache));
  ok('und wie oft sie schon ohne Suchlauf ein Geraet eingebunden hat',
    !!(s && s.wache && typeof s.wache.schnellFunde === 'number'), JSON.stringify(s && s.wache));

  console.log('\n 6) Ein Netzwechsel des PCs loest sofort eine neue Suche aus');
  {
    const plan2 = [];
    let karten = [{ address: '192.168.0.5', netmask: '255.255.255.0' }];
    const n = new E.Erstsuche({
      log: stumm,
      registry: { getDevices: () => [], adapters: [] },
      scan: () => Promise.resolve({ hosts: [], geraete: [] }),
      kartenQuelle: () => karten,
      konfigPfad: path.join(os.tmpdir(), 'vs-wache2-devices.json'),
      merkPfad: path.join(os.tmpdir(), 'vs-wache2-merk.json'),
      nachbarnPfad: path.join(os.tmpdir(), 'vs-wache2-nachbarn.json'),
    });
    n._plane = (ms, warum) => { plan2.push({ ms: ms, warum: warum }); };
    n._netzWache();                       // erster Aufruf: nur merken
    ok('der erste Blick auf die Netzlage loest nichts aus (nur merken)', plan2.length === 0);
    n._netzWache();                       // unveraendert
    ok('unveraenderte Netzlage loest nichts aus', plan2.length === 0);
    /* Jetzt der Fall des Nutzers: das Kabel wird umgesteckt bzw. auf WLAN gewechselt. */
    karten = [{ address: '10.0.0.23', netmask: '255.255.255.0' }];
    n._netzWache();
    ok('eine GEAENDERTE Netzlage loest sofort eine neue Suche aus', plan2.length === 1,
      JSON.stringify(plan2));
    ok('und zwar binnen Sekunden, nicht im Dauertakt',
      plan2.length === 1 && plan2[0].ms <= 10000, JSON.stringify(plan2));
    ok('der Zaehler der Netzwechsel steht im Statusbericht', n.status().wache.netzWechsel === 1);
    /* Und die Suche faengt wieder von vorn an: die alten Abstaende gehoerten zum alten Netz. */
    ok('die Suche beginnt im neuen Netz wieder von vorn', n.versuche === 0 && n.fertig === false);
    n.stop();
  }

  /*
   * 7) Und die Gegenprobe zur Dauerwache: der GROSSE Suchlauf bleibt waehrend einer Narkose
   *    gesperrt. Die Wache darf diese Sperre nicht aufweichen — sonst waere die Verbesserung
   *    genau die Verschlechterung, gegen die darfSuchen() gebaut wurde. Der schnelle Weg
   *    (Abschnitt 4) ist die Ausnahme, und zwar die einzige.
   */
  console.log('\n 7) Waehrend einer Narkose bleibt der grosse Suchlauf gesperrt');
  {
    const plan3 = [];
    const m = new E.Erstsuche({
      log: stumm,
      registry: {
        getDevices: () => [{ deviceId: 'y', status: 'active', lastTs: Date.now() }],   // Tier haengt dran
        adapters: [],
      },
      scan: () => { plan3.push('SUCHLAUF GESTARTET'); return Promise.resolve({ hosts: [], geraete: [] }); },
      kartenQuelle: () => [{ address: '192.168.0.5', netmask: '255.255.255.0' }],
      konfigPfad: path.join(os.tmpdir(), 'vs-wache3-devices.json'),
      merkPfad: path.join(os.tmpdir(), 'vs-wache3-merk.json'),
      nachbarnPfad: path.join(os.tmpdir(), 'vs-wache3-nachbarn.json'),
    });
    const geplant3 = [];
    m._plane = (ms, warum) => { geplant3.push({ ms: ms, warum: warum }); };
    return m.laufen().then(() => {
      ok('der Suchlauf wird waehrend der Narkose NICHT gestartet',
        plan3.indexOf('SUCHLAUF GESTARTET') < 0, JSON.stringify(plan3));
      ok('aber er wird verschoben, nicht vergessen', geplant3.length === 1, JSON.stringify(geplant3));
      m.stop();
      fertigMelden();
    });
  }

}).catch((err) => {
  console.log('  ✗ Ablauf abgebrochen: ' + ((err && err.stack) || err));
  process.exit(1);
});

function fertigMelden() {
  e.stop();
  console.log('');
  if (fail) { console.log(fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'); process.exit(1); }
  console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
  process.exit(0);
}
