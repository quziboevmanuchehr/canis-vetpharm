'use strict';
/*
 * firebase-regeln-test.js — die Datenbankregeln muessen fehlerfrei sein UND das abdecken,
 * was die Station wirklich schreibt.
 *
 * WARUM ES DIESEN TEST GIBT (Befund 01.08.2026, beim Veroeffentlichen von 1.2.0):
 * Die Regel auf verbund/lan/$station verlangt ein Feld 'sid'. cloud.lanAnkerSchreiben() schrieb es
 * nicht mit. Die Datenbank haette den ALLERERSTEN Schreibvorgang abgewiesen — und weil es der
 * erste ist, gibt es keinen vorhandenen Knoten, der die Bedingung schon erfuellt: der Knoten waere
 * nie entstanden, der direkte Weg zwischen zwei OP-Saelen nie zustande gekommen, und im Log haette
 * eine einzelne Ablehnung gestanden, die wie ein Rechteproblem aussieht.
 *
 * Gefunden wurde das beim LESEN der Regeldatei, nicht durch einen Test. Dieser hier schliesst die
 * Luecke von der anderen Seite: er prueft die Datei selbst.
 *
 * Und er prueft sie, BEVOR jemand sie in die Firebase-Konsole einfuegt. Dort faellt ein Tippfehler
 * erst beim Veroeffentlichen auf — und ab diesem Moment gilt die neue Fassung fuer JEDE Praxis.
 *
 * Start: node tools/firebase-regeln-test.js      (laeuft auch in tools/alle-tests.js)
 */
const fs = require('fs');
const path = require('path');

let pass = 0, fail = 0;
function ok(n, c, x) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (x ? '  -> ' + x : '')); } }

const ROOT = path.join(__dirname, '..');
const roh = fs.readFileSync(path.join(ROOT, 'installer', 'firebase-rtdb-rules.json'), 'utf8');
const cloud = fs.readFileSync(path.join(ROOT, 'bridge', 'src', 'cloud.js'), 'utf8');

console.log('VetStation — Firebase-Datenbankregeln\n');

/*
 * Firebase erlaubt Kommentare in den Regeln, JSON.parse nicht. Beim Entfernen duerfen // INNERHALB
 * von Zeichenketten nicht als Kommentar gelten — sonst zerschneidet der Entferner jedes
 * "https://..." und die Datei sieht kaputt aus, obwohl sie es nicht ist.
 */
function ohneKommentare(t) {
  let aus = '', imText = false, i = 0;
  while (i < t.length) {
    const c = t[i], n = t[i + 1];
    if (imText) {
      if (c === '\\') { aus += c + (n || ''); i += 2; continue; }
      if (c === '"') imText = false;
      aus += c; i++; continue;
    }
    if (c === '"') { imText = true; aus += c; i++; continue; }
    if (c === '/' && n === '/') { while (i < t.length && t[i] !== '\n') i++; continue; }
    if (c === '/' && n === '*') { i += 2; while (i < t.length && !(t[i] === '*' && t[i + 1] === '/')) i++; i += 2; continue; }
    aus += c; i++;
  }
  return aus;
}

console.log('Die Datei laesst sich lesen:');
let j = null, parseFehler = '';
try { j = JSON.parse(ohneKommentare(roh)); } catch (e) { parseFehler = e.message; }
ok('gueltiges JSON (Kommentare entfernt)', !!j, parseFehler);
if (!j) {
  console.log('\n' + fail + ' FEHLGESCHLAGEN — ohne lesbare Datei ist alles Weitere sinnlos.');
  process.exit(1);
}

const p = j.rules && j.rules.live && j.rules.live['$praxis'];
ok('es gibt Regeln unter /live/$praxis', !!p);

console.log('\nMandantentrennung — der Kern (eine Praxis darf nur ihre eigenen Daten sehen):');
ok('die Wurzel gibt kein Leserecht her', j.rules['.read'] !== true, String(j.rules['.read']));
ok('/live selbst ist nicht auflistbar (sonst waere die Kundenliste lesbar)',
  !(j.rules.live && j.rules.live['.read'] === true));
ok('je Praxis gilt auth.uid === $praxis fuers Lesen',
  /auth\s*!=\s*null\s*&&\s*auth\.uid\s*===\s*\$praxis/.test((p && p['.read']) || ''));

console.log('\nAlle Zweige, in die die Station schreibt, sind beschrieben:');
const zweige = p ? Object.keys(p).filter((k) => k[0] !== '.') : [];
['meta', 'patients', 'protokoll'].forEach((z) =>
  ok('Bestand unveraendert vorhanden: ' + z, zweige.indexOf(z) >= 0, zweige.join(', ')));
['tafel', 'saele', 'verbund'].forEach((z) =>
  ok('Mehrsaal-Zweig vorhanden: ' + z, zweige.indexOf(z) >= 0, zweige.join(', ')));
/* Die Formpruefung auf $praxis entscheidet ueber den GANZEN atomaren Koerper: fehlt dort ein
 * Zweig, faellt nicht nur er, sondern der Schreibvorgang samt Vitalwerten. */
const val = (p && p['.validate']) || '';
ok('die Formpruefung auf $praxis laesst alle vier Koerperarten zu',
  ['meta', 'tafel', 'saele', 'verbund'].every((z) => val.indexOf("'" + z + "'") >= 0), val.slice(0, 160));

console.log('\nDer Vertrauensanker des direkten Hauswegs (verbund/lan):');
const lan = p && p.verbund && p.verbund.lan && p.verbund.lan['$station'];
ok('verbund/lan/$station ist beschrieben', !!lan);
if (lan) {
  ok('nur das eigene Konto darf dort schreiben', /auth\.uid === \$praxis/.test(lan['.write'] || ''));
  ok('sid ist Pflicht', /hasChildren\(\['sid'\]\)/.test(lan['.validate'] || ''));
  ok('und muss dem Pfadsegment entsprechen (kein Schreiben unter fremder Kennung)',
    /child\('sid'\)\.val\(\) === \$station/.test(lan['.validate'] || ''));
  ok('sv muss ein frischer Serverzeitstempel sein', /now/.test((lan.sv && lan.sv['.validate']) || ''));

  /* DIE EIGENTLICHE PRUEFUNG: was cloud.js schreibt, muss die Regel bestehen. Genau hier lag der
   * Fehler vom 01.08.2026 — der Satz hatte kein sid. */
  const i = cloud.indexOf('lanAnkerSchreiben(anker)');
  const ab = cloud.indexOf('const satz = {', i);
  const satz = ab > 0 ? cloud.slice(ab, cloud.indexOf('};', ab)) : '';
  ok('cloud.js schreibt genau die Pflichtfelder, die die Regel verlangt',
    /\bsid:\s*sid\b/.test(satz), satz.replace(/\s+/g, ' ').slice(0, 160));
  ok('und einen Serverzeitstempel statt einer eigenen Zahl',
    /sv:\s*\{\s*'\.sv':\s*'timestamp'\s*\}/.test(satz));
}

console.log('\n---');
console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
if (fail) { console.log('FEHLGESCHLAGEN — diese Regeln NICHT veroeffentlichen.'); process.exit(1); }
console.log('OK (' + pass + ' Pruefungen)');
