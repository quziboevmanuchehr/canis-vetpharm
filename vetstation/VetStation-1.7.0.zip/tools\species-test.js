'use strict';
/*
 * species-test.js — beweist, dass die KOMPLETTE Kette für ALLE 8 Tierarten artspezifisch arbeitet
 * (nicht nur Hund): Normbänder (Brain), mL-Dosen (dose.js), Geräte-Soll (device-target.js).
 * Deckt den Nutzer-Schwerpunkt „muss für alle Arten funktionieren" + Audit H4/H5/M24 ab.
 * Start: node tools/species-test.js
 */
const A = require('../bridge/src/anaes').loadAnaes();
const brain = require('../ui/engine/brain');
const dose = require('../ui/engine/dose');
const dt = require('../ui/engine/device-target');

let pass = 0, fail = 0, warn = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function note(n) { warn++; console.log('  ⚠ ' + n); }

const SPECIES = [
  { id: 'hund', wt: 22 }, { id: 'katze', wt: 4.2 }, { id: 'kaninchen', wt: 2.5 },
  { id: 'meerschwein', wt: 0.8 }, { id: 'chinchilla', wt: 0.5 }, { id: 'degu', wt: 0.25 },
  /* Die kleinsten Patienten des Moduls. Das Gewicht ist bewusst das UNTERE Ende der jeweiligen
   * Art: eine 20-g-Maus ist der Fall, an dem eine Dosisrechnung zuerst zerbricht. */
  { id: 'ratte', wt: 0.35 }, { id: 'maus', wt: 0.025 },
  { id: 'hamster', wt: 0.09 }, { id: 'rennmaus', wt: 0.07 },
  { id: 'frettchen', wt: 1.1 }, { id: 'reptil', wt: 0.4 },
];

console.log('VetStation — Multi-Tierart-Selbsttest (' + SPECIES.length + ' Arten)\n');

// ---- 1) Normbänder für jede Art vorhanden + artspezifisch ----
console.log('1) Artspezifische Normbänder (Brain):');
ok('ANAES geladen (' + (A ? A.species.length : 0) + ' Arten)', !!A && A.species.length === SPECIES.length,
  'anaes-data kennt ' + (A ? A.species.length : 0) + ', der Test erwartet ' + SPECIES.length);
SPECIES.forEach(function (s) {
  const b = brain.bandsFor(A, s.id);
  ok(s.id + ': HR-Band vorhanden [' + (b.hr ? b.hr.join('-') : '?') + ']', !!(b && b.hr && b.hr.length === 2), JSON.stringify(b && b.hr));
});
// Kleine Nager haben deutlich höhere HR als Hund -> Bänder MÜSSEN sich unterscheiden.
const hundHr = brain.bandsFor(A, 'hund').hr;
['meerschwein', 'chinchilla', 'degu', 'ratte', 'maus', 'hamster', 'rennmaus'].forEach(function (sp) {
  const hr = brain.bandsFor(A, sp).hr;
  ok(sp + '-HR-Band ≠ Hund (artspezifisch, nicht Fallback)', hr[0] !== hundHr[0] || hr[1] !== hundHr[1], sp + '=' + hr + ' hund=' + hundHr);
});

// ---- 2) Brain reagiert ARTABHÄNGIG auf denselben Messwert ----
console.log('\n2) Brain nutzt Artbänder (gleiche HF, andere Bewertung):');
function assessHr(sp, wt, hr) {
  const b = brain.bandsFor(A, sp);
  const p = { species: sp, weightKg: wt, hr: hr, spo2: 98, etco2: Math.round((b.etco2[0] + b.etco2[1]) / 2),
    map: Math.round((b.map[0] + b.map[1]) / 2), af: Math.round((b.rr[0] + b.rr[1]) / 2), ekgRhythm: 'sinus' };
  return brain.assess(A, p, { iso: 1.8 });
}
// HF 70/min: für Hund (60-140) normal, für Meerschwein/Chinchilla/Degu (>=150) viel zu niedrig.
ok('Hund HF 70 → HF NICHT als Alarm (im Normband)', assessHr('hund', 22, 70).alarms.hr === false);
['meerschwein', 'chinchilla', 'degu', 'ratte', 'maus', 'hamster', 'rennmaus'].forEach(function (sp) {
  const r = assessHr(sp, 0.5, 70);
  ok(sp + ' HF 70 → HF-Alarm (unter Artnorm)', r.alarms.hr === true, 'alarms.hr=' + r.alarms.hr);
});
// Brain laeuft fuer ALLE Arten ohne Crash bei einem kritischen Fall.
SPECIES.forEach(function (s) {
  let r = null; try { r = brain.assess(A, { species: s.id, weightKg: s.wt, hr: 0, spo2: 0, etco2: 6, ekgRhythm: 'asys', capnoShape: 'flat', map: 0, af: 0 }, {}); } catch (e) {}
  ok(s.id + ': Brain-Asystolie ohne Crash (CPR-Priorität)', !!r && r.priority >= 8, r && 'pri=' + r.priority);
});

// ---- 3) mL-Dosen artspezifisch (Kern-Nutzerwunsch) ----
console.log('\n3) mL-Notfalldosen je Art (Bradykardie → Atropin):');
const atropinBy = {};
SPECIES.forEach(function (s) {
  const inj = dose.injectionsFor(A, 'bradykardie', s.id, s.wt).find(function (x) { return x.id === 'atropin'; });
  atropinBy[s.id] = inj;
  if (!inj) { ok(s.id + ': Atropin im Bradykardie-Protokoll', false); return; }
  const ml = (inj.mlLo != null) ? (dose.fmtRange(inj.mlLo, inj.mlHi) + ' mL') : 'keine mL';
  const tag = inj.speciesDose ? 'artspezifisch' : (inj.refFallback ? 'HUND-Referenz ⚠' : 'Ref');
  if (inj.speciesDose) { ok(s.id + ': artspezifische Atropin-Dosis, mL rechenbar (' + ml + ')', inj.mlLo != null, ml); }
  else if (inj.refFallback) { note(s.id + ': KEINE artspezifische Atropin-Dosis hinterlegt → Hund-Referenz (' + ml + '). Exoten-Formulary ergänzen.'); ok(s.id + ': trotzdem mL berechnet + als Referenz gekennzeichnet', inj.mlLo != null && inj.refFallback === true); }
  else { ok(s.id + ': Atropin mL rechenbar (' + ml + ')', inj.mlLo != null, ml); }
});

// ---- 4) Nicht-Regression + Artspezifik der wichtigsten Dosen ----
console.log('\n4) Nicht-Regression Hund + Artspezifik Kaninchen:');
const hundA = atropinBy['hund'], kanA = atropinBy['kaninchen'];
ok('Hund-Atropin unverändert 0,02–0,04 mg/kg (× 22 = 0,44–0,88 mg)', near(hundA.amtLo, 0.44) && near(hundA.amtHi, 0.88), hundA.amtLo + '–' + hundA.amtHi);
ok('Kaninchen-Atropin artspezifisch 0,1–0,5 mg/kg (× 2,5 = 0,25–1,25 mg), NICHT Hund-Dosis', near(kanA.amtLo, 0.25) && near(kanA.amtHi, 1.25), kanA.amtLo + '–' + kanA.amtHi);
ok('Kaninchen-Dosis > Hund-Dosis pro kg (Atropinesterase)', (kanA.amtLo / 2.5) > (hundA.amtLo / 22));
// Asystolie: Hund behält inzident-spezifische Einmaldosis 0,04 (nicht 0,02–0,04)
const hundAsys = dose.injectionsFor(A, 'asystolie', 'hund', 22).find(function (x) { return x.id === 'atropin'; });
ok('Hund-Asystolie-Atropin behält Ref-Einmaldosis 0,04 mg/kg (0,88 mg)', near(hundAsys.amtLo, 0.88) && near(hundAsys.amtHi, 0.88), hundAsys.amtLo + '–' + hundAsys.amtHi);

// ---- 5) Geräte-Soll je Art ----
console.log('\n5) Geräte-Soll (O₂/Iso) je Art:');
SPECIES.forEach(function (s) {
  const t = dt.devTarget(A, s.id, s.wt);
  ok(s.id + ': Soll O₂ ' + t.o2.map(function (x) { return Math.round(x * 10) / 10; }).join('–') + ' L/min · Iso ' + t.iso + ' · ' + t.mode, !!(t && t.o2 && t.iso));
});

function near(a, b) { return a != null && Math.abs(a - b) < 0.01; }

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL, ' + warn + ' Hinweis(e) (fehlende Exoten-Daten) ==');
process.exit(fail ? 1 : 0);
