'use strict';
/*
 * geraeteerkennung.js — WELCHES Geraet ist das da im Netz?
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 01.08.2026):
 * "Je nach Narkosegeraet oder Monitorgeraet muss auch das App erkennen ODER muss der Benutzer in
 *  Einstellung der Model das Geraet eingeben zu koennen."
 * Also beides — und dieses Modul ist die erste Haelfte: die Station soll selbst einen Vorschlag
 * machen koennen, statt den Tierarzt vor eine Liste mit vierzig Modellen zu stellen.
 *
 * WAS ES AUSDRUECKLICH NICHT TUT: raten. Die Erkennung liefert RANGIERTE KANDIDATEN mit
 * BEGRUENDUNG und einem ehrlichen Sicherheitsgrad — nie ein einzelnes Modell als Tatsache. Ein
 * falsch erkanntes Modell fuehrt zu einem falschen Menuepfad, und ein Tierarzt, der mitten im
 * OP-Betrieb einem falschen Menuepfad folgt, verliert Zeit, die er nicht hat. "Ich weiss es nicht"
 * ist hier ein gueltiges und gutes Ergebnis.
 *
 * WORAUS ERKANNT WIRD — vier voneinander unabhaengige Spuren:
 *   1. Der Geraetename im HL7-Kopf (MSH-3 / OBR-4). Die staerkste Spur: das Geraet sagt selbst,
 *      wie es heisst. Am LifeVet 10C stand dort tatsaechlich "LifeVet 10C".
 *   2. Das MAC-Praefix (OUI). Nennt den HERSTELLER sicher, das Modell nie — 98:CC:E4 tragen
 *      uMEC12 Vet und Veta 5 Plus gleichermassen.
 *   3. Der Port. Ein Geraet, das auf 8830 anklopft, ist mit hoher Wahrscheinlichkeit ein LifeVet 10C
 *      (dessen Werkseinstellung), eines auf 5510 ein LifeVet M.
 *   4. Die ersten Bytes des Datenstroms. 0x0B = HL7 im MLLP-Rahmen. 0x02 mit Synchronwort A5 5A =
 *      Mindrays herstellereigenes MD2. Das unterscheidet "spricht mit uns" von "sendet zwar, aber
 *      in einer Sprache, die niemand oeffentlich kennt".
 *
 * PURE FUNKTIONEN (kein Netz, keine Dateien, keine Uhr) -> vollstaendig testbar:
 * tools/geraeteerkennung-test.js
 */

const katalog = require('./geraetekatalog');

/* ------------------------------------------------------------------ *
 * 1) Was fuer ein Protokoll liegt da an?
 * ------------------------------------------------------------------ */

/*
 * protokollAusBytes(daten) — erkennt das Protokoll an den ersten Bytes.
 * `daten` darf ein Buffer, ein Hex-String oder ein Text sein; alles drei kommt im Programm vor
 * (probe.js hat einen Buffer, der Mitschnitt einen Hex-String, die Oberflaeche einen Text).
 */
function protokollAusBytes(daten) {
  let hex = '';
  let text = '';
  if (Buffer.isBuffer(daten)) {
    hex = daten.slice(0, 64).toString('hex');
    text = daten.slice(0, 512).toString('latin1');
  } else {
    const s = String(daten || '');
    if (/^[0-9a-fA-F\s]+$/.test(s) && s.replace(/\s/g, '').length >= 4) {
      hex = s.replace(/\s/g, '').toLowerCase().slice(0, 128);
      try { text = Buffer.from(hex, 'hex').toString('latin1'); } catch (_) { text = ''; }
    } else {
      text = s.slice(0, 512);
      hex = Buffer.from(text, 'latin1').slice(0, 64).toString('hex');
    }
  }

  if (!hex && !text) return { id: 'leer', name: 'nichts empfangen', lesbar: false };

  // HL7 im MLLP-Rahmen: <VT=0x0b> ... MSH|
  if (hex.indexOf('0b') === 0 && text.indexOf('MSH|') >= 0) {
    return { id: 'hl7-mllp', name: 'HL7 im MLLP-Rahmen', lesbar: true };
  }
  // HL7 ohne Rahmen — kommt vor, wenn ein Geraet die Nachricht roh auf die Leitung legt.
  if (text.indexOf('MSH|') >= 0) {
    return { id: 'hl7-roh', name: 'HL7 ohne MLLP-Rahmen', lesbar: true };
  }
  // Mindray MD2: Rahmenbyte 0x02, Synchronwort A5 5A. Belegt durch den eigenen Mitschnitt des
  // Veta 5 Plus (docs/VETA5-MITSCHNITT.md).
  if (hex.indexOf('02') === 0 || hex.indexOf('a55a') >= 0) {
    return { id: 'mindray-md2', name: 'Mindray MD2 (herstellereigenes Binaerprotokoll)', lesbar: false };
  }
  // Draeger MEDIBUS: ESC (0x1b) leitet jedes Kommando ein, Antworten enden mit CR (0x0d).
  if (hex.indexOf('1b') === 0) {
    return { id: 'medibus', name: 'sieht nach Draeger MEDIBUS aus (ESC-Rahmen)', lesbar: true };
  }
  return { id: 'unbekannt', name: 'unbekanntes Protokoll', lesbar: false };
}

/* ------------------------------------------------------------------ *
 * 2) Kandidaten bilden
 * ------------------------------------------------------------------ */

/* Punkte. Bewusst grob gestuft — eine Feinjustierung taeuscht Genauigkeit vor, die es nicht gibt. */
const P_NAME = 60;      // das Geraet nennt seinen Namen: staerkste Spur ueberhaupt
const P_ALIAS = 45;     // Name passt auf einen Alias/Rebrand
const P_OUI = 20;       // Hersteller stimmt
const P_PORT_PUSH = 18; // hat uns auf genau diesem Port angerufen
const P_PORT_OFFEN = 14;// hat genau diesen Port offen
const P_PROTOKOLL = 12; // das erkannte Protokoll passt zu einem Weg dieses Geraets

function normText(s) { return katalog.normText(s); }

/*
 * nameTrifft(text, geraet) — steckt der Modellname im HL7-Kopf?
 * Vergleich ueber die normalisierte Form, weil dort "LifeVet10C", "LIFEVET 10 C" und
 * "LifeVet_10C" alle vorkommen koennen.
 */
function nameTrifft(text, g) {
  const t = normText(text);
  if (!t) return null;
  if (normText(g.modell) && t.indexOf(normText(g.modell)) >= 0) return { treffer: g.modell, punkte: P_NAME };
  const a = (g.aliase || []).filter((x) => normText(x) && t.indexOf(normText(x)) >= 0)[0];
  if (a) return { treffer: a, punkte: P_ALIAS };
  return null;
}

/*
 * erkenne(spuren) -> { kandidaten:[…], protokoll, sicher, satz }
 *
 * spuren = {
 *   mac:          MAC des Teilnehmers (beliebige Schreibweise)
 *   offenePorts:  [4601, …]  Ports, auf denen der Teilnehmer LAUSCHT (aus netscan)
 *   quellPort:    Port, auf dem er UNS angerufen hat (aus probe)
 *   daten:        die ersten Bytes seines Datenstroms (Buffer/Hex/Text)
 *   hl7Kennung:   Text aus MSH-3/MSH-4/OBR-4, falls HL7 gelesen wurde
 * }
 *
 * Rueckgabe: Kandidaten absteigend nach Punkten. `sicherheit` je Kandidat:
 *   'sicher'         — das Geraet hat sich selbst benannt
 *   'wahrscheinlich' — zwei unabhaengige Spuren zeigen darauf (z. B. Hersteller + Port)
 *   'moeglich'       — nur eine Spur
 * Ohne jede Spur: leere Liste. Das ist Absicht.
 */
function erkenne(spuren) {
  const s = spuren || {};
  const protokoll = s.daten != null ? protokollAusBytes(s.daten) : { id: 'unbekannt', name: 'kein Datenstrom gesehen', lesbar: false };
  const offene = (s.offenePorts || []).map(Number).filter((x) => Number.isFinite(x));
  const quellPort = Number(s.quellPort) || null;

  const kandidaten = [];
  katalog.alle().forEach((g) => {
    let punkte = 0;
    const gruende = [];
    let spuren_anzahl = 0;
    let benannt = false;

    // (1) Der Name aus dem HL7-Kopf.
    const nt = s.hl7Kennung ? nameTrifft(s.hl7Kennung, g) : null;
    if (nt) {
      punkte += nt.punkte; spuren_anzahl++; benannt = true;
      gruende.push('das Geraet nennt sich selbst „' + nt.treffer + '“ (im HL7-Kopf)');
    }

    // (2) Der Hersteller aus der MAC.
    if (s.mac && (g.oui || []).length) {
      const m = katalog.normMac(s.mac);
      if (m.length >= 6 && (g.oui || []).some((o) => katalog.normMac(o) === m.slice(0, 6))) {
        punkte += P_OUI; spuren_anzahl++;
        gruende.push('MAC-Praefix ' + m.slice(0, 6) + ' gehoert ' + g.hersteller);
      }
    }

    // (3) Die Ports.
    let besterWeg = null;
    (g.wege || []).forEach((w) => {
      if (!w.port) return;
      if (quellPort && Number(w.port) === quellPort && (w.richtung === 'geraet_sendet' || w.richtung === 'beides')) {
        punkte += P_PORT_PUSH; spuren_anzahl++;
        gruende.push('hat den PC auf Port ' + quellPort + ' angerufen — das ist der Weg „' + w.name + '“');
        if (!besterWeg) besterWeg = w;
      }
      if (offene.indexOf(Number(w.port)) >= 0 && (w.richtung === 'pc_fragt_ab' || w.richtung === 'beides')) {
        punkte += P_PORT_OFFEN; spuren_anzahl++;
        gruende.push('Port ' + w.port + ' ist offen — dort kann der PC abfragen („' + w.name + '“)');
        if (!besterWeg) besterWeg = w;
      }
    });

    // (4) Das Protokoll.
    if (protokoll.id === 'mindray-md2' && /mindray/i.test(g.hersteller)) {
      punkte += P_PROTOKOLL; spuren_anzahl++;
      gruende.push('sendet Mindray-MD2 — das spricht nur Mindray-Technik');
    }
    if ((protokoll.id === 'hl7-mllp' || protokoll.id === 'hl7-roh') &&
        (g.wege || []).some((w) => w.adapter === 'hl7' || w.adapter === 'probe')) {
      punkte += P_PROTOKOLL; spuren_anzahl++;
      gruende.push('sendet HL7 — dieses Modell hat einen HL7-Weg');
    }
    if (protokoll.id === 'medibus' && (g.wege || []).some((w) => w.adapter === 'medibus')) {
      punkte += P_PROTOKOLL; spuren_anzahl++;
      gruende.push('sieht nach MEDIBUS aus — dieses Modell spricht MEDIBUS');
    }

    if (!punkte) return;

    const sicherheit = benannt ? 'sicher' : (spuren_anzahl >= 2 ? 'wahrscheinlich' : 'moeglich');
    kandidaten.push({
      geraetId: g.id,
      hersteller: g.hersteller,
      modell: g.modell,
      kategorie: g.kategorie,
      punkte: punkte,
      sicherheit: sicherheit,
      gruende: gruende,
      wegId: besterWeg ? besterWeg.id : ((g.wege || [])[0] || {}).id || null,
      vertrauen: g.vertrauen,
    });
  });

  kandidaten.sort((a, b) => (b.punkte - a.punkte) || a.modell.localeCompare(b.modell));

  return {
    protokoll: protokoll,
    kandidaten: kandidaten,
    /* `eindeutig` ist absichtlich streng: nur wenn der Erste sich selbst benannt hat ODER klar
     * vor dem Zweiten liegt. Zwei fast gleichauf liegende Kandidaten sind KEIN Ergebnis —
     * dann fragt die Oberflaeche den Menschen, statt eine Muenze zu werfen. */
    eindeutig: kandidaten.length > 0 &&
      (kandidaten[0].sicherheit === 'sicher' ||
       (kandidaten.length === 1) ||
       (kandidaten[0].punkte - kandidaten[1].punkte >= P_OUI)),
    satz: satz(kandidaten, protokoll),
  };
}

/*
 * satz(...) — der EINE Satz fuer die Oberflaeche und das Log. Nennt Zahlen und Gruende, keine
 * Stimmung, und sagt "unbekannt", wenn es unbekannt ist.
 */
function satz(kandidaten, protokoll) {
  if (!kandidaten || !kandidaten.length) {
    if (protokoll && protokoll.id === 'mindray-md2') {
      return 'Dort sendet ein Mindray-Geraet, aber in seinem eigenen Binaerprotokoll (MD2). ' +
        'Das kann VetStation nicht lesen und raet es auch nicht. Welches Modell es ist, laesst sich daraus nicht sagen.';
    }
    if (protokoll && protokoll.lesbar) {
      return 'Es kommen lesbare Daten an, aber das Modell laesst sich daraus nicht bestimmen. ' +
        'Im Reiter „Geräte“ kann das Modell von Hand gewaehlt werden.';
    }
    return 'Das Modell laesst sich nicht bestimmen — es liegt keine verwertbare Spur vor. ' +
      'Im Reiter „Geräte“ kann das Modell von Hand gewaehlt werden.';
  }
  const k = kandidaten[0];
  const wort = k.sicherheit === 'sicher' ? 'Das ist'
    : (k.sicherheit === 'wahrscheinlich' ? 'Sehr wahrscheinlich ist das' : 'Moeglicherweise ist das');
  let t = wort + ' ein ' + k.hersteller + ' ' + k.modell + ' (' + k.gruende.join('; ') + ').';
  if (kandidaten.length > 1 && k.sicherheit !== 'sicher') {
    t += ' Es kommen auch in Frage: ' + kandidaten.slice(1, 4).map((x) => x.hersteller + ' ' + x.modell).join(', ') + '.';
  }
  return t;
}

/*
 * ausNetscanHost(host, extra) — bequemer Einstieg fuer die Oberflaeche: nimmt einen Teilnehmer,
 * wie ihn netscan.scan() liefert, und macht daraus Spuren.
 */
function ausNetscanHost(host, extra) {
  const h = host || {};
  return erkenne(Object.assign({
    mac: h.mac,
    offenePorts: h.offenePorts || h.datenPorts || [],
  }, extra || {}));
}

module.exports = {
  erkenne, ausNetscanHost, protokollAusBytes, nameTrifft, satz,
  P_NAME, P_ALIAS, P_OUI, P_PORT_PUSH, P_PORT_OFFEN, P_PROTOKOLL,
};
