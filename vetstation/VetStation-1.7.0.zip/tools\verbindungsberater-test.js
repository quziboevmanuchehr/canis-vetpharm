'use strict';
/*
 * verbindungsberater-test.js — die Anleitung muss stimmen UND darf nicht schoenreden.
 *
 * WAS DIESER TEST FESTHAELT:
 * Der Berater (bridge/src/verbindungsberater.js) ist das, was ein Tierarzt liest, wenn ein Geraet
 * nicht liefert. Zwei Fehler waeren teuer:
 *   1. Eine Anleitung, die "PC-Adresse eintragen" sagt, ohne die Adresse zu nennen — dann sucht
 *      jemand mitten im OP-Betrieb in einem zweiten Fenster danach.
 *   2. Eine Anleitung, die so tut, als muesste man nur lange genug suchen, obwohl das Geraet gar
 *      keinen Datenausgang hat. Genau das ist am Veta 5 Plus ueber Tage passiert.
 * Beides wird hier festgenagelt.
 *
 * Start: node tools/verbindungsberater-test.js      (laeuft auch in tools/alle-tests.js)
 */
const vb = require('../bridge/src/verbindungsberater');
const katalog = require('../bridge/src/geraetekatalog');

let pass = 0, fail = 0;
function ok(n, c, x) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (x ? '  -> ' + x : '')); } }

console.log('VetStation — Verbindungsberater\n');

const ALLE_PORTS = katalog.datenPorts();

console.log('Anleitung: die echte PC-Adresse steht drin, nicht ein Platzhalter:');
const a1 = vb.anleitung('eickemeyer-lifevet-10c', 'hl7-push-8830', { pcIp: '192.168.0.5', lauschPorts: ALLE_PORTS });
ok('es gibt Schritte', a1.schritte.length >= 3, JSON.stringify(a1.schritte));
ok('die PC-Adresse 192.168.0.5 steht woertlich in einem Schritt',
  a1.schritte.some((s) => s.text.indexOf('192.168.0.5') >= 0), JSON.stringify(a1.schritte.map((s) => s.text)));
ok('das Passwort 888888 steht drin', a1.schritte.some((s) => /888888/.test(s.text)));
ok('der Weg ist machbar (Port 8830 wird belauscht)', a1.machbar === true);
ok('die Quellen werden mitgeliefert', (a1.geraet.quellen || []).length > 0);

console.log('\nAnleitung ohne bekannte PC-Adresse — kein erfundener Wert:');
const a2 = vb.anleitung('eickemeyer-lifevet-10c', 'hl7-push-8830', {});
ok('kein Platzhalter wie <IP> und keine erfundene Adresse',
  !a2.schritte.some((s) => /\d+\.\d+\.\d+\.\d+/.test(s.text)), JSON.stringify(a2.schritte.map((s) => s.text)));
ok('stattdessen ein Verweis, wo die Adresse steht',
  a2.schritte.some((s) => /Netzwerk & Geräte/.test(s.text)));

console.log('\nAnleitung fuer einen Weg, dessen Port NICHT belauscht wird:');
const a3 = vb.anleitung('eickemeyer-lifevet-m', 'push-5510', { pcIp: '192.168.0.5', lauschPorts: [3502, 4601] });
ok('gilt als NICHT machbar', a3.machbar === false);
ok('und sagt genau warum (niemand hoert zu)', a3.hinweise.some((h) => /jemand zuhoert/.test(h)), JSON.stringify(a3.hinweise));

console.log('\nUnbekanntes Modell:');
const a4 = vb.anleitung('gibtsnicht', null, {});
ok('kein Absturz, sondern eine Meldung', !!a4.fehler && a4.machbar === false);

console.log('\nBeratung — der beste Fall:');
const b1 = vb.berate({ geraetId: 'eickemeyer-lifevet-10c', werteKommen: true });
ok('Urteil ok', b1.urteil === 'ok');
ok('keine Befunde', b1.befunde.length === 0);
ok('der Satz nennt das Geraet', /LifeVet 10C/.test(b1.kurz), b1.kurz);

console.log('\nBeratung — der Veta-5-Fall: das Geraet gibt nichts heraus:');
const b2 = vb.berate({ geraetId: 'mindray-veta-5', wegId: 'mitschnitt-pruefen', empfangBytes: 0, lauschPorts: ALLE_PORTS });
const veta = b2.befunde.filter((x) => x.code === 'MODELL_OHNE_AUSGANG')[0];
ok('der Befund "Modell ohne Ausgang" kommt', !!veta, JSON.stringify(b2.befunde.map((x) => x.code)));
ok('und steht ganz oben (Schwere 3)', b2.befunde[0].code === 'MODELL_OHNE_AUSGANG');
ok('er sagt ausdruecklich: nicht weitersuchen', veta && veta.tun.some((t) => /Nicht weitersuchen/.test(t)));
ok('er nennt den Weg, der stattdessen funktioniert', veta && veta.tun.some((t) => /von Hand/.test(t)));

/*
 * SEIT DER RECHERCHE VOM 01.08.2026 IST DAS DER HAEUFIGSTE FALL, NICHT DER SELTENE:
 * Die grosse Mehrheit der Veterinaer-Narkosegeraete (Matrx VMS, Moduflex, Hallowell 2002,
 * Vetland, RWD, DRE, Supera) ist rein mechanisch-pneumatisch und hat ueberhaupt keine Buchse.
 * Der Katalog markiert solche Wege mit keinAusgang:true; hier wird festgehalten, dass der Berater
 * daraufhin die Fehlersuche ABBRICHT statt weiterzuschicken - und dass die Oberflaeche in diesem
 * Fall keinen "Einrichten"-Knopf anbietet (sie prueft genau auf diesen Befundcode).
 */
console.log('\nBeratung — Geraet ohne jeden Datenausgang (der Normalfall in der Tiermedizin):');
const b2b = vb.berate({ geraetId: 'mechanische-vet-narkose', wegId: 'kein-ausgang', empfangBytes: 0, lauschPorts: ALLE_PORTS });
ok('auch hier kommt MODELL_OHNE_AUSGANG', b2b.befunde.some((x) => x.code === 'MODELL_OHNE_AUSGANG'), JSON.stringify(b2b.befunde.map((x) => x.code)));
ok('und es wird auf das virtuelle Geraet verwiesen', b2b.befunde[0].tun.some((t) => /von Hand/.test(t)));
const w4 = vb.empfehleWeg('mechanische-vet-narkose', {});
ok('empfehleWeg schlaegt keinen unmoeglichen Weg als guten Weg vor', w4 && w4.keinAusgang === true, 'es gibt nur diesen einen');

console.log('\nBeratung — ein Geraet MIT Ausgang wird nicht faelschlich blockiert:');
const b2c = vb.berate({ geraetId: 'mindray-wato-ex35-vet', wegId: 'hl7-netz', empfangBytes: 0, lauschPorts: ALLE_PORTS });
ok('WATO EX-35Vet wird NICHT als ausweglos gemeldet', !b2c.befunde.some((x) => x.code === 'MODELL_OHNE_AUSGANG'), JSON.stringify(b2c.befunde.map((x) => x.code)));
const a5 = vb.anleitung('mindray-wato-ex35-vet', 'hl7-netz', { pcIp: '192.168.0.5', lauschPorts: ALLE_PORTS });
ok('und seine Anleitung nennt die echte PC-Adresse', a5.schritte.some((s) => /192\.168\.0\.5/.test(s.text)));
ok('und sagt, dass HL7 dort keine Kaufoption ist', /keine/.test(a5.weg.id ? (require('../bridge/src/geraetekatalog').weg('mindray-wato-ex35-vet', 'hl7-netz').lizenz || '') : ''));

console.log('\nBeratung — die Station hoert nicht auf dem noetigen Port:');
const b3 = vb.berate({ geraetId: 'eickemeyer-lifevet-m', wegId: 'push-5510', lauschPorts: [3502, 4601], empfangBytes: 0 });
ok('Befund PORT_NICHT_BELAUSCHT', b3.befunde.some((x) => x.code === 'PORT_NICHT_BELAUSCHT'), JSON.stringify(b3.befunde.map((x) => x.code)));
ok('Urteil problem', b3.urteil === 'problem');

console.log('\nBeratung — die Firewall blockiert genau diesen Port:');
const b4 = vb.berate({ geraetId: 'eickemeyer-lifevet-10c', wegId: 'hl7-push-8830', lauschPorts: ALLE_PORTS, firewallFehlend: [8830], empfangBytes: 0 });
ok('Befund FIREWALL_ZU', b4.befunde.some((x) => x.code === 'FIREWALL_ZU'));
ok('nennt FIREWALL-FREIGEBEN.bat', b4.befunde.some((x) => x.tun.some((t) => /FIREWALL-FREIGEBEN/.test(t))));

console.log('\nBeratung — ein fremdes Programm haelt den Port:');
const b5 = vb.berate({ geraetId: 'eickemeyer-lifevet-10c', wegId: 'hl7-push-8830', lauschPorts: ALLE_PORTS, portBelegt: [8830], empfangBytes: 0 });
ok('Befund PORT_FREMD_BELEGT', b5.befunde.some((x) => x.code === 'PORT_FREMD_BELEGT'));

console.log('\nBeratung — das Geraet haengt im falschen Netz:');
const b6 = vb.berate({ geraetId: 'mindray-umec12-vet', lauschPorts: ALLE_PORTS, pcIps: ['192.168.0.5'], geraetImNetz: true, gleichesNetz: false, geraetIp: '10.0.0.7', empfangBytes: 0 });
ok('Befund ANDERES_NETZ', b6.befunde.some((x) => x.code === 'ANDERES_NETZ'));
ok('beide Adressen stehen im Text', b6.befunde.some((x) => /10\.0\.0\.7/.test(x.titel) && /192\.168\.0\.5/.test(x.warum)));

console.log('\nBeratung — es kommt etwas an, aber unlesbar (MD2):');
const b7 = vb.berate({ geraetId: 'mindray-umec12-vet', lauschPorts: ALLE_PORTS, empfangBytes: 4096,
  empfangProtokoll: { id: 'mindray-md2', name: 'Mindray MD2 (herstellereigenes Binaerprotokoll)', lesbar: false } });
const p7 = b7.befunde.filter((x) => x.code === 'PROTOKOLL_UNLESBAR')[0];
ok('Befund PROTOKOLL_UNLESBAR', !!p7, JSON.stringify(b7.befunde.map((x) => x.code)));
ok('sagt ausdruecklich, dass die Leitung steht', p7 && /Leitung steht also/.test(p7.warum));
ok('sagt ausdruecklich, dass nicht geraten wird', p7 && /Geraten wird hier nichts/.test(p7.warum));

console.log('\nBeratung — alles steht, das Geraet sendet nur nichts:');
const b8 = vb.berate({ geraetId: 'eickemeyer-lifevet-10c', wegId: 'hl7-push-8830', lauschPorts: ALLE_PORTS, empfangBytes: 0, geraetImNetz: true, gleichesNetz: true });
const p8 = b8.befunde.filter((x) => x.code === 'GERAET_SENDET_NICHT')[0];
ok('Befund GERAET_SENDET_NICHT', !!p8, JSON.stringify(b8.befunde.map((x) => x.code)));
ok('die Anleitung des Geraets wird gleich mitgeliefert', p8 && p8.tun.length >= 3);
ok('der Sensor-Hinweis fehlt nicht', p8 && /Sensoren am Patienten/.test(p8.warum));

console.log('\nWegempfehlung:');
const w1 = vb.empfehleWeg('eickemeyer-lifevet-10c', { offenePorts: [4601] });
ok('bei offenem 4601 wird der Abfrageweg empfohlen (am Geraet ist dann nichts einzustellen)',
  w1 && w1.id === 'hl7-abfrage-4601', w1 && w1.id);
const w2 = vb.empfehleWeg('eickemeyer-lifevet-10c', {});
ok('ohne offenen Port bleibt der belegte Push-Weg vorn', w2 && w2.id === 'hl7-push-8830', w2 && w2.id);
const w3 = vb.empfehleWeg('mindray-umec12-vet', {});
ok('beim uMEC12 wird NICHT der MD2-Weg empfohlen', w3 && w3.id !== 'gateway-md2-3502', w3 && w3.id);

console.log('\n---');
console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
console.log('OK (' + pass + ' Pruefungen)');
