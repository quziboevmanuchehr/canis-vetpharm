<#
  watchdog-erkennung.ps1 - "Gehoert dieser Prozess zu UNS?"

  WARUM EIGENE DATEI (Befund der Gegenpruefung, 01.08.2026): Diese Frage entscheidet darueber, ob
  gleich Stop-Process auf einem Medizin-PC ausgefuehrt wird. Sie stand vorher mitten in
  watchdog.ps1 - und weil dort am Dateiende eine Endlosschleife laeuft, konnte kein Test sie je
  AUFRUFEN. Geprueft wurde nur, ob ihr Name im Quelltext vorkommt. Ein Umbau auf `return $true`
  waere gruen durchgegangen und haette den Watchdog zum Schaedling gemacht.

  Hier steht deshalb nur Erkennung, keine Handlung. tests/tools/watchdog-test.js laedt diese
  Datei, ersetzt Get-Process/Get-CimInstance/Get-NetTCPConnection durch eigene Funktionen (in
  PowerShell haben Funktionen Vorrang vor Cmdlets) und prueft das ECHTE Verhalten gegen
  erfundene Lagen - ohne dass ein einziger Prozess angefasst wird.
#>

<#
  Ohne den Watchdog daneben (also im Test) gibt es kein Protokoll. Dann wird nach Write-Verbose
  geschrieben statt zu verschlucken. Laedt watchdog.ps1 diese Datei, ist Schreibe dort schon
  definiert und bleibt es - deshalb wird sie dort erst NACH Schreibe eingebunden.
#>
if (-not (Get-Command -Name Schreibe -CommandType Function -ErrorAction SilentlyContinue)) {
  function Schreibe { param([string]$Text) Write-Verbose $Text }
}

<#
  Liegt dieser Pfad im Stationsordner?

  Bewusst StartsWith statt -like: in -like sind eckige Klammern PLATZHALTER. Bei einem Ordner wie
  'C:\Programme [alt]\VetStation' haette '-like "C:\Programme [alt]\VetStation\*"' die eigene
  Station NICHT erkannt - der Watchdog haette sie fuer fremd gehalten und nie geheilt.
  StartsWith kennt keine Platzhalter.
#>
function Test-ImStationsordner {
  param([string]$Pfad, [string]$Stammordner)
  if (-not $Pfad -or -not $Stammordner) { return $false }
  return $Pfad.StartsWith($Stammordner, [StringComparison]::OrdinalIgnoreCase)
}

<#
  Gehoert dieser Prozess zu UNS? Die Antwort muss in BEIDE Richtungen stimmen.

  DER FEHLER, DEN DIE GEGENPRUEFUNG FAND (und der die ganze Selbstheilung aushebelte): Die erste
  Fassung lautete sinngemaess

      if ($pfad) { return ($pfad -like "$Root\*") }      # <- und sonst nichts mehr
      ... Loopback-Pruefung nur bei LEEREM Pfad ...

  Damit galt: Pfad lesbar, liegt aber ausserhalb des Stationsordners -> "nicht unsere" -> 'fremd'
  -> nie beenden -> Station bleibt dauerhaft unten. Genau dieser Fall ist ausdruecklich
  vorgesehen: Find-Node in launch-kiosk.ps1 nimmt ein SYSTEM-Node ('C:\Program Files\nodejs\
  node.exe'), wenn kein node\node.exe mitgeliefert wurde, und Install-VetStation.ps1 fuehrt das
  als gleichwertige Wahl. Die Selbstheilung waere dort still ausgefallen - mit einer beruhigend
  klingenden Zeile im Protokoll ("gehoert nicht zu VetStation. Er wird NICHT angefasst.").

  Ebenfalls widerlegt wurde die Annahme, der Pfad sei bei der geplanten Aufgabe immer unlesbar.
  Nachgemessen: fuer die von der erhoehten Autostart-Aufgabe gestartete Station war der Pfad aus
  einer NICHT erhoehten Abfrage lesbar. Beide Faelle kommen vor.

  Deshalb zwei UNABHAENGIGE Kennzeichen, von denen EINES genuegt:
    1. Der Prozess heisst 'node' (Grundbedingung, ohne die nichts weiter geprueft wird), UND
    2a. sein Programmpfad liegt im Stationsordner  ODER
    2b. er horcht auf der LOOPBACK-Adresse genau dieses Stationsports.
  Der Pfad ist damit ein hinreichender, aber kein notwendiger Beleg - ein nicht passender Pfad
  schliesst nichts mehr aus, sondern gibt die Frage an das zweite Kennzeichen weiter.

  Warum 2b eng genug ist, um darauf einen Prozessabschuss zu stuetzen: die Bridge bindet
  ausdruecklich 127.0.0.1:8770, nicht 0.0.0.0. Ein FREMDES Programm muesste zugleich 'node'
  heissen, auf der reinen Loopback-Adresse sitzen, genau diesen Port halten und 30 Sekunden lang
  nicht auf /healthz antworten. Auf einem Stations-PC gibt es das nicht.
#>
function Test-IstUnsereBridge {
  param([int]$Kennung, [int]$P, [string]$Stammordner)

  $proz = Get-Process -Id $Kennung -ErrorAction SilentlyContinue
  if (-not $proz) { return $false }
  if ($proz.ProcessName -ne 'node') { return $false }

  # Kennzeichen 2a - Pfad. Ueber CIM statt (Get-Process).Path: letzteres WIRFT bei
  # unzugaenglichen Prozessen und braeuchte ein leeres catch. ExecutablePath ist schlicht leer,
  # wenn Windows keine Auskunft gibt.
  $pfad = $null
  $w = Get-CimInstance Win32_Process -Filter "ProcessId=$Kennung" -ErrorAction SilentlyContinue
  if ($w) { $pfad = $w.ExecutablePath }
  if (Test-ImStationsordner $pfad $Stammordner) { return $true }

  # Kennzeichen 2b - Loopback. Wird IMMER geprueft, nicht nur bei leerem Pfad.
  try {
    $v = @(Get-NetTCPConnection -LocalPort $P -State Listen -ErrorAction Stop |
           Where-Object { $_.OwningProcess -eq $Kennung })
    foreach ($e in $v) { if ($e.LocalAddress -eq '127.0.0.1' -or $e.LocalAddress -eq '::1') { return $true } }
  } catch {
    Schreibe "Loopback-Pruefung fuer Prozess ${Kennung} fehlgeschlagen: $($_.Exception.Message)"
  }
  return $false
}
