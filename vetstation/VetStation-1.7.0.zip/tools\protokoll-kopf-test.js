'use strict';
/*
 * protokoll-kopf-test.js — der Spaltenkopf des Narkoseprotokolls muss auf JEDER Seite stehen.
 *
 * DER BEFUND, DEN DIESER TEST FESTNAGELT (Praxis, 06.08.2026):
 * Auf dem ausgedruckten Protokoll hat die Tieraerztin auf Seite 2 mit rotem Stift
 * "Zeit · HF · SpO2 · AF · Befund" ueber die Spalten geschrieben — weil dort nichts stand.
 * need() brach die Seite um und rief band() (den blauen Titelbalken), aber der Spaltenkopf der
 * laufenden Tabelle wurde nie wiederholt. Bei einer einstuendigen Narkose sind das seitenweise
 * nackte Zahlenkolonnen: 121 · 97 · 20 — und niemand kann sagen, welche Spalte die
 * Sauerstoffsaettigung ist und welche die Atemfrequenz.
 *
 * WARUM DER TEST RECHNET STATT NACHZUSEHEN:
 * Eine Pruefung "steht die Zeichenkette kopfZeichnen in der Datei" wuerde auch dann gruen bleiben,
 * wenn der Kopf beim Seitenwechsel gar nicht gerufen wird oder wenn er sich in eine Endlosschleife
 * legt. Deshalb werden die Seitenaufbau-Funktionen (band, footer, need, nl, kopfZeichnen,
 * seitenwechsel, tableHead, tableRow, tabelleEnde) AUS DER DATEI geholt und gegen ein
 * Papier-Modell wirklich ausgefuehrt: 400 Messzeilen, und danach wird geprueft, ob auf jeder
 * Seite ganz oben der Kopf steht.
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const src = fs.readFileSync(path.join(WURZEL, 'ui/vetstation-live.js'), 'utf8');

let ok = 0, fail = 0;
function abschnitt(t) { console.log('\n' + t); }
function pruef(name, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (zusatz ? '   [' + zusatz + ']' : '')); }
}

/* Holt eine Funktionsdefinition per Klammerzaehlung aus dem Quelltext — dieselbe Bauart wie in
 * geraete-profil-test.js. Ein Ausschnitt nach Zeichenfenster wuerde beim naechsten Kommentar
 * brechen. */
function holeFunktion(name, text) {
  const start = text.indexOf('function ' + name + '(');
  if (start < 0) return null;
  let i = text.indexOf('{', start), tiefe = 0;
  if (i < 0) return null;
  for (let j = i; j < text.length; j++) {
    const c = text[j];
    if (c === '{') tiefe++;
    else if (c === '}') { tiefe--; if (tiefe === 0) return text.slice(start, j + 1); }
  }
  return null;
}

abschnitt('1) Die Bausteine sind da und haengen richtig zusammen');
const NAMEN = ['band', 'footer', 'need', 'nl', 'kopfZeichnen', 'seitenwechsel', 'tableHead', 'tableRow', 'tabelleEnde', 'sectionTitle'];
const teile = {};
NAMEN.forEach((n) => { teile[n] = holeFunktion(n, src); pruef(n + '() ist auffindbar', !!teile[n]); });

pruef('need() bricht ueber seitenwechsel() um (nicht mehr direkt ueber addPage)',
  /function need\(h\) \{ if \(y \+ h > H - 16\) seitenwechsel\(\); \}/.test(src));
pruef('seitenwechsel() zeichnet den Kopf der laufenden Tabelle nach',
  /function seitenwechsel\(\)[\s\S]{0,400}kopfZeichnen\(laufendeTabelle\.cells, laufendeTabelle\.cols, true\)/.test(src));
pruef('der Wiederholungskopf kann sich nicht selbst ausloesen (Rekursionsschutz)',
  /kopfLaeuft = true;[\s\S]{0,120}kopfLaeuft = false;/.test(src) && /if \(laufendeTabelle && !kopfLaeuft\)/.test(src));
/* Am AUSGESCHNITTENEN Rumpf gemessen, nicht am Zeichenfenster: ein Fenster ueber den rohen
 * Quelltext bricht beim naechsten eingefuegten Kommentar. */
const kopfCode = (teile.kopfZeichnen || '').replace(/\/\/[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');
pruef('kopfZeichnen() setzt y direkt und ruft NICHT nl() (darin steckt need)',
  !!teile.kopfZeichnen && /y \+= 6\.6;/.test(kopfCode) && !/\bnl\(/.test(kopfCode) && !/\bneed\(/.test(kopfCode),
  teile.kopfZeichnen ? '' : 'nicht gefunden');
pruef('Kopf und mindestens eine Zeile passen zusammen (kein Kopf als letzte Zeile)',
  /function tableHead\(cells, cols\) \{ laufendeTabelle = null; need\(13\)/.test(src));
pruef('jede der drei Tabellen wird ausdruecklich beendet',
  (src.match(/tabelleEnde\(\);/g) || []).length >= 4);
pruef('ein neuer Abschnitt beendet die Tabelle ebenfalls',
  /function sectionTitle\(t\) \{ tabelleEnde\(\);/.test(src));

abschnitt('2) Der Seitenaufbau wird WIRKLICH durchgerechnet (400 Messzeilen)');
/*
 * Papier-Modell: ein doc-Stellvertreter, der jede Textausgabe mit Seite und y-Lage mitschreibt.
 * Genau so rechnet jsPDF auch — nur ohne die PDF-Datei am Ende.
 */
function baueLauf() {
  const seiten = [];   // je Seite: Liste von { text, x, y }
  let aktuelle = null;
  const doc = {
    setFillColor() {}, setTextColor() {}, setDrawColor() {}, setLineWidth() {},
    setFont() {}, setFontSize() {}, rect() {}, line() {}, circle() {},
    splitTextToSize(s, b) { return [String(s)]; },
    addPage() { aktuelle = []; seiten.push(aktuelle); },
    text(s, x, yy) { if (!aktuelle) { aktuelle = []; seiten.push(aktuelle); } aktuelle.push({ text: String(s), x: x, y: yy }); },
  };
  const umgebung = {
    doc, W: 210, H: 297, M: 14, y: 14, pageNo: 0,
    TEAL: [18, 110, 120], INK: [33, 41, 51], MUT: [120, 130, 140], LINE: [214, 220, 226],
    Date, String, Number, Math,
  };
  // Die Funktionen im Zusammenhang auswerten — dieselben Quelltexte, ein gemeinsamer Namensraum.
  const rumpf = `
    var laufendeTabelle = null, kopfLaeuft = false;
    function setC(){} function T(s,x,size,style,c,align){ doc.setFont('helvetica'); doc.text(String(s), x==null?M:x, y); }
    ${teile.band}
    ${teile.footer}
    ${teile.kopfZeichnen}
    ${teile.seitenwechsel}
    ${teile.need}
    ${teile.nl}
    ${teile.tableHead}
    ${teile.tableRow}
    ${teile.tabelleEnde}
    return { band: band, tableHead: tableHead, tableRow: tableRow, tabelleEnde: tabelleEnde,
             seiten: null, hole: function(){ return { y: y, pageNo: pageNo }; } };
  `;
  const bauen = new Function('doc', 'W', 'H', 'M', 'y', 'pageNo', 'TEAL', 'INK', 'MUT', 'LINE', rumpf);
  const api = bauen(doc, umgebung.W, umgebung.H, umgebung.M, umgebung.y, umgebung.pageNo,
    umgebung.TEAL, umgebung.INK, umgebung.MUT, umgebung.LINE);
  return { api, seiten };
}

const KOPF = ['Zeit', 'HF', 'SpO₂', 'EtCO₂', 'MAP', 'AF', 'Temp', 'Befund / Rhythmus'];
const COLS = [22, 15, 16, 20, 16, 14, 17, 60];

let lauf = null, fehlerBeimLauf = null;
try {
  lauf = baueLauf();
  lauf.api.band();
  lauf.api.tableHead(KOPF, COLS);
  for (let i = 0; i < 400; i++) {
    const t = new Date(2026, 7, 6, 9, 0, 0).getTime() + i * 85000;
    lauf.api.tableRow(['09:0' + (i % 10) + ':01', String(120 - (i % 9)), '97', '-', '-', String(20 + (i % 12)), '-',
      'Ventrikuläre Extrasystolen'], COLS, 7.8);
  }
  lauf.api.tabelleEnde();
} catch (e) { fehlerBeimLauf = e; }

pruef('400 Zeilen laufen ohne Fehler durch (keine Endlosschleife, kein Stapelueberlauf)',
  !fehlerBeimLauf, fehlerBeimLauf ? String(fehlerBeimLauf.message).slice(0, 90) : '');

if (lauf && !fehlerBeimLauf) {
  const seiten = lauf.seiten;
  pruef('es sind wirklich mehrere Seiten geworden (sonst prueft der Test nichts)',
    seiten.length >= 4, seiten.length + ' Seiten');

  // Auf JEDER Seite muessen alle Kopfzellen vorkommen ...
  const ohneKopf = [];
  seiten.forEach((s, i) => {
    const txt = s.map((e) => e.text);
    const fehlt = KOPF.filter((k) => txt.indexOf(k) < 0);
    if (fehlt.length) ohneKopf.push('Seite ' + (i + 1) + ' ohne ' + fehlt.join('/'));
  });
  pruef('JEDE Seite traegt alle acht Spaltenueberschriften', ohneKopf.length === 0, ohneKopf.slice(0, 3).join(' · '));

  // ... und zwar GANZ OBEN, vor der ersten Messzeile.
  const zuTief = [];
  seiten.forEach((s, i) => {
    const kopfY = (s.find((e) => e.text === 'Zeit') || {}).y;
    const ersteZeile = s.find((e) => /^09:\d/.test(e.text) && e.y !== kopfY);
    if (kopfY == null) { zuTief.push('Seite ' + (i + 1) + ': kein Kopf'); return; }
    if (ersteZeile && ersteZeile.y < kopfY) zuTief.push('Seite ' + (i + 1) + ': Messzeile ueber dem Kopf');
  });
  pruef('der Kopf steht VOR der ersten Messzeile der Seite, nicht mittendrin',
    zuTief.length === 0, zuTief.slice(0, 3).join(' · '));

  // Die erste Seite bleibt, wie sie war: ohne den Zusatz "(Fortsetzung)".
  const ersteHatFortsetzung = seiten[0].some((e) => e.text === '(Fortsetzung)');
  pruef('die ERSTE Seite bleibt unveraendert (kein "(Fortsetzung)")', !ersteHatFortsetzung);
  const folgeOhneMarke = seiten.slice(1).filter((s) => !s.some((e) => e.text === '(Fortsetzung)')).length;
  pruef('jede FOLGESEITE ist als Fortsetzung gekennzeichnet', folgeOhneMarke === 0, folgeOhneMarke + ' ohne Marke');

  // Genau EIN Kopf je Seite — der Rekursionsschutz muss halten.
  const mehrfach = seiten.map((s, i) => [i + 1, s.filter((e) => e.text === 'Zeit').length]).filter((z) => z[1] !== 1);
  pruef('genau EIN Spaltenkopf je Seite (Rekursionsschutz haelt)',
    mehrfach.length === 0, mehrfach.slice(0, 3).map((z) => 'Seite ' + z[0] + ': ' + z[1]).join(' · '));

  // Nach tabelleEnde() darf kein Kopf mehr nachkommen.
  const nachher = baueLauf();
  nachher.api.band();
  nachher.api.tableHead(['Parameter', 'Wert', 'Einheit', 'Narkose-Norm'], [64, 30, 26, 42]);
  for (let i = 0; i < 6; i++) nachher.api.tableRow(['P' + i, '1', 'x', 'y'], [64, 30, 26, 42]);
  nachher.api.tabelleEnde();
  for (let i = 0; i < 120; i++) nachher.api.tableRow(['Fliesstext ' + i, '', '', ''], [64, 30, 26, 42]);
  const spaeterKopf = nachher.seiten.slice(1).some((s) => s.some((e) => e.text === 'Parameter'));
  pruef('nach tabelleEnde() wird KEIN Kopf mehr nachgezogen', !spaeterKopf);
}

abschnitt('3) Die Werte im Kopf stimmen mit den Werten in den Zeilen ueberein');
/* Ein Kopf, der andere Spalten nennt als die Zeilen tragen, waere schlimmer als gar keiner. */
const kopfZeile = src.match(/tableHead\(\[('Zeit'[^\]]*)\], cols\)/);
pruef('der Verlaufskopf nennt Zeit, HF, SpO2, EtCO2, MAP, AF, Temp, Befund',
  !!kopfZeile && /'Zeit'.*'HF'.*'SpO₂'.*'EtCO₂'.*'MAP'.*'AF'.*'Temp'.*'Befund/.test(kopfZeile[1]), kopfZeile ? kopfZeile[1] : '');
pruef('und die Messzeile fuellt genau diese acht Spalten in dieser Reihenfolge',
  /tableRow\(\[hhmmss\(e\.ts\), String\(nn\(e\.hr\)\), String\(nn\(e\.spo2\)\), String\(nn\(e\.etco2\)\), String\(nn\(e\.map\)\), String\(nn\(e\.af\)\), String\(nn\(e\.temp\)\)/.test(src));

console.log('\n== Ergebnis: ' + ok + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
