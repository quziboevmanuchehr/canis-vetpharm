'use strict';
/*
 * firewall.js — liest den Zustand der Windows-Firewall-Regeln fuer die Geraeteports AUS.
 *
 * WARUM (Befund 2.6): Fehlt eine Freigabe, verwirft Windows die Vitaldaten LAUTLOS. Das Geraet
 * meldet "sendet", der PC zeigt nichts, und NIRGENDS steht eine Fehlermeldung. Bisher wurde die
 * Freigabe nur EMPFOHLEN, nie geprueft.
 *
 * EHRLICHKEIT ist hier wichtiger als ein gruener Haken: laesst sich der Zustand nicht eindeutig
 * lesen (kein netsh, keine Rechte, fremde Sprache), melden wir 'unklar' — NIEMALS "in Ordnung".
 *
 * Sprachunabhaengig: wir suchen NICHT nach uebersetzten Feldnamen ("Aktiviert:"/"Enabled:"),
 * sondern nach unserem EIGENEN Regelnamen, der in jeder Windows-Sprache woertlich so dasteht.
 */
const { execFile } = require('child_process');
const { DATA_PORTS } = require('./netscan');

const REGEL_PREFIX = 'VetStation Geraetedaten TCP ';

/*
 * ZWEITER REGELSATZ, ab 1.1.0: der Nachbar-Port zwischen zwei OP-Saelen (Stufe 2, Port 8771).
 *
 * WARUM EIN EIGENER PRAEFIX UND NICHT EINFACH EIN PORT MEHR IN DER LISTE: der Regelname ist das
 * Einzige, woran sich hier etwas sprachunabhaengig wiedererkennen laesst — und die beiden Faelle
 * sind NICHT gleichwertig. Die Geraeteregeln lassen einen Monitor an den PC; diese hier laesst
 * einen ZWEITEN PC heran. Sie wird deshalb enger gesetzt (nur Profil Privat/Domaene, nur
 * LocalSubnet), und wer die Freigaben liest, soll die beiden Faelle auseinanderhalten koennen,
 * ohne eine Portnummer nachschlagen zu muessen.
 *
 * Ebenso wichtig: 8771 darf NIE in netscan.DATA_PORTS landen. Ein offener Datenport macht einen
 * Teilnehmer zum "sicheren Geraet" — die Geraetesuche hielte den Nachbar-PC dann fuer einen
 * Monitor. tools/paket-test.js erzwingt beides.
 */
const STATION_PREFIX = 'VetStation Nachbarsaal TCP ';
const STATION_PORTS = [8771];

function regelName(port, prefix) { return (prefix || REGEL_PREFIX) + port; }

// Zaehlt, wie oft unser Regelname in der netsh-Ausgabe vorkommt = Anzahl der Regeln.
function zaehleRegeln(stdout, port, prefix) {
  const name = regelName(port, prefix);
  let n = 0, i = 0;
  const text = String(stdout || '');
  for (;;) {
    const p = text.indexOf(name, i);
    if (p < 0) break;
    // Ausschliessen, dass "TCP 3502" auch in "TCP 35020" gefunden wird.
    const nach = text.charAt(p + name.length);
    if (!/\d/.test(nach)) n++;
    i = p + name.length;
  }
  return n;
}

/*
 * ================================================================
 * WARUM DER REGELNAME ALLEIN NICHT GENUEGT (Befund 01.08.2026)
 * ================================================================
 * Bis hierher galt: Regelname gefunden = 'frei'. Das ist in zwei Richtungen falsch.
 *
 *  (a) Eine Regel kann EXISTIEREN und trotzdem nicht wirken — deaktiviert (Enabled=False) oder
 *      mit Action=Block. Windows verwirft die Vitaldaten dann lautlos, und die Station meldet
 *      einen gruenen Haken. Das ist genau der Zustand, den diese Datei aufdecken soll.
 *  (b) Umgekehrt kann ein Port durch eine FREMDE Regel oder eine abgeschaltete Firewall offen
 *      sein. Frueher hiess das hier 'fehlt' und muendete in die harte Behauptung
 *      "WINDOWS-FIREWALL BLOCKIERT Port X" — obwohl die Daten in Wahrheit ankamen.
 *
 * DER WEG, DER SPRACHUNABHAENGIG BLEIBT: PowerShell statt netsh. `Get-NetFirewallRule` liefert
 * Enabled und Action als .NET-Aufzaehlungsnamen ("True"/"False", "Allow"/"Block") — die sind in
 * JEDER Windows-Sprache gleich, anders als die uebersetzten Feldnamen der netsh-Ausgabe. Ein
 * einziger Aufruf holt alle Regeln des Praefixes; schlaegt er fehl, bleibt der alte netsh-Weg als
 * Rueckfall, dann aber ausdruecklich als 'nurName' gekennzeichnet statt als sicheres 'frei'.
 */
function powershellRegeln(prefix) {
  return new Promise((resolve) => {
    const p = (prefix || REGEL_PREFIX);
    const befehl = "Get-NetFirewallRule -DisplayName '" + p.replace(/'/g, "''") + "*' -ErrorAction SilentlyContinue | " +
      'Select-Object -Property DisplayName,Enabled,Action,Direction | ConvertTo-Json -Compress';
    execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', befehl],
      { timeout: 15000, windowsHide: true }, (err, stdout) => {
        const text = String(stdout || '').trim();
        if (err || !text) return resolve(null);      // null = "kein Ergebnis", NICHT "keine Regeln"
        let j;
        try { j = JSON.parse(text); } catch (_) { return resolve(null); }
        const liste = Array.isArray(j) ? j : [j];
        const aus = [];
        liste.forEach((r) => {
          if (!r || !r.DisplayName) return;
          /* Enabled kommt je nach PowerShell-Fassung als true/false oder als 1/2
           * (1 = True, 2 = False in der NetSecurity-Aufzaehlung). Action: 2 = Allow, 4 = Block. */
          const an = (r.Enabled === true || r.Enabled === 1 || String(r.Enabled) === 'True' || String(r.Enabled) === '1');
          const erlaubt = (r.Action === 2 || String(r.Action) === 'Allow');
          aus.push({ name: String(r.DisplayName), an: an, erlaubt: erlaubt });
        });
        resolve(aus);
      });
  });
}

/* Aus der PowerShell-Liste den Zustand EINES Ports ableiten. Pure Funktion -> testbar. */
function zustandAus(regeln, port, prefix) {
  const name = regelName(port, prefix);
  const meine = (regeln || []).filter((r) => r.name === name);
  if (!meine.length) return { port: port, zustand: 'fehlt', anzahl: 0 };
  const wirksam = meine.filter((r) => r.an && r.erlaubt);
  if (wirksam.length) return { port: port, zustand: 'frei', anzahl: meine.length };
  /* Es GIBT eine Regel, aber sie wirkt nicht. Das ist der gefaehrlichste Zustand: er sah bisher
   * aus wie "in Ordnung", und die Daten kamen trotzdem nicht an. */
  const aus = meine.filter((r) => !r.an).length;
  return {
    port: port, zustand: 'unwirksam', anzahl: meine.length,
    grund: aus ? 'die Regel ist ABGESCHALTET' : 'die Regel steht auf BLOCKIEREN statt Zulassen',
  };
}

function frageRegel(port, prefix) {
  return new Promise((resolve) => {
    execFile('netsh', ['advfirewall', 'firewall', 'show', 'rule', 'name=' + regelName(port, prefix)],
      { timeout: 8000, windowsHide: true }, (err, stdout, stderr) => {
        const text = String(stdout || '') + String(stderr || '');
        const treffer = zaehleRegeln(text, port, prefix);
        if (treffer > 0) return resolve({ port: port, zustand: 'frei', anzahl: treffer });
        // netsh antwortet mit Exitcode 1 + "Keine Regeln entsprechen den Kriterien" wenn es sie nicht gibt.
        // Kam ueberhaupt eine Ausgabe? Dann ist die Aussage "existiert nicht" belastbar.
        if (text.trim().length > 0) return resolve({ port: port, zustand: 'fehlt', anzahl: 0 });
        // Gar keine Ausgabe / netsh nicht startbar -> wir wissen es schlicht nicht.
        resolve({ port: port, zustand: 'unklar', anzahl: 0, grund: err ? err.message : 'keine Ausgabe von netsh' });
      });
  });
}

/*
 * pruefe() -> {
 *   lesbar: bool,                       // konnte ueberhaupt etwas gelesen werden?
 *   ports: [{port, zustand:'frei'|'fehlt'|'unklar', anzahl}],
 *   fehlend: [port...], doppelt: [{port,anzahl}...], unklar: [port...]
 * }
 */
async function pruefe(ports, prefix) {
  const liste = ports && ports.length ? ports : DATA_PORTS;

  /* ZUERST der genaue Weg: eine PowerShell-Abfrage fuer ALLE Regeln des Praefixes. Sie sieht,
   * ob eine Regel eingeschaltet ist und ob sie zulaesst — beides kann der Namensvergleich nicht. */
  let res = null;
  const regeln = await powershellRegeln(prefix).catch(() => null);
  if (regeln) {
    res = liste.map((p) => zustandAus(regeln, p, prefix));
  } else {
    /* RUECKFALL auf den alten Namensvergleich. Er bleibt drin, weil er auf jedem Windows laeuft —
     * aber sein "frei" ist ausdruecklich nur ein "die Regel existiert". Das steht jetzt auch dran,
     * statt als sicherer gruener Haken durchzugehen. */
    res = [];
    for (const p of liste) {
      const r = await frageRegel(p, prefix);
      if (r.zustand === 'frei') r.nurName = true;
      res.push(r);
    }
  }

  return {
    lesbar: res.some((r) => r.zustand !== 'unklar'),
    genau: !!regeln,          // false = nur Namensvergleich, "frei" ist dann nicht bewiesen
    ports: res,
    fehlend: res.filter((r) => r.zustand === 'fehlt').map((r) => r.port),
    /* NEU und der eigentliche Grund fuer diesen Umbau: eine Regel, die es GIBT, die aber
     * abgeschaltet ist oder blockiert. Sie sah bisher aus wie "in Ordnung". */
    unwirksam: res.filter((r) => r.zustand === 'unwirksam').map((r) => ({ port: r.port, grund: r.grund })),
    doppelt: res.filter((r) => r.anzahl > 1).map((r) => ({ port: r.port, anzahl: r.anzahl })),
    unklar: res.filter((r) => r.zustand === 'unklar').map((r) => r.port),
  };
}

module.exports = {
  pruefe, zaehleRegeln, regelName, zustandAus, powershellRegeln,
  REGEL_PREFIX, STATION_PREFIX, STATION_PORTS,
};
