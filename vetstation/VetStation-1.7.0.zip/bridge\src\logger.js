'use strict';
/*
 * logger.js — Lokales Diagnose-Log (Technik/Verbindung, §14.4).
 * Schreibt anonymisierte Ereignisse in data/diag.log (lokal, keine Cloud) und haelt
 * einen Ringpuffer der letzten Ereignisse fuer den Admin-Bereich vor. Wird zusaetzlich
 * ueber den WebSocket als MSG.DIAG an die UI gesendet.
 *
 * WIEDERHOLUNGEN WERDEN ZUSAMMENGEFASST (Befund 2.2/2.3, 21.07.2026):
 * Bei nicht erreichbarer Cloud schrieb der Publisher ~2 Fehlerzeilen pro Sekunde, der HL7-Client
 * bei abwesendem Geraet ~40 pro Minute. Der Ringpuffer fasst 500 Zeilen — nach gut vier Minuten
 * war er voll und SAEMTLICHE Verbindungsmeldungen daraus verdraengt. Ausgerechnet das Log, das
 * bei der Inbetriebnahme helfen soll, enthielt nur noch Dauerfehler.
 * Deshalb: identische Meldungen erzeugen KEINE neue Zeile mehr, sondern zaehlen die vorhandene
 * hoch. Sobald etwas anderes passiert, wird die Wiederholung als EINE Zeile abgeschlossen.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = path.join(DATA_DIR, 'diag.log');
const MAX_RING = 500;
const DEDUP_MS = 5 * 60 * 1000;   // laenger als jede sinnvolle Wiederholrate

/*
 * DAS DIAGNOSE-LOG WIRD UMGEBROCHEN (02.08.2026) — vorher wuchs es unbegrenzt.
 *
 * GEMESSEN, nicht vermutet: C:\VetStation\data\diag.log war am 02.08.2026 6,0 MB gross und
 * enthielt Zeilen ab dem 21.07.2026 — die Datei wurde in zwoelf Tagen Dauerbetrieb kein einziges
 * Mal gekuerzt, weil ausgeben() nur fs.appendFile kennt. Im Mittel sind das etwa 0,5 MB je Tag.
 * Das allein waere ertraeglich; gefaehrlich ist der Ausnahmefall, und der steht im selben Log:
 * am 21.07.2026 schrieb der Fern-Versand binnen Minuten 3408 gleichlautende Zeilen
 * "Fern-Live Schreibfehler: HTTP 404". Die Zusammenfassung weiter unten hat das NICHT aufgefangen,
 * weil sie nur unmittelbar AUFEINANDERFOLGENDE gleiche Meldungen zaehlt — dazwischen lagen
 * Meldungen anderer Quellen, und damit begann jedes Mal eine neue Serie.
 *
 * Was ein volles Laufwerk auf einem Praxis-PC bedeutet, ist der eigentliche Grund fuer diese
 * Aenderung: dann laesst sich data/protokoll.json und data/patient-akte.json nicht mehr schreiben.
 * Das Narkoseprotokoll ist ein Nachweisdokument. Ein Diagnoseprotokoll darf niemals derjenige sein,
 * der es verdraengt.
 *
 * Die Zahlen sind bewusst klein gewaehlt: zwei Dateien a 4 MB reichen fuer mehrere Tage
 * gewoehnlichen Betriebs und selbst im Fehlersturm noch fuer die letzten Zehntausende Zeilen — und
 * mehr liest ohnehin niemand. Wer weiter zurueck muss, nimmt BEFUND-EXPORTIEREN.bat.
 */
const LOG_MAX_BYTES = 4 * 1024 * 1024;
const LOG_ALT_FILE = LOG_FILE + '.1';
/* Nicht bei jeder Zeile die Dateigroesse erfragen: das waere ein Systemaufruf je Logzeile, und
 * beim Start schreibt die Station in Sekunden dutzende. Die Groesse wird deshalb MITGEZAEHLT und
 * nur beim ersten Schreiben einmal vom Dateisystem geholt. */
let logBytes = -1;

const ring = [];
let sink = null;          // Funktion, die Ereignisse an die UI weiterreicht (MSG.DIAG)
let letzte = null;        // zuletzt ausgegebenes Ereignis (fuer die Zusammenfassung)
let wiederholt = 0;       // wie oft es seither identisch wiederkam
const einmalig = new Set();

function ensureDir() {
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (_) {}
}

function setSink(fn) { sink = fn; }

function schluessel(level, source, msg) { return level + '|' + source + '|' + msg; }

/*
 * umbrechenWennNoetig(zusatz) — haelt data/diag.log unter LOG_MAX_BYTES.
 *
 * Bewusst SYNCHRON, und das ist die einzige Stelle im heissen Pfad, an der das gerechtfertigt ist:
 * das Umbenennen passiert im Betrieb hoechstens alle paar Tage, und es MUSS abgeschlossen sein,
 * bevor die naechste Zeile angehaengt wird — sonst schreiben zwei Vorgaenge in dieselbe Datei,
 * waehrend sie unter ihnen wegbenannt wird, und ein Teil der Zeilen landet im Nirgendwo.
 *
 * Wirft nie. Ein Diagnoseprotokoll, das den Betrieb anhaelt, waere schlimmer als gar keines:
 * geht das Umbenennen schief (Datei von einem Editor offen, Rechte fehlen), wird weiter angehaengt
 * und beim naechsten Mal erneut versucht.
 */
function umbrechenWennNoetig(zusatz) {
  if (logBytes < 0) {
    try { logBytes = fs.statSync(LOG_FILE).size; } catch (_) { logBytes = 0; }
  }
  if (logBytes + zusatz <= LOG_MAX_BYTES) { logBytes += zusatz; return; }
  try {
    try { fs.unlinkSync(LOG_ALT_FILE); } catch (_) {}   // Vorgaenger weg, sonst scheitert rename auf Windows
    fs.renameSync(LOG_FILE, LOG_ALT_FILE);
    logBytes = zusatz;
  } catch (_) {
    /* Konnte nicht umgebrochen werden. Weiterschreiben ist richtig — aber nicht endlos zaehlen,
     * sonst wird bei JEDER Zeile ein neuer Versuch unternommen. Erst in einer Minute wieder. */
    logBytes = LOG_MAX_BYTES - 64 * 1024;
  }
}

function ausgeben(ev) {
  const line = new Date(ev.ts).toISOString() + ' [' + ev.level + '] ' + ev.source + ': ' + ev.msg;
  if (ev.level === 'error') console.error(line); else console.log(line);
  try {
    ensureDir();
    umbrechenWennNoetig(Buffer.byteLength(line, 'utf8') + 1);
    fs.appendFile(LOG_FILE, line + '\n', () => {});
  } catch (_) {}
  if (sink) { try { sink(ev); } catch (_) {} }
}

// Schliesst eine laufende Wiederholungsserie mit EINER zusammenfassenden Zeile ab.
function serieAbschliessen() {
  if (!wiederholt || !letzte) { wiederholt = 0; return; }
  const ev = {
    ts: Date.now(), level: letzte.level, source: letzte.source,
    msg: '(vorige Meldung ' + wiederholt + '× wiederholt)', wiederholungen: wiederholt,
  };
  ring.push(ev);
  if (ring.length > MAX_RING) ring.shift();
  ausgeben(ev);
  wiederholt = 0;
}

function log(level, source, msg, extra) {
  const text = String(msg);
  const k = schluessel(level, source, text);
  const now = Date.now();

  // Identisch zur letzten Meldung und noch im Zeitfenster -> nur hochzaehlen, keine neue Zeile.
  if (letzte && letzte._k === k && (now - letzte.ts) < DEDUP_MS) {
    wiederholt++;
    letzte.ts = now;
    letzte.wiederholungen = wiederholt;
    return letzte;
  }

  serieAbschliessen();

  const ev = { ts: now, level: level, source: source, msg: text };
  if (extra !== undefined) ev.extra = extra;
  Object.defineProperty(ev, '_k', { value: k, enumerable: false, writable: true });
  ring.push(ev);
  if (ring.length > MAX_RING) ring.shift();
  letzte = ev;
  ausgeben(ev);
  return ev;
}

module.exports = {
  setSink,
  recent(n) { return ring.slice(-(n || 100)); },
  info: (s, m, e) => log('info', s, m, e),
  warn: (s, m, e) => log('warn', s, m, e),
  error: (s, m, e) => log('error', s, m, e),
  // Meldungen, die pro Programmlauf HOECHSTENS EINMAL erscheinen sollen (z.B. Einrichtungshinweise).
  once(key, level, source, msg) {
    if (einmalig.has(key)) return null;
    einmalig.add(key);
    return log(level || 'info', source, msg);
  },
  // Nur fuer Tests: Zustand zuruecksetzen.
  _reset() { ring.length = 0; letzte = null; wiederholt = 0; einmalig.clear(); logBytes = -1; },
  /* Nur fuer den Wächter tools/logumbruch-test.js: die Umbruchgrenze ist sonst eine Konstante,
   * und ein Test, der 4 MB Text schreibt, um sie zu erreichen, misst die Festplatte statt den
   * Code. Die Datei- und Zaehlerlogik ist dieselbe. */
  _umbruch: { DATEI: LOG_FILE, ALT: LOG_ALT_FILE, MAX: LOG_MAX_BYTES, stand() { return logBytes; } },
};
