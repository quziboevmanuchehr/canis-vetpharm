'use strict';
/*
 * bremse-test.js — die Lastbremse der Nachbarsaele (bridge/src/lastbremse.js).
 *
 * ------------------------------------------------------------------------------------------
 * DER BEFUND, DEN DIESER TEST FESTNAGELT (02.08.2026, am laufenden Praxis-PC gemessen)
 * ------------------------------------------------------------------------------------------
 * Die alte Bremse schaltete die Nachbarsaele ab, sobald EIN Taktabstand ueber 700 ms lag, und
 * liess sie fruehestens nach zehn Sekunden zurueck. Im echten diag.log stand deshalb — bei einer
 * Station OHNE angeschlossenes Geraet und OHNE Patient — alle ein bis drei Minuten:
 *
 *     16:14:19  875 ms   16:15:47 2573 ms   16:16:20  868 ms   16:18:17  712 ms
 *     16:22:23 4314 ms   16:25:48  843 ms   16:25:59  958 ms
 *
 * Sieben Abschaltungen in zwoelf Minuten. Fuer den Tierarzt heisst das: der Blick in den anderen
 * OP-Saal ist mehrmals pro Stunde ohne Grund und ohne Meldung leer — genau das, was man als
 * "die Verbindung zwischen den Saelen ist nicht stabil" erlebt.
 *
 * Die Zahlen oben werden hier EINGESPIELT. Der Test besteht nur, wenn diese Ausrutscher die
 * Nachbarsaele NICHT mehr abschalten — und wenn eine wirklich haengende Station sie weiterhin
 * abschaltet. Beides zusammen, sonst waere die Reparatur nur ein Wegsehen.
 *
 * Start: node tools/bremse-test.js      (laeuft auch in `node tools/alle-tests.js`)
 */
const path = require('path');
const fs = require('fs');
const lastbremse = require(path.join(__dirname, '..', 'bridge', 'src', 'lastbremse.js'));

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

/*
 * Spielt eine Folge von Taktabstaenden ab und liefert, was dabei passiert ist.
 * Die Uhr ist erfunden — genau dafuer nimmt lastbremse.takt() sie als Argument.
 */
function spiele(abstaende, start) {
  let z = lastbremse.neuerZustand();
  let uhr = start || 1000000;
  const meldungen = [];
  z = lastbremse.takt(z, uhr);                 // erster Takt setzt nur den Bezugspunkt
  abstaende.forEach((a) => {
    uhr += a;
    z = lastbremse.takt(z, uhr);
    if (z.meldung) meldungen.push({ bei: a, an: z.bremse, text: z.meldung });
  });
  return { z, meldungen, uhr };
}

const SOLL = 350;
const RUHIG = () => SOLL + Math.round((Math.random() - 0.5) * 40);   // 330..370

console.log('bremse-test: die Nachbarsaele duerfen nicht an jedem Ausrutscher haengen\n');

console.log('1) Die am 02.08.2026 GEMESSENEN Ausrutscher');

/*
 * Der echte Verlauf: lange ruhige Strecken, dazwischen einzelne lange Takte. Zwischen den
 * Ausrutschern lagen im Log ein bis drei MINUTEN, hier je 40 ruhige Takte (= 14 s) — das reicht,
 * denn was zaehlt, ist das Fenster von sechs Takten.
 */
const GEMESSEN = [875, 2573, 868, 712, 843, 958];
{
  const folge = [];
  GEMESSEN.forEach((a) => {
    for (let i = 0; i < 40; i++) folge.push(RUHIG());
    folge.push(a);
  });
  for (let i = 0; i < 40; i++) folge.push(RUHIG());

  const r = spiele(folge);
  ok('EINZELNE Ausrutscher (875/2573/868/712/843/958 ms) schalten die Nachbarsaele NICHT ab',
    r.z.bremseZaehler === 0,
    r.z.bremseZaehler + ' Abschaltung(en): ' + r.meldungen.map((m) => m.bei + 'ms').join(', '));
  ok('sie werden trotzdem gezaehlt (sichtbar in /api/nachbarn)',
    r.z.spaeteTakte === GEMESSEN.length,
    'gezaehlt: ' + r.z.spaeteTakte + ', erwartet: ' + GEMESSEN.length);
  ok('am Ende laufen die Nachbarsaele', r.z.bremse === false);
}

console.log('\n2) Der 4314-ms-Takt: eine echte Blockade MUSS sofort bremsen');
{
  const folge = [];
  for (let i = 0; i < 20; i++) folge.push(RUHIG());
  folge.push(4314);
  const r = spiele(folge);
  ok('ein Takt von 4314 ms schaltet die Nachbarsaele sofort ab', r.z.bremse === true);
  ok('als Grund steht "blockade", nicht "anhaltend"', r.z.grund === 'blockade', String(r.z.grund));
  ok('und es steht eine Warnung im Protokoll',
    r.meldungen.length === 1 && /Ereignisschleife stand/.test(r.meldungen[0].text),
    JSON.stringify(r.meldungen));
}

console.log('\n3) Eine WIRKLICH haengende Station wird weiterhin abgeschaltet');
{
  const folge = [];
  for (let i = 0; i < 10; i++) folge.push(RUHIG());
  // Anhaltend zu spaet: nicht katastrophal, aber dauerhaft ueber der Schwelle.
  for (let i = 0; i < 10; i++) folge.push(900);
  const r = spiele(folge);
  ok('zehn Takte in Folge ueber 700 ms schalten ab', r.z.bremse === true);
  ok('als Grund steht "anhaltend"', r.z.grund === 'anhaltend', String(r.z.grund));
  ok('abgeschaltet wird, BEVOR alle zehn durch sind (nicht erst am Ende)',
    r.meldungen.length > 0 && r.meldungen[0].an === true);
}

console.log('\n4) Zurueck kommen die Saele von selbst — aber nicht flatternd');
{
  const folge = [];
  for (let i = 0; i < 10; i++) folge.push(900);      // bremsen
  for (let i = 0; i < 40; i++) folge.push(RUHIG());  // beruhigen (40 x 350 ms = 14 s)
  const r = spiele(folge);
  ok('nach ruhigen Takten laufen die Nachbarsaele wieder', r.z.bremse === false);
  ok('es gab genau ein Ab- und ein Anschalten (kein Flattern)',
    r.meldungen.length === 2 && r.meldungen[0].an === true && r.meldungen[1].an === false,
    r.meldungen.map((m) => (m.an ? 'AUS' : 'AN')).join(','));
}
{
  /*
   * Gerechnet wird ab dem letzten ZU SPAETEN Takt, nicht ab dem Einschalten der Bremse. Dieser
   * Fall hat den Unterschied gezeigt: die Station haengt 9 s (10 x 900 ms) und ist danach 1,75 s
   * ruhig. Nach der ersten Fassung ("5 s seit dem Bremsen") waeren die Nachbarsaele hier
   * zurueckgekommen — obwohl die Ruhe erst 1,75 s alt war — und beim naechsten Haenger sofort
   * wieder weg. Also das Flattern, das die Schwelle verhindern soll.
   */
  const folge = [];
  for (let i = 0; i < 10; i++) folge.push(900);
  for (let i = 0; i < 5; i++) folge.push(350);       // 1,75 s Ruhe < ruheMs (5 s)
  const r = spiele(folge);
  ok('nach nur 1,75 s Ruhe bleiben sie aus (gerechnet ab dem letzten spaeten Takt)',
    r.z.bremse === true);
  /* Und die Gegenprobe: mit genug Ruhe kommen sie zurueck. */
  for (let i = 0; i < 15; i++) folge.push(350);      // zusammen 7 s Ruhe > ruheMs
  const r2 = spiele(folge);
  ok('nach 7 s Ruhe kommen sie zurueck', r2.z.bremse === false);
}

console.log('\n5) Ein Uhrensprung zurueck darf die Bremse weder ausloesen noch loesen');
{
  let z = lastbremse.neuerZustand();
  let uhr = 5000000;
  z = lastbremse.takt(z, uhr);
  for (let i = 0; i < 6; i++) { uhr += 350; z = lastbremse.takt(z, uhr); }
  const vorher = JSON.stringify({ b: z.bremse, a: z.abstaende, s: z.spaeteTakte });
  uhr -= 3600000;                                   // Zeitumstellung, NTP-Sprung
  z = lastbremse.takt(z, uhr);
  const nachher = JSON.stringify({ b: z.bremse, a: z.abstaende, s: z.spaeteTakte });
  ok('ein negativer Abstand aendert am Zustand nichts', vorher === nachher, vorher + ' -> ' + nachher);
  ok('und erzeugt keine Meldung', !z.meldung);
}
{
  /*
   * DER FALL, DEN DIE GEGENPRUEFUNG GEFUNDEN HAT (02.08.2026) — nicht dieser Test.
   * Bremse ist AN, dann springt die Uhr eine Stunde zurueck. Die gemerkten Zeitpunkte liegen
   * damit in der ZUKUNFT, und (jetzt - letzterSpaeter) wird nie wieder gross genug fuer ruheMs:
   * die Nachbarsaele waeren bis zum naechsten Neustart weg, ohne eine einzige Meldung.
   */
  let z = lastbremse.neuerZustand();
  let uhr = 9000000;
  z = lastbremse.takt(z, uhr);
  for (let i = 0; i < 10; i++) { uhr += 900; z = lastbremse.takt(z, uhr); }   // bremsen
  ok('Vorbedingung: die Bremse ist an', z.bremse === true);

  uhr -= 3600000;                                    // Uhr springt eine Stunde zurueck
  z = lastbremse.takt(z, uhr);
  for (let i = 0; i < 40; i++) { uhr += 350; z = lastbremse.takt(z, uhr); }   // 14 s Ruhe
  ok('nach einem Uhrensprung zurueck kommen die Nachbarsaele trotzdem wieder', z.bremse === false,
    'letzterSpaeter=' + z.letzterSpaeter + ' uhr=' + uhr + ' -> Abstand ' + (uhr - z.letzterSpaeter));
}

console.log('\n6) Direkt nach dem Start wird nicht vorschnell geurteilt');
{
  /* Der erste Takt nach dem Start ist regelmaessig langsam (Module laden, Adapter verbinden).
   * Ohne die Mindestproben haette das sofort gebremst — und die Nachbarn waeren bei JEDEM Start
   * erst einmal weg. */
  const r = spiele([1200, 350, 350]);
  ok('ein einzelner langsamer Takt direkt nach dem Start bremst nicht', r.z.bremse === false,
    JSON.stringify(r.meldungen));
  /* Eine echte Blockade aber schon — sonst waere der Start ein blinder Fleck. */
  const r2 = spiele([5000]);
  ok('eine echte Blockade direkt nach dem Start bremst trotzdem', r2.z.bremse === true);
}

console.log('\n7) Das Modul bleibt rein (sonst ist es nicht mehr pruefbar)');
{
  const quelle = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'lastbremse.js'), 'utf8');
  ok('kein require', !/\brequire\s*\(/.test(quelle));
  ok('keine eigene Uhr (kein Date.now)', !/Date\.now/.test(quelle));
  ok('kein Zugriff auf das Dateisystem oder das Netz',
    !/\bfs\b|\bhttp\b|\bnet\b/.test(quelle.replace(/^\s*\*.*$/gm, '')));

  /* Und die Gegenprobe an der Nahtstelle: server.js muss das Modul wirklich benutzen und darf die
   * alte Ein-Takt-Regel nicht wieder enthalten. */
  const server = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'server.js'), 'utf8');
  ok('server.js benutzt lastbremse', /require\('\.\/lastbremse'\)/.test(server)
    && /lastbremse\.takt\(/.test(server));
  ok('die alte Ein-Takt-Regel steht nicht mehr in server.js',
    !/abstand > BROADCAST_MS \* 2/.test(server));
  ok('die Zaehler stehen in /api/nachbarn (sonst ist der Fall nicht diagnostizierbar)',
    /bremseZaehler/.test(server) && /spaeteTakte/.test(server));
}

console.log('\n' + pass + ' bestanden, ' + fail + ' fehlgeschlagen');
process.exit(fail ? 1 : 0);
