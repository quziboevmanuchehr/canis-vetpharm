'use strict';
/*
 * port3502-test.js — Regressionstest fuer den Mindray-Gateway-Port 3502.
 *
 * HINTERGRUND (Praxis-Foto 21.07.2026): Im uMEC12 Vet steht unter
 * "Gateway-Kommunikationseinst." das Ziel  192.168.0.99 : 3502.
 * VetStation lauschte frueher NUR auf 4601/5000/24105/2575 -> die Daten des Monitors
 * kamen an einem Port an, auf dem niemand zugehoert hat. Dieser Test stellt sicher,
 * dass 3502 dauerhaft mitgelauscht und HL7 darauf korrekt geparst wird.
 *
 * EHRLICHKEIT DES TESTS (Befund 2.12, 21.07.2026): Frueher meldete dieser Test auf JEDEM PC mit
 * laufender Station 6 falsche Fehler, weil der belegte Port nicht erkannt wurde. Auf einem
 * Praxis-PC sah das aus, als sei die Geraeteanbindung kaputt — dabei belegte nur die eigene
 * Station den Port. Jetzt wird der Fall erkannt und die Pruefungen werden als UEBERSPRUNGEN
 * ausgewiesen, nicht als fehlgeschlagen.
 *
 * Start: node tools/port3502-test.js      (laeuft auch in `npm test`)
 */
const net = require('net');
const { Registry } = require('../bridge/src/registry');
const { ProbeAdapter } = require('../bridge/src/adapters/probe');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
const GATEWAY_PORT = 3502;
let pass = 0, fail = 0, skip = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function uebersprungen(n, grund) { skip++; console.log('  ○ ' + n + '  (uebersprungen: ' + grund + ')'); }
function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }
function mllp(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }

function oru(app, patientId, obx) {
  return 'MSH|^~\\&|' + app + '|||||20260721125200||ORU^R01|1|P|2.3.1\r' +
    'PID|||' + patientId + '\r' +
    'OBR|1||||' + app + '\r' + obx.join('\r');
}
// Echte Mindray-OBX-Codes wie am uMEC12 Vet
const UMEC_OBX = ['OBX|1|NM|101^HR||88', 'OBX|2|NM|160^SpO2||97', 'OBX|3|NM|220^CO2||38',
  'OBX|4|NM|222^AWRR||14', 'OBX|5|NM|200^T1||37.6'];

async function run() {
  console.log('VetStation — Gateway-Port 3502 (uMEC12 Vet "Gateway-Kommunikationseinst.")\n');
  const logger = { info() {}, warn() {}, error() {} };
  const registry = new Registry({ log: logger });
  const ctx = { emit: (raw) => registry.ingest(raw), log: logger };

  // 1) Standard-Portliste MUSS 3502 enthalten (ohne explizite Konfiguration)
  const probe = new ProbeAdapter({ id: 'assistent' }, ctx);
  ok('3502 ist in der Standard-Portliste des Assistenten', probe.ports.indexOf(GATEWAY_PORT) >= 0,
    'ports=' + JSON.stringify(probe.ports));
  ok('3502 wird ZUERST geprueft (Praxis-Standard)', probe.ports[0] === GATEWAY_PORT,
    'ports[0]=' + probe.ports[0]);
  /* 24105 stand hier bis 1.2.3 mit in der Liste. Es ist am 02.08.2026 bewusst ENTFALLEN: Philips
   * Data Export laeuft ausschliesslich ueber UDP (Programming Guide 4535 645 88011, Kap. 4), ein
   * TCP-Lauscher dort empfaengt nie ein Byte. Der Weg steht vollstaendig im Katalog
   * (transport 'udp'), nur eben nicht mehr in der TCP-Lauschliste. */
  ok('bisherige Ports bleiben erhalten (keine Regression)',
    [4601, 5000, 2575].every((p) => probe.ports.indexOf(p) >= 0), JSON.stringify(probe.ports));
  ok('24105 wird NICHT mehr auf TCP belauscht (Philips sendet UDP)',
    probe.ports.indexOf(24105) < 0, JSON.stringify(probe.ports));

  // 2) End-to-end: Monitor pusht HL7 auf 3502 -> Patient erscheint mit echten Werten
  //    (nur auf 3502 lauschen, damit der Test keine anderen Ports belegt)
  const live = new ProbeAdapter({ id: 'assistent-3502', ports: [GATEWAY_PORT], arpScan: false }, ctx);
  let started = true;
  try { await live.connect(); } catch (e) { started = false; console.log('    (connect warf: ' + e.message + ')'); }
  // EADDRINUSE meldet der TCP-Server ASYNCHRON - erst kurz warten, dann nachsehen.
  await wait(250);
  const belegt = live.belegt.indexOf(GATEWAY_PORT) >= 0;

  if (belegt) {
    // Das ist KEIN Fehler: auf einem PC mit laufender VetStation ist genau das der Normalfall.
    console.log('  ○ Port ' + GATEWAY_PORT + ' ist bereits belegt — vermutlich laeuft VetStation.');
    console.log('    Das ist der ERWARTETE Zustand im Betrieb, kein Defekt.');
    ok('belegter Port wird erkannt und gemeldet (statt 6 Falschfehler)', true);
    ['Assistent lauscht auf ' + GATEWAY_PORT, 'Patient aus 3502-Datenstrom erkannt', 'HF korrekt geparst (88)',
     'SpO2 korrekt geparst (97)', 'EtCO2 korrekt geparst (38)', 'Atemfrequenz korrekt geparst (14)',
     'HL7 auf 3502 als HL7 erkannt'].forEach((n) => uebersprungen(n, 'Port belegt'));
    try { live.dispose(); } catch (_) {}
  } else {
    ok('Assistent lauscht auf ' + GATEWAY_PORT, started);
    await wait(150);
    // Monitor verbindet sich zum PC und sendet (wie "Gateway-Kommunikation -> Ziel PC:3502")
    const sock = net.connect(GATEWAY_PORT, '127.0.0.1', () => {
      try { sock.write(mllp(oru('uMEC12Vet', 'OP-3502', UMEC_OBX))); } catch (_) {}
    });
    sock.on('error', () => {});
    await wait(700);

    const pats = registry.getPatients();
    ok('Patient aus 3502-Datenstrom erkannt', pats.length >= 1, 'patients=' + pats.length);
    const p = pats[0] || {};
    const v = p.vitals || {};
    ok('HF korrekt geparst (88)', v.hr === 88, 'hr=' + v.hr);
    ok('SpO2 korrekt geparst (97)', v.spo2 === 97, 'spo2=' + v.spo2);
    ok('EtCO2 korrekt geparst (38)', v.etco2 === 38, 'etco2=' + v.etco2);
    ok('Atemfrequenz korrekt geparst (14)', v.af === 14, 'af=' + v.af);
    ok('HL7 auf 3502 als HL7 erkannt (nicht "unbekannt")', live.detected[GATEWAY_PORT] === 'hl7',
      'detected=' + JSON.stringify(live.detected));

    try { sock.destroy(); } catch (_) {}
    try { live.dispose(); } catch (_) {}
  }

  console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL' + (skip ? ', ' + skip + ' uebersprungen' : '') + ' ==');
  process.exit(fail ? 1 : 0);
}
run().catch((e) => { console.error('Testfehler:', e); process.exit(1); });
