'use strict';
/*
 * tafel.js — der kleine, gemeinsame Zustand EINES OP-Saals (Stufe 1, ab 1.1.0).
 *
 * WOZU DIESE DATEI DA IST: In einem Praxis-Konto koennen mehrere Stationen stehen (OP 1, OP 2, ...).
 * Damit ein Tierarzt in Saal 1 den Saal 2 sehen kann, ohne dessen vollen Datenstrom zu laden, gibt es
 * einen kleinen Zweig tafel/<sid>/ — Kopfzeile je Saal, eine winzige Kachel je Patient, eine Zeile je
 * Geraet. Der volle Strom (Kurven, Rohwerte, Protokoll) bleibt unter saele/<sid>/ und wird nur fuer
 * den EINEN gefuehrten Saal geladen.
 *
 * WARUM ALLES HIER REIN PUR IST: kein require, kein fs, kein Netz, und NIRGENDS wird die Uhr des
 * Rechners selbst abgefragt — die Zeit ist immer ein Argument. Nur so sind die Alterungsstufen
 * (12 s / 60 s / 12 h) und der Uhrenversatz eines Nachbarn ueberhaupt pruefbar, ohne zwei PCs, ein
 * Firebase-Konto und Warten. tools/tafel-test.js prueft diese Eigenschaft ausdruecklich am Quelltext
 * UND am Verhalten: ohne uebergebene Uhr muss jede Funktion "unbekannt" liefern, nie eine Zahl.
 *
 * WELCHE UHR DER AUFRUFER UEBERGEBEN MUSS (Befund B3): 'jetzt' MUSS die Serverzeit sein — die Uhr
 * des PCs, korrigiert um den Versatz aus der HTTP-Date-Kopfzeile der Datenbank (Reihenfolge 12 des
 * Plans). Grund: die fremden Zeitstempel in dieser Datei sind Serverzeit (sv setzt die Datenbank
 * selbst), die eigenen sind es nicht. Wer hier die unkorrigierte PC-Uhr uebergibt, vergleicht zwei
 * verschiedene Zeitrechnungen — und ein PC mit leerer CMOS-Batterie haelt dann jeden Nachbarn fuer
 * "aus der Zukunft". Was das anrichten DARF und was nicht, steht bei UHR_TOLERANZ_MS.
 *
 * WAS DIESE DATEI MIT installer/firebase-rtdb-rules.json VERBINDET (Befund B1): jeder Satz, den die
 * Funktionen hier bauen, geht in EINEM atomaren Mehrpfad-PATCH raus — zusammen mit den Vitalwerten.
 * Weist die Regel EIN Feld ab, faellt der GANZE Koerper; cloud.js:1090 zaehlt das als Konfigfehler
 * und schaltet nach DREI Treffern die Fern-Uebertragung dauerhaft ab. Deshalb steht unten
 * PFLICHTFELDER: die Felder, die die Regeldatei per hasChildren ERZWINGT. Sie werden immer gesetzt,
 * auch wenn der Wert unbekannt ist — dann mit einem ausdruecklichen Wert fuer "unbekannt", niemals
 * durch Weglassen. tools/tafel-test.js LIEST die Regeldatei und haelt beide Seiten gegeneinander;
 * verschaerft jemand die Regel, wird der Test rot, bevor eine Praxis es merkt.
 *
 * WAS HIER ABSICHTLICH FEHLT (Nachbesserung N1): ein 'probe'-Feld. Der Plan wollte damit eine
 * doppelte Stationskennung beweisen ("ueber 5 s fortlaufend ein fremder probe-Wert"). Das ist
 * unerfuellbar, weil BEIDE Zwillinge jede Sekunde selbst schreiben — jeder Lesevorgang liefert
 * abwechselnd den eigenen und den fremden Wert. Die Kollision haengt ab jetzt am Feld 'instanz'
 * (neu bei jedem Prozessstart), das jeder fremde Schreibvorgang ohnehin mitbringt.
 *
 * ZUR NAMENSGEBUNG: die Feldnamen sind kurz (n, a, g, hr, sp, et, ...), weil jede Kachel jede
 * Sekunde vollstaendig neu geschrieben wird und in JEDER Fern-Ansicht und auf JEDEM Nachbar-Kiosk
 * ankommt. Die Geraetezeile benutzt dagegen genau die Namen aus registry.getDevices() (model, role,
 * status, ip, port, transport, taktMs, werteAnzahl) — dort soll fern DASSELBE stehen wie im
 * Koppel-Dialog vor Ort, und eine zweite Namenswelt waere nur eine weitere Fehlerquelle.
 */

// Fassung des TAFEL-Formats. Bewusst getrennt von cloud.FORMAT_V (das bleibt bei 3 fuer die alte
// flache Ebene, Nachbesserung N11): die alte Web-App liest meta.v und darf davon nichts merken.
const TAFEL_V = 4;

/*
 * Alle Deckel an EINER Stelle, damit der Regelsatz der Datenbank dagegen geprueft werden kann
 * (Nachbesserung N9: die Kappung im Code und die Laengengrenze in der Regel muessen zusammenpassen,
 * sonst lehnt die Datenbank einen ganzen atomaren Schreibvorgang samt Vitalwerten ab).
 *
 * JEDE Zahl hier wird von tools/tafel-test.js gegen die Regeldatei gehalten: eine Grenze in der
 * Regel, die UNTER einer Kappung hier liegt, ist keine Sperre, sondern eine Falle (Befund B8).
 */
const GRENZEN = {
  tafelText: 40,        // jedes Textfeld der Tafel (Name, Tierart, Befundtitel, Geraetemodell)
  adresse: 45,          // ip — EINE Grenze fuer denselben Wert in dvAus UND geraeteSatz (Befund B7).
                        // 45 ist die laengste Textform einer IPv6-Adresse
                        // (ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255); eine reine IPv6-Adresse
                        // ohne IPv4-Ende hat 39. Eine abgeschnittene Adresse ist keine Adresse mehr —
                        // der Tierarzt soll sie ablesen und eintippen koennen, und zwei Geraete an
                        // benachbarten Adressen duerfen in dv nicht zu einem verschmelzen.
  dvEintrag: 96,        // ein dv-Eintrag ist '<deviceId>@<ip>': 40 + 1 + 45 = 86, aufgerundet
  spiegelStation: 120,  // meta/station der alten flachen Ebene (Regel: isString && length <= 120)
  wert: 200,            // allgemeine Kappung fuer JEDEN Snapshotwert (N9)
  schluessel: 200,      // Datenbankschluessel (= cloud.sanitizeKey), Befund B8
  sid: 24,              // Stationskennung (Regel: $station.length <= 24)
  felder: 40,           // Felder je Objekt (N9)
  liste: 80,            // Eintraege je Liste (N9)
  tiefe: 8,             // Verschachtelungstiefe (N9): ein tief verschachteltes Objekt ist eine Last
  kacheln: 12,          // Patientenkacheln je Saal (N17)
  geraete: 16,          // Geraetezeilen je Saal (N13/N17)
  saele: 8,             // gleichzeitig gezeigte Saele (N17)
  dv: 2,                // Eintraege in dv[] — mehr braucht die Doppelempfangserkennung nicht
};

/*
 * PFLICHTFELDER — was die Regeldatei per hasChildren ERZWINGT (Befund B1).
 *
 * Diese Listen sind der Vertrag zwischen dieser Datei und installer/firebase-rtdb-rules.json.
 * Sie sind NICHT geraten, sondern aus der Fassung vom 30.07.2026 abgelesen:
 *   flachMeta   live/<uid>/meta                 hasChildren(['station','ts'])   (Bestand, 1.0.3)
 *   tafelMeta   tafel/<sid>/meta                hasChildren(['sid'])
 *   uebersicht  tafel/<sid>/uebersicht/<key>    KEIN hasChildren
 *   geraete     tafel/<sid>/geraete/<id>        KEIN hasChildren
 *
 * WARUM DAS HIER STEHT UND NICHT NUR IN DER REGEL: ein Feld, das die Regel verlangt und der Code
 * weglaesst, kostet nicht dieses Feld, sondern den ganzen atomaren 1-Hz-Koerper samt Vitalwerten —
 * und nach drei Takten die Fern-Uebertragung. tools/tafel-test.js liest beide Seiten und vergleicht
 * sie Feld fuer Feld; verschaerft jemand die Regel (etwa zurueck auf hasChildren(['ts','altMs'])),
 * wird der Test rot und nennt das Feld.
 *
 * EIN NULL IST KEIN FELD: in der Realtime Database loescht ein null den Schluessel (cloud.js:788-805
 * benutzt genau das zum Loeschen). "Pflichtfeld gesetzt" heisst deshalb: ein Wert ungleich null.
 */
const PFLICHTFELDER = {
  flachMeta: ['station', 'ts'],
  tafelMeta: ['sid'],
  uebersicht: [],
  geraete: [],
};

// Alterungsstufen. Dieselben Schwellen benutzen Web-App, Nachbarstreifen und Station — ein Saal darf
// nicht auf einem Bildschirm "live" und auf dem anderen "offline" heissen.
const STUFE_LIVE_MS = 12000;
const STUFE_OFFLINE_MS = 60000;
const STUFE_WEG_MS = 12 * 3600 * 1000;

// "Frisch" heisst juenger als 60 s. Nachbesserung N5 verlangt dieses Merkmal an JEDER Stelle, an der
// ueber den Zustand entschieden wird — sonst haengt eine Einzelplatzpraxis wegen des liegengebliebenen
// Knotens eines ausgemusterten PCs dauerhaft im Mehrsaal-Modus und verliert in der alten Ansicht
// Kurven und Verlauf.
const FRISCH_MS = 60000;

/*
 * Wie weit darf die Uhr eines Nachbarn VORgehen, ohne dass wir seinen Eintrag fuer Muell halten?
 *
 * DIESE TOLERANZ GILT NUR FUER DIE ANZEIGE (Befund B3). Begruendung fuer die Anzeige: sv wird vom
 * Datenbank-SERVER gesetzt, ein liegengebliebener Knoten kann also nie in der Zukunft liegen —
 * steht ein sv vor unserer Uhr, geht UNSERE Uhr nach. Einen laufenden OP-Saal deswegen als tot zu
 * melden waere der schlimmere Fehler, also bleibt er in der Liste, aber mit "Alter unbekannt"
 * (Nachbesserung N16).
 *
 * FUER JEDE ZAEHLUNG, AN DER EIN BETRIEBSMODUS HAENGT, GILT SIE NICHT. Das Argument oben traegt
 * naemlich nur, solange der gelesene Wert wirklich Serverzeit ist — und der Rueckfall auf 'ts' ist
 * eine Zahl, die der Schreiber frei waehlt (die Regel verlangt fuer ts nichts als eine Laenge).
 * Nachgemessen war beides erreichbar: ein toter Knoten mit sv von vor 4 h galt bei einem PC, der
 * 5 h nachgeht, als frischer OP-Saal (F2-multi statt F2-solo — genau der Schaden, den N5
 * ausschliesst), und ein Knoten OHNE sv mit ts = jetzt + 11 h galt 11 h lang als lebender Saal.
 * Deshalb: istFrisch() = Anzeige (tolerant), istZaehlbar() = Zaehlung (Alter muss BEKANNT sein).
 *
 * EINE EINZIGE ZAEHLUNG IST TROTZDEM NACHSICHTIG GEGEN EINEN WERT VOR DER UHR, und sie steht hier
 * benannt, damit dieser Absatz nicht mehr behauptet als er haelt: das EIGENE qs-Kind in
 * qsEigenFrisch(). Sie benutzt NICHT diese Toleranz, sondern FRISCH_MS, und sie beantwortet auch
 * eine andere Frage — nicht "lebt dieser Saal?", sondern "steht unser eigenes Kind noch da?".
 * Die Begruendung steht vollstaendig dort (Befund A1).
 */
const UHR_TOLERANZ_MS = 12 * 3600 * 1000;

/*
 * Ist eine fremde Fassung 1.0.3 bewiesen, bleibt es so lange dabei — danach ist F2 wieder erreichbar
 * (Nachbesserung N4: der Zustand ist JEDERZEIT wieder betretbar, in beide Richtungen).
 *
 * WARUM 5 MINUTEN UND NICHT 60 SEKUNDEN (Befund B4): der einzige DAUERHAFTE Beweis fuer eine
 * laufende 1.0.3 ist das Verschwinden unseres eigenen qs-Kindes, und das passiert nur im
 * VOLLBILD-Takt der fremden Station: nur ihr Vollbild ersetzt den ganzen meta-Knoten
 * (cloud.js:534-535), der Delta-Weg schreibt Einzelpfade wie meta/sv und laesst qs stehen. Dieser
 * Wert ist damit an cfg.vollbildMs der GEGENSEITE gekoppelt — Werk 30 s, frei konfigurierbar
 * (cloud.js:170). Bei 60 s Stille und einer 1.0.3 mit vollbildMs 90000 entstand ein 90-s-Zyklus:
 * Wipe -> F1 -> nach 60 s F2 -> wir schreiben die flache Ebene -> das naechste Vollbild loescht uns
 * wieder, und der Kopf der ausgelieferten Web-App flackert zwischen zwei Namen. 300 s liegen ueber
 * dem Dreifachen des groessten plausiblen Vollbildabstands.
 *
 * EHRLICH BENANNT: eine 1.0.3 mit vollbildMs > 300000 (5 min, von Hand konfiguriert) bringt den
 * Zyklus zurueck. Weiter hochzudrehen hat auch einen Preis: nach dem Abschalten der letzten 1.0.3
 * bleibt die alte Fern-Ansicht genau so lange ohne frische Zahlen. 5 Minuten sind der Tausch.
 */
const FREMD_STILLE_MS = 300000;

// Sparregel auf die neue Lage (Nachbesserung N6): liegt im eigenen Saal kein Patient, genuegt ein
// Herzschlag alle 5 s.
const RUHE_TAKT_MS = 5000;
const TAFEL_TAKT_MS = 1000;

/*
 * Der Name, den ALLE Stationen in meta/station der alten flachen Ebene schreiben, sobald mehr als ein
 * Saal frisch ist. Diese Zeichenkette darf NIRGENDS ein zweites Mal im Code stehen: schreiben zwei
 * Stationen hier auch nur ein anderes Trennzeichen, flackert der Kopf der ausgelieferten Web-App im
 * Sekundentakt zwischen beiden Fassungen. tools/tafel-test.js ZAEHLT die Vorkommen im Quelltext
 * dieser Datei und in cloud.js.
 */
const SPIEGEL_NAME_MEHRSAAL = 'Praxis — mehrere OP-Saele (Web-Ansicht neu laden)';

/*
 * Der ausdrueckliche Wert fuer "dieser Saal hat keinen Namen" (Befund B1).
 *
 * meta/station ist auf der flachen Ebene PFLICHT und muss eine Zeichenkette sein
 * (hasChildren(['station','ts']) und isString). Ein null dort ist in der Datenbank kein leeres Feld,
 * sondern eine LOESCHUNG — das flache meta verlaere sein Kind 'station', die Regel wiese den ganzen
 * Koerper ab, und die Station schaltete sich nach drei Takten selbst ab. Deshalb gibt es hier einen
 * Ersatzwert statt eines Weglassens.
 *
 * DAS IST DIE LETZTE VERTEIDIGUNGSLINIE, NICHT DER NORMALFALL: cloud.js:156 setzt
 * this.station = cfg.station || 'VetStation', der Aufrufer hat also immer einen Namen. Dieser Wert
 * erscheint nur, wenn er trotzdem keinen uebergibt.
 */
const SPIEGEL_NAME_UNBENANNT = 'OP-Saal (ohne Namen)';

/*
 * Form der Stationskennung (Formatsperre, Befund A1-12: eine Kennung landet in einem Datenbankpfad).
 *
 * WORTGENAU wie bridge/src/stationsid.js:131 — tools/tafel-test.js vergleicht die beiden Quellen
 * zeichengenau. Zwei Fassungen dieser Form waeren schlimmer als eine nachsichtige: die eine Datei
 * baute einen Pfad, den die andere fuer unbrauchbar haelt.
 *
 * ZUM SUFFIXZWEIG (-<4hex>), Befund B10: er wird von NIEMANDEM mehr erzeugt. Die automatische
 * Selbstumbenennung ist verworfen (N2 streicht sidMitSuffix/eindeutigMachen), weil sie ein
 * Narkoseprotokoll in zwei unveraenderliche Teile zerschneidet. Gelesen wird die Form nur noch aus
 * Nachsicht gegen eine data/station-id.json aus einem 1.1.0-Vorabstand — genau so steht es in
 * stationsid.js. Sie hier abzuweisen hiesse: so eine Station bekaeme ueberhaupt keine Tafel mehr
 * (tafelPfade wirft), waehrend stationsid.js sie weiter fuer brauchbar haelt.
 */
const SID_FORM = /^st[0-9a-f]{12}(-[0-9a-f]{4})?$/;

// ---------------------------------------------------------------- Bausteine

/*
 * text(s, max) — ein Textfeld fuer die Tafel.
 *
 * Gekuerzt UND von Sonderzeichen befreit. Der Grund ist nicht Schoenheit: dieser Text wird auf dem
 * Kiosk-PC eines FREMDEN Saals angezeigt. Wer ein Geraet ins Gast-WLAN haengt, kann heute einen
 * Patientennamen frei setzen (die Datenports nehmen jede Gegenstelle an) — und der landet ueber den
 * Nachbarstreifen auf einem Bildschirm, der neben einer laufenden Narkose steht. Deshalb fallen
 * < > & " ' \ ` und alle Steuerzeichen hier weg, zusaetzlich zur Kuerzung.
 */
function text(s, max) {
  if (s == null) return null;
  let t = String(s);
  t = t.replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ');
  t = t.replace(/[<>&"'\\`]/g, '');
  t = t.replace(/\s+/g, ' ').trim();
  if (!t) return null;
  const m = Math.max(1, Math.floor(Number(max) || GRENZEN.tafelText));
  return t.length > m ? t.slice(0, m) : t;
}

/*
 * zahl(x, dez) — eine Zahl fuer die Tafel, oder null.
 *
 * Gerundet, weil die Kachel jede Sekunde vollstaendig neu geschrieben wird: eine Temperatur mit acht
 * Nachkommastellen kostet in jedem Saal, in jeder Ansicht und in jedem Monat echte Bytes und sagt
 * nichts. NaN und Unendlich werden null — sonst schreibt JSON.stringify sie als null in ein Feld,
 * fuer das die Regel eine Zahl verlangt, und der ganze atomare Schreibvorgang faellt.
 */
function zahl(x, dez) {
  if (x == null || x === '') return null;
  const n = typeof x === 'number' ? x : Number(x);
  if (!Number.isFinite(n)) return null;
  const d = dez == null ? 1 : Math.max(0, Math.floor(dez));
  const p = Math.pow(10, d);
  return Math.round(n * p) / p;
}

// "nicht belegt" — null, undefined und der leere String gelten gleich. Vorsicht: 0 und false sind
// BELEGT (FiCO2 0 ist ein Messwert, kurven false eine Zusage).
function leer(x) { return x == null || x === ''; }

// Ganze, nicht negative Zahl (Zaehler wie count, al, dev, werteAnzahl).
function ganz(x) {
  const n = zahl(x, 0);
  if (n == null) return null;
  return n < 0 ? 0 : n;
}

/*
 * schluessel(s, max) — ein Datenbank-Schluessel.
 *
 * Dieselbe Regel wie cloud.sanitizeKey, hier ABSICHTLICH ein zweites Mal: cloud.js laedt tafel.js,
 * nicht umgekehrt — ein require in die andere Richtung waere ein Ringschluss. Ohne diese Kappung
 * koennte eine Geraete-ID mit '/' oder '..' aus dem eigenen Saalzweig herausschreiben.
 *
 * Der Deckel ist ein ARGUMENT mit Vorgabe aus GRENZEN (Befund B8), damit er neben allen anderen
 * Kappungen steht und der Test ihn gegen die Laengengrenze der Regeldatei halten kann. Er war
 * frueher als 200 in die Zeile geschrieben — unsichtbar fuer jede Pruefung.
 */
function schluessel(s, max) {
  const m = Math.max(1, Math.floor(Number(max) || GRENZEN.schluessel));
  return String(s == null ? '' : s).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, m) || '_';
}

// Prueft die Stationskennung, bevor sie in einen Pfad kommt.
function pruefeSid(sid) {
  const s = String(sid == null ? '' : sid);
  return s.length <= GRENZEN.sid && SID_FORM.test(s);
}

/*
 * kappe(wert) — die gemeinsame Kappung fuer JEDEN Snapshotwert (Nachbesserung N9).
 *
 * Unterschied zu text(): hier wird NICHT gefiltert, nur begrenzt. Der volle Saalstrom enthaelt
 * Freitexte des Geraets (Alarmmeldungen, Akte), und wer daraus Zeichen entfernt, verfaelscht ein
 * Dokument. Begrenzt werden muss er trotzdem: saele/<sid>/patients/<key> ist der Zweig mit der
 * groessten Datenmenge, den jede Web-Ansicht und jede andere Station bei jedem Delta erneut laedt.
 * Die Schluessel werden sortiert, damit bei einem gekappten Objekt nicht die Einfuegereihenfolge
 * entscheidet, WELCHE 40 Felder ueberleben — sonst waere das Ergebnis von Lauf zu Lauf verschieden.
 */
function kappe(wert, tiefe) {
  const t = tiefe == null ? 0 : tiefe;
  if (wert == null) return null;
  const typ = typeof wert;
  if (typ === 'number') return Number.isFinite(wert) ? wert : null;
  if (typ === 'boolean') return wert;
  if (typ === 'string') return wert.length > GRENZEN.wert ? wert.slice(0, GRENZEN.wert) : wert;
  if (typ !== 'object') return null;                 // Funktionen/Symbole gehoeren nie in den Baum
  if (t >= GRENZEN.tiefe) return null;
  if (Array.isArray(wert)) {
    const out = [];
    for (let i = 0; i < wert.length && out.length < GRENZEN.liste; i++) out.push(kappe(wert[i], t + 1));
    return out;
  }
  const out = {};
  const namen = Object.keys(wert).sort();
  for (let i = 0; i < namen.length && i < GRENZEN.felder; i++) {
    const k = namen[i];
    out[k.length > GRENZEN.wert ? k.slice(0, GRENZEN.wert) : k] = kappe(wert[k], t + 1);
  }
  return out;
}

/*
 * istServerZeitstempel(x) — ist das der Platzhalter {".sv":"timestamp"}?
 *
 * Die Regel fuer tafel/<sid>/meta.sv lautet
 *     newData.isNumber() && newData.val() <= now && newData.val() > now - 60000
 * und ist neben 'sid' die EINZIGE Stelle in den neuen Zweigen, an der eine Regel etwas ABWEIST statt
 * nur zu begrenzen. Eine selbst gerechnete Zahl faellt dort durch und nimmt den ganzen atomaren
 * 1-Hz-Koerper samt Vitalwerten mit. Deshalb wird sv unten nur durchgetragen, wenn es wirklich der
 * Platzhalter ist.
 */
function istServerZeitstempel(x) {
  return !!x && typeof x === 'object' && !Array.isArray(x) && x['.sv'] === 'timestamp';
}

// ---------------------------------------------------------------- Alter

/*
 * alterMs(ts, jetzt) — Alter als DAUER, oder null fuer "Alter unbekannt".
 *
 * NIEMALS 0 BEI NEGATIVEM ALTER (Nachbesserung N16). Ein Saal, dessen Zeitstempel vor unserer Uhr
 * liegt, waere sonst dauerhaft "brandaktuell": 0 ms alt, gruen, mit seinen letzten Vitalwerten — und
 * genau das darf ein toter OP-Saal nicht koennen. 0 selbst ist erlaubt und heisst wirklich
 * "in dieser Millisekunde".
 */
function alterMs(ts, jetzt) {
  const t = Number(ts);
  const n = Number(jetzt);
  if (!Number.isFinite(t) || !Number.isFinite(n) || t <= 0) return null;
  const d = n - t;
  return d < 0 ? null : d;
}

/*
 * altersStufe(ms) — der Zustand, den die Anzeige daraus macht.
 *   'live'      < 12 s   Zahlen gelten
 *   'alt'      12-60 s   "keine neuen Daten (Xs)", Zahlen bleiben stehen
 *   'offline'  > 60 s    "offline seit X min", die Zahlen werden ERSETZT
 *   'weg'      > 12 h    die Karte verschwindet
 *   'unbekannt'          Alter nicht berechenbar (fremde Uhr laeuft vor, oder kein Zeitstempel)
 */
function altersStufe(ms) {
  if (ms == null) return 'unbekannt';
  const n = Number(ms);
  if (!Number.isFinite(n) || n < 0) return 'unbekannt';
  if (n < STUFE_LIVE_MS) return 'live';
  if (n < STUFE_OFFLINE_MS) return 'alt';
  if (n < STUFE_WEG_MS) return 'offline';
  return 'weg';
}

// Der Kopf eines Tafeleintrags: entweder liegt er unter 'meta', oder der Eintrag IST der Kopf.
function kopfAus(eintrag) {
  const e = eintrag || {};
  return (e.meta && typeof e.meta === 'object') ? e.meta : e;
}

// Zeitstempel eines Tafeleintrags fuer die ANZEIGE: die SERVERZEIT sv gilt, die lokale Uhr ts ist
// nur Rueckfall. Fuer eine ZAEHLUNG ist dieser Rueckfall nicht zulaessig — siehe svServer().
function svAus(eintrag) {
  const m = kopfAus(eintrag);
  if (m.sv != null && typeof m.sv !== 'object') return m.sv;
  return m.ts != null ? m.ts : null;
}

/*
 * svServer(eintrag) — NUR die vom Datenbankserver gesetzte Zeit, ohne Rueckfall auf ts.
 *
 * Fuer jede Zaehlung, an der ein Betriebsmodus haengt, ist das der einzig zulaessige Zeitstempel:
 * sv steht unter der Frischeregel der Datenbank (Fenster now-60000 .. now), ts dagegen ist eine
 * Zahl, die der Schreiber frei waehlt. Nachgemessen: ein Knoten ohne sv mit ts = jetzt + 11 h galt
 * ueber elf Stunden als lebender OP-Saal (Befund B3).
 */
function svServer(eintrag) {
  const m = kopfAus(eintrag);
  return (m.sv != null && typeof m.sv !== 'object') ? m.sv : null;
}

/*
 * istFrisch(eintrag, jetzt) — ANZEIGE: hat dieser Saal in den letzten 60 s geschrieben?
 *
 * Sonderfall "Alter unbekannt": siehe UHR_TOLERANZ_MS. Ein Eintrag, dessen Zeitstempel VOR unserer
 * Uhr liegt, gilt hier weiter als frisch (unsere Uhr geht nach, nicht sein Saal ist tot) — aber nur
 * innerhalb von 12 h, damit ein voelliger Uhrenunsinn nicht ewig als lebender Saal gilt.
 *
 * NICHT FUER ZAEHLUNGEN BENUTZEN, an denen ein Betriebsmodus haengt — dafuer gibt es istZaehlbar().
 * Ausnahme mit Begruendung: in modusAus() entscheidet istFrisch(), ob auf der FLACHEN Ebene gerade
 * ein Fremder schreibt. Dort ist die Nachsicht die sichere Richtung: sie kann nur dazu fuehren, dass
 * wir WENIGER schreiben (F1 schreibt gar nichts flach), nie dazu, dass wir einer laufenden 1.0.3
 * ihre Ebene ueberschreiben.
 */
function istFrisch(eintrag, jetzt) {
  const sv = svAus(eintrag);
  const a = alterMs(sv, jetzt);
  if (a != null) return a < FRISCH_MS;
  const vor = Number(sv) - Number(jetzt);
  return Number.isFinite(vor) && vor >= 0 && vor <= UHR_TOLERANZ_MS;
}

/*
 * istZaehlbar(eintrag, jetzt) — ZAEHLUNG: darf dieser Saal einen Betriebsmodus mitentscheiden?
 *
 * Strenger als istZeigbar(), und zwar in genau zwei Punkten (Befund B3):
 *   1. der Zeitstempel muss die SERVERZEIT sv sein (kein Rueckfall auf das frei waehlbare ts),
 *   2. das Alter muss BEKANNT sein: >= 0 und < 60 s. Ein Eintrag "aus der Zukunft" zaehlt NICHT.
 * Punkt 2 ist der Kern: eine vorlaufende fremde Uhr (oder eine nachgehende eigene) darf die ANZEIGE
 * beeinflussen, aber niemals die Zaehlung, an der F2-solo/F2-multi haengt. Nachgemessen war sonst
 * eine Einzelplatzpraxis mit 5 h nachgehendem PC dauerhaft im Mehrsaal-Modus und verlor in der alten
 * Fern-Ansicht Kurven und Verlauf — genau der Schaden, den N5 ausschliesst.
 *
 * Das instanz-Feld wird wie bei istZeigbar() verlangt, damit Zaehlung und Anzeige nicht aus
 * verschiedenen Gruenden verschiedene Saele fuehren.
 *
 * WAS DAS KOSTET, ausdruecklich benannt: geht die EIGENE Uhr weit nach, sehen wir JEDEN Nachbarn
 * "in der Zukunft" — auch einen echten. Diese Station haelt sich dann fuer allein (F2-solo) und
 * spiegelt Kurven und Protokoll unter ihrem eigenen Saalnamen, waehrend der Nachbar mit richtiger
 * Uhr F2-multi rechnet; der Kopf der alten Web-App wechselt zwischen beiden Fassungen. Ein toter
 * Knoten und ein lebender Nachbar sehen aus DIESER Sicht gleich aus (beide "aus der Zukunft"), eine
 * Regel kann sie in einem einzelnen Lesevorgang also nicht trennen. Unterscheidbar waeren sie nur
 * ueber MEHRERE Lesevorgaenge (ein lebender Nachbar bewegt sein sv, ein toter nicht) — das braucht
 * Gedaechtnis im Aufrufer und ist hier bewusst NICHT gebaut. Der Ausweg ist die richtige Uhr: der
 * Aufrufer MUSS die Serverzeit uebergeben (siehe Kopfkommentar), dann tritt der Fall nicht ein.
 */
function istZaehlbar(eintrag, jetzt) {
  if (!kopfAus(eintrag).instanz) return false;
  const a = alterMs(svServer(eintrag), jetzt);
  return a != null && a < FRISCH_MS;
}

/*
 * istZeigbar(eintrag, jetzt) — ANZEIGE: frisch UND mit instanz-Feld.
 *
 * Das instanz-Feld ist neu bei jedem Prozessstart und der Ersatz fuer das gestrichene probe-Feld
 * (N1). Ein Tafelknoten ohne instanz kann nur ein Rest oder ein Fremdschreibvorgang sein; der Leser
 * blendet ihn aus.
 */
function istZeigbar(eintrag, jetzt) {
  if (!kopfAus(eintrag).instanz) return false;
  return istFrisch(eintrag, jetzt);
}

// ---------------------------------------------------------------- Hilfsformen

/*
 * frischeSaele(tafelAbbildung, jetzt, wahl) — alle Saele, STABIL sortiert.
 *
 * NUR DIE ABBILDUNG {sid: satz} WIRD ANGENOMMEN, eine Liste NICHT (Befund B6). Grund: die
 * Sicherheitsaussage dieser Funktion lautet "der SCHLUESSEL gewinnt ueber das sid-Feld" — und nur
 * die Abbildung TRAEGT einen Schluessel. Nachgemessen an der frueheren Listenform: ein Nachbarknoten
 * mit einem sid-Feld, das nicht zu seinem Platz passt (Kennung von Hand geaendert, alter Knoten
 * liegt noch da, kopierte data/station-id.json), wurde von modusAus() per 'das bin ich selbst'
 * weggeworfen — zwei laufende Saele ergaben saele=1 und F2-solo, und in F2-solo spiegelt die Station
 * Kurven UND Protokoll unter ihrem eigenen Saalnamen. Das ist der Weg, den N8 als toedlich
 * beschreibt (Messwerte des Tiers aus Saal 1 unter dem Namen des Tiers in Saal 2).
 * Wer eine Liste hat (etwa aus fremdstore.js), baut daraus zuerst eine Abbildung nach dem Schluessel,
 * unter dem der Eintrag wirklich lag.
 *
 * wahl.anzeige === true  -> tolerante Frische (Nachbarstreifen, Saalkarten): ein Eintrag mit
 *                           unbekanntem Alter bleibt drin und wird mit stufe 'unbekannt' geliefert.
 * ohne wahl (Vorgabe)    -> strenge Zaehlung: nur Eintraege mit bekanntem Alter < 60 s. Die Vorgabe
 *                           ist absichtlich die STRENGE: wer zaehlt, ohne nachzudenken, soll die
 *                           sichere Fassung bekommen; die Nachsicht muss man ausdruecklich wollen.
 *
 * Sortiert nach Saalname, bei gleichem Namen nach sid (N17: "Saele stabil nach Saalname sortieren,
 * die ersten 8 zeigen"). Die Sortierung ist der eine Grund, warum saalName() und modusAus() aus
 * derselben Eingabe DASSELBE errechnen, egal in welcher Reihenfolge die Datenbank die Kinder
 * liefert; der andere ist, dass beide ueber dieselbe saalListe() gehen (Befund A3).
 */
function frischeSaele(tafelAbbildung, jetzt, wahl) {
  if (Array.isArray(tafelAbbildung)) {
    throw new Error('frischeSaele: nur die Abbildung {sid: satz} wird angenommen — eine Liste traegt '
      + 'keinen Schluessel, und nur der Schluessel beweist, zu welchem Saal ein Eintrag gehoert');
  }
  const anzeige = !!(wahl && wahl.anzeige);
  const raus = [];
  if (tafelAbbildung && typeof tafelAbbildung === 'object') {
    for (const k of Object.keys(tafelAbbildung)) {
      const e = tafelAbbildung[k];
      if (!e || typeof e !== 'object') continue;
      // Der SCHLUESSEL gewinnt ueber das Feld: dort, wo der Eintrag liegt, ist er auch zu Hause. Die
      // Regel erzwingt sid === $station, ein abweichendes Feld kann also nur ein Rest oder ein
      // Versuch sein, sich als ein anderer Saal auszugeben.
      const satz = Object.assign({}, kopfAus(e), { sid: String(k) });
      if (!(anzeige ? istZeigbar(satz, jetzt) : istZaehlbar(satz, jetzt))) continue;
      const alt = alterMs(anzeige ? svAus(satz) : svServer(satz), jetzt);
      raus.push({
        sid: satz.sid,
        name: text(satz.name, GRENZEN.spiegelStation),
        altMs: alt,
        stufe: altersStufe(alt),
        satz: satz,
      });
    }
  }
  return sortiereSaele(raus);
}

// Stabile Reihenfolge fuer JEDE Saalliste: erst Name, dann sid. Eine zweite Sortierregel an einer
// zweiten Stelle waere genau der Weg, auf dem zwei Stationen aus derselben Eingabe verschiedene
// Spiegelnamen errechnen.
function sortiereSaele(liste) {
  return liste.sort((a, b) => {
    const an = a.name || '', bn = b.name || '';
    if (an < bn) return -1;
    if (an > bn) return 1;
    if (a.sid < b.sid) return -1;
    if (a.sid > b.sid) return 1;
    return 0;
  });
}

/*
 * auswahl(quelle, max) — welche Schluessel eines Kachel-/Geraetebestands wirklich geschrieben werden.
 *
 * DIESE FUNKTION IST DER DECKEL, UND ES GIBT NUR SIE (Befund B5). Vorher rechnete tafelSatz() den
 * Saalkopf ueber ALLE uebergebenen Kacheln, waehrend tafelPfade() nur die ersten 12 schrieb.
 * Nachgemessen mit 14 Kacheln: der Kopf meldete Prioritaet 5 und drei Alarme aus einer Kachel, die
 * gar nicht geschrieben wurde — der Nachbarstreifen zeigte einen Alarm, den es in keiner sichtbaren
 * Kachel gab. Seitdem benutzen BEIDE Funktionen diese eine Auswahl.
 *
 * ZUERST sortieren, DANN falten: fallen zwei Rohschluessel nach der Kappung auf denselben
 * Datenbankschluessel (etwa 'a/b' und 'a:b' -> 'a_b'), gewinnt immer derselbe. Wuerde in
 * Einfuegereihenfolge gefaltet, haenge das Ergebnis daran, in welcher Reihenfolge die Registry ihre
 * Geraete gerade gemeldet hat — und die Kachel wechselte im Sekundentakt ihren Inhalt.
 *
 * Eine LISTE wird nicht angenommen (Ergebnis: leer). Auch das ist in beiden Funktionen gleich, damit
 * Kopf und Pfade nie ueber verschiedene Bestaende reden.
 */
function auswahl(quelle, max) {
  const rein = {};
  if (quelle && typeof quelle === 'object' && !Array.isArray(quelle)) {
    for (const k of Object.keys(quelle).sort()) {
      const s = schluessel(k);
      if (!Object.prototype.hasOwnProperty.call(rein, s)) rein[s] = quelle[k];
    }
  }
  const namen = Object.keys(rein).sort();
  const genommen = namen.slice(0, max);
  return { namen: genommen, werte: rein, ueber: namen.length - genommen.length };
}

// ---------------------------------------------------------------- Kachel

/*
 * befundAus(x, p) — Prioritaet und Befundtitel aus dem, was der Aufrufer gerade zur Hand hat.
 *
 * cloud.js hat fuer dieselbe Sache ZWEI Formen: _assess(p) liefert {pri, top:{title,...}},
 * befundTitel(p) nur die Zeichenkette. Beide werden hier angenommen, damit cloud.js nichts umbauen
 * muss, um eine Kachel zu bauen — eine zweite Umformung an der Aufrufstelle waere genau die Stelle,
 * an der irgendwann das ganze Befundobjekt (mit fix, incident, sev) in einer 1-Hz-Kachel landet.
 */
function befundAus(x, p) {
  const pat = p || {};
  let pri = null;
  let top = null;
  if (typeof x === 'string') {
    top = x;
  } else if (x && typeof x === 'object') {
    pri = zahl(x.pri != null ? x.pri : x.priority, 1);
    const t = x.top;
    if (t && typeof t === 'object') top = t.title != null ? t.title : null;
    else if (typeof t === 'string') top = t;
  }
  if (pri == null) pri = zahl(pat.pri, 1);
  if (top == null && typeof pat.top === 'string') top = pat.top;
  return { pri: pri, top: top };
}

/*
 * dvAus(devices) — hoechstens zwei '<deviceId>@<ip>' fuer die ANZEIGE in der Kachel.
 *
 * WOZU (Nachbesserung N13, Befund B7): dv ist die kleine Anzeigehilfe, mehr nicht. Die
 * Doppelempfangserkennung ("dasselbe Geraet sendet an ZWEI Stationen") laeuft ausdruecklich NICHT
 * ueber dieses Feld, sondern ueber die vollstaendige Geraeteliste tafel/<sid>/geraete — die liefert
 * diese Datei mit geraeteSatz() selbst. Der Grund steht in der Kappung: dv fasst zwei Werte in EINE
 * Zeichenkette, und eine gekuerzte Zeichenkette macht aus zwei Geraeten eines. Nachgemessen war das
 * mit der frueheren Grenze erreichbar: zwei verschiedene IPv6-Adressen ergaben denselben Eintrag
 * 'monitor@2001:0db8:85a3:0000:0000', und die Erkennung meldete einen Aufbaufehler, den es nicht gab.
 * Deshalb gilt fuer die Adresse hier DIESELBE Grenze wie in geraeteSatz() (GRENZEN.adresse), und der
 * ganze Eintrag darf GRENZEN.dvEintrag lang sein.
 *
 * Sortiert, weil mergePatients die Geraeteliste nach Sendezeit ordnet: unsortiert kaeme die Kachel
 * jede Sekunde mit getauschter Reihenfolge und derselben Aussage an.
 */
function dvAus(devices) {
  const liste = Array.isArray(devices) ? devices : [];
  const namen = [];
  liste.forEach((d) => {
    if (!d) return;
    const id = text(d.deviceId, GRENZEN.tafelText);
    if (!id) return;
    const ip = text(d.ip, GRENZEN.adresse);
    namen.push(ip ? (id + '@' + ip) : id);
  });
  namen.sort();
  const out = [];
  namen.forEach((n) => {
    if (out.length >= GRENZEN.dv) return;
    if (out.indexOf(n) < 0) out.push(n.length > GRENZEN.dvEintrag ? n.slice(0, GRENZEN.dvEintrag) : n);
  });
  return out;
}

/*
 * uebersichtSatz(patient, befundTitel, jetzt) — EINE Patientenkachel, so klein wie moeglich.
 *
 * LEERE FELDER FEHLEN GANZ. Auf der alten flachen Ebene muss cloud.js jedes erwartete Feld auch als
 * null schreiben, weil dort einzelne FELDER als Delta gehen und die alte Ansicht sonst zwischen
 * "kein Wert" und "Feld fehlt" blinkt. Hier ist es umgekehrt richtig: die Kachel geht als EIN
 * vollstaendiges Objekt auf EINEN Pfad (tafel/<sid>/uebersicht/<key>) und wird dabei jedes Mal ganz
 * ersetzt. Ein fehlendes Feld ist deshalb eindeutig "kein Wert", und es kann kein alter Wert
 * stehenbleiben. Ersparnis: ein Saal mit nur einem Monitor hat 8 der 13 Messfelder leer — das sind
 * rund 100 Byte je Kachel, jede Sekunde, in jeder offenen Ansicht.
 *
 * DAS DARF NUR SO BLEIBEN, SOLANGE DIE REGEL FUER tafel/<sid>/uebersicht/<key> KEIN hasChildren
 * FUEHRT (Befund B1). Sie tut es in der Fassung vom 30.07.2026 nicht — PFLICHTFELDER.uebersicht ist
 * leer, und tools/tafel-test.js liest das aus der Regeldatei und vergleicht. Kaeme dort je wieder
 * ein hasChildren(['ts','altMs']) hinein, waere ein weggelassenes Feld kein gespartes Byte mehr,
 * sondern die Ablehnung des ganzen atomaren 1-Hz-Koerpers samt Vitalwerten.
 *
 * al und dev stehen dagegen IMMER da: 0 ist bei ihnen eine Aussage ("kein Alarm", "kein Geraet"),
 * und eine Zahl, die immer vorhanden ist, kann der Leser nie mit einem verlorenen Feld verwechseln.
 * ts und altMs stehen NUR da, wenn sie bekannt sind — ein unbekanntes Alter muss als unbekannt
 * ankommen (N16) und nicht als 0, und ein null waere in der Datenbank ohnehin kein Feld.
 *
 * altMs IST EINE DAUER, kein Zeitpunkt. Der Leser rechnet altMs + (Serverzeit - sv) und ist damit
 * gegen jeden Uhrenversatz immun; ein Zeitstempel der fremden Uhr waere es nicht.
 */
function uebersichtSatz(patient, befundTitel, jetzt) {
  const p = patient || {};
  const v = (p.vitals && typeof p.vitals === 'object') ? p.vitals : {};
  const b = befundAus(befundTitel, p);
  const satz = {};
  const setzt = (feld, wert) => { if (wert != null) satz[feld] = wert; };

  setzt('pid', text(p.patientId, GRENZEN.tafelText));
  setzt('n', text(p.patientName, GRENZEN.tafelText));
  setzt('a', text(p.species, 24));
  setzt('g', zahl(p.weightKg, 1));

  setzt('hr', zahl(v.hr, 0));
  setzt('sp', zahl(v.spo2, 0));
  setzt('et', zahl(v.etco2, 1));
  setzt('fi', zahl(v.fico2, 1));
  setzt('af', zahl(v.af, 0));
  setzt('sys', zahl(v.sys, 0));
  setzt('dia', zahl(v.dia, 0));
  setzt('map', zahl(v.map, 0));
  setzt('t', zahl(v.temp, 1));
  setzt('rh', text(v.ekgRhythm, 24));

  setzt('pri', b.pri);
  setzt('top', text(b.top, GRENZEN.tafelText));

  satz.al = ganz(Array.isArray(p.alarms) ? p.alarms.length : 0) || 0;
  satz.dev = ganz(Array.isArray(p.devices) ? p.devices.length : 0) || 0;
  const ts = zahl(p.ts, 0);
  setzt('ts', ts);
  setzt('altMs', alterMs(ts, jetzt));

  const dv = dvAus(p.devices);
  if (dv.length) satz.dv = dv;
  return satz;
}

/*
 * keysJeGeraet(patients) — Abbildung deviceId -> patientKey.
 *
 * Sie wird aus dem ERGEBNIS von matching.mergePatients() gelesen (jeder Patient fuehrt dort seine
 * beteiligten Geraete mit), nicht neu gerechnet. Damit kann die Geraetezeile nie eine andere
 * Zuordnung behaupten als die Kachel darueber — und zwar auch dann nicht, wenn sich die Regeln in
 * matching.js einmal aendern.
 */
function keysJeGeraet(patients) {
  const out = {};
  (Array.isArray(patients) ? patients : []).forEach((p) => {
    if (!p || leer(p.patientKey)) return;
    (Array.isArray(p.devices) ? p.devices : []).forEach((d) => {
      if (d && !leer(d.deviceId) && out[d.deviceId] == null) out[d.deviceId] = p.patientKey;
    });
  });
  return out;
}

/*
 * geraeteSatz(geraet, jetzt, keyJeGeraet) — EINE Geraetezeile (Nachbesserung N13).
 *
 * WARUM ES DIESE ZEILE UEBERHAUPT GIBT: Der Auftrag des Nutzers lautet woertlich "alle Geraete, die
 * in diesem Konto angeschlossen sind, sehen koennen". Eine Patientenliste beantwortet das NICHT.
 * registry.getPatients() filtert mit _status(...) !== 'offline' jedes Geraet heraus, das seit 90 s
 * stumm ist — ein abgerissener Kapnograph senkt in der Kachel nur dev von 2 auf 1 und verschwindet
 * lautlos, ein eingeschalteter Monitor ohne Patienten faellt ganz heraus. Der Tierarzt in Saal 1
 * koennte dann nicht unterscheiden zwischen "in Saal 2 haengt kein Kapnograph" und "in Saal 2 ist
 * der Kapnograph abgerissen". Genau das ist der haeufigste Praxisfehler, und er war fern nicht
 * diagnostizierbar. Diese Zeile kommt deshalb aus registry.getDevices(), das auch offline-Geraete
 * fuehrt. Sie ist zugleich die Grundlage der Doppelempfangserkennung (N13) — nicht das dv-Feld der
 * Kachel, das zwei Werte in eine gekuerzte Zeichenkette presst.
 *
 * status kommt UNVERAENDERT aus der Registry und wird hier nicht neu berechnet: eine zweite
 * Statuslogik ist der Weg, auf dem lokale und ferne Ansicht auseinanderlaufen. Das ALTER dagegen
 * wird hier aus lastTs und der uebergebenen Uhr gerechnet — seitMs ist nur Rueckfall, weil es in
 * getDevices() gegen die dortige Uhr entstanden ist und damit nicht pruefbar waere.
 *
 * patientKey wird NICHT selbst abgeleitet: die Zuordnung ist registry.manual[deviceId] ||
 * model.patientKey(frame), und eine zweite Zuordnungslogik neben matching.js ist genau der Fehler,
 * den die Web-App mit handleSnapshot schon einmal hatte. Nachgemessen an den echten Formen:
 * getDevices() fuehrt patientId und manualKey, aber KEIN patientKey — ohne die Abbildung aus
 * keysJeGeraet() haette die Zeile also keine Verbindung zu ihrer Kachel, und die Frage "an welchem
 * Patienten haengt dieser Kapnograph?" waere fern unbeantwortbar. Deshalb der dritte Parameter.
 */
function geraeteSatz(geraet, jetzt, keyJeGeraet) {
  const g = geraet || {};
  const satz = {};
  const setzt = (feld, wert) => { if (wert != null) satz[feld] = wert; };

  setzt('model', text(g.model, GRENZEN.tafelText));
  setzt('role', text(g.role, 24));
  setzt('status', text(g.status, 16));
  // Dieselbe Grenze wie in dvAus() — eine zweite Grenze fuer denselben Wert in derselben Datei war
  // Befund B7. Warum 45 und nicht 40, steht bei GRENZEN.adresse.
  setzt('ip', text(g.ip, GRENZEN.adresse));
  setzt('port', ganz(g.port));
  setzt('transport', text(g.transport, 24));
  setzt('taktMs', ganz(g.taktMs));
  setzt('werteAnzahl', ganz(g.werteAnzahl));
  const abb = (keyJeGeraet && typeof keyJeGeraet === 'object') ? keyJeGeraet : null;
  const ausAbb = (abb && g.deviceId != null) ? abb[g.deviceId] : null;
  const key = leer(g.patientKey) ? (leer(ausAbb) ? (leer(g.manualKey) ? null : g.manualKey) : ausAbb) : g.patientKey;
  if (key != null) satz.patientKey = schluessel(key);

  let alt = alterMs(g.lastTs, jetzt);
  if (alt == null && g.lastTs == null) {
    // Rueckfall: seitMs ist schon eine Dauer. Ein negativer Wert bleibt "unbekannt" (N16).
    const s = zahl(g.seitMs, 0);
    if (s != null && s >= 0) alt = s;
  }
  // Wie in der Kachel: ein unbekanntes Alter FEHLT, statt als null geschrieben zu werden (ein null
  // ist in der Datenbank kein Feld). Die Regel fuehrt fuer diese Zeile kein Pflichtfeld —
  // PFLICHTFELDER.geraete ist leer, und der Test haelt das gegen die Regeldatei.
  setzt('altMs', alt);
  return satz;
}

// ---------------------------------------------------------------- Saalkopf

/*
 * tafelSatz(...) — der kleine Zustand EINES Saals: tafel/<sid>/meta.
 *
 * count, pri, al und altMs werden aus den UEBERGEBENEN Kacheln und Geraetezeilen abgeleitet, und
 * zwar aus GENAU DER AUSWAHL, die tafelPfade() auch schreibt (gemeinsame Funktion auswahl(), Befund
 * B5). Grund: der Kopf und die Kacheln gehen im SELBEN atomaren Schreibvorgang raus; rechnete der
 * Kopf ueber einen anderen Bestand, stuende dort "Prioritaet 5, drei Alarme", waehrend darunter
 * zwoelf Kacheln liegen, von denen keine das traegt — der Nachbarstreifen zeigte einen Alarm, den es
 * nirgends gibt. Einen fertigen count vom Aufrufer anzunehmen (frueher a.count) war genau diese
 * zweite Rechnung und ist deshalb entfallen.
 *
 * count IST DIE ZAHL DER GESCHRIEBENEN KACHELN, nicht die Zahl der Patienten im Saal. Das gilt auch
 * im Sperrfall nurMeta, in dem gar keine Kachel geschrieben wird — dort setzt tafelPfade() den Kopf
 * auf die Wahrheit zurueck, weil nur DIESE Funktion den Sperrfall kennt (Befund A6). Was der Deckel
 * abgeschnitten hat, steht daneben (N17: der Deckel muss sichtbar sein, nicht lautlos passieren):
 * 'ueber' zaehlt die nicht geschriebenen KACHELN, 'ueberG' die nicht geschriebenen GERAETEZEILEN.
 * Zwei Zahlen, weil zwei Deckel — eine Summe koennte niemand mehr auseinandernehmen. Die Gesamtzahl
 * der Patienten ist count + ueber; die Zeile "X weitere werden nicht angezeigt" liest die Web-App
 * aus 'ueber'.
 *
 * altMs ist das Alter der JUENGSTEN Geraetedaten des Saals (kleinstes Alter). Ein Saal mit einem
 * lebenden Monitor und einem abgerissenen Kapnographen ist lebendig — der Kapnograph faellt in
 * SEINER Zeile auf, nicht im Kopf des Saals.
 *
 * bv (Bauversion) und taktMs werden NICHT geraten: sie kommen aus version.js bzw. aus der
 * Schreibkonfiguration. Ein hier hart eingetragenes '1.1.0' stuende nach dem naechsten Versionssprung
 * falsch in jeder Fern-Ansicht (N11 setzt die Version an vier Stellen gleichzeitig).
 *
 * PFLICHTFELD DER REGEL: 'sid'. Es wird immer gesetzt — auch wenn der Aufrufer nichts uebergibt,
 * damit das Feld nicht FEHLT. Ob die Kennung brauchbar ist, entscheidet tafelPfade(): dort faellt
 * eine unbrauchbare Kennung laut auf, statt in einem Pfad zu landen.
 */
function tafelSatz(angabe) {
  const a = angabe || {};
  const jetzt = zahl(a.jetzt, 0);
  const u = auswahl(a.uebersicht, GRENZEN.kacheln);
  const g = auswahl(a.geraete, GRENZEN.geraete);
  const kacheln = u.namen.map((k) => u.werte[k]).filter((x) => x && typeof x === 'object');
  const zeilen = g.namen.map((k) => g.werte[k]).filter((x) => x && typeof x === 'object');

  let pri = null;
  let al = 0;
  let jung = null;
  kacheln.forEach((k) => {
    const p = zahl(k.pri, 1);
    if (p != null && (pri == null || p > pri)) pri = p;
    const n = ganz(k.al);
    if (n != null) al += n;
  });
  // Zuerst die Geraetezeilen fragen: sie kennen auch ein Geraet, das aus der Patientenliste schon
  // herausgefallen ist. Nur wenn es gar keine gibt, entscheiden die Kacheln.
  const quelle = zeilen.length ? zeilen : kacheln;
  quelle.forEach((z) => {
    const s = zahl(z.altMs, 0);
    if (s != null && s >= 0 && (jung == null || s < jung)) jung = s;
  });

  const satz = {};
  const setzt = (feld, wert) => { if (wert != null) satz[feld] = wert; };

  satz.sid = String(a.sid == null ? '' : a.sid);
  setzt('name', text(a.name, GRENZEN.tafelText));
  const v = ganz(a.v);
  satz.v = v != null ? v : TAFEL_V;
  setzt('bv', text(a.bv, 24));
  // instanz: nur Hexzeichen, hoechstens 16 — die Regel begrenzt dieses Feld, und ein fremdes Zeichen
  // darin liesse den ganzen 1-Hz-Koerper samt Vitalwerten abgelehnt werden.
  const inst = String(a.instanz == null ? '' : a.instanz).toLowerCase().replace(/[^0-9a-f]/g, '').slice(0, 16);
  if (inst) satz.instanz = inst;
  setzt('ts', jetzt);
  /*
   * sv ist der Serverplatzhalter der Datenbank ({".sv":"timestamp"}). tafel.js baut ihn nicht selbst,
   * sondern traegt ihn durch: Herzschlag und Nutzlast muessen in EINEM Koerper stehen (Befund A2-2),
   * also gehoert er in dieses Objekt und nicht in einen zweiten Schreibvorgang.
   * Alles andere als der Platzhalter wird WEGGELASSEN, nicht durchgereicht: die Regel laesst hier nur
   * ein Fenster von 60 s um die Serverzeit zu, eine selbst gerechnete Zahl faellt durch und nimmt den
   * ganzen atomaren Koerper mit. Ohne sv ist der Eintrag fuer eine ZAEHLUNG nicht mehr frisch
   * (istZaehlbar) — das kostet diesen Saal einen Platz in der Saalzaehlung, aber nicht die
   * Uebertragung aller Vitalwerte.
   */
  if (istServerZeitstempel(a.sv)) satz.sv = a.sv;
  satz.count = kacheln.length;
  satz.ueber = u.ueber;
  satz.ueberG = g.ueber;
  setzt('pri', pri);
  satz.al = al;
  setzt('altMs', jung);
  setzt('taktMs', ganz(a.taktMs));
  if (a.kurven != null) satz.kurven = !!a.kurven;
  satz.sq = ganz(a.sq) || 0;
  // dop: "Kennung doppelt". Die Web-App kann das nur aus der Tafel erfahren; ohne dieses Feld
  // muesste sie zwei Stationen mit derselben sid fuer einen Saal halten (N1).
  if (a.dop) satz.dop = 1;
  // aus: beim GEORDNETEN Beenden gesetzt. Damit unterscheidet der Leser "Station wurde abgeschaltet"
  // von "Station ist ausgefallen" — sonst steht nach jedem Feierabend ein Stoerungsbild auf dem Handy.
  setzt('aus', zahl(a.aus, 0));
  return satz;
}

// ---------------------------------------------------------------- Pfade

/*
 * tafelPfade({sid, meta, uebersicht, geraete, vorher, nurMeta}) — die flachen Schreibpfade.
 *
 * Zurueck kommt {pfade, stand, ueber}:
 *   pfade  flache PATCH-Schluessel, wortgenau nach Datenmodell:
 *            tafel/<sid>/meta, tafel/<sid>/uebersicht/<key>, tafel/<sid>/geraete/<deviceId>
 *   stand  was JETZT geschrieben wurde — der Aufrufer legt das als 'vorher' fuer die naechste Runde
 *          zurueck. Es kommt zusammen mit den Pfaden zurueck, damit niemand Pfade schreiben kann,
 *          ohne das Gedaechtnis mitzufuehren: genau das ist der Weg, auf dem eine Karteileiche
 *          entsteht.
 *   ueber  wie viele Kacheln/Zeilen der Deckel abgeschnitten hat (N17: das muss sichtbar sein, nicht
 *          lautlos passieren). Dieselben Zahlen stehen als Summe im Saalkopf.
 *
 * AUSDRUECKLICHE null-LOESCHUNG (Nachbesserung N7): Jeder Schluessel, der beim letzten Mal
 * geschrieben wurde und jetzt fehlt, bekommt null. Ohne das bleibt eine Kachel stehen, die niemand
 * mehr aktualisiert — und weil der Leser die Frische am SAAL (meta.sv) beurteilt und altMs im alten
 * Objekt eingefroren ist, erscheint sie dauerhaft als "1,2 s alt", mit plausiblen, unveraenderlichen
 * Vitalwerten, in der Tafel jeder Web-Ansicht und im Nachbarstreifen. Das gilt fuer Patienten UND
 * Geraete: wechselt der patientKey (sw_hund_22 -> id_12345, sobald die Patienten-ID nachgetragen
 * wird) oder verschwindet ein Geraet aus der Registry, muss der alte Pfad auf null gehen.
 *
 * DECKEL DETERMINISTISCH: die Auswahl macht auswahl() — dieselbe Funktion, die auch der Saalkopf
 * benutzt. Damit ist die Auswahl bei unveraendertem Bestand in jedem Takt dieselbe (eine zufaellige
 * Auswahl liesse Kacheln im Sekundentakt erscheinen und per null wieder verschwinden), und der Kopf
 * kann nie ueber einen anderen Bestand reden als die Kacheln darunter.
 */
function tafelPfade(angabe) {
  const a = angabe || {};
  const sid = String(a.sid == null ? '' : a.sid);
  if (!pruefeSid(sid)) {
    /*
     * Lautstark scheitern, nicht still ueberspringen. Eine unbrauchbare Kennung in einem Pfad ist ein
     * Pfaddurchbruch in einen fremden Saalzweig (Befund A1-12); ein stilles Ueberspringen ergaebe
     * dagegen eine Station, die einfach nie in der Fern-Ansicht auftaucht, ohne dass irgendwo steht,
     * warum. Der Aufrufer faengt Fehler ohnehin ab und schreibt sie ins Log.
     */
    throw new Error('tafelPfade: unbrauchbare Stationskennung "' + sid + '" — erwartet st + 12 Hexzeichen');
  }
  /*
   * Der Kopf muss zu SEINEM Pfad gehoeren. Die Regel fuer tafel/<sid>/meta lautet
   * hasChildren(['sid']) && child('sid').val() === $station — ein Kopf mit fremder sid weist den
   * GANZEN atomaren Koerper ab, samt Vitalwerten und samt aller anderen Saalpfade. Das hier faellt
   * beim ersten Aufruf auf; die Regel faellt erst in der Praxis auf, und dort dreimal, und dann ist
   * die Fern-Uebertragung dauerhaft abgeschaltet.
   */
  if (a.meta && typeof a.meta === 'object' && a.meta.sid !== undefined && String(a.meta.sid) !== sid) {
    throw new Error('tafelPfade: der Kopf traegt die Kennung "' + a.meta.sid + '", geschrieben wird '
      + 'aber nach "' + sid + '" — die Regel weist das ab und nimmt den ganzen Koerper mit');
  }
  const basis = 'tafel/' + sid + '/';
  const vorher = a.vorher || {};
  const altU = Array.isArray(vorher.u) ? vorher.u : [];
  const altG = Array.isArray(vorher.g) ? vorher.g : [];
  const pfade = {};

  if (a.meta !== undefined && a.meta !== null) pfade[basis + 'meta'] = a.meta;

  if (a.nurMeta) {
    /*
     * HARTE SPERRE (Nachbesserung N1): solange eine doppelte Stationskennung nicht ausgeschlossen
     * ist, wird NUR der Kopf geschrieben — keine Patientendaten. Es wird hier auch KEIN null gesetzt:
     * liegt tatsaechlich ein Zwilling auf derselben sid, wuerde ein null seine Kachel loeschen. Und
     * das Gedaechtnis bleibt unveraendert, damit die Loeschung nachgeholt wird, sobald wieder normal
     * geschrieben werden darf.
     *
     * DER KOPF WIRD DABEI AUF DIE WAHRHEIT ZURUECKGESETZT (Befund A6). tafelSatz() rechnet count,
     * pri, al und altMs aus den uebergebenen Kacheln und Geraetezeilen — es kennt den Sperrfall
     * nicht und kann ihn nicht kennen, denn es sieht die Sperre nicht. Bliebe der Kopf so stehen,
     * meldete der Nachbarstreifen fuer diesen Saal "Prioritaet 3, zwei Alarme", waehrend darunter in
     * diesem Takt keine einzige Kachel liegt — genau die Aussage, die Befund B5 als Schaden benennt
     * ("ein Alarm, den es in keiner Kachel gibt"), nur ueber den anderen Weg. Ein zweites Merkmal an
     * tafelSatz() waere die schlechtere Loesung: ein Aufrufer, der es an EINER der beiden Stellen
     * vergisst, baute genau diese Luege wieder auf. Hier kann er es nicht vergessen.
     * pri und altMs werden ENTFERNT, nicht auf 0 gesetzt: 0 waere eine Aussage ("hoechste Frische,
     * niedrigste Dringlichkeit"), das Fehlen ist keine — leere Felder fehlen in der Tafel ganz.
     * Kopiert statt geaendert, weil das uebergebene Objekt dem Aufrufer gehoert.
     */
    const kopf = pfade[basis + 'meta'];
    if (kopf && typeof kopf === 'object' && !Array.isArray(kopf)) {
      const ehrlich = Object.assign({}, kopf, { count: 0, ueber: 0, ueberG: 0, al: 0 });
      delete ehrlich.pri;
      delete ehrlich.altMs;
      pfade[basis + 'meta'] = ehrlich;
    }
    return { pfade: pfade, stand: { u: altU.slice(), g: altG.slice() }, ueber: { uebersicht: 0, geraete: 0 } };
  }

  const u = auswahl(a.uebersicht, GRENZEN.kacheln);
  const g = auswahl(a.geraete, GRENZEN.geraete);

  u.namen.forEach((k) => { pfade[basis + 'uebersicht/' + k] = u.werte[k]; });
  g.namen.forEach((k) => { pfade[basis + 'geraete/' + k] = g.werte[k]; });

  altU.forEach((k) => {
    const s = schluessel(k);
    if (u.namen.indexOf(s) < 0) pfade[basis + 'uebersicht/' + s] = null;
  });
  altG.forEach((k) => {
    const s = schluessel(k);
    if (g.namen.indexOf(s) < 0) pfade[basis + 'geraete/' + s] = null;
  });

  return {
    pfade: pfade,
    stand: { u: u.namen.slice(), g: g.namen.slice() },
    ueber: { uebersicht: u.ueber, geraete: g.ueber },
  };
}

// ---------------------------------------------------------------- Spiegelname

/*
 * saalListe(tafelAbbildung, jetzt, eigen) — die Saalliste, aus der der Spiegelname entsteht.
 *
 * DIESE FUNKTION IST DER EINZIGE WEG ZUM SPIEGELNAMEN, und genau darum gibt es sie (Befund A3).
 * Vorher rechnete saalName() ueber frischeSaele() und modusAus() ueber eine eigene, zweite Fassung
 * derselben Liste — dieselbe Eingabe ergab zwei verschiedene Zeichenketten fuer DASSELBE Feld
 * meta/station. Nachgemessen: der eigene Tafelknoten traegt ein sv 800 ms vor der eigenen
 * Uhrschaetzung; saalName() warf ihn aus der Zaehlung (istZaehlbar verlangt bekanntes Alter) und
 * lieferte den Namen des NACHBARN, waehrend modusAus() SPIEGEL_NAME_MEHRSAAL lieferte. Schreiben
 * zwei Stationen dieses eine Feld ueber verschiedene Wege, flackert der Kopf der ausgelieferten
 * Web-App im Sekundentakt zwischen beiden Fassungen — genau der Schaden, gegen den
 * SPIEGEL_NAME_MEHRSAAL gebaut ist.
 *
 * 'eigen' ({sid, name, instanz}) ist der EIGENE Saal. Er wird OHNE Uhrenpruefung aufgenommen: dass
 * dieser Prozess lebt, wissen wir ohne Zeitstempel, und beim ersten Takt steht er noch gar nicht in
 * der gelesenen Tafel. Ohne ihn hielte sich jede Station fuer "kein Saal". Ein fremder Eintrag unter
 * der eigenen Kennung faellt dabei weg — der eigene Saal steht genau einmal in der Liste.
 *
 * OHNE 'eigen' ist das Ergebnis die Sicht eines reinen LESERS (Web-App, Nachbar-Kiosk, Pruefung):
 * nur das, was in der Datenbank steht. Wer SCHREIBT, muss seinen eigenen Saal uebergeben.
 */
function saalListe(tafelAbbildung, jetzt, eigen) {
  const roh = (eigen && typeof eigen === 'object') ? eigen : null;
  const eigeneSid = (roh && pruefeSid(String(roh.sid == null ? '' : roh.sid))) ? String(roh.sid) : null;
  const liste = frischeSaele(tafelAbbildung, jetzt).filter((e) => e.sid !== eigeneSid);
  if (eigeneSid == null) return liste;
  liste.push({
    sid: eigeneSid,
    name: text(roh.name, GRENZEN.spiegelStation),
    altMs: 0,
    stufe: 'live',
    satz: { sid: eigeneSid, instanz: roh.instanz ? roh.instanz : 'eigen', sv: jetzt },
  });
  return sortiereSaele(liste);
}

/*
 * saalName(tafelAbbildung, jetzt, eigen) — die Zeichenkette fuer meta/station der alten flachen Ebene.
 *
 * ALLE SCHREIBER MUESSEN AUS DERSELBEN EINGABE DASSELBE ERRECHNEN. Der Spiegel hat keinen Anfuehrer
 * und keine Pacht (das war die Bauform, an der die Gegenpruefung neun Befunde gefunden hat): jede
 * Station schreibt dieses gemeinsame Feld selbst. Waere das Ergebnis von der Reihenfolge der Kinder
 * oder von der eigenen Sicht abhaengig, flackerte der Kopf der ausgelieferten Web-App im
 * Sekundentakt zwischen zwei Fassungen. Deshalb: nur ZAEHLBARE Eintraege (strenge Frische, siehe
 * istZaehlbar — dieser Name entscheidet mit ueber den Betriebsmodus), stabil sortiert, und bei mehr
 * als einem Saal eine feste Zeichenkette.
 *
 * Nur die Abbildung {sid: satz} wird angenommen (Befund B6, siehe frischeSaele).
 *
 * WICHTIG FUER DEN AUFRUFER: der eigene Saal gehoert als dritter Parameter dazu, sonst ist das
 * Ergebnis die Sicht eines Lesers und NICHT die eines Schreibers (Befund A3). modusAus() geht
 * ueber dieselbe saalListe() und liefert das Ergebnis fertig in spiegelMeta.station — wer schreibt,
 * nimmt das und rechnet nicht selbst.
 * null heisst "kein zaehlbarer Saal"; wer trotzdem schreiben muss, nimmt SPIEGEL_NAME_UNBENANNT.
 */
function saalName(tafelAbbildung, jetzt, eigen) {
  return nameAusListe(saalListe(tafelAbbildung, jetzt, eigen));
}

// Der Name aus einer FERTIGEN, bereits beglaubigten und sortierten Saalliste. Eine eigene Funktion,
// damit modusAus() denselben Weg geht wie saalName() und nicht eine zweite Regel bekommt — beide
// rufen saalListe() und danach diese Funktion, es gibt keinen zweiten Weg.
function nameAusListe(liste) {
  if (!liste.length) return null;
  if (liste.length > 1) return SPIEGEL_NAME_MEHRSAAL;
  return liste[0].name || null;
}

// ---------------------------------------------------------------- Kompatibilitaetsmodus

/*
 * qsFremdFrisch(wert, jetzt) — zaehlt ein FREMDES qs-Kind als lebende Station ab 1.1.0?
 *
 * STRENG, in derselben Richtung wie istZaehlbar(): das Alter muss BEKANNT sein (>= 0 und < 60 s).
 * Ein Wert aus der Zukunft zaehlt NICHT. Grund: er wuerde dauerhaft eine lebende 1.1.0-Station
 * vortaeuschen und damit den Beweis fuer eine laufende 1.0.3 unterdruecken — die Richtung, in der
 * wir einer laufenden 1.0.3 ihre flache Ebene ueberschreiben (Befund B3).
 */
function qsFremdFrisch(wert, jetzt) {
  const alt = alterMs(wert, jetzt);
  return alt != null && alt < FRISCH_MS;
}

/*
 * qsEigenFrisch(wert, jetzt) — steht UNSER EIGENES qs-Kind noch da?
 *
 * HIER GILT EIN ANDERES MASS ALS BEI EINEM FREMDEN KIND (qsFremdFrisch), und das ist der Kern von
 * Befund A1. Vorher wurden beide gleich streng behandelt. Nachgemessen, was das anrichtet: liegt das
 * eigene qs auch nur 300 ms vor 'jetzt', ist es "nicht frisch"; zusammen mit qsGeschrieben=true
 * ergibt das unten den Beweis "unser Kind wurde geloescht", und die Station erklaert sich SELBST zur
 * fremden 1.0.3. Verlauf ueber 700 Takte: F1, nach FREMD_STILLE_MS ein einziger F2-Takt, sofort
 * wieder F1. Der dauerhaft eingeschaltete Kompatibilitaetsspiegel wird damit EINEN Takt je
 * 5,5 Minuten bespielt — die ausgelieferte Web-App 1.0.3 meldet sich als "live" und zeigt bis zu
 * 5,5 Minuten alte Vitalwerte neben einer laufenden Narkose.
 *
 * DIE SCHADENSRICHTUNG IST ASYMMETRISCH, DESHALB IST DIE ANTWORT ES AUCH:
 *   • Ein FREMDES Kind aus der Zukunft, das faelschlich als frisch gilt, kostet einen unterdrueckten
 *     Beweis: wir spiegeln, waehrend eine 1.0.3 dasselbe Feld schreibt, und der Kopf der alten
 *     Web-App flackert zwischen zwei Namen. Sichtbar, und es heilt sich selbst, sobald der Wert
 *     altert. Deshalb bleibt es dort streng.
 *   • Das EIGENE Kind aus der Zukunft, das faelschlich als nicht frisch gilt, kostet den GANZEN
 *     Spiegel, 5 Minuten am Stueck, immer wieder — und ohne Aussicht auf Selbstheilung: in F1 gibt
 *     es kein qs-Recht, das eigene Kind kann also nie wieder frisch werden.
 * Beide gleich zu behandeln hiesse, den zweiten Schaden zu kaufen, um den ersten zu vermeiden.
 *
 * WARUM DIE NACHSICHT HIER NICHTS PREISGIBT: bei einem fremden Kind lautet die Frage "lebt dort eine
 * Station ab 1.1.0?", beim eigenen aber "wurde unser Kind GELOESCHT?". Der Beweis ist das
 * VERSCHWINDEN — nur das Vollbild einer 1.0.3 ersetzt den ganzen meta-Knoten (cloud.js:534-535). Ein
 * Wert, der vor unserer Uhr liegt, ist DA, also nicht geloescht. Ein geloeschtes Kind FEHLT, und ein
 * fehlendes Kind ist unten weiterhin der Beweis: es kommt in dieser Pruefung gar nicht vor.
 *
 * DAS FENSTER IST SYMMETRISCH: |jetzt - wert| < FRISCH_MS. Dieselben 60 s nach hinten wie bei jedem
 * anderen Frischemass dieser Datei, und dieselben 60 s nach vorn. Nach VORN braucht es sie, weil
 * 'jetzt' nur eine SCHAETZUNG der Serverzeit ist: die HTTP-Date-Kopfzeile hat 1 s Aufloesung und
 * wird abgeschnitten, unterschaetzt die Serverzeit also um bis zu 999 ms, waehrend das eigene qs
 * gerade erst ~1000 ms alt ist. Begrenzt bleibt es trotzdem, damit ein liegengebliebenes eigenes
 * Kind aus einem frueheren Prozesslauf den Beweis nicht ewig unterdruecken kann: nach spaetestens
 * 60 s Vorlauf plus 60 s Alterung faellt es aus dem Fenster.
 */
function qsEigenFrisch(wert, jetzt) {
  const w = Number(wert);
  const n = Number(jetzt);
  if (!Number.isFinite(w) || !Number.isFinite(n) || w <= 0) return false;
  return (w > n ? w - n : n - w) < FRISCH_MS;
}

/*
 * modusAus({...}) — welcher Kompatibilitaetsmodus gilt: F0, F1, F2-solo oder F2-multi.
 *
 * Der Kompatibilitaetsspiegel ist laut Entscheidung des Nutzers DAUERHAFT an: eine ausgelieferte
 * Web-App 1.0.3 liest ausschliesslich die alte flache Ebene, und wer sie leer laufen laesst, hat
 * einen Browser, der sich als "live" meldet und nichts zeigt — der schlechtestmoegliche Ausgang.
 *
 *  F0 'unbekannt'  Tafel und flaches meta noch nicht gelesen -> NICHTS flach schreiben, ohne
 *                  Ausnahme (siehe unten).
 *  F1 '1.0.3 im Konto'  eine fremde Fassung schreibt die flache Ebene -> gar nichts flach, und NIE
 *                  ein null auf einen unpraefixierten Schluessel.
 *  F2-solo         wir sind allein -> voller Spiegel mit Kurven und Protokoll: eine Einzelplatzpraxis
 *                  bleibt mit der alten Web-App vollstaendig wie heute.
 *  F2-multi        mehrere Saele -> Spiegel ohne Kurven und ohne Protokoll, meta/station konstant.
 *
 * WARUM F0 KEINE AUSNAHME MEHR HAT (Befund B2 und B1): frueher durfte der allererste Schreibvorgang
 * "die technischen meta-Felder (sv, v)" mitnehmen, weil die Regel auf /live/<uid> ein meta verlangte.
 * Das war aus zwei Gruenden falsch:
 *   1. Die Regel verlangt das nicht mehr. Sie lautet jetzt hasChildren(['meta']) ODER ['tafel'] ODER
 *      ['saele'] ODER ['verbund'] — ein Koerper mit ausschliesslich Tafelpfaden geht durch, und
 *      genau so einen schreibt eine neue Station im ersten Takt.
 *   2. Ein flaches meta mit sv und v, aber OHNE station und ts, ist nach der Bestandsregel
 *      hasChildren(['station','ts']) unzulaessig — auf einem leeren Konto haette dieser
 *      "harmlose" erste Schreibvorgang den ganzen Koerper gekostet. Und ein frisches flaches meta
 *      OHNE frisches qs-Kind ist unten der BEWEIS fuer eine fremde 1.0.3: die Station erklaerte sich
 *      im naechsten Takt selbst zur 1.0.3, verweigerte 5 min lang den Spiegel und begann von vorn.
 * Der Parameter 'erstschreibvorgang' wird deshalb nicht mehr ausgewertet. Er bleibt zulaessig, damit
 * ein Aufrufer aus einem Vorabstand nicht scheitert, aber er raeumt kein Recht mehr ein.
 *
 * WIE EINE FREMDE 1.0.3 BEWIESEN WIRD (Nachbesserung N5): an der ANWESENHEIT von meta/qs/<sid> —
 * ein Kind je Station, gezaehlt werden nur frische. Ein gemeinsames Einzelfeld (der Plan hatte
 * meta/q) kann nicht anzeigen, WER geschrieben hat, und meta/v bleibt konstant bei 3, unterscheidet
 * also nichts. Der Beweis ist positiv und braucht kein "fortlaufend":
 *   - Das Vollbild einer 1.0.3 ist {meta:{...}, patients:{...}} und ERSETZT den ganzen meta-Knoten
 *     (cloud.js:534-535). Unser eigenes qs-Kind ist danach WEG, obwohl wir es jede Sekunde
 *     schreiben. Das ist der Beweis.
 *   - Laeuft die 1.0.3 schon, wenn wir starten, ist das flache meta frisch und traegt ueberhaupt kein
 *     frisches qs-Kind. Auch das ist der Beweis, sofort beim ersten Lesen.
 * Die Frische eines FREMDEN qs-Kindes wird streng beurteilt, die des EIGENEN nicht — warum das kein
 * Versehen, sondern die Antwort auf eine asymmetrische Schadenslage ist, steht ausfuehrlich bei
 * qsFremdFrisch()/qsEigenFrisch() (Befund A1).
 *
 * Nachbesserung N4: F1 ist JEDERZEIT wieder betretbar. Sobald der Beweis vorliegt, gilt sofort F1;
 * zurueck nach F2 geht es erst nach FREMD_STILLE_MS ohne neuen Beweis. Der Aufrufer traegt fremdSeit
 * nur hin und zurueck, die Entscheidung faellt hier.
 *
 * WAS DER AUFRUFER SCHREIBEN DARF, steht in 'flach' — und 'qs' gehoert dazu (Befund B2). Ohne dieses
 * Recht schriebe die Station nie ein qs-Kind, und ihr eigenes frisches meta ohne qs waere im
 * naechsten Takt der Beweis fuer eine 1.0.3, die es gar nicht gibt.
 *
 * WAS 'qsGeschrieben' HEISST — UND WAS NICHT (Befund A2). Es heisst: "hat DIESE Station im LETZTEN
 * Takt tatsaechlich ein qs-Kind geschrieben?" Eine Aussage ueber EINEN Takt, nicht ueber die
 * Fassung. Der Aufrufer bildet es aus dem Ergebnis des letzten Taktes:
 *     qsGeschrieben = (Ergebnis des letzten Taktes).flach.qs === true && der Schreibvorgang lief
 * Die andere naheliegende Lesart ("wir schreiben in dieser Fassung ueberhaupt qs", also dauerhaft
 * true) waere ein dauerhafter Stillstand: in F1 gibt es kein qs-Recht, das eigene Kind kann nie
 * wieder frisch werden, und F1 erneuerte sich in jedem Takt. Nachgemessen an zwei 1.1.0-Stationen
 * ohne jede 1.0.3: Station A blieb mit dieser Lesart nach 1 min, 6 min, 60 min und 600 min in F1 und
 * spiegelte ihre Patienten nie wieder. GEGEN GENAU DIESEN STILLSTAND SICHERT DIESE FUNKTION SELBST
 * AB — siehe qsRechtLangGenug unten; die Sicherung braucht den Aufrufer nicht.
 *
 * WELCHEN WERT DER AUFRUFER ALS qs SCHREIBT, ENTSCHEIDET NICHT ER, sondern diese Funktion: das
 * Ergebnis fuehrt 'spiegelQs'. Warum das hier geprueft und nicht nur empfohlen wird, steht dort.
 */
function modusAus(angabe) {
  const a = angabe || {};
  const jetzt = Number(a.jetzt);
  const eigeneSid = String(a.eigeneSid == null ? '' : a.eigeneSid);
  const vorher = a.vorher || {};
  const flachGelesen = a.flachGelesen === true;
  const tafelGelesen = a.tafelGelesen === true;
  const flach = (a.flachMeta && typeof a.flachMeta === 'object') ? a.flachMeta : null;

  const aus = (modus, grund, fremdSeit, saele, flachRechte, spiegelMeta, spiegelQs) => ({
    modus: modus,
    saele: saele,
    grund: grund,
    fremdSeit: fremdSeit == null ? null : fremdSeit,
    flach: flachRechte,
    spiegelMeta: spiegelMeta,
    spiegelQs: spiegelQs,
  });
  const keineRechte = { meta: false, station: false, qs: false, patienten: false, kurven: false, protokoll: false };
  // Wird nur gelesen, wenn ein Recht erteilt ist — bei keineRechte schreibt der Aufrufer nichts.
  // Trotzdem ausdruecklich alle Felder mit null, damit ein Aufrufer nicht auf undefined stoesst.
  const keinMeta = { station: null, ts: null, taktMs: null, kurven: null };
  const keinQs = { sid: null, wert: null };

  if (!Number.isFinite(jetzt) || !pruefeSid(eigeneSid)) {
    return aus('F0', 'Zustand noch nicht entscheidbar: Uhr oder Stationskennung fehlt.', null, 0,
      keineRechte, keinMeta, keinQs);
  }

  // --- F0: es ist noch nichts gelesen, also ist nichts bekannt. Kein Recht, auch nicht das kleinste:
  //     der erste Koerper einer neuen Station besteht ohnehin nur aus Tafelpfaden, und die Regel auf
  //     /live/<uid> laesst genau das zu.
  if (!tafelGelesen || !flachGelesen) {
    return aus('F0',
      'Die Tafel ist noch nicht gelesen — es wird nichts in die alte flache Ebene geschrieben.',
      vorher.fremdSeit == null ? null : Number(vorher.fremdSeit), 0, keineRechte, keinMeta, keinQs);
  }

  // --- Wer schreibt die flache Ebene? istFrisch nimmt sv, sonst ts, und behandelt eine vorlaufende
  //     Uhr als frisch — hier ist das die SICHERE Richtung: es kann nur dazu fuehren, dass wir
  //     schweigen, nie dazu, dass wir einer laufenden 1.0.3 ihre Ebene ueberschreiben.
  const flachFrisch = flach ? istFrisch(flach, jetzt) : false;
  const qs = (flach && flach.qs && typeof flach.qs === 'object') ? flach.qs : null;
  let qsFrischIrgendwer = false;
  let qsFrischEigen = false;
  if (qs) {
    for (const s of Object.keys(qs)) {
      // Das EIGENE Kind und ein FREMDES werden ABSICHTLICH verschieden gemessen — die vollstaendige
      // Begruendung steht bei qsEigenFrisch(). Kurz: beim fremden lautet die Frage "lebt dort eine
      // 1.1.0?", beim eigenen "wurde unser Kind geloescht?", und ein Wert, der vor unserer
      // Uhrschaetzung liegt, ist DA, also nicht geloescht.
      if (!(s === eigeneSid ? qsEigenFrisch(qs[s], jetzt) : qsFremdFrisch(qs[s], jetzt))) continue;
      qsFrischIrgendwer = true;
      if (s === eigeneSid) qsFrischEigen = true;
    }
  }
  let fremdSeitVorher = vorher.fremdSeit == null ? null : Number(vorher.fremdSeit);
  if (!Number.isFinite(fremdSeitVorher)) fremdSeitVorher = null;
  /*
   * DER ZWEITE BEWEISWEG BRAUCHT EIN RECHT, DAS ES IN F1 NICHT GIBT (Befund A2).
   *
   * "Unser Kind fehlt, obwohl wir qs schreiben" beweist nur dann ein fremdes Vollbild, wenn wir lange
   * genug schreiben DURFTEN, dass unser Kind ueberhaupt frisch sein koennte. Waehrend F1 gilt, ist
   * flach.qs === false — dort fehlt unser Kind aus dem EIGENEN Schweigen. Ohne diese Bedingung haelt
   * F1 sich selbst fest: im Takt, in dem die Stille-Frist ablaeuft, haben wir seit 5 Minuten kein qs
   * geschrieben, ein Nachbar ab 1.1.0 hat ein frisches Kind, und der Beweis erneuerte den Latch —
   * fuer immer. Genau das war mit zwei 1.1.0-Stationen und ganz ohne 1.0.3 nachgemessen.
   * FREMD_STILLE_MS + FRISCH_MS: solange dauert es nach dem Beweis, bis wir wieder ein volles
   * Frischefenster lang schreiben durften.
   *
   * WAS DAS KOSTET, ehrlich benannt: in den 60 s nach einem F1-Ende ist dieser eine Beweisweg
   * gesperrt. Der andere (die flache Ebene ist frisch, aber KEIN qs-Kind ist frisch) bleibt offen,
   * und er ist der wirksame: ein Vollbild einer 1.0.3 loescht ALLE qs-Kinder auf einmal, auch die der
   * Nachbarn. Eine wirklich laufende 1.0.3 faellt also weiter sofort auf.
   */
  const qsRechtLangGenug = fremdSeitVorher == null
    || (jetzt - fremdSeitVorher) >= FREMD_STILLE_MS + FRISCH_MS;
  const fremdJetzt = flachFrisch && (!qsFrischIrgendwer
    || (a.qsGeschrieben === true && !qsFrischEigen && qsRechtLangGenug));
  let fremdSeit = fremdSeitVorher;
  if (fremdJetzt) fremdSeit = jetzt;

  /*
   * --- Wie viele Saele zaehlen? Nur ZAEHLBARE (istZaehlbar: Serverzeit, bekanntes Alter < 60 s),
   * plus der eigene ohne Uhrenpruefung. Gerechnet wird das in saalListe() — DERSELBEN Funktion, die
   * auch saalName() benutzt (Befund A3). Zwei Wege zu einer Zeichenkette, die ALLE Stationen in
   * dasselbe Feld schreiben, waeren zwei Fassungen dieses Feldes und damit ein Kopf, der im
   * Sekundentakt flackert.
   * Die fremden Eintraege kommen aus der ABBILDUNG, ihr sid ist also der Schluessel, unter dem sie
   * liegen — ein untergeschobenes sid-Feld kann sich nicht als "der eigene" ausgeben und dadurch aus
   * der Zaehlung verschwinden (Befund B6). Doppelte sid kann es dabei nicht geben: Schluessel eines
   * Objekts sind eindeutig.
   */
  const eigen = a.eigenSatz && typeof a.eigenSatz === 'object' ? a.eigenSatz : null;
  const liste = saalListe(a.tafelEintraege, jetzt, {
    sid: eigeneSid,
    name: eigen ? eigen.name : a.eigenName,
    instanz: eigen ? eigen.instanz : null,
  });
  const saele = liste.length;

  /*
   * Der Latch wird ABSICHTLICH nicht gegen eine rueckwaerts gestellte Uhr abgesichert: eine negative
   * Differenz haelt F1 ebenfalls. Ein Uhrensprung darf eine Sicherheitssperre niemals LOESEN — im
   * schlechtesten Fall spiegelt diese Station ein paar Minuten laenger nicht, im umgekehrten Fall
   * ueberschreibt sie einer laufenden 1.0.3 die flache Ebene.
   */
  if (fremdSeit != null && jetzt - fremdSeit < FREMD_STILLE_MS) {
    return aus('F1',
      'Eine Station in dieser Praxis hat noch Fassung 1.0.3. Solange sie laeuft, zeigt die alte '
      + 'Fern-Ansicht nur diesen einen Saal. Bitte diese Station aktualisieren.',
      fremdSeit, saele, keineRechte, keinMeta, keinQs);
  }

  // --- F2. Der Name ist die gemeinsame, deterministische Zeichenkette.
  const solo = saele <= 1;
  const rechte = { meta: true, station: true, qs: true, patienten: true, kurven: solo, protokoll: solo };
  /*
   * taktMs = 1000 in BEIDEN Unterfaellen: die flache Ebene wird nur noch im Tafeltakt bespielt
   * (1 Hz), nicht im 200-ms-Takt des eigenen Saalstroms. Eine 200 hier waere eine Zusage, die der
   * Spiegel nicht einhaelt — und sie wuerde beim Wechsel solo <-> multi wechseln, also flackern.
   *
   * station UND ts sind die beiden Pflichtkinder des flachen meta (PFLICHTFELDER.flachMeta). Sie
   * stehen hier IMMER, und station ist nie null: ein null loescht in der Datenbank das Kind, das
   * flache meta verlaere sein 'station', die Bestandsregel hasChildren(['station','ts']) wiese den
   * ganzen Koerper ab — und der traegt im 1-Hz-Takt auch die Vitalwerte (Befund B1). Ein Saal ohne
   * konfigurierten Namen bekommt deshalb den ausdruecklichen Ersatzwert.
   */
  const spiegelMeta = {
    station: nameAusListe(liste) || SPIEGEL_NAME_UNBENANNT,
    ts: jetzt,
    taktMs: TAFEL_TAKT_MS,
    kurven: solo,
  };
  /*
   * WAS UNTER meta/qs GESCHRIEBEN WIRD — und warum das hier GEPRUEFT wird und nicht nur im
   * Kopfkommentar steht (Befund A1).
   *
   * Der qs-Wert ist NUR als Serverzeitstempel brauchbar, genau wie tafel/<sid>/meta.sv: er wird oben
   * gegen 'jetzt' gerechnet, und 'jetzt' ist Serverzeit. Setzt ein Aufrufer dort die PC-Uhr ein, geht
   * auf einem 30 s vorgehenden OP-PC das eigene qs 30 s in die Zukunft — und das war der gemessene
   * Weg in den 5,5-Minuten-Takt aus Befund A1. Bei sv steht diese Pflicht nicht nur im Text, sondern
   * wird gepruft (istServerZeitstempel in tafelSatz); beim qs-Wert fehlte sie ganz. Deshalb steht sie
   * jetzt hier: was der Aufrufer uebergibt, wird geprueft und nur der Platzhalter durchgereicht —
   * alles andere wird durch den Platzhalter ERSETZT statt uebernommen.
   * Anders als sv ist ein Wegwerfen hier nicht moeglich: ein fehlendes eigenes qs-Kind ist oben der
   * Beweis fuer eine fremde 1.0.3, und die Station bewiese sich damit selbst (Befund B2).
   *
   * Geschrieben wird EIN Kind unter dem eigenen Schluessel (meta/qs/<sid>), nie der ganze qs-Knoten:
   * ein Vollbild auf meta/qs loeschte die Kinder der Nachbarstationen und liesse sie sich gegenseitig
   * fuer eine 1.0.3 halten.
   */
  const spiegelQs = {
    sid: eigeneSid,
    wert: istServerZeitstempel(a.qsWert) ? a.qsWert : { '.sv': 'timestamp' },
  };
  return aus(solo ? 'F2-solo' : 'F2-multi',
    solo
      ? 'Diese Station ist allein im Konto: die alte Fern-Ansicht bekommt alles wie bisher, '
        + 'einschliesslich Kurven und Verlauf.'
      : saele + ' OP-Saele im Konto: die alte Fern-Ansicht zeigt alle Patienten mit Saalnamen, '
        + 'aber ohne Kurven und ohne Verlauf.',
    fremdSeit, saele, rechte, spiegelMeta, spiegelQs);
}

// ---------------------------------------------------------------- Herzschlag

/*
 * tafelTakt(patientenZahl, cfg) — der Abstand zweier Tafelschreibvorgaenge.
 *
 * Sparregel auf die NEUE Lage (Nachbesserung N6): liegt im eigenen Saal kein Patient, genuegen 5 s.
 * Es zaehlt ausdruecklich nur der EIGENE Saal — wir schreiben nur unseren Zweig, und ein Nachbarsaal
 * mit Patienten schreibt seinen Herzschlag selbst.
 */
function tafelTakt(patientenZahl, cfg) {
  const c = cfg || {};
  const takt = Math.max(200, Math.floor(Number(c.tafelTaktMs) || TAFEL_TAKT_MS));
  const ruhe = Math.max(takt, Math.floor(Number(c.ruheTaktMs) || RUHE_TAKT_MS));
  return (ganz(patientenZahl) || 0) > 0 ? takt : ruhe;
}

/*
 * herzschlagFaellig({jetzt, letzter, patientenZahl, tafelTaktMs, ruheTaktMs}) -> true/false
 *
 * DER TAFELTAKT IST DER HERZSCHLAG EINES SAALS und muss laufen, auch wenn sich an den Werten nichts
 * aendert. Diese Funktion sieht deshalb ABSICHTLICH KEINEN EINZIGEN MESSWERT: sie kennt die Uhr, den
 * letzten Takt und die ANZAHL der Patienten — mehr nicht. patientenZahl entscheidet nur zwischen 1 s
 * und 5 s (Sparregel N6), niemals zwischen "schreiben" und "nicht schreiben". Zusaetzliche Felder im
 * Argument werden nicht gelesen; tools/tafel-test.js rechnet denselben Fall mit angehaengten Feldern
 * wie werteGleich/geaendert durch und verlangt dasselbe Ergebnis. Ohne diese Pruefung waere ein
 * spaeteres 'if (a.werteGleich) return false;' unsichtbar durchgerutscht.
 *
 * WARUM DIE HEUTIGE SPARREGEL AUS cloud.js NICHT WEITERVERWENDBAR IST: sie lautet dort
 *   nurHerzschlag = keys.length > 0 && keys.every((k) => k === 'meta/ts')
 * und haengt damit an der LITERALEN Zeichenkette 'meta/ts'. Sobald der Herzschlag nicht mehr
 * meta/ts heisst (er heisst jetzt tafel/<sid>/meta) und aus dem 200-ms-Delta herausgenommen ist,
 * ist zwischen zwei Geraeteframes keys.length === 0 — der Schreibvorgang entfaellt ganz, und
 * tafel/<sid>/meta.sv steht bis zu 30 s still, weil das LifeVet ab Werk nur alle ~30 s sendet.
 * Der Leser meldet dann nach 12 s gelb und nach 60 s "offline" fuer einen GESUNDEN Saal und ersetzt
 * seine Zahlen durch "Stand vor X min". Genau das darf nicht passieren.
 *
 * Eine zurueckgestellte Uhr macht faellig: ein zusaetzlicher Schreibvorgang kostet ein paar Byte,
 * ein stehender Herzschlag kostet die Aussage "dieser OP-Saal lebt".
 */
function herzschlagFaellig(angabe) {
  const a = angabe || {};
  const jetzt = Number(a.jetzt);
  if (!Number.isFinite(jetzt)) return false;          // ohne Uhr wird hier nichts entschieden
  if (a.letzter == null) return true;                 // noch nie geschrieben
  const l = Number(a.letzter);
  if (!Number.isFinite(l)) return true;
  const seit = jetzt - l;
  if (seit < 0) return true;                          // Uhr zurueckgestellt
  return seit >= tafelTakt(a.patientenZahl, a);
}

/*
 * waehleNachbarn(fremd, bekannt, deckel) — WELCHE Nachbarsaele werden gelesen, wenn es mehr gibt
 * als der Deckel zulaesst?
 *
 * WARUM ES DIESE FUNKTION GIBT (Befund 01.08.2026, Gegenpruefung des Verbunds):
 * cloud.js nahm bis hierher schlicht `fremd.sort().slice(0, 8)` — also die alphabetisch ersten
 * acht Stationskennungen. Eine Stationskennung ist aber eine Zufallsfolge; alphabetisch heisst
 * hier "willkuerlich". In einem Konto, in dem ueber die Jahre mehr als acht Kennungen aufgelaufen
 * sind — und der Knoten eines ausgemusterten PCs bleibt in der Datenbank stehen —, konnte damit
 * ein LAUFENDER OP-Saal aus der Liste fallen, waehrend eine Karteileiche gelesen wurde. Der Saal
 * war dann fern unsichtbar, ohne dass irgendwo ein Fehler stand.
 *
 * DIE REGEL JETZT: wer zuletzt am juengsten geschrieben hat, wird zuerst gelesen. Ein Saal, von
 * dem noch nie etwas gelesen wurde, gilt als HOECHSTE Prioritaet — sonst wuerde ein neu
 * aufgestellter Saal nie entdeckt, weil er per Definition noch keinen bekannten Zeitstempel hat.
 * Nach dem ersten Lesen hat er einen echten sv und ordnet sich von selbst ein: laeuft er, bleibt
 * er oben; ist er eine Karteileiche, sinkt er dauerhaft nach unten.
 *
 * `bekannt` ist die zuletzt gelesene Kopfzeile je Saal (cloud._tafelEintraege). Bei Gleichstand
 * wird alphabetisch sortiert — damit bleibt die Reihenfolge vorhersagbar und ein Test reproduzierbar.
 *
 * PURE FUNKTION: kein Netz, keine Uhr. Genau deshalb pruefbar (tools/tafel-test.js).
 * Rueckgabe: { genommen[], weggelassen[] } — Weggelassenes wird GEMELDET, nie verschwiegen.
 */
function waehleNachbarn(fremd, bekannt, deckel) {
  const liste = (fremd || []).slice();
  const bek = bekannt || {};
  const d = Number.isFinite(deckel) ? deckel : GRENZEN.saele;
  const rang = (k) => {
    const m = bek[k];
    const sv = (m && typeof m.sv === 'number') ? m.sv : null;
    /* Noch nie gelesen -> ganz nach vorn. Number.MAX_SAFE_INTEGER statt Infinity, weil
     * Infinity - Infinity = NaN und die Sortierung damit vom Zufall abhinge. */
    return sv == null ? Number.MAX_SAFE_INTEGER : sv;
  };
  liste.sort((a, b) => (rang(b) - rang(a)) || (a < b ? -1 : (a > b ? 1 : 0)));
  return { genommen: liste.slice(0, d), weggelassen: liste.slice(d) };
}

module.exports = {
  TAFEL_V, GRENZEN, PFLICHTFELDER, SID_FORM,
  waehleNachbarn,
  SPIEGEL_NAME_MEHRSAAL, SPIEGEL_NAME_UNBENANNT,
  STUFE_LIVE_MS, STUFE_OFFLINE_MS, STUFE_WEG_MS, FRISCH_MS, FREMD_STILLE_MS, UHR_TOLERANZ_MS,
  TAFEL_TAKT_MS, RUHE_TAKT_MS,
  text, zahl, ganz, leer, schluessel, pruefeSid, kappe, istServerZeitstempel,
  alterMs, altersStufe, istFrisch, istZaehlbar, istZeigbar, frischeSaele,
  tafelSatz, uebersichtSatz, geraeteSatz, keysJeGeraet, tafelPfade,
  saalName, modusAus, tafelTakt, herzschlagFaellig,
};
