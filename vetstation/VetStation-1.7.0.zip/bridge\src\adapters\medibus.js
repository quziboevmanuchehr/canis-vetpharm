'use strict';
/*
 * medibus.js — Draeger MEDIBUS (klassisch) und MEDIBUS.X ueber RS-232.
 *
 * WOFUER: Draeger-Narkosegeraete (Fabius, Primus, Perseus, Zeus, Atlan, Apollo) und
 * -Beatmungsgeraete (Evita, Savina, Carina) geben ihre Werte ausschliesslich ueber eine serielle
 * Schnittstelle heraus — nicht ueber Netzwerk. Ohne diesen Leser bleiben sie unerreichbar.
 *
 * ================================================================================
 * DAS HIER IST KEIN NORMALES "MITLESEN". Bitte den ganzen Abschnitt lesen.
 * ================================================================================
 * MEDIBUS ist ein Frage-Antwort-Protokoll mit HARTEN Zeitregeln. Ein Geraet, an dem ein PC haengt,
 * der die Regeln nicht einhaelt, BRICHT DIE VERBINDUNG AB — und zeigt am Bildschirm einen Fehler
 * ("COM1 error"). Die Regeln stehen in der Protokolldefinition (Best.-Nr. 90 28 258, Rev. 6.00,
 * S. 5 und FAQ S. 55-57) und lauten:
 *   1. Jede Pause im Datenfluss ueber 3 s gilt als Zeitueberschreitung -> Abbruch.
 *   2. Auf JEDES empfangene Kommando MUSS binnen 10 s geantwortet werden. Auch auf unbekannte —
 *      dann mit leerer Antwort. Ein unbeantwortetes Kommando bricht die Verbindung IMMER ab.
 *   3. Ohne Nutzdatenverkehr muss der PC alle 2 s ein NOP (30H) senden.
 *   4. Das Geraet sendet von sich aus etwa alle 3 s ein ICC (51H). Der PC muss nur DARAUF
 *      antworten; ein eigenes ICC ist nicht noetig.
 *   5. Kommandos koennen IN Antworten eingebettet sein, an beliebiger Stelle. Der haeufigste
 *      Fehler ist, das eingebettete "Request Device Identification" zu uebersehen — dann bricht
 *      die Verbindung nach 30-40 s ab, und es sieht aus wie ein Kabelproblem.
 *   6. Nach jedem (Wieder-)ICC sind ALLE vorher gesendeten Konfigurationen im Geraet geloescht.
 *
 * WAS DAS FUER DIE READ-ONLY-REGEL BEDEUTET (§10): Dieser Adapter MUSS senden, sonst schweigt das
 * Geraet. Gesendet werden ausschliesslich Datenanfragen und Protokollantworten — nie eine
 * Einstellung. Erzwungen wird das durch die Erlaubnisliste in seriell.js: dort steht jedes einzelne
 * Byte, das den PC verlassen darf. Ein Kommando, das am Geraet etwas veraendern wuerde, muesste
 * dort sichtbar eingetragen werden.
 *
 * ================================================================================
 * WAS DIESER LESER HEUTE TUT — UND WAS AUSDRUECKLICH NOCH NICHT
 * ================================================================================
 * FERTIG UND PRUEFBAR (tools/medibus-test.js, ohne Geraet):
 *   - Rahmen: Kommando = ESC(1Bh) + Code + [Argument] + Pruefsumme(2 ASCII-HEX) + CR(0Dh);
 *     Antwort = SOH(01h) + Echo + Nutzteil + Pruefsumme + CR. Pruefsumme = niederwertiges
 *     8-Bit-Summenbyte aller vorangehenden Bytes, als zwei ASCII-HEX-Zeichen.
 *   - Realtime-Bytes (80H-FFH) duerfen ueberall eingebettet sein und zaehlen NICHT zur Pruefsumme.
 *   - Die vollstaendige Zeitmaschinerie aus den sechs Regeln oben.
 *   - Die Satzbreite der Antworten wird GEMESSEN (siehe satzbreiteBestimmen) statt angenommen.
 *
 * BEWUSST NOCH NICHT: die Umsetzung Datencode -> Vitalwert.
 *   Grund: die konkreten Datencodes stehen NICHT in der allgemeinen Protokolldefinition, sondern
 *   in geraetespezifischen Dokumenten ("MEDIBUS for Draeger Anaesthesia Devices", 9037426), die
 *   oeffentlich nicht zu beschaffen waren. Eine geratene Zuordnung waere hier besonders
 *   gefaehrlich: im dokumentierten Praxisfall am Primus kamen ueber eine falsch gebaute Verbindung
 *   Zahlen an, die PLAUSIBEL AUSSAHEN und trotzdem falsch waren (Tidalvolumen 17165 mL statt 300).
 *   Deshalb gilt hier: OHNE hinterlegte Codetabelle wird KEIN Wert an die Station gemeldet.
 *   Der Leser baut die Verbindung auf, haelt sie stabil und schreibt jede Antwort mit — genau das,
 *   was gebraucht wird, um die Tabelle EINMAL an einem echten Geraet zu bestimmen. Danach genuegt
 *   ein Eintrag "codes" in der Konfiguration, und die Werte fliessen.
 *
 * ZWEITE FALLE, die dieser Leser abfaengt: bei der Fabius-Familie steht das Protokoll AB WERK auf
 * VITALINK, nicht auf MEDIBUS — und beide aehneln einander so sehr, dass eine Fehleinstellung
 * "inaccurate data" erzeugt (Warnung im Draeger-Servicehandbuch). Deshalb wird die Geraetekennung
 * (52H) ausgewertet und die Verbindung als unbestaetigt gefuehrt, solange sie nicht plausibel ist.
 */
const { Adapter } = require('./base');
const { SerielleVerbindung } = require('../seriell');

const ESC = 0x1b, SOH = 0x01, CR = 0x0d;

/*
 * DIE ERLAUBNISLISTE — jedes Kommando, das den PC verlassen darf, steht hier mit Begruendung.
 * Alles, was am Geraet etwas VERSTELLEN wuerde, fehlt absichtlich und wird von seriell.js
 * abgewiesen. Diese Liste ist die eigentliche Sicherheitszusage dieses Adapters.
 */
const KOMMANDO = {
  NOP: 0x30,                 // Lebenszeichen, traegt keine Wirkung
  ICC: 0x51,                 // Verbindungsaufbau (Initialize Communication)
  GERAETE_ID: 0x52,          // "wer bist du?" — reine Auskunft
  DATEN: 0x24,               // Messwerte anfordern
  ALARM_GRENZE_UNTEN: 0x25,  // Alarmgrenzen LESEN (nicht setzen)
  ALARM_GRENZE_OBEN: 0x26,
  ALARM_CP1: 0x27,           // aktive Alarme, Codepage 1
  EINSTELLUNGEN: 0x29,       // Geraeteeinstellungen LESEN
  TEXTE: 0x2a,               // Textmeldungen
  ALARM_CP2: 0x2e,           // aktive Alarme, Codepage 2
  DATEN_KONFIG: 0x4a,        // "Configure Data Response" — legt fest, WELCHE Werte kommen
  STOP: 0x55,                // Uebertragung beenden (beim Trennen)
};
/* Kommandos, die das Geraet an UNS schickt und die wir beantworten muessen. */
const ANTWORTPFLICHT = [KOMMANDO.ICC, KOMMANDO.GERAETE_ID, KOMMANDO.NOP];

/* Draeger empfiehlt fuer den PC die Kennungsnummer 0161. Cicero B und Evita 4 verlangen eine
 * VOLLSTAENDIGE Kennungsantwort, sonst brechen sie ab. */
const PC_KENNUNG = '0161VetStation      01.00';

/* Zeitregeln, alle aus 90 28 258 Rev 6.00. Die Zahlen stehen hier mit ihrer Herkunft, damit sie
 * niemand "optimiert", der den Grund nicht kennt. */
const NOP_MS = 2000;       // Regel 3
const TIMEOUT_MS = 3000;   // Regel 1 — Pause daraus = Verbindung tot
const ANTWORT_MS = 10000;  // Regel 2 — Obergrenze; wir antworten sofort
const NACH_ID_MS = 200;    // FAQ: Datenkonfiguration erst ~200 ms nach der Kennungsantwort

/* ------------------------------------------------------------------ *
 * 1) Rahmen — pure Funktionen, deshalb ohne Geraet pruefbar
 * ------------------------------------------------------------------ */

/*
 * pruefsumme(bytes) — niederwertiges 8-Bit-Summenbyte, als zwei ASCII-HEX-Zeichen (Grossbuchstaben).
 * Realtime-Bytes (80H-FFH) werden NICHT mitgezaehlt: sie duerfen ueberall eingebettet sein und
 * gehoeren nicht zur Nachricht.
 */
function pruefsumme(bytes) {
  let s = 0;
  for (const b of bytes) { if (b >= 0x80) continue; s = (s + b) & 0xff; }
  return s.toString(16).toUpperCase().padStart(2, '0');
}

/* Baut ein Kommando: ESC + Code + Argument + Pruefsumme + CR. */
function baueKommando(code, argument) {
  const arg = Buffer.from(String(argument || ''), 'latin1');
  if (arg.length > 251) throw new Error('MEDIBUS-Argument zu lang (max 251 Byte)');
  const kopf = Buffer.concat([Buffer.from([ESC, code]), arg]);
  return Buffer.concat([kopf, Buffer.from(pruefsumme(kopf), 'latin1'), Buffer.from([CR])]);
}

/* Baut eine Antwort auf ein Kommando des Geraets: SOH + Echo + Nutzteil + Pruefsumme + CR. */
function baueAntwort(code, nutzteil) {
  const n = Buffer.from(String(nutzteil || ''), 'latin1');
  const kopf = Buffer.concat([Buffer.from([SOH, code]), n]);
  return Buffer.concat([kopf, Buffer.from(pruefsumme(kopf), 'latin1'), Buffer.from([CR])]);
}

/*
 * zerlege(puffer) -> { nachrichten:[{art,code,nutzteil,ok,roh}], rest:Buffer }
 *
 * Sucht ESC- und SOH-Rahmen, prueft die Pruefsumme und gibt zurueck, was uebrig bleibt.
 * Realtime-Bytes (>= 0x80) werden aus dem Nutzteil entfernt — sie duerfen an jeder Position
 * eingebettet sein, auch mitten in einem Feld.
 *
 * `ok:false` heisst: Rahmen gefunden, aber Pruefsumme falsch. Solche Nachrichten werden NICHT
 * ausgewertet (eine falsche Pruefsumme bedeutet uebertragungsgestoerte Bytes — genau daraus
 * entstehen plausibel aussehende Falschwerte).
 */
function zerlege(puffer) {
  const nachrichten = [];
  let p = puffer;
  for (;;) {
    let start = -1, art = null;
    for (let i = 0; i < p.length; i++) {
      if (p[i] === ESC) { start = i; art = 'kommando'; break; }
      if (p[i] === SOH) { start = i; art = 'antwort'; break; }
    }
    if (start < 0) { p = p.slice(Math.max(0, p.length - 4)); break; }   // nichts gefunden
    const ende = p.indexOf(CR, start + 1);
    if (ende < 0) { p = p.slice(start); break; }                        // unvollstaendig, warten
    const roh = p.slice(start, ende);
    p = p.slice(ende + 1);
    if (roh.length < 4) continue;                                       // ESC+Code+2 Pruefzeichen
    const koerper = roh.slice(0, roh.length - 2);
    const soll = roh.slice(roh.length - 2).toString('latin1').toUpperCase();
    const ist = pruefsumme(koerper);
    const nutzRoh = koerper.slice(2);
    const nutzteil = Buffer.from(Array.from(nutzRoh).filter((b) => b < 0x80)).toString('latin1');
    nachrichten.push({ art: art, code: roh[1], nutzteil: nutzteil, ok: ist === soll, roh: roh.toString('hex') });
  }
  return { nachrichten: nachrichten, rest: p };
}

/* ------------------------------------------------------------------ *
 * 2) Satzbreite MESSEN statt annehmen
 * ------------------------------------------------------------------ */

/*
 * satzbreiteBestimmen(nutzteile) — wie breit ist ein Datensatz in der Antwort?
 *
 * WARUM GEMESSEN UND NICHT EINGETRAGEN: die allgemeine Protokolldefinition legt die Satzbreite
 * geraeteuebergreifend nicht fest, und das geraetespezifische Dokument war nicht zu beschaffen.
 * Eine geratene Breite waere der schlimmste Fall: sie liefert Zahlen — nur die falschen, weil sie
 * die Felder gegeneinander verschiebt.
 *
 * Messbar ist sie trotzdem, weil jeder Satz mit einem Datencode aus zwei HEX-Ziffern beginnt:
 * nur bei der richtigen Breite faellt in JEDEM Satz und ueber MEHRERE Antworten hinweg ein
 * gueltiger Code auf Position 0. Die Kandidaten werden durchprobiert; angenommen wird eine Breite
 * erst, wenn sie ueber alle uebergebenen Antworten haelt und keine zweite Breite gleich gut passt.
 *
 * Pure Funktion -> tools/medibus-test.js prueft sie mit erfundenen UND mit unpassenden Daten.
 */
const BREITEN = [6, 7, 8, 9, 10, 12];

function satzPasst(satz) {
  if (!/^[0-9A-Fa-f]{2}/.test(satz)) return false;
  const wert = satz.slice(2).trim();
  /* Der Wert darf leer sein (Messwert liegt nicht vor), sonst muss er eine Zahl sein —
   * mit Vorzeichen, Dezimalpunkt oder Komma. Alles andere spricht gegen diese Breite. */
  return wert === '' || wert === '---' || /^[-+]?\d+([.,]\d+)?$/.test(wert);
}

function satzbreiteBestimmen(nutzteile) {
  const kandidaten = [];
  for (const b of BREITEN) {
    let saetze = 0, gut = 0, verwendbar = 0;
    for (const n of nutzteile || []) {
      const t = String(n || '');
      if (t.length < b || t.length % b !== 0) continue;    // Laenge muss aufgehen
      verwendbar++;
      for (let i = 0; i + b <= t.length; i += b) {
        saetze++;
        if (satzPasst(t.slice(i, i + b))) gut++;
      }
    }
    if (verwendbar >= 2 && saetze >= 4 && gut === saetze) kandidaten.push({ breite: b, saetze: saetze });
  }
  if (kandidaten.length !== 1) return null;   // uneindeutig = kein Ergebnis, kein Ratespiel
  return kandidaten[0].breite;
}

/* Zerlegt einen Nutzteil in { code, wert } — erst wenn die Breite bekannt ist. */
function saetze(nutzteil, breite) {
  const aus = [];
  const t = String(nutzteil || '');
  if (!breite || t.length % breite !== 0) return aus;
  for (let i = 0; i + breite <= t.length; i += breite) {
    const s = t.slice(i, i + breite);
    const roh = s.slice(2).trim().replace(',', '.');
    aus.push({ code: s.slice(0, 2).toUpperCase(), text: roh, wert: (roh === '' || roh === '---') ? null : Number(roh) });
  }
  return aus;
}

/* ------------------------------------------------------------------ *
 * 3) Der Adapter
 * ------------------------------------------------------------------ */

class MedibusAdapter extends Adapter {
  /*
   * cfg = {
   *   id, model, role,
   *   art: 'com' | 'tcp'          'tcp' = ueber einen Geraeteserver (empfohlen)
   *   port | host + tcpPort
   *   baud: 19200, paritaet: 'e'  Fabius-Werk ist 9600/none — am Geraet ablesen, nicht raten
   *   profil: 'klassisch' | 'x'
   *   codes: { '82': { vital:'vt', faktor:1 }, ... }   LEER = es wird KEIN Wert gemeldet
   *   satzbreite: 6               optional; ohne Angabe wird sie gemessen
   * }
   */
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.verbindung = null;
    this.puffer = Buffer.alloc(0);
    this.breite = Number(cfg.satzbreite) || null;
    this.codes = cfg.codes || {};
    this.profil = cfg.profil === 'x' ? 'x' : 'klassisch';
    this.letzteBytes = 0;
    this.nopTimer = null;
    this.wachTimer = null;
    this.abfrageTimer = null;
    this.idBeantwortet = false;
    this.geraeteId = null;
    this.zaehler = { kommandos: 0, antworten: 0, pruefsummeFalsch: 0, saetze: 0 };
    this.mitschnitt = [];       // die letzten Antworten, fuer die Bestimmung der Codetabelle
    this.unbekannt = new Set();
    this.gemeldet = {};
  }

  describe() {
    return { id: this.id, model: this.cfg.model || 'Dräger (MEDIBUS)', role: this.cfg.role || 'anesthesia' };
  }

  async connect() {
    /* Die Erlaubnisliste wird HIER gebaut — aus genau den Kommandos oben, jedes einzeln.
     * seriell.js vergleicht byteweise und ohne Praefixlogik; ein Kommando, das hier nicht
     * entsteht, kann den PC nicht verlassen. */
    const erlaubt = [];
    Object.keys(KOMMANDO).forEach((k) => { erlaubt.push(baueKommando(KOMMANDO[k], '')); });
    erlaubt.push(baueKommando(KOMMANDO.DATEN_KONFIG, ''));
    ANTWORTPFLICHT.forEach((c) => { erlaubt.push(baueAntwort(c, '')); });
    erlaubt.push(baueAntwort(KOMMANDO.GERAETE_ID, PC_KENNUNG));
    erlaubt.push(baueAntwort(KOMMANDO.ICC, ''));
    erlaubt.push(baueAntwort(KOMMANDO.NOP, ''));

    this.verbindung = new SerielleVerbindung({
      art: this.cfg.art === 'com' ? 'com' : 'tcp',
      port: this.cfg.port, host: this.cfg.host, tcpPort: this.cfg.tcpPort,
      baud: this.cfg.baud || 19200,
      datenbits: this.cfg.datenbits || 8,
      paritaet: this.cfg.paritaet || 'e',
      stopbits: this.cfg.stopbits || 1,
      erlaubteBefehle: erlaubt,
    }, this.ctx);

    this.verbindung.beiDaten((d) => this._daten(d));
    this.verbindung.beiEnde(() => { this.connected = false; this._timerAus(); });
    await this.verbindung.oeffnen();
    this.connected = true;
    this.letzteBytes = Date.now();

    this.ctx.log.info('medibus', 'MEDIBUS-Verbindung offen (' + (this.cfg.baud || 19200) + ' Baud, Paritaet ' +
      (this.cfg.paritaet || 'e') + ', Profil ' + this.profil + '). Das Geraet meldet sich normalerweise ' +
      'binnen 3 s von selbst mit einem ICC. Am Geraet muss das Protokoll auf MEDIBUS stehen — bei der ' +
      'Fabius-Familie ist ab Werk VITALINK eingestellt, und das liefert plausibel aussehende FALSCHE Werte.');

    if (!Object.keys(this.codes).length) {
      this.ctx.log.warn('medibus', 'Es ist KEINE Codetabelle hinterlegt. Der Leser haelt die Verbindung und ' +
        'schneidet jede Antwort mit, meldet aber bewusst KEINEN Messwert an die Station — die Zuordnung ' +
        'Datencode → Wert steht in einem geraetespezifischen Draeger-Dokument, das nicht oeffentlich ist. ' +
        'Der Mitschnitt (Admin → Verbindung/Fehler bzw. status()) ist die Grundlage, sie EINMAL am echten ' +
        'Geraet zu bestimmen. Danach genuegt der Eintrag "codes" in devices.json.');
    }

    this._nopStarten();
    this._wachtStarten();
  }

  _timerAus() {
    if (this.nopTimer) { clearInterval(this.nopTimer); this.nopTimer = null; }
    if (this.wachTimer) { clearInterval(this.wachTimer); this.wachTimer = null; }
  }

  /* Regel 3: ohne Verkehr alle 2 s ein Lebenszeichen. */
  _nopStarten() {
    this._timerAus();
    this.nopTimer = setInterval(() => {
      if (!this.connected) return;
      if (Date.now() - this.letzteBytes < NOP_MS) return;   // es lief ohnehin Verkehr
      this._senden(baueKommando(KOMMANDO.NOP, ''));
    }, Math.floor(NOP_MS / 2));
    if (this.nopTimer.unref) this.nopTimer.unref();
  }

  /* Regel 1: laenger als 3 s Stille = die Gegenseite betrachtet die Verbindung als tot. */
  _wachtStarten() {
    this.wachTimer = setInterval(() => {
      if (!this.connected) return;
      const still = Date.now() - this.letzteBytes;
      if (still > TIMEOUT_MS * 3 && !this.gemeldet.still) {
        this.gemeldet.still = true;
        this.ctx.log.warn('medibus', 'Seit ' + Math.round(still / 1000) + ' s kommt kein einziges Byte vom ' +
          'Geraet. Der Reihe nach pruefen: (1) Steht am Geraet das Protokoll auf MEDIBUS (nicht VITALINK)? ' +
          '(2) Stimmen Baudrate und Paritaet? (3) Ist es das richtige Kabel? Die 9-poligen Draeger-Buchsen ' +
          'tragen Pin 2 = RXD und Pin 3 = TXD wie ein PC — es wird sehr wahrscheinlich ein NULLMODEM-Kabel ' +
          '(gekreuzt) gebraucht.');
      }
    }, 5000);
    if (this.wachTimer.unref) this.wachTimer.unref();
  }

  _senden(buf) {
    if (!this.verbindung) return;
    const ok = this.verbindung.senden(buf);
    if (!ok) this.ctx.log.warn('medibus', 'Ein Kommando wurde von der Sendesperre abgewiesen — das ist ' +
      'Absicht: es stand nicht in der Erlaubnisliste. ' + buf.toString('hex'));
  }

  _daten(chunk) {
    this.letzteBytes = Date.now();
    this.gemeldet.still = false;
    this.puffer = Buffer.concat([this.puffer, chunk]);
    if (this.puffer.length > 64 * 1024) this.puffer = this.puffer.slice(-8192);
    const erg = zerlege(this.puffer);
    this.puffer = erg.rest;
    erg.nachrichten.forEach((n) => this._nachricht(n));
  }

  _nachricht(n) {
    if (!n.ok) {
      this.zaehler.pruefsummeFalsch++;
      if (this.zaehler.pruefsummeFalsch === 5) {
        this.ctx.log.warn('medibus', 'Mehrere Nachrichten mit falscher Pruefsumme. Sie werden verworfen ' +
          '(eine gestoerte Nachricht ergaebe plausibel aussehende Falschwerte). Ursache ist fast immer ' +
          'eine falsche Baudrate oder Paritaet — beides am Geraet ablesen.');
      }
      return;
    }

    if (n.art === 'kommando') {
      /* Regel 2: JEDES Kommando beantworten — auch unbekannte, dann leer. Und zwar sofort, nicht
       * erst kurz vor Ablauf der 10 s. */
      this.zaehler.kommandos++;
      if (n.code === KOMMANDO.ICC) {
        /* Regel 6: nach einem ICC ist im Geraet alles zurueckgesetzt. */
        this.idBeantwortet = false;
        this._senden(baueAntwort(KOMMANDO.ICC, ''));
      } else if (n.code === KOMMANDO.GERAETE_ID) {
        this._senden(baueAntwort(KOMMANDO.GERAETE_ID, PC_KENNUNG));
        if (!this.idBeantwortet) {
          this.idBeantwortet = true;
          /* FAQ: erst die Kennungsantwort, dann ~200 ms warten, DANN konfigurieren. Wer sofort
           * konfiguriert, bekommt keine Daten und sucht den Fehler an der falschen Stelle. */
          setTimeout(() => {
            if (!this.connected) return;
            this._senden(baueKommando(KOMMANDO.DATEN_KONFIG, ''));
            this._senden(baueKommando(KOMMANDO.GERAETE_ID, ''));
            this._senden(baueKommando(KOMMANDO.DATEN, ''));
            /* Erst JETZT die regelmaessige Abfrage starten. MEDIBUS liefert nur auf Anfrage —
             * frueher gestartet wuerde sie vor der Konfiguration laufen und ins Leere gehen. */
            this._abfrageStarten();
          }, NACH_ID_MS);
        }
      } else {
        this._senden(baueAntwort(n.code, ''));   // unbekannt -> leere Antwort, aber ANTWORTEN
      }
      return;
    }

    /* --- Antwort des Geraets auf eines unserer Kommandos --- */
    this.zaehler.antworten++;

    if (n.code === KOMMANDO.GERAETE_ID) {
      this.geraeteId = n.nutzteil.trim();
      if (!this.gemeldet.id) {
        this.gemeldet.id = true;
        this.ctx.log.info('medibus', 'Geraet meldet sich als: "' + this.geraeteId + '". ' +
          'Passt das nicht zum erwarteten Draeger-Modell, steht am Geraet vermutlich VITALINK statt MEDIBUS.');
      }
      return;
    }

    if (n.code === KOMMANDO.DATEN || n.code === KOMMANDO.EINSTELLUNGEN) {
      this.mitschnitt.push({ ts: Date.now(), code: n.code, nutzteil: n.nutzteil });
      if (this.mitschnitt.length > 40) this.mitschnitt.shift();

      if (!this.breite) {
        const b = satzbreiteBestimmen(this.mitschnitt.filter((m) => m.code === n.code).map((m) => m.nutzteil));
        if (b) {
          this.breite = b;
          this.ctx.log.info('medibus', 'Satzbreite aus dem echten Datenstrom bestimmt: ' + b + ' Zeichen ' +
            '(ueber mehrere Antworten gegengeprueft, keine zweite Breite passte). Sie steht jetzt im Status ' +
            'und kann in devices.json als "satzbreite" festgeschrieben werden.');
        }
        return;   // ohne Breite wird nichts zerlegt
      }

      const liste = saetze(n.nutzteil, this.breite);
      this.zaehler.saetze += liste.length;
      const vitals = {};
      let etwas = false;
      liste.forEach((s) => {
        const abb = this.codes[s.code] || this.codes[s.code.toLowerCase()];
        if (!abb) {
          if (!this.unbekannt.has(s.code)) {
            this.unbekannt.add(s.code);
            this.ctx.log.info('medibus', 'Datencode ' + s.code + ' (Beispielwert "' + s.text + '") ist ' +
              'nicht zugeordnet. Er wird NICHT gemeldet. Zuordnen ueber "codes" in devices.json, sobald ' +
              'am Geraet ablesbar ist, welcher Wert das ist.');
          }
          return;
        }
        if (s.wert == null || !Number.isFinite(s.wert)) return;
        const w = abb.faktor ? s.wert * abb.faktor : s.wert;
        /* Grenzen sind PFLICHT, sobald ein Code zugeordnet wird — die Lehre aus dem Primus-Fall.
         * Ohne hinterlegte Grenzen wird der Wert nicht uebernommen. */
        if (!Array.isArray(abb.grenzen) || abb.grenzen.length !== 2) {
          if (!this.gemeldet['g' + s.code]) {
            this.gemeldet['g' + s.code] = true;
            this.ctx.log.warn('medibus', 'Code ' + s.code + ' ist zugeordnet, hat aber keine Grenzen ' +
              '("grenzen": [min, max]). Ohne Grenzen wird der Wert nicht uebernommen.');
          }
          return;
        }
        if (w < abb.grenzen[0] || w > abb.grenzen[1]) {
          if (!this.gemeldet['a' + s.code]) {
            this.gemeldet['a' + s.code] = true;
            this.ctx.log.warn('medibus', 'Code ' + s.code + ' lieferte ' + w + ' — ausserhalb von ' +
              abb.grenzen.join('..') + '. Verworfen.');
          }
          return;
        }
        vitals[abb.vital] = w; etwas = true;
      });

      if (etwas) {
        this.emit({
          deviceId: this.id,
          deviceModel: this.cfg.model || 'Dräger (MEDIBUS)',
          deviceRole: this.cfg.role || 'anesthesia',
          species: this.cfg.species || null,
          ts: Date.now(),
          vitals: vitals,
          alarms: [],
          _meta: { transport: 'MEDIBUS/RS-232', geraeteId: this.geraeteId, satzbreite: this.breite },
        });
      }
      return;
    }

    if (n.code === KOMMANDO.TEXTE || n.code === KOMMANDO.ALARM_CP1 || n.code === KOMMANDO.ALARM_CP2) {
      const text = n.nutzteil.trim();
      if (text) {
        this.emit({
          deviceId: this.id,
          deviceModel: this.cfg.model || 'Dräger (MEDIBUS)',
          deviceRole: this.cfg.role || 'anesthesia',
          ts: Date.now(), vitals: {},
          /* Alarmtexte kommen laut Handbuch IMMER auf Englisch, unabhaengig von der
           * Spracheinstellung am Geraet. Sie werden unveraendert durchgereicht — uebersetzen
           * hiesse deuten. */
          alarms: [text],
        });
      }
    }
  }

  /* Regelmaessig nachfragen. MEDIBUS liefert nur auf Anfrage. */
  _abfrageStarten() {
    if (this.abfrageTimer) clearInterval(this.abfrageTimer);
    this.abfrageTimer = setInterval(() => {
      if (!this.connected) return;
      this._senden(baueKommando(KOMMANDO.DATEN, ''));
    }, Math.max(1000, Number(this.cfg.abfrageMs) || 2000));
    if (this.abfrageTimer.unref) this.abfrageTimer.unref();
  }

  status() {
    return {
      verbunden: this.connected,
      geraeteId: this.geraeteId,
      satzbreite: this.breite,
      codesZugeordnet: Object.keys(this.codes).length,
      unbekannteCodes: Array.from(this.unbekannt),
      zaehler: this.zaehler,
      mitschnitt: this.mitschnitt.slice(-10),
    };
  }

  dispose() {
    this._timerAus();
    if (this.abfrageTimer) { clearInterval(this.abfrageTimer); this.abfrageTimer = null; }
    if (this.verbindung) {
      try { this._senden(baueKommando(KOMMANDO.STOP, '')); } catch (_) {}
      try { this.verbindung.schliessen(); } catch (_) {}
    }
    this.verbindung = null;
    this.connected = false;
  }
}

module.exports = {
  MedibusAdapter,
  pruefsumme, baueKommando, baueAntwort, zerlege,
  satzbreiteBestimmen, satzPasst, saetze,
  KOMMANDO, PC_KENNUNG, NOP_MS, TIMEOUT_MS, ANTWORT_MS, BREITEN,
};
