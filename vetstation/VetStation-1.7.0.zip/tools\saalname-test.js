'use strict';
/*
 * saalname-test.js — der SCHREIBWEG fuer den Namen dieses OP-Saals (Nachbesserung N10).
 *
 * WORUM ES GEHT, und warum das kein Kosmetikpunkt ist:
 * Bis 1.0.3 stand der Saalname allein in bridge/config/devices.json. Diese Datei EXISTIERT im
 * Auslieferstand nicht — Install-VetStation.ps1:92 schliesst sie per robocopy /XF ausdruecklich
 * aus, bridge/config/ enthaelt nur devices.example.json, und keine Zeile im Quellcode schreibt
 * sie. Jede ausgelieferte Station traegt deshalb den Vorlagewert 'Praxis OP 1'. Ab 1.1.0 koennen
 * mehrere OP-Saele im selben Praxis-Konto arbeiten; zwei Saele mit demselben Namen sind in der
 * Fern-Ansicht, im Nachbarstreifen und im Kopf des ausgedruckten Narkoseprotokolls nicht
 * auseinanderzuhalten. Am narkotisierten Patienten ist genau das die gefaehrlichste Verwechslung,
 * die dieses Programm anrichten kann.
 *
 * WAS DIESER TEST FESTSCHREIBT, und wogegen jede Pruefung steht:
 *   1. DIE GRENZE IST ABGELESEN, NICHT GEWAEHLT. NAME_MAX wird gegen die ECHTE Regeldatei
 *      gehalten. Eine Kappung ueber der Regelgrenze kostet nicht den Namen, sondern den ganzen
 *      atomaren 1-Hz-Koerper samt Vitalwerten — und nach drei Takten die Fern-Uebertragung.
 *   2. FORM. Der Name wird auf dem Kiosk-Bildschirm eines FREMDEN Saals angezeigt.
 *   3. SPEICHERN UND LESEN UEBER EINEN NEUSTART. Ein Name, der einen Neustart nicht ueberlebt,
 *      loest das Problem nicht — die Station hiesse nach jedem Stromausfall wieder wie alle.
 *   4. FORMMUELL AENDERT NICHTS. Eine versehentlich leere Eingabe darf einem laufenden OP-Saal
 *      nicht mitten in der Narkose seinen Namen nehmen.
 *   5. GENAU EINE NAMENSQUELLE, im Quelltext nachgezaehlt. Zwei Quellen waeren derselbe Fehler
 *      wie A3 der Vorrunde: derselbe Saal hiesse in Tafel, alter Fern-Ansicht und auf Papier
 *      verschieden.
 *   6. DER ENDPUNKT IST VON AUSSEN ZU. Wer den Namen oder die Kennung eines laufenden OP-Saals
 *      aus dem Praxis- oder Gast-WLAN aendern kann, kann jedes Narkoseprotokoll falsch
 *      beschriften.
 *   7. DER NAME VERLAESST DIESEN PC WIRKLICH (Befund C1/C2 der Gegenpruefung). Bis zum 30.07.2026
 *      speicherte dieser Baustein den Namen, zeigte ihn an, meldete Erfolg — und in die Datenbank
 *      ging weiter der Vorlagewert. Geprueft wird deshalb nicht mehr nur, dass es EINE Quelle
 *      gibt, sondern dass der gesetzte Name am anderen Ende ankommt: im Kopf der Saal-Tafel und
 *      am Patienten des Kompatibilitaetsspiegels. Ohne diese Pruefung besteht eine Fassung, die
 *      den Namen nur in eine Datei schreibt, den ganzen Rest dieses Tests.
 *   8. JEDER SATZ DER OBERFLAECHE IST EINE ZUSAGE (Projektregel 1). Die Texte des Admin-Bereichs
 *      versprachen den Saalnamen im Kopf des ausgedruckten Narkoseprotokolls — dort steht er
 *      nicht und stand er nie. Geprueft wird, dass die Oberflaeche das nicht mehr behauptet und
 *      dass sie die Bedingung nennt, unter der ihre Aussage ueberhaupt gilt (Fern-Live an und
 *      angemeldet).
 *   9. WAS EIN KENNUNGSWECHSEL WIRKLICH ANRICHTET (Befund C3), gemessen statt versprochen — und
 *      die drei Texte, die es einem Menschen sagen, gegen die Messung gehalten.
 *
 * OHNE NETZ UND OHNE DIE ECHTE data/station-id.json: alle Dateien liegen in einem temporaeren
 * Ordner, die Registry-Abfrage ist eine Funktion, und der HTTP-Server bindet auf 127.0.0.1 mit
 * Port 0 (das Betriebssystem sucht einen freien).
 *
 * Start: node tools/saalname-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const S = require('../bridge/src/stationsid');
const T = require('../bridge/src/tafel');
const SRV = require('../bridge/src/server');
/* cloud.js gehoert einem anderen Baustein — hierher kommt es trotzdem, und zwar OHNE Netz: der
 * Publisher wird nur gebaut und nach seinen Koerpern gefragt (Abschnitt 5c/5d). Genau an dieser
 * Naht ist der erste Anlauf gescheitert: jede Datei fuer sich war in Ordnung, der Name kam
 * trotzdem nie an. Ein Test, der an der Bausteingrenze haltmacht, haette das nie gesehen. */
const CLOUD = require('../bridge/src/cloud');

/* Die ECHTE Konsole, festgehalten BEVOR unten fuer den Serverabschnitt umgeleitet wird. Ohne das
 * verschwaenden die Pruefzeilen selbst im Auffangpuffer, sobald der Server anfaengt zu reden. */
const ECHT_LOG = console.log.bind(console);

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; ECHT_LOG('  ✓ ' + n); } else { fail++; ECHT_LOG('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function kopf(t) { ECHT_LOG('\n' + t); }

const still = { info() {}, warn() {}, error() {} };
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'vetstation-saal-'));
function datei(n) { return path.join(TMP, n); }
const GUID = '11111111-2222-3333-4444-555555555555';
function guidFest() { return Promise.resolve(GUID); }

const QUELLE = path.join(__dirname, '..');
function lies(...p) { return fs.readFileSync(path.join(QUELLE, ...p), 'utf8'); }

/*
 * Kommentare aus einer Quelle entfernen — WORTGETREU uebernommen aus tools/tafel-test.js:66.
 *
 * Warum eine Kopie und kein gemeinsames Modul: jeder Test in diesem Projekt laeuft fuer sich
 * (node tools/<datei>.js) und darf keinen zweiten Baustein voraussetzen, den jemand nebenher
 * umbaut. Und warum ueberhaupt: die Zaehlung "wie oft wird stationsName() definiert" darf nicht
 * an einem Kommentar haengenbleiben, in dem der Name erklaert wird — sonst zaehlt der Test
 * Prosa und nicht Code. Die Texterkennung achtet auf " ' und `, weil ein '//' innerhalb eines
 * Textes kein Kommentar ist; sie wird an jedem Zeilenende zurueckgesetzt, damit ein
 * Anfuehrungszeichen in einem regulaeren Ausdruck nicht den halben Quelltext verschluckt. Im
 * Zweifel bleibt Text STEHEN — der Irrtum wirkt also in die sichere Richtung (eher ein Vorkommen
 * zu viel, Test wird rot, als eines zu wenig, Test bleibt gruen).
 */
function ohneKommentare(t) {
  const zeilen = String(t == null ? '' : t).split('\n');
  let out = '';
  let imBlock = false;
  for (let z = 0; z < zeilen.length; z++) {
    const zeile = zeilen[z];
    let i = 0;
    let marke = '';
    while (i < zeile.length) {
      const c = zeile[i];
      if (imBlock) {
        if (c === '*' && zeile[i + 1] === '/') { imBlock = false; i += 2; continue; }
        i++; continue;
      }
      if (marke) {
        if (c === '\\') { out += c + (zeile[i + 1] || ''); i += 2; continue; }
        if (c === marke) marke = '';
        out += c; i++; continue;
      }
      if (c === '"' || c === '\'' || c === '`') { marke = c; out += c; i++; continue; }
      if (c === '/' && zeile[i + 1] === '/') break;
      if (c === '/' && zeile[i + 1] === '*') { imBlock = true; i += 2; continue; }
      out += c; i++;
    }
    if (z < zeilen.length - 1) out += '\n';
  }
  return out;
}

function zaehle(text, muster) { return (String(text).match(muster) || []).length; }

ECHT_LOG('VetStation — Saalname: Schreibweg, Erstinbetriebnahme, genau EINE Quelle\n');

/* ============================================================ 1) Die Grenze ist ABGELESEN */
kopf('Die Laengengrenze steht nicht im Code, sie steht in der Regeldatei:');
{
  const roh = lies('installer', 'firebase-rtdb-rules.json');
  const R = JSON.parse(ohneKommentare(roh)).rules.live.$praxis;
  /* Aus einem .validate-Ausdruck die Zahl hinter 'newData.val().length <=' ziehen. */
  const grenze = (v) => {
    const m = /newData\.val\(\)\.length\s*<=\s*(\d+)/.exec(String(v || ''));
    return m ? Number(m[1]) : null;
  };
  const gStation = grenze(R.meta.station['.validate']);
  const gTafelName = grenze(R.tafel.$station.meta.name['.validate']);

  ok('die Regeldatei zieht fuer meta/station eine Laengengrenze', gStation !== null, String(gStation));
  ok('die Regeldatei zieht fuer tafel/<sid>/meta/name eine Laengengrenze', gTafelName !== null, String(gTafelName));
  /*
   * DIE ENTSCHEIDENDE PRUEFUNG. Der Saalname geht an BEIDE Stellen; es gilt die NIEDRIGERE
   * Grenze. Wer NAME_MAX auf die grosszuegigere 400 setzt, baut eine Falle: die Tafel nimmt den
   * Namen an, meta/station weist ihn ab — und weil beide im SELBEN atomaren Koerper stehen,
   * faellt der ganze 1-Hz-Schreibvorgang samt Vitalwerten. Nachgemessen an dieser Zeile.
   */
  ok('NAME_MAX liegt unter BEIDEN Regelgrenzen (' + gStation + ' / ' + gTafelName + ')',
    S.NAME_MAX <= gStation && S.NAME_MAX <= gTafelName, 'NAME_MAX=' + S.NAME_MAX);
  ok('NAME_MAX ist genau die NIEDRIGERE der beiden (keine unnoetige Verschaerfung)',
    S.NAME_MAX === Math.min(gStation, gTafelName), String(S.NAME_MAX));
  /* Zweite Bindung: tafel.js kappt den Spiegelnamen mit derselben Zahl. Laufen die beiden Zahlen
   * auseinander, kappt eine Stelle auf mehr, als die andere durchlaesst. */
  ok('NAME_MAX und tafel.GRENZEN.spiegelStation sind dieselbe Zahl',
    S.NAME_MAX === T.GRENZEN.spiegelStation, S.NAME_MAX + ' vs ' + T.GRENZEN.spiegelStation);
  /* Und der Ersatzname, den tafel.js fuer einen unbenannten Saal einsetzt, muss selbst hindurch
   * passen — sonst ist der Zustand "kein Name" der einzige, der die Uebertragung abwuergt. */
  ok('der Ersatzname fuer einen unbenannten Saal passt in die Grenze',
    T.SPIEGEL_NAME_UNBENANNT.length <= S.NAME_MAX, T.SPIEGEL_NAME_UNBENANNT);
}

/* ============================================================ 2) Formpruefung (rein) */
kopf('Was als Saalname gilt — und was nicht (reine Funktion, ohne Datei):');
ok('kein Text ist kein Name',
  S.nameSauber(null) === null && S.nameSauber(undefined) === null && S.nameSauber(42) === null
  && S.nameSauber({}) === null && S.nameSauber(['OP 1']) === null);
ok('leer und nur Leerraum ist kein Name',
  S.nameSauber('') === null && S.nameSauber('   ') === null && S.nameSauber('\t\n  \r') === null);
ok('ein gewoehnlicher Name bleibt unveraendert', S.nameSauber('OP 2 (Zahn)') === 'OP 2 (Zahn)');
ok('Umlaute und Bindestriche bleiben', S.nameSauber('Röntgen-OP Süd') === 'Röntgen-OP Süd');
/*
 * WOGEGEN DIESER FILTER STEHT: der Saalname wird auf dem Bildschirm eines ANDEREN OP-Saals
 * angezeigt, im Nachbarstreifen neben einer laufenden Narkose. Dieselben Zeichen fallen in
 * tafel.js text() weg; hier ist die Sperre an der QUELLE, weil der volle Name an tafel.js vorbei
 * in PDF-Druckkopf und Firestore-Verlauf geht.
 */
ok('spitze Klammern, Anfuehrungszeichen, Schraegstrich rueckwaerts und Gravis fallen weg',
  S.nameSauber('<b>OP</b> "1" \'x\' \\ ` & OK') === 'bOP/b 1 x OK',
  String(S.nameSauber('<b>OP</b> "1" \'x\' \\ ` & OK')));
{
  /* Steuerzeichen ausdruecklich ueber ihre Zahlwerte, damit in dieser Datei nichts Unsichtbares
   * steht, das beim naechsten Kopieren oder Umformatieren still verlorengeht: 0 = NUL,
   * 9 = Tabulator, 127 = DEL. Genau solche Zeichen kommen ueber einen Geraetestrom herein. */
  const mitSteuer = 'OP' + String.fromCharCode(0) + '1' + String.fromCharCode(9) + 'links' + String.fromCharCode(127);
  ok('Steuerzeichen werden zu Leerraum und dann zusammengezogen',
    S.nameSauber(mitSteuer) === 'OP 1 links', JSON.stringify(S.nameSauber(mitSteuer)));
}
ok('mehrfacher Leerraum wird zusammengezogen und aussen abgeschnitten',
  S.nameSauber('   OP    2     Zahn   ') === 'OP 2 Zahn');
ok('ein zu langer Name wird auf NAME_MAX gekappt',
  S.nameSauber('A'.repeat(300)).length === S.NAME_MAX);
/* Gekappt wird NACH dem Zusammenziehen: sonst entschiede die Zahl der Leerzeichen darueber, wie
 * viel vom Namen uebrig bleibt — aus 'A A A ...' wuerde die Haelfte. */
{
  const g = S.nameSauber('A '.repeat(200));
  ok('gekappt wird nach dem Zusammenziehen, nicht davor',
    g.length <= S.NAME_MAX && g.length > S.NAME_MAX - 3 && g.indexOf('  ') < 0, String(g.length));
}
ok('ein Name aus lauter Sonderzeichen ist kein Name', S.nameSauber('<<<>>>&&&') === null);

/* ============================================================ 3) Die eine Quelle: Reihenfolge */
kopf('stationsName() — die Reihenfolge gesetzt > Vorbelegung > kein Name:');
ok('ohne Station und ohne Vorbelegung: kein Name', S.stationsName(null, null) === null);
ok('ohne Station zaehlt die Vorbelegung', S.stationsName(null, 'OP 3 links') === 'OP 3 links');
/*
 * DER VORLAGEWERT IST KEIN NAME. Er steht in devices.example.json und damit auf JEDER
 * ausgelieferten Station. Wuerde er als Name gelten, waere die Station "benannt" — und der ganze
 * Umbau haette nichts geloest, weil alle Saele wieder gleich hiessen.
 */
ok('der Vorlagewert "' + S.NAME_VORLAGE + '" zaehlt als Vorbelegung NICHT',
  S.stationsName(null, S.NAME_VORLAGE) === null);
ok('der Vorlagewert wird auch mit Leerraum drumherum erkannt',
  S.stationsName(null, '   Praxis OP 1  ') === null);
ok('die Vorbelegung wird ebenfalls gekappt und entschaerft',
  S.stationsName(null, '<b>OP 9</b>') === 'bOP 9/b');

/*
 * SIE WIRFT NIE — und das ist keine Hoeflichkeit mehr, seit cloud.js sie in JEDEM Sendetakt ruft.
 * Eine Ausnahme aus dieser Zeile entstuende mitten im Aufbau des Datenbankkoerpers einer laufenden
 * Narkose. Nachgemessen: die vorherige Fassung rief station.name() nackt auf und warf.
 * WELCHE FALSCHE FASSUNG HIER DURCHFAELLT: genau jene, und ausserdem jede, die den Rueckgabewert
 * von name() ungeprueft durchreicht — ein Objekt statt einer Zeichenkette laesst die Datenbank den
 * ganzen atomaren Koerper samt Vitalwerten abweisen.
 */
/* Eine geworfene Ausnahme wird HIER ABGEFANGEN und zu einem Wert gemacht. Sonst beendet sie den
 * ganzen Testlauf, und die eine Zeile, um die es geht, erschiene nie als ✗ — ein Test, der bei
 * einem Rueckschritt abstuerzt, statt ihn zu benennen, laesst den naechsten Menschen raten.
 * (Nachgemessen in der Mutationsprobe: ohne dieses Netz brach der Lauf an dieser Zeile ab.) */
function ohneWurf(fn) { try { return fn(); } catch (e) { return 'WURF: ' + (e && e.message); } }
ok('eine Station, deren name() wirft, kostet hoechstens den Namen — nie den Sendetakt',
  ohneWurf(() => S.stationsName({ name() { throw new Error('kaputt'); } }, 'OP 4 hinten')) === 'OP 4 hinten');
ok('und ohne Vorbelegung ist das Ergebnis schlicht "kein Name"',
  ohneWurf(() => S.stationsName({ name() { throw new Error('kaputt'); } }, null)) === null);
ok('auch ein werfendes Zugriffsmerkmal (getter) kommt nicht heraus',
  ohneWurf(() => S.stationsName({ get name() { throw new Error('getter'); } }, null)) === null);
ok('was keine Zeichenkette ist, gilt nicht als Name',
  ohneWurf(() => S.stationsName({ name() { return { boese: 1 }; } }, 'OP 5')) === 'OP 5'
  && ohneWurf(() => S.stationsName({ name() { return 42; } }, null)) === null);

/* ============================================================ 4) Datei: setzen, lesen, Neustart */
(async () => {
  kopf('Speichern und Lesen — ueber einen Neustart hinweg:');
  const d1 = datei('a.json');
  const s1 = new S.Stationsid({ log: still, datei: d1, hostname: 'OP-PC-1', machineGuid: guidFest });
  await s1.laden();
  const SID1 = s1.sid();

  ok('eine frisch angelegte Station hat KEINEN Namen (Erstinbetriebnahme)',
    s1.name() === null && s1.hatNamen() === false);
  ok('und stationsName() sagt das auch, wenn die Vorbelegung der Vorlagewert ist',
    S.stationsName(s1, S.NAME_VORLAGE) === null);
  ok('eine echte Vorbelegung wird benutzt, solange kein Name gesetzt ist',
    S.stationsName(s1, 'OP 3 links') === 'OP 3 links');
  ok('der Vorlagewert steht NICHT in der frisch angelegten Datei',
    fs.readFileSync(d1, 'utf8').indexOf(S.NAME_VORLAGE) < 0);
  /* Der Rechnername darf nicht als Saalname einspringen: er verraet in der Praxis regelmaessig
   * Praxis- oder Tierarztnamen und landet sonst in einem Knoten, den jede Fern-Ansicht dauerhaft
   * in den Browser laedt. tools/stationsid-test.js schreibt dasselbe fuer die Datei fest. */
  ok('der Rechnername springt NICHT als Saalname ein',
    S.stationsName(s1, null) === null && String(S.stationsName(s1, null)).indexOf('OP-PC-1') < 0);

  ok('setzeName() gibt den gespeicherten Namen zurueck', s1.setzeName('OP 2 (Zahn)') === 'OP 2 (Zahn)');
  ok('danach hat die Station einen Namen', s1.hatNamen() === true && s1.name() === 'OP 2 (Zahn)');
  /* DER GESETZTE NAME GEWINNT. Sonst haette eine von Hand angelegte devices.json Vorrang vor dem,
   * was ein Mensch an DIESER Station eingetippt hat — und der Saal hiesse nach dem naechsten
   * Kopieren einer Konfigurationsdatei wieder anders. */
  ok('der gesetzte Name schlaegt die Vorbelegung',
    S.stationsName(s1, 'OP 3 links') === 'OP 2 (Zahn)');
  ok('der Name steht in der Datei', JSON.parse(fs.readFileSync(d1, 'utf8')).name === 'OP 2 (Zahn)');
  ok('der Zeitpunkt der Namensgebung ist vermerkt', typeof s1.nameGesetztAm() === 'number');

  // --- NEUSTART: derselbe Ordner, ein neuer Prozess-Ersatz ---
  const s1b = new S.Stationsid({ log: still, datei: d1, hostname: 'OP-PC-1', machineGuid: guidFest });
  await s1b.laden();
  ok('nach dem Neustart ist der Name noch da', s1b.name() === 'OP 2 (Zahn)', String(s1b.name()));
  ok('und die Kennung hat sich dabei NICHT geaendert', s1b.sid() === SID1, s1b.sid() + ' vs ' + SID1);
  ok('die Instanz ist eine andere (es ist wirklich ein zweiter Lauf)', s1b.instanz !== s1.instanz);

  kopf('Kappung — auch ueber den Neustart:');
  const d2 = datei('b.json');
  const s2 = new S.Stationsid({ log: still, datei: d2, hostname: 'OP-PC-2', machineGuid: guidFest });
  await s2.laden();
  const lang = 'Operationssaal ' + 'X'.repeat(300);
  ok('setzeName() gibt die GEKAPPTE Form zurueck (nicht die eingetippte)',
    s2.setzeName(lang) !== lang && s2.setzeName(lang).length === S.NAME_MAX);
  ok('in der Datei steht ebenfalls nur die gekappte Form',
    JSON.parse(fs.readFileSync(d2, 'utf8')).name.length === S.NAME_MAX);
  const s2b = new S.Stationsid({ log: still, datei: d2, hostname: 'OP-PC-2', machineGuid: guidFest });
  await s2b.laden();
  ok('und nach dem Neustart ist sie immer noch gekappt', s2b.name().length === S.NAME_MAX);

  kopf('Formmuell aendert NICHTS — ein laufender Saal verliert seinen Namen nicht:');
  const d3 = datei('c.json');
  const s3 = new S.Stationsid({ log: still, datei: d3, hostname: 'OP-PC-3', machineGuid: guidFest });
  await s3.laden();
  s3.setzeName('OP 1 gross');
  /*
   * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH: eine, die den bereinigten Wert einfach zuweist.
   * Sie machte aus einer versehentlich geleerten Eingabe einen namenlosen Saal — mitten in einer
   * Narkose, waehrend der Name in jeder Fern-Ansicht und im Druckkopf des Protokolls steht.
   */
  ok('eine leere Eingabe wird abgelehnt und laesst den Namen stehen',
    s3.setzeName('   ') === null && s3.name() === 'OP 1 gross');
  ok('eine Zahl wird abgelehnt und laesst den Namen stehen',
    s3.setzeName(42) === null && s3.name() === 'OP 1 gross');
  ok('null wird abgelehnt und laesst den Namen stehen',
    s3.setzeName(null) === null && s3.name() === 'OP 1 gross');
  ok('ein Name aus lauter Sonderzeichen wird abgelehnt',
    s3.setzeName('<<>>&&') === null && s3.name() === 'OP 1 gross');
  ok('ein neuer, gueltiger Name wird uebernommen',
    s3.setzeName(' OP  1   klein ') === 'OP 1 klein' && s3.name() === 'OP 1 klein');

  kopf('Eine von Hand verbastelte station-id.json kann keinen Koerper abweisen lassen:');
  /*
   * data/station-id.json liegt auf einer Windows-Platte und laesst sich mit dem Editor oeffnen —
   * genau so wurde in diesem Projekt bisher konfiguriert. Was dort steht, ist UNGEPRUEFT:
   * istBrauchbar() sieht ausschliesslich auf sid. Ein 5000-Zeichen-Name oder ein '<' geriete
   * ungefiltert in den atomaren 1-Hz-Koerper und liesse ihn samt aller Vitalwerte abweisen.
   */
  const dH = datei('hand.json');
  fs.writeFileSync(dH, JSON.stringify({ sid: 'st7f3a91c2b45d', name: 'B'.repeat(5000) }), 'utf8');
  const sH = new S.Stationsid({ log: still, datei: dH, hostname: 'OP-PC-H', machineGuid: guidFest });
  await sH.laden();
  ok('ein von Hand eingetragener 5000-Zeichen-Name wird beim Laden gekappt',
    sH.name().length === S.NAME_MAX, String(sH.name() && sH.name().length));
  ok('und er steht auch in der Datei nur noch gekappt',
    JSON.parse(fs.readFileSync(dH, 'utf8')).name.length === S.NAME_MAX);
  ok('die Kennung aus der Datei bleibt dabei unveraendert', sH.sid() === 'st7f3a91c2b45d');

  const dH2 = datei('hand2.json');
  fs.writeFileSync(dH2, JSON.stringify({ sid: 'stb1c2d3e4f506', name: { boese: 1 } }), 'utf8');
  const sH2 = new S.Stationsid({ log: still, datei: dH2, hostname: 'OP-PC-H2', machineGuid: guidFest });
  await sH2.laden();
  ok('ein Objekt im Feld name wird geleert, nicht durchgereicht',
    sH2.name() === null && sH2.hatNamen() === false);
  ok('und die Datei traegt danach null statt des Objekts',
    JSON.parse(fs.readFileSync(dH2, 'utf8')).name === null);
  ok('die Kennung ueberlebt auch das', sH2.sid() === 'stb1c2d3e4f506');

  /* Der Lesepfad selbst muss filtern, nicht nur die Migration: wer die Datei im LAUFENDEN Betrieb
   * aendert, umginge eine Pruefung, die nur beim Laden greift. */
  sH2.daten.name = '<img> ' + 'C'.repeat(400);
  ok('auch eine Aenderung NACH dem Laden wird beim Lesen entschaerft und gekappt',
    sH2.name().length === S.NAME_MAX && sH2.name().indexOf('<') < 0, String(sH2.name()).slice(0, 30));

  /* ============================================================ 4b) Der Preis je Sendetakt */
  kopf('Billig genug fuer den Sendetakt — GEMESSEN, nicht geschaetzt:');
  {
    /*
     * WOZU DAS HIER STEHT: bis zu dieser Nachbesserung fragte nur der Admin-Bereich nach dem
     * Namen — ein paarmal am Tag. Seit cloud.js ihn in JEDEM Takt holt, ist der Preis dieser
     * Funktion ein Dauerposten neben einer laufenden Narkose. Gemessen wurden am 30.07.2026 ohne
     * Gedaechtnis: 0,39 us bei einem gewoehnlichen Namen, 16 us bei einem von Hand eingetragenen
     * 5000-Zeichen-Wert und 615 us bei einer 200000 Zeichen langen Vorbelegung. Beide grossen
     * Werte stammen aus Dateien, die ein Mensch mit dem Editor aendert.
     * Die Grenze von 3 us ist mit Absicht weit weg von beiden Seiten: das Ein-Eintrag-Gedaechtnis
     * liegt bei rund 0,1 us (Faktor 30 Luft nach oben), die Fassung ohne Gedaechtnis bei 16 bzw.
     * 615 us (Faktor 5 bzw. 200 daneben). Ein knapper Grenzwert waere auf einem ausgelasteten
     * Praxis-PC eine Wackelpruefung, ein weiter faengt genau den Rueckschritt, um den es geht.
     */
    const dP = datei('preis.json');
    const sP = new S.Stationsid({ log: still, datei: dP, hostname: 'OP-PC-P', machineGuid: guidFest });
    await sP.laden();
    const N = 100000;
    const messen = (fn) => {
      const t0 = process.hrtime.bigint();
      let x = null;
      for (let i = 0; i < N; i++) x = fn();
      return { us: Number(process.hrtime.bigint() - t0) / N / 1000, wert: x };
    };
    sP.daten.name = 'D'.repeat(5000);      // wie eine von Hand verbastelte station-id.json
    const m1 = messen(() => S.stationsName(sP, S.NAME_VORLAGE));
    ok('ein 5000-Zeichen-Rohwert kostet je Aufruf unter 3 us (gemessen ' + m1.us.toFixed(2) + ' us)',
      m1.us < 3, m1.us.toFixed(2) + ' us');
    ok('und das Ergebnis ist trotzdem der gekappte, gepruefte Name',
      m1.wert !== null && m1.wert.length === S.NAME_MAX, String(m1.wert && m1.wert.length));

    sP.daten.name = null;
    const langeVorbelegung = 'Y'.repeat(200000);
    const m2 = messen(() => S.stationsName(sP, langeVorbelegung));
    ok('eine riesige Vorbelegung kostet je Aufruf unter 3 us (gemessen ' + m2.us.toFixed(2) + ' us)',
      m2.us < 3, m2.us.toFixed(2) + ' us');
    ok('und auch sie wird gekappt', m2.wert !== null && m2.wert.length === S.NAME_MAX);

    /*
     * DAS GEDAECHTNIS DARF DIE PRUEFUNG NICHT STUMPF MACHEN. Es vergleicht den ROHWERT: aendert
     * jemand die Datei im laufenden Betrieb, ist der Rohwert ein anderer und es wird neu geprueft.
     * WELCHE FALSCHE FASSUNG HIER DURCHFAELLT: eine, die sich das Ergebnis einmal merkt (oder es
     * beim Laden berechnet) — sie liesse ein spaeter eingetragenes '<' unveraendert in den
     * atomaren Koerper und mit ihm die Vitalwerte abweisen.
     */
    sP.daten.name = '<script>OP 7';
    ok('ein GEAENDERTER Rohwert wird trotz Gedaechtnis neu geprueft und entschaerft',
      sP.name() === 'scriptOP 7', String(sP.name()));
    sP.daten.name = null;
    ok('und zurueck auf "kein Name" geht es auch', sP.name() === null && sP.hatNamen() === false);
  }

  kopf('Der Name ueberlebt eine NEUE Kennung (Ausweg aus einer Doppelkennung):');
  const dU = datei('u.json');
  const sU = new S.Stationsid({ log: still, datei: dU, hostname: 'OP-PC-U', machineGuid: guidFest });
  await sU.laden();
  sU.setzeName('OP 2 (Zahn)');
  const altSid = sU.sid();
  const neuSid = sU.umbenennen(null);
  ok('umbenennen() vergibt eine andere, formgueltige Kennung',
    neuSid !== altSid && S.pruefeSid(neuSid), String(neuSid));
  /* Der Saal heisst weiter "OP 2" — er hat nur eine andere Kennung. Wuerde die Umbenennung den
   * Namen mitnehmen, waere aus einem Ausweg aus der Doppelkennung ein zweites Problem geworden. */
  ok('der SAALNAME bleibt dabei unveraendert', sU.name() === 'OP 2 (Zahn)');
  ok('die alte Kennung ist vermerkt', sU.umbenanntVon().indexOf(altSid) >= 0);

  /* ============================================================ 5) Genau EINE Namensquelle */
  kopf('Genau EINE Namensquelle — im Quelltext nachgezaehlt:');
  {
    const srcDir = path.join(QUELLE, 'bridge', 'src');
    const dateien = fs.readdirSync(srcDir).filter((f) => f.endsWith('.js'));
    let definitionen = 0;
    const woDefiniert = [];
    dateien.forEach((f) => {
      const code = ohneKommentare(fs.readFileSync(path.join(srcDir, f), 'utf8'));
      const n = zaehle(code, /function\s+stationsName\s*\(/g);
      if (n) { definitionen += n; woDefiniert.push(f + '×' + n); }
    });
    /*
     * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH: genau die, die der Plantext vorschlaegt — Tafel
     * rechnet den Namen aus os.hostname(), der flache Spiegel aus cfg.station. Derselbe OP-Saal
     * hiesse dann in der Tafel, in der alten Fern-Ansicht und auf dem ausgedruckten
     * Narkoseprotokoll verschieden, und niemand kann mehr entscheiden, welches Blatt zu welchem
     * Tier gehoert. Das ist Befund A3 der Vorrunde.
     */
    /*
     * WAS DIESE PRUEFUNG NICHT ABDECKT — ausdruecklich benannt, damit niemand mehr aus ihr liest,
     * als sie haelt: sie zaehlt DEFINITIONEN, nicht Benutzer. Genau daran ist der erste Anlauf
     * dieses Bausteins gescheitert: es gab eine einzige Definition, und trotzdem rechnete
     * bridge/src/cloud.js seinen Saalnamen selbst
     *   this.station = CloudPublisher._kurz(this.cfg.station, 120) || 'VetStation'
     * — der gesetzte Name verliess den PC nicht. Die BENUTZER prueft deshalb Abschnitt 5c weiter
     * unten, und zwar am Verhalten und nicht am Text.
     */
    ok('stationsName() wird in bridge/src GENAU EINMAL definiert',
      definitionen === 1, woDefiniert.join(', ') || 'gar nicht');
    ok('und zwar in stationsid.js', woDefiniert.length === 1 && woDefiniert[0].indexOf('stationsid.js') === 0,
      woDefiniert.join(', '));

    const srvCode = ohneKommentare(lies('bridge', 'src', 'server.js'));
    ok('server.js holt den Namen ueber stationsName() und rechnet ihn nicht selbst',
      srvCode.indexOf('stationsName(') >= 0, 'kein Aufruf gefunden');
    ok('server.js kennt den Vorlagewert gar nicht',
      srvCode.indexOf(S.NAME_VORLAGE) < 0);
    ok('server.js benutzt den Rechnernamen nicht als Ersatz',
      srvCode.indexOf('hostname()') < 0);
    /* Die Naht fuer index.js: eine uebergebene Stationsid gewinnt. Zwei Instanzen im selben
     * Prozess wuerden ihre Instanzlisten gegenseitig ueberschreiben und die Kollisionserkennung
     * mit dem eigenen zweiten Prozessteil fuettern. */
    ok('server.js nimmt eine uebergebene Stationsid an, statt immer eine eigene zu bauen',
      /stationsid\s*\|\|\s*new\s+Stationsid\(/.test(srvCode));

    /*
     * DIE NAHT ZUM SENDER (Befund C1). cloud.js darf den Namen nicht mehr selbst ausrechnen —
     * und zwar nachweisbar: JEDES Vorkommen von cfg.station im Code muss das Argument von
     * stationsName() sein. Eine blosse Suche nach 'stationsName(' waere zu schwach: sie bliebe
     * gruen, wenn daneben irgendwo wieder eine zweite Rechnung aus cfg.station entstuende.
     * ('cfg.stationDatei' faellt durch das \b nicht in diese Zaehlung — das ist die Datei der
     * Stationskennung und hat mit dem Namen nichts zu tun.)
     */
    const cloudCode = ohneKommentare(lies('bridge', 'src', 'cloud.js'));
    const cfgStation = zaehle(cloudCode, /cfg\.station\b/g);
    const inQuelle = zaehle(cloudCode, /stationsName\(\s*this\.stationsid\s*,\s*this\.cfg\.station\s*\)/g);
    ok('cloud.js holt den Saalnamen ueber stationsName()', cloudCode.indexOf('stationsName(') >= 0,
      'kein Aufruf gefunden');
    ok('und cfg.station kommt in cloud.js NUR noch als Vorbelegung dort hinein ('
      + cfgStation + ' Vorkommen, ' + inQuelle + ' davon in stationsName)',
      cfgStation >= 1 && cfgStation === inQuelle);
    /* Der erfundene Ersatzname war die zweite Haelfte des Fehlers: er machte aus "kein Name" ein
     * "VetStation" und liess alle Saele aller Praxen wieder gleich heissen. */
    ok('cloud.js erfindet keinen Ersatznamen mehr (|| \'VetStation\')',
      !/\|\|\s*'VetStation'/.test(cloudCode));

    const adminCode = ohneKommentare(lies('ui', 'views', 'admin.js'));
    ok('der Admin-Bereich fragt /api/station und erfindet keinen Ersatznamen',
      adminCode.indexOf('/api/station') >= 0 && adminCode.indexOf(S.NAME_VORLAGE) < 0);

    /*
     * ================= DIE OBERFLAECHE SAGT, WAS WIRKLICH PASSIERT (Befund C2) =================
     *
     * Geprueft wird der TEXT, den ein Tierarzt liest — nicht der Kommentar daneben (ohneKommentare
     * hat den entfernt). Das ist kein Kosmetikpunkt: die Aussage "der Name erscheint im Kopf des
     * Narkoseprotokolls" stand an genau der Stelle, an der er sie glaubt, waehrend er zwei
     * Ausdrucke beschriftet.
     *
     * BIS 1.0.3 war die Zusage FALSCH und dieser Block hat sie festgehalten: der PDF-Kopf trug die
     * harte Konstante 'VetStation', station() gab sie unveraendert zurueck, ein Saalname kam nicht
     * vor. Geprueft wurde deshalb, dass die Oberflaeche das auch SAGT.
     *
     * SEIT 1.1.0 ist es umgekehrt (31.07.2026): mit mehreren OP-Saelen im selben Praxis-Konto ist
     * ein Ausdruck ohne Saalangabe ein Mangel am Dokument — zwei Protokolle desselben Tages, aus
     * verschiedenen Saelen, mit identischer Kopfzeile. station() liest jetzt Saalname und
     * Kennungs-Kurzform aus /api/station, also aus derselben einen Quelle wie Tafel und
     * Fern-Ansicht. Der Block prueft weiterhin dasselbe Prinzip — die Oberflaeche muss sagen, was
     * wirklich passiert —, nur ist die Wahrheit jetzt eine andere.
     */
    const pdfCode = lies('ui', 'vetstation-live.js');
    const pdfOhneKomm = ohneKommentare(pdfCode);
    ok('Voraussetzung dieser Pruefung: der PDF-Kopf traegt den Saalnamen aus /api/station',
      /function\s+station\s*\(\)\s*\{[\s\S]{0,400}state\.saal/.test(pdfOhneKomm)
      && pdfOhneKomm.indexOf('api/station') >= 0,
      'ui/vetstation-live.js hat sich geaendert — dann gehoeren die Texte NEU geprueft');
    /* Faellt die Auskunft aus, darf der Ausdruck nicht auf eine Antwort warten und nicht mit einem
     * leeren Kopf herauskommen. Der alte Wert ist dann der ehrliche Rueckfall. */
    ok('ohne geladene Auskunft faellt der Kopf auf "VetStation" zurueck statt leer zu bleiben',
      /function\s+station\s*\(\)\s*\{[\s\S]{0,400}return\s+'VetStation'/.test(pdfOhneKomm));
    /* Die Kennung MUSS daneben stehen: zwei Saele koennen denselben Namen tragen, und auf einem
     * Ausdruck aus der Akte ist sie das einzige, was sie dann noch unterscheidet. */
    ok('und die Kurzform der Stationskennung steht daneben',
      /function\s+station\s*\(\)\s*\{[\s\S]{0,400}s\.kurz/.test(pdfOhneKomm));
    /* wohinDerName() ist die EINE Stelle, an der die Oberflaeche behauptet, wohin der Name geht.
     * Sie muss die Verneinung tragen (sonst faellt die alte Zusage still wieder ein) und die
     * Bedingung nennen, unter der der Rest ueberhaupt gilt. */
    const wohin = /function\s+wohinDerName\s*\(([\s\S]*?)\n  \}/.exec(adminCode);
    ok('es gibt genau eine Stelle, die sagt wohin der Name geht (wohinDerName)',
      !!wohin && zaehle(adminCode, /function\s+wohinDerName\s*\(/g) === 1);
    const wohinText = wohin ? wohin[1] : '';
    ok('sie sagt ausdruecklich, dass der Name im Kopf des Ausdrucks steht (seit 1.1.0 wahr)',
      /Kopf des ausgedruckten\s*'?\s*\+?\s*'?Narkoseprotokolls/.test(wohinText.replace(/\s+/g, ' ')),
      wohinText.slice(0, 120));
    ok('und sie nennt die Stationskennung als Unterscheidung bei gleichem Saalnamen',
      /Stationskennung/.test(wohinText));
    /* Die alte, jetzt falsche Verneinung darf NICHT stehenbleiben. Sie stand zwei Fassungen lang
     * da und war beide Male die Aussage, an der sich ein Tierarzt orientiert hat. */
    ok('die alte Verneinung ist verschwunden',
      !/ausgedruckten Narkoseprotokoll steht er nicht/.test(adminCode));
    ok('sie nennt die Bedingung Fern-Live in JEDEM ihrer Faelle',
      zaehle(wohinText, /Fern-Live/g) >= 4, String(zaehle(wohinText, /Fern-Live/g)));
    ok('und sie liest den Zustand dieser Bedingung aus /api/station statt ihn zu unterstellen',
      /s\.fern/.test(wohinText) && /fern:\s*fernLage\(\)/.test(srvCode));
    /*
     * WELCHE FALSCHE FASSUNG HIER DURCHFAELLT: die vorherige. Sie versprach dem Tierarzt den
     * Saalnamen "in der Tafel, in der Web-Ansicht, auf dem Nachbar-Bildschirm und im Kopf des
     * Narkoseprotokolls" — vier Orte, an denen er zu diesem Zeitpunkt an keinem einzigen stand.
     * Die Suche laeuft ueber die ANGEZEIGTEN Texte des ganzen Reiters; im Abschnitt ueber die
     * Stationskennung darf das Narkoseprotokoll vorkommen (dort wird es wirklich geteilt),
     * deshalb wird auf die zusagende Wendung geprueft und nicht auf das Wort.
     */
    ok('nirgends in der Oberflaeche steht mehr, der Name erscheine auf dem Ausdruck',
      !/(erscheint|steht)[^.<]{0,120}Kopf des (ausgedruckten )?Narkoseprotokolls/.test(adminCode)
      && !/Kopf des Narkoseprotokolls/.test(lies('ui', 'index.html')),
      'die alte Zusage ist zurueck');
    ok('die Oberflaeche hat den Balken der Erstinbetriebnahme',
      lies('ui', 'index.html').indexOf('vsxSaalHint') >= 0
      && adminCode.indexOf('vsxSaalHint') >= 0);
    /* NICHTS BLOCKIEREND: der Hinweis ist ein Balken, kein Dialog. Ein Pflichtdialog vor der
     * Ueberwachung stuende im schlechtesten Fall zwischen dem Tierarzt und einem narkotisierten
     * Patienten. Nachgewiesen daran, dass die Oberflaeche dafuer weder alert/confirm/prompt noch
     * einen Sperrbildschirm benutzt — die einzigen confirm() im Admin-Bereich haengen an
     * Knoepfen, die ein Mensch ausdruecklich drueckt. */
    ok('der Hinweis blockiert nichts: kein Zwangsdialog beim Laden der Oberflaeche',
      /saalHinweisStarten/.test(adminCode)
      && !/saalHinweisStarten[\s\S]{0,600}?(alert|prompt)\s*\(/.test(adminCode));
  }

  /* ============================================================ 5b) Der Balken ist SICHTBAR */
  kopf('Der Balken liegt nicht hinter der Leiste — die Hoehen gehen auf:');
  {
    /*
     * NACHGEMESSEN UND DESHALB GEPRUEFT: in der ersten Fassung stand der Balken im normalen
     * Textfluss. #vsxBar ist aber position:fixed mit z-index 9999 — im Browser hatte der Balken
     * daraufhin exakt dieselbe Flaeche wie die Leiste (0,0,1280,48), war unsichtbar und sein
     * Knopf nicht anklickbar. Ein Hinweis, den niemand sieht, ist kein Hinweis; und ein Test, der
     * nur nachsieht, ob das Element im HTML vorkommt, haette das nie bemerkt.
     * Geprueft wird deshalb die RECHNUNG: jede Verschiebung ist die Summe der Hoehen darueber.
     */
    const css = lies('ui', 'vetstation-shell.css');
    const regel = (wahl) => {
      const m = new RegExp(wahl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*\\{([^}]*)\\}').exec(css);
      return m ? m[1] : null;
    };
    const zahl = (block, feld) => {
      if (!block) return null;
      const m = new RegExp(feld + '\\s*:\\s*(-?\\d+)px').exec(block);
      return m ? Number(m[1]) : null;
    };
    const bar = regel('#vsxBar');
    const test = regel('#vsxTestBanner');
    const saal = regel('#vsxSaalHint');
    const hBar = zahl(bar, 'height'), hTest = zahl(test, 'height'), hSaal = zahl(saal, 'height');

    ok('alle drei Balken haben eine feste Hoehe (sonst ist keine Rechnung moeglich)',
      hBar > 0 && hTest > 0 && hSaal > 0, hBar + '/' + hTest + '/' + hSaal);
    ok('der Balken ist fest positioniert und liegt damit NICHT hinter der Leiste',
      /position\s*:\s*fixed/.test(saal || ''), String(saal).slice(0, 60));
    ok('er beginnt genau unter der Leiste', zahl(saal, 'top') === hBar,
      zahl(saal, 'top') + ' statt ' + hBar);
    ok('mit Test-Balken darueber beginnt er unter beiden',
      zahl(regel('html.vsx-test #vsxSaalHint'), 'top') === hBar + hTest,
      String(zahl(regel('html.vsx-test #vsxSaalHint'), 'top')));
    /* Und der Inhalt DARUNTER muss nachruecken, sonst verdeckt der Balken den oberen Rand des
     * ersten Patientenfensters — waehrend einer Narkose die falsche Stelle zum Platzsparen. */
    ['#vsxGrid', '.vsx-hint'].forEach((was) => {
      ok('mit Balken rueckt ' + was + ' um dessen Hoehe nach',
        zahl(regel('html.vsx-saal ' + was), 'top') === hBar + hSaal,
        String(zahl(regel('html.vsx-saal ' + was), 'top')) + ' statt ' + (hBar + hSaal));
      ok('mit BEIDEN Balken rueckt ' + was + ' um beide Hoehen nach',
        zahl(regel('html.vsx-test.vsx-saal ' + was), 'top') === hBar + hTest + hSaal,
        String(zahl(regel('html.vsx-test.vsx-saal ' + was), 'top')) + ' statt ' + (hBar + hTest + hSaal));
    });
    /* Die Klasse am <html> ist es, die das Nachruecken ausloest — genau wie beim Test-Balken. */
    ok('admin.js setzt die Klasse vsx-saal am <html>, wenn der Name fehlt',
      /classList\.toggle\('vsx-saal'/.test(ohneKommentare(lies('ui', 'views', 'admin.js'))));
  }

  /* ====================================================== 5c) Der Name kommt am anderen Ende an
   *
   * DIE PRUEFUNG, DIE GEFEHLT HAT. Alles darueber war gruen, waehrend der gesetzte Name diesen PC
   * nie verliess: der Admin-Bereich speicherte ihn, zeigte ihn, meldete Erfolg — und in Tafel,
   * Kompatibilitaetsspiegel und Firestore-Verlauf stand weiter der Vorlagewert, den JEDE
   * ausgelieferte Station traegt. Zwei OP-Saele hiessen also weiter gleich, und der einzige
   * Hinweis, der davor gewarnt haette, war durch die Eingabe gerade abgeschaltet worden.
   *
   * OHNE NETZ: der Publisher wird gebaut und nach seinen Koerpern gefragt; _write ist fuer den
   * Tafelkopf durch eine Auffangfunktion ersetzt. Kein Socket, kein Konto, keine Anmeldung.
   */
  kopf('Der gesetzte Name verlaesst diesen PC — an den echten Modulen gemessen:');
  {
    const dE = datei('e2e.json');
    const stE = new S.Stationsid({ log: still, datei: dE, hostname: 'OP-PC-E', machineGuid: guidFest });
    await stE.laden();
    const sidE = stE.sid();
    /* Die Vorbelegung ist der VORLAGEWERT — der Auslieferstand. Genau hier hat die alte Fassung
     * ihren Namen hergenommen. */
    const pubE = new CLOUD.CloudPublisher(
      { enabled: false, station: S.NAME_VORLAGE, dbUrl: 'https://beispiel.invalid/', apiKey: 'x' },
      { log: still, stationsid: stE });
    const schnapp = { patients: { p1: { patientId: 'Rex', hr: 88, ts: 5 } } };
    const spiegelPatient = () => pubE._spiegelPfade(schnapp, sidE, { mehrsaal: true, kurven: false })
      .get('patients/s' + S.sidKurz(sidE) + '__p1/patientId');

    ok('Voraussetzung: der Publisher nimmt diese Stationskennung an', pubE.stationsid === stE);
    /*
     * DAS FELD, MIT DEM DIE AUSGELIEFERTE WEB-APP BEANTWORTET, WELCHES TIER IN WELCHEM SAAL LIEGT.
     * Solange die Station unbenannt ist, darf dort NICHT der Vorlagewert stehen: er steht auf
     * jeder Station, er unterscheidet nichts, und er behauptet einen Namen, den niemand vergeben
     * hat.
     */
    ok('ohne gesetzten Namen traegt der Patient im Spiegel keinen Vorlagewert',
      String(spiegelPatient()).indexOf(S.NAME_VORLAGE) < 0, String(spiegelPatient()));

    stE.setzeName('OP 2 (Zahn)');
    ok('der GESETZTE Name steht am Patienten des Kompatibilitaetsspiegels',
      spiegelPatient() === 'Rex · OP 2 (Zahn)', String(spiegelPatient()));
    /*
     * WELCHE FALSCHE FASSUNG HIER DURCHFAELLT: die naheliegende Reparatur — den Namen EINMAL im
     * Konstruktor holen. Sie besteht die Zeile darueber und faellt hier: der Name wird im
     * laufenden Betrieb gesetzt (POST /api/station/name ist mitten in einer Narkose erlaubt), und
     * beim Bau des Publishers ist die Kennungsdatei ueberdies oft noch gar nicht geladen.
     */
    stE.setzeName('OP 9 rechts');
    ok('eine Umbenennung IM LAUFENDEN BETRIEB kommt sofort mit',
      spiegelPatient() === 'Rex · OP 9 rechts', String(spiegelPatient()));

    /* Und derselbe Name im Kopf der Saal-Tafel — das ist der Knoten, aus dem jeder andere
     * Bildschirm im Haus erfaehrt, wie dieser Saal heisst. */
    let koerper = null;
    pubE._write = (m, ziel, body) => { koerper = body; return Promise.resolve({}); };
    pubE._tafelSchreiben({ sid: sidE, jetzt: Date.now(), patients: [], devices: [], darf: true, ziel: '/x.json' });
    const kopfSatz = koerper ? koerper['tafel/' + sidE + '/meta'] : null;
    ok('der Tafelkopf dieses Saals traegt denselben Namen',
      !!kopfSatz && kopfSatz.name === 'OP 9 rechts', JSON.stringify(kopfSatz && kopfSatz.name));
    ok('und er traegt die eigene Kennung (sonst weist die Regel den ganzen Koerper ab)',
      !!kopfSatz && kopfSatz.sid === sidE);
  }

  /* ====================================================== 5d) Was ein Kennungswechsel anrichtet
   *
   * Befund C3. Zwei Rueckfragen, ein Absatz und ein Kommentar sagten zu: "Geloescht wird nichts."
   * Gemessen wird beim naechsten Sendetakt jeder Live-Wert des alten Saals auf null gesetzt.
   * DIESER TEST HAELT DIE GEMESSENE FOLGE FEST — und die Texte daneben. Wer das Verhalten aendert
   * (cloud.js beim Kennungswechsel sein Gedaechtnis zuruecksetzen laesst), macht ihn rot und wird
   * damit auf die drei Texte gestossen, die dann falsch werden. Das ist die Absicht.
   */
  kopf('Ein Kennungswechsel — die gemessene Folge und die Texte, die sie einem Menschen sagen:');
  {
    const dK = datei('kennung.json');
    const stK = new S.Stationsid({ log: still, datei: dK, hostname: 'OP-PC-K', machineGuid: guidFest });
    await stK.laden();
    stK.setzeName('OP 1 gross');
    const altSid = stK.sid();
    const pubK = new CLOUD.CloudPublisher(
      { enabled: false, station: S.NAME_VORLAGE, dbUrl: 'https://beispiel.invalid/', apiKey: 'x' },
      { log: still, stationsid: stK });
    const schnapp = { patients: { p1: { patientId: 'Rex', hr: 88, ts: 5 } } };
    // Der Stand, den ein laufender Saal vor dem Wechsel uebertragen hat.
    pubK._gesendet = pubK._alsStand(pubK._pfade(schnapp, altSid));

    const neuSid = stK.umbenennen(null);
    const plan = pubK._delta(pubK._pfade(schnapp, neuSid), pubK._gesendet,
      'saele/' + neuSid + '/patients/', new Set(['p1']), false, null);
    const alteWege = Object.keys(plan).filter((p) => p.indexOf('saele/' + altSid + '/') === 0);

    ok('die LIVE-Werte der alten Kennung werden im naechsten Takt entfernt',
      alteWege.length > 0 && alteWege.every((p) => plan[p] === null),
      alteWege.length + ' Pfade: ' + alteWege.slice(0, 3).join(', '));
    ok('dieselben Werte stehen zugleich unter der NEUEN Kennung',
      plan['saele/' + neuSid + '/patients/p1/hr'] === 88);
    /* Das Protokoll wird NICHT angefasst — es ist unveraenderlich, und die Regel laesst ein
     * Ueberschreiben gar nicht zu. Es wird nur GETEILT. */
    ok('keine einzige Protokollzeile wird dabei geloescht',
      Object.keys(plan).every((p) => p.indexOf('/protokoll/') < 0));
    ok('die weiteren Protokollzeilen gehen unter die neue Kennung (das Protokoll wird geteilt)',
      pubK._protokollZiele('protokoll/pid1/1700', neuSid)[0] === 'saele/' + neuSid + '/protokoll/pid1/1700',
      JSON.stringify(pubK._protokollZiele('protokoll/pid1/1700', neuSid)));
    ok('und der SAALNAME ueberlebt den Wechsel unveraendert', stK.name() === 'OP 1 gross');

    /*
     * DIE DREI TEXTE. Sie sind das, was ein Mensch beim Druecken des Knopfes liest — und sie
     * standen im Widerspruch zur Messung darueber. Geprueft wird der ausgegebene Text (Kommentare
     * sind entfernt), nicht die Prosa daneben.
     */
    const adminOhne = ohneKommentare(lies('ui', 'views', 'admin.js'));
    const stationsidOhne = ohneKommentare(lies('bridge', 'src', 'stationsid.js'));
    ok('keiner der Texte verspricht mehr "geloescht wird nichts"',
      !/[Gg]el(ö|oe)scht wird nichts/.test(adminOhne) && !/[Gg]el(ö|oe)scht wird nichts/.test(stationsidOhne));
    ok('die Rueckfrage im Admin-Bereich nennt die Folge fuer die laufenden Werte',
      /laufenden Werte werden dort entfernt/.test(adminOhne));
    ok('und sie sagt zugleich, dass das Narkoseprotokoll bleibt und geteilt wird',
      /Narkoseprotokoll bleibt/.test(adminOhne) && /geteilt/.test(adminOhne));
    /* Gesucht wird in KURZEN Stuecken: die Logzeile ist ueber mehrere Zeichenketten
     * zusammengesetzt, ein langer Satz stuende nie am Stueck im Quelltext. */
    ok('das Logbuch der Station sagt dasselbe',
      /LIVE-Werte/.test(stationsidOhne) && /werden dabei entfernt/.test(stationsidOhne)
      && /Narkoseprotokoll bleibt vollstaendig erhalten/.test(stationsidOhne));
  }

  /* ============================================================ 6) Der Endpunkt ueber HTTP */
  kopf('Die Sperre gegen fremde Adressen (reine Funktion, ohne Netz):');
  ok('127.0.0.1 gilt als lokal', SRV.istLokaleAdresse('127.0.0.1') === true);
  ok('die beiden IPv6-Schreibweisen von localhost gelten als lokal',
    SRV.istLokaleAdresse('::1') === true && SRV.istLokaleAdresse('::ffff:127.0.0.1') === true);
  /*
   * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH: ein Praefixvergleich auf '127.'. Der wirkt richtig
   * und ist es nicht — er laesst jede Adresse durch, die nur so BEGINNT.
   */
  ok('ein Rechner im Praxisnetz gilt NICHT als lokal',
    SRV.istLokaleAdresse('192.168.0.55') === false
    && SRV.istLokaleAdresse('::ffff:192.168.0.55') === false
    && SRV.istLokaleAdresse('10.0.5.12') === false);
  ok('eine andere Rueckschleifen-Adresse gilt NICHT als lokal',
    SRV.istLokaleAdresse('127.0.0.2') === false);
  ok('ein Name, der nur mit 127.0.0.1 BEGINNT, gilt NICHT als lokal',
    SRV.istLokaleAdresse('127.0.0.1.beispiel.invalid') === false);
  ok('leer und Unfug gelten NICHT als lokal',
    SRV.istLokaleAdresse('') === false && SRV.istLokaleAdresse(undefined) === false);

  await serverAbschnitt();
  await serverMitVorbelegung();

  ECHT_LOG('\n---------------------------------------------------------------');
  if (fail === 0) ECHT_LOG('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
  else ECHT_LOG(fail + ' von ' + (pass + fail) + ' PRUEFUNGEN FEHLGESCHLAGEN');
  aufraeumen();
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  ECHT_LOG('\n✗ Testfehler: ' + (e && e.stack || e));
  aufraeumen();
  process.exit(1);
});

function aufraeumen() {
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (_) {}
}

/* ---------------------------------------------------------------- der echte HTTP-Weg */
async function serverAbschnitt() {
  kopf('Der echte Endpunkt: POST /api/station/name und /api/station/kennung/neu');

  const dS = datei('server.json');
  const stationsid = new S.Stationsid({ log: still, datei: dS, hostname: 'OP-PC-S', machineGuid: guidFest });
  await stationsid.laden();
  const sidVorher = stationsid.sid();

  /*
   * EINE STELLVERTRETER-REGISTRY. Der Server braucht sie nur, um seinen 350-ms-Rundruf zu fahren;
   * die echte wuerde bridge/data/protokoll.json beschreiben, und ein Test hat in den
   * Narkoseprotokollen dieses PCs nichts verloren.
   * Die Vorbelegung kommt als cloud.cfg.station herein — genau der Weg, den server.js benutzt.
   */
  const registry = {
    adapters: [],
    getDevices() { return []; },
    getPatients() { return []; },
    protokollSchritt() {},
    protokollFuerCloud() { return []; },
    protokollVon() { return {}; },
    protokollListe() { return []; },
    getRoh() { return []; },
    getRohNachrichten() { return []; },
  };
  const cloud = {
    cfg: { enabled: false, station: 'Praxis OP 1' },
    minInterval: 1000,
    status() { return { enabled: false }; },
    befundTitel() { return null; },
    publish() {},
  };

  /* Der Server redet ueber logger.js direkt in die Konsole. Die Zeilen werden AUFGEFANGEN statt
   * unterdrueckt: sie gehoeren bei einem Fehlschlag zur Diagnose, aber nicht zwischen die
   * Pruefzeilen. ok() und kopf() schreiben ueber ECHT_LOG und sind davon unberuehrt. */
  const gefangen = [];
  const echtLog = console.log, echtErr = console.error;
  console.log = (...a) => gefangen.push(a.join(' '));
  console.error = (...a) => gefangen.push(a.join(' '));

  let srv = null;
  let port = 0;
  try {
    srv = SRV.startServer({ port: 0, host: '127.0.0.1', registry, version: '1.1.0-test', cloud, stationsid });
    port = await new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('Server hoerte nicht innerhalb von 5 s')), 5000);
      srv.httpServer.on('listening', () => { clearTimeout(t); resolve(srv.httpServer.address().port); });
      srv.httpServer.on('error', (e) => { clearTimeout(t); reject(e); });
    });

    await pruefungenAmLaufendenServer();
  } finally {
    console.log = echtLog; console.error = echtErr;
    try { if (srv) srv.stop(); } catch (_) {}
    if (fail) { ECHT_LOG('\n  (Ausgabe des Servers waehrend des Tests:)'); gefangen.forEach((z) => ECHT_LOG('   | ' + z)); }
  }

  function anfrage(o) {
    return new Promise((resolve) => {
      const opt = {
        host: '127.0.0.1', port: port, path: o.pfad, method: o.method || 'GET',
        timeout: 4000, headers: {},
      };
      // Der Absender wird ueber die QUELLADRESSE des Sockets gestellt — genau die Groesse, auf die
      // istLokal() sieht. 127.0.0.2 ist eine Rueckschleifen-Adresse und damit ohne Netz erreichbar,
      // aber sie ist NICHT 127.0.0.1: fuer den Server ist das ein fremder Rechner.
      if (o.von) opt.localAddress = o.von;
      /* Seit 1.2.4 verlangt der Server bei SCHREIBENDEN Wegen Content-Type: application/json —
       * das ist der Riegel gegen eine fremde Webseite im Browser des Praxis-PCs (sie kann per
       * no-cors nur "einfache" Anfragen stellen, und die tragen text/plain). Deshalb setzt der
       * Test den Kopf ab jetzt bei jedem POST, nicht nur wenn ein Koerper dabei ist — und
       * weiter unten wird ausdruecklich geprueft, dass es OHNE ihn abgelehnt wird. */
      if (o.ohneTyp !== true && (o.koerper != null || (o.method || 'GET') === 'POST')) {
        opt.headers['Content-Type'] = 'application/json';
      }
      if (o.herkunft) opt.headers['Origin'] = o.herkunft;
      const req = http.request(opt, (r) => {
        let s = '';
        r.on('data', (c) => { s += c; });
        r.on('end', () => {
          let j = null; try { j = JSON.parse(s); } catch (_) {}
          resolve({ code: r.statusCode, text: s, json: j, kopf: r.headers });
        });
      });
      req.on('error', (e) => resolve({ code: 0, fehler: e.message }));
      req.on('timeout', () => { req.destroy(); resolve({ code: 0, fehler: 'Zeitablauf' }); });
      if (o.koerper != null) req.end(o.koerper); else req.end();
    });
  }

  async function pruefungenAmLaufendenServer() {
    // --- der Normalfall: vom Praxis-PC selbst ---
    const a1 = await anfrage({ pfad: '/api/station' });
    ok('GET /api/station antwortet vom Praxis-PC', a1.code === 200 && a1.json && a1.json.bereit === true,
      a1.code + ' ' + String(a1.text).slice(0, 120));
    ok('und meldet die Station als unbenannt (Vorbelegung ist nur der Vorlagewert)',
      a1.json && a1.json.gesetzt === false && a1.json.name === null, JSON.stringify(a1.json));
    ok('die Vorbelegung wird sichtbar mitgeschickt, nicht heimlich benutzt',
      a1.json && a1.json.vorbelegung === 'Praxis OP 1');
    /* jsonPrivat: ohne diese Kopfzeile kann keine fremde Webseite im Browser des Praxis-PCs die
     * Antwort auslesen — sie nennt Kennung und Schluessel-Fingerabdruck. */
    ok('die Antwort traegt KEIN Access-Control-Allow-Origin',
      a1.kopf['access-control-allow-origin'] === undefined, String(a1.kopf['access-control-allow-origin']));
    ok('die Antwort enthaelt weder Rechnername noch privaten Schluessel',
      a1.text.indexOf('OP-PC-S') < 0 && a1.text.indexOf('priv') < 0);

    const a2 = await anfrage({ pfad: '/api/station/name', method: 'POST', koerper: JSON.stringify({ name: 'OP 2 (Zahn)' }) });
    ok('POST /api/station/name speichert den Namen',
      a2.code === 200 && a2.json && a2.json.ok === true && a2.json.name === 'OP 2 (Zahn)',
      a2.code + ' ' + String(a2.text).slice(0, 160));
    ok('die Station selbst kennt den Namen jetzt auch', stationsid.name() === 'OP 2 (Zahn)');
    /*
     * DIE VERBINDUNG ZWISCHEN ENDPUNKT UND EINZIGER QUELLE: was der Endpunkt herausgibt, MUSS
     * Zeichen fuer Zeichen das sein, was stationsName() liefert. Sonst zeigt der Admin-Bereich
     * einen anderen Namen als Tafel und Spiegel — und dann glaubt ein Mensch, sein Name sei
     * angekommen, waehrend in der Fern-Ansicht ein anderer steht.
     */
    ok('der Endpunkt gibt exakt aus, was stationsName() liefert',
      a2.json.auskunft.name === S.stationsName(stationsid, cloud.cfg.station),
      a2.json.auskunft.name + ' vs ' + S.stationsName(stationsid, cloud.cfg.station));
    ok('und der gesetzte Name schlaegt die Vorbelegung auch ueber HTTP',
      a2.json.auskunft.name === 'OP 2 (Zahn)' && a2.json.auskunft.gesetzt === true);

    const a3 = await anfrage({ pfad: '/api/station/name', method: 'POST', koerper: JSON.stringify({ name: '   ' }) });
    ok('ein leerer Name wird ueber HTTP abgelehnt und aendert nichts',
      a3.code === 200 && a3.json && a3.json.ok === false && stationsid.name() === 'OP 2 (Zahn)',
      String(a3.text).slice(0, 160));
    const a4 = await anfrage({ pfad: '/api/station/name', method: 'POST', koerper: 'kein json' });
    ok('unlesbarer Koerper wird abgelehnt und aendert nichts',
      a4.json && a4.json.ok === false && stationsid.name() === 'OP 2 (Zahn)');
    const a5 = await anfrage({ pfad: '/api/station/name', method: 'POST', koerper: JSON.stringify({ name: 'D'.repeat(500) }) });
    ok('ein zu langer Name wird angenommen, aber gekappt gespeichert',
      a5.json && a5.json.ok === true && a5.json.name.length === S.NAME_MAX,
      String(a5.json && a5.json.name && a5.json.name.length));

    /*
     * EIN UEBERLANGER KOERPER BEKOMMT SEINEN EIGENEN GRUND (Befund C4). Vorher wurde bei
     * Ueberlaenge roh geleert und null zurueckgegeben; JSON.parse(null || '{}') ergab {} — also
     * KEIN Formfehler —, und der Tierarzt las "Bitte einen Saalnamen eingeben". Er hatte einen
     * eingegeben, er war nur zu lang; die naechste Handlung nach dieser Meldung ist, denselben
     * Namen noch einmal einzutippen.
     * WELCHE FALSCHE FASSUNG HIER DURCHFAELLT: genau jene — sie antwortet mit dem Satz ueber die
     * erlaubten Zeichen statt mit dem wirklichen Grund.
     */
    const gross = await anfrage({
      pfad: '/api/station/name', method: 'POST',
      koerper: JSON.stringify({ name: 'E'.repeat(4000) }),
    });
    ok('ein zu langer KOERPER wird mit dem wirklichen Grund beantwortet',
      gross.json && gross.json.ok === false && /zu lang/i.test(String(gross.json.fehler))
      && /2048/.test(String(gross.json.fehler)), String(gross.text).slice(0, 200));
    ok('und der Saalname ist danach unveraendert',
      stationsid.name() === S.nameSauber('D'.repeat(500)), String(stationsid.name()).slice(0, 20));
    /* Die Frist gegen eine Verbindung, die 'end' nie sendet, laesst sich ohne 10 s Wartezeit nicht
     * am Verhalten pruefen — deshalb an der Quelle, und nur so eng wie noetig: es muss eine Frist
     * geben und sie muss auf JEDEM Weg wieder abgebaut werden. */
    const leseFn = /function leseKoerper\([\s\S]*?\n  \}/.exec(ohneKommentare(lies('bridge', 'src', 'server.js')));
    ok('leseKoerper hat eine Frist und raeumt sie wieder ab',
      !!leseFn && /setTimeout\(/.test(leseFn[0]) && /clearTimeout\(/.test(leseFn[0]));

    await anfrage({ pfad: '/api/station/name', method: 'POST', koerper: JSON.stringify({ name: 'OP 2 (Zahn)' }) });

    /*
     * DIE BEDINGUNG, UNTER DER DER NAME DIESEN PC UEBERHAUPT VERLAESST (Befund C2). Der
     * Admin-Bereich schreibt sie hin; ihren ZUSTAND holt er von hier. Geprueft wird, dass er
     * wirklich von cloud.status() kommt und nicht im Server nachgerechnet wird.
     */
    const fern1 = await anfrage({ pfad: '/api/station' });
    ok('die Auskunft nennt den Zustand von Fern-Live',
      fern1.json && fern1.json.fern && fern1.json.fern.eingeschaltet === false
      && fern1.json.fern.sendet === false, JSON.stringify(fern1.json && fern1.json.fern));
    const echteStatus = cloud.status;
    cloud.status = () => ({ enabled: true, started: true, angemeldet: true });
    const fern2 = await anfrage({ pfad: '/api/station' });
    ok('schaltet Fern-Live um, sagt die Auskunft das auch',
      fern2.json && fern2.json.fern && fern2.json.fern.sendet === true,
      JSON.stringify(fern2.json && fern2.json.fern));
    /* Und ein Fern-Live, das beim Fragen stolpert, darf die Auskunft ueber den eigenen Saal nicht
     * kosten: ueber sie laeuft das Setzen des Namens. */
    cloud.status = () => { throw new Error('Fern-Live kaputt'); };
    const fern3 = await anfrage({ pfad: '/api/station' });
    ok('ein werfendes cloud.status() kostet die Saalauskunft nicht',
      fern3.code === 200 && fern3.json && fern3.json.bereit === true
      && fern3.json.fern.sendet === false, String(fern3.text).slice(0, 120));
    cloud.status = echteStatus;

    const a6 = await anfrage({ pfad: '/api/station/name' });
    ok('GET auf /api/station/name gibt 405 (ein Zustandswechsel gehoert nicht in ein GET)',
      a6.code === 405, String(a6.code));

    // --- der Ernstfall: NICHT vom Praxis-PC ---
    /*
     * WOGEGEN DAS STEHT: der Name und die Kennung eines OP-Saals bestimmen, unter welcher
     * Ueberschrift ein Narkoseprotokoll ausgedruckt wird und welcher Saal in der Fern-Ansicht
     * welche Werte zeigt. Waere der Endpunkt aus dem Praxis- oder Gast-WLAN erreichbar, koennte
     * ein beliebiges Geraet im Haus einem laufenden Saal einen fremden Namen geben — und der
     * Tierarzt saehe die Werte des einen Tiers unter dem Namen des anderen.
     * Der Absender wird ueber die Quelladresse des Sockets gestellt (127.0.0.2). Fuer istLokal()
     * ist das ein fremder Rechner; ein Netz oder eine zweite Karte braucht es dafuer nicht.
     */
    const f1 = await anfrage({ pfad: '/api/station', von: '127.0.0.2' });
    ok('GET /api/station von einer fremden Adresse wird abgewiesen (403)',
      f1.code === 403 && /nur lokal/.test(String(f1.text)), f1.code + ' ' + String(f1.text).slice(0, 80));

    const f2 = await anfrage({
      pfad: '/api/station/name', method: 'POST', von: '127.0.0.2',
      koerper: JSON.stringify({ name: 'FREMDER SAAL' }),
    });
    ok('POST /api/station/name von einer fremden Adresse wird abgewiesen (403)',
      f2.code === 403, f2.code + ' ' + String(f2.text).slice(0, 80));
    ok('und der Saalname ist danach UNVERAENDERT (die Sperre greift VOR dem Schreiben)',
      stationsid.name() === 'OP 2 (Zahn)', String(stationsid.name()));

    const f3 = await anfrage({ pfad: '/api/station/kennung/neu', method: 'POST', von: '127.0.0.2' });
    ok('POST /api/station/kennung/neu von einer fremden Adresse wird abgewiesen (403)',
      f3.code === 403, f3.code + ' ' + String(f3.text).slice(0, 80));
    ok('und die Stationskennung ist danach UNVERAENDERT',
      stationsid.sid() === sidVorher, stationsid.sid() + ' vs ' + sidVorher);

    /* ------------------------------------------------------------------
     * DER RIEGEL GEGEN EINE FREMDE WEBSEITE IM BROWSER DES PRAXIS-PCs
     * (Befund 02.08.2026, Schwere 5 — gefunden an /api/praxis/token, gilt hier genauso).
     *
     * istLokal() prueft die Absenderadresse. Eine beliebige Webseite, die im Browser DIESES PCs
     * geoeffnet ist, erfuellt das aber ebenfalls: sie sendet per fetch(..., {mode:'no-cors'}) an
     * 127.0.0.1. Solange kein Content-Type geprueft wurde, galt die Anfrage dem Browser als
     * "einfach" (Vorgabewert text/plain), er verzichtete auf die CORS-Vorabfrage und schickte sie
     * ab. Dass die ANTWORT unlesbar bleibt, aendert an der WIRKUNG nichts: eine neue
     * Stationskennung mitten in der Narkose teilt das Narkoseprotokoll in zwei Zweige.
     * ------------------------------------------------------------------ */
    const b1 = await anfrage({ pfad: '/api/station/name', method: 'POST', ohneTyp: true,
      koerper: JSON.stringify({ name: 'VON EINER WEBSEITE' }) });
    ok('POST ohne Content-Type: application/json wird abgewiesen (403)',
      b1.code === 403 && /application\/json/i.test(String(b1.text)),
      b1.code + ' ' + String(b1.text).slice(0, 100));
    ok('und der Saalname ist danach UNVERAENDERT',
      stationsid.name() === 'OP 2 (Zahn)', String(stationsid.name()));

    const b2 = await anfrage({ pfad: '/api/station/name', method: 'POST',
      herkunft: 'https://irgendeine-webseite.example',
      koerper: JSON.stringify({ name: 'VON EINER WEBSEITE' }) });
    ok('POST mit fremder Herkunft (Origin) wird abgewiesen (403)',
      b2.code === 403 && /Herkunft/i.test(String(b2.text)),
      b2.code + ' ' + String(b2.text).slice(0, 100));
    ok('und der Saalname ist auch danach UNVERAENDERT',
      stationsid.name() === 'OP 2 (Zahn)', String(stationsid.name()));

    const b3 = await anfrage({ pfad: '/api/station/name', method: 'POST',
      herkunft: 'http://127.0.0.1:' + port,
      koerper: JSON.stringify({ name: 'OP 2 (Zahn)' }) });
    ok('die EIGENE Oberflaeche (Origin = diese Station) darf weiterhin schreiben',
      b3.code === 200 && b3.json && b3.json.ok === true, b3.code + ' ' + String(b3.text).slice(0, 100));

    // --- die neue Kennung, vom Praxis-PC aus ---
    const n1 = await anfrage({ pfad: '/api/station/kennung/neu', method: 'POST' });
    ok('POST /api/station/kennung/neu vergibt vom Praxis-PC aus eine neue Kennung',
      n1.code === 200 && n1.json && n1.json.ok === true && S.pruefeSid(n1.json.sid) && n1.json.sid !== sidVorher,
      String(n1.text).slice(0, 160));
    ok('die alte Kennung wird als Vorgaengerin vermerkt',
      n1.json.auskunft.umbenanntVon.indexOf(sidVorher) >= 0, JSON.stringify(n1.json.auskunft.umbenanntVon));
    ok('der SAALNAME bleibt bei der neuen Kennung stehen',
      n1.json.auskunft.name === 'OP 2 (Zahn)' && stationsid.name() === 'OP 2 (Zahn)');
    ok('und der neue Name liegt auf der Platte (Neustart-fest)',
      JSON.parse(fs.readFileSync(dS, 'utf8')).name === 'OP 2 (Zahn)'
      && JSON.parse(fs.readFileSync(dS, 'utf8')).sid === n1.json.sid);
  }
}

/*
 * ---------------------------------------------------------------- EINE ECHTE VORBELEGUNG
 *
 * DIE LEERE STELLE IM SONST DICHTEN TEST (Befund C5). Der Server oben laeuft mit
 * cloud.cfg.station = 'Praxis OP 1' — dem VORLAGEWERT. Damit liefern stationsName(station, vorb.)
 * und station.name() beide null, und eine Fassung, die in stationsAuskunft() schlicht
 * 'name: station.name()' schriebe, bestuende jede einzelne Verhaltenspruefung dort oben. Rot wuerde
 * nur die Textsuche nach 'stationsName(' — und die faellt weg, sobald der Aufruf irgendwo sonst in
 * server.js steht.
 *
 * DER FALL, DEN DAS TRIFFT: eine Praxis mit von Hand angelegter devices.json und einem echten
 * Namen darin, aber ohne gesetzten Saalnamen. Sie ist unterscheidbar benannt — der Admin-Bereich
 * zeigte "kein Name", und der Balken der Erstinbetriebnahme bliebe stehen, obwohl eine Vorbelegung
 * da ist. Deshalb ein ZWEITER Server mit einer echten Vorbelegung.
 */
async function serverMitVorbelegung() {
  kopf('Eine ECHTE Vorbelegung aus devices.json (kein Vorlagewert, kein gesetzter Name):');

  const dV = datei('vorbelegung.json');
  const stationsid = new S.Stationsid({ log: still, datei: dV, hostname: 'OP-PC-V', machineGuid: guidFest });
  await stationsid.laden();

  const registry = {
    adapters: [], getDevices() { return []; }, getPatients() { return []; },
    protokollSchritt() {}, protokollFuerCloud() { return []; },
    protokollVon() { return {}; }, protokollListe() { return []; },
    getRoh() { return []; }, getRohNachrichten() { return []; },
  };
  const cloud = {
    cfg: { enabled: false, station: 'OP Sued' },
    minInterval: 1000, status() { return { enabled: false }; },
    befundTitel() { return null; }, publish() {},
  };

  const gefangen = [];
  const echtLog = console.log, echtErr = console.error;
  console.log = (...a) => gefangen.push(a.join(' '));
  console.error = (...a) => gefangen.push(a.join(' '));

  let srv = null, port = 0;
  try {
    srv = SRV.startServer({ port: 0, host: '127.0.0.1', registry, version: '1.1.0-test', cloud, stationsid });
    port = await new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('Server hoerte nicht innerhalb von 5 s')), 5000);
      srv.httpServer.on('listening', () => { clearTimeout(t); resolve(srv.httpServer.address().port); });
      srv.httpServer.on('error', (e) => { clearTimeout(t); reject(e); });
    });

    const antwort = await new Promise((resolve) => {
      const req = http.request({ host: '127.0.0.1', port: port, path: '/api/station', method: 'GET', timeout: 4000 }, (r) => {
        let s = ''; r.on('data', (c) => { s += c; });
        r.on('end', () => { let j = null; try { j = JSON.parse(s); } catch (_) {} resolve({ code: r.statusCode, text: s, json: j }); });
      });
      req.on('error', (e) => resolve({ code: 0, fehler: e.message }));
      req.on('timeout', () => { req.destroy(); resolve({ code: 0, fehler: 'Zeitablauf' }); });
      req.end();
    });
    const j = antwort.json || {};
    ok('GET /api/station meldet die echte Vorbelegung ALS NAMEN', j.name === 'OP Sued',
      JSON.stringify(j.name) + ' (' + String(antwort.text).slice(0, 120) + ')');
    /* gesetzt bleibt false: eine Vorbelegung ist kein an DIESER Station eingetippter Name. Der
     * Unterschied traegt die Erstinbetriebnahme — und den Balken, der nicht mehr noetig ist. */
    ok('gesetzt bleibt trotzdem false (die Vorbelegung ist kein gesetzter Name)', j.gesetzt === false);
    ok('und die Vorbelegung wird sichtbar mitgeschickt', j.vorbelegung === 'OP Sued');
    ok('die Station selbst hat weiterhin keinen eigenen Namen',
      stationsid.name() === null && stationsid.hatNamen() === false);
  } finally {
    console.log = echtLog; console.error = echtErr;
    try { if (srv) srv.stop(); } catch (_) {}
    if (fail) { ECHT_LOG('\n  (Ausgabe des zweiten Servers:)'); gefangen.forEach((z) => ECHT_LOG('   | ' + z)); }
  }
}
