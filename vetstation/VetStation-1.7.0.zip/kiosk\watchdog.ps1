<#
  watchdog.ps1 - Selbstheilung (Par.8): prueft periodisch, ob Bridge+UI erreichbar sind und der
  Kiosk-Browser laeuft; startet bei Absturz automatisch neu. Beendet ausschliesslich die eigene,
  nicht mehr antwortende Bridge - niemals ein fremdes Programm.

  Aufruf:  powershell -ExecutionPolicy Bypass -File kiosk\watchdog.ps1 -Port 8770

  ------------------------------------------------------------------------------------------
  WAS AM 01.08.2026 SCHIEFGING - und warum diese Datei seitdem anders aussieht:

  Die Bridge lief seit 06:45 Uhr. Irgendwann danach blieb ihre Ereignisschleife stehen: der
  Prozess lebte weiter (0 % CPU, alle Threads wartend), hielt Port 8770 und alle sieben
  Geraeteports, nahm TCP-Verbindungen sogar an - beantwortete aber kein einziges Byte. Selbst
  geschlossene Verbindungen raeumte er nicht mehr ab (CLOSE_WAIT blieb stehen).

  Der Watchdog bemerkte das um 14:37 Uhr korrekt und tat das Falsche: er startete einen ZWEITEN
  Prozess. Der fand jeden Port belegt ("Port 3502 ist von einem anderen Programm belegt"),
  konnte nichts binden und blieb selbst als Leiche stehen. Danach lief der Watchdog in den
  'throw "Bridge nicht erreichbar nach 16 s."' aus launch-kiosk.ps1 - und weil dort
  $ErrorActionPreference = 'Stop' gilt und hier kein try/catch stand, endete die Schleife.
  Ab da ueberwachte niemand mehr irgendetwas. Zustand bei der Entdeckung: ueber zwei Stunden
  tote Station, ohne dass ein einziger Hinweis irgendwo sichtbar gewesen waere.

  Drei Fehler, drei Gegenmassnahmen:
    1. Ein EINGEFRORENER Prozess wurde nie beendet.  -> wird jetzt erkannt und beendet.
    2. Der Watchdog konnte selbst sterben.           -> jeder Durchlauf liegt in try/catch.
    3. Es gab keine Spur.                            -> data\watchdog.log haelt jeden Eingriff fest.

  ABSICHTLICH NICHT EINGEBAUT: eine Sperre "nicht waehrend einer Narkose neu starten". Solange
  die Bridge steht, wird ohnehin nichts aufgezeichnet und nichts angezeigt - die Daten sind in
  diesem Moment bereits verloren. Gerade waehrend einer Narkose ist der schnelle Neustart die
  richtige Antwort, nicht das Abwarten.

  URSACHE DES EINFRIERENS: nicht ermittelt. Das ist ehrlich so festzuhalten - es gab keine
  Fehlerzeile, keinen Absturz und keinen Standby (das System lief seit 22:08 Uhr durch). Diese
  Heilung wirkt deshalb bewusst UNABHAENGIG von der Ursache: sie stellt den Dienst wieder her,
  gleich woran er gescheitert ist, und hinterlaesst im Protokoll, dass es passiert ist. Haeufen
  sich die Eintraege, ist das der Anhaltspunkt fuer die Ursachensuche.
  ------------------------------------------------------------------------------------------
#>
param(
  [int]$Port = 8770,
  [int]$IntervalSec = 10,
  # Erst nach so vielen erfolglosen Pruefungen HINTEREINANDER wird eingegriffen. Bei 3 und 10 s
  # Takt sind das rund 30 s Stille. Ein einzelner Aussetzer beendet nichts.
  [int]$FehlerBisEingriff = 3
)

# Der Watchdog darf an keiner Stelle abbrechen. 'Continue' ist hier kein Schlamperei-Schalter,
# sondern die Bedingung dafuer, dass er ueberhaupt weiterlaeuft.
$ErrorActionPreference = 'Continue'

$Root = Split-Path $PSScriptRoot -Parent
$Url = "http://127.0.0.1:$Port"
$LogDatei = Join-Path $Root 'data\watchdog.log'

. (Join-Path $PSScriptRoot 'watchdog-entscheidung.ps1')

function Schreibe {
  param([string]$Text)
  $zeile = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Text"
  try { Write-Host $zeile } catch {}
  try {
    $ordner = Split-Path $LogDatei -Parent
    if (-not (Test-Path $ordner)) { New-Item -ItemType Directory -Force -Path $ordner | Out-Null }
    # Nicht unbegrenzt wachsen lassen: ueber 512 KB die juengsten 500 Zeilen behalten.
    if ((Test-Path $LogDatei) -and ((Get-Item $LogDatei).Length -gt 524288)) {
      $rest = Get-Content $LogDatei -Tail 500
      Set-Content -Path $LogDatei -Value $rest -Encoding utf8
    }
    Add-Content -Path $LogDatei -Value $zeile -Encoding utf8
  } catch {}
}

<#
  Die Erkennung ("gehoert dieser Prozess zu uns?") wird ERST HIER eingebunden - nach Schreibe.
  Die Datei laesst Schreibe unangetastet, wenn es sie schon gibt, und faellt sonst auf
  Write-Verbose zurueck. So kann der Test sie allein laden, ohne ein Protokoll zu brauchen.
#>
. (Join-Path $PSScriptRoot 'watchdog-erkennung.ps1')

# 4 s statt 2 s: eine beschaeftigte Station (Suchlauf, grosser Datenstrom) darf nicht allein
# deshalb fuer tot erklaert werden, weil sie einen Moment braucht.
function Test-BridgeUp {
  try { return (Invoke-WebRequest "$Url/healthz" -UseBasicParsing -TimeoutSec 4).StatusCode -eq 200 }
  catch { return $false }
}
<#
  Laeuft der KIOSK - nicht irgendein Edge?

  Frueher stand hier `[bool](Get-Process msedge)`. Das trifft jeden msedge.exe-Prozess: die
  Hintergrundprozesse ("Weiter im Hintergrund ausfuehren" ist Vorgabe), Crashpad-Handler,
  Updater - und ein Edge-Fenster, das jemand nach der Wartung offen gelassen hat. Stuerzt der
  Kiosk ab, waehrend irgendeines davon lebt, gilt er als "laeuft" und kommt nie zurueck: der
  Bildschirm im OP bleibt leer, und im Protokoll steht dazu nichts.

  Erkannt wird der Kiosk an seinem eigenen Profilordner, den launch-kiosk.ps1 per
  --user-data-dir mitgibt - dasselbe Kennzeichen, das stop-kiosk.ps1 schon immer benutzt hat.
  Ist die Befehlszeile nicht lesbar, wird auf die alte, grosszuegige Pruefung zurueckgefallen:
  lieber einmal nicht neu starten als in einer Dauerschleife Fenster aufreissen.
#>
function Test-EdgeUp {
  $kiosk = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
             Where-Object { $_.CommandLine -and $_.CommandLine -match 'VetStation\\EdgeProfile' })
  if ($kiosk.Count -gt 0) { return $true }
  $alle = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue)
  $lesbar = @($alle | Where-Object { $_.CommandLine })
  if ($alle.Count -gt 0 -and $lesbar.Count -eq 0) { return $true }   # keine Auskunft -> nicht eingreifen
  return $false
}

<#
  Laesst sich der Port binden? Dann haelt ihn niemand.

  Diese zweite Meinung braucht KEIN CIM, KEIN WMI und KEINE Adminrechte - nur den Netzwerkstapel
  selbst, also genau die Stelle, um die es geht. Sie kann nicht sagen, WER den Port haelt (dafuer
  ist Get-NetTCPConnection da), aber sie kann zweifelsfrei sagen, dass ihn NIEMAND haelt. Windows
  bindet Sockets ohne SO_REUSEADDR ausschliesslich: gelingt das Binden, ist der Port frei.

  Gebunden wird auf der Loopback-Adresse, weil die Station dort horcht (host = 127.0.0.1).
#>
function Test-PortFrei {
  param([int]$P)
  $lauscher = $null
  try {
    $lauscher = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $P)
    $lauscher.Start()
    return $true
  } catch {
    return $false
  } finally {
    if ($lauscher) { try { $lauscher.Stop() } catch {} }
  }
}

<#
  Wer horcht auf dem Port?
     Prozesskennung = dieser Prozess horcht
     $null          = nachweislich niemand
     -1             = die Abfrage ist gescheitert, die Lage ist UNBEKANNT

  Der Unterschied zwischen den letzten beiden ist der Punkt (Gegenpruefung 01.08.2026): frueher
  stand hier ein leeres catch, das jeden Fehler in ein "niemand da" verwandelte. Scheitert
  Get-NetTCPConnection einmalig - CIM unter Last, Virenscanner, Umbau des Netzwerkstapels -,
  haette der Watchdog daraus "abgestuerzt" geschlossen und neu gestartet, waehrend die
  eingefrorene Bridge die Ports weiter haelt. Also genau die zweite Leiche vom 01.08.2026,
  diesmal von der Selbstheilung selbst erzeugt.

  ------------------------------------------------------------------------------------------
  GEMESSEN 02.08.2026 - DIESE FUNKTION HAT DIE GANZE SELBSTHEILUNG AUSSER KRAFT GESETZT.
  ------------------------------------------------------------------------------------------
  Get-NetTCPConnection liefert bei NULL Treffern keine leere Liste, sondern WIRFT:
      FullyQualifiedErrorId : CmdletizationQuery_NotFound,Get-NetTCPConnection
      Exception             : Microsoft.PowerShell.Cmdletization.Cim.CimJobException
  Mit -ErrorAction Stop landete also ausgerechnet der haeufigste Normalfall - "der Port ist frei,
  weil die Station abgestuerzt ist" - im catch und wurde als -1 = 'lage-unklar' gemeldet. Die
  Zeile `if ($v.Count -eq 0) { return $null }` war auf Windows UNERREICHBAR, und damit war die
  Entscheidung 'starten' unerreichbar: eine abgestuerzte Station wurde NIE neu gestartet.
  Belegt im echten Betrieb (data\watchdog.log, 02.08.2026 18:33:18 / :30 / :42, dreimal
  "Portabfrage fehlgeschlagen ... Es wird NICHTS unternommen", waehrend kein Prozess mehr lief).

  Derselbe Fehler traf den zweiten Zweig: Stop-EingefroreneBridge wartet unten darauf, dass
  Get-PortInhaber $null liefert. Auch das kam nie - nach einem ERFOLGREICHEN Beenden meldete sie
  "Port nach 5 s noch belegt" und gab $false zurueck, worauf der Aufrufer bewusst NICHT startete.
  Beide Heilungswege - abgestuerzt und eingefroren - waren damit tot.

  Unterschieden wird jetzt ueber die FullyQualifiedErrorId bzw. die Fehlerkategorie
  ObjectNotFound. Beide sind .NET-Bezeichner und in jeder Windows-Sprache gleich - anders als der
  Meldungstext, der uebersetzt ist (derselbe Grund wie bei firewall.js). Und bleibt danach noch
  Unklarheit, wird nicht geraten, sondern die zweite, CIM-unabhaengige Meinung eingeholt:
  Test-PortFrei. Nur wenn AUCH die keine Aussage liefert, bleibt es bei -1.
#>
function Get-PortInhaber {
  param([int]$P)
  $ev = $null
  $v = @(Get-NetTCPConnection -LocalPort $P -State Listen -ErrorAction SilentlyContinue -ErrorVariable ev)
  if ($v.Count -gt 0) {
    <#
      EIN PORT, MEHRERE LAUSCHER - und $v[0] ist der falsche.

      Gemessen am Praxis-PC 02.08.2026: fuer denselben Port kamen ZWEI Zeilen zurueck,
          LocalAddress ::        Port 8830  OwningProcess 10064
          LocalAddress 127.0.0.1 Port 8830  OwningProcess  8768
      weil die Station ihre Geraeteports auf allen Adressen (::) oeffnet, waehrend die
      Stationsoberflaeche selbst ausdruecklich auf 127.0.0.1 gebunden ist. Welche Zeile zuerst
      kommt, ist nicht zugesichert. Genommen wird deshalb die Zeile, die zu DER Adresse gehoert,
      auf der die Station horcht - sonst pruefte Test-IstUnsereBridge einen fremden Prozess und
      der Wachhund entschiede 'fremd': Station tot, und die Begruendung im Protokoll klaenge
      sogar vernuenftig.

      Reihenfolge: erst die Loopback-Adresse (dort bindet server.js), dann eine Alladressen-
      Bindung (0.0.0.0 / ::, so wuerde eine Station mit host=0.0.0.0 erscheinen), dann der Rest.
    #>
    $wahl = @($v | Where-Object { $_.LocalAddress -eq '127.0.0.1' -or $_.LocalAddress -eq '::1' })
    if ($wahl.Count -eq 0) { $wahl = @($v | Where-Object { $_.LocalAddress -eq '0.0.0.0' -or $_.LocalAddress -eq '::' }) }
    if ($wahl.Count -eq 0) { $wahl = $v }
    return [int]$wahl[0].OwningProcess
  }

  # Null Treffer. Zwei sehr verschiedene Gruende - und der Unterschied entscheidet ueber Leben
  # und Tod der Station, deshalb wird er hier ausdruecklich getrennt.
  $nurNichtGefunden = $true
  if ($ev -and $ev.Count -gt 0) {
    foreach ($e in $ev) {
      $kennung = "$($e.FullyQualifiedErrorId)"
      $kategorie = "$($e.CategoryInfo.Category)"
      if (-not ($kennung -like 'CmdletizationQuery_NotFound*' -or $kategorie -eq 'ObjectNotFound')) {
        $nurNichtGefunden = $false
      }
    }
  }
  if ($nurNichtGefunden) { return $null }   # nachweislich niemand

  Schreibe "Portabfrage fehlgeschlagen: $($ev[0].Exception.Message)"
  if (Test-PortFrei $P) {
    Schreibe "Gegenprobe ohne CIM: Port $P laesst sich binden - es haelt ihn also niemand."
    return $null
  }
  Schreibe "Gegenprobe ohne CIM: Port $P ist belegt, aber wer ihn haelt, ist nicht feststellbar."
  return -1
}



<#
  Beendet die eingefrorene Bridge und wartet, bis der Port wirklich frei ist. Ohne dieses Warten
  liefe der naechste Start in dasselbe EADDRINUSE.

  UNMITTELBAR VOR DEM ABSCHUSS WIRD NOCHMALS GEPRUEFT (Gegenpruefung 01.08.2026): Zwischen der
  Feststellung "Prozess 4711 haelt den Port und gehoert uns" und dem Stop-Process liegen bis zu
  mehrere Sekunden - die Loopback-Abfrage, das Schreiben ins Protokoll. Endet der Prozess in
  dieser Zeitspanne von selbst oder durch stop-kiosk.ps1, kann Windows dieselbe Kennung sofort
  neu vergeben. Der Abschuss traefe dann einen voellig unbeteiligten, gerade erst gestarteten
  Prozess. Die Wiederholung der Pruefung macht das Fenster nicht mathematisch null, aber sie
  verkleinert es von Sekunden auf Millisekunden - und ohne sie waere der schlimmste Ausgang ein
  fremder Prozessabschuss auf einem Medizin-PC.

  Der Rueckgabewert ist KEINE Nebensache: er entscheidet darueber, ob ueberhaupt neu gestartet
  wird. Frueher stand an der Aufrufstelle [void](...) - der Neustart lief auch dann, wenn das
  Beenden gescheitert war, und erzeugte bei jedem Takt eine weitere nutzlose Instanz.
#>
function Stop-EingefroreneBridge {
  param([int]$Kennung)

  $jetzt = Get-PortInhaber $Port
  if ($jetzt -ne $Kennung) {
    Schreibe "Prozess $Kennung haelt den Port nicht mehr (jetzt: $jetzt) - es wird NICHTS beendet."
    return ($null -eq $jetzt)   # Port frei = Ziel erreicht, ohne jemanden anzufassen
  }
  if (-not (Test-IstUnsereBridge $Kennung $Port $Root)) {
    Schreibe "Prozess $Kennung gilt unmittelbar vor dem Beenden nicht mehr als unsere Station - abgebrochen."
    return $false
  }

  try { Stop-Process -Id $Kennung -Force -Confirm:$false -ErrorAction Stop }
  catch { Schreibe "Konnte Prozess $Kennung nicht beenden: $($_.Exception.Message)"; return $false }
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 250
    if ($null -eq (Get-PortInhaber $Port)) { Schreibe "Prozess $Kennung beendet, Port $Port ist frei."; return $true }
  }
  Schreibe "Prozess $Kennung beendet, aber Port $Port ist nach 5 s noch belegt."
  return $false
}

Schreibe "Watchdog aktiv (Port $Port, Takt ${IntervalSec}s, Eingriff nach $FehlerBisEingriff erfolglosen Pruefungen)."

$fehlerFolge = 0
while ($true) {
  # Ein Durchlauf darf niemals die Schleife beenden - das war Fehler 2.
  try {
    if (Test-BridgeUp) {
      if ($fehlerFolge -gt 0) { Schreibe "Station antwortet wieder (nach $fehlerFolge erfolglosen Pruefungen)." }
      $fehlerFolge = 0
    } else {
      $fehlerFolge++
      $inhaber = Get-PortInhaber $Port
      $unsere = $false
      # -1 heisst "Abfrage gescheitert" - dann wird nicht weiter geforscht und auch nicht gehandelt.
      if ($null -ne $inhaber -and $inhaber -ne -1) { $unsere = Test-IstUnsereBridge $inhaber $Port $Root }

      $was = Get-WatchdogEntscheidung -Erreichbar $false -FehlerFolge $fehlerFolge `
               -Schwelle $FehlerBisEingriff -PortInhaber $inhaber -InhaberIstUnsere $unsere
      Schreibe (Get-WatchdogBegruendung -Entscheidung $was -PortInhaber $inhaber -FehlerFolge $fehlerFolge)

      <#
        Das Ergebnis des Beendens ENTSCHEIDET, ob gestartet wird. Frueher stand hier
        [void](Stop-EingefroreneBridge ...) - der Rueckgabewert wurde weggeworfen und der Start
        lief in jedem Fall. Schlug das Beenden fehl (Zugriff verweigert, weil der Watchdog
        unerhoeht laeuft) oder blieb der Port belegt, lief der neue Prozess in EADDRINUSE. Damit
        erzeugte die Selbstheilung bei JEDEM Takt eine weitere nutzlose Instanz - der Kommentar
        "wartet, bis der Port wirklich frei ist" beschrieb eine Absicherung, die durch das [void]
        keinerlei Wirkung hatte. Gefunden von der Gegenpruefung am 01.08.2026.

        Scheitert das Beenden, wird NICHT gestartet und die Fehlerfolge bleibt stehen: der
        naechste Takt versucht es erneut, und im Protokoll steht, woran es lag.
      #>
      $darfStarten = ($was -eq 'starten')
      if ($was -eq 'beenden-und-starten') {
        if (Stop-EingefroreneBridge $inhaber) {
          $darfStarten = $true
        } else {
          Schreibe 'Beenden fehlgeschlagen - es wird bewusst NICHT gestartet (das ergaebe nur eine zweite Instanz ohne Ports). Neuer Versuch beim naechsten Takt.'
        }
      }

      if ($darfStarten) {
        try {
          & (Join-Path $PSScriptRoot 'launch-kiosk.ps1') -Port $Port -NoKiosk
          Schreibe 'Neustart der Station angestossen.'
        } catch {
          # launch-kiosk.ps1 wirft, wenn die Bridge in 16 s nicht hochkommt. Das darf gemeldet
          # werden - beenden darf es den Watchdog nicht.
          Schreibe "Neustart fehlgeschlagen: $($_.Exception.Message) - wird beim naechsten Takt erneut versucht."
        }
        $fehlerFolge = 0
      }
    }

    if (-not (Test-EdgeUp)) {
      Schreibe 'Kiosk-Browser laeuft nicht -> wird gestartet.'
      try { & (Join-Path $PSScriptRoot 'launch-kiosk.ps1') -Port $Port | Out-Null }
      catch { Schreibe "Kiosk-Start fehlgeschlagen: $($_.Exception.Message)" }
    }
  } catch {
    Schreibe "Unerwarteter Fehler im Watchdog (wird uebergangen): $($_.Exception.Message)"
  }
  Start-Sleep -Seconds $IntervalSec
}
