'use strict';
/*
 * surgivet-test.js — der CSV-Leser wird Spalte fuer Spalte gegen die Handbuchtabelle geprueft.
 *
 * WAS DIESER TEST FESTHAELT:
 * Der SurgiVet Advisor sendet 25 kommagetrennte Felder in FESTER Reihenfolge. Eine um eins
 * verschobene Spalte liefert Zahlen, die plausibel aussehen und trotzdem falsch sind — EtCO2 an
 * der Stelle von NIBP. Genau dieser Fehlerfall (aus dem Draeger-Primus-Praxisbericht) ist der
 * schlimmste, den dieses Programm machen kann. Deshalb wird hier jede einzelne Spalte belegt.
 *
 * Ausserdem festgenagelt:
 *  - die vier Ungueltig-Kennungen (-32764 bis -32767) werden zu "kein Wert", nicht zu -32764,
 *  - die Herzfrequenz wird aus DER Quelle genommen, die das Geraet im Flags-Feld nennt,
 *  - die Temperaturskalierung wird ueber die mitgesendete Fahrenheit-Spalte GEGENGEPRUEFT,
 *    und wenn sie nicht aufgeht, kommt LIEBER KEIN WERT.
 *
 * Start: node tools/surgivet-test.js      (laeuft auch in tools/alle-tests.js)
 */
const sv = require('../bridge/src/adapters/surgivet');

let pass = 0, fail = 0;
function ok(n, c, x) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (x ? '  -> ' + x : '')); } }

console.log('VetStation — SurgiVet Advisor (RS-232 CSV)\n');

/* Eine Zeile nach der Handbuchtabelle (Kap. 14). Flags = 128 -> Bits 7-9 = 1 = Quelle EKG.
 * Temperaturen als Zehntel: 382 = 38,2 °C und 1008 = 100,8 °F  (38,2*1,8+32 = 100,76). */
function zeile(a) {
  const f = new Array(25).fill(-32767);
  Object.keys(a).forEach((k) => { f[sv.S[k]] = a[k]; });
  return f.join(',');
}

console.log('Eine vollstaendige Messzeile:');
const z1 = zeile({
  flags: 128, hrEkg: 96, spo2: 97, oxStaerke: 8, hrOx: 94,
  nibpSys: 118, nibpDia: 62, nibpMap: 81, nibpHr: 95,
  temp1c: 382, temp1f: 1008, etco2: 38, fico2: 2, af: 14, umgebungsdruck: 760,
});
const r1 = sv.parseZeile(z1);
ok('Zeile wird angenommen', !!r1, z1);
ok('Herzfrequenz 96 (Quelle EKG)', r1.vitals.hr === 96, JSON.stringify(r1.vitals));
ok('die Quelle wird benannt', r1.quelle === 'EKG', r1.quelle);
ok('SpO2 97', r1.vitals.spo2 === 97);
ok('EtCO2 38', r1.vitals.etco2 === 38);
ok('FiCO2 2', r1.vitals.fico2 === 2);
ok('Atemfrequenz 14 (Spalte CO2 RESP)', r1.vitals.af === 14);
ok('NIBP 118/62, Mitteldruck 81', r1.vitals.nibp.sys === 118 && r1.vitals.nibp.dia === 62 && r1.vitals.nibp.map === 81, JSON.stringify(r1.vitals.nibp));
ok('Temperatur 38,2 °C', r1.vitals.temp === 38.2, String(r1.vitals.temp));
ok('Teiler 10 wurde AUS DEN DATEN bestimmt', r1.teiler === 10, String(r1.teiler));
ok('keine Beanstandung', r1.hinweise.length === 0, JSON.stringify(r1.hinweise));

console.log('\nDie Spalten liegen wirklich dort, wo das Handbuch sagt:');
/* Wenn eine Spalte verrutscht waere, faende sich der Wert an der falschen Stelle wieder.
 * Deshalb je Spalte EIN eindeutiger Wert. */
const einzeln = sv.parseZeile(zeile({ flags: 128, hrEkg: 11, spo2: 22, etco2: 33, fico2: 44, af: 55, nibpSys: 66, nibpDia: 67, nibpMap: 68 }));
ok('hr=11', einzeln.vitals.hr === 11);
ok('spo2=22', einzeln.vitals.spo2 === 22);
ok('etco2=33', einzeln.vitals.etco2 === 33);
ok('fico2=44', einzeln.vitals.fico2 === 44);
ok('af=55', einzeln.vitals.af === 55);
ok('nibp=66/67/68', einzeln.vitals.nibp.sys === 66 && einzeln.vitals.nibp.dia === 67 && einzeln.vitals.nibp.map === 68);

console.log('\nUngueltige Werte werden zu "kein Wert" (nicht zu -32767):');
[-32764, -32765, -32766, -32767].forEach((u) => {
  const r = sv.parseZeile(zeile({ flags: 128, hrEkg: u, spo2: 95 }));
  ok(u + ' -> kein Wert', r.vitals.hr == null, String(r.vitals.hr));
});
ok('ein gueltiger Wert daneben bleibt erhalten', sv.parseZeile(zeile({ flags: 128, hrEkg: -32767, spo2: 95 })).vitals.spo2 === 95);

console.log('\nDie Herzfrequenzquelle aus dem Flags-Feld:');
ok('Quelle EKG (Bits 7-9 = 1)', sv.hrQuelle(1 << 7) === 'EKG');
ok('Quelle Oximetrie (= 2)', sv.hrQuelle(2 << 7) === 'Oximetrie');
ok('Quelle Blutdruck (= 3)', sv.hrQuelle(3 << 7) === 'Blutdruck');
const rOx = sv.parseZeile(zeile({ flags: 2 << 7, hrEkg: 200, hrOx: 88, spo2: 95 }));
ok('bei Quelle Oximetrie wird der Oximetriewert genommen, nicht der EKG-Wert', rOx.vitals.hr === 88, String(rOx.vitals.hr));

console.log('\nEKG-Ableitungsfehler werden zu Alarmen:');
ok('Bit 5 = Ableitung II', sv.ableitungsFehler(1 << 5).join() === 'II');
const rAbl = sv.parseZeile(zeile({ flags: (1 << 5) | (1 << 6) | (1 << 7), spo2: 95 }));
ok('zwei Ableitungen im Alarmtext', /II/.test(rAbl.alarms[0]) && /I\b/.test(rAbl.alarms[0]), JSON.stringify(rAbl.alarms));
const rNull = sv.parseZeile(zeile({ flags: (1 << 10) | (1 << 7), spo2: 95 }));
ok('IBP1-Nullabgleich wird gemeldet', rNull.alarms.some((a) => /IBP1/.test(a)), JSON.stringify(rNull.alarms));

console.log('\nDIE TEMPERATURSKALIERUNG WIRD GEMESSEN, NICHT GERATEN:');
ok('ganze Grad: 38 °C / 100 °F -> Teiler 1', (sv.temperaturSkala(38, 100) || {}).teiler === 1, JSON.stringify(sv.temperaturSkala(38, 100)));
ok('Zehntel: 382 / 1008 -> Teiler 10, 38,2 °C', JSON.stringify(sv.temperaturSkala(382, 1008)) === JSON.stringify({ teiler: 10, celsius: 38.2 }), JSON.stringify(sv.temperaturSkala(382, 1008)));
ok('Hundertstel: 3820 / 10076 -> Teiler 100', (sv.temperaturSkala(3820, 10076) || {}).teiler === 100, JSON.stringify(sv.temperaturSkala(3820, 10076)));
/* Der wichtigste Fall: die beiden Spalten passen NICHT zueinander. Dann ist etwas anders, als
 * angenommen — und dann darf KEIN Wert herauskommen. */
ok('widerspruechliche Spalten -> KEIN Wert', sv.temperaturSkala(382, 500) === null, JSON.stringify(sv.temperaturSkala(382, 500)));
ok('unmoegliche Temperatur -> KEIN Wert', sv.temperaturSkala(9999, 18030) === null);
ok('fehlende Fahrenheit-Spalte -> KEIN Wert', sv.temperaturSkala(382, null) === null);
const rT = sv.parseZeile(zeile({ flags: 128, temp1c: 382, temp1f: 500, spo2: 95 }));
ok('die Zeile wird trotzdem gelesen, nur ohne Temperatur', rT.vitals.spo2 === 95 && rT.vitals.temp == null);
ok('und es wird im Klartext begruendet', rT.hinweise.some((h) => /keine gueltige Skalierung/.test(h)), JSON.stringify(rT.hinweise));

console.log('\nPlausibilitaetsgrenzen (die Lehre aus dem Primus-Fall):');
const rUnsinn = sv.parseZeile(zeile({ flags: 128, hrEkg: 17165, spo2: 97 }));
ok('Herzfrequenz 17165 wird VERWORFEN', rUnsinn.vitals.hr == null, String(rUnsinn.vitals.hr));
ok('und die Verwerfung wird gemeldet', rUnsinn.hinweise.some((h) => /ausserhalb/.test(h)), JSON.stringify(rUnsinn.hinweise));
ok('der gueltige Nachbarwert bleibt', rUnsinn.vitals.spo2 === 97);
ok('SpO2 130 % wird verworfen', sv.parseZeile(zeile({ flags: 128, spo2: 130 })).vitals.spo2 == null);
ok('eine hohe, aber echte Frettchen-Frequenz (300) bleibt', sv.parseZeile(zeile({ flags: 128, hrEkg: 300 })).vitals.hr === 300);

console.log('\nWas KEINE Messzeile ist, wird auch nicht als eine gelesen:');
ok('leere Zeile', sv.parseZeile('') === null);
ok('zu wenige Felder (abgeschnittener Empfang)', sv.parseZeile('1,2,3') === null);
ok('zu viele Felder', sv.parseZeile(new Array(30).fill(0).join(',')) === null);
ok('Kopfzeile des Trendabrufs', sv.parseZeile('DATE,TIME,RATE,RESP,SPO2,PPR,ART1-S,ART1-D,ART1-MN,ICP2-MN,T1,T2,NIBP-S,NIBP-D,NIBP-M,ETCO2,INCO2,a,b,c,d,e,f,g,h') === null);
ok('Text statt Zahlen', sv.parseZeile(new Array(25).fill('---').join(',')) === null);

console.log('\n---');
console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
console.log('OK (' + pass + ' Pruefungen)');
