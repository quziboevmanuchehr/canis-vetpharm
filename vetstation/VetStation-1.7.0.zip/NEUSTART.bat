@echo off
title VetStation - neu starten
REM Beendet die laufende Station (auch wenn sie mit erhoehten Rechten laeuft) und startet sie neu.
REM Noetig nach einem Update, nach Aenderungen an bridge\config\devices.json und wenn ein
REM Datenport von einer zweiten Instanz belegt ist.
echo Beende VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\stop-kiosk.ps1"
REM ZWEITE SICHERUNG (02.08.2026): erst weiter, wenn Port 8770 wirklich frei ist.
REM stop-kiosk.ps1 wartet seit 1.2.4 selbst auf seinen erhoehten Lauf (-Wait). Diese Zeile ist
REM der Guertel zum Hosentraeger: solange die alte Bridge noch horcht, wuerde das Update ueber
REM laufende Dateien geschrieben, und der neue Start saehe die alte Station und taete nichts.
REM Hoechstens 15 Sekunden - danach laeuft es trotzdem weiter und meldet sich unten.
powershell -NoProfile -ExecutionPolicy Bypass -Command "for($i=0; $i -lt 30; $i++){ $b=@(Get-NetTCPConnection -LocalPort 8770 -State Listen -ErrorAction SilentlyContinue); if(-not $b){ break }; Start-Sleep -Milliseconds 500 }"
echo Starte VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo.
  pause
)
