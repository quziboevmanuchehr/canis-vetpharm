# Fern-Live — Werte & Monitor über das Internet ansehen

Der Praxis-PC (VetStation) liest die Geräte, berechnet die Empfehlungen **und** schreibt
die Live-Werte **zweimal je Sekunde** in ein Cloud-Relay (Firebase). Die öffentliche Web-App
`quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/` liest sie und zeigt
denselben Monitor + dieselben Empfehlungen **fern** an — z. B. von zu Hause.

- **Eigenes Konto je Praxis:** Jede Tierarztpraxis meldet sich mit **ihrem** Konto an — in der
  Web-App und auf dem Praxis-PC. Die Daten liegen unter der Anmelde-Kennung dieses Kontos und
  sind für **kein anderes Konto** lesbar, auch nicht mit dem richtigen Pfad.
- **Read-only:** Fern-Zuschauer können die Geräte niemals steuern.
- **Kein Link teilt Daten.** Bis 0.9.0 genügte ein Zugangscode in der Adresse — der stand im
  weiterleitbaren Link, im Browserverlauf und im Log, und ohne Anmeldung ließen sich sogar
  Vitalwerte fälschen. Dieser Weg ist ersatzlos entfallen.

```
Praxis-PC (VetStation-Bridge)          Firebase Realtime DB            Web-App (GitHub Pages)
  liest Geräte ─► Brain/Empfehlung ─►  /live/<Konto>  ◄─ abonniert ─►  Fern-Ansicht
                  schreibt alle 500 ms   nur dieses Konto darf lesen    (Anmeldung, dasselbe Konto)
                        │
                        └─ alle 15 s ─► Firestore  praxen/<Konto>/verlauf   (Historie/Fallakte)
```

## Wo die Daten liegen (Stand 1.1.0 — geändert gegenüber 1.0.3)

Seit 1.1.0 kann eine Praxis **mehrere OP-Säle** im selben Konto betreiben. Dafür hat der Datenbaum
unter `/live/<Praxis-Konto>/` jetzt vier Zweige statt einer flachen Ebene:

| Zweig | Inhalt | Takt |
|---|---|---|
| `tafel/<Kennung>/` | **Der Herzschlag.** Kopfzeile des Saals, eine winzige Kachel je Patient, eine Zeile je Gerät. Klein genug, dass jede Fern-Ansicht **alle** Säle dauerhaft abonnieren kann. | 2 s (leerer Saal: 5 s) |
| `saele/<Kennung>/patients/` | Die **vollen** Werte, Kurven und Rohwerte dieses Saals. Wird nur für den **einen** gerade geführten Saal abonniert. | 500 ms |
| `saele/<Kennung>/protokoll/` | Das Narkoseprotokoll, je Zeile ein eigener, **unveränderlicher** Pfad. | bei jedem Eintrag |
| `verbund/lan/<Kennung>/` | Adressen und **öffentlicher** Schlüssel für den direkten Weg im Hausnetz (Port 8771). Kein Geheimnis — der private Schlüssel verlässt den PC nie. | bei Änderung |

**Warum die Trennung tafel/saele die eigentliche Entscheidung ist:** Eine Fern-Ansicht muss
*alle* Säle sehen, aber nur *einen* fahren. Läge alles in einem Zweig, würde jeder zusätzliche
Saal die Datenmenge für jeden Zuschauer vervielfachen — bei vier Sälen wäre das Freikontingent
weg. Die Tafel ist deshalb bewusst winzig und der volle Strom bewusst einzeln abonnierbar.

**Die Tafel ist zugleich das Lebenszeichen.** Sie wird geschrieben, auch wenn sich kein Wert
ändert. Nur daran ist zu erkennen, dass es einen Saal überhaupt *gibt* — ohne sie wäre ein
gestörter Saal von einem ausgeschalteten nicht zu unterscheiden. Deshalb hängt sie **nicht** am
Wertestrom: ein klemmender Wertestrom hält den Herzschlag nicht an.

### Die flache Ebene bleibt stehen — als Kompatibilitätsschicht

Daneben schreibt jede Station weiterhin die alten Schlüssel `meta` und `patients/...` direkt unter
`/live/<Praxis-Konto>/`. **Warum das nicht entfällt:** eine Praxis aktualisiert ihre Stationen
nicht an einem Tag, und eine ausgelieferte Web-App liest genau diese Ebene. Ohne sie wäre die
Fern-Ansicht bis zum letzten Update leer.

Der Spiegel läuft in drei Zuständen:

- **F0 — die ersten 10 Sekunden**: gar nichts flach. Erst zusehen, wer sonst noch schreibt.
- **F1 — es schreibt eine alte 1.0.3 mit**: nichts flach, dazu eine Klartextmeldung. Zwei Stationen
  würden sich sonst Feld für Feld überschreiben, und bei zwei 22-kg-Hunden landen beide unter
  demselben Schlüssel.
- **F2 — nur neue Stationen**: jede spiegelt ihre eigenen Patienten unter einem eigenen Präfix
  (`s<Kennung>__<Schlüssel>`), zusammen mit gemeinsamen Kopf-Feldern. Ist sie die **einzige**,
  spiegelt sie zusätzlich Kurven und Protokoll unverändert.

F1 ist **jederzeit wieder betretbar**: sobald ein fremder Schreibvorgang auf der flachen Ebene
bewiesen ist, geht es sofort zurück nach F1; erst 60 s Stille führen zurück nach F2. Damit nimmt
eine Praxis, die ihren zweiten Saal in Betrieb nimmt, der ersten nichts weg.

**Was eine 1.0.3 schreibt und warum es stehen bleibt:** Sie nennt in ihrem Schreibvorgang
ausschließlich `meta`, `patients` und `protokoll/...` — die Geschwisterzweige `tafel`, `saele`
und `verbund` fasst sie nicht an. Ihr Vollbild räumt allerdings die flache Ebene komplett aus,
deshalb F1. Umgekehrt löscht keine 1.1.0-Station je die flache Ebene: der Schlüssel `patients` als
Ganzes kommt in ihrem Code nicht mehr vor, auch das Vollbild geht als einzelne tiefe Pfade.

**Wer was lesen darf:** `.write` steht **nicht** mehr oben auf dem Praxis-Konto, sondern je Zweig.
Protokollzeilen sind unveränderlich (`!data.exists() && newData.exists()`), die Wurzel bleibt
fail-closed, und `/live` selbst ist nicht auflistbar — niemand kann sehen, welche Praxen es gibt.

---

## Was fern ankommt (Stand 1.0.0)

| | |
|---|---|
| **Vitalwerte** | HF, SpO₂, EtCO₂, FiCO₂, AF (mit Quelle Kapnograf/Monitor), SYS/DIA/MAP, Temperatur, Paw — **alle** Felder, die der Patientendatensatz führt |
| **Echte Kurven** | Die Abtastwerte des Geräts (EKG 256 Hz, CO₂ 40 Hz) laufen mit, nicht bloß eine Nachbildung. Sie werden je Streifen **genau einmal** übertragen und als Int16+Base64 gepackt (~0,8 KB/s) |
| **EKG-Befund** | QRS-Breite, Rhythmus, ST, Güte — dieselbe Auswertung wie am Praxis-PC |
| **Narkosegerät** | Beatmungsmodus, Isofluran %, Frischgas O₂, alle Beatmungsparameter (Vt, AF, PEEP, Pinsp …) |
| **Geräte** | Modell, Rolle, IP:Port, Sendetakt, Sekunden seit den letzten Daten |
| **Alarme** | alle physiologischen **und** technischen Meldungen des Geräts |
| **Empfehlung** | Priorität + Top-Befund vom Praxis-PC; Beatmungs- und Dosisempfehlungen rechnet die Fern-App live aus denselben Werten mit derselben Regelbasis |
| **Rohwerte** | die Ansicht „Alle Werte vom Gerät" |
| **Narkoseprotokoll** | live mitgeführt und fern **druckbar** (Knopf „🖨 Protokoll drucken"). Ein Eintrag beim ersten Wert, dann alle 12 s und zusätzlich bei jedem neuen Befund. Die Bridge führt es jetzt selbst — vorher lag es nur im Kiosk-Browser und war nach jedem Neuladen weg |
| **Laufzeit** | die gemessene Verzögerung Praxis → Datenbank → hier, in Millisekunden |

In der Fern-Ansicht steht das alles zusätzlich gebündelt im neuen Reiter **📡 Fern-Live**.

**Warum Realtime Database und nicht Firestore für den Live-Strom?** Firestore verträgt dauerhaft
nur etwa einen Schreibvorgang pro Sekunde und Dokument und rechnet pro Schreibvorgang ab — bei
fünf Aktualisierungen je Sekunde wäre es gedrosselt und teuer. Die Realtime Database ist genau für
solche Ströme gebaut (offene Verbindung, 50–150 ms). Firestore bekommt deshalb den **Verlauf**,
wo es seine Stärken hat.

**Warum das trotz hohem Takt wenig Daten kostet:** Nach dem ersten Vollbild schreibt der Praxis-PC
nur noch, was sich tatsächlich geändert hat — meist ein paar hundert Byte. Ändert sich nichts,
wird gar nicht geschrieben (nur alle 2 s ein Lebenszeichen). Damit bleibt der Dauerbetrieb im
kostenlosen Spark-Tarif (10 GB/Monat).

---

## Einmalige Einrichtung

### 1) Realtime Database anlegen (einmalig, für alle Praxen zusammen)
[console.firebase.google.com](https://console.firebase.google.com) → Projekt **vet-station**
→ **Realtime Database → Datenbank erstellen** → Standort **Belgien (europe-west1)**
→ **im gesperrten Modus** starten. Adresse:
`https://vet-station-default-rtdb.europe-west1.firebasedatabase.app`

### 2) Anmeldeverfahren einschalten
**Authentication → Anmeldemethode.** Mindestens **E-Mail-Adresse/Passwort → Aktivieren → Speichern**
(„E-Mail-Link ohne Passwort" bleibt aus).

**Google** (empfohlen, in zwei Minuten erledigt): *Neuen Anbieter hinzufügen → Google → Aktivieren*,
öffentlichen Projektnamen und Support-E-Mail eintragen → Speichern.

**Microsoft / Outlook** (optional, dauert länger — Microsoft verlangt eine eigene App-Registrierung):

1. **[entra.microsoft.com](https://entra.microsoft.com)** öffnen und mit dem Microsoft-Konto anmelden.
2. **Identität → Anwendungen → App-Registrierungen → Neue Registrierung.**
   - Name: z. B. `Canis Anaesthesie`
   - Kontotypen: **„Konten in einem beliebigen Organisationsverzeichnis und persönliche
     Microsoft-Konten"** — nur damit funktionieren auch private Outlook-/Hotmail-Adressen.
   - Umleitungs-URI: Plattform **Web**, Adresse
     `https://vet-station.firebaseapp.com/__/auth/handler`
3. Nach dem Anlegen die **Anwendungs-ID (Client)** von der Übersichtsseite kopieren.
4. **Zertifikate & Geheimnisse → Neuer geheimer Clientschlüssel** → anlegen → den **Wert**
   sofort kopieren (er wird nur einmal angezeigt).
5. Zurück in Firebase: **Anmeldemethode → Neuen Anbieter hinzufügen → Microsoft → Aktivieren**,
   Anwendungs-ID und App-Secret einfügen → **Speichern**.

> Danach erscheint der Knopf „Mit Microsoft / Outlook anmelden" von selbst — in der Web-App **und**
> im Admin-Bereich der Station. Am Code ist nichts zu ändern.

**Wichtig für alle drei Verfahren:** In **Authentication → Einstellungen → Autorisierte Domains**
müssen `quziboevmanuchehr.github.io` und `127.0.0.1` stehen. Ohne sie bricht jede Google-/Microsoft-
Anmeldung mit `auth/unauthorized-domain` ab. Unter **Nutzerkontoverknüpfung** muss
„Konten mit derselben E-Mail-Adresse verknüpfen" gewählt sein — nur dann führen Google, Microsoft
und Passwort bei gleicher Adresse auf **dasselbe** Praxis-Konto und damit denselben Datenpfad.

### 3) Sicherheitsregeln veröffentlichen — **der wichtigste Schritt**
**Realtime Database → Regeln** → alles markieren → Inhalt von
**`C:\VetStation\installer\firebase-rtdb-rules.json`** einfügen → **Veröffentlichen**.

Dann **Firestore → Regeln** → alles markieren → Inhalt von
**`C:\VetStation\installer\firestore-rules.txt`** einfügen → **Veröffentlichen**.

> **`.json`/`.txt` öffnen:** Rechtsklick auf die Datei → „Öffnen mit" → „Editor" (Notepad),
> dann **Strg+A**, **Strg+C** — im Firebase-Regelfenster **Strg+A**, **Strg+V**.

**Was die Regeln bewirken:** Die Daten jeder Praxis liegen unter der Anmelde-Kennung ihres
Kontos. Die Regel vergleicht diese Kennung mit dem angemeldeten Konto — eine andere Praxis
kann den Pfad also nicht einmal dann lesen, wenn sie ihn kennt. Ohne Anmeldung geht gar nichts,
und die Liste der Praxen lässt sich nicht abfragen.

### 4) Praxis-Konto anlegen (je Praxis einmal)
Die Web-App öffnen:
`https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/`
→ **📡 Fern-Zugang** → **Neues Praxis-Konto** → E-Mail und Passwort (mind. 6 Zeichen) → fertig.

Dieses eine Konto gilt für **beides**: die Web-App und den Praxis-PC. Mehrere Personen derselben
Praxis melden sich mit demselben Konto an — dann sehen alle dieselbe Station.

### 5) Praxis-PC anmelden
In VetStation: **Admin → 📡 Fern-Live** → entweder **„Mit Google anmelden"** bzw.
**„Mit Microsoft / Outlook anmelden"**, oder E-Mail und Passwort desselben Kontos → **Anmelden**.

> Der Kiosk leitet dafür kurz zu Google/Microsoft und kommt zurück; oben erscheint dann
> „✓ Praxis-Konto angemeldet". Popups sind im Kiosk-Vollbild blockiert, deshalb nimmt die Station
> immer die Weiterleitung — das ist normal und kein Fehler.

Das war alles. Kein Bearbeiten von Dateien, kein Neustart. Im Log erscheint
`cloud: Praxis angemeldet: … Fern-Live sendet ab sofort.`

Das **Passwort wird nicht gespeichert** — nur eine Erneuerungs-Kennung in
`C:\VetStation\data\cloud-auth.json`. Nach Stromausfall oder Update läuft die Übertragung
deshalb von selbst wieder an.

> Ist Fern-Live noch ganz aus, steht im Admin-Bereich, wie man es einschaltet
> (`cloud.enabled` in `C:\VetStation\bridge\config\devices.json`).

### 6) Von zu Hause zusehen
Dieselbe Adresse öffnen, mit **demselben Konto** anmelden:
`https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/`

Oben erscheint **📡 FERN-ANSICHT** mit Verbindungsstatus, gemessener Laufzeit und — bei mehreren
Patienten — einem Umschalter. Der virtuelle Monitor (EKG/Kapno/Werte), die Beatmungsempfehlung
und die Notfallprotokolle laufen genauso wie am Praxis-PC. Der neue Reiter **📡 Fern-Live**
bündelt zusätzlich alles: alle Werte, EKG-Befund, Beatmungsparameter, Geräte mit Adresse und
Sendetakt, Alarme, Rohwerte — und das **Narkoseprotokoll mit Druckknopf**.

Die Anmeldung bleibt im Browser gespeichert; beim nächsten Öffnen ist die Station sofort da.

---

## Wie schnell ist die Übertragung wirklich?

Nicht schätzen — messen. Es gibt drei Abschnitte, und beide Werkzeuge zeigen jeweils einen davon:

**a) Praxis-PC → Datenbank.** Auf dem Praxis-PC **`GESCHWINDIGKEIT-MESSEN.bat`** doppelklicken.
Das Werkzeug schreibt einige Testpakete in der Größe eines echten Wertepakets und zeigt
schnellste/mittlere/langsamste Zeit, dazu den eingestellten Sendetakt und wie viele Bytes je
Paket tatsächlich über die Leitung gehen. Der erste Vorgang ist immer langsamer — daran sieht
man, dass die Dauerverbindung greift.

**b) Datenbank → Zuhause.** In der Web-App unter **📡 Fern-Live → „Verbindung & Geschwindigkeit"**
steht **„Laufzeit Praxis → hier"**, dazu der beste und schlechteste Wert seit dem Öffnen.
Dieselbe Zahl steht klein in der oberen Leiste (`live · 5/s · 87 ms`).

Diese Zahl ist gegen die **Uhr der Datenbank** gemessen, nicht gegen die Uhr des eigenen Geräts.
Sie stimmt also auch dann, wenn einer der beiden Rechner falsch geht — ein naiver Uhrenvergleich
würde bei einem um eine Minute abweichenden Praxis-PC „60 s Verzögerung" anzeigen, obwohl alles
in Millisekunden ankommt.

**c) Der eigentliche Engpass: das Gerät.** Liefert der Monitor nur alle 30 Sekunden neue Werte,
hilft die schnellste Leitung nichts. Der Sendetakt je Gerät steht im Reiter **📡 Fern-Live**
in der Geräte-Tabelle unter „Takt".

| Gemessene Laufzeit | Bedeutung |
|---|---|
| unter 120 ms | praktisch verzögerungsfrei |
| 120–300 ms | für die Fernüberwachung völlig ausreichend |
| 300–800 ms | brauchbar, aber träge — WLAN statt Kabel? Anderer Datenverkehr? |
| über 800 ms | die Internetverbindung der Praxis ist der Engpass, nicht die Software |

### Was tatsächlich gemessen wurde (27.07.2026)

Nicht geschätzt — die drei Abschnitte wurden einzeln gemessen:

| Abschnitt | Wert | womit gemessen |
|---|---|---|
| Software: Gerätepaket → fertig auf der Leitung | **147 ms** (23–258 ms) | `node tools/fern-durchsatz-test.js --sekunden 30` |
| Praxis-PC → Firebase (Belgien) | **28 ms** Rundreise | echte Anfragen an die Datenbank |
| Firebase → Browser zu Hause | **30 ms** Rundreise | echte Abfragen aus der veröffentlichten Web-App |
| **zusammen bis zum Bild zu Hause** | **rund 150 ms, im schlechtesten Fall 290 ms** | |

Ein neuer Messwert ist also **in weniger als einer Fünftelsekunde** zu Hause sichtbar — deutlich
schneller als „jede Sekunde bemerkbar".

**Datenmenge während einer Narkose** (Gerät liefert 1×/s inkl. EKG- und CO₂-Streifen):

| | |
|---|---|
| reines Wert-Paket | **243 Byte** |
| mit einem neuen Kurvenstreifen | ~3,9 KB |
| laufend | 4 KB/s = 14 MB je Stunde |
| hochgerechnet | 3,3 GB/Monat bei 8 h Betrieb am Tag — Freikontingent sind 10 GB |
| ohne Kurven (`kurven: false`) | 1,1 KB/s = 2,6 GB/Monat selbst rund um die Uhr |

**Woher die Geschwindigkeit kommt** (alles bereits eingebaut): Die Verbindung zur Datenbank bleibt
offen — das allein spart **73 ms pro Wert** (gemessen: 101 ms mit Neuaufbau, 28 ms mit
Dauerverbindung). Nach dem ersten Bild geht nur noch das Geänderte über die Leitung. Kurvenstreifen
gehen als Int16+Base64 und **je Streifen genau einmal** — nachgewiesen: 29 Streifen, 29 Pakete.

**Was den Takt schnell macht** (schon eingebaut, nichts einzustellen): nach dem ersten Bild wird
nur noch das **Geänderte** geschrieben — meist ein paar hundert Byte statt mehrerer Kilobyte.
Ändert sich nichts, wird gar nicht geschrieben. Die Verbindung zur Datenbank bleibt **offen**
(ohne das käme vor jedem Wert ein neuer Verbindungsaufbau nach Belgien dazu, rund 100 ms).
Kurven gehen als Int16+Base64 und je Streifen genau einmal.

---

## Einstellungen (`C:\VetStation\bridge\config\devices.json`, Block `cloud`)

```json
"cloud": {
  "enabled": true,
  "apiKey": "<Web-API-Key>",
  "dbUrl": "https://vet-station-default-rtdb.europe-west1.firebasedatabase.app",
  "email": "praxis@beispiel.de",
  "station": "Praxis OP 1",
  "minIntervalMs": 500,
  "kurven": true,
  "rohwerte": true,
  "stammdaten": true,
  "archiv": { "enabled": true, "intervalMs": 15000 }
}
```
- **`minIntervalMs`** = Sendetakt der Vitalwerte in Millisekunden (Untergrenze 100). `500` = zweimal je Sekunde.
  Bis 1.0.3 standen hier 200 ms. Seit mehrere OP-Säle in EIN Praxis-Konto schreiben, vervielfacht sich
  die Menge mit jedem Saal, und das Freikontingent gilt für das gesamte Firebase-Projekt — deshalb 500.
  Schneller als das Gerät liefert bringt ohnehin nichts; der größte Faktor bleibt der Sendetakt AM GERÄT.
- **`kurven`** = echte Abtastwerte mitschicken (EKG 256 Hz, CO₂ 40 Hz). Auf `false` bei sehr
  schmaler Leitung.
- **`stammdaten`** = Tiername und Patientenakte mitschicken. **Standard `true`**, seit die Daten
  ausschließlich im eigenen Praxis-Konto liegen — ein Narkoseprotokoll ohne Patientennamen wäre
  als Dokument wertlos. Auf `false`, wenn fern nur Vitalwerte erscheinen sollen.
- **`email`** darf vorbelegt werden, damit im Admin-Bereich nur noch das Passwort fehlt.
  **Ein Passwort gehört nicht in diese Datei** — sie wird bei „Auf USB kopieren" mitgenommen.

## Testen ohne Geräte / ohne Konto
- **Web-Ansicht mit erfundenen Werten** (kein Firebase, keine Anmeldung):
  `https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/?livedemo=1`
  — inklusive Protokoll und Druckvorschau.
- **Kommen überhaupt Gerätedaten am PC an?** `GERAETE-PRUEFEN.bat` doppelklicken.

## Sicherheit & Abschalten
- **Kein Link teilt Daten mehr.** Zugriff hat ausschließlich, wer E-Mail und Passwort der Praxis
  kennt. Alte Links der Form `?live=<code>` funktionieren nicht mehr — das war Absicht.
- **Read-only:** Fern kann niemand ein Gerät bedienen. Es wird nichts zurückgeschickt.
- **Abmelden:** in der Web-App oben rechts „abmelden", am Praxis-PC unter
  **Admin → 📡 Fern-Live → Abmelden**. Danach wird sofort nichts mehr übertragen.
- **Passwort wechseln:** in Firebase → Authentication → Nutzer. Danach beide Seiten neu anmelden.
- Die Erneuerungs-Kennung des Praxis-PCs liegt in `C:\VetStation\data\cloud-auth.json`
  (git-ignoriert, gehört nicht auf einen USB-Stick).

## Fehlersuche
| Symptom | Ursache / Lösung |
|---|---|
| Web-App: „nicht angemeldet" | Normal vor der ersten Anmeldung. E-Mail/Passwort eingeben. |
| Web-App: „Die E-Mail-Anmeldung ist im Firebase-Projekt noch nicht freigeschaltet" | Schritt 2 fehlt. |
| Web-App: „Verbindungsfehler" | Regeln nicht veröffentlicht (Schritt 3) oder falsche Datenbank-Adresse. |
| Web-App: „keine neuen Daten (Xs)" | Der Praxis-PC sendet nicht: VetStation läuft nicht, oder die Station ist nicht angemeldet (Admin → Fern-Live). |
| Web-App zeigt an, aber keine Patienten | Am Praxis-PC ist gerade kein Gerät/Patient aktiv. |
| Station: „Fern-Live wartet auf die PRAXIS-ANMELDUNG" | Admin → 📡 Fern-Live → anmelden. |
| Station: `Schreibfehler … 401/403` | Regeln nicht veröffentlicht, oder mit einem anderen Konto angemeldet als erwartet. |
| Verlauf fehlt, Live läuft | Firestore-Regeln fehlen (Schritt 3, zweiter Teil). Betrifft nur das Archiv. |

---

## Nur Entwickler-PC (D:\VetStation)
Diese Befehle gehören **nicht** auf den Praxis-PC — dort gibt es kein `npm` und kein `node`
im PATH. PowerShell startet außerdem in `C:\Windows\System32`, deshalb hier immer
**vollständige Pfade**:

```powershell
node D:\VetStation\tools\cloud-test.js              # Publisher-Selbsttest (Mock-Firebase, 68 Prüfungen)
node D:\VetStation\tools\cloud-integration-test.js  # Ende-zu-Ende: echte Bridge + Simulator
```

Muss ein Selbsttest ausnahmsweise doch auf dem **Praxis-PC** laufen (z. B. auf Bitten des
Supports), dann in PowerShell mit dem mitgelieferten portablen Node und vollständigen Pfaden:

```powershell
& "C:\VetStation\node\node.exe" "C:\VetStation\tools\cloud-test.js"
```
