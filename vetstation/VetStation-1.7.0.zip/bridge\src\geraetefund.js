'use strict';
/*
 * geraetefund.js — gemeinsames Gedaechtnis: WO im Netz haengt gerade ein Medizingeraet?
 *
 * WARUM ES DIESE DATEI GIBT (Befund 22.07.2026, Praxis-PC):
 * In devices.json stand die Geraete-IP FEST (192.168.0.50). Das Geraet hing an diesem Tag aber
 * auf 192.168.0.51 — der Router hatte per DHCP eine andere Adresse vergeben, nachdem der Monitor
 * einmal auf "Automatisch" zurueckgefallen war. Ergebnis:
 *   • Der Verbindungs-Assistent MELDETE das Geraet korrekt ("Mindray-Geraet gefunden: 192.168.0.51"),
 *   • der Abfrage-Adapter klopfte trotzdem stur an 192.168.0.50 und meldete "antwortet nicht".
 * Die Station wusste die richtige Adresse also bereits und benutzte sie nicht. Genau diese Luecke
 * schliesst dieses Modul: EIN Fundort, den alle Adapter lesen.
 *
 * In devices.json genuegt dann  "host": "auto"  statt einer festen IP — die Station folgt dem
 * Geraet selbst, egal welche Adresse es vom Router bekommt.
 *
 * STRIKT READ-ONLY: liest nur die ARP-Tabelle des PCs (arp -a). Es wird nichts gesendet und an
 * keinem Geraet etwas verstellt.
 */
const { execFile } = require('child_process');

/*
 * Hersteller-Praefixe der bekannten Geraete. Seit 01.08.2026 kommen sie aus dem Geraetekatalog
 * (bridge/src/geraetekatalog.js) — dort steht bei jedem Praefix auch, an welchem Geraet es
 * gemessen wurde. Vorher standen sie hier als feste Liste, und ein neues Fabrikat waere
 * stillschweigend durchgefallen: die Station haette "kein Geraet gefunden" gemeldet, waehrend
 * eines am Kabel hing. Der Rueckfall auf die urspruengliche Liste bleibt stehen, damit dieses
 * Modul auch dann arbeitet, wenn der Katalog einmal nicht ladbar ist.
 */
const MEDIZIN_OUI = (function () {
  try {
    const l = require('./geraetekatalog').ouiListe();
    if (l && l.length) return l;
  } catch (_) {}
  return ['98cce4', '000f14'];
})();

// ip -> { ip, mac, gesehen, quelle }
const gefunden = new Map();

function normMac(mac) { return String(mac || '').toLowerCase().replace(/[^0-9a-f]/g, ''); }
function istMedizinMac(mac) {
  const m = normMac(mac);
  return m.length >= 6 && MEDIZIN_OUI.indexOf(m.slice(0, 6)) >= 0;
}

/*
 * merke(liste, quelle) — traegt Funde ein. Wird vom Verbindungs-Assistenten (probe.js) bei jedem
 * ARP-Durchlauf aufgerufen. Pure genug zum Testen: keine Netz-/Dateizugriffe.
 */
/* `jetzt` ist ein ARGUMENT (seit 01.08.2026), nicht die Uhr des Rechners. Nur so laesst sich die
 * Alterung ueberhaupt pruefen: ein Test muesste sonst zehn Minuten warten, und ein Test, der zehn
 * Minuten wartet, wird nicht ausgefuehrt. Dieselbe Bauart wie in tafel.js. */
function merke(liste, quelle, jetztArg) {
  const jetzt = jetztArg || Date.now();
  (liste || []).forEach((g) => {
    if (!g || !g.ip) return;
    gefunden.set(g.ip, { ip: g.ip, mac: normMac(g.mac), gesehen: jetzt, quelle: quelle || 'arp' });
  });
  return alle();
}

/* Alle bekannten Geraete, das zuletzt gesehene zuerst. */
function alle() {
  return Array.from(gefunden.values()).sort((a, b) => b.gesehen - a.gesehen);
}

/*
 * WIE LANGE GILT EIN FUND ALS GUELTIG? (ergaenzt 01.08.2026)
 *
 * BEFUND: Dieses Gedaechtnis wurde nie gealtert und nie geleert — `merke()` fuegt nur hinzu.
 * Damit blieb eine einmal gesehene Adresse fuer immer "im Netz", und `beste(bevorzugt)` gab
 * hartnaeckig die ALTE Adresse zurueck, auch nachdem das Geraet per DHCP laengst auf eine neue
 * gewechselt war. Genau der Fall, fuer den diese Datei ueberhaupt gebaut wurde (Befund
 * 22.07.2026: eingetragen .50, Geraet auf .51), trat nach einem zweiten Wechsel wieder ein —
 * nur diesmal, weil die Station ihren eigenen alten Fund fuer aktuell hielt.
 *
 * 10 Minuten: der Verbindungs-Assistent liest die ARP-Tabelle alle 30 s, die Erstsuche laeuft
 * seltener. Ein Geraet, das noch da ist, wird in 10 Minuten also vielfach bestaetigt; eines,
 * das die Adresse gewechselt hat, faellt sicher heraus, ohne dass ein kurzer Aussetzer
 * (Switch-Neustart, Kabel kurz raus) sofort die Adresse verwirft.
 */
const FRISCH_MS = 10 * 60 * 1000;

function istFrisch(eintrag, jetzt) {
  if (!eintrag) return false;
  return ((jetzt || Date.now()) - (eintrag.gesehen || 0)) < FRISCH_MS;
}

/*
 * beste(bevorzugt) — welche Adresse soll ein Adapter ansprechen?
 *
 * Steht die in der Konfiguration hinterlegte Adresse noch FRISCH im Netz, bleibt es dabei (keine
 * ueberraschenden Wechsel im laufenden Betrieb). Sonst das zuletzt gesehene Geraet.
 * Ohne jeden frischen Fund: null — der Aufrufer sagt dann ehrlich "noch kein Geraet gefunden".
 */
function beste(bevorzugt, jetzt) {
  const t = jetzt || Date.now();
  if (bevorzugt && istFrisch(gefunden.get(bevorzugt), t)) return bevorzugt;
  const frisch = alle().filter((e) => istFrisch(e, t));
  if (frisch.length) return frisch[0].ip;
  /* Nichts Frisches: lieber die letzte bekannte Adresse als gar keine — ein Adapter, der
   * "null" bekommt, klopft ueberhaupt nicht mehr an und findet damit auch nie zurueck.
   * Der Aufrufer sieht am Alter (alle()), dass es ein alter Stand ist. */
  const liste = alle();
  return liste.length ? liste[0].ip : null;
}

/* Alte Eintraege wegwerfen. Wird vom Verbindungs-Assistenten bei jedem ARP-Durchlauf gerufen —
 * so bleibt die Liste im Admin-Bereich ehrlich, statt jede je gesehene Adresse zu behalten. */
function aufraeumen(jetzt) {
  const t = jetzt || Date.now();
  let weg = 0;
  Array.from(gefunden.keys()).forEach((ip) => {
    if (!istFrisch(gefunden.get(ip), t)) { gefunden.delete(ip); weg++; }
  });
  return weg;
}

/* Wurde ueberhaupt schon einmal gesucht bzw. etwas gefunden? */
function anzahl() { return gefunden.size; }

/* Nur fuer Tests: Gedaechtnis leeren. */
function leeren() { gefunden.clear(); }

/*
 * ausArpTabelle(text) — zieht die Medizingeraete aus der Ausgabe von `arp -a`.
 * Pure Funktion, deshalb ohne Netz testbar (tools/geraetefund-test.js).
 */
function ausArpTabelle(text) {
  const treffer = [];
  String(text || '').split(/\r?\n/).forEach((zeile) => {
    const m = zeile.match(/(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}(?:[-:][0-9a-fA-F]{2}){5})/);
    if (!m) return;
    if (!istMedizinMac(m[2])) return;
    treffer.push({ ip: m[1], mac: normMac(m[2]) });
  });
  return treffer;
}

/*
 * aktualisiere() — liest die ARP-Tabelle selbst ein (falls kein Verbindungs-Assistent laeuft).
 * Schlaegt der Aufruf fehl, bleibt das Gedaechtnis unveraendert — es wird nie etwas "vergessen",
 * nur weil `arp` einmal nicht antwortet.
 */
function aktualisiere() {
  return new Promise((resolve) => {
    execFile('arp', ['-a'], { timeout: 5000, windowsHide: true }, (err, stdout) => {
      if (err && !stdout) return resolve(alle());
      resolve(merke(ausArpTabelle(stdout), 'arp'));
    });
  });
}

module.exports = {
  MEDIZIN_OUI, FRISCH_MS,
  istMedizinMac, normMac,
  merke, alle, beste, anzahl, leeren, istFrisch, aufraeumen,
  ausArpTabelle, aktualisiere,
};
