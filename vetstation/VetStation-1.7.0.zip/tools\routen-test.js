'use strict';
/*
 * routen-test.js — RUFT JEDE LESENDE AUSKUNFTSROUTE WIRKLICH AUF.
 *
 * ------------------------------------------------------------------------------------------
 * WARUM ES DIESEN TEST GIBT (02.08.2026, am echten Praxis-PC gemessen)
 * ------------------------------------------------------------------------------------------
 * server.js rief in /api/nachbarn die Methode verbund.abo.status() auf. Die gibt es in
 * tafelabo.js nicht — die Auskunft heisst dort stand(). Ergebnis:
 *
 *     TypeError: verbund.abo.status is not a function
 *
 * mitten im HTTP-Behandler. Node beendet dabei den GANZEN Prozess: Geraeteempfang aus,
 * Kiosk-Bildschirm eingefroren, Fern-Uebertragung weg, Narkoseprotokoll steht. Ausgeloest durch
 * das Oeffnen des Admin-Bereichs (ui/views/admin.js holt /api/nachbarn). Der Wachhund startete
 * nicht neu, weil er "Port frei" als "Lage unklar" las. Die Station war weg, bis jemand hinsah.
 *
 * KEIN EINZIGER der 53 vorhandenen Tests hat das gefunden, und der Grund ist lehrreich: sie
 * pruefen die Bausteine EINZELN und sehr gruendlich (tafelabo-test.js hat 1142 Zeilen), aber
 * NIEMAND rief die zusammengesetzte Route auf. Ein Name, den ein Aufrufer erfindet, faellt nur
 * auf, wenn jemand den Aufruf wirklich macht.
 *
 * WAS DIESER TEST DESHALB TUT: er startet einen vollstaendig verdrahteten Server — ausdruecklich
 * MIT eingerichtetem Fern-Live, denn nur dann existiert verbund.abo ueberhaupt und nur dann war
 * der Fehler erreichbar — und ruft jede lesende Route auf. Erwartet wird nicht ein bestimmter
 * Inhalt (das pruefen die Bausteintests), sondern zweierlei:
 *   1. die Antwort kommt und ist gueltiges JSON bzw. HTML,
 *   2. der Prozess lebt danach noch.
 * Zusaetzlich wird geprueft, dass eine absichtlich zerstoerte Route die Station NICHT mehr
 * umbringt (der Mantel um handleHttp) und dass jede Methode, die server.js auf den drei
 * Verbund-Bausteinen aufruft, dort auch wirklich existiert.
 *
 * SCHREIBENDE ROUTEN sind bewusst nicht dabei (POST /api/praxis/token, /api/station/name, ...):
 * die haben eigene Tests und wuerden hier Zustand hinterlassen.
 */
const http = require('http');
const path = require('path');
const os = require('os');
const fs = require('fs');
const assert = require('assert');

const SRC = path.join(__dirname, '..', 'bridge', 'src');
const { startServer } = require(path.join(SRC, 'server.js'));
const { Registry } = require(path.join(SRC, 'registry.js'));
const { Stationsid } = require(path.join(SRC, 'stationsid.js'));
const { Tafelabo } = require(path.join(SRC, 'tafelabo.js'));
const { Nachbar } = require(path.join(SRC, 'nachbar.js'));
const { Fremdstore } = require(path.join(SRC, 'fremdstore.js'));

let gut = 0;
let schlecht = 0;
function pruefe(name, bedingung, zusatz) {
  if (bedingung) { gut++; console.log('  ok   ' + name); }
  else { schlecht++; console.log('  FEHL ' + name + (zusatz ? '  -> ' + zusatz : '')); }
}

/* Ein stiller Logger: der Test soll die Befunde zeigen, nicht den Startlauf der Station. */
const stillesLog = {
  _zeilen: [],
  info() {}, warn() {},
  error(bereich, text) { this._zeilen.push(bereich + ': ' + text); },
  debug() {},
};

/*
 * DER ERSTE TEIL BRAUCHT KEINEN SERVER: welche Methoden ruft server.js auf den Verbund-Bausteinen
 * auf, und gibt es die dort? Das ist die billigste Fassung derselben Frage und faengt den Fehler
 * schon beim Lesen — auch fuer Routen, die dieser Test (noch) nicht aufruft.
 */
function pruefeAufrufeGegenBausteine() {
  const quelle = fs.readFileSync(path.join(SRC, 'server.js'), 'utf8');
  const bausteine = [
    { name: 'verbund.abo', klasse: Tafelabo },
    { name: 'verbund.lan', klasse: Nachbar },
    { name: 'verbund.store', klasse: Fremdstore },
  ];
  bausteine.forEach((b) => {
    const muster = new RegExp(b.name.replace('.', '\\.') + '\\.([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(', 'g');
    const gerufen = new Set();
    let t;
    while ((t = muster.exec(quelle)) !== null) gerufen.add(t[1]);
    const vorhanden = new Set(Object.getOwnPropertyNames(b.klasse.prototype));
    gerufen.forEach((m) => {
      pruefe(b.name + '.' + m + '() existiert in ' + b.klasse.name,
        vorhanden.has(m),
        'server.js ruft es auf, ' + b.klasse.name + ' kennt nur: ' + [...vorhanden].sort().join(', '));
    });
    pruefe(b.name + ': ueberhaupt Aufrufe gefunden (' + gerufen.size + ')', gerufen.size > 0);
  });
}

function hole(port, pfad) {
  return new Promise((fertig) => {
    const anfrage = http.get({ host: '127.0.0.1', port: port, path: pfad, timeout: 8000 }, (res) => {
      let d = '';
      res.on('data', (c) => { d += c; });
      res.on('end', () => fertig({ code: res.statusCode, text: d, typ: res.headers['content-type'] || '' }));
    });
    anfrage.on('error', (e) => fertig({ code: 0, text: String(e.message), typ: '' }));
    anfrage.on('timeout', () => { anfrage.destroy(); fertig({ code: 0, text: 'Zeitueberschreitung', typ: '' }); });
  });
}

async function main() {
  console.log('routen-test: jede lesende Auskunftsroute wirklich aufrufen\n');

  console.log('1) Ruft server.js nur Methoden auf, die es gibt?');
  pruefeAufrufeGegenBausteine();

  console.log('\n2) Vollstaendig verdrahteter Server MIT eingerichtetem Fern-Live');

  const datenOrdner = fs.mkdtempSync(path.join(os.tmpdir(), 'vetstation-routen-'));
  const registry = new Registry({ log: stillesLog });
  const station = new Stationsid({ log: stillesLog, datei: path.join(datenOrdner, 'station-id.json') });
  await station.laden();

  /*
   * Ein Cloud-Doppel, das NUR so viel kann, wie server.js von ihm verlangt — aber mit
   * enabled + dbUrl, denn genau daran haengt die Frage, ob verbund.abo entsteht. Ohne die beiden
   * Felder waere dieser Test blind fuer den Fehler, den es zu verhindern gilt.
   * Die Adresse zeigt ins Leere (TEST-NET-3, RFC 5737): der Leseweg darf beim Testen nichts
   * erreichen und niemanden anrufen — er muss nur EXISTIEREN.
   */
  const cloudDoppel = {
    cfg: { enabled: true, dbUrl: 'https://203.0.113.1', minIntervalMs: 500 },
    localId: 'testuid0000000000000000000000',
    started: true,
    minInterval: 500,
    minIntervalMs: 500,
    angemeldet: () => true,
    status: () => ({ an: true, angemeldet: true }),
    befundTitel: () => null,
    tafelSatz: () => ({ meta: {}, kacheln: [] }),
    serverVersatzMs: () => 0,
    publish: () => Promise.resolve(),
    _ensureAuth: () => Promise.resolve('token'),
    _refresh: () => Promise.resolve('token'),
    lanAnkerSchreiben: () => Promise.resolve(),
    lanAnkerLesen: () => Promise.resolve([]),
    anmelden: () => Promise.resolve({ ok: false }),
    anmeldenMitToken: () => Promise.resolve({ ok: false }),
    abmelden: () => Promise.resolve({ ok: true }),
    stop: () => {},
  };

  const PORT = 8797;
  const server = startServer({
    port: PORT, host: '127.0.0.1', registry, version: '0.0.0-test',
    cloud: cloudDoppel, stationsid: station,
    adapterStarten: () => true,
    // Kein Suchlauf und kein LAN-Horchen im Test: beide wuerden echte Pakete ins Netz schicken.
    erstsucheCfg: { aus: true },
    nachbarnCfg: { aus: true },
  });

  await new Promise((r) => setTimeout(r, 800));

  pruefe('verbund.abo existiert (sonst prueft dieser Test den Fehlerfall gar nicht)',
    !!(server.verbund && server.verbund.abo));

  const LESEROUTEN = [
    '/healthz', '/api/version', '/api/state', '/api/geraete', '/api/diag', '/api/station',
    '/api/nachbarn', '/api/nachbarn/gibtesnicht', '/api/cloud', '/api/praxis', '/api/protokoll',
    '/api/kurven', '/api/katalog', '/api/erstsuche', '/api/netscan', '/api/rohnachrichten',
    '/api/scenarios', '/api/geraete/erkennung',
  ];

  for (const pfad of LESEROUTEN) {
    const a = await hole(PORT, pfad);
    pruefe('GET ' + pfad + ' antwortet (' + a.code + ')', a.code >= 200 && a.code < 500,
      a.code === 0 ? a.text : a.text.slice(0, 120));
    if (a.typ.indexOf('application/json') === 0) {
      let lesbar = true;
      try { JSON.parse(a.text); } catch (_) { lesbar = false; }
      pruefe('GET ' + pfad + ' liefert lesbares JSON', lesbar, a.text.slice(0, 120));
    }
  }

  /* Der eigentliche Nachweis: nach allen Aufrufen lebt der Prozess noch und antwortet weiter. */
  const nachher = await hole(PORT, '/healthz');
  pruefe('die Station lebt nach allen Routen noch', nachher.code === 200, nachher.text.slice(0, 120));

  console.log('\n3) Der Mantel: eine zerstoerte Route darf die Station nicht mitreissen');

  /*
   * Absichtlich Schaden anrichten — an genau der Stelle, an der der echte Fehler sass: eine
   * Methode, die server.js aufruft, wird durch eine ersetzt, die wirft. Frueher haette der
   * naechste Aufruf den Prozess beendet, und dieser Test waere nicht mit "FEHL" durchgefallen,
   * sondern gar nicht bis hierher gekommen.
   */
  /*
   * Mitgehoert wird am ECHTEN Logger-Modul, nicht am Doppel oben: server.js protokolliert ueber
   * require('./logger') und nicht ueber das uebergebene log-Objekt. Beim ersten Anlauf pruefte
   * dieser Test das Doppel — und meldete "nichts protokolliert", obwohl die Zeile sichtbar auf
   * dem Bildschirm stand. Ein Test, der an der falschen Stelle horcht, ist schlimmer als keiner.
   */
  const echterLogger = require(path.join(SRC, 'logger.js'));
  const mitgehoert = [];
  const echtesError = echterLogger.error;
  echterLogger.error = function (bereich, text) {
    mitgehoert.push(String(bereich) + ': ' + String(text));
    return echtesError.apply(this, arguments);
  };

  const echteStand = server.verbund.abo.stand;
  server.verbund.abo.stand = () => { throw new TypeError('absichtlich zerstoert (Testfall)'); };
  const kaputt = await hole(PORT, '/api/nachbarn');
  pruefe('die zerstoerte Route antwortet mit 500 statt den Prozess zu beenden', kaputt.code === 500,
    'Code ' + kaputt.code + ' / ' + kaputt.text.slice(0, 120));
  const lebtNoch = await hole(PORT, '/healthz');
  pruefe('die Station lebt nach der zerstoerten Route WEITER', lebtNoch.code === 200,
    lebtNoch.text.slice(0, 120));
  pruefe('der Fehler steht im Protokoll (nicht stillschweigend geschluckt)',
    mitgehoert.some((z) => z.indexOf('absichtlich zerstoert') >= 0),
    mitgehoert.join(' | ').slice(0, 200));
  pruefe('im Protokoll steht auch, WELCHE Route es war',
    mitgehoert.some((z) => z.indexOf('/api/nachbarn') >= 0),
    mitgehoert.join(' | ').slice(0, 200));
  echterLogger.error = echtesError;
  server.verbund.abo.stand = echteStand;

  const wieder = await hole(PORT, '/api/nachbarn');
  pruefe('nach der Reparatur antwortet die Route wieder normal', wieder.code === 200);

  try { server.stop(); } catch (_) {}
  try { fs.rmSync(datenOrdner, { recursive: true, force: true }); } catch (_) {}

  console.log('\n' + gut + ' ok, ' + schlecht + ' fehlgeschlagen');
  if (schlecht > 0) process.exit(1);
  process.exit(0);
}

main().catch((e) => { console.error('routen-test abgebrochen: ' + (e && e.stack)); process.exit(1); });
