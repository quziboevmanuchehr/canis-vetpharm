# Fremde Geräte anbinden — Katalog, Erkennung, Beratung

> Ab 1.2.0. Bis dahin kannte VetStation genau **eine** Gerätefamilie (Mindray/Eickemeyer über HL7).
> Alles Wissen darüber lag verstreut in Kommentaren, in `docs/*.md` und im Kopf dessen, der dabei
> war. Ein Tierarzt mit einem Dräger, einem Bionet oder einem WATO stand vor einer Station,
> die schwieg. Das ist der Umbau, der das beendet.

## Was neu ist, in einem Satz

Im Admin-Bereich gibt es den Reiter **🩺 Geräte**: dort schlägt die Station vor, was im Netz hängt,
man kann sein Modell selbst auswählen, bekommt die Anleitung **mit den echten Zahlen dieses PCs**,
richtet es mit einem Klick ein — und wenn trotzdem nichts ankommt, steht dort im Klartext, woran es
liegt und was zu tun ist.

## Die fünf Bausteine und warum sie getrennt sind

| Datei | Beantwortet | Art |
|---|---|---|
| `bridge/src/geraetekatalog.js` | **Was** es gibt: Hersteller, Modell, Protokoll, Port, Menüpfad, MAC-Präfix, Quelle | reine Daten |
| `bridge/src/geraeteerkennung.js` | **Welches** Gerät da hängt | reine Funktion, rät nie |
| `bridge/src/verbindungsberater.js` | **Was zu tun** ist — auch: „dieses Modell gibt gar nichts heraus" | reine Funktion |
| `bridge/src/geraeteeinrichtung.js` | **Tut** es: schreibt `devices.json`, ergänzt den Lauschport, startet sofort | schreibend |
| `bridge/src/seriell.js` | Geräte **ohne Netzwerkbuchse** (RS-232, Geräteserver) | Transport |

Zusammengelegt wären sie unprüfbar. Getrennt lässt sich jeder einzeln ohne Netz und ohne Gerät
testen — und genau das tun `tools/geraetekatalog-test.js`, `geraeteerkennung-test.js`,
`verbindungsberater-test.js`, `geraeteeinrichtung-test.js` und `seriell-test.js`.

## Der Katalog ist ab jetzt die einzige Quelle

Wer ein Gerät in `geraetekatalog.js` einträgt, muss **nirgends sonst** daran denken:

- `netscan.DATA_PORTS` — die Lauschports wachsen automatisch mit (die sieben gemessenen Bestandsports
  bleiben wörtlich und in ihrer Reihenfolge vorn, Neues wird angehängt).
- `geraetefund.MEDIZIN_OUI` und `netscan.istMedizinMac` — die MAC-Präfixe kommen aus dem Katalog.
- Der Modellwähler, die Erkennung und die Anleitung lesen ohnehin nur von dort.

**Warum das wichtig ist:** Am 31.07.2026 musste Port 5510 (Server-Port des LifeVet M) an vier
Stellen nachgetragen werden. Eine vergessene Stelle heißt, dass ein Gerät sauber sendet und
**niemand zuhört** — ohne eine einzige Logzeile, weil nie ein Byte ankommt. Dieser Fehler ist jetzt
bauartbedingt ausgeschlossen.

## Die Regel, die diesen Katalog von einer Werbebroschüre unterscheidet

Jeder Eintrag trägt ein `vertrauen`:

| Wert | Bedeutung | Anzeige |
|---|---|---|
| `belegt` | an einem echten Gerät gemessen **oder** im Herstellerdokument nachgelesen | grün |
| `wahrscheinlich` | gut begründet (Baugleichheit, Herstellerfamilie), nicht nachgemessen | gelb |
| `unbestaetigt` | Hinweis aus zweiter Hand | rot |

Der Anwender sieht diesen Grad, und die Anleitung sagt bei allem außer `belegt` ausdrücklich dazu,
dass das Menü abweichen kann. **Ein Eintrag ohne Quelle wird vom Test abgelehnt** — ein Eintrag ohne
Quelle ist ein Gerücht, und Gerüchte gehören nicht in eine Narkosestation.

Ebenso wichtig: der Katalog sagt auch, wenn ein Gerät **nichts** herausgibt. Der Mindray Veta 5 Plus
erscheint mit „kein offener Datenausgang", hat keinen Einrichten-Knopf und der Berater schreibt
„Nicht weitersuchen — an diesem Weg liegt es nicht am Netz und nicht an der Station." Am echten
Gerät sind dafür Tage in Menüs verloren gegangen.

## Die vier Anbindungswege

### 1. LAN — das Gerät ruft den PC an (`richtung: geraet_sendet`)
Der Normalfall bei HL7. Am Gerät wird die PC-Adresse als Ziel eingetragen; die Station lauscht.
Ein solches Gerät hat **keinen offenen Port** — das ist normal und sagt nichts darüber, ob die
Datenausgabe an ist.

### 2. LAN — der PC fragt das Gerät ab (`richtung: pc_fragt_ab`)
Am Gerät ist meist **nichts** einzustellen, es muss nur erreichbar sein. Dafür lassen die meisten
Monitore nur **ein** abfragendes Programm gleichzeitig zu: läuft VSCapture nebenher, bleibt dieser
Weg tot.

### 3. WLAN
Protokollseitig identisch zu LAN. Hat das Gerät keine Funkkarte — der Normalfall bei Medizingeräten —
hängt man eine **WLAN-Client-Bridge** (Access Point im Client-Modus) an seine LAN-Buchse. Für die
Station ändert sich dadurch nichts.

### 4. Seriell (RS-232) — `bridge/src/seriell.js`
Für alles ohne Netzwerkbuchse: Dräger-MEDIBUS-Familie, Datex-Ohmeda/GE S/5, ältere Monitore.

**Empfohlen: ein Geräteserver.** Ein Kasten für etwa 30–80 € (Moxa NPort, USR-TCP232, Waveshare)
hängt am seriellen Anschluss des Geräts und stellt den Datenstrom als rohen TCP-Port bereit. Für
VetStation ist es dann eine gewöhnliche Netzverbindung über den erprobten Weg — kein Treiber, und
das Gerät darf stehen bleiben, wo es steht.

**Möglich: direkt an einen COM-Anschluss des PCs.** Ohne npm-Modul (auf dem Praxis-PC gibt es nur
`node.exe`) geht das über `mode.com` plus Lesen von `\\.\COM3`.
*Stand der Erprobung, ehrlich:* Öffnen und Einstellen sind auf dem Praxis-PC an COM1 nachgewiesen
(01.08.2026). Das Lesen eines **echten** Geräts über diesen Weg ist noch nicht nachgewiesen, weil
hier keines am seriellen Anschluss hängt. Prüfen mit:

```bash
node tools/seriell-pruefen.js --com COM1 --baud 9600
```

### Read-only, auch seriell — und dort schärfer
Eine serielle Leitung ist beidseitig, und manche Protokolle (MEDIBUS) schweigen, bis der PC fragt.
Eine Datenanfrage ist erlaubt und bleibt Mitlesen. Alles, was am Gerät etwas **verstellt**, ist
verboten. Die Sperre dafür ist eine ausdrückliche **Erlaubnisliste** (`cfg.erlaubteBefehle`): was
nicht wörtlich darin steht, wird verworfen und protokolliert — kein Präfixvergleich, keine Ausnahme.
Ein Adapter müsste einen Verstell-Befehl also sichtbar in diese Liste eintragen, und das fällt in
jeder Durchsicht auf.

## Ein Modell in den Katalog eintragen

```js
{
  id: 'hersteller-modell',            // klein, mit Bindestrichen, eindeutig
  hersteller: 'Wie es auf dem Gerät steht',
  modell: 'Wie es auf dem Gerät steht',
  aliase: ['Schreibweisen', 'Rebrands', 'alte Namen'],
  kategorie: 'monitor',               // monitor | narkose | beatmung | kapnograph | kombi
  einsatz: 'vet',                     // vet | human | beides
  oui: ['98cce4'],                    // NUR gemessene MAC-Präfixe
  vertrauen: 'belegt',
  fallstricke: 'Der eine Satz, der die häufigste Enttäuschung vorwegnimmt.',
  quellen: ['Dokumentnummer, URL oder „eigene Messung TT.MM.JJJJ"'],
  wege: [{
    id: 'hl7-push',
    name: 'Wie ein Mensch den Weg nennt',
    adapter: 'probe',                 // probe | hl7 | vscapture | …
    transport: 'lan',                 // lan | wlan | seriell | usb | datei
    richtung: 'geraet_sendet',
    port: 8830,
    rang: 50,                         // kleiner = wird zuerst belauscht
    lizenz: 'keine',                  // oder 'ja …' / 'unklar …' mit Begründung
    liefert: 'WAS wirklich ankommt — ehrlich, auch wenn es wenig ist',
    vertrauen: 'belegt',
    vorlage: null,                    // devices.json-Eintrag, oder null wenn keiner nötig
    schritte: ['Was am GERÄT zu tun ist, in der Reihenfolge, in der man es tut'],
  }],
}
```

`node tools/geraetekatalog-test.js` prüft danach Form, Eindeutigkeit, Ports und **das Vorhandensein
einer Quelle**. Anschließend `node tools/alle-tests.js`.

> **Bei einem neuen Netzport zusätzlich:** `installer/set-firewall.ps1` (`$PORTS`) nachziehen.
> `tools/paket-test.js` erzwingt die Gleichheit mit `netscan.DATA_PORTS` — vergessen kann man es
> also nicht, aber automatisch geschieht es dort nicht, weil PowerShell den Katalog nicht liest.

## Was der Reiter „Geräte" anzeigt

1. **Eingerichtete Geräte** — mit Ampel: grün „liefert Werte", gelb „läuft, aber es kommt nichts an",
   grau „abgeschaltet". Darunter, auf welchen Ports die Station gerade hört und ob die Firewall
   dazu passt.
2. **Was hängt im Netz?** — je Fund ein Satz mit Begründung. Ist es nicht eindeutig, **fragt** die
   Oberfläche, statt zu wählen. Bei Mindray ist das keine Vorsicht, sondern Notwendigkeit:
   MAC-Präfix und Port 4601 sehen beim uMEC12 Vet und beim Veta 5 Plus **identisch** aus — und das
   eine liefert Werte, das andere nichts.
3. **Gerät selbst auswählen** — Volltextsuche über Hersteller, Modell und alle Schreibweisen.
   „LifeVet 10 C", „lifevet10c" und „ePM 10" finden dasselbe Gerät.
4. **Das gewählte Modell** — Weg wählen, Anleitung mit der echten PC-Adresse, Einrichten,
   und darunter die rangierten Empfehlungen des Beraters.

## Was „Einrichten" garantiert nicht tut

Ausdrückliche Auflage: *„Du musst die Infrastruktur und Verbindungen von bisherigen eingestellten
und verbundenen Geräten nicht schädigen."* Deshalb, jede Zusage einzeln im Test nachgewiesen
(`tools/geraeteeinrichtung-test.js`):

- Kein vorhandener Adapter wird gelöscht, umgeschrieben oder abgeschaltet — nur angefügt.
- Lauschports werden **nur ergänzt**, nie gekürzt und nie umsortiert.
- Zweimal Einrichten erzeugt **keinen** zweiten Eintrag (sonst erschiene dasselbe Gerät doppelt —
  genau der Fehler vom 22.07.2026 an Port 8830).
- Eine von Hand geänderte Adresse wird **nicht** überschrieben.
- „Abschalten" schaltet ab und **löscht nicht**; von Hand eingetragene Geräte und der
  Verbindungs-Assistent lassen sich hier gar nicht abschalten.
- Geschrieben wird atomar (Nebendatei + Umbenennen) — eine halbe `devices.json` würde die Station
  beim nächsten Start in den Simulator-Rückfall schicken.
- Ein neuer Lauschport wird dem **laufenden** Verbindungs-Assistenten sofort übergeben
  (`probe.ergaenzePort`) — ein Neustart mitten in einer Narkose ist keine Option.

## Fern-Live und mehrere OP-Säle

Beides ist unverändert und funktioniert für jedes neue Gerät automatisch mit: Jeder Adapter liefert
Frames im selben Ingest-Modell, und ab `registry.ingest` ist der Weg für alle Geräte identisch —
`matching` → `cloud.js` → Firebase Realtime Database → Web-App (gemessen ~150 ms, siehe
[FERN-LIVE.md](FERN-LIVE.md)) und `tafel` → Nachbarsäle (siehe [MEHRERE-SAELE.md](MEHRERE-SAELE.md)).
Ein neues Gerät braucht dafür **keine** Zeile Code.

## Siehe auch

- **[GERAETE-RECHERCHE-2026-08.md](GERAETE-RECHERCHE-2026-08.md) — welche Geräte es gibt, was sie
  können, und alle Entwicklerhandbücher mit Quellenangabe.** Dort steht auch, warum das
  Eickemeyer LifeVet M ein EDAN ist und nicht mit dem Mindray-Code zu lesen.
- [DEVICE-ADAPTERS.md](DEVICE-ADAPTERS.md) — Adapter-Schnittstelle, wie man einen neuen schreibt
- [MINDRAY-HL7.md](MINDRAY-HL7.md) — alles Gemessene zur Mindray-/Eickemeyer-Familie
- [GERAETE-EINSTELLEN.md](GERAETE-EINSTELLEN.md) — Menüpfade an den Geräten der Praxis
- [LAN-SETUP.md](LAN-SETUP.md) — Verkabelung, feste IP, isoliertes Gerätenetz
