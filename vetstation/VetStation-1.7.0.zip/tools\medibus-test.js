'use strict';
/*
 * medibus-test.js — Rahmen, Zeitregeln und vor allem: WAS NICHT gesendet und NICHT gemeldet wird.
 *
 * WARUM DIESER TEST SO AUSFUEHRLICH IST:
 * MEDIBUS ist das einzige Protokoll in VetStation, bei dem der PC SENDEN MUSS — ein Draeger-Geraet
 * schweigt, bis es gefragt wird, und bricht die Verbindung ab, wenn der PC die Zeitregeln nicht
 * einhaelt. Damit ist es auch das einzige, bei dem die Read-only-Zusage (§10) aktiv verteidigt
 * werden muss statt sich von selbst zu ergeben. Geprueft wird deshalb beides:
 *   (1) dass die Verbindung ueberhaupt zustande kommt (Rahmen, Pruefsumme, Antwortpflicht),
 *   (2) dass ausschliesslich Datenanfragen hinausgehen und OHNE belegte Codetabelle KEIN einziger
 *       Messwert an die Station gemeldet wird.
 *
 * Der zweite Punkt ist die Lehre aus dem dokumentierten Primus-Praxisfall: dort kamen ueber eine
 * falsch gebaute Verbindung Zahlen an, die plausibel aussahen und trotzdem falsch waren
 * (Tidalvolumen 17165 mL statt 300 mL). Ein leeres Feld ist besser als eine falsche Zahl.
 *
 * Start: node tools/medibus-test.js      (laeuft auch in tools/alle-tests.js)
 */
const mb = require('../bridge/src/adapters/medibus');

let pass = 0, fail = 0;
function ok(n, c, x) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (x ? '  -> ' + x : '')); } }

console.log('VetStation — Draeger MEDIBUS\n');

console.log('Pruefsumme (niederwertiges Summenbyte, ASCII-HEX):');
ok('leere Eingabe = 00', mb.pruefsumme(Buffer.from([])) === '00');
ok('ESC + NOP: 1B + 30 = 4B', mb.pruefsumme(Buffer.from([0x1b, 0x30])) === '4B', mb.pruefsumme(Buffer.from([0x1b, 0x30])));
ok('Ueberlauf wird abgeschnitten (nur 8 Bit)', mb.pruefsumme(Buffer.from([0xff, 0x02])) === '02', mb.pruefsumme(Buffer.from([0x7f, 0x7f, 0x04])));
/* Realtime-Bytes (80H-FFH) duerfen ueberall eingebettet sein und zaehlen NICHT mit — steht so in
 * der Protokolldefinition. Wer sie mitzaehlt, bekommt bei jedem Kurvenpaket eine falsche
 * Pruefsumme und verwirft gueltige Nachrichten. */
ok('eingebettete Realtime-Bytes zaehlen NICHT mit',
  mb.pruefsumme(Buffer.from([0x1b, 0x30])) === mb.pruefsumme(Buffer.from([0x1b, 0xa5, 0x30, 0xc6])),
  mb.pruefsumme(Buffer.from([0x1b, 0xa5, 0x30, 0xc6])));

console.log('\nRahmen bauen:');
const k = mb.baueKommando(mb.KOMMANDO.NOP, '');
ok('Kommando beginnt mit ESC (1Bh)', k[0] === 0x1b);
ok('dann der Kommandocode', k[1] === 0x30);
ok('und endet mit CR (0Dh)', k[k.length - 1] === 0x0d);
ok('genau 5 Byte: ESC + Code + 2 Pruefzeichen + CR', k.length === 5, String(k.length));
const a = mb.baueAntwort(mb.KOMMANDO.GERAETE_ID, mb.PC_KENNUNG);
ok('Antwort beginnt mit SOH (01h)', a[0] === 0x01);
ok('die PC-Kennung steht drin', a.toString('latin1').indexOf('0161') > 0, a.toString('latin1'));
ok('Draeger empfiehlt 0161 — genau das steht da', /^0161/.test(mb.PC_KENNUNG));
let zuLang = false;
try { mb.baueKommando(0x24, 'x'.repeat(300)); } catch (_) { zuLang = true; }
ok('ein zu langes Argument wird abgelehnt (max 251 Byte)', zuLang);

console.log('\nRahmen zerlegen:');
const strom = Buffer.concat([mb.baueKommando(mb.KOMMANDO.ICC, ''), mb.baueAntwort(mb.KOMMANDO.DATEN, '82 300')]);
const z = mb.zerlege(strom);
ok('zwei Nachrichten erkannt', z.nachrichten.length === 2, JSON.stringify(z.nachrichten));
ok('die erste ist ein Kommando', z.nachrichten[0].art === 'kommando' && z.nachrichten[0].code === 0x51);
ok('die zweite ist eine Antwort', z.nachrichten[1].art === 'antwort' && z.nachrichten[1].code === 0x24);
ok('beide mit gueltiger Pruefsumme', z.nachrichten.every((n) => n.ok));
ok('der Nutzteil kommt unveraendert an', z.nachrichten[1].nutzteil === '82 300', z.nachrichten[1].nutzteil);
ok('kein Rest uebrig', z.rest.length === 0);

console.log('\nEine GESTOERTE Nachricht wird verworfen, nicht ausgewertet:');
const kaputt = Buffer.from(mb.baueAntwort(mb.KOMMANDO.DATEN, '82 300'));
kaputt[4] = kaputt[4] ^ 0x01;                     // ein Bit im Nutzteil kippen
const zk = mb.zerlege(kaputt);
ok('als ungueltig markiert', zk.nachrichten[0] && zk.nachrichten[0].ok === false, JSON.stringify(zk.nachrichten));

console.log('\nUnvollstaendiger Empfang wird aufgehoben, nicht halb ausgewertet:');
const halb = mb.baueAntwort(mb.KOMMANDO.DATEN, '82 300');
const teil1 = mb.zerlege(halb.slice(0, 5));
ok('noch keine Nachricht', teil1.nachrichten.length === 0);
ok('der Anfang bleibt im Puffer', teil1.rest.length === 5, String(teil1.rest.length));
const teil2 = mb.zerlege(Buffer.concat([teil1.rest, halb.slice(5)]));
ok('nach dem Rest der Bytes ist sie vollstaendig', teil2.nachrichten.length === 1 && teil2.nachrichten[0].ok);

console.log('\nEingebettete Realtime-Bytes stoeren nicht:');
const mitRt = Buffer.concat([halb.slice(0, 3), Buffer.from([0xa5, 0xc6]), halb.slice(3)]);
const zrt = mb.zerlege(mitRt);
ok('Nachricht bleibt gueltig', zrt.nachrichten[0] && zrt.nachrichten[0].ok, JSON.stringify(zrt.nachrichten));
ok('und die Realtime-Bytes sind aus dem Nutzteil entfernt', zrt.nachrichten[0].nutzteil === '82 300', zrt.nachrichten[0].nutzteil);

console.log('\nDIE SATZBREITE WIRD GEMESSEN, NICHT ANGENOMMEN:');
/* Saetze zu 6 Zeichen: 2 HEX-Code + 4 Zeichen Wert. */
const sechs = ['82  300', '', ''];
const antw6 = ['82 300B9 8.5', '82 285B9 8.1', '07  45B9 8.3'];
ok('gleichmaessige 6er-Saetze werden erkannt', mb.satzbreiteBestimmen(antw6) === 6, String(mb.satzbreiteBestimmen(antw6)));
const antw8 = ['82   300B9   8.5', '82   285B9   8.1', '07    45B9   8.3'];
ok('gleichmaessige 8er-Saetze werden erkannt', mb.satzbreiteBestimmen(antw8) === 8, String(mb.satzbreiteBestimmen(antw8)));
ok('eine einzige Antwort reicht NICHT (zu wenig Beleg)', mb.satzbreiteBestimmen([antw6[0]]) === null);
ok('Unsinn ergibt keine Breite', mb.satzbreiteBestimmen(['hallo welt', 'noch was', 'dritte zeile']) === null);
ok('leere Eingabe ergibt keine Breite', mb.satzbreiteBestimmen([]) === null);
ok('Laengen, die nicht aufgehen, ergeben keine Breite', mb.satzbreiteBestimmen(['82 300B9 8.5X', 'ABC']) === null);
ok('satzPasst nimmt einen leeren Wert an (Messwert liegt nicht vor)', mb.satzPasst('82    ') === true);
ok('satzPasst lehnt einen nicht-hexadezimalen Code ab', mb.satzPasst('ZZ 300') === false);
ok('satzPasst lehnt Buchstaben im Wert ab', mb.satzPasst('82 abc') === false);

console.log('\nSaetze zerlegen:');
const s6 = mb.saetze('82 300B9 8.5', 6);
ok('zwei Saetze', s6.length === 2, JSON.stringify(s6));
ok('Code 82, Wert 300', s6[0].code === '82' && s6[0].wert === 300);
ok('Code B9, Wert 8.5', s6[1].code === 'B9' && s6[1].wert === 8.5);
ok('Komma als Dezimaltrennzeichen wird verstanden', mb.saetze('B9 8,5', 6)[0].wert === 8.5);
ok('ohne bekannte Breite wird NICHTS zerlegt', mb.saetze('82 300B9 8.5', null).length === 0);
ok('bei unpassender Laenge wird NICHTS zerlegt', mb.saetze('82 300B9 8.', 6).length === 0);

/* ------------------------------------------------------------------ *
 * Der Ablauf am nachgebauten Geraet: wir spielen die Rolle des Draeger-Geraets
 * und pruefen, was der PC daraufhin sendet.
 * ------------------------------------------------------------------ */
console.log('\nDer Ablauf (nachgebautes Geraet):');
const gesendet = [];
const meldungen = [];
const ctx = { log: { info: (a2, b) => meldungen.push(b), warn: (a2, b) => meldungen.push(b), error: () => {} }, emit: () => {} };

function bauAdapter(extra) {
  const A = new mb.MedibusAdapter(Object.assign({ id: 'test-medibus', art: 'tcp', host: 'x', tcpPort: 1 }, extra || {}), ctx);
  A.connected = true;
  A.verbindung = { senden: (buf) => { gesendet.push(buf.toString('hex')); return true; } };
  return A;
}
const A = bauAdapter();

A._nachricht({ art: 'kommando', code: mb.KOMMANDO.ICC, nutzteil: '', ok: true });
ok('auf ein ICC des Geraets wird geantwortet', gesendet.some((g) => g.indexOf('0151') === 0), JSON.stringify(gesendet));

gesendet.length = 0;
A._nachricht({ art: 'kommando', code: 0x77, nutzteil: '', ok: true });
ok('auch ein UNBEKANNTES Kommando wird beantwortet (sonst bricht die Verbindung ab)',
  gesendet.length === 1 && gesendet[0].indexOf('0177') === 0, JSON.stringify(gesendet));

gesendet.length = 0;
A._nachricht({ art: 'kommando', code: mb.KOMMANDO.GERAETE_ID, nutzteil: '', ok: true });
ok('auf die Kennungsanfrage antwortet der PC mit seiner Kennung',
  gesendet.some((g) => Buffer.from(g, 'hex').toString('latin1').indexOf('0161') > 0), JSON.stringify(gesendet));

console.log('\nOHNE Codetabelle wird KEIN Wert gemeldet:');
let gemeldet = 0;
const B = bauAdapter();
B.ctx = { log: ctx.log, emit: () => { gemeldet++; } };
B.breite = 6;
B._nachricht({ art: 'antwort', code: mb.KOMMANDO.DATEN, nutzteil: '82 300B9 8.5', ok: true });
ok('nichts an die Station gemeldet', gemeldet === 0, String(gemeldet));
ok('aber mitgeschnitten', B.mitschnitt.length === 1);
ok('und die unbekannten Codes werden benannt', B.status().unbekannteCodes.length === 2, JSON.stringify(B.status().unbekannteCodes));

console.log('\nMIT Codetabelle — aber nur mit Grenzen:');
let raus = null;
const C = bauAdapter({ codes: { '82': { vital: 'vt' } } });          // absichtlich OHNE grenzen
C.ctx = { log: ctx.log, emit: (f) => { raus = f; } };
C.breite = 6;
C._nachricht({ art: 'antwort', code: mb.KOMMANDO.DATEN, nutzteil: '82 300', ok: true });
ok('ein Code ohne Grenzen liefert KEINEN Wert', raus === null);
ok('und es wird begruendet', meldungen.some((m) => /keine Grenzen/.test(m)), JSON.stringify(meldungen.slice(-3)));

const D = bauAdapter({ codes: { '82': { vital: 'vt', grenzen: [1, 2000] } } });
D.ctx = { log: ctx.log, emit: (f) => { raus = f; } };
D.breite = 6;
raus = null;
D._nachricht({ art: 'antwort', code: mb.KOMMANDO.DATEN, nutzteil: '82 300', ok: true });
ok('mit Grenzen kommt der Wert durch', raus && raus.vitals.vt === 300, JSON.stringify(raus && raus.vitals));
raus = null;
D._nachricht({ art: 'antwort', code: mb.KOMMANDO.DATEN, nutzteil: '8217165', ok: true });
ok('der Primus-Fall (17165 statt 300) wird VERWORFEN', raus === null, JSON.stringify(raus && raus.vitals));

console.log('\nDie Sendesperre: was NICHT in der Erlaubnisliste steht:');
/* Diese Liste ist die eigentliche Sicherheitszusage. Sie darf ausschliesslich Anfragen enthalten. */
const namen = Object.keys(mb.KOMMANDO);
ok('kein Kommando heisst "setze/set/write/config schreiben"',
  !namen.some((n) => /^(SETZE|SET_|SCHREIB|WRITE)/i.test(n)), namen.join(','));
ok('NOP, ICC und Geraete-ID sind dabei (ohne sie kommt keine Verbindung zustande)',
  mb.KOMMANDO.NOP === 0x30 && mb.KOMMANDO.ICC === 0x51 && mb.KOMMANDO.GERAETE_ID === 0x52);
ok('die Alarmgrenzen-Kommandos LESEN nur (25H/26H sind die Abfragen)',
  mb.KOMMANDO.ALARM_GRENZE_UNTEN === 0x25 && mb.KOMMANDO.ALARM_GRENZE_OBEN === 0x26);

console.log('\nDie Zeitregeln stehen als Konstanten da (mit Herkunft im Kopfkommentar):');
ok('NOP alle 2 s', mb.NOP_MS === 2000);
ok('Zeitueberschreitung bei 3 s', mb.TIMEOUT_MS === 3000);
ok('Antwortpflicht binnen 10 s', mb.ANTWORT_MS === 10000);

console.log('\n---');
console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
console.log('OK (' + pass + ' Pruefungen)');
