

/* ===== FERN-LIVE Seam: Werte vom Praxis-PC (VetStation) in die echte App einspeisen =====
 * Wird vom additiven Fern-Ansicht-Modul (unten) aufgerufen. Es ist DIESELBE Einspeisung, die die
 * VetStation-Shell lokal ueber vetstation-live.js drive() macht - nur ohne iframe, direkt auf
 * state. Dadurch sieht und rechnet die Fern-Ansicht exakt wie die App am Praxis-PC: derselbe
 * virtuelle Monitor, dieselben echten Kurven, dieselbe Beatmungs-Empfehlung (ventAdvice),
 * dieselben Notfall-Verknuepfungen. Read-only: es wird nichts an ein Geraet zurueckgeschickt.
 *
 * WARUM DIE AENDERUNGSERKENNUNG (__liveSig): der Fern-Strom kommt jetzt bis zu 5x pro Sekunde.
 * rerender() baut Protokolle, Dosen, Rassenprofil und Beatmungspanel komplett neu - das 5x pro
 * Sekunde zu tun, wuerde die Seite auf einem Tablet sichtbar ruckeln lassen, obwohl sich an
 * diesen Panels fast nie etwas aendert. Deshalb: Vitalwerte gehen JEDES Mal durch (sie sind
 * billig und sollen fluessig laufen), der teure Vollaufbau nur, wenn sich wirklich etwas
 * Strukturelles geaendert hat (Tierart, Gewicht, Rasse, Rhythmus, Verdampfer, Beatmung). */
function ventModeIdFromName(name){
  if(!name) return null;
  var s=String(name).toLowerCase().replace(/[\s._/+-]/g,'');
  if(/(manu|hand|beutel|bag)/.test(s)) return 'manual';
  if(/simv/.test(s)) return 'simv';
  if(/(vsplus|vspls|volumesupportplus|adaptive|adaptiv)/.test(s)) return 'vsplus';
  if(/(psv|pressuresupport|druckunterst)/.test(s)) return 'psv';
  if(/(cpap|peeponly|nurpeep|spontanpeep)/.test(s)) return 'cpap';
  if(/(pcv|druckkontroll|pressurecontrol)/.test(s)) return 'pcv';
  if(/(vcv|volumenkontroll|volumecontrol|ippv|cmv)/.test(s)) return 'vcv';
  if(/(vs|volumesupport|volumensupport)/.test(s)) return 'vs';
  return null;
}
var __liveSig=null, __liveAlarmSig=null, __liveMessSig=null, __liveGeraetSig=null;
function applyLive(p){
  if(!p) return;
  var schwer=false;   // erzwingt den teuren Vollaufbau
  if(p.species && p.species!==state.sp && A.species.find(function(s){return s.id===p.species;})){ state.sp=p.species; schwer=true; }
  if(p.weightKg>0 && state.wt!==p.weightKg){ state.wt=p.weightKg; var wtEl=$('#wt'); if(wtEl) wtEl.value=state.wt; schwer=true; }
  if(p.breed && VB && VB.byId && VB.byId(p.breed) && state.breed!==p.breed){ state.breed=p.breed; schwer=true; }
  state.monMode='ist';
  if(!state.istVals) istInit();
  var v=p.vitals||{}, iv=state.istVals;
  /* Ein vom Geraet gelieferter Wert gilt als GESETZT: er darf beim naechsten Gewichts- oder
   * Tierartwechsel nicht von einer Bandmitte ueberschrieben werden (istNachziehen). */
  state.istHand=state.istHand||{};
  function sv(k,val){ if(val!=null && !isNaN(val)){ iv[k]=val; state.istHand[k]=1; } }
  sv('hr',v.hr); sv('spo2',v.spo2); sv('etco2',v.etco2); sv('rr',(v.af!=null?v.af:v.rr)); sv('temp',v.temp); sv('sys',v.sys); sv('dia',v.dia);
  var s=iv.sys||0, d=iv.dia||0;
  iv.nibp=(s>0&&d>0)?Math.round(d+(s-d)/3):(v.map!=null?v.map:(iv.nibp||0));
  if(v.ekgRhythm && v.ekgRhythm!==state.rhythm && (A.ekg||[]).some(function(r){return r.id===v.ekgRhythm;})){ state.rhythm=v.ekgRhythm; schwer=true; }

  /* ===== UNIVERSELLES VIRTUELLES GERAET, FERN (05.08.2026) =====
   * Beatmungs- und Gaskanaele gehen ueber DIESELBE Bruecke wie am Praxis-PC (__setMesswerte),
   * und das erkannte Modell ueber dieselbe Bruecke wie dort (__setGeraetProfil). Genau das ist
   * der Grund, warum fern und lokal dasselbe Bild entsteht: es ist derselbe Aufruf, nicht eine
   * zweite Umsetzung. Waere es hier nachgebaut, waere es beim naechsten neuen Kanal wieder
   * auseinandergelaufen — so wie einst der Veta-5-Spiegel, der lokal lief und fern still tot war. */
  try{
    if(window.__setMesswerte){
      /* ALLES weitergeben, was der zusammengefuehrte Patient hergibt — keine feste Feldliste.
       * Eine feste Liste muss bei jedem neuen Kanal an einer weiteren Stelle nachgetragen
       * werden, und die vergessene Stelle meldet sich nie: das Geraet liefert, und fern zeigt
       * es niemand. Ausgenommen sind die sieben, die oben schon ueber sv() gesetzt werden. */
      var UEBER_SV={hr:1,spo2:1,etco2:1,af:1,rr:1,temp:1,sys:1,dia:1,map:1,nibp:1};
      var mw={};
      Object.keys(v).forEach(function(k){
        if(UEBER_SV[k]) return;
        var x=v[k]; if(x!=null && typeof x!=='number') return;
        mw[k]=(x==null?null:x);
      });
      var msig=JSON.stringify(mw);
      if(msig!==__liveMessSig){ __liveMessSig=msig; window.__setMesswerte(mw); }
    }
    /* Die Falluhr laeuft mit dem Datenfluss, nicht mit einem Knopf — fern genauso wie am
     * Praxis-PC. Der Zeitstempel kommt aus dem Paket, damit die Uhr des Zuschauers nichts
     * zur Sache tut. */
    if(window.__setFallLauf) window.__setFallLauf(p.ts||Date.now());
  }catch(e){}
  try{
    if(window.__setGeraetProfil){
      var gm=null, gn=null;
      (p.devices||[]).forEach(function(d){ if(!d||!d.model) return;
        if(d.role==='anesthesia'||d.role==='capno'){ if(!gn) gn=d.model; } else if(!gm) gm=d.model; });
      var gsig=(gm||'')+'|'+(gn||'');
      if(gsig!=='|' && gsig!==__liveGeraetSig){ __liveGeraetSig=gsig; window.__setGeraetProfil({mon:gm,nark:gn}); schwer=true; }
    }
  }catch(e){}

  /* Narkosegeraet spiegeln — genau wie lokal: Verdampfer, Frischgas, Beatmungsmodus, Parameter.
   * Damit gluehen die Beatmungsmodus-Karten fern mit derselben Empfehlung wie am Praxis-PC. */
  var dv=state.dev; if(dv){
    dv.mirror=dv.mirror||{};
    if(p.isoPct!=null && dv.iso!==p.isoPct){ dv.iso=p.isoPct; dv.mirror.iso=true; dv.live=true; schwer=true; }
    if(p.o2Flow!=null && dv.o2!==p.o2Flow){ dv.o2=p.o2Flow; dv.mirror.o2=true; dv.live=true; schwer=true; }
    if(p.ventMode){
      var id=ventModeIdFromName(p.ventMode);
      var modes=(A.machine&&A.machine.ventModes)||[];
      if(id && modes.some(function(m){return m.id===id;}) && dv.mode!==id){ dv.mode=id; dv.mirror.mode=true; dv.live=true; schwer=true; }
      var autoAn=!/manu|hand/i.test(p.ventMode);
      if(dv.auto!==autoAn){ dv.auto=autoAn; schwer=true; }
    }
    if(p.ventParams && typeof p.ventParams==='object'){
      dv.vp=dv.vp||{}; dv.mirror.vp=dv.mirror.vp||{};
      Object.keys(p.ventParams).forEach(function(k){
        var val=p.ventParams[k]; if(val==null) return;
        if(dv.vp[k]!==val){ dv.vp[k]=val; schwer=true; }
        dv.mirror.vp[k]=true;
      });
      if(schwer) dv.live=true;
    }
  }

  try{ if(window.__setAfSource) window.__setAfSource(p.afSource||null); }catch(e){}
  /* Geraete-Alarme nur bei echter Aenderung neu setzen (sonst baut die Liste 5x/s neu auf). */
  try{
    var asig=(p.alarms||[]).map(function(a){ return a&&a.text?a.text:a; }).join('|');
    if(asig!==__liveAlarmSig){ __liveAlarmSig=asig; if(window.__setDeviceAlarms) window.__setDeviceAlarms(p.alarms||[]); }
  }catch(e){}

  var sig=[state.sp,state.wt,state.breed,state.rhythm,dv&&dv.iso,dv&&dv.o2,dv&&dv.mode,dv&&dv.auto].join('|');
  if(schwer || sig!==__liveSig){ __liveSig=sig; syncPatient(); if(typeof renderMonInputs==='function') renderMonInputs(); rerender(); }
  else if(typeof renderMonInputs==='function') renderMonInputs();
  if(mon.running) renderMonValues();
}
/* ---------------------------------------------------------------------------
 * neuerPatient(p) — DER SAALWECHSEL, und er gehoert HIER hinein, nicht ins Fern-Modul.
 *
 * WARUM (gemessen am 31.07.2026): Das Fern-Modul am Dateiende laeuft in einem ANDEREN Gueltigkeits-
 * bereich als dieser Block. istInit, monVitals und applyLive sind dort schlicht nicht sichtbar —
 * `typeof istInit` ergab dort "undefined". Der erste Versuch, den Wechsel von aussen zu bauen,
 * fiel deshalb still in seinen Rueckfallzweig und setzte alle Messkanaele auf null. Und null ist
 * hier gefaehrlich: renderAssess vergleicht x < band[0], also null < 60 = wahr, und applyLive zieht
 * iv.nibp auf die Zahl 0. Das ergab fuer ein gesundes Tier in einem Saal ohne Manschette und ohne
 * Temperatursonde drei erfundene Notfallbefunde samt Wirkstoffdosis ("MAP 0 mmHg - Hypotension",
 * "Apnoe", "Hypothermie"). Nachgestellt im Browser, nicht hergeleitet.
 *
 * Der richtige Zustand nach einem Wechsel ist der, in dem diese App STARTET: istInit() mit den
 * Bandmitten der NEUEN Tierart. Er behauptet keine Messung — im Gegensatz zu null, das eine
 * Messung von 0 behauptet. Tierart, Gewicht und Rasse werden vorher gesetzt, weil istInit() die
 * Baender daraus rechnet.
 *
 * Zusaetzlich geraeumt wird alles, was applyLive nur BEDINGT zuweist und deshalb aus dem vorigen
 * Saal stehenbliebe: der EKG-Rhythmus (ein 'flat' von dort ergibt "Asystolie - CPR" fuer ein
 * gesundes Tier) und die Geraeteeinstellungen samt Spiegelmarken.
 *
 * (4) state.istHand / state.mess — NEU 05.08.2026 mit dem universellen virtuellen Geraet.
 * istHand merkt sich, welche Kanaele von Hand oder von einem Geraet gesetzt wurden; sie werden
 * danach nicht mehr an Tierart und Gewicht angepasst. Bleibt die Marke beim Saalwechsel stehen,
 * gelten die Messkanaele des VORIGEN Saals weiterhin als gesetzt — fremde Zahlen unter neuem
 * Namen, und istNachziehen kommt nie wieder an sie heran. state.mess ist das zuletzt vom Geraet
 * gelieferte Messpaket und gehoert aus demselben Grund dem Saal, nicht dem Zuschauer.
 * --------------------------------------------------------------------------- */
function neuerPatient(p){
  var art=(p&&p.species)||null;
  state.sp=(art&&A.species.some(function(s){return s.id===art;}))?art:((A.species[0]&&A.species[0].id)||'hund');
  state.wt=(p&&p.weightKg>0)?p.weightKg:10;
  state.breed=(p&&p.breed&&VB&&VB.byId&&VB.byId(p.breed))?p.breed:null;
  state.rhythm='sinus';
  var wtEl=$('#wt'); if(wtEl) wtEl.value=state.wt;
  state.istHand={}; state.mess=null;   // siehe (4) im Kopf dieses Blocks
  state.fall={start:null,letzte:null}; // Falluhr gehoert dem Saal, nicht dem Zuschauer
  istInit();
  var dv=state.dev; if(dv){ dv.mirror={}; dv.vp={}; dv.live=false; dv.o2=1; dv.iso=2; dv.mode='vcv'; dv.auto=false; }
  /* Auch die Modellerkennung gehoert zum Saal, nicht zum Zuschauer: der naechste Saal darf ein
   * anderes Geraet haben. Eine HANDwahl des Zuschauers bleibt erhalten (autoErkannt=false). */
  if(state.geraet && state.geraet.autoErkannt){
    if(state.geraet.autoErkannt.mon!==false) state.geraet.autoErkannt.mon=null;
    if(state.geraet.autoErkannt.nark!==false) state.geraet.autoErkannt.nark=null;
  }
  __liveSig=null; __liveAlarmSig=null; __liveMessSig=null; __liveGeraetSig=null;
}
try{
  window.__anaesLive={ apply:applyLive, tab:switchTab, monResolve:monResolve, neuerPatient:neuerPatient,
    gotoIncident:(typeof gotoIncident==='function'?gotoIncident:null), ready:true };
}catch(e){}
