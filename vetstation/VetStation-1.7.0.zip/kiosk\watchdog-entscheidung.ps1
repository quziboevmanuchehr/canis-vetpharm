<#
  watchdog-entscheidung.ps1 - die REINE Entscheidung des Watchdogs, ohne Nebenwirkungen.

  WARUM EIGENE DATEI: Der Watchdog darf Prozesse beenden. Solcher Code muss pruefbar sein, ohne
  dass beim Pruefen etwas beendet wird. Deshalb steht hier nur die Frage "was ist zu tun?" -
  das Tun selbst steht in watchdog.ps1. tests/watchdog-test.js ruft diese Funktion mit erfundenen
  Lagen auf und vergleicht die Antworten.

  DER BEFUND, DER ZU DIESER DATEI GEFUEHRT HAT (01.08.2026):
  Die Bridge (PID 17332) hielt seit ueber zwei Stunden Port 8770 und alle sieben Geraeteports,
  nahm TCP-Verbindungen an - und beantwortete kein einziges Byte. Ihre Ereignisschleife stand.
  Der alte Watchdog pruefte nur "antwortet /healthz?" und startete bei Nein einen NEUEN Prozess.
  Der neue fand aber alle Ports belegt (der eingefrorene haelt sie ja weiter), konnte nichts tun
  und blieb als zweite Leiche stehen. Geheilt wurde nichts.

  Der Unterschied, auf den es ankommt:
    - ABGESTUERZT: der Prozess ist weg, die Ports sind frei  -> neu starten genuegt.
    - EINGEFROREN: der Prozess lebt und haelt die Ports      -> er MUSS erst beendet werden.
  Der alte Watchdog kannte nur den ersten Fall. Das ist der gefaehrlichere Fehler, denn ein
  Absturz faellt auf (Bildschirm leer), ein Einfrieren nicht (Bildschirm zeigt alte Werte weiter).
#>

<#
  Liefert eine von fuenf Anweisungen:

    ok                  - die Station antwortet, nichts tun.
    warten              - sie antwortet nicht, aber noch nicht oft genug hintereinander.
                          Ein einzelner Aussetzer (Sekundenlast, Virenscanner) darf NIE zum
                          Beenden fuehren - waehrend einer Narkose waere das schlimmer als
                          eine kurze Verzoegerung.
    starten             - sie antwortet nicht und niemand haelt den Port: abgestuerzt.
    beenden-und-starten - sie antwortet nicht, aber UNSER Prozess haelt den Port: eingefroren.
    fremd               - ein anderes Programm haelt den Port. Nicht anfassen, nur melden.
                          Ein Watchdog, der fremde Prozesse beendet, ist ein Schaedling.
    lage-unklar         - die Portabfrage selbst ist gescheitert. NICHTS tun (Gegenpruefung
                          01.08.2026): frueher verschluckte Get-PortInhaber jeden Fehler und
                          meldete "niemand da". Scheitert Get-NetTCPConnection einmalig - CIM
                          unter Last, Virenscanner, Umbau des Netzwerkstapels - genau im
                          entscheidenden Takt, haette der Watchdog "abgestuerzt" geschlossen,
                          neu gestartet und damit die zweite Leiche von neuem erzeugt.
                          Nichtwissen ist kein Grund zu handeln.
#>
function Get-WatchdogEntscheidung {
  param(
    [bool]$Erreichbar,
    [int]$FehlerFolge,
    [int]$Schwelle = 3,
    # PID des Prozesses, der auf dem Port horcht.
    #   $null = nachweislich niemand      -1 = die Abfrage selbst ist gescheitert (siehe oben)
    $PortInhaber = $null,
    [bool]$InhaberIstUnsere = $false
  )

  if ($Erreichbar) { return 'ok' }

  # Unterhalb der Schwelle wird nur gezaehlt. Bei Schwelle 3 und 10 s Takt heisst das:
  # erst nach rund 30 s ununterbrochener Stille wird ueberhaupt eingegriffen.
  if ($FehlerFolge -lt $Schwelle) { return 'warten' }

  <#
    Vor allen Handlungsentscheidungen: wissen wir ueberhaupt, wie die Lage ist?

    Der Vergleich laeuft ueber die ZEICHENKETTE, nicht ueber den Typ. Hier stand zuerst
    `$PortInhaber -is [int] -and $PortInhaber -eq -1` - und das griff nicht, weil PowerShell
    einen bar geschriebenen Wert in Befehlsschreibweise (`-PortInhaber -1`) als String bindet,
    nicht als Zahl. Nachgemessen: Typ=System.String, `-is [int]` = False. Der Aufrufer in
    watchdog.ps1 uebergibt zwar eine echte Zahl, aber eine Sicherung, die je nach
    Aufrufschreibweise still ausfaellt, ist keine Sicherung. Gefunden hat es der Test, nicht
    das Lesen.
  #>
  if ($null -ne $PortInhaber -and "$PortInhaber" -eq '-1') { return 'lage-unklar' }

  if ($null -eq $PortInhaber) { return 'starten' }
  if ($InhaberIstUnsere) { return 'beenden-und-starten' }
  return 'fremd'
}

<#
  Nur eine Lesehilfe fuer das Protokoll - damit im watchdog.log ein Satz steht und nicht ein Kuerzel.
#>
function Get-WatchdogBegruendung {
  param([string]$Entscheidung, $PortInhaber = $null, [int]$FehlerFolge = 0)
  switch ($Entscheidung) {
    'ok'     { return 'Station antwortet.' }
    'warten' { return "Keine Antwort ($FehlerFolge in Folge) - noch unterhalb der Schwelle, es wird abgewartet." }
    'starten' { return 'Keine Antwort und niemand haelt den Port: die Station ist abgestuerzt. Neustart.' }
    'beenden-und-starten' {
      return "Keine Antwort, aber Prozess $PortInhaber haelt den Port weiter: die Station ist EINGEFROREN. " +
             'Sie wird beendet und neu gestartet, sonst bleiben die Geraeteports fuer immer blockiert.'
    }
    'fremd' {
      return "Keine Antwort, und Prozess $PortInhaber gehoert nicht zu VetStation. Er wird NICHT angefasst. " +
             'Welches Programm es ist, zeigt: netstat -ano | findstr :8770'
    }
    'lage-unklar' {
      return 'Keine Antwort - und die Abfrage, wer den Port haelt, ist selbst gescheitert. ' +
             'Es wird NICHTS unternommen, bis die Lage wieder feststellbar ist: auf unsicherer ' +
             'Grundlage einen Neustart auszuloesen hat schon einmal eine zweite Leiche erzeugt.'
    }
  }
  return $Entscheidung
}
