<#
  Install-VetStation.ps1 - Installiert bzw. AKTUALISIERT VetStation auf dem Ziel-PC
  (Windows 10/11) als Autostart-Kiosk. Kopiert die App nach C:\VetStation, richtet Autostart +
  Watchdog + Firewall + Startmenue ein und prueft am Ende NACH, ob wirklich der neue Stand laeuft.

  BEHOBENE BEFUNDE (21.07.2026):
   2.7  Die Installation brach jedes Mal ab, weil ein Verknuepfungsname auf ein FRAGEZEICHEN
        endete - in Windows-Dateinamen verboten. Der Abbruch kam NACH dem Kopieren und
        hinterliess eine halb eingerichtete Station (drei von fuenf Verknuepfungen), die auf
        einem PC ein bereits installiertes 0.6.x auf 0.5.2 zurueckgesetzt hat.
        -> Namen werden jetzt zur Laufzeit von verbotenen Zeichen befreit.
   2.8  Startmenue-Eintraege gab es nur bei der Inno-Variante. Wer ueber INSTALLIEREN.bat
        installierte, bekam gar keine - obwohl die Anleitung sie verspricht.
        -> Dieses Skript legt sie jetzt selbst an.
   2.9  Nach einem Update lief WEITER der alte Programmstand: die laufende Station wurde nicht
        beendet, der alte Code blieb im Speicher, und weil der Prozess erhoeht laeuft, liess er
        sich nicht einmal im Task-Manager beenden.
        -> Station wird VOR dem Kopieren beendet, danach gestartet und der Stand NACHGEPRUEFT.
   2.5  Firewall-Regeln vermehrten sich pro Neuinstallation.
        -> Eine gemeinsame, wiederholbare Stelle: installer\set-firewall.ps1

  AUSFUEHREN: INSTALLIEREN.bat doppelklicken (holt sich die Adminrechte selbst).
#>
param(
  [string]$Dest = "C:\VetStation",
  [int]$Port = 8770,
  [switch]$NoStaticIP,
  [switch]$NoAutostart,
  [switch]$NoStart
)
$ErrorActionPreference = 'Stop'

function Ensure-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Starte Installer mit Administratorrechten neu (bitte UAC-Abfrage bestaetigen)..."
    try {
      # -Wait: der aufrufende Starter (SETUP-START.cmd bzw. INSTALLIEREN.bat) darf sich erst
      # beenden, wenn die Installation wirklich durch ist. Sonst raeumt er zu frueh auf.
      Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'))
    } catch { Write-Warning "Adminrechte noetig. Bitte 'INSTALLIEREN.bat' rechtsklicken -> Als Administrator ausfuehren." ; Start-Sleep 4 }
    exit
  }
}
Ensure-Admin

# Windows 10 UND Windows 11 werden gleichermassen unterstuetzt (WebView2 Evergreen, PowerShell, Scheduled Task).
$os = try { (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { 'Windows' }
Write-Host "Windows erkannt: $os  - Win10 und Win11 werden unterstuetzt."

$Src = Split-Path $PSScriptRoot -Parent   # Wurzel des Bundles (dieser Ordner)
$NeueVersion = try { (Get-Content (Join-Path $Src 'package.json') -Raw | ConvertFrom-Json).version } catch { '?' }
$AlteVersion = try { (Get-Content (Join-Path $Dest 'package.json') -Raw | ConvertFrom-Json).version } catch { $null }

Write-Host "== VetStation Installation =="
Write-Host "Quelle: $Src  (Version $NeueVersion)"
if ($AlteVersion) { Write-Host "Ziel:   $Dest  (bisher installiert: $AlteVersion)" }
else { Write-Host "Ziel:   $Dest  (Neuinstallation)" }

# --- WARNUNG vor einem versehentlichen Rueckschritt --------------------------
# Genau das ist am 21.07.2026 passiert: ein abgebrochenes Setup setzte 0.6.x auf 0.5.2 zurueck.
function Aelter([string]$a, [string]$b) {
  try {
    $va = [version]$a; $vb = [version]$b
    return ($va -lt $vb)
  } catch { return $false }
}
if ($AlteVersion -and (Aelter $NeueVersion $AlteVersion)) {
  Write-Warning "Die zu installierende Version ($NeueVersion) ist AELTER als die installierte ($AlteVersion)."
  $w = Read-Host "Wirklich zurueckstufen? (j/N)"
  if ($w -notmatch '^(j|y)') { Write-Host "Abgebrochen - es wurde NICHTS geaendert."; Start-Sleep 3; exit 0 }
}

# --- 0) Laufende Station beenden (SONST bleibt der alte Code im Speicher) -----
$stopper = Join-Path $Dest 'kiosk\stop-kiosk.ps1'
if (Test-Path $stopper) {
  Write-Host ""
  Write-Host "Beende die laufende Station (sonst laeuft nach dem Update weiter der alte Stand) ..."
  try { & $stopper -Port $Port } catch { Write-Warning "Beenden nicht vollstaendig moeglich: $($_.Exception.Message)" }
  Start-Sleep 2
}

# --- 1) Kopieren nach $Dest --------------------------------------------------
$srcResolved = (Resolve-Path $Src).Path
$dstResolved = (Resolve-Path -LiteralPath $Dest -ErrorAction SilentlyContinue)
if (-not $dstResolved -or $srcResolved -ne $dstResolved.Path) {
  New-Item -ItemType Directory -Force -Path $Dest | Out-Null
  Write-Host "Kopiere App nach $Dest ..."
  # Die lokale Konfiguration des Kunden (devices.json) und data\ werden NICHT ueberschrieben.
  robocopy $Src $Dest /E /XD (Join-Path $Src '.git') (Join-Path $Src 'dist') (Join-Path $Src 'node_modules') `
    /XF '*.log' 'devices.json' /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "Kopieren fehlgeschlagen (robocopy-Code $LASTEXITCODE)." }
}

# --- 2) Node pruefen (bundled bevorzugt) -------------------------------------
$node = $null
foreach ($p in @("$Dest\node\node.exe", "$env:ProgramFiles\nodejs\node.exe")) { if (Test-Path $p) { $node = $p; break } }
if (-not $node) { $c = Get-Command node -ErrorAction SilentlyContinue; if ($c) { $node = $c.Source } }
if (-not $node) {
  Write-Warning "Kein Node gefunden. Das Paket sollte 'node\node.exe' enthalten (make-dist.ps1). Sonst Node 18+ installieren."
} else {
  Write-Host "Node: $node"
}

# --- 3) Windows-Firewall (EINE gemeinsame, wiederholbare Stelle) -------------
Write-Host ""
$fw = Join-Path $Dest 'installer\set-firewall.ps1'
if (Test-Path $fw) {
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $fw
} else {
  Write-Warning "installer\set-firewall.ps1 fehlt - die Geraeteports bleiben moeglicherweise blockiert."
}

# --- 3b) USB-Treiber des EKG 2000 still vorinstallieren ----------------------
# Damit nach DIESER Installation kein zweites Setup mehr noetig ist: das EKG kann angesteckt
# werden und Windows richtet es selbst ein. Das Skript ist idempotent und bricht die
# Installation NIE ab - ohne EKG-Treiber laeuft alles andere unveraendert weiter.
Write-Host ""
$trv = Join-Path $Dest 'installer\set-ekg-treiber.ps1'
if (Test-Path $trv) {
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $trv -Root $Dest
} else {
  Write-Warning "installer\set-ekg-treiber.ps1 fehlt - der EKG-2000-Treiber wurde NICHT vorinstalliert."
}

# --- 4) Startmenue-Verknuepfungen -------------------------------------------
# Verbotene Zeichen in Windows-DATEINAMEN: \ / : * ? " < > |   Eine Verknuepfung ist eine
# .lnk-DATEI - ein Fragezeichen im Namen liess die Installation mit
# "IPersistFile::Save schlug fehl; Code 0x8007007B" abbrechen.
function Saubere-Verknuepfung([string]$name) {
  $n = $name
  foreach ($c in @('\', '/', ':', '*', '?', '"', '<', '>', '|')) { $n = $n.Replace($c, '') }
  return $n.Trim()
}

$grp = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\VetStation'
Write-Host ""
Write-Host "Lege Startmenue-Eintraege an ..."
try {
  New-Item -ItemType Directory -Force -Path $grp | Out-Null
  $ws = New-Object -ComObject WScript.Shell
  $eintraege = @(
    @{ Name = 'VetStation starten'; Ziel = 'START-VetStation.bat' },
    @{ Name = '1 Netzwerk einrichten (feste IP)'; Ziel = 'NETZWERK-EINRICHTEN.bat' },
    @{ Name = '2 Geraete pruefen (kommen Daten an)'; Ziel = 'GERAETE-PRUEFEN.bat' },
    @{ Name = '3 Firewall freigeben'; Ziel = 'FIREWALL-FREIGEBEN.bat' },
    @{ Name = '4 VetStation neu starten'; Ziel = 'NEUSTART.bat' },
    @{ Name = '5 Internet einrichten (nur fuer Update-Fern-Live)'; Ziel = 'INTERNET-EINRICHTEN.bat' },
    @{ Name = 'LAN-Anleitung'; Ziel = 'docs\LAN-SETUP.md' }
  )
  foreach ($e in $eintraege) {
    $zielDatei = Join-Path $Dest $e.Ziel
    if (-not (Test-Path $zielDatei)) { Write-Warning ("  uebersprungen (fehlt): " + $e.Ziel); continue }
    $lnkName = (Saubere-Verknuepfung $e.Name) + '.lnk'
    $lnk = $ws.CreateShortcut((Join-Path $grp $lnkName))
    $lnk.TargetPath = $zielDatei
    $lnk.WorkingDirectory = $Dest
    $lnk.Description = 'VetStation'
    $lnk.Save()
    Write-Host ("  + " + $lnkName)
  }
} catch {
  Write-Warning "Startmenue-Eintraege nicht vollstaendig: $($_.Exception.Message)"
}

# --- 5) Autostart-Kiosk registrieren ----------------------------------------
if (-not $NoAutostart) {
  Write-Host ""
  Write-Host "Richte Autostart (Kiosk + Watchdog) ein ..."
  & (Join-Path $Dest 'kiosk\install-autostart.ps1') -Port $Port
}

# --- 6) Optional: statische IP fuer das Geraete-Netz ------------------------
if (-not $NoStaticIP) {
  Write-Host ""
  $ans = Read-Host "Jetzt die feste IP 192.168.0.99 fuer das Geraete-Netz einrichten? (j/N)"
  if ($ans -match '^(j|y)') { & (Join-Path $Dest 'installer\set-static-ip.ps1') }
  else { Write-Host "Uebersprungen. Spaeter: NETZWERK-EINRICHTEN.bat doppelklicken." }
}

# --- 7) Station starten und NACHPRUEFEN, ob der neue Stand laeuft -----------
if (-not $NoStart) {
  Write-Host ""
  Write-Host "Starte VetStation ..."
  try {
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass',
      '-File', ('"' + (Join-Path $Dest 'kiosk\launch-kiosk.ps1') + '"'), '-Port', $Port)
  } catch { Write-Warning "Start fehlgeschlagen: $($_.Exception.Message)" }

  $laufend = $null
  for ($i = 0; $i -lt 25; $i++) {
    Start-Sleep 1
    try {
      $r = Invoke-WebRequest "http://127.0.0.1:$Port/api/version" -UseBasicParsing -TimeoutSec 2
      $laufend = ($r.Content | ConvertFrom-Json).version
      break
    } catch { }
  }
  Write-Host ""
  if (-not $laufend) {
    Write-Warning "Die Station antwortet noch nicht auf Port $Port. Bitte NEUSTART.bat doppelklicken und die Meldungen lesen."
  } elseif ($laufend -eq $NeueVersion) {
    Write-Host "GEPRUEFT: es laeuft Version $laufend - genau der Stand, der eben installiert wurde."
  } else {
    Write-Warning "ACHTUNG: installiert ist $NeueVersion, es LAEUFT aber $laufend."
    Write-Warning "Vermutlich haengt noch ein alter Prozess. Bitte NEUSTART.bat doppelklicken."
  }
}

Write-Host ""
Write-Host "== Installation abgeschlossen (Version $NeueVersion) =="
Write-Host "Kommen Daten an?          GERAETE-PRUEFEN.bat doppelklicken"
Write-Host "Netzwerk einrichten:      NETZWERK-EINRICHTEN.bat doppelklicken"
Write-Host "Station neu starten:      NEUSTART.bat doppelklicken"
Write-Host "In der App selbst:        Admin -> Netzwerk & Geraete -> 'Netzwerk jetzt durchsuchen'"
Write-Host "LAN-Aufbau (Switch, IPs): $Dest\docs\LAN-SETUP.md"
