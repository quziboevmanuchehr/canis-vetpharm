# Geräte-Adapter — Protokoll-Status & Anleitung

VetStation trennt **UI/Logik** sauber von der **Geräteanbindung**: jeder Gerätetyp hat einen
**Adapter** (Schicht 1), der sein Protokoll parst und normalisierte Frames liefert. So lassen sich
neue Geräte ohne Umbau ergänzen (§13).

> **Ab 1.2.0 kommt das Gerätewissen aus dem Katalog.** Welcher Hersteller, welches Modell, welcher
> Port, welcher Menüpfad, welches MAC-Präfix — das steht jetzt an **einer** Stelle:
> `bridge/src/geraetekatalog.js`. Von dort leiten sich die Lauschports, die Geräte-Erkennung, der
> Modellwähler im Admin-Bereich und die Anleitung bei Verbindungsproblemen ab.
> **Anleitung: [GERAETE-KATALOG.md](GERAETE-KATALOG.md).** Ein neues Gerät trägt man dort ein, nicht
> mehr an vier verstreuten Stellen. Diese Datei hier beschreibt weiterhin, wie ein **Adapter**
> (also ein neuer Protokoll-Leser) geschrieben wird.

## Adapter-Interface (`bridge/src/adapters/base.js`)
```js
class Adapter {
  describe()        // { id, model, role }  — für Auto-Discovery
  async connect()   // Verbindung aufbauen; ruft this.emit(rawFrame) je Datenframe
  dispose()         // sauber trennen
}
```
Jeder Adapter emittiert Roh-Frames im **ingest-Modell** (`bridge/src/model.js`, §5):
```js
emit({
  deviceId, deviceModel, deviceRole,        // "monitor" | "anesthesia" | "capno" | "combo"
  patientId, species, weightKg, ts,
  vitals: { hr, ekgRhythm, spo2, pleth, etco2, fico2, paw, af, nibp:{sys,dia,map}, temp, capnoShape },
  ventMode, isoPct, alarms:[…]
})
```
`species` muss eine kanonische ID sein (`hund, katze, kaninchen, meerschwein, chinchilla, degu, frettchen, reptil`),
`ekgRhythm` eine gültige EKG-ID (z. B. `sinus, ves, vfib, asys`), `capnoShape` eine Kurvenform
(`normal, high, low, baseline, shark, flat`). Ungültige Werte werden verworfen und als Diagnose gemeldet.

> **Wichtig:** Waveforms werden **nicht** übertragen — die UI synthetisiert EKG/Pleth/Kapno lokal aus
> den Vitalwerten. Ein Adapter muss also nur **numerische Vitalwerte** (~1–2 Hz reicht) plus die
> diskreten Zustände `ekgRhythm`/`capnoShape` liefern. Das hält Bandbreite und RAM minimal.

## Status der Geräte (Zielhardware)

| Adapter | Zweck | Status |
|---|---|---|
| **`probe.js`** | **Verbindungs-Assistent** — lauscht auf 4601/5000/24105/2575, erkennt HL7 automatisch, protokolliert Unbekanntes, ARP-Scan | **fertig** (Erst-Inbetriebnahme) — `node tools/probe-test.js` |
| **`hl7.js`** | Mindray **HL7/PDS** empfangen (falls das Gerät HL7 sendet), PC=Listener, MLLP, ORU^R01 | **fertig + getestet** (`hl7-test`, `hl7-live-test`) |
| **`vscapture.js`** | **Fallback**: Live-CSV von VSCapture „tailen" (VSCapture spricht Mindray) | **fertig** |
| **`simulator.js`** | Test/Demo, 8 Tierarten, 13 Szenarien | **fertig** |
| **`playback.js`** | VitalRecorder/VSCapture/NDJSON/CSV abspielen | **fertig** |
| **`mindray.js`** | proprietärer CentralStation-Binärlink (MD2) | **STUB** — undokumentiert |
| **`lifevet.js`** | (Reserve) — LifeVet läuft über `hl7`/`probe` | — |
| **`../seriell.js`** | **Transport** (kein Adapter): RS-232 direkt am COM-Anschluss **oder** über einen Geräteserver (RS-232→LAN). Für Geräte ohne Netzwerkbuchse: Dräger-MEDIBUS-Familie, Datex-Ohmeda/GE S/5, ältere Monitore. Senden nur über eine ausdrückliche Erlaubnisliste. | **gebaut**, `node tools/seriell-test.js`; Öffnen an COM1 nachgewiesen, Lesen eines echten Geräts noch nicht |
| **`surgivet.js`** | SurgiVet Advisor V9200/V9204: RS-232, Klartext-CSV mit 25 dokumentierten Spalten. **Die Temperaturskalierung wird aus der mitgesendeten °F-Spalte GEMESSEN** (F = C·1,8+32 muss aufgehen), nicht geraten; unmögliche Werte werden verworfen und gemeldet. | **fertig**, 47 Prüfungen (`node tools/surgivet-test.js`) |
| **`medibus.js`** | Dräger MEDIBUS / MEDIBUS.X: Rahmen (ESC/SOH, Prüfsumme, CR), vollständige Zeitmaschinerie (NOP alle 2 s, Antwort binnen 10 s auf **jedes** Kommando, ICC beantworten, Kennung 0161, dann 200 ms, dann Datenkonfiguration). Satzbreite wird aus dem echten Strom bestimmt. **Ohne hinterlegte Codetabelle wird bewusst KEIN Messwert gemeldet** — die Datencodes stehen in einem nicht öffentlichen Dräger-Dokument. | **Verbindung fertig**, 55 Prüfungen (`node tools/medibus-test.js`); Wertezuordnung braucht ein echtes Gerät |

**Ehrliche Lage der Geräte** (Recherche in den Original-Handbüchern):
- **LifeVet 10C** = modularer Mindray-Monitor (BeneView/ePM/BeneVision-Klasse) mit **dokumentiertem
  HL7-Ausgang**: `Wartung → Benutzer-Wartung (888888) → Netzwerk → EMR-Kommunikation` → Server-IP=PC, Port 4601,
  „Real Data Send" EIN. **Bester Kandidat.** VetStation braucht nur Numerik. Über **BeneLink** kann er externe
  Narkosegeräte einbinden (dann per HL7 mit dabei).
- **uMEC12 Vet**: kein HL7-Menü im öffentlichen Handbuch (proprietäres MD2) — *könnte* auf 4601 senden;
  Verbindungs-Assistent testet es am Gerät.
- **Veta 5 Plus**: kein offener Datenweg; EtCO₂ kommt über den Monitor.
Vollständig: **[MINDRAY-HL7.md](MINDRAY-HL7.md)**.

## Protokolle / Freischaltung mit dem Händler klären
- **Eickemeyer** — info@eickemeyer.de: bitte bestätigen, dass **HL7 / Patient Data Share auf uMEC12 Vet
  freigeschaltet** ist (ggf. Service-Aktivierung), den **Menüpfad/Port** nennen, und ob der **LifeVet 10C**
  bzw. **Veta 5 Plus** eine eigene Datenschnittstelle hat.
- **Mindray Animal Care** — nl.info@mindrayanimal.com (uMEC12 Vet, Veta 5 Plus).

Physischer Aufbau (isoliertes Geräte-Netz, eigener Switch): das Gerät verbindet sich zum PC
(**PC-IP = „Serveradresse"** am Gerät eingetragen, Port 5000). VetStation lauscht dort (read-only).

## Neuen Adapter hinzufügen
1. `bridge/src/adapters/<gerät>.js` von `base.js` ableiten; in `connect()` verbinden, in `_onData()` parsen → `this.emit({…})`.
2. In `bridge/src/index.js` unter `ADAPTERS` registrieren (Key = `type`).
3. In `bridge/config/devices.json` (aus `.example` kopieren) mit `"enabled": true` konfigurieren.
4. Mit **Playback** eines echten Mitschnitts gegenprüfen, bevor am Patienten getestet wird.

## Testen ohne Geräte (heute schon möglich)
- **Simulator** (Standard): realistische, driftende Vitalwerte + schaltbare Zwischenfälle je Tierart.
- **Playback**: einen VitalRecorder-/VSCapture-Export als **NDJSON** (eine Zeile = ein Frame im ingest-Modell)
  oder **CSV** (`ts,hr,spo2,etco2,af,sys,dia,temp,ekgRhythm,capnoShape`) abspielen. Beispiel-Config in
  `bridge/config/devices.example.json` (`type: "playback"`).

## Read-only (§10, nicht verhandelbar)
Adapter dürfen **niemals** an ein Gerät schreiben (kein Verstellen von Verdampfer/Beatmung). Der
TCP-Weg ist reines Mitlesen des vom Gerät gesendeten Streams.
