# Rassekatalog, Erstwahl-Narkose und Rettungswege (ab 1.3.0)

Wie die Rasse eines Patienten zu einer Narkoseempfehlung wird, wo die Daten herkommen und wie man
sie ändert, ohne etwas kaputt zu machen.

## Die drei Dateien und warum es drei sind

| Datei | Inhalt | gepflegt | Grösse |
|---|---|---|---|
| `ui/shared/breed-genetics.js` | Motor: Suche, Narkoseplan, Prüfung im Moment der Gabe. Dazu die ursprünglich einzeln gegen Quellen geprüften Erkrankungen und Wirkstoffregeln. | **von Hand** | ~50 KB |
| `ui/shared/narkose-risiko.js` | Erstwahl-Protokolle und Rettungswege — die eigentliche Medizin. | **von Hand** | ~85 KB |
| `ui/shared/breed-katalog.js` | Der Rassekatalog aller acht Tierarten + die Erkrankungen aus der Recherche. | **erzeugt** | ~600 KB |

Die Trennung ist Absicht. Der Katalog hat mehrere hundert Einträge und wird maschinell aus den
Rechercheauszügen zusammengesetzt; die Behandlungsanweisungen sind wenige Dutzend und müssen
gelesen, geprüft und verantwortet werden. Beides in einer Datei hiesse: entweder man erzeugt die
Medizin mit, oder man pflegt den Katalog von Hand.

**`VETBREED.register()` überschreibt nie einen handgepflegten Text.** Es fügt nur Felder hinzu, die
noch fehlen, und vereinigt Mengen (Erkrankungen, Gruppen, Aliase). Ein generierter Katalog kann
einen geprüften Eintrag also ergänzen, aber nicht ersetzen.

## Wie ein Narkoseplan entsteht

```
Rasse  →  ihre Erkrankungen (nach Schwere sortiert)  →  deren Protokolle
       →  ihre Gruppen (brachyzephal, Windhund, Zwergrasse, Artgrundlagen …)  →  deren Protokolle
       →  Artgrundsätze zuletzt (rang 9)
```

Vier Blöcke kommen dabei heraus: **Erstwahl**, **Meiden**, **Worauf achten**, **Stabilisieren**.
Die Reihenfolge innerhalb der Erstwahl ist nicht kosmetisch: bei einer Britisch Kurzhaar mit PKD
*und* HCM steht das Herz oben, weil `CONDITIONS[...].risk` dort `hoch` ist.

Zwei Regeln, die beim Bauen aus Fehlern entstanden sind:

* **Artgebundene Protokolle** (`sp: 'hund'` / `'katze'` / …) werden bei einer anderen Tierart
  **nicht** gezogen. Stattdessen wird nach der Artfassung `<schlüssel>-<art>` gesucht (z. B.
  `boas` → `boas-katze`). Gibt es keine, kommt gar nichts. Lieber keine Empfehlung als die einer
  anderen Tierart — ein Meerschweinchen mit Kaninchenprotokoll sieht auf dem Bildschirm völlig
  normal aus.
* **`rescueOnly`-Einträge** (Notfallabläufe, die die Recherche als „Erkrankung" geliefert hat)
  landen unter *stabilisieren* und nicht unter *erste Wahl*.

## Die Prüfung im Moment der Gabe

`medBuchen()` in `ui/app/index.html` ruft `gabePruefen()` → `VETBREED.checkGabe(rasse, wirkstoff)`.
Bei einer Injektionskombination wird **jede Komponente einzeln** geprüft (`rec.wirkstoffe`) — sonst
bliebe eine Ketamin-Warnung bei „Medetomidin + Ketamin" stumm. Die schwerste Warnung steht vorn.

Die Warnung wandert mit der Gabe durch die ganze Kette und steht am Ende im Protokoll:

```
medBuchen (rec.warnLevel/warnText/breedName)
  → postMessage(vsMed)
  → ui/vetstation-live.js  medEmpfangen → logMed + MSG.MED
  → bridge/src/registry.js medikamentGabe → med.warnText + Klartext in finding
  → bridge/data/protokoll.json  ·  PDF-Ausdruck  ·  Firebase → Web-App (eigene Zeile unter der Gabe)
```

Eine **zurückgenommene** Gabe wird nicht geprüft — sie braucht keinen Rettungsweg.

## Den Katalog neu bauen

```bash
node tools/rassen-bauen.js
```

Liest `docs/rassen-quellen/*.json` und schreibt `ui/shared/breed-katalog.js`. Anderer Quellordner:
`node tools/rassen-bauen.js --quelle <pfad>`.

Der Ordner `docs/rassen-quellen/` liegt im Git-Repo, wird aber **nicht** mit ausgeliefert
(`make-dist.ps1` schliesst ihn aus) — die Stationen brauchen die Rohdaten nicht.

**Änderungen an einzelnen Rassen gehören in die Quelle, nicht in `breed-katalog.js`** — dort sind
sie beim nächsten Bau weg. Änderungen an Behandlungsanweisungen gehören in `narkose-risiko.js`.

## Woher die Daten stammen

Rassenamen: FCI/VDH, FIFe/WCF/TICA/GCCF, ZDRK/BRC/ARBA.
Medizin: CliniPharm/CliniTox (vetpharm.uzh.ch), Vetidata, WSU-VCPL, OMIA, UC Davis VGL, PennGen,
WSAVA, ACVAA/AVA, AAHA 2020, BSAVA, Plumb's, MSD/Merck Veterinary Manual, RECOVER, Carpenter
Exotic Animal Formulary, AEMV/ARAV, RVC VetCompass, ACVIM-Konsensuspapiere und peer-reviewte
Journale (JVIM, JSAP, JAVMA, Vet Anaesth Analg, JFMS, Vet Record).

Jeder Eintrag trägt seine Quellen mit; die Oberfläche zeigt sie unter der jeweiligen Karte.
Wo die Recherche nichts Belegtes fand, steht `konfidenz: niedrig` in der Quelle und der Eintrag ist
entsprechend zurückhaltend formuliert.

### Drei Stellen, an denen der Befund der verbreiteten Annahme widerspricht

Sie sind so übernommen worden, wie die Belege sie hergeben — nicht so, wie man es erwartet:

1. **Widder- und Kurzkopfkaninchen haben nicht mehr Zahnerkrankungen.** Die grösste vorliegende
   Untersuchung (RVC VetCompass 2024, n = 161 979) findet weder Schlappohr noch brachyzephale
   Kopfform als Risikofaktor. Belegt sind das Alter (ab 5 Jahren 7,6-faches Risiko) und —
   gegenläufig zur Erwartung — ein *niedrigeres* Risiko oberhalb 2 kg. Die gegenteilige Aussage
   stammt aus einer Tierheimstichprobe mit n = 30. Beim Widder gut belegt ist dagegen der
   **Gehörgang** (Zerumenstau, Otitis).
2. **Riesenkaninchen und Kardiomyopathie**: durch keine Quelle gestützt. Die Kardiologie des
   Kaninchens (2,6 % Prävalenz, JAVMA 2021) zeigt keinen Rassebezug — der Befund entscheidet, nicht
   die Rasse.
3. **Atropinesterase beim Kaninchen**: die Literatur streut zwischen „einem Drittel" und „rund
   der Hälfte". Es gibt keine belastbare Einzelzahl, deshalb steht im Katalog „bei jedem Kaninchen
   damit rechnen" und Glycopyrrolat als verlässliche Alternative.

Ein **Druckfehler in einer Primärquelle** ist beim Prüfen aufgefallen und **nicht** übernommen
worden: van Zeeland & Schoemaker 2014, Tabelle 5, druckt Flumazenil mit „150 mg/kg IV" (plausibel
150 µg/kg).

## Wächter

`node tools/rassen-test.js` (94 Prüfungen, in `alle-tests.js` eingetragen). Die vier, auf die es
ankommt:

* **Kein toter Verweis.** Eine Rasse, die auf eine nicht vorhandene Erkrankung zeigt, lässt im
  Browser einfach eine leere Karte stehen — das fällt niemandem auf.
* **Keine Rasse doppelt**, und Beinahe-Doppelte („Collie Kurzhaar" / „Kurzhaarcollie") müssen
  **dieselben Erkrankungen** tragen. Sonst wählt der Tierarzt die eine Fassung und sieht die halbe
  Wahrheit.
* **Keine Rasse bekommt den Narkoseplan einer anderen Tierart.** Beim Bauen dreimal passiert
  (Meerschweinchen → Kaninchenplan, Perser → Hunde-BOAS, Frettchen → Hunde-DCM). Auf dem Bildschirm
  sieht das völlig normal aus.
* **Der Weg der Warnung ins Protokoll** wird über alle drei Glieder geprüft (App → Shell → Bridge).
  Fällt eines aus, stimmt der Bildschirm und das Protokoll ist leer.
