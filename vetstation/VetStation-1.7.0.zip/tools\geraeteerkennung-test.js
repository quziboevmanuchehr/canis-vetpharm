'use strict';
/*
 * geraeteerkennung-test.js — die Station darf VORSCHLAGEN, aber niemals RATEN.
 *
 * WAS DIESER TEST FESTHAELT:
 * Die automatische Modellerkennung (bridge/src/geraeteerkennung.js) entscheidet, welcher Menuepfad
 * einem Tierarzt angezeigt wird. Ein falsch erkanntes Modell schickt ihn mitten im OP-Betrieb in
 * ein Menue, das es an seinem Geraet gar nicht gibt — das kostet genau die Zeit, die er nicht hat.
 * Deshalb wird hier vor allem das GEGENTEIL geprueft: dass die Erkennung bei duenner Spurenlage
 * ehrlich "weiss ich nicht" sagt, statt sich auf ein Modell festzulegen.
 *
 * Die Beispiele sind echte Messwerte des Praxis-PCs (MAC-Adressen, Ports, Protokollbytes).
 *
 * Start: node tools/geraeteerkennung-test.js      (laeuft auch in tools/alle-tests.js)
 */
const e = require('../bridge/src/geraeteerkennung');

let pass = 0, fail = 0;
function ok(n, c, x) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (x ? '  -> ' + x : '')); } }

console.log('VetStation — automatische Geraeteerkennung\n');

console.log('Protokoll an den ersten Bytes:');
const mllp = Buffer.concat([Buffer.from([0x0b]), Buffer.from('MSH|^~\\&|LifeVet 10C|||')]);
ok('HL7 im MLLP-Rahmen wird erkannt', e.protokollAusBytes(mllp).id === 'hl7-mllp');
ok('HL7 ohne Rahmen wird erkannt', e.protokollAusBytes('MSH|^~\\&|X|||').id === 'hl7-roh');
// Genau diese Bytes standen im eigenen Mitschnitt des Veta 5 Plus (probe-4601.log).
ok('Mindray MD2 wird erkannt (0x02 / A5 5A)', e.protokollAusBytes(Buffer.from([0x02, 0xa5, 0x5a, 0x10])).id === 'mindray-md2');
ok('MD2 gilt ausdruecklich als NICHT lesbar', e.protokollAusBytes(Buffer.from([0x02, 0xa5, 0x5a])).lesbar === false);
ok('MEDIBUS-Rahmen (ESC) wird erkannt', e.protokollAusBytes(Buffer.from([0x1b, 0x51, 0x30])).id === 'medibus');
ok('Unbekanntes bleibt unbekannt (kein Ratespiel)', e.protokollAusBytes(Buffer.from([0x77, 0x88, 0x99])).id === 'unbekannt');
ok('leere Eingabe stuerzt nicht ab', e.protokollAusBytes('').id === 'leer');
ok('null stuerzt nicht ab', e.protokollAusBytes(null).id === 'leer');

console.log('\nDas Geraet nennt sich selbst (staerkste Spur):');
const r1 = e.erkenne({ hl7Kennung: 'LifeVet 10C', mac: '00-0f-14-2b-10-52', quellPort: 8830, daten: mllp });
ok('erkennt das LifeVet 10C', r1.kandidaten[0] && r1.kandidaten[0].geraetId === 'eickemeyer-lifevet-10c', JSON.stringify(r1.kandidaten[0]));
ok('Sicherheitsgrad "sicher"', r1.kandidaten[0].sicherheit === 'sicher');
ok('gilt als eindeutig', r1.eindeutig === true);
ok('nennt die Begruendung im Klartext', /nennt sich selbst/.test(r1.kandidaten[0].gruende.join(' ')));

console.log('\nNur der Hersteller ist bekannt (MAC) — das darf NICHT reichen:');
const r2 = e.erkenne({ mac: '98:cc:e4:00:d5:eb' });
ok('mehrere Mindray-Modelle kommen in Frage', r2.kandidaten.length >= 2, JSON.stringify(r2.kandidaten.map((x) => x.modell)));
ok('keiner ist "sicher"', r2.kandidaten.every((x) => x.sicherheit !== 'sicher'));
ok('das Ergebnis ist NICHT eindeutig', r2.eindeutig === false);
ok('der Satz nennt Alternativen', /kommen auch in Frage/.test(r2.satz), r2.satz);

/*
 * DIESER ABSCHNITT HAELT EINEN BEFUND FEST, den erst der Test sichtbar gemacht hat (01.08.2026):
 * MAC-Praefix 98:CC:E4 und ein offener Port 4601 kommen bei uMEC12 Vet, Veta 5 Plus UND den
 * ePM-/N-Serie-Monitoren voellig gleich vor. Diese beiden Spuren koennen die Geraete also gar
 * nicht unterscheiden — und der Unterschied ist gewaltig: das uMEC liefert Blutdruck und Alarme,
 * der Veta 5 liefert ueberhaupt nichts Lesbares.
 * Die Erkennung muss hier also mehrere Kandidaten nennen und "nicht eindeutig" sagen, damit die
 * Oberflaeche NACHFRAGT statt zu waehlen. Wuerde sie sich auf eines festlegen, bekaeme ein
 * Veta-5-Besitzer den Menuepfad des uMEC angezeigt — ein Menue, das es an seinem Geraet nicht gibt.
 */
console.log('\nHersteller + Port zusammen — reicht bei Mindray NICHT:');
const r3 = e.erkenne({ mac: '98:cc:e4:00:d5:eb', offenePorts: [4601] });
const gleichauf = r3.kandidaten.filter((x) => x.punkte === r3.kandidaten[0].punkte);
ok('mehrere Modelle liegen gleichauf', gleichauf.length >= 2, JSON.stringify(r3.kandidaten.map((x) => x.modell + ':' + x.punkte)));
ok('uMEC12 Vet ist unter den Kandidaten', r3.kandidaten.some((x) => x.geraetId === 'mindray-umec12-vet'));
ok('Veta 5 ist ebenfalls unter den Kandidaten (er hoert dort wirklich)', r3.kandidaten.some((x) => x.geraetId === 'mindray-veta-5'));
ok('das Ergebnis gilt NICHT als eindeutig — die Oberflaeche muss fragen', r3.eindeutig === false);
ok('Sicherheitsgrad hoechstens "wahrscheinlich"', r3.kandidaten.every((x) => x.sicherheit !== 'sicher'));

console.log('\nEin Port, den nur EIN Modell benutzt (5510 = LifeVet M):');
const r3b = e.erkenne({ quellPort: 5510 });
ok('genau ein Kandidat', r3b.kandidaten.length === 1, JSON.stringify(r3b.kandidaten.map((x) => x.modell)));
ok('und zwar das LifeVet M', r3b.kandidaten[0].geraetId === 'eickemeyer-lifevet-m');
ok('gilt damit als eindeutig', r3b.eindeutig === true);

console.log('\nEin Geraet, das MD2 sendet (der Veta-5-Fall):');
const r4 = e.erkenne({ mac: '98:cc:e4:04:2d:00', quellPort: 4601, daten: Buffer.from([0x02, 0xa5, 0x5a, 0x00]) });
ok('das Protokoll wird als MD2 benannt', r4.protokoll.id === 'mindray-md2');
ok('es wird NICHT behauptet, es sei lesbar', r4.protokoll.lesbar === false);

console.log('\nGar keine Spur:');
const r5 = e.erkenne({});
ok('keine Kandidaten', r5.kandidaten.length === 0);
ok('nicht eindeutig', r5.eindeutig === false);
ok('der Satz sagt ehrlich, dass es unbekannt ist', /nicht bestimmen/.test(r5.satz), r5.satz);
ok('der Satz verweist auf die Auswahl von Hand', /von Hand/.test(r5.satz), r5.satz);

console.log('\nEin Buero-PC darf nicht als Geraet durchgehen:');
const r6 = e.erkenne({ mac: '2c-9c-58-28-4a-59', offenePorts: [445, 139, 3389] });
ok('kein einziger Kandidat', r6.kandidaten.length === 0, JSON.stringify(r6.kandidaten));

console.log('\nEinstieg ueber einen netscan-Teilnehmer:');
const r7 = e.ausNetscanHost({ ip: '192.168.0.50', mac: '98cce400d5eb', offenePorts: [4601] });
ok('liefert dasselbe Ergebnis wie erkenne() mit denselben Spuren',
  JSON.stringify(r7.kandidaten) === JSON.stringify(r3.kandidaten));

console.log('\n---');
console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
console.log('OK (' + pass + ' Pruefungen)');
