'use strict';
/*
 * geraeteeinrichtung-test.js — ein neues Geraet einrichten darf ein LAUFENDES nie beschaedigen.
 *
 * WAS DIESER TEST FESTHAELT (ausdrueckliche Auflage des Nutzers, 01.08.2026):
 * "Du musst die Infrastruktur und Verbindungen von bisherigen eingestellten und verbundenen
 *  Geraeten nicht schaedigen."
 * In einer Praxis liegt waehrend des Einrichtens eines zweiten Geraets moeglicherweise ein Tier in
 * Narkose am ersten. Ein Klick auf "Einrichten" darf deshalb ausschliesslich ANFUEGEN:
 *   - kein vorhandener Adapter wird geloescht, umgeschrieben oder abgeschaltet,
 *   - die Lauschports werden nur ergaenzt, nie gekuerzt und nie umsortiert,
 *   - zweimal Einrichten erzeugt keinen zweiten Eintrag (sonst erscheint dasselbe Geraet doppelt —
 *     genau der Fehler vom 22.07.2026 an Port 8830),
 *   - eine von Hand geaenderte Adresse wird nicht ueberschrieben.
 * Jede dieser vier Zusagen wird hier einzeln nachgewiesen.
 *
 * Start: node tools/geraeteeinrichtung-test.js      (laeuft auch in tools/alle-tests.js)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Geraeteeinrichtung } = require('../bridge/src/geraeteeinrichtung');
const katalog = require('../bridge/src/geraetekatalog');

let pass = 0, fail = 0;
function ok(n, c, x) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (x ? '  -> ' + x : '')); } }

console.log('VetStation — Geraet einrichten\n');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vs-einricht-'));
const konfig = path.join(dir, 'devices.json');

/* Ein BESTEHENDER Zustand, wie er in einer laufenden Praxis aussieht: der Assistent mit seinen
 * gemessenen Ports und ein von Hand gepflegtes Geraet mit fester Adresse. */
function frischerBestand() {
  fs.writeFileSync(konfig, JSON.stringify({
    port: 8770,
    host: '127.0.0.1',
    adapters: [
      { type: 'probe', id: 'assistent', enabled: true, ports: [3502, 4601, 8830], arpScan: true },
      { type: 'hl7', id: 'lifevet-handarbeit', enabled: true, mode: 'client', host: '192.168.0.51', port: 4601, model: 'LifeVet 10C (von Hand)', role: 'combo', ack: true },
    ],
  }, null, 2), 'utf8');
}
function lesen() { return JSON.parse(fs.readFileSync(konfig, 'utf8')); }

const protokoll = [];
function neu(extra) {
  return new Geraeteeinrichtung(Object.assign({
    log: { info: (a, b) => protokoll.push(b), warn: (a, b) => protokoll.push(b), error: () => {} },
    konfigPfad: konfig,
    beispielPfad: konfig,
    registry: { adapters: [], getDevices: () => [] },
    adapterStarten: () => true,
  }, extra || {}));
}

/* ------------------------------------------------------------------ */
console.log('Einrichten fuegt AN, es ersetzt nichts:');
frischerBestand();
const vorher = lesen();
let e = neu();
let b = e.einrichten({ geraetId: 'mindray-umec12-vet', wegId: 'hl7-abfrage-4601' });
ok('meldet Erfolg', b.ok === true, JSON.stringify(b));
let jetzt = lesen();
ok('der von Hand gepflegte Eintrag ist WORTGLEICH unveraendert',
  JSON.stringify(jetzt.adapters.filter((a) => a.id === 'lifevet-handarbeit')) ===
  JSON.stringify(vorher.adapters.filter((a) => a.id === 'lifevet-handarbeit')));
ok('kein Eintrag ist verschwunden', vorher.adapters.every((a) => jetzt.adapters.some((x) => x.id === a.id)));
ok('genau ein Eintrag ist dazugekommen', jetzt.adapters.length === vorher.adapters.length + 1, jetzt.adapters.length + ' statt ' + (vorher.adapters.length + 1));
const neuer = jetzt.adapters.filter((a) => String(a.id).indexOf('katalog-') === 0)[0];
ok('der neue Eintrag traegt seine Herkunft mit', !!neuer && neuer._katalog === 'mindray-umec12-vet/hl7-abfrage-4601');
ok('und ist eingeschaltet', !!neuer && neuer.enabled === true);
ok('und nennt ehrlich, was er liefert', !!neuer && /Blutdruck \(NIBP\) und ALLE Alarme/.test(neuer._hinweis || ''));

console.log('\nDie Lauschports werden nur ergaenzt, nie gekuerzt oder umsortiert:');
frischerBestand();
e = neu();
b = e.einrichten({ geraetId: 'eickemeyer-lifevet-m', wegId: 'push-5510' });
const probe = lesen().adapters.filter((a) => a.type === 'probe')[0];
ok('die drei bestehenden Ports stehen unveraendert und in derselben Reihenfolge vorn',
  JSON.stringify(probe.ports.slice(0, 3)) === JSON.stringify([3502, 4601, 8830]), JSON.stringify(probe.ports));
ok('5510 ist dazugekommen', probe.ports.indexOf(5510) >= 0, JSON.stringify(probe.ports));
ok('es wurde kein Port entfernt', [3502, 4601, 8830].every((p) => probe.ports.indexOf(p) >= 0));
ok('der Bericht sagt, dass ein Neustart noetig ist (kein laufender Assistent da)', b.neustartNoetig === true);
ok('er nennt die Firewall-Freigabe', b.naechsteSchritte.some((s) => /FIREWALL-FREIGEBEN/.test(s)));
/* Die Schritte muessen den ECHTEN Menuepfad des Geraets nennen, nicht eine allgemeine Floskel.
 * Beim LifeVet M ist das seit der Recherche vom 01.08.2026 der EDAN-Weg (SYSTEM MENU → MAINTAIN →
 * Passwort ABC → USER MAINTAIN) — vorher stand hier die falsche Annahme, es sei ein Mindray. */
ok('er nennt den echten Menuepfad des Geraets', b.naechsteSchritte.some((s) => /USER MAINTAIN/.test(s)), JSON.stringify(b.naechsteSchritte));
ok('er nennt das Passwort ABC', b.naechsteSchritte.some((s) => /Passwort ABC/.test(s)));
ok('er warnt vor der Werks-Serveradresse 202.114.4.119', b.naechsteSchritte.some((s) => /202\.114\.4\.119/.test(s)));

console.log('\nEin laufender Verbindungs-Assistent nimmt den Port SOFORT dazu (ohne Neustart):');
frischerBestand();
const laufenderProbe = {
  id: 'assistent', ports: [3502, 4601, 8830], connected: true, offen: [],
  ergaenzePort(p) { this.ports.push(p); this.offen.push(p); return true; },
};
e = neu({ registry: { adapters: [laufenderProbe], getDevices: () => [] } });
b = e.einrichten({ geraetId: 'eickemeyer-lifevet-m', wegId: 'push-5510' });
ok('der laufende Assistent hoert jetzt auch auf 5510', laufenderProbe.offen.indexOf(5510) >= 0);
ok('kein Neustart noetig', b.neustartNoetig === false, JSON.stringify(b));

console.log('\nZweimal Einrichten erzeugt KEINEN zweiten Eintrag:');
frischerBestand();
e = neu();
e.einrichten({ geraetId: 'mindray-umec12-vet', wegId: 'hl7-abfrage-4601' });
const nach1 = lesen().adapters.length;
b = e.einrichten({ geraetId: 'mindray-umec12-vet', wegId: 'hl7-abfrage-4601' });
ok('die Anzahl bleibt gleich', lesen().adapters.length === nach1, lesen().adapters.length + ' statt ' + nach1);
ok('und es wird gesagt, dass es schon eingerichtet war', /bereits eingerichtet/.test(b.meldung));

console.log('\nEine von Hand geaenderte Adresse wird NICHT ueberschrieben:');
frischerBestand();
e = neu();
e.einrichten({ geraetId: 'mindray-umec12-vet', wegId: 'hl7-abfrage-4601' });
let cfg = lesen();
cfg.adapters.filter((a) => String(a.id).indexOf('katalog-') === 0)[0].host = '192.168.0.77';
fs.writeFileSync(konfig, JSON.stringify(cfg, null, 2), 'utf8');
e.einrichten({ geraetId: 'mindray-umec12-vet', wegId: 'hl7-abfrage-4601' });
ok('die Handarbeit steht noch da',
  lesen().adapters.filter((a) => String(a.id).indexOf('katalog-') === 0)[0].host === '192.168.0.77');

console.log('\nEin Weg ohne eigenen Eintrag (Geraet sendet von sich aus):');
frischerBestand();
e = neu();
b = e.einrichten({ geraetId: 'eickemeyer-lifevet-10c', wegId: 'hl7-push-8830' });
ok('es wird KEIN Adapter angelegt (der Assistent nimmt es entgegen)',
  !lesen().adapters.some((a) => String(a.id).indexOf('katalog-') === 0), JSON.stringify(lesen().adapters.map((a) => a.id)));
ok('und das wird auch so gesagt', /kein eigener Eintrag noetig/.test(b.meldung), b.meldung);
ok('der Port 8830 war ohnehin schon da', b.portZustand === 'schon-da', b.portZustand);

console.log('\nAbschalten statt Loeschen:');
frischerBestand();
e = neu();
b = e.einrichten({ geraetId: 'mindray-umec12-vet', wegId: 'hl7-abfrage-4601' });
const id = b.adapterId;
const r = e.entfernen(id);
ok('meldet Erfolg', r.ok === true, JSON.stringify(r));
ok('der Eintrag steht noch in der Datei', lesen().adapters.some((a) => a.id === id));
ok('ist aber ausgeschaltet', lesen().adapters.filter((a) => a.id === id)[0].enabled === false);
const r2 = e.entfernen('lifevet-handarbeit');
ok('ein von Hand eingetragenes Geraet laesst sich hier NICHT abschalten', r2.ok === false, JSON.stringify(r2));
ok('der Assistent selbst laesst sich hier NICHT abschalten', e.entfernen('assistent').ok === false);
ok('und der von Hand gepflegte Eintrag ist unveraendert eingeschaltet',
  lesen().adapters.filter((a) => a.id === 'lifevet-handarbeit')[0].enabled === true);

console.log('\nUnsinnige Eingaben:');
frischerBestand();
e = neu();
const vor = fs.readFileSync(konfig, 'utf8');
ok('unbekanntes Modell: Fehler statt Absturz', e.einrichten({ geraetId: 'traktor' }).ok === false);
ok('unbekannter Weg: es wird der erste Weg genommen, nicht abgestuerzt',
  e.einrichten({ geraetId: 'mindray-umec12-vet', wegId: 'gibtsnicht' }).ok === true);
ok('ohne Modellkennung: Fehler', e.einrichten({}).ok === false);
frischerBestand();
e.einrichten({ geraetId: 'traktor' });
ok('bei einem Fehler wird die Datei GAR NICHT angefasst', fs.readFileSync(konfig, 'utf8') === vor);

console.log('\nGeschrieben wird atomar:');
ok('keine halbe Datei (.neu) bleibt liegen', !fs.existsSync(konfig + '.neu'));

console.log('\nAuskunft ueber den Zustand:');
frischerBestand();
e = neu({ registry: { adapters: [{ id: 'lifevet-handarbeit', connected: true }], getDevices: () => [{ deviceId: 'lifevet-handarbeit', status: 'active', lastTs: Date.now() }] } });
const l = e.liste();
ok('nennt den laufenden Eintrag als laufend', l.filter((x) => x.id === 'lifevet-handarbeit')[0].laeuft === true);
ok('und dass dort Werte ankommen', l.filter((x) => x.id === 'lifevet-handarbeit')[0].letzteDatenVorMs < 2000);
ok('lauschPorts kommt aus dem LAUFENDEN Assistenten, nicht aus der Datei',
  JSON.stringify(neu({ registry: { adapters: [laufenderProbe], getDevices: () => [] } }).lauschPorts()) === JSON.stringify(laufenderProbe.ports));

console.log('\nDer Katalog und die Portliste passen zusammen:');
ok('jeder Netzweg des Katalogs hat einen Port in katalog.datenPorts()',
  katalog.alle().every((g) => (g.wege || []).every((w) =>
    (w.transport !== 'lan' && w.transport !== 'wlan') || katalog.datenPorts().indexOf(Number(w.port)) >= 0)));
ok('netscan.DATA_PORTS enthaelt alle Katalog-Ports',
  katalog.datenPorts().every((p) => require('../bridge/src/netscan').DATA_PORTS.indexOf(p) >= 0));

try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) {}

console.log('\n---');
console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
console.log('OK (' + pass + ' Pruefungen)');
