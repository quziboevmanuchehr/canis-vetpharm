'use strict';
/*
 * logumbruch-test.js — das Diagnose-Log darf das Laufwerk des Praxis-PCs nicht volllaufen lassen.
 *
 * WARUM ES DIESEN WAECHTER GIBT (02.08.2026, am laufenden Praxis-PC gemessen):
 * C:\VetStation\data\diag.log war 6,0 MB gross und enthielt Zeilen ab dem 21.07.2026 — in zwoelf
 * Tagen Dauerbetrieb wurde es kein einziges Mal gekuerzt. Im selben Log stehen 3408 gleichlautende
 * Zeilen "Fern-Live Schreibfehler: HTTP 404" aus wenigen Minuten: die Zusammenfassung in logger.js
 * faengt nur unmittelbar aufeinanderfolgende gleiche Meldungen, und dazwischen lagen andere
 * Quellen. Ein volles Laufwerk heisst auf einer Station: data/protokoll.json laesst sich nicht mehr
 * schreiben — das Narkoseprotokoll ist ein Nachweisdokument.
 *
 * Der Test schreibt NICHT 4 MB. Er prueft die Mechanik: zaehlt der Zaehler mit, wird bei
 * Ueberschreiten wirklich umbenannt, ueberlebt der Vorgaenger genau eine Runde, und wirft nichts.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

let ok_ = 0, bad = 0;
function ok(name, bed, zusatz) {
  if (bed) { ok_++; console.log('  \u2713 ' + name); }
  else { bad++; console.log('  \u2717 ' + name + (zusatz ? '   ' + zusatz : '')); }
}

const logger = require('../bridge/src/logger');
const U = logger._umbruch;

console.log('\nDas Diagnose-Log wird umgebrochen (kein volles Laufwerk):');

ok('logger.js nennt eine Obergrenze', typeof U.MAX === 'number' && U.MAX > 0);
ok('die Obergrenze ist klein genug fuer einen Praxis-PC (<= 16 MB)', U.MAX <= 16 * 1024 * 1024,
  'MAX=' + U.MAX);
ok('es gibt genau eine Vorgaengerdatei (.1), keine wachsende Kette',
  /\.1$/.test(U.ALT) && U.ALT.indexOf(U.DATEI) === 0, U.ALT);

/* Die Mechanik an einer ECHTEN Datei, aber in einem eigenen Ordner: der Test darf das
 * Betriebsprotokoll der Station nicht anfassen. Dafuer wird die Umbruchfunktion nachgebaut —
 * dieselben drei Schritte wie in logger.js: Vorgaenger loeschen, umbenennen, Zaehler neu. */
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vs-log-'));
const datei = path.join(tmp, 'diag.log');
const alt = datei + '.1';
fs.writeFileSync(datei, 'A'.repeat(1000), 'utf8');
fs.writeFileSync(alt, 'ALT-VORGAENGER', 'utf8');
try { fs.unlinkSync(alt); } catch (_) {}
fs.renameSync(datei, alt);
ok('nach dem Umbruch ist die Hauptdatei weg und die Vorgaengerdatei da',
  !fs.existsSync(datei) && fs.existsSync(alt));
ok('die Vorgaengerdatei enthaelt den ALTEN Inhalt (nichts geht verloren)',
  fs.readFileSync(alt, 'utf8').length === 1000);
try { fs.unlinkSync(alt); } catch (_) {}
try { fs.rmdirSync(tmp); } catch (_) {}

/* Und der Beweis am laufenden Modul: der Zaehler wird gefuehrt, statt bei jeder Zeile die
 * Dateigroesse zu erfragen (das waere ein Systemaufruf je Logzeile). */
logger._reset();
ok('vor der ersten Zeile ist der Zaehler ungelesen (-1)', U.stand() === -1, 'stand=' + U.stand());
logger.info('logumbruch-test', 'eine Zeile zum Mitzaehlen');
const nach = U.stand();
ok('nach einer Zeile kennt der Zaehler eine Groesse', typeof nach === 'number' && nach >= 0,
  'stand=' + nach);
logger.info('logumbruch-test', 'eine zweite, andere Zeile');
ok('der Zaehler waechst mit jeder Zeile mit', U.stand() > nach,
  'vorher=' + nach + ' nachher=' + U.stand());

/* Die Zusammenfassung gleicher Meldungen bleibt bestehen — sie ist der erste Damm, der Umbruch
 * der zweite. Beide sind noetig: die Zusammenfassung greift nur bei UNMITTELBAR aufeinander
 * folgenden gleichen Zeilen, und genau daran ist der 404-Sturm vorbeigelaufen. */
logger._reset();
logger.info('a', 'gleich');
logger.info('a', 'gleich');
logger.info('a', 'gleich');
const zeilen = logger.recent(50).filter((e) => e.source === 'a');
ok('gleiche Meldungen hintereinander erzeugen weiterhin nur EINE Zeile', zeilen.length === 1,
  'Zeilen=' + zeilen.length);
logger.info('b', 'etwas anderes');
ok('eine andere Meldung schliesst die Serie als eigene Zeile ab',
  logger.recent(50).some((e) => /wiederholt/.test(e.msg)));

console.log('');
if (bad) { console.log('  ' + bad + ' PRUEFUNG(EN) NICHT BESTANDEN'); process.exit(1); }
console.log('  ALLE ' + ok_ + ' PRUEFUNGEN BESTANDEN');
