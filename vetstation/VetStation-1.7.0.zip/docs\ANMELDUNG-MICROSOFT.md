# Anmelden mit Microsoft / Outlook

Stand 02.08.2026, VetStation 1.2.4.

## Kurz: was fertig ist und was fehlt

**Fertig ist alles am Programm.** Station und Web-App bieten den Knopf „Mit Microsoft / Outlook
anmelden“ an, der Anmeldeweg ist anbieterunabhängig gebaut (Google → `GoogleAuthProvider`, alles
andere → `OAuthProvider(id)`, Microsoft = `microsoft.com`), Popup-zuerst mit Weiterleitung als
Ausweg, und der Anbietername steht seit 1.2.4 auch im Protokoll und in den Fehlermeldungen.

**Es fehlt genau eine Sache, und die kann nur die Praxis selbst tun:** die App-Registrierung bei
Microsoft und das Eintragen der beiden Werte in Firebase. Dabei entsteht ein Konto und es wird ein
Geheimnis eingetippt — beides darf ein Assistent nicht.

**So sieht es heute aus (gemessen am 02.08.2026):**

```
POST identitytoolkit.googleapis.com/v1/accounts:createAuthUri  providerId=google.com     -> OK
POST identitytoolkit.googleapis.com/v1/accounts:createAuthUri  providerId=microsoft.com  -> OPERATION_NOT_ALLOWED
```

Deshalb ist der Microsoft-Knopf auf beiden Oberflächen ausgegraut und trägt den ehrlichen Zusatz
**„— noch nicht freigeschaltet“**. Er wird von selbst aktiv, sobald die Schritte unten erledigt
sind; am Programm ist danach nichts zu ändern und nichts neu zu starten.

## Schritt 1 — App bei Microsoft registrieren

Adresse: <https://entra.microsoft.com> → **Identität** → **Anwendungen** → **App-Registrierungen**
→ **Neue Registrierung**.

| Feld | Wert |
|---|---|
| Name | `VetStation Fern-Live` (frei wählbar, erscheint auf der Zustimmungsseite) |
| Unterstützte Kontotypen | **Konten in einem beliebigen Organisationsverzeichnis UND persönliche Microsoft-Konten** |
| Umleitungs-URI (Typ *Web*) | `https://vet-station.firebaseapp.com/__/auth/handler` |

Der Kontotyp ist wichtig: nur diese Auswahl lässt sowohl private Outlook-/Hotmail-Adressen als auch
Geschäftskonten zu. VetStation setzt bewusst **keinen** `tenant` — damit gilt die Vorgabe `common`,
und die passt genau zu dieser Auswahl.

Die Umleitungs-URI ist wortgetreu einzutragen. Sie folgt dem Muster
`https://<projekt-id>.firebaseapp.com/__/auth/handler`; die Projekt-ID dieses Firebase-Projekts ist
`vet-station`.

### Fallstrick, der am 30.07.2026 Zeit gekostet hat
Das Entra-/Azure-Portal leitet mit einem **privaten** Microsoft-Konto oft auf `…/organizations/`
weiter und lehnt dort private Konten ab. Die Adresszeile dann von Hand auf `…/common/` umschreiben —
danach geht es. Das Firmenkonto `…@ivcevidensia.de` ist der falsche Ort für diese Registrierung: es
ist das Verzeichnis des Arbeitgebers und verlangt zusätzlich SMS-Bestätigung.

## Schritt 2 — Geheimnis erzeugen

In derselben Registrierung: **Zertifikate & Geheimnisse** → **Neuer geheimer Clientschlüssel**.

Der **Wert** (nicht die „Geheimnis-ID“) wird genau einmal angezeigt. Verlässt man die Seite, ist er
nicht mehr abrufbar und man legt ein neues an.

Notiert werden zwei Dinge:
* **Anwendungs-ID (Client)** — steht auf der Übersichtsseite der Registrierung
* **Geheimnis (Wert)** — aus diesem Schritt

Geheimnisse laufen ab (Vorgabe meist 6 oder 24 Monate). Ablaufdatum notieren: läuft es aus, hört die
Microsoft-Anmeldung ohne weitere Vorwarnung auf zu funktionieren.

## Schritt 3 — In Firebase eintragen

<https://console.firebase.google.com> → Projekt **vet-station** → **Authentication** →
**Sign-in method** → **Microsoft** → aktivieren, Anwendungs-ID und Geheimnis eintragen, speichern.

Im selben Bereich unter **Einstellungen → Autorisierte Domains** müssen stehen:

* `quziboevmanuchehr.github.io` (die Web-App)
* `127.0.0.1` (die Station am Praxis-PC)
* `vet-station.firebaseapp.com` (steht ab Werk drin)

Fehlt eine, scheitert die Anmeldung mit `auth/unauthorized-domain`. Die Station nennt genau diesen
Fall im Klartext, statt nur „fehlgeschlagen“ zu zeigen.

## Schritt 4 — Nachprüfen

Ohne Anmeldung, von jedem Rechner aus:

```bash
curl -s -X POST "https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=AIzaSyBqcWNqa-X16O_Z3VAb6mOtRJZhQmGOKj0" -H "Content-Type: application/json" -d "{\"providerId\":\"microsoft.com\",\"continueUri\":\"https://vet-station.firebaseapp.com/__/auth/handler\"}"
```

Kommt eine Antwort **ohne** `OPERATION_NOT_ALLOWED`, ist der Weg offen. Beide Oberflächen fragen
genau das beim Aufbau selbst ab und beschriften den Knopf danach — es ist also nichts zu
konfigurieren und nichts neu zu starten.

## Registrieren über Microsoft — es gibt kein eigenes Formular

Bei OAuth ist die **erste Anmeldung zugleich die Registrierung**: Firebase legt das Praxis-Konto beim
ersten erfolgreichen Microsoft-Login an. Das Fenster „Neues Praxis-Konto anlegen“ in der Web-App gilt
ausschließlich für den Weg **E-Mail + Passwort**. Wer sich mit Microsoft anmelden will, klickt oben
auf den Microsoft-Knopf — auch beim allerersten Mal.

## Gleiche Adresse bei Google und Microsoft

In der Firebase-Konsole ist **„Konten mit derselben E-Mail-Adresse verknüpfen“** aktiv. Meldet sich
dieselbe Adresse einmal über Google und einmal über Microsoft an, entsteht deshalb **dieselbe
Konto-Kennung (uid)** — und damit derselbe Datenpfad `live/<uid>`. Station und Fern-Ansicht sehen
einander also weiterhin.

Wäre die Einstellung aus, entstünden zwei getrennte Konten mit derselben E-Mail — die Station
schriebe in den einen, die Fern-Ansicht läse den anderen, und **beide Bildschirme zeigten dieselbe
E-Mail an**. Genau dagegen zeigen seit 1.2.4 beide Oberflächen die ersten acht Zeichen der
Konto-Kennung: stimmen sie nicht überein, ist das der Grund für eine leere Fern-Ansicht.

## Was am Praxis-PC gilt

Der Kiosk startet Edge mit `--kiosk`. Popups sind dort normalerweise blockiert; `launch-kiosk.ps1`
startet ihn deshalb mit `--disable-popup-blocking`. Die Station versucht **zuerst** das eigene
Anmeldefenster und nur als Ausweg die Weiterleitung — denn `signInWithRedirect` liefert am
Praxis-PC nachweislich nichts (gemessen 29.07.2026: Rücksprung erfolgt, `getRedirectResult` liefert
`null`, kein Fehler; Chrome und Edge trennen den Speicher von `vet-station.firebaseapp.com` gegen
das Origin `127.0.0.1`). Bleibt der Rücksprung leer, sagt die Station das im Klartext, statt still
nichts zu tun.

Die Bridge bekommt vom Browser **nur die Erneuerungs-Kennung**, nie ein Passwort — und sie glaubt
die mitgeschickte Konto-Kennung nicht, sondern holt sie sich selbst (`cloud._refresh()`). Seit 1.2.4
verlangt dieser Weg zusätzlich `Content-Type: application/json` und eine passende Herkunft, damit
keine im Browser des Praxis-PCs geöffnete fremde Webseite die Station auf ein anderes Konto
umhängen kann.
