'use strict';
/*
 * gaben-protokoll-test.js — sichert die Regel, um die es dem Tierarzt geht:
 *
 *   IN DAS NARKOSEPROTOKOLL KOMMT NUR, WAS ER SELBST ALS „GEGEBEN" BESTAETIGT HAT.
 *
 * Die App rechnet und empfiehlt laufend Narkosemittel und Notfallmedikamente. Nichts davon darf
 * protokolliert werden — er kann jede Empfehlung uebergehen (anderes Mittel, andere Dosis, gar
 * nichts). Erst der Klick auf „○ als gegeben" macht daraus eine Gabe, und die muss dann UEBERALL
 * ankommen: im dauerhaften Protokoll der Bridge, im PDF-Ausdruck und in der Fern-Ansicht.
 *
 * Zweiter Teil: aus jedem Fenster, das sich vor die Arbeitsflaeche legt, muss ein Weg zurueck
 * fuehren. Der Kiosk-Edge hat keinen Zurueck-Knopf — ein PDF ohne eigenen Rueckweg war eine
 * Sackgasse mitten in der Narkose.
 *
 * Der Bridge-Teil laeuft ECHT (Registry wird instanziiert und gefragt), der Oberflaechen-Teil ist
 * ein Quell-Check — die Dateien laufen im Browser, nicht in node.
 *
 * Start: node tools/gaben-protokoll-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(WURZEL, 'ui', 'app', 'index.html'), 'utf8');
const shell = fs.readFileSync(path.join(WURZEL, 'ui', 'vetstation-live.js'), 'utf8');
const shellCss = fs.readFileSync(path.join(WURZEL, 'ui', 'vetstation-shell.css'), 'utf8');
const server = fs.readFileSync(path.join(WURZEL, 'bridge', 'src', 'server.js'), 'utf8');
const model = fs.readFileSync(path.join(WURZEL, 'bridge', 'src', 'model.js'), 'utf8');

// Die Web-App liegt im Nachbar-Repo. Fehlt sie (fremder Rechner, nur das Stations-Repo
// ausgecheckt), wird dieser Abschnitt uebersprungen statt falsch zu melden.
const WEB = path.join(WURZEL, '..', '..', 'canis-vetpharm', 'canis-anaesthesie', 'index.html');
const web = fs.existsSync(WEB) ? fs.readFileSync(WEB, 'utf8') : null;

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

console.log('Verabreichte Medikamente im Narkoseprotokoll + Rueckweg aus jedem Fenster — Selbsttest\n');

/* =============================================================================
 * 1) DIE BRIDGE — echt ausgefuehrt
 * ============================================================================= */
console.log('1) Bridge: registry.medikamentGabe()');
const { Registry } = require(path.join(WURZEL, 'bridge', 'src', 'registry'));
const stumm = { info() {}, warn() {}, error() {}, debug() {} };
const reg = new Registry({ log: stumm });
// Auf Wegwerf-Dateien umlenken, BEVOR irgendetwas schmutzig wird: sonst schriebe dieser Test in
// den echten Protokollbestand der Entwicklungsablage.
reg.protokollDatei = path.join(os.tmpdir(), 'vetstation-test-protokoll-' + process.pid + '.json');
reg.akteDatei = path.join(os.tmpdir(), 'vetstation-test-akte-' + process.pid + '.json');
reg.protokoll = {}; reg.protokollKopf = {}; reg._protokollSchmutzig = false;

ok('leere Angaben werden abgewiesen',
  reg.medikamentGabe('', { name: 'X' }) === false
  && reg.medikamentGabe('P1', null) === false
  && reg.medikamentGabe('P1', { name: '   ' }) === false);

const gutGeschrieben = reg.medikamentGabe('P1', {
  name: 'Propofol', kind: 'medikament', kindText: 'Injektionsnarkotikum', id: 'propofol',
  dosis: '44–88 mg ≈ 4.4–8.8 mL', route: 'IV', kg: 22,
});
ok('eine bestaetigte Gabe wird angenommen', gutGeschrieben === true);

const l1 = reg.protokollVon('P1').eintraege;
ok('sie steht als eigene Protokollzeile', l1.length === 1 && l1[0].art === 'med');
ok('Wirkstoff, Dosis, Weg und Gewicht stehen darin',
  l1[0].med.name === 'Propofol' && /4\.4/.test(l1[0].med.dosis) && l1[0].med.route === 'IV' && l1[0].med.kg === 22);
ok('der Klartext steht zusaetzlich im Bestandsfeld finding (alte Leser zeigen ihn dann auch)',
  /gegeben: Propofol/.test(l1[0].finding || ''));
ok('die Messfelder bleiben leer (es ist keine Messung)',
  l1[0].hr === null && l1[0].spo2 === null && l1[0].map === null);

/*
 * DER ZEITPUNKT IST DER SCHLUESSEL. In der Cloud liegt jede Zeile unter
 * protokoll/<Patient>/<Zeitpunkt> und ist dort unveraenderlich — ein zweites Mal derselbe Wert
 * waere eine DAUERHAFT abgewiesene Zeile. Beim Wechsel der Einleitung entstehen zwei Zeilen in
 * derselben Millisekunde (die alte zurueckgenommen, die neue gegeben); genau der Fall wird hier
 * geprueft.
 */
reg.medikamentGabe('P1', { name: 'Alfaxalon', storno: true });
reg.medikamentGabe('P1', { name: 'Ketamin' });
const l2 = reg.protokollVon('P1').eintraege;
const zeiten = l2.map((e) => e.ts);
ok('drei Zeilen, drei verschiedene Zeitpunkte (Cloud-Schluessel)',
  l2.length === 3 && new Set(zeiten).size === 3, JSON.stringify(zeiten));
ok('die Zeitpunkte steigen', zeiten[0] < zeiten[1] && zeiten[1] < zeiten[2]);
ok('Zuruecknehmen loescht nichts, es erzeugt eine eigene Zeile',
  l2[1].med.storno === true && /zurückgenommen: Alfaxalon/.test(l2[1].finding));

ok('der Patient bekommt Kopfdaten, auch ohne einen einzigen Messwert',
  (reg.protokollVon('P1').kopf || {}).patientId === 'P1');
ok('und taucht damit in der Exportliste auf',
  reg.protokollListe().some((x) => x.patientId === 'P1' && x.anzahl === 3));

// Die Fern-Uebertragung nimmt die Zeile unveraendert mit.
const fuerCloud = reg.protokollFuerCloud();
ok('protokollFuerCloud() liefert die Gabe mit',
  (fuerCloud.P1 || []).some((e) => e.art === 'med' && e.med && e.med.name === 'Ketamin'));

// Ueberlange Angaben werden gekappt: die Datenbankregel begrenzt jedes Textfeld auf 2000 Zeichen.
reg.medikamentGabe('P1', { name: 'N'.repeat(500), dosis: 'D'.repeat(3000) });
const lang = reg.protokollVon('P1').eintraege.slice(-1)[0];
ok('ueberlange Felder werden gekappt (Datenbankregel: hoechstens 2000 Zeichen)',
  lang.med.name.length <= 120 && lang.med.dosis.length <= 400);

/*
 * NACH EINER GABE SOLL EINE MESSZEILE FOLGEN. Genau dafuer ist ein Narkoseprotokoll da: was
 * hat sich nach dem Mittel geaendert. Der Befundvergleich in protokollSchritt() sorgt dafuer von
 * selbst, weil die Gabe im Feld finding steht — hier wird belegt, dass das auch wirklich passiert.
 */
const vorher = reg.protokollVon('P1').eintraege.length;
reg.protokollSchritt([{ patientId: 'P1', vitals: { hr: 88, spo2: 97 } }], () => null);
const nachher = reg.protokollVon('P1').eintraege;
ok('direkt nach einer Gabe entsteht eine Messzeile', nachher.length === vorher + 1 && nachher.slice(-1)[0].hr === 88);
// … und danach greift wieder der normale 12-Sekunden-Takt (kein Dauerfeuer).
reg.protokollSchritt([{ patientId: 'P1', vitals: { hr: 89, spo2: 97 } }], () => null);
ok('danach gilt wieder der 12-Sekunden-Takt', reg.protokollVon('P1').eintraege.length === nachher.length);

/*
 * PASST DIE ZEILE DURCH DIE DATENBANKREGEL? (installer/firebase-rtdb-rules.json)
 *
 * Das ist keine Formalie: das Saal-Protokoll geht in einem EIGENEN Schreibvorgang hinaus, und die
 * Regel dort verlangt hasChildren(['ts']) mit ts als ZAHL und begrenzt jedes Textfeld auf 2000
 * Zeichen — auf zwei Ebenen ($feld und $tief). Eine Zeile, die daran scheitert, wird nicht etwa
 * verworfen und vergessen: sie wird bei JEDEM Takt erneut angeboten und erneut abgelehnt, und die
 * Fern-Uebertragung des Protokolls schaltet sich nach drei Fehlern selbst ab. Deshalb wird die
 * Form hier gegen die Regel gerechnet, statt sie im Feld zu entdecken.
 */
const regeln = fs.readFileSync(path.join(WURZEL, 'installer', 'firebase-rtdb-rules.json'), 'utf8');
ok('die Regel verlangt weiterhin nur ts (und ts als Zahl)',
  /newData\.hasChildren\(\['ts'\]\) && newData\.child\('ts'\)\.isNumber\(\)/.test(regeln));
const probe = reg.protokollVon('P1').eintraege[0];
function tiefePruefen(o, ebene) {
  let maxTiefe = ebene, zuLang = null;
  Object.keys(o).forEach((k) => {
    const v = o[k];
    if (typeof v === 'string' && v.length > 2000) zuLang = k;
    if (v && typeof v === 'object') {
      const r = tiefePruefen(v, ebene + 1);
      if (r.maxTiefe > maxTiefe) maxTiefe = r.maxTiefe;
      if (r.zuLang) zuLang = r.zuLang;
    }
  });
  return { maxTiefe, zuLang };
}
const form = tiefePruefen(probe, 1);
ok('die Gabenzeile traegt ts als Zahl', typeof probe.ts === 'number' && Number.isFinite(probe.ts));
ok('kein Textfeld ueber 2000 Zeichen', form.zuLang === null, 'zu lang: ' + form.zuLang);
ok('hoechstens zwei Ebenen unter der Zeile ($feld/$tief der Regel)', form.maxTiefe <= 2, 'Tiefe ' + form.maxTiefe);

try { reg.dispose(); } catch (_) {}
try { fs.unlinkSync(reg.protokollDatei); } catch (_) {}
try { fs.unlinkSync(reg.akteDatei); } catch (_) {}

console.log('\n2) Bridge: Nachrichtenweg');
ok('MSG.MED ist vergeben', /MED:\s*'medGabe'/.test(model));
ok('server.js verarbeitet MSG.MED', /case MSG\.MED/.test(server));
ok('und ruft registry.medikamentGabe', /registry\.medikamentGabe\(/.test(server));
ok('patientId hat Vorrang vor patientKey (ueberlebt den Schluesselwechsel)',
  /medikamentGabe\(m\.patientId \|\| m\.patientKey/.test(server));
ok('die Gabe wird im Klartext protokolliert', /logger\.info\('protokoll'/.test(server));

/* =============================================================================
 * 3) DIE APP — nur Bestaetigtes wird gebucht
 * ============================================================================= */
console.log('\n3) Anaesthesie-App (ui/app/index.html)');
ok('state fuehrt eine Gabenliste', /medGaben\s*:\s*\[\]/.test(app));
ok('medBuchen() gibt es', /function\s+medBuchen\s*\(/.test(app));
ok('Medikamenten-Rechner bucht beim Klick', /data-give-drug[\s\S]{0,900}?medBuchen\(\{kind:'medikament'/.test(app));
ok('Injektionsnarkose bucht beim Klick', /data-give\]'\)[\s\S]{0,1200}?medBuchen\(\{kind:'narkose'/.test(app));
ok('Antagonisten haben denselben Knopf', /data-give-rev=/.test(app) && /medBuchen\(\{kind:'antagonist'/.test(app));
ok('Wechsel der Einleitung nimmt die vorherige zurueck', /if\(an && vorher && vorher!==id\) buche\(vorher, true\)/.test(app));
ok('Zuruecknehmen bucht storno statt zu loeschen', /storno:\(ix>=0\)/.test(app));
ok('„Zuruecksetzen" leert die Markierungen, NICHT das Protokoll',
  /injReset[\s\S]{0,600}?state\.givenDrugs=\[\]/.test(app) && !/state\.medGaben\s*=\s*\[\]\s*;/.test(app.replace(/medGaben\s*:\s*\[\]/, '')));
ok('die Gabe geht per postMessage an die Station', /postMessage\(\{vsMed:rec\}/.test(app));
ok('ohne Station wird nichts versprochen, was nicht gilt',
  /function\s+medAnStation\(/.test(app) && /Ohne angeschlossene Station bleibt diese Liste in diesem Browser/.test(app));
ok('die Liste ist in Injektionsnarkose UND Medikamenten sichtbar',
  (app.match(/class="med-log"/g) || []).length >= 2);
ok('der Leertext sagt ausdruecklich, dass Empfehlungen NICHT protokolliert werden',
  /Empfohlene[\s\S]{0,80}werden <b>nicht<\/b> von selbst protokolliert/.test(app));

/*
 * DIE WICHTIGSTE PRUEFUNG DIESER DATEI.
 * Jeder Aufruf von medBuchen() muss in einem Klick-Handler stehen. Entstuende irgendwo ein
 * Aufruf aus einer Render- oder Empfehlungsfunktion heraus, wuerde die App wieder Vorschlaege
 * protokollieren — genau das, was hier ausgeschlossen sein soll, und es faellt niemandem auf,
 * weil das Protokoll dann einfach „voller" aussieht.
 */
const appZeilen = app.split('\n');
const rufe = [];
appZeilen.forEach((z, i) => { if (/medBuchen\(/.test(z) && !/function\s+medBuchen/.test(z)) rufe.push(i); });
const ausserhalb = rufe.filter((i) => {
  for (let k = i; k >= Math.max(0, i - 16); k--) if (/onclick\s*=\s*function/.test(appZeilen[k])) return false;
  return true;
});
ok('JEDER medBuchen-Aufruf sitzt in einem Klick-Handler (keine Empfehlung protokolliert sich selbst)',
  rufe.length >= 4 && ausserhalb.length === 0,
  ausserhalb.length ? ('ausserhalb in Zeile ' + ausserhalb.map((i) => i + 1).join(', ')) : ('nur ' + rufe.length + ' Aufrufe'));

console.log('\n4) Anaesthesie-App: Zurueck / Weiter');
ok('Verlaufsknoepfe sind in der Leiste', /id="navBack"/.test(app) && /id="navFwd"/.test(app));
ok('jeder Ansichtswechsel wird gemerkt', /function\s+switchTab\(v\)\{[\s\S]{0,1400}?navMerke\(\);/.test(app));
ok('auch die Wahl eines Zwischenfalls', /renderVentReco\(\); navMerke\(\)/.test(app));
ok('ein Sprung = EIN Eintrag (navBuendel)', /function\s+navBuendel\(/.test(app) && /navBuendel\(function\(\)\{ state\.incident=id/.test(app));
ok('das Notfall-Dock buendelt ebenfalls', /window\.navBuendel\(tun\)/.test(app));
ok('Alt+Pfeil tut dasselbe wie die Knoepfe', /altKey[\s\S]{0,200}ArrowLeft[\s\S]{0,120}navZurueck/.test(app));
ok('die Knoepfe nennen ihr Ziel im Titel', /Zurück zu: '\+navName/.test(app));
ok('angehaengte Ansichten erfahren vom Wechsel (vs:view)', /CustomEvent\('vs:view'/.test(app));
ok('.navbar traegt jetzt die Sticky-Eigenschaft', /\.navbar\{position:sticky/.test(app));

/* =============================================================================
 * 5) DIE STATION — Weiterleitung, PDF, Rueckweg
 * ============================================================================= */
console.log('\n5) Station (ui/vetstation-live.js)');
ok('die Shell hoert auf die Gaben der Fenster', /addEventListener\('message'[\s\S]{0,300}vsMed/.test(shell));
ok('zugeordnet wird ueber das SENDENDE Fenster, nicht ueber eine mitgeschickte Kennung',
  /function\s+fensterVonQuelle\(/.test(shell) && /cw === quelle/.test(shell));
ok('und dann an die Bridge geschickt', /send\(\{ type: 'medGabe'/.test(shell));
ok('die Gabe landet sofort auch im Fenster-Protokoll (Rueckfall fuer den Ausdruck)', /function\s+logMed\(/.test(shell));
ok('der Ausdruck holt das dauerhafte Protokoll der Bridge', /api\/protokoll\?id=/.test(shell));
ok('die Auswahlliste kennt auch Patienten, die nur die Bridge noch hat (nach F5/Neustart)',
  /function\s+holeProtokollBestand\(/.test(shell) && /protokollBestand\.forEach/.test(shell));
ok('… und fuer die wird auch die richtige Kennung gefunden',
  /protokollBestand\.some\(function \(e\) \{ return String\(e\.patientId\) === String\(key\); \}\)/.test(shell));
ok('… und faellt auf das Fenster-Protokoll zurueck', /bp\.eintraege\.length\) \? bp\.eintraege : \(log\[key\]/.test(shell));
ok('das PDF hat einen eigenen Medikamenten-Abschnitt', /Verabreichte Medikamente \/ Narkosemittel/.test(shell));
ok('er sagt, dass nur Bestaetigtes darin steht', /Nur vom Tierarzt bestätigte Gaben/.test(shell));
ok('der Messverlauf wird ausgeduennt, die Gaben NIE',
  /var vit = L\.filter\(function \(e\) \{ return !e \|\| e\.art !== 'med'; \}\)/.test(shell)
  && /zeilen = zeilen\.concat\(meds\)/.test(shell));

console.log('\n6) Station: PDF-Ansicht mit Rueckweg (Kiosk hat keinen Zurueck-Knopf)');
ok('das PDF wird angezeigt statt blind gespeichert', /function\s+zeigePdfVorschau\(/.test(shell));
ok('doc.save steht nur noch als Rueckfall/Knopf da', !/^\s*doc\.save\('Narkoseprotokoll_/m.test(shell));
ok('Knopf „Zurueck zum Dashboard"', /Zurück zum Dashboard/.test(shell) && /id="pdfBack"/.test(shell));
ok('Blaettern zwischen Patienten (vor und zurueck)', /id="pdfPrev"/.test(shell) && /id="pdfNext"/.test(shell));
ok('Drucken und Speichern bleiben erreichbar', /id="pdfPrint"/.test(shell) && /id="pdfSave"/.test(shell));
ok('Esc fuehrt aus jedem Fenster zurueck',
  /e\.key !== 'Escape'/.test(shell) && /schliessePdf\(\)/.test(shell) && /closePairing\(\)/.test(shell));
ok('das Blob wird wieder freigegeben (der Kiosk laeuft tagelang)', /revokeObjectURL/.test(shell));
ok('kann der Browser kein Blob anzeigen, wird gespeichert statt zu haengen',
  /if \(!url\) \{ try \{ doc\.save\(datei\)/.test(shell));
ok('das Fenster hat einen Stil', /\.vsx-pdf/.test(shellCss) && /\.pdfframe/.test(shellCss));
ok('Esc schliesst auch den Admin-Bereich', /window\.VSADMIN\.close\(\); return;/.test(shell));
const admin = fs.readFileSync(path.join(WURZEL, 'ui', 'views', 'admin.js'), 'utf8');
ok('der Admin-Bereich sagt jetzt, wohin sein Knopf fuehrt (statt nur ✕)',
  /data-x title="Zurück zum Dashboard \(Esc\)">← Zurück</.test(admin) && !/data-x>✕</.test(admin));

/* =============================================================================
 * 7) DIE WEB-APP (Fern-Ansicht)
 * ============================================================================= */
console.log('\n7) Web-App (canis-anaesthesie/index.html)');
if (!web) {
  console.log('  – uebersprungen: das Web-Repo liegt auf diesem Rechner nicht neben dem Stations-Repo.');
} else {
  ok('die App-Haelfte ist nachgezogen (Gabenliste + Zurueck/Weiter)',
    /medGaben\s*:\s*\[\]/.test(web) && /id="navBack"/.test(web) && /function\s+navBuendel\(/.test(web));
  ok('Gaben werden im Verlauf als eigene Zeile gezeigt', /function\s+medZeile\(/.test(web));
  ok('eigene Karte „Verabreichte Medikamente"', /Verabreichte Medikamente &amp; Narkosemittel/.test(web));
  ok('sie sagt, dass Empfehlungen dort nie stehen', /Berechnete[\s\S]{0,60}Empfehlungen der Station stehen hier nie/.test(web));
  ok('auch der Ausdruck fuehrt die Gaben', /Verabreichte Medikamente \/ Narkosemittel/.test(web));
  ok('Druckvorschau statt Sprung in den Druckdialog',
    /host\.id='druckvorschau'/.test(web) && /function\s+druckAusloesen\(blatt, opt\)/.test(web)
    && !/druckAusloesen\(blatt\);/.test(web));
  ok('mit Knopf „Zurueck zur Ansicht"', /Zurück zur Ansicht/.test(web) && /id="dvBack"/.test(web));
  ok('und Esc', /e\.key==='Escape' && druckZurueck/.test(web));
  ok('das Anmeldefenster hat einen Rueckweg (es lag als Vollbild ohne Ausgang ueber der App)',
    /id="vlZurueck"/.test(web) && /Zurück zur App \(ohne Anmeldung\)/.test(web));
  ok('und der Fern-Reiter fuehrt danach wieder hinein', /id="flAnmelden"/.test(web));
  ok('bei einer Verlegung laesst sich zwischen beiden Blaettern blaettern',
    /andereTitel: andere2\.length \? 'Verlauf beider Säle/.test(web) && /andereTitel: '‹ Nur '/.test(web));
  ok('die Vorschau selbst wird NICHT mitgedruckt', /#druckvorschau\{display:none !important\}/.test(web));
  ok('die Fern-Ansicht zeichnet nach „Zurueck" neu (vs:view)', /addEventListener\('vs:view'/.test(web));
  ok('die Demo zeigt zwei Gaben, damit sich das ohne Praxis-PC pruefen laesst',
    /art:'med'[\s\S]{0,400}Propofol/.test(web));
}

console.log('\n' + (fail ? ('FEHLER: ' + fail + ' Test(s) fehlgeschlagen, ' + pass + ' ok')
  : ('ALLE ' + pass + ' Tests bestanden')));
process.exit(fail ? 1 : 0);
