'use strict';
/*
 * geraetefund-test.js — die Station muss dem Geraet FOLGEN, statt an einer toten IP zu klopfen.
 *
 * WAS DIESER TEST FESTHAELT (Befund 22.07.2026, Praxis-PC):
 * In bridge/config/devices.json stand fest "host": "192.168.0.50". Dort antwortete nichts mehr.
 * Das Geraet hing tatsaechlich auf 192.168.0.51 (Mindray-MAC 00:0f:14). Im selben Log standen
 * gleichzeitig:
 *     probe: Mindray-Geraet(e) im Netz gefunden: 192.168.0.51 (00-0f-14-2b-10-52)
 *     hl7:   Geraet 192.168.0.50:4601 antwortet nicht (connect ETIMEDOUT)
 * Die Station WUSSTE die richtige Adresse also und benutzte sie nicht. Genau das darf nie
 * wieder passieren.
 *
 * Start: node tools/geraetefund-test.js      (laeuft auch in tools/alle-tests.js)
 */
const fs = require('fs');
const path = require('path');
const gf = require('../bridge/src/geraetefund');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function read(rel) { try { return fs.readFileSync(path.join(__dirname, '..', rel), 'utf8').replace(/\r\n/g, '\n'); } catch (_) { return ''; } }

console.log('VetStation — die Station folgt dem Geraet (Befund 22.07.2026)\n');

// Echte Ausgabe von `arp -a` des Praxis-PCs (gekuerzt, Werte unveraendert uebernommen).
const ARP_PRAXIS = [
  'Schnittstelle: 192.168.0.99 --- 0x8',
  '  Internetadresse       Physische Adresse     Typ',
  '  192.168.0.1           02-10-18-32-d6-84     dynamisch',
  '  192.168.0.51          00-0f-14-2b-10-52     dynamisch',
  '  192.168.0.104         2c-9c-58-28-4a-59     dynamisch',
  '  192.168.0.233         88-ae-dd-8a-af-aa     dynamisch',
  '  192.168.0.255         ff-ff-ff-ff-ff-ff     statisch',
].join('\n');

console.log('Erkennung aus der ARP-Tabelle:');
gf.leeren();
const treffer = gf.ausArpTabelle(ARP_PRAXIS);
ok('genau EIN Medizingeraet erkannt', treffer.length === 1, JSON.stringify(treffer));
ok('und zwar 192.168.0.51 (das Geraet aus der Praxis)', treffer[0] && treffer[0].ip === '192.168.0.51');
ok('der Router 192.168.0.1 wird NICHT als Geraet gezaehlt',
  !treffer.some((t) => t.ip === '192.168.0.1'));
ok('der zweite PC 192.168.0.233 wird NICHT als Geraet gezaehlt',
  !treffer.some((t) => t.ip === '192.168.0.233'));
ok('Broadcast/Multicast wird ignoriert', !treffer.some((t) => t.ip === '192.168.0.255'));

console.log('\nHerstellererkennung:');
ok('00:0F:14 gilt als Medizingeraet (Mindray/Eickemeyer LifeVet 10C)', gf.istMedizinMac('00-0f-14-2b-10-52'));
ok('98:CC:E4 gilt als Medizingeraet (Mindray uMEC12 Vet)', gf.istMedizinMac('98:cc:e4:11:22:33'));
ok('eine Zufalls-MAC gilt NICHT als Geraet', !gf.istMedizinMac('88-ae-dd-8a-af-aa'));
ok('Schreibweise mit : und - wird gleich behandelt',
  gf.istMedizinMac('00:0F:14:2B:10:52') === gf.istMedizinMac('00-0f-14-2b-10-52'));
ok('Unsinn faellt nicht durch', !gf.istMedizinMac('') && !gf.istMedizinMac(null) && !gf.istMedizinMac('xx'));

console.log('\nWelche Adresse spricht die Station an?');
gf.leeren();
gf.merke(gf.ausArpTabelle(ARP_PRAXIS), 'test');
ok('ohne Vorgabe: das gefundene Geraet', gf.beste(null) === '192.168.0.51');
ok('DER KERNFALL: konfiguriert .50, gefunden .51 -> es wird .51 angesprochen',
  gf.beste('192.168.0.50') === '192.168.0.51');
ok('ist die konfigurierte Adresse im Netz, bleibt es dabei (kein unnoetiger Wechsel)',
  gf.beste('192.168.0.51') === '192.168.0.51');
gf.leeren();
ok('ohne jeden Fund wird ehrlich null gemeldet (statt zu raten)', gf.beste(null) === null);
ok('und der Aufrufer kann die Anzahl abfragen', gf.anzahl() === 0);

console.log('\nDer Verbindungs-Assistent hinterlegt seine Funde:');
const probe = read('bridge/src/adapters/probe.js');
ok('probe.js benutzt geraetefund', /require\('\.\.\/geraetefund'\)/.test(probe));
ok('und traegt jeden Fund dort ein', /geraetefund\.merke\(/.test(probe));
ok('es meldet nur noch AENDERUNGEN ins Log (nicht alle 30 s dieselbe Zeile)',
  /letzterFund/.test(probe));

console.log('\nDer Abfrage-Adapter folgt dem Fund:');
const hl7 = read('bridge/src/adapters/hl7.js');
ok('hl7.js benutzt geraetefund', /require\('\.\.\/geraetefund'\)/.test(hl7));
ok('es gibt eine Aufloesung der Zieladresse je Verbindungsversuch', /_zielHost\(\)/.test(hl7));
ok('"auto" wird als host akzeptiert', /'auto'/.test(hl7));
ok('ohne Fund wird gewartet statt ins Leere zu verbinden',
  /noch kein Geraet im Netz gefunden/.test(hl7));
ok('ein Adresswechsel wird im Log BEGRUENDET, nicht stillschweigend gemacht',
  /die Abfrage folgt der neuen Adresse/.test(hl7));

console.log('\nDie ausgelieferte Vorlage empfiehlt es auch:');
let bsp = null;
try { bsp = JSON.parse(read('bridge/config/devices.example.json')); } catch (_) {}
ok('devices.example.json ist gueltiges JSON', !!bsp);
if (bsp) {
  const hosts = (bsp.adapters || []).filter((a) => a.host).map((a) => a.host);
  ok('mindestens ein Adapter steht auf "auto"', hosts.indexOf('auto') >= 0, hosts.join(', '));
}


/* ---------------------------------------------------------------------------
 * DAS FUND-GEDAECHTNIS MUSS ALTERN (Befund 01.08.2026)
 *
 * Es wurde nie gealtert und nie geleert — merke() fuegte nur hinzu. Eine einmal gesehene Adresse
 * galt damit fuer immer als "im Netz", und beste(bevorzugt) gab hartnaeckig die ALTE Adresse
 * zurueck, auch nachdem das Geraet per DHCP laengst auf eine neue gewechselt war. Ausgerechnet
 * der Fall, fuer den diese Datei gebaut wurde, trat damit wieder ein — nur diesmal, weil die
 * Station ihren eigenen alten Fund fuer aktuell hielt.
 * --------------------------------------------------------------------------- */
console.log('\nDas Gedaechtnis altert (DHCP-Wechsel):');
{
  gf.leeren();
  gf.merke([{ ip: '192.168.0.50', mac: '98cce4000001' }], 'test');
  ok('frisch gesehen -> beste() bleibt bei der bevorzugten Adresse',
    gf.beste('192.168.0.50', Date.now()) === '192.168.0.50');
  const spaeter = Date.now() + gf.FRISCH_MS + 1000;
  ok('istFrisch: gerade gesehen', gf.istFrisch(gf.alle()[0], Date.now()) === true);
  ok('istFrisch: zu alt', gf.istFrisch(gf.alle()[0], spaeter) === false);

  /* DER EIGENTLICHE FALL, mit echter Zeitrechnung statt zweier gleicher Zeitstempel:
   * .50 wurde vor einer Stunde zuletzt gesehen, .51 gerade eben. Genau so sieht ein
   * DHCP-Wechsel im Log aus — die alte Adresse hoert einfach auf, sich zu melden. */
  const T = 5000000;
  gf.leeren();
  gf.merke([{ ip: '192.168.0.50', mac: '98cce4000001' }], 'test', T);
  gf.merke([{ ip: '192.168.0.51', mac: '98cce4000001' }], 'test', T + 60 * 60 * 1000);
  const jetzt = T + 60 * 60 * 1000 + 1000;
  ok('nach dem Wechsel wird die NEUE Adresse angesprochen, nicht die alte',
    gf.beste('192.168.0.50', jetzt) === '192.168.0.51',
    String(gf.beste('192.168.0.50', jetzt)));
  ok('und die alte gilt nicht mehr als frisch',
    gf.istFrisch(gf.alle().filter(function (e) { return e.ip === '192.168.0.50'; })[0], jetzt) === false);

  gf.leeren();
  gf.merke([{ ip: '192.168.0.50', mac: '98cce4000001' }], 'test');
  ok('aufraeumen entfernt den alten Eintrag',
    gf.aufraeumen(Date.now() + gf.FRISCH_MS + 1) === 1 && gf.anzahl() === 0);

  /* Aber: ein leeres Gedaechtnis darf NICHT dazu fuehren, dass ein Adapter gar nicht mehr klopft.
   * Lieber die letzte bekannte Adresse als null — sonst findet er nie zurueck. */
  gf.leeren();
  gf.merke([{ ip: '192.168.0.50', mac: '98cce4000001' }], 'test');
  ok('auch bei nur noch alten Funden kommt eine Adresse zurueck, nicht null',
    gf.beste(null, Date.now() + gf.FRISCH_MS + 1) === '192.168.0.50');
  gf.leeren();
  ok('ohne jeden Fund bleibt es bei null', gf.beste(null, Date.now()) === null);
}

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
