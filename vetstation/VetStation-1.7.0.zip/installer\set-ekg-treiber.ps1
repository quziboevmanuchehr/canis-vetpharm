<#
  set-ekg-treiber.ps1 - installiert den USB-Treiber des Eickemeyer/Grimed EKG 2000 STILL mit.

  WARUM ES DIESE DATEI GIBT (Wunsch 07.08.2026):
  "sodass direkt nach der Installation, ohne extra Treiber vom PC-EKG zu installieren, direkt
  auch in der Setup-Datei enthalten und installiert wird."
  Bis hierher musste in der Praxis nach der VetStation-Installation NOCH das Original-Setup des
  EKG 2000 laufen, nur damit Windows den USB-Wandler kennt. Zwei Installationen fuer ein Geraet
  sind eine Fehlerquelle: wer die zweite vergisst, steckt das EKG an und es passiert nichts -
  ohne jede Meldung, die auf den Treiber zeigt.

  WAS INSTALLIERT WIRD:
  Der FTDI-Treiber, den Eickemeyer dem EKG 2000 beilegt (WHQL-signiert, DriverVer 10/28/2024
  2.12.36.20). Er liegt unveraendert unter treiber\ekg2000\ und besteht aus zwei INF:
    ftdibus.inf   USB-Bus-Treiber   USB\VID_0403&PID_8AC8 = "EKG 2000"
                                    USB\VID_0403&PID_8AC9 = "VETNAR 2200"
    ftdiport.inf  virtueller COM-Port  "EKG 2000 Serial Port"
  Erst dieser zweite macht aus dem Geraet einen COM-Anschluss - und GENAU darueber liest die
  Station spaeter mit (bridge\src\adapters\ekg2000.js). Ohne ftdiport.inf gibt es kein COMx.

  VORINSTALLATION, NICHT ERZWINGEN:
  Es wird in den Windows-Treiberspeicher VORINSTALLIERT. Das heisst: beim ersten Anstecken
  findet Windows den Treiber selbst und richtet das Geraet ohne Nachfrage ein. Es wird KEIN
  Geraet umkonfiguriert, kein vorhandener Treiber verdraengt und nichts entfernt - ein bereits
  installierter neuerer FTDI-Treiber bleibt, wo er ist (Windows waehlt den passendsten).

  IDEMPOTENT: Bei jedem Start/Update laeuft das Skript mit, tut aber nur beim ersten Mal etwas.
  Ein Vermerk in data\treiber-ekg2000.json haelt fest, welcher Stand eingespielt wurde.

  DREI AUFRUFER, UND EINE ZEITLICHE EIGENHEIT, DIE MAN KENNEN MUSS:
    1. installer\Install-VetStation.ps1  (Erstinstallation / USB-Weg)  -> wirkt sofort.
    2. installer\vetstation-setup.iss    ([Run]-Abschnitt)             -> wirkt sofort.
    3. kiosk\launch-kiosk.ps1            (nach einem Update)           -> siehe unten.
  Bei (3) gilt: Apply-StagedUpdate laeuft aus der ALTEN Fassung von launch-kiosk.ps1 und
  ueberschreibt diese Datei waehrend des Laufs. Der Aufruf, der mit einem Update NEU
  hinzukommt, laeuft deshalb erst beim UEBERNAECHSTEN Start. Das ist kein Fehler und laesst
  sich nicht wegprogrammieren (ein Skript kann seinen eigenen, gerade ersetzten Nachfolger
  nicht ausfuehren) - es ist der Grund, warum der Treiber ZUSAETZLICH bei jedem normalen
  Start geprueft wird: spaetestens der naechste Neustart holt es nach, und weil das Skript
  idempotent ist, kostet das nichts.

  BRAUCHT ADMINRECHTE. Beide Aufrufer haben sie:
    installer\Install-VetStation.ps1  erhoeht sich selbst (Zeile 33-46)
    kiosk\launch-kiosk.ps1            laeuft als geplante Aufgabe mit -RunLevel Highest
  Ohne Adminrechte wird NICHT abgebrochen, sondern nur vermerkt - eine Station, die sonst
  laeuft, darf nicht an einem Treiber scheitern.

  PowerShell 5.1: kein Ternaer, kein ??, kein ?. - die Station laeuft auf Windows-Bordmitteln.
#>
[CmdletBinding()]
param(
  [string]$Root = (Split-Path -Parent $PSScriptRoot),   # Stationswurzel (...\VetStation)
  [switch]$Erzwingen                                     # Vermerk ignorieren und neu einspielen
)

$ErrorActionPreference = 'Continue'

$TreiberOrdner = Join-Path $Root 'treiber\ekg2000'
$DatenOrdner   = Join-Path $Root 'data'
$Vermerk       = Join-Path $DatenOrdner 'treiber-ekg2000.json'
$Protokoll     = Join-Path $DatenOrdner 'treiber.log'

function Spur([string]$text) {
  $zeile = ('{0}  {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $text)
  Write-Host $zeile
  try {
    if (-not (Test-Path $DatenOrdner)) { New-Item -ItemType Directory -Force -Path $DatenOrdner | Out-Null }
    Add-Content -LiteralPath $Protokoll -Value $zeile -Encoding utf8
  } catch { }
}

function Ist-Admin {
  try {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $pr = New-Object Security.Principal.WindowsPrincipal($id)
    return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  } catch { return $false }
}

# --- 1) Ist ueberhaupt etwas einzuspielen? -----------------------------------------
$infBus  = Join-Path $TreiberOrdner 'ftdibus.inf'
$infPort = Join-Path $TreiberOrdner 'ftdiport.inf'
if (-not (Test-Path $infBus) -or -not (Test-Path $infPort)) {
  Spur "EKG-2000-Treiber: treiber\ekg2000 fehlt oder ist unvollstaendig - uebersprungen."
  exit 0
}

# Stand = DriverVer aus der INF + Groesse/Zeit der beiden INF. Aendert sich der Treiber,
# aendert sich der Stand, und beim naechsten Lauf wird neu eingespielt.
function DriverVer([string]$inf) {
  try {
    $z = Select-String -LiteralPath $inf -Pattern '^\s*DriverVer\s*=' -ErrorAction Stop | Select-Object -First 1
    if ($z) { return ($z.Line -replace '^\s*DriverVer\s*=\s*', '').Trim() }
  } catch { }
  return 'unbekannt'
}
$stand = '{0}|{1}|{2}|{3}' -f (DriverVer $infBus), (DriverVer $infPort),
         (Get-Item $infBus).Length, (Get-Item $infPort).Length

if (-not $Erzwingen -and (Test-Path $Vermerk)) {
  try {
    $alt = Get-Content -LiteralPath $Vermerk -Raw | ConvertFrom-Json
    if ($alt -and $alt.stand -eq $stand -and $alt.ergebnis -eq 'ok') {
      Spur ("EKG-2000-Treiber: bereits eingespielt (Stand {0}) - nichts zu tun." -f (DriverVer $infBus))
      exit 0
    }
  } catch { }
}

if (-not (Ist-Admin)) {
  Spur "EKG-2000-Treiber: keine Adminrechte - Vorinstallation uebersprungen (die Station laeuft trotzdem)."
  exit 0
}

Spur ("EKG-2000-Treiber wird vorinstalliert (FTDI, DriverVer {0}) ..." -f (DriverVer $infBus))

# --- 2) Einspielen ------------------------------------------------------------------
# Weg 1: pnputil - steckt in jedem Windows, braucht keine mitgelieferte exe.
#        /add-driver <inf> /install  legt in den Treiberspeicher UND richtet passende,
#        bereits angesteckte Geraete gleich mit ein.
# Weg 2: dpinst - das von FTDI/Eickemeyer beigelegte Werkzeug, als Rueckfall fuer den Fall,
#        dass pnputil den Schalter /install nicht kennt (aeltere Windows-Fassungen).
$erfolg = $false
$meldung = ''

$pnputil = Join-Path $env:SystemRoot 'System32\pnputil.exe'
if (Test-Path $pnputil) {
  foreach ($inf in @($infBus, $infPort)) {
    $name = Split-Path $inf -Leaf
    try {
      $aus = & $pnputil /add-driver "$inf" /install 2>&1
      $code = $LASTEXITCODE
      # 0 = erledigt, 259 (ERROR_NO_MORE_ITEMS) = nichts hinzuzufuegen/kein passendes Geraet:
      # beides ist KEIN Fehler fuer eine Vorinstallation.
      if ($code -eq 0 -or $code -eq 259) {
        Spur ("  pnputil {0}: ok (Code {1})" -f $name, $code)
        $erfolg = $true
      } else {
        $meldung = ('pnputil {0} meldet Code {1}: {2}' -f $name, $code, ($aus -join ' '))
        Spur ("  " + $meldung)
        $erfolg = $false
        break
      }
    } catch {
      $meldung = ('pnputil {0} abgebrochen: {1}' -f $name, $_.Exception.Message)
      Spur ("  " + $meldung)
      $erfolg = $false
      break
    }
  }
}

if (-not $erfolg) {
  # Nur die 64-Bit-Fassung von dpinst liegt bei: pnputil (Weg 1) gibt es in JEDEM Windows,
  # auch im 32-Bit, und der zweite dpinst haette das Update-Paket um 0,9 MB verlaengert,
  # ohne einen Fall abzudecken, den pnputil nicht schon abdeckt.
  $dp = Join-Path $TreiberOrdner 'dpinst_amd64.exe'
  if (-not [Environment]::Is64BitOperatingSystem) { $dp = '' }
  if ($dp -and (Test-Path $dp)) {
    try {
      # /S still, /SA keine Assistenten, /SW keine Warnfenster, /PATH der Ordner mit den INF.
      $p = Start-Process -FilePath $dp -ArgumentList '/S','/SA','/SW','/PATH',"`"$TreiberOrdner`"" `
             -Wait -PassThru -WindowStyle Hidden
      # dpinst gibt eine Bitmaske zurueck; das obere Byte 0x80 bedeutet "Fehler".
      $rc = $p.ExitCode
      if (($rc -band 0x80000000) -eq 0) {
        Spur ("  dpinst: ok (Code 0x{0:X})" -f $rc)
        $erfolg = $true
      } else {
        $meldung = ('dpinst meldet Fehler (Code 0x{0:X})' -f $rc)
        Spur ("  " + $meldung)
      }
    } catch {
      $meldung = ('dpinst abgebrochen: ' + $_.Exception.Message)
      Spur ("  " + $meldung)
    }
  } elseif (-not $meldung) {
    $meldung = 'weder pnputil noch dpinst verfuegbar'
    Spur ("  " + $meldung)
  }
}

# --- 3) Vermerk schreiben ------------------------------------------------------------
$ergebnis = 'fehler'
if ($erfolg) { $ergebnis = 'ok' }
try {
  if (-not (Test-Path $DatenOrdner)) { New-Item -ItemType Directory -Force -Path $DatenOrdner | Out-Null }
  $obj = [ordered]@{
    stand     = $stand
    ergebnis  = $ergebnis
    driverVer = (DriverVer $infBus)
    zeit      = (Get-Date).ToString('o')
    meldung   = $meldung
    geraete   = @('USB\VID_0403&PID_8AC8 (EKG 2000)', 'USB\VID_0403&PID_8AC9 (VETNAR/VETMON 2200)')
  }
  ($obj | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $Vermerk -Encoding utf8
} catch { }

if ($erfolg) {
  Spur "EKG-2000-Treiber steht bereit. Das Geraet kann angesteckt werden - Windows richtet es selbst ein."
  exit 0
} else {
  # KEIN Abbruch der Installation: ohne EKG-Treiber laeuft alles andere weiter.
  Spur ("EKG-2000-Treiber NICHT eingespielt: " + $meldung + " - die Station laeuft trotzdem; " +
        "der Treiber laesst sich spaeter mit installer\set-ekg-treiber.ps1 -Erzwingen nachholen.")
  exit 0
}
