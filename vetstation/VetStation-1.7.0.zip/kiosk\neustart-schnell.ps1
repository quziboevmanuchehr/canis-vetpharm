<#
  neustart-schnell.ps1 - VetStation neu starten OHNE UAC-Abfrage.

  WOFUER (Befund 23.07.2026): Der uebliche Neustart (NEUSTART.bat -> stop-kiosk.ps1) beendet die
  erhoeht laufende Station und braucht dafuer jedes Mal eine Bestaetigung der Windows-
  Benutzerkontensteuerung (UAC). In der Praxis wurde diese Abfrage oft nicht bestaetigt, und der
  Neustart - und damit ein bereitgestelltes Update - blieb aus.

  Dieser Weg kommt ohne UAC aus: er beendet nur den node-Prozess der Station. Der Watchdog bzw. die
  Autostart-Aufgabe startet die Station daraufhin von selbst neu - mit dem aktuellen Stand auf der
  Platte (ein zuvor bereitgestelltes Update ist zu diesem Zeitpunkt bereits angewendet). Kommt der
  Watchdog wider Erwarten nicht, startet dieses Skript die Bridge zur Sicherheit selbst.

  STRIKT nur lokal: es wird kein Geraet angefasst, nur der eigene node-Prozess.
#>
param([int]$Port = 8770)

$ErrorActionPreference = 'SilentlyContinue'
Write-Host "VetStation wird neu gestartet (ohne Adminabfrage)..."

<#
  1) Laufenden node-Prozess der Station beenden - und NUR den.

  ZWEI FEHLER, DIE HIER BIS 1.2.1 STANDEN (Gegenpruefung 01.08.2026):

  a) Die Zeile enthielt den Ternaeroperator `$p.ProcessId ? $p.ProcessId : $p.Id`. Den gibt es
     erst ab PowerShell 7. Die Praxis-Station laeuft auf Windows PowerShell 5.1, und dort ist
     das ein PARSERFEHLER - nicht etwa an dieser einen Zeile, sondern fuer die GANZE Datei.
     Nachgemessen am 01.08.2026: "Unerwartetes Token '?' in Ausdruck oder Anweisung."
     Dieses Skript hat also nie irgendetwas getan. Ausgerechnet dieses: es ist der Weg, der
     einen Neustart OHNE UAC-Abfrage ermoeglichen soll - gebaut, weil die Abfrage in der Praxis
     oft nicht bestaetigt wurde und Updates deshalb liegenblieben.

  b) Der Rueckfall `if (-not $eigene) { $eigene = Get-Process node }` haette - waere die Datei je
     gelaufen - JEDEN node-Prozess auf dem Rechner beendet, auch fremde. Genau das, was der
     Kommentar darueber ausschliessen wollte. Ersatzlos gestrichen: findet sich keine eigene
     Station, ist nichts zu beenden.

  Der Abgleich laeuft ueber den ECHTEN Stationsordner, nicht ueber das Wort "VetStation" im
  Pfad - sonst trifft er auch einen Entwicklungsordner wie ...\VetStation\quellcode\.
#>
$Root = Split-Path $PSScriptRoot -Parent
$eigene = @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase) })
if (-not $eigene -or $eigene.Count -eq 0) {
  Write-Host "  Es laeuft keine Station aus $Root - es ist nichts zu beenden."
}
foreach ($p in $eigene) {
  try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; Write-Host "  Station beendet (PID $($p.ProcessId))." }
  catch { Write-Warning "  Konnte den Prozess nicht beenden: $($_.Exception.Message)" }
}

# 2) Kurz warten, ob der Watchdog/die Autostart-Aufgabe die Station von selbst neu startet.
function Laeuft { try { (Invoke-WebRequest "http://127.0.0.1:$Port/api/version" -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200 } catch { $false } }
$ok = $false
for ($i = 0; $i -lt 8; $i++) { Start-Sleep -Seconds 2; if (Laeuft) { $ok = $true; break } }

# 3) Kam sie nicht von selbst zurueck, Bridge direkt starten (Ports > 1024, keine Adminrechte noetig).
if (-not $ok) {
  Write-Host "  Kein automatischer Neustart - starte die Station selbst ..."
  $root = Split-Path $PSScriptRoot -Parent
  $node = Join-Path $root 'node\node.exe'
  if (-not (Test-Path $node)) { $node = 'node' }
  $env:PORT = "$Port"
  Start-Process -FilePath $node -ArgumentList 'bridge\src\index.js' -WorkingDirectory $root -WindowStyle Hidden
  for ($i = 0; $i -lt 10; $i++) { Start-Sleep -Seconds 1; if (Laeuft) { $ok = $true; break } }
}

if ($ok) { Write-Host "VetStation laeuft wieder." } else { Write-Warning "VetStation antwortet noch nicht - bitte START-VetStation.bat verwenden." }
