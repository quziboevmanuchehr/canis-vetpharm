# Mindray/Eickemeyer-Geräte anbinden — ehrlicher Stand & Vorgehen

Ergebnis einer gründlichen Recherche in den **Original-Handbüchern** (uMEC Operator's/Service Manual,
Veta 5 Operator's Manual, LifeVet 10C Manual) und Mindray-Produktdoku. Kurz und ehrlich vorweg:

> **Keines der Geräte hat einen öffentlich dokumentierten, offenen (HL7-)Datenausgang am Gerät.**
> Mindray-Geräte reden ihr **proprietäres „MD2"-Protokoll** mit der **BeneVision CMS Vet**
> (kostenpflichtige PC-Zentrale) bzw. einem **eGateway** — und erst der eGateway erzeugt HL7.

Das relativiert das „einfach Kabel dran und lesen" des Händlers: das **Kabel ist nötig, reicht aber
nicht** — es kommt darauf an, **was** das Gerät über das Kabel sendet (offenes HL7 vs. proprietäres MD2).

## ⭐ Bester Weg: der LifeVet 10C (hat einen DOKUMENTIERTEN HL7-Menüpunkt)
Der **LifeVet 10C** ist ein modularer **Mindray-Monitor** (BeneView-/ePM-/BeneVision-Klasse, System-SW
09.02). Diese Klasse hat HL7 **eingebaut** (kein eGateway für Numerik nötig). Dokumentierter Menüpfad:

`Hauptmenü → Wartung → Benutzer-Wartung` — **Passwort `888888`** → `Netzwerk` → **`EMR-Kommunikation`**
→ **Server-IP = PC-IP** (`192.168.0.99`), **Protokoll = HL7**, **„Real Data Send" = EIN**, **Port = 4601**.
(Die IP des LifeVet selbst ist `192.168.0.51`.)

VetStation braucht **nur die Zahlen** (Kurven zeichnet es selbst) — perfekt, denn Numerik ist bei dieser
Monitor-Klasse der zuverlässige Teil. **→ Zuerst den LifeVet so verbinden; das ist der beste Kandidat.**

**BeneLink-Bonus:** Der LifeVet kann über sein **BeneLink**-Modul externe Narkose-/Beatmungsgeräte
(Dräger, Hamilton, GE …) **einbinden** — deren Daten erscheinen am Monitor und gehen dann per HL7 **mit
raus**. So könnte ein Narkosegerät (über BeneLink + ID-Adapter + passendes Plugin) EtCO₂/Beatmung
beisteuern. (Ob es ein Plugin für den Veta gibt, mit Eickemeyer klären.)

## Zweiter Weg: der uMEC12 Vet — testen mit dem Assistenten
Beim **uMEC12 Vet** zeigt das öffentliche Handbuch **keinen** HL7-Menüpunkt (proprietäres MD2). Er *könnte*
per HL7 senden (VSCapture-Beleg) — das zeigt der **Verbindungs-Assistent** am echten Gerät
(lauscht auf 3502/4601/5000/24105/2575, erkennt HL7 automatisch, protokolliert Unbekanntes, ARP-Scan).

### Schritt-für-Schritt-Test (am echten Gerät)
1. **LAN** verkabeln (ein Switch, PC + Geräte — siehe [LAN-SETUP.md](LAN-SETUP.md)). Dann in `C:\VetStation`
   **`NETZWERK-EINRICHTEN.bat`** **doppelklicken** (liegt auch im *Startmenü → VetStation*, holt sich die
   Adminrechte selbst — UAC mit **Ja** bestätigen). Sie setzt den PC auf **`192.168.0.99`** / 255.255.255.0,
   **kein Gateway**. Geräte: uMEC12 Vet = `192.168.0.50`, LifeVet = `192.168.0.51`.
2. **VetStation starten**: in `C:\VetStation` **`START-VetStation.bat`** **doppelklicken**
   (der Verbindungs-Assistent läuft standardmäßig mit).
3. **Am uMEC12 Vet** (Touch): `Hauptmenü → Wartung/Maintenance → Benutzer-Wartung` — **Passwort `888888`**
   (Werks-/Factory-Wartung: `332888`, Demo: `2088`) → `Netzwerk` / `Netzwerk-Setup` →
   - **`Gateway-Kommunikationseinst.` (Gateway-Comm-Setup)**: `IP-Adresse` = **PC-IP** (`192.168.0.99`),
     `Port` = **`3502`** (Standardziel des uMEC12 — VetStation lauscht dort zuerst; `4601` wird ebenfalls
     mitgelauscht), ggf. `ADT Query` EIN.
   - Beim Gerät selbst muss der **Adresstyp „Manuell"** stehen (nicht DHCP).
   - (Alternativ/zusätzlich, falls vorhanden, ein „HL7"- oder „Export"-Untermenü im Werks-Modus `332888`.)
4. **Prüfen, ob Daten ankommen** — am einfachsten in `C:\VetStation` **`GERAETE-PRUEFEN.bat`**
   **doppelklicken** (liegt auch im *Startmenü → VetStation*). Dasselbe steht im
   **VetStation-Admin → „Verbindung/Fehler"** im Log:
   - **„✓ HL7 ERKANNT auf Port 3502"** (oder `4601`) → **es funktioniert**, die Werte laufen automatisch in
     VetStation. Fertig.
   - **„KEIN HL7 erkannt (evtl. proprietärer CentralStation-Link)"** → das Gerät sendet **MD2 (proprietär)**.
     Dann VetStation nicht direkt nutzbar → siehe **Fallbacks**.
     (Die Rohdaten liegen in `C:\VetStation\bridge\data\probe-3502.log` — Dateiname = der jeweilige Port.)

## Fallbacks, falls kein direktes HL7
### 1. VSCapture als Empfänger (kostenlos, bewährt) — schlüsselfertig
VSCapture „spricht" das Mindray-HL7 und schreibt eine CSV; VetStation liest sie live.
- **Einmalig einrichten** (einmal getippt, danach nur noch Doppelklick): PowerShell per **Rechtsklick →
  „Als Administrator ausführen"** öffnen — das Skript lädt aus dem Internet herunter und legt Ordner an —
  und dort diese Zeile mit **vollständigem Pfad in Anführungszeichen** eingeben:
  ```
  powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\setup-vscapture-fallback.ps1"
  ```
  Es lädt `VSCaptureCLIv1.008Binary.zip` und entpackt nach `C:\VetStation\vscapture`; dort legt es
  auch **`start-vscapture.bat`** an.

  > ⚠️ **Das Skript installiert .NET 8 NICHT — es prüft nur.** Fehlt die **.NET 8 Runtime**, gibt es
  > nur eine Warnung. Dann einmalig von https://dotnet.microsoft.com/download/dotnet/8.0
  > (*.NET Runtime 8.0*) installieren und das Skript **erneut** ausführen. Ohne .NET 8 scheitert der
  > nächste Schritt mit „dotnet … wird nicht als Name eines Cmdlets erkannt".

  (Manuell: Download von https://github.com/xeonfusion/VSCaptureCLI ; .NET 8 von https://dotnet.microsoft.com/download.)
- **Starten**: **`C:\VetStation\vscapture\start-vscapture.bat` doppelklicken** — mehr ist nicht nötig
  (**setzt installiertes .NET 8 voraus**; die `.bat` ruft ebenfalls `dotnet` auf).
  Nur falls doch getippt werden muss (PowerShell, vollständige Pfade, erst in den Ordner wechseln):
  ```
  cd "C:\VetStation\vscapture"
  dotnet VSCaptureMRay.dll -mode 2 -serverport 4601 -interval 1 -export 1
  ```
  Meldet PowerShell „`dotnet` wird nicht als Name eines Cmdlets erkannt", fehlt .NET 8 (siehe oben)
  oder es steht nicht im PATH — dann mit vollem Pfad: `& "C:\Program Files\dotnet\dotnet.exe" VSCaptureMRay.dll …`
  (interaktiv, ebenfalls nach dem `cd`: `dotnet VSCaptureMRay.dll` → `2` = TCP Listener → Port `4601`
  → Intervall `1` = 5 s.)
  Es schreibt **`MRayDataExport.csv`** in dieses Verzeichnis (Spalte 1 `Time`, dann dynamische Parameter-Spalten).
  **Wichtig:** VSCapture lauscht auf **4601** — das Gerät muss dann auf Port `4601` senden (statt `3502`).
- **VetStation** liest die CSV. Dazu im Ordner `C:\VetStation\bridge\config\`:
  1. Liegt dort noch **keine** `devices.json`? Dann `devices.example.json` **kopieren** und die Kopie
     in **`devices.json`** umbenennen. *(Ausgeliefert wird nur die `example`-Datei. Und nur
     `devices.json` überlebt Updates — beim Einspielen wird ausdrücklich nur sie geschützt.)*
  2. `devices.json` mit **Editor/Notepad** öffnen (Rechtsklick → Öffnen mit → Editor).
  3. Beim Adapter `vscapture` setzen: `"enabled": true` und
     `"file": "C:/VetStation/vscapture/MRayDataExport.csv"`.

  Der Adapter ordnet die Spalten über die Kopfzeile zu.
2. **Mindray eGateway** (kostenpflichtig): der dokumentierte Weg zu **echtem HL7** aus dem Mindray-Netz →
   VetStations `hl7`-Adapter liest es. Preise/Freischaltung über Eickemeyer/Mindray.
3. **BeneVision CMS Vet** (kostenpflichtige PC-Zentrale): sammelt die Daten; HL7-Export nur mit eGateway.

## Veta 5 Plus — der CS-Port liefert KEINE Daten (nur Firmware-Update)
Definitiv (Veta-5-Handbuch, Primärquelle): Der **CS-Port des Veta ist laut Hersteller ausschließlich
„Verbindung zum PC für Software-Update"** — **kein** Datenstrom, kein HL7, kein MD2. Der Veta↔Monitor-Link
fließt **hinein**: der Veta **liest EtCO₂ vom Monitor** (für die VS+-Beatmung), er sendet nichts nach außen.
Ein „Anesthesia-Plugin" für BeneLink ist nur für die **humane A-Serie** dokumentiert, nicht für den Veta.

→ **Konsequenz für die Verkabelung:** Das gelbe Kabel im Veta-CS-Port bringt VetStation **nichts**. Die
**Datenquelle ist der Monitor** (uMEC12 Vet **oder** LifeVet 10C). Dessen **Kapno-Modul liefert EtCO₂/FiCO₂/AF**
(OBX 220/221/222) — also ist alles im HL7-Strom des Monitors enthalten. **Es genügt, EINEN Monitor per HL7
anzubinden.** (Für Beatmungs-Detaildaten des Veta gäbe es nur den kostenpflichtigen Mindray-Weg Monitor→CMS.)

## Welche Werte VetStation aus HL7 liest (OBX-Codes, Mindray-PDS-Spezifikation)
`101=HF, 160=SpO₂, 170/171/172=NIBP Sys/Dia/Mean, 220=EtCO₂, 221=FiCO₂, 222=AWRR→AF, 200=T1/213=TB=Temp,
51=Gewicht, 102=PVCs`. Unbekannte Codes landen **automatisch im Diagnose-Log** — in der Praxis ist dafür
nichts zu tun; sie können später in der Software ergänzt werden (siehe Abschnitt „Nur Entwickler-PC").

## Nur Entwickler-PC (D:\VetStation)
*Diese Befehle sind **nicht** für den Praxis-PC gedacht — sie laufen nur auf dem Entwickler-PC mit
Node/npm im Projektordner `D:\VetStation`.*
- Code-Zuordnung der OBX-Codes: `bridge/src/adapters/hl7.js` → `CODE_MAP` (dort neue Codes ergänzen).
- Parser-Tests: `node tools/hl7-test.js` (15/15), `node tools/hl7-live-test.js` (7/7).

## Zwei klare Fragen an Eickemeyer/Mindray
1. **„Sendet der uMEC12 Vet Live-Daten per HL7 über LAN (Port 3502 bzw. 4601), oder nur das proprietäre MD2 an die
   BeneVision CMS Vet? Falls HL7: welcher Menüpfad/Port, und ist es freigeschaltet (Lizenz)?"**
2. **„Gibt es für uns einen offenen Datenausgang (HL7/eGateway) für Monitor UND/ODER Veta — und was kostet die
   Freischaltung?"**

## Quellen (Primär)
- uMEC Operator's/Service Manual (kein HL7-Menü; MD2; Passwörter 888888/332888; Gateway-Comm-Setup).
- Mindray Patient Data Share Programmer's Guide (HL7 v2.3.1, MLLP, ORU^R01, OBX-Codes).
- VSCapture v1.008 (Port 4601, PC=Listener; uMEC numerik-orientiert) — sourceforge.net/projects/vscapture.
- Veta 5 / LifeVet 10C Operator's Manuals (CS=proprietär, kein offener Export).
- Mindray BeneVision CMS Vet / eGateway (proprietäres MD2 bzw. HL7 nur am Gateway).

---

## Patientendaten & alle Messwerte — belegt aus dem Programmer's Guide (23.07.2026)

Quelle: **Mindray Patient Data Share Protocol Programmer's Guide v14.2** (H-0010-20-43061-2, 03/2020),
am Original gelesen. Ergänzt durch den **echten HL7-Mitschnitt** des Praxis-LifeVet.

### Was das Gerät im Live-Betrieb tatsächlich sendet (gemessen)
Der LifeVet sendet im „CONTINUOUS WAVEFORM"-Modus **MDC/IEEE-11073-Codes**:
`MSH | PID (ID, Name, Geschlecht) | PV1 | OBR | OBX(Kurven + MDC_EVT_INOP)`.
**ID, Name, Geschlecht kommen in JEDER Nachricht.** Gewicht/Größe/Tierart **nicht**.

### Warum Gewicht/Größe „fehlen" — und wie sie kommen
Laut Guide (Kap. 6.2/6.8) stehen **Gewicht und Größe NICHT in jeder Nachricht**. Sie kommen in einer
**separaten „Patient Information Change"-Nachricht** (ORU^R01), die **nur beim Verbindungsaufbau oder
beim Ändern der Patientendaten** gesendet wird. Aufbau:
```
OBX||NM|52^Height||62.0||||||F     ← Größe in cm (Mindray-Eigencode 52)
OBX||NM|51^Weight||15.0||||||F     ← Gewicht in kg (Mindray-Eigencode 51)
OBX||ST|2301^MRN||…                 ← am Monitor eingegebene Fallnummer
OBX||CE|2302^BloodType||1^A         ← Blutgruppe
OBX||CE|2303^PACE_Switch||0^Off     ← Schrittmacher
```
- **Es gibt KEIN `MDC_ATTR_PT_WEIGHT`/`188736`** in diesem Protokoll — nicht danach suchen.
- Ist am Gerät **kein Gewicht eingetragen**, sendet es `0.0` (VetStation ignoriert 0.0).
- VetStation **liest 51/52/2301/2302/2303 seit 0.8.0** und **hält sie fest**, solange die Patienten-ID
  gleich bleibt (die Nachricht kommt ja nur einmal). Tierart (Hund/Katze) ist **keine** HL7-Größe —
  einmal im Geräte-Menü setzen, bleibt an die ID gebunden gespeichert.

### Damit ALLE Werte + die Demografie kommen — Schritte am Gerät
1. **Patientendaten am Gerät eintragen** (Patientenverwaltung): Gewicht in kg, ggf. Größe.
2. **HL7-Ausgabe vollständig aktivieren.** N-Series-Menüweg (LifeVet 10C = N-Series-OEM; exakten
   Pfad am Gerät gegenprüfen): `Maintenance` (Passwort **MIN888**) → `Network Setup` → `HL7 Configuration`.
   Dort **Send Data** (Numerik), **Send Waveform** (Kurven) **und** **Send Alarms** auf **EIN**.
3. **Server-IP** = PC (`192.168.0.99`), **Data Interval** auf den kleinsten Wert (flüssige Kurven).
4. **Lizenz:** Realtime/Waveform-HL7 ist bei der N-Series **lizenzpflichtig**. Fehlt die Freischaltung,
   erscheint der HL7-Reiter nicht oder sendet nur Teildaten → bei **Eickemeyer** erfragen.
5. **Demografie auslösen:** nach dem Aktivieren den **Patientendialog neu bestätigen** oder die
   Verbindung neu aufbauen — dann sendet das Gerät die „Patient Information Change"-Nachricht mit
   Gewicht/Größe **einmal**, und VetStation übernimmt sie dauerhaft.

### Numerische Codes (VetStation mappt beide Dialekte, 0.8.0)
Privat (Bettmonitor): 101=HF, 160=SpO₂, 170/171/172=NIBP, 200/201=Temp, 220/250=EtCO₂, 102=PVC.
MDC (LifeVet): 147842=HF, 150456=SpO₂, 150021/150022/150023=NIBP, 151728=EtCO₂, 151570=AF, 150344=Temp.
Einheiten fehlen im Strom oft → aus dem Code abgeleitet. EKG-Kurve (256 Hz) → QRS/Rhythmus/ST-Analyse.

Quellen: Mindray Patient Data Share Protocol Programmer's Guide v14.2; VSCaptureCLI (xeonfusion);
mdpnp/mdpnp HL7Parser.java (MDC-Offsets); Mindray eGateway-Produktdoku.

---

## Verifizierte Nachrecherche (23.07.2026, 17 Agenten mit Gegenprüfung)

Diese Recherche wurde gegen die **Original-Handbücher** geführt und jede Aussage adversarial
gegengeprüft. Sie **korrigiert** einige frühere Annahmen — ehrlich festgehalten, auch wo es dem
widerspricht, was der Händler/Bediener sagt. Der Bediener hat das Gerät vor sich; wo seine Erfahrung
den Handbüchern widerspricht, entscheidet der **echte Mitschnitt** (siehe Binär-Abschnitt).

### Modell-Identität
Der **LifeVet 10C = Mindray ePM 10 Vet** (ePM-Serie, 10"-Vet-Variante) — **nicht** uMEC, N-Series oder
BeneView. Eickemeyer verkauft dasselbe Gerät offen als „Mindray ePM10 Vet". Passwörter der ePM-Serie:
**User-Maintenance 888888, Factory 332888**. (N-Series wäre MIN888/MIN315 — hier nicht zutreffend.)

### Lizenz — Handbuchlage vs. Bedienerangabe
- **Handbücher (N-Series §33.13.12, uMEC §23.16.8) sagen ausdrücklich:** „**Licenses are required for
  sending data, waveforms, and alarms via HL7.**" → HL7-Senden ist dort **lizenzpflichtig**.
- Das **ePM-Vet-Bedienerhandbuch** enthält gar **keinen** HL7-/EMR-Menüpunkt (Netzwerkkapitel ist rein
  CMS-orientiert). Ein „Send HL7" ist dort öffentlich nicht dokumentiert.
- **Bediener meldet:** an seinem konkreten Gerät ist HL7 **ohne Lizenz** aktiv und sendet Daten. Das ist
  möglich (Vet-/OEM-Firmware kann abweichen). → **Nicht wegdiskutieren, sondern messen.**

### Port 8830 — nirgends dokumentiert, aber vom Bediener bestätigt
In **keinem** Mindray-Handbuch (PDS-Guide, N-Series, ePM, uMEC) ist **8830** als HL7-Port belegt.
Dokumentiert sind **4601** (PDS Realtime, Gerät=Server, PC fragt per QRY^R02), **4678** (Bettliste),
**3502** (ADT-Gateway = Demografie-Abruf, **kein** Datenstrom). 8830 ist am ehesten ein
Deployment-/eGateway-Listener. VetStation lauscht ohnehin auf 8830 (probe-Adapter) — die Portfrage ist
also unkritisch, solange dort **HL7** ankommt.

### Der binäre Mitschnitt `02 10 FF A5 5A 00 01 02 03` — geklärt
- Er ist **KEIN HL7.** HL7/MLLP beginnt **zwingend** mit `0x0B` (VT) und endet mit `0x1C 0x0D`. Ein
  Rahmen mit `0x02` (STX) und Sync-Wort `0xA5 0x5A` ist ein **proprietäres Binärprotokoll**
  (Monitor↔CentralStation/CMS). Für dieses Protokoll existiert **kein** öffentlicher Decoder (VSCapture,
  mdpnp, HAPI, Mirth sind alle HL7-only und dekodieren es **nicht**).
- Der vorhandene Mitschnitt (`bridge/data/probe-5062.log`, Port **5062**) sind **26 identische** 9-Byte-
  Rahmen — ein **konstantes Keepalive/Handshake, null Vitaldaten.** Daraus ist nichts zu entziffern.
- **Konsequenz:** Entweder liefert das Gerät auf 8830 **HL7** (dann liest VetStation es direkt, kein
  Reverse Engineering nötig) — oder es liefert diesen **Binärstrom** (dann braucht es einen echten,
  **variierenden** Mitschnitt bei laufender Messung, um Datenfelder zu bestimmen; ein geratener Messwert
  wird in einem Narkose-Monitor **nie** angezeigt).

### Neues Werkzeug: `node tools/binaer-analyse.js [datei]`
Liest einen Mitschnitt, erkennt automatisch **HL7 vs. Binär**, bestimmt bei Binär die **Rahmenlänge**
(Sync-Wort/Autokorrelation) und zeigt, welche **Byte-Positionen sich ändern** (= Kandidaten für
Datenfelder). Urteil bei konstanten Rahmen: „Keepalive, keine Daten". Ordnet **nie** Bytes zu Vitalwerten
zu. → So lässt sich der 8830-Strom eindeutig klassifizieren und ein Binärprotokoll strukturiert reversen.

### So klärst du 8830 endgültig (2 Minuten)
1. Gerät sendet lassen (Sensoren am Patienten, Werte am Monitor sichtbar).
2. In `bridge/config/devices.json` beim probe-Adapter `"rawLog": true` setzen, NEUSTART, ~30 s laufen.
3. `node tools/binaer-analyse.js bridge/data/probe-8830.log`
   - „**sieht nach HL7 aus**" → alles gut, VetStation liest direkt; Werte erscheinen automatisch.
   - „**variiert — Nutzlast**" → Binär; die genannten Offsets sind der Startpunkt fürs Reverse Engineering.
   - „**identisch — Keepalive**" → es kommt nur Handshake; am Gerät „Send Data" wirklich einschalten.

### Veta 5 — endgültig: kein Live-Datenausgang
Bestätigt aus dem Veta-5-Handbuch: **kein** HL7/Seriell/MD2-Live-Ausgang. CS-Port = nur Firmware-Update,
SP-Port = nur interne Waage, USB = nur Offline-Export im Standby. Die Kopplung Monitor↔Veta fließt
**in** den Veta (er liest EtCO₂ zur VS+-Beatmung), **kein** Rückkanal. **Kein** BeneLink-Plugin für den
Veta (nur humane A-Serie). Verdampfer-% und Frischgasfluss sind **mechanisch**, nirgends digital.
→ Ventilationsnahe Werte kann VetStation nur über das **Kapno-Modul des Monitors** bekommen, nicht vom Veta.

---

## NACHGETRAGEN 02.08.2026 — die Mindray-Protokollanleitung ist ÖFFENTLICH, und zwei Pflichten fehlen uns

Die bisherigen Abschnitte dieser Datei stützten sich auf Messungen am Gerät und auf das
VSCapture-Binary. Am 02.08.2026 wurde das **Originaldokument von Mindray selbst** gefunden, frei
abrufbar, ohne Anmeldung:

> **Mindray Patient Data Share Protocol Programmer's Guide**, Dokumentnummer **0010-20-43061-2**,
> Revision **14.0**, März 2020.
> <https://www.mindray.com/content/dam/xpace/en_us/service-and-support/training-and-education/resource--library/technical--documents/operators-manuals-1/H-0010-20-43061-2-Mindray-Patient-Data-Share-Protocol-Programmers-Guide-v14_2-03-2020.pdf>

Daraus zwei Anforderungen, die VetStation **nicht** erfüllt. Beide passen genau zu dem, was am
uMEC12 Vet beobachtet wurde — nämlich dass das Gerät die Abfrage **kommentarlos ignoriert** (kein
QAK, kein MSA, kein ERR) und nur die unaufgefordert gesendeten Alarme und die aperiodische NIBP
liefert.

### 1. `MSH-10` muss `1203` sein

§6.9: Die Message Control ID der Abfrage ist **kein frei wählbarer Wert**. Steht dort etwas anderes,
meldet der Server „cannot be resolved“ — und laut §6.3.3 Punkt 9 wird bei einer fehlerhaften
Nachricht die Verbindung getrennt bzw. schlicht nichts getan. VetStation erzeugt dort bisher eine
laufende Nummer.

Die im Dokument abgedruckte Abfrage (§6.9.6, direkte Verbindung ans Bett) lautet wörtlich:

```
MSH|^~\&|||||||QRY^R02|1203|P|2.3.1<CR>
QRD|20060731145557|R|I|Q895211|||||RES<CR>
QRF|MON||||0&0^1^1^1^<CR>
QRF|MON||||0&0^3^1^1^<CR>
QRF|MON||||0&0^4^1^1^<CR>
```

Harte Formregeln aus demselben Kapitel: `QRD-2 = R`, `QRD-4` nicht leer und unter 16 Byte,
**`QRD-9 = RES`**, `QRF-1 = MON`, `QRF-5` nicht leer. Aufbau von QRF-5:
`<IP>&<IPSeq>^<SendType>^<SendFreq>^<SendAll>^<Liste>`. Bei direkter Verbindung ans Gerät ist
`<IP>&<IPSeq>` **`0&0`**; nur über ein CMS/PDS-Gateway steht dort die IP als 32-Bit-Zahl. Höchstens
**5** Parameter-IDs je QRF-Segment, deshalb mehrere Segmente. SendType: 1 = Parameter,
3 = physiologische Alarme, 4 = technische Alarme, 5 = Konfiguration. **2 ist reserviert.**

### 2. Eine Echo-Nachricht JEDE SEKUNDE, in BEIDE Richtungen

§6.7: Beide Seiten senden im Sekundentakt

```
MSH|^~\&|||||||ORU^R01|106|P|2.3.1|
```

Bleibt sie **10 Sekunden** aus, trennt das Gerät die Verbindung. Genau solche leeren MSH-Rahmen
wurden im Mitschnitt als „Keepalives“ gesehen — das Gerät hat also seine Hälfte gemacht. Ob
VetStation seine Hälfte sendet, ist der Punkt, den das erklärt: die beobachteten `ECONNRESET`- und
Wiederverbindungsschleifen auf `.50:4601` passen dazu.

### Was hier NICHT geändert wurde, und warum

Der Nutzer hat am 02.08.2026 ausdrücklich verlangt, **LifeVet und uMEC12 nicht anzufassen**. Beide
Punkte betreffen genau diesen Weg. Der uMEC12 liefert heute NIBP und Alarme; eine Änderung an der
Abfrage kann das brechen, und dann fehlt im OP ein Blutdruck. Deshalb steht die Erkenntnis hier
dokumentiert, aber **im Code ist nichts geändert**.

**Empfehlung, wenn es probiert werden soll:** an einem Tag ohne Operationen, mit einer Sicherung von
`bridge/config/devices.json`, und mit dieser Erfolgsprüfung: `/api/rohnachrichten` muss danach OBX
vom Typ **`NM`** mit den Codes `101` (HF), `160` (SpO₂), `200` (T1) zeigen — **ohne** die Markierung
`APERIODIC`. Kommt weiterhin nur `CE`, war es doch das Gerät, und der Stand von vorher wird
zurückgesetzt.

### Weitere belegte Zahlen aus demselben Dokument

* Ports: **4601** Realtime-Ergebnisse, **4678** Bettenliste, **UDP 4600** Online-Rundruf.
* Parameter-IDs (Anhang B.1): 101 HF · 151 AF · 160 SpO₂ · 161 PR · 170/171/172 NIBP sys/dia/mean ·
  200/201 T1/T2 · 220 CO₂ · 222 AwRR · 250/251 EtCO₂/FiCO₂ · 268/269 EtISO/FiISO ·
  301 Pmean · 302 PEEP · 303 Pplat · 305 MV · 306 VTE · 309 Frequenz · 310 FiO₂.
* **Kurven gibt es auf diesem Weg nicht.** Das Wort „waveform“ kommt im ganzen Dokument genau
  einmal vor, und zwar als Alarmtext „Waveform Storage Full“. Für VetStation ist das ohne Belang —
  die Kurven werden aus den Zahlen gezeichnet.
* Mindray selbst schreibt in §1.5.5: „Mindray will no longer update and maintain Realtime Results
  Interface. Please make cautious decision for using it.“
