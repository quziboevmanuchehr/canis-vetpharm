'use strict';
/*
 * anaes.js — laedt die klinische Datenbasis (window.ANAES aus der Web-App) in Node,
 * damit der Simulator ECHTE artspezifische Vitalwerte nutzt (eine Quelle der Wahrheit).
 * Faellt bei Fehler auf ein kleines eingebettetes Tabellenwerk zurueck.
 */
const fs = require('fs');
const path = require('path');

/*
 * DIE KANONISCHE DATEI IST ui/app/anaes-data.js - die, die auch der Browser laedt.
 *
 * Bis 1.3.3 stand hier ui/vendor/anaes-data.js, eine KOPIE vom 17.07.2026. Der Kopf dieser Datei
 * verspricht 'eine Quelle der Wahrheit', und genau das war es nicht: die Bridge (Alarmbaender,
 * mL-Dosen der Notfallprotokolle, Geraete-Sollwerte) rechnete mit einem alten Stand, waehrend die
 * Oberflaeche den neuen zeigte. Nachgemessen beim Umstellen: die klinischen Zahlen waren zufaellig
 * noch gleich (nur 'sources' und ein Textfeld in 'machine' wichen ab) - es ist also nie etwas
 * Falsches gerechnet worden. Aufgefallen ist es erst, als vier neue Tierarten in die App-Datei
 * kamen und die Bridge sie nicht sah.
 *
 * Der Rueckfall auf die vendor-Kopie bleibt: ein Paket, in dem ui/app fehlte, soll nicht ohne
 * Datenbasis dastehen.
 */
const APP_FILE = path.join(__dirname, '..', '..', 'ui', 'app', 'anaes-data.js');
const VENDOR_FILE = path.join(__dirname, '..', '..', 'ui', 'vendor', 'anaes-data.js');
const DEFAULT_FILE = fs.existsSync(APP_FILE) ? APP_FILE : VENDOR_FILE;

// Notfall-Fallback: Vital-Mittelbereiche fuer alle 8 Arten (aus anaes-data.js-Normen),
// nur falls die Datei nicht geladen werden kann. [low, high].
const FALLBACK_VITALS = {
  hund:        { hr:[60,140],  rr:[8,20],  spo2:[95,100], etco2:[30,55], map:[70,120], nibp:[90,160],  dia:[55,100], temp:[37.5,39.2] },
  katze:       { hr:[100,180], rr:[10,24], spo2:[95,100], etco2:[30,55], map:[70,120], nibp:[90,160],  dia:[55,100], temp:[37.8,39.5] },
  kaninchen:   { hr:[120,280], rr:[15,40], spo2:[93,100], etco2:[30,50], map:[60,110], nibp:[80,150],  dia:[45,90],  temp:[38.0,40.0] },
  meerschwein: { hr:[150,300], rr:[30,60], spo2:[93,100], etco2:[30,50], map:[55,100], nibp:[70,140],  dia:[40,85],  temp:[37.2,39.5] },
  chinchilla:  { hr:[150,320], rr:[30,70], spo2:[93,100], etco2:[30,50], map:[55,100], nibp:[70,140],  dia:[40,85],  temp:[37.0,38.5] },
  degu:        { hr:[180,360], rr:[40,80], spo2:[93,100], etco2:[30,50], map:[55,100], nibp:[70,140],  dia:[40,85],  temp:[37.0,38.5] },
  maus:        { hr:[300,550], rr:[55,160], spo2:[95,100], etco2:[20,40], map:[60,100], nibp:[80,130], dia:[45,85], temp:[36.5,38] },
  ratte:       { hr:[200,420], rr:[30,90], spo2:[95,100], etco2:[28,45], map:[70,110], nibp:[85,130], dia:[55,95], temp:[36.5,38] },
  rennmaus:    { hr:[230,400], rr:[70,130], spo2:[95,100], etco2:[28,55], map:[50,90], nibp:[60,110], dia:[40,85], temp:[36.5,38.5] },
  hamster:     { hr:[200,450], rr:[30,120], spo2:[95,100], etco2:[28,55], map:[55,95], nibp:[70,120], dia:[45,85], temp:[36,38] },
  frettchen:   { hr:[180,320], rr:[20,40], spo2:[93,100], etco2:[30,50], map:[60,110], nibp:[80,150],  dia:[45,90],  temp:[37.8,40.0] },
  reptil:      { hr:[20,90],   rr:[4,20],  spo2:[90,100], etco2:[15,45], map:[40,90],  nibp:[50,120],  dia:[30,75],  temp:[24,32] },
};

let cache = null;

function loadAnaes(file) {
  if (cache) return cache;
  const f = file || DEFAULT_FILE;
  try {
    const src = fs.readFileSync(f, 'utf8');
    const window = {};
    // Die Datei besteht nur aus window.ANAES-Zuweisungen -> in Sandbox ausfuehren.
    // eslint-disable-next-line no-new-func
    const fn = new Function('window', 'document', 'navigator', src + '\n;return window.ANAES;');
    const ANAES = fn(window, {}, {});
    // PROVISORISCHE Exoten-Notfalldosen additiv einspielen (patcht nur fehlende Artdosen).
    if (ANAES && ANAES.species) {
      try { const patch = require('../../ui/vendor/anaes-exotic-doses.js'); if (patch && patch.apply) patch.apply(ANAES); } catch (_) {}
    }
    cache = ANAES && ANAES.species ? ANAES : null;
  } catch (e) {
    cache = null;
  }
  return cache;
}

function speciesList() {
  const A = loadAnaes();
  if (A && A.species) return A.species.map(s => s.id);
  return Object.keys(FALLBACK_VITALS);
}

function vitalsFor(sp) {
  const A = loadAnaes();
  if (A && A.vitals && A.vitals[sp]) return A.vitals[sp];
  return FALLBACK_VITALS[sp] || FALLBACK_VITALS.hund;
}

function mid(range) { return Math.round((range[0] + range[1]) / 2); }

module.exports = { loadAnaes, speciesList, vitalsFor, mid, FALLBACK_VITALS };
