'use strict';
/*
 * simulator.js — Simulator-Adapter (Test/Demo ohne echte Geraete, §11.1).
 * Erzeugt fuer mehrere virtuelle Patienten je einen Monitor- UND einen Kapno/Narkose-Frame
 * mit DERSELBEN patientId -> demonstriert Auto-Discovery, Patienten-Zuordnung (§6) und
 * Zwei-Fenster-Ansicht. Vitalwerte driften realistisch auf das Szenario-Ziel zu.
 *
 * READ-ONLY: es werden nur Daten erzeugt, nie an ein reales Geraet gesendet.
 */
const { Adapter } = require('./base');
const { targetFor, byId } = require('../scenarios');

function rnd(a) { return (Math.random() * 2 - 1) * a; }

// Standard-Demo-Patienten (verschiedene Arten, fuer Split-View + Matching-Test).
// Zeigt bewusst die ART-VIELFALT (nicht nur Hund): Hund, Katze, Kaninchen, Reptil.
// Weitere Arten (meerschwein/chinchilla/degu/frettchen) via devices.json cloud/adapter-'patients' setzbar.
function defaultPatients() {
  return [
    { devId: 'SIM-MON-1', patientId: 'A-102', species: 'hund', weightKg: 22, scenarioId: 'normal',
      monModel: 'uMEC12 Vet (Sim)', capModel: 'Veta 5 Plus (Sim)' },
    { devId: 'SIM-MON-2', patientId: 'C-077', species: 'katze', weightKg: 4.2, scenarioId: 'normal',
      monModel: 'LifeVet 10C (Sim)', capModel: 'LifeVet 10C Kapno (Sim)' },
    { devId: 'SIM-MON-3', patientId: 'K-210', species: 'kaninchen', weightKg: 2.5, scenarioId: 'normal',
      monModel: 'uMEC12 Vet (Sim)', capModel: 'Veta 5 Plus (Sim)' },
    { devId: 'SIM-MON-4', patientId: 'R-018', species: 'reptil', weightKg: 0.4, scenarioId: 'normal',
      monModel: 'LifeVet 10C (Sim)', capModel: 'LifeVet 10C Kapno (Sim)' },
  ];
}

class SimulatorAdapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.rateMs = cfg.rateMs || 1000;
    this.patients = (cfg.patients || defaultPatients()).map(p => this._init(p));
    this.timer = null;
  }

  _init(p) {
    const t = targetFor(p.scenarioId, p.species, p.weightKg);
    return {
      devId: p.devId, patientId: p.patientId, species: p.species, weightKg: p.weightKg,
      monModel: p.monModel || 'Monitor (Sim)', capModel: p.capModel || 'Kapno (Sim)',
      scenarioId: p.scenarioId,
      cur: Object.assign({}, t), // Startzustand = Szenario-Ziel
    };
  }

  describe() {
    return { id: this.id, model: 'VetStation Simulator', role: 'combo' };
  }

  async connect() {
    this.connected = true;
    this.ctx.log && this.ctx.log.info('simulator', 'Simulator gestartet mit ' + this.patients.length + ' Patient(en), ' + this.rateMs + ' ms.');
    this.timer = setInterval(() => this._tick(), this.rateMs);
    this._tick();
  }

  dispose() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.connected = false;
  }

  // Externe Steuerung (UI -> Bridge SCENARIO).
  setScenario(patientId, scenarioId) {
    const p = this.patients.find(x => x.patientId === patientId);
    if (!p || !byId[scenarioId]) return false;
    p.scenarioId = scenarioId;
    return true;
  }

  listPatients() {
    return this.patients.map(p => ({ patientId: p.patientId, species: p.species, weightKg: p.weightKg, scenarioId: p.scenarioId }));
  }

  _tick() {
    const now = Date.now();
    for (const p of this.patients) {
      const target = targetFor(p.scenarioId, p.species, p.weightKg);
      const c = p.cur;
      // Sanftes Einschwingen auf Zielwerte (arrest schneller).
      const ease = (p.scenarioId === 'vfib' || p.scenarioId === 'asystolie') ? 0.6 : 0.3;
      ['hr', 'spo2', 'etco2', 'fico2', 'af', 'sys', 'dia', 'map', 'temp', 'isoPct'].forEach(k => {
        if (typeof target[k] === 'number') c[k] = c[k] + (target[k] - c[k]) * ease;
      });
      // Diskrete Zustaende hart uebernehmen.
      c.rhythm = target.rhythm; c.capnoShape = target.capnoShape; c.pleth = target.pleth;

      // Messrauschen.
      const hr = Math.max(0, Math.round(c.hr + rnd(c.hr > 0 ? 2 : 0)));
      const spo2 = Math.max(0, Math.min(100, Math.round(c.spo2 + rnd(0.6))));
      const etco2 = Math.max(0, Math.round(c.etco2 + rnd(1)));
      const af = Math.max(0, Math.round(c.af + rnd(af0(c.af))));
      const sys = c.sys > 0 ? Math.round(c.sys + rnd(3)) : 0;
      const dia = c.dia > 0 ? Math.round(c.dia + rnd(2)) : 0;
      const map = sys > 0 && dia > 0 ? Math.round(dia + (sys - dia) / 3) : Math.round(c.map);
      const temp = Math.round((c.temp + rnd(0.05)) * 10) / 10;

      // --- Monitor-Frame (Kreislauf/EKG/SpO2 + Impedanz-Atemfrequenz) ---
      // Der Monitor liefert AF nur als IMPEDANZ-Atmung (ungenauer). Sobald der Kapnograph AF
      // liefert, hat der Vorrang (matching.js) — hier leicht abweichend, damit man das sieht.
      const afImp = Math.max(0, Math.round(c.af + rnd(2)));
      this.emit({
        deviceId: p.devId, deviceModel: p.monModel, deviceRole: 'monitor',
        patientId: p.patientId, species: p.species, weightKg: p.weightKg, ts: now,
        vitals: { hr, ekgRhythm: c.rhythm, spo2, pleth: c.pleth, nibp: { sys, dia, map }, temp, af: afImp },
        alarms: [],
      });

      // --- Kapno/Narkose-Frame (Atmung/EtCO2 + gemeldete Iso% + Beatmungseinstellung) ---
      // Das Narkosegeraet "meldet" hier seinen Modus + Parameter, damit das virtuelle Geraet
      // die Spiegelung zeigen kann (in echt spricht der Veta 5 nur MD2 -> kommt heute nichts).
      const iso = Math.round(c.isoPct * 10) / 10;
      let ventMode = null, ventParams = null, o2Flow = null;
      if (iso > 0) {
        o2Flow = Math.round((0.5 + p.weightKg * 0.02) * 10) / 10;   // grobe Erhaltungs-Frischgasrate
        const vt = Math.max(1, Math.round(10 * p.weightKg));
        if (p.scenarioId === 'vfib' || p.scenarioId === 'asystolie') {
          ventMode = 'Manuell';
        } else if (c.capnoShape === 'shark') {
          ventMode = 'PCV'; ventParams = { pinsp: p.weightKg < 10 ? 10 : 12, af: Math.max(6, af), ie: '1:3', peep: 3 };
        } else if (c.capnoShape === 'flat' || af <= 0) {
          ventMode = 'VCV'; ventParams = { vt, af: 12, ie: '1:2', peep: 3 };
        } else {
          ventMode = 'VCV'; ventParams = { vt, af: Math.max(6, af), ie: '1:2', peep: 3 };
        }
      }
      /*
       * GEMESSENE Beatmungs- und Gaswerte (05.08.2026).
       *
       * Ein echtes Narkosegeraet zeigt neben den EINGESTELLTEN Werten die GEMESSENEN: Spitzendruck,
       * PEEP, zurueckgekommenes Atemzugvolumen, Minutenvolumen, FiO2 und die ausgeatmete
       * Gaskonzentration. Ohne sie liesse sich die neue Anzeige ohne echtes Geraet gar nicht
       * pruefen — und ein Simulator, der weniger sendet als der Bildschirm zeigt, laesst genau die
       * Anzeigefehler durchrutschen, die man nur mit Daten sieht.
       *
       * Bewusst nicht identisch mit den Sollwerten: das Volumen kommt mit ~6 % Verlust zurueck
       * (Kreissystem, Cuff), der Spitzendruck liegt in VCV ueber dem eingestellten Pinsp. Genau
       * dieser Unterschied ist der klinische Sinn der Anzeige.
       */
      const mess = {};
      if (ventParams) {
        const pe = ventParams.peep || 0;
        const vtSoll = ventParams.vt != null ? ventParams.vt : Math.max(1, Math.round(10 * p.weightKg));
        mess.vte = Math.max(1, Math.round(vtSoll * 0.94));
        mess.peep = pe;
        mess.ppeak = (ventMode === 'PCV')
          ? (ventParams.pinsp || 10) + 1
          : Math.max(pe + 4, Math.round(pe + vtSoll / Math.max(1, p.weightKg) * 0.9));
        if (c.capnoShape === 'shark') mess.ppeak += 8;              // Obstruktion -> Druck steigt
        mess.mv = Math.round(mess.vte * Math.max(1, ventParams.af || af) / 10) / 100;
        mess.compl = Math.round(mess.vte / Math.max(1, mess.ppeak - pe) * 10) / 10;
        mess.pmean = Math.round((pe + (mess.ppeak - pe) / 3) * 10) / 10;
      }
      if (iso > 0) {
        mess.fio2 = 95;
        mess.etAgent = Math.round(iso * 0.85 * 100) / 100;           // exspiratorisch unter Verdampfer
        mess.fiAgent = Math.round(iso * 0.96 * 100) / 100;
      }
      this.emit({
        deviceId: p.devId.replace('MON', 'CAP'), deviceModel: p.capModel, deviceRole: 'anesthesia',
        patientId: p.patientId, species: p.species, weightKg: p.weightKg, ts: now,
        vitals: Object.assign({ etco2, fico2: Math.max(0, Math.round(c.fico2)), af, capnoShape: c.capnoShape, ekgRhythm: c.rhythm }, mess),
        isoPct: iso, ventMode, o2Flow, ventParams,
        alarms: [],
      });
    }
  }
}

function af0(v) { return v > 0 ? 1 : 0; }

module.exports = { SimulatorAdapter, defaultPatients };
