# Befund 01.08.2026 — die Station war über zwei Stunden tot, und niemand konnte es merken

> **Wofür dieser Bericht?** Am laufenden Praxis-PC (`C:\VetStation`, Fassung 1.0.1) wurde ein
> Zustand gemessen, den die Software bis dahin nicht kannte und deshalb nicht heilen konnte:
> die Bridge lief, hielt alle Ports — und bediente nichts mehr.
> **Behoben in 1.2.1.** Abgesichert durch `tools/watchdog-test.js` (24 Prüfungen).

---

## 0. Die Kernaussage zuerst

**Die Selbstheilung kannte nur den Absturz. Das Einfrieren heilte sie nicht — sie machte es schlimmer.**

Ein Absturz ist der harmlose Fall: der Prozess ist weg, die Ports sind frei, ein Neustart genügt.
Ein Einfrieren ist der gefährliche: der Prozess **lebt**, hält Port 8770 und alle sieben
Geräteports weiter fest, nimmt TCP-Verbindungen sogar an — und antwortet nie.

Der alte Watchdog prüfte nur „antwortet `/healthz`?“ und startete bei Nein einen **zweiten**
Prozess. Der fand jeden Port belegt, konnte nichts binden und blieb als zweite Leiche stehen.
Danach lief der Watchdog in den `throw` aus `launch-kiosk.ps1`, und weil dort
`$ErrorActionPreference = 'Stop'` gilt und kein `try/catch` darum stand, **endete seine Schleife.**
Ab diesem Moment überwachte niemand mehr irgendetwas.

Und der Absturz fällt auf — der Bildschirm wird leer. Das Einfrieren fällt **nicht** auf: die
Anzeige steht mit den zuletzt empfangenen Werten da, als sei alles in Ordnung.

---

## 1. Was gemessen wurde

Zeitpunkt der Entdeckung: 01.08.2026, 17:00 Uhr. Station seit 06:45 Uhr in Betrieb.

| Messung | Ergebnis |
|---|---|
| Prozess 17332 vorhanden | ja, seit 06:45:39 |
| CPU-Zuwachs in 6 s | **0,000 s** — der Prozess rechnete nicht |
| Ports 2575, 3502, 4601, 5000, 5510, 8830, 24105, 8770 | alle von 17332 gehalten |
| TCP-Verbindung auf 8770 | wird angenommen |
| Antwort auf `GET /healthz` (roh, 6 s Wartezeit) | **kein einziges Byte** |
| `CLOSE_WAIT` auf 8770 | bleibt stehen — der Prozess räumt nicht mehr ab |
| letzte Zeile in `data/diag.log` | 12:37:44Z |
| Standby/Ruhezustand als Ursache | **ausgeschlossen**, System lief seit 31.07. 22:08 durch |
| Kiosk-Browser | lief gar nicht |

Der zweite Prozess (14440, gestartet 14:37:39) hinterließ im Log genau das erwartete Bild:

```
12:37:41Z [warn] probe: Port 3502 ist von einem anderen Programm belegt — VetStation kann dort NICHT zuhoeren.
12:37:41Z [warn] probe: Port 4601 ist von einem anderen Programm belegt — ...
12:37:41Z [error] server: HTTP-Fehler: listen EADDRINUSE: address already in use 127.0.0.1:8770
```

Das „andere Programm“ war die eigene, eingefrorene Station.

---

## 2. Die Ursache des Einfrierens ist **nicht** ermittelt

Das gehört so festgehalten. Es gab keine Fehlerzeile, keinen Absturz, keinen Standby. Der genaue
Auslöser ließ sich nachträglich nicht bestimmen — der Prozess war zum Zeitpunkt der Untersuchung
bereits stumm.

**Deshalb wirkt die Behebung bewusst unabhängig von der Ursache:** sie stellt den Dienst wieder
her, gleich woran er gescheitert ist, und hinterlässt eine Spur, dass es passiert ist. Häufen sich
die Einträge in `data/watchdog.log`, ist das der Anhaltspunkt für die eigentliche Ursachensuche.

Eine Vermutung, ausdrücklich als solche gekennzeichnet: Die Bridge wird über
`Start-Process -WindowStyle Hidden` gestartet und schreibt jede Protokollzeile mit `console.log`
in ein eigenes, unsichtbares Konsolenfenster. Schreibvorgänge dorthin sind unter Windows
blockierend. Das passt zum Bild (0 % CPU, alle Threads wartend), ist aber **nicht belegt** und
wird hier nur als Spur für später notiert.

---

## 3. Was geändert wurde

### 3.1 Der Watchdog unterscheidet jetzt vier Lagen (`kiosk/watchdog-entscheidung.ps1`)

| Lage | Entscheidung |
|---|---|
| Station antwortet | `ok` |
| antwortet nicht, aber noch nicht oft genug hintereinander | `warten` |
| antwortet nicht, **niemand** hält den Port → abgestürzt | `starten` |
| antwortet nicht, **unser** Prozess hält den Port → eingefroren | `beenden-und-starten` |
| antwortet nicht, ein **fremdes** Programm hält den Port | `fremd` (nicht anfassen, nur melden) |

Die Entscheidung steht in einer eigenen, nebenwirkungsfreien Datei. Grund: Code, der Prozesse
beendet, muss prüfbar sein, **ohne** dass beim Prüfen etwas beendet wird.

### 3.2 Drei Sicherungen gegen einen übereifrigen Watchdog

- **Schwelle:** erst nach 3 erfolglosen Prüfungen **hintereinander** (~30 s) wird eingegriffen.
  Ein einzelner Aussetzer durch Last oder Virenscanner beendet nichts.
- **Zeitgrenze 4 s** statt 2 s: eine beschäftigte Station darf nicht allein deshalb für tot
  erklärt werden, weil sie einen Moment braucht.
- **Herkunftsprüfung:** beendet wird nur ein Prozess, der `node` heißt **und** dessen Programmpfad
  im Stationsordner liegt. Ist der Pfad nicht lesbar — bei einem Prozess aus der geplanten Aufgabe
  verweigert Windows die Auskunft, am 01.08. genau so gemessen — muss er stattdessen auf der
  **Loopback-Adresse** des Stationsports horchen. Ein fremdes Programm wird nie beendet.

### 3.3 Der Watchdog kann nicht mehr sterben

Jeder Schleifendurchlauf liegt in `try/catch`, ebenso jeder Aufruf von `launch-kiosk.ps1`
(dort steht der `throw`, der ihn damals beendet hat).

### 3.4 Es gibt jetzt eine Spur

`data/watchdog.log` hält jeden Eingriff mit Zeitstempel und Begründung fest, gedeckelt auf 512 KB.
Ohne diese Datei war der Vorfall vom 01.08. von außen unsichtbar.

### 3.5 Absichtlich **nicht** eingebaut

Eine Sperre „nicht während einer Narkose neu starten“. Solange die Bridge steht, wird ohnehin
nichts aufgezeichnet und nichts angezeigt — die Daten sind in diesem Moment bereits verloren.
Gerade während einer Narkose ist der schnelle Neustart die richtige Antwort, nicht das Abwarten.

---

## 4. Absicherung

`tools/watchdog-test.js`, eingehängt in `tools/alle-tests.js`. Es wird dabei kein Prozess
angefasst und kein Port geöffnet: die Entscheidungsfunktion wird mit erfundenen Lagen aufgerufen.

Festgenagelt wird unter anderem:

- Eine eingefrorene Bridge ergibt `beenden-und-starten` — **nie** `starten`. Das war der Fehler.
- Ein fremdes Programm ergibt `fremd` — es wird nirgends beendet.
- Unterhalb der Schwelle kommt ausschließlich `warten` heraus.
- `Stop-Process` steht im Code genau **einmal**, und nur hinter der Herkunftsprüfung.
- Beide `.ps1`-Dateien sind für Windows PowerShell 5.1 syntaktisch gültig (echter Parser-Lauf) und
  enthalten kein `&&`/`||` — das wäre dort ein Parserfehler, und im versteckten Fenster sähe ihn
  niemand.

---

## 5. Die Gegenprüfung — was sie an der Behebung selbst fand (1.2.2)

Der Fix aus §3 wurde nach der Veröffentlichung von 1.2.1 adversarisch gegengeprüft: 46 unabhängige
Prüfer, vier Blickwinkel (Watchdog-Semantik, Abschuss-Sicherheit, Release-Stimmigkeit,
Test-Ehrlichkeit), jeder Befund anschließend von einem Skeptiker zu widerlegen versucht.
**42 Befunde, 23 bestätigt, 19 widerlegt.** Die wichtigsten:

### 5.1 Die Selbstheilung fiel bei System-Node komplett aus (schwer)

`Test-IstUnsereBridge` lautete sinngemäß:

```powershell
if ($pfad) { return ($pfad -like "$Root\*") }      # <- und sonst nichts mehr
... Loopback-Prüfung nur bei LEEREM Pfad ...
```

Damit galt: Pfad lesbar, liegt aber außerhalb des Stationsordners → „nicht unsere" → `fremd` → nie
beenden → **Station bleibt dauerhaft unten**. Und genau dieser Fall ist ausdrücklich vorgesehen:
`Find-Node` in `launch-kiosk.ps1` nimmt ein **System-Node** (`C:\Program Files\nodejs\node.exe`),
wenn kein `node\node.exe` mitgeliefert wurde; `Install-VetStation.ps1` führt das als gleichwertige
Wahl. Die Heilung wäre dort still ausgefallen — mit einer beruhigend klingenden Zeile im Protokoll:
„gehoert nicht zu VetStation. Er wird NICHT angefasst."

Der Prüfer hat außerdem **meine Begründung am laufenden System widerlegt**: ich hatte notiert, der
Programmpfad sei bei der geplanten Aufgabe grundsätzlich unlesbar. Für die von der erhöhten
Autostart-Aufgabe gestartete Station war er aus einer *nicht* erhöhten Abfrage lesbar. Beide Fälle
kommen vor. Behoben: zwei **unabhängige** Kennzeichen, von denen eines genügt — Pfad im
Stationsordner **oder** Horchen auf der Loopback-Adresse des Stationsports. Der Pfad ist damit ein
hinreichender, aber kein notwendiger Beleg.

### 5.2 Das Ergebnis des Beendens wurde weggeworfen (schwer)

An der Aufrufstelle stand `[void](Stop-EingefroreneBridge $inhaber)`. Schlug das Beenden fehl
(Zugriff verweigert, weil der Watchdog unerhöht läuft) oder blieb der Port belegt, wurde **trotzdem
gestartet** — der neue Prozess lief in `EADDRINUSE`. Die Selbstheilung erzeugte damit bei jedem Takt
eine weitere nutzlose Instanz. Der Kommentar „wartet, bis der Port wirklich frei ist" beschrieb eine
Absicherung, die durch das `[void]` keinerlei Wirkung hatte. Jetzt entscheidet der Rückgabewert, und
bei Fehlschlag wird bewusst **nicht** gestartet.

### 5.3 `stop-kiosk.ps1` beendete erhöht jeden Port-Inhaber (schwer)

Dort wurde jeder Prozess beendet, der auf 8770 horcht — ohne einen Blick darauf, *was* das ist. Und
das Skript besorgt sich selbst Adminrechte. Hält den Port ein fremdes Programm (Entwicklungsserver,
Hersteller-Werkzeug, VPN-Proxy), beendete ein Doppelklick auf `NEUSTART.bat` dieses fremde Programm.
Jetzt gilt dieselbe Herkunftsprüfung wie im Watchdog: erhöhte Rechte sind ein Grund für mehr
Sorgfalt, nicht für weniger.

### 5.4 `neustart-schnell.ps1` lief noch nie (schwer)

Zeile 27 enthielt den Ternäroperator `$p.ProcessId ? $p.ProcessId : $p.Id` — den gibt es erst ab
PowerShell 7. Auf der Station läuft Windows PowerShell 5.1, und dort ist das ein **Parserfehler für
die ganze Datei**. Nachgemessen: „Unerwartetes Token `?` in Ausdruck oder Anweisung."

Ausgerechnet diese Datei ist der Weg, der einen Neustart **ohne UAC-Abfrage** ermöglichen soll —
gebaut, weil die Abfrage in der Praxis oft nicht bestätigt wurde und Updates deshalb liegenblieben.
Zusätzlich entfernt: ein Rückfall, der andernfalls **jeden** node-Prozess auf dem Rechner beendet
hätte, auch fremde.

### 5.5 Ein halb angewendetes Update galt als erledigt (schwer)

`Apply-StagedUpdate` prüfte das Ergebnis von `robocopy` nicht und löschte den Marker bedingungslos.
Konnte eine Datei nicht ersetzt werden — Virenscanner, offener Editor, eine noch laufende zweite
node-Instanz (**am 01.08.2026 lagen genau solche herum**) —, blieb eine **halb aktualisierte
Station** zurück, die sich für fertig hielt. Jetzt: ab Rückgabewert 8 bleiben Marker und Zip liegen,
der nächste Start versucht es erneut, und es wird im Klartext gemeldet.

### 5.6 Der Test maß teilweise sich selbst (vier Befunde, schwer)

- **`Test-IstUnsereBridge` wurde nie ausgeführt.** Sie stand in `watchdog.ps1`, und weil dort am
  Dateiende eine Endlosschleife läuft, konnte kein Test sie aufrufen — geprüft wurde nur, ob ihr
  *Name* vorkommt. Ein Umbau auf `return $true` wäre grün durchgegangen und hätte den Watchdog zum
  Schädling gemacht. Sie steht jetzt in `kiosk/watchdog-erkennung.ps1` und wird mit erfundenen Lagen
  **aufgerufen**; `Get-Process`/`Get-CimInstance`/`Get-NetTCPConnection` werden dabei durch eigene
  Funktionen ersetzt (in PowerShell haben Funktionen Vorrang vor Cmdlets). Dazu eine Mutationsprobe,
  die belegt, dass ein pauschales `$true` auffallen *würde*.
- **Zehn von dreizehn Quelltext-Prüfungen maßen den Text mit Kommentaren.** Wer die Heilungszeile
  zum Debuggen auskommentiert und das Zurücknehmen vergisst, hätte einen grünen Test und eine
  Station, die sich nie mehr heilt. Jetzt misst alles den Text **ohne** Kommentare.
- **`Stop-Process` wurde nur gezählt, nicht an das geprüfte Ziel gebunden.** Ein Umbau auf
  `Stop-Process -Name node` wäre unbemerkt geblieben. Jetzt wird `-Id $Kennung` verlangt und
  `-Name` ausgeschlossen.
- **Der Vertrag zur Bridge war ungeprüft.** Wird `/healthz` umbenannt, ohne den Watchdog
  mitzuziehen, antwortet eine **gesunde** Station nie wieder — und die neue Selbstheilung beendet
  sie alle 30 Sekunden. Aus der Verbesserung würde eine Dauer-Abschussschleife. Jetzt wird gegen
  `bridge/src/server.js` geprüft, nicht gegen eine Zeichenkette in derselben Datei.

### 5.7 Weitere behobene Punkte

| Befund | Wirkung |
|---|---|
| `Get-PortInhaber` verschluckte jeden Fehler | Eine einmal gescheiterte Abfrage galt als „Port frei" → Neustart auf belegte Ports → zweite Leiche, diesmal von der Heilung erzeugt. Jetzt eigene Antwort `lage-unklar`: Nichtwissen ist kein Grund zu handeln. |
| `-like` mit unmaskiertem Pfad | Eckige Klammern sind in `-like` **Platzhalter**. In `C:\Praxis [alt]\VetStation` hätte der Watchdog die eigene Station für fremd gehalten. Jetzt `StartsWith`. |
| PID-Wiederverwendung | Zwischen Prüfung und `Stop-Process` lagen Sekunden. Endet der Prozess dazwischen, kann Windows die Kennung neu vergeben — der Abschuss träfe einen Unbeteiligten. Jetzt wird unmittelbar davor nochmals geprüft. |
| `Test-EdgeUp` traf jeden Edge | Hintergrundprozesse und ein vergessenes Edge-Fenster galten als „Kiosk läuft". Stürzt der Kiosk ab, kommt er nie zurück — der Bildschirm im OP bleibt leer. Jetzt am eigenen Profilordner erkannt. |

### 5.8 Und noch einer, den erst der Test fand

Die Sicherung gegen `lage-unklar` lautete zuerst `$PortInhaber -is [int] -and $PortInhaber -eq -1`.
Sie griff nicht: PowerShell bindet einen bar geschriebenen Wert in Befehlsschreibweise
(`-PortInhaber -1`) als **String**, nicht als Zahl (nachgemessen: `System.String`, `-is [int]` =
`False`). Der Aufrufer übergibt zwar eine echte Zahl — aber eine Sicherung, die je nach
Aufrufschreibweise still ausfällt, ist keine. Jetzt über die Zeichenkette verglichen, und **beide**
Schreibweisen sind als Testfall festgenagelt.
