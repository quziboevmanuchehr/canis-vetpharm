'use strict';
/*
 * lastbremse.js — die REINE Entscheidung "duerfen die Nachbarsaele gerade mitlaufen?".
 *
 * ------------------------------------------------------------------------------------------
 * WOZU DIESE DATEI DA IST
 * ------------------------------------------------------------------------------------------
 * Der eigene Saal hat Vorrang. Haengt die Ereignisschleife des Praxis-PCs, muessen die
 * Nachbarsaele weichen — sie sind Ansicht, der eigene Saal ist Betrieb. Die Frage ist nur: woran
 * erkennt man "haengt"?
 *
 * Bis 02.08.2026 lautete die Antwort in server.js: EIN Taktabstand ueber 700 ms genuegt, und
 * zurueck kommen die Nachbarn fruehestens nach zehn Sekunden. Am echten Praxis-PC gemessen
 * (data\diag.log, 02.08.2026, ohne angeschlossenes Geraet und ohne Patient):
 *     16:14:19  875 ms   16:15:47 2573 ms   16:16:20  868 ms   16:18:17  712 ms
 *     16:22:23 4314 ms   16:25:48  843 ms   16:25:59  958 ms
 * Alle ein bis drei Minuten ein Ausrutscher, und jeder nahm die Nachbarsaele fuer mindestens zehn
 * Sekunden vom Schirm. In einer Praxis mit zwei OP-Saelen ist das GENAU die Unstetigkeit, die
 * jemand als "die Verbindung zwischen den Saelen ist nicht stabil" erlebt: kein Fehler, keine
 * Meldung auf dem Bildschirm, der Nachbarsaal ist einfach mehrmals pro Stunde leer.
 *
 * Ein einzelner langer Abstand ist auf Windows KEIN Beleg fuer eine ueberlastete Station. Er
 * entsteht durch die Muellabfuhr der Laufzeitumgebung, einen Virenscanner, das Aufwachen aus
 * einem Energiesparzustand oder schlicht durch die Ungenauigkeit von setInterval. Ein Beleg ist
 * erst, dass es ANHAELT.
 *
 * ------------------------------------------------------------------------------------------
 * ZWEI WEGE IN DIE BREMSE — UND NUR ZWEI
 * ------------------------------------------------------------------------------------------
 *   1. ANHALTEND: mindestens 'spaetVonFenster' der letzten 'fenster' Takte waren zu spaet.
 *      Ein Ausrutscher unter lauter guten Takten reicht nie.
 *   2. BLOCKADE: ein einzelner Takt war laenger als 'blockadeMs'. Bei 2,8 s ist das keine
 *      Ungenauigkeit mehr, sondern eine echte Blockade — da soll die Bremse sofort greifen und
 *      nicht erst eine Mehrheit abwarten.
 *
 * ------------------------------------------------------------------------------------------
 * KEINE EIGENE UHR, KEIN require — WIE IN tafel.js
 * ------------------------------------------------------------------------------------------
 * 'jetzt' ist immer ein Argument. Nur so laesst sich die Hysterese pruefen, ohne eine Station
 * kuenstlich zu ueberlasten und Minuten zu warten. Und weil die Datei nichts laedt, kann sie
 * auch nichts kaputtmachen, was am Messweg haengt.
 *
 * Der Zustand wird vom Aufrufer gehalten und hier NICHT veraendert: die Funktion liefert einen
 * neuen Zustand zurueck. Das ist der Grund, warum tools/bremse-test.js die echten Messwerte von
 * oben einfach einspielen kann.
 */

/* Die Schwellen. Sie beziehen sich auf den Solltakt des Rundrufs (BROADCAST_MS = 350 ms). */
const VORGABE = {
  /* Ab wann ein einzelner Takt "zu spaet" heisst: doppelter Solltakt. */
  spaetMs: 700,
  /* So lang darf KEIN einzelner Takt sein: dann stand die Ereignisschleife wirklich. */
  blockadeMs: 2800,
  /* Beobachtungsfenster und noetige Mehrheit darin. 3 von 6 heisst: die Haelfte der letzten rund
   * zwei Sekunden war zu spaet — das ist kein Zucken mehr. */
  fenster: 6,
  spaetVonFenster: 3,
  /* Unter so vielen Proben wird gar nicht geurteilt (direkt nach dem Start ist das Fenster leer).
   * Ohne diese Sperre haette ein einziger langsamer Takt kurz nach dem Start sofort gebremst —
   * und ausgerechnet der erste Takt nach dem Start ist regelmaessig langsam. */
  mindestProben: 4,
  /* Als "ruhig" gilt ein Takt bis zum 1,5-fachen Solltakt. */
  ruhigMs: 525,
  /*
   * So lange muss es DURCHGEHEND ruhig gewesen sein, bevor die Nachbarsaele zurueckkommen —
   * gerechnet ab dem letzten zu spaeten Takt, NICHT ab dem Einschalten der Bremse.
   *
   * Der Unterschied ist nicht akademisch; der Test hat ihn gefunden. Zuerst stand hier "mindestens
   * 5 s seit dem Bremsen". Dabei zaehlen die langsamen Takte MIT: eine Station, die 6 s lang
   * haengt und dann 1,4 s ruhig ist, haette die Nachbarn sofort zurueckgeholt — und beim naechsten
   * Haenger wieder weggenommen. Also genau das Flattern, das diese Schwelle verhindern soll.
   * Gemessen wird deshalb die RUHE, nicht das Alter der Bremse.
   */
  ruheMs: 5000,
};

function neuerZustand() {
  return {
    bremse: false,
    bremseSeit: 0,
    letzterTakt: 0,
    /* Wann kam zuletzt ein zu spaeter Takt? Daran haengt die Rueckkehr — siehe ruheMs. */
    letzterSpaeter: 0,
    abstaende: [],
    bremseZaehler: 0,
    spaeteTakte: 0,
    /* Nur fuer die Anzeige: warum wurde zuletzt gebremst? */
    grund: null,
  };
}

/*
 * Ein Takt ist vergangen. Liefert den neuen Zustand plus ein Feld 'meldung' — gesetzt genau dann,
 * wenn sich die Bremse GEAENDERT hat. Der Aufrufer schreibt nur dann ins Protokoll; sonst stuende
 * bei einer knappen Maschine jede Sekunde dieselbe Zeile im Log.
 */
function takt(zustand, jetzt, schwellen) {
  const s = Object.assign({}, VORGABE, schwellen || {});
  const z = Object.assign(neuerZustand(), zustand);
  z.abstaende = (zustand && zustand.abstaende ? zustand.abstaende : []).slice();

  if (!z.letzterTakt) { z.letzterTakt = jetzt; return Object.assign(z, { meldung: null }); }

  const abstand = jetzt - z.letzterTakt;
  z.letzterTakt = jetzt;

  /* Ein negativer Abstand heisst: die Uhr des PCs ist zurueckgestellt worden (Zeitumstellung,
   * NTP-Sprung, leere CMOS-Batterie). Das ist KEIN Hinweis auf Last, und er darf die Bremse
   * weder ausloesen noch loesen — sonst haengt der Blick in den Nachbarsaal an der Uhrzeit.
   *
   * ABER: die gemerkten Zeitpunkte liegen nach einem Ruecksprung in der ZUKUNFT, und dann wird
   * (jetzt - letzterSpaeter) nie wieder gross genug fuer ruheMs. Eine eingeschaltete Bremse
   * bliebe fuer immer eingeschaltet — die Nachbarsaele waeren bis zum naechsten Neustart weg,
   * lautlos. Genau dieser Fehler steckte in der ersten Fassung von heute; gefunden hat ihn die
   * Gegenpruefung, nicht der Test. Deshalb werden beide Zeitpunkte auf die neue Uhr
   * zurueckgeholt: die Ruhefrist beginnt dann von vorn, was hoechstens ein paar Sekunden kostet.
   */
  if (abstand < 0) {
    if (z.letzterSpaeter > jetzt) z.letzterSpaeter = jetzt;
    if (z.bremseSeit > jetzt) z.bremseSeit = jetzt;
    return Object.assign(z, { meldung: null });
  }

  z.abstaende.push(abstand);
  while (z.abstaende.length > s.fenster) z.abstaende.shift();
  if (abstand > s.spaetMs) { z.spaeteTakte++; z.letzterSpaeter = jetzt; }

  const spaet = z.abstaende.filter((a) => a > s.spaetMs).length;
  const genugProben = z.abstaende.length >= s.mindestProben;
  const anhaltend = genugProben && spaet >= s.spaetVonFenster;
  const blockade = abstand > s.blockadeMs;

  if (!z.bremse && (anhaltend || blockade)) {
    z.bremse = true;
    z.bremseSeit = jetzt;
    z.bremseZaehler++;
    z.grund = blockade ? 'blockade' : 'anhaltend';
    return Object.assign(z, {
      meldung: 'Der eigene Rundruf haengt' + (blockade
        ? ' (ein Takt dauerte ' + abstand + ' ms — die Ereignisschleife stand)'
        : ' (' + spaet + ' der letzten ' + z.abstaende.length + ' Takte ueber ' + s.spaetMs
          + ' ms, zuletzt ' + abstand + ' ms)')
        + '. Die Nachbarsaele werden abgeschaltet, damit der EIGENE Saal fluessig bleibt. '
        + 'Sie kommen von selbst zurueck, sobald der Takt wieder steht.',
      art: 'warn',
    });
  }

  if (z.bremse
      && genugProben
      && z.abstaende.slice(-s.mindestProben).every((a) => a <= s.ruhigMs)
      && jetzt - z.letzterSpaeter >= s.ruheMs) {
    z.bremse = false;
    z.grund = null;
    return Object.assign(z, {
      meldung: 'Der eigene Rundruf laeuft wieder rund — die Nachbarsaele sind zurueck.',
      art: 'info',
    });
  }

  return Object.assign(z, { meldung: null });
}

module.exports = { VORGABE, neuerZustand, takt };
