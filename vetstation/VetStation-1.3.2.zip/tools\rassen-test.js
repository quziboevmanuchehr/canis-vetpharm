'use strict';
/*
 * rassen-test.js — sichert den Rassekatalog samt Erstwahl-Narkose und Rettungswegen.
 *
 * Wunsch des Nutzers (03.08.2026): das Modul soll ALLE Rassen aller gefuehrten Tierarten kennen,
 * beim Tippen im Rassefeld sofort die passenden Treffer der GEWAEHLTEN Tierart zeigen, und beim
 * Bestaetigen einer Gabe die rassespezifischen Erbkrankheiten und Risiken erkennen, davor warnen,
 * die Narkose erster Wahl vorschlagen und sagen, wie der Patient wieder stabil wird.
 *
 * Was dieser Test absichert — und warum genau das:
 *  - Ein Verweis auf eine Erkrankung/ein Protokoll, das es nicht gibt, faellt im Browser NICHT
 *    auf: die Karte bleibt einfach leer. Deshalb werden alle Schluessel gegengeprueft.
 *  - Eine Rasse, die zweimal im Katalog steht, ist gefaehrlicher als eine fehlende: der Tierarzt
 *    waehlt die eine Fassung, und die Warnung haengt an der anderen.
 *  - Die Warnung muss den Weg bis ins Protokoll gehen (App -> Shell -> Bridge). Faellt ein Glied
 *    aus, sieht der Bildschirm richtig aus und im Protokoll fehlt sie.
 *
 * Start: node tools/rassen-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const VB = require(path.join(WURZEL, 'ui/shared/breed-genetics.js'));
require(path.join(WURZEL, 'ui/shared/narkose-risiko.js'));
require(path.join(WURZEL, 'ui/shared/breed-katalog.js'));

const app = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
const shell = fs.readFileSync(path.join(WURZEL, 'ui/vetstation-live.js'), 'utf8');
const registry = fs.readFileSync(path.join(WURZEL, 'bridge/src/registry.js'), 'utf8');
const A = require(path.join(WURZEL, 'bridge/src/anaes')).loadAnaes();

let pass = 0, fail = 0, warn = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function note(n) { warn++; console.log('  ⚠ ' + n); }

console.log('Rassekatalog, Erstwahl-Narkose und Rettungswege — Selbsttest\n');

/* ------------------------------------------------------------------ 1) Umfang */
console.log('1) Umfang und Abdeckung der Tierarten:');
const proArt = VB.speciesWithBreeds();
ok('Rassekatalog geladen (' + VB.BREEDS.length + ' Rassen)', VB.BREEDS.length >= 400, String(VB.BREEDS.length));
A.species.forEach(function (s) {
  ok(s.name + ' hat Rassen im Katalog (' + (proArt[s.id] || 0) + ')', (proArt[s.id] || 0) > 0);
});
ok('Hund: mindestens 250 Rassen', (proArt.hund || 0) >= 250, String(proArt.hund));
ok('Katze: mindestens 40 Rassen', (proArt.katze || 0) >= 40, String(proArt.katze));
ok('Kaninchen: mindestens 40 Rassen', (proArt.kaninchen || 0) >= 40, String(proArt.kaninchen));

/* --------------------------------------------------------- 2) Innere Stimmigkeit */
console.log('\n2) Innere Stimmigkeit (kein toter Verweis, keine Doppelrasse):');
const ids = {}, doppelIds = [];
VB.BREEDS.forEach(function (b) { if (ids[b.id]) doppelIds.push(b.id); ids[b.id] = 1; });
ok('jede Rasse-Kennung kommt genau einmal vor', doppelIds.length === 0, doppelIds.slice(0, 5).join(', '));

const namen = {}, doppelNamen = [];
VB.BREEDS.forEach(function (b) {
  const k = b.sp + '|' + VB.norm(b.name);
  if (namen[k]) doppelNamen.push(b.sp + ' ' + b.name);
  namen[k] = 1;
});
ok('kein Rassename doppelt innerhalb einer Tierart', doppelNamen.length === 0, doppelNamen.slice(0, 5).join(', '));

/* Beinahe-Doppelte: „Collie Kurzhaar" und „Kurzhaarcollie" sind dasselbe Tier. Solche Paare
 * ganz zu verhindern ist nicht moeglich (Miniature Australian / American Shepherd sind
 * derselbe Hund unter zwei Verbandsnamen). Gefaehrlich ist nur der Fall, dass die eine Fassung
 * eine Warnung traegt und die andere nicht — der Tierarzt waehlt eine und sieht die halbe
 * Wahrheit. Genau das wird hier geprueft. */
const aliasIx = {};
VB.BREEDS.forEach(function (b) {
  (b.aliases || []).forEach(function (a) { const k = b.sp + '|' + VB.norm(a); (aliasIx[k] = aliasIx[k] || []).push(b.id); });
});
const ungleich = [];
VB.BREEDS.forEach(function (b) {
  const k = b.sp + '|' + VB.norm(b.name);
  (aliasIx[k] || []).forEach(function (id) {
    if (id === b.id) return;
    const z = VB.byId(id); if (!z) return;
    const a = (b.conditions || []).slice().sort().join(','), c = (z.conditions || []).slice().sort().join(',');
    if (a !== c) ungleich.push(b.name + ' vs ' + z.name);
  });
});
ok('Rassen, die dasselbe Tier meinen, tragen dieselben Erkrankungen', ungleich.length === 0, ungleich.slice(0, 4).join(' | '));

const ohneFeld = VB.BREEDS.filter(function (b) { return !b.name || !b.sp || !b.id; });
ok('jede Rasse hat Kennung, Name und Tierart', ohneFeld.length === 0, ohneFeld.length + ' ohne');

const bekannteArten = {}; A.species.forEach(function (s) { bekannteArten[s.id] = 1; });
const fremdeArt = VB.BREEDS.filter(function (b) { return !bekannteArten[b.sp]; });
ok('keine Rasse zeigt auf eine Tierart, die das Modul nicht kennt', fremdeArt.length === 0,
  fremdeArt.slice(0, 5).map(function (b) { return b.sp + '/' + b.name; }).join(', '));

const toteCond = [];
VB.BREEDS.forEach(function (b) {
  (b.conditions || []).forEach(function (k) { if (!VB.CONDITIONS[k]) toteCond.push(b.name + ' -> ' + k); });
  (b.groups || []).forEach(function (k) { if (!VB.GROUPS[k]) toteCond.push(b.name + ' -> Gruppe ' + k); });
});
ok('jede Rasse zeigt nur auf vorhandene Erkrankungen/Gruppen', toteCond.length === 0, toteCond.slice(0, 5).join(' | '));

const toteProt = [];
Object.keys(VB.CONDITIONS).forEach(function (k) {
  const c = VB.CONDITIONS[k];
  [].concat(c.protocol || []).forEach(function (p) { if (!VB.PROTOCOLS[p]) toteProt.push(k + ' -> Protokoll ' + p); });
  [].concat(c.rescue || []).forEach(function (r) { if (!VB.RESCUE[r]) toteProt.push(k + ' -> Rettung ' + r); });
});
Object.keys(VB.GROUPS).forEach(function (k) {
  const g = VB.GROUPS[k];
  [].concat(g.protocol || []).forEach(function (p) { if (!VB.PROTOCOLS[p]) toteProt.push('Gruppe ' + k + ' -> Protokoll ' + p); });
  [].concat(g.rescue || []).forEach(function (r) { if (!VB.RESCUE[r]) toteProt.push('Gruppe ' + k + ' -> Rettung ' + r); });
});
ok('jede Erkrankung/Gruppe zeigt nur auf vorhandene Protokolle und Rettungswege',
  toteProt.length === 0, toteProt.slice(0, 6).join(' | '));

const leereRettung = Object.keys(VB.RESCUE).filter(function (k) { return !(VB.RESCUE[k].schritte || []).length; });
ok('jeder Rettungsweg hat mindestens einen Schritt', leereRettung.length === 0, leereRettung.slice(0, 5).join(', '));

const leereProt = Object.keys(VB.PROTOCOLS).filter(function (k) {
  const p = VB.PROTOCOLS[k];
  return !(p.praemed || p.einleitung || p.erhalt || p.ziele);
});
ok('jedes Protokoll sagt wenigstens etwas zu Prämedikation/Einleitung/Erhalt/Zielen',
  leereProt.length === 0, leereProt.slice(0, 5).join(', '));

const ohneText = Object.keys(VB.CONDITIONS).filter(function (k) { return !VB.CONDITIONS[k].short; });
ok('jede Erkrankung hat eine Kurzbeschreibung', ohneText.length === 0, ohneText.slice(0, 5).join(', '));

/* Der gefaehrlichste stille Fehler: ein Meerschweinchen bekommt den Kaninchenplan, ein Perser den
 * Hunde-BOAS-Plan, ein Frettchen das Hunde-DCM-Protokoll. Auf dem Bildschirm sieht das voellig
 * normal aus — es steht ja ein vollstaendiger Narkoseplan da, nur eben der einer anderen Tierart.
 * Genau das ist beim Bauen dreimal passiert, deshalb wird es hier hart geprueft. */
const artfremd = [];
VB.BREEDS.forEach(function (b) {
  VB.plan(b).erstwahl.forEach(function (e) {
    const p = VB.PROTOCOLS[e.key];
    if (p && p.sp && p.sp !== b.sp) artfremd.push(b.sp + '/' + b.name + ' bekommt ' + e.key + ' (' + p.sp + ')');
  });
});
ok('keine Rasse bekommt den Narkoseplan einer ANDEREN Tierart', artfremd.length === 0, artfremd.slice(0, 5).join(' | '));

/* ------------------------------------------------------------------ 3) Suche */
console.log('\n3) Sofortsuche im Rassefeld (Tierart filtert, Treffer stehen oben):');
function ersteTreffer(text, sp, n) { return VB.search(text, sp, n || 3).map(function (t) { return t.breed.name; }); }
function findetOben(text, sp, erwartetTeil) {
  const t = VB.search(text, sp, 5);
  return t.length && VB.norm(t[0].breed.name).indexOf(VB.norm(erwartetTeil)) >= 0;
}
ok('„coll" (Hund) findet zuerst einen Collie', findetOben('coll', 'hund', 'collie'), ersteTreffer('coll', 'hund').join(' | '));
ok('„bkh" (Katze) findet Britisch Kurzhaar', findetOben('bkh', 'katze', 'britisch'), ersteTreffer('bkh', 'katze').join(' | '));
ok('„mops" (Hund) findet den Mops', findetOben('mops', 'hund', 'mops'), ersteTreffer('mops', 'hund').join(' | '));
ok('ein Buchstabe liefert schon Treffer', VB.search('m', 'hund', 10).length > 0);
ok('leere Eingabe liefert die Artenliste', VB.search('', 'katze', 10).length > 0);
const katzeTreffer = VB.search('a', 'katze', 40);
ok('die Suche mischt keine fremde Tierart hinein',
  katzeTreffer.every(function (t) { return t.breed.sp === 'katze'; }));
ok('eine Hunderasse ist unter Katze nicht zu finden', VB.search('mops', 'katze', 5).length === 0);
A.species.forEach(function (s) {
  if (!(proArt[s.id] || 0)) return;
  const bsp = VB.BREEDS.find(function (b) { return b.sp === s.id; });
  ok(s.name + ': voller Name findet genau diese Rasse',
    findetOben(bsp.name, s.id, bsp.name.split(' ')[0]), bsp.name);
});

/* --------------------------------------------------- 4) Narkoseplan und Warnung */
console.log('\n4) Narkoseplan der Rasse (erste Wahl · meiden · stabilisieren):');
const mitPlan = VB.BREEDS.filter(function (b) { const p = VB.plan(b); return p && p.erstwahl.length; });
ok('mindestens 90 % der Rassen haben eine Erstwahl-Empfehlung',
  mitPlan.length >= VB.BREEDS.length * 0.9, mitPlan.length + '/' + VB.BREEDS.length);
A.species.forEach(function (s) {
  if (!(proArt[s.id] || 0)) return;
  const einer = VB.BREEDS.find(function (b) { return b.sp === s.id && VB.plan(b).erstwahl.length; });
  ok(s.name + ': mindestens eine Rasse mit Narkoseplan', !!einer, einer ? einer.name : 'keine');
});

/* Der vom Nutzer genannte Beispielfall: BKH-Katze mit HCM und PKD. */
const bkh = VB.resolve('Britisch Kurzhaar', 'katze');
ok('Britisch Kurzhaar ist im Katalog', !!bkh);
if (bkh) {
  const p = VB.plan(bkh);
  ok('BKH: Risikostufe hoch', p.risk === 'hoch', String(p.risk));
  ok('BKH kennt HCM UND PKD', (bkh.conditions || []).indexOf('hcm-cat') >= 0 && (bkh.conditions || []).indexOf('pkd-cat') >= 0,
    (bkh.conditions || []).join(', '));
  ok('BKH: Herzempfehlung steht VOR der Nierenempfehlung',
    /HCM/i.test(p.erstwahl[0] && p.erstwahl[0].name || ''), (p.erstwahl[0] || {}).name);
  ok('BKH: es gibt einen Rettungsweg', p.rettung.length > 0);
  const k = VB.checkGabe(bkh, 'Ketamin');
  ok('Ketamin bei der BKH loest eine Warnung aus', !!k);
  ok('… und zwar die schaerfste Stufe (meiden)', k && k.level === 'avoid', k && k.level);
  ok('… und nennt gleich den Weg zurueck zur Stabilitaet', !!(k && k.rettung.length),
    k ? k.rettung.map(function (r) { return r.key; }).join(', ') : '');
  ok('… und der Rettungsweg hat konkrete Schritte', !!(k && k.rettung[0] && k.rettung[0].schritte.length >= 3));
  ok('Alfaxalon bei der BKH loest KEINE Meidewarnung aus',
    !(VB.checkGabe(bkh, 'Alfaxalon') || {}).level || VB.checkGabe(bkh, 'Alfaxalon').level !== 'avoid');
}
/* MDR1 */
const collie = VB.resolve('Collie', 'hund');
ok('Collie ist im Katalog', !!collie);
if (collie) {
  ok('Collie traegt MDR1', (collie.conditions || []).indexOf('mdr1') >= 0);
  const ace = VB.checkGabe(collie, 'Acepromazin');
  ok('Acepromazin beim Collie warnt (Dosis reduzieren)', !!ace && (ace.level === 'reduce' || ace.level === 'avoid'), ace && ace.level);
  ok('Collie: MDR1-Erstwahlprotokoll vorhanden',
    VB.plan(collie).erstwahl.some(function (e) { return /MDR1/i.test(e.name); }));
}
/* Brachyzephal */
const fb = VB.resolve('Französische Bulldogge', 'hund') || VB.resolve('Franzoesische Bulldogge', 'hund');
ok('Französische Bulldogge ist im Katalog', !!fb);
if (fb) {
  ok('… als brachyzephal erkannt', (fb.groups || []).indexOf('brachy') >= 0, (fb.groups || []).join(','));
  ok('… mit BOAS-Erstwahlprotokoll', VB.plan(fb).erstwahl.some(function (e) { return /BOAS|Brachyzephal/i.test(e.name); }));
}
/* Eine Rasse ohne eingetragene Erbkrankheit bekommt trotzdem einen Artplan. */
['kaninchen', 'meerschwein', 'chinchilla', 'degu', 'frettchen', 'reptil'].forEach(function (spId) {
  if (!(proArt[spId] || 0)) return;
  const alle = VB.BREEDS.filter(function (b) { return b.sp === spId; });
  const ohne = alle.filter(function (b) { return !VB.plan(b).erstwahl.length; });
  ok(spId + ': JEDE Rasse hat einen Narkoseplan (Artgrundlagen greifen)', ohne.length === 0,
    ohne.slice(0, 3).map(function (b) { return b.name; }).join(', '));
});

/* ------------------------------------------------------- 5) Verdrahtung in der App */
console.log('\n5) Verdrahtung in der Oberflaeche:');
ok('das Rassefeld ist nicht mehr auf Hund/Katze festgenagelt', /speciesWithBreeds/.test(app));
ok('die alte <datalist>-Loesung ist raus', !/id="breedList"/.test(app));
ok('es gibt eine eigene Sofort-Trefferliste', /breedPopAuf/.test(app) && /id="breedPop"/.test(app));
ok('Tastatur: Pfeiltasten und Enter bedienen die Liste', /ArrowDown/.test(app) && /breedPopMarkiere/.test(app));
ok('die Trefferliste zeigt eine Risikofarbe', /breedRiskKlasse/.test(app));
ok('das Rasseprofil zeigt den Narkoseplan', /function planHtml/.test(app) && /VB\.plan/.test(app));
ok('Erstwahl, Meiden, Ziele und Rettung sind eigene Bloecke',
  /Narkose – erste Wahl/.test(app) && /Bei dieser Rasse meiden/.test(app) && /stabilisieren/.test(app));
ok('die Skripte sind eingebunden', /narkose-risiko\.js/.test(app) && /breed-katalog\.js/.test(app));

console.log('\n6) Die Warnung im Augenblick der bestaetigten Gabe:');
ok('medBuchen prueft die Rasse', /function medBuchen\(rec\)\{[\s\S]{0,600}gabePruefen\(rec\)/.test(app));
ok('gabePruefen fragt VETBREED.checkGabe', /function gabePruefen[\s\S]{0,600}VB\.checkGabe/.test(app));
ok('eine zurueckgenommene Gabe wird NICHT geprueft', /rec\.storno\) return null/.test(app));
ok('die Injektionskombination gibt ihre Wirkstoffe mit', /wirkstoffe:\(\(c&&c\.comp\)\|\|\[\]\)/.test(app));
ok('die Warnung erscheint als eigener Kasten', /function gabeWarnZeigen/.test(app) && /gabe-warn/.test(app));
ok('der Kasten zeigt auch den Rettungsweg', /Jetzt stabilisieren/.test(app));
ok('die Warnung haengt sich an die Protokollzeile', /rec\.warnLevel\s*=/.test(app) && /rec\.warnText\s*=/.test(app));
ok('die Rasse selbst geht mit', /rec\.breed\s*=/.test(app) && /rec\.breedName\s*=/.test(app));

console.log('\n7) Der Weg der Warnung bis ins Narkoseprotokoll:');
ok('die Shell reicht warnText/breed weiter', /warnText: gabe\.warnText/.test(shell) && /breed: gabe\.breedName/.test(shell));
ok('die Shell schreibt sie auch in den Klartext-Befund', /gabe\.warnLevel && gabe\.warnText/.test(shell));
ok('die Bridge legt sie in die Protokollzeile', /warnText: kurz\(gabe\.warnText/.test(registry));
ok('die Bridge schreibt sie in den Befundtext (damit jede vorhandene Ansicht sie zeigt)',
  /finding:[\s\S]{0,400}gabe\.warnLevel && gabe\.warnText/.test(registry));
ok('die Rasse steht mit in der Protokollzeile', /breed: kurz\(gabe\.breedName/.test(registry));

console.log('\n8) Groesse und Ladbarkeit:');
const katPfad = path.join(WURZEL, 'ui/shared/breed-katalog.js');
const kb = Math.round(fs.statSync(katPfad).size / 1024);
ok('breed-katalog.js bleibt unter der Paketgrenze von 2 MB (' + kb + ' KB)', kb < 2048, kb + ' KB');
ok('breed-katalog.js laedt ohne Grundmodul nicht durch (kein harter Absturz)',
  /if \(!VB \|\| !VB\.register\) return;/.test(fs.readFileSync(katPfad, 'utf8')));
ok('narkose-risiko.js ebenso',
  /if \(!VB \|\| !VB\.register\) return;/.test(fs.readFileSync(path.join(WURZEL, 'ui/shared/narkose-risiko.js'), 'utf8')));

console.log('\n---------------------------------------------');
console.log('  bestanden: ' + pass + '   fehlgeschlagen: ' + fail + (warn ? '   Hinweise: ' + warn : ''));
process.exit(fail ? 1 : 0);
