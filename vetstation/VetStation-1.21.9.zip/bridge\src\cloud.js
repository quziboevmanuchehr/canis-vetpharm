'use strict';
/*
 * cloud.js — FERN-LIVE Publisher (Schicht 1/3 -> Internet).
 *
 * Aufgabe: die bereits pro Patient zusammengefuehrten Live-Daten (registry.getPatients())
 * plus die "Brain"-Bewertung (brain.assess -> Prioritaet + Top-Befund) mehrmals pro Sekunde in
 * ein Cloud-Relay schreiben, damit die oeffentliche Web-App (GitHub Pages,
 * quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie) sie FERN anzeigen kann.
 *
 * Relay = Firebase Realtime Database (Projekt vet-station, europe-west1). Der Praxis-PC schreibt
 * per REST, die Zuschauer LESEN mit dem Zugangscode.
 *
 * ------------------------------------------------------------------------------------------
 * UMBAU 27.07.2026 — "alles, live, in Millisekunden" (Nutzerwunsch)
 * ------------------------------------------------------------------------------------------
 * Vorher: alle 500-1000 ms wurde der KOMPLETTE Datenstand als ein PUT geschrieben - auch die 95 %,
 * die sich nicht geaendert hatten. Das begrenzte den Takt (Bandbreite) und uebertrug ausserdem nur
 * einen Ausschnitt der Daten (kein EKG-Befund, keine echten Kurven, keine Rohwerte, keine Geraete-
 * adressen). Jetzt:
 *
 *  1) DELTA statt VOLLBILD. Nach dem ersten Vollbild (PUT) wird nur noch geschrieben, was sich
 *     tatsaechlich geaendert hat (PATCH mit tiefen Pfaden, z. B. "patients/<key>/vitals").
 *     Praktisch aendern sich pro Takt nur die Vitalwerte - wenige hundert Byte statt mehrerer KB.
 *     Erst dadurch ist ein Takt von 150-250 ms bezahlbar und im Spark-Tarif tragbar.
 *  2) ECHTE KURVEN. Das LifeVet liefert echte Abtastwerte (EKG 256 Hz, CO2 40 Hz). Die gingen bisher
 *     NICHT ins Internet - fern sah man eine nachgezeichnete Kurve. Jetzt werden die Streifen
 *     uebertragen, aber NUR wenn sich die Kurvensignatur aendert (also je Streifen genau EINMAL) und
 *     als Int16+Base64 statt als JSON-Zahlenliste (~3x kleiner). Genau dieselbe Sparlogik wie lokal
 *     (matching.fuerRundruf -> kurvenSig -> /api/kurven).
 *  3) VOLLSTAENDIGKEIT. Zusaetzlich uebertragen: alle Vitalfelder (statt Positivliste), EKG-Analyse
 *     (QRS/Rhythmus/ST), AF-Quelle (Kapnograf vs. Monitor), Beatmungsparameter, Geraeteliste mit
 *     Adresse/Status/Sendetakt/Meldungen, alle Rohwerte des Geraets, Alarme.
 *  4) FIRESTORE-ARCHIV. Der Live-Strom gehoert in die Realtime Database (dafuer ist sie gebaut).
 *     Firestore bekommt parallel im Ruhetakt (Standard 15 s) einen Verlaufsdatensatz je Station -
 *     dort ist Firestore stark: Historie, spaetere Auswertung, Fallakte.
 *
 * DATENSCHUTZ: Klarnamen (Tiername) und die Patientenakte des Geraets (Besitzer, Arzt, Telefon)
 * werden uebertragen, SOLANGE cloud.stammdaten nicht ausdruecklich auf false steht - der
 * Standard ist also AN. Vitalwerte/Tierart/Gewicht/Befund gehen immer.
 *
 * WARUM AN, obwohl es Klarnamen sind: seit den Praxis-Konten (27.07.2026) liegen die Daten
 * ausschliesslich unter der Anmelde-Kennung der eigenen Praxis, und nur diese Praxis kann sie
 * lesen. Es sind IHRE Daten in IHREM Konto - dann gehoert der Tiername auch aufs Protokoll,
 * sonst waere der Ausdruck als Dokument wertlos. Die ausfuehrliche Begruendung steht bei der
 * Zuweisung selbst (dieselbe Datei, Suchwort "STAMMDATEN JETZT STANDARDMAESSIG AN").
 *
 * DIESER ABSATZ HAT BIS ZUM 13.08.2026 DAS GEGENTEIL BEHAUPTET ("Standard ist AUS"). Er stammte
 * aus der Zeit vor den Praxis-Konten, als der Fern-Zugang noch an einem weiterleitbaren Link
 * hing; die Zuweisung wurde damals geaendert, der Dateikopf nicht. Wer hier nachlas - bei einer
 * Datenschutzauskunft, vor einer Auslieferung, beim naechsten Umbau -, bekam eine falsche
 * Auskunft ueber personenbezogene Daten. Genau dagegen steht die Projektregel, dass der
 * Dateikopf die verbindliche Stelle ist: dann muss er auch stimmen.
 *
 * WER STAMMDATEN NICHT SENDEN WILL, setzt cloud.stammdaten = false. Das ist zugleich die
 * wirksamste Massnahme gegen "heute mitschneiden, spaeter entschluesseln" - was nie uebertragen
 * wurde, kann niemand aufheben (siehe docs/SICHERHEIT-POSTQUANTEN.md, Abschnitt 3).
 *
 * STRIKT READ-ONLY gegenueber den Geraeten. NULL npm-Dependencies (nur Node-Bordmittel: https).
 *
 * ==========================================================================================
 * UMBAU 30.07.2026 — MEHRERE OP-SAELE IN EINEM PRAXIS-KONTO (docs/PLAN-MEHRERE-SAELE.md)
 * ==========================================================================================
 * Bis 1.0.3 schrieb JEDE Station in denselben Knoten /live/<Praxis>. Zwei Stationen haetten sich
 * dort Feld fuer Feld ueberschrieben und — schlimmer — sich EINEN Frische-Zeitstempel geteilt: der
 * laufende Saal haette den ausgefallenen frisch aussehen lassen. Ab jetzt hat jeder Saal einen
 * eigenen Zweig unter seiner Stationskennung (bridge/src/stationsid.js).
 *
 * ES GIBT AB JETZT FUENF SCHREIBZIELE MIT FUENF GETRENNTEN FEHLERKONTEN. Das ist die wichtigste
 * Aussage dieser Datei, und sie ist keine Ordnungsliebe:
 *
 *   Weg L  saele/<sid>/patients/<key>/<feld>       Takt 500 ms   DIE UEBERWACHUNG
 *          Nur DIESES Ziel zaehlt konfigFehler hoch und kann sich selbst abschalten.
 *   Weg T  tafel/<sid>/{meta,uebersicht,geraete}   Takt 2000 ms  HERZSCHLAG + kleine Kacheln
 *          Eigenes Konto, eigene Wartezeit, KEINE Selbstabschaltung: ein Fehler im Tafelzweig
 *          darf die Ueberwachung nicht abschalten. Kopf und Kacheln gehen im SELBEN Koerper —
 *          ein Herzschlag ohne die zugehoerigen Kacheln waere ein Saal, der frisch aussieht und
 *          alte Zahlen zeigt (Befund A2-2).
 *   Weg S  meta/* + patients/s<sid6>__<key>/<feld> Takt 2000 ms  KOMPATIBILITAETSSPIEGEL
 *          Fuer die ausgelieferte Web-App 1.0.3. Eigenes Konto. Dauerhaft an (Nutzerentscheidung).
 *   Weg P  saele/<sid>/protokoll/<pid>/<ts>        eigener Vorgang, eigenes Konto (Reparatur b)
 *   Archiv Firestore-Verlauf                       eigener Vorgang, eigenes Konto (Bestand)
 *
 * WARUM NICHT ALLES IN EINEN ATOMAREN KOERPER (so stand es im Plantext): weil ein Mehrpfad-PATCH
 * atomar ist. Ein einziges abgelehntes Tafelfeld haette dann die Vitalwerte mitgenommen und nach
 * drei Takten die Fern-Uebertragung dieser Praxis abgeschaltet — genau die Kette, die am
 * 29.07.2026 schon einmal zugeschlagen hat (siehe prozessStart weiter unten).
 *
 * DIE TRENNUNG GILT IN BEIDE RICHTUNGEN (Befund C1, nachgebessert 30.07.2026). Bis dahin trennte
 * sie nur eine: ein Fehler auf Weg T liess Weg L in Ruhe, ein Fehler auf Weg L nahm dagegen ALLES
 * mit. Nachgemessen war das so gebaut, und es war die schlechtere Richtung:
 *   • der Wert-Schreibvorgang wurde ABGEWARTET, seine Ablehnung fiel aus _publizieren heraus und
 *     Protokoll, Tafel, Spiegel und Archiv wurden im selben Takt nie erreicht;
 *   • die Wartezeit aus _fehler (2 s -> 60 s) und die Selbstabschaltung (started = false) standen
 *     ganz oben in publish() und sperrten damit auch den Herzschlag.
 * Gemessen: nur Weg L abgelehnt -> in 12 s NULL Herzschlaege, Wartezeit auf 60 s gewachsen, und
 * tafel/<sid>/meta.sv stand still. STUFE_OFFLINE_MS ist 60000 — der laufende OP-Saal verschwand
 * also von JEDEM anderen Bildschirm und aus jeder Fern-Ansicht, waehrend er in Wahrheit narkotisiert
 * weiterlief. Ein gestoerter Saal war von einem ausgeschalteten nicht mehr zu unterscheiden; genau
 * gegen diese Verwechslung ist der ganze Umbau gebaut.
 * Deshalb jetzt: Weg L hat sein eigenes .catch wie Tafel, Spiegel, Protokoll und Archiv, seine
 * Wartezeit und seine Abschaltung gelten NUR fuer ihn (Feld 'abgeschaltet'), und publish() prueft
 * je Ziel, ob es dran ist. Der verbleibende Preis ist benannt und getragen: schlaegt Weg L fehl,
 * waehrend Weg T durchgeht, stehen die WERTE still, waehrend die Tafel frisch bleibt. Das ist
 * sichtbar und gewollt — jeder Patientensatz in saele/ traegt sein eigenes ts, jede Kachel ihr
 * altMs, und status().tafel/status().lastError sagen es im Klartext.
 *
 * WAS DER TAFELTAKT IST (Nachbesserung N6): der HERZSCHLAG eines Saals. Er laeuft, auch wenn sich
 * an den Werten nichts aendert. Die alte Sparregel haengt an der LITERALEN Zeichenkette 'meta/ts'
 * und traegt fuer den neuen Zweig nicht; entschieden wird ab jetzt mit tafel.herzschlagFaellig().
 *
 * WAS ES NICHT MEHR GIBT: den Top-Level-Schluessel 'patients'. Er ersetzte den GANZEN Knoten und
 * haette in einem Konto mit mehreren Saelen die Spiegelschluessel aller anderen Saele weggeraeumt.
 * Auch das Sicherheits-Vollbild geht deshalb als TIEFE Pfade plus ausdrueckliche null-Loeschungen
 * der EIGENEN weggefallenen Schluessel (Nachbesserung N7).
 */
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const tafel = require('./tafel');
const stationsidModul = require('./stationsid');
const { appVersion } = require('./version');

/*
 * DAUERVERBINDUNG (keep-alive) — der groesste einzelne Geschwindigkeitsgewinn beim Senden.
 *
 * Jeder Schreibvorgang ist eine HTTPS-Anfrage. OHNE Dauerverbindung baut Node fuer JEDE Anfrage
 * eine neue TCP-Verbindung samt TLS-Handschlag auf: das sind zwei bis drei Rundreisen nach
 * Belgien, bevor auch nur ein Byte Nutzdaten fliesst — bei ~40 ms Rundreise also rund 100 ms
 * ZUSAETZLICHE Verzoegerung pro Wert, und das fuenfmal pro Sekunde. Mit einer offen gehaltenen
 * Verbindung entfaellt das komplett: es bleibt die reine Uebertragungszeit.
 *
 * maxSockets 4: genug, damit sich Live-Schreibvorgang, Token-Erneuerung und Archiv nie gegenseitig
 * blockieren, aber wenig genug, dass nicht bei jedem Aussetzer ein Schwarm neuer Verbindungen
 * aufgemacht wird. scheduling 'fifo' nimmt die aelteste freie Verbindung — die ist am
 * wahrscheinlichsten noch warm.
 */
const AGENT_HTTPS = new https.Agent({ keepAlive: true, keepAliveMsecs: 15000, maxSockets: 4, scheduling: 'fifo' });
const AGENT_HTTP = new http.Agent({ keepAlive: true, keepAliveMsecs: 15000, maxSockets: 4, scheduling: 'fifo' });

// ---- klinische Engine (fuer die Fern-Prioritaet/Top-Befund je Patient) ----
// UMD-Module laufen auch in Node (siehe ui/engine/*.js). Faellt sauber aus, wenn nicht ladbar.
let brain = null, anaes = null, ANAES = null;
try {
  brain = require('../../ui/engine/brain.js');
  anaes = require('./anaes.js');
  ANAES = anaes.loadAnaes();
} catch (_) { /* Enrichment optional — ohne Engine werden Rohwerte ohne pri/top gesendet */ }

const IDENTITY = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword';
const SECURETOKEN = 'https://securetoken.googleapis.com/v1/token';
const FIRESTORE = 'https://firestore.googleapis.com/v1';

// Aktuelle Fassung des Fern-Datenformats DER ALTEN FLACHEN EBENE. Die ausgelieferte Web-App 1.0.3
// liest sie aus meta.v. v3 = Praxis-Konten: der Datenpfad ist die Anmelde-Kennung, es gibt keinen
// Zugangscode mehr. SIE BLEIBT BEI 3 (Nachbesserung N11): die alte Web-App darf vom Umbau nichts
// merken. Die Fassung des NEUEN Tafelformats ist tafel.TAFEL_V und wird getrennt gefuehrt.
const FORMAT_V = 3;

/*
 * Der Serverzeitstempel als PLATZHALTER. {".sv":"timestamp"} ist kein Wert, sondern ein Auftrag an
 * die Datenbank: sie setzt beim Schreiben IHRE Zeit ein. Nur dadurch kann ein toter Saal nicht fuer
 * immer frisch aussehen — und nur deshalb laesst die Regel fuer tafel/<sid>/meta.sv ueberhaupt ein
 * Zeitfenster zu (newData.val() <= now && > now - 60000). Eine selbst gerechnete Zahl faellt dort
 * durch und nimmt den ganzen Koerper mit. Die Konstante steht EINMAL hier, damit nicht an fuenf
 * Stellen fuenf Objektliterale entstehen, von denen eines irgendwann anders heisst.
 */
const SV = { '.sv': 'timestamp' };

function sanitizeKey(s) {
  // RTDB-Schluessel + URL-Parameter: nur unbedenkliche Zeichen zulassen (Rest -> _).
  return String(s == null ? '' : s).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 200) || '_';
}
function nowSec() { return Math.floor(Date.now() / 1000); }
function nn(x) { return (x == null || Number.isNaN(x)) ? null : x; }

/*
 * Abtastwerte platzsparend kodieren.
 * Ein EKG-Streifen sind 512 Zahlen. Als JSON-Liste (["-123.4",...]) sind das je nach Verstaerkung
 * 2,5-4 KB; als Int16 mit gemeinsamem Skalenfaktor und Base64 rund 1,4 KB - und zwar mit FESTER
 * Groesse, unabhaengig davon wie "krumm" die Werte sind. Bei 256 Hz EKG + 40 Hz CO2 im Dauerbetrieb
 * ergibt das ca. 0,8 KB/s, also gut 2 GB im Monat - das passt in den kostenlosen Spark-Tarif
 * (10 GB/Monat), waehrend die JSON-Variante ihn gerissen haette.
 */
function encodeSamples(samples) {
  const n = samples.length;
  let max = 0;
  for (let i = 0; i < n; i++) {
    const s = samples[i];
    if (s != null && Number.isFinite(s)) { const a = Math.abs(s); if (a > max) max = a; }
  }
  const skala = max > 0 ? max / 32000 : 1;
  const buf = Buffer.allocUnsafe(n * 2);
  for (let i = 0; i < n; i++) {
    const s = samples[i];
    let q = (s == null || !Number.isFinite(s)) ? 0 : Math.round(s / skala);
    if (q > 32767) q = 32767; else if (q < -32768) q = -32768;
    buf.writeInt16LE(q, i * 2);
  }
  return { n: n, skala: skala, b64: buf.toString('base64') };
}

// Billiger Hash ueber Stuetzstellen — identisch zu matching.kurvenChecksum, damit lokale und ferne
// Ansicht denselben Streifen als "neu" erkennen.
function kurvenChecksum(samples) {
  if (!samples || !samples.length) return 0;
  const n = samples.length;
  const a = samples[0] || 0, b = samples[n - 1] || 0, c = samples[n >> 1] || 0;
  return (((a * 31 + b) * 31 + c) | 0);
}

class CloudPublisher {
  /*
   * cfg = {
   *   enabled, provider:'firebase',
   *   apiKey,            // Firebase Web-API-Key (oeffentlich)
   *   dbUrl,             // z.B. https://vet-station-default-rtdb.europe-west1.firebasedatabase.app
   *   email,             // Anmeldename des PRAXIS-Kontos (das Passwort steht NICHT hier, siehe unten)
   *   station,           // Anzeigename der Station ("Praxis OP 1")
   *   minIntervalMs,     // Mindestabstand zweier Schreibvorgaenge (Default 200, Minimum 100)
   *   vollbildMs,        // Abstand eines Sicherheits-Vollbildes (Default 30000)
   *   kurven,            // echte Abtastwerte mituebertragen (Default true)
   *   rohwerte,          // alle Einzelwerte des Geraets mituebertragen (Default true)
   *   stammdaten,        // Tiername + Patientenakte mituebertragen (Default TRUE, siehe unten)
   *   archiv: { enabled, intervalMs, projectId },   // Firestore-Verlauf
   *   authFile           // Pfad zur persistenten Token-Datei (Default data/cloud-auth.json)
   * }
   *
   * DAS PASSWORT GEHOERT NICHT IN DIE KONFIGURATION. Es wird EINMAL im Admin-Bereich der
   * Station eingegeben (oder ueber die Umgebungsvariable VETSTATION_PASSWORT bei automatischer
   * Einrichtung). Aus der Anmeldung entsteht ein Erneuerungs-Token, der in data/cloud-auth.json
   * liegt und Neustarts ueberdauert — das Passwort selbst wird nirgends gespeichert.
   * devices.json waere dafuer der falsche Ort: die Datei wird bei "Auf USB kopieren" mitgenommen
   * und liegt im Klartext auf dem Praxis-PC.
   */
  constructor(cfg, { log, stationsid } = {}) {
    this.cfg = cfg || {};
    this.log = log || { info() {}, warn() {}, error() {} };
    this.provider = this.cfg.provider || 'firebase';
    /*
     * DIE STATIONSKENNUNG WIRD BEVORZUGT UEBERGEBEN, nicht hier erzeugt (Argument 'stationsid').
     * Grund: die Kennung traegt eine INSTANZ ("hier laeuft genau EIN Prozess", neu bei jedem
     * Start). Gaebe es zwei Stationsid-Objekte im selben Prozess, stuende im Admin-Bereich und in
     * diagnose.js eine andere Instanz als die, die tatsaechlich in den Kontobaum geschrieben wird —
     * und die Erkennung einer doppelten Kennung wuerde den eigenen Zwilling nicht wiedererkennen.
     * Uebergibt der Aufrufer nichts, legt sich diese Datei beim ersten Takt selbst eine an
     * (_stationLaden), damit eine Station auch ohne Verdrahtung fern sichtbar bleibt.
     */
    this.stationsid = stationsid || null;
    this._stationLaedt = false;
    this._ohneKennungGemeldet = false;
    this.identityUrl = this.cfg.identityUrl || IDENTITY;   // fuer Tests ueberschreibbar
    this.tokenUrl = this.cfg.tokenUrl || SECURETOKEN;
    this.firestoreUrl = this.cfg.firestoreUrl || FIRESTORE;
    this.email = String(this.cfg.email || '').trim();
    /*
     * STAMMDATEN JETZT STANDARDMAESSIG AN (geaendert 27.07.2026 mit Einfuehrung der Praxis-Konten).
     * Solange der Fern-Zugang an einem weiterleitbaren Link hing, waere es falsch gewesen,
     * Tiername und Besitzerdaten mitzuschicken. Seit die Daten ausschliesslich unter der
     * Anmelde-Kennung der eigenen Praxis liegen und nur diese Praxis sie lesen kann, sind es
     * IHRE eigenen Daten in IHREM eigenen Konto — dann gehoert der Tiername auch aufs Protokoll,
     * sonst waere der Ausdruck als Dokument wertlos. Abschaltbar bleibt es trotzdem.
     */
    this.sendeStammdaten = this.cfg.stammdaten !== false;
    /*
     * TAKTE — Entscheidung des Nutzers vom 30.07.2026: "mehr Saele, aber im Freikontingent
     * bleiben". Deshalb 500 ms fuer die Werte statt der frueheren 200 ms und 2000 ms fuer die
     * Tafel. Das ist keine Schoenheitsentscheidung: das Freikontingent (10 GB/Monat) gilt fuer das
     * GESAMTE Firebase-Projekt, also fuer ALLE Praxen zusammen, und ab dem zweiten Saal je Praxis
     * vervielfacht sich die Menge. 100 ms Untergrenze wie bisher: schneller ist sinnlos (die
     * Geraete liefern deutlich traeger) und wuerde nur Bandbreite verbrennen.
     */
    /*
     * AUF 40 ms GESENKT (Weisung des Betreibers, 19.08.2026), nachdem die Strecke gemessen
     * war: docs/FERN-KURVEN-MESSUNG-2026-08-19.md. Von den 154 ms Ende zu Ende entstanden
     * 118 ms VOR dem ersten Byte auf der Leitung, und der groesste Einzelposten darin war
     * dieser Takt. Die Netzstrecke traegt es: 36 ms Umlauf ueber eine offene Verbindung.
     *
     * DIE UNTERGRENZE FAELLT VON 100 AUF 40 ms. Sie stand seit dem 30.07.2026 auf 100 mit
     * der Begruendung, schneller sei sinnlos, weil die Geraete traeger liefern. Fuer WERTE
     * stimmt das weiterhin; fuer KURVEN nicht - ein EKG mit 250 Hz erzeugt in 40 ms zehn
     * Abtastwerte, und die sollen fern ankommen, solange sie noch etwas bedeuten.
     *
     * WAS DAS KOSTET, steht im Freigabetext und ist gemessen, nicht geschaetzt. Wer das
     * Freikontingent enger braucht, setzt minIntervalMs in der Konfiguration wieder hoch -
     * die Einstellung bleibt genau dafuer bestehen.
     */
    this.minInterval = Math.max(40, Number(this.cfg.minIntervalMs) || 40);
    this.tafelTaktMs = Math.max(200, Number(this.cfg.tafelTaktMs) || 2000);
    // Sparregel N6: liegt im EIGENEN Saal kein Patient, genuegt ein Herzschlag alle 5 s. Nie
    // schneller als der Tafeltakt — sonst waere "Ruhe" teurer als Betrieb.
    this.ruheTaktMs = Math.max(this.tafelTaktMs, Number(this.cfg.ruheTaktMs) || 5000);
    /*
     * RUECKLESEWEG. Zwei Takte, weil zwei verschiedene Fragen:
     *  leseTaktMs  — der EIGENE Kopf (tafel/<sid>/meta.instanz, fuer die Erkennung einer doppelten
     *                Kennung) und das flache meta (fuer den Kompatibilitaetsmodus). Klein und
     *                dringend: stationsid.js verlangt drei Meldungen ueber 5 s, bevor ein Zwilling
     *                als bewiesen gilt, und oeffnet die Anlaufsperre nach 15 s.
     *  fremdLeseTaktMs — die Liste der NACHBARSAELE und ihre Koepfe. Teurer (ein Vorgang je Saal)
     *                und nicht dringend: Saalname und Betriebsmodus aendern sich in Minuten, nicht
     *                in Sekunden. Der Beweis fuer eine laufende 1.0.3 haengt am flachen meta, das
     *                im schnellen Takt mitkommt.
     */
    this.leseTaktMs = Math.max(500, Number(this.cfg.leseTaktMs) || this.tafelTaktMs);
    this.fremdLeseTaktMs = Math.max(this.leseTaktMs, Number(this.cfg.fremdLeseTaktMs) || 10000);
    // Kompatibilitaetsspiegel: laut Entscheidung des Nutzers DAUERHAFT an. Abschaltbar bleibt er
    // nur fuer den Fall, dass eine Praxis nachweislich keine 1.0.3-Ansicht mehr benutzt.
    this.spiegel = this.cfg.spiegel !== false;
    this.vollbildMs = Math.max(5000, Number(this.cfg.vollbildMs) || 30000);
    this.sendeKurven = this.cfg.kurven !== false;
    this.sendeRohwerte = this.cfg.rohwerte !== false;
    this.authFile = this.cfg.authFile || path.join(__dirname, '..', '..', 'data', 'cloud-auth.json');

    const arch = this.cfg.archiv || {};
    this.archiv = {
      enabled: arch.enabled !== false,
      intervalMs: Math.max(5000, Number(arch.intervalMs) || 15000),
      projectId: arch.projectId || this.cfg.projectId || this._projektAusDbUrl(),
    };
    this.letztesArchiv = 0;
    this.archivInFlight = false;
    this.archivFehler = null;
    this.archivAus = false;      // nach wiederholten Konfigurationsfehlern: Archiv still abschalten
    this.archivFehlerZahl = 0;
    this.archivGeschrieben = 0;

    this.idToken = null;
    this.refreshToken = null;
    this.localId = null;
    this.tokenExp = 0;          // Unix-Sekunden
    this.lastPublish = 0;       // ms
    this.inFlight = false;
    /*
     * EIGENE "laeuft gerade"-Marke FUER WEG L (Befund C1). inFlight deckt nur noch den gemeinsamen
     * Vorlauf ab (Anmeldung besorgen, Snapshot bauen); der Wert-Schreibvorgang selbst wird NICHT
     * mehr abgewartet, sonst haengt eine 8-Sekunden-Zeitueberschreitung auf Weg L den Herzschlag
     * fuer 8 Sekunden mit ab. Ohne eine eigene Marke liefen dagegen zwei Wert-Schreibvorgaenge
     * gleichzeitig, und der zweite rechnete sein Delta gegen ein Gedaechtnis, das der erste noch
     * gar nicht fortgeschrieben hat.
     */
    this.werteInFlight = false;
    this.authFailAt = 0;        // Backoff nach Auth-Fehlern
    this.started = false;
    this.lastError = null;

    // Delta-Buchhaltung: letzter tatsaechlich uebertragener Stand, je Pfad als JSON-Text.
    // ZWEI GETRENNTE BUECHER, weil zwei getrennte Ziele mit verschiedenen Takten und verschiedenem
    // Inhalt (der Spiegel laesst pri/top weg, N8). Ein gemeinsames Buch haette bedeutet, dass ein
    // fehlgeschlagener Spiegel-Schreibvorgang den Saalzweig zu einem Vollbild zwingt.
    this._gesendet = null;          // Weg L: Map 'saele/<sid>/patients/<key>/<feld>' -> JSON-Text
    this._spiegelGesendet = null;   // Weg S: Map 'patients/s<sid6>__<key>/<feld>' -> JSON-Text
    this._tafelStand = null;        // Weg T: {u:[Kachelschluessel], g:[Geraeteschluessel]}
    /*
     * Was beim Start schon in tafel/<sid> lag — getrennt vom eigenen Stand, weil der Schreibweg
     * _tafelStand nach jedem Erfolg ueberschreibt und den Fund sonst wegwerfen wuerde, bevor er
     * benutzt wird (Befund 17.08.2026). Wird von _tafelVorher() dazugelegt und nach dem ersten
     * erfolgreichen Schreibvorgang verworfen.
     */
    this._tafelAltbestand = null;
    this._letztesVollbild = 0;
    this._letzterSpiegelVollbild = 0;   // eigene Uhr: im Ruhezustand schreibt Weg L gar nicht
    /*
     * Beim naechsten Wert-Schreibvorgang ein VOLLBILD erzwingen (nach einem Fehler, nach dem Ende
     * der Doppelkennungs-Sperre). Frueher wurde dafuer das Gedaechtnis weggeworfen — das erzwingt
     * zwar auch ein Vollbild, nimmt ihm aber die LOESCHUNGEN: was in der Datenbank liegt und im
     * neuen Bild fehlt, kann nur aus dem alten Gedaechtnis kommen. Ohne das bleibt die Kachel
     * eines abgehaengten Patienten mit eingefrorenem altMs stehen (Karteileiche aus N7).
     */
    this._vollbildErzwingen = false;
    // Wann zuletzt WERTE geschrieben wurden. Nur noch fuer die Anzeige und fuer Messungen —
    // ueber den Herzschlag entscheidet er NICHT mehr (er darf es nicht: der Tafeltakt haengt an
    // der Uhr und an der Patientenzahl, an keinem Messwert, Nachbesserung N6).
    this._letzterSchreibvorgang = 0;
    this._letzterTafelTakt = null;  // null = noch nie -> herzschlagFaellig() sagt sofort "faellig"
    /*
     * Wann zuletzt ein Herzschlag WIRKLICH in der Datenbank angekommen ist, und welcher Takt dafuer
     * gerade gilt. Beides nur, damit status().tafel.aktiv eine gemessene Aussage ist und keine
     * Behauptung (Befund C1/C4): 'aktiv: true' stand dort frueher hart im Code, waehrend der
     * Herzschlag nachweislich stillstand.
     */
    this._letzterTafelErfolg = 0;
    this._tafelSollTakt = this.tafelTaktMs;
    this._kurvenSigGesendet = {};   // patientKey -> zuletzt uebertragene Kurvensignatur
    /*
     * Kurvenstreifen, die in DIESEM Snapshot stecken, aber noch nicht bestaetigt sind.
     * Ein Streifen gilt erst als uebertragen, wenn Weg L ihn wirklich losgeworden ist. Frueher
     * wurde er schon beim BAUEN des Snapshots als gesendet vermerkt — schlug der Schreibvorgang
     * fehl oder unterblieb er (Herzschlag-Takt ohne Wert-Takt, siehe C3), war der Streifen fuer
     * immer verloren: die Signatur galt als erledigt, der Streifen lag nirgends, und fern fehlte
     * die Kurve bis zum naechsten Signaturwechsel.
     */
    this._kurvenOffen = {};
    this._protokollGesendet = {};   // patientId -> Set der bereits uebertragenen Zeitpunkte
    this.bytesGesendet = 0;
    this.schreibVorgaenge = 0;
    this.protokollGesendet = 0;     // Zaehler fuer den Admin-Bereich
    this.sq = 0;                    // erfolgreiche Schreibvorgaenge MIT saele-Schluesseln (tafel/meta.sq)
    this.bauVersion = appVersion(); // tafel/<sid>/meta.bv — NICHT geraten, aus version.js

    /*
     * SERVERZEIT OHNE SDK. Alle Frischevergleiche der Tafel (tafel.js) rechnen gegen die Zeit der
     * DATENBANK: sv setzt der Server selbst, die eigene PC-Uhr ist es nicht. Wer hier die
     * unkorrigierte Uhr uebergibt, haelt auf einem PC mit leerer CMOS-Batterie jeden Nachbarn fuer
     * "aus der Zukunft" — und eine Einzelplatzpraxis dauerhaft fuer einen Mehrsaalbetrieb.
     * Gemessen wird der Versatz an der HTTP-Date-Kopfzeile JEDER Antwort (_reqJson). Sie hat 1 s
     * Aufloesung und wird abgeschnitten, unterschaetzt die Serverzeit also um bis zu 999 ms —
     * genau darauf ist tafel.qsEigenFrisch() ausgelegt, deshalb wird hier NICHTS dazugerechnet.
     */
    this._serverVersatz = 0;
    /* Der zuletzt gebaute Tafelinhalt, damit der LAN-Weg GENAU denselben ausliefert und ihn nicht
     * ein zweites Mal rechnet (Begruendung bei tafelSatz()). */
    this._tafelLetzter = null;
    this._versatzGemessen = false;

    // Rueckleseweg: was zuletzt aus dem Kontobaum kam. Eigenes Fehlerkonto — ein klemmender
    // Leseweg darf die Uebertragung nie abschalten (er ist kein Schreibfehler).
    this._flachMeta = null;
    this._flachGelesen = false;
    this._flachGelesenAm = 0;      // wann der flache Stand zuletzt ANKAM
    this._tafelEintraege = {};      // {sid: Kopf} der NACHBARSAELE
    this._tafelGelesen = false;
    this._letzteLese = 0;
    this._letzteFremdLese = 0;
    this._leseLaeuft = false;
    this.leseFehler = null;
    this.leseVorgaenge = 0;
    this._saalAltbestand = null;    // eigene Schluessel, die beim Start schon in der Datenbank lagen
    this._spiegelAltbestand = null;
    /*
     * DER BLICK AUF DEN EIGENEN ALTBESTAND DARF NICHT LAUTLOS AUSFALLEN (Befund C6).
     * Frueher stand hier ein einziges Ja/Nein, und es wurde gesetzt, BEVOR die Abfrage ueberhaupt
     * losging: fiel die Leitung genau beim Start kurz aus, blieb der Altbestand fuer die ganze
     * Laufzeit unbekannt und wurde nie nachgeholt — und genau dann steht die Karteileiche in der
     * Tafel, gegen die dieser Blick gebaut ist (ein abgehaengter Patient mit eingefrorenem altMs).
     * Jetzt: hoechstens drei Versuche, und 'erledigt' wird erst im Erfolgsfall gesetzt.
     */
    this._altbestandGeholt = false;
    this._altbestandLaeuft = false;
    this._altbestandVersuche = 0;
    this._deckelGemeldet = 0;

    // Kompatibilitaetsmodus (tafel.modusAus). fremdSeit wandert hin und zurueck, entschieden wird
    // in tafel.js — hier wird NICHTS nachgerechnet, sonst laufen zwei Quellen auseinander.
    this._fremdSeit = null;
    this._qsGeschrieben = false;
    this._qsGeschriebenAm = 0;     // wann wir zuletzt ein qs-Kind GESCHRIEBEN haben
    this._modus = 'F0';
    this._modusGrund = 'noch nichts gelesen';
    this._saele = 0;
    this._beendet = null;           // beim geordneten Beenden gesetzt (tafel/<sid>/meta.aus)

    /*
     * GETRENNTE FEHLERKONTEN FUER TAFEL UND SPIEGEL, nach dem Vorbild des Firestore-Archivs.
     * KEINE Selbstabschaltung fuer die Tafel: sie ist der Herzschlag dieses Saals und die einzige
     * Stelle, an der ein anderer Bildschirm im Haus ueberhaupt sieht, dass es diesen Saal gibt.
     * Statt dessen eine wachsende Wartezeit — hoechstens eine Anfrage je Minute, das kostet nichts
     * und gibt nie auf. Der Spiegel darf sich abschalten (er ist eine Zugabe fuer die alte
     * Web-App); die Ueberwachung haengt an keinem von beiden.
     */
    this.tafelInFlight = false;
    this.tafelFehler = null;
    this.tafelFehlerZahl = 0;
    this.tafelGeschrieben = 0;
    this.tafelBackoffMs = 0;
    this.tafelNaechster = 0;
    this.spiegelInFlight = false;
    this.spiegelFehler = null;
    this.spiegelFehlerZahl = 0;
    this.spiegelGeschrieben = 0;
    this.spiegelAus = false;
    this.spiegelBackoffMs = 0;
    this.spiegelNaechster = 0;
    /*
     * Beim naechsten Spiegel-Schreibvorgang ein VOLLBILD erzwingen. Gesetzt wird das beim Wechsel
     * des Kompatibilitaetsmodus — Begruendung in _spiegelSchreiben (Befund C2): der Modus
     * entscheidet, WELCHE Felder gespiegelt werden, und was jetzt wegfaellt, muss ausdruecklich
     * geloescht werden statt einfach vergessen.
     */
    this._spiegelVollbildErzwingen = false;

    /*
     * PROZESSSTEMPEL — der Kern der Reparatur vom 30.07.2026.
     *
     * WAS VORHER GESCHAH (nachgemessen, Belegstellen unten): registry laedt das OP-Protokoll beim
     * Start aus bridge/data/protokoll.json (registry.js:81-87) — die Datei ueberdauert jeden
     * Neustart. Die Merkliste _protokollGesendet lebt dagegen nur im Speicher und ist nach einem
     * Neustart leer. Die Station bot deshalb JEDE bereits uebertragene Protokollzeile erneut an.
     * Die Regel protokoll/$patient/$zeitpunkt lautet "!data.exists()" (firebase-rtdb-rules.json:65)
     * und ist eine UNVERAENDERLICHKEITS-Regel, keine Aenderungserkennung: sie lehnt auch einen
     * Schreibvorgang mit identischem Inhalt ab. Ein Mehrpfad-PATCH ist atomar — mit dem Protokoll
     * fielen also auch meta und alle Vitalwerte durch. HTTP 401 zaehlt als Konfigurationsfehler
     * (Zeile 232), und nach drei davon schaltete _selbstAbschalten die Fern-Uebertragung dieser
     * Station ab. Ein Neustart half NICHT — er stellte genau denselben Zustand wieder her.
     * Nach etwa 30 Sekunden ab dem Neustart stand in der Fern-Ansicht ein eingefrorenes Bild,
     * und das Log begruendete es mit der falschen Ursache (Anmeldeproblem, wegen der "401").
     *
     * Ein eingefrorener Wert ist am narkotisierten Patienten schlimmer als ein leeres Feld: er
     * sieht aus wie eine Messung. Deshalb ist das hier kein Schoenheitsfehler.
     *
     * WAS DER STEMPEL LEISTET: alles, was VOR diesem Prozess entstand, liegt entweder schon in der
     * Datenbank oder gehoert nicht mehr dorthin. Es wird einmalig als erledigt vermerkt statt
     * erneut gesendet. Fachlich unschaedlich: diese Zeilen stehen in der Fern-Ansicht bereits, und
     * der lokale PDF-Ausdruck liest ohnehin aus registry.protokollVon(), nie aus der Cloud.
     */
    this.prozessStart = Date.now();
    this._altzeilenUebersprungen = 0;
    this._altzeilenGemeldet = false;
    /*
     * AUS DEM STEMPEL FUEHRT SEIT DEM 21.08.2026 EIN AUSDRUECKLICHER WEG HERAUS.
     *
     * Wunsch aus der Praxis: "wenn in der VetStation ein Protokoll gespeichert, gedruckt oder
     * erstellt wird, muss es sofort und vollstaendig in der Web-App stehen, damit man es dort
     * ausdrucken kann." Der Stempel oben verhindert genau das nach einem Neustart der Station:
     * die Zeilen von VOR dem Neustart werden nie wieder angeboten. Fuer den LAUFENDEN Strom ist
     * das richtig und bleibt (die Begruendung darueber gilt unveraendert) — fuer ein
     * ausdruecklich erzeugtes Dokument nicht.
     *
     * WARUM DAS GEFAHRLOS IST, obwohl es genau der Vorgang ist, der 2026 einmal die ganze
     * Fern-Uebertragung abgeschaltet hat: seit dem 30.07.2026 hat das Protokoll ein EIGENES
     * Fehlerkonto (protokollInFlight/protokollFehler/protokollAus), es geht in einem EIGENEN
     * Schreibvorgang, und eine Ablehnung wird nicht geraten, sondern nachgesehen
     * (_protokollAbgleich liest flach, welche Zeitpunkte wirklich schon dort liegen). Eine
     * bereits vorhandene Zeile wird also bestaetigt statt als Fehler gezaehlt, und die
     * Vitalwerte beruehrt der ganze Vorgang nicht mehr.
     *
     * BEGRENZT IST ER TROTZDEM: er gilt je Patient, er wird nur auf ausdrueckliche Anforderung
     * gesetzt, und er loescht sich selbst, sobald fuer diesen Patienten nichts Offenes mehr da
     * ist. Er ist kein Dauerzustand.
     */
    this._protokollNachtrag = {};    // sanitisierter Patientenschluessel -> true
    this.protokollNachtragLaeuft = 0;
    this.ausdruckInFlight = false;
    this.ausdruckFehler = null;
    this._ausdruckWartet = [];    /* Vermerke, die warten, weil gerade einer laeuft */

    /*
     * EIGENES FEHLERKONTO FUER DAS PROTOKOLL, nach dem Vorbild des Firestore-Archivs (Zeile 812).
     * Das Protokoll ist Dokumentation, die Vitalwerte sind die Ueberwachung. Die Dokumentation
     * darf die Ueberwachung nie ausbremsen und schon gar nicht abschalten. Deshalb geht sie ab
     * jetzt in einem EIGENEN Schreibvorgang, und ihre Fehler bleiben in diesen Feldern —
     * sie beruehren konfigFehler, idToken und _gesendet nicht.
     */
    this.protokollInFlight = false;
    this.protokollFehler = null;
    this.protokollFehlerZahl = 0;
    this.protokollAus = false;
    this.protokollEinzeln = false;   // nach einem Streitfall: Zeile fuer Zeile statt gebuendelt
    this._letzterAbgleich = 0;

    // Selbstschutz gegen Log-Flutung (Befund 2.2, 21.07.2026): bei nicht erreichbarer Datenbank
    // schrieb der Publisher ~2 Fehlerzeilen pro Sekunde und verdraengte nach vier Minuten
    // SAEMTLICHE Verbindungsmeldungen aus dem Ringpuffer. Jetzt: wachsende Wartezeit und nach
    // drei KONFIGURATIONSfehlern (die sich von selbst nie beheben) Selbstabschaltung mit Begruendung.
    this.backoffMs = 0;          // aktuelle Zwangspause nach einem Fehler
    this.naechsterVersuch = 0;   // Zeitpunkt, ab dem wieder geschrieben werden darf
    this.konfigFehler = 0;       // Zaehler NUR fuer nicht selbstheilende Fehler
    this.abgeschaltet = false;
    this.abschaltGrund = null;
    /*
     * AUS DER SELBSTABSCHALTUNG FUEHRT EIN WEG ZURUECK (02.08.2026).
     *
     * Bis hierher war 'abgeschaltet' eine Einbahnstrasse: zurueckgesetzt wurde es nur in
     * anmelden() und anmeldenMitToken(). Der Erfolgsweg (konfigFehler = 0) konnte nie erreicht
     * werden, weil werteFaellig ausdruecklich '!this.abgeschaltet' verlangt. Wer einmal
     * abgeschaltet war, brauchte einen Menschen am Praxis-PC — moeglicherweise mitten in einer
     * Narkose. Das ist auch dann falsch, wenn die Ursache wirklich in der Konsole liegt: die
     * Regeln koennen dort in der Zwischenzeit veroeffentlicht worden sein, und dann soll die
     * Station das von selbst merken.
     * Also: nach PROBE_NACH_MS wird GENAU EIN Schreibvorgang zugelassen. Gelingt er, laeuft die
     * Uebertragung wieder an (und sagt das im Klartext). Scheitert er, bleibt alles wie es war
     * und der naechste Versuch kommt in weiteren fuenf Minuten — das ist eine Anfrage je fuenf
     * Minuten und flutet weder Log noch Freikontingent.
     */
    this.abschaltAm = 0;
    this.probeVersuche = 0;      // wie oft nach einer Abschaltung ein Probeschreiben lief
  }

  /*
   * DER SAALNAME — EIN ZUGRIFF, KEIN FELD (Naht zu N10, nachgebessert 30.07.2026).
   *
   * WAS VORHER GESCHAH: hier stand im Konstruktor
   *     this.station = CloudPublisher._kurz(this.cfg.station, 120) || 'VetStation'
   * Damit war cfg.station aus bridge/config/devices.json die Quelle des Namens — und der GESETZTE
   * Name aus data/station-id.json verliess den PC ueberhaupt nicht. Der Admin-Bereich speicherte
   * ihn, zeigte ihn an und meldete Erfolg, waehrend in Tafel, Kompatibilitaetsspiegel und
   * Firestore-Verlauf weiter der Vorlagewert stand. Da devices.json im Auslieferstand gar nicht
   * existiert (Install-VetStation.ps1 schliesst sie aus), hiessen ALLE Saele aller Praxen gleich —
   * genau die Verwechslung zweier narkotisierter Tiere, gegen die N10 gebaut ist.
   *
   * ES IST BEWUSST EIN GETTER UND KEIN FELD. Ein Feld waere beim Start gesetzt worden und haette
   * eine Umbenennung IM LAUFENDEN BETRIEB (POST /api/station/name, mitten in der Narkose zulaessig)
   * bis zum naechsten Programmstart eingefroren — dieselbe Fehlerklasse in klein. Ein Zugriff kann
   * nicht veralten. Der Preis ist ein Funktionsaufruf und ein Regex ueber hoechstens 120 Zeichen je
   * Takt; gemessen an einem abgewiesenen Koerper samt Vitalwerten ist das nichts.
   *
   * DIE QUELLE IST stationsid.stationsName() UND NUR SIE: gesetzter Name schlaegt Vorbelegung,
   * der Vorlagewert 'Praxis OP 1' zaehlt nicht, kein Rueckfall auf den Rechnernamen. cfg.station
   * ist ab jetzt reine VORBELEGUNG und wird genau dort hineingereicht.
   *
   * NULL IST EIN GUELTIGER ZUSTAND ("dieser Saal hat noch keinen Namen") und wird NICHT durch eine
   * erfundene Zeichenkette ersetzt. Wer eine Zeichenkette braucht (Firestore-Feld, Anzeige), setzt
   * an seiner Stelle tafel.SPIEGEL_NAME_UNBENANNT ein — die Ersatzzeichenkette gehoert der Anzeige,
   * nicht dieser Quelle.
   *
   * DIE KAPPUNG AUF 120 BLEIBT. stationsName() kappt bereits auf NAME_MAX (=120), die zweite
   * Kappung hier ist trotzdem kein Zierat: sie ist die Zeile, an der tools/regeln-test.js die
   * Kappung im Code GEGEN die Regelgrenze fuer meta/station misst (dort sind 120 die niedrigste
   * Grenze der ganzen Regeldatei). Ein Name mit 121 Zeichen laesst die Datenbank den ganzen
   * atomaren Koerper abweisen — samt Vitalwerten.
   */
  get station() {
    return CloudPublisher._kurz(stationsidModul.stationsName(this.stationsid, this.cfg.station), 120);
  }
  /* Der Saalname fuer Felder, die zwingend eine Zeichenkette brauchen (Firestore-Verlauf,
   * Anzeige im Admin-Bereich). Die Ersatzzeichenkette steht EINMAL in tafel.js. */
  _stationText() { return this.station || tafel.SPIEGEL_NAME_UNBENANNT; }

  _projektAusDbUrl() {
    // https://vet-station-default-rtdb.europe-west1.firebasedatabase.app -> vet-station
    const m = /^https?:\/\/([a-z0-9-]+?)-default-rtdb\./i.exec(String(this.cfg.dbUrl || ''));
    return m ? m[1] : null;
  }

  /*
   * TEXTE KAPPEN, BEVOR SIE IN DIE DATENBANK GEHEN (30.07.2026).
   *
   * WARUM DAS KEIN SCHOENHEITSTHEMA IST: die Sicherheitsregeln der Datenbank setzen Laengengrenzen.
   * Ist ein Feld laenger, wird der Schreibvorgang ABGELEHNT — und weil ein Mehrpfad-PATCH atomar
   * ist, mit den Vitalwerten zusammen. Drei Ablehnungen in Folge, und die Fern-Uebertragung dieser
   * Station schaltet sich ab (dieselbe Kette wie beim Protokoll-Altfehler oben).
   *
   * EIN FALL IST HEUTE SCHON SCHARF: meta/station. Die veroeffentlichte Regel erlaubt dort 120
   * Zeichen, der Saalname kam aber ungekappt aus devices.json. Wer seinen OP-Saal ausfuehrlich
   * benennt, haette die Fern-Uebertragung seiner Praxis damit lahmgelegt — ohne dass irgendetwas
   * auf den Namen hingewiesen haette. Gekappt wird er heute im Zugriff 'station' (siehe oben).
   *
   * Die uebrigen Felder stammen vom GERAET (Tiername, Alarmtexte, Geraetemodell, Rohwert-Einheiten)
   * und sind damit von aussen bestimmt. Sie werden auf 200 Zeichen gekappt — das ist die Grenze,
   * gegen die die neuen Regeln pruefen, und mehr braucht keines dieser Felder auf einem Bildschirm.
   *
   * AUSDRUECKLICH NICHT GEKAPPT: kurven/<kanal>/b64 und kurvenSig. Das sind keine Texte zum Lesen,
   * sondern die Abtastwerte selbst — eine Kappung wuerde die Kurve zerstoeren, und die Regeln
   * lassen dort entsprechend viel zu.
   */
  static _kurz(s, max) {
    if (s == null) return null;
    // Steuerzeichen raus: in JSON zulaessig, aber ein Zeilenumbruch mitten im Saalnamen
    // zerreisst die Kopfleiste und macht jedes Diagnose-Log unlesbar. Bindestriche bleiben —
    // sie stehen in Geburtsdaten, Adressen und Geraetenamen.
    const t = String(s).replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ');
    return t.length > max ? t.slice(0, max) : t;
  }
  /* Ein Objekt aus fremder Hand: Schluessel UND Werte begrenzen, und nicht beliebig viele davon.
   * Die Patientenakte des Geraets ist so ein Objekt — sie wird unveraendert durchgereicht. */
  static _kurzObjekt(o, max, maxFelder) {
    if (!o || typeof o !== 'object') return null;
    const out = {};
    Object.keys(o).slice(0, maxFelder).forEach((k) => {
      const kk = CloudPublisher._kurz(k, 64);
      if (!kk) return;
      const v = o[k];
      out[kk] = (v && typeof v === 'object') ? null
        : (typeof v === 'string' ? CloudPublisher._kurz(v, max) : v);
    });
    return out;
  }

  /*
   * Unterscheidet Fehler, die sich von selbst erledigen koennen (Netz weg, Zeitueberschreitung),
   * von solchen, die ohne Eingriff NIE verschwinden (Datenbank existiert nicht, Regeln verbieten
   * das Schreiben, Adresse falsch geschrieben). Nur letztere fuehren zur Selbstabschaltung.
   *
   * ENOTFOUND UND EAI_AGAIN SIND HIER RAUSGEFLOGEN (02.08.2026) — sie standen im Widerspruch zum
   * Satz direkt darueber. Es sind GENAU die beiden Meldungen, die Node liefert, wenn das Internet
   * weg ist und deshalb kein Name mehr aufgeloest werden kann ("getaddrinfo EAI_AGAIN vet-station
   * -default-rtdb…"). Damit galt ein Router-Neustart von zehn Sekunden als dauerhafter
   * Konfigurationsfehler: drei Takte a 2/4 s, dann _selbstAbschalten() — und 'abgeschaltet' wurde
   * ausser bei einer Neuanmeldung nie wieder zurueckgesetzt.
   *
   * Was der Tierarzt davon gehabt haette: der Herzschlag (Weg T) laeuft nach der Selbstabschaltung
   * ausdruecklich weiter, der Saal steht in der Fern-Ansicht also weiterhin auf "live" — mit den
   * eingefrorenen Zahlen von vor dem Ausfall. Ein Tier, das fern ueberwacht wird, sieht damit
   * stabil aus, waehrend im OP etwas anderes passiert. Das ist die gefaehrlichste Fehlerart, die
   * dieses Programm haben kann, und sie entstand aus zwei Woertern in dieser Zeile.
   *
   * Bleiben: HTTP 400/401/403/404/409 (Datenbank/Regeln/Adresse) und PERMISSION_DENIED. Die
   * gehoeren wirklich in die Firebase-Konsole und nicht auf diesen PC.
   */
  static _istKonfigFehler(msg) {
    return /HTTP 40[01349]|URL ungueltig|PERMISSION_DENIED/i.test(String(msg || ''));
  }

  // Der Fern-Zugang ist jetzt eine reine Anmeldung — es gibt keinen Code mehr im Link.
  // Der Tierarzt oeffnet die Web-App und meldet sich mit DEMSELBEN Praxis-Konto an.
  shareUrl(base) {
    return base || 'https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/';
  }

  // Ist die Praxis angemeldet (gueltiges Token oder wenigstens ein Erneuerungs-Token)?
  angemeldet() {
    return !!(this.localId && (this.refreshToken || (this.idToken && this.tokenExp > nowSec())));
  }

  start() {
    if (this.started) return;
    if (!this.cfg.enabled) { this.log.info('cloud', 'Fern-Live deaktiviert (cloud.enabled=false).'); return; }
    if (this.provider !== 'firebase') { this.log.warn('cloud', 'Unbekannter Provider "' + this.provider + '" — nur "firebase" unterstuetzt.'); return; }
    if (!this.cfg.apiKey || !this.cfg.dbUrl) {
      this.log.warn('cloud', 'Fern-Live: apiKey/dbUrl fehlen in der Konfiguration (cloud-Block). Uebertragung aus.');
      return;
    }
    this._loadAuth();
    this._gesendet = null;   // beim Start immer ein Vollbild
    // started erst NACH der Anmeldepruefung setzen: "gestartet" soll heissen "sendet tatsaechlich".
    // Sonst meldet der Admin-Bereich eine laufende Uebertragung, die es gar nicht gibt.
    if (!this.angemeldet()) {
      this.log.warn('cloud', 'Fern-Live wartet auf die PRAXIS-ANMELDUNG. ' +
        'Im Admin-Bereich unter "📡 Fern-Live" mit dem Praxis-Konto anmelden — danach laeuft die ' +
        'Uebertragung automatisch, auch nach jedem Neustart. Bis dahin wird nichts gesendet ' +
        '(die Geraeteanzeige vor Ort ist davon nicht betroffen).');
      return;
    }
    this.started = true;
    // Die Stationskennung schon jetzt besorgen, damit der erste Takt sofort schreiben kann.
    this._stationLaden();
    this.log.info('cloud', 'Fern-Live AKTIV als "' + (this.email || this.localId) + '", Takt ' +
      this.minInterval + ' ms' + (this.sendeKurven ? ', mit echten Kurven' : '') + '.');
    this.log.info('cloud', 'Fern ansehen: ' + this.shareUrl() + ' — dort mit DEMSELBEN Praxis-Konto anmelden.');
    if (!this.sendeStammdaten) {
      this.log.info('cloud', 'Fern-Live: Tiername/Patientenakte werden NICHT uebertragen (cloud.stammdaten=false).');
    }
    if (this.archiv.enabled && this.archiv.projectId) {
      this.log.info('cloud', 'Firestore-Verlauf aktiv: alle ' + Math.round(this.archiv.intervalMs / 1000) + ' s.');
    }
  }

  /*
   * status(privat) — Zustand fuer die Anzeige.
   *
   * OHNE privat=true bleiben Anmeldename und Kennung DRAUSSEN. Grund: /api/cloud antwortet mit
   * "Access-Control-Allow-Origin: *", das heisst JEDE beliebige Webseite, die im Browser des
   * Praxis-PCs geoeffnet ist, kann diese Antwort auslesen. Was dort steht, ist damit faktisch
   * oeffentlich. Anmeldename und Kennung gehen deshalb nur ueber den auf 127.0.0.1 beschraenkten
   * Endpunkt /api/praxis heraus.
   */
  /*
   * ZWEI AUSKUENFTE FUER DIE NACHBARSAELE — und ausdruecklich nur Auskuenfte.
   *
   * tafelSatz() gibt den zuletzt gebauten Tafelinhalt heraus (bridge/src/nachbar.js liefert ihn
   * ueber den direkten Weg im Haus aus). null, solange noch kein Takt gelaufen ist oder die
   * Fern-Uebertragung aus ist — dann hat dieser Saal auch fuer die Cloud noch nichts gesagt, und
   * ein erfundener Satz waere schlimmer als keiner.
   *
   * serverVersatzMs() gibt den gemessenen Unterschied zwischen dieser PC-Uhr und der Serverzeit
   * heraus. Ohne ihn rechnet der Leseweg das Alter fremder Saele gegen die ROHE eigene Uhr —
   * geht sie zwei Minuten vor, erscheint jeder gesunde Nachbarsaal als zwei Minuten alt.
   * Es gibt ihn genau einmal im Prozess, gemessen an derselben Stelle wie die eigene Laufzeit.
   */
  tafelSatz() { return this._tafelLetzter || null; }
  serverVersatzMs() { return this._serverVersatz || 0; }

  status(privat) {
    const s = {
      enabled: !!this.cfg.enabled, provider: this.provider,
      /*
       * 'started' heisst hier "die UEBERWACHUNG wird uebertragen" — so steht es seit jeher in
       * start() ('"gestartet" soll heissen "sendet tatsaechlich"'). Seit die Selbstabschaltung nur
       * noch Weg L trifft (Befund C1), ist this.started dafuer nicht mehr die ganze Wahrheit:
       * der Prozess laeuft weiter und schreibt den Herzschlag, die Werte aber nicht. Der
       * Admin-Bereich faerbt seine Ampel an diesem Feld — es muss also den Wertestrom meinen.
       * Was der Herzschlag tut, sagt tafel.aktiv weiter unten.
       */
      started: this.started && !this.abgeschaltet,
      station: this._stationText(), url: this.shareUrl(),
      angemeldet: this.angemeldet(),
      authed: this.angemeldet(),
      lastPublish: this.lastPublish, lastError: this.lastError,
      abgeschaltet: this.abgeschaltet, abschaltGrund: this.abschaltGrund,
      backoffMs: this.backoffMs,
      taktMs: this.minInterval, formatV: FORMAT_V,
      kurven: this.sendeKurven, rohwerte: this.sendeRohwerte, stammdaten: this.sendeStammdaten,
      schreibVorgaenge: this.schreibVorgaenge, bytesGesendet: this.bytesGesendet,
      protokollGesendet: this.protokollGesendet,
      /*
       * Eigener Zustand fuer das Protokoll. Es kann jetzt ausfallen, OHNE dass die Vitalwerte
       * ausfallen — dann muss der Admin-Bereich das aber auch sagen koennen. Ein stiller Ausfall
       * der Dokumentation waere schlimmer als ein sichtbarer.
       */
      protokoll: {
        aktiv: !this.protokollAus,
        lastError: this.protokollFehler,
        altzeilenUebersprungen: this._altzeilenUebersprungen,
        /* Ein laufender Nachtrag muss sichtbar sein: solange er laeuft, ist die Fern-Ansicht
         * noch NICHT vollstaendig, und wer dort druckt, druckt einen halben Verlauf. Der
         * Admin-Bereich zeigt das an, die Fern-Ansicht kann es ebenfalls lesen. */
        nachtragLaeuft: this.protokollNachtragLaeuft,
        ausdruckFehler: this.ausdruckFehler,
      },
      /*
       * Jedes Ziel meldet sich selbst. Ein stiller Ausfall der Tafel waere schlimmer als ein
       * sichtbarer: der Saal verschwindet dann von jedem anderen Bildschirm im Haus, waehrend die
       * Werte hier weiterlaufen und niemand einen Grund sieht.
       */
      tafel: {
        /*
         * 'aktiv' ist eine MESSUNG, keine Zusage (Befund C1/C4). Hier stand frueher hart 'true'
         * mit der Begruendung, die Tafel schalte sich nie ab. Das stimmte auch — nur ging der
         * Herzschlag trotzdem nicht raus, weil ein Fehler auf dem WERT-Weg den ganzen Takt sperrte.
         * Ein Feld, das "alles in Ordnung" meldet, waehrend der Saal auf jedem anderen Bildschirm
         * als offline steht, ist schlimmer als gar kein Feld: es ist genau die Stelle, an der ein
         * Tierarzt nachsieht, wenn der Nachbarsaal verschwunden ist.
         */
        aktiv: this._tafelSchlaegt(), taktMs: this.tafelTaktMs, geschrieben: this.tafelGeschrieben,
        lastError: this.tafelFehler, backoffMs: this.tafelBackoffMs,
      },
      spiegel: {
        aktiv: this.spiegel && !this.spiegelAus, geschrieben: this.spiegelGeschrieben,
        lastError: this.spiegelFehler, backoffMs: this.spiegelBackoffMs,
      },
      saal: {
        modus: this._modus, grund: this._modusGrund, saele: this._saele,
        gelesen: this._tafelGelesen && this._flachGelesen,
        leseFehler: this.leseFehler, serverVersatzMs: this._serverVersatz,
        sperre: this.stationsid ? this.stationsid.kollisionsstand() : 'unbekannt',
      },
      archiv: {
        enabled: this.archiv.enabled && !this.archivAus, projectId: this.archiv.projectId,
        intervalMs: this.archiv.intervalMs,
        geschrieben: this.archivGeschrieben, lastError: this.archivFehler,
      },
    };
    /*
     * DIE STATIONSKENNUNG STEHT NUR IM PRIVATEN ZUSTAND. Sie ist kein Geheimnis (stationsid.js sagt
     * das ausdruecklich), aber /api/cloud antwortet mit "Access-Control-Allow-Origin: *" — was
     * dort steht, kann jede beliebige Webseite im Browser des Praxis-PCs auslesen. Ein Wert, den
     * niemand braucht, gehoert dann auch nicht hinein.
     * DER SAALNAME STEHT DAGEGEN OBEN IM OEFFENTLICHEN TEIL (Feld 'station', seit 1.0.3). Das ist
     * Bestand und bleibt so: die Oberflaeche zeigt ihn in der Kopfzeile, und er steht ohnehin in
     * jeder Fern-Ansicht dieser Praxis.
     */
    if (privat) {
      s.email = this.email || null;
      s.uid = this.localId || null;
      s.sid = this._sid();
      s.instanz = this.stationsid ? this.stationsid.instanz : null;
      s.kollision = this.stationsid ? this.stationsid.kollisionVermerk() : null;
    }
    return s;
  }

  /*
   * anmelden(email, passwort) — einmalige Praxis-Anmeldung aus dem Admin-Bereich.
   * Danach traegt der Erneuerungs-Token die Station ueber alle Neustarts; das Passwort wird
   * NICHT gespeichert. Setzt ausserdem die Fehlerzaehler zurueck, damit ein vorher falsch
   * eingegebenes Passwort die Uebertragung nicht dauerhaft stillgelegt laesst.
   */
  async anmelden(email, passwort) {
    const mail = String(email || '').trim();
    if (!mail || !passwort) throw new Error('E-Mail und Passwort werden beide gebraucht.');
    if (!this.cfg.apiKey) throw new Error('In der Konfiguration fehlt der Firebase-Schluessel (cloud.apiKey).');
    this.email = mail;
    this.idToken = null; this.refreshToken = null; this.localId = null; this.tokenExp = 0;
    await this._signIn(passwort);
    // Nach erfolgreicher Anmeldung alles zuruecksetzen, was eine fruehere Fehlkonfiguration
    // hinterlassen hat — sonst bliebe die Station trotz gueltiger Anmeldung abgeschaltet.
    this.abgeschaltet = false; this.abschaltGrund = null;
    this.konfigFehler = 0; this.backoffMs = 0; this.naechsterVersuch = 0;
    this.authFailAt = 0; this.lastError = null;
    this.archivAus = false; this.archivFehler = null; this.archivFehlerZahl = 0;
    this.protokollAus = false; this.protokollFehler = null; this.protokollFehlerZahl = 0;
    this.protokollEinzeln = false;
    this._zieleZuruecksetzen();
    this._gesendet = null;             // naechster Schreibvorgang ist ein Vollbild
    /*
     * Nach einer Neuanmeldung kann die Konto-Kennung eine ANDERE sein — dann liegt unter dem neuen
     * Konto noch kein Protokoll, und alles muss neu hin. Deshalb wird hier geleert. Der
     * Prozessstempel bleibt aber: was vor diesem Programmstart entstand, wird auch jetzt nicht
     * nachgesendet, sonst waere der reparierte Fehler durch eine Neuanmeldung wieder da.
     */
    this._protokollGesendet = {};
    this._kurvenSigGesendet = {};
    this.started = !!this.cfg.enabled;
    this._stationLaden();
    this.log.info('cloud', 'Praxis angemeldet: ' + this.email + '. Fern-Live sendet ab sofort.');
    return this.status(true);
  }

  /*
   * anmeldenMitToken(refreshToken, uid, email) — Anmeldung mit dem GOOGLE-Konto.
   *
   * WARUM DIESER UMWEG: Eine Google-Anmeldung laeuft ueber die Zustimmungsseite von Google und
   * braucht dafuer einen Browser. Der Praxis-PC hat einen — die Oberflaeche der Station LAEUFT ja
   * in einem. Der Browser meldet sich also an, und die Bridge bekommt anschliessend nur noch die
   * Erneuerungs-Kennung. Der Alternativweg waere ein eigener OAuth-Client mit Geraete-Anmeldung
   * in Node gewesen: mehr Teile, mehr Fehlerquellen, und der Tierarzt haette Codes abtippen muessen.
   *
   * Die uebergebene Kennung wird NICHT geglaubt, sondern nachgeprueft: _refresh() tauscht den
   * Token bei Google gegen ein frisches Zugangs-Token und liefert die Kennung aus erster Hand.
   * Ohne diese Probe koennte ein beliebiger Fremdtoken hier landen und die Station wuerde in
   * einen fremden Datenpfad schreiben.
   */
  async anmeldenMitToken(refreshToken, uid, email, anbieter) {
    /*
     * DER ANBIETERNAME WIRD MITGEFUEHRT (02.08.2026, Befund Schwere 2).
     *
     * Hier stand ueberall fest "Google" — im Log und in der Fehlermeldung. Meldet sich eine Praxis
     * ueber Microsoft/Outlook an, schrieb die Station trotzdem "Praxis ueber Google angemeldet"
     * und im Fehlerfall "Die Anmeldung wurde von Google nicht bestaetigt". Wer daraufhin die
     * Google-Einstellungen prueft, sucht am falschen Ort. Der Anmeldeweg ist im Code seit 1.0.2
     * anbieterunabhaengig; nur die Texte waren es nicht.
     * Der Wert kommt aus der Oberflaeche und wird NUR fuer Text benutzt — an der Pruefung des
     * Tokens aendert er nichts (die laeuft weiterhin ueber _refresh() gegen Google Identity,
     * unabhaengig davon, welcher Anbieter dahinterstand).
     */
    const anbName = /microsoft/i.test(String(anbieter || '')) ? 'Microsoft/Outlook'
      : (/google|^$/i.test(String(anbieter || '')) ? 'Google' : String(anbieter).slice(0, 40));
    if (!refreshToken) throw new Error('Es kam keine Anmeldung vom Browser an.');
    if (!this.cfg.apiKey) throw new Error('In der Konfiguration fehlt der Firebase-Schluessel (cloud.apiKey).');
    const vorher = { r: this.refreshToken, u: this.localId, e: this.email };
    this.refreshToken = refreshToken;
    this.localId = uid || null;
    if (email) this.email = String(email).trim();
    this.idToken = null; this.tokenExp = 0;
    try {
      await this._refresh();                       // Probe + massgebliche Kennung
    } catch (e) {
      // Bei einem ungueltigen Token die vorherige Anmeldung nicht zerstoeren.
      this.refreshToken = vorher.r; this.localId = vorher.u; this.email = vorher.e;
      throw new Error('Die Anmeldung wurde von ' + anbName + ' nicht bestaetigt: ' + e.message);
    }
    this.abgeschaltet = false; this.abschaltGrund = null;
    this.konfigFehler = 0; this.backoffMs = 0; this.naechsterVersuch = 0;
    this.authFailAt = 0; this.lastError = null;
    this.archivAus = false; this.archivFehler = null; this.archivFehlerZahl = 0;
    this.protokollAus = false; this.protokollFehler = null; this.protokollFehlerZahl = 0;
    this.protokollEinzeln = false;
    this._zieleZuruecksetzen();
    this._gesendet = null;
    this._protokollGesendet = {};      // Begruendung wie in anmelden()
    this._kurvenSigGesendet = {};
    this.started = !!this.cfg.enabled;
    this._stationLaden();
    this.log.info('cloud', 'Praxis ueber ' + anbName + ' angemeldet: ' + (this.email || this.localId) + '. Fern-Live sendet ab sofort.');
    return this.status(true);
  }

  // Abmelden: Token verwerfen und die gespeicherte Anmeldung loeschen.
  abmelden() {
    this.idToken = null; this.refreshToken = null; this.localId = null; this.tokenExp = 0;
    this.started = false;
    try { fs.unlinkSync(this.authFile); } catch (_) { /* war nie da */ }
    this.log.info('cloud', 'Praxis abgemeldet — es wird nichts mehr ins Internet uebertragen.');
    return this.status(true);
  }

  /*
   * Wird aus dem Takt der Bridge aufgerufen.
   *   patients   = registry.getPatients()
   *   devices    = registry.getDevices()   — Status/Adresse/Sendetakt je Geraet
   *   protokoll  = registry.protokollFuerCloud()  — { patientId: [ {ts, ...}, ... ] }
   */
  publish(patients, devices, protokoll) {
    if (!this.started) return;
    if (!this.angemeldet()) return;          // ohne Praxis-Anmeldung wird nichts uebertragen
    // Die Kennung wird beim ERSTEN Takt besorgt, nicht im Konstruktor: dort waere sie auch dann
    // erzeugt worden, wenn die Fern-Uebertragung gar nicht laeuft (kein Konto, cloud.enabled=false).
    this._stationLaden();
    // Solange sie noch nicht da ist, wird der Takt NICHT verbraucht: lastPublish und inFlight
    // bleiben unberuehrt, damit der naechste Takt sofort schreiben kann statt erst nach einer
    // weiteren Drosselperiode.
    if (!this._sid()) { this._ohneKennung(); return; }
    const now = Date.now();
    if (this.inFlight) return;
    if (this.authFailAt && now - this.authFailAt < 15000) return; // Backoff
    /*
     * DER HERZSCHLAG HAT SEINEN EIGENEN TAKT (Nachbesserung N6). Gerechnet wird er in tafel.js,
     * hier wird nichts nachgerechnet. Er haengt an der Uhr und der Patientenzahl — an keiner
     * Wartezeit, keinem Fehlerkonto und keinem Messwert.
     */
    const patientenZahl = Array.isArray(patients) ? patients.length : 0;
    this._tafelSollTakt = tafel.tafelTakt(patientenZahl, {
      tafelTaktMs: this.tafelTaktMs, ruheTaktMs: this.ruheTaktMs,
    });
    const tafelFaellig = tafel.herzschlagFaellig({
      jetzt: now, letzter: this._letzterTafelTakt,
      patientenZahl: patientenZahl,
      tafelTaktMs: this.tafelTaktMs, ruheTaktMs: this.ruheTaktMs,
    });
    /*
     * DIE WERT-DROSSEL IST DIE DROSSEL DER WERTE — und nur die (Befund C3).
     *
     * Vorher oeffnete der Herzschlag den Takt und der Wert-Koerper ging bedingungslos mit: bei
     * minIntervalMs 3000 gegen tafelTaktMs 500 wurden statt der eingestellten ~2 Wertkoerper in 6 s
     * ganze 12 geschrieben — Faktor 6 gegen die Einstellung, mit der eine Praxis mit schmaler
     * Leitung im Freikontingent bleiben will. bridge/config/devices.example.json verspricht
     * ausdruecklich "_minIntervalMs: Sendetakt der VITALWERTE".
     *
     * DREI GRUENDE, DEN WERT-KOERPER AUSZULASSEN, UND JEDER GILT NUR FUER IHN:
     *   • die eingestellte Drosselung ist noch nicht abgelaufen,
     *   • die wachsende Wartezeit nach einem Wert-Fehler laeuft (naechsterVersuch),
     *   • Weg L hat sich nach drei Konfigurationsfehlern selbst abgeschaltet.
     * KEINER von ihnen darf den Herzschlag anhalten — sonst verschwindet ein laufender OP-Saal
     * von jedem anderen Bildschirm (Befund C1).
     */
    /*
     * Der Rueckweg aus der Selbstabschaltung (02.08.2026, Begruendung bei this.abschaltAm):
     * genau EIN Probeschreiben je PROBE_NACH_MS. Der Zeitstempel wird SOFORT gesetzt, nicht erst
     * nach dem Ergebnis — sonst liefe waehrend der offenen Anfrage im naechsten Takt gleich der
     * naechste Versuch, und aus "einer alle fuenf Minuten" wuerden wieder zwei je Sekunde.
     */
    let probelauf = false;
    if (this.abgeschaltet && this.started && now - this.abschaltAm >= CloudPublisher.PROBE_NACH_MS) {
      this.abschaltAm = now;
      this.probeVersuche++;
      probelauf = true;
      this.log.info('cloud', 'Fern-Live: Probeschreiben nach der Selbstabschaltung (Versuch '
        + this.probeVersuche + '). Gelingt es, laeuft die Uebertragung der Vitalwerte von selbst '
        + 'wieder an — dafuer muss niemand an den Praxis-PC.');
    }
    const werteFaellig = !this.werteInFlight
      && (!this.abgeschaltet || probelauf)
      && now >= this.naechsterVersuch
      && (now - this.lastPublish >= this.minInterval);
    if (!werteFaellig && !tafelFaellig) return;
    if (werteFaellig) this.lastPublish = now;
    this.inFlight = true;
    this._publizieren(patients || [], devices || [], protokoll || {}, now, tafelFaellig, werteFaellig)
      .catch((e) => this._fehler(e))
      .then(() => { this.inFlight = false; });
  }

  /*
   * REIHENFOLGE IST HIER SICHERHEITSRELEVANT (Befund 27.07.2026):
   * Die Anmeldung muss VOR dem Zusammenbauen des Datensatzes stehen. Vorher lief es umgekehrt —
   * beim allerersten Schreibvorgang stand die eigene Kennung (localId) also noch nicht fest, und
   * der Zielpfad /live/<kennung> waere "/live/null" gewesen. Die Regel haette das mit HTTP 401
   * abgelehnt, und drei solche Ablehnungen schalten die Uebertragung dauerhaft ab.
   *
   * DIE VIER WEGE UND IHRE REIHENFOLGE (siehe Kopf der Datei):
   *   1. Weg L — die Vitalwerte. Zuerst angestossen, aber NICHT MEHR ABGEWARTET (Befund C1).
   *   2. Weg P — das OP-Protokoll (Dokumentation, eigenes Konto, nicht abgewartet).
   *   3. Weg T — der Tafeltakt (Herzschlag), nur wenn er faellig ist.
   *   4. Weg S — der Kompatibilitaetsspiegel, im selben Takt wie die Tafel.
   * Danach das Firestore-Archiv wie bisher.
   *
   * WARUM WEG L NICHT MEHR ABGEWARTET WIRD: 'await' auf einen Schreibvorgang heisst, dass ALLES
   * dahinter von seinem Ausgang abhaengt. Eine Ablehnung fiel aus dieser Funktion heraus, und
   * Protokoll, Tafel, Spiegel und Archiv wurden im selben Takt nie erreicht — gemessen NULL
   * Herzschlaege ueber 12 s, waehrend der Saal in Wahrheit narkotisiert weiterlief. Auch eine
   * blosse Zeitueberschreitung (8 s) haette den Herzschlag 8 s lang mitgenommen. Weg L hat deshalb
   * jetzt sein eigenes .catch und seine eigene "laeuft gerade"-Marke, genau wie die anderen vier.
   */
  async _publizieren(patients, devices, protokoll, now, tafelFaellig, werteFaellig) {
    const tok = await this._ensureAuth();
    const ziel = '/live/' + this.localId + '.json?auth=' + encodeURIComponent(tok);

    /*
     * OHNE BRAUCHBARE STATIONSKENNUNG WIRD NICHTS GESCHRIEBEN. Die Kennung ist das erste
     * Pfadsegment jedes neuen Zweiges; eine unbrauchbare wuerde in einen fremden Saal schreiben
     * (Befund A1-12). _sid() laesst nur durch, was die Formpruefung von tafel.js besteht.
     */
    const sid = this._sid();
    if (!sid) { this._ohneKennung(); return; }

    // Rueckleseweg zuerst anstossen (gedrosselt, eigenes Fehlerkonto, nicht abgewartet): er
    // liefert die Antwort auf "steht ein Zwilling auf meiner Kennung?" und "schreibt hier eine
    // 1.0.3?". Beides entscheidet weiter unten, WAS ueberhaupt geschrieben werden darf.
    this._zustandLesen(tok, now);

    /*
     * HARTE SPERRE BEI NICHT AUSGESCHLOSSENER DOPPELKENNUNG (Nachbesserung N1).
     * Zwei geklonte Stationen mit derselben Kennung wuerden unter saele/<sid>/patients/<key> zwei
     * Narkosen Feld fuer Feld vermischen — bei zwei 22-kg-Hunden beide unter sw_hund_22. Solange
     * das nicht ausgeschlossen ist, geht NUR der Kopf tafel/<sid>/meta raus: der Saal bleibt
     * sichtbar und meldet den Konflikt, aber es wandert kein Patientendatum in den Baum.
     */
    const darf = this.stationsid.darfPatientendatenSchreiben();
    /*
     * ZWEI UHREN, UND SIE DUERFEN SICH NICHT MISCHEN.
     *
     *   now  = die Uhr DIESES PCs. Sie gehoert zu allem, was auf diesem PC entstanden ist:
     *          p.ts (Zeitpunkt des Geraetepakets) und g.lastTs. Das Alter einer Kachel ist eine
     *          DAUER, und eine Dauer darf nur aus EINER Uhr gerechnet werden.
     *   jetzt = dieselbe Uhr, korrigiert um den Versatz zur Datenbank (_jetzt). Sie gehoert zu
     *          allem, was aus dem Kontobaum kommt: sv setzt der Server selbst, und die qs-Kinder
     *          der Nachbarn ebenso.
     *
     * WAS PASSIERT, WENN MAN SIE VERTAUSCHT: geht der PC fuenf Minuten nach, waere
     * (Serverzeit - lokales p.ts) um fuenf Minuten zu gross — jede Kachel dieses gesunden Saals
     * kaeme als "vor 5 min" an, und der Leser ersetzte ihre Zahlen durch "Stand vor X min". In der
     * anderen Richtung (lokale Uhr gegen fremde sv) haelt die Station jeden Nachbarn fuer "aus der
     * Zukunft" und sich selbst fuer allein im Konto. Beides ist nachgemessen und steht in tafel.js.
     */
    const jetzt = this._jetzt();
    const snapshot = this._buildSnapshot(patients, devices);
    /*
     * DER TAFELTAKT IST DER HERZSCHLAG (Nachbesserung N6): er laeuft, auch wenn sich an den Werten
     * nichts aendert, und er wird VOR jeder Sparregel entschieden — in publish(), noch vor der
     * Drossel des Wert-Taktes. Die fruehere Sparregel hing an der literalen Zeichenkette 'meta/ts';
     * sie traegt fuer den neuen Zweig nicht und ist ersatzlos entfallen.
     */

    if (darf) {
      // Neue Protokolleintraege heraussuchen, BEVOR ueber "nichts zu tun" entschieden wird.
      const protPfade = this._protokollPfade(protokoll);

      /*
       * DER WERT-KOERPER GEHT NUR IM WERT-TAKT (Befund C3). Ist dieser Takt nur wegen des
       * Herzschlags offen, wird hier NICHTS gerechnet und NICHTS geschrieben — sonst bekaeme eine
       * Praxis, die ihre Werte ausdruecklich langsamer gestellt hat, ein Vielfaches der Datenmenge
       * ueber die Leitung, mit der sie im Freikontingent bleiben will.
       */
      if (werteFaellig) {
        // Vollbild, wenn noch nie geschrieben wurde oder das Sicherheitsintervall abgelaufen ist.
        // Das Sicherheits-Vollbild raeumt Reste auf, falls ein PATCH je verloren ging.
        const vollbild = this._vollbildErzwingen || !this._gesendet
          || (now - this._letztesVollbild >= this.vollbildMs);
        const wurzel = 'saele/' + sid + '/patients/';
        const neu = this._pfade(snapshot, sid);
        const plan = this._delta(neu, this._gesendet, wurzel,
          new Set(Object.keys(snapshot.patients || {})), vollbild, this._saalAltbestand);
        const kurvenOffen = this._kurvenOffen;

        /*
         * "Nichts zu tun" fragt NUR die Vitalwerte. Das Protokoll geht seinen eigenen Weg und wird
         * deshalb unten auch dann geschrieben, wenn sich an den Werten nichts geaendert hat; der
         * Herzschlag liegt in Weg T und haengt an gar keinem Wert mehr.
         */
        if (Object.keys(plan).length) {
          /*
           * EIGENES .catch STATT await (Befund C1). Was hier schiefgeht, gehoert Weg L allein:
           * _fehler() fuehrt sein Konto (lastError, Wartezeit, konfigFehler, Selbstabschaltung).
           * Tafel, Spiegel, Protokoll und Archiv laufen im selben Takt weiter — sie stehen unten
           * und werden jetzt auch dann erreicht, wenn dieser Schreibvorgang abgelehnt wird.
           */
          this.werteInFlight = true;
          this._write('PATCH', ziel, plan)
            .then(() => {
              if (this.lastError) this.log.info('cloud', 'Fern-Live schreibt wieder.');
              /* Ein gelungener Schreibvorgang hebt die Selbstabschaltung auf — das ist der
               * Rueckweg, den es bis 1.2.3 nicht gab (Begruendung bei this.abschaltAm). */
              if (this.abgeschaltet) {
                this.abgeschaltet = false; this.abschaltGrund = null; this.probeVersuche = 0;
                this.log.info('cloud', 'FERN-LIVE LAEUFT WIEDER: das Probeschreiben ist gelungen, '
                  + 'die Vitalwerte gehen ab sofort wieder in die Fern-Ansicht. Es war also eine '
                  + 'voruebergehende Stoerung, kein Einrichtungsfehler.');
              }
              this.lastError = null; this.backoffMs = 0; this.naechsterVersuch = 0; this.konfigFehler = 0;
              this._gesendet = this._alsStand(neu);
              this._vollbildErzwingen = false;
              this._saalAltbestand = null;      // der Altbestand ist mit diesem Koerper aufgeraeumt
              this._letzterSchreibvorgang = now;
              this.sq++;
              /*
               * ERST JETZT gelten die Kurvenstreifen dieses Koerpers als uebertragen. Wurden sie
               * schon beim Bauen des Snapshots vermerkt, war ein Streifen nach einem einzigen
               * fehlgeschlagenen Schreibvorgang fuer immer weg: die Signatur galt als erledigt,
               * der Streifen lag nirgends, und fern blieb die EKG-Kurve leer, bis sich die
               * Signatur zufaellig wieder aenderte.
               */
              Object.keys(kurvenOffen).forEach((k) => { this._kurvenSigGesendet[k] = kurvenOffen[k]; });
              if (vollbild) this._letztesVollbild = now;
            })
            .catch((e) => this._fehler(e))
            .then(() => { this.werteInFlight = false; });
        }
      }

      this._protokollSchreiben(protPfade, tok, sid);
    } else {
      /*
       * Waehrend der Sperre wird der Saalzweig nicht angefasst — auch nicht geloescht: liegt dort
       * wirklich ein Zwilling, waere ein null seine Kachel.
       *
       * NACH der Sperre wird ein VOLLBILD geschrieben statt eines Deltas: der Zwilling koennte
       * einzelne Felder ueberschrieben haben, und ein Delta wuerde sie nie wieder richtigstellen.
       * Das GEDAECHTNIS bleibt dabei ausdruecklich stehen (frueher wurde es weggeworfen): ein
       * Vollbild schreibt alle eigenen Pfade ohnehin neu, aber nur MIT dem alten Gedaechtnis kann
       * es auch die Pfade loeschen, die es inzwischen nicht mehr gibt. Ohne diese Loeschungen
       * bliebe die Kachel eines waehrend der Sperre abgehaengten Patienten mit eingefrorenem altMs
       * stehen — dieselbe Karteileiche wie in N7 (und derselbe Fehler wie C2 beim Spiegel).
       */
      this._vollbildErzwingen = true;
      this._spiegelVollbildErzwingen = true;
    }

    if (tafelFaellig) {
      this._letzterTafelTakt = now;
      // Tafel: LOKALE Uhr (die Alter darin sind Dauern aus lokalen Zeitstempeln).
      this._tafelSchreiben({ patients: patients, devices: devices, jetzt: now, ziel: ziel, sid: sid, darf: darf });
      // Spiegel: SERVERZEIT (modusAus vergleicht gegen fremde sv- und qs-Werte).
      this._spiegelSchreiben({ snapshot: snapshot, jetzt: jetzt, now: now, ziel: ziel, sid: sid, darf: darf });
    }

    if (darf) await this._archivieren(snapshot, now, tok);
  }

  /*
   * Einmal sagen, nicht in jedem Takt: ohne Kennung passiert gar nichts, und wer das Log liest,
   * soll den Grund finden statt eine schweigende Station zu sehen.
   */
  _ohneKennung() {
    if (this._ohneKennungGemeldet) return;
    this._ohneKennungGemeldet = true;
    this.log.warn('cloud', 'Die Stationskennung steht noch nicht fest — bis dahin wird nichts in die '
      + 'Fern-Ansicht geschrieben. Sie wird beim Start aus data/station-id.json gelesen oder neu '
      + 'abgeleitet; das dauert ueblicherweise weniger als eine Sekunde.');
  }

  /* Die eigene Kennung, IMMER durch die Formpruefung. Ein Wert, der sie nicht besteht, darf nie in
   * einen Datenbankpfad geraten — new URL() loest '..' auf, im Kontobaum waere das ein fremder Saal. */
  _sid() {
    const s = this.stationsid ? this.stationsid.sid() : null;
    return (typeof s === 'string' && tafel.pruefeSid(s)) ? s : null;
  }

  // Serverzeit (PC-Uhr + gemessener Versatz aus der HTTP-Date-Kopfzeile). ALLE Frischevergleiche
  // der Tafel rechnen damit — Begruendung im Konstruktor bei _serverVersatz.
  _jetzt() { return Date.now() + this._serverVersatz; }

  /*
   * Die Stationskennung selbst besorgen, wenn der Aufrufer keine uebergeben hat.
   * Laeuft genau einmal und nebenher: laden() liest eine Datei oder fragt die Windows-Geraete-ID ab
   * und wirft laut Zusage nie. Bis sie da ist, schreibt diese Datei nichts (siehe _ohneKennung).
   */
  _stationLaden() {
    if (this.stationsid || this._stationLaedt) return;
    this._stationLaedt = true;
    let st = null;
    try {
      const opt = { log: this.log };
      if (this.cfg.stationDatei) opt.datei = this.cfg.stationDatei;
      st = new stationsidModul.Stationsid(opt);
    } catch (e) {
      this.log.error('cloud', 'Die Stationskennung liess sich nicht anlegen (' + e.message
        + ') — die Fern-Uebertragung bleibt aus, die Anzeige vor Ort ist nicht betroffen.');
      return;
    }
    Promise.resolve()
      .then(() => st.laden())
      .then(() => { this.stationsid = st; })
      .catch((e) => {
        this.log.error('cloud', 'Die Stationskennung konnte nicht geladen werden (' + e.message + ').');
        this._stationLaedt = false;       // beim naechsten Takt noch einmal versuchen
      });
  }

  // Alle Ziele ausser dem Archiv/Protokoll (die haben ihre eigenen Zeilen) auf Anfang.
  _zieleZuruecksetzen() {
    this.tafelFehler = null; this.tafelFehlerZahl = 0; this.tafelBackoffMs = 0; this.tafelNaechster = 0;
    this.spiegelAus = false; this.spiegelFehler = null; this.spiegelFehlerZahl = 0;
    this.spiegelBackoffMs = 0; this.spiegelNaechster = 0;
    this._spiegelGesendet = null; this._tafelStand = null; this._letzterSpiegelVollbild = 0;
    this._spiegelVollbildErzwingen = false; this._vollbildErzwingen = false;
    this._flachGelesen = false; this._tafelGelesen = false; this._tafelEintraege = {};
    this._flachMeta = null; this._fremdSeit = null; this._qsGeschrieben = false;
    this._flachGelesenAm = 0; this._qsGeschriebenAm = 0;
    this._altbestandGeholt = false; this._altbestandVersuche = 0; this._altbestandLaeuft = false;
    this._saalAltbestand = null; this._spiegelAltbestand = null;
    this._letzterTafelTakt = null; this._letzterTafelErfolg = 0;
    this._kurvenOffen = {};
  }

  /*
   * SCHLAEGT DAS HERZ DIESES SAALS WIRKLICH? — die Messung hinter status().tafel.aktiv.
   *
   * Die Frage ist nicht "ist die Tafel eingeschaltet" (sie ist immer eingeschaltet, sie schaltet
   * sich nie ab), sondern "ist im letzten erwarteten Takt wirklich ein Herzschlag in der Datenbank
   * angekommen". Nur diese Frage hat einen Wert: solange sie mit Ja beantwortet ist, sieht jeder
   * andere Bildschirm im Haus, DASS es diesen Saal gibt.
   *
   * DREI GRUENDE FUER NEIN, und jeder ist einer, den ein Mensch wissen muss:
   *   • es wird ueberhaupt nicht gesendet (nicht gestartet, nicht angemeldet),
   *   • der letzte Tafel-Schreibvorgang wurde abgelehnt (tafelFehler steht),
   *   • es kam laenger nichts durch, als der geltende Takt erlaubt — auch dann, wenn niemand einen
   *     Fehler gemeldet hat. Genau dieser Fall war Befund C1: ein Fehler auf dem WERT-Weg hielt den
   *     ganzen Takt an, tafelFehler blieb null, und das Feld meldete trotzdem "in Ordnung".
   *
   * DREI TAKTE TOLERANZ, nicht einer: ein einzelner verlorener Takt (Wartezeit nach einem Fehler,
   * ein langsamer Vorgang) soll das Feld nicht flattern lassen. Der Leser der Tafel meldet einen
   * Saal erst nach STUFE_OFFLINE_MS (60 s) als offline — drei Takte sind bei jedem eingestellten
   * Takt deutlich frueher als das, die Anzeige ist also nie zu spaet dran.
   */
  _tafelSchlaegt() {
    if (!this.started || !this.angemeldet()) return false;
    if (this.tafelFehler) return false;
    // Noch nie ein Herzschlag faellig gewesen (oder er ist gerade unterwegs): es gibt nichts zu
    // beanstanden. Ein 'false' waere hier eine Falschmeldung beim Anlauf.
    if (!this._letzterTafelErfolg) return true;
    return (Date.now() - this._letzterTafelErfolg) <= (this._tafelSollTakt || this.tafelTaktMs) * 3;
  }

  /*
   * DAS OP-PROTOKOLL IN EINEM EIGENEN SCHREIBVORGANG.
   *
   * Absichtlich nicht abgewartet (wie _archivieren): die Dokumentation darf den naechsten Wert-Takt
   * nicht verzoegern. Fehler bleiben in protokollFehler/protokollFehlerZahl und beruehren weder
   * konfigFehler noch idToken noch die Delta-Buchhaltung — eine Station soll wegen einer
   * Protokollzeile nie ihre Vitaluebertragung verlieren.
   */
  _protokollSchreiben(protPfade, tok, sid) {
    if (this.protokollAus || this.protokollInFlight) return;
    const alle = Object.keys(protPfade);
    if (!alle.length) return;
    if (this.protokollEinzeln) return this._protokollEinzelweise(protPfade, tok, sid);

    /*
     * Hoechstens 50 Zeilen je Schreibvorgang. Nach einer laengeren Leitungsstoerung kaemen sonst
     * mehrere hundert Pfade in einem Koerper — und weil der PATCH atomar ist, wuerde ein einziger
     * strittiger Pfad alle anderen mitnehmen. Der Rest folgt im naechsten Takt.
     */
    const genommen = alle.slice(0, 50);
    const teil = {};
    genommen.forEach((p) => {
      this._protokollZiele(p, sid).forEach((z) => { teil[z] = protPfade[p]; });
    });
    const ziel = '/live/' + this.localId + '.json?auth=' + encodeURIComponent(tok);
    this.protokollInFlight = true;
    this._write('PATCH', ziel, teil)
      .then(() => {
        if (this.protokollFehler) this.log.info('cloud', 'OP-Protokoll wird wieder uebertragen.');
        this.protokollFehler = null; this.protokollFehlerZahl = 0;
        this._protokollMerken(genommen);
      })
      .catch((e) => {
        const msg = e && e.message ? e.message : String(e);
        this.protokollFehler = msg;
        /*
         * Eine Ablehnung auf einem Protokollpfad kann zwei Ursachen haben, und sie duerfen nicht
         * verwechselt werden: die Zeile liegt schon dort (Unveraenderlichkeits-Regel, harmlos)
         * ODER die Anmeldung stimmt nicht (ernst). Statt zu RATEN wird nachgesehen: ein flacher
         * Blick in die Datenbank sagt, welche Zeitpunkte wirklich schon vorhanden sind. Nur die
         * werden als erledigt vermerkt. Ohne diese Unterscheidung wuerde ein echtes
         * Anmeldeproblem stillschweigend Protokollzeilen verschlucken.
         *
         * Die Bedingung ist ABSICHTLICH eng: nur eine Antwort, die die Regelablehnung auch
         * benennt. Ein blankes HTTP 401 ohne diesen Text ist ein Anmeldeproblem, und dann waere
         * ein Abgleich sinnlos (er scheitert am selben Token) und irrefuehrend.
         */
        if (/Permission denied|PERMISSION_DENIED/i.test(msg)) {
          this._protokollAbgleich(genommen, tok, sid);
          /*
           * UND: ab jetzt Zeile fuer Zeile schreiben. Der Grund ist nicht Sparsamkeit, sondern
           * Zuordenbarkeit — die Datenbank sagt bei einem Mehrpfad-PATCH NICHT, welcher Pfad
           * abgelehnt wurde. Eine einzige strittige Zeile blockiert damit alle anderen im selben
           * Koerper, und keiner kann sagen, welche es war. Einzelne Schreibvorgaenge machen jede
           * Antwort eindeutig: die strittige faellt durch, die uebrigen kommen an. Der Normalfall
           * bleibt der eine gebuendelte Schreibvorgang — einzeln wird nur nach einem Streitfall.
           */
          this.protokollEinzeln = true;
        }
        this.protokollFehlerZahl++;
        if (CloudPublisher._istKonfigFehler(msg) && this.protokollFehlerZahl >= 3) {
          this.protokollAus = true;
          this.log.warn('cloud', 'Uebertragung des OP-Protokolls abgeschaltet: ' + msg +
            ' — die Vitalwerte laufen davon unberuehrt weiter, und der lokale Ausdruck ist ' +
            'vollstaendig. Nach dem Beheben der Ursache neu anmelden oder neu starten.');
        }
      })
      .then(() => { this.protokollInFlight = false; });
  }

  /*
   * Jede Zeile fuer sich, hoechstens ein paar je Takt. Wird erst benutzt, nachdem ein gebuendelter
   * Schreibvorgang an einer Regel gescheitert ist (siehe protokollEinzeln oben). Jede Antwort
   * gehoert dann zu genau einer Zeile, und eine strittige nimmt keine gesunde mit.
   */
  _protokollEinzelweise(protPfade, tok, sid) {
    const alle = Object.keys(protPfade).slice(0, 8);
    if (!alle.length) return;
    this.protokollInFlight = true;
    /*
     * Je Zeile ein Schreibvorgang JE ZIEL. In F2-solo sind das zwei (Saalzweig und flacher
     * Spiegel) — sie muessen getrennt gehen, denn genau das ist der Sinn des Einzelweges: jede
     * Antwort gehoert zu genau einem Pfad. Vermerkt wird die Zeile am SAALZWEIG; er ist das
     * fuehrende Ziel, der flache Spiegel ist die Zugabe fuer die alte Web-App.
     */
    const auftraege = [];
    alle.forEach((pfad) => {
      this._protokollZiele(pfad, sid).forEach((z, i) => auftraege.push({ logisch: pfad, ziel: z, fuehrend: i === 0 }));
    });
    let offen = auftraege.length, streit = 0;
    const fertig = () => {
      if (--offen > 0) return;
      this.protokollInFlight = false;
      // Ging alles durch, wieder buendeln — der Streitfall war offenbar erledigt.
      if (!streit) {
        this.protokollEinzeln = false;
        if (this.protokollFehler) this.log.info('cloud', 'OP-Protokoll wird wieder uebertragen.');
        this.protokollFehler = null; this.protokollFehlerZahl = 0;
      }
    };
    auftraege.forEach((a) => {
      const pfad = a.logisch;
      const ziel = '/live/' + this.localId + '/' + a.ziel + '.json?auth=' + encodeURIComponent(tok);
      this._write('PUT', ziel, protPfade[pfad])
        .then(() => { if (a.fuehrend) this._protokollMerken([pfad]); })
        .catch((e) => {
          const msg = e && e.message ? e.message : String(e);
          streit++;
          this.protokollFehler = msg;
          if (/Permission denied|PERMISSION_DENIED/i.test(msg)) {
            /*
             * HIER STAND EINE ANNAHME, UND SIE WAR FALSCH (behoben 31.07.2026).
             *
             * Der Satz lautete: "Jetzt ist es eindeutig — die Zeile liegt schon dort." Eindeutig
             * ist daran gar nichts. Dieselbe Antwort "Permission denied" kommt auch, wenn die
             * Anmeldung nicht mehr gilt. Die Zeile wurde dann als erledigt vermerkt, obwohl sie
             * nie angekommen ist — und weil Protokollzeilen per Regel unveraenderlich sind und
             * nie wieder angeboten werden, fehlte sie im Narkoseprotokoll fuer immer. Lautlos.
             *
             * Der gebuendelte Weg ein paar Zeilen weiter oben macht es seit dem 30.07. richtig:
             * er SIEHT NACH, statt zu raten. Der Einzelweg tut das jetzt auch. Bestaetigt wird
             * nur, was die Datenbank wirklich vorweist; alles andere bleibt offen und wird im
             * naechsten Takt erneut versucht.
             */
            this._protokollAbgleich([pfad], tok, sid);
            /*
             * Und mitzaehlen. Sonst drehte sich der Einzelweg bei einem echten Anmeldeproblem
             * endlos im Kreis: ablehnen, nicht vermerkt, erneut anbieten — ohne dass je jemand
             * etwas davon erfaehrt. Nach drei nicht selbstheilenden Fehlern schaltet sich die
             * Protokolluebertragung ab und sagt das; die Vitalwerte laufen davon unberuehrt weiter.
             */
            this.protokollFehlerZahl++;
            if (this.protokollFehlerZahl >= 3) {
              this.protokollAus = true;
              this.log.warn('cloud', 'Uebertragung des OP-Protokolls abgeschaltet: ' + msg +
                ' — die Zeilen liessen sich weder schreiben noch als bereits vorhanden bestaetigen. '
                + 'Die Vitalwerte laufen davon unberuehrt weiter, und der lokale Ausdruck ist '
                + 'vollstaendig. Nach dem Beheben der Ursache neu anmelden oder neu starten.');
            }
          } else {
            this.protokollFehlerZahl++;
            if (CloudPublisher._istKonfigFehler(msg) && this.protokollFehlerZahl >= 3) {
              this.protokollAus = true;
              this.log.warn('cloud', 'Uebertragung des OP-Protokolls abgeschaltet: ' + msg +
                ' — die Vitalwerte laufen davon unberuehrt weiter, und der lokale Ausdruck ist '
                + 'vollstaendig.');
            }
          }
        })
        .then(fertig);
    });
  }

  /*
   * Flacher Blick in die Datenbank: welche Protokoll-Zeitpunkte liegen dort wirklich schon?
   * shallow=true liefert nur die Schluessel, nicht die Inhalte — ein paar hundert Byte je Patient.
   * Hoechstens einmal je Minute, damit daraus bei dauerhafter Ablehnung keine Abfrageschleife wird.
   */
  _protokollAbgleich(logische, tok, sid) {
    const now = Date.now();
    if (now - this._letzterAbgleich < 60000) return;
    this._letzterAbgleich = now;
    if (!tafel.pruefeSid(String(sid || ''))) return;
    const keys = {};
    (logische || []).forEach((p) => {
      const m = /^protokoll\/([^/]+)\//.exec(p);
      if (m) keys[m[1]] = 1;
    });
    Object.keys(keys).forEach((key) => {
      // Nachgesehen wird im SAALZWEIG — dort liegt das fuehrende Protokoll. Die flache Ebene
      // traegt in F2-multi gar keine Zeilen mehr, sie kann die Frage also nicht beantworten.
      const url = this.cfg.dbUrl.replace(/\/+$/, '') + '/live/' + this.localId + '/saele/'
        + encodeURIComponent(sid) + '/protokoll/'
        + key + '.json?shallow=true&auth=' + encodeURIComponent(tok);
      this._reqJson('GET', url, null, null)
        .then((vorhanden) => {
          if (!vorhanden || typeof vorhanden !== 'object') return;
          const gesendet = this._protokollGesendet[key] || (this._protokollGesendet[key] = {});
          let n = 0;
          Object.keys(vorhanden).forEach((ts) => { if (!gesendet[ts]) { gesendet[ts] = 1; n++; } });
          if (n) this.log.info('cloud', n + ' Protokollzeile(n) lagen bereits in der Datenbank — '
            + 'sie werden nicht erneut gesendet.');
        })
        .catch(() => { /* dann bleibt es beim naechsten Versuch — kein Grund fuer eine Meldung */ });
    });
  }

  /*
   * Neue Protokolleintraege als EINZELNE tiefe Pfade.
   *
   * WARUM NICHT ALS LISTE: _pfade() flacht je Patient nur eine Ebene ab. Ein Feld
   * "protokoll: [ ... ]" wuerde deshalb bei JEDEM neuen Eintrag die KOMPLETTE Liste erneut
   * uebertragen — bei 1200 Eintraegen also jedes Mal ein paar hundert Kilobyte. Als einzelne
   * Pfade protokoll/<patient>/<zeitpunkt> geht dagegen nur der neue Eintrag ueber die Leitung,
   * und die Regel kann ihn zugleich unveraenderlich machen (".validate": "!data.exists()").
   */
  _protokollPfade(protokoll) {
    const out = {};
    if (!protokoll) return out;
    let alt = 0;
    const gesehen = {};        /* welche Kennungen kamen in dieser Runde ueberhaupt vor */
    for (const pid in protokoll) {
      const key = sanitizeKey(pid);
      gesehen[key] = 1;
      const gesendet = this._protokollGesendet[key] || (this._protokollGesendet[key] = {});
      const liste = protokoll[pid] || [];
      const nachtrag = !!this._protokollNachtrag[key];
      let offenHier = 0;
      for (const e of liste) {
        if (!e || e.ts == null) continue;
        const ts = String(e.ts);
        if (gesendet[ts]) continue;
        /*
         * Zeilen von VOR diesem Prozess nicht erneut anbieten (Begruendung bei prozessStart im
         * Konstruktor). Einmalig als erledigt vermerken, damit sie auch in den folgenden Takten
         * nicht wieder auftauchen — die Protokolldatei wird beim Laden ja nicht kuerzer.
         *
         * AUSNAHME seit 21.08.2026: wurde fuer diesen Patienten ein Nachtrag angefordert (die
         * Station hat gerade ein Protokoll erzeugt oder gedruckt), gehen auch die aelteren
         * Zeilen mit. Begruendung bei _protokollNachtrag im Konstruktor.
         */
        if (!nachtrag && Number(e.ts) < this.prozessStart) { gesendet[ts] = 1; alt++; continue; }
        out['protokoll/' + key + '/' + ts] = e;
        offenHier++;
      }
      /*
       * Der Nachtrag loescht sich selbst, sobald fuer diesen Patienten nichts Offenes mehr
       * uebrig ist. Ohne diese Zeile bliebe die Ausnahme dauerhaft stehen — und nach jedem
       * Neustart wuerde der ganze Bestand wieder angeboten, also genau der Zustand, gegen den
       * der Stempel gebaut ist.
       */
      if (nachtrag && !offenHier) {
        delete this._protokollNachtrag[key];
        this.protokollNachtragLaeuft = Math.max(0, this.protokollNachtragLaeuft - 1);
        this.log.info('cloud', 'Protokoll-Nachtrag fuer "' + key + '" abgeschlossen — der '
          + 'gefuehrte Verlauf dieses Patienten steht jetzt vollstaendig in der Fern-Ansicht '
          + 'und laesst sich dort ausdrucken.');
      }
    }
    /*
     * EIN NACHTRAG FUER EINE KENNUNG, DIE ES NICHT GIBT, MUSS SICH TROTZDEM BEENDEN.
     *
     * Die Selbstloeschung weiter oben sitzt INNERHALB der Schleife ueber protokoll. Meldet die
     * Oberflaeche einen Ausdruck fuer eine Kennung, zu der die Registry keine einzige Zeile
     * fuehrt (Protokoll aus dem 30-Tage-Bestand, Kennung inzwischen umbenannt, Tippfehler), lief
     * die Schleife an ihr vorbei — die Fahne blieb stehen und protokollNachtragLaeuft kam nie
     * zurueck auf null. Der Admin-Bereich haette dauerhaft einen laufenden Nachtrag gemeldet,
     * und der Stempel waere fuer diese Kennung dauerhaft aufgehoben geblieben.
     */
    Object.keys(this._protokollNachtrag).forEach((k) => {
      if (gesehen[k]) return;
      delete this._protokollNachtrag[k];
      this.protokollNachtragLaeuft = Math.max(0, this.protokollNachtragLaeuft - 1);
      this.log.info('cloud', 'Protokoll-Nachtrag fuer "' + k + '" beendet — zu dieser Kennung '
        + 'fuehrt die Station keine Protokollzeile. Der lokale Ausdruck ist davon unberuehrt.');
    });
    if (alt && !this._altzeilenGemeldet) {
      this._altzeilenGemeldet = true;
      this._altzeilenUebersprungen = alt;
      // EINMAL sagen, nicht in jedem Takt. Wer das Log liest, soll wissen, dass hier bewusst
      // nichts nachgesendet wurde — und nicht raten muessen, wo die Zeilen geblieben sind.
      this.log.info('cloud', alt + ' Protokollzeile(n) aus der Zeit vor diesem Programmstart '
        + 'werden nicht erneut gesendet — sie stehen in der Fern-Ansicht schon. '
        + 'Der lokale Ausdruck enthaelt sie unveraendert.');
    }
    return out;
  }

  /*
   * Die ZIELE einer Protokollzeile. Der logische Pfad ist unveraendert 'protokoll/<pid>/<ts>' —
   * daran haengt die Merkliste, und nur deshalb kostet eine Zeile mit zwei Zielen auch nur EINEN
   * Eintrag im Gedaechtnis.
   *   saele/<sid>/protokoll/<pid>/<ts>   IMMER. Das ist ab 1.1.0 das fuehrende Protokoll.
   *   protokoll/<pid>/<ts>               NUR in F2-solo. In F2-multi wuerden sich die Zeilen
   *                                      mehrerer Saele auf der flachen Ebene unter derselben
   *                                      Patienten-ID mischen — zwei 22-kg-Hunde ergeben denselben
   *                                      Ersatzschluessel, und das Ergebnis waere ein Protokoll,
   *                                      das zwei Tiere zu einem macht. In F1 schreibt eine 1.0.3
   *                                      die flache Ebene selbst; dort haben wir nichts zu suchen.
   */
  _protokollZiele(logisch, sid) {
    const out = [];
    if (tafel.pruefeSid(String(sid || ''))) out.push('saele/' + sid + '/' + logisch);
    if (this._darfFlachProtokoll()) out.push(logisch);
    return out;
  }
  _darfFlachProtokoll() { return this.spiegel && !this.spiegelAus && this._modus === 'F2-solo'; }

  /* ================================================================================
   * EIN ERZEUGTES PROTOKOLL GEHOERT SOFORT UND VOLLSTAENDIG IN DIE FERN-ANSICHT
   * ================================================================================
   * (Wunsch aus der Praxis, 21.08.2026. Wortlaut: "wenn in Vetstation ein Protokoll
   * gespeichert oder ausgedruckt oder erstellt wird, muss es direkt auch in der Web-App
   * ankommen, damit man es ueberall ausdrucken kann.")
   *
   * ZWEI GETRENNTE DINGE, absichtlich in zwei Methoden:
   *
   *   protokollNachtragen(pid)  sorgt dafuer, dass die ZEILEN vollstaendig drueben sind —
   *                             auch die von vor einem Neustart der Station.
   *   ausdruckVermerken(rec)    hinterlaesst die NACHRICHT, dass hier gerade ein Dokument
   *                             entstanden ist: wann, fuer wen, aus welchem Saal, wie viele
   *                             Zeilen. Erst dadurch kann die Fern-Ansicht sagen "Ausdruck
   *                             vom 21.08. 14:07 aus Saal 2" statt nur Zeilen zu zeigen.
   *
   * WARUM NICHT DAS PDF SELBST UEBERTRAGEN WIRD: die Datenbankregeln begrenzen jede
   * Zeichenkette unter einem Saal auf 12000 Zeichen (firebase-rtdb-rules.json, Auffangkette).
   * Ein base64-kodiertes Narkoseprotokoll ist ein Vielfaches davon und wuerde ABGEWIESEN —
   * und zwar still, weil der Schreibvorgang sein eigenes Fehlerkonto hat. Die Web-App setzt
   * das Blatt deshalb aus denselben Zeilen selbst; sie tut das ohnehin schon (drucke() im
   * Fern-Modul). Uebertragen wird, was das Blatt braucht, nicht das fertige Blatt.
   */
  /* Fuer server.js: laeuft fuer DIESEN Patienten gerade ein Nachtrag? Die Sanitisierung bleibt
   * damit hier, wo sie hingehoert — die Registry kennt nur rohe Kennungen und soll das auch. */
  istNachtrag(pid) { return !!this._protokollNachtrag[sanitizeKey(pid)]; }

  protokollNachtragen(pid) {
    const key = sanitizeKey(pid);
    if (!key || key === '_') return false;
    /*
     * EHRLICHE ANTWORT, WENN DIE FERN-UEBERTRAGUNG GAR NICHT LAEUFT (21.08.2026).
     * Vorher gab diese Methode auch dann true zurueck, wenn die Station nicht angemeldet oder
     * die Uebertragung abgeschaltet war. Der Aufrufer meldete daraufhin dem Praxis-PC Erfolg,
     * und der Tierarzt ging davon aus, sein Protokoll liege fern zum Ausdrucken bereit — es lag
     * nirgends. Der lokale Ausdruck ist davon unberuehrt und vollstaendig; genau das sagt die
     * Meldung im Log jetzt auch.
     */
    if (!this.started || this.abgeschaltet || this.protokollAus || !this.localId) return false;
    if (this._protokollNachtrag[key]) return true;      /* laeuft schon */
    this._protokollNachtrag[key] = true;
    this.protokollNachtragLaeuft++;
    /* Die bereits als "erledigt" vermerkten Altzeilen wieder oeffnen — sonst greift der
     * Nachtrag genau bei den Zeilen nicht, fuer die er gedacht ist. Was wirklich schon in der
     * Datenbank liegt, bestaetigt _protokollAbgleich beim ersten Widerspruch. */
    delete this._protokollGesendet[key];
    this.log.info('cloud', 'Protokoll-Nachtrag angefordert fuer "' + key + '" — der vollstaendige '
      + 'Verlauf wird in die Fern-Ansicht uebertragen, damit er dort gedruckt werden kann.');
    return true;
  }

  /*
   * DER PARAMETER HEISST vermerk UND NICHT rec — und das ist kein Geschmack.
   *
   * tools/vollauslesung-test.js zaehlt in dieser Datei die Vorkommen des Feldzugriffs, mit dem
   * der TIERNAME gesetzt wird, und verlangt GENAU EINEN. Dahinter steht eine Datenschutzzusage:
   * der Klarname darf an einer einzigen Stelle in den Datenstrom geraten, und die muss unter
   * dem Stammdaten-Schalter liegen. Ein zweiter Traeger mit demselben Namen haette den Waechter
   * entwertet, obwohl der Schalter hier eingehalten ist (siehe unten) — der Test kann die
   * beiden nicht auseinanderhalten. Lieber weicht der Variablenname aus als die Pruefung.
   *
   * UND DIESER KOMMENTAR SCHREIBT DEN AUSDRUCK DESHALB AUCH NICHT AUS. Quellpruefungen in
   * diesem Projekt lesen Kommentare mit; beim ersten Versuch stand er hier woertlich, und der
   * Test blieb rot, obwohl der Code stimmte (CLAUDE.md nennt genau diese Falle).
   */
  ausdruckVermerken(vermerk) {
    if (!this.started || this.abgeschaltet || !this.localId) return false;
    const sid = this._sid();
    if (!sid) return false;
    const pid = sanitizeKey((vermerk && vermerk.patientId) || '');
    if (!pid || pid === '_') return false;
    /*
     * WARTESCHLANGE STATT WEGWERFEN (21.08.2026).
     *
     * Hier stand `if (this.ausdruckInFlight) return false;` — beim Sammelausdruck ("Alle
     * Patienten") schickt die Oberflaeche aber EINEN Vermerk JE PATIENT, und zwar in derselben
     * Schleife. Der erste ging los, alle uebrigen fielen wortlos heraus, und das ack meldete
     * trotzdem Erfolg. Fern sah man dann einen einzigen Ausdruck-Vermerk fuer einen Stapel von
     * acht Protokollen.
     *
     * Der Deckel ist bewusst niedrig: mehr als ein paar Ausdrucke in Folge gibt es nicht, und
     * eine unbegrenzte Schlange waere bei dauerhaft gestoerter Leitung ein Speicherleck.
     */
    const ts = Number(vermerk && vermerk.ts) || Date.now();
    const koerper = {
      ts: ts,
      art: CloudPublisher._kurz((vermerk && vermerk.art) || 'erstellt', 40),
      patientId: CloudPublisher._kurz((vermerk && vermerk.patientId) || '', 200),
      /* Der Tiername folgt derselben Regel wie ueberall sonst: nur, wenn Stammdaten gesendet
       * werden duerfen. Sonst stuende er in der Datenbank, waehrend die Vitalwerte daneben
       * ausdruecklich anonym sind — das waere die Luecke, die der Schalter schliessen soll. */
      patientName: this.sendeStammdaten ? CloudPublisher._kurz((vermerk && vermerk.patientName) || '', 200) : '',
      zeilen: Number(vermerk && vermerk.zeilen) || 0,
      gaben: Number(vermerk && vermerk.gaben) || 0,
      datei: CloudPublisher._kurz((vermerk && vermerk.datei) || '', 200),
      station: CloudPublisher._kurz(this._stationText(), 120),
      sid: String(sid),
      version: appVersion(),
    };
    /*
     * EIGENER Schreibvorgang mit EIGENEM Fehlerkonto, aus demselben Grund wie beim Protokoll:
     * ein Vermerk ueber einen Ausdruck ist Dokumentation. Er darf die Ueberwachung nie
     * ausbremsen und schon gar nicht abschalten. Deshalb wird der Fehler hier nur GEMERKT
     * (status() zeigt ihn im Admin-Bereich) und nirgends weitergereicht.
     */
    if (this.ausdruckInFlight) {
      if (this._ausdruckWartet.length < 12) this._ausdruckWartet.push(koerper);
      return true;
    }
    this._ausdruckSenden(koerper, sid, pid);
    return true;
  }

  /*
   * DER ZEITPUNKT KOMMT AUS DEM KOERPER, NICHT AUS EINER AEUSSEREN VARIABLEN.
   *
   * Beim Umbau auf die Warteschlange stand hier zunaechst weiter `ts` — eine lokale Variable von
   * ausdruckVermerken(), die es in dieser Methode gar nicht mehr gibt. Der ReferenceError fiel
   * INNERHALB der Promise-Kette an und landete im .catch dieser Methode, also in genau dem
   * eigenen Fehlerkonto, das die Vitalwerte schuetzen soll: kein Schreibvorgang, keine Meldung,
   * kein roter Test. Gefunden nur, weil der Selbsttest die Zahl der Schreibvorgaenge zaehlt.
   * koerper.ts ist dieselbe Zahl und ueberlebt den Sprung in die Warteschlange.
   */
  _ausdruckSenden(koerper, sid, pid) {
    this.ausdruckInFlight = true;
    this._ensureAuth()
      .then((tok) => this._write('PUT', '/live/' + this.localId + '/saele/' + sid + '/ausdruck/'
        + pid + '/' + koerper.ts + '.json?auth=' + encodeURIComponent(tok), koerper))
      .then(() => { this.ausdruckFehler = null; })
      .catch((e) => { this.ausdruckFehler = (e && e.message) ? e.message : String(e); })
      .then(() => {
        this.ausdruckInFlight = false;
        const naechst = this._ausdruckWartet.shift();
        if (naechst) this._ausdruckSenden(naechst, naechst.sid, sanitizeKey(naechst.patientId || ''));
      });
  }

  _protokollMerken(logische) {
    (logische || []).forEach((pfad) => {
      const m = /^protokoll\/([^/]+)\/(\d+)$/.exec(pfad);
      if (!m) return;
      (this._protokollGesendet[m[1]] || (this._protokollGesendet[m[1]] = {}))[m[2]] = 1;
      this.protokollGesendet++;
    });
  }

  /* ================================================================
   * DER VERTRAUENSANKER DES DIREKTEN HAUSWEGS — verbund/lan/<sid>
   *
   * WARUM DAS AM 01.08.2026 DAZUKAM: Der direkte Weg zwischen zwei OP-Saelen im selben Haus
   * (bridge/src/nachbar.js, Port 8771, ohne Internet) war vollstaendig gebaut, getestet und
   * konnte trotzdem NIE funktionieren — es fehlte genau ein Stueck: das Nachbarverzeichnis wurde
   * nirgends gefuellt. `nachbar.setzeNachbarn()` hatte ausserhalb der Tests keinen einzigen
   * Aufrufer, und der Knoten verbund/lan kam nur in Kommentaren und in den Datenbankregeln vor.
   * Folge: der Client sagte nie "hallo", und der Server wies jeden eingehenden Handschlag mit
   * "unbekannt" ab. Kein Fehler, kein Log — der Weg war einfach still tot.
   *
   * WARUM DER ANKER IN DIE CLOUD GEHOERT UND NICHT INS LAN: der oeffentliche Schluessel eines
   * Nachbarn muss aus einer Quelle kommen, die ein Fremder im selben Netz NICHT faelschen kann.
   * Das Praxis-Konto ist genau das: ueber TLS, nur mit Anmeldung les- und schreibbar, und jeder
   * Saal schreibt ausschliesslich unter seiner eigenen Kennung. Wer den Schluessel im LAN selbst
   * verteilen wuerde, koennte sich unterwegs dazwischenschieben — dann waere der ganze
   * Handschlag wertlos.
   *
   * WAS HIER NICHT PASSIERT: es wird kein Vertrauen hergestellt. Der Anker liefert nur die
   * ADRESSE und den erwarteten Schluessel; ob dort wirklich der Nachbar sitzt, entscheidet allein
   * der signierte Handschlag in nachbar.js. Eine Adresse ist ein Hinweis, kein Ausweis.
   * ================================================================ */

  /*
   * lanAnkerSchreiben(anker) — die eigene Adresse und den eigenen Schluessel im Konto hinterlegen.
   * Klein und selten: nur wenn sich etwas geaendert hat bzw. alle paar Minuten als Auffrischung.
   * Wirft nie — der LAN-Weg ist Zusatz, der eigene Saal darf daran nicht haengen.
   */
  lanAnkerSchreiben(anker) {
    if (!this.cfg || !this.cfg.enabled || !this.angemeldet()) return Promise.resolve(false);
    const sid = this._sid();
    if (!sid || !anker || !anker.pub) return Promise.resolve(false);
    const ips = (Array.isArray(anker.ips) ? anker.ips : []).filter((x) => typeof x === 'string').slice(0, 4);
    if (!ips.length) return Promise.resolve(false);   // ohne Adresse hat der Anker keinen Zweck
    /*
     * `sid` MUSS MIT (Befund 01.08.2026, vor dem Veroeffentlichen gefunden).
     * Die Datenbankregel auf verbund/lan/$station verlangt
     *     newData.hasChildren(['sid']) && newData.child('sid').val() === $station
     * Ohne dieses Feld haette die Datenbank den ALLERERSTEN Schreibvorgang abgewiesen — und weil
     * es der erste ist, gibt es auch keinen vorhandenen Knoten, der die Bedingung erfuellt. Der
     * Knoten waere also nie entstanden, der direkte Hausweg nie zustande gekommen, und im Log
     * haette eine einzelne Ablehnung gestanden, die wie ein Rechteproblem aussieht.
     * tools/cloud-test.js haelt den Satz jetzt gegen die Regeldatei.
     */
    const satz = {
      sid: sid,
      pub: String(anker.pub).slice(0, 200),
      ips: ips,
      port: Number(anker.port) || 8771,
      name: anker.name ? String(anker.name).slice(0, 40) : null,
      sv: { '.sv': 'timestamp' },
    };
    return this._ensureAuth()
      .then((tok) => this._write('PATCH', '/live/' + this.localId + '/verbund/lan/' +
        encodeURIComponent(sid) + '.json?auth=' + encodeURIComponent(tok), satz))
      .then(() => true)
      .catch((e) => {
        if (!this._lanSchreibFehler) {
          this._lanSchreibFehler = true;
          this.log.warn('cloud', 'Der Vertrauensanker fuer den direkten Hausweg liess sich nicht ' +
            'schreiben (' + (e && e.message) + '). Die Saele sehen einander weiterhin ueber das ' +
            'Praxis-Konto; nur der Weg OHNE Internet bleibt aus. Pruefen: sind die Datenbankregeln ' +
            'aus installer/firebase-rtdb-rules.json veroeffentlicht?');
        }
        return false;
      });
  }

  /*
   * lanAnkerLesen() — die Anker der ANDEREN Saele holen. Liefert die Liste, die
   * nachbar.setzeNachbarn() erwartet. Der eigene Eintrag faellt heraus (sonst spraeche die
   * Station mit sich selbst — im Plan der toedliche Befund A2-8).
   */
  lanAnkerLesen() {
    if (!this.cfg || !this.cfg.enabled || !this.angemeldet()) return Promise.resolve([]);
    const eigen = this._sid();
    return this._ensureAuth()
      .then((tok) => {
        const url = this.cfg.dbUrl.replace(/\/+$/, '') + '/live/' + encodeURIComponent(this.localId) +
          '/verbund/lan.json?auth=' + encodeURIComponent(tok);
        return this._reqJson('GET', url, null, null);
      })
      .then((obj) => {
        if (!obj || typeof obj !== 'object') return [];
        const aus = [];
        Object.keys(obj).forEach((sid) => {
          if (sid === eigen) return;
          if (!tafel.pruefeSid(sid)) return;
          const e = obj[sid] || {};
          if (!e.pub || !Array.isArray(e.ips) || !e.ips.length) return;
          aus.push({ sid: sid, pub: String(e.pub), ips: e.ips.slice(0, 4).map(String),
            port: Number(e.port) || 8771, name: e.name || null });
        });
        return aus;
      })
      .catch(() => []);
  }

  _write(method, pathAndQuery, obj) {
    const url = this.cfg.dbUrl.replace(/\/+$/, '') + pathAndQuery;
    const text = JSON.stringify(obj);
    this.bytesGesendet += Buffer.byteLength(text);
    this.schreibVorgaenge++;
    return this._reqJson(method, url, text, { 'Content-Type': 'application/json' });
  }

  // ---------- Delta ----------
  /*
   * DIE PFADE DES EIGENEN SAALS — Weg L.
   *
   * Zerlegt den Snapshot in TIEFE RTDB-Pfade unter saele/<sid>/patients/<key>/<feld>. Die Realtime
   * Database wendet solche Schluessel als Pfad an (update()-Semantik): geschrieben wird wirklich
   * nur der genannte Teilbaum. ES GIBT KEINEN PFAD 'patients' MEHR und keinen Pfad 'meta' — beide
   * ersetzten frueher einen ganzen Knoten und haetten in einem Konto mit mehreren Saelen den Zweig
   * eines Nachbarn weggeraeumt (Nachbesserung N7).
   *
   * JEDER WERT LAEUFT DURCH DIE GEMEINSAME KAPPUNG (Nachbesserung N9) — mit genau zwei benannten
   * Ausnahmen, siehe _kappeFeld().
   */
  // Die Wurzel des eigenen Saalzweiges. EINE Stelle, an der dieser Pfad entsteht — zwei Meinungen
  // darueber, wie er heisst, waren der Weg, auf dem eine gemerkte Kurve nicht wiedergefunden wurde.
  _saalWurzel() { return 'saele/' + this._sid() + '/patients/'; }

  _pfade(snapshot, sid) {
    const map = new Map();
    const wurzel = 'saele/' + sid + '/patients/';
    const pats = snapshot.patients || {};
    for (const key in pats) {
      const p = pats[key];
      for (const f in p) map.set(wurzel + key + '/' + f, this._kappeFeld(f, p[f]));
    }
    return map;
  }

  /*
   * _kappeFeld — die gemeinsame Kappung auf JEDEN Snapshotwert (N9): Zeichenketten 200,
   * Objekte 40 Felder, Listen 80 Eintraege, Tiefe 8. Sie liegt in tafel.js, damit Code und
   * Regeldatei gegeneinander pruefbar sind (tools/regeln-vertrag-test.js misst beide Seiten).
   *
   * ZWEI FELDER SIND AUSGENOMMEN, und zwar dieselben wie in Reparatur (c) oben:
   *   kurven    — die Abtastwerte selbst (b64, rund 1400 Zeichen je Streifen). Eine Kappung auf
   *               200 Zeichen wuerde die Kurve nicht kuerzen, sondern zerstoeren; die Regel laesst
   *               dort ausdruecklich 12000 zu.
   *   kurvenSig — EIN Text fuer ALLE Kanaele zusammen. Er waechst mit der Laenge der Geraetecodes
   *               (MDC-Codes sind lang) und traegt in der Regel dieselbe 12000er-Grenze.
   * Beide sind keine Texte zum Lesen, sondern Messdaten. Sie kommen ausserdem nicht aus einem
   * Freitextfeld des Geraets, sondern aus der Kodierung in dieser Datei.
   */
  _kappeFeld(feld, wert) {
    if (feld === 'kurven' || feld === 'kurvenSig') return wert;
    return tafel.kappe(wert);
  }

  /*
   * DIE PFADE DES KOMPATIBILITAETSSPIEGELS — Weg S.
   *
   * Dieselben Patientenfelder, aber unter IMMER praefixierten Schluesseln
   * patients/s<sid6>__<key>/<feld>, damit zwei Saele auf der alten flachen Ebene nicht
   * uebereinander schreiben. Zwei Felder bleiben ausdruecklich draussen (Nachbesserung N8):
   *
   *   pri und top. Die ausgelieferte Web-App 1.0.3 waehlt bei Ende einer Narkose den Patienten mit
   *   der HOECHSTEN Prioritaet aus — ueber alle Saele hinweg. Sie setzt dabei den Messmodus
   *   bedingungslos auf "ist" und uebernimmt nur nicht-leere Werte; hat der neue Saal keine
   *   Kapnografie und keine Temperatursonde, stehen EtCO2, Temp, AF und NIBP des Tieres aus Saal 1
   *   unter dem Namen des Tieres in Saal 2 — ausgewiesen als gemessene Istwerte, eingehend in
   *   Dosis- und Beatmungsempfehlung. Ohne pri bleibt die Auswahl beim ersten Schluessel und
   *   springt nicht quer durch die Praxis.
   *
   * Die Kurven gehen nur mit, wenn der Modus es erlaubt (F2-solo): in F2-multi zahlt eine Praxis
   * sonst jeden Streifen doppelt, ohne dass die alte Ansicht ihn zuordnen koennte.
   */
  _spiegelPfade(snapshot, sid, wahl) {
    const map = new Map();
    const w = wahl || {};
    const praefix = 's' + stationsidModul.sidKurz(sid) + '__';
    const pats = snapshot.patients || {};
    for (const key in pats) {
      const p = pats[key];
      for (const f in p) {
        if (f === 'pri' || f === 'top') continue;                 // N8
        /*
         * OHNE STREIFEN AUCH KEINE SIGNATUR (Befund C2). kurvenSig ist fuer die alte Fern-Ansicht
         * die Aussage "es gibt einen NEUEN Kurvenstreifen". Wurde sie weiter fortgeschrieben,
         * waehrend der Streifen selbst nicht mehr mitkommt, meldet die Station der Ansicht einen
         * neuen Streifen und laesst sie den alten lesen — ein eingefrorenes Kurvenbild, das aussieht
         * wie eine Messung. Die beiden Felder gehoeren zusammen oder gar nicht.
         */
        if ((f === 'kurven' || f === 'kurvenSig') && !w.kurven) continue;
        let wert = this._kappeFeld(f, p[f]);
        /*
         * DER SAALNAME WANDERT ZUSAETZLICH IN patientId (N8). Die alte Web-App kennt keine Saele;
         * ohne diesen Zusatz stehen die Tiere zweier OP-Saele in EINER Liste, ohne dass irgendwo
         * steht, welches Tier wo liegt. Nur im Mehrsaalbetrieb — eine Einzelplatzpraxis soll
         * genau dasselbe sehen wie bisher.
         */
        if (f === 'patientId' && w.mehrsaal) {
          // Der Name kommt aus DER EINEN Quelle (Zugriff 'station'); hat dieser Saal noch keinen,
          // steht die Ersatzzeichenkette der Anzeige dort — ein leeres Anhaengsel waere schlimmer
          // als ein ehrliches "ohne Namen", weil dann zwei Tiere wieder ununterscheidbar sind.
          const saal = this._stationText();
          wert = CloudPublisher._kurz(wert ? (wert + ' · ' + saal) : saal, 200);
        }
        map.set('patients/' + praefix + key + '/' + f, wert);
      }
    }
    return map;
  }

  /*
   * _delta — was in DIESEM Takt wirklich geschrieben wird, samt der Loeschungen.
   *
   * Gemeinsam fuer Saalzweig und Spiegel, weil beide dieselbe Frage haben: was hat sich gegenueber
   * dem zuletzt uebertragenen Stand geaendert, und was ist weggefallen?
   *
   * VOLLBILD IST HIER NUR EIN SCHALTER, KEIN ZWEITER WEG. Frueher war das Vollbild ein PUT mit dem
   * ganzen Knoten 'patients' — der ersetzte alles darunter und haette die Spiegelschluessel aller
   * anderen Saele geloescht. Jetzt bedeutet Vollbild: ALLE eigenen Pfade noch einmal schreiben und
   * zusaetzlich die eigenen weggefallenen Schluessel ausdruecklich auf null setzen. Ein fremder
   * Zweig kann dabei nicht getroffen werden, weil jeder erzeugte Pfad unter der eigenen Wurzel
   * beginnt und jede Loeschung aus dem eigenen Gedaechtnis stammt (Nachbesserung N7).
   *
   * 'altbestand' sind eigene Schluessel, die beim Start schon in der Datenbank lagen (aus einem
   * frueheren Prozesslauf). Ohne sie bliebe nach einem Neustart die Kachel eines Patienten stehen,
   * der laengst abgehaengt ist — mit eingefrorenem altMs, also dauerhaft "1,2 s alt" und mit
   * plausiblen Vitalwerten. Genau das ist die Karteileiche aus N7.
   */
  _delta(neu, altMap, wurzel, keys, vollbild, altbestand) {
    const alt = altMap || new Map();
    const vergleich = vollbild ? new Map() : alt;
    const out = {};
    for (const [pfad, wert] of neu) {
      const t = JSON.stringify(wert === undefined ? null : wert);
      if (vergleich.get(pfad) !== t) out[pfad] = wert === undefined ? null : wert;
    }
    // Verschwundene Patienten/Felder ausdruecklich loeschen, sonst bleiben Karteileichen stehen
    // und die Fern-Ansicht zeigt einen Patienten, der laengst abgehaengt ist.
    const weg = new Set();
    for (const pfad of alt.keys()) {
      if (neu.has(pfad)) continue;
      if (pfad.indexOf(wurzel) !== 0) { out[pfad] = null; continue; }
      const key = pfad.slice(wurzel.length).split('/')[0];
      if (keys.has(key)) out[pfad] = null;   // Patient bleibt, aber das Feld ist weggefallen
      else weg.add(key);                     // ganzer Patient weg
    }
    if (altbestand) altbestand.forEach((k) => { if (!keys.has(k)) weg.add(k); });
    // Aufgeraeumt: wenn ein ganzer Patient geloescht wird, sind seine Einzelfelder ueberfluessig.
    weg.forEach((k) => {
      out[wurzel + k] = null;
      Object.keys(out).forEach((p) => { if (p.indexOf(wurzel + k + '/') === 0) delete out[p]; });
    });
    return out;
  }

  // Was jetzt uebertragen wurde, als Gedaechtnis fuer den naechsten Vergleich.
  _alsStand(neu) {
    const m = new Map();
    for (const [pfad, wert] of neu) m.set(pfad, JSON.stringify(wert === undefined ? null : wert));
    return m;
  }

  // ---------- Weg T: die Tafel (Herzschlag + Kacheln + Geraetezeilen) ----------
  /*
   * DER TAFELTAKT IST DER HERZSCHLAG DIESES SAALS (Nachbesserung N6).
   *
   * Er laeuft, auch wenn sich an den Werten nichts aendert — das LifeVet sendet ab Werk nur alle
   * ~30 s, und ohne eigenen Takt stuende tafel/<sid>/meta.sv genauso lange still. Jeder andere
   * Bildschirm im Haus meldete den gesunden Saal dann nach 12 s gelb, nach 60 s "offline" und
   * ersetzte seine Zahlen durch "Stand vor X min".
   *
   * KOPF UND KACHELN GEHEN IM SELBEN KOERPER. Ein Herzschlag ohne die zugehoerigen Kacheln waere
   * ein Saal, der frisch aussieht und alte Zahlen zeigt (Befund A2-2) — am narkotisierten
   * Patienten die gefaehrlichste Anzeige, die dieses Programm erzeugen kann.
   *
   * GERECHNET WIRD HIER NICHTS. Kachel, Geraetezeile, Kopf, Deckel und die Loeschungen kommen
   * vollstaendig aus tafel.js; diese Datei stellt nur die Eingaben zusammen. Zwei Quellen fuer
   * dieselbe Zahl waren Befund A3.
   */
  _tafelSchreiben(a) {
    if (this.tafelInFlight) return;
    const now = Date.now();
    if (now < this.tafelNaechster) return;      // wachsende Wartezeit nach einem Fehler

    let tp = null;
    /*
     * WELCHER Altbestand in DIESEN Koerper eingeflossen ist. Er wird nach dem Erfolg nur dann
     * verworfen, wenn es noch derselbe ist (Befund 17.08.2026, zweiter Anlauf): _altbestandLesen()
     * kann waehrend eines laufenden Schreibvorgangs antworten, und ein pauschales Loeschen im
     * .then() haette den gerade erst gefundenen Altbestand weggeworfen, bevor ihn je ein Koerper
     * getragen hat. Genau daran ist der erste Entwurf im Test gescheitert.
     */
    let altVerbraucht = null;
    try {
      const keyJeGeraet = tafel.keysJeGeraet(a.patients);
      const uebersicht = {};
      (a.patients || []).forEach((p) => {
        if (!p) return;
        // DERSELBE Schluessel wie im Saalzweig (sanitizeKey): sonst zeigt die Kachel auf einen
        // Patienten, den es unter saele/<sid>/patients gar nicht gibt.
        const key = sanitizeKey(p.patientKey || ('dev:' + (p.devices && p.devices[0] && p.devices[0].deviceId)));
        uebersicht[key] = tafel.uebersichtSatz(p, this._assess(p), a.jetzt);
      });
      const geraete = {};
      (a.devices || []).forEach((g) => {
        if (g && g.deviceId) geraete[g.deviceId] = tafel.geraeteSatz(g, a.jetzt, keyJeGeraet);
      });
      const kopf = tafel.tafelSatz({
        sid: a.sid, name: this.station, jetzt: a.jetzt, sv: SV,
        bv: this.bauVersion, instanz: this.stationsid.instanz,
        taktMs: this.minInterval, kurven: this.sendeKurven, sq: this.sq,
        dop: this.stationsid.kollisionsstand() === 'bewiesen',
        aus: this._beendet,
        uebersicht: uebersicht, geraete: geraete,
      });
      /*
       * DENSELBEN SATZ HERGEBEN, DEN DIE CLOUD BEKOMMT (Stufe 2, LAN-Weg).
       *
       * bridge/src/nachbar.js liefert Nachbarstationen im Hausnetz die Tafel dieses Saals. Der
       * Plan verlangt woertlich, dass sie IDENTISCH zum Inhalt von tafel/<sid> ist. Deshalb wird
       * hier der GERADE GEBAUTE Satz abgelegt statt ihn dort ein zweites Mal zu rechnen: zwei
       * Rechenwege driften auseinander, und dann zeigt derselbe Saal auf zwei Bildschirmen
       * verschiedene Zahlen — genau der Widerspruch, den fremdstore hinterher aufloesen muesste.
       * Nur lesen, nie veraendern: es ist dieselbe Objektreferenz, die gleich geschrieben wird.
       */
      this._tafelLetzter = { name: this.station, meta: kopf, kacheln: uebersicht, geraete: geraete, am: now };
      tp = tafel.tafelPfade({
        sid: a.sid, meta: kopf, uebersicht: uebersicht, geraete: geraete,
        /* Der eigene Stand UND der beim Start vorgefundene Altbestand — siehe _tafelVorher(). */
        vorher: (altVerbraucht = this._tafelAltbestand, this._tafelVorher()), nurMeta: !a.darf,
      });
      this._deckelMelden(tp.ueber, now);
    } catch (e) {
      // tafelPfade() scheitert laut, wenn die Kennung nicht in einen Pfad darf. Das ist kein
      // Netzfehler und wiederholt sich in jedem Takt — deshalb hoechstens eine Zeile je Minute.
      if (now - (this._tafelBauFehlerAm || 0) > 60000) {
        this._tafelBauFehlerAm = now;
        this.log.error('cloud', 'Tafel konnte nicht gebaut werden: ' + (e && e.message)
          + ' — die Vitalwerte laufen davon unberuehrt weiter.');
      }
      return;
    }

    this.tafelInFlight = true;
    this._write('PATCH', a.ziel, tp.pfade)
      .then(() => {
        if (this.tafelFehler) this.log.info('cloud', 'Die Saal-Tafel wird wieder geschrieben.');
        this.tafelFehler = null; this.tafelFehlerZahl = 0;
        this.tafelBackoffMs = 0; this.tafelNaechster = 0;
        this.tafelGeschrieben++;
        // Der Zeitpunkt, an dem der Herzschlag WIRKLICH angekommen ist — die Messgrundlage von
        // status().tafel.aktiv. Nicht der Zeitpunkt des Absendens: ein abgesendeter, aber
        // abgelehnter Koerper ist kein Herzschlag.
        this._letzterTafelErfolg = Date.now();
        // Das Gedaechtnis kommt ZUSAMMEN mit den Pfaden zurueck und wird erst nach dem Erfolg
        // uebernommen: sonst gilt eine Kachel als geschrieben, die nie ankam — und ihre Loeschung
        // wuerde nie nachgeholt.
        this._tafelStand = tp.stand;
        /*
         * Der beim Start vorgefundene Altbestand ist mit DIESEM Koerper abgearbeitet: seine
         * Loeschpfade sind angekommen. Er wird deshalb weggeworfen — sonst truege jeder weitere
         * Takt dieselben null-Pfade erneut, und der atomare Koerper wuechse ueber die Laufzeit.
         * NUR nach einem Erfolg und NUR, wenn wirklich geschrieben werden durfte: im Sperrfall
         * (nurMeta) enthaelt der Koerper keine Loeschungen, und der Altbestand muss stehenbleiben,
         * bis er wirklich geschrieben werden konnte.
         */
        if (a.darf && altVerbraucht && this._tafelAltbestand === altVerbraucht) {
          this._tafelAltbestand = null;
        }
      })
      .catch((e) => {
        const msg = e && e.message ? e.message : String(e);
        this.tafelFehler = msg;
        this.tafelFehlerZahl++;
        /*
         * KEINE SELBSTABSCHALTUNG, auch nicht nach hundert Fehlern — nur eine wachsende
         * Wartezeit bis hoechstens einer Anfrage je Minute. Begruendung: die Tafel ist die
         * einzige Stelle, an der ein anderer Bildschirm ueberhaupt sieht, DASS es diesen Saal
         * gibt. Wer sie abschaltet, laesst einen laufenden OP-Saal aus der Praxis verschwinden.
         * Eine Anfrage je Minute kostet nichts und gibt nie auf.
         *
         * DIESE ZUSAGE GILT SEIT DEM 30.07.2026 WIRKLICH (Befund C1/C4). Vorher galt sie nur fuer
         * Fehler, die HIER entstanden: ein Fehler auf dem WERT-Weg schaltete ueber publish() auch
         * die Tafel mit ab, waehrend dieser Kommentar das Gegenteil versprach. Jetzt haengt der
         * Eintritt in den Takt an keinem fremden Fehlerkonto mehr, und ob der Herzschlag
         * tatsaechlich ankommt, wird gemessen statt behauptet (_tafelSchlaegt).
         */
        this.tafelBackoffMs = this.tafelBackoffMs ? Math.min(this.tafelBackoffMs * 2, 60000) : 2000;
        this.tafelNaechster = Date.now() + this.tafelBackoffMs;
        if (this.tafelFehlerZahl === 3) {
          this.log.warn('cloud', 'Die Saal-Tafel laesst sich nicht schreiben: ' + msg
            + ' — dieser OP-Saal erscheint auf anderen Bildschirmen als "offline". Die Vitalwerte '
            + 'und das Protokoll laufen davon unberuehrt weiter; es wird weiter versucht.');
        }
      })
      .then(() => { this.tafelInFlight = false; });
  }

  // N17: ein erreichter Deckel muss SICHTBAR sein, nicht lautlos passieren.
  _deckelMelden(ueber, now) {
    if (!ueber) return;
    const n = (ueber.uebersicht || 0) + (ueber.geraete || 0);
    if (!n) return;
    if (now - (this._deckelGemeldet || 0) < 60000) return;
    this._deckelGemeldet = now;
    this.log.warn('cloud', 'In der Fern-Tafel dieses Saals werden ' + (ueber.uebersicht || 0)
      + ' Patientenkachel(n) und ' + (ueber.geraete || 0) + ' Geraetezeile(n) NICHT angezeigt — '
      + 'Deckel erreicht. Vor Ort ist alles vollstaendig zu sehen.');
  }

  // ---------- Weg S: der Kompatibilitaetsspiegel fuer die ausgelieferte Web-App 1.0.3 ----------
  /*
   * DIE ALTE FERN-ANSICHT LIEST AUSSCHLIESSLICH DIE FLACHE EBENE. Wer sie leer laufen laesst, hat
   * einen Browser, der sich als "live" meldet und nichts zeigt — der schlechtestmoegliche Ausgang.
   * Der Spiegel ist deshalb laut Entscheidung des Nutzers DAUERHAFT an.
   *
   * WELCHER MODUS GILT, ENTSCHEIDET tafel.modusAus() — und NUR dort (Befund A3). Diese Datei
   * rechnet weder den Saalnamen noch die Saalzahl noch die Frische selbst nach: schrieben zwei
   * Stationen dasselbe Feld meta/station ueber verschiedene Wege, flackerte der Kopf der
   * ausgelieferten Web-App im Sekundentakt zwischen zwei Fassungen.
   *   F0  noch nichts gelesen        -> gar nichts flach schreiben
   *   F1  eine 1.0.3 schreibt hier   -> gar nichts flach schreiben, nie ein null
   *   F2-solo  wir sind allein       -> voller Spiegel mit Kurven
   *   F2-multi mehrere Saele         -> Spiegel ohne Kurven, meta/station konstant
   */
  _spiegelSchreiben(a) {
    // modusAus() wird IMMER gerufen, auch wenn nichts geschrieben werden darf: es fuehrt den
    // Latch fuer "eine 1.0.3 laeuft hier" (fremdSeit) hin und zurueck. Ein Takt ohne Aufruf waere
    // ein Takt ohne Gedaechtnis.
    const m = tafel.modusAus({
      jetzt: a.jetzt, eigeneSid: a.sid,
      tafelEintraege: this._tafelEintraege,
      flachMeta: this._flachMeta,
      flachGelesen: this._flachGelesen, tafelGelesen: this._tafelGelesen,
      vorher: { fremdSeit: this._fremdSeit },
      /*
       * ZWEI ANGABEN AUS DEMSELBEN ZEITPUNKT — sonst beweist sich die Station selbst etwas
       * Falsches (Befund vom 31.07.2026, an zwei echten Stationen gemessen).
       *
       * modusAus() benutzt "wir haben ein qs-Kind geschrieben, aber im gelesenen Stand fehlt es"
       * als Beweis dafuer, dass hier eine 1.0.3 schreibt (deren Vollbild loescht alle qs-Kinder).
       * Der gelesene Stand hinkt dem Schreibvorgang aber um einen Lesetakt hinterher: beim
       * ALLERERSTEN eigenen qs-Schreibvorgang meldet _qsGeschrieben bereits true, waehrend
       * _flachMeta noch der Stand von davor ist — ohne unser Kind. Genau das sah aus wie eine
       * fremde 1.0.3.
       *
       * WAS DAS ANRICHTETE: zwei nagelneue Stationen, keine einzige alte, und eine von beiden
       * erklaerte die andere zur 1.0.3 und schrieb 5 Minuten lang NICHTS mehr auf die flache
       * Ebene — auch nicht die Loeschung ihres dort stehenden Patienten. Die ausgelieferte
       * Web-App beurteilt die Frische an meta/ts, das weiterlief: sie zeigte ein Tier mit
       * eingefrorenen Zahlen als LIVE. Gemessen 302 s am Stueck, in vier Laeufen reproduzierbar —
       * ausgeloest ausgerechnet dadurch, dass eine Praxis ihren zweiten Saal in Betrieb nimmt.
       * Dazu eine falsche Diagnose im Log ("Bitte diese Station aktualisieren" — es gab keine).
       *
       * Deshalb zaehlt die Aussage nur, wenn der gelesene Stand JUENGER ist als unser
       * Schreibvorgang. Ist er es nicht, ist die Frage schlicht noch nicht beantwortbar, und
       * modusAus() bekommt sie gar nicht erst gestellt.
       */
      qsGeschrieben: this._qsGeschrieben && this._flachGelesenAm > this._qsGeschriebenAm,
      eigenSatz: { name: this.station, instanz: this.stationsid.instanz },
      qsWert: SV,
    });
    this._fremdSeit = m.fremdSeit;
    if (m.modus !== this._modus) {
      this._modus = m.modus;
      /*
       * BEI JEDEM MODUSWECHSEL WIRD EIN VOLLBILD ERZWUNGEN — UND DAS GEDAECHTNIS BLEIBT STEHEN
       * (Befund C2, nachgebessert 30.07.2026).
       *
       * Das Vollbild ist der alte Grund und gilt weiter: nach einer Runde F1 kann eine 1.0.3 den
       * ganzen flachen meta-Knoten ersetzt haben (ihr Vollbild tut genau das) — unser 'station'
       * waere dann weg, und ein Delta wuerde es nie wieder schreiben. Das flache meta ohne
       * 'station' laesst die Bestandsregel den GANZEN Koerper abweisen.
       *
       * DAS GEDAECHTNIS WEGZUWERFEN war der Fehler. Der Modus entscheidet, WELCHE Felder gespiegelt
       * werden (in F2-multi ohne Kurven, N8). Ohne altes Gedaechtnis gibt es nichts, woraus eine
       * Loeschung entstehen koennte — gemessen: beim Wechsel F2-solo -> F2-multi blieb der zuletzt
       * gespiegelte KURVENSTREIFEN dauerhaft in der flachen Ebene stehen, waehrend Signatur und
       * Vitalwerte daneben weiterliefen. Die ausgelieferte Web-App 1.0.3 zeichnete danach eine
       * eingefrorene EKG-Kurve neben lebenden Zahlen, ohne jedes Kennzeichen, und das genau in dem
       * Moment, fuer den dieser Umbau gebaut ist (die Praxis nimmt ihren zweiten Saal in Betrieb).
       * Ein eingefrorener Wert, der aussieht wie eine Messung, ist die gefaehrlichste Anzeige, die
       * dieses Programm hervorbringen kann.
       * Mit stehendem Gedaechtnis erzeugt _delta() fuer jeden weggefallenen Pfad ein ausdrueckliches
       * null. Treffen kann das per Konstruktion nur eigene Schluessel: im Gedaechtnis stehen
       * ausschliesslich meta-Felder (deren null unten ausgefiltert wird) und mit s<sid6>__
       * praefixierte Patientenpfade.
       */
      this._spiegelVollbildErzwingen = true;
      this.log.info('cloud', 'Kompatibilitaetsspiegel: ' + m.modus + ' — ' + m.grund);
    }
    this._modusGrund = m.grund;
    this._saele = m.saele;

    if (!this.spiegel || this.spiegelAus) return;
    /*
     * Waehrend der Sperre (Doppelkennung nicht ausgeschlossen) wird auch flach nichts geschrieben:
     * ein Zwilling wuerde die gemeinsame flache Ebene sonst mit unseren Werten unter seinem Namen
     * fuellen. Nur der Kopf tafel/<sid>/meta geht raus, dort steht der Konflikt im Klartext.
     */
    if (!a.darf || !m.flach.meta) { this._qsGeschrieben = false; return; }
    if (this.spiegelInFlight) return;
    if (a.now < this.spiegelNaechster) return;

    const body = {};
    /*
     * DER SPIEGEL GEHT ALS DELTA — auch seine meta-Felder (gemessen 30.07.2026).
     *
     * Im Ruhezustand (kein Patient) besteht der Spiegel nur noch aus dem Herzschlag. Wurden dabei
     * station, v, taktMs, kurven und count in JEDEM Takt mitgeschickt, kostete das rund die
     * Haelfte der Ruhemenge — 24 Stunden am Tag, in JEDEM Saal, und die Zahl multipliziert sich
     * mit der Zahl der Saele. Sie stehen deshalb im selben Delta-Gedaechtnis wie die Patienten.
     *
     * ts, sv UND qs BLEIBEN AUSSERHALB DES VERGLEICHS. Sie sind der Herzschlag und der Nachweis,
     * dass diese Station noch lebt: sv ist ein Platzhalter, dessen JSON-Text sich NIE aendert
     * (ein Delta wuerde ihn also nach dem ersten Mal fuer immer weglassen), und ein fehlendes
     * eigenes qs-Kind ist in modusAus() der Beweis fuer eine fremde 1.0.3 — die Station bewiese
     * sich damit selbst.
     */
    const neu = new Map();
    if (m.flach.station) {
      /*
       * station ist nie null: ein null LOESCHT in der Realtime Database das Kind, das flache meta
       * verlaere sein 'station', und die Bestandsregel hasChildren(['station','ts']) wiese den
       * ganzen Koerper ab.
       */
      neu.set('meta/station', CloudPublisher._kurz(m.spiegelMeta.station, 120));
      neu.set('meta/v', FORMAT_V);          // bleibt 3 — die alte Web-App darf nichts merken (N11)
      /*
       * taktMs KOMMT UNVERAENDERT AUS tafel.js, hier wird nichts nachgerechnet — zwei Quellen fuer
       * dieselbe Zahl waren Befund A3.
       *
       * BEKANNTE ABWEICHUNG, BEWUSST OFFEN GELASSEN (Befund C5): tafel.js setzt dort
       * TAFEL_TAKT_MS = 1000, geschrieben wird der Spiegel aber im Tafeltakt dieser Station, und
       * der steht seit der Nutzerentscheidung vom 30.07.2026 auf 2000 ms. Die alte Fern-Ansicht
       * bekommt also eine Zusage, die doppelt so schnell ist wie die Wirklichkeit. Der Schaden ist
       * klein und einseitig: die 1.0.3 benutzt den Wert nur fuer ihre Anzeige "Takt", nicht fuer
       * eine Frischebewertung — die haengt an meta/ts und meta/sv, und die sind richtig.
       * HIER IST ES NICHT ZU BEHEBEN: cloud.js waere die falsche Stelle (es wuerde die zweite
       * Meinung wieder einfuehren, die A3 beseitigt hat). Entweder wird TAFEL_TAKT_MS mit der
       * Nutzervorgabe in Deckung gebracht, oder modusAus() bekommt den tatsaechlichen Takt
       * uebergeben; beides gehoert in tafel.js und die Hauptschleife.
       */
      neu.set('meta/taktMs', m.spiegelMeta.taktMs);
      neu.set('meta/kurven', !!m.spiegelMeta.kurven);
      neu.set('meta/count', Object.keys(a.snapshot.patients || {}).length);
    }
    if (m.flach.patienten) {
      for (const [p, w] of this._spiegelPfade(a.snapshot, a.sid,
        { kurven: !!m.flach.kurven, mehrsaal: m.modus === 'F2-multi' })) neu.set(p, w);
    }
    const keys = new Set();
    for (const p of neu.keys()) { if (p.indexOf('patients/') === 0) keys.add(p.slice('patients/'.length).split('/')[0]); }
    /*
     * Die Wurzel ist 'patients/' — aber im Gedaechtnis stehen AUSSCHLIESSLICH eigene, mit
     * s<sid6>__ praefixierte Schluessel. Eine Loeschung kann deshalb per Konstruktion nur den
     * eigenen Spiegel treffen, nie den Schluessel eines Nachbarsaals und nie den einer 1.0.3.
     */
    const vollbild = this._spiegelVollbildErzwingen || !this._spiegelGesendet
      || (a.now - this._letzterSpiegelVollbild >= this.vollbildMs);
    const plan = this._delta(neu, this._spiegelGesendet, 'patients/', keys, vollbild, this._spiegelAltbestand);
    Object.keys(plan).forEach((p) => {
      /*
       * EIN null AUF EINEM meta-FELD WIRD NIE GESCHRIEBEN. In der Realtime Database ist ein null
       * kein leerer Wert, sondern eine LOESCHUNG: verschwaende 'station', wiese die Bestandsregel
       * hasChildren(['station','ts']) den ganzen Koerper ab — und der traegt den Herzschlag der
       * alten Fern-Ansicht. Erreichbar ist das heute nicht (die Rechte fuer meta und patienten
       * gelten immer zusammen), aber die Folge waere so teuer, dass sie nicht an einer Annahme
       * ueber eine andere Datei haengen soll.
       */
      if (p.indexOf('meta/') === 0 && plan[p] === null) return;
      body[p] = plan[p];
    });

    if (m.flach.station) {
      body['meta/ts'] = m.spiegelMeta.ts;
      body['meta/sv'] = SV;
    }
    // EIN Kind je Station unter meta/qs/<sid>, nie der ganze qs-Knoten: ein Vollbild auf meta/qs
    // loeschte die Kinder der Nachbarstationen und liesse sie sich gegenseitig fuer eine 1.0.3
    // halten (Nachbesserung N5).
    const qsDrin = !!(m.flach.qs && m.spiegelQs && m.spiegelQs.sid);
    if (qsDrin) body['meta/qs/' + m.spiegelQs.sid] = m.spiegelQs.wert;
    if (!Object.keys(body).length) return;

    this.spiegelInFlight = true;
    this._write('PATCH', a.ziel, body)
      .then(() => {
        if (this.spiegelFehler) this.log.info('cloud', 'Der Spiegel fuer die alte Fern-Ansicht wird wieder geschrieben.');
        this.spiegelFehler = null; this.spiegelFehlerZahl = 0;
        this.spiegelBackoffMs = 0; this.spiegelNaechster = 0;
        this.spiegelGeschrieben++;
        this._spiegelGesendet = this._alsStand(neu);
        this._spiegelVollbildErzwingen = false;
        this._spiegelAltbestand = null;
        if (vollbild) this._letzterSpiegelVollbild = a.now;
        // "Haben WIR im letzten Takt ein qs-Kind geschrieben?" — eine Aussage ueber EINEN Takt,
        // nicht ueber die Fassung. modusAus() braucht sie genau so (Befund A2 in tafel.js).
        this._qsGeschrieben = qsDrin;
        // WANN wir es geschrieben haben. Ohne diesen Zeitpunkt laesst sich nicht sagen, ob der
        // zuletzt zurueckgelesene Stand ueberhaupt jung genug ist, um unser Kind enthalten zu
        // koennen — siehe die Begruendung an der Uebergabe an modusAus().
        if (qsDrin) this._qsGeschriebenAm = Date.now();
      })
      .catch((e) => {
        const msg = e && e.message ? e.message : String(e);
        this.spiegelFehler = msg;
        this.spiegelFehlerZahl++;
        this._qsGeschrieben = false;
        this.spiegelBackoffMs = this.spiegelBackoffMs ? Math.min(this.spiegelBackoffMs * 2, 60000) : 2000;
        this.spiegelNaechster = Date.now() + this.spiegelBackoffMs;
        /*
         * Der Spiegel DARF sich abschalten (anders als die Tafel): er ist eine Zugabe fuer eine
         * Ansicht, die es nur noch gibt, solange eine Praxis ihre Web-App nicht aktualisiert hat.
         * Ein nicht selbstheilender Fehler auf der flachen Ebene betrifft ausserdem den Zweig,
         * den eine 1.0.3 im Feld beschreibt — dort weiter zu haemmern ist der schlechtere Fehler.
         */
        if (CloudPublisher._istKonfigFehler(msg) && this.spiegelFehlerZahl >= 3) {
          this.spiegelAus = true;
          this.log.warn('cloud', 'Der Spiegel fuer die ALTE Fern-Ansicht ist abgeschaltet: ' + msg
            + ' — die neue Ansicht (Saal-Tafel) und die Vitalwerte laufen unberuehrt weiter. '
            + 'Nach dem Beheben der Ursache neu anmelden oder neu starten.');
        }
      })
      .then(() => { this.spiegelInFlight = false; });
  }

  // ---------- Rueckleseweg ----------
  /*
   * WAS DIESE STATION LIEST — und warum so wenig.
   *
   * Gelesen werden genau drei Dinge, und jedes beantwortet eine Frage, die diese Datei sonst raten
   * muesste:
   *   1. tafel/<sid>/meta.instanz  — "steht ein Zwilling auf meiner Kennung?" Die Antwort geht
   *      unveraendert in stationsid.kollisionAusgeschlossen(); dort faellt die Entscheidung.
   *   2. meta (flach)              — "schreibt hier eine Station der Fassung 1.0.3?" Die Antwort
   *      geht unveraendert in tafel.modusAus().
   *   3. die Koepfe der NACHBARSAELE — "wie viele Saele sind frisch?" (Saalname und Betriebsmodus).
   *
   * DIE NACHBARN WERDEN SELTENER GELESEN als der eigene Kopf, und es wird NICHT der ganze
   * tafel-Zweig geholt, sondern je Saal nur meta. Der Grund ist das Freikontingent: ein voller
   * tafel-Zweig traegt auch alle Kacheln und alle Geraetezeilen jedes Saals; im 2-Sekunden-Takt
   * gelesen waere das ein Vielfaches dessen, was diese Station schreibt. Ein Saalkopf ist rund
   * 200 Byte.
   *
   * FEHLER HABEN EIN EIGENES KONTO. Ein klemmender Leseweg ist kein Schreibfehler: er darf weder
   * konfigFehler hochzaehlen noch zur Selbstabschaltung fuehren. Was er bewirkt, ist genau eins —
   * der Kompatibilitaetsmodus bleibt in F0, und in F0 wird flach NICHTS geschrieben. Das ist die
   * sichere Richtung: wir koennen einer laufenden 1.0.3 nichts ueberschreiben.
   */
  _zustandLesen(tok, now) {
    if (this._leseLaeuft) return;
    if (this._letzteLese && now - this._letzteLese < this.leseTaktMs) return;
    const sid = this._sid();
    if (!sid) return;
    this._letzteLese = now;
    this._leseLaeuft = true;
    const basis = this.cfg.dbUrl.replace(/\/+$/, '') + '/live/' + encodeURIComponent(this.localId);
    const q = '.json?auth=' + encodeURIComponent(tok);

    const auftraege = [
      this._reqJson('GET', basis + '/meta' + q, null, null).then((m) => {
        this._flachMeta = (m && typeof m === 'object' && !Array.isArray(m)) ? m : null;
        this._flachGelesen = true;
        this._flachGelesenAm = Date.now();
      }),
      this._reqJson('GET', basis + '/tafel/' + encodeURIComponent(sid) + '/meta' + q, null, null)
        .then((m) => {
          /*
           * JEDER zurueckgelesene Wert geht hier hinein — auch null, auch Muell. Was daraus folgt,
           * entscheidet stationsid.js und nur dort; ein Aufrufer, der selbst vorsortiert, erwischt
           * die halbe Logik.
           */
          const wert = (m && typeof m === 'object' && !Array.isArray(m)) ? m.instanz : null;
          this.stationsid.kollisionAusgeschlossen(wert === undefined ? null : wert);
        }),
    ];
    if (!this._letzteFremdLese || now - this._letzteFremdLese >= this.fremdLeseTaktMs) {
      this._letzteFremdLese = now;
      auftraege.push(this._nachbarnLesen(basis, q, sid));
    }
    /*
     * Der Blick auf den eigenen Altbestand wird NICHT hier als erledigt vermerkt, sondern erst,
     * wenn er wirklich geglueckt ist (Befund C6). Er haengt auch nicht in Promise.all: sein
     * Fehlschlag ist kein Lesefehler des Zustands und soll die Meldung darueber nicht faelschen.
     */
    this._altbestandLesen(basis, q, sid);

    this.leseVorgaenge++;
    Promise.all(auftraege)
      .then(() => { this.leseFehler = null; })
      .catch((e) => {
        const msg = e && e.message ? e.message : String(e);
        // Einmal je Minute reden, sonst steht im Diagnose-Log jede zweite Sekunde dieselbe Zeile
        // in dem Puffer, in dem waehrend einer Narkose die klinischen Warnungen stehen.
        if (this.leseFehler !== msg || now - (this._leseFehlerAm || 0) > 60000) {
          this._leseFehlerAm = now;
          this.log.warn('cloud', 'Der Blick in den eigenen Praxis-Knoten ist fehlgeschlagen: ' + msg
            + ' — geschrieben wird weiter. Solange nichts gelesen werden kann, bleibt der Spiegel '
            + 'fuer die alte Fern-Ansicht aus (sichere Richtung) und eine doppelte Stationskennung '
            + 'ist weder bewiesen noch ausgeschlossen.');
        }
        this.leseFehler = msg;
      })
      .then(() => { this._leseLaeuft = false; });
  }

  /* Die Koepfe der Nachbarsaele: erst die Schluesselliste (shallow, ein paar Byte je Saal), dann
   * je Saal nur meta. Gedeckelt auf tafel.GRENZEN.saele — mehr zeigt keine Ansicht, und mehr zu
   * lesen kostet Kontingent, das die eigene Uebertragung braucht. */
  _nachbarnLesen(basis, q, sid) {
    return this._reqJson('GET', basis + '/tafel' + q.replace('.json?', '.json?shallow=true&'), null, null)
      .then((liste) => {
        const alle = (liste && typeof liste === 'object') ? Object.keys(liste) : [];
        const fremd = alle.filter((k) => k !== sid && tafel.pruefeSid(k));
        /*
         * DIE AUSWAHL GEHT NACH FRISCHE, NICHT NACH ALPHABET (Befund 01.08.2026).
         * Hier stand `fremd.sort().slice(0, 8)`. Eine Stationskennung ist eine Zufallsfolge —
         * alphabetisch heisst also willkuerlich. Sind in einem Konto ueber die Jahre mehr als acht
         * Kennungen aufgelaufen (der Knoten eines ausgemusterten PCs bleibt stehen), konnte damit
         * ein LAUFENDER OP-Saal aus der Liste fallen, waehrend eine Karteileiche gelesen wurde:
         * fern unsichtbar, ohne dass irgendwo ein Fehler stand. Die Regel steht jetzt als reine,
         * pruefbare Funktion in tafel.js.
         */
        const wahl = tafel.waehleNachbarn(fremd, this._tafelEintraege, tafel.GRENZEN.saele);
        const genommen = wahl.genommen;
        if (wahl.weggelassen.length) {
          this.log.warn('cloud', wahl.weggelassen.length + ' weitere OP-Saele werden nicht '
            + 'angezeigt — Deckel erreicht (' + tafel.GRENZEN.saele + '). Weggelassen werden die '
            + 'AELTESTEN: ' + wahl.weggelassen.join(', ') + '. Stehen darunter ausgemusterte PCs, '
            + 'koennen ihre Knoten in der Datenbank geloescht werden; laufende Saele fallen hier '
            + 'nicht heraus, solange sie schreiben.');
        }
        return Promise.all(genommen.map((k) => this
          ._reqJson('GET', basis + '/tafel/' + encodeURIComponent(k) + '/meta' + q, null, null)
          .then((meta) => ({ k: k, meta: meta }))
          .catch(() => null)));
      })
      .then((paare) => {
        const neu = {};
        (paare || []).forEach((p) => {
          if (p && p.meta && typeof p.meta === 'object' && !Array.isArray(p.meta)) neu[p.k] = p.meta;
        });
        this._tafelEintraege = neu;
        this._tafelGelesen = true;
      });
  }

  /*
   * EINMAL BEIM START: welche eigenen Schluessel liegen schon in der Datenbank?
   *
   * Nach einem Neustart ist das Delta-Gedaechtnis leer, die Datenbank aber nicht. Ohne diesen
   * Blick bliebe die Kachel eines Patienten stehen, der vor dem Neustart abgehaengt wurde — mit
   * eingefrorenem altMs, also dauerhaft "1,2 s alt" und mit plausiblen Vitalwerten, in der Tafel
   * jeder Web-Ansicht und im Nachbarstreifen (genau die Karteileiche aus N7). Der Plan wollte das
   * mit einer persistenten Schluesselliste in bridge/data/ loesen; die entfaellt ersatzlos, weil
   * data/ von Auslieferung und Update ausgeschlossen ist — drei flache Abfragen beim Start kosten
   * ein paar hundert Byte und koennen nicht veralten.
   *
   * shallow=true liefert nur die SCHLUESSEL, nicht die Inhalte. Auf der flachen Ebene wird streng
   * auf das eigene Praefix gefiltert: dort liegen auch die Schluessel anderer Saele und die einer
   * 1.0.3, und die gehen uns nichts an.
   *
   * ER DARF NICHT LAUTLOS AUSFALLEN (Befund C6). Frueher wurde "erledigt" gesetzt, BEVOR die
   * Abfrage losging, und jeder der vier Vorgaenge hatte ein stummes .catch(() => {}). Ein kurzer
   * Leitungsausfall genau beim Start liess den Altbestand damit fuer die GANZE Laufzeit unbekannt,
   * ohne eine Zeile im Log — und genau dann bleibt die Karteileiche stehen, gegen die dieser Blick
   * gebaut ist. Jetzt: alle vier muessen gelingen, sonst gilt der Blick nicht als erledigt und wird
   * beim naechsten Rueckleseweg wiederholt; hoechstens drei Versuche (danach ist die Ursache keine
   * kurze Leitungsstoerung mehr), und der Fehlschlag wird genau EINMAL gemeldet.
   */
  /*
   * _tafelVorher() — welche Tafelschluessel koennten geloescht werden muessen?
   *
   * Das ist der eigene Stand aus dem letzten erfolgreichen Schreibvorgang PLUS das, was beim Start
   * schon in der Datenbank lag. tafel.js:tafelPfade() macht aus jedem Schluessel dieser Liste, der
   * im aktuellen Bestand nicht mehr vorkommt, ein null — also die Loeschung.
   *
   * Beides getrennt zu halten und erst hier zusammenzulegen ist der Kern der Berichtigung vom
   * 17.08.2026: der Schreibweg darf _tafelStand nach jedem Erfolg ueberschreiben (sonst wuechse das
   * Gedaechtnis), und der Altbestand darf dabei NICHT verlorengehen (sonst bleibt die Karteileiche).
   */
  _tafelVorher() {
    const alt = this._tafelAltbestand;
    if (!alt) return this._tafelStand;
    const eigen = this._tafelStand || { u: [], g: [] };
    const zusammen = (a, b) => {
      const s = new Set(Array.isArray(a) ? a : []);
      (Array.isArray(b) ? b : []).forEach((k) => s.add(k));
      return Array.from(s);
    };
    return { u: zusammen(eigen.u, alt.u), g: zusammen(eigen.g, alt.g) };
  }

  _altbestandLesen(basis, q, sid) {
    if (this._altbestandGeholt || this._altbestandLaeuft) return Promise.resolve();
    if (this._altbestandVersuche >= 3) return Promise.resolve();
    this._altbestandLaeuft = true;
    this._altbestandVersuche++;
    const flach = q.replace('.json?', '.json?shallow=true&');
    const praefix = 's' + stationsidModul.sidKurz(sid) + '__';
    const keys = (o) => ((o && typeof o === 'object') ? Object.keys(o) : []);
    const hole = (pfad) => this._reqJson('GET', basis + pfad + flach, null, null);
    return Promise.all([
      hole('/saele/' + encodeURIComponent(sid) + '/patients'),
      hole('/patients'),
      hole('/tafel/' + encodeURIComponent(sid) + '/uebersicht'),
      hole('/tafel/' + encodeURIComponent(sid) + '/geraete'),
    ]).then((r) => {
      this._saalAltbestand = new Set(keys(r[0]));
      this._spiegelAltbestand = new Set(keys(r[1]).filter((k) => k.indexOf(praefix) === 0));
      /*
       * DER ALTBESTAND DER TAFEL BEKOMMT EIN EIGENES FELD (Befund 17.08.2026).
       *
       * Frueher stand hier "if (!this._tafelStand) this._tafelStand = {...}". Das loeste den einen
       * Fall und schuf den anderen: diese Antwort kann NACH dem ersten erfolgreichen
       * Tafel-Schreibvorgang eintreffen, und dann wurden die ALTEN Schluessel gar nicht gelernt —
       * genau die, die geloescht werden muessten. Die Kachel eines vor dem Neustart abgehaengten
       * Patienten blieb dadurch fuer die ganze Laufzeit stehen: eingefrorene Werte, aber frisches
       * Alter, weil das Alter aus dem laufenden Herzschlag gerechnet wird. In der Tafel JEDER
       * Web-Ansicht und im Nachbarstreifen.
       *
       * WARUM NICHT EINFACH IN _tafelStand VEREINIGEN: probiert und am Test gescheitert. Ein
       * Schreibvorgang, der bereits unterwegs ist, setzt in seinem .then() _tafelStand auf
       * tp.stand — also auf die neuen Namen allein — und loescht die eben vereinigten alten
       * Schluessel wieder weg, bevor sie je benutzt wurden. Genau dieses Ueberschreiben wollte die
       * fruehere Fassung verhindern; sie hat nur die falsche Seite geschuetzt.
       *
       * DESHALB EIN GETRENNTES FELD, das der Schreibweg NUR LIEST und erst nach einem Erfolg
       * verwirft (siehe _tafelVorher() und die Uebernahme nach dem PATCH). Damit ist die
       * Reihenfolge gleichgueltig:
       *   Antwort frueh -> beim ersten Schreiben liegen die alten Schluessel schon vor.
       *   Antwort spaet -> sie kommen beim naechsten Takt dazu, und der Takt danach loescht.
       * Und es waechst nicht: nach dem erfolgreichen Schreiben ist der Altbestand abgearbeitet und
       * wird weggeworfen. Nachgemessen: bei Vereinigung AUCH nach dem Erfolg waere das Gedaechtnis
       * ueber 60 Takte mit 20 wechselnden Patienten von 1 auf 20 Schluessel gewachsen und haette
       * bis zu 19 Loeschpfade je Takt in denselben atomaren Koerper gelegt, der die Vitalwerte
       * traegt.
       */
      this._tafelAltbestand = { u: keys(r[2]), g: keys(r[3]) };
      this._altbestandGeholt = true;
    }).catch((e) => {
      const msg = e && e.message ? e.message : String(e);
      if (this._altbestandVersuche >= 3) {
        this.log.warn('cloud', 'Der einmalige Blick auf die eigenen Reste in der Datenbank ist '
          + 'dreimal fehlgeschlagen (' + msg + '). Folge: ein Patient, der VOR diesem Programmstart '
          + 'abgehaengt wurde, kann als Kachel mit eingefrorenem Alter stehen bleiben, bis diese '
          + 'Station neu startet. Werte, Tafel und Protokoll sind davon nicht betroffen.');
      }
    }).then(() => { this._altbestandLaeuft = false; });
  }

  // ---------- Snapshot ----------
  _buildSnapshot(patients, devices) {
    const out = {};
    let count = 0;
    // Kurvenstreifen dieses Snapshots, noch unbestaetigt. Uebernommen wird das erst, wenn Weg L
    // den Koerper wirklich losgeworden ist (siehe _publizieren) — Begruendung im Konstruktor.
    const kurvenOffen = {};
    const devById = {};
    (devices || []).forEach((d) => { if (d && d.deviceId) devById[d.deviceId] = d; });

    for (const p of patients) {
      const key = sanitizeKey(p.patientKey || ('dev:' + (p.devices && p.devices[0] && p.devices[0].deviceId)));
      const v = p.vitals || {};
      /*
       * ALLE Vitalfelder statt einer Positivliste. Die alte Fassung zaehlte die Felder einzeln auf -
       * jedes neue Messfeld (z. B. PEEP, FiO2, Pulsdruck) waere fern unsichtbar geblieben, ohne dass
       * es irgendwo aufgefallen waere. Jetzt geht alles mit, was einfacher Wert ist.
       */
      const vitals = {};
      for (const f in v) {
        const val = v[f];
        if (val == null) { vitals[f] = null; continue; }
        const t = typeof val;
        if (t === 'number') vitals[f] = Number.isNaN(val) ? null : val;
        else if (t === 'string' || t === 'boolean') vitals[f] = val;
        // verschachtelte Objekte (nibp) sind in mergePatients bereits flachgezogen
      }
      // Sicherstellen, dass die Felder, die die Web-App fest erwartet, immer existieren
      // (auch als null) - sonst blinkt die Fern-Anzeige zwischen "kein Wert" und "Feld fehlt".
      ['hr', 'spo2', 'etco2', 'fico2', 'af', 'sys', 'dia', 'map', 'temp', 'paw',
        'ekgRhythm', 'capnoShape', 'pleth',
        /* Beatmungs-/Gaskanaele des universellen virtuellen Geraets (05.08.2026). Sie muessen
         * hier stehen, obwohl die Schleife darueber ohnehin ALLES mitnimmt: fehlt der Schluessel
         * ganz, bleibt in der Fern-Ansicht der zuletzt gesehene Wert eingefroren stehen (RTDB
         * PATCH loescht nur, was ausdruecklich auf null gesetzt wird). Ein eingefrorener
         * Spitzendruck neben einer laufenden Beatmung ist genau die Art Anzeige, der man
         * ansieht, dass sie stimmt — und die nicht stimmt. */
        'ppeak', 'pmean', 'peep', 'vte', 'mv', 'compl',
        'fio2', 'etAgent', 'fiAgent', 'mac', 'etn2o', 'pi', 'temp2', 'ibp',
      ].forEach((f) => { if (!(f in vitals)) vitals[f] = null; });

      const rec = {
        patientId: p.patientId || null,
        /*
         * DER SCHLUESSEL, UNTER DEM DAS PROTOKOLL DIESES PATIENTEN WIRKLICH LIEGT (21.08.2026).
         *
         * Die Bridge schreibt nach saele/<sid>/protokoll/<sanitizeKey(pid)>/<ts>; die Fern-App
         * baute denselben Pfad bis dahin aus dem ROHEN patientId mit encodeURIComponent. Solange
         * eine Kennung nur aus [A-Za-z0-9_-] besteht, ist beides gleich. Enthaelt sie ein
         * Leerzeichen oder einen Punkt — "Bello 1" wird hier zu "Bello_1", dort zu "Bello%201" —,
         * abonniert die Fern-Ansicht einen Pfad, den es nicht gibt, und meldet "kein
         * Protokolleintrag", waehrend die Zeilen daneben in der Datenbank stehen. Kein Fehler,
         * keine Meldung, kein Test. Deshalb steht der Schluessel jetzt IM Datensatz: die Web-App
         * muss ihn nicht mehr nachbilden, und die beiden koennen nicht mehr auseinanderlaufen.
         */
        protokollKey: p.patientId ? sanitizeKey(p.patientId) : null,
        species: p.species || null,
        weightKg: p.weightKg != null ? p.weightKg : null,
        isoPct: p.isoPct != null ? p.isoPct : null,
        ventMode: p.ventMode || null,
        o2Flow: p.o2Flow != null ? p.o2Flow : null,
        ventParams: (p.ventParams && typeof p.ventParams === 'object') ? p.ventParams : null,
        ts: p.ts || Date.now(),
        vitals: vitals,
        // Alarmtexte kommen vom GERAET, sind also von aussen bestimmt: Anzahl UND Laenge begrenzen.
        alarms: Array.isArray(p.alarms) ? p.alarms.slice(0, 30).map((a) => (
          (a && typeof a === 'object') ? CloudPublisher._kurzObjekt(a, 200, 12) : CloudPublisher._kurz(a, 200)
        )) : [],
        /*
         * GERAETELISTE ABSICHTLICH GROBKOERNIG (gemessen 27.07.2026).
         * Die Liste ist ein einziges Delta-Feld: aendert sich EIN Wert darin, geht die GANZE Liste
         * neu ueber die Leitung. Genau das passierte im Sekundentakt, weil "Sekunden seit den
         * letzten Daten" und der gemessene Sendetakt sich staendig um Kleinigkeiten aendern —
         * gemessen 152 Byte pro Sekunde, die niemand braucht (rund 390 MB im Monat).
         * Deshalb: Sekunden in 5-Sekunden-Stufen, Sendetakt in 50-ms-Stufen. Fuer die Anzeige
         * "vor 10 s" bzw. "1000 ms" ist das genau so aussagekraeftig, aendert sich aber nur noch,
         * wenn sich wirklich etwas tut. werteAnzahl faellt ganz weg: ein reiner Zaehler, der in
         * jedem Paket hochlaeuft und in der Fern-Ansicht nirgends gezeigt wird.
         */
        devices: (p.devices || []).map((d) => {
          const reg = devById[d.deviceId] || {};
          const stufe = (x, s) => (x == null ? null : Math.round(x / s) * s);
          return {
            model: CloudPublisher._kurz(d.model, 200) || '?', role: CloudPublisher._kurz(d.role, 40) || 'monitor',
            status: reg.status || d.status || null,
            ip: d.ip || reg.ip || null, port: d.port || reg.port || null,
            transport: reg.transport || null,
            taktMs: stufe(reg.taktMs, 50),
            sekundenSeitDaten: stufe(reg.sekundenSeitDaten, 5),
          };
        }),
        // Neu fern verfuegbar:
        afSource: p.afSource || null,                 // Kapnograf oder Monitor — steht am AF-Kaestchen
        ekgAnalyse: p.ekgAnalyse || null,             // QRS-Breite, Rhythmus, ST — die eigentliche Aussage
        gebDatum: CloudPublisher._kurz(p.gebDatum, 200),
        geschlecht: CloudPublisher._kurz(p.geschlecht, 200),
        herkunft: p.herkunft || null,                 // woher Tierart/Gewicht stammen (Geraet/Hand)
        manual: !!p.manual,
        kurvenNamen: Array.isArray(p.kurven) ? p.kurven.slice(0, 10).map((n) => CloudPublisher._kurz(n, 200)) : [],
      };

      // Patientenakte + Tiername NUR auf ausdruecklichen Wunsch (Datenschutz, siehe Kopf).
      if (this.sendeStammdaten) {
        rec.patientName = CloudPublisher._kurz(p.patientName, 200);
        // Die Patientenakte kommt unveraendert vom Geraet — Feldnamen und Werte begrenzen.
        rec.akte = CloudPublisher._kurzObjekt(p.akte, 200, 24);
      }

      // Alle Einzelwerte des Geraets ("Alle Werte vom Geraet"-Ansicht auch fern).
      if (this.sendeRohwerte && Array.isArray(p.roh) && p.roh.length) {
        rec.roh = p.roh.slice(0, 80).map((r) => ({
          // Alles hier kommt vom Geraet. label bleibt bei 60 (es steht in einer Tabellenspalte),
          // die uebrigen bekommen die allgemeine Grenze — vorher hatten sie GAR KEINE.
          code: typeof r.code === 'string' ? CloudPublisher._kurz(r.code, 200) : (r.code != null ? r.code : null),
          label: r.label != null ? CloudPublisher._kurz(r.label, 60) : null,
          wert: typeof r.wert === 'string' ? CloudPublisher._kurz(r.wert, 200)
            : (r.wert != null ? r.wert : (typeof r.value === 'string' ? CloudPublisher._kurz(r.value, 200) : (r.value != null ? r.value : null))),
          einheit: CloudPublisher._kurz(r.einheit || r.unit, 200),
          von: CloudPublisher._kurz(r.von, 200), modell: CloudPublisher._kurz(r.modell, 200),
        }));
      }

      // ECHTE KURVEN: Signatur immer, Abtastwerte nur bei Aenderung (= je Streifen genau einmal).
      const kd = Array.isArray(p.kurvenDaten) ? p.kurvenDaten : [];
      const sig = kd
        .map((k) => (k.code || '') + ':' + (k.hz || '') + ':' + (k.samples ? k.samples.length : 0) + ':' + kurvenChecksum(k.samples))
        .join('|') || null;
      rec.kurvenSig = sig;
      if (this.sendeKurven && sig) {
        // Verglichen wird gegen die zuletzt BESTAETIGTE Signatur. Ein Streifen, dessen
        // Schreibvorgang gescheitert oder ausgeblieben ist, gilt weiter als offen und wird im
        // naechsten Wert-Takt erneut angeboten.
        if (this._kurvenSigGesendet[key] !== sig) {
          const kv = {};
          kd.slice(0, 4).forEach((k) => {
            if (!k || !Array.isArray(k.samples) || !k.samples.length) return;
            const enc = encodeSamples(k.samples);
            kv[sanitizeKey(k.code || k.name || 'kanal')] = {
              name: String(k.name || '').slice(0, 40),
              code: k.code || null,
              hz: k.hz != null ? k.hz : null,
              geraeteSkala: k.skala != null ? k.skala : null,
              /* Einheit der GERAETESKALA (seit 07.08.2026 in model.js gefuehrt, meist 'uV').
               * Ohne sie kann die Fern-Ansicht die Werte zwar zeichnen, aber nicht in mV
               * benennen — und das Diagnostik-EKG druckt fern unkalibriert, waehrend es am
               * Tisch kalibriert ist. Zwei Ausdrucke desselben Streifens duerfen sich darin
               * nicht unterscheiden. Kurz gekappt, es ist ein Kuerzel wie 'uV'. */
              einheit: k.einheit ? String(k.einheit).slice(0, 8) : null,
              n: enc.n, skala: enc.skala, b64: enc.b64,
              ts: p.ts || Date.now(),
            };
          });
          if (Object.keys(kv).length) {
            rec.kurven = kv;
            kurvenOffen[key] = sig;
          }
        } else if (this._gesendet) {
          /*
           * Unveraendert: den bereits uebertragenen Streifen im Snapshot beibehalten, damit das
           * Delta ihn nicht faelschlich als "geloescht" meldet und neu schickt.
           * DER PFAD IST DER DES SAALZWEIGES — nachgemessen: mit dem alten, flachen Pfad findet
           * die Abfrage nichts, der Streifen fehlt im naechsten Snapshot, und das Delta schreibt
           * "kurven": null. Fern verschwindet die laufende EKG-Kurve dann bei jedem zweiten Takt.
           */
          const alt = this._gesendet.get(this._saalWurzel() + key + '/kurven');
          if (alt !== undefined) { try { rec.kurven = JSON.parse(alt); } catch (_) { /* egal */ } }
        }
      }

      const res = this._assess(p);
      if (res) { rec.pri = res.pri; rec.top = res.top; }
      out[key] = rec;
      count++;
    }
    // Patienten, die verschwunden sind, verlieren auch ihren gemerkten Kurvenstand.
    for (const k in this._kurvenSigGesendet) { if (!(k in out)) delete this._kurvenSigGesendet[k]; }
    this._kurvenOffen = kurvenOffen;

    return {
      meta: {
        station: this._stationText(), v: FORMAT_V, ts: Date.now(), count: count,
        taktMs: this.minInterval, kurven: this.sendeKurven,
      },
      patients: out,
    };
  }

  /*
   * befundTitel(p) — nur der Titel des Top-Befunds, fuer die Protokollfuehrung der Registry.
   * Bewusst DIESELBE Bewertung wie in der Fern-Ansicht: sonst stuende im Protokoll ein anderer
   * Befund als der, den der Tierarzt auf dem Bildschirm gesehen hat.
   */
  befundTitel(p) {
    const r = this._assess(p);
    return (r && r.top && r.top.title) ? r.top.title : null;
  }

  // Brain-Bewertung -> kompakte Fern-Zusammenfassung (Prioritaet + Top-Befund).
  _assess(p) {
    if (!brain || !ANAES) return null;
    try {
      const flat = Object.assign({ species: p.species || 'hund', weightKg: p.weightKg || 10, isoPct: p.isoPct }, p.vitals || {});
      const r = brain.assess(ANAES, flat, { iso: p.isoPct });
      const top = r.top ? { sev: r.top.sev || 0, title: r.top.title || '', tag: r.top.tag || '', fix: r.top.fix || '', incident: r.top.incident || null } : null;
      return { pri: Math.round((r.priority || 0) * 10) / 10, top: top };
    } catch (_) { return null; }
  }

  // ---------- Firestore-Verlauf (Archiv) ----------
  /*
   * Der Live-Strom gehoert in die Realtime Database. Firestore bekommt parallel einen
   * VERLAUFSDATENSATZ im Ruhetakt - dafuer ist es gebaut (Abfragen ueber Zeitraeume, Fallakte,
   * spaetere Auswertung) und dort ist es auch bezahlbar.
   *
   * Der komplette Stand wandert als EIN JSON-Textfeld hinein (statt als typisierte Firestore-Felder):
   * das haelt den Schreibvorgang klein, ist gegen jede Formatserweiterung immun und kostet genau
   * einen Dokumentschreibvorgang. Die paar Felder, nach denen man spaeter WIRKLICH sucht
   * (Zeit, Station, Patientenzahl, hoechste Prioritaet), stehen zusaetzlich einzeln daneben.
   */
  _archivieren(snapshot, now, idToken) {
    if (!this.archiv.enabled || this.archivAus) return;
    if (!this.archiv.projectId || !this.cfg.apiKey || !idToken || !this.localId) return;
    if (this.archivInFlight) return;
    if (now - this.letztesArchiv < this.archiv.intervalMs) return;
    if (!snapshot.meta.count) return;                 // leere Station nicht archivieren
    this.letztesArchiv = now;
    this.archivInFlight = true;

    let maxPri = 0;
    for (const k in snapshot.patients) {
      const pr = snapshot.patients[k].pri;
      if (typeof pr === 'number' && pr > maxPri) maxPri = pr;
    }
    // Kurven gehoeren nicht ins Archiv (sie wuerden das Dokument sprengen und sind fuer die
    // Verlaufsauswertung ohne Wert - die Zahlen daneben sagen dasselbe).
    const ohneKurven = { meta: snapshot.meta, patients: {} };
    for (const k in snapshot.patients) {
      const p = Object.assign({}, snapshot.patients[k]);
      delete p.kurven;
      delete p.roh;
      ohneKurven.patients[k] = p;
    }

    const doc = {
      fields: {
        ts: { integerValue: String(snapshot.meta.ts) },
        zeit: { timestampValue: new Date(snapshot.meta.ts).toISOString() },
        // Firestore verlangt hier eine Zeichenkette; ein Saal ohne Namen bekommt die ausdrueckliche
        // Ersatzzeichenkette statt eines null, das das ganze Dokument abweisen wuerde.
        station: { stringValue: this._stationText() },
        /*
         * SID UND SAALNAME AB 1.1.0 — sonst ist der Verlauf im Mehrsaalbetrieb nicht auswertbar.
         *
         * 'station' allein genuegt nicht mehr, und zwar aus zwei Gruenden gleichzeitig: es traegt
         * im Mehrsaalbetrieb fuer ALLE Saele dieselbe Ersatzzeichenkette ("mehrere OP-Saele"), und
         * zwei Saele duerfen ohnehin denselben Namen haben. Ohne die Kennung liessen sich zwei
         * Momentaufnahmen desselben Zeitpunkts hinterher nicht mehr auseinanderhalten — und der
         * Verlauf ist die Fallakte, also genau das Dokument, das man Monate spaeter aufschlaegt.
         *
         * 'saal' ist der ECHTE Name dieses Saals (stationsName), 'station' bleibt unveraendert,
         * damit vorhandene Auswertungen nicht brechen. Beide Felder gehen durch dieselbe Kappung
         * wie alles andere; die Firestore-Regel (installer/firestore-rules.txt) verlangt sie und
         * begrenzt ihre Laenge.
         */
        sid: { stringValue: String((this.stationsid && this.stationsid.sid()) || '') },
        saal: { stringValue: this.station || '' },
        patienten: { integerValue: String(snapshot.meta.count) },
        prioritaet: { doubleValue: maxPri },
        daten: { stringValue: JSON.stringify(ohneKurven) },
      },
    };
    /*
     * Der Verlauf haengt unter praxen/<Anmelde-Kennung>/verlauf und wird MIT ANMELDUNG geschrieben.
     * Frueher genuegte der oeffentliche API-Schluessel — der steht aber zwangslaeufig auch in der
     * oeffentlichen Web-App, also konnte jeder Fremde Dokumente anlegen. Im kostenlosen Tarif gilt
     * das Kontingent fuer das GESAMTE Projekt: ein einzelner Angreifer haette damit den Verlauf
     * ALLER Praxen lahmlegen koennen. Firestore nimmt das Anmelde-Token als Bearer-Kopfzeile.
     */
    const url = this.firestoreUrl + '/projects/' + encodeURIComponent(this.archiv.projectId) +
      '/databases/(default)/documents/praxen/' + encodeURIComponent(this.localId) + '/verlauf' +
      '?key=' + encodeURIComponent(this.cfg.apiKey);

    this._reqJson('POST', url, JSON.stringify(doc), {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + idToken,
    })
      .then(() => {
        this.archivGeschrieben++;
        if (this.archivFehler) this.log.info('cloud', 'Firestore-Verlauf schreibt wieder.');
        this.archivFehler = null; this.archivFehlerZahl = 0;
      })
      .catch((e) => {
        this.archivFehler = e && e.message ? e.message : String(e);
        this.archivFehlerZahl++;
        // Das Archiv ist eine Zugabe — es darf die LIVE-Uebertragung niemals stoeren oder das Log
        // zumuellen. Nach drei nicht selbstheilenden Fehlern still abschalten, einmal begruenden.
        if (CloudPublisher._istKonfigFehler(this.archivFehler) && this.archivFehlerZahl >= 3) {
          this.archivAus = true;
          this.log.warn('cloud', 'Firestore-Verlauf abgeschaltet: ' + this.archivFehler +
            ' — die Firestore-Regeln fehlen vermutlich (installer/firestore-rules.txt). ' +
            'Die LIVE-Uebertragung laeuft davon unberuehrt weiter.');
        }
      })
      .then(() => { this.archivInFlight = false; });
  }

  _fehler(e) {
    this.lastError = e && e.message ? e.message : String(e);
    /*
     * Nach einem Fehler ist der gemerkte Stand nicht mehr verlaesslich -> naechster Versuch als
     * Vollbild, sonst wuerde ein verlorener PATCH dauerhaft fehlen.
     * DAS GEDAECHTNIS BLEIBT DABEI STEHEN (frueher: this._gesendet = null). Ein Vollbild schreibt
     * alle eigenen Pfade ohnehin neu; nur MIT dem Gedaechtnis kann es zusaetzlich die Pfade
     * loeschen, die es inzwischen nicht mehr gibt. Ein weggeworfenes Gedaechtnis hiess: jeder
     * Patient, der waehrend der Stoerung abgehaengt wurde, blieb als Karteileiche stehen.
     */
    this._vollbildErzwingen = true;
    // Wartezeit verdoppeln: 2 s -> 4 -> 8 ... max. 60 s. Der Logger fasst identische Meldungen
    // ausserdem zu EINER Zeile zusammen, sodass das Diagnose-Log brauchbar bleibt.
    this.backoffMs = this.backoffMs ? Math.min(this.backoffMs * 2, 60000) : 2000;
    this.naechsterVersuch = Date.now() + this.backoffMs;
    this.log.warn('cloud', 'Fern-Live Schreibfehler: ' + this.lastError +
      ' — naechster Versuch in ' + Math.round(this.backoffMs / 1000) + ' s.');

    /*
     * EINE REGELABLEHNUNG IST KEIN ANMELDEPROBLEM (Befund C1, zweite Haelfte).
     *
     * Die Realtime Database antwortet auf BEIDES mit HTTP 401: auf ein abgelaufenes Token und auf
     * einen Schreibvorgang, den die Sicherheitsregeln nicht zulassen. Nur der erste Fall ist ein
     * Anmeldeproblem. Wurde er nicht unterschieden, warf diese Zeile bei JEDER Regelablehnung das
     * gueltige Token weg und setzte authFailAt — und authFailAt sperrt in publish() den GANZEN
     * Takt fuer 15 Sekunden, also auch den Herzschlag. Gemessen: bei einer dauerhaft abgelehnten
     * Wert-Zeile lief die Tafel nur noch in kurzen Stoessen alle 15 s, und eine Token-Erneuerung
     * ging jedes Mal ueberfluessig ueber die Leitung.
     * Die Unterscheidung ist genau dieselbe wie beim OP-Protokoll (siehe _protokollSchreiben) und
     * absichtlich eng: nur eine Antwort, die die Regelablehnung auch benennt.
     */
    const regelAblehnung = /Permission denied|PERMISSION_DENIED/i.test(this.lastError);
    if (!regelAblehnung && /401|403|token|auth|credential/i.test(this.lastError)) {
      this.idToken = null; this.tokenExp = 0; this.authFailAt = Date.now();
    }

    /*
     * Eine fehlende oder abgelaufene Anmeldung ist KEIN Fall fuer die Selbstabschaltung: sie laesst
     * sich im Admin-Bereich mit zwei Eingaben beheben, und eine abgeschaltete Uebertragung wuerde
     * nach der Anmeldung erst nach einem Neustart wieder anlaufen. Sie faellt deshalb nur in die
     * wachsende Wartezeit.
     */
    if (/Nicht angemeldet/i.test(this.lastError)) return;

    if (CloudPublisher._istKonfigFehler(this.lastError)) {
      this.konfigFehler++;
      if (this.konfigFehler >= 3) this._selbstAbschalten();
    }
  }

  /*
   * Nach drei Konfigurationsfehlern in Folge: den WERT-STROM aufgeben und im Klartext SAGEN warum.
   * Weiterprobieren waere sinnlos (die Ursache liegt in der Firebase-Konsole, nicht auf diesem PC)
   * und wuerde nur das Diagnose-Log zumuellen, das bei der Inbetriebnahme gebraucht wird.
   *
   * WAS HIER NICHT MEHR PASSIERT: 'this.started = false'. Das hat frueher den ganzen Takt
   * stillgelegt — samt Herzschlag. Der laufende OP-Saal verschwand damit aus der Tafel jeder
   * anderen Station und aus jeder Fern-Ansicht, und ein gestoerter Saal war von einem
   * AUSGESCHALTETEN nicht mehr zu unterscheiden (Befund C1). Genau diese Verwechslung ist die
   * gefaehrlichste, die dieser Umbau erzeugen kann: niemand geht nachsehen.
   * Ab jetzt schaltet sich nur Weg L ab; der Herzschlag laeuft mit seiner eigenen, wachsenden
   * Wartezeit weiter (hoechstens eine Anfrage je Minute) und traegt weiter die Aussage "diesen
   * Saal gibt es". status().started meldet den Wertestrom als gestoppt, status().tafel sagt, dass
   * das Herz noch schlaegt.
   */
  _selbstAbschalten() {
    this.abgeschaltet = true;
    this.abschaltAm = Date.now();
    this.probeVersuche = 0;
    const db404 = /HTTP 404/.test(String(this.lastError));
    this.abschaltGrund = db404
      ? 'Die Cloud-Datenbank antwortet mit HTTP 404 — sie ist in der Firebase-Konsole noch nicht angelegt.'
      : 'Dauerhafter Konfigurationsfehler: ' + this.lastError;
    this.log.warn('cloud', 'FERN-LIVE: DIE UEBERTRAGUNG DER VITALWERTE IST ABGESCHALTET. ' + this.abschaltGrund +
      ' Der Herzschlag dieses OP-Saals laeuft weiter, damit er auf anderen Bildschirmen nicht als ' +
      'ausgeschaltet erscheint — dort steht er ab jetzt mit veralteten Werten. ' +
      'Das betrifft NICHT die Geraeteverbindung — Vitaldaten werden weiterhin lokal angezeigt. ' +
      'Anleitung: docs\\FERN-LIVE.md. Die Station versucht es alle ' +
      Math.round(CloudPublisher.PROBE_NACH_MS / 60000) + ' Minuten von selbst noch einmal; ist die ' +
      'Ursache behoben, laeuft die Uebertragung ohne Neustart wieder an.');
  }

  // ---------- Firebase-Anmeldung (Praxis-Konto, E-Mail + Passwort) ----------
  /*
   * Gespeichert wird NUR der Erneuerungs-Token, nie das Passwort. Der Token ist langlebig und
   * traegt die Station ueber jeden Neustart — nach einem Stromausfall laeuft die Uebertragung
   * also von selbst wieder an, ohne dass jemand etwas eingeben muss.
   */
  _loadAuth() {
    try {
      const j = JSON.parse(fs.readFileSync(this.authFile, 'utf8'));
      if (j && j.refreshToken) {
        this.refreshToken = j.refreshToken;
        this.localId = j.localId || null;
        if (j.email && !this.email) this.email = j.email;
      }
    } catch (_) { /* erste Nutzung */ }
  }
  _saveAuth() {
    try {
      fs.mkdirSync(path.dirname(this.authFile), { recursive: true });
      fs.writeFileSync(this.authFile, JSON.stringify({
        refreshToken: this.refreshToken, localId: this.localId, email: this.email || null,
      }), 'utf8');
    } catch (e) { this.log.warn('cloud', 'Token-Datei nicht speicherbar: ' + e.message); }
  }

  /*
   * Kein Rueckfall auf eine Neuanmeldung mehr.
   * Frueher legte _signUp() bei verworfenem Token stillschweigend ein NEUES anonymes Konto an —
   * mit neuer Kennung. Unter uid-gebundenen Regeln waere das fatal: die Station schriebe ploetzlich
   * in einen anderen Pfad, die Web-App der Praxis saehe nichts mehr, und niemand wuesste warum.
   * Jetzt gilt: entweder die gespeicherte Anmeldung traegt, oder es wird ehrlich gemeldet.
   */
  async _ensureAuth() {
    if (this.idToken && this.tokenExp > nowSec() + 60) return this.idToken;
    if (this.refreshToken) return await this._refresh();
    throw new Error('Nicht angemeldet — bitte im Admin-Bereich unter "Fern-Live" das Praxis-Konto anmelden.');
  }

  async _signIn(passwort) {
    const url = this.identityUrl + '?key=' + encodeURIComponent(this.cfg.apiKey);
    const res = await this._reqJson('POST', url,
      JSON.stringify({ email: this.email, password: passwort, returnSecureToken: true }),
      { 'Content-Type': 'application/json' });
    if (!res.idToken) throw new Error('Anmeldung ohne Token: ' + JSON.stringify(res).slice(0, 160));
    this.idToken = res.idToken;
    this.refreshToken = res.refreshToken;
    this.localId = res.localId;
    this.tokenExp = nowSec() + (parseInt(res.expiresIn, 10) || 3600);
    this._saveAuth();
    return this.idToken;
  }

  async _refresh() {
    const url = this.tokenUrl + '?key=' + encodeURIComponent(this.cfg.apiKey);
    const body = 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(this.refreshToken);
    const res = await this._reqJson('POST', url, body, { 'Content-Type': 'application/x-www-form-urlencoded' });
    if (!res.id_token) throw new Error('refresh ohne id_token: ' + JSON.stringify(res).slice(0, 160));
    this.idToken = res.id_token;
    this.refreshToken = res.refresh_token || this.refreshToken;
    this.localId = res.user_id || this.localId;
    this.tokenExp = nowSec() + (parseInt(res.expires_in, 10) || 3600);
    this._saveAuth();
    return this.idToken;
  }

  // ---------- RTDB REST ----------
  _put(pathAndQuery, obj) {
    return this._write('PUT', pathAndQuery, obj);
  }

  /*
   * DIE SERVERZEIT AUS DER HTTP-DATE-KOPFZEILE — ohne SDK, ohne zusaetzliche Anfrage.
   *
   * Jede Antwort traegt sie ohnehin. Gebraucht wird sie, weil ALLE Frischevergleiche der Tafel
   * gegen die Zeit der DATENBANK rechnen: sv setzt der Server selbst, die eigene PC-Uhr ist es
   * nicht. Auf einem OP-PC mit leerer CMOS-Batterie haelt eine unkorrigierte Uhr sonst jeden
   * Nachbarn fuer "aus der Zukunft" — nachgemessen wurde daraus eine Einzelplatzpraxis, die sich
   * dauerhaft fuer einen Mehrsaalbetrieb hielt und in der alten Fern-Ansicht Kurven und Verlauf
   * verlor (Befund B3 in tafel.js).
   *
   * DIE KOPFZEILE HAT 1 s AUFLOESUNG und wird abgeschnitten; der Versatz unterschaetzt die
   * Serverzeit also um bis zu 999 ms. Genau darauf ist tafel.qsEigenFrisch() ausgelegt — deshalb
   * wird hier NICHTS dazugerechnet, was dort schon getragen wird.
   *
   * KEIN GLAETTEN, KEIN MITTELWERT: der letzte Wert gewinnt. Ein Mittelwert ueber Stunden wuerde
   * eine Uhr, die per NTP nachgestellt wird (leere CMOS-Batterie beim Hochfahren), minutenlang
   * hinter sich herziehen.
   */
  _serverZeitMerken(dateKopf) {
    if (!dateKopf) return;
    const t = Date.parse(dateKopf);
    if (!Number.isFinite(t)) return;
    const versatz = t - Date.now();
    // Ein Versatz von mehr als 12 h ist kein Gangunterschied, sondern ein kaputter Kopf oder eine
    // Zwischenstelle mit eigener Uhr. Dann lieber die eigene Uhr behalten und es sagen.
    if (Math.abs(versatz) > 12 * 3600 * 1000) {
      if (!this._versatzGemessen) {
        this._versatzGemessen = true;
        this.log.warn('cloud', 'Die Uhr dieses PCs weicht um mehr als 12 Stunden von der Serverzeit '
          + 'ab. Die Abweichung wird NICHT uebernommen — bitte die Uhrzeit des Praxis-PCs richtig '
          + 'stellen, sonst ist das Alter fremder OP-Saele nicht berechenbar.');
      }
      return;
    }
    if (!this._versatzGemessen && Math.abs(versatz) > 5000) {
      this.log.info('cloud', 'Uhrenversatz zur Datenbank: ' + Math.round(versatz / 1000)
        + ' s — er wird ab jetzt herausgerechnet.');
    }
    this._versatzGemessen = true;
    this._serverVersatz = versatz;
  }

  _reqJson(method, urlString, body, headers) {
    return new Promise((resolve, reject) => {
      let u;
      try { u = new URL(urlString); } catch (e) { return reject(new Error('URL ungueltig: ' + e.message)); }
      const isHttp = u.protocol === 'http:';
      const lib = isHttp ? http : https;
      const opts = {
        method: method,
        hostname: u.hostname,
        port: u.port || (isHttp ? 80 : 443),
        path: u.pathname + u.search,
        headers: Object.assign({ 'Accept': 'application/json' }, headers || {}),
        timeout: 8000,
        agent: isHttp ? AGENT_HTTP : AGENT_HTTPS,   // Dauerverbindung, siehe Kopf der Datei
      };
      if (body != null) opts.headers['Content-Length'] = Buffer.byteLength(body);
      const req = lib.request(opts, (res) => {
        let data = '';
        this._serverZeitMerken(res.headers && res.headers.date);
        res.on('data', (c) => { data += c; });
        res.on('end', () => {
          const code = res.statusCode || 0;
          if (code < 200 || code >= 300) return reject(new Error('HTTP ' + code + ': ' + String(data).slice(0, 200)));
          if (!data) return resolve({});
          try { resolve(JSON.parse(data)); } catch (_) { resolve({ raw: data }); }
        });
      });
      req.on('error', (e) => reject(e));
      req.on('timeout', () => { req.destroy(new Error('Zeitueberschreitung')); });
      if (body != null) req.write(body);
      req.end();
    });
  }

  /*
   * stop() — geordnetes Beenden.
   *
   * Das Feld tafel/<sid>/meta.aus unterscheidet fuer jeden Leser "die Station wurde abgeschaltet"
   * von "die Station ist ausgefallen" — sonst steht nach jedem Feierabend ein Stoerungsbild auf
   * dem Handy des Tierarztes. EHRLICH BENANNT: der letzte Schreibvorgang wird nur noch ANGESTOSSEN.
   * index.js ruft unmittelbar danach process.exit(0), und ein laufender HTTPS-Vorgang ueberlebt
   * das nicht zuverlaessig. Bleibt er aus, altert der Saal in der Fern-Ansicht ganz normal (nach
   * 12 s gelb, nach 60 s offline) — das ist unschoen, aber nie falsch.
   */
  stop() {
    this._beendet = Date.now();
    const sid = this._sid();
    if (this.started && sid && this.idToken && this.localId && !this.tafelInFlight) {
      try {
        const ziel = '/live/' + this.localId + '.json?auth=' + encodeURIComponent(this.idToken);
        const kopf = tafel.tafelSatz({
          sid: sid, name: this.station, jetzt: this._jetzt(), sv: SV, bv: this.bauVersion,
          instanz: this.stationsid.instanz, taktMs: this.minInterval, kurven: this.sendeKurven,
          sq: this.sq, aus: this._beendet,
        });
        this._write('PATCH', ziel, tafel.tafelPfade({ sid: sid, meta: kopf, nurMeta: true }).pfade)
          .catch(() => { /* beim Beenden wird darueber nicht mehr geredet */ });
      } catch (_) { /* eine Abmeldung darf am Beenden nichts aendern */ }
    }
    this.started = false;
  }
}

/*
 * Wie lange nach einer Selbstabschaltung gewartet wird, bis GENAU EIN Probeschreiben laeuft
 * (Begruendung ausfuehrlich bei this.abschaltAm im Konstruktor). Fuenf Minuten sind kurz genug,
 * dass eine behobene Stoerung noch waehrend derselben Narkose von selbst zurueckkommt, und lang
 * genug, dass ein wirklich falsch eingerichtetes Projekt hoechstens 12 Anfragen je Stunde kostet.
 * Als statisches Feld und nicht als Konstante im Modul, damit ein Test sie herabsetzen kann,
 * ohne fuenf Minuten zu warten.
 */
CloudPublisher.PROBE_NACH_MS = 5 * 60 * 1000;

module.exports = { CloudPublisher, sanitizeKey, encodeSamples, kurvenChecksum, FORMAT_V };
