'use strict';
/*
 * kanal-live.js — fragt den VEROEFFENTLICHTEN Kanal so ab, wie es eine laufende Station tut,
 * und rechnet nach: Version, Pruefsumme des heruntergeladenen Pakets, Ed25519-Signatur.
 *
 * Der oertliche manifest-pruefen.js prueft die Dateien auf dieser Platte. Ob GitHub Pages sie
 * auch ausliefert, sagt er nicht - und genau dort ist der Kanal schon einmal stehen geblieben.
 *
 * Start (aus quellcode/):  node <pfad>/kanal-live.js
 */
var https = require('https');
var crypto = require('crypto');
var fs = require('fs');

var BASIS = 'https://quziboevmanuchehr.github.io/canis-vetpharm/';
function hol(url, cb, tiefe) {
  https.get(url, function (r) {
    if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && (tiefe || 0) < 5) {
      r.resume(); return hol(r.headers.location, cb, (tiefe || 0) + 1);
    }
    var teile = [];
    r.on('data', function (d) { teile.push(d); });
    r.on('end', function () { cb(null, r.statusCode, Buffer.concat(teile)); });
  }).on('error', function (e) { cb(e); });
}
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

console.log('Der Kanal, wie ihn eine laufende Station sieht\n');
hol(BASIS + 'vetstation-version.json?t=' + Date.now(), function (e, code, buf) {
  if (e) { console.log('  ✗ Manifest nicht erreichbar: ' + e.message); process.exit(1); }
  ok('Manifest wird ausgeliefert (HTTP ' + code + ')', code === 200);
  var m;
  try { m = JSON.parse(String(buf)); } catch (x) { ok('Manifest ist lesbar', false, x.message); process.exit(1); }
  /*
   * Die erwartete Version kommt aus package.json, nicht aus dieser Datei.
   *
   * Zuerst stand hier "1.21.1" fest eingetragen - an ZWEI Stellen, und beim Weiterschalten
   * auf 1.21.2 wurde nur eine davon mitgezogen (die andere steckte in einem regulaeren
   * Ausdruck mit maskierten Punkten und entzog sich dem Ersetzen). Eine Pruefung, die ihre
   * Erwartung von Hand gepflegt haben will, prueft frueher oder spaeter die falsche Zahl.
   */
  var soll = require(process.cwd() + '/package.json').version;
  ok('Manifest meldet ' + soll, m.app === soll, 'gemeldet: ' + m.app);
  ok('es nennt die Zip zu ' + soll,
    String(m.zipUrl).slice(-(('VetStation-' + soll + '.zip').length)) === 'VetStation-' + soll + '.zip',
    String(m.zipUrl));
  ok('es traegt eine Signatur', !!m.sigEd25519);
  hol(String(m.zipUrl), function (e2, code2, zip) {
    if (e2) { console.log('  ✗ Paket nicht erreichbar: ' + e2.message); process.exit(1); }
    ok('Paket wird ausgeliefert (HTTP ' + code2 + ', ' + Math.round(zip.length / 1024) + ' KB)', code2 === 200);
    var sha = crypto.createHash('sha256').update(zip).digest('hex');
    ok('Pruefsumme des HERUNTERGELADENEN Pakets stimmt mit dem Manifest', sha === m.sha256,
      'geladen ' + sha.slice(0, 16) + '..., Manifest ' + String(m.sha256).slice(0, 16) + '...');
    /*
     * Die Signatur mit DERSELBEN Stelle pruefen, die auch der Praxis-PC benutzt.
     * Zuerst hatte ich sie hier nachgebaut als version + "\n" + sha - und die Pruefung fiel
     * rot aus. Die Aussage ist aber laenger: updater/signatur.js stellt ein Praefix davor.
     * Wer eine Signaturpruefung nachbaut, prueft am Ende seinen Nachbau.
     */
    try {
      var sig = require(process.cwd() + '/updater/signatur.js');
      var pub = fs.readFileSync('updater/release-key.pub', 'utf8');
      var r = sig.pruefe(m.app, m.sha256, m.sigEd25519, pub);
      ok('die Signatur gilt fuer genau diese Version und diese Pruefsumme', r.ok, r.grund);
    } catch (x) { ok('Signatur pruefbar', false, x.message); }
    console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
    process.exit(fail ? 1 : 0);
  });
});
