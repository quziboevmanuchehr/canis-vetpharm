'use strict';
/*
 * kontrast-test.js — Waechter fuer die LESBARKEIT IM HELLMODUS.
 *
 * WARUM ES DIESE DATEI GIBT (gemessen 21.08.2026):
 * Im ganzen Baum kam bis heute weder "0.2126" noch "luminan" noch "contrastRatio" vor — es gab
 * also KEINE einzige Stelle, die Kontrast rechnet. Jede Hellmodus-Berichtigung war damit
 * ungesichert: sie stand als Farbe in einer Regel und nichts hielt fest, dass sie noetig war.
 * Genau das ist hier mehrfach passiert — der naechste Umbau nahm sie still zurueck, und
 * niemand merkte es, weil eine zu helle Schrift keinen Test rot faerbt und im Dunkelmodus
 * (in dem entwickelt wird) gar nicht auffaellt. Der Hellmodus ist aber die VORGABE:
 * ui/shared/vetpharm-ui.js Zeile 41-45 setzt "light", nur ein ausdrueckliches "dark" im
 * localStorage macht dunkel. Was hier falsch ist, sieht die Praxis, nicht der Entwickler.
 *
 * WAS GEPRUEFT WIRD
 *   ui/app/index.html          alle <style>-Bloecke
 *   ui/shared/glass.css        ganze Datei
 *   tools/web-fern-modul.html  <style>-Bloecke UND der per JS eingesetzte Stilblock
 *
 * Der eingesetzte Block (injectCss, dort als String-Verkettung) ist kein Beiwerk: .vetlive-saele-tog
 * liegt nur dort. Wer nur <style> liest, findet diese Regel nie — und sie ist eine der
 * schlechtesten der ganzen Anwendung.
 *
 * WARUM EINE VERERBUNGSHEURISTIK HIER NICHT REICHT (der Kern der Datei)
 * Aus einer Stilvorlage allein laesst sich NICHT ablesen, in welchem Kasten ein Element
 * spaeter steht. ".fl-al .phys" sagt nichts darueber, ob dieses span auf dem Seitengrund,
 * in einer Karte oder in einem Anmeldefenster liegt — das entscheidet das Markup, und das
 * Markup wird hier zur Laufzeit aus JavaScript gebaut. Jede Heuristik ("nimm den Grund des
 * naechsten Vorfahren, der im Selektor steht") faellt deshalb auf die Nase: bei ".fl-al .phys"
 * waere das ".fl-al" — und .fl-al hat gar keinen Grund. Man landet bei "durchsichtig", also
 * rechnerisch bei Schwarz, und meldet die Stelle als tiefschwarz lesbar. Deshalb steht unten
 * eine AUSDRUECKLICHE Zuordnung "Selektor -> Kasten, in dem er liegt". Sie ist von Hand
 * gepflegtes Wissen ueber das Markup, keine Ableitung — und sie muss mitgepflegt werden,
 * wenn ein neuer Baustein dazukommt. Ein unbekannter Selektor faellt auf .card zurueck, weil
 * dort der weitaus groesste Teil des Textes dieser Anwendung steht.
 *
 * ZWEI FALLEN, DIE BEIM ERSTEN MESSEN IM BROWSER SCHON ZUGESCHLAGEN HABEN
 *   a) Ein Element auf einem FARBVERLAUF hat backgroundColor rgba(0,0,0,0). Wer nur die Farbe
 *      liest, haelt jeden Verlauf fuer durchsichtig und meldet ihn als Schwarz — die erste
 *      Messung hatte so zehn Fehlalarme. Hier wird background-image mitgewertet: die Farbstopps
 *      eines Verlaufs werden gemittelt (verlaufMitteln), und die Gegenprobe prueft genau das.
 *   b) Halbdurchsichtige Farben muessen UEBER ihren Grund gerechnet werden, nicht als Vollton.
 *      rgba(255,255,255,.62) ist auf #e9eef7 etwas voellig anderes als reines Weiss.
 *
 * WARUM ES EINE AUSNAHMELISTE GIBT — UND WARUM SIE BLEIBEN MUSS
 * Mehrere Flaechen sind in BEIDEN Farbschemata absichtlich dunkel: das Bild des virtuellen
 * Geraets samt Messkacheln (ein Patientenmonitor ist schwarz; glass.css:469-471 schreibt das
 * mit !important fest), das Diagnostik-EKG-Overlay und das CPR-Fenster (index.html:5770-5781
 * begruendet das ausdruecklich am 21.08.2026: zwoelf helle Farben nachzuziehen waere die
 * halbe Umstellung gewesen, die beim naechsten Umbau wieder auseinanderfaellt). Ohne diese
 * Liste faerbt der Test genau diese Flaechen zu Unrecht rot — und die naechste Person schaltet
 * ihn dann ab, statt die echten Fehlstellen zu beheben. Ein Waechter, den man abschaltet, ist
 * schlechter als keiner. Jeder Eintrag traegt deshalb seine Begruendung; --alle zeigt, was er
 * verschluckt, damit die Liste selbst nachpruefbar bleibt.
 *
 * WAS DER TEST NICHT KANN
 *   - Er misst DEKLARIERTE Farben, keine geerbten. Text ohne eigene color-Regel wird nur ueber
 *     body erfasst.
 *   - Er kennt kein Layout. Ob ein Kasten tatsaechlich sichtbar ist, weiss nur der Browser.
 *   - Kombinatoren werden als Nachfahren behandelt (">" wie " ") — in diesen drei Dateien
 *     gibt es keinen Fall, in dem das etwas aendert.
 *
 * Start:  node tools/kontrast-test.js          nur die Unterschreitungen
 *         node tools/kontrast-test.js --alle   zusaetzlich alles Bestandene und Uebersprungene
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const ALLES = process.argv.indexOf('--alle') >= 0;

/* ==========================================================================================
 * 1 · FARBEN
 * ========================================================================================== */

const NAMEN = {
  white: [255, 255, 255, 1], black: [0, 0, 0, 1], transparent: [0, 0, 0, 0],
  red: [255, 0, 0, 1], gray: [128, 128, 128, 1], grey: [128, 128, 128, 1]
};

/* Farbwerte kommen in dieser Anwendung in sechs Schreibweisen vor. Alles, was sich nicht
 * eindeutig aufloesen laesst (inherit, currentColor, eine erst zur Laufzeit gesetzte
 * Variable), gibt null zurueck — und null heisst spaeter "nicht messbar", nicht "schwarz".
 * Der Unterschied ist der ganze Punkt: eine geratene Farbe waere ein erfundener Befund. */
function farbeLesen(txt, vars) {
  if (!txt) return null;
  let t = String(txt).trim();
  if (!t) return null;

  const varTreffer = /^var\(\s*(--[\w-]+)\s*(?:,\s*([\s\S]+))?\)$/.exec(t);
  if (varTreffer) {
    const name = varTreffer[1];
    /* CSS nimmt den Ersatzwert NUR, wenn die Variable ueberhaupt nicht gesetzt ist. Wer den
     * Ersatzwert immer nimmt, misst im Hellmodus die Dunkelmodus-Farbe: var(--muted,#9aa8bb)
     * ist hier #56657a, nicht #9aa8bb — ein Unterschied von 2,4 zu 5,4 im Kontrast. */
    if (vars && Object.prototype.hasOwnProperty.call(vars, name)) return farbeLesen(vars[name], vars);
    if (varTreffer[2] !== undefined) return farbeLesen(varTreffer[2], vars);
    return null;
  }

  const kleinT = t.toLowerCase();
  if (kleinT === 'inherit' || kleinT === 'currentcolor' ||
      kleinT === 'initial' || kleinT === 'unset') return null;
  if (Object.prototype.hasOwnProperty.call(NAMEN, kleinT)) {
    const n = NAMEN[kleinT];
    return { r: n[0], g: n[1], b: n[2], a: n[3] };
  }

  let m = /^#([0-9a-f]{3,8})$/i.exec(t);
  if (m) {
    const h = m[1];
    if (h.length === 3 || h.length === 4) {
      const w = function (i) { return parseInt(h[i] + h[i], 16); };
      return { r: w(0), g: w(1), b: w(2), a: h.length === 4 ? w(3) / 255 : 1 };
    }
    if (h.length === 6 || h.length === 8) {
      const w2 = function (i) { return parseInt(h.substr(i, 2), 16); };
      return { r: w2(0), g: w2(2), b: w2(4), a: h.length === 8 ? w2(6) / 255 : 1 };
    }
    return null;
  }

  m = /^rgba?\(([^)]*)\)$/i.exec(t);
  if (m) {
    const teile = m[1].split(/[\s,\/]+/).filter(function (s) { return s !== ''; });
    if (teile.length < 3) return null;
    const z = function (s) { return /%$/.test(s) ? parseFloat(s) * 2.55 : parseFloat(s); };
    const a = teile.length > 3
      ? (/%$/.test(teile[3]) ? parseFloat(teile[3]) / 100 : parseFloat(teile[3]))
      : 1;
    const c = { r: z(teile[0]), g: z(teile[1]), b: z(teile[2]), a: isNaN(a) ? 1 : a };
    if (isNaN(c.r) || isNaN(c.g) || isNaN(c.b)) return null;
    return c;
  }
  return null;
}

/* Falle b: eine halbdurchsichtige Farbe ist erst ueber ihrem Grund eine echte Farbe. */
function ueberlagern(vorn, hinten) {
  if (!vorn) return hinten;
  if (vorn.unmessbar) return vorn;
  if (vorn.a >= 1) return { r: vorn.r, g: vorn.g, b: vorn.b, a: 1 };
  /* Erst hier zaehlt ein unmessbarer Grund: eine deckende Schicht darueber verdeckt ihn. */
  if (hinten && hinten.unmessbar) return hinten;
  if (vorn.a <= 0) return hinten;
  const a = vorn.a;
  return {
    r: a * vorn.r + (1 - a) * hinten.r,
    g: a * vorn.g + (1 - a) * hinten.g,
    b: a * vorn.b + (1 - a) * hinten.b,
    a: 1
  };
}

function linear(c) {
  const s = c / 255;
  return s <= 0.04045 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
}

/* WCAG 2.1, relative Leuchtdichte. Die drei Faktoren 0.2126/0.7152/0.0722 sind der Grund,
 * warum Gelb auf Weiss unlesbar ist und Blau auf Weiss nicht: Gruen zaehlt siebenmal so viel
 * wie Blau. Wer nach Augenmass korrigiert, korrigiert deshalb regelmaessig die falsche Farbe. */
function leuchtdichte(c) {
  return 0.2126 * linear(c.r) + 0.7152 * linear(c.g) + 0.0722 * linear(c.b);
}

function kontrast(vorn, hinten) {
  const l1 = leuchtdichte(vorn), l2 = leuchtdichte(hinten);
  const hell = Math.max(l1, l2), dunkel = Math.min(l1, l2);
  return (hell + 0.05) / (dunkel + 0.05);
}

function hex(c) {
  const w = function (v) {
    const n = Math.max(0, Math.min(255, Math.round(v))).toString(16);
    return n.length < 2 ? '0' + n : n;
  };
  return '#' + w(c.r) + w(c.g) + w(c.b);
}

/* ------------------------------------------------------------------------------------------
 * Falle a: Verlaeufe.
 * Ein Element mit linear-gradient() hat im Browser backgroundColor rgba(0,0,0,0). Gemittelt
 * wird ueber die Farbstopps; ein vollstaendig durchsichtiger Stopp faerbt nichts und faellt
 * aus dem Mittel, verringert aber die Deckung des Verlaufs — deshalb wird die Deckkraft mit
 * dem Anteil der farbigen Stopps gewichtet. Ein Mittelwert ist naeherungsweise: an einem Ende
 * des Kastens steht eine andere Farbe als am anderen. Fuer die Glasflaechen dieser Anwendung
 * (rgba(255,255,255,.72) nach rgba(255,255,255,.56)) liegen die Enden 0,03 Leuchtdichte
 * auseinander, das aendert an keiner Einordnung etwas.
 *
 * EINE FORM WIRD BEWUSST NICHT GEMITTELT: conic-gradient laeuft ueber den ganzen Farbkreis
 * (das Markenzeichen faechert von Teal ueber Gruen und Amber nach Pink). Sein Mittelwert ist
 * ein schmutziges Graugruen, das an keiner Stelle der Flaeche vorkommt — eine Zahl daraus
 * waere erfunden. Solche Gruende werden als unmessbar gemeldet, nicht geschaetzt.
 * ------------------------------------------------------------------------------------------ */
const UNMESSBAR = { unmessbar: true, r: 0, g: 0, b: 0, a: 1 };

/* Den obersten Verlauf einer Hintergrundangabe herausschneiden. Bei mehreren Schichten
 * ("background-image:A,B,C") ist A die oberste; die darunter werden vernachlaessigt. In diesen
 * drei Dateien betrifft das ausschliesslich die Aurora-Schleier von body — und body hat aus
 * genau diesem Grund einen festen Wert (siehe WURZEL). */
function ersterVerlauf(txt) {
  const m = /(repeating-linear-gradient|linear-gradient|radial-gradient|conic-gradient)\(/i.exec(txt);
  if (!m) return null;
  const start = m.index + m[0].length;
  let tiefe = 1, i = start;
  while (i < txt.length && tiefe > 0) {
    if (txt[i] === '(') tiefe++;
    else if (txt[i] === ')') tiefe--;
    i++;
  }
  return { art: m[1].toLowerCase(), inhalt: txt.slice(start, i - 1) };
}

function verlaufMitteln(txt, vars) {
  const v = ersterVerlauf(txt);
  if (!v) return null;
  if (v.art === 'conic-gradient') return UNMESSBAR;

  const stuecke = [];
  let tiefe = 0, start = 0;
  for (let i = 0; i < v.inhalt.length; i++) {
    const c = v.inhalt[i];
    if (c === '(') tiefe++;
    else if (c === ')') tiefe--;
    else if (c === ',' && tiefe === 0) { stuecke.push(v.inhalt.slice(start, i)); start = i + 1; }
  }
  stuecke.push(v.inhalt.slice(start));

  const sum = { r: 0, g: 0, b: 0, a: 0 };
  let farbig = 0, stopps = 0;
  stuecke.forEach(function (s) {
    const roh = s.trim();
    if (!roh) return;
    /* Richtungsangaben ("180deg", "to bottom", "circle at 50% 40%") sind keine Stopps. */
    if (/^(to\s|-?[\d.]+deg|-?[\d.]+turn|-?[\d.]+rad|circle|ellipse|at\s|from\s|in\s)/i.test(roh)) return;
    const ohnePos = roh.replace(/\s+(-?[\d.]+(%|px|em|rem|vh|vw)|calc\([^)]*\))\s*$/i, '').trim();
    const f = farbeLesen(ohnePos, vars);
    if (!f) return;
    stopps++;
    if (f.a <= 0) return;
    farbig++;
    sum.r += f.r; sum.g += f.g; sum.b += f.b; sum.a += f.a;
  });
  if (!farbig) return null;
  return {
    r: sum.r / farbig, g: sum.g / farbig, b: sum.b / farbig,
    a: (sum.a / farbig) * (farbig / Math.max(stopps, 1))
  };
}

/* ==========================================================================================
 * 2 · STILVORLAGEN EINLESEN
 * ========================================================================================== */

/* Kommentare werden durch Leerzeichen ersetzt statt geloescht — sonst verschieben sich alle
 * Zeichenpositionen und jede gemeldete Zeilennummer zeigt auf die falsche Zeile. */
function ohneKommentare(css) {
  return css.replace(/\/\*[\s\S]*?\*\//g, function (m) { return m.replace(/[^\n]/g, ' '); });
}

function stilbloecke(text) {
  const out = [];
  const re = /<style[^>]*>/gi;
  let m;
  while ((m = re.exec(text))) {
    const start = m.index + m[0].length;
    const ende = text.indexOf('</style>', start);
    if (ende < 0) break;
    out.push({ css: text.slice(start, ende), versatz: start });
    re.lastIndex = ende;
  }
  return out;
}

/*
 * Der per JavaScript eingesetzte Stilblock aus tools/web-fern-modul.html.
 * Er wird als String-Verkettung geschrieben und ist damit fuer jeden <style>-Leser unsichtbar.
 * Beim Zusammensetzen wird eine Rueckrechnung mitgefuehrt (Position im zusammengesetzten CSS
 * -> Position in der Datei). Ohne sie zeigt jede gemeldete Zeile irgendwohin in die Naehe:
 * die Stuecke sind unterschiedlich lang, und die Anfuehrungszeichen samt "+" fehlen im
 * Ergebnis. Eine Zeilennummer, die nur ungefaehr stimmt, kostet den Leser genau das
 * Vertrauen, das ein Waechter braucht.
 */
function eingesetzterStil(text) {
  const anfang = text.indexOf('function injectCss()');
  if (anfang < 0) return null;
  const zuweisung = text.indexOf('s.textContent', anfang);
  if (zuweisung < 0) return null;
  const ende = text.indexOf('document.head.appendChild', zuweisung);
  if (ende < 0) return null;
  const roh = ohneKommentare(text.slice(zuweisung, ende));
  let css = '';
  const karte = [];
  const re = /'((?:[^'\\]|\\.)*)'/g;
  let m;
  while ((m = re.exec(roh))) {
    karte.push({ cssAb: css.length, dateiAb: zuweisung + m.index + 1 });
    css += m[1].replace(/\\'/g, "'");
  }
  return css ? { css: css, karte: karte } : null;
}

/* Rueckrechnung: welche Stelle der Datei entspricht dieser Stelle im zusammengesetzten CSS? */
function ausKarte(karte, cssPos) {
  let treffer = karte[0];
  for (let i = 0; i < karte.length; i++) {
    if (karte[i].cssAb <= cssPos) treffer = karte[i]; else break;
  }
  return treffer.dateiAb + (cssPos - treffer.cssAb);
}

/* Ein toleranter Regelleser. Kein vollstaendiger CSS-Parser: er kennt Blocktiefe, At-Regeln
 * und Deklarationen, und mehr braucht es fuer diese drei Dateien nicht. */
function regelnLesen(css, ortVon, datei, band) {
  const roh = ohneKommentare(css);
  const out = [];
  const stapel = [];
  let i = 0, selStart = 0;
  while (i < roh.length) {
    const c = roh[i];
    if (c === '{') {
      /* Der Selektor beginnt beim ersten Zeichen, das kein Leerraum ist. Ohne dieses Nachruecken
       * zeigt jede Zeilennummer auf das Zeilenende der VORIGEN Regel — die Meldung waere
       * durchgehend um eine Zeile daneben. */
      let s = selStart;
      while (s < i && /\s/.test(roh[s])) s++;
      const kopf = roh.slice(s, i).trim();
      if (kopf.charAt(0) === '@') { stapel.push(kopf); i++; selStart = i; continue; }
      let j = i + 1, t = 1;
      while (j < roh.length && t > 0) { if (roh[j] === '{') t++; else if (roh[j] === '}') t--; j++; }
      out.push({
        kopf: kopf, body: roh.slice(i + 1, j - 1), at: stapel.join(' | '),
        datei: datei, zeichen: ortVon(s), band: band
      });
      i = j; selStart = i; continue;
    }
    if (c === '}') { stapel.pop(); i++; selStart = i; continue; }
    i++;
  }
  return out;
}

function deklarationen(body) {
  const roh = [];
  let tiefe = 0, start = 0;
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (c === '(') tiefe++;
    else if (c === ')') tiefe--;
    else if (c === ';' && tiefe === 0) { roh.push(body.slice(start, i)); start = i + 1; }
  }
  roh.push(body.slice(start));
  const res = [];
  roh.forEach(function (d) {
    const k = d.indexOf(':');
    if (k < 0) return;
    const name = d.slice(0, k).trim().toLowerCase();
    if (!name || /\s/.test(name)) return;
    let wert = d.slice(k + 1).trim();
    let wichtig = false;
    if (/!\s*important\s*$/i.test(wert)) {
      wichtig = true;
      wert = wert.replace(/!\s*important\s*$/i, '').trim();
    }
    res.push({ name: name, wert: wert, wichtig: wichtig });
  });
  return res;
}

function zeileVon(text, zeichen) {
  let n = 1;
  for (let i = 0; i < zeichen && i < text.length; i++) if (text[i] === '\n') n++;
  return n;
}

/* ==========================================================================================
 * 3 · EINLESEN UND ORDNEN
 * ========================================================================================== */

const DATEIEN = {};
function lies(rel) {
  if (!DATEIEN[rel]) DATEIEN[rel] = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  return DATEIEN[rel];
}

const APP = 'ui/app/index.html';
const GLASS = 'ui/shared/glass.css';
const FERN = 'tools/web-fern-modul.html';

function versetzt(v) { return function (p) { return v + p; }; }

let REGELN = [];
(function einlesen() {
  const app = lies(APP);
  /* Die Reihenfolge entscheidet bei gleicher Spezifitaet, welche Regel gewinnt. index.html
   * bindet glass.css MITTEN im Dokument ein — Stilbloecke davor verlieren gegen glass.css,
   * die danach gewinnen. Wer glass.css pauschal ans Ende sortiert, bekommt fuer §7 des
   * zweiten Blocks (ab Zeile 5460) die falschen Farben. */
  const glassLink = app.indexOf('shared/glass.css');
  stilbloecke(app).forEach(function (b) {
    REGELN = REGELN.concat(regelnLesen(b.css, versetzt(b.versatz), APP, b.versatz < glassLink ? 0 : 2));
  });
  REGELN = REGELN.concat(regelnLesen(lies(GLASS), versetzt(0), GLASS, 1));

  const fern = lies(FERN);
  stilbloecke(fern).forEach(function (b) {
    REGELN = REGELN.concat(regelnLesen(b.css, versetzt(b.versatz), FERN, 3));
  });
  const inj = eingesetzterStil(fern);
  if (inj) {
    REGELN = REGELN.concat(regelnLesen(inj.css, function (p) { return ausKarte(inj.karte, p); }, FERN, 4));
  }
})();

/*
 * WELCHE SELEKTOREN GEHOEREN UEBERHAUPT ZU DIESER ANWENDUNG?
 * glass.css ist die gemeinsame Vorlage der ganzen VET-PHARM-Familie (Hæmatica, Metabolica,
 * Reise, Atlas ...). Sie gestaltet Bausteine, die es in VetStation gar nicht gibt — .atlas,
 * .country-card, .disease-btn, .detail-title, .logo-icon und ein Dutzend mehr. Wer sie
 * mitmisst, bekommt einen Bericht, in dem die echten Fehlstellen zwischen Meldungen ueber
 * fremde Anwendungen untergehen, und aendert am Ende eine Datei, die drei andere Module
 * benutzen. Gemessen wird deshalb nur, was im Markup ODER im Code dieser Anwendung vorkommt.
 * Geprueft wird der ERSTE Klassen-/Kennungsname des Selektors: Zustandsklassen werden oft
 * zusammengesetzt ('medwarn lvl-'+stufe) und stuenden sonst nirgends woertlich.
 */
const MARKUP = (function () {
  const t = lies(APP) + '\n' + lies(FERN) + '\n' +
            fs.readFileSync(path.join(ROOT, 'ui/shared/vetpharm-ui.js'), 'utf8');
  return t
    /* Die Stilbloecke selbst zaehlen nicht als Verwendung — sonst gilt jede Regel als benutzt,
     * nur weil sie existiert, und der Filter prueft gar nichts mehr. */
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
    /* Eigenschaftszugriffe im JavaScript sind keine Klassennamen. Ohne diese Zeile gilt die
     * fremde Klasse .search als benutzt, weil irgendwo "zeile.search(" steht — und glass.css
     * bekommt zwei Meldungen ueber ein Modul, das gar nicht hier lebt. */
    .replace(/[\w$\])]\s*\.\s*[\w$]+/g, ' ');
})();

function inDieserAnwendung(ziel) {
  const erstes = /^[^\s>+~]+/.exec(ziel);
  if (!erstes) return true;
  const namen = erstes[0].match(/[.#]([\w-]+)/g);
  if (!namen || !namen.length) return true;         /* reine Elementselektoren: immer messen */
  const n = namen[0].slice(1);
  /* Auf Wortgrenzen suchen. Eine blosse Teilzeichenkette haelt ".search" fuer benutzt, weil
   * irgendwo "dsearch" steht — und misst dann eine Regel eines fremden Moduls an einem
   * VetStation-Grund. Gemessen 21.08.2026: genau dieser Treffer war der einzige Fehlalarm
   * des Filters. */
  return new RegExp('(^|[^\\w-])' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^\\w-]|$)').test(MARKUP);
}

/* Variablentabelle des HELLMODUS: :root liefert die Grundwerte, html[data-theme="light"]
 * ueberschreibt sie. Nur damit steht var(--muted) hier fuer #56657a und nicht fuer #9aa8bb. */
const VARS = {};
REGELN.forEach(function (r) {
  if (r.at) return;
  const kopf = r.kopf.trim();
  const istRoot = kopf === ':root' || kopf === 'html';
  const istLicht = kopf === 'html[data-theme="light"]';
  if (!istRoot && !istLicht) return;
  deklarationen(r.body).forEach(function (d) {
    if (d.name.indexOf('--') !== 0) return;
    if (istLicht || !Object.prototype.hasOwnProperty.call(VARS, d.name)) VARS[d.name] = d.wert;
  });
});

/* ==========================================================================================
 * 4 · SELEKTOREN, SPEZIFITAET, PASSUNG
 * ========================================================================================== */

function spezifitaet(sel) {
  let a = 0, b = 0, c = 0;
  let s = sel.replace(/::[a-z-]+/g, function () { c++; return ' '; });
  s = s.replace(/#[\w-]+/g, function () { a++; return ' '; });
  s = s.replace(/\[[^\]]*\]/g, function () { b++; return ' '; });
  s = s.replace(/\.[\w-]+/g, function () { b++; return ' '; });
  s = s.replace(/:[a-z-]+(\([^)]*\))?/g, function () { b++; return ' '; });
  s.split(/[\s>+~]+/).forEach(function (t) { if (/^[a-z][\w-]*$/i.test(t.trim())) c++; });
  return a * 10000 + b * 100 + c;
}

/* Ein Selektor wird in Verbindungsstuecke zerlegt (".fl-al .phys" -> [".fl-al", ".phys"]) und
 * jedes Stueck in seine einfachen Teile. ">" wird wie " " behandelt, siehe Dateikopf. */
function zerlegen(sel) {
  return sel.replace(/\s*[>+~]\s*/g, ' ').trim().split(/\s+/).map(function (st) {
    const muster = /(::[a-z-]+|#[\w-]+|\.[\w-]+|\[[^\]]*\]|:[a-z-]+(\([^)]*\))?|\*|^[a-z][\w-]*)/gi;
    const teile = st.match(muster) || [];
    return { roh: st, teile: teile };
  });
}

/* Passt Regel-Selektor R auf Ziel-Selektor Z? R muss als Teilfolge in Z vorkommen und mit
 * demselben letzten Stueck enden. Damit gewinnt "html[data-theme=light] .tab{...!important}"
 * auch ueber ".tab.active{color:#fff}" — genau wie im Browser. Ohne diese Passung haette
 * jedes Ziel nur seine woertlich gleiche Regel gesehen und der aktive Reiter waere im
 * Hellmodus als weisse Schrift gemeldet worden, obwohl er dunkel ist. */
function stueckPasst(rStueck, zStueck) {
  for (let i = 0; i < rStueck.teile.length; i++) {
    const t = rStueck.teile[i];
    if (t === '*') continue;
    if (zStueck.teile.indexOf(t) < 0) return false;
  }
  return true;
}
function passt(rTeile, zTeile) {
  if (!rTeile.length || rTeile.length > zTeile.length) return false;
  if (!stueckPasst(rTeile[rTeile.length - 1], zTeile[zTeile.length - 1])) return false;
  let zi = zTeile.length - 2;
  for (let ri = rTeile.length - 2; ri >= 0; ri--) {
    let gefunden = false;
    while (zi >= 0) {
      if (stueckPasst(rTeile[ri], zTeile[zi])) { gefunden = true; zi--; break; }
      zi--;
    }
    if (!gefunden) return false;
  }
  return true;
}

const THEMA_LICHT = /^html\[data-theme="light"\]\s*/;

/* Alle im Hellmodus wirksamen Einzelregeln, jede mit Rang. */
const EINZEL = [];
REGELN.forEach(function (r) {
  /* @media print ist kein Bildschirm. @keyframes setzt keinen Dauerzustand. Bildschirm-
   * Medienabfragen setzen in diesen drei Dateien nachweislich KEINE Farbe (nachgezaehlt
   * 21.08.2026: vier color-Regeln in @media, alle vier in @media print) — ihre Schriftgroessen
   * werden weiter unten trotzdem beruecksichtigt, und zwar mit dem kleinsten Wert. */
  if (/^@keyframes/.test(r.at) || /^@media\s*print/.test(r.at)) return;
  const dek = deklarationen(r.body);
  if (!dek.length) return;
  r.kopf.split(',').forEach(function (sel) {
    sel = sel.trim().replace(/\s+/g, ' ');
    if (!sel) return;
    if (/\[data-theme="dark"\]/.test(sel)) return;
    /* html[data-vp-*] sind ausdrueckliche Nutzereinstellungen (Schriftgroesse, hoher Kontrast).
     * Gemessen wird die Vorgabe, nicht jede Einstellung — sonst misst der Test einen Zustand,
     * den fast niemand hat, und schweigt zu dem, den alle sehen. */
    if (/\[data-vp-/.test(sel)) return;
    const ziel = sel.replace(THEMA_LICHT, '');
    if (!ziel) return;
    EINZEL.push({
      sel: sel, ziel: ziel, teile: zerlegen(ziel), dek: dek,
      spez: spezifitaet(sel), rang: r.band * 100000000 + r.zeichen,
      datei: r.datei, zeichen: r.zeichen, media: r.at
    });
  });
});

function rangKleiner(a, b) {
  if (a.wichtig !== b.wichtig) return a.wichtig ? 1 : -1;
  if (a.spez !== b.spez) return a.spez < b.spez ? -1 : 1;
  return a.rang < b.rang ? -1 : (a.rang > b.rang ? 1 : 0);
}

/* Alle auf ein Ziel passenden Deklarationen einer Eigenschaft, aufsteigend nach Kaskadenrang. */
function anwendbar(zielTeile, namen) {
  const treffer = [];
  EINZEL.forEach(function (e) {
    let hat = false;
    for (let i = 0; i < e.dek.length; i++) if (namen.indexOf(e.dek[i].name) >= 0) { hat = true; break; }
    if (!hat) return;
    if (!passt(e.teile, zielTeile)) return;
    e.dek.forEach(function (d) {
      if (namen.indexOf(d.name) < 0) return;
      treffer.push({
        name: d.name, wert: d.wert, wichtig: d.wichtig, spez: e.spez, rang: e.rang,
        datei: e.datei, zeichen: e.zeichen, sel: e.sel, media: e.media
      });
    });
  });
  treffer.sort(rangKleiner);
  return treffer;
}

/* ==========================================================================================
 * 5 · GRUENDE — die ausdrueckliche Zuordnung "Selektor -> Kasten, in dem er liegt"
 * ==========================================================================================
 * Erster Treffer gewinnt, deshalb steht das Speziellere oben. Der zweite Eintrag ist der
 * Selektor des Kastens; sein Grund wird mit derselben Kaskade ausgerechnet und rekursiv
 * ueber seinen eigenen Kasten gelegt. Die Kette endet immer bei "body", und body hat einen
 * festen Wert (siehe WURZEL).
 */
const GRUENDE = [
  /* --- die Kaesten selbst: worauf LIEGEN sie? (muessen zuerst stehen, sonst zeigt der
         Familieneintrag darunter auf den Kasten selbst und die Aufloesung dreht sich im
         Kreis) ------------------------------------------------------------------------- */
  [/^\.card$/, 'body'],
  [/^header$/, 'body'],
  [/^\.tabs$/, 'body'],
  [/^\.patient$/, 'body'],
  [/^\.vp-nav-panel$/, 'body'],
  [/^\.vp-set-panel$/, 'body'],
  [/^\.vp-tip$/, 'body'],
  [/^\.welcome-box$/, 'body'],
  [/^#vetlive-bar$/, 'body'],
  [/^\.vl-box$/, 'body'],
  [/^#druckvorschau$/, 'body'],

  /* --- Fern-Ansicht (tools/web-fern-modul.html) --------------------------------------- */
  [/^\.vl-/, '.vl-box'],                          // Anmelde-/Registrierfenster ueber allem
  [/^#vetlive-(login|signup)/, '.vl-box'],
  [/^#vetlive-launch/, 'header'],                 // sitzt in der Kopfleiste neben "CPR"
  [/^(\.vetlive-|#vetlive-bar)/, '#vetlive-bar'], // Statusleiste oben, samt Saal-Tafel darin
  [/^(\.fl-|#fernlive)/, '.card'],                // Fern-Live-Reiter: alles liegt in Karten
  [/^\.medwarn/, '.card'],                        // Rassewarnung in der Protokolltabelle
  [/^\.medbreed/, '.card'],

  /* --- Chrome der Anwendung ------------------------------------------------------------ */
  [/^(header|\.title|\.brand|\.logo|\.subtitle)/, 'header'],
  [/^(\.vp-gear|\.vp-hamburger|\.vp-theme-toggle|\.vp-fab-bar)/, 'header'],
  [/^(\.tab|\.mode-tab)/, '.tabs'],
  [/^(\.patient|\.sp-chip|\.pfield|\.pchip-note|\.breed-)/, '.patient'],
  [/^\.disc/, 'body'],                            // Haftungshinweis liegt frei unter dem Kopf
  [/^(\.vp-nav|\.vp-brand-tx|\.vp-qlink)/, '.vp-nav-panel'],
  [/^(\.vp-set|\.vp-seg)/, '.vp-set-panel'],
  [/^\.vp-tip/, '.vp-tip'],
  [/^\.welcome-(feat|disc)/, '.welcome-box'],
  [/^\.nf-(dock|fab|lbl)/, 'body'],               // Notfall-Dock schwebt fest ueber der Seite

  /* --- was IN der dunklen Geraeteflaeche sitzt, aber nicht zu ihr gehoert ---------------
   * .af-src ist die Quellenmarke der Atemfrequenz und wird in index.html:2391 IN eine
   * Messkachel gezeichnet. Sie steht deshalb nicht auf der Karte, sondern auf #0b1017 —
   * und wird gemessen, nicht uebersprungen: fuer .af-monitor gibt es nur eine helle
   * HINTERGRUND-Regel, die Schriftfarbe bleibt var(--muted) und kippt im Hellmodus von
   * #9aa8bb nach #56657a. Dunkelgrau auf Fastschwarz. Genau diese halben Umstellungen
   * soll der Waechter finden. */
  [/^\.af-src/, '.mon-tile']
];

/*
 * Einzelfaelle, in denen der Kasten NICHT im Selektor steht und der Vorfahre im Selektor
 * ihn auch nicht traegt. Diese Liste schlaegt alles andere.
 * .la-out bekommt seinen Grund erst mit einer Zustandsklasse (.ok/.warn/.tox); ".la-out b"
 * nennt keine, das Markup setzt aber immer eine. Genommen wird .ok, weil sie fuer helle
 * Schrift die guenstigste Zahl ergibt — wer meldet, soll mit dem mildesten Wert melden.
 */
const SONDERGRUND = [
  [/^\.la-out b$/, '.la-out.ok']
];

/* Feste Wurzeln. Sie werden NICHT aus der Kaskade geholt, weil sie es dort nicht sauber gibt:
 * body traegt im Hellmodus background-color:#e9eef7 !important UND drei radiale Schleier
 * ("Aurora"), die nur Ecken einfaerben. Wer die mitmittelt, bekommt fuer die ganze Seite einen
 * Grund, den sie an keiner Stelle wirklich hat — und damit fuer jeden Text der Anwendung eine
 * Zahl, die 8 % daneben liegt. Gemessen wird deshalb gegen die erklaerte Grundfarbe. */
const WURZEL = { 'body': '#e9eef7' };

/*
 * Der Grund, auf dem ein Selektor liegt.
 *
 * Zwei Quellen, in dieser Reihenfolge:
 *   1. Nennt der Selektor selbst einen Vorfahren (".vl-box .vl-sub"), wird DESSEN Grund
 *      benutzt. Das ist keine Heuristik, sondern steht woertlich im Selektor.
 *   2. Bleibt nur ein Stueck uebrig (".fl-al" allein), entscheidet die Zuordnung oben —
 *      denn ab hier sagt die Stilvorlage nichts mehr darueber, wo das Element steht.
 * Zum Schluss wird der eigene Hintergrund darueber gelegt; ist er halbdurchsichtig oder gar
 * nicht gesetzt, scheint der Grund darunter durch. Genau so rechnet der Browser auch.
 */
const GRUND_CACHE = {};
function grundVon(zielRoh, tiefe) {
  const ziel = zielRoh.replace(THEMA_LICHT, '').trim();
  if ((tiefe || 0) > 12) return farbeLesen(WURZEL.body, VARS);
  if (Object.prototype.hasOwnProperty.call(WURZEL, ziel)) return farbeLesen(WURZEL[ziel], VARS);
  if (Object.prototype.hasOwnProperty.call(GRUND_CACHE, ziel)) return GRUND_CACHE[ziel];

  const stuecke = ziel.replace(/\s*[>+~]\s*/g, ' ').split(/\s+/).filter(function (s) { return s; });
  let elternSel = null;
  for (let s = 0; s < SONDERGRUND.length; s++) {
    if (SONDERGRUND[s][0].test(ziel)) { elternSel = SONDERGRUND[s][1]; break; }
  }
  if (elternSel === null && stuecke.length > 1) {
    elternSel = stuecke.slice(0, stuecke.length - 1).join(' ');
  }
  if (elternSel === null) {
    elternSel = '.card';                        /* Rueckfall, siehe Dateikopf */
    for (let i = 0; i < GRUENDE.length; i++) {
      if (GRUENDE[i][0].test(ziel)) { elternSel = GRUENDE[i][1]; break; }
    }
  }
  if (elternSel === ziel) elternSel = 'body';    /* Selbstbezug abfangen */
  const eltern = grundVon(elternSel, (tiefe || 0) + 1);
  const eigen = eigenerGrund(ziel);
  const erg = ueberlagern(eigen, eltern);
  GRUND_CACHE[ziel] = erg;
  return erg;
}

/* Der eigene Grund eines Selektors. background ist eine Kurzform und setzt Farbe UND Bild
 * zurueck — wer das nicht nachbildet, laesst die dunkle Grundfarbe aus dem Dunkelmodus stehen
 * und rechnet helle Schrift auf dunkel: der Test waere dann ueberall gruen. */
function eigenerGrund(ziel) {
  const teile = zerlegen(ziel);
  const dek = anwendbar(teile, ['background', 'background-color', 'background-image']);
  let farbe = null, bild = null;
  dek.forEach(function (d) {
    if (d.name === 'background') {
      farbe = null; bild = null;
      const v = verlaufMitteln(d.wert, VARS);
      if (v) bild = v;
      /* Bei "background:<farbe>" bleibt nach dem Entfernen aller Funktionsaufrufe genau die
       * Farbe uebrig; bei "background:url(...) #fff" ebenso. */
      const ohneFn = /(linear|radial|conic|repeating-linear)-gradient\([\s\S]*?\)(?=[,\s]|$)/gi;
      const rest = d.wert.replace(ohneFn, ' ').replace(/url\([^)]*\)/gi, ' ').trim();
      const f = farbeLesen(rest.split(/\s+/)[0], VARS) || farbeLesen(rest, VARS);
      if (f) farbe = f;
    } else if (d.name === 'background-color') {
      farbe = farbeLesen(d.wert, VARS);
    } else if (d.name === 'background-image') {
      const v = verlaufMitteln(d.wert, VARS);
      bild = v || null;
    }
  });
  if (!bild && !farbe) return null;
  if (!bild) return farbe;
  if (!farbe) return bild;
  /* Das Bild liegt ueber der Farbe. */
  const unter = { r: farbe.r, g: farbe.g, b: farbe.b, a: farbe.a };
  const oben = ueberlagern(bild, unter.a >= 1 ? unter : { r: unter.r, g: unter.g, b: unter.b, a: 1 });
  const deck = bild.a + farbe.a * (1 - bild.a);
  return { r: oben.r, g: oben.g, b: oben.b, a: Math.min(1, deck) };
}

/* ==========================================================================================
 * 6 · AUSNAHMEN — Flaechen, die in BEIDEN Farbschemata absichtlich dunkel sind
 * ==========================================================================================
 * Jeder Eintrag nennt den Grund. Ohne diese Liste faerbt der Test genau die Stellen rot, die
 * mit Absicht so aussehen — und wird deshalb abgeschaltet statt benutzt.
 */
const AUSNAHMEN = [
  /* ACHTUNG BEIM ERWEITERN: die Muster sind absichtlich eng. Ein weites ".dev-" haette auch
   * .dev-row und .dev-modes verschluckt — und die sind im Hellmodus HELL (glass.css:494-501
   * gibt ihnen eigene helle Gruende). Genau dort steckte eine echte Fehlstelle. Wer die Liste
   * grosszuegig schreibt, macht den Waechter blind fuer die Nachbarschaft dessen, was er
   * schuetzen soll. */
  [new RegExp('^(\\.mon-(screen|tile|tiles|lane|lanes|in|alarm)|\\.mt-|\\.mc-' +
              '|\\.dev-(head|brand|al|mon)|\\.vs-|\\.vent-screen|\\.gaswahl|\\.ck-links \\.(mc-|mon-))'),
   'Bild des virtuellen Geraets samt Messkacheln. Ein Patientenmonitor ist schwarz; ' +
   'glass.css:469-471 nagelt .mon-screen/.mon-tile/.mon-in auch im Hellmodus mit ' +
   '!important auf #05080d bzw. #0b1017 fest.'],

  [/^(#ekgOverlay|#ekgPdfView|\.ekg-|table\.ekg-eich|\.m3d-|\.th2|\.rh-karte|\.rh-mehr)/,
   'Diagnostik-EKG-Overlay (#ekgOverlay{background:#05080d}, ohne Hellregel). Ein EKG-Schirm ist dunkel, ' +
   'damit die Kurve traegt; .rh-karte, .th2 und .m3d-* werden ausschliesslich in ' +
   '#ekgTipps darin gezeichnet.'],

  [/^(\.cpr-|html\.cpr-offen)/,
   'CPR-Fenster. Seit 21.08.2026 ausdruecklich in beiden Schemata dunkel — ' +
   'index.html:5770-5781 begruendet ' +
   'das: zwoelf helle Farben nachzuziehen waere die halbe Umstellung, die beim naechsten Umbau wieder ' +
   'auseinanderfaellt. Rot auf Dunkel ist ausserdem die kraeftigste Warnfarbe, die es gibt.'],

  [/^#druckvorschau \.dv-(back|foot|title|head)/,
   'Huelle der Druckvorschau (#druckvorschau{background:#0a0c10}). Sie rahmt das weisse Blatt und ist ' +
   'bewusst dunkel, damit das Blatt als Blatt erkennbar bleibt. Das Blatt selbst wird gemessen.'],

  [/^(\.canvas-box|\.canvas-container|\.canvas3d|\.video-box|\.vp-mol-stage|\.atlas)/,
   'Kern-Leinwaende (3D-Szene, Molekuele, Karte, Video). glass.css:8-11 nennt sie ausdruecklich als ' +
   'in beiden Themen dunkel gelassen — sie rendern genau wie entworfen, gerahmt vom hellen Glas.']
];

function ausnahmeFuer(ziel) {
  for (let i = 0; i < AUSNAHMEN.length; i++) if (AUSNAHMEN[i][0].test(ziel)) return AUSNAHMEN[i][1];
  return null;
}

/* ==========================================================================================
 * 7 · SCHRIFTGROESSE UND -GEWICHT (fuer die 3.0-Schwelle)
 * ========================================================================================== */

function pxAus(wert, elternPx) {
  if (!wert) return null;
  const t = String(wert).trim();
  /* clamp(min,ideal,max): der kleinste Wert ist der, bei dem die Schwelle am strengsten ist. */
  const cl = /^clamp\(([^,]+),/i.exec(t);
  if (cl) return pxAus(cl[1], elternPx);
  const px = /(-?[\d.]+)px/i.exec(t);
  if (px) return parseFloat(px[1]);
  const em = /^(-?[\d.]+)(em|rem)$/i.exec(t);
  if (em) return parseFloat(em[1]) * (em[2].toLowerCase() === 'rem' ? 16 : elternPx);
  const pr = /^(-?[\d.]+)%$/.exec(t);
  if (pr) return parseFloat(pr[1]) / 100 * elternPx;
  return null;
}

/* Die font-Kurzform ist in diesem Baum haeufig ("font:800 22px/1.15 ...", "font:11px var(--mono)").
 * Wer sie nicht liest, haelt jede so gesetzte Zahl fuer 16 px und wendet die falsche Schwelle an. */
function ausKurzform(wert, elternPx) {
  const m = /(^|\s)(-?[\d.]+(px|em|rem|%))\s*(\/[^\s]+)?(\s|$)/.exec(wert);
  const groesse = m ? pxAus(m[2], elternPx) : null;
  const g = /(^|\s)(bold|bolder|[1-9]00)(\s|$)/i.exec(wert);
  let gewicht = null;
  if (g) gewicht = /bold/i.test(g[2]) ? 700 : parseInt(g[2], 10);
  return { groesse: groesse, gewicht: gewicht };
}

/*
 * Schriftgroesse und -gewicht eines Ziels.
 *
 * VERERBUNG WIRD MITGERECHNET, und zwar entlang derselben Kette wie der Grund: erst der
 * Selektor selbst, dann seine Vorfahren, dann der Kasten aus der Zuordnung. Ohne das gilt
 * fuer ".vetlive-saal .s-ger .a" die Vorgabe 16 px, obwohl .s-ger 10,5 px setzt — und die
 * Meldung nennt eine Groesse, die es nicht gibt. Die SCHWELLE wird davon nicht milder:
 * kleiner heisst strenger, und im Zweifel bleibt es bei 4.5.
 */
function schriftKette(ziel, tiefe) {
  const eigen = schrift(ziel, 16);
  if (eigen.groesse !== null && eigen.gewicht !== null) return eigen;
  if ((tiefe || 0) > 12) return eigen;

  const stuecke = ziel.replace(/\s*[>+~]\s*/g, ' ').split(/\s+/).filter(function (s) { return s; });
  let elternSel = null;
  if (stuecke.length > 1) elternSel = stuecke.slice(0, stuecke.length - 1).join(' ');
  else {
    for (let i = 0; i < GRUENDE.length; i++) {
      if (GRUENDE[i][0].test(ziel)) { elternSel = GRUENDE[i][1]; break; }
    }
  }
  if (!elternSel || elternSel === ziel || elternSel === 'body') return eigen;
  const oben = schriftKette(elternSel, (tiefe || 0) + 1);
  return {
    groesse: eigen.groesse !== null ? eigen.groesse : oben.groesse,
    gewicht: eigen.gewicht !== null ? eigen.gewicht : oben.gewicht,
    geerbt: eigen.groesse === null && oben.groesse !== null
  };
}

function schrift(ziel, elternPx) {
  const teile = zerlegen(ziel);
  const dek = anwendbar(teile, ['font-size', 'font-weight', 'font']);
  let groesse = null, gewicht = null;
  dek.forEach(function (d) {
    if (d.name === 'font-size') { const p = pxAus(d.wert, elternPx); if (p !== null) groesse = p; }
    else if (d.name === 'font-weight') {
      if (/bold/i.test(d.wert)) gewicht = 700;
      else { const n = parseInt(d.wert, 10); if (!isNaN(n)) gewicht = n; }
    } else if (d.name === 'font') {
      const k = ausKurzform(d.wert, elternPx);
      if (k.groesse !== null) groesse = k.groesse;
      gewicht = k.gewicht !== null ? k.gewicht : 400;
    }
  });
  /* Bildschirm-Medienabfragen aendern Schriftgroessen. Beruecksichtigt wird der KLEINSTE Wert,
   * denn er ergibt die strengere Schwelle — ein Text, der auf dem Handy 15 px klein wird, darf
   * nicht mit der Grossschrift-Schwelle 3.0 durchrutschen. */
  REGELN.forEach(function (r) {
    if (!/^@media/.test(r.at) || /^@media\s*print/.test(r.at)) return;
    r.kopf.split(',').forEach(function (sel) {
      sel = sel.trim().replace(/\s+/g, ' ');
      if (!sel || /\[data-theme="dark"\]/.test(sel) || /\[data-vp-/.test(sel)) return;
      if (!passt(zerlegen(sel.replace(THEMA_LICHT, '')), teile)) return;
      deklarationen(r.body).forEach(function (d) {
        let p = null;
        if (d.name === 'font-size') p = pxAus(d.wert, elternPx);
        else if (d.name === 'font') p = ausKurzform(d.wert, elternPx).groesse;
        if (p !== null && (groesse === null || p < groesse)) groesse = p;
      });
    });
  });
  return { groesse: groesse, gewicht: gewicht };
}

/* WCAG 1.4.3: 4.5 fuer normalen Text, 3.0 ab 24 px oder ab 18.66 px in Fettschrift. */
function schwelleFuer(groesse, gewicht) {
  const g = groesse === null ? 16 : groesse;
  const w = gewicht === null ? 400 : gewicht;
  if (g >= 24) return 3.0;
  if (g >= 18.66 && w >= 700) return 3.0;
  return 4.5;
}

/* ==========================================================================================
 * 8 · GEGENPROBE
 * ==========================================================================================
 * Ohne sie misst niemand, ob der Waechter ueberhaupt messen kann. Sie rechnet bekannte
 * Paarungen durch — darunter #767676 auf Weiss, die von der WCAG selbst genannte Grenzfarbe
 * (4.54, also gerade noch bestanden) und ihr Nachbar #777777 (4.48, also gerade durchgefallen).
 * Wer nur "hell gegen dunkel" prueft, merkt einen Vorzeichen- oder Gamma-Fehler nicht.
 */
function gegenprobe() {
  const proben = [];
  function nah(was, ist, soll, tol) {
    proben.push({ was: was, ok: Math.abs(ist - soll) <= tol, ist: ist, soll: soll });
  }
  const w = { r: 255, g: 255, b: 255, a: 1 };
  const s = { r: 0, g: 0, b: 0, a: 1 };

  nah('Schwarz auf Weiss ist 21', kontrast(s, w), 21, 0.01);
  nah('Weiss auf Weiss ist 1', kontrast(w, w), 1, 0.001);
  nah('bekannt GUT  #15202e auf #ffffff', kontrast(farbeLesen('#15202e', {}), w), 16.43, 0.02);
  nah('bekannt SCHLECHT #9aa8bb auf #ffffff', kontrast(farbeLesen('#9aa8bb', {}), w), 2.42, 0.05);
  nah('WCAG-Grenzfarbe #767676 auf Weiss', kontrast(farbeLesen('#767676', {}), w), 4.54, 0.02);
  nah('knapp darunter  #777777 auf Weiss', kontrast(farbeLesen('#777777', {}), w), 4.48, 0.02);

  /* Falle b: halbdurchsichtig ueber Grund gerechnet, nicht als Vollton. */
  const halb = ueberlagern(farbeLesen('rgba(0,0,0,.5)', {}), w);
  nah('rgba(0,0,0,.5) ueber Weiss ergibt Grau', halb.r, 127.5, 0.6);
  nah('und dessen Kontrast zu Weiss', kontrast(halb, w), 3.95, 0.05);

  /* Falle a: ein Verlauf darf nicht als durchsichtig (= schwarz) gelesen werden. */
  const verlauf = verlaufMitteln('linear-gradient(180deg,#ffffff,#eef7fd)', {});
  proben.push({ was: 'Verlauf wird gelesen statt als durchsichtig gemeldet',
                ok: !!verlauf && verlauf.a >= 0.99 && verlauf.r > 240,
                ist: verlauf ? hex(verlauf) : 'null', soll: 'hell, deckend' });
  const nurBild = eigenerGrundProbe('linear-gradient(180deg,rgba(255,255,255,.72),rgba(255,255,255,.56))');
  proben.push({ was: 'Glaskarte ueber #e9eef7 wird hell, nicht schwarz',
                ok: nurBild.r > 240 && nurBild.g > 240, ist: hex(nurBild), soll: 'heller als #f0f0f0' });

  /* Die Einordnung selbst: dieselbe Farbe muss je nach Schriftgroesse anders bewertet werden. */
  function schwelle(was, g, w, soll) {
    proben.push({ was: was, ok: schwelleFuer(g, w) === soll, ist: schwelleFuer(g, w), soll: soll });
  }
  schwelle('Schwelle 4.5 fuer normalen Text', 13, 400, 4.5);
  schwelle('Schwelle 3.0 ab 18.66px fett', 18.66, 700, 3.0);
  schwelle('18.66px NICHT fett bleibt bei 4.5', 18.66, 400, 4.5);
  schwelle('Schwelle 3.0 ab 24px', 24, 400, 3.0);

  /* Die Variablenaufloesung ist der Unterschied zwischen 2,4 und 5,4 — sie gehoert geprueft. */
  proben.push({ was: 'var(--muted,#9aa8bb) ist im Hellmodus #56657a',
                ok: hex(farbeLesen('var(--muted,#9aa8bb)', VARS)) === '#56657a',
                ist: hex(farbeLesen('var(--muted,#9aa8bb)', VARS)), soll: '#56657a' });

  /* Und die Selektor-Passung, ohne die der aktive Reiter falsch gemessen wuerde. */
  proben.push({ was: '".tab" passt auf ".tab.active"', ist: '', soll: 'passt',
                ok: passt(zerlegen('.tab'), zerlegen('.tab.active')) });
  proben.push({ was: '".fl-kv .k" passt NICHT auf ".fl-tile .k"', ist: '', soll: 'passt nicht',
                ok: !passt(zerlegen('.fl-kv .k'), zerlegen('.fl-tile .k')) });

  return proben;
}
function eigenerGrundProbe(bg) {
  return ueberlagern(verlaufMitteln(bg, VARS), farbeLesen(WURZEL.body, VARS));
}

/* ==========================================================================================
 * 9 · LAUF
 * ========================================================================================== */

console.log('\n===============================================================');
console.log('  KONTRAST IM HELLMODUS  (WCAG 2.1, Schwelle 4.5 / 3.0)');
console.log('===============================================================\n');

console.log('GEGENPROBE — kann der Rechner ueberhaupt rechnen?');
const proben = gegenprobe();
let probeFehler = 0;
proben.forEach(function (p) {
  if (p.ok) { if (ALLES) console.log('  + ' + p.was); }
  else { probeFehler++; console.log('  ! ' + p.was + '   gemessen ' + p.ist + ', erwartet ' + p.soll); }
});
console.log('  ' + (proben.length - probeFehler) + ' von ' + proben.length + ' Proben richtig eingeordnet' +
            (ALLES ? '' : '  (--alle zeigt sie einzeln)'));
console.log('');

/* Alle Ziele mit einer erklaerten Schriftfarbe einsammeln. */
const ZIELE = {};
EINZEL.forEach(function (e) {
  let hat = false;
  for (let i = 0; i < e.dek.length; i++) {
    if (e.dek[i].name === 'color' || e.dek[i].name === '-webkit-text-fill-color') { hat = true; break; }
  }
  if (hat) ZIELE[e.ziel] = true;
});

const treffer = [];
const bestanden = [];
const uebersprungen = [];

const fremd = [];

Object.keys(ZIELE).sort().forEach(function (ziel) {
  const aus = ausnahmeFuer(ziel);
  if (aus) { uebersprungen.push({ ziel: ziel, warum: aus }); return; }
  if (!inDieserAnwendung(ziel)) { fremd.push(ziel); return; }

  const teile = zerlegen(ziel);
  /* -webkit-text-fill-color schlaegt color bei der Textdarstellung. glass.css benutzt das fuer
   * die Kopfzeile (erst transparent fuer den Farbverlauf-Text, spaeter wieder deckend). Wer nur
   * color liest, meldet dort eine Farbe, die gar nicht gemalt wird. */
  const dek = anwendbar(teile, ['color', '-webkit-text-fill-color']);
  if (!dek.length) return;
  let sieger = null;
  dek.forEach(function (d) {
    if (!sieger) { sieger = d; return; }
    const fuellt = function (x) { return x.name === '-webkit-text-fill-color' ? x.spez + 1 : x.spez; };
    const a = { wichtig: d.wichtig, spez: fuellt(d), rang: d.rang };
    const b = { wichtig: sieger.wichtig, spez: fuellt(sieger), rang: sieger.rang };
    if (rangKleiner(a, b) >= 0) sieger = d;
  });

  const farbe = farbeLesen(sieger.wert, VARS);
  if (!farbe) {
    uebersprungen.push({ ziel: ziel, warum: 'Farbe erst zur Laufzeit bestimmt (' + sieger.wert + ')' });
    return;
  }
  if (farbe.a <= 0) {
    uebersprungen.push({ ziel: ziel, warum: 'durchsichtige Schrift (Zierelement)' });
    return;
  }

  const grund = grundVon(ziel, 0);
  if (grund.unmessbar) {
    uebersprungen.push({ ziel: ziel, warum: 'Grund ist ein Kegelverlauf (conic-gradient) — ein ' +
      'Mittelwert ueber den ganzen Farbkreis waere erfunden' });
    return;
  }
  const eigen = eigenerGrund(ziel);
  /* Schrift und eigener Grund exakt gleich: das ist kein unlesbarer Text, das ist gar keiner.
   * Die Statuspunkte der Fern-Leiste setzen color nur, damit box-shadow ueber currentColor
   * dieselbe Farbe bekommt (.vetlive-conn i, 9x9 px, ohne Inhalt). Wer solche Stellen meldet,
   * meldet Kreise als unleserliche Schrift — und wer sie behebt, zerstoert den Schein. */
  if (eigen && !eigen.unmessbar && eigen.a >= 1 && farbe.a >= 1 &&
      Math.round(eigen.r) === Math.round(farbe.r) && Math.round(eigen.g) === Math.round(farbe.g) &&
      Math.round(eigen.b) === Math.round(farbe.b)) {
    uebersprungen.push({ ziel: ziel, warum: 'Schrift- und Eigenfarbe identisch — gefaerbte Form, ' +
      'kein Text (color fuettert currentColor)' });
    return;
  }

  const vorn = ueberlagern(farbe, grund);
  const k = kontrast(vorn, grund);

  const s = schriftKette(ziel, 0);
  const schwelle = schwelleFuer(s.groesse, s.gewicht);

  const zeile = zeileVon(lies(sieger.datei), sieger.zeichen);
  const eintrag = {
    ziel: ziel, farbe: hex(vorn), grund: hex(grund), k: k, schwelle: schwelle,
    datei: sieger.datei, zeile: zeile, sel: sieger.sel, geerbt: !!s.geerbt,
    groesse: s.groesse === null ? 16 : s.groesse, gewicht: s.gewicht === null ? 400 : s.gewicht
  };
  if (k + 0.0005 < schwelle) treffer.push(eintrag); else bestanden.push(eintrag);
});

/* Dieselbe gewinnende Regel kann ueber mehrere Ziele gefunden werden — ".ew-nr" und
 * ".ew-sperre .ew-nr" haengen beide an derselben Zeile, liegen aber auf verschiedenen
 * Gruenden. Gemeldet wird die STELLE, mit ihrem schlechtesten Fall vorn; die anderen Wege
 * stehen darunter, damit beim Beheben keiner uebersehen wird. */
const gesehen = {};
const bericht = [];
treffer.sort(function (a, b) { return a.k - b.k; }).forEach(function (t) {
  const schluessel = t.datei + ':' + t.zeile;
  if (gesehen[schluessel]) { gesehen[schluessel].auch.push(t); return; }
  t.auch = [];
  gesehen[schluessel] = t;
  bericht.push(t);
});

function feld(s, n) { s = String(s); while (s.length < n) s += ' '; return s; }

console.log('BEFUND — ' + bericht.length + ' Unterschreitung' + (bericht.length === 1 ? '' : 'en') +
            ' (aus ' + (bericht.length + bestanden.length) + ' gemessenen Stellen)\n');
if (bericht.length) {
  console.log('  ' + feld('Kontr.', 8) + feld('Selektor', 34) + feld('Datei:Zeile', 34) + 'Farbe auf Grund');
  console.log('  ' + new Array(104).join('-'));
  bericht.forEach(function (t) {
    const kurz = t.datei.replace('ui/app/', '').replace('ui/shared/', '').replace('tools/', '');
    console.log('  ' + feld(t.k.toFixed(2) + (t.schwelle === 3 ? '/3.0' : '/4.5'), 8) +
                feld(t.ziel.length > 32 ? t.ziel.slice(0, 31) + '…' : t.ziel, 34) +
                feld(kurz + ':' + t.zeile, 34) +
                t.farbe + ' auf ' + t.grund +
                '   ' + t.groesse + 'px' + (t.geerbt ? '~' : '') + (t.gewicht >= 700 ? ' fett' : ''));
    t.auch.forEach(function (a) {
      console.log('        auch ' + a.ziel + ' auf ' + a.grund + ' = ' + a.k.toFixed(2));
    });
  });
  console.log('\n  (~ = Groesse geerbt, nicht am Element selbst gesetzt)');
  console.log('');
}

console.log('  uebersprungen: ' + uebersprungen.length + ' Ziele (Ausnahmeliste, Kegelverlaeufe,' +
            ' gefaerbte Formen, zur Laufzeit gesetzte Farben)');
console.log('  fremde Module: ' + fremd.length + ' Ziele aus glass.css, die es in VetStation nicht gibt');
if (ALLES) {
  console.log('');
  uebersprungen.forEach(function (u) { console.log('    ~ ' + feld(u.ziel, 40) + u.warum); });
  console.log('');
  console.log('    fremd: ' + fremd.join(', '));
  console.log('');
  bestanden.sort(function (a, b) { return a.k - b.k; }).forEach(function (b) {
    console.log('    + ' + feld(b.k.toFixed(2), 7) + feld(b.ziel, 40) + b.farbe + ' auf ' + b.grund);
  });
}

/* ================================================================================
 * DIE BEIDEN THEMENBLAETTER MUESSEN GLEICH BLEIBEN (21.08.2026)
 * ================================================================================
 * glass.css liegt ZWEIMAL: ui/shared/glass.css (Station) und canis-vetpharm/shared/glass.css
 * (Web-App). tools/web-app-bauen.js nimmt es AUSDRUECKLICH aus der Kopierliste heraus
 * (FREMDER_BAUM) — der andere Baum gilt als der fuehrende. Damit fliesst nichts von selbst
 * hinueber, und bis heute verglich sie KEIN Test.
 *
 * Warum das hierher gehoert: dieser Waechter misst die Lesbarkeit im Hellmodus GEGEN
 * ui/shared/glass.css. Laufen die beiden Dateien auseinander, misst er ab dann eine Datei,
 * die die Web-App gar nicht laedt — er bliebe gruen, waehrend am Handy etwas unlesbar ist.
 * Ein Waechter, der die falsche Datei misst, ist schlimmer als keiner.
 *
 * Verglichen wird nach Entfernen der Wagenruecklaeufe: die beiden Dateien unterscheiden sich
 * heute nur in den Zeilenenden (38145 gegen 38767 Byte, 0 Zeilen Unterschied). Das ist kein
 * Fehler, sondern Windows.
 */
var themaFehler = 0;
(function () {
  var a = path.join(ROOT, 'ui/shared/glass.css');
  var b = path.join(ROOT, '..', '..', 'canis-vetpharm', 'shared', 'glass.css');
  if (!fs.existsSync(b)) {
    console.log('\n  (canis-vetpharm liegt nicht daneben — die beiden Themenblaetter sind nicht vergleichbar)');
    return;
  }
  var sa = fs.readFileSync(a, 'utf8').replace(/\r/g, '');
  var sb = fs.readFileSync(b, 'utf8').replace(/\r/g, '');
  if (sa === sb) { console.log('\n  Themenblatt: Station und Web-App tragen denselben Stand.'); return; }
  themaFehler = 1;
  var za = sa.split('\n'), zb = sb.split('\n');
  var erste = -1;
  for (var i = 0; i < Math.max(za.length, zb.length); i++) { if (za[i] !== zb[i]) { erste = i + 1; break; } }
  console.log('\n  ACHTUNG: die beiden glass.css sind NICHT mehr gleich.');
  console.log('    ui/shared/glass.css            ' + za.length + ' Zeilen');
  console.log('    canis-vetpharm/shared/glass.css ' + zb.length + ' Zeilen');
  console.log('    erster Unterschied in Zeile ' + erste);
  console.log('    Der Bau kopiert diese Datei NICHT (web-app-bauen.js, FREMDER_BAUM) — wer sie');
  console.log('    aendert, muss BEIDE aendern. Sonst gilt die Aenderung nur fuer die Station.');
})();

console.log('\n===============================================================');
if (probeFehler) {
  console.log('  GEGENPROBE FEHLGESCHLAGEN: der Rechner selbst ist falsch.');
  console.log('  Der Befund oben ist damit wertlos.');
  console.log('===============================================================\n');
  process.exit(1);
}
if (bericht.length) {
  console.log('  FEHLGESCHLAGEN: ' + bericht.length + ' Stelle' + (bericht.length === 1 ? '' : 'n') +
              ' unter der Lesbarkeitsschwelle.');
  console.log('===============================================================\n');
  process.exit(1);
}
if (themaFehler) {
  console.log('  FEHLGESCHLAGEN: die beiden Themenblaetter sind auseinandergelaufen.');
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + bestanden.length + ' GEMESSENEN STELLEN LESBAR');
console.log('===============================================================\n');
