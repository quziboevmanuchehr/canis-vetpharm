'use strict';
/*
 * dosis-abgleich.js — vergleicht JEDE Dosis der Arzneikarten mit jeder Dosisangabe, die
 * irgendwo sonst im Baum zu demselben Wirkstoff steht.
 *
 * WARUM ES DIESE DATEI GIBT (Befund 19.08.2026):
 *
 *   Noradrenalin stand in ui/app/anaes-data.js mit 0,05-2 mcg/kg/min. An 28 ANDEREN Stellen
 *   derselben Anwendung - ui/shared/breed-katalog.js und ui/shared/narkose-risiko.js - stand
 *   durchweg 0,05-0,2 bis 0,05-0,5, nirgends mehr. Die Arzneikarte war der einzige Ort mit
 *   der 2, also dem Vierfachen des eigenen Hoechstwerts, und CliniPharm/vetpharm nennt
 *   0,1-1,0 (Kraft 2003a).
 *
 *   Gefunden wurde das von Hand, beim Nachschlagen eines einzelnen Stoffes. Bei 247 dosierten
 *   Artzeilen ist das kein Verfahren. Diese Datei macht daraus eine Messung.
 *
 * WIE VERGLICHEN WIRD, und was das NICHT ist:
 *   Gesucht werden Textstellen der Form "<Wirkstoffname> <zahl>[-<zahl>] <einheit>". Liegt
 *   eine gefundene Zahl AUSSERHALB der Spanne der Arzneikarte, ist das ein Widerspruch der
 *   Anwendung mit sich selbst - und genau der ist mechanisch findbar.
 *
 *   Das ersetzt KEINEN Abgleich mit einem Buch oder mit vetpharm. Es findet nur, wo die
 *   Anwendung zwei verschiedene Zahlen fuehrt. Ob die Karte oder der Text recht hat, sagt
 *   dieser Test nicht - das bleibt eine fachliche Entscheidung mit Quelle.
 *
 * WARUM ER TROTZDEM IM SAMMELLAUF STEHT: er faellt nicht rot, sondern zaehlt. Neue
 * Widersprueche fallen dadurch beim naechsten Lauf auf, statt erst beim naechsten Zufall.
 *
 * Start: node tools/dosis-abgleich.js [--alle]        Bericht
 *        node tools/dosis-abgleich.js --wache         Waechter (rot bei Neuem)
 */
var fs = require('fs');
var path = require('path');
var vm = require('vm');

var WURZEL = path.join(__dirname, '..');
var ALLE = process.argv.indexOf('--alle') >= 0;
var WACHE = process.argv.indexOf('--wache') >= 0;

/* ---- Die Arzneikarten laden, so wie die Anwendung sie sieht (mit Exotenpatch) ---- */
var sb = { self: {} };
sb.window = sb.self; sb.self.window = sb.self;
vm.createContext(sb);
vm.runInContext(fs.readFileSync(path.join(WURZEL, 'ui/app/anaes-data.js'), 'utf8'), sb);
vm.runInContext(fs.readFileSync(path.join(WURZEL, 'ui/shared/anaes-exotic-doses.js'), 'utf8'), sb);
var A = sb.self.ANAES;

/*
 * Name -> LISTE der Arzneikarten dieses Namens. Aliase zaehlen mit, weil die Texte auch
 * "Norepinephrin" schreiben, und der Klammerzusatz wird zusaetzlich als Kurzname gefuehrt.
 *
 * WARUM EINE LISTE UND KEIN EINZELEINTRAG (Fehlbefund 19.08.2026):
 *   Es gibt zwei Karten namens Lidocain - lidocain_iv (Antiarrhythmikum, Katze 0,25-0,5
 *   mg/kg) und lidocain_lok (Lokalanaesthesie, Katze 1-2 mg/kg). Beide kuerzen sich auf
 *   "lidocain". Solange ein Name nur EINE Karte trug, ueberschrieb die zweite die erste,
 *   und das Werkzeug hielt den korrekt zitierten Bolus 0,25-0,5 mg/kg gegen die Spanne der
 *   Lokalanaesthesie. Gemeldet wurde ein Sicherheitsfehler, den es nicht gab.
 *   Eine Textstelle gilt jetzt als gedeckt, sobald IRGENDEINE Karte dieses Namens sie deckt.
 */
var karten = {};
(A.drugs || []).forEach(function (m) {
  var namen = [m.name].concat(m.aliases || []);
  namen.push(String(m.name).replace(/\s*\(.*$/, '').trim());
  var karte = { id: m.id, name: m.name, arten: {} };
  Object.keys(m.species || {}).forEach(function (a) {
    var s = m.species[a];
    if (s && s.low != null) karte.arten[a] = { lo: s.low, hi: s.high, unit: String(s.unit || '') };
  });
  var gesehen = {};
  namen.forEach(function (nm) {
    nm = String(nm).trim().toLowerCase();
    if (nm.length < 4 || gesehen[nm]) return;
    gesehen[nm] = 1;
    (karten[nm] = karten[nm] || []).push(karte);
  });
});

/* Alle bekannten Wirkstoffnamen, laengste zuerst - fuer die Fremdnamen-Pruefung unten. */
var NAMEN = Object.keys(karten).sort(function (a, b) { return b.length - a.length; });

/* ---- Die Textquellen ---- */
var QUELLEN = ['ui/shared/breed-katalog.js', 'ui/shared/narkose-risiko.js',
  'ui/shared/rasse-herz.js', 'ui/shared/kardio-regeln.js', 'ui/shared/dosis-warnungen.js'];

/*
 * Einheiten vergleichbar machen. Das ist nicht nur Schreibweise:
 *
 * Beim ersten Lauf meldete dieses Werkzeug "Medetomidin 200-250 ug/kg gegen Karte
 * kaninchen 0,1-0,5" als Abweichung. Die Karte fuehrt das Kaninchen in mg/kg, der Text in
 * ug/kg - 200-250 ug/kg sind 0,2-0,25 mg/kg und liegen damit MITTEN in der Karte. Der
 * Befund war ein Fehler der Messung, nicht der Anwendung.
 *
 * Deshalb wird hier nicht auf Gleichheit geprueft, sondern auf dieselbe GROESSE (mg/kg,
 * ug/kg/min, ...) und der Faktor zurueckgegeben. Passt die Groesse nicht, wird gar nicht
 * verglichen - eine Einzeldosis in mg/kg und eine Dauertropfrate in ug/kg/min haben nichts
 * miteinander zu tun.
 */
function zerlege(u) {
  var t = String(u).toLowerCase().replace(/µ/g, 'u').replace(/mcg/g, 'ug')
    .replace(/\s+/g, '').replace(/,/g, '.');
  var m = /^(m?g|ug|mg)\/kg(\/(min|h|std))?$/.exec(t);
  if (!m) return null;
  var f = m[1] === 'ug' ? 0.001 : (m[1] === 'g' ? 1000 : 1);
  return { zeit: m[3] || '', faktor: f };
}
/* Gibt den Faktor zurueck, mit dem eine Zahl in Einheit b in Einheit a umzurechnen ist. */
function passt(a, b) {
  var A = zerlege(a), B = zerlege(b);
  if (!A || !B || A.zeit !== B.zeit) return null;
  return B.faktor / A.faktor;
}

/*
 * Welche Art meint diese Textstelle? breed-katalog.js fuehrt Befunde, die fuer mehrere Arten
 * gelten, und narkose-risiko.js schreibt Protokolle im Fliesstext. Ohne diese Zuordnung wird
 * ein Kaninchenprotokoll gegen die Hundekarte gehalten, und der Befund sagt nichts.
 * Gesucht wird der naechste Artmarker VOR der Fundstelle; steht keiner da, bleibt es beim
 * Vergleich gegen alle Arten - dann aber als eigene, schwaechere Klasse.
 */
var ARTWORT = [[/\bkaninchen|\brabbit/i, 'kaninchen'], [/\bmeerschwein/i, 'meerschwein'],
  [/\breptil|schildkroet|echse|bartagame|schlange|gecko|leguan/i, 'reptil'],
  [/\bkatze|\bkater|\bfelin/i, 'katze'], [/\bhund|\bcanin/i, 'hund'],
  [/\bratte\b/i, 'ratte'], [/\bmaus\b|\bmaeuse/i, 'maus'],
  [/\bhamster/i, 'hamster'], [/\brennmaus|gerbil/i, 'rennmaus']];
function artBei(txt, idx) {
  var fenster = txt.slice(Math.max(0, idx - 900), idx);
  var best = null, wo = -1;
  ARTWORT.forEach(function (p) {
    var re = new RegExp(p[0].source, 'gi'), m, letzte = -1;
    while ((m = re.exec(fenster))) letzte = m.index;
    if (letzte > wo) { wo = letzte; best = p[1]; }
  });
  return best;
}

/*
 * Gehoert die gefundene Zahl wirklich zu DIESEM Wirkstoff - und ist sie ueberhaupt ein Rat?
 *
 * Zwei Fehlbefunde des zweiten Laufs, beide vom Werkzeug und nicht von der Anwendung:
 *
 *   "Alfaxalon 20-40 mg/kg beim Meerschwein". Im Text stand
 *       "... oder Alfaxalon i.v./i.m.; Ketamin 20-40 mg/kg + Medetomidin ..."
 *   Das Suchfenster war ueber das Semikolon hinweg zur naechsten Arznei gesprungen.
 *
 *   "Atipamezol 0,5-2 mg/kg beim Kaninchen". Die Stelle lag in einer sources:-Liste und
 *   lautete "Ohio State University IACUC Rodent Guideline (Atipamezol 0,5-2 mg/kg)" - ein
 *   Quellenbeleg fuer Nager, kein Rat fuer dieses Tier.
 *
 * Beides waere als Widerspruch gemeldet worden und ist keiner. Wer einer Messung
 * Fehlbefunde durchgehen laesst, macht sie unbrauchbar: die echten gehen darin unter.
 */
function fremdeAngabe(luecke, txt, idx) {
  /* Satzzeichen, die eine neue Angabe eroeffnen - dahinter steht ein anderes Mittel. */
  if (/[;+"'\[\]]|\bund\b|\boder\b|\bstatt\b/i.test(luecke)) return true;
  /* Ein anderer Wirkstoffname im Zwischenraum. */
  var l = luecke.toLowerCase();
  for (var i = 0; i < NAMEN.length; i++) if (l.indexOf(NAMEN[i]) >= 0) return true;
  /* Belegzeile statt Empfehlung: sources:[ ... ] umschliesst die Fundstelle. */
  var vor = txt.lastIndexOf('sources:[', idx);
  if (vor >= 0 && txt.indexOf(']', vor) > idx) return true;
  return false;
}

/*
 * gesagt: der HOECHSTE Wert, den die Anwendung im Fliesstext zu einer Arznei und Art
 * ueberhaupt nennt, und wie oft sie ueber sie spricht. Braucht die zweite Messrichtung.
 */
var gesagt = {};
var funde = [], geprueft = 0, stellen = 0;

QUELLEN.forEach(function (rel) {
  var p = path.join(WURZEL, rel);
  if (!fs.existsSync(p)) return;
  var txt = fs.readFileSync(p, 'utf8');
  Object.keys(karten).forEach(function (nm) {
    var liste = karten[nm];
    /* Alle Arten aller gleichnamigen Karten - fuer die Artzuordnung unten. */
    var arten = [];
    liste.forEach(function (k) {
      Object.keys(k.arten).forEach(function (a) { if (arten.indexOf(a) < 0) arten.push(a); });
    });
    if (!arten.length) return;
    /* "<Name> [beliebiges kurzes Wort] 0,05-0,4 ug/kg/min" */
    var re = new RegExp(nm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') +
      '([^0-9\\n]{0,28}?)([0-9]+[.,]?[0-9]*)\\s*[-–]\\s*([0-9]+[.,]?[0-9]*)\\s*' +
      '(m?[gu]g?\\s*/\\s*kg(?:\\s*/\\s*(?:min|h|std))?|ug\\s*/\\s*kg\\s*/\\s*min|µg\\s*/\\s*kg[^\\s,;.]*)', 'gi');
    var m;
    while ((m = re.exec(txt))) {
      /*
       * Gehoert die Zahl wirklich zu DIESEM Wirkstoff? Beim zweiten Lauf meldete das
       * Werkzeug "Alfaxalon 20-40 mg/kg beim Meerschwein". Im Text stand:
       *     "... oder Alfaxalon i.v./i.m.; Ketamin 20-40 mg/kg + Medetomidin ..."
       * Das Suchfenster war ueber das Semikolon hinweg zur naechsten Arznei gesprungen.
       * Deshalb: liegt zwischen Name und Zahl ein Satzzeichen, das eine neue Angabe
       * eroeffnet, oder gar ein anderer Wirkstoffname, zaehlt die Stelle nicht.
       */
      if (fremdeAngabe(m[1], txt, m.index)) continue;
      stellen++;
      var lo = parseFloat(m[2].replace(',', '.'));
      var hi = parseFloat(m[3].replace(',', '.'));
      var unit = m[4];
      var art = artBei(txt, m.index);
      var fehltArt = !!(art && arten.indexOf(art) < 0);

      /* Je Karte: welche Arten sind ueberhaupt vergleichbar, und deckt eine davon die Zahl? */
      var drin = false, spannen = [], vergleichbar = false, sicher = false, hoeherAlle = true;
      liste.forEach(function (k) {
        var eigene = Object.keys(k.arten)
          .filter(function (a) { return passt(k.arten[a].unit, unit) != null; });
        /* Nennt der Text eine Art, gilt nur die. Sonst bleibt es beim Vergleich gegen alle. */
        if (art && eigene.indexOf(art) >= 0) { eigene = [art]; sicher = true; }
        if (!eigene.length) return;
        vergleichbar = true;
        eigene.forEach(function (a) {
          var s = k.arten[a], f = passt(s.unit, unit);
          if (lo * f >= s.lo - 1e-9 && hi * f <= s.hi + 1e-9) drin = true;
          if (!(hi * f < s.hi)) hoeherAlle = false;
          spannen.push(a + ' ' + s.lo + '-' + s.hi + ' ' + s.unit
            + (liste.length > 1 ? ' [' + k.id + ']' : ''));
        });
      });
      if (!vergleichbar) continue;
      geprueft++;
      /* Jeden Wert mitschreiben, AUCH den passenden - die zweite Messrichtung unten
         braucht den hoechsten Wert, den die Anwendung sonst zu diesem Mittel schreibt. */
      liste.forEach(function (k) {
        Object.keys(k.arten).forEach(function (a) {
          /*
           * NUR zugeordnete Nennungen zaehlen. Ohne diese Zeile setzte eine Angabe ohne
           * Artmarker die Obergrenze fuer JEDE Art der Karte - und die Messung meldete
           * "Medetomidin Maus: Karte 1 mg/kg gegen hoechstens 0,003", also das 333-Fache.
           * Die 0,003 stammten aus einem Hundeprotokoll (3 ug/kg beim Herzpatienten).
           * Was keiner Art zugeordnet ist, taugt nicht als Vergleichsmass.
           */
          if (a !== art) return;
          var f = passt(k.arten[a].unit, unit);
          if (f == null) return;
          var schl = k.id + '|' + a;
          gesagt[schl] = gesagt[schl] || { hoechst: 0, n: 0, id: k.id, name: k.name, art: a };
          gesagt[schl].n++;
          if (hi * f > gesagt[schl].hoechst) gesagt[schl].hoechst = hi * f;
        });
      });
      /*
       * continue, NICHT return. Diese Schleife steckt in einem forEach-Rueckruf je
       * Wirkstoffname: ein return beendete die Suche nach DIESEM Mittel vollstaendig,
       * sobald der erste Treffer in die Karte passte. Bei Noradrenalin passte der erste,
       * also sah das Werkzeug die uebrigen fuenf Nennungen nie - und die zweite
       * Messrichtung unten, die den hoechsten sonst genannten Wert braucht, blieb ohne
       * Datengrundlage. Gefunden am 19.08.2026 nur dadurch, dass die Gegenprobe den
       * gerade berichtigten Noradrenalin-Wert versuchsweise zurueckdrehte und der
       * Waechter gruen blieb.
       */
      if (drin) continue;
      spannen = spannen.join(', ');
      funde.push({
        stoff: liste[0].name, datei: rel,
        zeile: txt.slice(0, m.index).split('\n').length,
        text: lo + '-' + hi + ' ' + unit.replace(/\s+/g, '') + (art ? '  [' + art + ']' : ''),
        karte: fehltArt ? '(fuehrt ' + art + ' nicht)' : spannen,
        klasse: fehltArt ? 'LUECKE' : (sicher ? 'WIDERSPRUCH' : 'unklar'),
        /* Nur das obere Ende zaehlt als gefaehrlich: eine Karte, die MEHR erlaubt als jeder
           Text, ist die Richtung, in die zu viel gegeben wird. */
        hoeher: !fehltArt && hoeherAlle
      });
    }
  });
});

/* ==================================================================================
 * ZWEITE MESSRICHTUNG: die Karte ist ZU WEIT.
 *
 * WARUM ES SIE GIBT - die Gegenprobe hat den ersten Entwurf widerlegt (19.08.2026):
 *
 *   Der obere Teil dieser Datei meldet Textwerte, die AUSSERHALB der Karte liegen. Zur
 *   Gegenprobe wurde die gerade berichtigte Noradrenalin-Obergrenze versuchsweise wieder
 *   auf 2 mcg/kg/min gesetzt - also genau der Fehler, fuer den dieses Werkzeug gebaut
 *   wurde. Der Waechter blieb GRUEN.
 *
 *   Der Grund ist einfach und war uebersehen: eine zu weite Karte schluckt jeden Text.
 *   Je falscher die Obergrenze, desto WENIGER faellt auf. Die Messung war blind fuer
 *   genau ihren Anlass.
 *
 * Deshalb hier die umgekehrte Frage: liegt die Kartenobergrenze um mehr als das Doppelte
 * ueber dem hoechsten Wert, den die Anwendung selbst je zu diesem Mittel und dieser Art
 * schreibt? Dann behauptet die Arzneikarte etwas, das sie sonst nirgends vertritt.
 *
 * Das ist kein Beweis eines Fehlers - Karte und Fliesstext duerfen verschiedene Dinge
 * meinen. Es ist ein Ort, an dem nachgeschlagen gehoert.
 */
Object.keys(gesagt).forEach(function (schl) {
  var g = gesagt[schl];
  if (g.n < 2 || !(g.hoechst > 0)) return;
  var kar = null;
  (A.drugs || []).forEach(function (m) { if (m.id === g.id) kar = m.species[g.art]; });
  if (!kar || !(kar.high > 0)) return;
  if (kar.high < g.hoechst * 2) return;
  funde.push({
    stoff: g.name, datei: '(Arzneikarte)', zeile: 0,
    text: 'Karte bis ' + kar.high + ' ' + kar.unit + '  [' + g.art + ']',
    karte: 'die Anwendung schreibt sonst hoechstens ' + Math.round(g.hoechst * 1000) / 1000
      + ' (' + g.n + 'x genannt)',
    klasse: 'ZUWEIT', hoehe: 0, hoeher: true
  });
});

/* Gleiche Befunde zusammenfassen - dieselbe Zahl steht oft in zwanzig Rassehinweisen. */
var gruppen = {};
funde.forEach(function (f) {
  var s = f.stoff + '|' + f.text + '|' + f.karte;
  gruppen[s] = gruppen[s] || { f: f, n: 0, orte: [] };
  gruppen[s].n++;
  if (gruppen[s].orte.length < 3) gruppen[s].orte.push(f.datei.split('/').pop() + ':' + f.zeile);
});
var RANG = { ZUWEIT: 0, WIDERSPRUCH: 1, LUECKE: 2, unklar: 3 };
var liste = Object.keys(gruppen).map(function (k) { return gruppen[k]; })
  .sort(function (a, b) {
    if (RANG[a.f.klasse] !== RANG[b.f.klasse]) return RANG[a.f.klasse] - RANG[b.f.klasse];
    return b.n - a.n;
  });

console.log('VetStation — Dosisabgleich der Anwendung mit sich selbst\n');
console.log('  ' + Object.keys(karten).length + ' Wirkstoffnamen, ' + stellen + ' Textstellen gefunden, '
  + geprueft + ' mit passender Einheit vergleichbar.');
console.log('  ' + liste.length + ' verschiedene Abweichungen (' + funde.length + ' Fundstellen).\n');

if (!liste.length) {
  console.log('  Keine Textstelle liegt ausserhalb der Spanne ihrer Arzneikarte.');
} else {
  var KOPF = {
    ZUWEIT: 'A) KARTE ZU WEIT — die Arzneikarte laesst mehr als das Doppelte dessen zu,\n'
      + '   was die Anwendung sonst ueberhaupt zu diesem Mittel schreibt. Genau diese Form\n'
      + '   hatte der Noradrenalin-Fehler.',
    WIDERSPRUCH: 'B) WIDERSPRUCH BEI DERSELBEN ART — Text und Karte meinen dasselbe Tier\n'
      + '   und nennen verschiedene Zahlen. Das gehoert entschieden.',
    LUECKE: 'C) LUECKE — der Text dosiert eine Art, die die Arzneikarte gar nicht fuehrt.\n'
      + '   Kein Widerspruch: der Rechner bietet den Stoff fuer diese Art schlicht nicht an.',
    unklar: 'D) OHNE ARTANGABE — die Fundstelle nennt keine Art, verglichen wurde gegen alle.\n'
      + '   Meist bewusst gesenkte Dosen in Rassehinweisen; einzeln anzusehen.'
  };
  var letzte = null;
  var zeigen = ALLE ? liste : liste.filter(function (g) { return g.f.klasse !== 'unklar'; });
  zeigen.forEach(function (g) {
    var f = g.f;
    if (f.klasse !== letzte) { console.log('\n' + KOPF[f.klasse] + '\n'); letzte = f.klasse; }
    console.log('  ' + (f.klasse === 'ZUWEIT' ? 'KARTE ZU WEIT     '
      : (f.hoeher ? 'KARTE ERLAUBT MEHR' : 'Karte deckt nicht ')) + '  ' + f.stoff);
    console.log('      Text : ' + f.text
      + (f.klasse === 'ZUWEIT' ? '' : '   (' + g.n + 'x, z.B. ' + g.orte.join(', ') + ')'));
    console.log('      Karte: ' + f.karte);
  });
  if (!ALLE && liste.length > zeigen.length) {
    console.log('\n  (' + (liste.length - zeigen.length) + ' weitere ohne Artangabe — vollstaendig mit --alle.)');
  }
  console.log('\n  ZU LESEN ALS: hier fuehrt die Anwendung zwei verschiedene Zahlen. Welche stimmt,');
  console.log('  sagt diese Messung NICHT - das braucht eine Quelle. "KARTE ERLAUBT MEHR" ist die');
  console.log('  Richtung, in die zu viel gegeben werden kann, und gehoert zuerst angesehen.');
}

/* ==================================================================================
 * WAECHTERBETRIEB (--wache)
 *
 * Ein Bericht, den niemand liest, findet nichts. Deshalb laeuft dieselbe Messung im
 * Sammellauf mit --wache und faellt rot, sobald sich etwas aendert.
 *
 * ER WACHT NUR UEBER KLASSE A, und das ist Absicht:
 *
 *   Klasse A ("Karte zu weit") hat die nachgewiesene Fehlerform. Der Noradrenalin-Fehler
 *   sah genau so aus: die Arzneikarte liess 2 mcg/kg/min zu, waehrend die Anwendung selbst
 *   nirgends mehr als 0,5 schrieb. Die Klasse ist klein, jede Zeile ist nachschlagbar, und
 *   die Gegenprobe unten zeigt, dass ein Rueckfall wirklich rot wird.
 *
 *   Die Klassen B bis D zaehlen zusammen ueber 130 Stellen, und die allermeisten sind
 *   Absicht: ein Rassehinweis nennt bewusst eine niedrigere Dosis als das Nachschlagewerk.
 *   Sie alle in eine Ausnahmeliste zu schreiben, hiesse 130 Zeilen abzuhaken, ohne 130
 *   Zahlen nachgeschlagen zu haben. Das waere keine Pruefung, sondern ihr Anschein.
 *   Sie bleiben deshalb Bericht: node tools/dosis-abgleich.js --alle
 *
 * JEDE ZEILE UNTEN IST EINE ENTSCHEIDUNG MIT BEGRUENDUNG. Sie enthaelt die Kartenzahl,
 * also aendert schon das Verstellen der Karte die Kennung und faellt auf.
 */
var ANGENOMMEN = {
  'Noradrenalin Karte bis 1 mcg/kg/min  [hund]':
    'Obergrenze 1,0 steht bei CliniPharm/vetpharm (Kraft 2003a) fuer Hund und Katze. Die '
    + 'Rassehinweise nennen 0,3-0,4, weil sie den EINSTIEG beschreiben, nicht die Grenze. '
    + 'Bis 19.08.2026 stand hier 2 - das Vierfache des sonst Geschriebenen und ohne Quelle.',
  'Noradrenalin Karte bis 1 mcg/kg/min  [katze]': 'wie beim Hund - derselbe Eintrag bei vetpharm.',

  /* Nagetiere und Kaninchen: die Karte fuehrt die volle publizierte Spanne der Art, die
     Rassehinweise nennen die niedrige Kombinationsdosis. Beides ist belegt. */
  'Atropin Karte bis 0.5 mg/kg  [kaninchen]':
    'Kaninchen bauen Atropin mit Atropinesterase ab und brauchen deshalb die hohe Spanne; '
    + 'die Hinweise nennen 0,05 mg/kg SC als Routinegabe.',
  'Dexmedetomidin Karte bis 100 mcg/kg  [kaninchen]': 'Volle Sedationsspanne des Kaninchens; die Protokolle nennen die niedrige Kombinationsdosis.',
  'Medetomidin Karte bis 0.5 mg/kg  [kaninchen]': 'wie vor - Kombination liegt am unteren Rand.',
  'Midazolam Karte bis 2 mg/kg  [kaninchen]': 'Karte 0,5-2 mg/kg; die Praemedikationskombination nutzt 0,25-0,5. Beides publiziert.',
  'Midazolam Karte bis 2 mg/kg  [meerschwein]': 'wie beim Kaninchen.',
  'Midazolam Karte bis 2 mg/kg  [reptil]': 'wie beim Kaninchen.',
  'Butorphanol Karte bis 2 mg/kg  [meerschwein]': 'Volle Analgesiespanne; die Protokolle nennen 0,2-0,4 mg/kg in Kombination.',

  /* Hund und Katze */
  'Medetomidin Karte bis 20 mcg/kg  [hund]':
    'Karte 5-20 ug/kg ist die allgemeine Sedationsspanne. Die 2-5 der Hinweise gelten dem '
    + 'Herzpatienten und sind bewusst gesenkt - kein Widerspruch, sondern der Zweck der Hinweise.',
  'Lidocain (Lokalanästhesie) Karte bis 2 mg/kg  [katze]':
    'Vergleichswert 0,5 stammt aus dem i.v.-Antiarrhythmikum (Bolus 0,25-0,5 mg/kg) und '
    + 'gehoert zu der ANDEREN Lidocain-Karte. Fuer die Lokalanaesthesie ist 2 mg/kg die '
    + 'uebliche Hoechstdosis der Katze.'
};

if (WACHE) {
  var pass = 0, fail = 0;
  function ok(n, c, e) {
    if (c) { pass++; console.log("  \u2713 " + n); }
    else { fail++; console.log("  \u2717 " + n + (e ? "  -> " + e : "")); }
  }
  console.log("\nWaechter ueber Klasse A: keine Arzneikarte darf mehr zulassen als die");
  console.log("Anwendung sonst vertritt, ohne dass jemand die Zahl nachgeschlagen hat.\n");
  var offen = liste.filter(function (g) { return g.f.klasse === "ZUWEIT"; });
  var gesehen = {};
  offen.forEach(function (g) {
    var kennung = g.f.stoff + " " + g.f.text;
    gesehen[kennung] = 1;
    ok(kennung, !!ANGENOMMEN[kennung],
      "Neu. Zahl nachschlagen, entscheiden, dann mit Begruendung in ANGENOMMEN eintragen.");
  });
  console.log("");
  Object.keys(ANGENOMMEN).forEach(function (k) {
    ok("(noch vorhanden) " + k, !!gesehen[k],
      "Diese Stelle gibt es nicht mehr - Zeile entfernen, sonst deckt sie kuenftig nichts mehr ab.");
  });
  console.log("\n  (Klassen B-D sind Bericht, nicht Waechter: node tools/dosis-abgleich.js --alle)");
  console.log("\n== Ergebnis: " + pass + " OK, " + fail + " FAIL ==");
  if (!fail) console.log("ALLE " + pass + " PRUEFUNGEN BESTANDEN");
  process.exit(fail ? 1 : 0);
}
process.exit(0);
