'use strict';
/*
 * glukose-bezug-test.js — bei einer Prozentloesung muss klar sein, WORAUF sich das Volumen
 * bezieht: auf die Stammloesung oder auf die fertige Verduennung. Dazwischen liegt Faktor 4.
 *
 * BEFUND 19.08.2026:
 *
 *   ui/shared/narkose-risiko.js, Rettungsweg Hypoglykaemie, schrieb woertlich
 *       "Glukose 50 % 1:4 verduennen und 0,5-1 mL/kg der verduennten Loesung langsam i.v.
 *        ueber 5 min geben (entspricht etwa 0,25-0,5 g/kg)."
 *   Der Satz widerspricht sich selbst. 50 % sind 0,5 g/mL, auf 1:4 verduennt 0,125 g/mL:
 *       0,5-1 mL/kg der VERDUENNTEN  = 0,06-0,125 g/kg
 *       0,5-1 mL/kg der 50-PROZENTIGEN = 0,25-0,50 g/kg   <- die Klammer
 *   Dieselbe Verwechslung stand in ui/shared/breed-katalog.js, dort ohne Klammer und damit
 *   ohne Widerspruch, den man haette sehen koennen.
 *
 *   Der Eintrag ist der Rettungsweg bei Hypoglykaemie - Zwergrasse, Welpe, Frettchen,
 *   Leber-Shunt, Degu. Ein Viertel der Menge holt ein krampfendes Tier nicht aus dem
 *   Unterzucker, und beim Nachmessen 30 Minuten spaeter stuende derselbe Wert da.
 *
 * WIE DIESER TEST PRUEFT: er RECHNET. Ueberall, wo ein Volumen je kg einer Prozentloesung und
 * eine Menge in g/kg im selben Satz stehen, muss Volumen x Konzentration die genannte Menge
 * ergeben. Ein Test, der nur nach Woertern sucht, haette den Fehler nie gesehen - die Woerter
 * waren alle da.
 *
 * WAS ER AUSDRUECKLICH IN RUHE LAESST: den Frettchen-Rettungsweg (Insulinom). Dort stehen
 * bewusst nur 0,25-0,5 mL/kg der verduennten Loesung, und die naechste Zeile begruendet es:
 * "ein grosser Glukosebolus reizt den Tumor zur Insulinausschuettung und der Zucker faellt
 * danach tiefer - deshalb klein und langsam." Wer dort dieselbe Berichtigung anbraechte,
 * vervierfachte eine absichtlich niedrige Dosis. Der Test haelt das fest, damit es niemand
 * spaeter "mit berichtigt".
 *
 * Start: node tools/glukose-bezug-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function lies(rel) { return fs.readFileSync(path.join(WURZEL, rel), 'utf8'); }
function zahl(s) { return parseFloat(String(s).replace(',', '.')); }

console.log('VetStation — Bezug von Volumenangaben bei Prozentloesungen\n');

var DATEIEN = ['ui/shared/narkose-risiko.js', 'ui/shared/breed-katalog.js',
  'ui/shared/rasse-herz.js', 'ui/app/index.html'];

console.log('1) Die Rechnung, ueberall wo mL/kg und g/kg im selben Satz stehen:');
var geprueft = 0, schief = [];
DATEIEN.forEach(function (rel) {
  var t = lies(rel);
  /*
   * Ein Satz endet hier am Punkt, am Anfuehrungszeichen oder am Semikolon. Ohne diese Grenze
   * zieht der Ausdruck ueber die naechste Arznei hinweg und vergleicht Zahlen, die nichts
   * miteinander zu tun haben.
   */
  var re = /([0-9][0-9.,]*)\s*[–-]\s*([0-9][0-9.,]*)\s*(?:mL|ml)\/kg[^"'.;]{0,80}?([0-9]{1,2})\s*(?:%|Prozent)[^"'.;]{0,80}?([0-9][0-9.,]*)\s*[–-]\s*([0-9][0-9.,]*)\s*g\/kg/g;
  var re2 = /([0-9]{1,2})\s*(?:%|Prozent)[^"'.;]{0,60}?([0-9][0-9.,]*)\s*[–-]\s*([0-9][0-9.,]*)\s*(?:mL|ml)\/kg[^"'.;]{0,90}?([0-9][0-9.,]*)\s*[–-]\s*([0-9][0-9.,]*)\s*g\/kg/g;
  [[re, 0], [re2, 1]].forEach(function (paar) {
    var r = paar[0], form = paar[1], m;
    while ((m = r.exec(t))) {
      var vLo = zahl(form ? m[2] : m[1]), vHi = zahl(form ? m[3] : m[2]);
      var proz = zahl(form ? m[1] : m[3]);
      var gLo = zahl(form ? m[4] : m[4]), gHi = zahl(form ? m[5] : m[5]);
      var konz = proz / 100;               /* 50 % = 0,5 g/mL */
      geprueft++;
      var sollLo = vLo * konz, sollHi = vHi * konz;
      var passt = Math.abs(sollLo - gLo) < 0.005 && Math.abs(sollHi - gHi) < 0.005;
      var zeile = t.slice(0, m.index).split('\n').length;
      if (!passt) {
        schief.push(rel.split('/').pop() + ':' + zeile + '  ' + vLo + '-' + vHi + ' mL/kg der '
          + proz + '% = ' + (Math.round(sollLo * 1000) / 1000) + '-' + (Math.round(sollHi * 1000) / 1000)
          + ' g/kg, im Text steht ' + gLo + '-' + gHi);
      }
    }
  });
});
ok('es gibt ueberhaupt solche Saetze zu pruefen (' + geprueft + ')', geprueft >= 2,
  'Ohne Fundstellen prueft dieser Abschnitt nichts');
ok('jede Volumenangabe ergibt die daneben genannte Menge', schief.length === 0,
  schief.join(' | '));

console.log('\n2) Die beiden berichtigten Stellen nennen den Bezug ausdruecklich:');
var nr = lies('ui/shared/narkose-risiko.js');
var bk = lies('ui/shared/breed-katalog.js');
ok('Rettungsweg Hypoglykaemie: das Volumen ist das der UNVERDUENNTEN Loesung',
  /UNVERDÜNNTEN 50-%-Lösung abmessen \(= 0,25–0,5 g\/kg\)/.test(nr));
ok('… und sagt es nochmals in Worten',
  /beziehen sich auf die 50-%-Stammlösung, nicht auf die fertige Verdünnung/.test(nr));
ok('… und verlangt weiterhin das Verduennen',
  /mindestens 1:4 verdünnen/.test(nr),
  'Unverduennte 50-%-Glukose ist hyperosmolar und schaedigt die Vene');
ok('Rassekatalog: Volumen der 50-prozentigen, dann verduennen',
  /0,5-1 ml\/kg Glukose 50 Prozent abmessen \(entspricht 0,25-0,5 g\/kg\), mindestens 1:4 verduennen/.test(bk));

console.log('\n3) Was NICHT mitberichtigt werden darf:');
/*
 * Diese Pruefung ist die eigentliche Absicherung gegen den naechsten gut gemeinten Griff.
 * Beim Insulinom ist die kleine Menge die Behandlung, nicht der Fehler.
 */
ok('Frettchen mit Insulinom: weiterhin 0,25-0,5 mL/kg der VERDUENNTEN Loesung',
  /0,25–0,5 mL\/kg der verdünnten Lösung/.test(nr),
  'Dort ist die kleine Menge Absicht - Vervierfachung waere ein Behandlungsfehler');
ok('… und die Begruendung steht unmittelbar dabei',
  /Glukosebolus reizt den Tumor zur Insulinausschüttung/.test(nr));

console.log('\n4) Die App bleibt sich ueber die Zielmenge einig:');
var alleG = [];
DATEIEN.forEach(function (rel) {
  var t = lies(rel), m, r = /Hypoglyk[aä]e?mie[^"';]{0,200}?([0-9][0-9.,]*)\s*[–-]\s*([0-9][0-9.,]*)\s*g\/kg/g;
  while ((m = r.exec(t))) alleG.push(zahl(m[1]) + '-' + zahl(m[2]));
});
var verschieden = {};
alleG.forEach(function (x) { verschieden[x] = 1; });
ok('alle Zielmengen bei Hypoglykaemie lauten gleich (' + alleG.length + ' Fundstellen)',
  Object.keys(verschieden).length <= 1, 'gefunden: ' + Object.keys(verschieden).join(', '));

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
