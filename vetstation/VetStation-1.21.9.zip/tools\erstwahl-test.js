'use strict';
/*
 * erstwahl-test.js — die Erstwahl-Liste im Medikamenten-Reiter (Wunsch vom 21.08.2026).
 *
 * WAS DIE OBERFLAECHE SEITHER TUT: erkennt die Station am Narkosepatienten ein Problem, stehen
 * im Reiter "Medikamente" die Mittel der ersten Wahl ganz oben — in der Reihenfolge, in der sie
 * dran sind, mit der Menge fuer das eingetragene Gewicht, und mit dem, was VOR jeder Arznei zu
 * tun ist.
 *
 * WARUM DIESER TEST DEN CODE AUSFUEHRT UND NICHT NUR LIEST: eine Erstwahl-Liste ist eine
 * Behandlungsempfehlung. Ob in der Datei die richtigen Woerter stehen, sagt nichts darueber,
 * welches Mittel am Ende oben steht — genau daran ist in diesem Baum schon einmal ein
 * Waechter gescheitert (tools/dosis-abgleich-test.js, erster Entwurf: er verglich nur
 * Textwerte und war damit blind fuer seinen eigenen Anlass). Deshalb werden arzneiSperre(),
 * erstwahlSetzen() und erstwahlAusZwischenfall() aus ui/app/index.html HERAUSGESCHNITTEN und
 * mit echten Daten (ui/app/anaes-data.js) gefahren.
 *
 * DREI DINGE, DIE ER FESTHAELT:
 *   1. DIE SPERREN. Vier Mittel duerfen nur unter Bedingungen empfohlen werden. Sie sassen bis
 *      zum 21.08.2026 als anonyme Fahne in renderAssess() und werden jetzt an ZWEI Stellen
 *      gebraucht. Eine Kopie waere der "zweite Rechenweg" aus CLAUDE.md.
 *   2. DER UNTERSCHIED ZWISCHEN "GEMESSEN GUT" UND "NICHT GEMESSEN". Die erste Fassung
 *      antwortete einem Tierarzt OHNE angeschlossenes Geraet "Der Blutdruck traegt" — eine
 *      Behauptung ueber etwas, das die Station nicht weiss. Dagegen steht die erste
 *      Projektregel, und deshalb steht sie hier als Pruefung.
 *   3. KEINE ZAHLEN IN DER RANGFOLGE. Die erst-Bloecke duerfen Reihenfolgen und Bedingungen
 *      enthalten, aber KEINE Dosen. Sonst stuenden dieselben Milligramm ein drittes Mal im
 *      Baum (neben Arzneikarte und Zwischenfall) — und tools/dosis-abgleich.js liest
 *      ui/app/index.html gar nicht, es fiele also nie auf, wenn sie auseinanderliefen.
 *
 * Start: node tools/erstwahl-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

var HTML = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');

/* Eine Funktion samt Koerper aus der Datei schneiden — ueber Klammernzaehlung, nicht ueber
 * einen regulaeren Ausdruck: der Koerper enthaelt selbst geschweifte Klammern in Zeichenketten.
 * Zeichenketten und Kommentare werden deshalb beim Zaehlen uebersprungen. */
function schneide(name) {
  var start = HTML.indexOf('function ' + name + '(');
  if (start < 0) return null;
  var i = HTML.indexOf('{', start), tiefe = 0, z = null, esc = false;
  for (var k = i; k < HTML.length; k++) {
    var c = HTML[k];
    if (z) {
      if (esc) { esc = false; continue; }
      if (c === '\\') { esc = true; continue; }
      if (c === z) z = null;
      continue;
    }
    if (c === '"' || c === "'") { z = c; continue; }
    if (c === '/' && HTML[k + 1] === '*') { k = HTML.indexOf('*/', k) + 1; continue; }
    if (c === '/' && HTML[k + 1] === '/') { k = HTML.indexOf('\n', k); continue; }
    if (c === '{') tiefe++;
    else if (c === '}') { tiefe--; if (tiefe === 0) return HTML.slice(start, k + 1); }
  }
  return null;
}

block('1. Die Bausteine sind ueberhaupt da');
var quellen = ['erstwahlLoeschen', 'arzneiSperre', 'erstwahlSetzen', 'erstwahlAusZwischenfall', 'erstwahlRef', 'erstwahlHtml', 'renderErstwahl'];
var teile = {};
quellen.forEach(function (n) {
  teile[n] = schneide(n);
  ok('function ' + n + '() steht in ui/app/index.html', !!teile[n]);
});
if (quellen.some(function (n) { return !teile[n]; })) {
  console.log('\nABBRUCH: ohne die Funktionen laesst sich nichts fahren.');
  process.exit(1);
}

/* ---- Umgebung bauen: echte Daten, minimale Stubs ---- */
global.window = {};
require(path.join(WURZEL, 'ui/app/anaes-data.js'));
require(path.join(WURZEL, 'ui/shared/anaes-exotic-doses.js'));
var A = global.window.ANAES;

var umgebung = {
  A: A,
  state: { sp: 'hund', wt: 24, wtGesetzt: true, incident: null, erstwahl: null, erstwahlAlle: null, givenDrugs: [] },
  gaben: {},                       /* wirkstoffId -> Minuten seit Gabe (null = nie) */
  fmt: function (x) { return String(x); }
};
umgebung.gabeMinAny = function (ids) {
  for (var i = 0; i < ids.length; i++) if (umgebung.gaben[ids[i]] != null) return umgebung.gaben[ids[i]];
  return null;
};
umgebung.drugById = function (id) { return A.drugs.filter(function (d) { return d.id === id; })[0]; };
umgebung.sp = function () { return A.species.filter(function (s) { return s.id === umgebung.state.sp; })[0]; };

var namen = Object.keys(umgebung);
var werte = namen.map(function (n) { return umgebung[n]; });
var quelltext = quellen.slice(0, 5).map(function (n) { return teile[n]; }).join('\n') +
  '\nreturn { arzneiSperre:arzneiSperre, erstwahlSetzen:erstwahlSetzen, ' +
  'erstwahlAusZwischenfall:erstwahlAusZwischenfall, erstwahlRef:erstwahlRef };';
var F;
try { F = Function.apply(null, namen.concat([quelltext])).apply(null, werte); }
catch (e) { console.log('\nABBRUCH: der herausgeschnittene Code laesst sich nicht uebersetzen: ' + e.message); process.exit(1); }
ok('der herausgeschnittene Code laeuft', !!F && typeof F.arzneiSperre === 'function');

/* ================================================================================ */
block('2. Die vier Sperren — jede in BEIDE Richtungen');
var S = F.arzneiSperre;

umgebung.gaben = {};
ok('Naloxon OHNE protokolliertes Opioid: gesperrt', !!S('naloxon', {}));
ok('… und der Grund nennt das fehlende Opioid', /Opioid/.test(S('naloxon', {}) || ''));
umgebung.gaben = { fentanyl: 12 };
ok('Naloxon MIT protokolliertem Opioid: frei', S('naloxon', {}) === null);

umgebung.gaben = {};
ok('Flumazenil ohne Benzodiazepin: gesperrt', !!S('flumazenil', {}));
umgebung.gaben = { midazolam: 5 };
ok('Flumazenil mit Midazolam: frei', S('flumazenil', {}) === null);

umgebung.gaben = {};
ok('Atipamezol ohne alpha2: gesperrt', !!S('atipamezol', {}));
umgebung.gaben = { dexmedetomidin: 20 };
ok('Atipamezol mit Dexmedetomidin: frei', S('atipamezol', {}) === null);

umgebung.gaben = {};
ok('Adrenalin OHNE Kreislaufstillstand: gesperrt', !!S('adrenalin', { stillstand: false }));
ok('… und der Grund nennt das Kammerflimmern als Gefahr', /Kammerflimmern/.test(S('adrenalin', {}) || ''));
ok('Adrenalin IM Kreislaufstillstand: frei', S('adrenalin', { stillstand: true }) === null);

/* ================================================================================ */
block('3. Anticholinergikum: drei Lagen, drei verschiedene Antworten');
ok('Atropin bei Bradykardie MIT gemessener Hypotonie: frei',
  S('atropin', { hypoton: true, druckBekannt: true }) === null);
var gutGemessen = S('atropin', { hypoton: false, druckBekannt: true });
ok('Atropin bei gemessenem, tragendem Druck: gesperrt', !!gutGemessen);
ok('… und der Grund spricht von der MESSUNG ("Der Blutdruck traegt")',
  /Der Blutdruck tr/.test(gutGemessen || ''));
var ohneMessung = S('atropin', { hypoton: false, druckBekannt: false });
ok('Atropin OHNE Blutdruckmessung: ebenfalls gesperrt', !!ohneMessung);
/*
 * DIESE PRUEFUNG IST DER EIGENTLICHE ANLASS DES ABSCHNITTS. Die erste Fassung gab in beiden
 * Faellen denselben Satz aus — und behauptete damit einem Tierarzt ohne angeschlossenes Geraet
 * gegenueber, der Blutdruck seines Patienten sei in Ordnung. Die Station misst und schweigt im
 * Zweifel; sie behauptet nicht.
 */
ok('… aber mit einem ANDEREN Grund: sie sagt, dass nicht gemessen wurde',
  /nicht gemessen/.test(ohneMessung || '') && !/Der Blutdruck tr/.test(ohneMessung || ''),
  'gelesen: ' + String(ohneMessung).slice(0, 90));
ok('Im Kreislaufstillstand gilt die Druckregel NICHT (RECOVER: Atropin bei Vagotonus)',
  S('atropin', { hypoton: false, druckBekannt: false, stillstand: true }) === null);
ok('Glycopyrrolat folgt derselben Regel wie Atropin',
  !!S('glyco', { hypoton: false, druckBekannt: true }) && S('glyco', { hypoton: true, druckBekannt: true }) === null);

/* ================================================================================ */
block('4. Die Auswahl: welche Lage steht oben, und bleibt sie stehen');
umgebung.gaben = {};
function karteMit(inc, sev, erst, titel) {
  return { erst: erst, title: titel || ('Karte ' + inc), tag: inc, color: '#f00', inc: inc, sev: sev };
}
function wert(id, incId) { return { p: { id: id, abbr: id.toUpperCase(), unit: '' }, dir: 'low', x: 1, inc: incId, far: 0.3 }; }

umgebung.state.erstwahl = null; umgebung.state.erstwahlAlle = null;
F.erstwahlSetzen([karteMit('bradykardie', 4, { vor: ['Verdampfer senken'], reihe: [], nach: ['atropin'] })],
  [wert('nibp', 'hypotension')], { hypoton: true, druckBekannt: true });
ok('eine Kreuz-Karte mit Rangfolge steht oben', umgebung.state.erstwahl.inc === 'bradykardie');
ok('die zweite gleichzeitige Lage geht NICHT verloren',
  (umgebung.state.erstwahlAlle || []).length === 2 &&
  umgebung.state.erstwahlAlle[1].inc === 'hypotension');
ok('die Einzelwert-Lage erbt die Reihenfolge ihres Zwischenfalls (Ephedrin zuerst)',
  umgebung.state.erstwahlAlle[1].erst.reihe[0] === 'ephedrin',
  'gelesen: ' + JSON.stringify(umgebung.state.erstwahlAlle[1].erst.reihe));

/* Der Nutzer schaltet auf die zweite Lage um — der naechste Messtakt darf ihn nicht
 * zurueckwerfen, sonst liest er waehrend einer Narkose gegen die Uhr. */
umgebung.state.erstwahl = umgebung.state.erstwahlAlle[1];
F.erstwahlSetzen([karteMit('bradykardie', 4, { vor: [], reihe: [], nach: ['atropin'] })],
  [wert('nibp', 'hypotension')], { hypoton: true, druckBekannt: true });
ok('die angesehene Lage bleibt ueber den naechsten Messtakt gewaehlt',
  umgebung.state.erstwahl.inc === 'hypotension');

/* Faellt sie weg, geht es auf die staerkste zurueck. */
F.erstwahlSetzen([karteMit('bradykardie', 4, { vor: [], reihe: [], nach: ['atropin'] })], [],
  { hypoton: true, druckBekannt: true });
ok('faellt die angesehene Lage weg, steht wieder die staerkste da',
  umgebung.state.erstwahl.inc === 'bradykardie');

F.erstwahlSetzen([], [], {});
ok('kein Befund -> keine Erstwahl (nichts bleibt stehen)',
  umgebung.state.erstwahl === null && umgebung.state.erstwahlAlle === null);

/* ================================================================================ */
block('5. Ohne Messung: der von Hand gewaehlte Zwischenfall traegt');
umgebung.state.incident = 'bradykardie';
var vonHand = F.erstwahlAusZwischenfall();
ok('er liefert eine Erstwahl', !!vonHand && vonHand.inc === 'bradykardie');
/*
 * NUR DAS ERSTE MITTEL BEKOMMT EINE RANGZAHL (geaendert 21.08.2026, nach dem Gegenpruefen).
 *
 * Die erste Fassung setzte ALLE Arzneien des Zwischenfalls in reihe — also alle mit Rangzahl,
 * also alle als "jetzt". Bei einer Katze mit Sinustachykardie stand Lidocain damit als
 * Erstwahl Nr. 3, obwohl die klinische Leiter in renderAssess() fuer die Katze eine
 * ausdrueckliche Lidocain-Sperre kennt (RECOVER 2024). Der Zwischenfall fuehrt seine Arzneien
 * als AUSWAHL, nicht als Reihenfolge; wer sie durchnummeriert, behauptet eine Rangfolge, die
 * dort nie stand — und umgeht dabei genau die Leiter, um derentwillen es die Liste gibt.
 */
ok('nur das erste Mittel des Zwischenfalls bekommt eine Rangzahl',
  vonHand.erst.reihe.join(',') === 'atropin', 'gelesen: ' + vonHand.erst.reihe.join(','));
ok('der Rest steht unter "danach", geht aber nicht verloren',
  vonHand.erst.nach.join(',') === 'glyco', 'gelesen: ' + vonHand.erst.nach.join(','));
ok('… und die Liste sagt ausdruecklich, dass sie KEINE Rangfolge ist',
  /Auswahl, nicht als Rangfolge/.test(vonHand.erst.merk || ''));
ok('er kennzeichnet sich als ERKLAERT, nicht gemessen', vonHand.quelle === 'zwischenfall');
ok('… und sagt ausdruecklich, dass der Druck nicht bekannt ist', vonHand.lage.druckBekannt === false);
ok('… ein Stillstand gilt nur beim Zwischenfall "asystolie"', vonHand.lage.stillstand === false);
umgebung.state.incident = 'asystolie';
ok('… und dort dann schon', F.erstwahlAusZwischenfall().lage.stillstand === true);
umgebung.state.incident = 'gibtesnicht';
ok('unbekannter Zwischenfall -> nichts', F.erstwahlAusZwischenfall() === null);

/* ================================================================================ */
block('6. Die Mengen kommen aus der bestehenden Quelle, nicht aus einer neuen');
var refBrady = F.erstwahlRef('atropin', 'bradykardie');
var kb = A.incidents.filter(function (i) { return i.id === 'bradykardie'; })[0];
var db = kb.drugs.filter(function (d) { return d.id === 'atropin'; })[0];
ok('die Dosis eines Zwischenfall-Mittels ist ZEICHENGLEICH mit dem Zwischenfall',
  refBrady.low === db.low && refBrady.high === db.high && refBrady.unit === db.unit && refBrady.route === db.route,
  JSON.stringify(refBrady));
var refFremd = F.erstwahlRef('terbutalin', 'hypoxaemie');
var terb = umgebung.drugById('terbutalin').species.hund;
ok('ein Mittel, das der Zwischenfall nicht fuehrt, bekommt die ARTDOSIS der Arzneikarte',
  refFremd.low === terb.low && refFremd.high === terb.high && refFremd.unit === terb.unit,
  JSON.stringify(refFremd));

/*
 * ========================================================================================
 * DIE ARZNEIKARTE IST DIE INSTANZ — DER TEUERSTE BEFUND DES GEGENPRUEFENS (21.08.2026).
 * ========================================================================================
 * Die erste Fassung nahm die Dosis des Zwischenfalls, sobald es eine gab. Nachgerechnet ueber
 * ALLE Zwischenfaelle und ALLE zwoelf Tierarten war das an 66 Stellen falsch, und zwar
 * systematisch: die Zahlen in A.incidents[].drugs sind fuer Hund und Katze geschrieben und
 * tragen keinerlei Artunterscheidung. Ein Kaninchen mit Bradykardie bekam Atropin
 * 0,02-0,04 mg/kg angeboten, waehrend die eigene Arzneikarte fuer das Kaninchen 0,1-0,5 mg/kg
 * fuehrt — das Fuenf- bis Zwoelffache. Die richtige Zahl stand in derselben Anwendung, einen
 * Reiter weiter.
 *
 * Die Regel lautet seither: die Artdosis der Arzneikarte gilt; der Zwischenfall darf nur
 * EINGRENZEN. Diese Pruefung faehrt das fuer jede Kombination aus Zwischenfall, Arznei und
 * Tierart durch und ist damit zugleich der Waechter gegen einen kuenftigen Eintrag, der es
 * wieder einreisst.
 */
(function () {
  var artFehler = [], eingegrenzt = 0;
  A.incidents.forEach(function (inc) {
    (inc.drugs || []).forEach(function (d) {
      var karte = umgebung.drugById(d.id);
      if (!karte) return;
      A.species.forEach(function (art) {
        umgebung.state.sp = art.id;
        var spd = karte.species[art.id];
        var ref = F.erstwahlRef(d.id, inc.id);
        if (!spd || spd.low == null) {
          if (!ref.ohneArtdosis) artFehler.push(inc.id + '/' + d.id + '/' + art.id + ': Dosis ohne Artangabe');
          return;
        }
        if (ref.low == null) { artFehler.push(inc.id + '/' + d.id + '/' + art.id + ': keine Dosis, obwohl die Karte eine hat'); return; }
        if (ref.low < spd.low - 1e-9 || ref.high > spd.high + 1e-9 || ref.unit !== spd.unit) {
          artFehler.push(inc.id + '/' + d.id + '/' + art.id + ': ' + ref.low + '-' + ref.high + ' ' + ref.unit +
            ' liegt AUSSERHALB der Artspanne ' + spd.low + '-' + spd.high + ' ' + spd.unit);
        }
        if (ref.low > spd.low + 1e-9 || ref.high < spd.high - 1e-9) eingegrenzt++;
      });
    });
  });
  umgebung.state.sp = 'hund';
  ok('KEINE gezeigte Dosis liegt ausserhalb der Artspanne der Arzneikarte',
    artFehler.length === 0, artFehler.slice(0, 5).join(' | '));
  /* Gegenprobe zur Regel selbst: naehme man immer nur die Artspanne, waere die fallbezogene
   * Eingrenzung verschwunden und der Zwischenfall zum blossen Verweis geworden. Es MUSS also
   * Stellen geben, an denen enger gerechnet wird, als die Karte erlaubt. */
  ok('… und die fallbezogene Eingrenzung ist trotzdem erhalten', eingegrenzt > 0,
    'sonst waere der Zwischenfall zum blossen Verweis auf die Arzneikarte geworden');
})();

/* Ohne Artdosis wird NICHTS gerechnet — und die Karte sagt das, statt leer zu bleiben. */
umgebung.state.sp = 'kaninchen';
var refOhne = F.erstwahlRef('amiodaron', 'asystolie');
ok('kein Wert fuer eine Tierart ohne Artdosis (Amiodaron kennt nur Hund und Katze)',
  refOhne.ohneArtdosis === true && refOhne.low == null, JSON.stringify(refOhne));
umgebung.state.sp = 'hund';

/* ================================================================================ */
block('7. In den erst-Bloecken steht KEINE Dosis');
/*
 * Der Waechter gegen den dritten Ort fuer dieselbe Zahl. Gesucht wird in den erst-Bloecken der
 * xc()-Aufrufe nach Mustern wie "0,01 mg/kg" oder "5 mg/kg". Erlaubt bleiben Vol% (der
 * Verdampfer ist keine Arznei), ml/kg (Volumenbolus), Zeit- und Frequenzangaben.
 */
var ohneKommentar = HTML.replace(/\/\*[\s\S]*?\*\//g, ' ');
var erstBloecke = ohneKommentar.match(/\{\s*vor:\[[\s\S]{0,4000}?\}\)/g) || [];
ok('es gibt ueberhaupt erst-Bloecke zu pruefen', erstBloecke.length >= 8, 'gefunden: ' + erstBloecke.length);
var dosisMuster = /\d+[,.]?\d*\s*(mg|mcg|µg|U|IU|mEq|mmol)\s*\/\s*kg/i;
var treffer = [];
erstBloecke.forEach(function (b) {
  var m = b.match(dosisMuster);
  if (m) treffer.push(m[0] + '  in: ' + b.replace(/\s+/g, ' ').slice(0, 110));
});
ok('kein erst-Block traegt eine Dosis je Kilogramm', treffer.length === 0, treffer.join(' | '));

/* ================================================================================ */
block('8. Die Oberflaeche haengt wirklich daran');
ok('der Medikamenten-Reiter hat den Platz dafuer', /<div id="erstwahl"><\/div>/.test(HTML));
ok('er steht VOR der Wirkstoffliste', HTML.indexOf('id="erstwahl"') < HTML.indexOf('id="drugList"'));
ok('renderAssess() reicht seinen Befund weiter', /erstwahlSetzen\(cross, items, sperrLage\)/.test(ohneKommentar));
ok('… und zeichnet die Liste danach neu', /renderErstwahl\(\);/.test(ohneKommentar));
ok('auch wenn gar kein Befund uebrig bleibt',
  /Patient stabil\.<\/div>'; renderErstwahl\(\); return;/.test(ohneKommentar),
  'sonst bliebe der letzte Befund stehen, obwohl das Tier stabil ist');
ok('… und wenn die Messung ganz abgeschaltet wird',
  /erstwahlLoeschen\(\); renderErstwahl\(\); return;/.test(ohneKommentar));
/* EINE Loeschstelle fuer BEIDE Felder. state.erstwahl wurde an drei Stellen einzeln auf null
 * gesetzt, state.erstwahlAlle blieb dabei jedes Mal stehen — der Umschalter "Gleichzeitig
 * erkannt" zeigte danach Lagen, die es nicht mehr gab, und holte sie auf Klick zurueck. */
ok('es gibt genau EINE Stelle, die die Erstwahl loescht',
  (ohneKommentar.match(/function erstwahlLoeschen\(\)/g) || []).length === 1 &&
  /state\.erstwahl=null; state\.erstwahlAlle=null;/.test(ohneKommentar));
ok('… und der Artwechsel benutzt sie',
  /state\.adrHigh=false;[\s\S]{0,200}erstwahlLoeschen\(\);/.test(ohneKommentar),
  'eine Empfehlung fuer das vorige Tier darf das naechste nicht erreichen');
ok('die Gabe entsteht durch den KLICK, nicht durch die Anzeige',
  /#erstwahl \[data-give-drug\]'\)\.forEach\(function\(b\)\{ b\.onclick=/.test(ohneKommentar));
ok('die Liste benutzt doseLine() — dieselbe Rechnung wie ueberall sonst',
  /var ref=erstwahlRef\(id, q\.inc\);/.test(ohneKommentar) && /doseLine\(ref\)/.test(ohneKommentar));
/*
 * WAS ANGEZEIGT WIRD, MUSS AUCH GEBUCHT WERDEN.
 * Die Anzeige nimmt unter Umstaenden die engere Dosis des Zwischenfalls (Atropin beim Hund im
 * Kreislaufstillstand: 0,04 statt 0,02-0,04). medDosisText() rechnete dagegen immer aus der
 * Artdosis — auf der Karte stand also eine Zahl und im Gaben-Protokoll eine andere. Das
 * Protokoll ist ausdruecklich unveraenderlich: eine falsche Anzeige laesst sich berichtigen,
 * eine falsche Protokollzeile nie.
 */
ok('der Buchungstext bekommt DENSELBEN Bezug wie die Anzeige',
  /medDosisText\(id, erstwahlRef\(id,/.test(ohneKommentar));
ok('… und medDosisText nimmt ihn ueberhaupt an', /function medDosisText\(id, ref\)/.test(ohneKommentar));
/* Ohne Artdosis kein Buchungsknopf: ein Klick haette eine Gabe OHNE Dosis in ein Dokument
 * geschrieben, das sich nicht mehr aendern laesst. */
ok('ohne Artdosis gibt es keinen Buchungsknopf', /if\(ref\.ohneArtdosis\)\{/.test(ohneKommentar));
ok('gesperrte Mittel werden GEZEIGT, nicht weggelassen',
  /ew-sperre/.test(HTML) && /NICHT jetzt/.test(HTML),
  'wer ein Mittel sucht und nicht findet, sucht weiter; wer es durchgestrichen sieht, hoert auf');

var DOLLAR = String.fromCharCode(36);
var BS = String.fromCharCode(92);
/* ================================================================================ */
block('9. Ein einzelnes $ vor .forEach — der Fehler, der jeden Test gruen laesst');
/*
 * DIESER ABSCHNITT HAT EINEN ANLASS, UND ZWAR EINEN TEUREN (21.08.2026).
 *
 * Beim Einbau der Erstwahl wurde aus $$('#erstwahl [data-ew-idx]') ein einfaches
 * $('#erstwahl [data-ew-idx]') — ein verschlucktes Zeichen. $ liefert EIN Element oder null,
 * $$ liefert eine Liste. .forEach() darauf wirft also, sobald der Knopf gerade fehlt.
 *
 * WAS DANN GESCHAH: boot() brach an dieser Zeile ab. Alles danach lief nie — die Wirkstoffliste
 * blieb leer, und das Gewichtsfeld bekam keinen Zuhoerer. Damit rechnete die GANZE Anwendung
 * weiter mit dem Vorgabewert 10 kg, egal was jemand eintippte.
 *
 * UND JETZT DER PUNKT: die 111 Pruefungen von webapp-fern-test.js waren gruen, darunter
 * ausdruecklich eine Syntaxprobe (new Function). Ein Aufruf auf null ist eben kein
 * Syntaxfehler. Keiner der damals 101 Testlaeufe hat es gemerkt. Gefunden wurde es NUR, weil
 * die Seite wirklich geladen und die Fehlerkonsole gelesen wurde.
 *
 * Ein vollstaendiger Waechter waere ein Browser im Sammellauf; den gibt es hier nicht. Diese
 * Quellpruefung faengt dafuer genau die Fehlerklasse ab, an der es passiert ist — billig, und
 * sie haette gereicht.
 */
['ui/app/index.html', 'tools/web-fern-modul.html', 'ui/vetstation-live.js'].forEach(function (rel) {
  var voll = path.join(WURZEL, rel);
  if (!fs.existsSync(voll)) { console.log('  (' + rel + ' liegt nicht da)'); return; }
  var zeilen = fs.readFileSync(voll, 'utf8').split(String.fromCharCode(10));
  var treffer = [];
  var muster = new RegExp('(^|[^' + DOLLAR + '\\w.])' + BS + DOLLAR + '\\([^)]*\\)\\.forEach', 'g');
  zeilen.forEach(function (l, k) {
    muster.lastIndex = 0;
    var m;
    while ((m = muster.exec(l))) treffer.push(rel + ':' + (k + 1) + '  ' + m[0].trim());
  });
  ok('kein einzelnes ' + DOLLAR + '(...).forEach in ' + rel, treffer.length === 0, treffer.join(' | '));
});

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
