'use strict';
/*
 * glukose-bezug-gegenprobe.js — wird tools/glukose-bezug-test.js wirklich rot? Vier Richtungen, darunter der Originalfehler.
 * Nicht im Sammellauf: die Datei veraendert kurzzeitig zwei Quelldateien (mit finally
 * wiederhergestellt und danach nachgeprueft). Von Hand aus quellcode/ starten.
 *
 * Die wichtigste Probe ist die erste: der Test muss den Stand von VOR der Berichtigung
 * ablehnen. Ein Test, der den eigenen Anlass durchgehen laesst, prueft nichts.
 */
var fs = require('fs');
var cp = require('child_process');
var pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function lauf() {
  var r = cp.spawnSync('dist/VetStation/node/node.exe', ['tools/glukose-bezug-test.js'], { encoding: 'utf8' });
  return { code: r.status, aus: String(r.stdout || '') + String(r.stderr || '') };
}
function probe(name, datei, alt, neu, erwartet) {
  var orig = fs.readFileSync(datei, 'utf8');
  if (orig.indexOf(alt) < 0) { ok(name, false, 'Anker fehlt in ' + datei); return; }
  try {
    fs.writeFileSync(datei, orig.replace(alt, function () { return neu; }));
    var r = lauf();
    ok(name, r.code !== 0 && new RegExp('✗ ' + erwartet).test(r.aus),
      r.code === 0 ? 'BLIEB GRUEN' : 'rot, aber nicht an der erwarteten Zeile');
  } finally { fs.writeFileSync(datei, orig); }
}

var NR = 'ui/shared/narkose-risiko.js';
var BK = 'ui/shared/breed-katalog.js';
console.log('Gegenprobe des Glukose-Waechters\n');
ok('unveraendert gruen', lauf().code === 0);

/* 1) DER ORIGINALFEHLER, wortwoertlich wiederhergestellt. */
probe('der Fehler von vorher faellt auf', NR,
  '0,5–1 mL/kg der UNVERDÜNNTEN 50-%-Lösung abmessen (= 0,25–0,5 g/kg), mindestens 1:4 verdünnen und langsam i.v. über 5 min geben. Die mL/kg beziehen sich auf die 50-%-Stammlösung, nicht auf die fertige Verdünnung.',
  'Glukose 50 % 1:4 verdünnen und 0,5–1 mL/kg der verdünnten Lösung langsam i.v. über 5 min geben (entspricht etwa 0,25–0,5 g/kg).',
  'Rettungsweg Hypoglykaemie: das Volumen ist das der UNVERDUENNTEN Loesung');

/* 2) Die reine RECHNUNG: Volumen halbiert, Klammer stehen gelassen. */
probe('eine falsche Rechnung faellt auf (Volumen halbiert)', BK,
  '0,5-1 ml/kg Glukose 50 Prozent abmessen (entspricht 0,25-0,5 g/kg)',
  '0,25-0,5 ml/kg Glukose 50 Prozent abmessen (entspricht 0,25-0,5 g/kg)',
  'jede Volumenangabe ergibt die daneben genannte Menge');

/* 3) Das Verduennen wegfallen lassen - unverduennte 50-%-Glukose schaedigt die Vene. */
probe('weggefallenes Verduennen faellt auf', NR,
  'mindestens 1:4 verdünnen und langsam i.v.',
  'langsam i.v.',
  '… und verlangt weiterhin das Verduennen');

/* 4) Der gut gemeinte Griff: das Frettchen "mitberichtigen". */
probe('das Vervierfachen der Insulinom-Dosis faellt auf', NR,
  '0,25–0,5 mL/kg der verdünnten Lösung langsam i.v.',
  '0,25–0,5 mL/kg der unverdünnten 50-%-Lösung langsam i.v.',
  'Frettchen mit Insulinom: weiterhin 0,25-0,5 mL/kg der VERDUENNTEN Loesung');

ok('beide Dateien wiederhergestellt und wieder gruen', lauf().code === 0);
console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
