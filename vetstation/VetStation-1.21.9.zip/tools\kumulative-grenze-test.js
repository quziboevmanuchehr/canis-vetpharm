'use strict';
/*
 * kumulative-grenze-test.js — wo eine Arznei bolusweise wiederholt wird, muss die Station die
 * SUMMENGRENZE nennen, nicht nur die Einzeldosis.
 *
 * BEFUND 19.08.2026, bei CliniPharm/vetpharm selbst nachgelesen
 * (https://www.vetpharm.uzh.ch/Wirkstoffe/000000010359/8034_05.html):
 *
 *   Katze und Hund, Esmolol, Rubrik "Ventrikulaere Tachykardie" und "Supraventrikulaere
 *   Tachyarrhythmie", woertlich: "0,05 - 0,5 mg/kg als Bolus alle 5 Minuten; BIS MAXIMAL
 *   0,5 mg/kg (Fox 1999b)".
 *
 *   Die Arzneikarte nannte nur die Einzelgabe 0,05-0,5 mg/kg. Wer nachdosiert, weil die
 *   Frequenz nicht faellt, ueberschreitet eine Grenze, die die Station gar nicht erwaehnt.
 *   Bei einem negativ inotropen Betablocker am kreislauflabilen Patienten ist das nicht
 *   nebensaechlich.
 *
 *   Ebenso fehlte in der Indikationszeile der Katze die ventrikulaere Tachykardie - vetpharm
 *   fuehrt sie als EIGENE Rubrik. Die Zahl stimmte, aber wer ein Mittel gegen die
 *   Kammertachykardie der Katze suchte, las an der Karte vorbei.
 *
 * WAS DIESER TEST TUT, und warum er mehr ist als eine Textsuche: er RECHNET. Wo eine
 * Summengrenze genannt ist, muss sie mindestens so gross sein wie die Einzeldosis - sonst
 * waere schon die erste erlaubte Gabe verboten, und die Karte widerspraeche sich selbst.
 *
 * Start: node tools/kumulative-grenze-test.js
 */
var fs = require('fs');
var path = require('path');
var vm = require('vm');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

var sb = { self: {} };
sb.window = sb.self; sb.self.window = sb.self;
vm.createContext(sb);
vm.runInContext(fs.readFileSync(path.join(WURZEL, 'ui/app/anaes-data.js'), 'utf8'), sb);
vm.runInContext(fs.readFileSync(path.join(WURZEL, 'ui/shared/anaes-exotic-doses.js'), 'utf8'), sb);
var A = sb.self.ANAES;
function karte(id) { return (A.drugs || []).filter(function (d) { return d.id === id; })[0]; }

console.log('VetStation — Summengrenzen bei wiederholbaren Boli\n');

console.log('1) Esmolol nennt die Rubrik, unter der man das Mittel sucht:');
var es = karte('esmolol');
ok('die Karte gibt es', !!es);
['hund', 'katze'].forEach(function (a) {
  var s = es.species[a];
  /*
   * Der Wortanfang MUSS geprueft werden. Beim ersten Versuch stand hier schlicht
   * /ventrikuläre Tachykardie/i - und das trifft auch auf "SUPRAventrikuläre Tachykardie"
   * zu, das schon vorher dastand. Der Test war gruen und haette den alten, unvollstaendigen
   * Stand anstandslos durchgelassen; gemerkt hat es nur die Gegenprobe.
   */
  ok(a + ': die ventrikuläre Tachykardie steht in der Indikation',
    /(^|[^a-zäöüß])ventrikuläre Tachykardie/i.test(String(s.indication)),
    'vetpharm fuehrt sie als eigene Rubrik - ohne den Eintrag findet sie niemand');
});

console.log('\n2) … und die Grenze, die beim Nachdosieren gilt:');
['hund', 'katze'].forEach(function (a) {
  var s = es.species[a];
  ok(a + ': die Summengrenze ist genannt',
    /SUMME höchstens 0,5 mg\/kg/.test(String(s.notes)),
    'Nur die Einzeldosis zu nennen laedt zum Nachlegen ohne Ende ein');
  ok(a + ': … samt Mindestabstand von 5 min',
    /alle 5 min/i.test(String(s.notes)));
  ok(a + ': … und dem Weg danach (Dauertropf statt weiterer Bolus)',
    /Dauertropf/.test(String(s.notes)));
});

console.log('\n3) Die Rechnung: eine Summengrenze unter der Einzeldosis waere unmöglich.');
/*
 * Diese Pruefung ist der Grund, warum der Test nicht nur nach Woertern sucht. Wer die
 * Einzeldosis spaeter anhebt und die Grenze stehen laesst, baut eine Karte, deren erste
 * erlaubte Gabe schon verboten ist - und keine Textsuche wuerde das bemerken.
 */
var gefunden = 0;
(A.drugs || []).forEach(function (d) {
  Object.keys(d.species || {}).forEach(function (a) {
    var s = d.species[a];
    if (!s || !(s.high > 0)) return;
    var txt = String(s.notes || '') + ' ' + String(s.caution || '');
    var m = /SUMME höchstens ([0-9]+[.,]?[0-9]*) (mg|µg|mcg)\/kg/.exec(txt);
    if (!m) return;
    gefunden++;
    var grenze = parseFloat(m[1].replace(',', '.'));
    /* Einheiten angleichen: die Karte fuehrt mg/kg oder mcg/kg. */
    var einzel = s.high;
    var eU = String(s.unit).toLowerCase().replace('µ', 'u').replace('mcg', 'ug');
    var gU = m[2].toLowerCase().replace('µ', 'u').replace('mcg', 'ug');
    if (eU.indexOf('ug/kg') === 0 && gU === 'mg') einzel = einzel / 1000;
    if (eU.indexOf('mg/kg') === 0 && gU === 'ug') einzel = einzel * 1000;
    ok(d.name + '/' + a + ': Summengrenze ' + grenze + ' ' + m[2] + '/kg >= Einzeldosis ' + s.high + ' ' + s.unit,
      grenze >= einzel - 1e-9,
      'Die erste erlaubte Gabe laege schon ueber der Gesamtgrenze');
  });
});
ok('es gibt ueberhaupt Summengrenzen zu pruefen (' + gefunden + ')', gefunden >= 2,
  'Ohne Fundstellen prueft dieser Abschnitt nichts');

console.log('\n4) Die Quelle, die diese Zahlen traegt, ist genannt:');
ok('Esmolol nennt CliniPharm/vetpharm',
  (es.sources || []).some(function (q) { return /vetpharm/i.test(q); }),
  'Die Summengrenze und die VT-Rubrik stammen von dort, nicht aus RECOVER');

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
