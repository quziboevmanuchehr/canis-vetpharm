'use strict';
/*
 * qrs-breite-test.js — wie genau misst qrsBreiteMs() wirklich?
 *
 * WARUM ES DIESE DATEI GIBT (Befund 20.08.2026):
 *
 * Der Baum trug an zwei Stellen eine Fehlerangabe, die BEIDE falsch waren:
 *   ui/shared/ekg-analyse.js:293  "systematisch zu kurz - rund 20 % gegenueber der gezeichneten Dauer"
 *   ui/app/index.html             "-20 % Hund, -43 % Katze, -40 % P-Dauer"
 *
 * Beide stammen aus Messungen gegen den Gauss-Generator in tools/ekg-analyse-test.js:31-38.
 * Der zeichnet eine Glocke ueber plus/minus b Abtastwerte, wobei b aus breiteMs folgt - die
 * GEZEICHNETE Gesamtbreite ist damit 2b, also das Doppelte der Vorgabe, und eine Glocke hat
 * ohnehin keinen scharfen Rand. Gegen so einen Streifen gemessen, misst man den Massstab.
 *
 * DIE EINDEUTIGE REFERENZ, die dieser Test benutzt: eine Halbwelle
 *      wert(t) = A * sin(pi * t / D)   fuer 0 <= t <= D, sonst GENAU NULL.
 * Ihre Dauer ist unstrittig D, weil das Signal ausserhalb exakt null ist.
 *
 * DAGEGEN GEMESSEN (500 Hz, rauschfrei) ist der Fehler klein und haengt an der ABTASTRATE,
 * nicht an der Tierart und nicht an der Breite:
 *
 *      125 Hz   -12 bis -18 ms
 *      200 Hz   -10 ms durchweg
 *      250 Hz    -6 bis  -8 ms      <- der uebliche Bereich
 *      500 Hz    -4 bis  -8 ms
 *     1000 Hz    -2 bis  -8 ms
 *
 * Bei hoher Abtastrate bleibt allein der Schwellenanteil uebrig: die Halbwelle kreuzt die
 * 8-%-Grenze bei t = D*asin(0,08)/pi, also rund 2,6 % innen - beidseitig rund 5 % der Dauer.
 * Das deckt sich mit der Messung (D=140 -> -8 ms = -5,7 %).
 *
 * WAS DARAUS FOLGT, und warum dieser Test wichtiger ist als eine Korrektur:
 * Die Messung ist rund VIERMAL besser als der Baum behauptete. Wer die alten -20/-43 % als
 * Korrekturfaktor angebracht haette, haette die gemessene Breite um 25 bis 75 % aufgeblaeht -
 * und die Station haette reihenweise verbreiterte Kammerkomplexe gemeldet, wo keine sind.
 * Das ist die gefaehrliche Richtung: ein erfundener Befund.
 *
 * Dieser Test haelt deshalb den GEMESSENEN Stand fest, statt etwas zu korrigieren:
 * die Messung darf nie zu LANG werden (das erfaende Befunde) und nicht schlechter als heute.
 *
 * Start: node tools/qrs-breite-test.js
 */
var path = require('path');
var E = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-analyse.js'));

var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

/* Die eindeutige Referenz: ausserhalb [0,D] exakt null. */
function halbwelle(hz, dauerMs, amp, rauschAmp, saat) {
  var lang = Math.round(dauerMs / 1000 * hz);
  var n = Math.round(hz * 3), s = new Array(n), i;
  var z = saat || 7;
  function zuf() { z = (z * 1103515245 + 12345) & 0x7fffffff; return z / 0x7fffffff - 0.5; }
  for (i = 0; i < n; i++) s[i] = rauschAmp ? Math.round(zuf() * rauschAmp) : 0;
  var start = Math.round(hz * 1.0);
  for (i = 0; i <= lang; i++) s[start + i] += Math.round(amp * Math.sin(Math.PI * i / lang));
  return { samples: s, r: start + Math.round(lang / 2) };
}
function miss(hz, dauerMs, rausch) {
  var h = halbwelle(hz, dauerMs, 1000, rausch || 0, 11);
  return E.qrsBreiteMs(h.samples, h.r, hz, rausch ? rausch * 0.5 : 0);
}

console.log('VetStation — Genauigkeit der QRS-Breitenmessung\n');

console.log('1) Die Messung darf NIE zu lang ausfallen:');
/*
 * Das ist die einzige Richtung, in der ein Fehler einen Befund ERFINDET. Zu kurz gemessen
 * beruhigt zwar faelschlich, aber der Rhythmus wird zusaetzlich ueber Form und RR beurteilt.
 * Zu lang gemessen heisst unmittelbar "verbreiterter Kammerkomplex".
 */
var RATEN = [125, 200, 250, 256, 400, 500, 1000];
var DAUERN = [30, 40, 50, 60, 70, 80, 100, 120, 140];
var zuLang = [], groesster = 0, tabelle = [];
RATEN.forEach(function (hz) {
  DAUERN.forEach(function (d) {
    var g = miss(hz, d, 0);
    if (g == null) return;
    var f = g - d;
    tabelle.push({ hz: hz, d: d, g: g, f: f });
    if (f > 0) zuLang.push(hz + ' Hz / ' + d + ' ms -> ' + g);
    if (-f > groesster) groesster = -f;
  });
});
ok('es gibt etwas zu pruefen (' + tabelle.length + ' Messpunkte)', tabelle.length >= 50);
ok('keine einzige Messung faellt zu LANG aus', zuLang.length === 0, zuLang.slice(0, 5).join(' | '));

console.log('\n2) Und nicht schlechter als heute gemessen:');
ok('der groesste Fehlbetrag bleibt unter 20 ms (heute ' + groesster + ' ms)', groesster < 20,
  'Bei mehr waere die Messung fuer die Katze unbrauchbar');
/* Im ueblichen Bereich der Geraete ist die Messung deutlich besser. */
var ueblich = tabelle.filter(function (t) { return t.hz >= 200 && t.hz <= 500; });
var schlimmst = 0;
ueblich.forEach(function (t) { if (-t.f > schlimmst) schlimmst = -t.f; });
ok('bei 200-500 Hz bleibt der Fehler unter 12 ms (heute ' + schlimmst + ' ms)', schlimmst < 12);

console.log('\n3) Der Fehler ist KEIN artabhaengiger Prozentsatz:');
/*
 * Genau das behauptete der Baum bis 20.08.2026 ("-20 % Hund, -43 % Katze"). Waere es ein
 * Prozentsatz, muesste der Fehlbetrag mit der Dauer wachsen. Er tut es nicht - bei 250 Hz
 * ist er ueber den ganzen Bereich 30..140 ms nahezu gleich.
 */
var bei250 = tabelle.filter(function (t) { return t.hz === 250; });
var minF = Infinity, maxF = -Infinity;
bei250.forEach(function (t) { if (t.f < minF) minF = t.f; if (t.f > maxF) maxF = t.f; });
ok('bei 250 Hz schwankt der Fehlbetrag ueber 30-140 ms um hoechstens 4 ms ('
  + minF + ' bis ' + maxF + ')', (maxF - minF) <= 4,
  'Ein Prozentsatz muesste mit der Dauer wachsen - er tut es nicht');
var f30 = bei250.filter(function (t) { return t.d === 30; })[0];
var f140 = bei250.filter(function (t) { return t.d === 140; })[0];
ok('als Prozentsatz gelesen waere er bei 30 ms ' + Math.round(-100 * f30.f / 30)
  + ' % und bei 140 ms ' + Math.round(-100 * f140.f / 140) + ' % — also gar kein Prozentsatz',
  Math.abs(-100 * f30.f / 30) > Math.abs(-100 * f140.f / 140) * 1.5);

console.log('\n4) Die Abtastrate ist der bestimmende Anteil:');
function fehlerBei(hz) {
  var e = tabelle.filter(function (t) { return t.hz === hz; }), s = 0;
  e.forEach(function (t) { s += -t.f; });
  return s / e.length;
}
var f125 = fehlerBei(125), f1000 = fehlerBei(1000);
ok('bei 125 Hz ist der Fehler groesser als bei 1000 Hz (' + f125.toFixed(1)
  + ' gegen ' + f1000.toFixed(1) + ' ms)', f125 > f1000,
  'Waere der Fehler ein Verfahrensfehler, haette die Abtastrate keinen Einfluss');

console.log('\n5) Rauschen macht die Messung nicht laenger:');
/* Der Rauschterm (2,5x Grundlinienunruhe) soll verhindern, dass die Messung ins Rauschen
 * laeuft. Er darf sie kuerzer machen, aber nie laenger. */
var schlimm = [];
[250, 500].forEach(function (hz) {
  [30, 50, 80, 120].forEach(function (d) {
    var ohne = miss(hz, d, 0), mit = miss(hz, d, 120);
    if (mit != null && ohne != null && mit > ohne) schlimm.push(hz + '/' + d + ': ' + ohne + ' -> ' + mit);
  });
});
ok('mit Rauschen wird keine Messung laenger als ohne', schlimm.length === 0, schlimm.join(' | '));

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
