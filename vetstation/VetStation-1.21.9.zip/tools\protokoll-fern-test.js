'use strict';
/*
 * protokoll-fern-test.js — ein ERZEUGTES Narkoseprotokoll steht sofort und VOLLSTAENDIG in der
 * Fern-Ansicht (Wunsch aus der Praxis, 21.08.2026).
 *
 * WAS VORHER GALT UND WARUM ES DEM WUNSCH WIDERSPRACH:
 * cloud.js setzt beim Start einen Stempel (prozessStart) und ueberspringt danach JEDE
 * Protokollzeile, die aelter ist. Das ist fuer den laufenden Strom richtig und bleibt — die
 * Begruendung steht ausfuehrlich im Konstruktor von cloud.js (nach einem Neustart wuerde die
 * Station sonst jede bereits uebertragene Zeile erneut anbieten, die Unveraenderlichkeits-Regel
 * lehnt sie ab, und bis zum 30.07.2026 nahm das die Vitalwerte mit).
 *
 * Fuer ein AUSDRUECKLICH erzeugtes Dokument ist es aber falsch: wer nach einem Neustart der
 * Station ein Protokoll erstellt und es fern ausdrucken will, bekaeme einen halben Verlauf —
 * und saehe nicht, dass er halb ist. Seit dem 21.08.2026 gibt es deshalb den Nachtrag, und
 * dieser Test haelt die ganze Kette fest:
 *
 *     Klick am Praxis-PC (PDF / Drucken / Speichern)
 *       -> ui/vetstation-live.js  protokollGemeldet()   send({type:'protokollErzeugt'})
 *       -> bridge/src/server.js   case MSG.PROTOKOLL_ERZEUGT
 *       -> cloud.protokollNachtragen(pid)  + cloud.ausdruckVermerken(rec)
 *       -> saele/<sid>/protokoll/<key>/<ts>   (die Zeilen, vollstaendig)
 *          saele/<sid>/ausdruck/<key>/<ts>    (der Vermerk, DASS es ein Dokument gibt)
 *
 * DIE KETTE HAT SECHS GLIEDER IN VIER DATEIEN. Genau so eine Kette ist in diesem Baum schon
 * mehrfach still gerissen (der direkte Hausweg zwischen zwei Saelen war vollstaendig gebaut und
 * konnte nie funktionieren, weil EIN Aufrufer fehlte). Der Test faehrt sie deshalb wirklich,
 * mit einem echten CloudPublisher und einem gefaelschten Schreibweg, statt nach Woertern zu
 * suchen.
 *
 * Start: node tools/protokoll-fern-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

console.log('VetStation — erzeugtes Protokoll geht vollstaendig in die Fern-Ansicht\n');

/* ================================================================================ */
block('1. Die Kette ist an allen vier Stellen verdrahtet');
var model = fs.readFileSync(path.join(WURZEL, 'bridge/src/model.js'), 'utf8');
var server = fs.readFileSync(path.join(WURZEL, 'bridge/src/server.js'), 'utf8');
var shell = fs.readFileSync(path.join(WURZEL, 'ui/vetstation-live.js'), 'utf8');

var MODEL = require(path.join(WURZEL, 'bridge/src/model.js'));
ok('model.js kennt den Nachrichtentyp', !!(MODEL.MSG && MODEL.MSG.PROTOKOLL_ERZEUGT));
/*
 * DIE ZEICHENKETTE MUSS BEIDSEITIG DIESELBE SEIN. ui/vetstation-live.js laeuft im Browser und
 * kann bridge/src/model.js nicht laden — es schreibt den Wert also als Literal. Laufen die
 * beiden auseinander, faellt kein Test um und keine Fehlermeldung erscheint: die Bridge landet
 * schlicht im default-Zweig ihres switch und tut nichts. Der Knopf am Praxis-PC saehe dabei
 * unveraendert funktionsfaehig aus.
 */
ok('… und die Oberflaeche sendet GENAU diesen Wert',
  shell.indexOf("type: '" + MODEL.MSG.PROTOKOLL_ERZEUGT + "'") >= 0,
  'model.js sagt "' + MODEL.MSG.PROTOKOLL_ERZEUGT + '"');
ok('server.js behandelt ihn', /case MSG\.PROTOKOLL_ERZEUGT:/.test(server));
ok('… und ruft BEIDE Wirkungen auf',
  /cloud\.protokollNachtragen\(/.test(server) && /cloud\.ausdruckVermerken\(/.test(server),
  'der Nachtrag holt die Zeilen, der Vermerk sagt, DASS es ein Dokument gibt');

var shellOhneKommentar = shell.replace(/\/\*[\s\S]*?\*\//g, ' ');
ok('die Oberflaeche meldet beim ERZEUGEN', /protokollGemeldet\(k, 'erstellt'/.test(shellOhneKommentar));
ok('… beim DRUCKEN', /protokollGemeldet\(k, 'gedruckt'/.test(shellOhneKommentar));
ok('… und beim SPEICHERN', /protokollGemeldet\(k, 'gespeichert'/.test(shellOhneKommentar));
/*
 * Ein Ausdruck darf nie an einer Meldung scheitern: die Station steht am narkotisierten Tier,
 * und das Blatt ist wichtiger als der Vermerk darueber.
 */
ok('die Meldung kann den Ausdruck nicht umbringen (sie liegt in try/catch)',
  /function protokollGemeldet\(key, art, datei, zahlen\) \{\s*try \{/.test(shellOhneKommentar));
/*
 * DIE GEMELDETE ZEILENZAHL MUSS DIE DES BLATTES SEIN.
 *
 * Ohne den vierten Parameter zaehlte die Meldung den Fenster-Rueckfall log[key]. Beim Drucken
 * aus dem 30-Tage-Bestand der Station (GET api/protokoll) ist der leer — fern stand dann
 * "0 Zeilen, 0 Gaben" ueber einem Protokoll mit vierhundert Eintraegen, und wer das las, hielt
 * die Uebertragung fuer fehlgeschlagen.
 */
ok('… und sie nennt die Zahlen des wirklich gesetzten Blattes',
  /gedruckteZeilen\[key\] = \{ zeilen: L\.length,/.test(shellOhneKommentar) &&
  /protokollGemeldet\(k, 'erstellt', datei, gedruckteZeilen\[k\]\)/.test(shellOhneKommentar));

/* ================================================================================ */
block('2. Der Nachtrag hebt den Stempel auf — gefahren, nicht gelesen');
var CloudMod = require(path.join(WURZEL, 'bridge/src/cloud.js'));
var CloudPublisher = CloudMod.CloudPublisher || CloudMod;

function stilleLog() { return { info: function () {}, warn: function () {}, error: function () {} }; }
function bauePublisher() {
  var p = new CloudPublisher({ enabled: true, station: 'Testsaal' }, stilleLog());
  p.localId = 'praxis1';
  p.started = true;
  p.stationsid = { sid: function () { return 'st0123456789ab'; }, kollisionsstand: function () { return 'ok'; } };
  return p;
}
var pub = bauePublisher();
ok('ein Publisher laesst sich bauen', !!pub && typeof pub._protokollPfade === 'function');

/*
 * Zwei Zeilen: eine ALT (vor dem Programmstart) und eine NEU. Ohne Nachtrag darf nur die neue
 * angeboten werden — genau das ist der Stempel, und er soll auch weiterhin greifen.
 */
var ALT = pub.prozessStart - 60000;
var NEU = pub.prozessStart + 60000;
var protokoll = { 'Bello 1': [{ ts: ALT, hr: 80, finding: 'Einleitung' }, { ts: NEU, hr: 76, finding: '' }] };

var ohne = pub._protokollPfade(protokoll);
var schluessel = Object.keys(ohne);
ok('ohne Nachtrag geht NUR die neue Zeile', schluessel.length === 1, schluessel.join(', '));
ok('… und zwar die richtige', schluessel[0] && schluessel[0].indexOf(String(NEU)) > 0);
/*
 * DER SCHLUESSEL WIRD SANITISIERT. "Bello 1" darf im Datenbankpfad kein Leerzeichen tragen.
 * Genau an dieser Sanitisierung lief die Web-App bis zum 21.08.2026 vorbei (sie baute den Pfad
 * aus dem ROHEN patientId mit encodeURIComponent) — siehe Abschnitt 4.
 */
ok('der Patientenschluessel ist sanitisiert (kein Leerzeichen im Pfad)',
  schluessel[0] === 'protokoll/Bello_1/' + NEU, schluessel[0]);

/* Zweiter Durchlauf ohne Nachtrag: nichts Neues, die alte Zeile bleibt vermerkt. */
ok('die alte Zeile wird nur EINMAL uebersprungen und dann nie wieder angeboten',
  Object.keys(pub._protokollPfade(protokoll)).length === 1,
  'die neue ist noch offen (sie wurde nicht als gesendet vermerkt), die alte nicht mehr');

/* Jetzt der Nachtrag. */
var an = pub.protokollNachtragen('Bello 1');
ok('protokollNachtragen() nimmt die Anforderung an', an === true);
ok('… und meldet einen laufenden Nachtrag', pub.protokollNachtragLaeuft === 1);
var mit = Object.keys(pub._protokollPfade(protokoll));
ok('MIT Nachtrag gehen BEIDE Zeilen — auch die von vor dem Programmstart', mit.length === 2,
  mit.join(', '));
ok('… die alte ist wirklich dabei', mit.some(function (k) { return k.indexOf(String(ALT)) > 0; }));

/* Der Nachtrag muss sich selbst beenden, sonst waere der Stempel dauerhaft aufgehoben. */
pub._protokollMerken(mit);
var danach = Object.keys(pub._protokollPfade(protokoll));
ok('ist alles uebertragen, sind keine Pfade mehr offen', danach.length === 0, danach.join(', '));
ok('… und der Nachtrag hat sich selbst beendet', pub.protokollNachtragLaeuft === 0,
  'sonst wuerde nach dem naechsten Neustart wieder der ganze Bestand angeboten — genau der '
  + 'Zustand, gegen den der Stempel gebaut ist');

/* Zweimal anfordern darf nicht zweimal zaehlen. */
var p2 = bauePublisher();
p2.protokollNachtragen('Rex');
p2.protokollNachtragen('Rex');
ok('zweimal anfordern zaehlt einmal', p2.protokollNachtragLaeuft === 1);
ok('eine leere Kennung wird abgewiesen', p2.protokollNachtragen('') === false);

/* ================================================================================ */
block('3. Der Ausdruck-Vermerk: eigener Pfad, eigenes Fehlerkonto, kein PDF darin');
var p3 = bauePublisher();
var geschrieben = [];
p3._ensureAuth = function () { return Promise.resolve('TOKEN'); };
p3._write = function (verb, ziel, koerper) { geschrieben.push({ verb: verb, ziel: ziel, koerper: koerper }); return Promise.resolve({}); };
var v = p3.ausdruckVermerken({ patientId: 'Bello 1', patientName: 'Bello', art: 'gedruckt', zeilen: 412, gaben: 7, datei: 'x.pdf' });
ok('ausdruckVermerken() nimmt an', v === true);

var fertig = new Promise(function (res) { setTimeout(res, 30); });
fertig.then(function () {
  ok('genau EIN Schreibvorgang', geschrieben.length === 1, 'es waren ' + geschrieben.length);
  var w = geschrieben[0] || {};
  ok('er geht als PUT', w.verb === 'PUT');
  /*
   * DER PFAD MUSS UNTER saele/<sid>/ LIEGEN. Nur dort greift die Auffangkette der
   * Datenbankregeln (firebase-rtdb-rules.json, "$sonst" unter einem Saal, fuenf Stufen). Auf
   * der flachen Ebene gaebe es keine Regel fuer diesen Zweig — der Vermerk wuerde abgewiesen,
   * und zwar still, weil dieser Schreibvorgang sein eigenes Fehlerkonto hat.
   */
  ok('der Pfad liegt unter saele/<sid>/ausdruck/<schluessel>/<zeitpunkt>',
    /\/live\/praxis1\/saele\/st0123456789ab\/ausdruck\/Bello_1\/\d+\.json/.test(String(w.ziel)),
    String(w.ziel));
  ok('… mit sanitisiertem Schluessel, wie beim Protokoll', String(w.ziel).indexOf('Bello_1') > 0);
  var k = w.koerper || {};
  ok('der Vermerk nennt Art, Zeilenzahl und Gabenzahl',
    k.art === 'gedruckt' && k.zeilen === 412 && k.gaben === 7);
  ok('… und den Saal, aus dem er stammt', !!k.station && !!k.sid);
  /*
   * KEIN PDF IM KOERPER. Die Auffangkette begrenzt jede Zeichenkette unter einem Saal auf 12000
   * Zeichen; ein base64-kodiertes Narkoseprotokoll ist ein Vielfaches davon. Es wuerde
   * abgewiesen, und der Tierarzt saehe fern einen Vermerk ohne Dokument. Die Fern-Ansicht setzt
   * ihr Blatt deshalb aus den uebertragenen ZEILEN selbst zusammen.
   */
  var laengste = 0;
  Object.keys(k).forEach(function (f) { if (typeof k[f] === 'string') laengste = Math.max(laengste, k[f].length); });
  ok('keine Zeichenkette im Vermerk ist auch nur annaehernd zu lang (< 1000)', laengste < 1000,
    'laengste: ' + laengste);
  ok('es steckt kein base64-Dokument darin',
    !Object.keys(k).some(function (f) { return typeof k[f] === 'string' && /^data:|^JVBER/.test(k[f]); }));

  /*
   * MEHRERE AUSDRUCKE HINTEREINANDER — der Sammelausdruck "Alle Patienten".
   *
   * Die Oberflaeche schickt dabei EINEN Vermerk JE PATIENT, in derselben Schleife. Die erste
   * Fassung wies jeden ab, solange einer unterwegs war (`if (ausdruckInFlight) return false`):
   * der erste ging los, alle uebrigen fielen wortlos heraus, und das ack meldete trotzdem
   * Erfolg. Fern stand dann ein einziger Vermerk fuer einen Stapel von acht Protokollen.
   *
   * Dieser Abschnitt haelt zugleich einen zweiten Befund fest: beim Umbau auf die Warteschlange
   * benutzte die neue Methode weiter eine Variable, die es in ihr nicht mehr gab. Der
   * ReferenceError fiel INNERHALB der Promise-Kette an und landete im eigenen Fehlerkonto —
   * kein Schreibvorgang, keine Meldung, kein roter Test. Deshalb wird hier die ZAHL der
   * Schreibvorgaenge gezaehlt und nicht nur der Rueckgabewert geprueft.
   */
  var p5 = bauePublisher();
  var g5 = [];
  var frei = [];
  p5._ensureAuth = function () { return Promise.resolve('T'); };
  p5._write = function (verb, ziel, koerper) {
    g5.push(ziel);
    return new Promise(function (res) { frei.push(res); });   /* haengt, bis wir loslassen */
  };
  var drei = [
    p5.ausdruckVermerken({ patientId: 'A', art: 'erstellt' }),
    p5.ausdruckVermerken({ patientId: 'B', art: 'erstellt' }),
    p5.ausdruckVermerken({ patientId: 'C', art: 'erstellt' })
  ];
  ok('alle drei Vermerke werden angenommen', drei.join(',') === 'true,true,true', drei.join(','));
  return new Promise(function (res) { setTimeout(function () { res({ p5: p5, g5: g5, frei: frei }); }, 30); });
}).then(function (u) {
  ok('… aber nur EINER geht sofort los (kein Schwarm gleichzeitiger Anfragen)', u.g5.length === 1,
    'es waren ' + u.g5.length);
  ok('die anderen beiden warten', u.p5._ausdruckWartet.length === 2,
    'in der Schlange: ' + u.p5._ausdruckWartet.length);
  /* Jetzt der Reihe nach loslassen. */
  u.frei.forEach(function (f) { f({}); });
  return new Promise(function (res) { setTimeout(function () { u.frei.forEach(function (f) { f({}); }); setTimeout(function () { res(u); }, 30); }, 30); });
}).then(function (u) {
  ok('nach dem Loslassen sind ALLE DREI geschrieben', u.g5.length === 3,
    'geschrieben: ' + u.g5.length + ' -> ' + u.g5.map(function (z) { return (z.match(/ausdruck\/([^/]+)\//) || [])[1]; }).join(','));
  ok('… und die Schlange ist leer', u.p5._ausdruckWartet.length === 0);
  ok('die Schlange hat einen Deckel (kein Speicherleck bei gestoerter Leitung)',
    /_ausdruckWartet\.length < \d+/.test(fs.readFileSync(path.join(WURZEL, 'bridge/src/cloud.js'), 'utf8')));

  /* Datenschutz: ohne Stammdaten-Erlaubnis kein Tiername. */
  var p4 = bauePublisher();
  p4.sendeStammdaten = false;
  var g2 = [];
  p4._ensureAuth = function () { return Promise.resolve('T'); };
  p4._write = function (verb, ziel, koerper) { g2.push(koerper); return Promise.resolve({}); };
  p4.ausdruckVermerken({ patientId: 'Rex', patientName: 'Rex vom Hof', art: 'erstellt' });
  return new Promise(function (res) { setTimeout(function () { res(g2); }, 30); });
}).then(function (g2) {
  ok('ohne Stammdaten-Erlaubnis steht KEIN Tiername im Vermerk',
    g2.length === 1 && !g2[0].patientName,
    'sonst laege der Klarname in der Datenbank, waehrend die Vitalwerte daneben anonym sind');

  /* ================================================================================ */
  block('4. Die Fern-Ansicht bekommt den Schluessel mitgeliefert');
  var cloudQuelle = fs.readFileSync(path.join(WURZEL, 'bridge/src/cloud.js'), 'utf8');
  ok('_buildSnapshot liefert protokollKey mit',
    /protokollKey: p\.patientId \? sanitizeKey\(p\.patientId\) : null/.test(cloudQuelle),
    'ohne dieses Feld muesste die Web-App sanitizeKey nachbilden — und tat es nicht');

  var fernQuelle = path.join(WURZEL, 'tools/web-fern-modul.html');
  if (!fs.existsSync(fernQuelle)) {
    console.log('  (tools/web-fern-modul.html fehlt — der Fern-Teil wird nicht geprueft)');
  } else {
    var fern = fs.readFileSync(fernQuelle, 'utf8');
    ok('die Fern-Ansicht benutzt den mitgelieferten Schluessel',
      /protokollKey/.test(fern),
      'sonst baut sie den Pfad weiter aus dem rohen patientId und findet bei "Bello 1" nichts');
  }

  /* ================================================================================ */
  block('5. Der Deckel des Protokolls wirft keine Medikamentengabe mehr weg');
  var regQuelle = fs.readFileSync(path.join(WURZEL, 'bridge/src/registry.js'), 'utf8');
  var regOhne = regQuelle.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/\/\/[^\n]*/g, ' ');
  ok('medikamentGabe() duennt aus, statt vorne abzuschneiden',
    /this\._protokollAusduennen\(L\)/.test(regOhne.slice(regOhne.indexOf('medikamentGabe'))),
    'shift() nimmt die AELTESTE Zeile — und das kann eine Gabe sein');
  ok('… und es gibt kein L.shift() mehr im Protokollteil',
    regOhne.indexOf('L.shift()') < 0, 'gefunden bei Zeichen ' + regOhne.indexOf('L.shift()'));
  ok('der Deckel steht als Konstante, nicht als Zahl',
    /L\.length > PROTOKOLL_MAX/.test(regOhne),
    'zwei literale 2000 laufen beim naechsten Aendern auseinander');

  /*
   * DASSELBE IM RUECKFALL-SPEICHER DES FENSTERS (ui/vetstation-live.js).
   *
   * Dort stand die abschneidende Bauart an ZWEI Stellen weiter, davon einmal in logMed — die
   * herausfallende Zeile konnte also eine Medikamentengabe sein. Dass es nur der Rueckfall ist,
   * macht es nicht harmloser: er greift genau dann, wenn die Bridge nichts liefert, also im
   * Stoerfall, fuer den er gedacht ist.
   */
  var shellQuelle = fs.readFileSync(path.join(WURZEL, 'ui/vetstation-live.js'), 'utf8');
  var shellOhne = shellQuelle.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/\/\/[^\n]*/g, ' ');
  ok('auch das Fenster duennt aus, statt vorne abzuschneiden',
    /function fensterProtokollDeckeln\(L\)/.test(shellOhne) && shellOhne.indexOf('L.shift()') < 0,
    'gefunden bei Zeichen ' + shellOhne.indexOf('L.shift()'));
  ok('… und es verwirft dabei nie eine Gabe',
    /z\.art === 'med'\)\) \{ behalten\.push\(z\); continue; \}/.test(shellOhne));
  ok('beide Aufrufstellen benutzen sie',
    (shellOhne.match(/fensterProtokollDeckeln\(L\);/g) || []).length === 2,
    'gefunden: ' + (shellOhne.match(/fensterProtokollDeckeln\(L\);/g) || []).length);

  console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
  if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
  console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
}).catch(function (e) {
  console.log('\nABBRUCH: ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
