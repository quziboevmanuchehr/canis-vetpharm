'use strict';
/*
 * fern-durchsatz-test.js — Wie schnell und wie vollstaendig kommen Werte UND KURVEN durch?
 *
 * WOFUER: "Es soll jede Sekunde von zu Hause bemerkbar sein" laesst sich nur beantworten, wenn man
 * die ganze Kette misst — nicht nur die Leitung. Dieser Test durchlaeuft die ECHTE Software-Kette
 *   Geraetepaket -> registry.ingest -> matching.mergePatients -> cloud.publish -> Leitung
 * und protokolliert jeden Schreibvorgang mit Zeit und Groesse. Nur die HL7-Zerlegung und das
 * echte Internet sind ersetzt: statt des Geraets werden Pakete eingespeist, statt Firebase
 * antwortet ein lokaler Endpunkt (der die reine Softwarezeit sichtbar macht — die Netzstrecke
 * misst GESCHWINDIGKEIT-MESSEN.bat separat).
 *
 * GEMESSEN WIRD:
 *   1. Wie viele Uebertragungen je Sekunde tatsaechlich stattfinden
 *   2. Wie gross ein Paket ist (belegt, dass nur das Geaenderte geht)
 *   3. Wie lange ein neuer Messwert vom Geraet bis in die Leitung braucht
 *   4. Ob echte Kurvenstreifen ankommen — und ob jeder Streifen GENAU EINMAL geht
 *   5. Ob Protokollzeilen mitlaufen
 *   6. Wie viel im Leerlauf gespart wird
 *
 * Start:  node tools/fern-durchsatz-test.js [--sekunden 20]
 */
const http = require('http');
const path = require('path');
const os = require('os');
const fs = require('fs');

const { Registry } = require('../bridge/src/registry');
const { CloudPublisher } = require('../bridge/src/cloud');
const tafel = require('../bridge/src/tafel');

// Vorgabe kurz, damit die Gesamt-Testreihe zuegig bleibt. Fuer eine aussagekraeftige Messung
// von Hand laenger laufen lassen:  node tools/fern-durchsatz-test.js --sekunden 30
const SEK = Math.max(5, Math.min(120, zahl('--sekunden', 8)));
/* Sendetakt einstellbar (19.08.2026): --takt 40. Vorgabe ist der Wert, den die Station
   selbst benutzt - eine festverdrahtete 200 haette nach der Umstellung auf 40 ms eine
   Zahl gemeldet, die es im Betrieb nicht mehr gibt. */
const SENDETAKT = (function(){ var i=process.argv.indexOf('--takt');
  if(i>=0){ var v=parseInt(process.argv[i+1],10); if(Number.isFinite(v)&&v>=20) return v; }
  return 40; })();
function zahl(n, s) { const i = process.argv.indexOf(n); if (i < 0) return s; const v = parseInt(process.argv[i + 1], 10); return Number.isFinite(v) ? v : s; }

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
const r1 = (x) => Math.round(x * 10) / 10;

// ---- Endpunkt, der jeden Schreibvorgang mit Zeit und Groesse mitschreibt ----
const schreib = [];
const srv = http.createServer((req, res) => {
  let b = '';
  req.on('data', (c) => { b += c; });
  req.on('end', () => {
    if (req.url.indexOf('/token') === 0) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ id_token: 'ID', refresh_token: 'RT', user_id: 'messpraxis', expires_in: '3600' }));
    }
    /*
     * LESEN zaehlt NICHT als Schreibvorgang (Umbau 30.07.2026). Die Station liest ab 1.1.0 ihren
     * eigenen Tafelkopf und das flache meta zurueck; wuerden diese Anfragen in schreib[] landen,
     * saehe die Messung Pakete mit 0 Byte und rechnete daraus eine falsche Rate. Ein leeres Konto
     * antwortet mit null — genau das ist hier der Fall, und es haelt die Anlaufsperre kurz.
     */
    if (req.method === 'GET' && req.url.indexOf('/live/') >= 0) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end('null');
    }
    if (req.url.indexOf('/live/') >= 0) {
      let j = null; try { j = JSON.parse(b); } catch (_) {}
      schreib.push({ t: Date.now(), bytes: Buffer.byteLength(b), body: j });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end('{}');
    }
    res.writeHead(404); res.end();
  });
});

// ---- Ein Geraetepaket wie es das LifeVet liefert: Werte + echte Kurvenstreifen ----
function streifen(nr, laenge, hz, code, name) {
  const s = new Array(laenge);
  for (let i = 0; i < laenge; i++) s[i] = Math.sin((i + nr * laenge) / 9) * 900 + Math.sin(i / 1.7) * 60;
  return { code, name, hz, skala: 1, samples: s };
}
function paket(nr, hr) {
  return {
    deviceId: 'lifevet-mess', deviceModel: 'LifeVet 10C', deviceRole: 'combo',
    patientId: 'MESS-1', species: 'hund', weightKg: 22, ts: Date.now(),
    isoPct: 2.0, o2Flow: 1.2, ventMode: 'VCV', ventParams: { Vt: 220, AF: 12, PEEP: 3 },
    vitals: {
      hr: hr, spo2: 96, etco2: 38, fico2: 1, af: 12, temp: 37.6, paw: 12,
      nibp: { sys: 118, dia: 74 }, ekgRhythm: 'sinus', capnoShape: 'normal', pleth: 'normal',
    },
    // Wie beim echten Geraet: EKG 256 Hz und CO2 40 Hz, je 2 Sekunden Streifen.
    kurvenDaten: [streifen(nr, 512, 256, 'ECG_I', 'EKG I'), streifen(nr, 80, 40, 'CO2', 'Kapnogramm')],
  };
}

(async () => {
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const basis = 'http://127.0.0.1:' + srv.address().port;
  const authDatei = path.join(os.tmpdir(), 'vetstation-durchsatz-' + process.pid + '.json');
  fs.writeFileSync(authDatei, JSON.stringify({ refreshToken: 'RT', localId: 'messpraxis', email: 'mess@test' }));

  console.log('FERN-DURCHSATZ: echte Kette Geraet -> Registry -> Zusammenfuehrung -> Publisher -> Leitung');
  console.log('Dauer ' + SEK + ' s, Geraetetakt 1 s (wie das LifeVet), Sendetakt ' + SENDETAKT + ' ms.\n');

  const still = { info() {}, warn() {}, error() {} };
  const reg = new Registry({ log: still });
  // Eigene Stationskennung im Temp-Verzeichnis: eine Messung darf im Projekt nichts anlegen, und
  // der gemessene Saalzweig soll nicht von der Windows-Geraete-ID dieses Rechners abhaengen.
  const stationDatei = path.join(os.tmpdir(), 'vetstation-durchsatz-station-' + process.pid + '.json');
  fs.writeFileSync(stationDatei, JSON.stringify({ sid: 'stda7a7a700001', quelle: 'test', instanzen: [] }));
  const pub = new CloudPublisher({
    enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: basis, station: 'Messstation',
    minIntervalMs: SENDETAKT, authFile: authDatei, tokenUrl: basis + '/token', archiv: { enabled: false },
    stationDatei: stationDatei,
  }, { log: still });
  pub.start();
  if (!pub.angemeldet()) { console.log('Anmeldung im Test fehlgeschlagen.'); process.exit(1); }

  /*
   * MARKE statt Messwert. Die erste Fassung verfolgte den Herzfrequenz-Wert und bekam dadurch
   * negative Laufzeiten: dieselbe Zahl taucht in anderen Feldern und in aelteren Protokollzeilen
   * wieder auf, ein Treffer stammte also aus einem frueheren Schreibvorgang. Verfolgt wird jetzt
   * der Zeitstempel des Pakets — der ist je Paket einmalig und kann nicht kollidieren.
   */
  let nr = 0;
  const wertZeit = new Map();        // Paket-Zeitstempel -> Zeitpunkt der Einspeisung
  const geraet = setInterval(() => {
    nr++;
    const marke = Date.now();
    const p = paket(nr, 60 + (nr % 40));
    p.ts = marke;
    wertZeit.set(marke, marke);
    reg.ingest(p);
  }, 1000);

  const takt = setInterval(() => {
    const pats = reg.getPatients();
    reg.protokollSchritt(pats, () => null);
    pub.publish(pats, reg.getDevices(), reg.protokollFuerCloud());
  }, 100);

  await new Promise((r) => setTimeout(r, SEK * 1000));
  clearInterval(geraet); clearInterval(takt);
  await new Promise((r) => setTimeout(r, 600));   // letzte Antworten abwarten

  /*
   * RUHEZUSTAND ALS EIGENE MESSGROESSE (Nachbesserung N6).
   *
   * Die wichtigste Zahl fuer das Freikontingent ist nicht die Narkose, sondern der Leerlauf: eine
   * Praxis hat 24 Stunden am Tag Stationen laufen und narkotisiert vielleicht acht davon. Seit der
   * Tafeltakt der HERZSCHLAG eines Saals ist, wird auch OHNE Patienten geschrieben — genau das
   * soll so sein (ein Saal, der schweigt, gilt fern nach 60 s als offline), aber es muss GEMESSEN
   * sein. Gemessen wird mit derselben Kette, nur ohne Geraet und ohne Patienten.
   */
  const messEnde = schreib.length;          // Ende der Narkose-Messung
  /*
   * GEMESSEN WIRD DIE GROESSE EINES HERZSCHLAGS, hochgerechnet auf den echten Ruhetakt — nicht
   * eine Rate ueber ein paar Sekunden. Grund: im Ruhezustand schreibt eine Station alle 5 s
   * (tafel.RUHE_TAKT_MS). In einem Messfenster von 4 s faellt entweder EIN Herzschlag hinein oder
   * ZWEI, und dieselbe Software ergaebe je nach Zufall 68 oder 136 Byte/s. Deshalb: eine eigene
   * Station mit 1-s-Ruhetakt, die Groesse ihrer Herzschlaege messen und mit dem Takt rechnen, der
   * im Feld gilt. Der Takt selbst wird aus tafel.js gelesen, damit die Rechnung nicht veraltet.
   */
  const ruheStation = path.join(os.tmpdir(), 'vetstation-durchsatz-ruhe-' + process.pid + '.json');
  fs.writeFileSync(ruheStation, JSON.stringify({ sid: 'stda7a7a700002', quelle: 'test', instanzen: [] }));
  const pubRuhe = new CloudPublisher({
    enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: basis, station: 'Ruhestation',
    minIntervalMs: SENDETAKT, authFile: authDatei, tokenUrl: basis + '/token', archiv: { enabled: false },
    stationDatei: ruheStation, tafelTaktMs: 1000, ruheTaktMs: 1000,
  }, { log: still });
  pubRuhe.start();
  const leer = new Registry({ log: still });
  const ruheTakt = setInterval(() => { pubRuhe.publish(leer.getPatients(), leer.getDevices(), {}); }, 100);
  // Die ersten 2,5 s zaehlen NICHT mit: dort geht der einmalige Vollbild-Koerper raus (Saalkopf
  // und die konstanten Spiegelfelder). Danach bleibt genau das, was ein Herzschlag wirklich kostet.
  await new Promise((r) => setTimeout(r, 2500));
  const ruheStart = schreib.length;
  await new Promise((r) => setTimeout(r, 4000));
  clearInterval(ruheTakt);
  await new Promise((r) => setTimeout(r, 400));
  const ruhePakete = schreib.slice(ruheStart);
  const ruheBytes = ruhePakete.reduce((a, s) => a + s.bytes, 0);
  const ruheHerzschlaege = Math.max(1, Math.round(ruhePakete.length / 2));   // Tafel + Spiegel je Schlag
  const ruheProSchlag = ruhePakete.length ? ruheBytes / ruheHerzschlaege : 0;
  const RUHE_TAKT_S = tafel.RUHE_TAKT_MS / 1000;
  const ruheProSek = ruheProSchlag / RUHE_TAKT_S;
  leer.dispose();
  pubRuhe.stop();
  try { fs.unlinkSync(ruheStation); } catch (_) {}
  // Die Auswertung unten misst die NARKOSE. Der Ruhezustand ist eine eigene Groesse und wird
  // getrennt ausgewiesen — vermischt waeren beide Zahlen falsch.
  schreib.length = messEnde;

  srv.close(); try { fs.unlinkSync(authDatei); } catch (_) {}
  try { fs.unlinkSync(stationDatei); } catch (_) {}

  /* ---------------- Auswertung ----------------
   * Der ERSTE Schreibvorgang ist das Vollbild und faellt aus der laufenden Statistik heraus —
   * er kommt genau einmal je Stationsstart. Er wird stattdessen dort eingerechnet, wo er
   * tatsaechlich wiederkehrt: als Sicherheits-Vollbild alle vollbildMs. Ohne diese Trennung
   * verzerrt ein kurzes Messfenster das Ergebnis massiv (bei 8 s macht das eine Vollbild ein
   * Achtel der Gesamtmenge aus und die Hochrechnung sprengt scheinbar das Freikontingent).
   */
  const n = schreib.length;
  const dauer = n > 1 ? (schreib[n - 1].t - schreib[0].t) / 1000 : 0;
  const rate = dauer > 0 ? (n - 1) / dauer : 0;
  const vollbildBytes = n ? schreib[0].bytes : 0;
  const laufend = schreib.slice(1);
  const laufendDauer = laufend.length > 1 ? (laufend[laufend.length - 1].t - laufend[0].t) / 1000 : dauer;
  const laufendBytes = laufend.reduce((a, s) => a + s.bytes, 0);
  // Byte je Sekunde im Dauerbetrieb: laufende Pakete + anteilig das wiederkehrende Vollbild.
  const proSekunde = (laufendDauer > 0 ? laufendBytes / laufendDauer : 0) + vollbildBytes / (pub.vollbildMs / 1000);
  const bytes = laufend.map((x) => x.bytes).sort((a, b) => a - b);
  const mitte = bytes[Math.floor(bytes.length / 2)] || 0;

  // Laufzeit: wann taucht ein eingespeister HF-Wert zum ersten Mal in einem Paket auf?
  const laufzeiten = [];
  const gesehen = new Set();
  for (const s of schreib) {
    const txt = JSON.stringify(s.body || {});
    for (const [wert, t] of wertZeit) {
      if (gesehen.has(wert)) continue;
      if (txt.indexOf(String(wert)) >= 0) { gesehen.add(wert); laufzeiten.push(s.t - t); }
    }
  }
  laufzeiten.sort((a, b) => a - b);

  /*
   * Kurven: wie oft ging ein Streifen ueber die Leitung, und wie gross war er?
   * ACHTUNG bei der Signatur: im Delta ist der Schluessel der PFAD, also
   * "patients/<key>/kurvenSig" — ein Muster auf "kurvenSig": trifft dort NICHT.
   * Genau daran ist die erste Fassung dieser Messung vorbeigelaufen und meldete
   * "0 verschiedene Streifen", obwohl jede Sekunde ein neuer kam.
   */
  let kurvenPakete = 0, kurvenBytes = 0, kurvenPaketeSaal = 0, kurvenPaketeSpiegel = 0;
  const kurvenSigs = new Set();
  for (const s of schreib) {
    const txt = JSON.stringify(s.body || {});
    if (/"b64"/.test(txt)) {
      kurvenPakete++;
      // ZWEI ZIELE, ZWEI ZAEHLER (Umbau 30.07.2026). Ein Streifen geht in den eigenen Saalzweig
      // UND — solange die Station allein im Konto ist (F2-solo) — in den Kompatibilitaetsspiegel
      // fuer die ausgelieferte Web-App 1.0.3. Das ist der Preis dafuer, dass eine Einzelplatzpraxis
      // mit der alten Ansicht vollstaendig weiterarbeitet; er wird unten AUSGEWIESEN, nicht
      // versteckt. Zusammengezaehlt saehe es aus wie "jeder Streifen geht doppelt raus" — die
      // Aussage, die dieser Test seit jeher verhindern soll, ist aber eine andere: derselbe
      // Streifen darf nicht MEHRFACH JE ZIEL gehen.
      const saal = Object.keys(s.body || {}).some((k) => k.indexOf('saele/') === 0);
      if (saal) kurvenPaketeSaal++; else kurvenPaketeSpiegel++;
      const m = txt.match(/"b64":"[^"]*"/g) || [];
      kurvenBytes += m.reduce((a, x) => a + x.length, 0);
    }
    (txt.match(/kurvenSig"\s*:\s*"([^"]+)"/g) || []).forEach((x) => kurvenSigs.add(x));
  }
  /*
   * Wie gross ist ein Wert-Paket OHNE Kurven? Das ist die Zahl, die den schnellen Takt bezahlbar
   * macht. Gemessen wird NUR im eingeschwungenen Zustand: die ersten Pakete tragen einmalig alle
   * Stammfelder des neuen Patienten (Tierart, Gewicht, Geraeteliste, Beatmungsparameter …) und
   * sind daher um ein Vielfaches groesser. In einem kurzen Messfenster hat das den Wert vorher
   * voellig verzerrt.
   */
  const eingeschwungen = schreib.slice(3);
  const ohneKurven = eingeschwungen.filter((s) => !/"b64"/.test(JSON.stringify(s.body || {})))
    .map((s) => s.bytes).sort((a, b) => a - b);
  // Protokollzeilen liegen ab 1.1.0 unter saele/<sid>/protokoll/<pid>/<ts> (und in F2-solo
  // zusaetzlich flach). Gezaehlt wird deshalb die FORM, nicht der Anfang des Pfades.
  const protokollZeilen = schreib.reduce((a, s) =>
    a + Object.keys(s.body || {}).filter((k) => /(?:^|\/)protokoll\//.test(k)).length, 0);

  console.log('DURCHSATZ');
  console.log('  Uebertragungen           ' + n + ' in ' + r1(dauer) + ' s  =  ' + r1(rate) + ' je Sekunde');
  console.log('  Paketgroesse (Mitte)     ' + mitte + ' Byte   (kleinstes ' + (bytes[0] || 0) + ', groesstes ' + (bytes[bytes.length - 1] || 0) + ')');
  console.log('  davon reine Wert-Pakete  ' + (ohneKurven.length
    ? ohneKurven[Math.floor(ohneKurven.length / 2)] + ' Byte (' + ohneKurven.length + ' Stueck ohne Kurven)'
    : 'keine (jedes Paket trug einen Streifen)'));
  console.log('  Vollbild beim Start      ' + vollbildBytes + ' Byte (einmalig, danach alle ' +
    Math.round(pub.vollbildMs / 1000) + ' s zur Sicherheit)');
  console.log('  Datenmenge gesamt        ' + Math.round(schreib.reduce((a, s) => a + s.bytes, 0) / 1024) + ' KB');
  console.log('  waehrend einer Narkose   ' + r1(proSekunde / 1024) + ' KB/s  =  ' +
    r1(proSekunde * 3600 / 1024 / 1024) + ' MB je Stunde');
  const gbMonat = (h) => proSekunde * h * 3600 * 30 / 1024 / 1024 / 1024;
  console.log('  hochgerechnet            ' + r1(gbMonat(8)) + ' GB/Monat bei 8 h Betrieb am Tag  ·  ' +
    r1(gbMonat(24)) + ' GB/Monat rund um die Uhr   (Freikontingent: 10 GB)');
  const ohneKurvenProSek = proSekunde - (kurvenBytes / (laufendDauer || dauer));
  console.log('  davon ohne Kurven        ' + r1(ohneKurvenProSek / 1024) + ' KB/s  =  ' +
    r1(ohneKurvenProSek * 2592000 / 1024 / 1024 / 1024) + ' GB/Monat rund um die Uhr');
  console.log('\nLAUFZEIT (Geraetepaket -> fertig auf der Leitung, ohne Internet)');
  if (laufzeiten.length) {
    console.log('  schnellste ' + laufzeiten[0] + ' ms · Mitte ' + laufzeiten[Math.floor(laufzeiten.length / 2)] +
      ' ms · langsamste ' + laufzeiten[laufzeiten.length - 1] + ' ms   (' + laufzeiten.length + ' Werte verfolgt)');
  } else console.log('  keine Werte verfolgt');
  console.log('\nKURVEN');
  console.log('  Streifen uebertragen     ' + kurvenPakete + ' Pakete mit Abtastwerten'
    + '  (' + kurvenPaketeSaal + ' in den Saalzweig, ' + kurvenPaketeSpiegel + ' in den Spiegel)');
  console.log('  verschiedene Streifen    ' + kurvenSigs.size);
  console.log('  Kurvendaten gesamt       ' + Math.round(kurvenBytes / 1024) + ' KB  =  ' + r1(kurvenBytes / 1024 / dauer) + ' KB/s');
  console.log('\nPROTOKOLL');
  console.log('  Zeilen uebertragen       ' + protokollZeilen);
  console.log('\nRUHEZUSTAND (kein Geraet, kein Patient — der Herzschlag laeuft trotzdem)');
  console.log('  Herzschlaege gemessen    ' + ruheHerzschlaege + ' (' + ruhePakete.length + ' Pakete)');
  console.log('  je Herzschlag            ' + Math.round(ruheProSchlag) + ' Byte, Ruhetakt ' + RUHE_TAKT_S + ' s');
  console.log('  Datenmenge               ' + Math.round(ruheProSek) + ' Byte/s  =  '
    + r1(ruheProSek * 2592000 / 1024 / 1024) + ' MB je Monat rund um die Uhr');

  console.log('\nBEWERTUNG');
  /*
   * NICHT die Schreibrate bewerten, sondern die LAUFZEIT.
   * Das Geraet liefert einmal je Sekunde neue Werte — mehr als eine Uebertragung je Sekunde kann
   * es also gar nicht geben, und mehr WAERE auch falsch: geschrieben wird nur, was sich geaendert
   * hat. Entscheidend ist, wie schnell ein NEUER Wert draussen ist, nicht wie oft geschrieben wird.
   * Die erste Fassung dieser Messung hat genau das verwechselt und "1/s" als Fehler gemeldet.
   */
  const mitteLauf = laufzeiten.length ? laufzeiten[Math.floor(laufzeiten.length / 2)] : null;
  ok('jeder neue Geraetewert geht raus (keiner faellt aus)', gesehen.size >= wertZeit.size - 1,
    gesehen.size + ' von ' + wertZeit.size + ' verfolgt');
  ok('Laufzeit durch die Software unter 300 ms', mitteLauf !== null && mitteLauf < 300,
    mitteLauf !== null ? mitteLauf + ' ms' : 'nicht gemessen');
  // 2 KB ist die Schwelle, ab der ein Wert-Paket verraet, dass NICHT mehr nur das Geaenderte geht:
  // ein Vollbild dieser Station liegt bei ueber 4 KB.
  if (ohneKurven.length) {
    ok('Wert-Pakete ohne Kurven bleiben unter 2 KB (= es geht wirklich nur das Delta)',
      ohneKurven[Math.floor(ohneKurven.length / 2)] < 2048,
      ohneKurven[Math.floor(ohneKurven.length / 2)] + ' Byte');
  } else {
    // Ehrlich uebersprungen statt auf einer Stichprobe von null zu urteilen.
    console.log('  ○ Wert-Pakete ohne Kurven: im Messfenster kam keines vor (laenger messen: --sekunden 30)');
  }
  ok('echte Kurvenstreifen kommen an', kurvenPakete > 0, kurvenPakete + ' Pakete');
  // Der Kern der Sparlogik: je NEUEM Streifen genau ein Paket JE ZIEL. Ginge derselbe Streifen im
  // 200-ms-Takt erneut ueber die Leitung, waere das Freikontingent in Tagen aufgebraucht.
  ok('kein Streifen geht doppelt — je Ziel hoechstens ein Paket je Streifen',
    kurvenPaketeSaal <= kurvenSigs.size && kurvenPaketeSpiegel <= kurvenSigs.size,
    kurvenPaketeSaal + ' Saal- und ' + kurvenPaketeSpiegel + ' Spiegelpakete bei ' + kurvenSigs.size
    + ' verschiedenen Streifen');
  ok('Kurven kosten unter 5 KB/s', kurvenBytes / 1024 / dauer < 5, r1(kurvenBytes / 1024 / dauer) + ' KB/s');
  ok('Protokollzeilen laufen mit', protokollZeilen > 0, String(protokollZeilen));
  /*
   * ZWEI GETRENNTE AUSSAGEN statt einer irrefuehrenden.
   * Die Kurven sind der mit Abstand groesste Posten — und sie fallen nur an, WAEHREND ein Patient
   * am Geraet haengt. Eine Praxis narkotisiert nicht rund um die Uhr. Deshalb wird einmal gegen
   * einen realistischen Betrieb (8 h/Tag) geprueft und einmal gegen den Dauerbetrieb OHNE Kurven —
   * beides muss ins Freikontingent passen. Waere nur "rund um die Uhr mit Kurven" geprueft, haette
   * der Test bei jeder harmlosen Erhoehung der Kurvenaufloesung Alarm geschlagen.
   */
  ok('bei 8 h Narkosebetrieb am Tag im Freikontingent (unter 10 GB/Monat)',
    gbMonat(8) < 10, r1(gbMonat(8)) + ' GB/Monat');
  ok('ohne Kurven auch rund um die Uhr im Freikontingent',
    ohneKurvenProSek * 2592000 / 1024 / 1024 / 1024 < 10,
    r1(ohneKurvenProSek * 2592000 / 1024 / 1024 / 1024) + ' GB/Monat');
  /*
   * DER RUHEZUSTAND IST DIE ZAHL, DIE SICH MIT DER ZAHL DER SAELE MULTIPLIZIERT (N6).
   * Er laeuft 24 Stunden am Tag in jedem Saal, narkotisiert wird vielleicht acht. Die Grenze ist
   * bewusst streng: bei 8 Saelen und 250 MB je Saal und Monat sind 2 GB weg, bevor ein einziger
   * Patient am Geraet haengt. Reisst sie, ist entweder der Tafeltakt zu schnell oder es geht im
   * Leerlauf etwas raus, das dort nichts zu suchen hat.
   */
  ok('im Ruhezustand bleibt ein Saal unter 250 MB je Monat (der Herzschlag laeuft trotzdem)',
    ruheProSek * 2592000 / 1024 / 1024 < 250, r1(ruheProSek * 2592000 / 1024 / 1024) + ' MB/Monat');
  ok('im Ruhezustand wird UEBERHAUPT noch geschrieben (ein stiller Saal gilt fern als offline)',
    ruhePakete.length > 0, String(ruhePakete.length));

  console.log('\nErgebnis: ' + pass + ' OK, ' + fail + ' Fehler.');
  reg.dispose();
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('Messung fehlgeschlagen: ' + e.message); process.exit(1); });
