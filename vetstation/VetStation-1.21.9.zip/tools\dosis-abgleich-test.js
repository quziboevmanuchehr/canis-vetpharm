'use strict';
/*
 * dosis-abgleich-test.js — bringt tools/dosis-abgleich.js in den Sammellauf.
 *
 * Die Messung selbst steht in dosis-abgleich.js; dort steht auch, warum es sie gibt und
 * was sie NICHT leistet. Diese Datei existiert nur, weil tools/alle-tests.js seine Tests
 * ohne Schalter startet - der Waechterbetrieb braucht aber --wache. Ein Aufruf, kein Inhalt.
 *
 * Die Gegenprobe (wird der Waechter wirklich rot?) laeuft NICHT hier mit: sie veraendert
 * dafuer kurzzeitig ui/app/anaes-data.js und gehoert nicht in einen Routinelauf.
 * Sie steht in tools/dosis-abgleich-gegenprobe.js und wird von Hand gestartet.
 *
 * Start: node tools/dosis-abgleich-test.js
 */
var path = require('path');
var r = require('child_process').spawnSync(
  process.execPath, [path.join(__dirname, 'dosis-abgleich.js'), '--wache'],
  { encoding: 'utf8' });
process.stdout.write(String(r.stdout || '') + String(r.stderr || ''));
process.exit(r.status === 0 ? 0 : 1);
