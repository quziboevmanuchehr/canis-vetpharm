'use strict';
/*
 * kumulative-grenze-gegenprobe.js — wird tools/kumulative-grenze-test.js wirklich rot?
 *
 * Vier Richtungen, darunter der Stand von VOR der Ergaenzung. Die dritte ist die eigentliche
 * Daseinsberechtigung des Tests: eine angehobene Einzeldosis bei stehen gelassener
 * Summengrenze faellt KEINER Textsuche auf - nur der Rechnung.
 *
 * Nicht im Sammellauf: die Datei veraendert kurzzeitig ui/app/anaes-data.js (mit finally
 * wiederhergestellt und danach nachgeprueft). Von Hand aus quellcode/ starten.
 */
var fs = require('fs');
var cp = require('child_process');
var P = 'ui/app/anaes-data.js';
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function lauf() {
  var r = cp.spawnSync('dist/VetStation/node/node.exe', ['tools/kumulative-grenze-test.js'], { encoding: 'utf8' });
  return { code: r.status, aus: String(r.stdout || '') + String(r.stderr || '') };
}
function probe(name, alt, neu, erwartet) {
  var orig = fs.readFileSync(P, 'utf8');
  if (orig.indexOf(alt) < 0) { ok(name, false, 'Anker fehlt'); return; }
  try {
    fs.writeFileSync(P, orig.replace(alt, function () { return neu; }));
    var r = lauf();
    ok(name, r.code !== 0 && new RegExp('✗ ' + erwartet).test(r.aus),
      r.code === 0 ? 'BLIEB GRUEN' : 'rot, aber nicht an der erwarteten Zeile');
  } finally { fs.writeFileSync(P, orig); }
}

console.log('Gegenprobe des Summengrenzen-Waechters\n');
ok('unveraendert gruen', lauf().code === 0);

/* 1) Der Stand von vorher: Indikation ohne die ventrikulaere Tachykardie. */
probe('fehlende VT-Rubrik faellt auf',
  "Supraventrikuläre Tachykardie bei normalem Blutdruck; ebenso ventrikuläre Tachykardie — vetpharm führt dafür bei der Katze eine eigene Rubrik (Fox 1999b)",
  "Supraventrikuläre Tachykardie bei normalem Blutdruck",
  'katze: die ventrikuläre Tachykardie steht in der Indikation');

/* 2) Der Stand von vorher: keine Summengrenze. */
probe('fehlende Summengrenze faellt auf',
  " Wiederholung frühestens alle 5 min, in der SUMME höchstens 0,5 mg/kg — danach über den Dauertropf weiterführen, nicht weiter bolusweise nachlegen (vetpharm, Fox 1999b).",
  "",
  'katze: die Summengrenze ist genannt');

/*
 * 3) DIE RICHTUNG, DIE NUR DIE RECHNUNG SIEHT: Einzeldosis angehoben, Grenze stehen
 *    gelassen. Alle Woerter bleiben, wo sie sind - eine Textsuche bliebe gruen.
 */
probe('Einzeldosis ueber der Summengrenze faellt auf',
  "katze:{low:0.05,high:0.5,unit:'mg/kg',route:'langsam IV über 1 min'",
  "katze:{low:0.05,high:0.8,unit:'mg/kg',route:'langsam IV über 1 min'",
  'Esmolol/katze: Summengrenze 0.5 mg/kg >= Einzeldosis 0.8 mg/kg');

/* 4) Die Quelle wieder entfernen. */
probe('entfernte Quellenangabe faellt auf',
  "'CliniPharm/vetpharm UZH (Fox 1999a/b, Strickland 1998a)',",
  "",
  'Esmolol nennt CliniPharm/vetpharm');

ok('Datei wiederhergestellt und wieder gruen', lauf().code === 0);
console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
