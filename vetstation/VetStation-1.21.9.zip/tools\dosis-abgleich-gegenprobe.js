'use strict';
/*
 * dosis-abgleich-gegenprobe.js — prueft, ob tools/dosis-abgleich.js --wache wirklich rot wird.
 *
 * Die Projektregel dazu: eine neue Pruefung wird absichtlich zerbrochen, in JEDE Richtung,
 * die sie abdecken soll. Sonst weiss niemand, ob sie nur gruen leuchtet.
 *
 * Drei Richtungen:
 *   1. Eine echte, neue Abweichung in den DATEN  -> muss als unbekannte Kennung auffallen.
 *   2. Eine Zeile aus der Ausnahmeliste entfernt -> dieselbe Abweichung muss auffallen.
 *   3. Eine erfundene Zeile in der Ausnahmeliste -> muss als veraltet auffallen.
 *
 * Richtung 1 ist die einzige, die auch beweist, dass die MESSUNG greift und nicht nur die
 * Buchhaltung darueber.
 */
var fs = require('fs');
var cp = require('child_process');
/* Vom Projektwurzelverzeichnis aus starten - node.exe liegt nur unter dist/. */
var NODE = 'dist/VetStation/node/node.exe';

function lauf() {
  var r = cp.spawnSync(NODE, ['tools/dosis-abgleich.js', '--wache'], { encoding: 'utf8' });
  return { code: r.status, aus: String(r.stdout || '') + String(r.stderr || '') };
}
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

console.log('Gegenprobe: wird der Waechter wirklich rot?\n');

var vorher = lauf();
ok('unveraendert gruen', vorher.code === 0, 'Ausgabe: ' + vorher.aus.slice(-200));

/* ---- Richtung 1: eine echte neue Abweichung in den Daten ---- */
var PD = 'ui/app/anaes-data.js';
var daten = fs.readFileSync(PD, 'utf8');
try {
  var alt = "katze:{low:0.05,high:1,unit:'mcg/kg/min',route:'CRI IV'";
  if (daten.indexOf(alt) < 0) throw new Error('Anker in anaes-data.js fehlt');
  fs.writeFileSync(PD, daten.replace(alt, function () {
    return "katze:{low:0.05,high:2,unit:'mcg/kg/min',route:'CRI IV'";
  }));
  var r1 = lauf();
  ok('neue Abweichung in den Daten faellt auf (Noradrenalin katze wieder auf 2)',
    r1.code !== 0 && /Noradrenalin/.test(r1.aus),
    r1.code === 0 ? 'blieb gruen - die Messung sieht die Aenderung nicht'
      : 'rot, aber ohne Noradrenalin in der Ausgabe');
} finally {
  fs.writeFileSync(PD, daten);
}
ok('Daten sind wiederhergestellt', fs.readFileSync(PD, 'utf8') === daten);

/* ---- Richtungen 2 und 3: die Buchhaltung ---- */
var PT = 'tools/dosis-abgleich.js';
var werkzeug = fs.readFileSync(PT, 'utf8');
try {
  var zeile = werkzeug.split('\n').filter(function (z) {
    return z.indexOf("'Midazolam Karte bis 2 mg/kg  [reptil]':") >= 0;
  })[0];
  if (!zeile) throw new Error('Ausnahmezeile nicht gefunden');
  fs.writeFileSync(PT, werkzeug.replace(zeile + '\n', function () { return ''; }));
  var r2 = lauf();
  /*
   * Auf die MIT ✗ gemeldete Zeile pruefen, nicht auf den Wirkstoffnamen. Beim ersten
   * Versuch stand hier nur /Atropin/ - und das Wort steht ohnehin in jeder Ausgabe, in
   * den gruenen Zeilen. Der Test war gruen, ohne irgendetwas zu zeigen.
   */
  ok('fehlende Begruendung faellt auf',
    r2.code !== 0 && /✗ Midazolam Karte bis 2 mg\/kg {2}\[reptil\]/.test(r2.aus),
    'Ohne Eintrag muesste genau diese Abweichung als unbekannt gemeldet werden');

  fs.writeFileSync(PT, werkzeug.replace("var ANGENOMMEN = {", function () {
    return "var ANGENOMMEN = {\n  'Erfundenes Mittel 1-2 mg/kg  [hund]': 'gibt es nicht',";
  }));
  var r3 = lauf();
  ok('veraltete Zeile faellt auf', r3.code !== 0 && /Erfundenes Mittel/.test(r3.aus),
    'Eine Ausnahme fuer eine Abweichung, die es nicht gibt, muss gemeldet werden');
} finally {
  fs.writeFileSync(PT, werkzeug);
}
ok('Werkzeug ist wiederhergestellt', fs.readFileSync(PT, 'utf8') === werkzeug);
ok('und wieder gruen', lauf().code === 0);

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
