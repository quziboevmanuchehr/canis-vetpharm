'use strict';
/*
 * kanal-alte-station.js — spielt eine Station auf ALTEM Stand durch: bekommt sie 1.21.3 angeboten,
 * und haelt das Paket der Signaturpruefung stand?
 *
 * Der Betreiber hat mehrfach gesagt, der Update-Kanal habe am zweiten PC nicht funktioniert.
 * Ein gruener Kanaltest auf der Entwicklerplatte beweist dafuer nichts: dort ist die
 * installierte Version immer schon die neueste. Deshalb wird hier eine Station mit einer
 * KLEINEREN Nummer nachgestellt - genau die Lage, in der der Kanal etwas tun muss.
 *
 * Es wird nichts installiert und nichts veraendert; die Kopie liegt im Temp-Ordner und wird
 * danach geloescht. Der Lauf braucht Internet und laedt das Paket wirklich herunter (~4,5 MB),
 * deshalb steht er NICHT im Sammellauf, sondern wird vor einer Freigabe von Hand gefahren.
 *
 * Start (aus quellcode/): dist/VetStation/node/node.exe tools/kanal-alte-station.js
 */
var fs = require('fs');
var os = require('os');
var path = require('path');
var cp = require('child_process');

var WURZEL = process.cwd();
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

/* Eine Station auf 1.21.0 nachstellen: nur updater/ und die Versionsdatei werden gebraucht. */
var heim = fs.mkdtempSync(path.join(os.tmpdir(), 'vetstation-alt-'));
fs.mkdirSync(path.join(heim, 'updater'));
['updater.js', 'check-update.js', 'signatur.js', 'release-key.pub', 'version.json'].forEach(function (f) {
  var q = path.join(WURZEL, 'updater', f);
  if (fs.existsSync(q)) fs.copyFileSync(q, path.join(heim, 'updater', f));
});
fs.copyFileSync(path.join(WURZEL, 'package.json'), path.join(heim, 'package.json'));

var vj = path.join(heim, 'updater', 'version.json');
var v = JSON.parse(fs.readFileSync(vj, 'utf8'));
var neu = v.app;
v.app = '1.21.0';
fs.writeFileSync(vj, JSON.stringify(v, null, 2));
var pj = path.join(heim, 'package.json');
var p = JSON.parse(fs.readFileSync(pj, 'utf8'));
p.version = '1.21.0';
fs.writeFileSync(pj, JSON.stringify(p, null, 2));

console.log('Eine Station auf 1.21.0 fragt den Kanal (der fuehrt ' + neu + ')\n');
console.log('  Nachgestellt in: ' + heim + '\n');

var r = cp.spawnSync(process.execPath, [path.join(heim, 'updater', 'check-update.js')],
  { cwd: heim, encoding: 'utf8', timeout: 120000 });
var aus = String(r.stdout || '') + String(r.stderr || '');
console.log(aus.split('\n').map(function (z) { return '    ' + z; }).join('\n'));

ok('der Update-Check laeuft ohne Absturz', r.status === 0 || /1\.21\.3/.test(aus), 'Exit ' + r.status);
ok('er erkennt die eigene Version als 1.21.0', /1\.21\.0/.test(aus));
ok('er bietet ' + neu + ' an', new RegExp('NEUE App-Version verf.gbar: ' + neu.replace(/\./g, '\\.')).test(aus),
  'Der Updater vergleicht numerisch - eine kleinere Nummer wuerde gar nicht angeboten');

/*
 * Jetzt der Teil, auf den es ankommt.
 *
 * "check-update" ohne Schalter MELDET nur. Heruntergeladen, geprueft und bereitgelegt wird
 * erst mit --apply - und genau dort sitzen Pruefsumme und Signatur. Ein gruener Melde-Lauf
 * beweist also nichts ueber den Weg, den der Betreiber am zweiten PC beschreitet.
 *
 * Beim ersten Versuch stand hier statt dessen die Frage, ob in der Ausgabe das Wort
 * "Signatur" vorkommt. Das tat es - in der FREIGABENOTIZ, die der Updater mit ausdruckt.
 * Der Test meldete einen Signaturfehler, den es nicht gab. Ein Suchmuster ueber fremden
 * Fliesstext ist keine Pruefung.
 */
console.log('\n  Und jetzt wirklich anwenden (--apply):\n');
var r2 = cp.spawnSync(process.execPath,
  [path.join(heim, 'updater', 'check-update.js'), '--apply'],
  { cwd: heim, encoding: 'utf8', timeout: 300000 });
var aus2 = String(r2.stdout || '') + String(r2.stderr || '');
console.log(aus2.split('\n').map(function (z) { return '    ' + z; }).join('\n'));

ok('das Anwenden laeuft durch (Exit ' + r2.status + ')', r2.status === 0);
ok('das Paket wurde wirklich geholt und geprueft',
  /geprüft|geprueft|Signatur .*(ok|gültig|gueltig)|bereitgelegt|entpackt|gestagt|staged/i.test(aus2),
  'Ohne eine solche Meldung ist unklar, ob ueberhaupt etwas geladen wurde');
ok('kein Abbruch wegen Pruefsumme oder Signatur',
  !/sha256 stimmt nicht|Signatur ungültig|Signatur ungueltig|abgelehnt|abgebrochen/i.test(aus2),
  'Ausgabe oben lesen');
/* Liegt hinterher wirklich etwas bereit? */
var gefunden = [];
(function suche(d, tiefe) {
  if (tiefe > 3) return;
  fs.readdirSync(d, { withFileTypes: true }).forEach(function (e) {
    var p = path.join(d, e.name);
    if (e.isDirectory()) suche(p, tiefe + 1);
    else if (/\.zip$/i.test(e.name) || /pending|update/i.test(e.name)) gefunden.push(path.relative(heim, p));
  });
})(heim, 0);
ok('es liegt hinterher etwas bereit (' + gefunden.length + ' Datei(en))', gefunden.length > 0,
  'gefunden: ' + gefunden.slice(0, 6).join(', '));
if (gefunden.length) console.log('      ' + gefunden.slice(0, 6).join('\n      '));

try { fs.rmSync(heim, { recursive: true, force: true }); } catch (x) { /* Temp bleibt liegen, unkritisch */ }
console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
