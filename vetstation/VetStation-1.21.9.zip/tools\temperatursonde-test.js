'use strict';
/*
 * temperatursonde-test.js — die Station erkennt eine abgefallene Temperatursonde.
 *
 * BEFUND 19.08.2026, vom Betreiber bestaetigt ("die Sonde war nicht angeschlossen"):
 * Im Protokoll einer Katze stand 400-mal "Temperatur zu niedrig", die Kachel meldete
 * "Hypothermie", und der Rat lautete "Warmluftgeblaese/Waermematte; aktiv waermen". Die
 * Temperatur stand stabil zwischen 22,7 und 23,7 Grad - Raumtemperatur -, waehrend das Herz
 * mit rund 125 Schlaegen je Minute lief.
 *
 * DREI GRUENDE, WARUM DAS NICHT NUR LAESTIG IST:
 *   1. Eine Katze mit 23 Grad Koerpertemperatur ist tot. Mit 125/min ist sie es offensichtlich
 *      nicht. Die beiden Werte widersprechen einander, und der unglaubwuerdige ist die
 *      Temperatur.
 *   2. 400 falsche Alarme sind das Rauschen, in dem ein echter Alarm untergeht.
 *   3. "Aktiv waermen" ist bei unbekannter Temperatur ein Rat ins Blaue - Warmluft auf ein
 *      normothermes Tier fuehrt in die Hyperthermie.
 *
 * DIE ERKENNUNG IST EIN KREUZVERGLEICH, KEINE SCHWELLE: unter 30 Grad UND eine Herzfrequenz
 * am oder ueber dem unteren Normband. Schwere Hypothermie liegt bei 32-35 Grad und geht IMMER
 * mit ausgepraegter Bradykardie einher. Fehlt die Frequenz oder ist sie niedrig, bleibt es
 * beim Hypothermie-Alarm - eine echte Unterkuehlung darf nicht wegerklaert werden. Genau das
 * prueft der zweite Fall unten.
 *
 * WAS BEIM EINBAU SCHIEFGING, und warum es hier steht: die Karte stand zuerst VOR der Anlage
 * von cross[]. xc() lief damit gegen undefined und riss die ganze Auswertung mit - im Browser
 * sah man davon nur einen Folgefehler beim Tippen ("Cannot set properties of undefined
 * (setting 'temp')"), weil istInit() danach nie mehr lief. Gefunden wurde es NUR durch die
 * Gegenprobe mit dem Stand vor der Aenderung. Deshalb prueft dieser Test auch die Reihenfolge.
 *
 * Start: node tools/temperatursonde-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
var html = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
var code = html.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/<!--[\s\S]*?-->/g, ' ');

console.log('VetStation — abgefallene Temperatursonde\n');

console.log('1) Die Erkennung:');
ok('es gibt sie', /var sondeAb=\(function\(\)\{/.test(code));
ok('sie greift erst unter 30 °C', /r\.temp>=30\) return false;/.test(code),
  '32-35 °C ist schwere, aber echte Hypothermie - die darf nicht wegerklaert werden');
ok('sie verlangt eine vorhandene Herzfrequenz', /if\(!\(r\.hr>0\)\) return false;/.test(code));
ok('… und eine, die NICHT bradykard ist', /return r\.hr >= hfUnten;/.test(code),
  'Das ist der eigentliche Widerspruch: 23 °C und 125/min gibt es nicht');
ok('ohne Normband keine Aussage', /if\(hfUnten==null\) return false;/.test(code),
  'Ohne Vergleichsband waere die Erkennung geraten');

console.log('\n2) Was die Station daraufhin sagt:');
ok('sie nennt die Sonde beim Namen', /Temperatursonde prüfen/.test(html));
ok('sie sagt ausdruecklich, dass sie die Temperatur NICHT kennt',
  /kennt die Temperatur dieses Patienten/.test(html) && /NICHT/.test(html),
  'Sie behauptet nicht, das Tier sei warm - sie sagt, sie weiss es nicht');
ok('sie warnt vor dem Waermen auf Verdacht',
  /NICHT auf Verdacht aktiv wärmen/.test(html),
  'Warmluft auf ein normothermes Tier fuehrt in die Hyperthermie');
/*
 * Der typeof-Schutz in diesen beiden Zeilen ist kein Zierat: tools/geraete-profil-test.js
 * schneidet die Ursachenkette als EIGENEN Block heraus und fuehrt ihn aus - ohne die
 * Erkennung, die weiter oben in derselben Funktion steht. Ohne den Schutz scheiterte dieser
 * fremde Test an "sondeAb is not defined". Im Betrieb ist sondeAb immer definiert.
 */
ok('der Rat "aktiv waermen" faellt weg, solange die Zahl nicht traegt',
  /r\.temp<tempLo&&!\(typeof sondeAb[^)]*\)\) ur\.push\('⑥ Aktiv wärmen/.test(code));
ok('… und wird durch den richtigen ersetzt',
  /else if\(typeof sondeAb[^)]*\) ur\.push\('⑥ Temperatur unbekannt/.test(code));

console.log('\n3) Die Reihenfolge, an der der Einbau zuerst zerbrach:');
var iErk = code.indexOf('var sondeAb=');
var iXc = code.indexOf('function xc(sev');
var iKarte = code.indexOf('if(sondeAb){');
ok('Erkennung, xc() und Karte sind alle vorhanden', iErk > 0 && iXc > 0 && iKarte > 0);
ok('die Karte wird ERST NACH der Anlage von cross[] erzeugt', iKarte > iXc,
  'Davor lief xc() gegen undefined und riss die ganze Auswertung mit - sichtbar nur als '
  + 'Folgefehler beim Tippen, weil istInit() danach nie mehr lief');
ok('die Erkennung steht vor der Karte (sie braucht nur r und v)', iErk < iKarte);

/* ---- Und die Regel selbst rechnen, nicht nur lesen ---- */
console.log('\n4) Die Regel an Zahlen:');
function schneide(q, kopf) {
  var a = q.indexOf(kopf);
  if (a < 0) return '';
  var t = q.indexOf('{', a), tiefe = 0, j = t;
  for (; j < q.length; j++) { if (q[j] === '{') tiefe++; else if (q[j] === '}') { tiefe--; if (!tiefe) break; } }
  return q.slice(a, j + 1);
}
/*
 * schneide() zaehlt Klammern bis zum schliessenden "}" der FUNKTION - das "))" und "()" des
 * sofort aufgerufenen Ausdrucks bleiben draussen. Beim ersten Versuch stand deshalb
 * "return (function(){...};" da, und der Abschnitt meldete nur, dass er nichts pruefen kann.
 * Der Rumpf wird hier bewusst neu verpackt, statt am Ausschnitt herumzuraten.
 */
var quelle = schneide(html, 'var sondeAb=(function()');
var rumpf = quelle.slice(quelle.indexOf('{') + 1, quelle.lastIndexOf('}'));
var regel = null;
try {
  regel = new Function('r', 'v', rumpf);
} catch (e) { console.log('  (Regel nicht ausschneidbar: ' + e.message + ')'); }
if (regel) {
  var katze = { hr: [100, 180], temp: [37.5, 39.2] };
  [['der gemeldete Fall: 23,1 °C bei HF 125', { temp: 23.1, hr: 125 }, true],
   ['echte schwere Unterkuehlung: 31 °C bei HF 48', { temp: 31, hr: 48 }, false],
   ['Grenzfall 30 °C: noch Hypothermie', { temp: 30, hr: 125 }, false],
   ['29,9 °C bei normaler Frequenz: Sonde', { temp: 29.9, hr: 125 }, true],
   ['tief, aber ohne Frequenz: keine Aussage', { temp: 23, hr: 0 }, false],
   /*
    * DER FALL, AN DEM DIE BRADYKARDIE-BEDINGUNG WIRKLICH HAENGT. Beim Zerbrechen der Regel
    * ("return true" statt "r.hr >= hfUnten") blieben alle anderen Faelle richtig, weil sie
    * schon an der 30-Grad-Schwelle entschieden werden. Ohne diese Zeile war die Pruefung
    * gegen genau die Aenderung blind, die sie absichern soll.
    * Klinisch: 23 Grad MIT Bradykardie ist ein sterbendes Tier - da darf die Station nicht
    * "Sonde pruefen" sagen und die Hypothermie wegerklaeren.
    */
   ['23 °C MIT Bradykardie (HF 40): keine Sonde, sondern Notfall', { temp: 23, hr: 40 }, false],
   ['normale Temperatur', { temp: 38.2, hr: 125 }, false],
   ['gar keine Temperatur', { temp: 0, hr: 125 }, false]
  ].forEach(function (t) {
    var g = regel(t[1], katze);
    ok(t[0] + ' → ' + (t[2] ? 'Sonde' : 'kein Sondenbefund'), g === t[2], 'bekommen: ' + g);
  });
} else {
  ok('die Regel liess sich rechnen', false, 'Ohne das prueft dieser Abschnitt nur Quelltext');
}

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
