'use strict';
/*
 * paket-eintrag.js — liest ein Update-Paket und gibt zu jedem Eintrag die sha256 seines
 * INHALTS aus, als JSON auf stdout: { "package.json": "<hex>", ... }
 *
 * WARUM ES DIESE DATEI GIBT (Befund 19.08.2026):
 *
 *   tools/manifest-pruefen.js --freigabe stand nach der Freigabe von 1.21.1 rot mit
 *   "neuer als das Paket: package.json". Geaendert hatte sich daran nichts - ein
 *   "git checkout master" schreibt jede Datei des Baumes neu und setzt ihre Uhrzeit hoch.
 *
 *   Das ist kein Schoenheitsfehler: der naechste Schritt nach einem roten Freigabetest
 *   heisst "sicherheitshalber neu bauen", und das haette ein bereits VEROEFFENTLICHTES
 *   Paket ersetzt - samt neuer Pruefsumme und neuer Signatur -, wegen einer Uhrzeit.
 *
 *   Seither fragt manifest-pruefen.js bei Verdacht den INHALT. Die Uhrzeit bleibt der
 *   billige Vorfilter, der Vergleich hier ist der Befund.
 *
 * Der Zip-Leser ist bewusst derselbe wie in tools/paket-gleich-test.js: reines Node ohne
 * Fremdbibliothek, weil der Praxis-PC weder npm noch Node im PATH hat.
 *
 * Start: node tools/paket-eintrag.js <pfad-zur-zip>
 */
var fs = require('fs');
var zlib = require('zlib');
var crypto = require('crypto');

var zip = process.argv[2];
if (!zip || !fs.existsSync(zip)) {
  process.stderr.write('Paket nicht gefunden: ' + zip + '\n');
  process.exit(1);
}
var b = fs.readFileSync(zip);
var aus = {};
var i = 0;
while ((i = b.indexOf(Buffer.from([0x50, 0x4b, 0x03, 0x04]), i)) >= 0) {
  var nlen = b.readUInt16LE(i + 26), elen = b.readUInt16LE(i + 28);
  var name = b.toString('utf8', i + 30, i + 30 + nlen);
  var meth = b.readUInt16LE(i + 8), csize = b.readUInt32LE(i + 18);
  var start = i + 30 + nlen + elen;
  i = start + csize;
  if (/[\\/]$/.test(name)) continue;
  var roh;
  try {
    roh = meth === 8 ? zlib.inflateRawSync(b.slice(start, start + csize))
      : b.slice(start, start + csize);
  } catch (x) { continue; }
  aus[name.replace(/\\/g, '/')] = crypto.createHash('sha256').update(roh).digest('hex');
}
process.stdout.write(JSON.stringify(aus));
