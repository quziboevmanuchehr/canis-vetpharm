# VetStation — Projektregeln

Tiermedizinische Narkose- und Überwachungsstation für Kleintierpraxen.
Läuft auf einem Praxis-PC im Praxisnetz, spricht mit Monitoren, Kapnografen und
Narkosegeräten, führt das Narkoseprotokoll und spiegelt alles in eine Web-App.

**Diese Datei wird zu Beginn jeder Sitzung gelesen. Sie enthält nur Dauerfakten.**
Einzelheiten stehen in den Gedächtnisnotizen — welche wann, steht unten unter „Kartei".

---

## Was diese Anwendung ist — und was nicht

Sie ist eine **Entscheidungs- und Trainingshilfe**, kein zugelassener Patientenmonitor.
Daraus folgt die wichtigste inhaltliche Regel des Projekts:

> **Sie misst und schweigt im Zweifel.**

Eine falsche Zahl ist schädlicher als keine Zahl. Wo eine Angabe nicht belegbar ist
(unbekannte Geräteverstärkung, zu kurzer Streifen, nur eine aufgezeichnete Ableitung),
wird das ausdrücklich gesagt, statt etwas zu behaupten. Wer eine neue Aussage einbaut,
muss angeben können, woraus sie folgt.

## Harte Regeln

| Regel | Warum |
|---|---|
| Reines **ES5**, kein Build-Schritt für die UI | Der Praxis-PC hat kein npm und kein Node im PATH |
| Fremdcode nur **mitgeliefert und minifiziert** in `ui/shared/`, nie über npm | Heute: `jspdf.umd.min.js` (PDF), `gsap.min.js` (Bewegung). Beide sind reines ES5 und werden per `<script src>` geladen — kein Bauschritt, kein Internet nötig. Jede neue Datei muss **vor** der Aufnahme darauf geprüft werden (`grep -cE "=>\|\bclass \|\bconst \|\blet "` muss 0 ergeben); `anime.js` 4 fiel genau daran durch |
| `node.exe` liegt **nur** unter `dist/VetStation/node/node.exe` | Es gibt kein Node im PATH — auch nicht auf dem Entwicklerrechner |
| `.ps1`-Dateien müssen **reines ASCII** sein | Ein Gedankenstrich hat schon einmal die ganze Testreihe gekippt |
| Kommentare **begründen**, sie beschreiben nicht | Was der Code tut, steht im Code. Warum, steht nirgends sonst |
| Jeder Dateikopf sagt **warum es die Datei gibt**, mit Datum und gemessenem Befund | Sonst wiederholt der Nächste den Fehler |
| Lange Erklärungen stehen **über** der Funktion, nicht daneben | Zeilen über ~110 Zeichen sind im Editor nicht mehr lesbar |
| `dist/` ist **Bauergebnis**, keine Quelle | Wer dort ändert, verliert es beim nächsten Bau |
| Die Web-App wird **gebaut**, nie von Hand bearbeitet | `tools/web-app-bauen.js` — sonst laufen Station und Fern-App auseinander |

## Wege

```
quellcode/                      Git-Repo (master) -> github.com/quziboevmanuchehr/VetStation
  ui/app/index.html             die ganze Oberfläche, ~11430 Zeilen (auch das EKG-Submodul)
                                (die daraus GEBAUTE Web-App ist ~13670 Zeilen lang)
  ui/shared/*.js                gemeinsam mit der Web-App: ekg-analyse, ekg-skala, ekg-befunde,
                                geraete-profile, breed-katalog, patient-alter, rasse-herz,
                                tier3d, jspdf, gsap
                                ACHTUNG: jede neue Datei hier MUSS in die Kopierliste von
                                tools/web-app-bauen.js — sonst laedt die Fern-App eine Datei,
                                die es dort nicht gibt, und das Merkmal faellt STILL aus.
  bridge/src/                   Server, Geräteanbindung, Firebase, Updater
  tools/*.js                    Selbsttests und Werkzeuge (alle mit node startbar)
  docs/*.md                     Fachdokumentation im Repo (24 Dateien: Geraeteprotokolle,
                                Fern-Live, virtuelles Geraet, QA, Rassen-Narkoseplan)
  installer/*.ps1               dist bauen, Setup.exe bauen, Treiber, Firewall
../../canis-vetpharm/           Git-Repo (main), ÖFFENTLICH auf GitHub Pages
                                Web-App + Update-Kanal (vetstation-version.json, vetstation/*.zip)
```

## Arbeiten

```bash
# Selbsttests (das Maß der Dinge — vor jedem Bau grün)
dist/VetStation/node/node.exe tools/alle-tests.js

# Einzelner Test
dist/VetStation/node/node.exe tools/ekg-skala-test.js

# Dosen der Arzneikarten gegen alles halten, was die Anwendung sonst zu ihnen schreibt
dist/VetStation/node/node.exe tools/dosis-abgleich.js --alle
#   Der Bericht nennt vier Klassen; rot faellt im Sammellauf nur Klasse A ("Karte zu weit").
#   Warum nur die, steht im Kopf der Datei.

# Den Update-Kanal so pruefen, wie ihn eine laufende Station sieht (braucht Internet)
dist/VetStation/node/node.exe tools/kanal-live.js

# Web-App neu bauen (nach JEDER Änderung an ui/app/index.html)
dist/VetStation/node/node.exe tools/web-app-bauen.js ui/app/index.html ../../canis-vetpharm/canis-anaesthesie/index.html

# 3D-Modell ANSEHEN, ohne Browser (die Vorschau drosselt den Bildtakt — siehe unten)
dist/VetStation/node/node.exe tools/tier3d-bild.js modell.png hund katze 560x400
#   FLACH=1 rendert ohne Schattierung auf hellem Grund: so sieht man Löcher im Netz
#   SICHT="0,8;180,8" wählt eigene Blickwinkel (gier,nick)

# Paket bauen (erst wenn alle Tests grün sind)
powershell -ExecutionPolicy Bypass -File installer/make-dist.ps1
```

**Vorschau-Server:** `preview_start` mit `vetstation-ui` (Port 8791) oder `canis-web` (Port 8792).
Der Server **sperrt `node.exe` und Port 8791** — vor `make-dist.ps1` und vor `alle-tests.js`
beenden, sonst scheitern der Bau und `doppelstart-test.js`.

## Messen statt schätzen

Dieses Projekt hat sich mehrfach an Vermutungen verbrannt. Die Haltung ist deshalb:

- **Bei einem fehlgeschlagenen Test zuerst fragen, ob der TEST falsch ist.** Das war er
  auffallend oft — mit erfundenen Signalen, falschen Erwartungen oder abgesicherten Fehlern.
- **Neue Prüfungen absichtlich zerbrechen** und nachsehen, ob sie wirklich rot werden.
- **Die Browser-Vorschau drosselt den Bildtakt.** Wer eine `canvas` ausliest, misst alte
  Bilder. Geometrie, die stimmen muss, gehört in eine reine Funktion in `ui/shared/` mit
  einem Node-Test — nicht in eine Zeichenroutine. Siehe `vetstation-leinwand-messfalle.md`.
  Dasselbe gilt für alles, was am **GSAP-Ticker** hängt: der läuft auf `requestAnimationFrame`.
  Wird die Vorschau nicht angezeigt, feuert rAF nicht und ein Tween steht still. `gsap.ticker.tick()`
  von Hand hilft **nicht** — GSAP nimmt die Zeit von der echten Uhr, nicht vom Tick. Wer einen
  Endzustand messen will, erzwingt ihn mit `tween.progress(1)`.
- **Ein Bild ansehen, nicht nur rechnen.** Am 12.08.2026 waren Kopf und Hals des 3D-Modells
  sichtbar getrennt und alle 152 Prüfungen grün — Punktzahl, Seiten, Rahmen und Sortierung
  berühren ein Loch nun einmal nicht. Umgekehrt gilt genauso: derselbe Blick aufs Bild ließ
  *zerrissene* Hinterbeine vermuten, die keine waren (es war der Hintergrund dazwischen).
  **Bild und Messung widerlegen einander gegenseitig — erst beides zusammen trägt.**
- **Quellprüfungen in Tests lesen auch Kommentare.** Vor einer „kommt nicht mehr vor"-Prüfung
  die Blockkommentare entfernen (`.replace(/\/\*[\s\S]*?\*\//g,' ')`).

## Vier stille Fehlerklassen (Befunde 18./19.08.2026)

Alle vier laden fehlerfrei, bestehen `node --check` und faerben keinen Test rot.
Fuer jede gibt es seither einen Waechter im Sammellauf.

| Was | Wie es sich zeigt | Waechter |
|---|---|---|
| **Doppelter Schluessel** im Objektliteral | Der LETZTE gewinnt, der erste verschwindet spurlos. Ein neu geschriebener Warntext war weg; bei `low:` waere es die zehnfache Dosis | `tools/doppelschluessel-test.js` |
| **Gekapptes Datenfeld** | 23 Felder endeten mitten im Wort (Schnitt bei 40/44/90/240/280 Zeichen, aus einem alten Import). Bei `adrenalin/maus` fehlte dadurch das Wort „verduennen" — und damit griff der Stammloesungs-Riegel nicht | `tools/dosis-einheiten-test.js`, Abschnitt 9 |
| **Zweiter Rechenweg** | Die Antagonisten-Ansicht rechnet an `calc()` vorbei (eigene Tabelle `ANAES.reversal[].sp`, Konzentration als blosse Zahl). Sperren, die in `doseLine()` sitzen, gelten dort NICHT | `tools/dosis-einheiten-test.js`, Abschnitt 8 |
| **Karte weiter als die eigene Anwendung** (19.08.2026) | Noradrenalin stand in der Arzneikarte bis 2 mcg/kg/min, waehrend `breed-katalog.js` und `narkose-risiko.js` an 28 Stellen hoechstens 0,5 schrieben. Nichts widersprach sich sichtbar: eine ZU WEITE Spanne schluckt jede engere Angabe, es faellt also nichts auf — im Gegenteil, je falscher die Obergrenze, desto weniger | `tools/dosis-abgleich-test.js` |

Zur vierten Klasse gehoert die Gegenprobe `tools/dosis-abgleich-gegenprobe.js` (von Hand,
sie veraendert kurz `ui/app/anaes-data.js`). Sie dreht den berichtigten Noradrenalin-Wert
zurueck und verlangt, dass der Waechter rot wird. **Genau daran ist der erste Entwurf des
Waechters gescheitert** — er verglich nur Textwerte gegen die Karte und war damit blind fuer
seinen eigenen Anlass.

**Merksatz dazu:** eine Datei zu lesen genuegt nicht. Erst wer die **geladene Struktur**
ausliest, sieht, was die Anwendung wirklich bekommt.

Ebenso: **es gibt ZWEI Setup-Bauwege mit derselben Ausgabedatei** —
`installer/make-setup-exe.ps1` (IExpress, der tatsaechlich benutzte, weil Inno Setup hier
gar nicht installiert ist) und `installer/vetstation-setup.iss`. Wer nur einen haertet,
haelt das Problem fuer geloest. `tools/setup-sauber-test.js` prueft beide — der zweite
packte `dist\VetStation\data\station-id.json` samt privatem Schluessel mit ein.

## Freigabe

Version an **vier** Stellen gleichzeitig: `package.json`, `bridge/package.json`,
`updater/version.json` (`app`), `installer/vetstation-setup.iss` (`AppVersion`).
`tools/version-test.js` erzwingt das.

Die Nummer, die der Nutzer nennt, hinkt oft hinterher — **vor jeder Freigabe `git log`
und den Kanalordner ansehen.** Der Updater vergleicht numerisch; eine kleinere Nummer wird
gar nicht erst angeboten. Ganze Kette und die zwei stillen Fallen: `vetstation-freigabe.md`.

Das Paket ZULETZT bauen, nach der letzten Quelländerung, dann **signieren**, dann prüfen:

```bash
dist/VetStation/node/node.exe tools/paket-signieren.js
dist/VetStation/node/node.exe tools/manifest-pruefen.js --freigabe
```

**Seit 1.16.0 ist der Kanal signiert (Ed25519).** `paket-signieren.js` rechnet die Prüfsumme
selbst und setzt sha256 **und** Signatur zusammen ins Manifest — beides von Hand einzutragen
ist genau die Stelle, an der „die falsche Zip gehasht" wieder passiert. Der private Schlüssel
liegt unter `%USERPROFILE%\.vetstation-keys\` und **gehört nirgendwo sonst hin**; ohne ihn ist
keine Freigabe mehr möglich (Absicht, keine Hintertür). Der öffentliche Schlüssel
`updater/release-key.pub` **muss** im Paket liegen — sonst lehnt jede Station ab 1.16.0 jedes
Update ab. `tools/update-paket-test.js` erzwingt das.

Ohne `--freigabe` meldet derselbe Test einen veralteten Kanalstand nur als Hinweis — während
der Arbeit ist das der Regelfall und darf den Sammellauf nicht rot färben.

**Das Paket ist die letzte Änderung. Wirklich die letzte** — `tools/` liegt mit 115 Dateien
im Update-Paket, also macht schon eine Zeile in einem *Werkzeug* den Baum wieder ungleich und
`paket-gleich-test.js` rot. Am 19.08.2026 kostete das eine zusätzliche Freigabe: nach dem Bau
von 1.21.1 wurde noch `manifest-pruefen.js` verbessert, also musste 1.21.2 hinterher.
Erst alles fertig schreiben, dann bauen.

Passiert es doch, gibt es genau **einen** sauberen Ausweg: die nächste Nummer wirklich
freigeben. Ein unveröffentlichter Arbeitsstand ist hier **nicht** vorgesehen — `manifest-pruefen.js`
steht im Sammellauf und verlangt ohne jeden Schalter, dass das Manifest dieselbe Version nennt
wie `package.json`. Wer nur hochzählt und nicht veröffentlicht, färbt den Sammellauf rot.
(Am 19.08.2026 zuerst genau falsch geplant und erst an diesem roten Test gemerkt.)
Das veröffentlichte Paket zu ersetzen ist in keinem Fall der Ausweg.

**Ein Zeitstempel ist kein Befund.** `git checkout` schreibt jede Datei des Baumes neu und
setzt ihre Uhrzeit hoch, ohne ein Zeichen zu ändern — danach meldete `--freigabe`
„package.json ist neuer als das Paket" auf ein byteweise identisches Paket. Wer daraufhin
„sicherheitshalber neu baut", ersetzt ein **veröffentlichtes** Paket samt Prüfsumme und
Signatur wegen einer Uhrzeit. Seit 1.21.2 fragt die Prüfung bei Verdacht den Inhalt
(`tools/paket-eintrag.js`).

**Zuletzt den Kanal selbst fragen, nicht die eigene Platte:** `tools/kanal-live.js` holt das
veröffentlichte Manifest, lädt das Paket, rechnet dessen Prüfsumme nach und prüft die
Signatur mit `updater/signatur.js`. GitHub Pages braucht nach dem Push ein bis zwei Minuten —
ein rotes Ergebnis unmittelbar danach heißt erst einmal nur „noch nicht ausgerollt".

## Kartei — welche Notiz wann laden

Die Notizen liegen unter `~/.claude/projects/C--Users-akhme-Desktop-Manu-VetStation/memory/`.
**Nicht alle laden.** Beim Arbeiten an einem Thema gezielt die passenden:

| Thema | Notizen |
|---|---|
| EKG-Submodul, Kurven, Messzirkel, PDF | `vetstation-ekg-submodul`, `vetstation-ekg-normwerte`, `vetstation-leinwand-messfalle` |
| Patientenblatt, Rasse, Alter, Rassehinweise | `vetstation-rasse-alter-kette`, `vetstation-iife-und-katalogfallen` |
| Elektroden anlegen, 3D-Modell | `vetstation-3d-modell` |
| Geräteanbindung, HL7, serielle Geräte | `vetstation-hl7-facts`, `vetstation-geraetekatalog` |
| Fern-Live, Firebase, Web-App | `vetstation-fernlive`, `vetstation-verbund-befunde`, `vetstation-verbund-stabilitaet` |
| Mehrere OP-Säle, Saal-Tafel | `vetstation-mehrere-saele`, `vetstation-verbund-stabilitaet` |
| Oberfläche, Layout, Lesbarkeit | `vetstation-cockpit`, `vetstation-leinwand-messfalle` |
| Arzneien, Dosen, Rassen | `vetstation-rassekatalog`, `vetstation-klinische-logik`, `vetstation-gaben-protokoll` |
| Veröffentlichen | `vetstation-freigabe` |

`MEMORY.md` ist der Index und bleibt **unter 100 Zeilen** — eine Zeile je Notiz, nie Inhalt.

## Sitzungsabschluss

Auf das Stichwort **„speichere die Sitzung"**: neue Erkenntnis als eigene Notiz anlegen
(eine Aussage je Datei, Datum nennen), eine Zeile in `MEMORY.md` ergänzen, und prüfen, ob
eine bestehende Notiz dadurch falsch geworden ist — falsche Notizen werden gelöscht,
nicht ergänzt.

## Was nicht angefasst wird

- Monitor- und EKG-Anzeige der Hauptansicht, solange nicht ausdrücklich verlangt
- Fremde Zips unter `canis-vetpharm/vetstation/` — sie sind veröffentlichte Stände.
  **Eine Ausnahme, am 15.08.2026 auf ausdrückliche Weisung:** die acht Pakete 1.12.0–1.18.0
  wurden zurückgezogen, weil sie `ui/shared/ekg-literatur.js` (Buchauszüge) enthielten.
  Gefahrlos, weil der Updater numerisch vergleicht und nur höhere Nummern anbietet. Das ist
  kein Freibrief: veröffentlichte Stände werden weiterhin nur auf ausdrückliche Weisung und
  nur mit vorheriger Sicherung angefasst. Siehe [[vetstation-buchwissen-bleibt-lokal]]
- `bridge/data/` und `data/` — dort liegen Patientendaten. Sie gehören in **kein** Paket
