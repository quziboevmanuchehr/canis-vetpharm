'use strict';
/*
 * web-app-bauen.js — baut canis-vetpharm/canis-anaesthesie/index.html neu aus der Quelle.
 *
 * WARUM ES DIESES WERKZEUG GIBT:
 * Die Fern-Web-App IST die App der Station plus zwei additive Teile:
 *   1) FERN-LIVE-SEAM  — laeuft INNERHALB der Motor-IIFE (braucht state/istInit/MON),
 *                        liegt daneben als tools/web-fern-seam.js
 *   2) FERN-MODUL      — alles ab dem Marker "<!-- ===== FERN-LIVE Ansicht",
 *                        eigener Gueltigkeitsbereich, wird aus der bisherigen Fassung uebernommen
 *
 * Bis 1.3.4 war das ein Merksatz in der Dokumentation: "beim Aktualisieren neu kopieren und Modul
 * + applyLive-Seam wieder anfuegen". Ein Merksatz ist kein Verfahren — wer ihn einmal uebersieht,
 * liefert eine Fern-Ansicht aus, die entweder alt ist oder gar keine Werte mehr annimmt. Jetzt ist
 * es ein Programm, das danach NACHSIEHT, ob wirklich alles drin ist.
 *
 * Aufruf:
 *   node tools/web-app-bauen.js ui/app/index.html ../../canis-vetpharm/canis-anaesthesie/index.html
 *
 * Es kopiert ausserdem anaes-data.js und shared/geraete-profile.js zeichengleich mit — eine Kopie,
 * die man abschreibt statt kopiert, ist eine Zeitbombe mit Zufallszuender (Befund 04.08.2026:
 * die Bridge las jahrelang eine ANDERE anaes-data.js als der Browser).
 * tools/geraete-profil-test.js prueft die Zeichengleichheit bei jedem Testlauf.
 */
const fs = require('fs');
const path = require('path');

const QUELL = process.argv[2];
const WEB = process.argv[3];
const SEAM_DATEI = path.join(__dirname, 'web-fern-seam.js');
const MODUL_DATEI = path.join(__dirname, 'web-fern-modul.html');

const MARKER_ENDE = '\n<!-- ================= FERN-LIVE Ansicht';
const ANKER = '}catch(e){}\n})();\n</script>';

const src = fs.readFileSync(QUELL, 'utf8');
const alt = fs.readFileSync(WEB, 'utf8');
const seam = fs.readFileSync(SEAM_DATEI, 'utf8');

/*
 * DAS FERN-MODUL HAT SEIT DEM 21.08.2026 EINE QUELLE IM REPO (tools/web-fern-modul.html).
 *
 * Bis dahin las diese Zeile `alt.slice(i)` — also den Fern-Teil aus dem BAUERGEBNIS der
 * letzten Runde. Damit waren 2225 Zeilen (Abonnements, Protokolltabelle, Druckblatt,
 * Anmeldung) die einzige Datei des Projekts ohne Quelle: wer daran etwas aendern wollte,
 * musste von Hand in ein Bauergebnis schreiben — genau das, was die Projektregel
 * "Die Web-App wird gebaut, nie von Hand bearbeitet" verbietet. Gemerkt hat es niemand,
 * weil der Bau sich seine eigene Ausgabe zurueckreichte und dabei nie etwas verlor.
 *
 * Der Rueckfall auf die alte Fassung bleibt bewusst stehen: fehlt die Quelldatei (alter
 * Arbeitsbaum, unvollstaendiger Auszug), soll der Bau die vorhandene Fern-Ansicht
 * weiterreichen statt sie zu loeschen. Er sagt dabei laut, was er tut.
 */
let fernModul;
if (fs.existsSync(MODUL_DATEI)) {
  fernModul = fs.readFileSync(MODUL_DATEI, 'utf8');
  if (fernModul.indexOf(MARKER_ENDE.replace(/^\n/, '')) < 0) {
    console.error('FEHLER: tools/web-fern-modul.html traegt den Fern-Marker nicht — Abbruch.');
    process.exit(1);
  }
} else {
  const i = alt.indexOf(MARKER_ENDE);
  if (i < 0) { console.error('FEHLER: Fern-Modul-Marker nicht gefunden — Abbruch, nichts geschrieben.'); process.exit(1); }
  fernModul = alt.slice(i);
  console.log('HINWEIS: tools/web-fern-modul.html fehlt — Fern-Modul aus der bisherigen Fassung uebernommen.');
}

const j = src.indexOf(ANKER);
if (j < 0) { console.error('FEHLER: Anker "}catch(e){}\\n})();" in der Quelle nicht gefunden — Abbruch.'); process.exit(1); }
if (src.indexOf(ANKER, j + 1) >= 0) { console.error('FEHLER: Anker kommt MEHRFACH vor — Abbruch (sonst landet der Seam an der falschen Stelle).'); process.exit(1); }

const vorher = src.slice(0, j + '}catch(e){}\n'.length);
const nachher = src.slice(j + '}catch(e){}\n'.length);   // beginnt mit "})();\n</script>"

// Alles nach </script> bis zum Fern-Marker aus der QUELLE uebernehmen (dort stehen die
// zusaetzlichen Style-/Skriptbloecke der App), das Fern-Modul aus der bisherigen Web-Fassung.
const neu = vorher + seam + nachher.replace(/\s*$/, '\n') + fernModul;

fs.writeFileSync(WEB, neu);

// Mitgelieferte Dateien 1:1 kopieren — NIE abschreiben (siehe Kopf).
const webWurzel = path.join(path.dirname(WEB), '..');
const quellWurzel = path.join(path.dirname(QUELL), '..');   // .../ui
const KOPIEREN = [
 ['app/anaes-data.js', 'canis-anaesthesie/anaes-data.js'],
 /*
  * 31 belegte Exoten-Notfalldosen (17.08.2026). Sie lag bis dahin in ui/vendor/ und wurde vom
  * Patientenfenster gar nicht geladen; dabei fiel auf, dass der Waechter weiter unten
  * ausschliesslich ../shared/ durchsucht — eine Datei in vendor/ waere hier nie vermisst
  * worden. Deshalb liegt sie jetzt in shared/ und steht hier: sonst laedt die Fern-App eine
  * Datei, die es dort nicht gibt, und Chinchilla, Degu und Frettchen haetten in der
  * Handy-Ansicht wieder keine einzige Notfalldosis.
  */
 ['shared/anaes-exotic-doses.js', 'shared/anaes-exotic-doses.js'],
 ['shared/geraete-profile.js', 'shared/geraete-profile.js'],
 // Diagnostik-EKG (07.08.2026): die App laedt beide ueber ../shared/. Sie MUESSEN mitkopiert
 // werden — sonst laedt die Fern-Web-App zwei Dateien, die es dort nicht gibt: der PDF-Knopf
 // meldet dann "PDF-Bibliothek nicht geladen" und die Messung faellt still auf das Modell zurueck.
 ['shared/jspdf.umd.min.js', 'shared/jspdf.umd.min.js'],
 ['shared/ekg-analyse.js', 'shared/ekg-analyse.js'],
 // Wissensbasis (203 belegte Befundregeln) - die Web-App zeigt dasselbe Nachschlagewerk.
 ['shared/ekg-befunde.js', 'shared/ekg-befunde.js'],
 /* ekg-literatur.js steht ABSICHTLICH NICHT MEHR HIER — siehe NUR_LOKAL weiter unten.
  * Bis zum 14.08.2026 wurde es mitkopiert; es geht jetzt nur noch an die Station. */
 /* Die Richtigstellungen dagegen SCHON (15.08.2026). Sie sind kein Buchwissen, sondern eigene
  * Korrekturen mit oeffentlichen Gegenquellen, und sie muessen ueberall ankommen — auch dort,
  * wo das Nachschlagewerk selbst fehlt. Vier KB gegen 516. */
 ['shared/dosis-warnungen.js', 'shared/dosis-warnungen.js'],
 /* Ohne diese Zeile zeichnet das virtuelle Geraet in der Fern-App gar keine EKG-Kurve mehr
  * (wEkg gibt ohne Modell bewusst 0.5 zurueck, statt etwas zu erfinden). */
 ['shared/ekg-modell.js', 'shared/ekg-modell.js'],
 // Herzmodell (13.08.2026). Es holt seine Zeiten aus ekg-modell.js und MUSS deshalb nach ihm
 // stehen. Fehlt die Zeile, faellt der Knopf "Herz" in der Fern-App still aus: window.VS.herz3d
 // ist dann undefined, herzOeffnen() kehrt wortlos zurueck und der Tierarzt haelt einen toten
 // Knopf fuer ein Merkmal, das es nicht gibt. Genau dieser Fehler ist hier schon mehrfach
 // passiert - deshalb erzwingt ihn tools/herz3d-test.js Block 8.
 ['shared/herz3d.js', 'shared/herz3d.js'],
 // Beschriftete Achsen (08.08.2026). Fehlt sie, zeichnet die Fern-App zwar noch Raster und
 // Kurve, aber ohne jede Beschriftung - und der PDF-Ausdruck verliert seine Sekunden- und
 // mV-Marken still, weil sekundenmarken()/mvmarken() ohne VS.skala nichts tun.
 ['shared/ekg-skala.js', 'shared/ekg-skala.js'],
 // Alter und die EKG-Schicht ueber den Rassekatalog (09.08.2026). Ohne sie laedt die
 // Fern-App zwei Dateien, die es dort nicht gibt: das Altersfeld rechnet dann nichts
 // (alterJetzt() gibt null) und die rassebezogenen Herzhinweise bleiben still aus -
 // beides ohne jede Fehlermeldung, weil beide Aufrufe abgesichert sind.
 ['shared/patient-alter.js', 'shared/patient-alter.js'],
 ['shared/rasse-herz.js', 'shared/rasse-herz.js'],
 // Drehbares 3D-Modell (09.08.2026). Fehlt es, bleibt der Block still leer: modell3dBlock()
 // gibt ohne VS.tier3d eine leere Zeichenkette zurueck - kein Fehler, kein Modell.
 ['shared/tier3d.js', 'shared/tier3d.js'],
 // GSAP (12.08.2026) fuer die gefuehrte Drehung auf die festen Blickrichtungen des
 // 3D-Modells. Fehlt die Datei, springt die Ansicht wie frueher, statt zu drehen
 // (m3dSicht faellt ohne window.gsap auf Setzen zurueck) - das ist der einzige Unterschied.
 // Sie steht hier trotzdem, weil "faellt still zurueck" in diesem Projekt schon zweimal
 // geheissen hat: niemand merkt es, bis es jemand am Praxis-PC sucht.
 ['shared/gsap.min.js', 'shared/gsap.min.js'],
 /* ------------------------------------------------------------------------------------
  * NACHGETRAGEN AM 12.08.2026, und eine davon war bereits auseinandergelaufen.
  *
  * breed-genetics.js: Quelle 671 Zeilen (09.08.), Kanal 641 Zeilen (04.08.) - gemessen ueber
  *   sha256. Die Fassung im Kanal kannte RESOLVE_MIN noch nicht: resolve() nahm dort
  *   kommentarlos den ERSTEN Treffer. In der Fern-App setzte deshalb ein getipptes "HCM"
  *   oder "MDR1" eine konkrete RASSE - Treffer allein ueber den Erkrankungstext. Diese
  *   Rasse steuert danach die rassebezogenen Herzhinweise. Genau die stille Sorte Fehler,
  *   vor der die Kopierliste warnt, nur diesmal nicht durch eine FEHLENDE, sondern durch
  *   eine VERALTETE Datei.
  * narkose-risiko.js: heute zeichengleich, aber ungesichert - also nur zufaellig heil.
  * ------------------------------------------------------------------------------------ */
 ['shared/breed-genetics.js', 'shared/breed-genetics.js'],
 ['shared/narkose-risiko.js', 'shared/narkose-risiko.js'],
 /* NACHGETRAGEN AM 15.08.2026 — und es stand nur durch Zufall gut.
  * breed-katalog.js wurde von index.html geladen, war aber NIE in dieser Liste. Der Waechter
  * unten hielt es trotzdem fuer kopiert, weil sein Name in der Gegenpruefung weiter unten
  * vorkommt (Zeile mit 'shared/rasse-herz.js' > 'shared/breed-katalog.js'): er durchsuchte
  * die eigene Quelldatei als TEXT. Gemessen am 15.08.2026 waren Quelle und Kanal zufaellig
  * bytegleich - also genau die Lage, aus der breed-genetics.js am 12.08. fuenf Tage lang
  * auseinandergelaufen ist, mit klinischer Wirkung. */
 ['shared/breed-katalog.js', 'shared/breed-katalog.js'],
];
/* Liste und Lauf sind getrennt, weil der Waechter weiter unten die LISTE liest. Beides in
 * einem Ausdruck (`const KOPIEREN = [...].forEach(...)`) haette KOPIEREN auf undefined
 * gesetzt - forEach gibt nichts zurueck. Genau daran ist der erste Versuch gescheitert. */
KOPIEREN.forEach(([q, z]) => {
  const von = path.join(quellWurzel, q), nach = path.join(webWurzel, z);
  fs.copyFileSync(von, nach);
  console.log('  kopiert  ' + q + ' -> ' + z + (fs.readFileSync(von, 'utf8') === fs.readFileSync(nach, 'utf8') ? ' (zeichengleich)' : ' (ABWEICHUNG!)'));
});

/* ==========================================================================================
 * VOLLSTAENDIGKEIT DER KOPIERLISTE — die Falle, die dieses Projekt zweimal getroffen hat
 *
 * Bis zum 12.08.2026 war die Kopierliste eine Liste, die jemand pflegen MUSSTE. Wer eine
 * neue Datei in ui/shared/ ablegte und sie in index.html einband, bekam davon keinen Hinweis:
 * der Bau lief durch, die Station lief, und in der Fern-App fiel das Merkmal STILL aus.
 * Genau so ist breed-genetics.js fuenf Tage lang auseinandergelaufen (Kanal 641 Zeilen vom
 * 04.08., Quelle 671 vom 09.08.) - mit klinischer Wirkung, siehe Kommentar in der Liste.
 *
 * Diese Pruefung dreht die Beweislast um: jede Datei, die index.html ueber ../shared/ laedt,
 * MUSS entweder kopiert werden oder ausdruecklich als "gehoert dem anderen Baum" eingetragen
 * sein. Wer eine neue Datei einbindet und beides vergisst, bekommt einen roten Bau statt
 * eines stillen Ausfalls.
 *
 * WARUM ES DIE ZWEITE LISTE UEBERHAUPT GIBT (und warum sie nicht einfach mitkopiert wird):
 * canis-vetpharm/shared/ versorgt FUENF Anwendungen (canis-anaesthesie, -haematica,
 * -metabolica, -reise und die Startseite), nicht nur diese. Bei glass.css und vetpharm-ui.js
 * ist der ANDERE Baum der neuere: gemessen am 12.08.2026 stammen sie dort vom 27.07. und sind
 * groesser, die Kopien hier vom 18.07. Wer sie "der Vollstaendigkeit halber" mitkopierte,
 * wuerde vier fremde Anwendungen auf einen aelteren Stand zuruecksetzen. Die Flussrichtung
 * ist bei diesen beiden also umgekehrt - und das steht hier, damit es niemand "berichtigt".
 * ========================================================================================== */
const FREMDER_BAUM = {
  'glass.css': 'gemeinsames Thema aller fuenf canis-Anwendungen; der andere Baum ist der neuere (27.07. gegen 18.07.)',
  'vetpharm-ui.js': 'gemeinsame Navigation aller fuenf canis-Anwendungen; der andere Baum ist der neuere',
};

/* ==========================================================================================
 * NUR LOKAL — was die Station laedt, aber NICHT veroeffentlicht wird (14.08.2026)
 *
 * `canis-vetpharm/` liegt OEFFENTLICH auf GitHub Pages. `ekg-literatur.js` ist ein Auszug aus
 * den Fachbuechern des Nutzers; auf jeder Seite der Vorlagen steht "nur fuer den persoenlichen
 * Gebrauch bestimmt und darf in keiner Form an Dritte weitergegeben werden". Auf dem eigenen
 * Praxis-PC nachschlagen ist etwas anderes, als dasselbe ins offene Netz zu stellen.
 *
 * WEGLASSEN ALLEIN REICHT NICHT. index.html laedt die Datei ueber <script src>; ohne Ersatz
 * gaebe es im Kanal einen 404 und in der Fern-App eine Seite, die "Literaturauszug nicht
 * geladen" meldet - also genau die stille Luecke, gegen die die Vollstaendigkeitspruefung
 * unten gebaut ist, nur diesmal von uns selbst gerissen. Deshalb wird ein PLATZHALTER
 * geschrieben: er besetzt die Stelle, traegt KEIN Buchwissen und sagt der Oberflaeche
 * ausdruecklich, warum hier nichts steht. Der Tierarzt an der Fern-App soll den Unterschied
 * zwischen "gibt es nicht" und "gibt es nur an der Station" sehen koennen.
 * ========================================================================================== */
const NUR_LOKAL = {
  'ekg-literatur.js': {
    grund: 'Auszug aus lizenzierten Fachbuechern - canis-vetpharm ist oeffentlich',
    ziel: 'shared/ekg-literatur.js',
    platzhalter: [
      '/*',
      ' * PLATZHALTER — erzeugt von tools/web-app-bauen.js, nicht von Hand aendern.',
      ' *',
      ' * Das Literatur-Nachschlagewerk steht NUR an der Station. Es ist ein Auszug aus den',
      ' * Fachbuechern des Praxisinhabers; diese Web-App ist oeffentlich zugaenglich, und die',
      ' * Vorlagen sind ausdruecklich nur fuer den persoenlichen Gebrauch lizenziert.',
      ' *',
      ' * Diese Datei besetzt die Stelle, damit das <script src> in index.html kein 404 wirft,',
      ' * und setzt EIN Merkmal, an dem die Oberflaeche den Unterschied zwischen "fehlt" und',
      ' * "steht nur an der Station" erkennt. Buchwissen enthaelt sie nicht.',
      ' */',
      '(function (root) {',
      "  'use strict';",
      '  root.VS = root.VS || {};',
      '  root.VS.literaturNurLokal = true;',
      '}(typeof self !== \'undefined\' ? self : this));',
      ''
    ].join('\n')
  },
  /* Dieselbe Lage wie beim Nachschlagewerk, nur groesser: 1088 KB aus einem Werk, das
   * ausdruecklich nur fuer den persoenlichen Gebrauch lizenziert ist. Auch hier besetzt ein
   * Platzhalter die Stelle, damit das <script src> kein 404 wirft. */
  'kardio-regeln.js': {
    grund: 'Auswertung eines lizenzierten Fachbuchs - canis-vetpharm ist oeffentlich',
    ziel: 'shared/kardio-regeln.js',
    platzhalter: [
      '/*',
      ' * PLATZHALTER — erzeugt von tools/web-app-bauen.js, nicht von Hand aendern.',
      ' *',
      ' * Die Kardiologie-Regeln stehen NUR an der Station. Sie sind die Auswertung eines',
      ' * Fachbuchs des Praxisinhabers; diese Web-App ist oeffentlich zugaenglich.',
      ' *',
      ' * Messung, Befundregeln, Narkoseplan und Herzmodell arbeiten in der Fern-App',
      ' * unveraendert weiter — sie haengen nicht an dieser Datei.',
      ' */',
      '(function (root) {',
      "  'use strict';",
      '  root.VS = root.VS || {};',
      '  root.VS.kardioNurLokal = true;',
      '}(typeof self !== \'undefined\' ? self : this));',
      ''
    ].join('\n')
  }
};
Object.keys(NUR_LOKAL).forEach((f) => {
  const e = NUR_LOKAL[f];
  const nach = path.join(webWurzel, e.ziel);
  fs.writeFileSync(nach, e.platzhalter, 'utf8');
  console.log('  NUR LOKAL ' + f + ' -> Platzhalter (' + e.grund + ')');
});
{
  const quelle = fs.readFileSync(QUELL, 'utf8');
  const geladen = [];
  const re = /["'(]\.\.\/shared\/([A-Za-z0-9._-]+)/g;
  let m;
  while ((m = re.exec(quelle))) if (geladen.indexOf(m[1]) < 0) geladen.push(m[1]);
  /*
   * DIE LISTE SELBST FRAGEN, NICHT DEN EIGENEN QUELLTEXT (berichtigt 15.08.2026).
   *
   * Bisher stand hier eine Suche nach 'shared/xxx.js' in der EIGENEN Datei. Das zaehlte jeden
   * Treffer mit - auch die in Kommentaren und die in der Gegenpruefung weiter unten. Gemessen:
   * breed-katalog.js galt dadurch als kopiert, ohne je in der Kopierliste zu stehen, und war
   * nur zufaellig bytegleich. Ausserdem entschaerfte jede neu angelegte Gegenpruefungszeile
   * den Waechter fuer genau die Datei, die sie pruefen sollte - wer der Anleitung folgte,
   * machte ihn blind.
   *
   * Die Kopierliste ist ein Feld im Programm; sie zu lesen kostet nichts und kann nicht luegen.
   */
  const kopiert = KOPIEREN.map(([q]) => q.replace(/^.*\//, ''));
  const vergessen = geladen.filter((f) => kopiert.indexOf(f) < 0 && !FREMDER_BAUM[f] && !NUR_LOKAL[f]);
  geladen.forEach((f) => {
    if (FREMDER_BAUM[f]) console.log('  fremd    ' + f + '  (' + FREMDER_BAUM[f] + ')');
  });
  if (vergessen.length) {
    console.log('\nUNVOLLSTAENDIG: index.html laedt ../shared/-Dateien, die weder kopiert werden');
    console.log('noch als "gehoert dem anderen Baum" eingetragen sind:');
    vergessen.forEach((f) => console.log('   FEHLT  shared/' + f));
    console.log('\nEntweder in die Kopierliste oben aufnehmen oder in FREMDER_BAUM eintragen —');
    console.log('mit Begruendung, warum der andere Baum die Datei besitzt.');
    process.exit(1);
  }
}

// --- Gegenpruefung: ist wirklich alles drin? ---
const p = fs.readFileSync(WEB, 'utf8');
const pruef = [
  ['Fern-Seam applyLive', p.indexOf('function applyLive(') >= 0],
  ['Fern-Seam neuerPatient', p.indexOf('function neuerPatient(') >= 0],
  ['Fern-Seam __anaesLive', p.indexOf('window.__anaesLive=') >= 0],
  ['Fern-Modul vorhanden', p.indexOf('FERN-LIVE Ansicht') >= 0],
  ['Geraeteprofil-Modul geladen', p.indexOf('../shared/geraete-profile.js') >= 0],
  ['universelles Geraet', p.indexOf('__setGeraetProfil') >= 0 && p.indexOf('__setMesswerte') >= 0],
  ['Seam VOR dem IIFE-Ende', p.indexOf('function applyLive(') < p.lastIndexOf('})();')],
  /* Reihenfolge der Skripte: rasse-herz.js schlaegt zur Laufzeit in VETBREED.CONDITIONS nach.
   * Stuende es VOR breed-katalog.js, waere das kein Fehler beim Laden - die Herzhinweise
   * blieben nur immer leer. Genau so ein stiller Ausfall soll hier auffallen. */
  ['Rasse-Herz nach dem Katalog geladen',
    p.indexOf('shared/rasse-herz.js') > p.indexOf('shared/breed-katalog.js') &&
    p.indexOf('shared/breed-katalog.js') > 0],
  ['Alter-Modul geladen', p.indexOf('shared/patient-alter.js') >= 0],
  ['3D-Modell geladen', p.indexOf('shared/tier3d.js') >= 0],
  /* GSAP muss VOR dem Skriptblock stehen, der m3dSicht() enthaelt. Erst zur Laufzeit
   * nachgeladen waere window.gsap beim ersten Klick auf eine Blickrichtung noch nicht da,
   * und die Ansicht spraenge - genau einmal, danach nie wieder. Solche Fehler sucht man
   * lange, weil sie sich nicht wiederholen lassen. */
  ['GSAP geladen und vor der Oberflaeche',
    p.indexOf('shared/gsap.min.js') >= 0 &&
    p.indexOf('shared/gsap.min.js') < p.indexOf('function m3dSicht(')],
  /* Und der Rueckfall muss stehen bleiben: ohne ihn wuerde ein fehlendes GSAP die
   * Anlegehilfe lahmlegen, statt sie nur ohne Uebergang zu zeigen. */
  ['3D-Ansicht laeuft auch ohne GSAP', /if\(!G\)\{\s*M3D\.gier=s\.g/.test(p)],
];
let ok = true;
pruef.forEach(([n, v]) => { if (!v) ok = false; console.log((v ? '  OK   ' : '  FEHLT') + '  ' + n); });
console.log(ok ? ('\nGeschrieben: ' + WEB + ' (' + p.split('\n').length + ' Zeilen)') : '\nUNVOLLSTAENDIG');
process.exit(ok ? 0 : 1);
