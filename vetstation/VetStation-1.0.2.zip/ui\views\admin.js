/*
 * admin.js — PIN-geschuetzter Admin-/Selbstdiagnose-Bereich (§14).
 * Zeigt priorisierte Verbesserungsvorschlaege, Verbindungs-/Fehler-Log, Feedback-Statistik,
 * Sammlung fehlender Inhalte + manuelles Team-Feedback und Ein-Klick-Export (anonymisiert).
 * Standard-PIN "1234" (localStorage 'vetstation.pin', im Betrieb aendern).
 */
(function () {
  'use strict';
  var VS = window.VS;
  var host = document.getElementById('admin');
  var PIN_KEY = 'vetstation.pin';
  var authed = false, tab = 'sug';

  function pin() { return localStorage.getItem(PIN_KEY) || '1234'; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  window.VSADMIN = {
    open: function () { host.classList.add('open'); render(); },
    close: function () { host.classList.remove('open'); stopNetzPoll(); },
    onDiag: function () { if (authed && (tab === 'diag')) renderBody(); },
  };

  function render() { authed ? renderPanel() : renderPin(); }

  function renderPin() {
    host.innerHTML = '<div class="vs-admin-box"><div class="vs-admin-h"><h2>🔒 Admin</h2><div class="vs-spacer" style="flex:1"></div>' +
      '<button class="vs-btn" data-x>✕</button></div>' +
      '<div class="vs-pin"><div style="color:var(--muted)">PIN eingeben (Standard 1234)</div>' +
      '<input id="pinIn" type="password" inputmode="numeric" maxlength="8" autofocus>' +
      '<button class="vs-btn" data-ok>Öffnen</button><div id="pinErr" style="color:#ff8ba0;font-size:12px"></div></div></div>';
    host.querySelector('[data-x]').onclick = window.VSADMIN.close;
    var inp = host.querySelector('#pinIn');
    var go = function () { if (inp.value === pin()) { authed = true; renderPanel(); } else { host.querySelector('#pinErr').textContent = 'Falsche PIN.'; inp.value = ''; } };
    host.querySelector('[data-ok]').onclick = go;
    inp.onkeydown = function (e) { if (e.key === 'Enter') go(); };
    inp.focus();
  }

  var TABS = [['netz', '🌐 Netzwerk &amp; Geräte'], ['sug', '💡 Verbesserungen'], ['diag', '🔌 Verbindung/Fehler'], ['fern', '📡 Fern-Live'], ['update', '🔄 Aktualisieren'], ['fb', '📊 Feedback'], ['content', '📝 Inhalte/Notiz']];

  function renderPanel() {
    host.innerHTML = '<div class="vs-admin-box">' +
      '<div class="vs-admin-h"><h2>⚙ Admin · Selbstdiagnose</h2><div style="flex:1"></div>' +
      '<button class="vs-btn" data-exp>⬇ Bericht exportieren</button>' +
      '<button class="vs-btn warn" data-clr>Zurücksetzen</button>' +
      '<button class="vs-btn" data-x>✕</button></div>' +
      '<div class="vs-admin-tabs">' + TABS.map(function (t) { return '<button class="vs-atab' + (t[0] === tab ? ' active' : '') + '" data-t="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</div>' +
      '<div class="vs-admin-body" id="adminBody"></div></div>';
    host.querySelector('[data-x]').onclick = window.VSADMIN.close;
    host.querySelector('[data-exp]').onclick = exportReport;
    host.querySelector('[data-clr]').onclick = function () { if (confirm('Alle lokalen Feedback-/Diagnosedaten löschen?')) { VS.feedback.clear(); renderBody(); } };
    host.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { tab = b.getAttribute('data-t'); renderPanel(); }; });
    renderBody();
  }

  function renderBody() {
    var b = host.querySelector('#adminBody'); if (!b) return;
    if (tab !== 'netz') stopNetzPoll();
    if (tab === 'netz') { b.innerHTML = '<p style="color:var(--muted)">Lade Netzwerkzustand…</p>'; loadNetz(b); }
    else if (tab === 'sug') b.innerHTML = viewSuggestions();
    else if (tab === 'diag') b.innerHTML = viewDiag();
    else if (tab === 'fern') { b.innerHTML = '<p style="color:var(--muted)">Lade Fern-Live-Status…</p>'; loadFern(b); }
    else if (tab === 'update') { b.innerHTML = '<p style="color:var(--muted)">Prüfe auf Updates…</p>'; loadUpdate(b); }
    else if (tab === 'fb') b.innerHTML = viewFeedback();
    else if (tab === 'content') { b.innerHTML = viewContent(); wireContent(b); }
  }

  /* ================= Netzwerk & Geräte =================
   * Die Station prüft ihr Netz SELBST und sagt im Klartext, wo das Problem liegen kann.
   * Kernbefund 21.07.2026: Empfang und Auswertung funktionierten — es fehlte jede brauchbare
   * Information darüber, WARUM nichts ankommt. Genau das steht jetzt hier.
   */
  var netzTimer = null;
  function stopNetzPoll() { if (netzTimer) { clearInterval(netzTimer); netzTimer = null; } }

  function loadNetz(b) {
    fetch('/api/netscan').then(function (r) { return r.json(); }).then(function (s) {
      b.innerHTML = viewNetz(s); wireNetz(b, s);
      if (s.laufend && !netzTimer) startNetzPoll(b);
    }).catch(function (e) {
      b.innerHTML = '<p style="color:#ff8ba0">Netzwerkzustand nicht abrufbar: ' + esc(e.message) + '</p>';
    });
  }
  function startNetzPoll(b) {
    stopNetzPoll();
    netzTimer = setInterval(function () {
      if (tab !== 'netz' || !host.classList.contains('open')) return stopNetzPoll();
      fetch('/api/netscan').then(function (r) { return r.json(); }).then(function (s) {
        var body = host.querySelector('#adminBody'); if (!body) return stopNetzPoll();
        body.innerHTML = viewNetz(s); wireNetz(body, s);
        if (!s.laufend) stopNetzPoll();
      }).catch(function () { stopNetzPoll(); });
    }, 1200);
  }

  var URTEIL_FARBE = { ok: '#35d69a', problem: '#ff8ba0', unklar: '#ffc23c' };
  var STUFE = {
    sicher: { farbe: '#35d69a', zeichen: '✓', text: 'sicher ein Gerät' },
    moeglich: { farbe: '#ffc23c', zeichen: '?', text: 'möglich' },
    unwahrscheinlich: { farbe: 'var(--muted)', zeichen: '·', text: 'unwahrscheinlich' },
    selbst: { farbe: '#7cc4ff', zeichen: '▣', text: 'dieser PC' }
  };

  function viewNetz(s) {
    var d = s.diagnose || { urteil: 'unklar', kurz: 'Noch nicht geprüft.', befunde: [] };
    var farbe = URTEIL_FARBE[d.urteil] || '#ffc23c';
    var h = '';

    // 1) Urteil in EINEM Satz — das ist die Zeile, die vorher gefehlt hat.
    h += '<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:12px;' +
      'border:1px solid ' + farbe + '55;background:' + farbe + '14;margin-bottom:12px">' +
      '<span style="width:12px;height:12px;border-radius:50%;background:' + farbe + ';box-shadow:0 0 10px ' + farbe + '"></span>' +
      '<b style="font-size:15px">' + esc(d.kurz) + '</b></div>';

    // 2) Der Knopf, um den es geht: die App sucht ihr Netz selbst ab.
    if (s.laufend) {
      var f = s.fortschritt || { getan: 0, gesamt: 1, text: 'läuft…' };
      var pct = Math.round(100 * (f.getan || 0) / Math.max(1, f.gesamt || 1));
      h += '<div style="margin-bottom:12px"><div style="color:var(--muted);font-size:12.5px;margin-bottom:5px">' + esc(f.text || 'Suche läuft…') + '</div>' +
        '<div style="height:8px;border-radius:5px;background:rgba(255,255,255,.09);overflow:hidden">' +
        '<div style="height:100%;width:' + pct + '%;background:#23c7bb;transition:width .3s"></div></div></div>';
    } else {
      h += '<button class="vs-btn" id="netzGo">🔎 Netzwerk jetzt durchsuchen</button>' +
        '<span style="margin-left:10px;color:var(--muted);font-size:12px">' +
        (s.ts ? 'zuletzt geprüft: ' + new Date(s.ts).toLocaleTimeString() : 'noch nicht geprüft') +
        ' · prüft alle Adressen .1–.254, dauert je nach Netz einige Sekunden bis etwa eine Minute</span>';
    }

    // 3) Wo das Problem liegen kann — rangiert, mit Begründung und konkretem nächsten Schritt.
    var bef = (d.befunde || []).filter(function (x) { return x.code !== 'EMPFANG_OK'; });
    if (bef.length) {
      h += '<h3 style="margin:16px 0 8px">Wo das Problem liegen kann</h3>';
      h += bef.map(function (x) {
        var c = x.schwere >= 3 ? '#ff8ba0' : (x.schwere === 2 ? '#ffc23c' : 'var(--muted)');
        var k = x.schwere >= 3 ? 'blockiert' : (x.schwere === 2 ? 'wahrscheinlich' : 'Hinweis');
        return '<div class="vs-sug" style="border-color:' + c + '55"><div class="k" style="color:' + c + '">' + k + '</div>' +
          '<b>' + esc(x.titel) + '</b>' +
          '<div style="color:var(--muted);font-size:12.5px;margin-top:5px">' + esc(x.warum) + '</div>' +
          (x.tun && x.tun.length
            ? '<ul style="margin:8px 0 0 18px;padding:0;font-size:12.5px;line-height:1.6">' +
              x.tun.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>'
            : '') + '</div>';
      }).join('');
    }

    // 4) Was die Suche gefunden hat — jeder Fund mit Begründung, nichts wird verschwiegen.
    var e = s.ergebnis;
    if (e) {
      h += '<h3 style="margin:16px 0 8px">Gefundene Teilnehmer' +
        (e.netz ? ' im Netz ' + esc(e.netz.base) + '1–254' : '') + '</h3>';
      if (!e.hosts || !e.hosts.length) {
        h += '<p style="color:var(--muted)">Kein einziger Teilnehmer hat geantwortet.</p>';
      } else {
        // Beantwortet die Frage, die sich bei jeder Inbetriebnahme stellt: was trage ich am
        // GERÄT bei Gateway und DNS ein? Das hängt allein daran, ob ein Router im Netz hängt.
        var router = null;
        for (var ri = 0; ri < e.hosts.length; ri++) { if (e.hosts[ri].istGateway) { router = e.hosts[ri]; break; } }
        var pcIp = (e.adapter && e.adapter.address) || '192.168.0.99';
        h += '<div style="padding:9px 11px;border-radius:9px;background:rgba(35,199,187,.10);' +
          'border:1px solid rgba(35,199,187,.35);margin-bottom:9px;font-size:12.5px;line-height:1.65">' +
          '<b>Am Gerät bei „Gateway" und „Bevorzugter DNS-Server" eintragen:</b><br>' +
          (router
            ? 'Gateway <b>' + esc(router.ip) + '</b> · DNS <b>' + esc(router.ip) + '</b> — auf ' + esc(router.ip) + ' antwortet ein Router.'
            : 'Gateway <b>0.0.0.0</b> · DNS <b>0.0.0.0</b> — es hängt kein Router im Netz (eigener Switch).') +
          '<br><span style="color:var(--muted)">Für die Datenverbindung ist beides ohne Bedeutung: VetStation wird über die ' +
          'Zahl <b>' + esc(pcIp) + '</b> angesprochen, nicht über einen Namen. Ein fehlender DNS-Eintrag kann die Werte ' +
          'weder verhindern noch verbessern.</span></div>';
        h += '<div style="display:flex;flex-direction:column;gap:6px">' + e.hosts.map(function (x) {
          var st = STUFE[x.stufe] || STUFE.moeglich;
          return '<div style="display:flex;gap:10px;align-items:flex-start;padding:8px 10px;border-radius:9px;background:rgba(255,255,255,.035)">' +
            '<span style="color:' + st.farbe + ';font-weight:700;min-width:14px">' + st.zeichen + '</span>' +
            '<div style="flex:1;min-width:0">' +
            '<b>' + esc(x.ip) + '</b> <span style="color:' + st.farbe + ';font-size:12px">' + st.text + '</span>' +
            (x.mac ? ' <span style="color:var(--muted);font-size:11.5px">' + esc(x.mac) + '</span>' : '') +
            '<div style="color:var(--muted);font-size:12px;margin-top:2px">' + esc((x.gruende || []).join(' · ')) + '</div>' +
            '</div></div>';
        }).join('') + '</div>';
        if (!e.arpOk) h += '<p style="color:var(--muted);font-size:11.5px;margin-top:6px">Die MAC-Tabelle (arp) war nicht lesbar — Herstellerangaben fehlen deshalb. Die Einstufung nach offenen Datenports gilt unverändert.</p>';
      }
    }

    // 5) Dieser PC + Firewall — Zustand, nicht Empfehlung.
    if (e && e.adapters) {
      h += '<h3 style="margin:16px 0 8px">Dieser PC</h3><div style="font-size:12.5px;line-height:1.7">' +
        e.adapters.map(function (a) {
          return '• <b>' + esc(a.name) + '</b>: ' + esc(a.address) + ' (Maske ' + esc(a.netmask) + ')' +
            (a.virtuell ? ' <span style="color:#ffc23c">— virtuell/VPN, nicht verwenden</span>' : '');
        }).join('<br>') + '</div>';
    }
    if (s.firewall) {
      h += '<h3 style="margin:16px 0 8px">Windows-Firewall</h3><div style="font-size:12.5px;line-height:1.7">' +
        s.firewall.ports.map(function (p) {
          var t = p.zustand === 'frei' ? '<span style="color:#8fe3b8">✓ freigegeben' + (p.anzahl > 1 ? ' (' + p.anzahl + ' Regeln — doppelt)' : '') + '</span>'
            : (p.zustand === 'fehlt' ? '<span style="color:#ff8ba0">✗ FEHLT — Windows verwirft die Daten lautlos</span>'
              : '<span style="color:#ffc23c">? unklar (nicht lesbar)</span>');
          return '• TCP ' + p.port + ': ' + t;
        }).join('<br>') + '</div>' +
        '<p style="color:var(--muted);font-size:11.5px;margin-top:6px">Reparieren mit Doppelklick: <b>C:\\VetStation\\FIREWALL-FREIGEBEN.bat</b></p>';
    }

    h += '<p style="color:var(--muted);font-size:11.5px;margin-top:14px">Die Suche ist <b>rein lesend</b>: es wird nur kurz angeklopft und sofort wieder aufgelegt — an keinem Gerät wird etwas verstellt.</p>';
    return h;
  }

  function wireNetz(b, s) {
    var go = b.querySelector('#netzGo'); if (!go) return;
    go.onclick = function () {
      go.disabled = true; go.textContent = 'startet…';
      fetch('/api/netscan/start').then(function () { startNetzPoll(b); loadNetz(b); })
        .catch(function (e) { go.disabled = false; go.textContent = '🔎 Netzwerk jetzt durchsuchen (' + e.message + ')'; });
    };
  }

  /* ================= Google-Anmeldung der Station =========================================
   * Google verlangt seine eigene Zustimmungsseite, also einen Browser. Die Station HAT einen —
   * ihre Oberfläche läuft darin. Der Browser meldet sich an, und die Bridge bekommt anschließend
   * nur noch die Erneuerungs-Kennung; das Passwort sieht sie nie.
   *
   * WEITERLEITUNG statt Popup: Der Kiosk startet Edge mit "--kiosk", dort werden neue Fenster
   * blockiert — ein Popup-Anmeldefenster bliebe unsichtbar hängen. Die Weiterleitung ist eine
   * ganz normale Navigation und funktioniert auch im Vollbild-Kiosk.
   *
   * Nach der Rückkehr ist die Seite neu geladen und der Admin-Bereich zu. Deshalb merkt sich
   * sessionStorage, dass eine Anmeldung unterwegs ist; beim Start wird das Ergebnis abgeholt.
   * ====================================================================================== */
  var FBSDK = 'https://www.gstatic.com/firebasejs/10.12.0/';
  var GOOGLE_MARKE = 'vs_google_anmeldung';

  function firebaseCfg() {
    // Dieselben öffentlichen Werte wie in der Web-App (kein Geheimnis, stehen in jeder Firebase-App).
    return {
      apiKey: 'AIzaSyBqcWNqa-X16O_Z3VAb6mOtRJZhQmGOKj0',
      authDomain: 'vet-station.firebaseapp.com',
      databaseURL: 'https://vet-station-default-rtdb.europe-west1.firebasedatabase.app',
      projectId: 'vet-station',
    };
  }
  function ladeAuth() {
    return Promise.all([import(FBSDK + 'firebase-app.js'), import(FBSDK + 'firebase-auth.js')])
      .then(function (m) {
        var app = m[0].initializeApp(firebaseCfg());
        return { A: m[1], auth: m[1].getAuth(app) };
      });
  }
  /*
   * Anmelde-Anbieter. Google hat in Firebase eine eigene Klasse, alle uebrigen laufen ueber
   * OAuthProvider mit ihrer Kennung — Microsoft/Outlook ist "microsoft.com".
   * Bei Microsoft wird bewusst KEIN "tenant" gesetzt: mit der Vorgabe "common" funktionieren
   * sowohl persoenliche Outlook-/Hotmail-Konten als auch Geschaeftskonten einer Praxis.
   */
  function anbieterObjekt(fb, id) {
    var p = (id === 'google.com') ? new fb.A.GoogleAuthProvider() : new fb.A.OAuthProvider(id);
    // Kontoauswahl erzwingen: an einem Praxis-PC melden sich sonst alle unbemerkt mit dem
    // zuletzt benutzten Konto an — und landen im falschen Datenpfad.
    p.setCustomParameters({ prompt: 'select_account' });
    return p;
  }
  function anbieterName(id) { return id === 'microsoft.com' ? 'Microsoft' : 'Google'; }

  function oauthAnmeldung(id, sag) {
    ladeAuth().then(function (fb) {
      try { sessionStorage.setItem(GOOGLE_MARKE, '1'); } catch (e) {}
      return fb.A.signInWithRedirect(fb.auth, anbieterObjekt(fb, id));
    }).catch(function (e) {
      try { sessionStorage.removeItem(GOOGLE_MARKE); } catch (x) {}
      if (sag) sag('✗ ' + googleFehler(e), '#ff8ba0');
    });
  }
  function googleFehler(e) {
    var c = (e && e.code) || '';
    if (/unauthorized-domain/i.test(c)) return 'Diese Adresse ist in Firebase nicht freigegeben (Authentication → Einstellungen → Autorisierte Domains → 127.0.0.1).';
    if (/operation-not-allowed/i.test(c)) return 'Dieses Anmeldeverfahren ist im Firebase-Projekt nicht aktiviert.';
    if (/network-request-failed/i.test(c)) return 'Keine Internetverbindung.';
    if (/popup-blocked|cancelled-popup/i.test(c)) return 'Das Anmeldefenster wurde blockiert.';
    if (/account-exists-with-different-credential/i.test(c)) return 'Für diese E-Mail gibt es schon ein Konto mit einem anderen Anmeldeweg.';
    return (e && e.message) || String(e);
  }
  /*
   * Wird beim Laden der Oberfläche aufgerufen. Holt das Ergebnis einer laufenden Google-Anmeldung
   * ab und übergibt der Bridge die Erneuerungs-Kennung. Läuft still, wenn keine Anmeldung
   * unterwegs war — der normale Fall bei jedem Start.
   */
  function googleRueckkehrPruefen() {
    var offen = false;
    try { offen = sessionStorage.getItem(GOOGLE_MARKE) === '1'; } catch (e) {}
    if (!offen) return;
    try { sessionStorage.removeItem(GOOGLE_MARKE); } catch (e) {}
    ladeAuth().then(function (fb) {
      return fb.A.getRedirectResult(fb.auth).then(function (res) {
        var u = res && res.user;
        if (!u) return;
        return fetch('/api/praxis/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken: u.refreshToken, uid: u.uid, email: u.email }),
        }).then(function (r) { return r.json(); }).then(function (a) {
          /* Die Anmeldung des BROWSERS wird danach wieder aufgehoben: die Station braucht sie
           * nicht mehr (die Bridge hat die Kennung), und ein dauerhaft angemeldeter Kiosk-Browser
           * am Empfangstresen wäre ein unnötiges offenes Konto. */
          try { fb.A.signOut(fb.auth); } catch (e) {}
          meldung(a && a.ok
            ? '✓ Praxis-Konto über Google angemeldet — Fern-Live sendet.'
            : '✗ Anmeldung fehlgeschlagen: ' + ((a && a.fehler) || 'unbekannt'), a && a.ok);
        });
      });
    }).catch(function (e) { meldung('✗ Google-Anmeldung: ' + googleFehler(e), false); });
  }
  // Kurze Rückmeldung, auch wenn der Admin-Bereich gerade zu ist.
  function meldung(text, gut) {
    var d = document.createElement('div');
    d.textContent = text;
    d.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:99999;' +
      'padding:10px 16px;border-radius:10px;font:600 13px system-ui,sans-serif;color:#fff;' +
      'box-shadow:0 8px 26px rgba(0,0,0,.45);background:' + (gut ? '#1f8f5f' : '#a33');
    document.body.appendChild(d);
    setTimeout(function () { d.remove(); }, 9000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', googleRueckkehrPruefen);
  else googleRueckkehrPruefen();

  // ---- Fern-Live (Werte über Internet in die Web-App, Anmeldung mit dem Praxis-Konto) ----
  // Bewusst /api/praxis statt /api/cloud: nur dieser Endpunkt liefert Anmeldename und Kennung,
  // und er ist auf den Praxis-PC selbst beschränkt (kein Access-Control-Allow-Origin).
  function loadFern(b) {
    fetch('/api/praxis').then(function (r) { return r.json(); }).then(function (c) { b.innerHTML = viewFern(c); wireFern(b, c); })
      .catch(function (e) { b.innerHTML = '<p style="color:#ff8ba0">Status nicht abrufbar: ' + esc(e.message) + '</p>'; });
  }
  function viewFern(c) {
    if (!c || !c.enabled) {
      // Vollstaendige Pfade: auf dem Praxis-PC liegt alles unter C:\VetStation, und ausgeliefert
      // wird nur devices.example.json - devices.json muss der Nutzer erst daraus erzeugen.
      return '<div class="vs-sug"><div class="k">inaktiv</div>Fern-Live ist ausgeschaltet. So aktivieren:' +
        '<br>1. Ordner <code>C:\\VetStation\\bridge\\config\\</code> öffnen.' +
        '<br>2. Ist dort noch keine <code>devices.json</code>: <code>devices.example.json</code> kopieren und die Kopie in <code>devices.json</code> umbenennen.' +
        '<br>3. Die Datei mit <b>Editor/Notepad</b> öffnen (Rechtsklick → Öffnen mit → Editor) und im <code>cloud</code>-Block <b>enabled:true</b> setzen.</div>' +
        '<p style="color:var(--muted);margin-top:10px">Schritt für Schritt: <b>C:\\VetStation\\docs\\FERN-LIVE.md</b>. Danach VetStation beenden und neu starten.</p>';
    }

    /* NICHT ANGEMELDET → Anmeldemaske. Das ist der Normalfall bei der Erstinbetriebnahme. */
    if (!c.angemeldet) {
      return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><span style="width:11px;height:11px;border-radius:50%;background:#ffc23c;box-shadow:0 0 8px #ffc23c"></span><b>Praxis-Konto anmelden</b></div>' +
        '<p style="color:var(--muted);font-size:12.5px;margin:0 0 12px;line-height:1.6">Jede Praxis hat ein <b>eigenes Konto</b>. Alle Werte, Kurven und Protokolle dieser Station ' +
        'liegen darunter und sind <b>ausschließlich für dieses Konto</b> lesbar – keine andere Praxis kommt daran. ' +
        'Zum Ansehen von zu Hause in der Web-App <b>dasselbe Konto</b> verwenden.</p>' +
        '<div style="display:grid;gap:8px;max-width:420px">' +
        '<label style="font-size:12.5px;color:var(--muted)">E-Mail der Praxis' +
        '<input id="pxMail" type="email" autocomplete="username" class="vs-ta" style="min-height:0;height:40px;width:100%;font-size:13px;margin-top:3px" value="' + esc(c.email || '') + '" placeholder="praxis@beispiel.de"></label>' +
        '<label style="font-size:12.5px;color:var(--muted)">Passwort' +
        '<input id="pxPw" type="password" autocomplete="current-password" class="vs-ta" style="min-height:0;height:40px;width:100%;font-size:13px;margin-top:3px" placeholder="••••••••"></label>' +
        '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button class="vs-btn" id="pxLogin">🔐 Anmelden</button>' +
        '<span id="pxMsg" style="font-size:12.5px;color:var(--muted)"></span></div>' +
        '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:2px">' +
        '<button class="vs-btn" data-anb="google.com" style="background:#fff;color:#3c4043;border-color:#dadce0">Mit Google anmelden</button>' +
        '<button class="vs-btn" data-anb="microsoft.com" style="background:#fff;color:#3c4043;border-color:#dadce0">Mit Microsoft / Outlook anmelden</button>' +
        '</div>' +
        '</div>' +
        '<p style="color:var(--muted);font-size:11.5px;margin-top:14px;line-height:1.6">Das Passwort wird <b>nicht gespeichert</b> – nur eine Erneuerungs-Kennung, damit die Station nach ' +
        'einem Neustart von selbst weitersendet. Noch kein Konto? In der Web-App unter ' +
        '<b>quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/</b> einmalig eines anlegen.</p>';
    }

    var stColor = c.started ? '#35d69a' : '#ffc23c';
    var stTxt = c.started ? 'aktiv &amp; angemeldet' : 'angemeldet – gestoppt';
    var last = c.lastPublish ? new Date(c.lastPublish).toLocaleTimeString() : '–';
    var kb = c.bytesGesendet ? Math.round(c.bytesGesendet / 1024) : 0;
    return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span style="width:11px;height:11px;border-radius:50%;background:' + stColor + ';box-shadow:0 0 8px ' + stColor + '"></span><b>Fern-Live ' + stTxt + '</b></div>' +
      '<div style="color:var(--muted);font-size:12.5px;margin-bottom:6px">Konto <b>' + esc(c.email || '–') + '</b> · Station <b>' + esc(c.station || '') + '</b> · zuletzt gesendet ' + last +
      (c.lastError ? ' · <span style="color:#ff8ba0">Fehler: ' + esc(c.lastError) + '</span>' : '') + '</div>' +
      '<div style="color:var(--muted);font-size:12px;margin-bottom:12px">Takt ' + esc(String(c.taktMs || '?')) + ' ms · ' +
      esc(String(c.schreibVorgaenge || 0)) + ' Übertragungen · ' + kb + ' KB gesendet · ' +
      esc(String(c.protokollGesendet || 0)) + ' Protokollzeilen' + (c.kurven ? ' · echte Kurven an' : '') + '</div>' +
      '<div style="color:var(--muted);font-size:12.5px;margin-bottom:4px">Von zu Hause öffnen und dort mit <b>demselben Konto</b> anmelden:</div>' +
      '<div style="display:flex;gap:6px;align-items:stretch"><input id="fernUrl" class="vs-ta" readonly style="min-height:0;height:40px;flex:1;font-size:12px" value="' + esc(c.url || '') + '"><button class="vs-btn" id="fernCopy">⧉ Kopieren</button></div>' +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:10px;line-height:1.6">READ-ONLY: fern kann niemand ein Gerät bedienen. ' +
      'Die Daten liegen unter der Kennung dieses Kontos und sind für kein anderes Konto lesbar.</p>' +
      '<button class="vs-btn" id="pxLogout" style="margin-top:8px">Abmelden</button> <span id="pxMsg" style="font-size:12.5px;color:var(--muted)"></span>';
  }
  // ---- In-App-Update (§13) ----
  function loadUpdate(b) {
    fetch('/api/update/check').then(function (r) { return r.json(); }).then(function (c) { b.innerHTML = viewUpdate(c); wireUpdate(b, c); })
      .catch(function (e) { b.innerHTML = '<p style="color:#ff8ba0">Update-Prüfung nicht möglich: ' + esc(e.message) + '</p>'; });
  }
  function viewUpdate(c) {
    var head = '<div style="margin-bottom:10px"><b>App-Version:</b> ' + esc(c.current || '?') + ' <span style="color:var(--muted)">(' + esc(c.channel || 'stable') + ')</span></div>' +
      '<div class="vs-sug" style="border-color:rgba(53,214,154,.35)"><div class="k">automatisch</div>Klinische Daten (Medikamente, Dosen, Logik) aktualisieren sich <b>zur Laufzeit</b> vom Live-Server – ohne Neuinstallation.</div>';
    if (c.pending) head += '<div class="vs-sug" style="border-color:rgba(255,209,102,.5)"><div class="k">bereit</div>Update <b>' + esc(c.pending.version) + '</b> ist geladen &amp; geprüft – wird beim <b>nächsten Neustart</b> angewendet.</div>';
    var body;
    if (!c.manifestUrl) body = '<p style="color:var(--muted)">Kein App-Shell-Update-Kanal konfiguriert. (Nur Laufzeit-Datenupdate aktiv.)</p>';
    else if (!c.reachable) body = '<p style="color:var(--muted)">Update-Server nicht erreichbar: ' + esc(c.msg || 'offline') + '<br><small>Manifest: ' + esc(c.manifestUrl) + '</small></p>';
    else if (c.updateAvailable) body = '<div class="vs-sug" style="border-color:#23c7bb"><div class="k">neu</div><b>Neue Version ' + esc(c.latest) + '</b> verfügbar.' + (c.notes ? '<br>' + esc(c.notes) : '') + '</div>' +
      '<button class="vs-btn" id="updApply" style="margin-top:6px">⬇ Update laden &amp; anwenden</button> <span id="updMsg" style="margin-left:8px;font-size:12.5px;color:var(--muted)"></span>';
    else body = '<p style="color:#8fe3b8">✓ App-Shell ist aktuell (' + esc(c.latest || c.current) + ').</p>';
    return head + '<h3 style="margin:12px 0 6px">App-Programm (Bridge/Adapter/Oberfläche)</h3>' + body +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:12px">Updates sind ' + (c.isGit ? 'Git-basiert (git pull)' : 'Zip-basiert (Download + sha256-Prüfung, Anwendung beim Neustart)') + '. Es werden nie automatisch klinische Dosierungen geändert – Datensatz-/Logikänderungen bleiben geprüfte Schritte.</p>';
  }
  function wireUpdate(b, c) {
    var btn = b.querySelector('#updApply'); if (!btn) return;
    btn.onclick = function () {
      var msg = b.querySelector('#updMsg'); btn.disabled = true; if (msg) msg.textContent = 'lädt & prüft…';
      fetch('/api/update/apply').then(function (r) { return r.json(); }).then(function (res) {
        if (msg) { msg.textContent = (res.ok ? '✓ ' : '✗ ') + (res.msg || ''); msg.style.color = res.ok ? '#8fe3b8' : '#ff8ba0'; }
        // WICHTIG: location.reload() wuerde nur die Browser-Seite neu laden - das Update wird
        // aber von kiosk\launch-kiosk.ps1 (Apply-StagedUpdate) VOR dem Start der Bridge
        // angewendet. Es braucht also einen echten Neustart des Programms. Bewusst KEIN
        // automatischer Neustart: die Station laeuft waehrend der OP am Patienten.
        if (res.ok && res.restart) {
          btn.remove();
          var hin = document.createElement('div');
          hin.className = 'vs-sug';
          hin.style.borderColor = 'rgba(255,209,102,.5)';
          hin.style.marginTop = '8px';
          hin.innerHTML = '<div class="k">geladen &amp; geprüft</div>Das Update liegt bereit. Es wird beim ' +
            '<b>nächsten Start von VetStation</b> automatisch angewendet — <b>nicht</b> durch Neuladen dieser Seite.' +
            '<br><br><b>Bitte erst nach der OP:</b> VetStation beenden und neu starten (oder den PC neu starten). ' +
            'Beim Hochfahren erscheint kurz „Wende bereitgestelltes App-Update an…" — danach läuft die neue Version.';
          b.appendChild(hin);
        }
      }).catch(function (e) { if (msg) { msg.textContent = '✗ ' + e.message; msg.style.color = '#ff8ba0'; } btn.disabled = false; });
    };
  }

  function wireFern(b, c) {
    var msg = b.querySelector('#pxMsg');
    function sag(t, farbe) { if (msg) { msg.textContent = t; msg.style.color = farbe || 'var(--muted)'; } }

    var login = b.querySelector('#pxLogin');
    if (login) {
      var mailEl = b.querySelector('#pxMail'), pwEl = b.querySelector('#pxPw');
      var anmelden = function () {
        var mail = (mailEl && mailEl.value || '').trim(), pw = (pwEl && pwEl.value) || '';
        if (!mail || !pw) { sag('Bitte E-Mail und Passwort eingeben.', '#ffb84d'); return; }
        login.disabled = true; sag('melde an…');
        // Zugangsdaten ausschliesslich im Koerper einer POST-Anfrage - niemals in der Adresszeile,
        // sonst stuenden sie im Browserverlauf.
        fetch('/api/praxis/anmelden', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: mail, passwort: pw }),
        }).then(function (r) { return r.json(); }).then(function (res) {
          if (pwEl) pwEl.value = '';
          if (res && res.ok) { sag('✓ angemeldet', '#8fe3b8'); setTimeout(function () { loadFern(b); }, 700); }
          else { sag('✗ ' + ((res && res.fehler) || 'Anmeldung fehlgeschlagen'), '#ff8ba0'); login.disabled = false; }
        }).catch(function (e) { sag('✗ ' + e.message, '#ff8ba0'); login.disabled = false; });
      };
      login.onclick = anmelden;
      // Enter im Passwortfeld meldet an - sonst sucht der Tierarzt den Knopf.
      if (pwEl) pwEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') anmelden(); });

      b.querySelectorAll('[data-anb]').forEach(function (btn) {
        var id = btn.getAttribute('data-anb');
        btn.onclick = function () {
          btn.disabled = true;
          sag('öffne ' + anbieterName(id) + '…');
          oauthAnmeldung(id, sag);
        };
      });
    }

    var logout = b.querySelector('#pxLogout');
    if (logout) {
      logout.onclick = function () {
        logout.disabled = true; sag('melde ab…');
        fetch('/api/praxis/abmelden', { method: 'POST' }).then(function (r) { return r.json(); })
          .then(function () { loadFern(b); })
          .catch(function (e) { sag('✗ ' + e.message, '#ff8ba0'); logout.disabled = false; });
      };
    }

    var cp = b.querySelector('#fernCopy'); if (!cp) return;
    cp.onclick = function () {
      var inp = b.querySelector('#fernUrl'); if (!inp) return;
      inp.select();
      var done = function () { cp.textContent = '✓ kopiert'; setTimeout(function () { cp.textContent = '⧉ Kopieren'; }, 1500); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(inp.value).then(done, function () { try { document.execCommand('copy'); done(); } catch (e) {} });
      else { try { document.execCommand('copy'); done(); } catch (e) {} }
    };
  }

  function viewSuggestions() {
    var s = VS.feedback.suggestions();
    if (!s.length) return '<p style="color:var(--muted)">Noch keine Auffälligkeiten. Vorschläge entstehen aus überstimmten Empfehlungen, fehlenden Inhalten und Verbindungsfehlern.</p>';
    return '<p style="color:var(--muted)">Top 5 – automatisch aus Nutzung abgeleitet:</p>' + s.map(function (x) {
      return '<div class="vs-sug"><div class="k">' + esc(x.kind) + '</div>' + esc(x.text) + '</div>';
    }).join('');
  }

  function viewDiag() {
    var devs = (window.VSAPP ? window.VSAPP.getDevices() : []);
    var pats = (window.VSAPP ? window.VSAPP.getPatients() : []);
    var head = '<div style="margin-bottom:10px"><b>Geräte:</b> ' + devs.length + ' · <b>Patienten:</b> ' + pats.length + '</div>' +
      '<div class="vs-devices" style="padding:0 0 10px">' + devs.map(function (d) {
        return '<div class="vs-dev"><span class="st ' + d.status + '"></span>' + esc(d.model) + ' <small>' + d.role + '/' + d.status + '</small></div>';
      }).join('') + '</div>';
    var ev = VS.feedback.diagRecent(150);
    // Fehler/Warnungen je Quelle (Gerät/Adapter) zusammenfassen (§14 Kategorie 4).
    var counts = {};
    ev.forEach(function (e) { var s = e.source || '?'; (counts[s] = counts[s] || { e: 0, w: 0 }); if (e.level === 'error') counts[s].e++; else if (e.level === 'warn') counts[s].w++; });
    var srcKeys = Object.keys(counts).filter(function (s) { return counts[s].e || counts[s].w; }).sort(function (a, b) { return (counts[b].e + counts[b].w) - (counts[a].e + counts[a].w); });
    var summary = srcKeys.length ? '<div style="margin-bottom:10px;font-size:12px"><b>Fehler/Warnungen je Quelle:</b> ' + srcKeys.map(function (s) {
      return '<span style="display:inline-block;margin:3px 5px 0 0;padding:2px 8px;border-radius:6px;border:1px solid ' + (counts[s].e ? '#ff5470' : 'rgba(120,150,180,.3)') + ';color:' + (counts[s].e ? '#ff8ba0' : '#c8d6e5') + '">' + esc(s) + ': ' + counts[s].e + '×Fehler · ' + counts[s].w + '×Warn</span>';
    }).join('') + '</div>' : '';
    var log = ev.length ? ev.map(function (e) {
      var cls = e.level === 'error' ? 'er' : e.level === 'warn' ? 'wa' : 'in';
      return '<div class="' + cls + '">' + new Date(e.ts).toLocaleTimeString() + ' [' + e.level + '] ' + esc(e.source) + ': ' + esc(e.msg) + '</div>';
    }).join('') : '<div class="in">keine Ereignisse</div>';
    return head + summary + '<div class="vs-log">' + log + '</div>';
  }

  function viewFeedback() {
    var d = VS.feedback.all();
    var help = d.events.filter(function (e) { return e.verdict === 'helpful'; }).length;
    var over = d.events.filter(function (e) { return e.verdict === 'override'; }).length;
    var byT = {};
    d.events.filter(function (e) { return e.verdict === 'override'; }).forEach(function (e) { var k = e.title || e.incident || '?'; byT[k] = (byT[k] || 0) + 1; });
    var rows = Object.keys(byT).sort(function (a, b) { return byT[b] - byT[a]; }).map(function (k) { return '<div class="vs-sug"><b>' + byT[k] + '×</b> überstimmt: ' + esc(k) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine überstimmten Empfehlungen</p>';
    return '<p><b>' + help + '</b> hilfreich · <b>' + over + '</b> nicht passend · <b>' + d.manual.length + '</b> Notizen · <b>' + d.missing.length + '</b> fehlende Inhalte</p>' +
      '<h3 style="margin:10px 0 6px">Häufig überstimmt</h3>' + rows;
  }

  function viewContent() {
    var d = VS.feedback.all();
    var miss = d.missing.slice(-20).reverse().map(function (m) { return '<div class="vs-sug"><span class="k">' + esc(m.kind) + '</span>' + esc(m.text) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine</p>';
    var notes = d.manual.slice(-20).reverse().map(function (m) { return '<div class="vs-sug">' + esc(m.text) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine</p>';
    return '<h3 style="margin:0 0 6px">Fehlender Inhalt melden</h3>' +
      '<div style="display:flex;gap:6px;margin-bottom:6px"><select id="missKind" class="vs-btn"><option value="medikament">Medikament</option><option value="szenario">Szenario</option><option value="rhythmus">Rhythmus</option><option value="sonstiges">Sonstiges</option></select>' +
      '<input id="missText" class="vs-ta" style="min-height:0;height:36px;flex:1" placeholder="was fehlt?"><button class="vs-btn" id="missAdd">+</button></div>' + miss +
      '<h3 style="margin:14px 0 6px">Manuelles Team-Feedback</h3>' +
      '<textarea id="noteText" class="vs-ta" placeholder="Was war unklar / was fehlt / Grenzfall?"></textarea><div style="margin-top:6px"><button class="vs-btn" id="noteAdd">Notiz speichern</button></div>' + '<div style="margin-top:10px">' + notes + '</div>';
  }
  function wireContent(b) {
    b.querySelector('#missAdd').onclick = function () { var t = b.querySelector('#missText'); if (t.value.trim()) { VS.feedback.missing({ kind: b.querySelector('#missKind').value, text: t.value.trim() }); t.value = ''; renderBody(); } };
    b.querySelector('#noteAdd').onclick = function () { var t = b.querySelector('#noteText'); if (t.value.trim()) { VS.feedback.manual(t.value.trim()); t.value = ''; renderBody(); } };
  }

  function exportReport() {
    var text = VS.feedback.exportReport();
    var blob = new Blob([text], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'vetstation-bericht-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
})();
