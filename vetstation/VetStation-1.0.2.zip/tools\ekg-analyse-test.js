'use strict';
/*
 * ekg-analyse-test.js — die EKG-Auswertung misst, statt zu raten, und SCHWEIGT im Zweifel.
 *
 * HINTERGRUND (22.07.2026): Das LifeVet 10C liefert die EKG-Kurve als Abtastblock mit 256 Hz.
 * Die Station hat sie nie ausgewertet - sie zeichnete aus der gemeldeten Herzfrequenz eine
 * Musterkurve nach. Jede Aussage ueber QRS-Form, Extrasystolen oder ST-Strecke war damit unmoeglich.
 *
 * Beim Bau dieser Auswertung sind DREI Fehler aufgetreten, die alle in dieselbe Richtung gingen -
 * sie haetten einen kranken Patienten gesund aussehen lassen oder einen gesunden krank:
 *   1. Die Schwellenschaetzung nahm den Median NUR der positiven Huellwerte, also der aktiven
 *      QRS-Abschnitte statt der Ruhephasen. Die geschaetzte Grundlinie lag dadurch fast so hoch
 *      wie ein QRS (14882 bei Spitzen von 40452) - die flachere ventrikulaere Extrasystole (17410)
 *      fiel durch. Aus "unregelmaessig mit Extrasystolen" wurde ein beruhigendes "regelmaessig".
 *   2. Die Schwankung wurde als MEDIAN der Abstandsunterschiede berechnet. Der Median ist
 *      unempfindlich gegen Ausreisser - eine einzelne Extrasystole IST aber der Ausreisser.
 *   3. Auf REINEM RAUSCHEN meldete die Auswertung "unregelmaessig mit vorzeitigen Schlaegen".
 *
 * Dieser Test haelt alle drei fest.
 *
 * Start: node tools/ekg-analyse-test.js      (laeuft auch in tools/alle-tests.js)
 */
const E = require('../ui/engine/ekg-analyse');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

const HZ = 256;

// --- Kunst-EKG bauen: Gauss-foermige QRS-Zacken auf ruhiger Grundlinie ----------------------
function qrs(s, r, breiteMs, amp) {
  const b = Math.round(breiteMs / 1000 * HZ);
  for (let k = -b; k <= b; k++) {
    const i = r + k;
    if (i < 0 || i >= s.length) continue;
    s[i] += Math.round(amp * Math.exp(-(k * k) / (2 * Math.pow(b / 3, 2))));
  }
}
/*
 * opt.ves: ein vorgezogener, BREITER Schlag mit kompensatorischer Pause danach - das vollstaendige
 * Muster einer ventrikulaeren Extrasystole (kurz, dann lang). Ohne die Pause waere es kein
 * belastbarer Befund, und der Test wuerde etwas verlangen, das klinisch nicht gilt.
 */
function bauEKG(opt) {
  opt = opt || {};
  const sek = opt.sek || 6;
  const n = Math.round(sek * HZ);
  const s = new Array(n).fill(0);
  if (opt.rauschen) for (let j = 0; j < n; j++) s[j] = Math.round((Math.random() - 0.5) * opt.rauschen);
  const rrSek = 60 / (opt.hf || 100);
  const pos = [];
  let t = HZ * 0.4;
  for (let i = 0; i < 20 && t < n - HZ * 0.3; i++) {
    pos.push(Math.round(t));
    let d = rrSek;
    if (opt.ves && i === 3) d = rrSek * 0.66;   // vorgezogen
    if (opt.ves && i === 4) d = rrSek * 1.34;   // kompensatorische Pause
    t += d * HZ;
  }
  pos.forEach((r, i) => qrs(s, r, (opt.ves && i === 4) ? 90 : (opt.qrsMs || 50), 600));
  return s;
}

console.log('VetStation — EKG-Auswertung auf echten Abtastwerten\n');

/* ---------------- 1) Grundmessung ---------------- */
console.log('Messung (Hund, 120/min, 6 s):');
const hund = E.analysiere({ samples: bauEKG({ hf: 120 }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('der Streifen ist auswertbar', hund.brauchbar === true, hund.warum);
ok('die Herzfrequenz wird aus den RR-Abstaenden gemessen', Math.abs(hund.hf - 120) <= 3, String(hund.hf));
ok('die QRS-Breite wird gemessen', hund.qrsBreiteMs > 20 && hund.qrsBreiteMs < 120, String(hund.qrsBreiteMs));
ok('die RR-Abstaende werden ausgewiesen', hund.rr && hund.rr.mittelMs > 400 && hund.rr.mittelMs < 600, JSON.stringify(hund.rr));
ok('der Rhythmus wird als regelmaessig erkannt', hund.rhythmus.id === 'sinus', hund.rhythmus.name);
ok('jede Aussage traegt eine Begruendung', !!hund.rhythmus.begruendung);

console.log('\nKatze mit 210/min (Mensch-Grenzen wuerden hier versagen):');
const katze = E.analysiere({ samples: bauEKG({ hf: 210, qrsMs: 35 }), hz: HZ, skala: 1 }, { bandHr: [140, 220], einheit: 'uV' });
ok('auch 210/min werden korrekt gemessen', Math.abs(katze.hf - 210) <= 6, String(katze.hf));
ok('und gelten fuer die Katze NICHT als Tachykardie', katze.rhythmus.id === 'sinus', katze.rhythmus.name);

/* ---------------- 2) Fehler 1 + 2: die Extrasystole ---------------- */
console.log('\nVentrikulaere Extrasystole (breit, vorgezogen, mit Pause):');
let erkannt = 0;
for (let i = 0; i < 20; i++) {
  const r = E.analysiere({ samples: bauEKG({ ves: true }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
  if (r.rhythmus && /vorzeitig/.test(r.rhythmus.name)) erkannt++;
}
ok('sie wird zuverlaessig erkannt (20 Durchlaeufe)', erkannt === 20, erkannt + '/20');
const ves = E.analysiere({ samples: bauEKG({ ves: true }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('der BREITE Schlag wird ueberhaupt gefunden (Nachsuche in der Luecke)',
  ves.schlaege >= 8, ves.schlaege + ' Schlaege');
ok('der verkuerzte Abstand steht in der Begruendung', /kürzester Abstand/.test(ves.rhythmus.begruendung), ves.rhythmus.begruendung);
ok('sie wird als VERDACHT ausgewiesen, nicht als Diagnose', ves.rhythmus.sicherheit === 'Verdacht', ves.rhythmus.sicherheit);

/* ---------------- 3) Fehler 3: nichts aus Rauschen erfinden ---------------- */
console.log('\nSchweigeregeln:');
const rauschen = new Array(4 * HZ).fill(0).map(() => Math.round((Math.random() - 0.5) * 40));
const rr = E.analysiere({ samples: rauschen, hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('reines Rauschen ergibt KEINE Rhythmusaussage', rr.brauchbar === false, rr.rhythmus && rr.rhythmus.name);
ok('und nennt den Grund im Klartext', /verrauscht/.test(rr.warum || ''), rr.warum);

let fehlalarm = 0;
for (let i = 0; i < 20; i++) {
  const r = E.analysiere({ samples: bauEKG({ rauschen: 120 }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
  if (r.rhythmus && /vorzeitig/.test(r.rhythmus.name)) fehlalarm++;
}
ok('ein verrauschtes, aber regelmaessiges EKG ergibt kaum Fehlalarme (hoechstens 3 von 20)',
  fehlalarm <= 3, fehlalarm + '/20');

const kurz = E.analysiere({ samples: bauEKG({ sek: 1 }), hz: HZ, skala: 1 }, { bandHr: [60, 140] });
ok('ein zu kurzer Streifen ergibt keine Aussage', kurz.brauchbar === false);
ok('mit Begruendung', /zu kurz/.test(kurz.warum || ''), kurz.warum);

const abgefallen = E.analysiere({ samples: new Array(4 * HZ).fill(null), hz: HZ }, {});
ok('eine abgefallene Ableitung ergibt keine Aussage', abgefallen.brauchbar === false);
ok('und wird NICHT als Asystolie gemeldet', !/[Aa]systolie/.test(abgefallen.warum || '') || /Ableitung/.test(abgefallen.warum));

const ohneRate = E.analysiere({ samples: bauEKG({}), hz: 0 }, {});
ok('ohne Abtastrate wird nichts behauptet', ohneRate.brauchbar === false, ohneRate.warum);

/* ---------------- 4) ST-Strecke nur mit bekannter Verstaerkung ---------------- */
console.log('\nST-Strecke:');
const stOhne = E.analysiere({ samples: bauEKG({ hf: 120 }), hz: HZ, skala: null }, { bandHr: [60, 140], einheit: '' });
ok('ohne bekannte Verstaerkung gibt es KEINE Angabe in mV', stOhne.st && stOhne.st.messbar === false, JSON.stringify(stOhne.st));
ok('und der Grund wird genannt', /Verstärkung/.test((stOhne.st && stOhne.st.warum) || ''), stOhne.st && stOhne.st.warum);
const stMit = E.analysiere({ samples: bauEKG({ hf: 120 }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('mit Verstaerkung wird ein Wert in mV geliefert', stMit.st && stMit.st.messbar === true && typeof stMit.st.mv === 'number', JSON.stringify(stMit.st));

/* ---------------- 5) Die Kurve kommt wirklich aus dem Geraet ---------------- */
console.log('\nAnbindung an die Geraetedaten:');
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const werte = bauEKG({ hf: 120, sek: 2 }).join('^');
const frame = parseHL7Message([
  'MSH|^~\\&|LifeVet 10C||||||ORU^R01|1|P|2.3.1',
  'OBX|1|NM|131330^MDC_ECG_ELEC_POTL_II||' + werte + '|uV|||||F',
  'OBX|2|NM|0^MDC_ATTR_SAMP_RATE||256|Hz|||||F',
  'OBX|3|NM|2327^MDC_ATTR_NU_MSMT_RES||1.000000||||||F',
].join('\r'), { deviceId: 't' }, function () {});
ok('der Kurvenblock des Geraets wird gelesen', (frame.kurvenDaten || []).length === 1);
ok('mit Abtastrate 256 Hz', frame.kurvenDaten[0].hz === 256);
const ausGeraet = E.analysiere(frame.kurvenDaten[0], { bandHr: [60, 140], einheit: 'uV' });
ok('und laesst sich direkt auswerten', ausGeraet.brauchbar === true, ausGeraet.warum);
ok('die gemessene Frequenz stimmt', Math.abs(ausGeraet.hf - 120) <= 6, String(ausGeraet.hf));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
