'use strict';
/*
 * paket-test.js — Regressionstest fuer die BEDIENBARKEIT auf dem Praxis-PC.
 *
 * HINTERGRUND (21.07.2026): Der Nutzer hat auf dem frisch installierten Praxis-PC
 *   powershell -ExecutionPolicy Bypass -File installer\set-static-ip.ps1
 * eingegeben und bekam: "Das Argument ... fuer den -File-Parameter ist nicht vorhanden".
 * Grund: PowerShell startet in C:\Windows\System32 — ein RELATIVER Pfad zeigt dort ins Leere.
 * Zweiter Fehler derselben Klasse: die Anleitung empfahl `npm run check`, aber auf dem
 * Ziel-PC gibt es KEIN npm (nur das portable node\node.exe).
 *
 * Dieser Test stellt sicher, dass der Tierarzt NIEMALS einen Pfad tippen muss:
 * es gibt Doppelklick-Dateien, sie benutzen %~dp0 (eigener Ordner) und liegen im Startmenue.
 *
 * Start: node tools/paket-test.js      (laeuft auch in `npm test`)
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
// ZEILENENDEN NORMALISIEREN (Befund 2.12, 21.07.2026): dieser Test scheiterte an CRLF statt am
// Inhalt — ein Fehler, der keiner war. Sobald Git die Dateien mit \r\n auscheckt, findet
// indexOf('title VetStation\n') nichts mehr und die Blockgrenzen rutschen. Der Inhalt ist
// gemeint, nicht das Zeilenende.
function read(rel) { try { return fs.readFileSync(path.join(ROOT, rel), 'utf8').replace(/\r\n/g, '\n'); } catch (_) { return ''; } }

console.log('VetStation — Paket/Bedienbarkeit auf dem Praxis-PC\n');

const mk = read('installer/make-dist.ps1');
const iss = read('installer/vetstation-setup.iss');
const ip = read('installer/set-static-ip.ps1');
const lan = read('docs/LAN-SETUP.md');

// 1) Die beiden Doppelklick-Dateien werden ins Paket geschrieben
console.log('Doppelklick statt Tippen:');
ok('make-dist erzeugt NETZWERK-EINRICHTEN.bat', mk.indexOf('NETZWERK-EINRICHTEN.bat') >= 0);
ok('make-dist erzeugt GERAETE-PRUEFEN.bat', mk.indexOf('GERAETE-PRUEFEN.bat') >= 0);

// 2) Sie duerfen NICHT vom Startverzeichnis abhaengen -> immer %~dp0 (Ordner der .bat)
const netzBlock = mk.slice(mk.indexOf('title VetStation'), mk.indexOf("'NETZWERK-EINRICHTEN.bat'"));
ok('NETZWERK-EINRICHTEN.bat benutzt %~dp0 (kein relativer Pfad)',
  /%~dp0installer\\set-static-ip\.ps1/.test(netzBlock), 'Block: ' + netzBlock.slice(0, 120));
const pruefIdx = mk.indexOf('Geraete pruefen');
const pruefBlock = pruefIdx >= 0 ? mk.slice(pruefIdx, mk.indexOf("'GERAETE-PRUEFEN.bat'")) : '';
ok('GERAETE-PRUEFEN.bat benutzt %~dp0 (kein relativer Pfad)',
  /%~dp0tools\\geraete-check\.js/.test(pruefBlock));

// 3) Auf dem Ziel-PC gibt es kein npm -> nur portables node.exe verwenden
ok('GERAETE-PRUEFEN.bat startet node\\node.exe (nicht npm)',
  /%~dp0node\\node\.exe/.test(pruefBlock));
ok('GERAETE-PRUEFEN.bat ruft NICHT "npm run" auf',
  !/npm\s+run\s+check/.test(pruefBlock.replace(/^REM.*$/gm, '')));
ok('das aufgerufene Skript existiert wirklich', fs.existsSync(path.join(ROOT, 'tools', 'geraete-check.js')));
ok('GERAETE-PRUEFEN.bat haelt das Fenster offen (pause)', /\npause/.test(pruefBlock));

// 3b) Weitere Doppelklick-Dateien, die es vorher gar nicht gab (Befund 2.6 / 2.9)
ok('make-dist erzeugt NEUSTART.bat', mk.indexOf("'NEUSTART.bat'") >= 0);
ok('make-dist erzeugt FIREWALL-FREIGEBEN.bat', mk.indexOf("'FIREWALL-FREIGEBEN.bat'") >= 0);
const neuBlock = mk.slice(mk.indexOf('title VetStation - neu starten'), mk.indexOf("'NEUSTART.bat'"));
ok('NEUSTART.bat beendet ZUERST und startet dann',
  neuBlock.indexOf('stop-kiosk.ps1') >= 0 && neuBlock.indexOf('launch-kiosk.ps1') >= 0 &&
  neuBlock.indexOf('stop-kiosk.ps1') < neuBlock.indexOf('launch-kiosk.ps1'));
ok('NEUSTART.bat benutzt %~dp0 (kein relativer Pfad)', /%~dp0kiosk\\stop-kiosk\.ps1/.test(neuBlock));
const fwBlock = mk.slice(mk.indexOf('title VetStation - Firewall freigeben'), mk.indexOf("'FIREWALL-FREIGEBEN.bat'"));
ok('FIREWALL-FREIGEBEN.bat ruft set-firewall.ps1 mit %~dp0', /%~dp0installer\\set-firewall\.ps1/.test(fwBlock));

// 3b2) Ferndiagnose + Projektuebergabe an einen anderen PC (Wunsch 22.07.2026)
ok('make-dist erzeugt BEFUND-EXPORTIEREN.bat', mk.indexOf("'BEFUND-EXPORTIEREN.bat'") >= 0);
ok('make-dist erzeugt AUF-USB-KOPIEREN.bat', mk.indexOf("'AUF-USB-KOPIEREN.bat'") >= 0);
const befBlock = mk.slice(mk.indexOf('title VetStation - Befund exportieren'), mk.indexOf("'BEFUND-EXPORTIEREN.bat'"));
ok('BEFUND-EXPORTIEREN.bat benutzt node\\node.exe (kein npm am Praxis-PC)', /%~dp0node\\node\.exe/.test(befBlock));
ok('und ruft tools\\befund-export.js mit %~dp0', /%~dp0tools\\befund-export\.js/.test(befBlock));
ok('das Exportwerkzeug existiert', fs.existsSync(path.join(ROOT, 'tools', 'befund-export.js')));
const bex = read('tools/befund-export.js');
ok('der Export macht Patienten-Kennungen unkenntlich (§10)', /function anonym/.test(bex));
ok('er exportiert KEINE Vitalwerte, nur deren Vorhandensein',
  /vorhandene Messwerte/.test(bex) && !/p\.vitals\.hr/.test(bex));
ok('er meldet, wenn eine ANDERE Version laeuft als installiert ist', /es LAEUFT/.test(bex));
const usb = read('installer/auf-usb-kopieren.ps1');
ok('das Kopierskript existiert', usb.length > 500);
ok('es kopiert die Git-Historie mit (sonst fehlt am anderen PC jede Begruendung)', /\.git/.test(usb));
ok('es prueft die Kopie NACH dem Schreiben', /Kopie nachpruefen/.test(usb));
ok('es bricht ab, wenn die Selbsttests rot sind', /Selbsttests fehlgeschlagen/.test(usb));
ok('es prueft vorher den freien Platz', /Free/.test(usb) && /400MB|400 MB/.test(usb));
ok('es schreibt einen Wegweiser fuer den anderen PC', /LIESMICH\.txt/.test(usb));

// 3c) Nach einem Update lief weiter der ALTE Programmstand (Befund 2.9).
const instBlock = mk.slice(mk.indexOf('title VetStation - installieren'), mk.indexOf("'INSTALLIEREN.bat'"));
ok('INSTALLIEREN.bat ist EIN Weg fuer Neuinstallation UND Update',
  /installieren \/ aktualisieren/.test(instBlock) || /Neuinstallation UND Update/.test(instBlock));
const inst = read('installer/Install-VetStation.ps1');
ok('Installer beendet die laufende Station VOR dem Kopieren',
  inst.indexOf('stop-kiosk.ps1') >= 0 && inst.indexOf('stop-kiosk.ps1') < inst.indexOf('Kopiere App nach'));
ok('Installer startet die Station danach wieder', inst.indexOf('launch-kiosk.ps1') >= 0);
ok('Installer PRUEFT NACH, ob der laufende Stand dem installierten entspricht',
  inst.indexOf('/api/version') >= 0 && /GEPRUEFT: es laeuft Version/.test(inst));
ok('Installer warnt vor einem versehentlichen Rueckschritt auf eine aeltere Version',
  /AELTER als die installierte/.test(inst));
ok('Installer laesst die Kundenkonfiguration devices.json unangetastet',
  /\/XF[^\n]*devices\.json/.test(inst));

// 4) Startmenue-/Desktop-Verknuepfungen im Installer
console.log('\nVerknuepfungen im Installer:');
ok('Setup legt Startmenue-Eintrag "Netzwerk einrichten" an',
  /\[Icons\][\s\S]*NETZWERK-EINRICHTEN\.bat/.test(iss));
ok('Setup legt Startmenue-Eintrag "Geraete pruefen" an',
  /\[Icons\][\s\S]*GERAETE-PRUEFEN\.bat/.test(iss));

// 4b) VERBOTENE ZEICHEN IN VERKNUEPFUNGSNAMEN (Befund 2.7) — der Fehler, der die Installation
//     JEDES MAL abbrechen liess, und zwar NACH dem Kopieren:
//       IPersistFile::Save schlug fehl; Code 0x8007007B
//     Ursache: der Name endete auf ein Fragezeichen. Eine Verknuepfung ist eine .lnk-DATEI,
//     und \ / : * ? " < > | sind in Windows-Dateinamen verboten.
console.log('\nVerknuepfungsnamen ohne verbotene Zeichen (Befund 2.7):');
const VERBOTEN = ['*', '?', '"', '<', '>', '|'];   // \ / : trennen im Inno-Namen die Ordner
const issNamen = [];
iss.split('\n').forEach((ln) => {
  const m = ln.match(/^\s*Name:\s*"([^"]+)"/);
  if (m) issNamen.push(m[1]);
});
ok('das Setup legt ueberhaupt Verknuepfungen an', issNamen.length >= 5, issNamen.length + ' gefunden');
issNamen.forEach((n) => {
  const datei = n.split('\\').pop();
  const schlimm = VERBOTEN.filter((c) => datei.indexOf(c) >= 0);
  ok('Inno-Verknuepfung ohne verbotene Zeichen: ' + datei, schlimm.length === 0, 'enthaelt ' + schlimm.join(' '));
});
// Derselbe Fehler darf auch im PowerShell-Weg nicht auftreten.
const psNamen = [];
inst.split('\n').forEach((ln) => {
  const m = ln.match(/@\{\s*Name\s*=\s*'([^']+)'/);
  if (m) psNamen.push(m[1]);
});
ok('Install-VetStation.ps1 legt Startmenue-Eintraege an (Befund 2.8)', psNamen.length >= 4, psNamen.length + ' gefunden');
psNamen.forEach((n) => {
  const schlimm = VERBOTEN.filter((c) => n.indexOf(c) >= 0);
  ok('Startmenue-Eintrag ohne verbotene Zeichen: ' + n, schlimm.length === 0, 'enthaelt ' + schlimm.join(' '));
});
ok('Install-VetStation.ps1 filtert verbotene Zeichen zusaetzlich zur Laufzeit',
  /function Saubere-Verknuepfung/.test(inst) && /IPersistFile::Save/.test(inst));

// 4c) Firewall: EINE gemeinsame, wiederholbare Stelle (Befund 1.3 / 2.5)
console.log('\nFirewall-Regeln vermehren sich nicht mehr (Befund 2.5):');
const setfw = read('installer/set-firewall.ps1');
ok('installer/set-firewall.ps1 existiert', setfw.length > 200);
ok('sie loescht Altbestaende, BEVOR sie neu anlegt',
  setfw.indexOf('EntferneAlle $p') >= 0 && setfw.indexOf('EntferneAlle $p') < setfw.indexOf('if (Lege $p)'));
ok('sie kann auch nur pruefen, ohne etwas zu aendern', /\[switch\]\$Pruefen/.test(setfw));
ok('sie kann die Regeln wieder entfernen (Deinstallation)', /\[switch\]\$Entfernen/.test(setfw));
ok('sie holt sich die Adminrechte selbst',
  setfw.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && setfw.indexOf('-Verb RunAs') >= 0);
ok('das Inno-Setup legt die Regeln NICHT mehr selbst mit netsh an',
  !/\[Run\][\s\S]*netsh\.exe[^\n]*add rule/.test(iss));
ok('das Inno-Setup benutzt dieselbe set-firewall.ps1', /\[Run\][\s\S]*set-firewall\.ps1/.test(iss));
ok('Install-VetStation.ps1 benutzt ebenfalls set-firewall.ps1',
  inst.indexOf('set-firewall.ps1') >= 0 && !/New-NetFirewallRule/.test(inst));
ok('die Deinstallation raeumt die Regeln wieder ab',
  /\[UninstallRun\][\s\S]*set-firewall\.ps1[^\n]*-Entfernen/.test(iss));

// 4c2) DIESELBEN PORTS UEBERALL. Die Firewall muss genau die Ports oeffnen, auf denen die Station
//      auch zuhoert. Weicht eines ab, verwirft Windows die Vitaldaten LAUTLOS - und niemand merkt es.
console.log('\nFirewall, App und Konfigvorlage kennen dieselben Ports:');
const { DATA_PORTS } = require('../bridge/src/netscan');
const fwPortsRaw = setfw.match(/\$PORTS\s*=\s*@\(([^)]*)\)/);
const fwPorts = fwPortsRaw ? fwPortsRaw[1].split(',').map((x) => Number(x.trim())).filter(Boolean) : [];
ok('set-firewall.ps1 nennt eine Portliste', fwPorts.length > 0);
ok('Firewall-Ports == Datenports der App',
  fwPorts.length === DATA_PORTS.length && DATA_PORTS.every((p) => fwPorts.indexOf(p) >= 0),
  'Firewall: ' + fwPorts.join(',') + '  App: ' + DATA_PORTS.join(','));
const probeSrc = read('bridge/src/adapters/probe.js');
const probeRaw = probeSrc.match(/this\.ports\s*=\s*cfg\.ports[^:]*:\s*\[([^\]]*)\]/);
const probePorts = probeRaw ? probeRaw[1].split(',').map((x) => Number(x.trim())).filter(Boolean) : [];
ok('der Verbindungs-Assistent lauscht auf denselben Ports',
  probePorts.length === DATA_PORTS.length && DATA_PORTS.every((p) => probePorts.indexOf(p) >= 0),
  'Assistent: ' + probePorts.join(',') + '  App: ' + DATA_PORTS.join(','));
// Eigene Lesung: die Vorlage wird weiter unten nochmal fuer den Auslieferungszustand geparst.
let vorlage = null;
try { vorlage = JSON.parse(fs.readFileSync(path.join(ROOT, 'bridge/config/devices.example.json'), 'utf8')); } catch (_) { }
if (vorlage) {
  const vorlagePorts = ((vorlage.adapters || []).find((a) => a.type === 'probe') || {}).ports || [];
  ok('devices.example.json nennt dieselben Ports',
    vorlagePorts.length === DATA_PORTS.length && DATA_PORTS.every((p) => vorlagePorts.indexOf(p) >= 0),
    'Vorlage: ' + vorlagePorts.join(','));
}
// Der Port, der in der Praxis am 22.07.2026 fehlte: das LifeVet 10C sendet ab Werk an 8830.
ok('Port 8830 ist dabei (Standardziel des LifeVet 10C)', DATA_PORTS.indexOf(8830) >= 0);
ok('3502 wird weiterhin zuerst geprueft (uMEC12-Standard)', DATA_PORTS[0] === 3502);

// 4c3) INTERNET-EINRICHTEN.bat (neu 22.07.2026). Der Praxis-PC hatte 192.168.0.99 OHNE Gateway -
//      richtig fuer ein isoliertes Geraetenetz, aber er hing ueber einen TP-Link-Verstaerker am
//      Hausnetz. Folge: Geraetedaten liefen, Update/Fern-Live/klinische Daten waren STILL tot.
//      Es gab keinen Weg, das ohne Systemsteuerung zu heilen.
console.log('\nInternetzugang nachtragen, ohne die Geraete-IP zu zerstoeren:');
const inet = read('installer/set-internet.ps1');
const inetBat = read('INTERNET-EINRICHTEN.bat');
ok('installer/set-internet.ps1 existiert', inet.length > 500);
ok('INTERNET-EINRICHTEN.bat existiert und ruft es mit %~dp0 auf',
  /%~dp0installer\\set-internet\.ps1/.test(inetBat));
ok('es holt sich die Adminrechte selbst',
  inet.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && inet.indexOf('-Verb RunAs') >= 0);
ok('es aendert die feste IP NICHT (sonst reisst es die Geraeteverbindung ab)',
  !/New-NetIPAddress/.test(inet) && /bleibt UNVERAENDERT/.test(inet));
ok('es schreibt die Route auch in den PersistentStore (ueberlebt den Neustart)',
  /PolicyStore PersistentStore/.test(inet));
ok('es prueft NACH, ob wirklich Internet da ist, statt Erfolg zu behaupten',
  /Test-Connection[\s\S]{0,200}Resolve-DnsName/.test(inet) && /ERFOLG/.test(inet));
ok('es kann den Zustand wieder zuruecknehmen (-Entfernen)', /\[switch\]\$Entfernen/.test(inet));
ok('es sagt, dass die Geraeteverbindung davon unberuehrt bleibt',
  /GERAETEVERBINDUNG ist davon unabhaengig|Geraeteverbindung ist davon nicht betroffen/.test(inet));

// 4d) Setup.exe muss OHNE Fremdsoftware baubar sein (Befund 2.10)
console.log('\nSetup.exe ohne Inno Setup baubar (Befund 2.10):');
const mse = read('installer/make-setup-exe.ps1');
ok('installer/make-setup-exe.ps1 existiert', mse.length > 200);
ok('benutzt IExpress (steckt in jedem Windows)', mse.indexOf('iexpress.exe') >= 0);
ok('bricht ab, wenn das Paket fehlt statt eine kaputte Setup.exe zu bauen',
  /ABBRUCH: .*fehlt/.test(mse));
ok('bricht ab, wenn node.exe im Paket fehlt', /node\\node\.exe fehlt/.test(mse));
ok('nimmt die Version aus der EINEN Quelle der Wahrheit', /package\.json[\s\S]{0,120}\$Version = \$pkg\.version/.test(mse));
const bauen = read('SETUP-BAUEN.bat');
ok('SETUP-BAUEN.bat baut Paket UND Setup.exe mit einem Doppelklick',
  bauen.indexOf('make-dist.ps1') >= 0 && bauen.indexOf('make-setup-exe.ps1') >= 0);
ok('SETUP-BAUEN.bat baut KEIN Setup, wenn die Selbsttests fehlschlagen',
  /Selbsttests sind FEHLGESCHLAGEN/.test(bauen));
ok('SETUP-BAUEN.bat raeumt die Bau-Reste auf', /rmdir[^\n]*_setupbau/.test(bauen));
ok('SETUP-BAUEN.bat sagt am Ende, WAS entstanden ist', /VetStation-Setup\.exe/.test(bauen) && /Update-Paket/.test(bauen));

// 4e) Das UPDATE-PAKET fuer den In-App-Updater. Bei 0.6.0 gab es zuerst eine neue Setup.exe,
//     aber KEIN Update-Paket - eine bereits laufende Station haette also nicht nachziehen
//     koennen. Der Schritt war reine Handarbeit; jetzt macht ihn make-dist.ps1 mit.
console.log('\nUpdate-Paket fuer den In-App-Updater:');
ok('make-dist.ps1 erzeugt das versionierte Update-Paket',
  /VetStation-\$ver\.zip/.test(mk) || mk.indexOf('"VetStation-$ver.zip"') >= 0);
ok('das Update-Paket laesst node\\ draussen (sonst 27 MB statt 0,7 MB)',
  /\$_\.Name -ne 'node'/.test(mk));
ok('und data\\ ebenfalls (Betriebsdaten des Kunden)', /\$_\.Name -ne 'data'/.test(mk));
ok('make-dist.ps1 nennt die sha256-Pruefsumme fuers Manifest', /Get-FileHash[^\n]*SHA256/.test(mk));
ok('make-dist.ps1 warnt, falls node\\ doch hineingeraten ist', /vermutlich ist node/.test(mk));
ok('die Version des Update-Pakets kommt aus der Wurzel-package.json',
  /Get-Content \(Join-Path \$Root 'package\.json'\)[\s\S]{0,80}\$ver/.test(mk));

// 5) set-static-ip.ps1 muss sich die Adminrechte selbst holen und lesbar bleiben
console.log('\nset-static-ip.ps1:');
ok('holt sich Adminrechte selbst (RunAs-Guard)',
  ip.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && ip.indexOf('-Verb RunAs') >= 0);
ok('nennt den VOLLSTAENDIGEN Pfad als Handaufruf',
  ip.indexOf('C:\\VetStation\\installer\\set-static-ip.ps1') >= 0);
ok('empfiehlt NICHT mehr "npm run check"', !/npm run check/.test(ip));
ok('verweist auf GERAETE-PRUEFEN.bat', ip.indexOf('GERAETE-PRUEFEN.bat') >= 0);
ok('Fenster bleibt am Ende offen (Read-Host)', /Read-Host[^\n]*EINGABETASTE/.test(ip));
// Der Nutzer tippte auf die Frage "Nummer der Karte" eine IP bzw. "1231" und bekam nur
// "Ungueltige Auswahl" + sofortigen Abbruch. Deshalb: bei einer Karte gar nicht fragen.
ok('waehlt die Netzwerkkarte automatisch, wenn es nur eine (verbundene) gibt',
  /Netzwerkkarte automatisch gewaehlt/.test(ip) && /Where-Object Status -eq 'Up'\)\.Count -eq 1/.test(ip));
ok('blendet VPN-/virtuelle Adapter aus', /\$VIRTUELL\s*=/.test(ip) && ip.indexOf('Radmin') >= 0);
ok('bricht bei Fehleingabe nicht sofort ab (mehrere Versuche)', /versuch -ge 3/.test(ip));
ok('sagt klar, dass nur die Zahl aus der Klammer erwartet wird',
  ip.indexOf('NUR die Zahl aus der eckigen Klammer') >= 0);
ok('prueft nach, ob die IP wirklich gesetzt wurde', /ERFOLG/.test(ip) && /Get-NetIPAddress[^\n]*\n?[^\n]*IPAddress -eq \$IP/.test(ip));

// 6) ANSI-Falle: Windows PowerShell 5.1 liest .ps1 ohne BOM als ANSI. Ein UTF-8-Gedankenstrich
//    zerfaellt dabei in U+201D — und das ist fuer PowerShell ein STRING-ANFANG. Ergebnis:
//    "Die schliessende } fehlt". Deshalb muessen die Skripte ASCII-rein bleiben.
console.log('\nASCII-Reinheit der PowerShell-Skripte (PowerShell-5.1-ANSI-Falle):');
['installer', 'kiosk'].forEach((dir) => {
  const psDir = path.join(ROOT, dir);
  fs.readdirSync(psDir).filter((f) => f.endsWith('.ps1')).forEach((f) => {
    const buf = fs.readFileSync(path.join(psDir, f));
    let bad = -1;
    for (let i = 0; i < buf.length; i++) { if (buf[i] > 0x7f) { bad = i; break; } }
    ok(dir + '/' + f + ' ist rein ASCII', bad === -1, bad >= 0 ? ('Byte 0x' + buf[bad].toString(16) + ' an Position ' + bad) : '');
  });
});

// 6b) Adminrechte: Skripte, die geplante Aufgaben registrieren, muessen sich selbst erhoehen —
//     sonst brechen sie mit "Zugriff verweigert" ab (beim Entfernen frueher sogar lautlos).
console.log('\nAdminrechte holen sich die Skripte selbst:');
const autostart = read('kiosk/install-autostart.ps1');
ok('install-autostart.ps1 hat RunAs-Guard',
  autostart.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && autostart.indexOf('-Verb RunAs') >= 0);
ok('install-autostart.ps1 meldet ehrlich, wenn nichts zu entfernen war',
  autostart.indexOf('war nicht registriert') >= 0);
ok('install-autostart.ps1 nennt den vollstaendigen Pfad',
  autostart.indexOf('C:\\VetStation\\kiosk\\install-autostart.ps1') >= 0);

// 6c) Der Starter darf im Fehlerfall nicht kommentarlos verschwinden.
console.log('\nStarter zeigt Fehler an:');
const startBlock = mk.slice(mk.indexOf('title VetStation\n'), mk.indexOf("'START-VetStation.bat'"));
ok('START-VetStation.bat haelt bei Fehler an (errorlevel + pause)',
  /if errorlevel 1/.test(startBlock) && /pause/.test(startBlock));
ok('GERAETE-PRUEFEN.bat reicht eine Geraete-IP durch (%*)', /geraete-check\.js" %\*/.test(pruefBlock));

// 7) Konsolen-Hinweise der Pruef-App: sie haben dem Nutzer genau den Befehl vorgeschlagen,
//    der heute fehlgeschlagen ist. Sie duerfen keine relativen Pfade mehr nennen.
//    Die Handlungsanweisungen selbst stehen inzwischen in bridge/src/diagnose.js — EINE Stelle
//    fuer CLI und Oberflaeche, damit Check und App nie Verschiedenes behaupten.
console.log('\nHinweistexte (tools/geraete-check.js + bridge/src/diagnose.js):');
const check = read('tools/geraete-check.js');
const diag = read('bridge/src/diagnose.js');
const rat = check + '\n' + diag;
ok('schlaegt KEINEN relativen -File-Pfad mehr vor', !/-File installer\\\\set-static-ip/.test(rat));
// Nur die BILDSCHIRMAUSGABE zaehlt: im Kopfkommentar darf der Entwickler-Aufruf stehen bleiben.
const ausgaben = check.split('\n').filter((l) => l.indexOf('console.log') >= 0).join('\n');
ok('keine Bildschirmausgabe schlaegt "node tools/..." vor', !/node tools\//.test(ausgaben));
ok('keine Bildschirmausgabe nennt einen relativen installer/-Pfad',
  !/[^\\:]installer[\\/]set-static-ip|[^\\:]installer[\\/]setup-vscapture/.test(ausgaben));
ok('verweist auf NETZWERK-EINRICHTEN.bat', rat.indexOf('NETZWERK-EINRICHTEN.bat') >= 0);
ok('nennt setup-vscapture mit vollem Pfad', rat.indexOf('C:\\\\VetStation\\\\installer\\\\setup-vscapture-fallback.ps1') >= 0);
ok('CLI-Check und Oberflaeche benutzen DIESELBE Diagnose',
  check.indexOf("require('../bridge/src/diagnose')") >= 0);
ok('CLI-Check benutzt die aktive Suche statt nur der ARP-Tabelle (Befund 2.1)',
  check.indexOf("require('../bridge/src/netscan')") >= 0);
ok('CLI-Check liest die Firewall aus, statt sie nur zu empfehlen (Befund 2.6)',
  check.indexOf("require('../bridge/src/firewall')") >= 0);
ok('CLI-Check verweist auf denselben Knopf in der App',
  /Admin -> "Netzwerk & Geraete"/.test(check));

// 7b) AUSLIEFERUNGSZUSTAND: was der Kunde auspackt, muss zum Praxisnetz passen (Befund 2.11).
console.log('\nAuslieferungszustand bridge/config/devices.example.json:');
let bsp = null;
try { bsp = JSON.parse(fs.readFileSync(path.join(ROOT, 'bridge/config/devices.example.json'), 'utf8')); } catch (e) { }
ok('devices.example.json ist gueltiges JSON', !!bsp);
if (bsp) {
  const roh = JSON.stringify(bsp);
  ok('keine erfundenen Geraete-IPs mehr (192.168.23.x gibt es im Praxisnetz nicht)',
    !/192\.168\.23\./.test(roh));
  const hosts = (bsp.adapters || []).filter((a) => a.host).map((a) => a.host);
  // "auto" ist seit 0.7.2 der EMPFOHLENE Wert: die Station folgt dem Geraet, das sie tatsaechlich
  // im Netz findet. Am 22.07.2026 stand hier fest .50, das Geraet hing auf .51 - die Abfrage lief
  // 60 s lang gegen eine tote Adresse, waehrend der Assistent die richtige bereits kannte.
  ok('alle Geraete-Adressen sind "auto" oder liegen im ausgelieferten Netz 192.168.0.x',
    hosts.length > 0 && hosts.every((h) => h === 'auto' || h.indexOf('192.168.0.') === 0), hosts.join(', '));
  ok('die Vorlage empfiehlt "auto" (folgt dem Geraet auch nach einem DHCP-Wechsel)',
    hosts.indexOf('auto') >= 0, hosts.join(', '));
  ok('der Verbindungs-Assistent ist ab Werk AN (findet Geraete von selbst)',
    (bsp.adapters || []).some((a) => a.type === 'probe' && a.enabled !== false));
  ok('der Assistent lauscht ab Werk auf 3502 (Praxis-Standard)',
    (bsp.adapters || []).some((a) => a.type === 'probe' && (a.ports || []).indexOf(3502) >= 0));
  ok('der Simulator ist ab Werk AUS (keine simulierten Patienten im Betrieb)',
    (bsp.adapters || []).every((a) => a.type !== 'simulator' || a.enabled === false));
  /*
   * Fern-Live. Bis 0.8.0 stand hier "muss ab Werk AUS sein", weil die Realtime Database in der
   * Firebase-Konsole gar nicht existierte (HTTP 404) und der Publisher ab der ersten Sekunde nur
   * Fehler produziert haette (Befund 1.4 / 2.2). Am 27.07.2026 wurde die Datenbank angelegt
   * (vet-station-default-rtdb, europe-west1) — die Begruendung fuer "aus" ist damit entfallen.
   * Geprueft wird jetzt, dass die Vorlage auf genau diese Datenbank zeigt und dass die
   * datenschutzrelevante Voreinstellung stimmt.
   */
  const cl = bsp.cloud || {};
  ok('Fern-Live ist ab Werk AN (Datenbank ist angelegt)', cl.enabled === true);
  ok('Fern-Live zeigt auf die angelegte Datenbank (europe-west1)',
    /^https:\/\/vet-station-default-rtdb\.europe-west1\.firebasedatabase\.app\/?$/.test(cl.dbUrl || ''), cl.dbUrl);
  ok('Sendetakt ist gesetzt und nicht unter der Untergrenze (100 ms)',
    typeof cl.minIntervalMs === 'number' && cl.minIntervalMs >= 100, String(cl.minIntervalMs));
  /*
   * KEIN GEMEINSAMER ZUGANGSCODE IN DER VORLAGE (Sicherheitsbefund 27.07.2026).
   * bridge/src/index.js faellt auf devices.example.json zurueck, wenn keine eigene devices.json
   * existiert. Solange dort ein FESTER Zugangscode stand, landeten zwei Praxen ohne eigene
   * Konfiguration auf demselben Datenknoten — jede haette die Patienten der anderen gesehen und
   * beide haetten sich im 200-ms-Takt die Vitalwerte ueberschrieben. Seit die Daten an der
   * Anmelde-Kennung haengen, darf hier kein Code mehr auftauchen.
   */
  ok('die Vorlage enthaelt KEINEN Zugangscode mehr', cl.code === undefined, String(cl.code));
  ok('die Vorlage enthaelt KEIN Passwort im Klartext',
    cl.password === undefined && cl.passwort === undefined);
  ok('die Vorlage erklaert, warum das Passwort nicht hier steht', !!cl._kein_passwort_hier);
  ok('die Vorlage erklaert die Schalter', !!(cl._minIntervalMs && cl._stammdaten && cl._kurven));
}

// 8) Oberflaeche: keine Pfade nennen, die es auf dem Praxis-PC nicht gibt.
console.log('\nOberflaeche (ui):');
const adm = read('ui/views/admin.js');
ok('Fern-Live nennt den vollstaendigen Konfigurationspfad',
  adm.indexOf('C:\\\\VetStation\\\\bridge\\\\config\\\\') >= 0);
ok('Fern-Live erklaert devices.example.json -> devices.json', adm.indexOf('devices.example.json') >= 0);
ok('Update wendet nicht mehr per location.reload() an (tat nichts)',
  !/restart[\s\S]{0,200}location\.reload\(\)/.test(adm));
ok('Update sagt, dass es beim naechsten Start angewendet wird',
  adm.indexOf('nächsten Start von VetStation') >= 0);
const live = read('ui/vetstation-live.js');
ok('Kiosk macht tote Modul-Links unklickbar', /a\[href\^="\.\.\/"\]\{pointer-events:none/.test(live));
ok('Kiosk blendet den toten "Start"-Link aus', live.indexOf('header a[href="../"]') >= 0);

// 7) Paket ohne node.exe waere unbrauchbar -> make-dist muss abbrechen
console.log('\nPaketbau:');
ok('make-dist bricht ab, wenn node.exe fehlt', /throw "ABBRUCH: node\\node\.exe fehlt/.test(mk));
ok('make-dist rettet vorhandenes node.exe (Offline-Build)', mk.indexOf('vetstation-node-cache.exe') >= 0);

// 8) Die Anleitung darf den Fehler nicht wiederholen
console.log('\nAnleitung docs/LAN-SETUP.md:');
ok('warnt vor dem relativen Pfad', lan.indexOf('C:\\Windows\\System32') >= 0);
ok('nennt NETZWERK-EINRICHTEN.bat zum Doppelklicken', lan.indexOf('NETZWERK-EINRICHTEN.bat') >= 0);
ok('nennt GERAETE-PRUEFEN.bat statt npm', lan.indexOf('GERAETE-PRUEFEN.bat') >= 0);
ok('erklaert, dass es auf dem Praxis-PC kein npm gibt', /npm[^\n]*gibt es auf dem Praxis-PC nicht/.test(lan));

// 9) Lautlose Fehlschlaege: Skripte duerfen nicht "erledigt" melden, wenn nichts passiert ist.
console.log('\nKeine lautlosen Fehlschlaege:');
const stop = read('kiosk/stop-kiosk.ps1');
ok('stop-kiosk.ps1 holt sich Adminrechte (Kiosk laeuft erhoeht)',
  stop.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && stop.indexOf('-Verb RunAs') >= 0);
// Kommentare ausblenden: der Kopfkommentar BESCHREIBT das alte "try{}catch{}" und darf das auch.
const stopCode = stop.replace(/<#[\s\S]*?#>/g, '').split('\n').filter((l) => !/^\s*#/.test(l)).join('\n');
ok('stop-kiosk.ps1 verschluckt Fehler nicht mehr (kein leeres catch)', !/catch\s*\{\s*\}/.test(stopCode));
ok('stop-kiosk.ps1 warnt, wenn der Kiosk weiterlaeuft', stop.indexOf('laeuft moeglicherweise WEITER') >= 0);
const kiosk = read('docs/KIOSK-SETUP.md');
ok('KIOSK-SETUP.md behauptet nicht mehr "keine Adminrechte noetig"',
  kiosk.indexOf('keine Adminrechte nötig') < 0);

// 10) Sachlich falsche Zusagen in der Doku
console.log('\nDoku sagt die Wahrheit:');
const mray = read('docs/MINDRAY-HL7.md');
ok('MINDRAY-HL7.md behauptet nicht mehr, .NET 8 werde installiert',
  mray.indexOf('prüft/installiert **.NET 8') < 0 && /installiert \.NET 8 NICHT/.test(mray));
ok('MINDRAY-HL7.md erklaert devices.example.json -> devices.json', mray.indexOf('devices.example.json') >= 0);
const aa = read('kiosk/assigned-access.md');
ok('assigned-access.md warnt: Shell Launcher gibt es nicht in Windows Pro',
  /Pro gibt es Shell Launcher\s*\n?>?\s*nicht|nicht in Pro/.test(aa));
ok('assigned-access.md erklaert, dass die PIN im Kiosk nicht aenderbar ist',
  aa.indexOf('nur vom Techniker ändern') >= 0);

// 11) Veraltete Netzwerkangaben duerfen in keiner Anleitung mehr stehen - sie widersprechen
//     der ausgelieferten Software (PC .99 / Monitor .50 / Port 3502).
console.log('\nKeine veralteten IPs in den Anleitungen:');
['README.md', 'docs/LAN-SETUP.md', 'docs/KIOSK-SETUP.md', 'docs/MINDRAY-HL7.md',
 'docs/FERN-LIVE.md', 'installer/README.md', 'kiosk/assigned-access.md'].forEach((f) => {
  const t = read(f);
  const alt = (t.match(/192\.168\.(?:23|2)\.\d+/g) || []).filter((ip) => ip.indexOf('192.168.2.') !== 0 || true);
  // 192.168.23.x und 192.168.2.x sind beide veraltet; erlaubt ist nur eine ausdrueckliche
  // "veraltet"-Warnung, die den Wert nennt.
  const nurWarnung = alt.length > 0 && /veraltet/i.test(t);
  ok(f + ' ohne veraltete IP', alt.length === 0 || nurWarnung,
    alt.length ? ('gefunden: ' + alt.slice(0, 4).join(', ')) : '');
});

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
