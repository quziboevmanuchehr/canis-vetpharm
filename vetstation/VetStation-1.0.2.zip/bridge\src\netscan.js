'use strict';
/*
 * netscan.js — AKTIVE Geraetesuche im Praxisnetz.
 *
 * WARUM ES DIESE DATEI GIBT (Befund 21.07.2026):
 * Die alte Suche las nur die ARP-Tabelle und liess ausschliesslich zwei MAC-Praefixe gelten
 * (98:CC:E4, 00:0F:14). Beides ist blind:
 *   • Ein FRISCH angestecktes Geraet steht noch gar nicht in der ARP-Tabelle.
 *   • Ein Geraet mit anderem Praefix (andere Fertigungscharge, Eickemeyer-Rebrand, Fremdfabrikat)
 *     wurde stillschweigend verworfen.
 * In beiden Faellen meldete die Station "kein Geraet gefunden", obwohl eines am Kabel hing.
 *
 * DESHALB HIER: jede Adresse .1-.254 wird aktiv angesprochen (TCP-Anklopfen erzwingt die
 * ARP-Aufloesung, unabhaengig davon ob der Port offen ist), danach Portscan. Der HERSTELLER ist
 * nur noch ein HINWEIS, KEIN FILTER. Jeder Fund wird eingestuft UND BEGRUENDET.
 *
 * STRIKT READ-ONLY: es wird nur die TCP-Verbindung geoeffnet und sofort wieder geschlossen —
 * es werden keine Nutzdaten gesendet und an keinem Geraet etwas verstellt.
 *
 * Keine npm-Abhaengigkeiten (nur Node-Bordmittel).
 */
const os = require('os');
const net = require('net');
const { execFile } = require('child_process');

// Datenports, auf denen Narkose-/Patientenmonitore sprechen.
// 3502  = Mindray "Gateway-Kommunikation" (Standard-Ziel im uMEC12-Vet-Netzwerkmenue) -> zuerst.
// 4601  = HL7/VSCapture (am Praxisgeraet 192.168.0.50 tatsaechlich offen, 22.07.2026 gemessen).
// 8830  = Standardziel der HL7-Konfiguration im Eickemeyer LifeVet 10C ("Daten + Kurven" UND
//         "Alarme" stehen dort ab Werk auf Port 8830). Ohne diesen Port muesste der Tierarzt ihn
//         am Geraet umstellen - eine zusaetzliche Fehlerquelle. Die Station hoert lieber selbst
//         dort zu.
// 5000/24105/2575 = weitere HL7-Kandidatenports.
const DATA_PORTS = [3502, 4601, 8830, 5000, 24105, 2575];

// Ports, die einen Teilnehmer als NICHT-Medizingeraet ausweisen. Ein offener Datenport oder eine
// Medizin-MAC schlaegt diese Erkennung IMMER (ein Monitor bleibt ein Monitor).
const FREMD_PORTS = {
  445: 'Windows-Dateifreigabe (SMB)',
  139: 'Windows-Netzwerkname (NetBIOS)',
  3389: 'Remotedesktop (Windows-PC)',
  9100: 'Drucker (RAW/JetDirect)',
  515: 'Drucker (LPD)',
  631: 'Drucker (IPP)',
  53: 'DNS-Dienst (Router)',
};
// Absichtlich NICHT als Fremd-Merkmal: 80/443. Monitore haben oft selbst eine Web-Konfiguration.

// Hersteller-MAC (OUI) — reiner HINWEIS zur Einordnung, niemals Ausschlusskriterium.
const OUI = {
  '98cce4': 'Mindray (uMEC12 Vet / Veta 5 Plus)',
  '000f14': 'Mindray/Eickemeyer (LifeVet 10C)',
  '00e0fc': 'Huawei',
  '001b21': 'Intel',
  '000c29': 'VMware',
};

const VIRTUELL = /vpn|virtual|hyper-?v|vmware|virtualbox|radmin|tailscale|zerotier|tap|tun|wsl|bluetooth|docker|loopback/i;

function istPrivat(ip) { return /^192\.168\./.test(ip) || /^10\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip); }

/* ------------------------------------------------------------------ *
 * 1) Dieser PC im Netz
 * ------------------------------------------------------------------ */
function localAdapters() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const name in ifs) {
    for (const a of ifs[name] || []) {
      if (a.family !== 'IPv4' && a.family !== 4) continue;
      if (a.internal) continue;
      out.push({ name: name, address: a.address, netmask: a.netmask, mac: a.mac });
    }
  }
  out.forEach((i) => {
    let s = 0;
    i.virtuell = VIRTUELL.test(i.name);
    if (!i.virtuell) s += 10;
    if (istPrivat(i.address)) s += 5;
    if (/^192\.168\./.test(i.address)) s += 2;   // typisches Praxisnetz
    if (/ethernet|lan/i.test(i.name)) s += 3;    // Kabel schlaegt WLAN
    i.score = s;
  });
  out.sort((a, b) => b.score - a.score);
  return out;
}

/* ------------------------------------------------------------------ *
 * 2) TCP-Anklopfen — der eigentliche Trick
 *
 * Ein Verbindungsversuch zwingt Windows, die MAC-Adresse per ARP aufzuloesen — AUCH wenn der Port
 * geschlossen ist. Ein "Verbindung abgelehnt" (ECONNREFUSED/ECONNRESET) ist deshalb der STAERKSTE
 * Beweis, dass an dieser Adresse ein Geraet haengt: es hat aktiv geantwortet.
 * ------------------------------------------------------------------ */
function knock(host, port, timeoutMs) {
  return new Promise((resolve) => {
    const s = new net.Socket();
    let done = false;
    const fin = (r) => { if (done) return; done = true; try { s.destroy(); } catch (_) {} resolve(r); };
    s.setTimeout(timeoutMs || 400);
    s.once('connect', () => fin({ offen: true, lebt: true }));
    s.once('timeout', () => fin({ offen: false, lebt: false }));
    s.once('error', (e) => {
      // Abgelehnt/zurueckgesetzt = da IST jemand. Nur "nicht erreichbar" heisst wirklich niemand.
      const lebt = e && (e.code === 'ECONNREFUSED' || e.code === 'ECONNRESET');
      fin({ offen: false, lebt: !!lebt });
    });
    try { s.connect(port, host); } catch (_) { fin({ offen: false, lebt: false }); }
  });
}

// Arbeitet eine Liste mit begrenzter Gleichzeitigkeit ab (sonst laufen 254 Sockets gleichzeitig auf).
async function pool(items, worker, concurrency) {
  const n = Math.max(1, concurrency || 32);
  const out = new Array(items.length);
  let next = 0;
  const runner = async () => {
    for (;;) {
      const i = next++;
      if (i >= items.length) return;
      out[i] = await worker(items[i], i);
    }
  };
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, runner));
  return out;
}

/* ------------------------------------------------------------------ *
 * 3) ARP-Tabelle (Hersteller-HINWEIS, kein Filter)
 * ------------------------------------------------------------------ */
function parseArpTable(stdout) {
  const map = {};
  String(stdout || '').split(/\r?\n/).forEach((ln) => {
    const m = ln.match(/(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}(?:[-:][0-9a-fA-F]{2}){5})/);
    if (!m) return;
    const mac = m[2].toLowerCase().replace(/[-:]/g, '');
    if (mac === 'ffffffffffff' || /^01005e/.test(mac)) return;   // Broadcast/Multicast
    map[m[1]] = mac;
  });
  return map;
}

function arpTable() {
  return new Promise((resolve) => {
    execFile('arp', ['-a'], { timeout: 8000, windowsHide: true }, (err, stdout) => {
      if (err && !stdout) return resolve({ ok: false, map: {} });
      resolve({ ok: true, map: parseArpTable(stdout) });
    });
  });
}

// MAC mit gesetztem "locally administered"-Bit = Zufalls-MAC (Handy/Laptop mit Privatsphaere-Modus).
function istZufallsMac(mac) {
  if (!mac || mac.length < 2) return false;
  const zweites = parseInt(mac.slice(0, 2), 16);
  return Number.isFinite(zweites) && (zweites & 0x02) !== 0;
}

function herstellerVon(mac) { return mac ? (OUI[mac.slice(0, 6)] || null) : null; }
function istMedizinMac(mac) { return !!(mac && /^(98cce4|000f14)/.test(mac)); }

/*
 * Nachtrag aus der ARP-Tabelle — schliesst die letzte Luecke der TCP-Suche.
 *
 * Manche Geraete verwerfen TCP-Pakete auf geschlossenen Ports STILL (kein "abgelehnt", keine
 * Antwort). Sie sehen im Anklopfen wie "niemand da" aus. Auf der ARP-Ebene antworten sie aber
 * IMMER, sonst koennten sie ueberhaupt nicht im Netz arbeiten. Da unser Anklopfen die
 * ARP-Aufloesung ohnehin erzwungen hat, steht ein solches Geraet danach in der Tabelle —
 * und wird hier nachtraeglich aufgenommen, statt uebersehen zu werden.
 *
 * Pure Funktion (deshalb ohne Netz testbar).
 */
function ergaenzeAusArp(lebend, arpMap, base, selbst) {
  const bekannt = {};
  lebend.forEach((h) => { bekannt[h.ip] = true; });
  const zusatz = [];
  Object.keys(arpMap || {}).forEach((ip) => {
    if (bekannt[ip]) return;
    if (ip === selbst) return;
    if (base && ip.indexOf(base) !== 0) return;          // nur unser eigenes Netz
    if (/\.(0|255)$/.test(ip)) return;                    // Netz-/Broadcastadresse
    zusatz.push({ ip: ip, offenePorts: [], nurArp: true });
  });
  return lebend.concat(zusatz);
}

/* ------------------------------------------------------------------ *
 * 4) EINSTUFUNG — mit Begruendung. Pure Funktion (deshalb testbar ohne Netz).
 *
 *   sicher            antwortet auf Datenport / Medizin-MAC
 *   moeglich          antwortet im Netz, aber nichts spricht dafuer oder dagegen
 *   unwahrscheinlich  erkennbar Buero-PC, Drucker oder Router
 * ------------------------------------------------------------------ */
function classifyHost(h) {
  const gruende = [];
  const datenPorts = (h.offenePorts || []).filter((p) => DATA_PORTS.indexOf(p) >= 0);
  const fremd = (h.offenePorts || []).filter((p) => FREMD_PORTS[p]);
  const mac = h.mac || null;
  const hersteller = herstellerVon(mac);

  if (h.selbst) {
    return { stufe: 'selbst', gruende: ['dieser PC (VetStation laeuft hier)'], datenPorts: datenPorts, hersteller: hersteller };
  }

  // (0) EIN ZWEITER PC MIT VETSTATION sieht aus wie ein Geraet — ist aber keins.
  // Beobachtet am 22.07.2026: 192.168.0.233 wurde als "sicher ein Geraet" gemeldet, weil es auf
  // 2575, 3502, 4601, 5000, 8830 UND 24105 antwortete. Genau das tut der Verbindungs-Assistent
  // von VetStation: er lauscht auf ALLEN Datenports. Ein echter Monitor oeffnet hoechstens EINEN.
  // Eine Medizin-MAC schlaegt diese Regel weiterhin (ein Monitor bleibt ein Monitor).
  if (datenPorts.length >= 4 && !istMedizinMac(mac)) {
    gruende.push('antwortet auf ' + datenPorts.length + ' Datenports gleichzeitig (' + datenPorts.join(', ') + ')');
    gruende.push('so verhaelt sich ein PC mit laufender VetStation, nicht ein Medizingeraet — ein Monitor oeffnet hoechstens einen Port');
    if (hersteller) gruende.push('Hersteller laut MAC: ' + hersteller);
    return { stufe: 'unwahrscheinlich', gruende: gruende, datenPorts: datenPorts, hersteller: hersteller, zweiteStation: true };
  }

  // (1) Offener Datenport schlaegt ALLES — ein Monitor bleibt ein Monitor.
  if (datenPorts.length) {
    gruende.push('antwortet auf Datenport ' + datenPorts.join(', '));
    if (hersteller) gruende.push('Hersteller laut MAC: ' + hersteller);
    return { stufe: 'sicher', gruende: gruende, datenPorts: datenPorts, hersteller: hersteller };
  }

  // (2) Medizin-MAC schlaegt die Fremdgeraete-Erkennung ebenfalls.
  //
  // WICHTIG - HIER STAND EINE IRREFUEHRENDE BEGRUENDUNG (korrigiert 22.07.2026):
  // Frueher hiess es "aber KEIN offener Datenport - Datenausgabe am Geraet vermutlich aus".
  // Das ist falsch geschlossen. Ein Monitor, der seine Werte von sich aus SENDET (Push - der
  // Normalfall bei HL7), oeffnet ueberhaupt keinen Port: er baut die Verbindung ZUM PC auf.
  // Dass hier kein Port offen ist, sagt also NICHTS darueber, ob die Datenausgabe an ist.
  // Entscheidend ist allein, ob beim PC Werte ankommen.
  if (istMedizinMac(mac)) {
    gruende.push('feste MAC eines Medizingeraets (' + hersteller + ')');
    gruende.push('kein offener Datenport — das ist NORMAL: ein sendendes Geraet lauscht nicht, es ruft den PC an');
    gruende.push('ob Werte ankommen, zeigt erst die Lauschphase bzw. die Patientenanzeige');
    return { stufe: 'sicher', gruende: gruende, datenPorts: [], hersteller: hersteller, sendetVermutlich: true };
  }

  // (3) Erkennbare Fremdgeraete herabstufen — mit Begruendung, nicht stillschweigend.
  if (h.istGateway) {
    gruende.push('ist das Standardgateway (Router) — kein Medizingeraet');
    return { stufe: 'unwahrscheinlich', gruende: gruende, datenPorts: [], hersteller: hersteller };
  }
  if (fremd.length) {
    fremd.forEach((p) => gruende.push(FREMD_PORTS[p] + ' offen (Port ' + p + ')'));
    gruende.push('kein Medizingeraet');
    return { stufe: 'unwahrscheinlich', gruende: gruende, datenPorts: [], hersteller: hersteller };
  }
  if (istZufallsMac(mac)) {
    gruende.push('Zufalls-MAC (Handy/Laptop mit Privatsphaere-Modus)');
    return { stufe: 'unwahrscheinlich', gruende: gruende, datenPorts: [], hersteller: hersteller };
  }

  // (4) Rest: ehrlich "moeglich" — nicht als Geraet ausgeben, aber auch nicht verschweigen.
  gruende.push('antwortet im Netz, aber kein Datenport offen');
  if (hersteller) gruende.push('Hersteller laut MAC: ' + hersteller);
  if (!mac) gruende.push('keine MAC ermittelbar (nicht in der ARP-Tabelle)');
  return { stufe: 'moeglich', gruende: gruende, datenPorts: [], hersteller: hersteller };
}

/* ------------------------------------------------------------------ *
 * 5) Netzbereich bestimmen
 * ------------------------------------------------------------------ */
function subnetOf(adapter) {
  const ip = String(adapter.address || '').split('.').map(Number);
  const mask = String(adapter.netmask || '255.255.255.0').split('.').map(Number);
  if (ip.length !== 4 || ip.some((x) => !Number.isFinite(x))) return null;
  const bits = mask.reduce((n, o) => n + ((o >>> 0).toString(2).match(/1/g) || []).length, 0);
  const base = ip.slice(0, 3).join('.') + '.';
  // Groesser als /24 wird auf das /24 des PCs begrenzt — 65534 Adressen abzuklopfen dauert Stunden.
  return { base: base, bits: bits, begrenzt: bits < 24, hosts: 254 };
}

function gatewayIp(base) { return base + '1'; }   // in Praxisnetzen praktisch immer .1

/* ------------------------------------------------------------------ *
 * 5b) Kommt dieser PC ins Internet?
 *
 * WARUM DAS HIER STEHT (Praxis-PC, 22.07.2026): der PC hatte 192.168.0.99/24 OHNE Standardgateway
 * und ohne DNS — so sieht das isolierte Geraetenetz laut Anleitung auch aus. Nur hing er in
 * Wahrheit ueber einen TP-Link-Verstaerker am Hausnetz, in dem unter 192.168.0.1 ein Router steht.
 * Fuer die Geraetedaten ist das folgenlos (gleiches Netz), aber Update, Fern-Live und die
 * klinischen Daten waren still tot. Das stand nirgends — die Station meldete nur "kein Update
 * gefunden". Deshalb wird es jetzt gemessen und benannt.
 *
 * READ-ONLY: ein TCP-Anklopfen nach draussen, keine Nutzdaten.
 * ------------------------------------------------------------------ */
function gatewayAusRoute() {
  return new Promise((resolve) => {
    execFile('route', ['print', '-4', '0.0.0.0'], { timeout: 6000, windowsHide: true }, (err, stdout) => {
      if (err && !stdout) return resolve(null);
      // Zeile der Standardroute:  0.0.0.0   0.0.0.0   <Gateway>   <Schnittstelle>  <Metrik>
      const m = String(stdout).match(/^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+(\d+\.\d+\.\d+\.\d+)/m);
      resolve(m ? m[1] : null);
    });
  });
}

async function internetLage(opts) {
  opts = opts || {};
  const adapter = opts.adapter || localAdapters().filter((a) => !a.virtuell)[0] || null;
  const sub = adapter ? subnetOf(adapter) : null;
  const router = sub ? gatewayIp(sub.base) : null;
  const t = opts.timeoutMs || 2000;

  const gateway = await gatewayAusRoute();

  // Antwortet unter .1 ueberhaupt ein Router? (Web-Oberflaeche oder DNS - beides typisch)
  let routerImNetz = false;
  if (router) {
    const a = await knock(router, 80, 800);
    const b = a.lebt ? a : await knock(router, 53, 800);
    routerImNetz = a.lebt || b.lebt;
  }

  /*
   * BEIDE Protokolle einzeln messen — das war die Ueberraschung am 22.07.2026:
   * Der PC hatte KEIN IPv4-Standardgateway (1.1.1.1 unerreichbar), bezog aber ueber den
   * Kabelrouter per Router Advertisement eine vollstaendige IPv6-Verbindung samt DNS. Update und
   * klinische Daten funktionierten deshalb — nur eben ausschliesslich ueber IPv6. Wer hier nur
   * IPv4 prueft, meldet faelschlich "kein Internet"; wer nur "irgendwas geht" prueft, uebersieht,
   * wie duenn das Eis ist (jeder Dienst ohne AAAA-Eintrag ist unerreichbar).
   * Je Protokoll zwei verschiedene Ziele: faellt eines aus, entscheidet das andere.
   */
  const v4a = await knock('1.1.1.1', 443, t);
  const v4b = v4a.offen ? v4a : await knock('8.8.8.8', 53, t);
  const v4 = v4a.offen || v4b.offen;

  const v6a = await knock('2606:4700:4700::1111', 443, t);
  const v6b = v6a.offen ? v6a : await knock('2001:4860:4860::8888', 53, t);
  const v6 = v6a.offen || v6b.offen;

  return {
    gateway: gateway, router: router, routerImNetz: routerImNetz,
    v4: v4, v6: v6,
    nurV6: !v4 && v6,
    erreichbar: v4 || v6,
  };
}

/* ------------------------------------------------------------------ *
 * 6) Vollstaendiger Suchlauf
 * ------------------------------------------------------------------ */
async function scan(opts) {
  opts = opts || {};
  const onProgress = typeof opts.onProgress === 'function' ? opts.onProgress : function () {};
  const adapters = localAdapters();
  const echte = adapters.filter((a) => !a.virtuell);
  const gewaehlt = opts.adapter || echte[0] || adapters[0] || null;

  const ergebnis = {
    ts: Date.now(),
    adapters: adapters,
    adapter: gewaehlt,
    netz: null,
    hosts: [],
    arpOk: false,
    geraete: [],
    routerNetz: false,
    dauerMs: 0,
    abgebrochen: false,
  };
  const t0 = Date.now();

  if (!gewaehlt) {
    ergebnis.dauerMs = Date.now() - t0;
    return ergebnis;   // ohne Netzwerkkarte gibt es nichts zu suchen — diagnose.js erklaert das
  }

  const sub = opts.base ? { base: opts.base, bits: 24, begrenzt: false, hosts: 254 } : subnetOf(gewaehlt);
  if (!sub) { ergebnis.dauerMs = Date.now() - t0; return ergebnis; }
  ergebnis.netz = sub;

  const gw = gatewayIp(sub.base);
  const selbst = gewaehlt.address;
  const alle = [];
  for (let i = 1; i <= 254; i++) alle.push(sub.base + i);

  // --- Runde 1: wer antwortet ueberhaupt? (ein Anklopfen je Adresse) ---
  onProgress({ phase: 'suche', getan: 0, gesamt: alle.length, text: 'Suche Teilnehmer im Netz ' + sub.base + '1-254' });
  let getan = 0;
  const lebend = [];
  await pool(alle, async (ip) => {
    // Der eigene PC muss nicht abgeklopft werden.
    if (ip !== selbst) {
      const a = await knock(ip, DATA_PORTS[0], opts.knockMs || 350);
      let lebt = a.lebt;
      let offen = a.offen ? [DATA_PORTS[0]] : [];
      if (!lebt) {
        // Zweite Chance auf einem Port, den fast jedes Geraet belegt oder wenigstens ablehnt.
        const b = await knock(ip, 445, opts.knockMs || 350);
        lebt = b.lebt;
        if (b.offen) offen.push(445);
      }
      if (lebt) lebend.push({ ip: ip, offenePorts: offen });
    }
    getan++;
    if (getan % 16 === 0 || getan === alle.length) {
      onProgress({ phase: 'suche', getan: getan, gesamt: alle.length, text: 'Suche Teilnehmer … ' + getan + '/' + alle.length });
    }
  }, opts.concurrency || 48);

  // --- Runde 1b: still verwerfende Geraete aus der ARP-Tabelle nachtragen ---
  // Das Anklopfen hat die ARP-Aufloesung fuer JEDE Adresse erzwungen. Wer dort jetzt mit MAC
  // steht, ist da — auch wenn er auf TCP nicht geantwortet hat.
  const arpFrueh = await arpTable();
  const vorher = lebend.length;
  const alleHosts = ergaenzeAusArp(lebend, arpFrueh.map, sub.base, selbst);
  if (alleHosts.length > vorher) {
    onProgress({ phase: 'suche', getan: alle.length, gesamt: alle.length,
      text: (alleHosts.length - vorher) + ' weitere Teilnehmer aus der MAC-Tabelle nachgetragen' });
  }

  // --- Runde 2: Portscan je gefundenem Teilnehmer ---
  const scanPorts = DATA_PORTS.concat(Object.keys(FREMD_PORTS).map(Number));
  onProgress({ phase: 'ports', getan: 0, gesamt: alleHosts.length, text: alleHosts.length + ' Teilnehmer gefunden — pruefe Datenports' });
  let pGetan = 0;
  await pool(alleHosts, async (h) => {
    const offen = h.offenePorts.slice();
    await pool(scanPorts, async (p) => {
      if (offen.indexOf(p) >= 0) return;
      const r = await knock(h.ip, p, opts.portMs || 600);
      if (r.offen) offen.push(p);
    }, 8);
    h.offenePorts = offen.sort((a, b) => a - b);
    pGetan++;
    onProgress({ phase: 'ports', getan: pGetan, gesamt: alleHosts.length, text: 'Pruefe Datenports … ' + pGetan + '/' + alleHosts.length });
  }, 8);

  // --- Runde 3: MAC-Adressen nachschlagen (jetzt IST die ARP-Tabelle gefuellt) ---
  const arp = await arpTable();
  ergebnis.arpOk = arp.ok || arpFrueh.ok;

  ergebnis.hosts = alleHosts.map((h) => {
    const mac = arp.map[h.ip] || arpFrueh.map[h.ip] || null;
    const roh = { ip: h.ip, mac: mac, offenePorts: h.offenePorts, istGateway: h.ip === gw, selbst: h.ip === selbst };
    const c = classifyHost(roh);
    return Object.assign(roh, c);
  }).sort((a, b) => {
    const rang = { sicher: 0, moeglich: 1, selbst: 2, unwahrscheinlich: 3 };
    const d = (rang[a.stufe] || 9) - (rang[b.stufe] || 9);
    if (d) return d;
    return Number(a.ip.split('.')[3]) - Number(b.ip.split('.')[3]);
  });

  ergebnis.geraete = ergebnis.hosts.filter((h) => h.stufe === 'sicher');
  // Router-Netz: das Gateway antwortet UND es haengen erkennbar Fremdgeraete drin.
  ergebnis.routerNetz = ergebnis.hosts.some((h) => h.istGateway) &&
    ergebnis.hosts.filter((h) => h.stufe === 'unwahrscheinlich').length >= 2;
  ergebnis.dauerMs = Date.now() - t0;
  onProgress({ phase: 'fertig', getan: 1, gesamt: 1, text: 'Suche abgeschlossen (' + Math.round(ergebnis.dauerMs / 1000) + ' s)' });
  return ergebnis;
}

module.exports = {
  DATA_PORTS, FREMD_PORTS, OUI,
  localAdapters, subnetOf, gatewayIp, gatewayAusRoute, internetLage,
  knock, pool, arpTable, parseArpTable,
  istZufallsMac, herstellerVon, istMedizinMac, ergaenzeAusArp,
  classifyHost, scan,
};
