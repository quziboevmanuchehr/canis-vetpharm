'use strict';
/*
 * cloud-test.js — Selbsttest des FERN-LIVE Publishers (bridge/src/cloud.js) OHNE Internet.
 * Ein lokaler HTTP-Server spielt Firebase (signUp + securetoken-refresh + RTDB-PUT) nach.
 * Geprueft: Anmelde-Fluss, Snapshot-Schema, Brain-Enrichment (pri/top), Throttle,
 * Token-Refresh, Persistenz der Token-Datei.  Start: node tools/cloud-test.js
 */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { CloudPublisher, sanitizeKey } = require('../bridge/src/cloud');

let pass = 0, fail = 0;
function ok(name, cond, extra) { if (cond) { pass++; console.log('  ✓ ' + name); } else { fail++; console.log('  ✗ ' + name + (extra ? '  -> ' + extra : '')); } }
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

// ---- Mock-"Firebase" ----
// writes[] faengt PUT (Vollbild) UND PATCH (Delta) — seit 27.07.2026 schreibt der Publisher nach
// dem ersten Vollbild nur noch die geaenderten Pfade. puts[] bleibt PUT-only, damit die
// Vollbild-Pruefungen unveraendert aussagekraeftig sind.
const captured = { signups: 0, refreshes: 0, puts: [], writes: [], firestore: [], signins: [] };
const srv = http.createServer((req, res) => {
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    if (req.url.startsWith('/identity')) {
      // Praxis-Anmeldung mit E-Mail + Passwort (accounts:signInWithPassword).
      let m = null; try { m = JSON.parse(body); } catch (_) {}
      captured.signins.push(m);
      if (!m || !m.email || !m.password) { res.writeHead(400); return res.end('{"error":{"message":"MISSING_PASSWORD"}}'); }
      if (m.password !== 'geheim123') { res.writeHead(400); return res.end('{"error":{"message":"INVALID_LOGIN_CREDENTIALS"}}'); }
      captured.signups++;
      return json(res, { idToken: 'IDTOKEN_1', refreshToken: 'REFRESH_1', localId: 'UIDPRAXIS1', email: m.email, expiresIn: '3600' });
    }
    if (req.url.startsWith('/token')) {
      captured.refreshes++;
      return json(res, { id_token: 'IDTOKEN_REFRESHED', refresh_token: 'REFRESH_1', user_id: 'UIDPRAXIS1', expires_in: '3600' });
    }
    if (req.url.indexOf('/projects/') >= 0 && req.url.indexOf('/documents/') >= 0) {
      let parsed = null; try { parsed = JSON.parse(body); } catch (_) {}
      captured.firestore.push({ url: req.url, body: parsed, auth: req.headers.authorization || null });
      return json(res, { name: 'doc/1' });
    }
    if ((req.method === 'PUT' || req.method === 'PATCH') && req.url.indexOf('/live/') >= 0) {
      let parsed = null; try { parsed = JSON.parse(body); } catch (_) {}
      const w = { method: req.method, url: req.url, body: parsed };
      captured.writes.push(w);
      if (req.method === 'PUT') captured.puts.push(w);
      return json(res, parsed);
    }
    res.writeHead(404); res.end('nope');
  });
});
function json(res, o) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); }

// hr: erlaubt es, GEZIELT einen einzigen Wert zu aendern — damit laesst sich pruefen, dass das
// Delta wirklich nur den geaenderten Pfad schreibt und nicht wieder den ganzen Baum.
function samplePatients(hr, extra) {
  const p1 = { patientKey: 'sw:hund:22', patientId: 'Bello', species: 'hund', weightKg: 22, isoPct: 2.4,
    devices: [{ deviceId: 'd1', model: 'LifeVet 10C', role: 'combo' }],
    vitals: { hr: hr == null ? 38 : hr, spo2: 88, etco2: 62, af: 8, sys: 84, dia: 46, map: 59, temp: 37.1, ekgRhythm: 'sinusbrady', capnoShape: 'high', pleth: 'weak' },
    ts: 1753600000000 };
  if (extra) Object.assign(p1, extra);
  return [
    p1,
    { patientKey: 'sw:katze:4.2', patientId: 'Minka', species: 'katze', weightKg: 4.2, isoPct: 1.5,
      devices: [{ deviceId: 'd2', model: 'uMEC12 Vet', role: 'monitor' }],
      vitals: { hr: 150, spo2: 98, etco2: 40, af: 18, sys: 120, dia: 80, map: 93, temp: 38.4, ekgRhythm: 'sinus' }, ts: 1753600000000 },
  ];
}

async function run() {
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + srv.address().port;
  const authFile = path.join(os.tmpdir(), 'vetstation-cloudtest-' + Date.now() + '.json');

  console.log('FERN-LIVE Publisher-Selbsttest (Mock-Firebase auf ' + base + ')');

  const pub = new CloudPublisher({
    enabled: true, provider: 'firebase',
    apiKey: 'TEST_KEY', dbUrl: base, station: 'Test-OP',
    minIntervalMs: 800, authFile: authFile,
    identityUrl: base + '/identity', tokenUrl: base + '/token',
  }, { log: { info() {}, warn() {}, error() {} } });

  /* --- 1) OHNE Anmeldung wird NICHTS uebertragen ---------------------------------------------
   * Das ist die wichtigste Zusicherung des Umbaus vom 27.07.2026: Patientendaten verlassen den
   * Praxis-PC erst, wenn sich die Praxis angemeldet hat. Vorher hing der Zugang an einem
   * Zugangscode im Link — jeder, der ihn hatte, konnte mitlesen und sogar Werte faelschen. */
  pub.start();
  ok('ohne Anmeldung startet die Uebertragung NICHT', pub.started === false);
  ok('ohne Anmeldung gilt "nicht angemeldet"', pub.angemeldet() === false);
  pub.publish(samplePatients());
  await wait(200);
  ok('ohne Anmeldung wird NICHTS geschrieben', captured.writes.length === 0, 'writes=' + captured.writes.length);
  ok('Fern-Link enthaelt KEINEN Zugangscode mehr',
    pub.shareUrl().indexOf('live=') < 0 && pub.shareUrl().indexOf('?') < 0, pub.shareUrl());

  // --- 1b) Falsches Passwort: klare Absage, keine halbe Anmeldung ---
  let fehlerText = null;
  try { await pub.anmelden('praxis@test.de', 'falsch'); } catch (e) { fehlerText = e.message; }
  ok('falsches Passwort wird abgelehnt', !!fehlerText, fehlerText);
  ok('nach Fehlversuch weiterhin nicht angemeldet', pub.angemeldet() === false);

  // --- 2) Anmeldung + erste Veroeffentlichung ---
  const st = await pub.anmelden('praxis@test.de', 'geheim123');
  ok('Anmeldung liefert die Praxis-Kennung', st.uid === 'UIDPRAXIS1', st.uid);
  ok('Anmeldung erfolgte mit E-Mail und Passwort',
    captured.signins.some((s) => s && s.email === 'praxis@test.de' && s.password === 'geheim123' && s.returnSecureToken === true));
  ok('nach der Anmeldung laeuft die Uebertragung', pub.started === true && pub.angemeldet() === true);

  pub.publish(samplePatients());
  await waitForWrite(1);
  ok('genau 1 Schreibvorgang', captured.writes.length === 1, 'writes=' + captured.writes.length);

  const put = captured.writes[0];
  /* Der Zielpfad ist die ANMELDE-KENNUNG, nicht mehr ein frei gewaehlter Code. Genau daran haengt
   * die Mandantentrennung: die Regel vergleicht das Pfadsegment mit auth.uid. */
  ok('Zielpfad = /live/<Anmelde-Kennung>', /\/live\/UIDPRAXIS1\.json\?auth=IDTOKEN_1/.test(put.url), put.url);
  ok('geschrieben wird als PATCH (PUT wuerde das Protokoll daneben loeschen)', put.method === 'PATCH', put.method);
  const snap = put.body || {};
  ok('Snapshot hat meta + patients', !!snap.meta && !!snap.patients);
  ok('meta.count = 2', snap.meta && snap.meta.count === 2, snap.meta && snap.meta.count);
  ok('meta.station korrekt', snap.meta && snap.meta.station === 'Test-OP');
  ok('meta enthaelt KEINEN Zugangscode mehr', snap.meta && snap.meta.code === undefined, JSON.stringify(snap.meta));
  ok('Datenformat ist v3 (Praxis-Konten)', snap.meta && snap.meta.v === 3, snap.meta && snap.meta.v);

  const keyHund = sanitizeKey('sw:hund:22');
  const ph = snap.patients[keyHund];
  ok('Patient (Hund) vorhanden unter sanitisiertem Key', !!ph, keyHund);
  ok('Vitalwerte uebertragen (hr=38, etco2=62)', ph && ph.vitals.hr === 38 && ph.vitals.etco2 === 62);
  ok('MAP uebertragen (59)', ph && ph.vitals.map === 59);
  ok('EKG-Rhythmus uebertragen (sinusbrady)', ph && ph.vitals.ekgRhythm === 'sinusbrady');
  ok('isoPct uebertragen (2.4)', ph && ph.isoPct === 2.4);

  // --- 3) Brain-Enrichment ---
  ok('Brain-Prioritaet vorhanden (pri > 0)', ph && typeof ph.pri === 'number' && ph.pri > 0, ph && ph.pri);
  ok('Top-Befund vorhanden', ph && ph.top && typeof ph.top.title === 'string' && ph.top.title.length > 0, ph && ph.top && ph.top.title);
  ok('Top-Befund hat Schweregrad (sev)', ph && ph.top && ph.top.sev >= 1, ph && ph.top && ph.top.sev);

  // --- 4) Throttle: sofortiger zweiter publish darf NICHT schreiben ---
  const before = captured.writes.length;
  pub.publish(samplePatients());
  await wait(150);
  ok('Throttle: kein zweiter Schreibvorgang innerhalb minInterval', captured.writes.length === before, 'writes=' + captured.writes.length);

  // --- 5) Nach Ablauf des Intervalls mit GEAENDERTEM Wert: PATCH nur des geaenderten Pfades ---
  // Kernzusage des Umbaus vom 27.07.2026: nach dem ersten Vollbild wird nur noch das Delta
  // geschrieben. Wuerde hier wieder der ganze Baum gehen, waere der schnelle Takt unbezahlbar.
  await wait(800);
  pub.publish(samplePatients(44));
  await waitForWrite(before + 1);
  ok('nach Intervall: weiterer Schreibvorgang', captured.writes.length === before + 1, 'writes=' + captured.writes.length);
  const delta = captured.writes[captured.writes.length - 1];
  ok('Delta wird als PATCH geschrieben (nicht PUT)', delta.method === 'PATCH', delta.method);
  const dKeys = Object.keys(delta.body || {});
  ok('Delta enthaelt nur geaenderte Pfade (Vitalwerte + Herzschlag + Server-Zeitstempel)',
    dKeys.length <= 3 && dKeys.indexOf('patients/' + keyHund + '/vitals') >= 0, dKeys.join(', '));
  // Der Server-Zeitstempel ist die Grundlage der Laufzeitmessung in der Web-App. Fehlt er, zeigt
  // die Fern-Ansicht statt der echten Verzoegerung nur den Gangunterschied der beiden Uhren an.
  ok('jeder Schreibvorgang traegt den Server-Zeitstempel-Platzhalter',
    delta.body['meta/sv'] && delta.body['meta/sv']['.sv'] === 'timestamp', JSON.stringify(delta.body['meta/sv']));
  ok('Delta enthaelt NICHT den unveraenderten zweiten Patienten',
    !dKeys.some((k) => k.indexOf(sanitizeKey('sw:katze:4.2')) >= 0), dKeys.join(', '));
  ok('Delta traegt den neuen Wert (hr=44)',
    delta.body['patients/' + keyHund + '/vitals'] && delta.body['patients/' + keyHund + '/vitals'].hr === 44);
  ok('keine erneute Anmeldung (Token gueltig)', captured.signups === 1, 'signups=' + captured.signups);

  // --- 5b) Unveraenderte Daten: gar kein Schreibvorgang (ausser dem Herzschlag alle 2 s) ---
  const vorRuhe = captured.writes.length;
  await wait(800);
  pub.publish(samplePatients(44));
  await wait(200);
  ok('unveraenderte Daten -> kein Schreibvorgang', captured.writes.length === vorRuhe, 'writes=' + captured.writes.length);

  // --- 6) Token-Erneuerung: Ablauf simulieren -> securetoken, KEINE Neuanmeldung ---
  pub.tokenExp = 0; // erzwingt Erneuerung
  await wait(800);
  pub.publish(samplePatients(46));
  await waitForWrite(vorRuhe + 1);
  ok('abgelaufener Token -> Erneuerung (securetoken)', captured.refreshes === 1, 'refreshes=' + captured.refreshes);
  ok('dabei wird das Passwort NICHT erneut gebraucht', captured.signups === 1, 'signups=' + captured.signups);
  const lastWrite = captured.writes[captured.writes.length - 1];
  ok('Schreibvorgang nutzt erneuerten Token', /auth=IDTOKEN_REFRESHED/.test(lastWrite.url), lastWrite.url);
  // Frueher legte der Rueckfall bei verworfenem Token ein NEUES anonymes Konto an - unter
  // uid-gebundenen Regeln waere die Station damit still in einen fremden, leeren Pfad gewandert.
  ok('die Praxis-Kennung bleibt nach der Erneuerung DIESELBE',
    /\/live\/UIDPRAXIS1\.json/.test(lastWrite.url), lastWrite.url);

  // --- 7) Persistenz: Erneuerungs-Token ja, Passwort NIEMALS ---
  let saved = null; try { saved = JSON.parse(fs.readFileSync(authFile, 'utf8')); } catch (_) {}
  ok('Erneuerungs-Token wird gespeichert (ueberdauert Neustarts)', saved && saved.refreshToken === 'REFRESH_1', saved && saved.refreshToken);
  ok('Praxis-Kennung wird gespeichert', saved && saved.localId === 'UIDPRAXIS1', saved && saved.localId);
  ok('das PASSWORT steht NIRGENDS in der Datei',
    JSON.stringify(saved || {}).indexOf('geheim123') < 0, JSON.stringify(saved));

  // --- 8) Status: oeffentlich vs. privat ---
  const stOeff = pub.status();
  const stPriv = pub.status(true);
  ok('Status meldet angemeldet', stOeff.angemeldet === true);
  /* /api/cloud antwortet mit "Access-Control-Allow-Origin: *" - jede fremde Webseite im
   * Praxis-Browser kann das lesen. Anmeldename und Kennung duerfen dort deshalb NICHT stehen. */
  ok('oeffentlicher Status enthaelt KEINE E-Mail', stOeff.email === undefined, JSON.stringify(stOeff.email));
  ok('oeffentlicher Status enthaelt KEINE Praxis-Kennung', stOeff.uid === undefined, JSON.stringify(stOeff.uid));
  ok('privater Status enthaelt beides', stPriv.email === 'praxis@test.de' && stPriv.uid === 'UIDPRAXIS1');

  // --- 9) Abmelden: Uebertragung endet und die gespeicherte Anmeldung ist weg ---
  const vorAbmeldung = captured.writes.length;
  pub.abmelden();
  ok('nach dem Abmelden: nicht mehr angemeldet', pub.angemeldet() === false);
  ok('nach dem Abmelden: Token-Datei geloescht', !fs.existsSync(authFile));
  await wait(900);
  pub.publish(samplePatients(99));
  await wait(200);
  ok('nach dem Abmelden wird NICHTS mehr uebertragen',
    captured.writes.length === vorAbmeldung, 'writes=' + captured.writes.length);

  // --- 10) ECHTE KURVEN: kodiert, und je Streifen nur EINMAL uebertragen ---
  // Ohne die "nur bei geaenderter Signatur"-Regel wuerde ein 512-Werte-EKG in JEDEM Takt neu
  // gesendet — bei 200 ms Takt waere das Freikontingent in wenigen Tagen aufgebraucht.
  const streifen = [{ code: 'ECG_I', name: 'EKG I', hz: 256, samples: Array.from({ length: 512 }, (_, i) => Math.sin(i / 8) * 900) }];
  const pubK = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'K', minIntervalMs: 1, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.k', identityUrl: base + '/identity', tokenUrl: base + '/token' },
    { log: { info() {}, warn() {}, error() {} } });
  await pubK.anmelden('kurven@test.de', 'geheim123');
  const w0 = captured.writes.length;
  pubK.publish(samplePatients(38, { kurvenDaten: streifen }));
  await waitForWrite(w0 + 1);
  const kPut = captured.writes[w0];
  const kRec = kPut.body.patients[keyHund];
  ok('Kurven-Signatur wird uebertragen', !!kRec.kurvenSig, kRec.kurvenSig);
  ok('Kurven-Abtastwerte werden uebertragen', !!(kRec.kurven && kRec.kurven.ECG_I), Object.keys(kRec.kurven || {}).join(','));
  const kanal = kRec.kurven && kRec.kurven.ECG_I;
  ok('Kurve ist Int16+Base64 kodiert (nicht als Zahlenliste)', !!(kanal && typeof kanal.b64 === 'string' && kanal.n === 512));
  ok('Kurve ist kompakter als die JSON-Zahlenliste',
    kanal && kanal.b64.length < JSON.stringify(streifen[0].samples).length,
    kanal && (kanal.b64.length + ' vs ' + JSON.stringify(streifen[0].samples).length));
  // Dekodieren und mit dem Original vergleichen — die Kurve muss klinisch unveraendert ankommen.
  const roh = Buffer.from(kanal.b64, 'base64');
  let maxAbw = 0;
  for (let i = 0; i < 512; i++) {
    const abw = Math.abs(roh.readInt16LE(i * 2) * kanal.skala - streifen[0].samples[i]);
    if (abw > maxAbw) maxAbw = abw;
  }
  ok('dekodierte Kurve weicht < 0,1 uV ab (verlustfrei genug)', maxAbw < 0.1, 'max ' + maxAbw.toFixed(4));

  const w1 = captured.writes.length;
  await wait(140);   // > minInterval (Untergrenze 100 ms), sonst greift die Drosselung
  pubK.publish(samplePatients(39, { kurvenDaten: streifen }));   // Puls geaendert, Streifen gleich
  await waitForWrite(w1 + 1);
  const kDelta = captured.writes[w1];
  ok('unveraenderter Streifen wird NICHT erneut uebertragen',
    !Object.keys(kDelta.body).some((k) => /\/kurven$/.test(k)), Object.keys(kDelta.body).join(', '));

  /* --- 11) Stammdaten: jetzt standardmaessig AN, weil sie im EIGENEN Konto liegen ------------
   * Solange der Fern-Zugang an einem weiterleitbaren Link hing, waeren Tiername und Besitzerdaten
   * dort falsch aufgehoben gewesen. Seit die Daten ausschliesslich unter der Anmelde-Kennung der
   * eigenen Praxis liegen und nur diese Praxis sie lesen kann, gehoert der Tiername aufs
   * Protokoll — ein Narkoseprotokoll ohne Patientennamen waere als Dokument wertlos.
   * Abschaltbar bleibt es trotzdem, und das wird hier ausdruecklich geprueft. */
  ok('Stammdaten sind standardmaessig AN (eigenes Konto)', pubK.sendeStammdaten === true);
  const pubS = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'S', minIntervalMs: 1, stammdaten: false, archiv: { enabled: false },
    authFile: authFile + '.s', identityUrl: base + '/identity', tokenUrl: base + '/token' },
    { log: { info() {}, warn() {}, error() {} } });
  await pubS.anmelden('stamm@test.de', 'geheim123');
  const w2 = captured.writes.length;
  pubS.publish([Object.assign(samplePatients()[0], { patientName: 'Bello', akte: { besitzer: 'Muster' } })]);
  await waitForWrite(w2 + 1);
  const sRec = captured.writes[w2].body.patients[keyHund];
  ok('mit cloud.stammdaten=false bleibt der Tiername DRAUSSEN', !('patientName' in sRec), Object.keys(sRec).join(','));
  ok('mit cloud.stammdaten=false bleibt die Patientenakte DRAUSSEN', !('akte' in sRec));

  const w2b = captured.writes.length;
  await wait(140);
  pubK.publish([Object.assign(samplePatients()[0], { patientName: 'Bello', akte: { besitzer: 'Muster' } })]);
  await waitForWrite(w2b + 1);
  const kBody = captured.writes[w2b].body;
  const kName = kBody['patients/' + keyHund + '/patientName'];
  ok('mit der Voreinstellung wird der Tiername uebertragen', kName === 'Bello', String(kName));

  // --- 12) Firestore-Verlauf ---
  const fs0 = captured.firestore.length;
  const pubA = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'A', minIntervalMs: 1, firestoreUrl: base,
    authFile: authFile + '.a', identityUrl: base + '/identity', tokenUrl: base + '/token',
    archiv: { enabled: true, intervalMs: 5000, projectId: 'vet-station' } }, { log: { info() {}, warn() {}, error() {} } });
  await pubA.anmelden('archiv@test.de', 'geheim123');
  pubA.publish(samplePatients());
  await new Promise((resolve, reject) => {
    const t0 = Date.now();
    (function poll() {
      if (captured.firestore.length > fs0) return resolve();
      if (Date.now() - t0 > 5000) return reject(new Error('Timeout: kein Firestore-Schreibvorgang'));
      setTimeout(poll, 20);
    })();
  });
  const fdoc = captured.firestore[fs0];
  ok('Firestore-Verlauf liegt unter praxen/<Anmelde-Kennung>/verlauf',
    /\/documents\/praxen\/UIDPRAXIS1\/verlauf/.test(fdoc.url), fdoc.url);
  // Frueher genuegte der oeffentliche API-Schluessel — der steht auch in der oeffentlichen
  // Web-App, also konnte jeder Fremde Dokumente anlegen und das Kontingent ALLER Praxen sprengen.
  ok('Firestore-Verlauf wird MIT Anmeldung geschrieben (Bearer-Kopfzeile)',
    fdoc.auth === 'Bearer IDTOKEN_1', String(fdoc.auth));
  ok('Firestore-Verlauf: Station + Patientenzahl als eigene Felder',
    fdoc.body.fields.station.stringValue === 'A' && fdoc.body.fields.patienten.integerValue === '2');
  ok('Firestore-Verlauf traegt KEINEN Zugangscode mehr', fdoc.body.fields.code === undefined);
  const archDaten = JSON.parse(fdoc.body.fields.daten.stringValue);
  ok('Firestore-Verlauf: Vitalwerte im Datensatz', archDaten.patients[keyHund].vitals.hr === 38);
  ok('Firestore-Verlauf: Kurven NICHT im Archiv (Dokumentgroesse)', !archDaten.patients[keyHund].kurven);

  // --- 13) OP-Protokoll wird als EINZELNE, unveraenderliche Pfade uebertragen ---
  const w3 = captured.writes.length;
  await wait(140);
  pubK.publish(samplePatients(41), [], { 'Bello': [{ ts: 1753600001000, hr: 41, finding: 'Bradykardie' }] });
  await waitForWrite(w3 + 1);
  const pBody = captured.writes[w3].body;
  ok('Protokolleintrag geht als eigener Pfad protokoll/<Patient>/<Zeitpunkt>',
    !!pBody['protokoll/Bello/1753600001000'], Object.keys(pBody).join(', '));
  ok('Protokolleintrag traegt die Werte', pBody['protokoll/Bello/1753600001000'].hr === 41);
  // Ein zweites Mal derselbe Eintrag darf NICHT erneut uebertragen werden - sonst wuechse die
  // Datenmenge mit jedem Takt, und die Regel ".validate: !data.exists()" wuerde ihn ablehnen.
  const w4 = captured.writes.length;
  await wait(140);
  pubK.publish(samplePatients(42), [], { 'Bello': [{ ts: 1753600001000, hr: 41, finding: 'Bradykardie' }] });
  await waitForWrite(w4 + 1);
  ok('bereits gesendeter Protokolleintrag wird NICHT wiederholt',
    !Object.keys(captured.writes[w4].body).some((k) => k.indexOf('protokoll/') === 0),
    Object.keys(captured.writes[w4].body).join(', '));

  // --- 14) Sicherheits-Vollbild ---
  ok('Vollbild-Intervall gesetzt (raeumt verlorene Deltas auf)', pub.vollbildMs >= 5000, String(pub.vollbildMs));

  try { fs.unlinkSync(authFile); } catch (_) {}
  srv.close();
  console.log('\nErgebnis: ' + pass + ' OK, ' + fail + ' Fehler.');
  process.exit(fail ? 1 : 0);

  function waitForPut(n) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      (function poll() {
        if (captured.puts.length >= n) return resolve();
        if (Date.now() - t0 > 5000) return reject(new Error('Timeout: erwartet >=' + n + ' PUTs, hatte ' + captured.puts.length));
        setTimeout(poll, 20);
      })();
    });
  }
  function waitForWrite(n) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      (function poll() {
        if (captured.writes.length >= n) return resolve();
        if (Date.now() - t0 > 5000) return reject(new Error('Timeout: erwartet >=' + n + ' Schreibvorgaenge, hatte ' + captured.writes.length));
        setTimeout(poll, 20);
      })();
    });
  }
}

run().catch(e => { console.error('TESTFEHLER:', e); try { srv.close(); } catch (_) {} process.exit(1); });
