'use strict';
/*
 * index.js — Einstieg der Acquisition-Bridge (Schicht 1) + UI-Server (Schicht 2/3).
 * Laedt die Geraete-Konfiguration, startet die Adapter (Simulator by default) und den Server.
 * STRIKT READ-ONLY gegenueber allen Geraeten.
 */
const path = require('path');
const fs = require('fs');
const logger = require('./logger');
const { Registry } = require('./registry');
const { SimulatorAdapter } = require('./adapters/simulator');
const { PlaybackAdapter } = require('./adapters/playback');
const { MindrayAdapter } = require('./adapters/mindray');
const { LifeVetAdapter } = require('./adapters/lifevet');
const { HL7Adapter } = require('./adapters/hl7');
const { ProbeAdapter } = require('./adapters/probe');
const { VSCaptureAdapter } = require('./adapters/vscapture');
const { startServer } = require('./server');
const { CloudPublisher } = require('./cloud');
// EINE Quelle der Wahrheit: die Wurzel-package.json. Frueher stand hier '../package.json' —
// das ist bridge/package.json und meldete dauerhaft 0.1.0 (Befund 2.4).
const { appVersion, pruefe: pruefeVersion } = require('./version');

const ADAPTERS = {
  simulator: SimulatorAdapter,
  playback: PlaybackAdapter,
  hl7: HL7Adapter,           // Mindray HL7/PDS (falls das Geraet HL7 sendet), PC=Listener
  probe: ProbeAdapter,       // Verbindungs-Assistent: Auto-Erkennung HL7 + Rohdaten + ARP
  vscapture: VSCaptureAdapter, // Fallback: tailt die Live-CSV von VSCapture (das spricht Mindray)
  mindray: MindrayAdapter,
  lifevet: LifeVetAdapter,
};

function loadConfig() {
  const custom = path.join(__dirname, '..', 'config', 'devices.json');
  const example = path.join(__dirname, '..', 'config', 'devices.example.json');
  const file = fs.existsSync(custom) ? custom : example;
  try {
    const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
    logger.info('config', 'Konfiguration: ' + path.basename(file));
    return cfg;
  } catch (e) {
    logger.error('config', 'Konfiguration nicht lesbar (' + e.message + ') -> Simulator-Fallback.');
    return { adapters: [{ type: 'simulator', id: 'sim' }] };
  }
}

function main() {
  const cfg = loadConfig();
  const port = Number(process.env.PORT) || cfg.port || 8770;
  const host = cfg.host || '127.0.0.1';

  const registry = new Registry({ log: logger });
  const ctx = { emit: (raw) => registry.ingest(raw), log: logger };

  const list = (cfg.adapters || []).filter((a) => a.enabled !== false);
  // TEST-MODUS: nur wenn ausdruecklich gewuenscht (START-TESTMODUS.bat) wird der Simulator zugeschaltet.
  // Standard = ECHTE Geraete (keine Simulation).
  if (process.env.VETSTATION_SIM === '1' && !list.some((a) => a.type === 'simulator')) {
    list.push({ type: 'simulator', id: 'sim-test' });
    logger.info('config', 'TEST-MODUS aktiv: Simulator zugeschaltet (VETSTATION_SIM=1).');
  }
  if (!list.length) logger.warn('config', 'Keine aktiven Adapter — warte auf echte Geraete (Verbindungs-Assistent). Fuer Demo: START-TESTMODUS.bat.');
  list.forEach((a) => {
    const Cls = ADAPTERS[a.type];
    if (!Cls) { logger.warn('config', 'Unbekannter Adapter-Typ: ' + a.type); return; }
    registry.addAdapter(new Cls(a, ctx));
    logger.info('config', 'Adapter geladen: ' + a.type + ' [' + (a.id || '?') + ']');
  });

  // FERN-LIVE: optionaler Cloud-Publisher (schreibt Live-Daten ins Internet fuer die Web-App).
  const cloud = new CloudPublisher(cfg.cloud || {}, { log: logger });
  cloud.start();

  const v = pruefeVersion();
  if (!v.stimmig) {
    logger.warn('version', 'Versionsnummern weichen ab: ' +
      v.abweichungen.map((a) => a.datei + '=' + a.wert).join(', ') + ' — massgeblich ist ' + v.version + '.');
  }
  const server = startServer({ port, host, registry, version: appVersion(), cloud });
  registry.start();
  selbsttestBeimStart();

  const shutdown = () => { logger.info('bridge', 'Beende VetStation-Bridge...'); cloud.stop(); registry.dispose(); server.stop(); process.exit(0); };

  /*
   * SELBSTTEST BEIM START — sagt SOFORT, was im Weg steht.
   *
   * Kernbefund 21.07.2026: Empfang und Auswertung funktionierten; was fehlte, war jede Information
   * darueber, WARUM nichts ankommt. Deshalb prueft die Station jetzt beim Hochfahren von selbst
   * die beiden Dinge, die man NICHT sehen kann: die eigene Netzadresse und die Firewall.
   * Bewusst KEIN voller Netzwerkscan beim Start — der dauert eine Minute und wuerde den Start
   * verzoegern. Den startet der Anwender mit einem Klick (Admin -> Netzwerk & Geraete).
   */
  function selbsttestBeimStart() {
    const netscan = require('./netscan');
    const firewall = require('./firewall');
    const { ZIEL } = require('./diagnose');

    const karten = netscan.localAdapters();
    const echte = karten.filter((k) => !k.virtuell);
    if (!echte.length) {
      logger.warn('selbsttest', 'Dieser PC hat KEINE echte Netzwerkkarte (nur virtuell/VPN oder gar keine). ' +
        'Es kann kein Geraet Daten liefern — LAN-Kabel pruefen.');
    } else {
      const meine = echte.map((k) => k.address).join(', ');
      if (echte.some((k) => k.address === ZIEL.ip)) {
        logger.info('selbsttest', 'PC-Adresse ' + ZIEL.ip + ' — genau das Ziel, das im Monitor eingetragen ist. Passt.');
      } else if (echte.some((k) => k.address.indexOf(ZIEL.netz) === 0)) {
        logger.warn('selbsttest', 'PC-Adresse ist ' + meine + ', der Monitor sendet aber an ' + ZIEL.ip + ':' + ZIEL.port +
          '. Entweder NETZWERK-EINRICHTEN.bat doppelklicken oder am Monitor das Ziel auf ' + meine + ' aendern.');
      } else {
        logger.warn('selbsttest', 'PC-Adresse ist ' + meine + ' — das ist NICHT das Netz ' + ZIEL.netz + 'x, ' +
          'in das der Monitor sendet. Zwei verschiedene Netze sehen einander nicht. NETZWERK-EINRICHTEN.bat doppelklicken.');
      }
    }

    /*
     * Kommt dieser PC ueberhaupt ins Internet? (Befund 22.07.2026)
     * Die feste IP wird laut Anleitung OHNE Gateway gesetzt — richtig fuer ein isoliertes
     * Geraetenetz. Haengt der PC aber ueber einen Verstaerker/Switch am Praxis- oder Hausnetz,
     * sind damit Update, Fern-Live und die klinischen Daten still tot, waehrend die
     * Geraeteverbindung voellig in Ordnung ist. Beides sauber trennen statt raten.
     */
    netscan.gatewayAusRoute().then((gw) => {
      if (gw) return;
      // KEIN IPv4-Gateway. Das heisst NICHT automatisch "kein Internet": am Praxis-PC lief alles
      // ueber IPv6 weiter (Router Advertisement des Kabelrouters). Deshalb erst messen, dann reden.
      return netscan.internetLage().then((inet) => {
        if (inet.nurV6) {
          logger.info('selbsttest', 'Kein IPv4-Gateway, aber IPv6 ist vollstaendig verbunden — Update und ' +
            'klinische Daten laufen darueber. Fragil: Dienste ohne IPv6-Adresse sind unerreichbar. ' +
            'Beide Beine: INTERNET-EINRICHTEN.bat doppelklicken (aendert die feste IP NICHT).');
        } else if (!inet.erreichbar) {
          logger.warn('selbsttest', 'Kein Weg ins Internet (weder IPv4 noch IPv6) — Geraetedaten funktionieren ' +
            'trotzdem (gleiches Netz), aber Update, Fern-Live und die klinischen Daten koennen NICHT laden. ' +
            'Haengt der PC am Praxis-/Hausnetz: INTERNET-EINRICHTEN.bat doppelklicken. Im isolierten ' +
            'Geraetenetz ist das so gewollt.');
        }
      });
    }).catch(() => {});

    firewall.pruefe().then((fw) => {
      if (!fw.lesbar) {
        logger.warn('selbsttest', 'Firewall-Zustand nicht lesbar. Das heisst NICHT "in Ordnung" — im Zweifel FIREWALL-FREIGEBEN.bat doppelklicken.');
      } else if (fw.fehlend.length) {
        logger.warn('selbsttest', 'WINDOWS-FIREWALL BLOCKIERT Port ' + fw.fehlend.join(', ') + '. ' +
          'Ankommende Vitaldaten werden LAUTLOS verworfen — das Geraet meldet "sendet", hier kommt nichts an. ' +
          'Beheben: FIREWALL-FREIGEBEN.bat doppelklicken.');
      } else {
        logger.info('selbsttest', 'Windows-Firewall: alle Geraeteports freigegeben' +
          (fw.doppelt.length ? ' (aber doppelte Altregeln auf Port ' + fw.doppelt.map((d) => d.port).join(', ') + ' — FIREWALL-FREIGEBEN.bat raeumt auf)' : '') + '.');
      }
    }).catch((e) => logger.warn('selbsttest', 'Firewall-Pruefung fehlgeschlagen: ' + e.message));
  }

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main();
