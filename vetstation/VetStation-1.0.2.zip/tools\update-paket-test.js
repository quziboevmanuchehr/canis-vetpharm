'use strict';
/*
 * update-paket-test.js — prueft das AUSGELIEFERTE Update-Paket dist/VetStation-<version>.zip.
 *
 * WARUM (Befund 21.07.2026): Bei 0.6.0 gab es zuerst eine neue Setup.exe, aber KEIN Update-Paket.
 * Eine bereits laufende Praxis-Station haette also gar nicht nachziehen koennen — der einzige
 * Weg ohne USB-Stick war tot, ohne dass es jemandem aufgefallen waere.
 * Zweite Gefahr: geraet node\ mit hinein, wird aus 0,7 MB ein 27-MB-Download (die Praxis haengt
 * an einer normalen Leitung); geraet data\ hinein, ueberschreibt das Update die Betriebsdaten.
 *
 * Das Paket entsteht erst beim Bauen (SETUP-BAUEN.bat). Ist keins da, wird das ehrlich als
 * UEBERSPRUNGEN gemeldet — nicht als Fehler und erst recht nicht als "in Ordnung".
 *
 * Start: node tools/update-paket-test.js      (laeuft auch in `npm test`)
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0, skip = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function uebersprungen(n, grund) { skip++; console.log('  ○ ' + n + '  (uebersprungen: ' + grund + ')'); }

// Eintragsnamen direkt aus dem zentralen ZIP-Verzeichnis lesen (keine Fremdbibliothek noetig).
const SIG = Buffer.from([0x50, 0x4b, 0x01, 0x02]);
function zipEintraege(datei) {
  const b = fs.readFileSync(datei);
  const out = [];
  let i = 0;
  while ((i = b.indexOf(SIG, i)) >= 0) {
    const len = b.readUInt16LE(i + 28);
    // Windows-PowerShell schreibt Backslash-Pfade in die ZIP (nicht normgerecht, aber
    // Expand-Archive liest sie - so sind ALLE bisherigen Releases gebaut). Deshalb normalisieren.
    out.push(b.slice(i + 46, i + 46 + len).toString('utf8').split('\\').join('/'));
    i += 46 + len;
  }
  return out;
}

console.log('VetStation — ausgeliefertes Update-Paket\n');

const version = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const zipPfad = path.join(ROOT, 'dist', 'VetStation-' + version + '.zip');
console.log('  Erwartet: dist/VetStation-' + version + '.zip\n');

if (!fs.existsSync(zipPfad)) {
  uebersprungen('Update-Paket vorhanden', 'noch nicht gebaut — SETUP-BAUEN.bat doppelklicken');
  console.log('\n' + pass + ' bestanden, ' + fail + ' fehlgeschlagen, ' + skip + ' uebersprungen');
  process.exit(0);
}

const eintraege = zipEintraege(zipPfad);
const groesse = fs.statSync(zipPfad).size;
ok('Update-Paket ist vorhanden und nicht leer', eintraege.length > 50, eintraege.length + ' Eintraege');

// Die teuerste Verwechslung: node\ mit eingepackt -> 27 MB statt 0,7 MB.
console.log('\nGroesse und Ausschluesse:');
ok('node\\ ist NICHT enthalten (sonst 27 MB statt 0,7 MB)',
  eintraege.filter((x) => x.indexOf('node/') === 0).length === 0);
ok('data\\ ist NICHT enthalten (Betriebsdaten des Kunden)',
  eintraege.filter((x) => x.indexOf('data/') === 0).length === 0);
/*
 * ...UND AUCH NICHT TIEFER IM BAUM (Befund 27.07.2026).
 * Die Pruefung oben sah nur den obersten Ordner. bridge/data/ rutschte deshalb unbemerkt mit ins
 * Paket - und dort liegen patient-akte.json und protokoll.json, also PATIENTENDATEN. Das Paket
 * wird auf einer oeffentlichen Webseite veroeffentlicht; auf einem Rechner, der die echte Station
 * betrieben hat, waeren das echte Patientenakten gewesen. Deshalb jetzt: KEIN data-Ordner,
 * egal auf welcher Ebene.
 */
const datenReste = eintraege.filter((x) => /(^|\/)data\//.test(x));
ok('auch kein data-Ordner TIEFER im Baum (z. B. bridge/data mit Patientenakten)',
  datenReste.length === 0, datenReste.slice(0, 5).join(', '));
ok('keine Patientenakte im Paket', !eintraege.some((x) => /patient-akte\.json$/.test(x)));
ok('kein Protokoll im Paket', !eintraege.some((x) => /protokoll\.json$/.test(x)));
/*
 * KEINE .git-RESTE (Befund 27.07.2026, echter Ausfall beim Kunden-Update).
 * In einem Git-Arbeitsbaum ist ".git" eine DATEI mit einem Zeiger, kein Ordner — robocopy /XD
 * hat sie deshalb nicht ausgeschlossen. Auf der Station hielt der Updater die Installation
 * daraufhin fuer ein Git-Checkout und rief "git pull" auf; der Tierarzt sah nur
 * "fatal: not a git repository: (NULL)" und konnte gar nicht mehr aktualisieren.
 */
ok('kein .git-Rest im Paket (sonst versucht der Updater "git pull")',
  !eintraege.some((x) => /(^|\/)\.git($|\/)/.test(x)),
  eintraege.filter((x) => /(^|\/)\.git($|\/)/.test(x)).join(', '));
ok('.git\\ ist NICHT enthalten', eintraege.filter((x) => x.indexOf('.git/') === 0).length === 0);
ok('Paket bleibt unter 5 MB (Praxis haengt an einer normalen Leitung)', groesse < 5 * 1024 * 1024,
  Math.round(groesse / 1024) + ' KB');

// Was drin sein MUSS, damit die aktualisierte Station auch wirklich die neue Fassung ist.
console.log('\nProgrammdateien im Paket:');
[
  'package.json',
  'bridge/src/index.js', 'bridge/src/server.js', 'bridge/src/logger.js',
  'bridge/src/netscan.js', 'bridge/src/diagnose.js', 'bridge/src/firewall.js', 'bridge/src/version.js',
  'bridge/src/adapters/hl7.js', 'bridge/src/adapters/probe.js',
  'ui/views/admin.js', 'ui/vetstation-live.js', 'ui/index.html',
  'updater/version.json', 'updater/updater.js',
  'kiosk/launch-kiosk.ps1', 'kiosk/stop-kiosk.ps1',
  'installer/set-firewall.ps1', 'installer/Install-VetStation.ps1',
  'tools/alle-tests.js', 'tools/geraete-check.js',
  'INSTALLIEREN.bat', 'NEUSTART.bat', 'FIREWALL-FREIGEBEN.bat', 'GERAETE-PRUEFEN.bat',
].forEach((f) => ok('enthaelt ' + f, eintraege.indexOf(f) >= 0));

// Die Version im Paket muss zu seinem Dateinamen passen — sonst meldet die Station nach dem
// Update eine andere Nummer als die, die geladen wurde (genau der Fehler aus Befund 2.4).
console.log('\nVersion im Paket:');
ok('der Dateiname nennt die Version aus der Wurzel-package.json', /VetStation-\d+\.\d+\.\d+\.zip$/.test(zipPfad));
ok('updater/version.json liegt bei (Station kennt danach ihre neue Nummer)',
  eintraege.indexOf('updater/version.json') >= 0);

console.log('\n' + (fail === 0
  ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' + (skip ? ' (' + skip + ' uebersprungen)' : '')
  : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
