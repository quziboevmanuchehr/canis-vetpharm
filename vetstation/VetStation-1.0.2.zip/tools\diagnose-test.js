'use strict';
/*
 * diagnose-test.js — "Die App muss SAGEN, wo das Problem liegen kann."
 *
 * Kernbefund 21.07.2026: "Die App war nicht schuld, dass keine Werte ankamen — aber sie hat es
 * VERSCHWIEGEN." Empfang und Auswertung funktionierten nachweislich; es fehlte jede brauchbare
 * Information darueber, WARUM nichts ankommt. Der Anwender suchte am falschen Ende.
 *
 * Dieser Test haelt die Diagnose ehrlich: sie muss die richtige Ursache OBEN nennen, jede
 * Aussage begruenden, einen konkreten naechsten Schritt liefern — und nie "in Ordnung"
 * behaupten, wo sie nichts geprueft hat.
 *
 * Start: node tools/diagnose-test.js      (laeuft auch in `npm test`)
 */
const { diagnose } = require('../bridge/src/diagnose');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

const KARTE = (ip) => ({ name: 'Ethernet', address: ip, netmask: '255.255.255.0', virtuell: false });
const FW_OK = { lesbar: true, ports: [], fehlend: [], doppelt: [], unklar: [] };
const STILL = { aktiv: false, geraete: 0, letzteDatenVorMs: null };
const LAEUFT = { aktiv: true, geraete: 1, letzteDatenVorMs: 900 };

function lage(o) { return diagnose(o); }
function codes(r) { return r.befunde.map((b) => b.code); }
function oben(r) { return r.befunde.filter((b) => b.code !== 'EMPFANG_OK')[0] || {}; }

console.log('VetStation — Diagnose sagt, wo das Problem liegt\n');

/* ---------------- 1) Ungeprueft heisst ungeprueft ---------------- */
console.log('Ehrlichkeit:');
const leer = lage({});
ok('ohne Suchlauf lautet das Urteil "unklar", nicht "ok"', leer.urteil === 'unklar', leer.urteil);
ok('und sagt das auch', /Noch nicht geprueft/.test(leer.kurz), leer.kurz);
ok('ohne Firewall-Pruefung wird das als ungeprueft gemeldet, nicht als "in Ordnung"',
  codes(leer).indexOf('FIREWALL_UNGEPRUEFT') >= 0, codes(leer).join(','));

/* ---------------- 2) Der PC selbst ---------------- */
console.log('\nDer PC:');
const keinNetz = lage({ scan: { adapters: [], hosts: [], netz: null }, firewall: FW_OK, empfang: STILL });
ok('gar keine Netzwerkkarte -> das steht ganz oben', oben(keinNetz).code === 'KEIN_NETZ', oben(keinNetz).code);
ok('und es wird als blockierend eingestuft', oben(keinNetz).schwere === 3);
ok('mit konkretem naechsten Schritt (Kabel)', /Kabel/.test(oben(keinNetz).tun.join(' ')));

const nurVpn = lage({
  scan: { adapters: [{ name: 'Radmin VPN', address: '26.1.1.1', netmask: '255.0.0.0', virtuell: true }], hosts: [], netz: null },
  firewall: FW_OK, empfang: STILL,
});
ok('nur VPN-Karte -> eigener Befund', oben(nurVpn).code === 'NUR_VIRTUELL', oben(nurVpn).code);

const falschesNetz = lage({
  scan: { adapters: [KARTE('10.0.0.5')], hosts: [], netz: { base: '10.0.0.' } }, firewall: FW_OK, empfang: STILL,
});
ok('PC im falschen Netz -> FALSCHES_NETZ', codes(falschesNetz).indexOf('FALSCHES_NETZ') >= 0);
ok('nennt NETZWERK-EINRICHTEN.bat als Loesung',
  /NETZWERK-EINRICHTEN\.bat/.test(JSON.stringify(falschesNetz.befunde)));

const andereIp = lage({
  scan: { adapters: [KARTE('192.168.0.233')], hosts: [{ ip: '192.168.0.50', stufe: 'sicher', datenPorts: [3502], gruende: [] }], netz: { base: '192.168.0.' } },
  firewall: FW_OK, empfang: STILL,
});
ok('richtiges Netz, falsche Adresse -> ANDERE_PC_IP', codes(andereIp).indexOf('ANDERE_PC_IP') >= 0, codes(andereIp).join(','));
ok('erklaert, dass niemand an der Zieladresse zuhoert',
  /niemand zuhoert/.test(andereIp.befunde.find((b) => b.code === 'ANDERE_PC_IP').warum));

// Am Praxisnetz gemessen: .99 antwortete, obwohl der PC .233 hatte.
const zielBesetzt = lage({
  scan: {
    adapters: [KARTE('192.168.0.233')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.99', stufe: 'moeglich', mac: 'aabbccddeeff', datenPorts: [], gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL,
});
ok('belegte Zieladresse wird erkannt', codes(zielBesetzt).indexOf('ZIEL_IP_BESETZT') >= 0, codes(zielBesetzt).join(','));
ok('warnt VOR dem Adresskonflikt, statt ihn entstehen zu lassen',
  /Adresskonflikt/.test(zielBesetzt.befunde.find((x) => x.code === 'ZIEL_IP_BESETZT').warum));
const zielIstIch = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.99', stufe: 'selbst', selbst: true, datenPorts: [], gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL,
});
ok('der eigene PC auf der Zieladresse ist KEIN Konflikt', codes(zielIstIch).indexOf('ZIEL_IP_BESETZT') < 0);

/* ---------------- 3) Kein Geraet ---------------- */
console.log('\nGeraetesuche:');
const niemand = lage({
  scan: { adapters: [KARTE('192.168.0.99')], hosts: [], netz: { base: '192.168.0.' } }, firewall: FW_OK, empfang: STILL,
});
ok('kein einziger Teilnehmer -> NIEMAND_IM_NETZ', codes(niemand).indexOf('NIEMAND_IM_NETZ') >= 0);
ok('fragt zuerst nach dem Offensichtlichen (Geraet ein? Kabel?)',
  /eingeschaltet/.test(niemand.befunde.find((b) => b.code === 'NIEMAND_IM_NETZ').tun.join(' ')));
ok('nennt das Monitor-Menue mit Passwort', /888888/.test(JSON.stringify(niemand.befunde)));

// Genau die Lage vom 21.07.2026: 12 Teilnehmer, KEINER ein Medizingeraet.
const nurBuero = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, routerNetz: true,
    hosts: [
      { ip: '192.168.0.1', stufe: 'unwahrscheinlich', istGateway: true, gruende: ['Router'] },
      { ip: '192.168.0.104', stufe: 'unwahrscheinlich', gruende: ['Drucker'] },
      { ip: '192.168.0.233', stufe: 'unwahrscheinlich', gruende: ['Windows-PC'] },
    ],
  },
  firewall: FW_OK, empfang: STILL,
});
ok('Teilnehmer da, aber kein Medizingeraet -> KEIN_GERAET', codes(nurBuero).indexOf('KEIN_GERAET') >= 0, codes(nurBuero).join(','));
ok('Router-Netz wird zusaetzlich gemeldet', codes(nurBuero).indexOf('ROUTER_NETZ') >= 0);
ok('und warnt vor der DHCP-Adresskollision',
  /DHCP/.test(nurBuero.befunde.find((b) => b.code === 'ROUTER_NETZ').warum));

/* ---------------- 4) Geraet da, aber still ---------------- */
console.log('\nGeraet gefunden, es kommt trotzdem nichts:');
const stumm = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.50', stufe: 'sicher', datenPorts: [], mac: '98cce4aabbcc', gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL,
});
ok('Medizin-MAC ohne Datenport -> GERAET_GEFUNDEN_STILL', codes(stumm).indexOf('GERAET_GEFUNDEN_STILL') >= 0, codes(stumm).join(','));
// KORREKTUR 22.07.2026: frueher hiess es "Das Geraet misst, sendet aber nicht" - falsch geschlossen.
// Ein sendendes Geraet oeffnet gar keinen Port; es ruft den PC an. Die Diagnose darf daraus also
// NICHT auf einen abgeschalteten Datenausgang schliessen.
const still = stumm.befunde.find((x) => x.code === 'GERAET_GEFUNDEN_STILL');
ok('sie behauptet NICHT mehr, das Geraet sende nicht', !/sendet aber nicht/.test(still.warum));
ok('sie erklaert, dass ein sendendes Geraet gar nicht lauscht', /lauscht nicht|ruft den PC an/.test(still.warum));
ok('sie nennt die ADRESSE DIESES PCs als einzutragendes Ziel', /192\.168\.0\.99/.test(JSON.stringify(still.tun)));
ok('sie nennt den Menueweg beim LifeVet', /HL7-Konfiguration/.test(JSON.stringify(still.tun)));
ok('sie warnt vor dem traegen Datenintervall', /Datenintervall/.test(JSON.stringify(still.tun)));
ok('nennt "CMS auswaehlen" — die letzte offene Stellschraube am Geraet',
  /CMS auswaehlen/.test(JSON.stringify(stumm.befunde)));
ok('nennt "Real Data Send"', /Real Data Send/.test(JSON.stringify(stumm.befunde)));

const offenAberStill = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.50', stufe: 'sicher', datenPorts: [3502], gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL,
});
ok('Datenport offen, aber keine Werte -> GERAET_OK_ABER_STILL',
  codes(offenAberStill).indexOf('GERAET_OK_ABER_STILL') >= 0, codes(offenAberStill).join(','));

/* ---------------- 4c) Die echte Praxislage vom 22.07.2026 ---------------- */
console.log('\nDie tatsaechliche Praxislage (Fotos + Check vom 22.07.2026):');
// LifeVet 10C stand auf 192.168.0.1 = Router-Adresse -> Geraet meldete selbst
// "LAN1-IP-Adressenkonflikt" und war fuer die Suche zeitweise unsichtbar.
const praxis = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, routerNetz: false,
    hosts: [
      { ip: '192.168.0.1', istGateway: true, mac: '000f14aabbcc', stufe: 'sicher', datenPorts: [], gruende: [] },
      { ip: '192.168.0.50', mac: '98cce4042d00', stufe: 'sicher', datenPorts: [4601], gruende: [] },
    ],
  },
  firewall: FW_OK, empfang: STILL,
  proprietaer: [{ ip: '192.168.0.50', port: 4601 }],
});
ok('Geraet auf der Router-Adresse wird erkannt', codes(praxis).indexOf('GERAET_AUF_GATEWAY') >= 0, codes(praxis).join(','));
ok('das steht GANZ OBEN (es macht das Geraet unsichtbar)', oben(praxis).code === 'GERAET_AUF_GATEWAY', oben(praxis).code);
ok('es nennt den Menueweg am LifeVet', /Wartung -> Netzwerk-Setup -> LAN1/.test(JSON.stringify(praxis.befunde)));
ok('"antwortet, aber kein HL7" wird als eigener Befund gemeldet',
  codes(praxis).indexOf('GERAET_SPRICHT_ANDERS') >= 0);
const anders = praxis.befunde.find((x) => x.code === 'GERAET_SPRICHT_ANDERS');
ok('er nennt MD2 als wahrscheinliches Protokoll', /MD2/.test(anders.warum));
ok('er stellt klar, dass die Leitung in Ordnung ist', /Netzverbindung ist also in Ordnung/.test(anders.warum));
ok('er bietet den VSCapture-Fallback mit vollem Pfad an',
  /C:\\\\VetStation\\\\installer\\\\setup-vscapture-fallback\.ps1/.test(JSON.stringify(anders.tun)));
// Ein Buero-PC auf der Gateway-Adresse ist KEIN Medizingeraet -> kein Fehlalarm.
const routerNormal = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.1', istGateway: true, mac: 'a42bb0112233', stufe: 'unwahrscheinlich', datenPorts: [], gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL,
});
ok('ein normaler Router loest KEINEN Fehlalarm aus', codes(routerNormal).indexOf('GERAET_AUF_GATEWAY') < 0);

/* ---------------- 4d) Zweite VetStation im Netz ---------------- */
// Beobachtet 22.07.2026: ein zweiter PC antwortete auf alle sechs Datenports. Das erklaert eine
// haeufige Verwirrung - ein Geraet sendet nur an EINE eingetragene Adresse.
console.log('\nZweite VetStation im Netz:');
const zwei = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [
      { ip: '192.168.0.51', mac: '000f142b1052', stufe: 'sicher', datenPorts: [], gruende: [] },
      { ip: '192.168.0.233', stufe: 'unwahrscheinlich', zweiteStation: true, datenPorts: [3502, 4601, 8830, 5000], gruende: [] },
    ],
  },
  firewall: FW_OK, empfang: STILL,
});
ok('die zweite Station wird gemeldet', codes(zwei).indexOf('ZWEITE_STATION') >= 0, codes(zwei).join(','));
const zs = zwei.befunde.find((x) => x.code === 'ZWEITE_STATION');
ok('erklaert, dass ein Geraet nur an EINE Adresse sendet', /nur an die EINE/.test(zs.warum));
ok('nennt beide Adressen zum Vergleich', /192\.168\.0\.99/.test(zs.warum) && /192\.168\.0\.233/.test(zs.warum));
ok('ist eine Warnung, kein Blocker', zs.schwere === 2);
// Kommen Werte an, ist die zweite Station kein Thema mehr.
const zweiOk = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.233', stufe: 'unwahrscheinlich', zweiteStation: true, datenPorts: [3502, 4601, 8830, 5000], gruende: [] }],
  },
  firewall: FW_OK, empfang: LAEUFT,
});
ok('bei ankommenden Werten wird nicht mehr gewarnt', codes(zweiOk).indexOf('ZWEITE_STATION') < 0);

/* ---------------- 5) Firewall ---------------- */
console.log('\nFirewall (der lautlose Killer):');
const fwFehlt = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [{ ip: '192.168.0.50', stufe: 'sicher', datenPorts: [3502], gruende: [] }] },
  firewall: { lesbar: true, ports: [], fehlend: [3502], doppelt: [], unklar: [] }, empfang: STILL,
});
ok('fehlende Freigabe -> FIREWALL_FEHLT', codes(fwFehlt).indexOf('FIREWALL_FEHLT') >= 0);
ok('erklaert das LAUTLOSE Verwerfen', /LAUTLOS/.test(fwFehlt.befunde.find((b) => b.code === 'FIREWALL_FEHLT').warum));
ok('nennt FIREWALL-FREIGEBEN.bat', /FIREWALL-FREIGEBEN\.bat/.test(JSON.stringify(fwFehlt.befunde)));
ok('gilt als blockierend', fwFehlt.befunde.find((b) => b.code === 'FIREWALL_FEHLT').schwere === 3);

const fwDoppelt = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [] },
  firewall: { lesbar: true, ports: [], fehlend: [], doppelt: [{ port: 3502, anzahl: 2 }], unklar: [] }, empfang: LAEUFT,
});
ok('doppelte Regeln -> nur Hinweis, kein Alarm',
  fwDoppelt.befunde.find((b) => b.code === 'FIREWALL_DOPPELT').schwere === 1);

const fwUnklar = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [] },
  firewall: { lesbar: false, ports: [], fehlend: [], doppelt: [], unklar: [3502] }, empfang: LAEUFT,
});
const u = fwUnklar.befunde.find((b) => b.code === 'FIREWALL_UNKLAR');
ok('unlesbarer Zustand wird als "unklar" gemeldet', !!u);
ok('und ausdruecklich NICHT als "in Ordnung"', /NICHT "in Ordnung"/.test(u.warum), u.warum);

/* ---------------- 6) Fremdbelegter Port + Fern-Live ---------------- */
console.log('\nWeitere Ursachen:');
const belegt = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [] },
  firewall: FW_OK, empfang: STILL, fremdBelegt: [3502],
});
ok('fremd belegter Datenport wird gemeldet', codes(belegt).indexOf('PORT_FREMD_BELEGT') >= 0);
ok('nennt NEUSTART.bat als Loesung', /NEUSTART\.bat/.test(JSON.stringify(belegt.befunde)));

const fern = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [{ ip: '192.168.0.50', stufe: 'sicher', datenPorts: [3502], gruende: [] }] },
  firewall: FW_OK, empfang: LAEUFT, cloud: { enabled: true, lastError: 'HTTP 404: not found' },
});
const f = fern.befunde.find((b) => b.code === 'FERNLIVE_FEHLER');
ok('Fern-Live-Fehler wird gemeldet', !!f);
ok('aber ausdruecklich als NICHT-Geraeteproblem', /NICHT die Geraeteverbindung/.test(f.titel), f.titel);
ok('erklaert HTTP 404 als "Datenbank nicht angelegt"', /nicht angelegt/.test(f.warum));
ok('Fern-Live-Fehler ist nur ein Hinweis', f.schwere === 1);
ok('und stoert das Gesamturteil nicht', fern.urteil === 'ok', fern.urteil);

/* ---------------- 7) Alles laeuft ---------------- */
console.log('\nWenn alles laeuft:');
const gut = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [{ ip: '192.168.0.50', stufe: 'sicher', datenPorts: [3502], gruende: [] }] },
  firewall: FW_OK, empfang: LAEUFT,
});
ok('Urteil "ok"', gut.urteil === 'ok', gut.urteil);
ok('und sagt, dass Werte ankommen', /Datenverbindung steht/.test(gut.kurz), gut.kurz);
ok('EMPFANG_OK steht ganz oben', gut.befunde[0].code === 'EMPFANG_OK');

/* ---------------- 8) Nichts gefunden UND nichts kommt an ---------------- */
console.log('\nWenn nichts erklaerbar ist, wird das auch gesagt:');
const raetsel = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [{ ip: '192.168.0.50', stufe: 'sicher', datenPorts: [], mac: null, gruende: [] }] },
  firewall: FW_OK, empfang: STILL,
});
ok('es wird nie "alles in Ordnung" behauptet, wenn nichts ankommt', raetsel.urteil !== 'ok', raetsel.urteil);

const ungeklaert = lage({
  scan: { adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' }, hosts: [{ ip: '192.168.0.90', stufe: 'moeglich', datenPorts: [], gruende: [] }, { ip: '192.168.0.91', stufe: 'moeglich', datenPorts: [], gruende: [] }] },
  firewall: FW_OK, empfang: STILL,
});
ok('ohne sicheren Fund bleibt es bei KEIN_GERAET (nicht "ungeklaert")',
  codes(ungeklaert).indexOf('KEIN_GERAET') >= 0);

/* ---------------- 8b) Das Geraet liegt woanders als in der Konfiguration ----------------
 * DER FALL VOM 22.07.2026: devices.json sagte 192.168.0.50, das Geraet hing auf 192.168.0.51.
 * Im Log stand beides nebeneinander ("gefunden: .51" / ".50 antwortet nicht") und niemand konnte
 * daraus schliessen, was zu tun ist.
 */
console.log('\nKonfigurierte Adresse gegen tatsaechlichen Fundort:');
const umgezogen = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.51', stufe: 'sicher', datenPorts: [], mac: '000f142b1052', gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL, konfigHosts: ['192.168.0.50'],
});
ok('der Widerspruch wird ueberhaupt benannt', codes(umgezogen).indexOf('GERAET_ANDERE_IP') >= 0, codes(umgezogen).join(','));
const uz = umgezogen.befunde.find((b) => b.code === 'GERAET_ANDERE_IP');
ok('die tote Adresse wird genannt', /192\.168\.0\.50/.test(uz.warum));
ok('die tatsaechliche Adresse wird genannt', /192\.168\.0\.51/.test(uz.warum));
ok('DHCP wird als haeufigste Ursache erklaert', /DHCP/.test(uz.warum));
ok('der erste Schritt ist die dauerhafte Loesung "auto"', /"auto"/.test(uz.tun[0]));
ok('es gilt als wahrscheinliche Ursache (Schwere 2)', uz.schwere === 2);

const passt = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.51', stufe: 'sicher', datenPorts: [], mac: '000f142b1052', gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL, konfigHosts: ['192.168.0.51'],
});
ok('stimmt die Adresse, wird NICHT gemeckert', codes(passt).indexOf('GERAET_ANDERE_IP') < 0);
const autoKonf = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.51', stufe: 'sicher', datenPorts: [], mac: '000f142b1052', gruende: [] }],
  },
  firewall: FW_OK, empfang: STILL, konfigHosts: ['auto'],
});
ok('bei "auto" gibt es diesen Befund gar nicht mehr', codes(autoKonf).indexOf('GERAET_ANDERE_IP') < 0);

/* ---------------- 8c) Kein Weg ins Internet (Update/Fern-Live) ----------------
 * Der PC hatte 192.168.0.99 OHNE Gateway - richtig fuer ein isoliertes Geraetenetz, aber er hing
 * ueber einen Verstaerker am Hausnetz. Geraetedaten liefen, Updates waren still tot.
 */
console.log('\nInternet (Update/Fern-Live) getrennt von der Geraeteverbindung:');
const ohneInternet = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.51', stufe: 'sicher', datenPorts: [3502], mac: '000f142b1052', gruende: [] }],
  },
  firewall: FW_OK, empfang: LAEUFT,
  internet: { gateway: null, router: '192.168.0.1', routerImNetz: true, erreichbar: false },
});
const oi = ohneInternet.befunde.find((b) => b.code === 'KEIN_INTERNET');
ok('fehlendes Internet wird gemeldet', !!oi, codes(ohneInternet).join(','));
ok('aber NICHT als Geraeteproblem eingestuft (Schwere 1)', oi && oi.schwere === 1);
ok('es sagt ausdruecklich, dass die Geraetedaten davon NICHT betroffen sind',
  /GERAETEDATEN sind davon NICHT betroffen/.test(oi.warum));
ok('es nennt den gefundenen Router als Loesung', /192\.168\.0\.1/.test(oi.warum + oi.tun.join(' ')));
ok('und die Doppelklick-Datei dafuer', /INTERNET-EINRICHTEN\.bat/.test(oi.tun.join(' ')));
ok('das Gesamturteil bleibt "ok", solange Werte ankommen', ohneInternet.urteil === 'ok', ohneInternet.urteil);

const inselNetz = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.51', stufe: 'sicher', datenPorts: [3502], mac: '000f142b1052', gruende: [] }],
  },
  firewall: FW_OK, empfang: LAEUFT,
  internet: { gateway: null, router: '192.168.0.1', routerImNetz: false, erreichbar: false },
});
const iz = inselNetz.befunde.find((b) => b.code === 'KEIN_INTERNET');
ok('im echten Inselnetz wird das isolierte Netz als die sicherere Variante benannt',
  iz && /sicherere Variante/.test(iz.tun.join(' ')));

// DER TATSAECHLICHE ZUSTAND DES PRAXIS-PCs am 22.07.2026: kein IPv4-Gateway, aber vollstaendiges
// IPv6 vom Kabelrouter. Update-Manifest und klinische Daten waren erreichbar (HTTP 200). Die
// Station darf daraus weder "kein Internet" machen noch so tun, als sei alles selbstverstaendlich.
const nurV6 = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.51', stufe: 'sicher', datenPorts: [3502], mac: '000f142b1052', gruende: [] }],
  },
  firewall: FW_OK, empfang: LAEUFT,
  internet: { gateway: null, router: '192.168.0.1', routerImNetz: true, v4: false, v6: true, nurV6: true, erreichbar: true },
});
const nv = nurV6.befunde.find((b) => b.code === 'NUR_IPV6');
ok('nur IPv6 wird als eigener Fall erkannt', !!nv, codes(nurV6).join(','));
ok('es wird NICHT faelschlich "kein Internet" gemeldet', codes(nurV6).indexOf('KEIN_INTERNET') < 0);
ok('es sagt, dass Update und klinische Daten derzeit LAUFEN', /laufen Update und/.test(nv.warum));
ok('es benennt das Risiko (Dienste ohne AAAA / Router schaltet IPv6 ab)',
  /AAAA/.test(nv.warum) && /IPv6 abschaltet|IPv6 ab, faellt/.test(nv.warum));
ok('es sagt zu, dass die feste IP unangetastet bleibt', /feste IP.*unveraendert|aendert die feste IP/i.test(nv.tun.join(' ')));
ok('es bleibt ein Hinweis, kein Alarm (Schwere 1)', nv.schwere === 1);

const ungeprueftesInternet = lage({
  scan: {
    adapters: [KARTE('192.168.0.99')], netz: { base: '192.168.0.' },
    hosts: [{ ip: '192.168.0.51', stufe: 'sicher', datenPorts: [3502], mac: '000f142b1052', gruende: [] }],
  },
  firewall: FW_OK, empfang: LAEUFT,
});
ok('ohne Internetpruefung wird nichts behauptet', codes(ungeprueftesInternet).indexOf('KEIN_INTERNET') < 0);

/* ---------------- 9) Form: jede Aussage begruendet + ein Schritt ---------------- */
console.log('\nForm jeder Aussage:');
const alleLagen = [keinNetz, falschesNetz, niemand, nurBuero, stumm, offenAberStill, fwFehlt, belegt, raetsel,
  umgezogen, ohneInternet, inselNetz, nurV6];
let ohneWarum = 0, ohneTun = 0, langeTitel = 0;
alleLagen.forEach((r) => r.befunde.forEach((x) => {
  if (!x.warum || x.warum.length < 20) ohneWarum++;
  if (x.code !== 'EMPFANG_OK' && (!x.tun || !x.tun.length)) ohneTun++;
  if (x.titel.length > 90) langeTitel++;
}));
ok('jeder Befund hat eine Begruendung', ohneWarum === 0, ohneWarum + ' ohne');
ok('jeder Befund hat mindestens einen konkreten Schritt', ohneTun === 0, ohneTun + ' ohne');
ok('kein Titel ist laenger als eine Zeile', langeTitel === 0, langeTitel + ' zu lang');
ok('Befunde sind nach Schwere sortiert (schlimmstes zuerst)',
  alleLagen.every((r) => {
    const s = r.befunde.filter((x) => x.code !== 'EMPFANG_OK').map((x) => x.schwere);
    return s.every((v, i) => i === 0 || s[i - 1] >= v);
  }));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
