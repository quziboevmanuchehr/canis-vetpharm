'use strict';
/*
 * cloud-integration-test.js — Ende-zu-Ende: ECHTE Bridge (Simulator) -> Cloud-Publisher -> Mock-Firebase.
 * Beweist, dass server.js die zusammengefuehrten Patienten (registry.getPatients) tatsaechlich
 * ~1x/s an die Cloud sendet, inkl. Brain-Enrichment. Legt temporaer eine devices.json an
 * (Simulator + cloud.enabled) und raeumt sie am Ende wieder weg.  Start: node tools/cloud-integration-test.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CFG = path.join(__dirname, '..', 'bridge', 'config', 'devices.json');
const AUTH_FILE = path.join(require('os').tmpdir(), 'vetstation-integ-auth-' + process.pid + '.json');
let pass = 0, fail = 0, child = null, hadCfgBefore = fs.existsSync(CFG);
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? ' -> ' + e : '')); } }

const captured = { puts: [], urls: [], signups: 0, refreshes: 0 };
const mock = http.createServer((req, res) => {
  let body = ''; req.on('data', c => body += c); req.on('end', () => {
    if (req.url.startsWith('/identity')) { captured.signups++; return j(res, { idToken: 'ID', refreshToken: 'RT', localId: 'u1', expiresIn: '3600' }); }
    if (req.url.startsWith('/token')) { captured.refreshes++; return j(res, { id_token: 'ID', refresh_token: 'RT', user_id: 'u1', expires_in: '3600' }); }
    if ((req.method === 'PATCH' || req.method === 'PUT') && req.url.indexOf('/live/') >= 0) {
      let p = null; try { p = JSON.parse(body); } catch (_) {}
      captured.puts.push(p); captured.urls.push(req.url);
      return j(res, p);
    }
    res.writeHead(404); res.end();
  });
});
function j(res, o) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); }

let cleaned = false;
function cleanup() {
  if (cleaned) return; cleaned = true;
  try { if (child) child.kill(); } catch (_) {}
  // KERNPUNKT (23.07.2026): Diese temporaere devices.json aktiviert den Simulator + Cloud-Code
  // "integ-test". Bleibt sie liegen, laedt JEDER spaetere Start sie und zeigt simulierte Patienten
  // statt der echten Geraete — genau der Befund "haengt nur beim Hund, uebernimmt keine Daten".
  // Deshalb wird sie hier IMMER entfernt, wenn der Test sie selbst angelegt hat.
  try { if (!hadCfgBefore) fs.unlinkSync(CFG); } catch (_) {}
  try { fs.unlinkSync(AUTH_FILE); } catch (_) {}
  try { mock.close(); } catch (_) {}
}
// Absturz-/Abbruchsicher: Strg-C, kill und regulaeres Ende raeumen die Test-Konfig ebenfalls weg.
// Ohne diese Handler blieb bei Strg-C nach dem writeFileSync die Simulator-devices.json zurueck.
['SIGINT', 'SIGTERM', 'SIGHUP'].forEach((sig) => process.on(sig, () => { cleanup(); process.exit(1); }));
process.on('exit', cleanup);

async function run() {
  if (hadCfgBefore) { console.log('devices.json existiert bereits — Test uebersprungen (nicht ueberschreiben).'); process.exit(0); }
  await new Promise(r => mock.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + mock.address().port;
  console.log('Integrationstest: Bridge -> Cloud -> Mock (' + base + ')');

  /*
   * Gespeicherte Anmeldung VOR dem Start hinlegen. Das ist genau der Fall, der in der Praxis
   * zaehlt: nach Stromausfall oder Update startet der PC neu, und die Uebertragung muss von
   * selbst wieder anlaufen — ohne dass jemand ein Passwort eintippt. Das Passwort steht
   * bewusst nirgends in dieser Datei.
   */
  fs.writeFileSync(AUTH_FILE, JSON.stringify({ refreshToken: 'RT', localId: 'u1', email: 'integ@test.de' }));

  fs.writeFileSync(CFG, JSON.stringify({
    port: 8779, host: '127.0.0.1',
    cloud: { enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
      station: 'Integ-OP', minIntervalMs: 600, identityUrl: base + '/identity', tokenUrl: base + '/token',
      authFile: AUTH_FILE, archiv: { enabled: false } },
    adapters: [{ type: 'simulator', id: 'sim', enabled: true, rateMs: 500 }],
  }, null, 2));

  child = spawn(process.execPath, [path.join(__dirname, '..', 'bridge', 'src', 'index.js')], { stdio: 'ignore' });

  // bis zu 6s auf >=2 Schreibvorgaenge warten
  const t0 = Date.now();
  while (captured.puts.length < 2 && Date.now() - t0 < 6000) await wait(150);

  ok('startet mit gespeicherter Anmeldung (Erneuerung, KEINE Passworteingabe)',
    captured.refreshes >= 1 && captured.signups === 0, 'signups=' + captured.signups + ' refreshes=' + captured.refreshes);
  ok('mindestens 2 Snapshots gesendet', captured.puts.length >= 2, 'puts=' + captured.puts.length);
  ok('geschrieben wird unter der Praxis-Kennung, mit Token',
    captured.urls.every((u) => u.indexOf('/live/u1.json') >= 0 && u.indexOf('auth=') >= 0),
    captured.urls[0]);

  /*
   * Der ERSTE Schreibvorgang ist das Vollbild (meta + patients). Alles danach sind Deltas mit
   * flachen Pfadschluesseln — genau das ist der Sinn des Umbaus, deshalb wird es hier auch
   * ausdruecklich geprueft: waere der letzte Schreibvorgang wieder ein Vollbild, waere die
   * Delta-Ersparnis kaputt und der schnelle Takt unbezahlbar.
   */
  const snap = captured.puts[0] || {};
  const letzter = captured.puts[captured.puts.length - 1] || {};
  ok('spaetere Schreibvorgaenge sind Deltas (flache Pfade, kein Vollbild)',
    captured.puts.length < 2 || (!letzter.patients && Object.keys(letzter).some((k) => k.indexOf('/') > 0)),
    Object.keys(letzter).slice(0, 4).join(', '));
  ok('Snapshot hat meta+patients', !!snap.meta && !!snap.patients);
  ok('meta.station = Integ-OP', snap.meta && snap.meta.station === 'Integ-OP');
  const keys = snap.patients ? Object.keys(snap.patients) : [];
  ok('mehrere zusammengefuehrte Patienten (Simulator-Standard = 4)', keys.length === 4, 'keys=' + keys.length);
  const specs = keys.map(k => snap.patients[k].species);
  ok('Art-Vielfalt end-to-end (Kaninchen + Reptil in der Cloud)', specs.indexOf('kaninchen') >= 0 && specs.indexOf('reptil') >= 0, specs.join(','));

  const anyVitals = keys.some(k => snap.patients[k].vitals && snap.patients[k].vitals.hr != null);
  ok('echte Vitalwerte enthalten (hr)', anyVitals);
  const anyEnriched = keys.some(k => typeof snap.patients[k].pri === 'number');
  ok('Brain-Enrichment vorhanden (pri)', anyEnriched);
  const anySpecies = keys.every(k => !!snap.patients[k].species);
  ok('jede Spezies gesetzt', anySpecies);

  cleanup();
  console.log('\nErgebnis: ' + pass + ' OK, ' + fail + ' Fehler.');
  process.exit(fail ? 1 : 0);
}
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }
process.on('uncaughtException', e => { console.error('FEHLER', e); cleanup(); process.exit(1); });
run().catch(e => { console.error('TESTFEHLER', e); cleanup(); process.exit(1); });
