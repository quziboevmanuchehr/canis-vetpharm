<#
  set-firewall.ps1 - Gibt die Geraete-Datenports in der Windows-Firewall frei.
  EINE gemeinsame, WIEDERHOLBARE Stelle fuer beide Installationswege (Install-VetStation.ps1
  UND vetstation-setup.iss) - plus zum Reparieren per Doppelklick (FIREWALL-FREIGEBEN.bat).

  WARUM DIESE DATEI EXISTIERT (Befund 1.3 / 2.5, 21.07.2026):
  Auf dem Praxis-PC standen 10 statt 5 Regeln. Ursache: das Inno-Setup legte die Regeln OHNE
  vorheriges Loeschen an, Install-VetStation.ps1 zusaetzlich - pro Neuinstallation kam ein
  weiterer Satz dazu. Nicht gefaehrlich, aber die Firewall-Liste wird unlesbar und die
  Fehlersuche schwerer.

  WARUM ES UEBERHAUPT NOETIG IST (Befund 2.6):
  Fehlt eine Freigabe, verwirft Windows die Vitaldaten LAUTLOS. Das Geraet meldet "sendet",
  der PC zeigt nichts, und nirgends steht eine Fehlermeldung.

  IDEMPOTENT: erst ALLE gleichnamigen Altregeln entfernen, dann GENAU EINE je Port anlegen.
  Mehrfaches Ausfuehren aendert das Ergebnis nicht.

  Aufruf:  powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-firewall.ps1"
  Pruefen: -Pruefen   (aendert nichts, meldet nur den Zustand)
  Entfernen: -Entfernen
#>
param(
  [switch]$Pruefen,
  [switch]$Entfernen,
  [switch]$Leise
)

# 3502 = Mindray Gateway-Kommunikation (Standard-Ziel im uMEC12-Vet-Netzwerkmenue)
# 4601 = HL7/VSCapture
# 8830 = Standardziel der HL7-Konfiguration im Eickemeyer LifeVet 10C (Daten+Kurven UND Alarme)
# 5000/24105/2575 = weitere HL7-Kandidatenports
$PORTS = @(3502, 4601, 8830, 5000, 24105, 2575)
$PREFIX = 'VetStation Geraetedaten TCP '

function Regelname([int]$p) { return ($PREFIX + $p) }

# --- Adminrechte sicherstellen (Firewall-Regeln brauchen sie zwingend) ---------
if (-not $Pruefen) {
  $__id = [Security.Principal.WindowsIdentity]::GetCurrent()
  if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
    # NICHT $args benennen - das ist eine automatische PowerShell-Variable.
    $argListe = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'))
    if ($Entfernen) { $argListe += '-Entfernen' }
    if ($Leise) { $argListe += '-Leise' }
    try { Start-Process powershell.exe -Verb RunAs -ArgumentList $argListe }
    catch {
      Write-Warning "Adminrechte noetig. Bitte FIREWALL-FREIGEBEN.bat rechtsklicken -> 'Als Administrator ausfuehren'."
      Start-Sleep 6
    }
    exit
  }
}

# Zaehlt vorhandene Regeln je Port. Sprachunabhaengig: gesucht wird unser EIGENER Regelname,
# der in jeder Windows-Sprache woertlich so in der Ausgabe steht.
function Zaehle([int]$p) {
  $name = Regelname $p
  $n = 0
  try {
    $r = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue
    if ($r) { $n = @($r).Count }
    return $n
  } catch { }
  # Fallback fuer Systeme ohne NetSecurity-Modul
  try {
    $out = & netsh advfirewall firewall show rule name="$name" 2>$null
    if ($out) { $n = @($out | Where-Object { $_ -like ('*' + $name + '*') }).Count }
  } catch { }
  return $n
}

function EntferneAlle([int]$p) {
  $name = Regelname $p
  try { Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue } catch { }
  # netsh loescht ALLE gleichnamigen auf einmal - genau das brauchen wir zum Aufraeumen.
  # Kein 2>&1: in PowerShell 5.1 wuerde das jede stderr-Zeile eines nativen Programms in einen
  # ErrorRecord verwandeln und $? auf $false setzen, obwohl netsh erfolgreich war.
  try { & netsh advfirewall firewall delete rule name="$name" | Out-Null } catch { }
}

function Lege([int]$p) {
  $name = Regelname $p
  try {
    New-NetFirewallRule -DisplayName $name -Direction Inbound -Action Allow -Protocol TCP `
      -LocalPort $p -Profile Any `
      -Description "VetStation: Vitaldaten von Narkose-/Patientenmonitoren (nur lesend)" -ErrorAction Stop | Out-Null
    return $true
  } catch { }
  try {
    & netsh advfirewall firewall add rule name="$name" dir=in action=allow protocol=TCP localport=$p | Out-Null
    return $true
  } catch { }
  return $false
}

if (-not $Leise) {
  Write-Host ""
  Write-Host "== VetStation - Windows-Firewall fuer die Geraeteports =="
}

# --- Nur pruefen -------------------------------------------------------------
if ($Pruefen) {
  $fehlend = @(); $doppelt = @()
  foreach ($p in $PORTS) {
    $n = Zaehle $p
    if ($n -eq 0) { $fehlend += $p; Write-Host ("  TCP {0}: FEHLT - Windows verwirft die Daten lautlos" -f $p) }
    elseif ($n -gt 1) { $doppelt += $p; Write-Host ("  TCP {0}: freigegeben, aber {1} Regeln (Altbestand)" -f $p, $n) }
    else { Write-Host ("  TCP {0}: freigegeben" -f $p) }
  }
  if ($fehlend.Count -or $doppelt.Count) {
    Write-Host ""
    Write-Host "  -> Reparieren: FIREWALL-FREIGEBEN.bat doppelklicken."
    exit 1
  }
  Write-Host "  Alles in Ordnung (genau eine Regel je Port)."
  exit 0
}

# --- Entfernen ---------------------------------------------------------------
if ($Entfernen) {
  foreach ($p in $PORTS) { EntferneAlle $p }
  if (-not $Leise) { Write-Host "Alle VetStation-Firewallregeln entfernt." }
  exit 0
}

# --- Setzen (idempotent) -----------------------------------------------------
$ok = 0; $nichtOk = @(); $aufgeraeumt = 0
foreach ($p in $PORTS) {
  $vorher = Zaehle $p
  if ($vorher -gt 1) { $aufgeraeumt += ($vorher - 1) }
  EntferneAlle $p
  if (Lege $p) { $ok++ } else { $nichtOk += $p }
}

if (-not $Leise) {
  Write-Host ("  {0} von {1} Ports freigegeben (genau eine Regel je Port)." -f $ok, $PORTS.Count)
  if ($aufgeraeumt -gt 0) { Write-Host ("  {0} doppelte Altregel(n) aufgeraeumt." -f $aufgeraeumt) }
  if ($nichtOk.Count -gt 0) {
    Write-Warning ("Nicht freigegeben: TCP " + ($nichtOk -join ', ') + ". Bitte in der Windows-Firewall von Hand pruefen.")
  } else {
    Write-Host "  Fertig. Ankommende Vitaldaten werden nicht mehr blockiert."
  }
  Write-Host ""
}
if ($nichtOk.Count -gt 0) { exit 1 }
exit 0
