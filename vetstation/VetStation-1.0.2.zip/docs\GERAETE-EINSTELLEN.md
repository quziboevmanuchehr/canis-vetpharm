# Geräte einstellen — Schritt für Schritt

> Stand 22.07.2026, erstellt aus den **Fotos der echten Gerätemenüs** in der Praxis.
> Alle Werte hier sind auf genau diese beiden Geräte abgestimmt.
> Der PC steht bereits richtig auf **192.168.0.99** — das ist erledigt und wird nicht angefasst.

---

## Was aktuell falsch steht (aus den Fotos abgelesen)

| Gerät | Was steht dort | Warum das nicht geht |
|---|---|---|
| **LifeVet 10C** | LAN1-IP **192.168.0.1** | Das ist die **Router-Adresse**. Das Gerät meldet selbst `*LAN1-IP-Adressenkonflikt` und verschwindet zeitweise ganz aus dem Netz — die Suche vom PC hat es deshalb **gar nicht gefunden**. |
| **LifeVet 10C** | HL7-Ziel **192.168.2.16** | Anderes Netz (`192.168.2.x` statt `192.168.0.x`). Der Monitor schickt seine Werte an eine Adresse, die es hier nicht gibt. |
| **LifeVet 10C** | Datenintervall **30 s** | Für eine Narkoseüberwachung viel zu träge — zwischen zwei Werten liegt eine halbe Minute. |
| **Narkosegerät** | Gateway **192.168.0.2** | Diese Adresse gibt es im Praxisnetz nicht. Stört den Datenverkehr im selben Netz zwar nicht, sollte aber sauber sein. |
| **Narkosegerät** | Port 4601 antwortet, aber **kein HL7** | Das Gerät spricht dort Mindrays eigenes Protokoll (**MD2**), das nur die hauseigene CentralStation versteht. |

**Merksatz:** Jedes Gerät braucht eine **eigene, freie** Adresse, und alle müssen im selben
Bereich `192.168.0.x` liegen.

| Teilnehmer | Adresse |
|---|---|
| PC (VetStation) | `192.168.0.99` ✅ steht schon |
| Narkosegerät (Veta 5) | `192.168.0.52` ✅ am Gerät gesetzt *(geändert von .50 → .52)* |
| LifeVet 10C | `192.168.0.51` ⬅ **muss geändert werden** |
| Router (falls vorhanden) | `192.168.0.1` — **für kein Gerät verwenden** |

---

## Schritt 1 — LifeVet 10C: eigene Adresse geben ⬅ **das Wichtigste**

Solange das Gerät auf `192.168.0.1` steht, hilft nichts anderes.

1. Am LifeVet: **Wartung → Netzwerk-Setup → LAN1**
2. Eintragen:
   - **IP-Adresse:** `192.168.0.51`
   - **Subnetzmaske:** `255.255.255.0`
   - **Gateway:** `0.0.0.0` *(siehe Kasten unten)*
   - **Bevorzugter DNS-Server:** `0.0.0.0` · **Alternativer DNS-Server:** `0.0.0.0`
3. Bestätigen.

> **Kontrolle:** Die Meldung `*LAN1-IP-Adressenkonflikt` oben im Bildschirm **muss verschwinden**.
> Bleibt sie, ist `.51` ebenfalls belegt — dann `192.168.0.52` nehmen.

### Was trage ich bei Gateway und DNS ein?

**Kurz: Für die Verbindung zu VetStation ist DNS völlig egal.**

Ein DNS-Server übersetzt *Namen* in Adressen (wie ein Telefonbuch). VetStation wird aber über eine
**Zahl** angesprochen — `192.168.0.99`. Da ist kein Name im Spiel. Ein falscher, leerer oder
fehlender DNS-Eintrag kann die Vitaldaten deshalb **weder verhindern noch verbessern**.

Dasselbe gilt fürs Gateway: Ein Gateway wird nur gebraucht, um in **andere** Netze zu kommen.
PC (`.99`), Narkosegerät (`.50`) und LifeVet (`.51`) liegen alle im selben Netz `192.168.0.x` und
reden **direkt** miteinander.

| Deine Situation | Gateway | Bevorzugter DNS |
|---|---|---|
| **Eigener Switch, kein Router** ⬅ *das ist bei dir der Fall* | `0.0.0.0` | `0.0.0.0` |
| Geräte hängen am Hausnetz mit Router | Adresse des Routers (meist `192.168.0.1`) | dieselbe Router-Adresse |

**Woran erkennst du, was zutrifft?** `GERAETE-PRUEFEN.bat` doppelklicken. Taucht in der Fundliste
eine Zeile `· 192.168.0.1 … ist das Standardgateway (Router)` auf, gibt es einen Router. Erscheint
sie nicht, hängen nur PC und Geräte am Switch — dann `0.0.0.0` eintragen.

> **Warum bei dir `0.0.0.0`?** Der Suchlauf am Praxis-PC hat **ausschließlich** `192.168.0.50`
> gefunden, sonst nichts. Und der PC selbst wurde bewusst **ohne Gateway** eingerichtet
> („isoliert"). Es ist also kein Router da, auf den man zeigen könnte. `192.168.0.1` einzutragen
> würde bedeuten: das Gerät sucht bei jedem Verbindungsaufbau nach einem Nachbarn, den es nicht
> gibt — das bringt nichts und kann Wartezeiten verursachen.

**Nebenwirkung, die du ignorieren kannst:** Ohne DNS bleibt am LifeVet die Meldung
`*Zeitserver nicht verfügbar.` stehen. Das ist **harmlos** — VetStation stempelt jeden Messwert
mit der Uhr des **PCs**, nicht mit der des Geräts. Protokoll und PDF-Export haben also immer die
richtige Zeit. Nur die Anzeige am Gerät selbst zeigt dann eine falsche Uhrzeit; die kannst du im
Gerätemenü von Hand stellen.

---

## Schritt 2 — LifeVet 10C: Werte an den PC schicken

1. **Wartung → Netzwerk-Setup → HL7-Konfiguration**
2. Oben unter **„Daten + Kurven"**:
   - **Ziel-IP:** `192.168.0.99` ⬅ *(steht jetzt auf 192.168.2.16)*
   - **Port:** `8830` — **so lassen!** VetStation hört ab 0.7.0 selbst auf diesem Port zu.
   - **Daten senden:** EIN ✅ *(ist schon an)*
   - **Kurven senden:** EIN ✅ *(ist schon an)*
   - **Datenintervall:** auf den **kleinsten wählbaren Wert** stellen (1 s oder 5 s).
     30 s sind für eine Narkose zu langsam.
3. Darunter unter **„Alarme"**:
   - **Ziel-IP:** `192.168.0.99`
   - **Port:** `8830`
   - **Alarme senden:** **EIN** *(steht auf AUS)* — dann meldet der Monitor seine Alarme mit.
4. Bestätigen.

> **Kontrolle:** Der **Verbindungsstatus** unter „Daten + Kurven" muss von *Nicht verbunden* auf
> **verbunden** springen — spätestens ein paar Sekunden nachdem VetStation läuft.

---

## Schritt 3 — Narkosegerät: Gateway korrigieren

1. **System → Setup → Netzwerk einr.**
2. **Standard-Gateway** von `192.168.0.2` auf **`0.0.0.0`** ändern
   *(bzw. auf die Router-Adresse, falls doch ein Router im Netz hängt — siehe Kasten in Schritt 1)*
3. **DNS-Server** ebenfalls auf `0.0.0.0` lassen — gleiche Begründung wie beim LifeVet.
4. IP **`192.168.0.52`** und Maske `255.255.255.0` **bleiben so** *(am Gerät bewusst auf `.52` gestellt, nicht `.50` — so gibt es keinen Konflikt mit dem LifeVet auf `.51`)*.

> `192.168.0.2` ist eine Adresse, die es in deinem Netz nicht gibt. Sie verhindert die
> Datenübertragung zwar nicht (gleiche Netze brauchen kein Gateway), sollte aber nicht
> stehenbleiben — sonst sucht das Gerät regelmäßig nach einem Nachbarn, den es nie findet.

### Was mit „MD2" ist — bitte **NICHT** einschalten

Im Menü **System → Setup → CentralStation Verbindung** gibt es einen Schalter **MD2** und ein Feld
*Serveradresse*. Das ist verlockend, hilft aber **nicht**:

**MD2 ist Mindrays eigenes, nicht offengelegtes Protokoll.** Es spricht ausschließlich mit
Mindrays kostenpflichtiger *BeneVision CMS Vet*-Zentrale. VetStation versteht es nicht — und darf
es auch nicht raten, denn falsch interpretierte Vitalwerte wären am narkotisierten Patienten
gefährlich.

Genau das hat die Prüfung am 22.07.2026 auch gemessen: Port 4601 des Narkosegeräts **antwortet**,
schickt aber kein HL7, sondern ein unbekanntes Binärformat.

**Deshalb gilt:** Die Vitalwerte kommen vom **LifeVet-Monitor** (Schritt 1 + 2). Das ist der
dokumentierte und belegte Weg — der Monitor misst ohnehin auch CO₂.

> Der Punkt **„Monitor verbunden"** mit dem Knopf *[Verbinden]* koppelt den Monitor an das
> **Narkosegerät** (damit dort dessen Werte erscheinen). Für VetStation ist das **nicht nötig** —
> die Station liest den Monitor direkt. Wer es trotzdem nutzen möchte, kann es gefahrlos tun.

---

## Schritt 4 — Am PC nachsehen, ob es klappt

1. **`NEUSTART.bat`** doppelklicken *(damit die Station den neuen Port 8830 auch belegt)*
2. **`GERAETE-PRUEFEN.bat`** doppelklicken

Zu erwarten ist dann:

```
✓ 192.168.0.52    SICHER ein Geraet   antwortet auf Datenport 4601
✓ 192.168.0.51    SICHER ein Geraet   antwortet auf Datenport 8830
```

und am Ende **`[OK] Datenverbindung steht`**.

Dasselbe gibt es auch in der App: **Admin ▸ 🌐 Netzwerk & Geräte ▸ „Netzwerk jetzt durchsuchen"**.

---

## Wenn danach immer noch nichts ankommt

Die Station sagt selbst, woran es liegt — der Check nennt die wahrscheinlichste Ursache zuerst.
Die drei häufigsten Fälle:

| Meldung | Bedeutung | Was tun |
|---|---|---|
| „Ein Gerät benutzt die Adresse des Routers" | Schritt 1 hat nicht gegriffen | andere freie Adresse vergeben, Gerät aus/ein |
| „Das Gerät antwortet, spricht aber kein HL7" | Es sendet MD2 statt HL7 | am Gerät **HL7-Konfiguration** benutzen, nicht die CentralStation-Kopplung |
| „Windows-Firewall blockiert …" | Freigabe fehlt | `FIREWALL-FREIGEBEN.bat` doppelklicken |

Hilft alles nicht, beim Händler (Eickemeyer) die **Freischaltung der HL7-Datenausgabe** erfragen —
bei manchen Firmwareständen ist sie lizenzpflichtig.
