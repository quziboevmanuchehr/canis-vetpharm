'use strict';
/*
 * geraetefund.js — gemeinsames Gedaechtnis: WO im Netz haengt gerade ein Medizingeraet?
 *
 * WARUM ES DIESE DATEI GIBT (Befund 22.07.2026, Praxis-PC):
 * In devices.json stand die Geraete-IP FEST (192.168.0.50). Das Geraet hing an diesem Tag aber
 * auf 192.168.0.51 — der Router hatte per DHCP eine andere Adresse vergeben, nachdem der Monitor
 * einmal auf "Automatisch" zurueckgefallen war. Ergebnis:
 *   • Der Verbindungs-Assistent MELDETE das Geraet korrekt ("Mindray-Geraet gefunden: 192.168.0.51"),
 *   • der Abfrage-Adapter klopfte trotzdem stur an 192.168.0.50 und meldete "antwortet nicht".
 * Die Station wusste die richtige Adresse also bereits und benutzte sie nicht. Genau diese Luecke
 * schliesst dieses Modul: EIN Fundort, den alle Adapter lesen.
 *
 * In devices.json genuegt dann  "host": "auto"  statt einer festen IP — die Station folgt dem
 * Geraet selbst, egal welche Adresse es vom Router bekommt.
 *
 * STRIKT READ-ONLY: liest nur die ARP-Tabelle des PCs (arp -a). Es wird nichts gesendet und an
 * keinem Geraet etwas verstellt.
 */
const { execFile } = require('child_process');

// Hersteller-Praefixe der bekannten Geraete. 98:CC:E4 = Mindray (uMEC12 Vet / Veta 5 Plus),
// 00:0F:14 = Mindray/Eickemeyer (LifeVet 10C).
const MEDIZIN_OUI = ['98cce4', '000f14'];

// ip -> { ip, mac, gesehen, quelle }
const gefunden = new Map();

function normMac(mac) { return String(mac || '').toLowerCase().replace(/[^0-9a-f]/g, ''); }
function istMedizinMac(mac) {
  const m = normMac(mac);
  return m.length >= 6 && MEDIZIN_OUI.indexOf(m.slice(0, 6)) >= 0;
}

/*
 * merke(liste, quelle) — traegt Funde ein. Wird vom Verbindungs-Assistenten (probe.js) bei jedem
 * ARP-Durchlauf aufgerufen. Pure genug zum Testen: keine Netz-/Dateizugriffe.
 */
function merke(liste, quelle) {
  const jetzt = Date.now();
  (liste || []).forEach((g) => {
    if (!g || !g.ip) return;
    gefunden.set(g.ip, { ip: g.ip, mac: normMac(g.mac), gesehen: jetzt, quelle: quelle || 'arp' });
  });
  return alle();
}

/* Alle bekannten Geraete, das zuletzt gesehene zuerst. */
function alle() {
  return Array.from(gefunden.values()).sort((a, b) => b.gesehen - a.gesehen);
}

/*
 * beste(bevorzugt) — welche Adresse soll ein Adapter ansprechen?
 *
 * Steht die in der Konfiguration hinterlegte Adresse noch im Netz, bleibt es dabei (keine
 * ueberraschenden Wechsel im laufenden Betrieb). Sonst das zuletzt gesehene Geraet.
 * Ohne jeden Fund: null — der Aufrufer sagt dann ehrlich "noch kein Geraet gefunden".
 */
function beste(bevorzugt) {
  if (bevorzugt && gefunden.has(bevorzugt)) return bevorzugt;
  const liste = alle();
  return liste.length ? liste[0].ip : null;
}

/* Wurde ueberhaupt schon einmal gesucht bzw. etwas gefunden? */
function anzahl() { return gefunden.size; }

/* Nur fuer Tests: Gedaechtnis leeren. */
function leeren() { gefunden.clear(); }

/*
 * ausArpTabelle(text) — zieht die Medizingeraete aus der Ausgabe von `arp -a`.
 * Pure Funktion, deshalb ohne Netz testbar (tools/geraetefund-test.js).
 */
function ausArpTabelle(text) {
  const treffer = [];
  String(text || '').split(/\r?\n/).forEach((zeile) => {
    const m = zeile.match(/(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}(?:[-:][0-9a-fA-F]{2}){5})/);
    if (!m) return;
    if (!istMedizinMac(m[2])) return;
    treffer.push({ ip: m[1], mac: normMac(m[2]) });
  });
  return treffer;
}

/*
 * aktualisiere() — liest die ARP-Tabelle selbst ein (falls kein Verbindungs-Assistent laeuft).
 * Schlaegt der Aufruf fehl, bleibt das Gedaechtnis unveraendert — es wird nie etwas "vergessen",
 * nur weil `arp` einmal nicht antwortet.
 */
function aktualisiere() {
  return new Promise((resolve) => {
    execFile('arp', ['-a'], { timeout: 5000, windowsHide: true }, (err, stdout) => {
      if (err && !stdout) return resolve(alle());
      resolve(merke(ausArpTabelle(stdout), 'arp'));
    });
  });
}

module.exports = {
  MEDIZIN_OUI,
  istMedizinMac, normMac,
  merke, alle, beste, anzahl, leeren,
  ausArpTabelle, aktualisiere,
};
