'use strict';
/*
 * firewall.js — liest den Zustand der Windows-Firewall-Regeln fuer die Geraeteports AUS.
 *
 * WARUM (Befund 2.6): Fehlt eine Freigabe, verwirft Windows die Vitaldaten LAUTLOS. Das Geraet
 * meldet "sendet", der PC zeigt nichts, und NIRGENDS steht eine Fehlermeldung. Bisher wurde die
 * Freigabe nur EMPFOHLEN, nie geprueft.
 *
 * EHRLICHKEIT ist hier wichtiger als ein gruener Haken: laesst sich der Zustand nicht eindeutig
 * lesen (kein netsh, keine Rechte, fremde Sprache), melden wir 'unklar' — NIEMALS "in Ordnung".
 *
 * Sprachunabhaengig: wir suchen NICHT nach uebersetzten Feldnamen ("Aktiviert:"/"Enabled:"),
 * sondern nach unserem EIGENEN Regelnamen, der in jeder Windows-Sprache woertlich so dasteht.
 */
const { execFile } = require('child_process');
const { DATA_PORTS } = require('./netscan');

const REGEL_PREFIX = 'VetStation Geraetedaten TCP ';

function regelName(port) { return REGEL_PREFIX + port; }

// Zaehlt, wie oft unser Regelname in der netsh-Ausgabe vorkommt = Anzahl der Regeln.
function zaehleRegeln(stdout, port) {
  const name = regelName(port);
  let n = 0, i = 0;
  const text = String(stdout || '');
  for (;;) {
    const p = text.indexOf(name, i);
    if (p < 0) break;
    // Ausschliessen, dass "TCP 3502" auch in "TCP 35020" gefunden wird.
    const nach = text.charAt(p + name.length);
    if (!/\d/.test(nach)) n++;
    i = p + name.length;
  }
  return n;
}

function frageRegel(port) {
  return new Promise((resolve) => {
    execFile('netsh', ['advfirewall', 'firewall', 'show', 'rule', 'name=' + regelName(port)],
      { timeout: 8000, windowsHide: true }, (err, stdout, stderr) => {
        const text = String(stdout || '') + String(stderr || '');
        const treffer = zaehleRegeln(text, port);
        if (treffer > 0) return resolve({ port: port, zustand: 'frei', anzahl: treffer });
        // netsh antwortet mit Exitcode 1 + "Keine Regeln entsprechen den Kriterien" wenn es sie nicht gibt.
        // Kam ueberhaupt eine Ausgabe? Dann ist die Aussage "existiert nicht" belastbar.
        if (text.trim().length > 0) return resolve({ port: port, zustand: 'fehlt', anzahl: 0 });
        // Gar keine Ausgabe / netsh nicht startbar -> wir wissen es schlicht nicht.
        resolve({ port: port, zustand: 'unklar', anzahl: 0, grund: err ? err.message : 'keine Ausgabe von netsh' });
      });
  });
}

/*
 * pruefe() -> {
 *   lesbar: bool,                       // konnte ueberhaupt etwas gelesen werden?
 *   ports: [{port, zustand:'frei'|'fehlt'|'unklar', anzahl}],
 *   fehlend: [port...], doppelt: [{port,anzahl}...], unklar: [port...]
 * }
 */
async function pruefe(ports) {
  const liste = ports && ports.length ? ports : DATA_PORTS;
  const res = [];
  for (const p of liste) res.push(await frageRegel(p));
  return {
    lesbar: res.some((r) => r.zustand !== 'unklar'),
    ports: res,
    fehlend: res.filter((r) => r.zustand === 'fehlt').map((r) => r.port),
    doppelt: res.filter((r) => r.anzahl > 1).map((r) => ({ port: r.port, anzahl: r.anzahl })),
    unklar: res.filter((r) => r.zustand === 'unklar').map((r) => r.port),
  };
}

module.exports = { pruefe, zaehleRegeln, regelName, REGEL_PREFIX };
