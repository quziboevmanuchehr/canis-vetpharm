'use strict';
/*
 * cloud.js — FERN-LIVE Publisher (Schicht 1/3 -> Internet).
 *
 * Aufgabe: die bereits pro Patient zusammengefuehrten Live-Daten (registry.getPatients())
 * plus die "Brain"-Bewertung (brain.assess -> Prioritaet + Top-Befund) mehrmals pro Sekunde in
 * ein Cloud-Relay schreiben, damit die oeffentliche Web-App (GitHub Pages,
 * quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie) sie FERN anzeigen kann.
 *
 * Relay = Firebase Realtime Database (Projekt vet-station, europe-west1). Der Praxis-PC schreibt
 * per REST, die Zuschauer LESEN mit dem Zugangscode.
 *
 * ------------------------------------------------------------------------------------------
 * UMBAU 27.07.2026 — "alles, live, in Millisekunden" (Nutzerwunsch)
 * ------------------------------------------------------------------------------------------
 * Vorher: alle 500-1000 ms wurde der KOMPLETTE Datenstand als ein PUT geschrieben - auch die 95 %,
 * die sich nicht geaendert hatten. Das begrenzte den Takt (Bandbreite) und uebertrug ausserdem nur
 * einen Ausschnitt der Daten (kein EKG-Befund, keine echten Kurven, keine Rohwerte, keine Geraete-
 * adressen). Jetzt:
 *
 *  1) DELTA statt VOLLBILD. Nach dem ersten Vollbild (PUT) wird nur noch geschrieben, was sich
 *     tatsaechlich geaendert hat (PATCH mit tiefen Pfaden, z. B. "patients/<key>/vitals").
 *     Praktisch aendern sich pro Takt nur die Vitalwerte - wenige hundert Byte statt mehrerer KB.
 *     Erst dadurch ist ein Takt von 150-250 ms bezahlbar und im Spark-Tarif tragbar.
 *  2) ECHTE KURVEN. Das LifeVet liefert echte Abtastwerte (EKG 256 Hz, CO2 40 Hz). Die gingen bisher
 *     NICHT ins Internet - fern sah man eine nachgezeichnete Kurve. Jetzt werden die Streifen
 *     uebertragen, aber NUR wenn sich die Kurvensignatur aendert (also je Streifen genau EINMAL) und
 *     als Int16+Base64 statt als JSON-Zahlenliste (~3x kleiner). Genau dieselbe Sparlogik wie lokal
 *     (matching.fuerRundruf -> kurvenSig -> /api/kurven).
 *  3) VOLLSTAENDIGKEIT. Zusaetzlich uebertragen: alle Vitalfelder (statt Positivliste), EKG-Analyse
 *     (QRS/Rhythmus/ST), AF-Quelle (Kapnograf vs. Monitor), Beatmungsparameter, Geraeteliste mit
 *     Adresse/Status/Sendetakt/Meldungen, alle Rohwerte des Geraets, Alarme.
 *  4) FIRESTORE-ARCHIV. Der Live-Strom gehoert in die Realtime Database (dafuer ist sie gebaut).
 *     Firestore bekommt parallel im Ruhetakt (Standard 15 s) einen Verlaufsdatensatz je Station -
 *     dort ist Firestore stark: Historie, spaetere Auswertung, Fallakte.
 *
 * DATENSCHUTZ: Klarnamen (Tiername) und die Patientenakte des Geraets (Besitzer, Arzt, Telefon)
 * werden NUR uebertragen, wenn cloud.stammdaten ausdruecklich auf true steht. Standard ist AUS -
 * der Fern-Link ist nur durch den Code geschuetzt, und Besitzer-Telefonnummern gehoeren nicht in
 * eine Adresse, die man weiterleiten kann. Vitalwerte/Tierart/Gewicht/Befund gehen immer.
 *
 * STRIKT READ-ONLY gegenueber den Geraeten. NULL npm-Dependencies (nur Node-Bordmittel: https).
 */
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

/*
 * DAUERVERBINDUNG (keep-alive) — der groesste einzelne Geschwindigkeitsgewinn beim Senden.
 *
 * Jeder Schreibvorgang ist eine HTTPS-Anfrage. OHNE Dauerverbindung baut Node fuer JEDE Anfrage
 * eine neue TCP-Verbindung samt TLS-Handschlag auf: das sind zwei bis drei Rundreisen nach
 * Belgien, bevor auch nur ein Byte Nutzdaten fliesst — bei ~40 ms Rundreise also rund 100 ms
 * ZUSAETZLICHE Verzoegerung pro Wert, und das fuenfmal pro Sekunde. Mit einer offen gehaltenen
 * Verbindung entfaellt das komplett: es bleibt die reine Uebertragungszeit.
 *
 * maxSockets 4: genug, damit sich Live-Schreibvorgang, Token-Erneuerung und Archiv nie gegenseitig
 * blockieren, aber wenig genug, dass nicht bei jedem Aussetzer ein Schwarm neuer Verbindungen
 * aufgemacht wird. scheduling 'fifo' nimmt die aelteste freie Verbindung — die ist am
 * wahrscheinlichsten noch warm.
 */
const AGENT_HTTPS = new https.Agent({ keepAlive: true, keepAliveMsecs: 15000, maxSockets: 4, scheduling: 'fifo' });
const AGENT_HTTP = new http.Agent({ keepAlive: true, keepAliveMsecs: 15000, maxSockets: 4, scheduling: 'fifo' });

// ---- klinische Engine (fuer die Fern-Prioritaet/Top-Befund je Patient) ----
// UMD-Module laufen auch in Node (siehe ui/engine/*.js). Faellt sauber aus, wenn nicht ladbar.
let brain = null, anaes = null, ANAES = null;
try {
  brain = require('../../ui/engine/brain.js');
  anaes = require('./anaes.js');
  ANAES = anaes.loadAnaes();
} catch (_) { /* Enrichment optional — ohne Engine werden Rohwerte ohne pri/top gesendet */ }

const IDENTITY = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword';
const SECURETOKEN = 'https://securetoken.googleapis.com/v1/token';
const FIRESTORE = 'https://firestore.googleapis.com/v1';

// Aktuelle Fassung des Fern-Datenformats. Die Web-App liest sie aus meta.v.
// v3 = Praxis-Konten: der Datenpfad ist die Anmelde-Kennung, es gibt keinen Zugangscode mehr.
const FORMAT_V = 3;

function sanitizeKey(s) {
  // RTDB-Schluessel + URL-Parameter: nur unbedenkliche Zeichen zulassen (Rest -> _).
  return String(s == null ? '' : s).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 200) || '_';
}
function nowSec() { return Math.floor(Date.now() / 1000); }
function nn(x) { return (x == null || Number.isNaN(x)) ? null : x; }

/*
 * Abtastwerte platzsparend kodieren.
 * Ein EKG-Streifen sind 512 Zahlen. Als JSON-Liste (["-123.4",...]) sind das je nach Verstaerkung
 * 2,5-4 KB; als Int16 mit gemeinsamem Skalenfaktor und Base64 rund 1,4 KB - und zwar mit FESTER
 * Groesse, unabhaengig davon wie "krumm" die Werte sind. Bei 256 Hz EKG + 40 Hz CO2 im Dauerbetrieb
 * ergibt das ca. 0,8 KB/s, also gut 2 GB im Monat - das passt in den kostenlosen Spark-Tarif
 * (10 GB/Monat), waehrend die JSON-Variante ihn gerissen haette.
 */
function encodeSamples(samples) {
  const n = samples.length;
  let max = 0;
  for (let i = 0; i < n; i++) {
    const s = samples[i];
    if (s != null && Number.isFinite(s)) { const a = Math.abs(s); if (a > max) max = a; }
  }
  const skala = max > 0 ? max / 32000 : 1;
  const buf = Buffer.allocUnsafe(n * 2);
  for (let i = 0; i < n; i++) {
    const s = samples[i];
    let q = (s == null || !Number.isFinite(s)) ? 0 : Math.round(s / skala);
    if (q > 32767) q = 32767; else if (q < -32768) q = -32768;
    buf.writeInt16LE(q, i * 2);
  }
  return { n: n, skala: skala, b64: buf.toString('base64') };
}

// Billiger Hash ueber Stuetzstellen — identisch zu matching.kurvenChecksum, damit lokale und ferne
// Ansicht denselben Streifen als "neu" erkennen.
function kurvenChecksum(samples) {
  if (!samples || !samples.length) return 0;
  const n = samples.length;
  const a = samples[0] || 0, b = samples[n - 1] || 0, c = samples[n >> 1] || 0;
  return (((a * 31 + b) * 31 + c) | 0);
}

class CloudPublisher {
  /*
   * cfg = {
   *   enabled, provider:'firebase',
   *   apiKey,            // Firebase Web-API-Key (oeffentlich)
   *   dbUrl,             // z.B. https://vet-station-default-rtdb.europe-west1.firebasedatabase.app
   *   email,             // Anmeldename des PRAXIS-Kontos (das Passwort steht NICHT hier, siehe unten)
   *   station,           // Anzeigename der Station ("Praxis OP 1")
   *   minIntervalMs,     // Mindestabstand zweier Schreibvorgaenge (Default 200, Minimum 100)
   *   vollbildMs,        // Abstand eines Sicherheits-Vollbildes (Default 30000)
   *   kurven,            // echte Abtastwerte mituebertragen (Default true)
   *   rohwerte,          // alle Einzelwerte des Geraets mituebertragen (Default true)
   *   stammdaten,        // Tiername + Patientenakte mituebertragen (Default TRUE, siehe unten)
   *   archiv: { enabled, intervalMs, projectId },   // Firestore-Verlauf
   *   authFile           // Pfad zur persistenten Token-Datei (Default data/cloud-auth.json)
   * }
   *
   * DAS PASSWORT GEHOERT NICHT IN DIE KONFIGURATION. Es wird EINMAL im Admin-Bereich der
   * Station eingegeben (oder ueber die Umgebungsvariable VETSTATION_PASSWORT bei automatischer
   * Einrichtung). Aus der Anmeldung entsteht ein Erneuerungs-Token, der in data/cloud-auth.json
   * liegt und Neustarts ueberdauert — das Passwort selbst wird nirgends gespeichert.
   * devices.json waere dafuer der falsche Ort: die Datei wird bei "Auf USB kopieren" mitgenommen
   * und liegt im Klartext auf dem Praxis-PC.
   */
  constructor(cfg, { log } = {}) {
    this.cfg = cfg || {};
    this.log = log || { info() {}, warn() {}, error() {} };
    this.provider = this.cfg.provider || 'firebase';
    this.identityUrl = this.cfg.identityUrl || IDENTITY;   // fuer Tests ueberschreibbar
    this.tokenUrl = this.cfg.tokenUrl || SECURETOKEN;
    this.firestoreUrl = this.cfg.firestoreUrl || FIRESTORE;
    this.station = this.cfg.station || 'VetStation';
    this.email = String(this.cfg.email || '').trim();
    /*
     * STAMMDATEN JETZT STANDARDMAESSIG AN (geaendert 27.07.2026 mit Einfuehrung der Praxis-Konten).
     * Solange der Fern-Zugang an einem weiterleitbaren Link hing, waere es falsch gewesen,
     * Tiername und Besitzerdaten mitzuschicken. Seit die Daten ausschliesslich unter der
     * Anmelde-Kennung der eigenen Praxis liegen und nur diese Praxis sie lesen kann, sind es
     * IHRE eigenen Daten in IHREM eigenen Konto — dann gehoert der Tiername auch aufs Protokoll,
     * sonst waere der Ausdruck als Dokument wertlos. Abschaltbar bleibt es trotzdem.
     */
    this.sendeStammdaten = this.cfg.stammdaten !== false;
    // 100 ms Untergrenze: schneller ist sinnlos (die Geraete liefern deutlich traeger) und wuerde
    // nur Bandbreite und Freikontingent verbrennen.
    this.minInterval = Math.max(100, Number(this.cfg.minIntervalMs) || 200);
    this.vollbildMs = Math.max(5000, Number(this.cfg.vollbildMs) || 30000);
    this.sendeKurven = this.cfg.kurven !== false;
    this.sendeRohwerte = this.cfg.rohwerte !== false;
    this.authFile = this.cfg.authFile || path.join(__dirname, '..', '..', 'data', 'cloud-auth.json');

    const arch = this.cfg.archiv || {};
    this.archiv = {
      enabled: arch.enabled !== false,
      intervalMs: Math.max(5000, Number(arch.intervalMs) || 15000),
      projectId: arch.projectId || this.cfg.projectId || this._projektAusDbUrl(),
    };
    this.letztesArchiv = 0;
    this.archivInFlight = false;
    this.archivFehler = null;
    this.archivAus = false;      // nach wiederholten Konfigurationsfehlern: Archiv still abschalten
    this.archivFehlerZahl = 0;
    this.archivGeschrieben = 0;

    this.idToken = null;
    this.refreshToken = null;
    this.localId = null;
    this.tokenExp = 0;          // Unix-Sekunden
    this.lastPublish = 0;       // ms
    this.inFlight = false;
    this.authFailAt = 0;        // Backoff nach Auth-Fehlern
    this.started = false;
    this.lastError = null;

    // Delta-Buchhaltung: letzter tatsaechlich uebertragener Stand, je Pfad als JSON-Text.
    this._gesendet = null;      // Map Pfad -> JSON-Text
    this._letztesVollbild = 0;
    this._letzterSchreibvorgang = 0;
    // Herzschlag: Mindesttakt, in dem meta.ts auch dann geschrieben wird, wenn sich sonst nichts
    // geaendert hat (die Web-App misst daran, ob der Praxis-PC noch lebt).
    this.herzschlagMs = Math.max(1000, Number(this.cfg.herzschlagMs) || 2000);
    this._kurvenSigGesendet = {};   // patientKey -> zuletzt uebertragene Kurvensignatur
    this._protokollGesendet = {};   // patientId -> Set der bereits uebertragenen Zeitpunkte
    this.bytesGesendet = 0;
    this.schreibVorgaenge = 0;
    this.protokollGesendet = 0;     // Zaehler fuer den Admin-Bereich

    // Selbstschutz gegen Log-Flutung (Befund 2.2, 21.07.2026): bei nicht erreichbarer Datenbank
    // schrieb der Publisher ~2 Fehlerzeilen pro Sekunde und verdraengte nach vier Minuten
    // SAEMTLICHE Verbindungsmeldungen aus dem Ringpuffer. Jetzt: wachsende Wartezeit und nach
    // drei KONFIGURATIONSfehlern (die sich von selbst nie beheben) Selbstabschaltung mit Begruendung.
    this.backoffMs = 0;          // aktuelle Zwangspause nach einem Fehler
    this.naechsterVersuch = 0;   // Zeitpunkt, ab dem wieder geschrieben werden darf
    this.konfigFehler = 0;       // Zaehler NUR fuer nicht selbstheilende Fehler
    this.abgeschaltet = false;
    this.abschaltGrund = null;
  }

  _projektAusDbUrl() {
    // https://vet-station-default-rtdb.europe-west1.firebasedatabase.app -> vet-station
    const m = /^https?:\/\/([a-z0-9-]+?)-default-rtdb\./i.exec(String(this.cfg.dbUrl || ''));
    return m ? m[1] : null;
  }

  // Unterscheidet Fehler, die sich von selbst erledigen koennen (Netz weg, Zeitueberschreitung),
  // von solchen, die ohne Eingriff NIE verschwinden (Datenbank existiert nicht, Regeln verbieten
  // das Schreiben, Adresse falsch geschrieben). Nur letztere fuehren zur Selbstabschaltung.
  static _istKonfigFehler(msg) {
    return /HTTP 40[01349]|ENOTFOUND|EAI_AGAIN|URL ungueltig|PERMISSION_DENIED/i.test(String(msg || ''));
  }

  // Der Fern-Zugang ist jetzt eine reine Anmeldung — es gibt keinen Code mehr im Link.
  // Der Tierarzt oeffnet die Web-App und meldet sich mit DEMSELBEN Praxis-Konto an.
  shareUrl(base) {
    return base || 'https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/';
  }

  // Ist die Praxis angemeldet (gueltiges Token oder wenigstens ein Erneuerungs-Token)?
  angemeldet() {
    return !!(this.localId && (this.refreshToken || (this.idToken && this.tokenExp > nowSec())));
  }

  start() {
    if (this.started) return;
    if (!this.cfg.enabled) { this.log.info('cloud', 'Fern-Live deaktiviert (cloud.enabled=false).'); return; }
    if (this.provider !== 'firebase') { this.log.warn('cloud', 'Unbekannter Provider "' + this.provider + '" — nur "firebase" unterstuetzt.'); return; }
    if (!this.cfg.apiKey || !this.cfg.dbUrl) {
      this.log.warn('cloud', 'Fern-Live: apiKey/dbUrl fehlen in der Konfiguration (cloud-Block). Uebertragung aus.');
      return;
    }
    this._loadAuth();
    this._gesendet = null;   // beim Start immer ein Vollbild
    // started erst NACH der Anmeldepruefung setzen: "gestartet" soll heissen "sendet tatsaechlich".
    // Sonst meldet der Admin-Bereich eine laufende Uebertragung, die es gar nicht gibt.
    if (!this.angemeldet()) {
      this.log.warn('cloud', 'Fern-Live wartet auf die PRAXIS-ANMELDUNG. ' +
        'Im Admin-Bereich unter "📡 Fern-Live" mit dem Praxis-Konto anmelden — danach laeuft die ' +
        'Uebertragung automatisch, auch nach jedem Neustart. Bis dahin wird nichts gesendet ' +
        '(die Geraeteanzeige vor Ort ist davon nicht betroffen).');
      return;
    }
    this.started = true;
    this.log.info('cloud', 'Fern-Live AKTIV als "' + (this.email || this.localId) + '", Takt ' +
      this.minInterval + ' ms' + (this.sendeKurven ? ', mit echten Kurven' : '') + '.');
    this.log.info('cloud', 'Fern ansehen: ' + this.shareUrl() + ' — dort mit DEMSELBEN Praxis-Konto anmelden.');
    if (!this.sendeStammdaten) {
      this.log.info('cloud', 'Fern-Live: Tiername/Patientenakte werden NICHT uebertragen (cloud.stammdaten=false).');
    }
    if (this.archiv.enabled && this.archiv.projectId) {
      this.log.info('cloud', 'Firestore-Verlauf aktiv: alle ' + Math.round(this.archiv.intervalMs / 1000) + ' s.');
    }
  }

  /*
   * status(privat) — Zustand fuer die Anzeige.
   *
   * OHNE privat=true bleiben Anmeldename und Kennung DRAUSSEN. Grund: /api/cloud antwortet mit
   * "Access-Control-Allow-Origin: *", das heisst JEDE beliebige Webseite, die im Browser des
   * Praxis-PCs geoeffnet ist, kann diese Antwort auslesen. Was dort steht, ist damit faktisch
   * oeffentlich. Anmeldename und Kennung gehen deshalb nur ueber den auf 127.0.0.1 beschraenkten
   * Endpunkt /api/praxis heraus.
   */
  status(privat) {
    const s = {
      enabled: !!this.cfg.enabled, provider: this.provider, started: this.started,
      station: this.station, url: this.shareUrl(),
      angemeldet: this.angemeldet(),
      authed: this.angemeldet(),
      lastPublish: this.lastPublish, lastError: this.lastError,
      abgeschaltet: this.abgeschaltet, abschaltGrund: this.abschaltGrund,
      backoffMs: this.backoffMs,
      taktMs: this.minInterval, formatV: FORMAT_V,
      kurven: this.sendeKurven, rohwerte: this.sendeRohwerte, stammdaten: this.sendeStammdaten,
      schreibVorgaenge: this.schreibVorgaenge, bytesGesendet: this.bytesGesendet,
      protokollGesendet: this.protokollGesendet,
      archiv: {
        enabled: this.archiv.enabled && !this.archivAus, projectId: this.archiv.projectId,
        intervalMs: this.archiv.intervalMs,
        geschrieben: this.archivGeschrieben, lastError: this.archivFehler,
      },
    };
    if (privat) { s.email = this.email || null; s.uid = this.localId || null; }
    return s;
  }

  /*
   * anmelden(email, passwort) — einmalige Praxis-Anmeldung aus dem Admin-Bereich.
   * Danach traegt der Erneuerungs-Token die Station ueber alle Neustarts; das Passwort wird
   * NICHT gespeichert. Setzt ausserdem die Fehlerzaehler zurueck, damit ein vorher falsch
   * eingegebenes Passwort die Uebertragung nicht dauerhaft stillgelegt laesst.
   */
  async anmelden(email, passwort) {
    const mail = String(email || '').trim();
    if (!mail || !passwort) throw new Error('E-Mail und Passwort werden beide gebraucht.');
    if (!this.cfg.apiKey) throw new Error('In der Konfiguration fehlt der Firebase-Schluessel (cloud.apiKey).');
    this.email = mail;
    this.idToken = null; this.refreshToken = null; this.localId = null; this.tokenExp = 0;
    await this._signIn(passwort);
    // Nach erfolgreicher Anmeldung alles zuruecksetzen, was eine fruehere Fehlkonfiguration
    // hinterlassen hat — sonst bliebe die Station trotz gueltiger Anmeldung abgeschaltet.
    this.abgeschaltet = false; this.abschaltGrund = null;
    this.konfigFehler = 0; this.backoffMs = 0; this.naechsterVersuch = 0;
    this.authFailAt = 0; this.lastError = null;
    this.archivAus = false; this.archivFehler = null; this.archivFehlerZahl = 0;
    this._gesendet = null;             // naechster Schreibvorgang ist ein Vollbild
    this._protokollGesendet = {};
    this._kurvenSigGesendet = {};
    this.started = !!this.cfg.enabled;
    this.log.info('cloud', 'Praxis angemeldet: ' + this.email + '. Fern-Live sendet ab sofort.');
    return this.status(true);
  }

  /*
   * anmeldenMitToken(refreshToken, uid, email) — Anmeldung mit dem GOOGLE-Konto.
   *
   * WARUM DIESER UMWEG: Eine Google-Anmeldung laeuft ueber die Zustimmungsseite von Google und
   * braucht dafuer einen Browser. Der Praxis-PC hat einen — die Oberflaeche der Station LAEUFT ja
   * in einem. Der Browser meldet sich also an, und die Bridge bekommt anschliessend nur noch die
   * Erneuerungs-Kennung. Der Alternativweg waere ein eigener OAuth-Client mit Geraete-Anmeldung
   * in Node gewesen: mehr Teile, mehr Fehlerquellen, und der Tierarzt haette Codes abtippen muessen.
   *
   * Die uebergebene Kennung wird NICHT geglaubt, sondern nachgeprueft: _refresh() tauscht den
   * Token bei Google gegen ein frisches Zugangs-Token und liefert die Kennung aus erster Hand.
   * Ohne diese Probe koennte ein beliebiger Fremdtoken hier landen und die Station wuerde in
   * einen fremden Datenpfad schreiben.
   */
  async anmeldenMitToken(refreshToken, uid, email) {
    if (!refreshToken) throw new Error('Es kam keine Anmeldung vom Browser an.');
    if (!this.cfg.apiKey) throw new Error('In der Konfiguration fehlt der Firebase-Schluessel (cloud.apiKey).');
    const vorher = { r: this.refreshToken, u: this.localId, e: this.email };
    this.refreshToken = refreshToken;
    this.localId = uid || null;
    if (email) this.email = String(email).trim();
    this.idToken = null; this.tokenExp = 0;
    try {
      await this._refresh();                       // Probe + massgebliche Kennung
    } catch (e) {
      // Bei einem ungueltigen Token die vorherige Anmeldung nicht zerstoeren.
      this.refreshToken = vorher.r; this.localId = vorher.u; this.email = vorher.e;
      throw new Error('Die Anmeldung wurde von Google nicht bestaetigt: ' + e.message);
    }
    this.abgeschaltet = false; this.abschaltGrund = null;
    this.konfigFehler = 0; this.backoffMs = 0; this.naechsterVersuch = 0;
    this.authFailAt = 0; this.lastError = null;
    this.archivAus = false; this.archivFehler = null; this.archivFehlerZahl = 0;
    this._gesendet = null;
    this._protokollGesendet = {};
    this._kurvenSigGesendet = {};
    this.started = !!this.cfg.enabled;
    this.log.info('cloud', 'Praxis ueber Google angemeldet: ' + (this.email || this.localId) + '. Fern-Live sendet ab sofort.');
    return this.status(true);
  }

  // Abmelden: Token verwerfen und die gespeicherte Anmeldung loeschen.
  abmelden() {
    this.idToken = null; this.refreshToken = null; this.localId = null; this.tokenExp = 0;
    this.started = false;
    try { fs.unlinkSync(this.authFile); } catch (_) { /* war nie da */ }
    this.log.info('cloud', 'Praxis abgemeldet — es wird nichts mehr ins Internet uebertragen.');
    return this.status(true);
  }

  /*
   * Wird aus dem Takt der Bridge aufgerufen.
   *   patients   = registry.getPatients()
   *   devices    = registry.getDevices()   — Status/Adresse/Sendetakt je Geraet
   *   protokoll  = registry.protokollFuerCloud()  — { patientId: [ {ts, ...}, ... ] }
   */
  publish(patients, devices, protokoll) {
    if (!this.started) return;
    if (!this.angemeldet()) return;          // ohne Praxis-Anmeldung wird nichts uebertragen
    const now = Date.now();
    if (this.inFlight) return;
    if (now < this.naechsterVersuch) return;                      // wachsende Pause nach Fehlern
    if (now - this.lastPublish < this.minInterval) return;
    if (this.authFailAt && now - this.authFailAt < 15000) return; // Backoff
    this.lastPublish = now;
    this.inFlight = true;
    this._publizieren(patients || [], devices || [], protokoll || {}, now)
      .catch((e) => this._fehler(e))
      .then(() => { this.inFlight = false; });
  }

  /*
   * REIHENFOLGE IST HIER SICHERHEITSRELEVANT (Befund 27.07.2026):
   * Die Anmeldung muss VOR dem Zusammenbauen des Datensatzes stehen. Vorher lief es umgekehrt —
   * beim allerersten Schreibvorgang stand die eigene Kennung (localId) also noch nicht fest, und
   * der Zielpfad /live/<kennung> waere "/live/null" gewesen. Die Regel haette das mit HTTP 401
   * abgelehnt, und drei solche Ablehnungen schalten die Uebertragung dauerhaft ab.
   */
  async _publizieren(patients, devices, protokoll, now) {
    const tok = await this._ensureAuth();
    const ziel = '/live/' + this.localId + '.json?auth=' + encodeURIComponent(tok);

    const snapshot = this._buildSnapshot(patients, devices);
    // Neue Protokolleintraege heraussuchen, BEVOR ueber "nichts zu tun" entschieden wird.
    const protPfade = this._protokollPfade(protokoll);

    // Vollbild, wenn noch nie geschrieben wurde oder das Sicherheitsintervall abgelaufen ist.
    // Das Sicherheits-Vollbild raeumt Reste auf, falls ein PATCH je verloren ging.
    const vollbild = !this._gesendet || (now - this._letztesVollbild >= this.vollbildMs);
    const plan = vollbild ? null : this._delta(snapshot);
    if (plan && !Object.keys(protPfade).length) {
      const keys = Object.keys(plan);
      /*
       * meta.ts ist ein HERZSCHLAG: die Web-App erkennt daran, dass der Praxis-PC noch sendet
       * ("keine neuen Daten seit X s"). Er aendert sich per Definition in JEDEM Takt - ohne
       * Sonderbehandlung gaebe es also selbst im leeren OP alle 200 ms einen Schreibvorgang, und
       * die ganze Delta-Ersparnis waere dahin. Deshalb: wenn sich AUSSER dem Herzschlag nichts
       * geaendert hat, wird er nur alle paar Sekunden geschrieben. Aendert sich ein echter Wert,
       * geht er ohnehin im selben Schreibvorgang mit.
       */
      const nurHerzschlag = keys.length > 0 && keys.every((k) => k === 'meta/ts');
      if (keys.length === 0 || (nurHerzschlag && now - this._letzterSchreibvorgang < this.herzschlagMs)) {
        await this._archivieren(snapshot, now, tok);
        return;
      }
    }

    /*
     * SERVER-ZEITSTEMPEL fuer die ECHTE Laufzeitmessung.
     *
     * meta.ts ist die Uhr des Praxis-PCs. Wer damit zu Hause die Verzoegerung ausrechnet, misst in
     * Wirklichkeit vor allem den Gangunterschied der beiden Uhren — liegt der PC eine Minute
     * daneben, steht dort "Verzoegerung 60 s", obwohl alles in 80 ms ankommt. Deshalb schreibt die
     * Datenbank zusaetzlich meta.sv SELBST: {".sv":"timestamp"} ist ein Platzhalter, den der
     * Firebase-Server beim Schreiben durch SEINE Zeit ersetzt. Die Web-App korrigiert ihre eigene
     * Uhr ueber /.info/serverTimeOffset gegen dieselbe Serverzeit und rechnet die Differenz — das
     * ist die tatsaechliche Strecke Praxis -> Datenbank -> Zuhause, unabhaengig von beiden Uhren.
     *
     * Der Platzhalter haengt bewusst AUSSERHALB des Delta-Vergleichs: er soll jeden Schreibvorgang
     * frisch stempeln, aber niemals selbst einen ausloesen.
     */
    const SV = { '.sv': 'timestamp' };
    /*
     * Auch das Vollbild geht als PATCH, nicht als PUT.
     * PUT wuerde den GANZEN Knoten ersetzen — und damit das OP-Protokoll mit loeschen, das
     * daneben unter protokoll/ liegt. Ein PATCH auf oberster Ebene ersetzt dagegen genau die
     * genannten Kinder (meta und patients werden vollstaendig neu geschrieben), waehrend
     * protokoll/ unberuehrt stehen bleibt. Das ist genau die gewuenschte Wirkung.
     */
    const body = vollbild
      ? { meta: Object.assign({}, snapshot.meta, { sv: SV }), patients: snapshot.patients }
      : Object.assign({}, plan, { 'meta/sv': SV });
    Object.assign(body, protPfade);

    await this._write('PATCH', ziel, body);

    if (this.lastError) this.log.info('cloud', 'Fern-Live schreibt wieder.');
    this.lastError = null; this.backoffMs = 0; this.naechsterVersuch = 0; this.konfigFehler = 0;
    this._merken(snapshot);
    this._protokollMerken(protPfade);
    this._letzterSchreibvorgang = now;
    if (vollbild) this._letztesVollbild = now;

    await this._archivieren(snapshot, now, tok);
  }

  /*
   * Neue Protokolleintraege als EINZELNE tiefe Pfade.
   *
   * WARUM NICHT ALS LISTE: _pfade() flacht je Patient nur eine Ebene ab. Ein Feld
   * "protokoll: [ ... ]" wuerde deshalb bei JEDEM neuen Eintrag die KOMPLETTE Liste erneut
   * uebertragen — bei 1200 Eintraegen also jedes Mal ein paar hundert Kilobyte. Als einzelne
   * Pfade protokoll/<patient>/<zeitpunkt> geht dagegen nur der neue Eintrag ueber die Leitung,
   * und die Regel kann ihn zugleich unveraenderlich machen (".validate": "!data.exists()").
   */
  _protokollPfade(protokoll) {
    const out = {};
    if (!protokoll) return out;
    for (const pid in protokoll) {
      const key = sanitizeKey(pid);
      const gesendet = this._protokollGesendet[key] || (this._protokollGesendet[key] = {});
      const liste = protokoll[pid] || [];
      for (const e of liste) {
        if (!e || e.ts == null) continue;
        const ts = String(e.ts);
        if (gesendet[ts]) continue;
        out['protokoll/' + key + '/' + ts] = e;
      }
    }
    return out;
  }

  _protokollMerken(protPfade) {
    for (const pfad in protPfade) {
      const m = /^protokoll\/([^/]+)\/(\d+)$/.exec(pfad);
      if (!m) continue;
      (this._protokollGesendet[m[1]] || (this._protokollGesendet[m[1]] = {}))[m[2]] = 1;
      this.protokollGesendet++;
    }
  }

  _write(method, pathAndQuery, obj) {
    const url = this.cfg.dbUrl.replace(/\/+$/, '') + pathAndQuery;
    const text = JSON.stringify(obj);
    this.bytesGesendet += Buffer.byteLength(text);
    this.schreibVorgaenge++;
    return this._reqJson(method, url, text, { 'Content-Type': 'application/json' });
  }

  // ---------- Delta ----------
  /*
   * Zerlegt den Snapshot in flache RTDB-Pfade und vergleicht sie mit dem zuletzt uebertragenen
   * Stand. Zurueck kommt ein PATCH-Koerper mit TIEFEN Schluesseln, z. B.
   *   { "meta/ts": 1753..., "patients/id_1234/vitals": {...} }
   * Die Realtime Database wendet solche Schluessel als Pfad an (update()-Semantik) - so wird
   * wirklich nur der geaenderte Teilbaum geschrieben.
   */
  _pfade(snapshot) {
    const map = new Map();
    for (const k in snapshot.meta) map.set('meta/' + k, snapshot.meta[k]);
    const pats = snapshot.patients || {};
    for (const key in pats) {
      const p = pats[key];
      for (const f in p) map.set('patients/' + key + '/' + f, p[f]);
    }
    return map;
  }

  _delta(snapshot) {
    const neu = this._pfade(snapshot);
    const alt = this._gesendet || new Map();
    const out = {};
    for (const [pfad, wert] of neu) {
      const t = JSON.stringify(wert === undefined ? null : wert);
      if (alt.get(pfad) !== t) out[pfad] = wert === undefined ? null : wert;
    }
    // Verschwundene Patienten/Felder ausdruecklich loeschen, sonst bleiben Karteileichen stehen
    // und die Fern-Ansicht zeigt einen Patienten, der laengst abgehaengt ist.
    const entferntePatienten = new Set();
    for (const pfad of alt.keys()) {
      if (neu.has(pfad)) continue;
      const m = /^patients\/([^/]+)\//.exec(pfad);
      if (m) {
        if (snapshot.patients && Object.prototype.hasOwnProperty.call(snapshot.patients, m[1])) {
          out[pfad] = null;                 // Patient bleibt, aber das Feld ist weggefallen
        } else if (!entferntePatienten.has(m[1])) {
          entferntePatienten.add(m[1]);
          out['patients/' + m[1]] = null;   // ganzer Patient weg
        }
      } else {
        out[pfad] = null;
      }
    }
    // Aufgeraeumt: wenn ein ganzer Patient geloescht wird, sind seine Einzelfelder ueberfluessig.
    for (const key of entferntePatienten) {
      for (const pfad of Object.keys(out)) {
        if (pfad.indexOf('patients/' + key + '/') === 0) delete out[pfad];
      }
    }
    return out;
  }

  _merken(snapshot) {
    const m = new Map();
    for (const [pfad, wert] of this._pfade(snapshot)) {
      m.set(pfad, JSON.stringify(wert === undefined ? null : wert));
    }
    this._gesendet = m;
  }

  // ---------- Snapshot ----------
  _buildSnapshot(patients, devices) {
    const out = {};
    let count = 0;
    const devById = {};
    (devices || []).forEach((d) => { if (d && d.deviceId) devById[d.deviceId] = d; });

    for (const p of patients) {
      const key = sanitizeKey(p.patientKey || ('dev:' + (p.devices && p.devices[0] && p.devices[0].deviceId)));
      const v = p.vitals || {};
      /*
       * ALLE Vitalfelder statt einer Positivliste. Die alte Fassung zaehlte die Felder einzeln auf -
       * jedes neue Messfeld (z. B. PEEP, FiO2, Pulsdruck) waere fern unsichtbar geblieben, ohne dass
       * es irgendwo aufgefallen waere. Jetzt geht alles mit, was einfacher Wert ist.
       */
      const vitals = {};
      for (const f in v) {
        const val = v[f];
        if (val == null) { vitals[f] = null; continue; }
        const t = typeof val;
        if (t === 'number') vitals[f] = Number.isNaN(val) ? null : val;
        else if (t === 'string' || t === 'boolean') vitals[f] = val;
        // verschachtelte Objekte (nibp) sind in mergePatients bereits flachgezogen
      }
      // Sicherstellen, dass die Felder, die die Web-App fest erwartet, immer existieren
      // (auch als null) - sonst blinkt die Fern-Anzeige zwischen "kein Wert" und "Feld fehlt".
      ['hr', 'spo2', 'etco2', 'fico2', 'af', 'sys', 'dia', 'map', 'temp', 'paw',
        'ekgRhythm', 'capnoShape', 'pleth'].forEach((f) => { if (!(f in vitals)) vitals[f] = null; });

      const rec = {
        patientId: p.patientId || null,
        species: p.species || null,
        weightKg: p.weightKg != null ? p.weightKg : null,
        isoPct: p.isoPct != null ? p.isoPct : null,
        ventMode: p.ventMode || null,
        o2Flow: p.o2Flow != null ? p.o2Flow : null,
        ventParams: (p.ventParams && typeof p.ventParams === 'object') ? p.ventParams : null,
        ts: p.ts || Date.now(),
        vitals: vitals,
        alarms: Array.isArray(p.alarms) ? p.alarms.slice(0, 30) : [],
        devices: (p.devices || []).map((d) => {
          const reg = devById[d.deviceId] || {};
          return {
            model: d.model || '?', role: d.role || 'monitor',
            status: reg.status || d.status || null,
            ip: d.ip || reg.ip || null, port: d.port || reg.port || null,
            transport: reg.transport || null,
            taktMs: reg.taktMs != null ? reg.taktMs : null,
            sekundenSeitDaten: reg.sekundenSeitDaten != null ? reg.sekundenSeitDaten : null,
            werteAnzahl: reg.werteAnzahl != null ? reg.werteAnzahl : null,
          };
        }),
        // Neu fern verfuegbar:
        afSource: p.afSource || null,                 // Kapnograf oder Monitor — steht am AF-Kaestchen
        ekgAnalyse: p.ekgAnalyse || null,             // QRS-Breite, Rhythmus, ST — die eigentliche Aussage
        gebDatum: p.gebDatum || null,
        geschlecht: p.geschlecht || null,
        herkunft: p.herkunft || null,                 // woher Tierart/Gewicht stammen (Geraet/Hand)
        manual: !!p.manual,
        kurvenNamen: Array.isArray(p.kurven) ? p.kurven.slice(0, 10) : [],
      };

      // Patientenakte + Tiername NUR auf ausdruecklichen Wunsch (Datenschutz, siehe Kopf).
      if (this.sendeStammdaten) {
        rec.patientName = p.patientName || null;
        rec.akte = (p.akte && typeof p.akte === 'object') ? p.akte : null;
      }

      // Alle Einzelwerte des Geraets ("Alle Werte vom Geraet"-Ansicht auch fern).
      if (this.sendeRohwerte && Array.isArray(p.roh) && p.roh.length) {
        rec.roh = p.roh.slice(0, 80).map((r) => ({
          code: r.code != null ? r.code : null,
          label: r.label != null ? String(r.label).slice(0, 60) : null,
          wert: r.wert != null ? r.wert : (r.value != null ? r.value : null),
          einheit: r.einheit || r.unit || null,
          von: r.von || null, modell: r.modell || null,
        }));
      }

      // ECHTE KURVEN: Signatur immer, Abtastwerte nur bei Aenderung (= je Streifen genau einmal).
      const kd = Array.isArray(p.kurvenDaten) ? p.kurvenDaten : [];
      const sig = kd
        .map((k) => (k.code || '') + ':' + (k.hz || '') + ':' + (k.samples ? k.samples.length : 0) + ':' + kurvenChecksum(k.samples))
        .join('|') || null;
      rec.kurvenSig = sig;
      if (this.sendeKurven && sig) {
        if (this._kurvenSigGesendet[key] !== sig) {
          const kv = {};
          kd.slice(0, 4).forEach((k) => {
            if (!k || !Array.isArray(k.samples) || !k.samples.length) return;
            const enc = encodeSamples(k.samples);
            kv[sanitizeKey(k.code || k.name || 'kanal')] = {
              name: String(k.name || '').slice(0, 40),
              code: k.code || null,
              hz: k.hz != null ? k.hz : null,
              geraeteSkala: k.skala != null ? k.skala : null,
              n: enc.n, skala: enc.skala, b64: enc.b64,
              ts: p.ts || Date.now(),
            };
          });
          if (Object.keys(kv).length) {
            rec.kurven = kv;
            this._kurvenSigGesendet[key] = sig;
          }
        } else if (this._gesendet) {
          // Unveraendert: den bereits uebertragenen Streifen im Snapshot beibehalten, damit das
          // Delta ihn nicht faelschlich als "geloescht" meldet und neu schickt.
          const alt = this._gesendet.get('patients/' + key + '/kurven');
          if (alt !== undefined) { try { rec.kurven = JSON.parse(alt); } catch (_) { /* egal */ } }
        }
      }

      const res = this._assess(p);
      if (res) { rec.pri = res.pri; rec.top = res.top; }
      out[key] = rec;
      count++;
    }
    // Patienten, die verschwunden sind, verlieren auch ihren gemerkten Kurvenstand.
    for (const k in this._kurvenSigGesendet) { if (!(k in out)) delete this._kurvenSigGesendet[k]; }

    return {
      meta: {
        station: this.station, v: FORMAT_V, ts: Date.now(), count: count,
        taktMs: this.minInterval, kurven: this.sendeKurven,
      },
      patients: out,
    };
  }

  /*
   * befundTitel(p) — nur der Titel des Top-Befunds, fuer die Protokollfuehrung der Registry.
   * Bewusst DIESELBE Bewertung wie in der Fern-Ansicht: sonst stuende im Protokoll ein anderer
   * Befund als der, den der Tierarzt auf dem Bildschirm gesehen hat.
   */
  befundTitel(p) {
    const r = this._assess(p);
    return (r && r.top && r.top.title) ? r.top.title : null;
  }

  // Brain-Bewertung -> kompakte Fern-Zusammenfassung (Prioritaet + Top-Befund).
  _assess(p) {
    if (!brain || !ANAES) return null;
    try {
      const flat = Object.assign({ species: p.species || 'hund', weightKg: p.weightKg || 10, isoPct: p.isoPct }, p.vitals || {});
      const r = brain.assess(ANAES, flat, { iso: p.isoPct });
      const top = r.top ? { sev: r.top.sev || 0, title: r.top.title || '', tag: r.top.tag || '', fix: r.top.fix || '', incident: r.top.incident || null } : null;
      return { pri: Math.round((r.priority || 0) * 10) / 10, top: top };
    } catch (_) { return null; }
  }

  // ---------- Firestore-Verlauf (Archiv) ----------
  /*
   * Der Live-Strom gehoert in die Realtime Database. Firestore bekommt parallel einen
   * VERLAUFSDATENSATZ im Ruhetakt - dafuer ist es gebaut (Abfragen ueber Zeitraeume, Fallakte,
   * spaetere Auswertung) und dort ist es auch bezahlbar.
   *
   * Der komplette Stand wandert als EIN JSON-Textfeld hinein (statt als typisierte Firestore-Felder):
   * das haelt den Schreibvorgang klein, ist gegen jede Formatserweiterung immun und kostet genau
   * einen Dokumentschreibvorgang. Die paar Felder, nach denen man spaeter WIRKLICH sucht
   * (Zeit, Station, Patientenzahl, hoechste Prioritaet), stehen zusaetzlich einzeln daneben.
   */
  _archivieren(snapshot, now, idToken) {
    if (!this.archiv.enabled || this.archivAus) return;
    if (!this.archiv.projectId || !this.cfg.apiKey || !idToken || !this.localId) return;
    if (this.archivInFlight) return;
    if (now - this.letztesArchiv < this.archiv.intervalMs) return;
    if (!snapshot.meta.count) return;                 // leere Station nicht archivieren
    this.letztesArchiv = now;
    this.archivInFlight = true;

    let maxPri = 0;
    for (const k in snapshot.patients) {
      const pr = snapshot.patients[k].pri;
      if (typeof pr === 'number' && pr > maxPri) maxPri = pr;
    }
    // Kurven gehoeren nicht ins Archiv (sie wuerden das Dokument sprengen und sind fuer die
    // Verlaufsauswertung ohne Wert - die Zahlen daneben sagen dasselbe).
    const ohneKurven = { meta: snapshot.meta, patients: {} };
    for (const k in snapshot.patients) {
      const p = Object.assign({}, snapshot.patients[k]);
      delete p.kurven;
      delete p.roh;
      ohneKurven.patients[k] = p;
    }

    const doc = {
      fields: {
        ts: { integerValue: String(snapshot.meta.ts) },
        zeit: { timestampValue: new Date(snapshot.meta.ts).toISOString() },
        station: { stringValue: this.station },
        patienten: { integerValue: String(snapshot.meta.count) },
        prioritaet: { doubleValue: maxPri },
        daten: { stringValue: JSON.stringify(ohneKurven) },
      },
    };
    /*
     * Der Verlauf haengt unter praxen/<Anmelde-Kennung>/verlauf und wird MIT ANMELDUNG geschrieben.
     * Frueher genuegte der oeffentliche API-Schluessel — der steht aber zwangslaeufig auch in der
     * oeffentlichen Web-App, also konnte jeder Fremde Dokumente anlegen. Im kostenlosen Tarif gilt
     * das Kontingent fuer das GESAMTE Projekt: ein einzelner Angreifer haette damit den Verlauf
     * ALLER Praxen lahmlegen koennen. Firestore nimmt das Anmelde-Token als Bearer-Kopfzeile.
     */
    const url = this.firestoreUrl + '/projects/' + encodeURIComponent(this.archiv.projectId) +
      '/databases/(default)/documents/praxen/' + encodeURIComponent(this.localId) + '/verlauf' +
      '?key=' + encodeURIComponent(this.cfg.apiKey);

    this._reqJson('POST', url, JSON.stringify(doc), {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + idToken,
    })
      .then(() => {
        this.archivGeschrieben++;
        if (this.archivFehler) this.log.info('cloud', 'Firestore-Verlauf schreibt wieder.');
        this.archivFehler = null; this.archivFehlerZahl = 0;
      })
      .catch((e) => {
        this.archivFehler = e && e.message ? e.message : String(e);
        this.archivFehlerZahl++;
        // Das Archiv ist eine Zugabe — es darf die LIVE-Uebertragung niemals stoeren oder das Log
        // zumuellen. Nach drei nicht selbstheilenden Fehlern still abschalten, einmal begruenden.
        if (CloudPublisher._istKonfigFehler(this.archivFehler) && this.archivFehlerZahl >= 3) {
          this.archivAus = true;
          this.log.warn('cloud', 'Firestore-Verlauf abgeschaltet: ' + this.archivFehler +
            ' — die Firestore-Regeln fehlen vermutlich (installer/firestore-rules.txt). ' +
            'Die LIVE-Uebertragung laeuft davon unberuehrt weiter.');
        }
      })
      .then(() => { this.archivInFlight = false; });
  }

  _fehler(e) {
    this.lastError = e && e.message ? e.message : String(e);
    // Nach einem Fehler ist der gemerkte Stand nicht mehr verlaesslich -> naechster Versuch als
    // Vollbild, sonst wuerde ein verlorener PATCH dauerhaft fehlen.
    this._gesendet = null;
    // Wartezeit verdoppeln: 2 s -> 4 -> 8 ... max. 60 s. Der Logger fasst identische Meldungen
    // ausserdem zu EINER Zeile zusammen, sodass das Diagnose-Log brauchbar bleibt.
    this.backoffMs = this.backoffMs ? Math.min(this.backoffMs * 2, 60000) : 2000;
    this.naechsterVersuch = Date.now() + this.backoffMs;
    this.log.warn('cloud', 'Fern-Live Schreibfehler: ' + this.lastError +
      ' — naechster Versuch in ' + Math.round(this.backoffMs / 1000) + ' s.');

    if (/401|403|token|auth|credential/i.test(this.lastError)) {
      this.idToken = null; this.tokenExp = 0; this.authFailAt = Date.now();
    }

    /*
     * Eine fehlende oder abgelaufene Anmeldung ist KEIN Fall fuer die Selbstabschaltung: sie laesst
     * sich im Admin-Bereich mit zwei Eingaben beheben, und eine abgeschaltete Uebertragung wuerde
     * nach der Anmeldung erst nach einem Neustart wieder anlaufen. Sie faellt deshalb nur in die
     * wachsende Wartezeit.
     */
    if (/Nicht angemeldet/i.test(this.lastError)) return;

    if (CloudPublisher._istKonfigFehler(this.lastError)) {
      this.konfigFehler++;
      if (this.konfigFehler >= 3) this._selbstAbschalten();
    }
  }

  // Nach drei Konfigurationsfehlern in Folge: aufhoeren und im Klartext SAGEN warum. Weiterprobieren
  // waere sinnlos (die Ursache liegt in der Firebase-Konsole, nicht auf diesem PC) und wuerde nur
  // das Diagnose-Log zumuellen, das bei der Inbetriebnahme gebraucht wird.
  _selbstAbschalten() {
    this.started = false;
    this.abgeschaltet = true;
    const db404 = /HTTP 404/.test(String(this.lastError));
    this.abschaltGrund = db404
      ? 'Die Cloud-Datenbank antwortet mit HTTP 404 — sie ist in der Firebase-Konsole noch nicht angelegt.'
      : 'Dauerhafter Konfigurationsfehler: ' + this.lastError;
    this.log.warn('cloud', 'FERN-LIVE ABGESCHALTET. ' + this.abschaltGrund +
      ' Das betrifft NICHT die Geraeteverbindung — Vitaldaten werden weiterhin lokal angezeigt. ' +
      'Anleitung: docs\\FERN-LIVE.md. Danach VetStation neu starten (NEUSTART.bat).');
  }

  // ---------- Firebase-Anmeldung (Praxis-Konto, E-Mail + Passwort) ----------
  /*
   * Gespeichert wird NUR der Erneuerungs-Token, nie das Passwort. Der Token ist langlebig und
   * traegt die Station ueber jeden Neustart — nach einem Stromausfall laeuft die Uebertragung
   * also von selbst wieder an, ohne dass jemand etwas eingeben muss.
   */
  _loadAuth() {
    try {
      const j = JSON.parse(fs.readFileSync(this.authFile, 'utf8'));
      if (j && j.refreshToken) {
        this.refreshToken = j.refreshToken;
        this.localId = j.localId || null;
        if (j.email && !this.email) this.email = j.email;
      }
    } catch (_) { /* erste Nutzung */ }
  }
  _saveAuth() {
    try {
      fs.mkdirSync(path.dirname(this.authFile), { recursive: true });
      fs.writeFileSync(this.authFile, JSON.stringify({
        refreshToken: this.refreshToken, localId: this.localId, email: this.email || null,
      }), 'utf8');
    } catch (e) { this.log.warn('cloud', 'Token-Datei nicht speicherbar: ' + e.message); }
  }

  /*
   * Kein Rueckfall auf eine Neuanmeldung mehr.
   * Frueher legte _signUp() bei verworfenem Token stillschweigend ein NEUES anonymes Konto an —
   * mit neuer Kennung. Unter uid-gebundenen Regeln waere das fatal: die Station schriebe ploetzlich
   * in einen anderen Pfad, die Web-App der Praxis saehe nichts mehr, und niemand wuesste warum.
   * Jetzt gilt: entweder die gespeicherte Anmeldung traegt, oder es wird ehrlich gemeldet.
   */
  async _ensureAuth() {
    if (this.idToken && this.tokenExp > nowSec() + 60) return this.idToken;
    if (this.refreshToken) return await this._refresh();
    throw new Error('Nicht angemeldet — bitte im Admin-Bereich unter "Fern-Live" das Praxis-Konto anmelden.');
  }

  async _signIn(passwort) {
    const url = this.identityUrl + '?key=' + encodeURIComponent(this.cfg.apiKey);
    const res = await this._reqJson('POST', url,
      JSON.stringify({ email: this.email, password: passwort, returnSecureToken: true }),
      { 'Content-Type': 'application/json' });
    if (!res.idToken) throw new Error('Anmeldung ohne Token: ' + JSON.stringify(res).slice(0, 160));
    this.idToken = res.idToken;
    this.refreshToken = res.refreshToken;
    this.localId = res.localId;
    this.tokenExp = nowSec() + (parseInt(res.expiresIn, 10) || 3600);
    this._saveAuth();
    return this.idToken;
  }

  async _refresh() {
    const url = this.tokenUrl + '?key=' + encodeURIComponent(this.cfg.apiKey);
    const body = 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(this.refreshToken);
    const res = await this._reqJson('POST', url, body, { 'Content-Type': 'application/x-www-form-urlencoded' });
    if (!res.id_token) throw new Error('refresh ohne id_token: ' + JSON.stringify(res).slice(0, 160));
    this.idToken = res.id_token;
    this.refreshToken = res.refresh_token || this.refreshToken;
    this.localId = res.user_id || this.localId;
    this.tokenExp = nowSec() + (parseInt(res.expires_in, 10) || 3600);
    this._saveAuth();
    return this.idToken;
  }

  // ---------- RTDB REST ----------
  _put(pathAndQuery, obj) {
    return this._write('PUT', pathAndQuery, obj);
  }

  _reqJson(method, urlString, body, headers) {
    return new Promise((resolve, reject) => {
      let u;
      try { u = new URL(urlString); } catch (e) { return reject(new Error('URL ungueltig: ' + e.message)); }
      const isHttp = u.protocol === 'http:';
      const lib = isHttp ? http : https;
      const opts = {
        method: method,
        hostname: u.hostname,
        port: u.port || (isHttp ? 80 : 443),
        path: u.pathname + u.search,
        headers: Object.assign({ 'Accept': 'application/json' }, headers || {}),
        timeout: 8000,
        agent: isHttp ? AGENT_HTTP : AGENT_HTTPS,   // Dauerverbindung, siehe Kopf der Datei
      };
      if (body != null) opts.headers['Content-Length'] = Buffer.byteLength(body);
      const req = lib.request(opts, (res) => {
        let data = '';
        res.on('data', (c) => { data += c; });
        res.on('end', () => {
          const code = res.statusCode || 0;
          if (code < 200 || code >= 300) return reject(new Error('HTTP ' + code + ': ' + String(data).slice(0, 200)));
          if (!data) return resolve({});
          try { resolve(JSON.parse(data)); } catch (_) { resolve({ raw: data }); }
        });
      });
      req.on('error', (e) => reject(e));
      req.on('timeout', () => { req.destroy(new Error('Zeitueberschreitung')); });
      if (body != null) req.write(body);
      req.end();
    });
  }

  stop() { this.started = false; }
}

module.exports = { CloudPublisher, sanitizeKey, encodeSamples, kurvenChecksum, FORMAT_V };
