# Das universelle virtuelle Gerät (ab 1.4.0)

> „Es muss eine universale Monitor und kapnograph Virtuell sein, damit für alle Monitorgeräte
> und auch kapnograph und Narkosegeräte passt." — Auftrag vom 05.08.2026

## Warum

Bis 1.3.4 war das virtuelle Gerät **fest verdrahtet**: im Bild stand „mindray uMEC12 Vet" und
„mindray Veta 5 Plus", es hatte genau **sechs Kacheln** (HF, SpO₂, EtCO₂, NIBP, AF, Temp) und
genau **drei Kurvenbahnen** (EKG, Pleth, Kapno).

Zwei Folgen, beide unangenehm:

1. Wer einen Dräger, Bionet, EDAN oder SurgiVet vor sich hat, sah trotzdem ein Mindray.
2. Wer ein **Veta 5 Plus** vor sich hat, sah nur die **Hälfte** von dessen Bildschirm. Auf den
   Fotos des Praxisgeräts (30.07. und 04.08.2026) stehen: **FiCO₂**, die **Paw-Kurve**, **MAX**
   (Spitzendruck), **PEEP**, gemessenes **Vt**, **MV**, die **Alarmgrenzen neben jeder Zahl**,
   die **Falluhr** und die Knöpfe **Audio-Pause / Alarm Setup / Insp. Hold / Fall beenden**.
   Nichts davon gab es in der App.

Der zweite Punkt ist der klinisch wichtigere. Foto 2 zeigt **FiCO₂ 8 mmHg** mit dem Alarm
„FiCO₂ zu hoch" und eine Kapnokurve, deren Grundlinie nicht auf null zurückgeht — **Rückatmung**.
Ohne diesen Kanal sieht man nur ein erhöhtes EtCO₂ und beatmet stärker. Der erschöpfte Atemkalk
bleibt drin.

## Aufbau: eine Datei, drei Orte

`ui/shared/geraete-profile.js` ist reine Daten plus reine Funktionen — kein DOM, kein Netz, kein
`require`. Deshalb läuft sie identisch

* im Kiosk-Browser der Station (`ui/app/index.html`),
* in der Fern-Web-App (`canis-vetpharm/canis-anaesthesie/`),
* in der Bridge unter Node (`bridge/src/*`, über den Test).

**Genau das** ist der Grund, warum Kurven, Werte und Einstellungen überall gleich sind: es gibt
**eine** Beschreibung, nicht drei. `tools/geraete-profil-test.js` erzwingt, dass die Fassung in
der Web-App **zeichengleich** ist — eine Kopie, die man abschreibt statt kopiert, ist eine
Zeitbombe mit Zufallszünder (Befund 04.08.2026: die Bridge las jahrelang eine andere
`anaes-data.js` als der Browser).

### Vier Bausteine

| Baustein | Was es ist |
|---|---|
| `KANAELE` | 23 Messkanäle mit Kurzname, Einheit, Farbe, Normband und Erklärung |
| `KURVEN` | 6 Kurvenbahnen: EKG · Pleth · CO₂ · **Paw** · **Flow** · Resp |
| `GASE` | Isofluran · Sevofluran · Desfluran · Halothan, je mit Skala und **MAC pro Tierart** |
| `PROFILE` | 27 Geräteprofile (Monitore, Kapnografen, Narkose-/Beatmungsgeräte) |

### Neue Kanäle gegenüber 1.3.4

`fico2` · `ppeak` · `pmean` · `peep` · `vte` · `mv` · `compl` · `fio2` · `etAgent` · `fiAgent` ·
`mac` · `etn2o` · `pi` · `temp2` · `ibp`

## Die drei Regeln, an denen sich alles entscheidet

### 1. Ein Kanal, den ein Gerät nicht hat, steht nicht im Bild

Das **LifeVet M** hat laut Modulverzeichnis (`CO2(C5) = -.-`, Fotos 31.07.2026) **kein
CO₂-Modul verbaut**. Sein Profil hat deshalb weder `etco2` noch die Kapno-Bahn. Es ist keine
Einstellung — die Hardware kann es nicht. Eine EtCO₂-Kachel wäre dort eine vorgetäuschte Messung.

Umgekehrt hat der **Veta 5 Plus** kein Gasmodul: `etAgent` fehlt in seinem Profil, obwohl das
Universalprofil ihn kennt.

### 2. Gerechnet ist nicht gemessen — und gemessen schlägt gerechnet

`MV`, `Cdyn`, `Pmean` und `MAC` werden gerechnet, wenn **alle** Eingangswerte da sind. Fehlt
einer, bleibt der Wert weg — nie geschätzt. Gerechnete Werte tragen in der Kachel ein `∗`.

Liefert das Gerät den Wert **selbst**, gewinnt er. (Gemessen 05.08.2026: das Gerät meldete
MV 0,9, die Anzeige rechnete 0,85 und überschrieb es. Wer zwei Zahlen für dieselbe Größe sieht,
glaubt keiner mehr.)

### 3. MAC gehört zum Gas UND zur Tierart

2,0 Vol% sind bei **Isofluran** eine Erhaltungsdosis und bei **Desfluran** ein Viertel MAC.
Der Verdampfer wechselt deshalb mit dem Gas seine Skala (Iso 0–6, Sevo 0–8, Des 0–18) und der
Soll-Abgleich seine Zahlen.

Wo ein artspezifischer MAC publiziert ist, steht er drin (Hund, Katze, Kaninchen, Ratte, Maus,
Meerschwein). Sonst wird er aus dem **Isofluran-MAC derselben Tierart** hochgerechnet und
**als abgeleitet gekennzeichnet** — in der Oberfläche mit `∗` und dem Satz „nicht artspezifisch
belegt". Eine Größenordnung, kein Beleg.

## Was der Anwender sieht

Im Reiter **🖥️ Gerät** stehen oben drei Auswahlfelder:

* **Monitor / Kapnograf** — 17 Modelle
* **Narkosegerät / Beatmung** — 10 Modelle, dazu „kein Narkosegerät"
* **Narkosegas** — die Gase, die das gewählte Gerät führen kann

Die Wahl wird pro Praxis gemerkt (`localStorage`) und von der Station **automatisch gesetzt**,
sobald ein Gerät sein Modell meldet (HL7 `MSH-3`/`OBR-4`, sonst der Katalogeintrag aus
`devices.json`). **Eine Handwahl gewinnt immer** — sonst dreht die Station die Auswahl im
Sekundentakt zurück, derselbe Fehler wie einst bei der Tierart.

Darunter das Gerätebild wie am echten Apparat:

```
🐈  00:12:44  VCV   ⚠!! EtCO₂ zu hoch          2026-08-05 10:25:30
┌──────────────────────────────────────────────┐  EtCO₂  75   55/35
│ CO₂  ▁▄██▄▁▄██▄▁▄██▄                        │  FiCO₂   0     3
│ Paw  ▁▟▛▙▁▟▛▙▁▟▛▙   (violett = Pflichthub)  │  MAX     7    15
└──────────────────────────────────────────────┘  PEEP    3     8
🔔 Audio-Pause  ⚙ Alarm-Setup  ⏸ Insp. Hold  ▶ Fall  Vt      36   65/43
```

* **Alarmgrenzen** stehen als kleine Doppelzahl neben jedem Wert. Vorgabe ist das Normband der
  Tierart; eine von Hand gesetzte Grenze schlägt es und bleibt stehen, bis sie zurückgesetzt wird.
  Bewusst **keine** Automatik, die eine Grenze im Hintergrund verschiebt.
* Das **Alarmband** nennt den Kanal beim Namen („EtCO₂ zu hoch"), nicht „3 Werte außerhalb".
* Die **Paw-Kurve** ist zweifarbig: gelb = spontaner/getriggerter Atemzug, violett = maschineller
  Pflichthub — so steht es auch auf dem Veta 5. Ihre **Form** hängt am Modus: VCV zeichnet eine
  Rampe (konstanter Fluss), PCV ein Rechteck, Spontanmodi eine Sog-Delle vor dem Hub.
* **Insp. Hold** friert nur das Bild ein, damit Plateaudruck und Kurvenform in Ruhe abgelesen
  werden können. Am Patienten passiert nichts.

## Zwei neue Kreuz-Analysen

| Befund | Was die App sagt |
|---|---|
| **FiCO₂ > 3** | „Rückatmung – eingeatmetes CO₂ X mmHg". Atemkalk prüfen/wechseln · Ein-/Ausatemventil auf Klemmen prüfen · Frischgasfluss erhöhen · Totraum verkleinern. **Erst danach** die Ventilation nachstellen. |
| **Ppeak > Grenzdruck + 3** | „Spitzendruck zu hoch". Tubus freimachen · Vt auf 6–8 ml/kg · in PCV wechseln · I:E verlängern. Ein Barotrauma ist in Sekunden gemacht. |

Beide unterdrücken die allgemeinere Einzelwert-Karte desselben Kanals — sonst stand unter der
Rückatmungs-Karte noch „FiCO₂ ↑ → Narkosetiefe prüfen", ein Rat, der dem Befund widerspricht.

## Der Weg der Werte

```
Gerät ─HL7→ bridge/src/adapters/hl7.js ─→ model.js ─→ matching.js ─→ registry
                                                                        │
                        ┌───────────────────────────────────────────────┤
                        ▼                                               ▼
        ui/vetstation-live.js  drive()                    bridge/src/cloud.js
        __setMesswerte / __setGeraetProfil                        │
                        ▼                                    Firebase RTDB
              virtuelles Gerät (Kiosk)                             │
                                                                   ▼
                                              canis-anaesthesie  applyLive()
                                              __setMesswerte / __setGeraetProfil
```

Fern und lokal rufen **dieselben** Brücken auf, nicht zwei Umsetzungen. Wäre es fern nachgebaut,
wäre es beim nächsten neuen Kanal wieder auseinandergelaufen — so wie einst der Veta-5-Spiegel,
der lokal lief und fern still tot war.

### Was in der Bridge dazukam

* **`hl7.js`** — die neuen Kanäle **nur über das Label**, nicht über Zahlencodes. Für HF/SpO₂/NIBP
  stehen private Mindray-Nummern drin, weil sie am echten Gerät dieser Praxis **gemessen** wurden.
  Für Paw/PEEP/Vt/MV/FiO₂/Narkosegas gibt es hier keine eigene Messung — eine ausgedachte Nummer
  wäre ein Gerücht und würde stillschweigend einen fremden Parameter unter falschem Namen anzeigen.
  Die MDC-Bezeichner (IEEE 11073-10101) sind dagegen selbstbeschreibend und kommen bei genau
  diesen Geräten mit jedem OBX mit.
* **Einheitenprüfung** für cmH₂O (gegen mbar/hPa/kPa), ml (gegen Liter), L/min (gegen ml/min) und
  Vol% (gegen kPa). Ein Gerät, das den Atemwegsdruck in kPa meldet, würde sonst „1" statt „10"
  anzeigen — ein bedrohlich hoher Spitzendruck sähe aus wie eine Idealeinstellung.
* **`matching.js`** — die Beatmungswerte bekommen das Gewicht 4 für `anesthesia`/`capno`: bei zwei
  Quellen gewinnt das Gerät, das **beatmet**. `MERGE_FELDER` ist **eine** Liste, damit ein neuer
  Kanal nicht an mehreren Stellen nachgetragen werden muss.
* **`model.js`** — Plausibilitätsfenster je Kanal. Mindrays 32767 wird nicht zum Spitzendruck,
  und **jede** Verwerfung wird gemeldet statt verschwiegen.
* **`cloud.js`** — die neuen Kanäle stehen in der Liste der immer vorhandenen Felder. Fehlt der
  Schlüssel ganz, bleibt in der Fern-Ansicht der zuletzt gesehene Wert eingefroren stehen (RTDB
  `PATCH` löscht nur, was ausdrücklich auf `null` gesetzt wird).

## Ein neues Gerät eintragen

1. In `ui/shared/geraete-profile.js` ein Profil an `PROFILE` anhängen. Pflicht: `id`, `rolle`,
   `hersteller`, `typ`, `vertrauen`, `hinweis`.
2. `kanaele[]` und `kurven[]` **nur mit dem, was das Gerät wirklich kann.** Im Zweifel weglassen.
3. `katalogId` auf den passenden Eintrag in `bridge/src/geraetekatalog.js` setzen (dort steht,
   **wie** man es ansteckt — hier steht, **was** es zeigt). Der Test prüft, dass der Verweis lebt.
4. `hinweis` ist der eine Satz, der die häufigste Enttäuschung vorwegnimmt („zeigt alles, gibt
   nichts heraus", „Werkseinstellung ist VITALINK, nicht MEDIBUS", „Pin 6 führt +5 V").
5. `node tools/geraete-profil-test.js`

## Prüfen

```
node tools/geraete-profil-test.js
```

180 Prüfungen in zwölf Blöcken. Zwei davon sind ungewöhnlich und lohnen die Erwähnung:

* **Block 11** holt `wCapno`, `wPaw` und `wFlow` per Textsuche aus `index.html`, baut sie mit
  `new Function` und **rechnet** damit: hebt FiCO₂ 8 die Grundlinie? Ist VCV eine Rampe und PCV
  ein Rechteck? Erreicht der Ausatemfluss bei Obstruktion die Null nicht? Ein reiner Textabgleich
  hätte das nie gefunden — genau daran ist 2026 der Veta-5-Spiegel vorbeigelaufen, der
  vollständig vorhanden und trotzdem tot war.
* **Block 12** vergleicht die Web-App zeichenweise mit der Quelle.

Nach jeder Änderung an `ui/app/index.html`:

```
node tools/web-app-bauen.js ui/app/index.html ../../canis-vetpharm/canis-anaesthesie/index.html
```

Das Werkzeug setzt den Fern-Seam (`tools/web-fern-seam.js`) und das Fern-Modul wieder an und
kopiert `anaes-data.js` und `geraete-profile.js` zeichengleich mit.
