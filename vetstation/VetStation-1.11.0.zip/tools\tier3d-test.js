'use strict';
/*
 * tier3d-test.js — das drehbare 3D-Modell mit den Anlegepunkten.
 *
 * WAS HIER WIRKLICH BEWACHT WIRD, und es ist nur EINE Sache in drei Formen:
 * WELCHE SEITE IST DAS? Wer RA und LA vertauscht, bekommt eine Kurve, die tadellos
 * aussieht und in Ableitung I gespiegelt ist - der gefaehrlichste Bedienfehler am EKG.
 * Ein Modell, das man drehen kann, soll genau diese Verwechslung ausschliessen. Tut es das
 * nicht, ist es schlimmer als der alte flache Umriss, weil es Raeumlichkeit vortaeuscht.
 *
 * Deshalb prueft dieser Test in dieser Reihenfolge:
 *   1. Liegen die vier Punkte auf der richtigen Seite und am richtigen Ende? (Rohdaten)
 *   2. Bleibt das beim Drehen so? (Bild)
 *   3. Wird eine Marke, die hinter dem Tier liegt, auch als verdeckt gemeldet?
 *
 * Und weil eine Marke NICHT aufgemalt, sondern das Gelenk selbst ist: sie muss mit dem
 * Treffpunkt der beiden Beinabschnitte uebereinstimmen. Das kann gar nicht auseinanderlaufen -
 * dieser Test haelt fest, dass es so bleibt.
 *
 * Start: node tools/tier3d-test.js
 */
const T = require('../ui/shared/tier3d.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }
const ARTEN = T.arten();

console.log('\nVetStation - 3D-Modell und Anlegepunkte\n');

/* ================================================================================
 * 1. DIE SEITEN — Rohdaten
 * ============================================================================== */
block('1. links, rechts, vorn, hinten');
pruef('es gibt Modelle', ARTEN.length >= 3, ARTEN.join(','));
ARTEN.forEach((art) => {
  const m = T.netz(art);
  pruef(art + ': Netz gebaut', !!m && m.pts.length > 200 && m.faces.length > 150,
    m ? (m.pts.length + ' Punkte, ' + m.faces.length + ' Flaechen') : 'null');
  const M = {};
  m.marken.forEach((s) => { M[s.k] = s; });
  pruef(art + ': genau vier Anlegepunkte', m.marken.length === 4, String(m.marken.length));
  ['RA', 'LA', 'LL', 'RL'].forEach((k) => pruef(art + ': ' + k + ' vorhanden', !!M[k]));
  /* z < 0 ist RECHTS, z > 0 ist LINKS (siehe Dateikopf von tier3d.js). */
  pruef(art + ': RA liegt RECHTS', M.RA.p[2] < 0, String(M.RA.p[2]));
  pruef(art + ': RL liegt RECHTS', M.RL.p[2] < 0, String(M.RL.p[2]));
  pruef(art + ': LA liegt LINKS', M.LA.p[2] > 0, String(M.LA.p[2]));
  pruef(art + ': LL liegt LINKS', M.LL.p[2] > 0, String(M.LL.p[2]));
  /* x > 0 ist VORN (Nase), x < 0 ist HINTEN (Schwanz). */
  pruef(art + ': RA und LA sind VORN', M.RA.p[0] > 0 && M.LA.p[0] > 0, M.RA.p[0] + '/' + M.LA.p[0]);
  pruef(art + ': RL und LL sind HINTEN', M.RL.p[0] < 0 && M.LL.p[0] < 0, M.RL.p[0] + '/' + M.LL.p[0]);
  /* Und sie muessen einander spiegeln - eine Seite darf nicht weiter vorn sitzen. */
  pruef(art + ': RA und LA spiegeln einander',
    Math.abs(M.RA.p[0] - M.LA.p[0]) < 1e-9 && Math.abs(M.RA.p[2] + M.LA.p[2]) < 1e-9);
  pruef(art + ': RL und LL spiegeln einander',
    Math.abs(M.RL.p[0] - M.LL.p[0]) < 1e-9 && Math.abs(M.RL.p[2] + M.LL.p[2]) < 1e-9);
  pruef(art + ': vorn heisst Ellbogen, hinten Knie',
    M.RA.gelenk === 'Ellbogen' && M.LA.gelenk === 'Ellbogen' &&
    M.RL.gelenk === 'Knie' && M.LL.gelenk === 'Knie');
  pruef(art + ': RL ist als Neutral/Erde ausgewiesen', /Neutral|Erde/.test(M.RL.wo), M.RL.wo);
});

/* ================================================================================
 * 2. DIE MARKE IST DAS GELENK — nicht daneben gemalt
 * ============================================================================== */
block('2. die Marke sitzt auf dem Gelenk');
ARTEN.forEach((art) => {
  const b = T.BAU[art], m = T.netz(art);
  const M = {}; m.marken.forEach((s) => { M[s.k] = s; });
  /* Der Ellbogen des Bauplans, auf die linke Seite gespiegelt, MUSS der Punkt von LA sein.
   * Das Netz wird beim Bauen auf seine eigene Mitte geschoben - deshalb wird sie hier
   * wieder aufgeschlagen. Waere das eine Ausrede, wuerde die Pruefung nichts mehr bewachen;
   * sie ist es nicht: m.mitte ist EINE Verschiebung fuer alle Punkte, ein falsch gesetztes
   * Gelenk faellt darunter genauso auf wie vorher. */
  const mi = m.mitte, e = b.vorn.ellbogen, k = b.hinten.knie;
  const gl = (a, soll) => Math.abs(a - soll) < 1e-9;
  pruef(art + ': LA sitzt genau auf dem Ellbogen des Bauplans',
    gl(M.LA.p[0] + mi[0], e[0]) && gl(M.LA.p[1] + mi[1], e[1]) && gl(Math.abs(M.LA.p[2]), Math.abs(e[2])),
    JSON.stringify(M.LA.p) + ' + ' + JSON.stringify(mi) + ' vs ' + JSON.stringify(e));
  pruef(art + ': LL sitzt genau auf dem Knie des Bauplans',
    gl(M.LL.p[0] + mi[0], k[0]) && gl(M.LL.p[1] + mi[1], k[1]) && gl(Math.abs(M.LL.p[2]), Math.abs(k[2])),
    JSON.stringify(M.LL.p) + ' + ' + JSON.stringify(mi) + ' vs ' + JSON.stringify(k));
  /* Und das Modell muss wirklich zentriert sein - sonst steht es schief im Bild und dreht
   * sich um einen Punkt neben seinem Koerper. */
  {
    let lo = 1e9, hi = -1e9;
    m.pts.forEach((p) => { if (p[0] < lo) lo = p[0]; if (p[0] > hi) hi = p[0]; });
    pruef(art + ': das Netz ist waagerecht zentriert', Math.abs(lo + hi) < 1e-9, lo + ' / ' + hi);
  }
  /* Und das Gelenk liegt ZWISCHEN Schulter und Pfote - nicht darueber oder darunter. */
  pruef(art + ': der Ellbogen liegt zwischen Schulter und Pfote',
    e[1] < b.vorn.schulter[1] && e[1] > b.vorn.pfote[1],
    b.vorn.schulter[1] + ' > ' + e[1] + ' > ' + b.vorn.pfote[1]);
  pruef(art + ': das Knie liegt zwischen Huefte und Pfote',
    k[1] < b.hinten.huefte[1] && k[1] > b.hinten.pfote[1]);
});
{
  /* DER GRUND, WARUM JEDE ART EIN EIGENES MODELL HAT: beim Frettchen liegt der Ellbogen
   * viel dichter an der Unterlinie als beim Hund. Wer die Punkte des Hundes uebernimmt,
   * klemmt am Bauch. Diese Pruefung haelt den Unterschied fest. */
  const h = T.BAU.hund, f = T.BAU.frettchen;
  const anteil = (b) => (b.vorn.schulter[1] - b.vorn.ellbogen[1]) / (b.vorn.schulter[1] - b.vorn.pfote[1]);
  const relBein = (b) => (b.vorn.schulter[1] - b.vorn.pfote[1]) / (2 * b.rumpf.r[0]);
  console.log('    Beinlaenge/Rumpflaenge: Hund ' + relBein(h).toFixed(2) + ', Frettchen ' + relBein(f).toFixed(2));
  pruef('das Frettchen hat im Verhaeltnis viel kuerzere Beine als der Hund',
    relBein(f) < relBein(h) * 0.6, relBein(f).toFixed(2) + ' vs ' + relBein(h).toFixed(2));
  pruef('und der Ellbogen sitzt bei beiden auf gleicher relativer Beinhoehe',
    Math.abs(anteil(h) - anteil(f)) < 0.15, anteil(h).toFixed(2) + ' vs ' + anteil(f).toFixed(2));
  /* Das Kaninchen traegt die Kraft in der Hinterhand: sein Knie sitzt deutlich weiter VORN
   * (relativ zur Huefte) als beim Hund. */
  const kn = (b) => b.hinten.knie[0] - b.hinten.huefte[0];
  pruef('beim Kaninchen sitzt das Knie weiter vorn als beim Hund',
    kn(T.BAU.kaninchen) > kn(T.BAU.hund) + 0.05, kn(T.BAU.kaninchen).toFixed(2) + ' vs ' + kn(T.BAU.hund).toFixed(2));
}

/* ================================================================================
 * 3. DREHEN — die Geometrie muss stimmen, sonst verzerrt jedes Bild
 * ============================================================================== */
block('3. Drehung');
{
  const laenge = (p) => Math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]);
  const p = [1.3, -0.4, 0.7], L = laenge(p);
  [0, 37, 90, 180, 271, 359].forEach((g) => {
    [0, 20, -35].forEach((n) => {
      const q = T.drehe(p, g * Math.PI / 180, n * Math.PI / 180);
      pruef('Drehung ' + g + '/' + n + ' erhaelt die Laenge', Math.abs(laenge(q) - L) < 1e-9,
        laenge(q) + ' vs ' + L);
    });
  });
  const rund = T.drehe(p, 2 * Math.PI, 0);
  pruef('volle Umdrehung fuehrt zum Ausgangspunkt zurueck',
    Math.abs(rund[0] - p[0]) < 1e-9 && Math.abs(rund[2] - p[2]) < 1e-9);
  const halb = T.drehe(p, Math.PI, 0);
  pruef('halbe Umdrehung spiegelt x und z', Math.abs(halb[0] + p[0]) < 1e-9 && Math.abs(halb[2] + p[2]) < 1e-9);
  pruef('und laesst y in Ruhe (Drehung um die Hochachse)', Math.abs(halb[1] - p[1]) < 1e-9);
}

/* ================================================================================
 * 4. DAS BILD — bleibt links links?
 * ============================================================================== */
block('4. Seiten im gedrehten Bild');
{
  const m = T.netz('hund');
  /* Blick auf die LINKE Seite: die Kamera steht auf +z. Dann muessen LA und LL vorn
   * (sichtbar) sein und RA/RL hinten. */
  const a0 = T.ansicht(m, { gierGrad: 0, nickGrad: 0, breite: 420, hoehe: 300 });
  const V = {}; a0.marken.forEach((s) => { V[s.k] = s; });
  pruef('Blick von links: LA und LL sind sichtbar', V.LA.vorn === true && V.LL.vorn === true);
  pruef('Blick von links: RA und RL sind VERDECKT', V.RA.vorn === false && V.RL.vorn === false,
    'RA ' + V.RA.vorn + ', RL ' + V.RL.vorn);
  /* Und um 180 Grad gedreht kehrt sich das um - das ist der eigentliche Zweck des Modells. */
  const a180 = T.ansicht(m, { gierGrad: 180, nickGrad: 0, breite: 420, hoehe: 300 });
  const W = {}; a180.marken.forEach((s) => { W[s.k] = s; });
  pruef('um 180 Grad gedreht: RA und RL sind sichtbar', W.RA.vorn === true && W.RL.vorn === true);
  pruef('um 180 Grad gedreht: LA und LL sind verdeckt', W.LA.vorn === false && W.LL.vorn === false);
  /* Die Nase wechselt dabei die Bildseite - sonst dreht sich gar nichts. */
  const nase = (g) => {
    const v = T.ansicht(m, { gierGrad: g, nickGrad: 0, breite: 420, hoehe: 300 });
    return v.marken.filter((s) => s.k === 'LA')[0].x;
  };
  pruef('die Vordergliedmasse wechselt beim Drehen die Bildseite', (nase(0) - 210) * (nase(180) - 210) < 0,
    nase(0).toFixed(0) + ' -> ' + nase(180).toFixed(0));
}
{
  /* Ueber den ganzen Drehkreis: es duerfen NIE alle vier Marken gleichzeitig sichtbar sein.
   * Genau das waere die vorgetaeuschte Raeumlichkeit, vor der der Dateikopf warnt. */
  const m = T.netz('katze');
  let maxSichtbar = 0, minSichtbar = 9;
  for (let g = 0; g < 360; g += 5) {
    const v = T.ansicht(m, { gierGrad: g, nickGrad: 0, breite: 420, hoehe: 300 });
    const n = v.marken.filter((s) => s.vorn).length;
    if (n > maxSichtbar) maxSichtbar = n;
    if (n < minSichtbar) minSichtbar = n;
  }
  console.log('    sichtbare Marken ueber 72 Drehwinkel: ' + minSichtbar + ' bis ' + maxSichtbar);
  pruef('nie alle vier Marken gleichzeitig sichtbar', maxSichtbar < 4, String(maxSichtbar));
  pruef('aber auch nie weniger als zwei (sonst ist das Bild unbrauchbar)', minSichtbar >= 2, String(minSichtbar));
}

/* ================================================================================
 * 5. DAS BILD BLEIBT IM RAHMEN
 * ============================================================================== */
block('5. Rahmen');
ARTEN.forEach((art) => {
  const m = T.netz(art);
  let drin = true, groesster = 0;
  /* Ueber den GANZEN erlaubten Kippbereich, nicht nur ±30: der Massstab haengt seit dem
   * zweiten Fehlversuch vom Kippwinkel ab, und genau an den Raendern muss er tragen. */
  [[420, 300], [320, 220], [640, 420], [300, 300], [233, 144]].forEach(([B, H]) => {
    for (let g = 0; g < 360; g += 17) {
      for (const n of [-80, -55, -33, -12, 0, 7, 25, 44, 72, 80]) {
        const v = T.ansicht(m, { gierGrad: g, nickGrad: n, breite: B, hoehe: H });
        v.flaechen.forEach((f) => f.eck.forEach((e) => {
          if (e.x < -1 || e.x > B + 1 || e.y < -1 || e.y > H + 1) drin = false;
          groesster = Math.max(groesster, Math.abs(e.x - B / 2) / B, Math.abs(e.y - H / 2) / H);
        }));
      }
    }
  });
  pruef(art + ': ragt bei keiner Groesse und keinem Winkel aus der Flaeche', drin,
    'groesste relative Auslenkung ' + groesster.toFixed(2));
});

/* ================================================================================
 * 6. TIEFENSORTIERUNG UND RUECKSEITEN
 * ============================================================================== */
block('6. Zeichenreihenfolge');
{
  const m = T.netz('hund');
  const v = T.ansicht(m, { gierGrad: 35, nickGrad: 15, breite: 420, hoehe: 300 });
  let sortiert = true;
  for (let i = 1; i < v.flaechen.length; i++) if (v.flaechen[i].tiefe < v.flaechen[i - 1].tiefe) sortiert = false;
  pruef('Flaechen liegen hinten-zuerst (Maler-Verfahren)', sortiert);
  pruef('Rueckseiten werden weggelassen', v.flaechen.length < m.faces.length,
    v.flaechen.length + ' von ' + m.faces.length);
  pruef('aber es bleibt genug uebrig', v.flaechen.length > m.faces.length * 0.25,
    v.flaechen.length + ' von ' + m.faces.length);
  let hellOk = true;
  v.flaechen.forEach((f) => { if (!(f.hell >= 0.28 && f.hell <= 1)) hellOk = false; });
  pruef('die Helligkeit bleibt im Band 0,28 bis 1', hellOk);
}

/* ================================================================================
 * 7. WO ES KEIN MODELL GIBT, WIRD KEINES BEHAUPTET
 * ============================================================================== */
block('7. Schweigen');
['vogel', 'reptil', 'pferd', 'hamster', '', null, 'unsinn'].forEach((art) => {
  pruef('"' + String(art) + '" hat kein Modell', T.hatModell(art) === false);
  pruef('"' + String(art) + '" liefert null statt einer Hundevorlage', T.netz(art) === null);
});

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
