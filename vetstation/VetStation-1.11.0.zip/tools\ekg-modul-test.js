'use strict';
/*
 * ekg-modul-test.js — Selbsttest des Diagnostik-EKG-Submoduls in ui/app/index.html.
 *
 * WARUM DIESER TEST SO GEBAUT IST:
 * Das Submodul laeuft im Browser und zeichnet auf eine Leinwand. In der Vorschau feuert
 * requestAnimationFrame NICHT (document.hidden), ein Bildschirmfoto beweist also nichts ueber
 * die RECHNUNG. Deshalb wird hier genauso verfahren wie in geraete-profil-test.js: die
 * Funktionen werden per Klammerzaehlung aus der HTML-Datei geholt, mit new Function gebaut und
 * dann wird MIT IHNEN GERECHNET. Ein Test, der nur nach Zeichenketten greppt, haette keinen der
 * Fehler gefunden, um die es hier geht (doppelte Element-Kennung, doppeltes dpr in der
 * Zeitbasis, falscher Startpunkt bei doc.lines, Ableitung II zweimal projiziert).
 *
 * Aufruf:  node tools/ekg-modul-test.js
 */
const fs = require('fs');
const path = require('path');

const DATEI = path.join(__dirname, '..', 'ui', 'app', 'index.html');
const src = fs.readFileSync(DATEI, 'utf8');

let gruen = 0, rot = 0;
function pruef(name, bedingung, zusatz) {
  if (bedingung) { gruen++; console.log('  ✓ ' + name); }
  else { rot++; console.log('  ✗ ' + name + (zusatz ? '   -> ' + zusatz : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

/* Holt eine Funktion per Klammerzaehlung heraus (vertraegt Klammern in Zeichenketten nicht
 * perfekt, reicht aber fuer diesen Quelltext und ist genau das Verfahren der uebrigen Tests). */
function holeFunktion(name) {
  const start = src.indexOf('function ' + name + '(');
  if (start < 0) return null;
  const auf = src.indexOf('{', start);
  if (auf < 0) return null;
  let tiefe = 0;
  for (let i = auf; i < src.length; i++) {
    const c = src[i];
    if (c === '{') tiefe++;
    else if (c === '}') { tiefe--; if (tiefe === 0) return src.slice(start, i + 1); }
  }
  return null;
}

// ---------------------------------------------------------------------------
block('1. Bausteine vorhanden');
const teile = ['ekgWave', 'proj', 'echtEkg', 'echtNaechster', 'advance', 'buildPDF', 'updateMeasures', 'renderSheet'];
teile.forEach((n) => pruef('Funktion ' + n + ' gefunden', !!holeFunktion(n)));
pruef('LEADS-Tabelle vorhanden', /var LEADS\s*=\s*\[/.test(src));
pruef('jsPDF wird geladen', /shared\/jspdf\.umd\.min\.js/.test(src));
pruef('ekg-analyse wird geladen', /shared\/ekg-analyse\.js/.test(src));

// ---------------------------------------------------------------------------
block('2. Element-Kennungen sind eindeutig');
/* Der Fehler, den nur der echte Klick zeigte: Knopf und Ansicht hiessen beide "ekgPdf",
 * $('#ekgPdf') traf den Knopf und die PDF-Ansicht ging nie auf. */
/* NUR die AUSZEICHNUNG zaehlen. Dieselben Kennungen stehen zusaetzlich in einer
 * JS-Zeichenkette (rebuildSide baut die Seitenleiste neu auf) — das ist zur Laufzeit
 * KEIN Duplikat, weil der Inhalt ersetzt wird. Ein Test, der beides zaehlt, meldet einen
 * Fehler, den es nicht gibt; genau das ist beim ersten Lauf passiert. */
const ohneSkript = src.replace(/<script[\s\S]*?<\/script>/g, '');
const ids = [];
const reId = /\bid="([A-Za-z0-9_-]+)"/g;
let m;
while ((m = reId.exec(ohneSkript))) ids.push(m[1]);
const doppelt = {};
ids.forEach((i) => { doppelt[i] = (doppelt[i] || 0) + 1; });
const mehrfach = Object.keys(doppelt).filter((k) => doppelt[k] > 1);
pruef('keine doppelte id in der Auszeichnung', mehrfach.length === 0, 'doppelt: ' + mehrfach.join(', '));
['ekgOverlay', 'ekgCanvas', 'ekgStripCv', 'ekgPdf', 'ekgPdfView', 'mHr', 'ekgDx'].forEach((i) =>
  pruef('id ' + i + ' genau einmal ausgezeichnet', doppelt[i] === 1, 'Anzahl ' + (doppelt[i] || 0)));
// Der Oeffnen-Knopf wird zur Laufzeit erzeugt, steht also NICHT in der Auszeichnung.
pruef('Oeffnen-Knopf wird im Skript mit fester Kennung erzeugt', /btn\.id\s*=\s*'ekgOpenBtn'/.test(src));
pruef('und vorher gegen doppeltes Einhaengen geprueft', /if\(\$\('#ekgOpenBtn'\)\)\s*return true;/.test(src));

// ---------------------------------------------------------------------------
block('3. Ableitungen nach Einthoven/Goldberger');
const LEADS = (function () {
  const s = src.indexOf('var LEADS');
  const e = src.indexOf('];', s);
  return new Function('return ' + src.slice(src.indexOf('[', s), e + 1))();
})();
const proj = new Function('return ' + holeFunktion('proj'))();
pruef('sechs Ableitungen', LEADS.length === 6, 'gefunden ' + LEADS.length);
pruef('Winkel I=0 II=60 III=120', LEADS[0].ang === 0 && LEADS[1].ang === 60 && LEADS[2].ang === 120);
pruef('Winkel aVR=-150 aVL=-30 aVF=90', LEADS[3].ang === -150 && LEADS[4].ang === -30 && LEADS[5].ang === 90);
const achse = 70;
const pII = proj(60, achse), pAVR = proj(-150, achse);
pruef('Ableitung II positiv bei Achse 70 Grad', pII > 0.9, 'pII=' + pII.toFixed(3));
pruef('aVR NEGATIV (gespiegelt) - das Kennzeichen eines richtig abgeleiteten EKG', pAVR < -0.5, 'pAVR=' + pAVR.toFixed(3));
pruef('aVR ist etwa das Gegenteil von II', Math.abs(pII + pAVR) < 0.35, 'Summe=' + (pII + pAVR).toFixed(3));

// ---------------------------------------------------------------------------
block('4. Zeitbasis - mm/s muss auf dem Papier STIMMEN');
/* Der Fehler in der ersten Fassung: pxPerSec = mp * speed * dpr, obwohl mp bereits
 * Geraetepixel je Millimeter ist (2,2*dpr). Der Vorschub war damit um den Geraetefaktor
 * zu schnell - bei dpr 2 doppelt. Aus "25 mm/s" wurden 50. */
const advSrc = holeFunktion('advance');
pruef('advance rechnet pxPerSec = mp * M.speed (ohne zusaetzliches dpr)',
  /var pxPerSec\s*=\s*mp\s*\*\s*M\.speed\s*;/.test(advSrc), 'gefunden: ' + (advSrc.match(/var pxPerSec[^;]*;/) || [''])[0]);
pruef('colT ist der Kehrwert von pxPerSec', /var colT\s*=\s*1\s*\/\s*pxPerSec\s*;/.test(advSrc));
pruef('Abtastrate wird fuer Ausdruck/Auswertung gemerkt (M.hz)', /M\.hz\s*=\s*pxPerSec/.test(advSrc));
// Gegenrechnung: 1 s Signal muss genau M.speed Millimeter breit werden.
const mmPxSrc = holeFunktion('mmPx');
const mmPx = new Function('M', 'return (' + mmPxSrc + ')();').bind(null, { dpr: 2 });
const pxProMm = mmPx();
[25, 50].forEach((sp) => {
  const pxProSek = pxProMm * sp;
  const mmProSek = pxProSek / pxProMm;
  pruef('bei ' + sp + ' mm/s ergibt 1 s genau ' + sp + ' mm', Math.abs(mmProSek - sp) < 1e-9, 'gerechnet ' + mmProSek);
});

// ---------------------------------------------------------------------------
block('5. Echtes Signal hat Vorrang und wird NICHT verfaelscht');
pruef('advance fragt zuerst echtEkg()', /var base\s*,\s*ech\s*=\s*echtEkg\(\)/.test(advSrc));
pruef('nur ohne echtes Signal wird synthetisiert', /else\s*\{[\s\S]*ekgWave\(/.test(advSrc));
pruef('Ableitung II wird bei echtem Signal NICHT projiziert',
  /if\s*\(\s*ech\s*&&\s*LEADS\[li\]\.id\s*===\s*'II'\s*\)\s*mv\s*=\s*base/.test(advSrc));
pruef('Rauschen wird einem ECHTEN Streifen nicht hinzugefuegt',
  /if\(\s*!ech\s*&&\s*!M\.musk/.test(advSrc));
pruef('Rhythmusstreifen nimmt bei echt ebenfalls den Messwert',
  /var mvII\s*=\s*ech\s*\?\s*base\s*:/.test(advSrc));

const echtNaechsterSrc = holeFunktion('echtNaechster');
const kalOfSrc = holeFunktion('kalOf');
pruef('bekannte Verstaerkung => Umrechnung uV/mV',
  /\/mv\/i\.test\(eh\)\s*\?\s*1\s*:\s*0\.001/.test(echtNaechsterSrc));
pruef('echter Streifen laeuft mit SEINER Abtastrate',
  /M\.ePos\s*=\s*\(M\.ePos\s*\+\s*hz\s*\*\s*colT\)/.test(echtNaechsterSrc));
pruef('die Kalibrierfrage stellt EINE Funktion (kalOf), nicht jede Stelle selbst', !!kalOfSrc);

// kalOf wird in den Gueltigkeitsbereich mitgegeben - genau wie im Browser, wo beide
// Funktionen nebeneinander in derselben IIFE stehen.
const bau = (M) => new Function('M', 'kalOf', 'return ' + echtNaechsterSrc + ';')(M, new Function('return ' + kalOfSrc)());
const kalOf = new Function('return ' + kalOfSrc)();
pruef('kalOf: skala 1 + Einheit uV = kalibriert', kalOf({ skala: 1, einheit: 'uV' }) === true);
pruef('kalOf: ohne Einheit NICHT kalibriert', kalOf({ skala: 1 }) === false);
pruef('kalOf: ohne Skala NICHT kalibriert', kalOf({ einheit: 'uV' }) === false);
pruef('kalOf: Skala 0 NICHT kalibriert (Division waere sinnlos)', kalOf({ skala: 0, einheit: 'uV' }) === false);
pruef('kalOf: kein Kanal = nicht kalibriert', kalOf(null) === false);

// Rechnung: 500 uV bei skala 1, Einheit uV -> 0,5 mV
const M1 = { ePos: 0 };
const mv = bau(M1)({ samples: [500, 500, 500, 500, 500], hz: 256, skala: 1, einheit: 'uV' }, 1 / 256);
pruef('500 uV (skala 1) werden zu 0,5 mV', Math.abs(mv - 0.5) < 1e-9, 'gerechnet ' + mv);
const M2 = { ePos: 0 };
const roh = bau(M2)({ samples: [500, 500, 500, 500, 500], norm: [1, 1, 1, 1, 1], hz: 256 }, 1 / 256);
pruef('ohne Skala/Einheit wird NICHT in mV gerechnet (normiert statt behauptet)',
  Math.abs(roh - 1) < 1e-9, 'gerechnet ' + roh);
// Gegenprobe mV: skala 1000 mit Einheit mV darf NICHT durch 1000 geteilt werden
const M3 = { ePos: 0 };
const mv2 = bau(M3)({ samples: [2, 2, 2, 2, 2], hz: 256, skala: 0.5, einheit: 'mV' }, 1 / 256);
pruef('Einheit mV wird nicht zusaetzlich skaliert (2 x 0,5 = 1,0 mV)', Math.abs(mv2 - 1) < 1e-9, 'gerechnet ' + mv2);

// ---------------------------------------------------------------------------
block('6. PDF - massstabsgetreu und vektoriell');
const pdfSrc = holeFunktion('buildPDF');
pruef('A4 quer', /orientation:\s*'landscape'/.test(pdfSrc) && /format:\s*'a4'/.test(pdfSrc));
pruef('Einheit Millimeter (sonst ist jede Skala Zufall)', /unit:\s*'mm'/.test(pdfSrc));
pruef('Raster zeichnet 1-mm-Linien', /for\(i=0;i<=w\+0\.01;i\+=1\)/.test(pdfSrc));
pruef('Raster zeichnet 5-mm-Linien', /i\+=5/.test(pdfSrc));
pruef('Amplitude = mV * M.gain (mm)', /v\s*\*\s*M\.gain/.test(pdfSrc));
/* Bis 08.08.2026 stand hier: /Math\.round\(w\/M\.speed\*hz\)/ — also die Forderung, der
 * Ausdruck moege so viele Werte nehmen, wie in die Breite passen, und sie dann ueber
 * dxmm = w/(n-1) verteilen. Genau das war der Fehler: reichte der Puffer nicht, wurde die
 * Kurve gedehnt und das Blatt behauptete eine Dauer, die es nicht zeigt. Der Test hat die
 * Dehnung also abgesichert. Jetzt wird das Gegenteil verlangt - der Ausschnitt kommt aus der
 * gemeinsamen Funktion, und ein Abtastwert bekommt immer seine eigene Breite. */
/* Eine Pruefung auf "das kommt NICHT mehr vor" muss den Code lesen, nicht die Begruendung
 * daneben: der Kommentar, der die alte Rechnung erklaert, enthaelt sie woertlich und wuerde
 * die Pruefung sonst selbst ausloesen (zweimal passiert am 08.08.2026). */
const pdfCode = pdfSrc.replace(/\/\*[\s\S]*?\*\//g, ' ');
pruef('Zeitfenster kommt aus VS.skala.kurvenAusschnitt (kein Dehnen)',
  /kurvenAusschnitt\(w,\s*1,\s*M\.speed,\s*hz/.test(pdfCode));
pruef('Wertabstand ist der massstabsgetreue, nicht die halbe Bahnbreite',
  /dxmm\s*=\s*A\.proWert/.test(pdfCode) && !/dxmm\s*=\s*w\s*\/\s*\(n-1\)/.test(pdfCode));
pruef('kurve() meldet die WIRKLICH gezeichnete Breite zurueck', /return\s+A\.breite/.test(pdfSrc));
pruef('doc.lines startet auf dem ERSTEN Kurvenpunkt, nicht auf der Bahnmitte',
  /doc\.lines\(pts,\s*x,\s*startY/.test(pdfSrc));
pruef('Kalibrierimpuls ist so hoch wie die Verstaerkung', /amp\s*=\s*Math\.min\(M\.gain/.test(pdfSrc));
pruef('Herkunft der Kurve steht auf dem Blatt (gemessen vs nachgebildet)',
  /NACHGEBILDET/.test(pdfSrc) && /Gemessenes Ger/.test(pdfSrc));
pruef('Latin-1-Filter wird angewendet (jsPDF kann kein Tiefgestellt)', /doc\.text=function\(\)\{[^}]*pdfSan/.test(pdfSrc));

// ---------------------------------------------------------------------------
block('7. Fern: KEIN eigener Uebertragungsweg (bewusste Entscheidung)');
/*
 * Der Ausdruck ist fern verfuegbar, weil die Web-App dasselbe Modul traegt und den Streifen
 * ueber den GEREGELTEN kurven-Pfad ohnehin bekommt. Ein eigener Zweig waere von den Regeln
 * zwar erlaubt (das .write kaskadiert, ohne .validate gilt "erlaubt") — aber voellig
 * ungedeckelt. Diese Pruefungen halten fest, dass hier nichts zurueckgebaut wird.
 */
pruef('kein Sendeknopf mehr in der Auszeichnung', !/id="pdfSendBtn"/.test(src));
pruef('keine Funktion sendePdfFern', !/function sendePdfFern/.test(src));
/* Auf den AUFRUF pruefen, nicht auf das Wort: der Pfad wird im Quelltext ausdruecklich
 * erwaehnt, um zu begruenden, warum es ihn NICHT gibt. Eine Zeichenkettensuche wuerde
 * genau diese Begruendung als Fehler melden. */
pruef('kein fetch auf einen eigenen EKG-Endpunkt', !/fetch\(\s*['"][^'"]*ekg-streifen/.test(src));
pruef('das fertige PDF wird NICHT in die Cloud geschoben',
  !/output\('datauristring'\)/.test(src));
pruef('die Entscheidung ist im Quelltext begruendet',
  /KEINE EINZIGE Groessengrenze/.test(src) && /12000/.test(src));
pruef('Hinweis fuer den Benutzer steht im PDF-Kopf', /id="pdfFernNote"/.test(src));

// ---------------------------------------------------------------------------
block('8. Das Fenster stoert den Monitor nicht');
pruef('eigener Schlagzaehler (M.beatN), nicht mon.beatN', /M\.beatN/.test(advSrc) && !/\bmon\.beatN/.test(advSrc));
pruef('ekgWave bekommt den Zaehler UEBERGEBEN', /function ekgWave\(ph,W,beatN\)/.test(src));
pruef('Zugriff auf den Monitor nur lesend ueber __ekgFeed', /window\.__ekgFeed\s*=\s*function/.test(src));
pruef('__ekgFeed reicht den echten Kanal durch', /real:\(mon\.real&&mon\.real\.ekg\)/.test(src));
pruef('Oeffnen-Knopf traegt NICHT die Klasse mon-mode (sonst ueberschreibt der Cockpit-Aufbau den Handler)',
  /btn\.className\s*=\s*'ekg-launch'/.test(src));
pruef('Knopf haengt per addEventListener, nicht per onclick', /btn\.addEventListener\('click',openEkg\)/.test(src));
pruef('Esc raeumt erst die PDF-Ansicht ab, dann das Fenster',
  /if\(\$\('#ekgPdfView'\)&&\$\('#ekgPdfView'\)\.classList\.contains\('open'\)\)\{ closePDF\(\); return; \}/.test(src));

// ---------------------------------------------------------------------------
block('9. __setRealWave fuehrt die Kalibrierung mit');
const swSrc = src.slice(src.indexOf('window.__setRealWave'), src.indexOf('window.__setDeviceAlarms'));
pruef('Rohwerte werden mitgefuehrt', /samples:ch\.samples/.test(swSrc));
pruef('skala wird mitgefuehrt', /skala:ch\.skala/.test(swSrc));
pruef('einheit wird mitgefuehrt', /einheit:ch\.einheit/.test(swSrc));
pruef('norm bleibt erhalten (realVal der Monitorbahn haengt daran)', /norm:norm/.test(swSrc));

// ---------------------------------------------------------------------------
block('10. Die Kalibrierung ueberlebt die GANZE Kette');
/*
 * Der gefaehrlichste Befund dieser Runde: die mV-Kalibrierung im EKG-Fenster war TOTER CODE.
 * ui/vetstation-live.js baute nur { hz, samples } — skala wurde abgeschnitten; und 'einheit'
 * kam in der ganzen Bridge nicht vor (model.js ist eine Positivliste). M.kal waere damit
 * IMMER false gewesen: die Kurve laeuft, sieht richtig aus, und der Ausdruck ist nie
 * kalibriert. Diese drei Pruefungen halten die Kette zusammen.
 */
const liveSrc = fs.readFileSync(path.join(__dirname, '..', 'ui', 'vetstation-live.js'), 'utf8');
const modelSrc = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'model.js'), 'utf8');
pruef('Shell reicht skala an __setRealWave weiter', /map\[lane\]\s*=\s*\{[^}]*skala:\s*kd\.skala/.test(liveSrc));
pruef('Shell reicht einheit weiter', /map\[lane\]\s*=\s*\{[^}]*einheit:\s*kd\.einheit/.test(liveSrc));
pruef('model.js fuehrt einheit am Kurvenkanal (Positivliste!)', /einheit:\s*k\.einheit\s*\?/.test(modelSrc));
pruef('model.js nimmt uV an, wenn eine Skala da ist', /\(num\(k\.skala\)\s*\?\s*'uV'\s*:\s*null\)/.test(modelSrc));
pruef('model.js deckelt weiterhin auf 4 Kanaele', /slice\(0,\s*4\)/.test(modelSrc));
pruef('model.js deckelt weiterhin auf 512 Werte', /slice\(0,\s*512\)/.test(modelSrc));

// ---------------------------------------------------------------------------
block('11. Einzelableitung gross + Messzirkel');
pruef('Zoom-Ansicht vorhanden', /id="ekgZoom"/.test(ohneSkript));
pruef('eigene Leinwand fuer die grosse Ansicht', /id="zCanvas"/.test(ohneSkript));
pruef('alle sechs Ableitungen + Rhythmus waehlbar',
  /var ZLEADS=\['I','II','III','aVR','aVL','aVF','RHY'\]/.test(src));
pruef('Doppelklick auf die Uebersicht oeffnet gross', /addEventListener\('dblclick',function\(e\)\{ var l=leadUnterPunkt/.test(src));
pruef('Doppelklick auf den Rhythmusstreifen ebenfalls', /sc2\.addEventListener\('dblclick',function\(\)\{ oeffneZoom\('RHY'\)/.test(src));
pruef('hoehere Vorschuebe fuer das Studium (100 mm/s)', /data-zspeed="100"/.test(ohneSkript));
pruef('hoehere Verstaerkung fuer kleine Ausschlaege (40 mm/mV)', /data-zgain="40"/.test(ohneSkript));

const zmSrc = holeFunktion('zMesswerte');
pruef('Messzirkel rechnet ueber Punkte je Millimeter', /mmPx\(\)\/M\.dpr/.test(zmSrc));
pruef('Zeit = mm / (mm\\/s) * 1000', /mm\/Z\.speed\*1000/.test(zmSrc));
pruef('Frequenz = 60000 / ms', /60000\/ms/.test(zmSrc));
pruef('Amplitude = mm / (mm\\/mV)', /mmA\/Z\.gain/.test(zmSrc));
// Gegenrechnung mit echten Zahlen (dpr 2 -> mmPx 4 -> 2 CSS-Punkte je mm)
const zm = new Function('M', 'Z', 'mmPx', 'return ' + zmSrc + ';');
const Mfake = { dpr: 2 };
const mmPxFake = () => 4;                       // 4 Geraetepunkte je mm -> 2 CSS-Punkte je mm
[[50, 100, 1000, 60], [50, 50, 500, 120], [25, 100, 2000, 30]].forEach(([sp, px, msSoll, bpmSoll]) => {
  const Zf = { speed: sp, gain: 10, t1: 0, t2: px, a1: null, a2: null };
  const r = zm(Mfake, Zf, mmPxFake)();
  pruef(px + ' px bei ' + sp + ' mm/s = ' + msSoll + ' ms = ' + bpmSoll + '/min',
    Math.abs(r.ms - msSoll) < 1e-6 && Math.abs(r.bpm - bpmSoll) < 1e-6,
    'gerechnet ' + Math.round(r.ms) + ' ms / ' + Math.round(r.bpm) + ' min');
});
[[10, 20, 1], [10, 10, 0.5], [20, 20, 0.5]].forEach(([g, px, mvSoll]) => {
  const Zf = { speed: 25, gain: g, t1: null, t2: null, a1: 0, a2: px };
  const r = zm(Mfake, Zf, mmPxFake)();
  pruef(px + ' px bei ' + g + ' mm/mV = ' + mvSoll + ' mV', Math.abs(r.mv - mvSoll) < 1e-9, 'gerechnet ' + r.mv);
});
pruef('beim Messen wird das Bild angehalten', /if\(Z\.modus && !M\.freeze\)\{ M\.freeze=true;/.test(src));
pruef('ohne Kalibrierung wird mm statt mV genannt', /unkalibriert/.test(holeFunktion('zZeigeMesswerte')));

// ---------------------------------------------------------------------------
block('12. Patientendaten: uebernehmen ODER von Hand');
pruef('zwei Betriebsarten', /P=\{ modus:'auto'/.test(src));
pruef('Auto-Modus liest aus der Anwendung', /if\(P\.modus==='auto'\)\{[\s\S]{0,400}f\.sp\|\|''/.test(holeFunktion('patDaten')));
pruef('Kardio-Modus nimmt Handeingaben', /return \{ quelle:'von Hand eingetragen'/.test(holeFunktion('patDaten')));
pruef('das EKG schreibt NIE in den Narkosepatienten zurueck',
  !/state\.(sp|wt|breed|age)\s*=/.test(src.slice(src.indexOf('var P={ modus'))));
pruef('Eingaben ueberleben einen Neustart (localStorage)', /localStorage\.setItem\(PKEY/.test(src));
pruef('Patient steht auf dem Ausdruck', /var pd=patDaten\(\), kopf=\[\]/.test(holeFunktion('buildPDF')));
pruef('Fragestellung und Untersucher stehen auf dem Ausdruck',
  /pd\.frage/.test(holeFunktion('buildPDF')) && /pd\.untersucher/.test(holeFunktion('buildPDF')));

// ---------------------------------------------------------------------------
block('13. Luecke fuer die spaetere KI (Vertrag, kein Modell)');
const kiSrc = holeFunktion('kiBefund');
pruef('Einhaengepunkt ist window.__ekgKI', /typeof window\.__ekgKI!=='function'/.test(kiSrc));
/* Kommentare wegnehmen, bevor gesucht wird: der Einhaengepunkt ist im Quelltext ausdruecklich
 * DOKUMENTIERT ("window.__ekgKI = function (eingabe) { ... }"). Eine reine Textsuche haelt die
 * Anleitung fuer ein eingebautes Modell — derselbe Fehlertyp wie beim /api/ekg-streifen-Hinweis. */
const ohneKommentare = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/[^\n]*/g, '$1');
pruef('heute ist KEIN Modell eingebaut (nur der Vertrag)', !/__ekgKI\s*=\s*function/.test(ohneKommentare));
['samples', 'hz', 'einheit', 'kalibriert', 'ableitung', 'art', 'gewichtKg', 'speed', 'gain', 'echt']
  .forEach((f) => pruef('Vertrag liefert ' + f, new RegExp(f + ':').test(kiSrc)));
pruef('Abtastrate wird NIE als 0 uebergeben', /hz:Math\.round\(hzJetzt\(\)\)/.test(kiSrc));
pruef('ein Absturz des Modells haelt das EKG nicht an', /catch\(e\)\{ return null; \}/.test(kiSrc));
const kiR = holeFunktion('renderKI');
pruef('unsichere Aussagen werden als unsicher gekennzeichnet', /a\.vertrauen>=0\.6/.test(kiR));
pruef('die KI ersetzt weder Messung noch Urteil (steht dabei)', /Zweiter Leser, keine Diagnose/.test(kiR));

// ---------------------------------------------------------------------------
block('14. Kalibrierung haengt an den DATEN, nicht am Zeichnen');
pruef('kalOf() prueft Skala und Einheit', /function kalOf\(R\)/.test(src));
pruef('currentFeed setzt echt/kal', /M\.echt=!!R; M\.kal=kalOf\(R\);/.test(holeFunktion('currentFeed')));
pruef('advance setzt sie NICHT mehr selbst', !/M\.kal=false;/.test(holeFunktion('advance')));
pruef('Abtastrate hat einen rechnerischen Rueckfall', /function hzJetzt\(\)/.test(src));

// ---------------------------------------------------------------------------
block('15. Tiermedizinische Normwerte (Humangrenzen gelten hier NICHT)');
const NORM = new Function('return ' + src.slice(src.indexOf('var EKGNORM={') + 'var EKGNORM='.length,
  src.indexOf('\n};', src.indexOf('var EKGNORM={')) + 2))();
pruef('Hund, Katze und Pferd gefuehrt', !!(NORM.hund && NORM.katze && NORM.pferd));
pruef('Katzen-QRS-Grenze ist 40 ms, nicht die Humangrenze 120', NORM.katze.qrs[1] === 40);
pruef('Hunde-QRS-Grenze ist 60 ms', NORM.hund.qrs[1] === 60);
pruef('Katze hat ein HOEHERES Frequenzband als der Hund',
  NORM.katze.hf[0] > NORM.hund.hf[0] && NORM.katze.hf[1] > NORM.hund.hf[1],
  'Hund ' + NORM.hund.hf.join('-') + ' / Katze ' + NORM.katze.hf.join('-'));
pruef('Katzen-R-Amplitude deutlich kleiner als beim Hund', NORM.katze.rAmp[1] < NORM.hund.rAmp[1],
  'Katze ' + NORM.katze.rAmp[1] + ' mV / Hund ' + NORM.hund.rAmp[1] + ' mV');
pruef('Katze startet auf 50 mm/s (0,04 s QRS waeren bei 25 nur 1 mm)', NORM.katze.speed === 50);
pruef('Hund startet auf 25 mm/s', NORM.hund.speed === 25);
pruef('Achsensektor Hund enger als bei der Katze',
  (NORM.hund.achse[1] - NORM.hund.achse[0]) < (NORM.katze.achse[1] - NORM.katze.achse[0]));
pruef('beim Pferd ist die Frontalachse ausdruecklich NICHT hinterlegt', NORM.pferd.achse === null);
pruef('Sinusarrhythmie: beim Hund normal, bei der Katze auffaellig',
  NORM.hund.sinusarrhythmie === 'normal' && NORM.katze.sinusarrhythmie === 'auffaellig');

const normUrteil = new Function('return ' + holeFunktion('normUrteil'))();
pruef('QRS 55 ms ist beim Hund normal', normUrteil(NORM.hund.qrs, 55, 'ms').ok === true);
pruef('QRS 55 ms ist bei der Katze zu breit', normUrteil(NORM.katze.qrs, 55, 'ms').ok === false);
pruef('HF 200 ist beim Hund zu schnell', normUrteil(NORM.hund.hf, 200).ok === false);
pruef('HF 200 ist bei der Katze normal', normUrteil(NORM.katze.hf, 200).ok === true);
pruef('ohne Band wird NICHT bewertet', normUrteil(null, 55) === null);
pruef('ohne Messwert wird NICHT bewertet', normUrteil(NORM.hund.qrs, null) === null);

const qtcV = new Function('return ' + holeFunktion('qtcVanDeWater'))();
/* Van de Water: QTcV = QT - 0,087 * ((60/HF) - 1), QT in Sekunden.
 * Gegenrechnung bei HF 60: (60/60)-1 = 0 -> QTcV == QT. Das ist der Fixpunkt der Formel. */
pruef('Van de Water: bei HF 60 bleibt QT unveraendert', qtcV(200, 60) === 200, 'gerechnet ' + qtcV(200, 60));
const q120 = qtcV(200, 120);           // 0,2 - 0,087*((0,5)-1) = 0,2 + 0,0435 = 0,2435 s
pruef('bei HF 120 wird VERLAENGERT (243 ms aus 200 ms)', q120 === 244 || q120 === 243, 'gerechnet ' + q120);
const q30 = qtcV(200, 30);             // 0,2 - 0,087*((2)-1) = 0,113 s
pruef('bei HF 30 wird VERKUERZT (113 ms aus 200 ms)', q30 === 113, 'gerechnet ' + q30);
pruef('ohne Frequenz keine Korrektur', qtcV(200, 0) === null);
pruef('Bazett wird NICHT angeboten (beim Tier irrefuehrend)',
  !/bazett/i.test(ohneKommentare), 'im Code gefunden');

const netto = new Function('return ' + holeFunktion('nettoAusschlag'))();
pruef('Nettoausschlag: rein positiv', Math.abs(netto(new Array(12).fill(0).map((_, i) => i === 6 ? 1 : 0)) - 1) < 1e-9);
pruef('Nettoausschlag: positiv und negativ heben sich auf',
  Math.abs(netto([0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0])) < 1e-9);
pruef('Nettoausschlag: ueberwiegend negativ ergibt negativ',
  netto([0, 0, 0, 0.3, 0, 0, -1, 0, 0, 0, 0, 0]) < 0);
pruef('zu kurzer Streifen ergibt nichts', netto([1, 2, 3]) === null);
/*
 * ACHSE — DIE SKALENKORREKTUR IST DER GANZE PUNKT.
 * Die erste Fassung rechnete atan2(aVF, I). Das ist die verbreitete, aber UNKORRIGIERTE
 * Formel: aVF misst denselben Vektor um sqrt(3)/2 kleiner als die bipolaren Ableitungen.
 * Ergebnis waren durchweg zu kleine Winkelbetraege — also eine scheinbar normalere Achse.
 * Diese Pruefungen rechnen den Unterschied nach, statt nur nach Zeichen zu suchen.
 */
const achseSrc = holeFunktion('achseRechnen');
pruef('MEA nutzt atan2 (nicht atan — sonst Vorzeichenfehler ueber +/-90 Grad)',
  /Math\.atan2\(/.test(achseSrc) && !/Math\.atan\(/.test(achseSrc));
pruef('die augmentierte Ableitung wird skalenkorrigiert (Faktor 2/sqrt(3))',
  /nF\s*\*\s*2\s*\/\s*Math\.sqrt\(3\)/.test(achseSrc));
const meaVon = (nI, nF) => Math.round(Math.atan2(nF * 2 / Math.sqrt(3), nI) * 180 / Math.PI);
/*
 * DER EIGENTLICHE BEWEIS: derselbe Winkel ueber ZWEI unabhaengige Ableitungspaare.
 * Physik dahinter — bei einem Herzvektor der Groesse A unter dem Winkel t gilt
 *     I   = A * cos(t)
 *     aVF = (II + III)/2 = A * sin(t) * sqrt(3)/2      <- deshalb die Korrektur 2/sqrt(3)
 *     III = A * cos(t - 120 Grad)
 * Der zweite, in der Tiermedizin gebraeuchliche Weg rechnet y = (I + 2*III)/sqrt(3).
 * Beide muessen denselben Winkel liefern. Waere die Skalenkorrektur falsch (oder fehlte
 * sie, wie in der ersten Fassung), gingen die beiden Wege auseinander — genau das faengt
 * diese Pruefung ab, und eine blosse Zeichensuche haette es nie gefunden.
 */
[-75, -30, 0, 25, 49, 70, 100, 140, 179].forEach((t) => {
  const rad = t * Math.PI / 180, A = 1.4;
  const nI = A * Math.cos(rad);
  const nF = A * Math.sin(rad) * Math.sqrt(3) / 2;
  const nIII = A * Math.cos(rad - 120 * Math.PI / 180);
  const ueberAVF = meaVon(nI, nF);
  const ueberIII = Math.round(Math.atan2((nI + 2 * nIII) / Math.sqrt(3), nI) * 180 / Math.PI);
  pruef('Achse ' + t + ' Grad: I/aVF und I/III stimmen ueberein',
    ueberAVF === t && ueberIII === t, 'aVF-Weg ' + ueberAVF + ', III-Weg ' + ueberIII);
});
// Und der Gegenbeweis: OHNE Korrektur weichen die beiden Wege auseinander.
(function () {
  // Der Fehler der unkorrigierten Formel ist um 45 Grad herum am groessten.
  const t = 45, rad = t * Math.PI / 180, A = 1.4;
  const nI = A * Math.cos(rad), nF = A * Math.sin(rad) * Math.sqrt(3) / 2;
  const ohne = Math.round(Math.atan2(nF, nI) * 180 / Math.PI);
  const mit = meaVon(nI, nF);
  pruef('mit Korrektur kommt genau 45 Grad heraus', mit === t, 'gerechnet ' + mit);
  pruef('ohne Korrektur waere die Achse faelschlich flacher (Gegenbeweis)',
    ohne < t, 'unkorrigiert ' + ohne + ' statt ' + t + ' — Fehler ' + (t - ohne) + ' Grad');
})();
pruef('nur Ableitung I positiv = 0 Grad', meaVon(1, 0) === 0);
pruef('nur aVF positiv = +90 Grad', meaVon(0, 1) === 90);
pruef('I negativ, aVF positiv = Rechtsverschiebung ueber +90 Grad', meaVon(-1, 1) > 90);
pruef('I negativ, aVF negativ ergibt einen NEGATIVEN Winkel jenseits -90 Grad (atan2-Beweis)',
  meaVon(-1, -1) < -90, 'gerechnet ' + meaVon(-1, -1));
pruef('die Korrektur vergroessert den Betrag gegenueber der unkorrigierten Formel',
  Math.abs(meaVon(1, 1)) > Math.abs(Math.round(Math.atan2(1, 1) * 180 / Math.PI)));

// ---------------------------------------------------------------------------
block('16. Grenzen der Aussage werden benannt statt ueberspielt');
pruef('Van de Water gilt nur fuer den Hund (an narkotisierten Hunden abgeleitet)',
  /function qtcErlaubt\(sp\)\{ return sp==='hund'; \}/.test(src));
pruef('QTc erscheint am Messzirkel nur bei erlaubter Art', /qtcErlaubt\(f\.sp\)/.test(holeFunktion('zZeigeMesswerte')));
pruef('die ST-Grenzen werden als Orientierung gezeigt, nicht als Urteil',
  /Orientierung/.test(holeFunktion('updateMeasures')) && /Quellenlage schwach/.test(holeFunktion('updateMeasures')));
pruef('der humanmedizinische ST-Messpunkt J+60\\/80 ms ist ausdruecklich ausgeschlossen',
  /J\+60\/80 ms hier NICHT/.test(src));

// ---------------------------------------------------------------------------
block('17. Artefakte ausklammern (Funktion des Original-PC-EKG)');
/*
 * Der Hersteller nennt "Erkennen von eventuellen Artefakten und Ausklammern per Mausklick"
 * ausdruecklich als Merkmal des Geraets. Der Grund ist klinisch: Zittern oder ein
 * verrutschtes Kabel erzeugt Zacken, die jede Zackensuche als Schlaege zaehlt — aus Rauschen
 * wird "unregelmaessig mit vorzeitigen Schlaegen". Ausgeklammerte Stellen gehen deshalb als
 * null in die Auswertung; ekg-analyse.js zaehlt null als Luecke und schweigt ab 20 %.
 */
pruef('Ausklammer-Knopf vorhanden', /id="zArt"/.test(ohneSkript));
pruef('ausgeklammerte Abschnitte werden gefuehrt', /aus:\s*\[\]/.test(src));
pruef('die Auswertung rechnet auf dem BEREINIGTEN Streifen',
  /samples:streifenFuerMessung\(\)/.test(holeFunktion('echtBefund')));
pruef('Ausklammern nur im Rhythmusstreifen (dort wird gemessen)',
  /if\(Z\.lead!=='RHY'\)\{ flash/.test(src));
pruef('beim Ausklammern haelt das Bild an', /if\(!M\.freeze\)\{ M\.freeze=true; syncBtns\(\); \}/.test(src));
pruef('Zuruecksetzen hebt die Ausklammerungen auf und misst neu',
  /Z\.aus=\[\][\s\S]{0,120}updateMeasures\(\)/.test(src));

const istAus = new Function('Z', 'return ' + holeFunktion('istAusgeklammert') + ';');
const sfm = new Function('M', 'Z', 'istAusgeklammert', 'return ' + holeFunktion('streifenFuerMessung') + ';');
const Zf = { aus: [{ von: 3, bis: 5 }] };
const Mf = { strip: [1, 2, 3, 4, 5, 6, 7, 8] };
const bereinigt = sfm(Mf, Zf, istAus(Zf))();
pruef('ausgeklammerte Werte werden zu null', bereinigt[3] === null && bereinigt[4] === null && bereinigt[5] === null,
  JSON.stringify(bereinigt));
pruef('alles ausserhalb bleibt unveraendert',
  bereinigt[0] === 1 && bereinigt[2] === 3 && bereinigt[6] === 7 && bereinigt[7] === 8);
pruef('ohne Ausklammerung wird nichts angefasst',
  JSON.stringify(sfm(Mf, { aus: [] }, istAus({ aus: [] }))()) === JSON.stringify(Mf.strip));
pruef('das Original bleibt unberuehrt (es wird eine Kopie gemessen)',
  Mf.strip[3] === 4, 'strip[3]=' + Mf.strip[3]);

// Gegenprobe an der ECHTEN Auswertung: Rauschen als Artefakt ausklammern muss den
// Extrasystolen-Fehlbefund verhindern.
const VS = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-analyse.js'));
(function () {
  const hz = 256, sek = 6, n = hz * sek, per = hz * 60 / 120;
  const s = [];
  for (let i = 0; i < n; i++) {
    const ph = (i % per) / per;
    s.push(1000 * Math.exp(-Math.pow((ph - 0.335) / 0.010, 2) / 2));
  }
  // Ein kraeftiger Stoerabschnitt in der Mitte (Zittern), fester Verlauf statt Zufall.
  const vonS = Math.floor(n * 0.45), bisS = Math.floor(n * 0.60);
  for (let i = vonS; i <= bisS; i++) s[i] += 900 * Math.sin(i * 2.7) * Math.cos(i * 0.9);
  const mitStoerung = VS.analysiere({ samples: s.slice(), hz: hz }, {});
  const ohne = s.slice(); for (let i = vonS; i <= bisS; i++) ohne[i] = null;
  const nachAus = VS.analysiere({ samples: ohne, hz: hz }, {});
  pruef('die Stoerung veraendert den Befund ueberhaupt (sonst waere der Test blind)',
    mitStoerung.schlaege !== nachAus.schlaege || mitStoerung.brauchbar !== nachAus.brauchbar,
    'mit ' + mitStoerung.schlaege + ' Zacken, ohne ' + nachAus.schlaege);
  pruef('nach dem Ausklammern bleibt der Streifen auswertbar',
    nachAus.brauchbar === true, nachAus.warum || '');
  pruef('und die Frequenz stimmt wieder (120/min +/- 6)',
    nachAus.hf != null && Math.abs(nachAus.hf - 120) <= 6, 'gemessen ' + nachAus.hf);
})();

// ---------------------------------------------------------------------------
block('18. Hinweis-Maschine: sagt was auffaellt, stellt KEINE Diagnose');
const regelnSrc = src.slice(src.indexOf('var BEFUNDREGELN=['), src.indexOf('\n];', src.indexOf('var BEFUNDREGELN=[')) + 2);
/* ==================================================================================
 * DIE SANDKISTE MUSS ALLES ENTHALTEN, WAS EINE REGEL AUFRUFT (09.08.2026)
 *
 * Die Regelkoerper werden hier in einem eigenen Gueltigkeitsbereich uebersetzt. Ruft eine
 * Regel eine Hilfsfunktion aus index.html, die hier fehlt, wirft sie zur Laufzeit - und
 * befundHinweise() faengt das bewusst ab ("eine kaputte Regel schweigt", damit ein Fehler
 * nicht das ganze EKG anhaelt). Im Test heisst das: die Regel wird still uebersprungen und
 * der Test wird GRUEN ueber einer toten Regel.
 *
 * Genau das ist beim Einbau von jungtierBand() passiert. Die Hilfsfunktionen werden deshalb
 * mit uebersetzt, und weiter unten steht die Gegenprobe, dass keine Regel wirft.
 * ================================================================================== */
const hilfSrc =
  src.slice(src.indexOf('var JUNGTIER='), src.indexOf('\n', src.indexOf('var JUNGTIER='))) + '\n' +
  holeFunktion('jungtierBand') + '\n';
const REGELN = new Function(hilfSrc + 'return ' + regelnSrc.slice('var BEFUNDREGELN='.length))();
const befundHinweise = new Function('BEFUNDREGELN', 'fuelle',
  'return ' + holeFunktion('befundHinweise') + ';')(REGELN, new Function('return ' + holeFunktion('fuelle'))());

/* KEINE REGEL DARF WERFEN. befundHinweise() verschluckt Fehler bewusst, damit eine kaputte
 * Regel nicht das ganze EKG anhaelt - genau deshalb braucht es hier die Gegenprobe. */
{
  const ktx = {
    sp: 'hund', hf: 200, band: [70, 160], qrs: 55, qrsGrenze: 60, guete: 20, speed: 25,
    kal: true, echt: true, rAmp: 3.5, rOben: 3.0, achse: 70, achseBand: [40, 100],
    alterJahre: 0.25, vorzeitig: true, rassePraedAktiv: true, rassePraedName: 'X', rassePraedTun: 'Y',
    rrSchwankung: 0.3, windhund: false, alterText: '3 Monate',
  };
  const kaputt = [];
  REGELN.forEach((R) => {
    try { R.pruef(ktx); } catch (e) { kaputt.push(R.id + ': ' + e.message); }
  });
  pruef('keine Regel wirft bei vollstaendigem Kontext', kaputt.length === 0, kaputt.join(' | '));
}

pruef('Regeln vorhanden', REGELN.length >= 8, REGELN.length + ' Regeln');
REGELN.forEach((R) => {
  pruef('Regel "' + R.id + '" hat Quelle, Sicherheit, Stufe und Tierart',
    !!R.quelle && !!R.sicherheit && !!R.stufe && !!R.art);
});
pruef('jede Regel ist als Hinweis formuliert (kein "muss"/"sofort geben")',
  !REGELN.some((R) => /\bmuss (sofort|jetzt)\b|\bverabreichen\b|\bgeben Sie\b/i.test(R.hinweis)));

// --- Der Artunterschied, der am leichtesten falsch herum programmiert wird ---
const basis = { hf: 120, qrs: 40, guete: 20, achse: 60, speed: 50, kal: true, echt: true,
  band: [120, 240], qrsGrenze: 40, achseBand: [0, 160], rrSchwankung: 0.2, vorzeitig: false };
const hund = befundHinweise(Object.assign({}, basis, { sp: 'hund', band: [70, 160], qrsGrenze: 60, achseBand: [40, 100], hf: 100 }));
const katze = befundHinweise(Object.assign({}, basis, { sp: 'katze' }));
pruef('Sinusarrhythmie: beim HUND als physiologisch eingeordnet',
  hund.some((t) => t.id === 'sinusarrhythmie-hund' && t.stufe === 'hinweis'));
pruef('Sinusarrhythmie: bei der KATZE als auffaellig eingeordnet',
  katze.some((t) => t.id === 'sinusarrhythmie-katze' && t.stufe === 'auffaellig'));
pruef('die Hunde-Regel greift NICHT bei der Katze', !katze.some((t) => t.id === 'sinusarrhythmie-hund'));
pruef('die Katzen-Regel greift NICHT beim Hund', !hund.some((t) => t.id === 'sinusarrhythmie-katze'));

// --- QRS-Grenze artabhaengig ---
const q55hund = befundHinweise({ sp: 'hund', qrs: 55, qrsGrenze: 60, guete: 20, speed: 25, kal: true, echt: true });
const q55katze = befundHinweise({ sp: 'katze', qrs: 55, qrsGrenze: 40, guete: 20, speed: 50, kal: true, echt: true });
pruef('QRS 55 ms loest beim Hund KEINEN Befund aus', !q55hund.some((t) => t.id === 'qrs-breit'));
pruef('QRS 55 ms loest bei der Katze einen Befund aus', q55katze.some((t) => t.id === 'qrs-breit'));
pruef('der Hinweis nennt ausdruecklich, dass 120 ms hier nicht gilt',
  /120 ms gilt hier ausdr/.test(q55katze.find((t) => t.id === 'qrs-breit').text));

/* ==================================================================================
 * DAS ALTER AENDERT DIE BEWERTUNG — nicht nur die Anzeige (09.08.2026)
 *
 * Bei der Gegenpruefung gemessen: alterJahre stand im Regelkontext und wurde von KEINER
 * Regel gelesen. Der Tierarzt gab ein Geburtsdatum ein, sah es auf dem Blatt und im
 * Ausdruck - und durfte annehmen, die Bewertung beruecksichtige es. Sie tat es nicht.
 * Diese Pruefungen halten fest, dass es jetzt wirkt: DERSELBE Streifen, nur ein anderes
 * Alter, muss zu einer anderen Meldung fuehren.
 * ============================================================================== */
{
  const streifen = (alter) => befundHinweise({
    sp: 'hund', hf: 190, band: [70, 160], guete: 20, speed: 25, kal: true, echt: true,
    alterJahre: alter, alterText: alter === null ? 'ohne Altersangabe' : (alter * 12) + ' Monate',
  });
  const welpe = streifen(0.25);        /* drei Monate */
  const erwachsen = streifen(4);
  const ohneAlter = streifen(null);
  pruef('190/min beim ERWACHSENEN Hund ist ein Befund', erwachsen.some((t) => t.id === 'hf-hoch'));
  pruef('190/min beim drei Monate alten Welpen NICHT', !welpe.some((t) => t.id === 'hf-hoch'),
    welpe.map((t) => t.id).join(','));
  pruef('stattdessen wird erklaert, warum nicht', welpe.some((t) => t.id === 'jungtier-hf'));
  pruef('und der Hinweis nennt das Alter', /Monate/.test((welpe.find((t) => t.id === 'jungtier-hf') || {}).text || ''));
  /* OHNE ALTER GREIFT DIE AUSNAHME NICHT. "Wir wissen es nicht" darf keine Tachykardie
   * unterdruecken - das waere die gefaehrliche Richtung dieses Fehlers. */
  pruef('ohne Altersangabe bleibt es beim Befund', ohneAlter.some((t) => t.id === 'hf-hoch'));
  pruef('und es wird nichts als jungtiertypisch erklaert', !ohneAlter.some((t) => t.id === 'jungtier-hf'));
  /* Die Ausnahme hat eine OBERGRENZE. 260/min ist auch beim Welpen ein Befund. */
  const rasend = befundHinweise({ sp: 'hund', hf: 260, band: [70, 160], guete: 20, speed: 25,
    kal: true, echt: true, alterJahre: 0.25, alterText: '3 Monate' });
  pruef('260/min ist auch beim Welpen ein Befund', rasend.some((t) => t.id === 'hf-hoch'));
  /* Und sie gilt nur fuer die Art, fuer die eine Zahl belegt ist. */
  const katzenkind = befundHinweise({ sp: 'katze', hf: 260, band: [100, 240], guete: 20, speed: 50,
    kal: true, echt: true, alterJahre: 0.25, alterText: '3 Monate' });
  pruef('fuer die Katze gibt es keine erfundene Jungtiergrenze', katzenkind.some((t) => t.id === 'hf-hoch'));
}
{
  /* Rasse + Alter + Streifen zusammen: erst diese Verbindung macht aus "worauf man bei
   * dieser Rasse schaut" eine Aussage ueber DIESES Tier. */
  const basisVes = { sp: 'hund', guete: 20, speed: 25, kal: true, echt: true, vorzeitig: true };
  const mit = befundHinweise(Object.assign({}, basisVes,
    { rassePraedAktiv: true, rassePraedName: 'DCM des Dobermanns', rassePraedTun: 'Holter.' }));
  const ohne = befundHinweise(Object.assign({}, basisVes, { rassePraedAktiv: false }));
  pruef('Extrasystole + einschlaegige Rasse -> eigener Befund', mit.some((t) => t.id === 'rasse-ektopie'));
  pruef('ohne einschlaegige Rasse nicht', !ohne.some((t) => t.id === 'rasse-ektopie'));
  pruef('und der Befund nennt die Erkrankung beim Namen',
    /DCM des Dobermanns/.test((mit.find((t) => t.id === 'rasse-ektopie') || {}).text || ''));
}

// --- Platzhalter werden wirklich gefuellt ---
const hf200 = befundHinweise({ sp: 'hund', hf: 200, band: [70, 160], guete: 20, speed: 25, kal: true, echt: true });
const tHf = hf200.find((t) => t.id === 'hf-hoch');
pruef('Messwerte stehen im Hinweistext', /200\/min/.test(tHf.text), tHf.text.slice(0, 60));
pruef('das Normband steht im Hinweistext', /70–160/.test(tHf.text));
pruef('kein Platzhalter bleibt ungefuellt', !/\{\w+\}/.test(tHf.text));

// --- Reihenfolge: Dringendes zuerst ---
const gemischt = befundHinweise({ sp: 'katze', hf: 300, band: [120, 240], qrs: 60, qrsGrenze: 40,
  guete: 3, speed: 25, kal: true, echt: true, achse: 200, achseBand: [0, 160] });
pruef('auffaellige Befunde stehen VOR Bedienhinweisen',
  gemischt.findIndex((t) => t.stufe === 'auffaellig') < gemischt.findIndex((t) => t.stufe === 'hinweis'),
  gemischt.map((t) => t.stufe).join(','));

// --- Schweigen im Zweifel ---
pruef('ohne Messwerte laeuft keine Wert-Regel',
  befundHinweise({ sp: 'hund', speed: 25, kal: true, echt: true }).every((t) => t.stufe === 'hinweis'));
pruef('ohne Messgroessen ueberhaupt: leere Liste statt Behauptung', befundHinweise(null).length === 0);
pruef('eine kaputte Regel legt die Maschine nicht lahm', (function () {
  const kaputt = [{ id: 'x', name: 'x', art: 'alle', stufe: 'hinweis', sicherheit: 's', quelle: 'q',
    hinweis: 'x', pruef: function () { throw new Error('kaputt'); } }];
  const f = new Function('BEFUNDREGELN', 'fuelle', 'return ' + holeFunktion('befundHinweise') + ';')(kaputt, () => '');
  return f({ sp: 'hund' }).length === 0;
})());
pruef('unkalibriert wird gemeldet, damit keine mV-Aussage erwartet wird',
  befundHinweise({ sp: 'hund', echt: true, kal: false, speed: 25 }).some((t) => t.id === 'unkalibriert'));

// --- Auf einer NACHGEBILDETEN Kurve wird nicht befundet (Zirkelschluss) ---
pruef('auf der Nachbildung laeuft die Befundung nicht',
  /Auf einer selbst erzeugten Kurve wird bewusst nicht befundet/.test(src));
pruef('der Haftungshinweis steht unter jeder Hinweisliste',
  /Hinweise, <b>keine Diagnose<\/b>/.test(holeFunktion('zeigeHinweise')));
pruef('es wird gesagt, dass ein unauffaelliges EKG nichts ausschliesst',
  /schließt eine Herzerkrankung <b>nicht aus<\/b>/.test(holeFunktion('zeigeHinweise')));
pruef('Vorschub-/Verstaerkungswechsel rechnet die Anzeige sofort neu',
  /function setSpeed\(v\)\{ M\.speed=v; syncBtns\(\); try\{ updateMeasures/.test(src));

// ---------------------------------------------------------------------------
block('19. Achse nur, wenn sie bestimmbar ist (Zirkelschluss behoben)');
/*
 * DER FEHLER, DEN DIE FACHRECHERCHE GEFUNDEN HAT (08.08.2026):
 * __setRealWave fuehrt genau EINEN EKG-Kanal (Ableitung II). Die uebrigen fuenf entstehen in
 * advance() als Projektion mit der ANGENOMMENEN Achse M.axis. achseRechnen() las genau diese
 * Puffer zurueck — das Ergebnis war zwangslaeufig eine Funktion der eigenen Annahme und nichts
 * ueber das Tier. Aus EINER Ableitung ist die Frontalachse nicht bestimmbar; es braucht zwei
 * unabhaengige. Schlimmer noch: darauf stand eine HINWEIS-Regel, die daraus eine Rechts- oder
 * Linksverschiebung behauptet haette.
 */
const achseSrc2 = holeFunktion('achseRechnen');
pruef('achseRechnen verlangt mindestens zwei GEMESSENE Ableitungen',
  /gemesseneAbleitungen\(\)<2\) return null/.test(achseSrc2));
pruef('bei nachgebildeter Kurve wird keine Achse gerechnet',
  /if\(!M\.echt\) return null/.test(achseSrc2));
pruef('es gibt eine Funktion, die die gemessenen Ableitungen zaehlt',
  /function gemesseneAbleitungen\(\)/.test(src));
const gAbl = new Function('echtEkg', 'return ' + holeFunktion('gemesseneAbleitungen') + ';');
pruef('mit echtem Kanal: 1 gemessene Ableitung', gAbl(() => ({ samples: [1, 2, 3, 4] }))() === 1);
pruef('ohne echten Kanal: 0', gAbl(() => null)() === 0);
// Die Rechnung selbst muss bei zu wenigen Ableitungen null liefern.
const achseFn = new Function('M', 'nettoAusschlag', 'gemesseneAbleitungen',
  'return ' + achseSrc2 + ';');
const bufFake = { I: new Array(20).fill(0).map((_, i) => i === 10 ? 1 : 0), aVF: new Array(20).fill(0).map((_, i) => i === 10 ? 1 : 0) };
const nettoFn = new Function('return ' + holeFunktion('nettoAusschlag'))();
pruef('echtes Signal mit nur 1 Ableitung -> KEINE Achse',
  achseFn({ echt: true, buf: bufFake }, nettoFn, () => 1)() === null);
pruef('echtes Signal mit 2 Ableitungen -> Achse wird gerechnet',
  achseFn({ echt: true, buf: bufFake }, nettoFn, () => 2)() !== null);
pruef('Nachbildung -> KEINE gerechnete Achse',
  achseFn({ echt: false, buf: bufFake }, nettoFn, () => 2)() === null);

// Die Hinweis-Regel darf ohne zwei Ableitungen nicht feuern.
const achseRegel = REGELN.find((R) => R.id === 'achse-ausserhalb');
pruef('die Achsen-Regel verlangt ablGemessen >= 2', /m\.ablGemessen>=2/.test(String(achseRegel.pruef)));
pruef('Achse 200 Grad bei 1 gemessenen Ableitung loest KEINEN Befund aus',
  !befundHinweise({ sp: 'hund', achse: 200, achseBand: [40, 100], ablGemessen: 1, guete: 20, speed: 25, kal: true, echt: true })
    .some((t) => t.id === 'achse-ausserhalb'));
pruef('Achse 200 Grad bei 2 gemessenen Ableitungen loest einen Befund aus',
  befundHinweise({ sp: 'hund', achse: 200, achseBand: [40, 100], ablGemessen: 2, guete: 20, speed: 25, kal: true, echt: true })
    .some((t) => t.id === 'achse-ausserhalb'));
pruef('die Anzeige sagt, warum die Achse fehlt', /für die Achse sind 2 nötig/.test(holeFunktion('updateMeasures')));
pruef('gerechnete Ableitungen werden im Raster als gerechnet beschriftet',
  /gemessen\?'gemessen':'gerechnet'/.test(holeFunktion('drawLeadCanvas')));

// ---------------------------------------------------------------------------
block('20. Wissensbasis: 203 belegte Regeln, ehrlich getrennt');
const BEF = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-befunde.js'));
pruef('Wissensbasis laedt', BEF.anzahl >= 200, BEF.anzahl + ' Regeln');
pruef('jede Regel hat eine Quelle', BEF.REGELN.every((r) => r.quelle && r.quelle.length > 3));
pruef('jede Regel hat eine messbar formulierte Bedingung', BEF.REGELN.every((r) => r.bedingung && r.bedingung.length > 14));
pruef('jede Regel hat einen Hinweistext', BEF.REGELN.every((r) => r.hinweis && r.hinweis.length > 14));
pruef('jede Regel traegt eine Tierart',
  BEF.REGELN.every((r) => ['hund', 'katze', 'beide', 'alle', 'pferd', 'heimtier'].indexOf(r.art) >= 0));
pruef('keine doppelten Kennungen', (function () {
  const s = {}; let d = 0; BEF.REGELN.forEach((r) => { if (s[r.id]) d++; s[r.id] = 1; }); return d === 0;
})());
pruef('Artfilter: Hunderegeln enthalten keine reinen Katzenregeln',
  !BEF.fuerArt('hund').some((r) => r.art === 'katze'));
pruef('Artfilter: "beide" erscheint bei Hund UND Katze',
  BEF.fuerArt('hund').some((r) => r.art === 'beide') && BEF.fuerArt('katze').some((r) => r.art === 'beide'));
pruef('Artfilter: "alle" erscheint auch beim Pferd', BEF.fuerArt('pferd').some((r) => r.art === 'alle'));
pruef('Suche findet Vorhofflimmern', BEF.suche('vorhofflimmern').length > 5);
pruef('Suche findet Rassebezuege (Dobermann)', BEF.suche('dobermann').length > 0);
pruef('Suche ohne Treffer liefert leer, nicht alles', BEF.suche('zzzgibtesnicht').length === 0);

/* DIE EHRLICHE TRENNUNG — der Kern dieser Erweiterung.
 * Nur ein Teil der Regeln ist mit den heute erhobenen Messgroessen pruefbar. Der Rest steht
 * zum NACHSCHLAGEN da und wird ausdruecklich nicht automatisch behauptet. */
const HEUTE = ['hf', 'rr', 'rrschwankung', 'qrs', 'guete', 'signalguete', 'st', 'sekunden', 'schlaege', 'vorzeitig', 'ramp'];
const autoZahl = BEF.REGELN.filter((r) => BEF.machbar(r, HEUTE)).length;
pruef('ein Teil der Regeln ist automatisch pruefbar', autoZahl >= 15, autoZahl + ' von ' + BEF.anzahl);
pruef('die MEISTEN sind es NICHT - und das ist der ehrliche Befund',
  autoZahl < BEF.anzahl * 0.3, autoZahl + ' von ' + BEF.anzahl + ' automatisch pruefbar');
pruef('machbar() verlangt ALLE benoetigten Messgroessen',
  BEF.machbar({ mess: ['hf', 'qrs'] }, HEUTE) === true &&
  BEF.machbar({ mess: ['hf', 'pdauer'] }, HEUTE) === false);
pruef('ohne Messgroessen gilt eine Regel NICHT als automatisch pruefbar',
  BEF.machbar({ mess: [] }, HEUTE) === false);
pruef('die Messgroessenliste steht an EINER Stelle im Modul',
  /var MESSGROESSEN_HEUTE=\[/.test(src));
pruef('das Nachschlagewerk sagt, dass nur Messbares behauptet wird',
  /behauptet davon nur, was sie messen kann/.test(holeFunktion('renderWissen')));

// ---------------------------------------------------------------------------
block('21. Neue Messgroessen und die Regeln darauf');
pruef('R-Amplitude wird mitgemessen', /erg\.rAmpMv=Math\.round/.test(holeFunktion('echtBefund')));
pruef('R-Amplitude NUR bei bekannter Verstaerkung', /if\(M\.kal && erg && erg\.brauchbar/.test(holeFunktion('echtBefund')));
pruef('sie wird als Median gebildet (ein Ausreisser kippt sie nicht)', /VS\.ekg\.median\(betr\)/.test(holeFunktion('echtBefund')));
const NORM2 = new Function('return ' + src.slice(src.indexOf('var EKGNORM={') + 'var EKGNORM='.length,
  src.indexOf('\n};', src.indexOf('var EKGNORM={')) + 2))();
pruef('Hund: Niedervoltage-Grenze 1,0 mV', NORM2.hund.rAmp[0] === 1.0);
pruef('Katze: Niedervoltage-Grenze 0,2 mV', NORM2.katze.rAmp[0] === 0.2);
pruef('Katzen-Obergrenze deutlich unter der des Hundes', NORM2.katze.rAmp[1] < NORM2.hund.rAmp[1]);

const R2 = new Function('return ' + src.slice(src.indexOf('var BEFUNDREGELN=['), src.indexOf('\n];', src.indexOf('var BEFUNDREGELN=[')) + 2).slice('var BEFUNDREGELN='.length))();
const bh2 = new Function('BEFUNDREGELN', 'fuelle', 'return ' + holeFunktion('befundHinweise') + ';')(R2, new Function('return ' + holeFunktion('fuelle'))());
const basisR = { sp: 'hund', guete: 20, speed: 25, kal: true, echt: true, rUnten: 1.0, rOben: 3.0 };
pruef('R 0,6 mV beim Hund -> Niedervoltage',
  bh2(Object.assign({}, basisR, { rAmp: 0.6 })).some((t) => t.id === 'niedervoltage'));
pruef('R 2,0 mV beim Hund -> kein Amplitudenbefund',
  !bh2(Object.assign({}, basisR, { rAmp: 2.0 })).some((t) => t.id === 'niedervoltage' || t.id === 'r-hoch'));
pruef('R 4,0 mV beim Hund -> hohe R-Amplitude',
  bh2(Object.assign({}, basisR, { rAmp: 4.0 })).some((t) => t.id === 'r-hoch'));
/* Die Ausnahme, die einen Fehlbefund verhindert: beim Windhund ist ein hohes R normal. */
pruef('R 4,0 mV beim WINDHUND -> KEIN Vergroesserungsverdacht',
  !bh2(Object.assign({}, basisR, { rAmp: 4.0, windhund: true })).some((t) => t.id === 'r-hoch'));
pruef('sondern der Hinweis, dass das rassetypisch ist',
  bh2(Object.assign({}, basisR, { rAmp: 4.0, windhund: true })).some((t) => t.id === 'windhund-normal'));
pruef('ohne Kalibrierung KEIN Amplitudenbefund',
  !bh2(Object.assign({}, basisR, { rAmp: 0.6, kal: false })).some((t) => t.id === 'niedervoltage'));
pruef('lange Pause beim Hund ab 3000 ms', bh2(Object.assign({}, basisR, { rrMax: 3200 })).some((t) => t.id === 'pause-lang'));
pruef('bei der Katze schon ab 2000 ms',
  bh2({ sp: 'katze', guete: 20, speed: 50, kal: true, echt: true, rrMax: 2200 }).some((t) => t.id === 'pause-lang'));
pruef('kurze Pause loest nichts aus', !bh2(Object.assign({}, basisR, { rrMax: 900 })).some((t) => t.id === 'pause-lang'));

pruef('updateMeasures schreibt nur, wenn das Messfeld dasteht', /if\(!\$\('#mHr'\)\) return;/.test(src));

// ---------------------------------------------------------------------------
block('22. Der eigene Filter darf keinen Befund erzeugen');
/*
 * BEFUND DER GERAETERECHERCHE (08.08.2026): ein Muskelfilter (Tiefpass ~40 Hz) SENKT die
 * R-Amplitude. Ohne Sperre haette die Anwendung eine "Niedervoltage" gemeldet, die sie mit
 * ihrem EIGENEN Filter erzeugt hat — und daraus einen Perikarderguss-Verdacht abgeleitet.
 */
const R3 = new Function('return ' + src.slice(src.indexOf('var BEFUNDREGELN=['), src.indexOf('\n];', src.indexOf('var BEFUNDREGELN=[')) + 2).slice('var BEFUNDREGELN='.length))();
const bh3 = new Function('BEFUNDREGELN', 'fuelle', 'return ' + holeFunktion('befundHinweise') + ';')(R3, new Function('return ' + holeFunktion('fuelle'))());
const mFilt = { sp: 'hund', guete: 20, speed: 25, kal: true, echt: true, rUnten: 1.0, rOben: 3.0, rAmp: 0.6 };
pruef('ohne Filter: Niedervoltage wird gemeldet',
  bh3(Object.assign({}, mFilt, { filterAmp: false })).some((t) => t.id === 'niedervoltage'));
pruef('MIT Muskelfilter: KEINE Niedervoltage (der Filter senkt die Amplitude selbst)',
  !bh3(Object.assign({}, mFilt, { filterAmp: true })).some((t) => t.id === 'niedervoltage'));
pruef('MIT Muskelfilter: auch kein hohes R',
  !bh3(Object.assign({}, mFilt, { filterAmp: true, rAmp: 4.0 })).some((t) => t.id === 'r-hoch'));
pruef('stattdessen der Hinweis, warum keine Amplitudenaussage kommt',
  bh3(Object.assign({}, mFilt, { filterAmp: true })).some((t) => t.id === 'filter-amplitude'));
pruef('der Filterzustand wird aus M.musk gespeist', /filterAmp:!!M\.musk/.test(src));

block('23. Lagerung entscheidet über die Gültigkeit der Normwerte');
pruef('Lagerung wird gefuehrt und ist mit rechter Seitenlage vorbelegt',
  /lagerung:'rechte Seitenlage'/.test(src));
pruef('Auswahlfeld im Patientenblatt', /id="pLag"/.test(src));
pruef('rechte Seitenlage loest KEINEN Hinweis aus',
  !bh3(Object.assign({}, mFilt, { lagerungAbweichend: false })).some((t) => t.id === 'lagerung'));
pruef('abweichende Lagerung loest einen Hinweis aus',
  bh3(Object.assign({}, mFilt, { lagerungAbweichend: true, lagerung: 'stehend' })).some((t) => t.id === 'lagerung'));
pruef('der Hinweis nennt die eingetragene Lagerung',
  /stehend/.test(bh3(Object.assign({}, mFilt, { lagerungAbweichend: true, lagerung: 'stehend' })).find((t) => t.id === 'lagerung').text));
pruef('und sagt, dass der Rhythmus weiterhin beurteilbar bleibt',
  /Rhythmus bleibt beurteilbar/.test(bh3(Object.assign({}, mFilt, { lagerungAbweichend: true, lagerung: 'stehend' })).find((t) => t.id === 'lagerung').text));
pruef('die Lagerung steht auf dem Ausdruck', /zeile2\.push\('Lagerung: '/.test(holeFunktion('buildPDF')));

// ---------------------------------------------------------------------------
block('24. Kabelfarben IEC/AHA – die gefaehrlichste Verwechslung');
const KAB = new Function('return ' + src.slice(src.indexOf('var KABEL={') + 'var KABEL='.length,
  src.indexOf('\n};', src.indexOf('var KABEL={')) + 2))();
pruef('beide Normen gefuehrt', !!(KAB.IEC && KAB.AHA));
pruef('IEC: ROT ist die rechte VORDERgliedmaesse', KAB.IEC.RA.t === 'rot');
pruef('AHA: ROT ist die linke HINTERgliedmaesse', KAB.AHA.LL.t === 'rot');
pruef('genau darin liegt die Falle: dieselbe Farbe, andere Gliedmaesse',
  KAB.IEC.RA.t === KAB.AHA.LL.t && KAB.IEC.RA.t !== KAB.AHA.RA.t);
pruef('IEC: gelb = linke Vorder, gruen = linke Hinter, schwarz = Neutral',
  KAB.IEC.LA.t === 'gelb' && KAB.IEC.LL.t === 'grün' && KAB.IEC.RL.t === 'schwarz');
pruef('AHA: weiss = rechte Vorder, schwarz = linke Vorder, gruen = Neutral',
  KAB.AHA.RA.t === 'weiß' && KAB.AHA.LA.t === 'schwarz' && KAB.AHA.RL.t === 'grün');
pruef('Brustwand in beiden Normen braun', KAB.IEC.V.t === 'braun' && KAB.AHA.V.t === 'braun');
pruef('jede Norm hat einen Merksatz', KAB.IEC.merk.length > 10 && KAB.AHA.merk.length > 10);
/* ANLEGEGRAFIK JE TIERART (09.08.2026). Bis dahin gab es EINE Liste ANLEGEPUNKTE fuer alle
 * Arten. Das ist fachlich falsch: die Klemmen sitzen an Ellbogen und Knie, und wo diese
 * Gelenke liegen, haengt am Koerperbau. Ein Frettchen ist ein Schlauch auf sehr kurzen
 * Beinen - wer ihm die Punkte eines Hundeumrisses gibt, klemmt am Bauch.
 * Geprueft wird deshalb: es gibt eigene Bilder, ihre Punkte sind WIRKLICH verschieden,
 * und fuer Arten ohne eigenes Bild wird das gesagt statt ein fremdes gezeigt. */
const TB = new Function('return ' + src.slice(src.indexOf('var TIERBILD={'),
  src.indexOf('\n};', src.indexOf('var TIERBILD={')) + 2).slice('var TIERBILD='.length))();
const ARTEN_MIT_BILD = ['hund', 'katze', 'frettchen', 'kaninchen', 'nager', 'pferd'];
pruef('es gibt eigene Bilder je Tierart', ARTEN_MIT_BILD.every((a) => !!TB[a]),
  Object.keys(TB).join(','));
ARTEN_MIT_BILD.forEach((a) => {
  const b = TB[a];
  const soll = b.basisSpitze ? 3 : 4;   // Pferd: Basis-Spitzen-Ableitung, kein Einthoven
  pruef(a + ': ' + soll + ' Anlegepunkte mit Kuerzel und Ortsangabe',
    b.punkte.length === soll && b.punkte.every((p) => p.k && p.wo), b.punkte.length + ' Punkte');
  pruef(a + ': die Punkte liegen in der Zeichenflaeche (0..1)',
    b.punkte.every((p) => p.x > 0 && p.x < 1 && p.y > 0 && p.y < 1));
  pruef(a + ': Umriss, Kopf und Beine vorhanden', !!(b.koerper && b.kopf && b.beine));
});
['hund', 'katze', 'frettchen', 'kaninchen', 'nager'].forEach((a) => {
  pruef(a + ': alle vier Kuerzel genau einmal',
    ['RA', 'LA', 'LL', 'RL'].every((k) => TB[a].punkte.filter((p) => p.k === k).length === 1));
});
/* Der Kern: die Bilder muessen sich WIRKLICH unterscheiden. Sechs gleiche Umrisse unter
 * sechs Namen waeren schlimmer als einer, weil sie Genauigkeit vortaeuschen. */
{
  const umrisse = ARTEN_MIT_BILD.map((a) => TB[a].koerper);
  pruef('jeder Umriss ist ein anderer', new Set(umrisse).size === umrisse.length,
    new Set(umrisse).size + ' verschiedene von ' + umrisse.length);
  const ra = ARTEN_MIT_BILD.filter((a) => !TB[a].basisSpitze)
    .map((a) => TB[a].punkte.find((p) => p.k === 'RA'));
  pruef('auch die Anlegepunkte unterscheiden sich zwischen den Arten',
    new Set(ra.map((p) => p.x + '/' + p.y)).size === ra.length);
  /* Das Frettchen ist die Probe aufs Exempel: kurze Beine heisst TIEFER und WEITER VORN. */
  const f = TB.frettchen.punkte.find((p) => p.k === 'RA');
  const h = TB.hund.punkte.find((p) => p.k === 'RA');
  pruef('Frettchen: RA sitzt tiefer als beim Hund (kurze Beine)', f.y > h.y,
    'Frettchen y=' + f.y + ', Hund y=' + h.y);
  pruef('Frettchen: RA sitzt weiter vorn als beim Hund (langer Rumpf)', f.x < h.x,
    'Frettchen x=' + f.x + ', Hund x=' + h.x);
}
/* Pferd: Basis-Spitzen-Ableitung am STEHENDEN Tier, nicht Einthoven an den Gliedmassen. */
pruef('Pferd ist als Basis-Spitzen-Ableitung gekennzeichnet', TB.pferd.basisSpitze === true);
pruef('Pferd steht, es liegt nicht', /STEHEND/.test(TB.pferd.lage));
pruef('die Oberflaeche erklaert die Basis-Spitzen-Ableitung',
  /Basis-Spitzen-Ableitung/.test(holeFunktion('renderAnlegen')));
/* Vogel und Reptil: lieber KEIN Bild als ein falsches. */
pruef('Vogel und Reptil bekommen kein Gliedmassen-Bild',
  !/vogel:|reptil:/.test(src.slice(src.indexOf('var TIERBILD_ZUORDNUNG='), src.indexOf('};', src.indexOf('var TIERBILD_ZUORDNUNG=')))));
pruef('und die Oberflaeche sagt, warum', /nicht<\/b> nach Einthoven/.test(holeFunktion('renderAnlegen')));
/* Die Tierart kommt aus den Patientendaten, nicht aus dem Geraetestrom. */
pruef('die Anlegegrafik nimmt die Tierart aus patDaten()',
  /var d=patDaten\(\), sp=d\.sp/.test(holeFunktion('renderAnlegen')));
pruef('die Kopfzeile ebenfalls (nicht f.sp)',
  /function patChipText/.test(src) && !/ekgPat'\)\.textContent=speciesName\(f\.sp\)/.test(src));
pruef('intern wird mit Kuerzeln gerechnet, nicht mit Farben',
  /K\[p\.k\]/.test(holeFunktion('renderAnlegen')));
pruef('die Warnung vor der Verwechslung steht in der Oberflaeche',
  /Rot<\/b> ist bei IEC/.test(holeFunktion('renderAnlegen')));
pruef('die Kabelnorm steht auf dem Ausdruck', /zeile2\.push\('Kabelnorm: '/.test(holeFunktion('buildPDF')));
pruef('Vorgabe ist IEC (Europa)', /kabelnorm:'IEC'/.test(src));
pruef('rechte Seitenlage steht in der Anlegegrafik', /rechte Seitenlage/.test(holeFunktion('renderAnlegen')));

block('25. Patientenuebernahme vom Geraet, sonst von Hand mit ID');
pruef('der Feed meldet, ob ein Geraet angeschlossen ist', /amGeraet:!!\(mon\.real&&mon\.real\.ekg\)/.test(src));
pruef('der Feed reicht die Patienten-ID durch', /patId:\(state\.patientId\|\|null\)/.test(src));
pruef('ID-Feld im Patientenblatt', /id="pId"/.test(src));
pruef('ID wird gemerkt', /bind\('#pId','patId'\)/.test(src));
pruef('ID steht auf dem Ausdruck', /kopf\.push\('ID '\+pd\.patId\)/.test(holeFunktion('buildPDF')));
pruef('im Handbetrieb ist die ID als Pflicht gekennzeichnet', /\(Pflicht\)/.test(holeFunktion('renderPatient')));
pruef('ohne Geraet wird im Auto-Modus GEWARNT statt Daten vorzutaeuschen',
  /Kein Gerät angeschlossen/.test(holeFunktion('renderPatient')));
pruef('die Herkunft wird ehrlich benannt',
  /quelle:'vom Gerät übernommen'/.test(src) && /quelle:'von Hand eingetragen'/.test(src));

block('26. Extrasystole, ausgefallener Schlag, Netzeinstreuung');
const R4 = new Function('return ' + src.slice(src.indexOf('var BEFUNDREGELN=['), src.indexOf('\n];', src.indexOf('var BEFUNDREGELN=[')) + 2).slice('var BEFUNDREGELN='.length))();
const bh4 = new Function('BEFUNDREGELN', 'fuelle', 'return ' + holeFunktion('befundHinweise') + ';')(R4, new Function('return ' + holeFunktion('fuelle'))());
const basis4 = { sp: 'hund', guete: 20, speed: 25, kal: true, echt: true };
pruef('erkannte Extrasystolen werden gemeldet',
  bh4(Object.assign({}, basis4, { rhythmusId: 'ves' })).some((t) => t.id === 'extrasystolen'));
pruef('der Hinweis unterscheidet ventrikulaer/supraventrikulaer ueber die QRS-Breite',
  /ventrikulären Ursprung \(VES\)/.test(bh4(Object.assign({}, basis4, { rhythmusId: 'ves' })).find((t) => t.id === 'extrasystolen').text));
pruef('ohne erkannte Extrasystolen kein Hinweis',
  !bh4(Object.assign({}, basis4, { rhythmusId: 'sinus' })).some((t) => t.id === 'extrasystolen'));
pruef('Kammertachykardie-Verdacht ist als kritisch eingestuft',
  bh4(Object.assign({}, basis4, { rhythmusId: 'vtach' })).some((t) => t.id === 'vtach-verdacht' && t.stufe === 'kritisch'));
pruef('und verweist auf Puls/Blutdruck am TIER',
  /Puls und Blutdruck am Tier/.test(bh4(Object.assign({}, basis4, { rhythmusId: 'vtach' })).find((t) => t.id === 'vtach-verdacht').text));
// Ausgefallener Schlag: Pause etwa doppelt so lang
pruef('Pause 2x so lang -> Verdacht auf ausgefallenen Kammerkomplex',
  bh4(Object.assign({}, basis4, { rrMittel: 500, rrMax: 1000 })).some((t) => t.id === 'schlag-ausgefallen'));
pruef('gleichmaessiger Rhythmus loest das NICHT aus',
  !bh4(Object.assign({}, basis4, { rrMittel: 500, rrMax: 540 })).some((t) => t.id === 'schlag-ausgefallen'));
pruef('eine SEHR lange Pause faellt nicht mehr unter "ausgefallen" (dann Sinusarrest)',
  !bh4(Object.assign({}, basis4, { rrMittel: 500, rrMax: 1600 })).some((t) => t.id === 'schlag-ausgefallen'));
pruef('der Blocktyp wird ausdruecklich OFFEN gelassen (P-Welle fehlt)',
  /nur an der P-Welle entscheiden/.test(bh4(Object.assign({}, basis4, { rrMittel: 500, rrMax: 1000 })).find((t) => t.id === 'schlag-ausgefallen').text));

// Netzstoerung: echte Rechnung auf erzeugten Signalen
const netzFn = new Function('return ' + holeFunktion('netzStoerung'))();
(function () {
  const hz = 500, n = 2000;
  const brumm = [], zittern = [];
  for (let i = 0; i < n; i++) {
    brumm.push(Math.sin(2 * Math.PI * 50 * i / hz));                 // saubere 50-Hz-Schwingung
    zittern.push(Math.sin(i * (1.1 + 0.9 * Math.sin(i / 7))) * (0.5 + 0.5 * Math.sin(i / 13)));
  }
  pruef('gleichfoermige 50-Hz-Schwingung wird als Netzeinstreuung erkannt', netzFn(brumm, hz) === true);
  pruef('unregelmaessiges Zittern wird NICHT als Netz gemeldet', netzFn(zittern, hz) !== true);
  pruef('unter 100 Hz Abtastrate wird NICHTS behauptet (Nyquist)', netzFn(brumm, 80) === null);
  pruef('zu kurzer Streifen: keine Aussage', netzFn(brumm.slice(0, 40), hz) === null);
})();
pruef('der Netzhinweis raet zu Kontakt/Erdung statt zum Filter',
  /Kontakt und Erdung prüfen<\/b> ist besser als den Filter/.test(bh4(Object.assign({}, basis4, { netzStoerung: true })).find((t) => t.id === 'netzeinstreuung').text));

// ---------------------------------------------------------------------------
block('27. Regeln auf der P-Welle: AV-Block-Typ wird unterscheidbar');
const R5 = new Function('return ' + src.slice(src.indexOf('var BEFUNDREGELN=['), src.indexOf('\n];', src.indexOf('var BEFUNDREGELN=[')) + 2).slice('var BEFUNDREGELN='.length))();
const bh5 = new Function('BEFUNDREGELN', 'fuelle', 'return ' + holeFunktion('befundHinweise') + ';')(R5, new Function('return ' + holeFunktion('fuelle'))());
const b5 = { sp: 'hund', guete: 20, speed: 25, kal: true, echt: true, filterAmp: false,
  pqBand: [60, 130], pDauerGrenze: 40, pAmpGrenze: 0.4 };

pruef('PQ 160 ms -> AV-Block I moeglich',
  bh5(Object.assign({}, b5, { pVorhanden: true, pq: 160 })).some((t) => t.id === 'pq-lang'));
pruef('PQ 100 ms -> kein Befund', !bh5(Object.assign({}, b5, { pVorhanden: true, pq: 100 })).some((t) => t.id === 'pq-lang'));
pruef('bei der Katze ist die Grenze enger (PQ 100 ms schon zu lang)',
  bh5({ sp: 'katze', guete: 20, speed: 50, kal: true, echt: true, pVorhanden: true, pq: 100, pqBand: [50, 90] })
    .some((t) => t.id === 'pq-lang'));

/* DER EIGENTLICHE ZUGEWINN: Wenckebach gegen Mobitz II. */
pruef('zunehmende PQ -> Wenckebach-Muster',
  bh5(Object.assign({}, b5, { pVorhanden: true, pqVerlauf: 'zunehmend', pqSpanne: 60 })).some((t) => t.id === 'pq-zunehmend'));
const mob = bh5(Object.assign({}, b5, { pVorhanden: true, pqVerlauf: 'konstant', pq: 140, rrMittel: 500, rrMax: 1000 }));
pruef('Ausfall bei KONSTANTER PQ -> Mobitz II, als kritisch eingestuft',
  mob.some((t) => t.id === 'pq-konstant-ausfall' && t.stufe === 'kritisch'));
pruef('Mobitz-II-Hinweis nennt die klinische Bedeutung (kaum Atropin, kann kippen)',
  /kaum auf Atropin an/.test(mob.find((t) => t.id === 'pq-konstant-ausfall').text));
pruef('bei zunehmender PQ wird NICHT Mobitz II gemeldet',
  !bh5(Object.assign({}, b5, { pVorhanden: true, pqVerlauf: 'zunehmend', pqSpanne: 60, rrMittel: 500, rrMax: 1000 }))
    .some((t) => t.id === 'pq-konstant-ausfall'));

pruef('fehlende P (Anteil 10 %) wird gemeldet',
  bh5(Object.assign({}, b5, { pMessbar: false, pAnteil: 10 })).some((t) => t.id === 'keine-p'));
pruef('der Hinweis nennt Vorhofflimmern UND Vorhofstillstand, ohne zu waehlen',
  (function () { const t = bh5(Object.assign({}, b5, { pMessbar: false, pAnteil: 10 })).find((x) => x.id === 'keine-p').text;
    return /Vorhofflimmern/.test(t) && /Vorhofstillstand/.test(t); })());
pruef('bei schlechtem Signal wird die fehlende P NICHT gemeldet (sonst Fehlschluss)',
  !bh5(Object.assign({}, b5, { pMessbar: false, pAnteil: 10, guete: 2 })).some((t) => t.id === 'keine-p'));

pruef('P-Dauer 55 ms beim Hund -> P mitrale',
  bh5(Object.assign({}, b5, { pVorhanden: true, pDauer: 55 })).some((t) => t.id === 'p-breit'));
pruef('P-Amplitude 0,6 mV beim Hund -> P pulmonale',
  bh5(Object.assign({}, b5, { pVorhanden: true, pAmp: 0.6 })).some((t) => t.id === 'p-hoch'));
pruef('ohne Kalibrierung KEINE P-Amplituden-Aussage',
  !bh5(Object.assign({}, b5, { pVorhanden: true, pAmp: 0.6, kal: false })).some((t) => t.id === 'p-hoch'));
pruef('mit Muskelfilter ebenfalls nicht (der Filter senkt Amplituden)',
  !bh5(Object.assign({}, b5, { pVorhanden: true, pAmp: 0.6, filterAmp: true })).some((t) => t.id === 'p-hoch'));

pruef('die PQ-Zelle zeigt den gemessenen Wert', /pw\.pqMs\+' <small>ms gemessen/.test(holeFunktion('updateMeasures')));
pruef('ohne abgrenzbare P sagt die Zelle das', /keine P abgrenzbar/.test(holeFunktion('updateMeasures')));

// ---------------------------------------------------------------------------
block('28. QT-Regeln (Zeit bewerten, Form NICHT)');
const R6 = new Function('return ' + src.slice(src.indexOf('var BEFUNDREGELN=['), src.indexOf('\n];', src.indexOf('var BEFUNDREGELN=[')) + 2).slice('var BEFUNDREGELN='.length))();
const bh6 = new Function('BEFUNDREGELN', 'fuelle', 'return ' + holeFunktion('befundHinweise') + ';')(R6, new Function('return ' + holeFunktion('fuelle'))());
const b6 = { sp: 'hund', guete: 20, speed: 25, kal: true, echt: true, filterAmp: false, tMessbar: true, qtBand: [150, 250], qtcText: '' };
pruef('QT 300 ms beim Hund -> verlaengert', bh6(Object.assign({}, b6, { qt: 300 })).some((t) => t.id === 'qt-lang'));
pruef('QT 200 ms -> kein Befund', !bh6(Object.assign({}, b6, { qt: 200 })).some((t) => t.id === 'qt-lang' || t.id === 'qt-kurz'));
pruef('QT 120 ms -> verkuerzt', bh6(Object.assign({}, b6, { qt: 120 })).some((t) => t.id === 'qt-kurz'));
pruef('bei der Katze gilt ein engeres Band (QT 200 ms schon lang)',
  bh6({ sp: 'katze', guete: 20, speed: 50, kal: true, echt: true, tMessbar: true, qt: 200, qtBand: [120, 180], qtcText: '' })
    .some((t) => t.id === 'qt-lang'));
pruef('ohne messbares T-Ende KEINE QT-Aussage',
  !bh6(Object.assign({}, b6, { qt: 300, tMessbar: false })).some((t) => t.id === 'qt-lang'));
pruef('der Verlaengerungs-Hinweis nennt Torsade de pointes als Risiko',
  /Torsade de pointes/.test(bh6(Object.assign({}, b6, { qt: 300 })).find((t) => t.id === 'qt-lang').text));
pruef('der Verkuerzungs-Hinweis nennt Hyperkalzaemie',
  /Hyperkalzämie/.test(bh6(Object.assign({}, b6, { qt: 120 })).find((t) => t.id === 'qt-kurz').text));
pruef('die frequenzkorrigierte Zeit erscheint nur, wenn sie gebildet wurde',
  /frequenzkorrigiert 232 ms/.test(bh6(Object.assign({}, b6, { qt: 300, qtcText: ' (frequenzkorrigiert 232 ms nach Van de Water)' })).find((t) => t.id === 'qt-lang').text));
pruef('kein Platzhalter bleibt stehen', !/\{\w+\}/.test(bh6(Object.assign({}, b6, { qt: 300 })).find((t) => t.id === 'qt-lang').text));
pruef('die T-FORM wird bewusst nicht bewertet (nur Zeit)',
  !R6.some((r) => /tForm|tAmp|T-Welle (spitz|zeltf)/.test(String(r.pruef) + r.name)));
pruef('QT steht in der Messwertspalte', /tw\.qtMs\+' <small>ms QT/.test(holeFunktion('updateMeasures')));

// ---------------------------------------------------------------------------
block('29. QRS-Form und Schlagvergleich — und die Schenkelblock-Sperre');
const R7 = new Function('return ' + src.slice(src.indexOf('var BEFUNDREGELN=['), src.indexOf('\n];', src.indexOf('var BEFUNDREGELN=[')) + 2).slice('var BEFUNDREGELN='.length))();
const bh7 = new Function('BEFUNDREGELN', 'fuelle', 'return ' + holeFunktion('befundHinweise') + ';')(R7, new Function('return ' + holeFunktion('fuelle'))());
const b7 = { sp: 'hund', guete: 20, speed: 25, kal: true, echt: true, filterAmp: false, qrsGrenze: 60 };

/* DIE SPERRE — der Kern dieser Erweiterung. */
const breit1 = bh7(Object.assign({}, b7, { qrs: 90, ablGemessen: 1 }));
pruef('breiter QRS bei EINER gemessenen Ableitung -> Blockart NICHT bestimmbar',
  breit1.some((t) => t.id === 'block-nicht-klassifizierbar'));
pruef('und der Hinweis sagt, WAS dafuer fehlt (mehrere Ableitungen)',
  /Mehrkanal-EKG/.test(breit1.find((t) => t.id === 'block-nicht-klassifizierbar').text));
pruef('er nennt die Kriterien beider Blockarten, ohne eine zu behaupten', (function () {
  const t = breit1.find((x) => x.id === 'block-nicht-klassifizierbar').text;
  return /Rechts-/.test(t) && /Linksschenkelblock/.test(t) && !/liegt ein/.test(t);
})());
pruef('bei ZWEI gemessenen Ableitungen entfaellt dieser Hinweis',
  !bh7(Object.assign({}, b7, { qrs: 90, ablGemessen: 2 })).some((t) => t.id === 'block-nicht-klassifizierbar'));
pruef('KEINE Regel behauptet einen Rechts- oder Linksschenkelblock',
  !R7.some((r) => /Rechtsschenkelblock vor|liegt ein Schenkelblock/i.test(r.hinweis || '')));

/* Kerbung */
pruef('Kerbe wird gemeldet, wenn in mV gemessen',
  bh7(Object.assign({}, b7, { qrs: 50, ablGemessen: 1, kerbeInMv: true, qrsKerben: 1 })).some((t) => t.id === 'qrs-gekerbt'));
pruef('OHNE Kalibrierung keine Kerbaussage (0,05 mV waeren nicht pruefbar)',
  !bh7(Object.assign({}, b7, { qrs: 50, ablGemessen: 1, kerbeInMv: false, qrsKerben: 1 })).some((t) => t.id === 'qrs-gekerbt'));
pruef('der Hinweis grenzt Kerbung von echter Fragmentierung ab',
  /zwei benachbarten<\/b> Ableitungen/.test(bh7(Object.assign({}, b7, { qrs: 50, ablGemessen: 1, kerbeInMv: true, qrsKerben: 1 })).find((t) => t.id === 'qrs-gekerbt').text));

/* Uniform gegen multiform */
const uni = bh7(Object.assign({}, b7, { qrs: 50, ablGemessen: 1, formen: 1, formFremd: 4, formFremdAnteil: 25 }));
const multi = bh7(Object.assign({}, b7, { qrs: 50, ablGemessen: 1, formen: 3, formFremd: 6, formFremdAnteil: 30 }));
pruef('eine fremde Form -> uniforme Ektopie', uni.some((t) => t.id === 'ektopie-uniform'));
pruef('mehrere fremde Formen -> multiforme Ektopie', multi.some((t) => t.id === 'ektopie-multiform'));
pruef('multiform ist hoeher eingestuft als uniform',
  multi.find((t) => t.id === 'ektopie-multiform').stufe === 'kritisch' &&
  uni.find((t) => t.id === 'ektopie-uniform').stufe === 'auffaellig');
pruef('uniform und multiform schliessen sich aus', !uni.some((t) => t.id === 'ektopie-multiform'));
pruef('die Zahl der Formen steht im Hinweistext',
  /<b>3 verschiedenen<\/b>/.test(multi.find((t) => t.id === 'ektopie-multiform').text),
  multi.find((t) => t.id === 'ektopie-multiform').text.slice(0, 90));
pruef('bei unruhigem Signal wird keine Ektopieform behauptet',
  !bh7(Object.assign({}, b7, { qrs: 50, ablGemessen: 1, formen: 3, formFremd: 6, guete: 4 }))
    .some((t) => t.id === 'ektopie-multiform'));
pruef('kein Platzhalter bleibt stehen', !/\{\w+\}/.test(multi.find((t) => t.id === 'ektopie-multiform').text));

// ---------------------------------------------------------------------------
console.log('\n' + (rot === 0
  ? 'ALLE ' + gruen + ' PRUEFUNGEN BESTANDEN'
  : rot + ' FEHLGESCHLAGEN von ' + (gruen + rot)));
process.exit(rot === 0 ? 0 : 1);
