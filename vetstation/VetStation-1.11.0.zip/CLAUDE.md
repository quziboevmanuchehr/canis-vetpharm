# VetStation — Projektregeln

Tiermedizinische Narkose- und Überwachungsstation für Kleintierpraxen.
Läuft auf einem Praxis-PC im Praxisnetz, spricht mit Monitoren, Kapnografen und
Narkosegeräten, führt das Narkoseprotokoll und spiegelt alles in eine Web-App.

**Diese Datei wird zu Beginn jeder Sitzung gelesen. Sie enthält nur Dauerfakten.**
Einzelheiten stehen in den Gedächtnisnotizen — welche wann, steht unten unter „Kartei".

---

## Was diese Anwendung ist — und was nicht

Sie ist eine **Entscheidungs- und Trainingshilfe**, kein zugelassener Patientenmonitor.
Daraus folgt die wichtigste inhaltliche Regel des Projekts:

> **Sie misst und schweigt im Zweifel.**

Eine falsche Zahl ist schädlicher als keine Zahl. Wo eine Angabe nicht belegbar ist
(unbekannte Geräteverstärkung, zu kurzer Streifen, nur eine aufgezeichnete Ableitung),
wird das ausdrücklich gesagt, statt etwas zu behaupten. Wer eine neue Aussage einbaut,
muss angeben können, woraus sie folgt.

## Harte Regeln

| Regel | Warum |
|---|---|
| Reines **ES5**, keine Abhängigkeiten, kein Build-Schritt für die UI | Der Praxis-PC hat kein npm und kein Node im PATH |
| `node.exe` liegt **nur** unter `dist/VetStation/node/node.exe` | Es gibt kein Node im PATH — auch nicht auf dem Entwicklerrechner |
| `.ps1`-Dateien müssen **reines ASCII** sein | Ein Gedankenstrich hat schon einmal die ganze Testreihe gekippt |
| Kommentare **begründen**, sie beschreiben nicht | Was der Code tut, steht im Code. Warum, steht nirgends sonst |
| Jeder Dateikopf sagt **warum es die Datei gibt**, mit Datum und gemessenem Befund | Sonst wiederholt der Nächste den Fehler |
| Lange Erklärungen stehen **über** der Funktion, nicht daneben | Zeilen über ~110 Zeichen sind im Editor nicht mehr lesbar |
| `dist/` ist **Bauergebnis**, keine Quelle | Wer dort ändert, verliert es beim nächsten Bau |
| Die Web-App wird **gebaut**, nie von Hand bearbeitet | `tools/web-app-bauen.js` — sonst laufen Station und Fern-App auseinander |

## Wege

```
quellcode/                      Git-Repo (master) -> github.com/quziboevmanuchehr/VetStation
  ui/app/index.html             die ganze Oberfläche, ~7050 Zeilen (auch das EKG-Submodul)
                                (die daraus GEBAUTE Web-App ist ~9390 Zeilen lang)
  ui/shared/*.js                gemeinsam mit der Web-App: ekg-analyse, ekg-skala, ekg-befunde,
                                geraete-profile, breed-katalog, patient-alter, rasse-herz,
                                tier3d, jspdf
                                ACHTUNG: jede neue Datei hier MUSS in die Kopierliste von
                                tools/web-app-bauen.js — sonst laedt die Fern-App eine Datei,
                                die es dort nicht gibt, und das Merkmal faellt STILL aus.
  bridge/src/                   Server, Geräteanbindung, Firebase, Updater
  tools/*.js                    Selbsttests und Werkzeuge (alle mit node startbar)
  docs/*.md                     Fachdokumentation im Repo (22 Dateien: Geraeteprotokolle,
                                Fern-Live, virtuelles Geraet, QA, Rassen-Narkoseplan)
  installer/*.ps1               dist bauen, Setup.exe bauen, Treiber, Firewall
../../canis-vetpharm/           Git-Repo (main), ÖFFENTLICH auf GitHub Pages
                                Web-App + Update-Kanal (vetstation-version.json, vetstation/*.zip)
```

## Arbeiten

```bash
# Selbsttests (das Maß der Dinge — vor jedem Bau grün)
dist/VetStation/node/node.exe tools/alle-tests.js

# Einzelner Test
dist/VetStation/node/node.exe tools/ekg-skala-test.js

# Web-App neu bauen (nach JEDER Änderung an ui/app/index.html)
dist/VetStation/node/node.exe tools/web-app-bauen.js ui/app/index.html ../../canis-vetpharm/canis-anaesthesie/index.html

# Paket bauen (erst wenn alle Tests grün sind)
powershell -ExecutionPolicy Bypass -File installer/make-dist.ps1
```

**Vorschau-Server:** `preview_start` mit `vetstation-ui` (Port 8791) oder `canis-web` (Port 8792).
Der Server **sperrt `node.exe` und Port 8791** — vor `make-dist.ps1` und vor `alle-tests.js`
beenden, sonst scheitern der Bau und `doppelstart-test.js`.

## Messen statt schätzen

Dieses Projekt hat sich mehrfach an Vermutungen verbrannt. Die Haltung ist deshalb:

- **Bei einem fehlgeschlagenen Test zuerst fragen, ob der TEST falsch ist.** Das war er
  auffallend oft — mit erfundenen Signalen, falschen Erwartungen oder abgesicherten Fehlern.
- **Neue Prüfungen absichtlich zerbrechen** und nachsehen, ob sie wirklich rot werden.
- **Die Browser-Vorschau drosselt den Bildtakt.** Wer eine `canvas` ausliest, misst alte
  Bilder. Geometrie, die stimmen muss, gehört in eine reine Funktion in `ui/shared/` mit
  einem Node-Test — nicht in eine Zeichenroutine. Siehe `vetstation-leinwand-messfalle.md`.
- **Quellprüfungen in Tests lesen auch Kommentare.** Vor einer „kommt nicht mehr vor"-Prüfung
  die Blockkommentare entfernen (`.replace(/\/\*[\s\S]*?\*\//g,' ')`).

## Freigabe

Version an **vier** Stellen gleichzeitig: `package.json`, `bridge/package.json`,
`updater/version.json` (`app`), `installer/vetstation-setup.iss` (`AppVersion`).
`tools/version-test.js` erzwingt das.

Die Nummer, die der Nutzer nennt, hinkt oft hinterher — **vor jeder Freigabe `git log`
und den Kanalordner ansehen.** Der Updater vergleicht numerisch; eine kleinere Nummer wird
gar nicht erst angeboten. Ganze Kette und die zwei stillen Fallen: `vetstation-freigabe.md`.

Das Paket ZULETZT bauen, nach der letzten Quelländerung, und dann:

```bash
dist/VetStation/node/node.exe tools/manifest-pruefen.js --freigabe
```

Ohne `--freigabe` meldet derselbe Test einen veralteten Kanalstand nur als Hinweis — während
der Arbeit ist das der Regelfall und darf den Sammellauf nicht rot färben.

## Kartei — welche Notiz wann laden

Die Notizen liegen unter `~/.claude/projects/C--Users-akhme-Desktop-Manu-VetStation/memory/`.
**Nicht alle laden.** Beim Arbeiten an einem Thema gezielt die passenden:

| Thema | Notizen |
|---|---|
| EKG-Submodul, Kurven, Messzirkel, PDF | `vetstation-ekg-submodul`, `vetstation-ekg-normwerte`, `vetstation-leinwand-messfalle` |
| Patientenblatt, Rasse, Alter, Rassehinweise | `vetstation-rasse-alter-kette`, `vetstation-iife-und-katalogfallen` |
| Elektroden anlegen, 3D-Modell | `vetstation-3d-modell` |
| Geräteanbindung, HL7, serielle Geräte | `vetstation-hl7-facts`, `vetstation-geraetekatalog` |
| Fern-Live, Firebase, Web-App | `vetstation-fernlive`, `vetstation-verbund-befunde`, `vetstation-verbund-stabilitaet` |
| Mehrere OP-Säle, Saal-Tafel | `vetstation-mehrere-saele`, `vetstation-verbund-stabilitaet` |
| Oberfläche, Layout, Lesbarkeit | `vetstation-cockpit`, `vetstation-leinwand-messfalle` |
| Arzneien, Dosen, Rassen | `vetstation-rassekatalog`, `vetstation-klinische-logik`, `vetstation-gaben-protokoll` |
| Veröffentlichen | `vetstation-freigabe` |

`MEMORY.md` ist der Index und bleibt **unter 100 Zeilen** — eine Zeile je Notiz, nie Inhalt.

## Sitzungsabschluss

Auf das Stichwort **„speichere die Sitzung"**: neue Erkenntnis als eigene Notiz anlegen
(eine Aussage je Datei, Datum nennen), eine Zeile in `MEMORY.md` ergänzen, und prüfen, ob
eine bestehende Notiz dadurch falsch geworden ist — falsche Notizen werden gelöscht,
nicht ergänzt.

## Was nicht angefasst wird

- Monitor- und EKG-Anzeige der Hauptansicht, solange nicht ausdrücklich verlangt
- Fremde Zips unter `canis-vetpharm/vetstation/` — sie sind veröffentlichte Stände
- `bridge/data/` und `data/` — dort liegen Patientendaten. Sie gehören in **kein** Paket
