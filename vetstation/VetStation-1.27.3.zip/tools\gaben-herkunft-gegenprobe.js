'use strict';
/* =============================================================================================
 * gaben-herkunft-gegenprobe.js — wird der Waechter wirklich rot? (24.08.2026)
 * =============================================================================================
 *
 * WARUM ES DIESE DATEI GIBT: gaben-herkunft-test.js prueft lauter ZUSATZfelder. Ein Waechter
 * ueber Zusatzfelder hat eine tueckische Eigenschaft — er kann versehentlich so geschrieben sein,
 * dass er auch dann gruen bleibt, wenn das Feld fehlt (falsche Verschachtelung, ein `.test()` auf
 * einem Kommentar, ein Vergleich gegen undefined). Genau daran ist am 19.08.2026 der erste
 * Entwurf von dosis-abgleich.js gescheitert: er war blind fuer seinen eigenen Anlass.
 *
 * DIESE DATEI VERAENDERT KURZ ECHTE QUELLDATEIEN und stellt sie danach wieder her. Sie laeuft
 * deshalb NICHT im Sammellauf, sondern von Hand:
 *     dist/VetStation/node/node.exe tools/gaben-herkunft-gegenprobe.js
 *
 * Am Ende wird byteweise nachgerechnet, dass jede Datei wieder genau so daliegt wie vorher.
 * Bricht der Lauf mittendrin ab (Strg-C), stellt der finally-Zweig ebenfalls wieder her.
 * ============================================================================================= */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const WURZEL = path.join(__dirname, '..');
const NODE = path.join(WURZEL, 'dist', 'VetStation', 'node', 'node.exe');
const TEST = path.join(__dirname, 'gaben-herkunft-test.js');

const REG = path.join(WURZEL, 'bridge', 'src', 'registry.js');
const APP = path.join(WURZEL, 'ui', 'app', 'index.html');
const LIVE = path.join(WURZEL, 'ui', 'vetstation-live.js');

const ORIG = {};
[REG, APP, LIVE].forEach((f) => { ORIG[f] = fs.readFileSync(f, 'utf8'); });
function summe(s) { return crypto.createHash('sha256').update(s).digest('hex').slice(0, 12); }
const VORHER = {};
Object.keys(ORIG).forEach((f) => { VORHER[f] = summe(ORIG[f]); });

let gut = 0, schlecht = 0;

/* Ein Schaden: Datei, was ersetzt wird, wodurch, und was er bedeutet. */
const SCHAEDEN = [
  /* Die Zeile `fall: this._fallKennung(L, ts),` steht ZWEIMAL — einmal in der Messzeile, einmal
   * in der Gabenzeile. Beim ersten Anlauf war sie als Suchtext nicht eindeutig und der Schaden
   * wurde stillschweigend gar nicht gesetzt; der Waechter galt damit faelschlich als blind.
   * Deshalb hier je ein Nachbar als Anker. */
  [REG, '        finding: befund || null,\n        fall: this._fallKennung(L, ts),',
    '        finding: befund || null,',
    'Messzeile ohne Fallkennung'],
  [REG, "      fall: this._fallKennung(L, ts),\n      art: 'med',", "      art: 'med',",
    'Gabenzeile ohne Fallkennung — Gabe und Wirkung finden nicht mehr zusammen'],
  [REG, 'dev: geraete || null,', '',
    'Messzeile ohne Geraet'],
  [REG, 'quelle: kurz(gabe.quelle, 24),', '',
    'Gabe ohne Herkunft (med{} ist eine Positivliste!)'],
  [REG, 'rang: Number.isFinite(Number(gabe.rang)) ? Number(gabe.rang) : null,', '',
    'Gabe ohne Rang'],
  [REG, 'incName: kurz(gabe.incName, 80),', 'incName: gabe.incName || null,',
    'Kappung des Zwischenfallnamens entfaellt'],
  [REG, 'const FALL_ENDE_MS = 300000;', 'const FALL_ENDE_MS = 99999999;',
    'Fallgrenze so weit, dass zwei Narkosen aneinanderhaengen'],
  [REG, 'const geraete = (p.devices || []).map', 'const geraete = (p.devices).map',
    'der Schutz um p.devices faellt weg — JEDE Protokollzeile geht still verloren'],
  [REG, 'if (dl.length && !k.geraete) k.geraete = dl;', 'if (dl.length) k.geraete = dl;',
    'der Kopf wird ueberschrieben statt ergaenzt'],
  [REG, "return 'f' + ts;", "return null;",
    'die Fallkennung wird gar nicht erst vergeben'],
  [APP, "storno:(ix>=0), quelle:'liste'});", 'storno:(ix>=0)});',
    'eine der fuenf Buchungsstellen vergisst ihre Herkunft'],
  [APP, 'rang:ewRang(id),', 'rang:null,',
    'die Zwischenfall-Stelle reicht den Rang nicht weiter'],
  [APP, 'var E=state.erstwahl&&state.erstwahl.erst, r=(E&&E.reihe)||[], k=r.indexOf(id);',
    'var E=state.erstwahl&&state.erstwahl.erst, r=((E&&E.reihe)||[]).concat((E&&E.nach)||[]), k=r.indexOf(id);',
    'ewRang nummeriert auch den Nachlauf durch — erfundene Rangfolge im Protokoll'],
  [APP, 'return k>=0?(k+1):null;', 'return k>=0?(k+1):0;',
    'ohne Treffer steht 0 statt null im Protokoll'],
  [APP, 'rec.rang=(rec.rang!=null&&isFinite(Number(rec.rang)))?Number(rec.rang):null;', '',
    'medBuchen kappt den Rang nicht mehr'],
  [LIVE, 'incId: gabe.incId ? String(gabe.incId).slice(0, 40) : null,', '',
    'der Ausdruck verliert den Zwischenfall — Akte und Papier widersprechen sich'],
  [LIVE, 'quelle: gabe.quelle ? String(gabe.quelle).slice(0, 24) : null,',
    'quelle: gabe.quelle || null,',
    'der Ausdruck kappt anders als die Akte'],
];

console.log('Gegenprobe: wird gaben-herkunft-test.js bei jedem einzelnen Schaden rot?\n');

function testLaeuft() {
  try { execFileSync(NODE, [TEST], { stdio: 'pipe' }); return true; }
  catch (_) { return false; }
}

try {
  if (!testLaeuft()) {
    console.log('  ABBRUCH: der Waechter ist schon OHNE Schaden rot. Erst den beheben.');
    process.exit(1);
  }
  console.log('  (unveraendert: gruen — die Ausgangslage stimmt)\n');

  SCHAEDEN.forEach(([datei, suchen, ersetzen, was], i) => {
    const text = ORIG[datei];
    const treffer = text.split(suchen).length - 1;
    const nr = String(i + 1).padStart(2, ' ');
    if (treffer !== 1) {
      schlecht++;
      console.log('  ' + nr + ') ✗ ' + was + '\n         -> die Stelle kommt ' + treffer
        + '-mal vor, erwartet genau 1. Der Schaden waere gar nicht gesetzt worden.');
      return;
    }
    fs.writeFileSync(datei, text.replace(suchen, () => ersetzen), 'utf8');
    const rot = !testLaeuft();
    fs.writeFileSync(datei, text, 'utf8');
    if (rot) { gut++; console.log('  ' + nr + ') ✓ rot bei: ' + was); }
    else {
      schlecht++;
      console.log('  ' + nr + ') ✗ BLIND: ' + was + '\n         -> ' + path.basename(datei)
        + ', der Waechter blieb gruen. Er prueft diese Stelle nicht wirklich.');
    }
  });
} finally {
  Object.keys(ORIG).forEach((f) => { fs.writeFileSync(f, ORIG[f], 'utf8'); });
}

console.log('\n---------------------------------------------');
let heil = true;
Object.keys(ORIG).forEach((f) => {
  const jetzt = summe(fs.readFileSync(f, 'utf8'));
  if (jetzt !== VORHER[f]) { heil = false; console.log('  !! NICHT WIEDERHERGESTELLT: ' + f); }
});
console.log('  Quelldateien unveraendert: ' + (heil ? 'ja' : 'NEIN — von Hand pruefen!'));
console.log('  Schaeden erkannt: ' + gut + ' von ' + SCHAEDEN.length
  + (schlecht ? '   BLIND: ' + schlecht : ''));
if (schlecht || !heil) process.exit(1);
console.log('  Der Waechter sieht jeden dieser Schaeden.');
