'use strict';
/*
 * logger.js — Lokales Diagnose-Log (Technik/Verbindung, §14.4).
 * Schreibt Ereignisse in data/diag.log (lokal, keine Cloud) und haelt einen Ringpuffer der
 * letzten Ereignisse fuer den Admin-Bereich vor. Wird zusaetzlich ueber den WebSocket als
 * MSG.DIAG an die UI gesendet.
 *
 * HIER STAND "schreibt ANONYMISIERTE Ereignisse" (berichtigt 25.08.2026). Das stimmte nicht:
 * die Meldungen des Narkoseprotokolls trugen die Patientenkennung im Klartext, samt Wirkstoff
 * und Dosis. Anonymisiert wird seither, was den Logger VERLAESST (Abschnitt unten) — die Datei
 * auf dem Praxis-PC bleibt absichtlich lesbar.
 *
 * WIEDERHOLUNGEN WERDEN ZUSAMMENGEFASST (Befund 2.2/2.3, 21.07.2026):
 * Bei nicht erreichbarer Cloud schrieb der Publisher ~2 Fehlerzeilen pro Sekunde, der HL7-Client
 * bei abwesendem Geraet ~40 pro Minute. Der Ringpuffer fasst 500 Zeilen — nach gut vier Minuten
 * war er voll und SAEMTLICHE Verbindungsmeldungen daraus verdraengt. Ausgerechnet das Log, das
 * bei der Inbetriebnahme helfen soll, enthielt nur noch Dauerfehler.
 * Deshalb: identische Meldungen erzeugen KEINE neue Zeile mehr, sondern zaehlen die vorhandene
 * hoch. Sobald etwas anderes passiert, wird die Wiederholung als EINE Zeile abgeschlossen.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = path.join(DATA_DIR, 'diag.log');
const MAX_RING = 500;
const DEDUP_MS = 5 * 60 * 1000;   // laenger als jede sinnvolle Wiederholrate

/* ============================================================================================
 * DIE PATIENTENKENNUNG GEHOERT NICHT IN DEN MELDUNGSTEXT (25.08.2026)
 *
 * WAS WAR: server.js baute Zeilen wie
 *     protokoll: Gegeben: Atropin (0.084-0.168 mg = 0.168-0.336 mL IV/IM/SC) - Patient C-077
 * Die stehen so in data/diag.log — das ist auf dem Praxis-PC richtig und nuetzlich. Sie gehen
 * aber auch ueber DREI Ausgaenge nach draussen: den WebSocket an die Oberflaeche (server.js:621
 * und :904, von dort in den Browserspeicher und dessen Ausleiten-Knopf) und /api/diag
 * (server.js:1275), das tools/befund-export.js liest. Der Befundbericht sagt am Ende woertlich
 * "Patienten-Kennungen sind unkenntlich gemacht" — und hing die letzten 40 Meldungen ROH an.
 * Die Zusage war damit falsch, und zwar in genau der Datei, die zum Weitergeben gedacht ist.
 *
 * WARUM STRUKTURELL UND NICHT MIT EINER MUSTERSUCHE: eine Regel ueber freien Text ("alles nach
 * dem Wort Patient") bricht still, sobald jemand eine Meldung umformuliert — und man merkt es
 * nicht, weil nichts rot wird. Die Kennung steht deshalb in einem EIGENEN Feld. Die Datei
 * haengt sie lesbar an, jeder Ausgang ersetzt sie durch ein abgeleitetes Kuerzel.
 *
 * DAS KUERZEL IST STABIL: derselbe Patient ergibt dasselbe #abc123, verschiedene Patienten
 * verschiedene. Damit bleibt der Bericht lesbar ("dreimal derselbe Patient"), ohne die
 * Aktennummer zu tragen. Gesalzen mit der Stationskennung, damit sich das Kuerzel nicht durch
 * blosses Durchprobieren kurzer Kennungen zurueckrechnen laesst.
 * ============================================================================================ */
let salzWert = null;
function salz() {
  if (salzWert !== null) return salzWert;
  try {
    const d = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'station-id.json'), 'utf8'));
    salzWert = String(d.sid || d.fp || '');
  } catch (_) { salzWert = ''; }
  /* Ohne Stationskennung (frische Installation, Test) bleibt das Kuerzel trotzdem stabil —
   * nur eben nicht gesalzen. Das ist immer noch besser als die Aktennummer im Klartext. */
  return salzWert;
}
function kuerzel(id) {
  if (id == null || id === '') return null;
  return '#' + crypto.createHash('sha256').update(salz() + '|' + String(id)).digest('hex').slice(0, 6);
}
/* Was die DATEI sieht: die lesbare Kennung. Was ein AUSGANG sieht: das Kuerzel.
 * Beides derselbe Bau, damit keine Stelle vergessen wird. */
function mitKennung(ev, lesbar) {
  if (!ev || ev.kennung == null) return ev;
  const k = lesbar ? String(ev.kennung) : kuerzel(ev.kennung);
  const kopie = { ts: ev.ts, level: ev.level, source: ev.source, msg: ev.msg + ' — Patient ' + k };
  if (ev.wiederholungen) kopie.wiederholungen = ev.wiederholungen;
  if (ev.extra !== undefined) kopie.extra = ev.extra;
  return kopie;
}
function hinaus(ev) { return mitKennung(ev, false); }

/*
 * DAS DIAGNOSE-LOG WIRD UMGEBROCHEN (02.08.2026) — vorher wuchs es unbegrenzt.
 *
 * GEMESSEN, nicht vermutet: C:\VetStation\data\diag.log war am 02.08.2026 6,0 MB gross und
 * enthielt Zeilen ab dem 21.07.2026 — die Datei wurde in zwoelf Tagen Dauerbetrieb kein einziges
 * Mal gekuerzt, weil ausgeben() nur fs.appendFile kennt. Im Mittel sind das etwa 0,5 MB je Tag.
 * Das allein waere ertraeglich; gefaehrlich ist der Ausnahmefall, und der steht im selben Log:
 * am 21.07.2026 schrieb der Fern-Versand binnen Minuten 3408 gleichlautende Zeilen
 * "Fern-Live Schreibfehler: HTTP 404". Die Zusammenfassung weiter unten hat das NICHT aufgefangen,
 * weil sie nur unmittelbar AUFEINANDERFOLGENDE gleiche Meldungen zaehlt — dazwischen lagen
 * Meldungen anderer Quellen, und damit begann jedes Mal eine neue Serie.
 *
 * Was ein volles Laufwerk auf einem Praxis-PC bedeutet, ist der eigentliche Grund fuer diese
 * Aenderung: dann laesst sich data/protokoll.json und data/patient-akte.json nicht mehr schreiben.
 * Das Narkoseprotokoll ist ein Nachweisdokument. Ein Diagnoseprotokoll darf niemals derjenige sein,
 * der es verdraengt.
 *
 * Die Zahlen sind bewusst klein gewaehlt: zwei Dateien a 4 MB reichen fuer mehrere Tage
 * gewoehnlichen Betriebs und selbst im Fehlersturm noch fuer die letzten Zehntausende Zeilen — und
 * mehr liest ohnehin niemand. Wer weiter zurueck muss, nimmt BEFUND-EXPORTIEREN.bat.
 */
const LOG_MAX_BYTES = 4 * 1024 * 1024;
const LOG_ALT_FILE = LOG_FILE + '.1';
/* Nicht bei jeder Zeile die Dateigroesse erfragen: das waere ein Systemaufruf je Logzeile, und
 * beim Start schreibt die Station in Sekunden dutzende. Die Groesse wird deshalb MITGEZAEHLT und
 * nur beim ersten Schreiben einmal vom Dateisystem geholt. */
let logBytes = -1;

const ring = [];
let sink = null;          // Funktion, die Ereignisse an die UI weiterreicht (MSG.DIAG)
let letzte = null;        // zuletzt ausgegebenes Ereignis (fuer die Zusammenfassung)
let wiederholt = 0;       // wie oft es seither identisch wiederkam
const einmalig = new Set();

function ensureDir() {
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (_) {}
}

function setSink(fn) { sink = fn; }

function schluessel(level, source, msg) { return level + '|' + source + '|' + msg; }

/*
 * umbrechenWennNoetig(zusatz) — haelt data/diag.log unter LOG_MAX_BYTES.
 *
 * Bewusst SYNCHRON, und das ist die einzige Stelle im heissen Pfad, an der das gerechtfertigt ist:
 * das Umbenennen passiert im Betrieb hoechstens alle paar Tage, und es MUSS abgeschlossen sein,
 * bevor die naechste Zeile angehaengt wird — sonst schreiben zwei Vorgaenge in dieselbe Datei,
 * waehrend sie unter ihnen wegbenannt wird, und ein Teil der Zeilen landet im Nirgendwo.
 *
 * Wirft nie. Ein Diagnoseprotokoll, das den Betrieb anhaelt, waere schlimmer als gar keines:
 * geht das Umbenennen schief (Datei von einem Editor offen, Rechte fehlen), wird weiter angehaengt
 * und beim naechsten Mal erneut versucht.
 */
function umbrechenWennNoetig(zusatz) {
  if (logBytes < 0) {
    try { logBytes = fs.statSync(LOG_FILE).size; } catch (_) { logBytes = 0; }
  }
  if (logBytes + zusatz <= LOG_MAX_BYTES) { logBytes += zusatz; return; }
  try {
    try { fs.unlinkSync(LOG_ALT_FILE); } catch (_) {}   // Vorgaenger weg, sonst scheitert rename auf Windows
    fs.renameSync(LOG_FILE, LOG_ALT_FILE);
    logBytes = zusatz;
  } catch (_) {
    /* Konnte nicht umgebrochen werden. Weiterschreiben ist richtig — aber nicht endlos zaehlen,
     * sonst wird bei JEDER Zeile ein neuer Versuch unternommen. Erst in einer Minute wieder. */
    logBytes = LOG_MAX_BYTES - 64 * 1024;
  }
}

function ausgeben(ev) {
  /* Die Datei bekommt die LESBARE Kennung: sie bleibt auf dem Praxis-PC, dort sitzt der
   * Tierarzt davor, und "welcher Patient" ist beim Nachsehen genau die Frage. Der Sink geht
   * an die Oberflaeche und von dort weiter — er bekommt das Kuerzel. */
  const datei = mitKennung(ev, true);
  const line = new Date(datei.ts).toISOString() + ' [' + datei.level + '] ' + datei.source + ': ' + datei.msg;
  if (datei.level === 'error') console.error(line); else console.log(line);
  try {
    ensureDir();
    umbrechenWennNoetig(Buffer.byteLength(line, 'utf8') + 1);
    fs.appendFile(LOG_FILE, line + '\n', () => {});
  } catch (_) {}
  if (sink) { try { sink(hinaus(ev)); } catch (_) {} }
}

// Schliesst eine laufende Wiederholungsserie mit EINER zusammenfassenden Zeile ab.
function serieAbschliessen() {
  if (!wiederholt || !letzte) { wiederholt = 0; return; }
  const ev = {
    ts: Date.now(), level: letzte.level, source: letzte.source,
    msg: '(vorige Meldung ' + wiederholt + '× wiederholt)', wiederholungen: wiederholt,
  };
  ring.push(ev);
  if (ring.length > MAX_RING) ring.shift();
  ausgeben(ev);
  wiederholt = 0;
}

function log(level, source, msg, extra, kennungVon) {
  const text = String(msg);
  const k = schluessel(level, source, text);
  const now = Date.now();

  // Identisch zur letzten Meldung und noch im Zeitfenster -> nur hochzaehlen, keine neue Zeile.
  if (letzte && letzte._k === k && (now - letzte.ts) < DEDUP_MS) {
    wiederholt++;
    letzte.ts = now;
    letzte.wiederholungen = wiederholt;
    return letzte;
  }

  serieAbschliessen();

  const ev = { ts: now, level: level, source: source, msg: text };
  if (extra !== undefined) ev.extra = extra;
  /* Die Kennung wird NICHT enumerierbar abgelegt: der Ring ist nur ueber recent() erreichbar
   * und das maskiert — aber falls jemand den Ring einmal anders herausgibt (JSON.stringify
   * ueber ein Ereignis), darf die Aktennummer nicht einfach mitgehen. */
  if (kennungVon !== undefined && kennungVon !== null && kennungVon !== '') {
    Object.defineProperty(ev, 'kennung', { value: String(kennungVon), enumerable: false, writable: true });
  }
  Object.defineProperty(ev, '_k', { value: k, enumerable: false, writable: true });
  ring.push(ev);
  if (ring.length > MAX_RING) ring.shift();
  letzte = ev;
  ausgeben(ev);
  return ev;
}

module.exports = {
  setSink,
  /* recent() ist EIN Ausgang von dreien und maskiert deshalb selbst — wer hier eine
   * zweite Auskunft anbaut, bekommt die Maskierung geschenkt statt sie zu vergessen. */
  recent(n) { return ring.slice(-(n || 100)).map(hinaus); },
  info: (s, m, e) => log('info', s, m, e),
  warn: (s, m, e) => log('warn', s, m, e),
  error: (s, m, e) => log('error', s, m, e),
  /* Fuer Meldungen, die sich auf EINEN Patienten beziehen. Die Kennung wird als eigenes
   * Feld uebergeben und NIE in den Text geschrieben — siehe Kopf dieser Datei. */
  patient: (s, m, kennung, lvl) => log(lvl || 'info', s, m, undefined, kennung),
  _kuerzel: kuerzel,
  // Meldungen, die pro Programmlauf HOECHSTENS EINMAL erscheinen sollen (z.B. Einrichtungshinweise).
  once(key, level, source, msg) {
    if (einmalig.has(key)) return null;
    einmalig.add(key);
    return log(level || 'info', source, msg);
  },
  // Nur fuer Tests: Zustand zuruecksetzen.
  _reset() { ring.length = 0; letzte = null; wiederholt = 0; einmalig.clear(); logBytes = -1; },
  /* Nur fuer den Wächter tools/logumbruch-test.js: die Umbruchgrenze ist sonst eine Konstante,
   * und ein Test, der 4 MB Text schreibt, um sie zu erreichen, misst die Festplatte statt den
   * Code. Die Datei- und Zaehlerlogik ist dieselbe. */
  _umbruch: { DATEI: LOG_FILE, ALT: LOG_ALT_FILE, MAX: LOG_MAX_BYTES, stand() { return logBytes; } },
};
