'use strict';
/* =============================================================================================
 * gaben-herkunft-test.js — WARUM wurde dieses Mittel gegeben? (24.08.2026)
 * =============================================================================================
 *
 * WAS WAR: das Narkoseprotokoll hielt fest, DASS ein Mittel gegeben wurde ("Atropin 0,04 mg/kg,
 * 14:22"). Es hielt nicht fest, WESHALB. Damit laesst sich hinterher nicht mehr feststellen, ob
 * die von der Station empfohlene Massnahme auch die genommene war — und genau das ist die einzige
 * Frage, aus deren Beantwortung die Empfehlungen jemals besser werden koennen. Dieselbe Luecke
 * bei den Messzeilen: sie sagten nicht, WELCHE Narkose sie beschreiben (die Listen laufen je
 * PATIENT, gemessen 25-27 Tage je Schluessel) und an welchem GERAET gemessen wurde.
 *
 * SEITHER traegt jede Zeile eine Fallkennung, jede Messzeile das Geraet und jede Gabe ihre
 * Herkunft (incId/incName/quelle/rang).
 *
 * WARUM DIESER TEST: alle diese Felder sind ZUSATZ. Faellt einer weg, sieht nichts anders aus —
 * kein Fenster bleibt leer, keine Zahl wird falsch, kein anderer Test wird rot. Die Auswertung
 * bekaeme still weniger, und niemand merkte es. Drei Stellen muessen zusammenpassen und tun es
 * nur, wenn man sie zusammen prueft:
 *   bridge/src/registry.js   -> die Zeile in der Akte
 *   ui/app/index.html        -> wer die Felder ueberhaupt setzt
 *   ui/vetstation-live.js    -> die Zeile im AUSDRUCK (zweiter Bauweg derselben Zeile!)
 *
 * BESONDERS: med{} in registry.medikamentGabe ist eine POSITIVLISTE. Was dort nicht genannt ist,
 * hoert lautlos auf zu existieren — deshalb wird hier gegen die AUSGEFUEHRTE Funktion geprueft
 * und nicht gegen den Dateitext.
 * ============================================================================================= */

const fs = require('fs');
const os = require('os');
const path = require('path');
const WURZEL = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

/* Quellpruefungen lesen sonst auch Kommentare — und in den Kommentaren dieser Dateien stehen die
 * gesuchten Feldnamen reichlich. Ohne diesen Schnitt prueft der Test seinen eigenen Fliesstext. */
function ohneKommentar(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/^[ \t]*\/\/.*$/gm, ' ');
}

const app = ohneKommentar(fs.readFileSync(path.join(WURZEL, 'ui', 'app', 'index.html'), 'utf8'));
const live = ohneKommentar(fs.readFileSync(path.join(WURZEL, 'ui', 'vetstation-live.js'), 'utf8'));

console.log('Herkunft der Gabe und Fallkennung im Protokoll — Selbsttest\n');

/* =============================================================================================
 * 1) DIE REGISTRY — echt ausgefuehrt, nicht gelesen
 * ============================================================================================= */
console.log('1) Bridge: was wirklich in der Zeile steht');
const { Registry } = require(path.join(WURZEL, 'bridge', 'src', 'registry'));
const stumm = { info() {}, warn() {}, error() {}, debug() {} };
const reg = new Registry({ log: stumm });
reg.protokollDatei = path.join(os.tmpdir(), 'vs-herkunft-' + process.pid + '.json');
reg.akteDatei = path.join(os.tmpdir(), 'vs-herkunft-akte-' + process.pid + '.json');
/* Leeren, BEVOR etwas geschrieben wird. Der Konstruktor laedt den echten Bestand der
 * Entwicklungsablage — dort steht bereits ein Patient "P1". Beim ersten Anlauf dieses Tests
 * wurden dadurch ALTE Zeilen gemessen und als "Feld fehlt" gemeldet. */
reg.protokoll = {}; reg.protokollKopf = {}; reg._protokollSchmutzig = false;

const VITALS = { hr: 90, spo2: 97, etco2: 38, af: 14, map: 70, sys: 100, dia: 55, temp: 38.1 };
function schritt(pid, versatz, mitGeraet) {
  const p = { patientId: pid, species: 'hund', weightKg: 12, vitals: VITALS, isoPct: 1.8, ventMode: 'VCV' };
  if (mitGeraet) {
    p.devices = [{ deviceId: 'd1', model: 'LifeVet 10C', role: 'monitor' }];
    p.kurvenDaten = { ecg: { hz: 256, skala: 2.5, einheit: 'uV' } };
  }
  const echt = Date.now;
  Date.now = () => echt() + versatz;
  try { reg.protokollSchritt([p]); } finally { Date.now = echt; }
}

/* Ohne devices — genau so rufen mehrere aeltere Selbsttests protokollSchritt() auf. Ohne den
 * Schutz (p.devices || []) wirft die Zeile, server.js faengt still, und JEDE Protokollzeile
 * geht verloren. Das ist die teuerste Fehlerart dieses Umbaus, deshalb steht sie hier zuerst. */
schritt('T-ohne', 0, false);
const Lohne = reg.protokoll['T-ohne'] || [];
ok('ohne devices entsteht trotzdem eine Zeile', Lohne.length === 1,
  'Zeilen: ' + Lohne.length + ' — der Schutz (p.devices || []) fehlt');
ok('… und sie traegt eine Fallkennung', !!(Lohne[0] && Lohne[0].fall));
ok('… und dev ist null statt undefined', Lohne[0] && Lohne[0].dev === null);

schritt('T-dev', 0, true);
const Ldev = reg.protokoll['T-dev'] || [];
const Kdev = reg.protokollKopf['T-dev'] || {};
ok('mit Geraet steht das Geraet als Kurztext in der Zeile',
  /LifeVet 10C/.test(String(Ldev[0] && Ldev[0].dev)));
ok('der Kopf fuehrt das Geraet ausfuehrlich',
  Array.isArray(Kdev.geraete) && Kdev.geraete.length === 1 && Kdev.geraete[0].id === 'd1');
ok('der Kopf fuehrt den Kurvenmassstab',
  !!(Kdev.kurvenMass && Kdev.kurvenMass.ecg && Kdev.kurvenMass.ecg.hz === 256),
  'ohne Abtastrate und Skala laesst sich eine aufgezeichnete Kurve spaeter nicht nachrechnen');

/* Der Kopf darf nur ERGAENZEN. Ein zweiter Takt mit anderem Geraet (Monitor gewechselt) darf
 * die zuerst festgehaltene Angabe nicht ueberschreiben — sonst stuende am Ende der Narkose ein
 * anderes Geraet im Dokument als das, an dem gemessen wurde. */
{
  const p2 = {
    patientId: 'T-dev', species: 'hund', weightKg: 12, vitals: VITALS,
    devices: [{ deviceId: 'd9', model: 'Anderes Geraet', role: 'monitor' }],
  };
  const echt = Date.now;
  Date.now = () => echt() + 600000;
  try { reg.protokollSchritt([p2]); } finally { Date.now = echt; }
  ok('der Kopf wird nur ergaenzt, nie ueberschrieben',
    (reg.protokollKopf['T-dev'].geraete || [])[0].id === 'd1');
}

console.log('\n2) Die Fallgrenze trennt zwei Narkosen desselben Patienten');
schritt('T-fall', 0, true);
schritt('T-fall', 60000, true);     // 1 min:  dieselbe Narkose
schritt('T-fall', 600000, true);    // 10 min: neue Narkose
const F = (reg.protokoll['T-fall'] || []).map((x) => x.fall);
ok('drei Zeilen entstanden', F.length === 3, 'Zeilen: ' + F.length);
ok('eine Minute Pause bleibt DERSELBE Fall', F[0] === F[1],
  'sonst zerfaellt eine laufende Narkose in Bruchstuecke');
ok('zehn Minuten Pause sind ein NEUER Fall', F[1] !== F[2],
  'sonst haengen zwei Patiententermine aneinander');

/* Die Fallkennung wird aus der LISTE hergeleitet, nicht aus this. Das ist der Grund, weshalb sie
 * einen Neustart der Station mitten in der Narkose ueberlebt: eine frische Registry liest die
 * Liste von der Platte und findet dieselbe Kennung wieder. */
{
  const reg2 = new Registry({ log: stumm });
  reg2.protokollDatei = reg.protokollDatei; reg2.akteDatei = reg.akteDatei;
  reg2.protokoll = { 'T-fall': (reg.protokoll['T-fall'] || []).slice() };
  reg2.protokollKopf = {}; reg2._protokollSchmutzig = false;
  const echt = Date.now;
  Date.now = () => echt() + 660000;   // 1 min nach der letzten Zeile
  try {
    reg2.protokollSchritt([{ patientId: 'T-fall', species: 'hund', weightKg: 12, vitals: VITALS }]);
  } finally { Date.now = echt; }
  const N = reg2.protokoll['T-fall'];
  ok('ein Neustart mitten in der Narkose behaelt die Fallkennung',
    N[N.length - 1].fall === F[2],
    'die Kennung darf nicht am Arbeitsspeicher haengen, sonst zerreisst jeder Neustart den Fall');
}

console.log('\n3) Die Gabe traegt ihre Herkunft');
const gutGeschrieben = reg.medikamentGabe('T-fall', {
  name: 'Atropin', dosis: '0,04 mg/kg', kind: 'medikament', id: 'atropin',
  incId: 'bradykardie', incName: 'Bradykardie', quelle: 'erstwahl', rang: 1,
});
ok('die Gabe wurde angenommen', gutGeschrieben === true);
const G = (reg.protokoll['T-fall'] || []).filter((x) => x.art === 'med')[0] || {};
const M = G.med || {};
ok('med.incId steht in der Zeile', M.incId === 'bradykardie');
ok('med.incName steht in der Zeile', M.incName === 'Bradykardie');
ok('med.quelle steht in der Zeile', M.quelle === 'erstwahl');
ok('med.rang steht als ZAHL in der Zeile', M.rang === 1 && typeof M.rang === 'number');
ok('die Gabe haengt am selben Fall wie die Messzeilen daneben', G.fall === F[2],
  'sonst findet die Auswertung Gabe und Wirkung nicht zusammen');

/* Nichts erfinden: fehlt die Herkunft, muss null dastehen — nicht 0, nicht ''. Eine 0 im Rang
 * hiesse "nullter Vorschlag" und waere eine Aussage, die niemand gemacht hat. */
reg.medikamentGabe('T-leer', { name: 'Propofol', dosis: '4 mg/kg' });
const ML = ((reg.protokoll['T-leer'] || [])[0] || {}).med || {};
ok('ohne Herkunft steht ueberall null', ML.incId === null && ML.incName === null
  && ML.quelle === null && ML.rang === null,
  'gefunden: ' + JSON.stringify([ML.incId, ML.incName, ML.quelle, ML.rang]));

/* Ein Unfug-Rang darf nicht durchrutschen: die Cloud-Regel nimmt nur Zahlen. */
reg.medikamentGabe('T-mist', { name: 'X', dosis: '1', rang: 'zwei' });
ok('ein Rang, der keine Zahl ist, wird zu null',
  (((reg.protokoll['T-mist'] || [])[0] || {}).med || {}).rang === null);

console.log('\n4) Die Zeile bleibt uebertragbar');
/* Die Fern-Uebertragung erlaubt hoechstens ZWEI Ebenen. Eine dritte wird abgewiesen, und drei
 * abgewiesene Zeilen schalten die Uebertragung ganz ab — deshalb ist das keine Formfrage. */
function tiefe(o, d) {
  if (!o || typeof o !== 'object') return d;
  let m = d;
  Object.keys(o).forEach((k) => { const t = tiefe(o[k], d + 1); if (t > m) m = t; });
  return m;
}
ok('die Messzeile bleibt einstufig', tiefe(reg.protokoll['T-fall'][0], 0) === 1);
ok('die Gabenzeile bleibt hoechstens zweistufig', tiefe(G, 0) <= 2,
  'gemessen: ' + tiefe(G, 0));
ok('fall und dev stehen auf der obersten Ebene, nicht in einem Unterobjekt',
  typeof reg.protokoll['T-fall'][0].fall === 'string');

/* Ueberlange Angaben werden gekappt — die Cloud-Regel begrenzt Zeichenketten. */
reg.medikamentGabe('T-lang', {
  name: 'Y', dosis: '1',
  incId: 'x'.repeat(200), incName: 'y'.repeat(400), quelle: 'z'.repeat(200),
});
const MG = (((reg.protokoll['T-lang'] || [])[0] || {}).med) || {};
ok('incId/incName/quelle werden gekappt',
  MG.incId.length === 40 && MG.incName.length === 80 && MG.quelle.length === 24,
  'gemessen: ' + [MG.incId.length, MG.incName.length, MG.quelle.length].join('/'));

/* =============================================================================================
 * 5) DIE OBERFLAECHE — wer setzt die Felder ueberhaupt?
 * ============================================================================================= */
console.log('\n5) Oberflaeche: jede Buchungsstelle nennt ihre Herkunft');
const aufrufe = app.match(/medBuchen\(\{[\s\S]{0,900}?\}\);/g) || [];
ok('es gibt weiterhin genau fuenf Buchungsstellen', aufrufe.length === 5,
  'gefunden: ' + aufrufe.length + ' — eine neue Stelle muss hier mitgezaehlt und begruendet werden');
const ohneQuelle = aufrufe.filter((a) => !/quelle\s*:/.test(a));
ok('jede von ihnen setzt quelle', ohneQuelle.length === 0,
  ohneQuelle.length + ' Stelle(n) ohne quelle: ' + ohneQuelle.map((a) => a.slice(0, 60)).join(' || '));

const QUELLEN = ['liste', 'erstwahl', 'injektion', 'antagonist', 'reset'];
QUELLEN.forEach((q) => {
  ok('die Herkunft "' + q + '" kommt vor', new RegExp("quelle:'" + q + "'").test(app));
});

ok('medBuchen kappt die vier Felder selbst',
  /rec\.quelle=/.test(app) && /rec\.incId=/.test(app) && /rec\.incName=/.test(app) && /rec\.rang=/.test(app),
  'sonst muesste jede Aufrufstelle daran denken');
/* Die Kappung muss VOR der Buchung stehen. Danach waere sie wirkungslos: die Zeile liegt dann
 * schon in state.medGaben und ist per postMessage unterwegs. */
ok('… und zwar vor state.medGaben.push',
  /rec\.rang=[\s\S]{0,200}state\.medGaben\.push\(rec\)/.test(app));

ok('die Zwischenfall-Stelle reicht incId und incName weiter',
  /incId:\(state\.erstwahl&&state\.erstwahl\.inc\)\|\|state\.incident\|\|null/.test(app));
ok('… und den Rang', /rang:ewRang\(id\)/.test(app));

/* ewRang darf NUR aus `reihe` lesen. `nach` ist ausdruecklich eine Auswahl und keine Rangfolge —
 * wer sie durchnummeriert, schreibt eine Empfehlung ins Protokoll, die nie ausgesprochen wurde. */
ok('ewRang liest die Rangfolge, nicht den Nachlauf',
  /function ewRang\(id\)\{[\s\S]{0,300}\}/.test(app)
  && /E&&E\.reihe/.test(app)
  && !/function ewRang\(id\)\{[\s\S]{0,300}\.nach/.test(app));
ok('ewRang gibt ohne Treffer null zurueck, nicht 0',
  /k>=0\?\(k\+1\):null/.test(app),
  'eine 0 hiesse "nullter Vorschlag" — eine Aussage, die niemand gemacht hat');

/* =============================================================================================
 * 6) DER ZWEITE BAUWEG — das Fensterprotokoll fuer den AUSDRUCK
 * ============================================================================================= */
console.log('\n6) Ausdruck: die zweite Stelle, die dieselbe Zeile baut');
ok('logMed() fuehrt dieselben vier Felder',
  /incId:/.test(live) && /incName:/.test(live) && /quelle:/.test(live) && /rang:/.test(live),
  'sonst widersprechen sich Ausdruck und Akte derselben Narkose');
const logMedBlock = (live.match(/function logMed\(key, gabe\)[\s\S]{0,2200}?fensterProtokollDeckeln/) || [''])[0];
ok('… und zwar innerhalb von logMed', /incId/.test(logMedBlock) && /rang/.test(logMedBlock));
ok('… mit derselben Kappung wie die Registry',
  /slice\(0, 40\)/.test(logMedBlock) && /slice\(0, 80\)/.test(logMedBlock) && /slice\(0, 24\)/.test(logMedBlock),
  'zwei verschiedene Grenzen liefern zwei verschiedene Texte fuer dieselbe Gabe');

console.log('\n---------------------------------------------');
console.log('  bestanden: ' + pass + '   fehlgeschlagen: ' + fail);
try { fs.unlinkSync(reg.protokollDatei); } catch (_) { /* nie angelegt */ }
try { fs.unlinkSync(reg.akteDatei); } catch (_) { /* nie angelegt */ }
if (fail) process.exit(1);
console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
