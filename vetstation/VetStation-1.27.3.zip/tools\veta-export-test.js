'use strict';
/*
 * veta-export-test.js - landen die Beatmungswerte des Veta 5 Plus an der RICHTIGEN MINUTE?
 *
 * WARUM ES DIESEN TEST GIBT:
 * tools/veta-export-lesen.js hat genau eine Stelle, an der ein Fehler unsichtbar bleibt.
 * Die Trendliste des Geraetes steht ZEILENWEISE:
 *     Feld 0        Kopf
 *     Feld 1..2880  die Zeitstempel
 *     Feld 2881     Spaltenname "Fi/Et CO2(mmHg)"
 *     Feld 2882..   die 2880 Werte dazu
 *     ... sechs Spalten HINTEREINANDER, nicht nebeneinander.
 * Greift der Leser um EINS daneben, stehen alle Werte eine Minute zu frueh oder zu spaet.
 * Nichts stuerzt ab, keine Zahl sieht falsch aus, die Kurve ist genauso glatt wie vorher -
 * nur das Atemzugvolumen im Moment des Zwischenfalls gehoert dann zur Nachbarminute. Ein
 * Bericht, der so entsteht, ist schlimmer als keiner.
 *
 * WORAN DER TEST MISST - und warum das nicht der Leser selbst ist:
 *
 *   1. AN EINER UNABHAENGIG ABGELESENEN STICHPROBE. Die Werte unten stammen NICHT aus diesem
 *      Programm, sondern aus der im Browser angezeigten Tabelle des echten Exports (der
 *      Tierarzt hat sie dort abgelesen, bevor es einen Leser gab):
 *         letzter Fall 29.08.2026, 00:16 bis 00:33
 *         00:23  Vt 72, MV 8.0, AF 111
 *         00:24  MAX 4, PEEP 3, Vt 13, MV 0.2, AF 8
 *         00:33  Marke "End Case"
 *      Die Minute 00:24 ist dabei die entscheidende: 00:22 und 00:23 tragen ZUFAELLIG
 *      dieselben Werte (72 / 8.0 / 111). Eine Pruefung, die nur 00:23 abfragt, wuerde eine
 *      Verschiebung um +1 nicht bemerken. 00:24 bemerkt beide Richtungen.
 *
 *   2. AN DER DARSTELLUNG, DIE DIE DATEI SELBST VORSCHREIBT. Die HTML bringt ihre eigene
 *      Zeichenroutine mit: CreateTable(id, Zeilen, Spalten, Feld) liest Zelle [i][j] als
 *      Feld[i*Spalten+j]. Dieser Test baut die Tabelle GENAU SO nach - Zeile fuer Zeile, wie
 *      sie im Browser erscheint - und vergleicht Zelle fuer Zelle mit dem, was der Leser
 *      ausgibt. Damit steht dem Leser nicht seine eigene Rechnung gegenueber, sondern die
 *      des Geraeteherstellers.
 *
 * PFLICHT-GEGENPROBE (29.08.2026 gefahren): in veta-export-lesen.js wurde der Spaltenanfang
 * absichtlich um eins verschoben (felder[z*breite + i]  ->  felder[z*breite + i + 1]).
 * Ergebnis: 4 Pruefungen rot, darunter beide Stichprobenminuten und der Zellenvergleich.
 * Danach zurueckgedreht.
 *
 * ABSCHNITT A laeuft IMMER (kleine, hier gebaute Exporte). Er prueft die Dinge, die der echte
 * Export nicht hergibt, weil bei ihm alles in Ordnung ist: vertauschte Spaltenreihenfolge,
 * unbekannte Spalte, sich widersprechende Spaltenbreite, falsch umkodierte Datei und den
 * Ersatzweg ueber die "End Case"-Marken.
 * ABSCHNITT B braucht den ECHTEN Export. Fehlt er, wird er mit klarer Meldung uebersprungen
 * statt rot zu werden - er liegt ausserhalb des Repos und ist auf keinem anderen Rechner da.
 *
 * Start: node tools/veta-export-test.js
 *        VETA_EXPORT=<Ordner mit dem Beispielexport> node tools/veta-export-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const M = require('./veta-export-lesen.js');

/* WO DER BEISPIELEXPORT LIEGT - und warum das hier nicht mehr fest dasteht (29.08.2026).
 *
 * An dieser Stelle stand ein fester Pfad. Er trug den Windows-Kontonamen des Entwicklers,
 * und der Ordnername darunter TRUG DIE MAC-ADRESSE des Praxisgeraetes; gleich darunter stand
 * dessen Geraete-ID als Vergleichswert. tools/ faehrt vollstaendig im oeffentlichen
 * Update-Zip mit, das jede Station von GitHub Pages laedt - beides waere damit auf jedem
 * fremden Praxis-PC gelandet. MAC und Geraetekennung wiegen dabei schwerer als eine
 * Netzadresse: sie benennen ein bestimmtes Geraet in einer bestimmten Praxis. Dieselbe
 * Begruendung hat am 19.08.2026 die vier Netzskripte aus dem Update genommen.
 *
 * Gesucht wird jetzt in dieser Reihenfolge:
 *   1. VETA_EXPORT - Ordner oder HTML-Datei, ausdruecklich gesetzt
 *   2. ein Ordner NEBEN dem Baum, dessen Name mit "veta-export" beginnt; eine Ebene tiefer
 *      wird mitgesucht, weil das Geraet seinen Export in einen Unterordner legt
 * Der Export selbst gehoert weiterhin NICHT ins Repo: 2,4 MB Betriebsdaten einer Praxis
 * haben in einem Quellcodebaum nichts zu suchen (siehe tools/setup-sauber-test.js). Wird
 * nichts gefunden, wird Abschnitt B uebersprungen - wie bisher, statt rot zu werden.
 */
function hatHtml(ordner) {
  try { return fs.readdirSync(ordner).some(function (n) { return /\.html?$/i.test(n); }); }
  catch (e) { return false; }
}
function exportSuchen() {
  const gesetzt = process.env.VETA_EXPORT;
  if (gesetzt) return fs.existsSync(gesetzt) ? gesetzt : null;
  const baum = path.join(__dirname, '..');
  const eltern = [path.join(baum, '..'), path.join(baum, '..', '..')];
  for (let e = 0; e < eltern.length; e++) {
    let namen;
    try { namen = fs.readdirSync(eltern[e]); } catch (err) { continue; }
    const kandidaten = namen.filter(function (n) { return /^veta-export/i.test(n); });
    for (let k = 0; k < kandidaten.length; k++) {
      const ordner = path.join(eltern[e], kandidaten[k]);
      let st;
      try { st = fs.statSync(ordner); } catch (err) { continue; }
      if (!st.isDirectory()) continue;
      if (hatHtml(ordner)) return ordner;
      let tiefer;
      try { tiefer = fs.readdirSync(ordner); } catch (err) { continue; }
      for (let t = 0; t < tiefer.length; t++) {
        const unten = path.join(ordner, tiefer[t]);
        if (hatHtml(unten)) return unten;
      }
    }
  }
  return null;
}
const ECHT = exportSuchen();

let ok = 0;
const fehler = [];
let uebersprungen = 0;

function pruef(was, bedingung, zusatz) {
  if (bedingung) { ok++; console.log('  + ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  FEHLGESCHLAGEN: ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }
function wirftFehler(fn) {
  try { fn(); return null; } catch (e) { return e.message; }
}

/* =====================================================================================
 * EIN KLEINER EXPORT, HIER GEBAUT
 * Aufbau wie beim echten: die Felder stehen als JavaScript-Feldliteral im <script>, die
 * Spaltenbreite steht im CreateTable-Aufruf am Dateiende.
 * =================================================================================== */
function feldText(name, felder) {
  return 'var ' + name + ' = [' + felder.map(function (f) { return '"' + f + '"'; }).join(',') + ',];\n';
}
function baueExport(o) {
  const zeiten = o.zeiten;                     /* ['2026-01-02<br>1:00 PM', ...] neueste zuerst */
  const spalten = o.spalten;                   /* [[name, [wert,...]], ...] */
  const breite = zeiten.length + 1;
  let t3 = ['Date<br>Time<br>Event'].concat(zeiten);
  spalten.forEach(function (s) { t3 = t3.concat([s[0]]).concat(s[1]); });

  let t4 = ['Zeit', 'Informationen', 'Details'];
  (o.protokoll || []).forEach(function (p) { t4 = t4.concat(p); });

  /* Die Versionstabelle ist ab dem 29.08.2026 kein Beiwerk mehr: aus ihr nimmt der Leser,
   * welche Vier-Zahlen-Bloecke Versionen und keine Netzadressen sind. Deshalb muss der Test
   * sie setzen koennen - sonst laesst sich der Fall "6.5.0.0" gar nicht nachstellen. */
  const t2 = o.t2 || ['ITEM', 'Version', 'Datum', 'Bundle-Version', '01.10.00.01', '---'];
  /* Zusaetzliche Tabellen (T_Data5..), damit die Suche ueber ALLE Tabellen einen Anlass hat. */
  let mehr = '';
  (o.mehrTabellen || []).forEach(function (t) { mehr += feldText(t[0], t[1]); });

  const breiteImAufruf = (o.breiteImAufruf != null) ? o.breiteImAufruf : breite;
  /* ohneCreateTable: der zweite Breitenweg faellt weg - der Anlass fuer B7. */
  const aufruf = o.ohneCreateTable ? ''
    : '<script> CreateTable("T_Data3", -1, ' + breiteImAufruf + ', T_Data3); </script>\n';
  return '<html>\n <head>\n <meta http-equiv="content-type" content="text/html;charset=UTF-8">\n' +
    ' <script type ="text/javascript">\n' +
    feldText('T_Data0', ['Ger\u00e4tetyp', 'Anesthesia machine', 'Ger\u00e4te-ID', o.id || '1', 'MAC-Adresse', o.mac || '00:00:00:00:00:00']) +
    feldText('T_Data1', ['ITEM', 'Std.:Min.', 'Betriebszeit des Ger\u00e4tes', '1:00']) +
    feldText('T_Data2', t2) +
    feldText('T_Data3', t3) +
    feldText('T_Data4', t4) +
    mehr +
    '</script>\n</head>\n<body>\n' +
    aufruf +
    '<script> CreateTable("T_Data4", -1, 3, T_Data4); </script>\n' +
    '</body>\n</html>\n';
}

/* Sechs Wertespalten mit demselben Fuellwert je Minute - fuer alle Faelle, in denen es auf
 * die Zahlen gar nicht ankommt, sondern auf Faelle, Zeiten oder Freitext. */
function spaltenFuer(n, leerBei) {
  const namen = ['Fi/Et CO2(mmHg)', 'MAX(cmH2O)', 'PEEP(cmH2O)', 'Vt(ml)', 'MV(l/min)', 'AF(BPM)'];
  const werte = ['1/40', '10', '3', '100', '1.5', '12'];
  return namen.map(function (name, k) {
    const spalte = [];
    for (let i = 0; i < n; i++) spalte.push((leerBei && leerBei.indexOf(i) >= 0) ? '' : werte[k]);
    return [name, spalte];
  });
}
function schreibe(ordner, name, inhalt, kodierung) {
  const p = path.join(ordner, name);
  fs.writeFileSync(p, Buffer.from(inhalt, kodierung || 'utf8'));
  return p;
}

console.log('\nVetStation - USB-Export des Veta 5 Plus lesen\n');

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'veta-test-'));

/* =====================================================================================
 * ABSCHNITT A - gebaute Exporte (laeuft immer)
 * =================================================================================== */
block('A1. Grundfall: drei Minuten, sechs Spalten, ein Fall im Protokoll');

const A1 = baueExport({
  zeiten: [
    '2026-01-02<br>1:02 PM<br>End Case',
    '2026-01-02<br>1:02 PM ',
    '2026-01-02<br>1:01 PM ',
    '2026-01-02<br>1:00 PM '
  ],
  spalten: [
    ['Fi/Et CO2(mmHg)', ['', '1/40', '2/41', '---/---']],
    ['MAX(cmH2O)', ['', '10', '11', '---']],
    ['PEEP(cmH2O)', ['', '3', '4', '5']],
    ['Vt(ml)', ['', '100', '110', '120']],
    ['MV(l/min)', ['', '1.5', '1.6', '1.7']],
    ['AF(BPM)', ['', '12', '13', '14']]
  ],
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 12:59 PM <br>Ende <br>2026-01-02 1:02 PM <br>'],
    ['2026-01-02 12:59:10 PM', 'Fall starten', 'Start <br>2026-01-02 12:59 PM <br>Ende <br>-------- --:-- <br>']
  ]
});
const a1 = M.exportLesen(schreibe(temp, 'a1.html', A1), 1);

pruef('vier Trendzeilen, davon drei Messminuten und eine Marke',
  a1.trend.zeilen === 4 && a1.trend.punkte.length === 3 && a1.trend.marken.length === 1);
pruef('die Messminuten stehen chronologisch (aelteste zuerst)',
  a1.trend.punkte[0].zeit === '2026-01-02T13:00:00' &&
  a1.trend.punkte[2].zeit === '2026-01-02T13:02:00');
pruef('13:00 traegt die aelteste Wertespalte (Vt 120, AF 14, PEEP 5)',
  a1.trend.punkte[0].vt === 120 && a1.trend.punkte[0].af === 14 && a1.trend.punkte[0].peep === 5,
  JSON.stringify(a1.trend.punkte[0]));
pruef('13:02 traegt die neueste Wertespalte (Vt 100, AF 12, MAX 10)',
  a1.trend.punkte[2].vt === 100 && a1.trend.punkte[2].af === 12 && a1.trend.punkte[2].max === 10,
  JSON.stringify(a1.trend.punkte[2]));
pruef('"---" wird null, nicht 0',
  a1.trend.punkte[0].max === null && a1.trend.punkte[1].max === 11);
pruef('"---/---" wird zu zwei null, "2/41" zu fico2=2 und etco2=41',
  a1.trend.punkte[0].fico2 === null && a1.trend.punkte[0].etco2 === null &&
  a1.trend.punkte[1].fico2 === 2 && a1.trend.punkte[1].etco2 === 41);
pruef('der Fall kommt aus dem Ereignisprotokoll (12:59 bis 13:02, 3 min)',
  a1.faelle.length === 1 && a1.faelle[0].dauerMin === 3 &&
  a1.faelle[0].quelleZeiten === 'Ereignisprotokoll' && a1.faelle[0].punkte.length === 3,
  JSON.stringify(a1.faelle.map(function (f) { return [f.start, f.ende, f.punkte.length]; })));
pruef('die End-Case-Marke ist dem Fall zugeordnet und traegt keine Werte',
  a1.faelle[0].marke != null && a1.trend.marken[0].hatWerte === false);

block('A2. Die Spalten werden ueber ihren NAMEN zugeordnet, nicht ueber ihre Stellung');

/* Dieselben Werte, aber die sechs Spalten in umgekehrter Reihenfolge. Ein Leser, der nach
 * Stellung zuordnet, wuerde hier AF in das Vt-Feld schreiben - und niemandem faellt es auf,
 * weil beide Zahlen plausibel sind. */
const A2 = baueExport({
  zeiten: ['2026-01-02<br>1:00 PM '],
  spalten: [
    ['AF(BPM)', ['14']],
    ['MV(l/min)', ['1.7']],
    ['Vt(ml)', ['120']],
    ['PEEP(cmH2O)', ['5']],
    ['MAX(cmH2O)', ['9']],
    ['Fi/Et CO2(mmHg)', ['3/42']]
  ]
});
const a2 = M.exportLesen(schreibe(temp, 'a2.html', A2), 1);
pruef('vertauschte Spaltenreihenfolge aendert nichts an der Zuordnung',
  a2.trend.punkte[0].af === 14 && a2.trend.punkte[0].mv === 1.7 && a2.trend.punkte[0].vt === 120 &&
  a2.trend.punkte[0].peep === 5 && a2.trend.punkte[0].max === 9 &&
  a2.trend.punkte[0].fico2 === 3 && a2.trend.punkte[0].etco2 === 42,
  JSON.stringify(a2.trend.punkte[0]));

block('A3. Was der Leser NICHT stillschweigend hinnehmen darf');

const A3a = baueExport({
  zeiten: ['2026-01-02<br>1:00 PM '],
  spalten: [
    ['Fi/Et CO2(mmHg)', ['1/40']], ['MAX(cmH2O)', ['10']], ['PEEP(cmH2O)', ['3']],
    ['Vt(ml)', ['100']], ['MV(l/min)', ['1.5']], ['Pplat(cmH2O)', ['7']]
  ]
});
const m3a = wirftFehler(function () { M.exportLesen(schreibe(temp, 'a3a.html', A3a), 1); });
pruef('eine unbekannte Trendspalte wird gemeldet, nicht geraten',
  m3a != null && /unbekannte Trendspalte/.test(m3a), String(m3a));

const A3b = baueExport({
  zeiten: ['2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '],
  spalten: [
    ['Fi/Et CO2(mmHg)', ['1/40', '1/41']], ['MAX(cmH2O)', ['10', '11']], ['PEEP(cmH2O)', ['3', '4']],
    ['Vt(ml)', ['100', '110']], ['MV(l/min)', ['1.5', '1.6']], ['AF(BPM)', ['12', '13']]
  ],
  breiteImAufruf: 4                      /* die Datei widerspricht sich selbst: 3 waere richtig */
});
const m3b = wirftFehler(function () { M.exportLesen(schreibe(temp, 'a3b.html', A3b), 1); });
pruef('widerspricht CreateTable dem Feldinhalt, bricht der Leser ab',
  m3b != null && /widerspricht sich/.test(m3b), String(m3b));

/* Eine als latin1 gespeicherte Datei: der Umlaut in "Geraetetyp" wird zu zwei Zeichen.
 * Wer das nicht merkt, liest ab hier falsche Spaltennamen. */
const A3c = baueExport({
  zeiten: ['2026-01-02<br>1:00 PM '],
  spalten: [
    ['Fi/Et CO2(mmHg)', ['1/40']], ['MAX(cmH2O)', ['10']], ['PEEP(cmH2O)', ['3']],
    ['Vt(ml)', ['100']], ['MV(l/min)', ['1.5']], ['AF(BPM)', ['12']]
  ]
});
const pfadC = path.join(temp, 'a3c.html');
fs.writeFileSync(pfadC, Buffer.from(A3c, 'latin1'));
const m3c = wirftFehler(function () { M.exportLesen(pfadC, 1); });
pruef('eine falsch kodierte Datei wird abgewiesen statt halb gelesen',
  m3c != null && /UTF-8|umkodiert/.test(m3c), String(m3c));

block('A4. Ersatzweg: Faelle aus den "End Case"-Marken, wenn das Protokoll nichts hergibt');

/* Am echten Export tritt dieser Zweig nie ein - dort nennt das Protokoll immer Faelle.
 * Ein Zweig, der nie faehrt, ist ungeprueft; deshalb hier ein Export ohne Protokoll. */
const A4 = baueExport({
  zeiten: [
    '2026-01-02<br>1:04 PM<br>End Case',
    '2026-01-02<br>1:04 PM ',
    '2026-01-02<br>1:03 PM ',
    '2026-01-02<br>1:01 PM<br>End Case',
    '2026-01-02<br>1:01 PM ',
    '2026-01-02<br>1:00 PM '
  ],
  spalten: [
    ['Fi/Et CO2(mmHg)', ['', '1/40', '1/41', '', '1/42', '1/43']],
    ['MAX(cmH2O)', ['', '10', '11', '', '12', '13']],
    ['PEEP(cmH2O)', ['', '3', '4', '', '5', '6']],
    ['Vt(ml)', ['', '100', '110', '', '120', '130']],
    ['MV(l/min)', ['', '1.5', '1.6', '', '1.7', '1.8']],
    ['AF(BPM)', ['', '12', '13', '', '14', '15']]
  ],
  protokoll: []
});
const a4 = M.exportLesen(schreibe(temp, 'a4.html', A4), 1);
pruef('ohne Faelle im Protokoll wird an den Marken getrennt - und das steht auch dran',
  a4.ersatzweise === true && /End-Case-Marken/.test(a4.faelle[0].quelleZeiten));
pruef('der Ersatzweg findet zwei Faelle (13:00-13:01 und 13:03-13:04)',
  a4.faelle.length === 2 && a4.faelle[0].punkte.length === 2 && a4.faelle[1].punkte.length === 2,
  JSON.stringify(a4.faelle.map(function (f) { return [f.start, f.ende, f.punkte.length]; })));
pruef('der Bericht sagt dem Leser, dass er den schlechteren Weg gegangen ist',
  /End Case.*Marken|Marken der Trendliste/.test(M.bericht(a4, 1)));

block('A5. Fall ohne Ende im Protokoll frisst nicht die ganze Liste');

/* Genau dieser Fehler ist beim Bauen aufgetreten: ein "Fall starten" ohne "Fall beenden"
 * bekam als Ende das Ende der Trendliste und verschluckte 2802 von 2819 Messminuten -
 * alle spaeteren Faelle waren leer, und der Bericht sah trotzdem ordentlich aus. */
const A5 = baueExport({
  zeiten: [
    '2026-01-02<br>1:04 PM ', '2026-01-02<br>1:03 PM ',
    '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '
  ],
  spalten: [
    ['Fi/Et CO2(mmHg)', ['1/40', '1/41', '1/42', '1/43']],
    ['MAX(cmH2O)', ['10', '11', '12', '13']],
    ['PEEP(cmH2O)', ['3', '4', '5', '6']],
    ['Vt(ml)', ['100', '110', '120', '130']],
    ['MV(l/min)', ['1.5', '1.6', '1.7', '1.8']],
    ['AF(BPM)', ['12', '13', '14', '15']]
  ],
  protokoll: [
    ['2026-01-02 1:04:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:03 PM <br>Ende <br>2026-01-02 1:04 PM <br>'],
    ['2026-01-02 1:03:00 PM', 'Fall starten', 'Start <br>2026-01-02 1:03 PM <br>Ende <br>-------- --:-- <br>'],
    ['2026-01-02 1:00:00 PM', 'Fall starten', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>-------- --:-- <br>']
  ]
});
const a5 = M.exportLesen(schreibe(temp, 'a5.html', A5), 1);
const a5Beendet = a5.faelle.filter(function (f) { return f.beendet; })[0];
const a5Offen = a5.faelle.filter(function (f) { return !f.beendet; })[0];
pruef('der beendete Fall behaelt seine zwei Minuten',
  a5Beendet && a5Beendet.punkte.length === 2,
  JSON.stringify(a5.faelle.map(function (f) { return [f.start, f.ende, f.beendet, f.punkte.length]; })));
pruef('der nie beendete Fall endet am naechsten Fall-Ereignis, nicht am Listenende',
  a5Offen && a5Offen.punkte.length === 2 && a5Offen.ende < a5Beendet.start,
  a5Offen ? String(a5Offen.ende) + ' >= ' + String(a5Beendet.start) : 'kein offener Fall gefunden');
pruef('sein geschaetztes Ende steht als solches dran',
  a5Offen && /geschaetzt/.test(a5Offen.quelleZeiten), a5Offen ? a5Offen.quelleZeiten : '-');

block('A6. Die HTML-Datei wird im Ordner selbst gefunden');
/* Im Temp-Ordner liegen inzwischen mehrere HTML-Dateien (a1..a5). Keine davon heisst wie der
 * Ordner - der Leser darf sich dann NICHT eine aussuchen. */
const m6 = wirftFehler(function () { M.htmlFinden(temp); });
pruef('mehrere HTML-Dateien im Ordner werden gemeldet statt geraten',
  m6 != null && /Mehrere HTML/.test(m6), String(m6));
const einzelOrdner = fs.mkdtempSync(path.join(os.tmpdir(), 'veta-einzel-'));
schreibe(einzelOrdner, 'irgendwas.html', A1);
pruef('ein Ordner mit einer HTML-Datei wird ohne Nachfrage gelesen',
  M.exportLesen(einzelOrdner, 1).trend.punkte.length === 3);

/* =====================================================================================
 * ABSCHNITT A7..A18 - die zwoelf Befunde der Gegenpruefung vom 29.08.2026
 *
 * Jeder dieser Bloecke stellt den Anlass NACH, an dem die alte Fassung falsch lag. Das ist
 * der Kern: eine Pruefung, deren Anlass im geprueften Exemplar gar nicht eintreten kann,
 * ist keine Pruefung (siehe den Kopf von tools/pds-feldsonde.js und die Notiz
 * pruefung-ohne-anlass). Am echten Export tritt keiner dieser Faelle ein - deshalb stehen
 * sie hier an eigens gebauten Exporten.
 * =================================================================================== */
block('A7. B1: der Datenschutz-Abschnitt MISST, statt eine Zusage zu drucken');

/* Genau der Export, mit dem die Gegenpruefung den Befund nachgestellt hat: zwei
 * Protokollzeilen mit Namen, sonst identisch zu A1. Alte Fassung: die Namen standen im
 * Bericht UND in der JSON, und sechs Zeilen darunter stand, es gebe sie nicht. */
const A7 = baueExport({
  zeiten: [
    '2026-01-02<br>1:02 PM<br>End Case',
    '2026-01-02<br>1:02 PM ',
    '2026-01-02<br>1:01 PM ',
    '2026-01-02<br>1:00 PM '
  ],
  spalten: spaltenFuer(4, [0]),
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 12:59 PM <br>Ende <br>2026-01-02 1:02 PM <br>'],
    ['2026-01-02 1:02:00 PM', 'Tiername: Minka, Besitzer Dr. Schulz', 'Modus VS<br>'],
    ['2026-01-02 1:01:30 PM', 'Anmeldung erfolgreich: Dr. A. Weber', 'Benutzer<br>a.weber<br>'],
    ['2026-01-02 12:59:10 PM', 'Fall starten', 'Start <br>2026-01-02 12:59 PM <br>Ende <br>-------- --:-- <br>']
  ]
});
const a7 = M.exportLesen(schreibe(temp, 'a7.html', A7), 1);
const b7txt = M.bericht(a7, 1);

pruef('der Export MIT Namen wird als solcher gemeldet (nicht nur gedruckt)',
  a7.namen.treffer >= 3, a7.namen.treffer + ' Treffer');
pruef('der Bericht nennt die Fundstellen einzeln und mit Uhrzeit',
  /GEFUNDEN: \d+ Stelle\(n\)/.test(b7txt) &&
  /Ereignisprotokoll 02\.01\.2026 13:02.*Tiername/.test(b7txt) &&
  /Ereignisprotokoll 02\.01\.2026 13:01/.test(b7txt),
  b7txt.slice(b7txt.indexOf('GEFUNDEN:'), b7txt.indexOf('GEFUNDEN:') + 200));
pruef('der Bericht sagt, dass er so nicht weitergegeben werden sollte',
  /NICHT WEITERGEGEBEN WERDEN/.test(b7txt));
/*
 * DIE EIGENTLICHE LEHRE AUS B1: der feste Satz darf NIRGENDS mehr stehen. Eine Zusage, die
 * nicht aus einer Messung stammt, ist auch dann falsch, wenn sie zufaellig zutrifft.
 */
pruef('die alte feste Zusage steht in KEINEM Bericht mehr',
  !/fuehrt KEIN Namensfeld/.test(b7txt) && !/kommt kein Patienten-/.test(b7txt));
pruef('der Bericht sagt, WIE VIEL durchsucht wurde (Felder, Tabellen, Woerter)',
  /Durchsucht: \d+ Felder aller \d+ Tabellen \(\d+ verschiedene Woerter\)/.test(b7txt));

/* Derselbe Export OHNE Namen: "gefunden: nichts" muss dastehen - und daneben die Grenze. */
const A7b = baueExport({
  zeiten: ['2026-01-02<br>1:02 PM<br>End Case', '2026-01-02<br>1:02 PM ', '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '],
  spalten: spaltenFuer(4, [0]),
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 12:59 PM <br>Ende <br>2026-01-02 1:02 PM <br>'],
    /* Genau die Texte, an denen eine zu grobe Suche stolpert: "halter" steckt in
     * "Waagenschalter", "K. Frischgas" sieht aus wie "A. Weber", und die Anmeldungen des
     * echten Geraetes nennen Rollen. Alle drei kommen im echten Export vor. */
    ['2026-01-02 1:01:00 PM', 'Elektron. Waagenschalter', 'Modus VS<br>'],
    ['2026-01-02 1:00:30 PM', 'K. Frischgas', 'Modus VS<br>'],
    ['2026-01-02 1:00:10 PM', 'System: Anmeldung erfolgreich', 'Modus Standby<br>']
  ]
});
const a7b = M.exportLesen(schreibe(temp, 'a7b.html', A7b), 1);
const b7btxt = M.bericht(a7b, 1);
pruef('ein Export ohne Namen ergibt 0 Treffer - auch bei "Waagenschalter" und "K. Frischgas"',
  a7b.namen.treffer === 0,
  JSON.stringify(a7b.namen.suchen.map(function (s) { return [s.kurz, s.treffer.map(function (t) { return t.fund; })]; })));
pruef('der Bericht sagt auch dann, wonach gesucht wurde, und schreibt "nichts"',
  /GESUCHT WURDE NACH/.test(b7btxt) && /Bezeichnung eines Namensfeldes[ .]+nichts/.test(b7btxt) &&
  /Tiername/.test(b7btxt));
/*
 * GEPRUEFT WIRD DIE AUSSAGE, NICHT DIE FORMULIERUNG (nachgezogen 29.08.2026).
 *
 * Hier stand die Suche nach zwei woertlichen Zeichenketten ("kein Merkmal gefunden",
 * 'nicht "es steht kein Name in der Datei"'). Als der Abschnitt umgeschrieben wurde -
 * weil eine dritte Gegenpruefung nachwies, dass die Suche auch Namen MIT Merkmal
 * uebersieht - wurde diese Pruefung rot, obwohl die neue Fassung MEHR sagt als die alte.
 * Das ist die Fehlerklasse "angenagelte Entscheidung": ein Test, der einen Wortlaut
 * festhaelt, verbietet jede Verbesserung daran.
 *
 * Geprueft werden deshalb jetzt die drei Aussagen, auf die es ankommt:
 *   1. der Bericht sagt, dass er ungefilterten Geraetetext enthaelt
 *   2. er nennt die Suche einen HINWEIS und ausdruecklich KEINE Zusage
 *   3. er sagt, dass "nichts gefunden" NICHT heisst, dass kein Name darin steht
 * Wie diese drei Saetze formuliert sind, darf sich aendern.
 */
pruef('er nennt die GRENZE der Suche - "nichts gefunden" ist kein Beweis',
  /ungefiltert/i.test(b7btxt) &&
  /HINWEIS/.test(b7btxt) && /KEINE ZUSAGE/i.test(b7btxt) &&
  /heisst NICHT, dass kein Name/i.test(b7btxt) &&
  /LIEST IHN VORHER/i.test(b7btxt),
  'ungefiltert=' + /ungefiltert/i.test(b7btxt) + ' hinweis=' + /HINWEIS/.test(b7btxt) +
  ' keineZusage=' + /KEINE ZUSAGE/i.test(b7btxt) +
  ' grenze=' + /heisst NICHT, dass kein Name/i.test(b7btxt));
const j7 = M.fuerJson(a7);
pruef('auch die JSON traegt die Messung samt Grenze, nicht nur eine Zahl',
  j7.datenschutz && j7.datenschutz.gesuchtNach.length === M.NAMENSMERKMALE.length &&
  j7.datenschutz.durchsuchteFelder > 0 && /kein Beweis/.test(j7.datenschutz.grenze) &&
  j7.datenschutz.gesuchtNach.some(function (g) { return g.treffer > 0; }),
  JSON.stringify(j7.datenschutz && j7.datenschutz.gesuchtNach));

block('A8. B2: ein "Fall beenden", dessen Ende vor dem Start liegt');

/* Uhrsprung am Geraet. Alte Fassung: der Fall stand mit "Dauer -2 min" im Bericht. */
const A8 = baueExport({
  zeiten: ['2026-01-02<br>1:02 PM ', '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '],
  spalten: spaltenFuer(3),
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:02 PM <br>'],
    /* Start UND Ende liegen im Trendzeitraum - sonst faellt der Eintrag schon an der
     * Zeitraumgrenze heraus und der Riegel gegen die negative Dauer bliebe ungefahren.
     * Genau das ist beim ersten Entwurf dieses Testfalls passiert. */
    ['2026-01-02 1:03:00 PM', 'Fall beenden', 'Start <br>2026-01-02 1:02 PM <br>Ende <br>2026-01-02 1:00 PM <br>']
  ]
});
const a8 = M.exportLesen(schreibe(temp, 'a8.html', A8), 1);
const b8txt = M.bericht(a8, 1);
pruef('der Eintrag mit Ende vor Start wird kein Fall',
  a8.faelle.length === 1 && a8.faelle.every(function (f) { return f.dauerMin >= 0; }),
  JSON.stringify(a8.faelle.map(function (f) { return [f.start, f.ende, f.dauerMin]; })));
pruef('er wird benannt statt stillschweigend weggelassen',
  a8.verworfen.length === 1 && /Ende liegt vor dem Start/.test(a8.verworfen[0].grund) &&
  /verworfen, weil sie keine Dauer ergeben/.test(b8txt),
  JSON.stringify(a8.verworfen));
pruef('im ganzen Bericht steht keine negative Dauer',
  !/Dauer\s+-\d/.test(b8txt) && !/-\d+ min/.test(b8txt));

block('A9. B3: zwei "End Case"-Marken in derselben Minute (Ersatzweg)');

/* Ohne Protokoll wird an den Marken getrennt. Zwei Marken in derselben Minute ergaben in der
 * alten Fassung einen Fall mit "Dauer -1 min": start = aelter+1 lag hinter dem Ende. */
const A9 = baueExport({
  zeiten: [
    '2026-01-02<br>1:04 PM<br>End Case',
    '2026-01-02<br>1:04 PM ',
    '2026-01-02<br>1:03 PM ',
    '2026-01-02<br>1:01 PM<br>End Case',
    '2026-01-02<br>1:01 PM<br>End Case',
    '2026-01-02<br>1:01 PM ',
    '2026-01-02<br>1:00 PM '
  ],
  spalten: spaltenFuer(7, [0, 3, 4]),
  protokoll: []
});
const a9 = M.exportLesen(schreibe(temp, 'a9.html', A9), 1);
const b9txt = M.bericht(a9, 1);
pruef('der Ersatzweg erzeugt keinen Fall mit negativer Dauer',
  a9.ersatzweise === true && a9.faelle.every(function (f) { return f.dauerMin >= 0 && f.start <= f.ende; }),
  JSON.stringify(a9.faelle.map(function (f) { return [f.start, f.ende, f.dauerMin]; })));
pruef('die zweite Marke derselben Minute wird als verworfen benannt',
  a9.verworfen.length === 1 && /derselben Minute/.test(a9.verworfen[0].grund),
  JSON.stringify(a9.verworfen));
pruef('auch hier steht im Bericht keine negative Dauer',
  !/-\d+ min/.test(b9txt));

block('A10. B4: bericht(daten, N) zeigt nie einen anderen Fall als den gelesenen');

/* Der Beweis der Gegenpruefung: bericht(exportLesen(O,1), 3) druckte Kopf und Minutenwerte
 * von Fall 3 und darunter die Ereignisse von Fall 1. Ueber die Befehlszeile nicht
 * erreichbar, ueber module.exports sehr wohl - und beide Funktionen sind exportiert. */
const A10 = baueExport({
  zeiten: [
    '2026-01-02<br>1:10 PM ', '2026-01-02<br>1:09 PM ',
    '2026-01-02<br>1:02 PM ', '2026-01-02<br>1:01 PM '
  ],
  spalten: spaltenFuer(4),
  protokoll: [
    ['2026-01-02 1:10:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:09 PM <br>Ende <br>2026-01-02 1:10 PM <br>'],
    ['2026-01-02 1:09:30 PM', 'Zweiter Fall laeuft', 'Modus VS<br>'],
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:01 PM <br>Ende <br>2026-01-02 1:02 PM <br>'],
    ['2026-01-02 1:01:30 PM', 'Erster Fall laeuft', 'Modus VS<br>']
  ]
});
const p10 = schreibe(temp, 'a10.html', A10);
const a10eins = M.exportLesen(p10, 1);
const a10zwei = M.exportLesen(p10, 2);
pruef('die beiden Faelle tragen wirklich VERSCHIEDENE Ereignisse (sonst prueft A10 nichts)',
  a10eins.ereignisse.length === 2 && a10zwei.ereignisse.length === 2 &&
  a10eins.ereignisse.map(function (e) { return e.was; }).join() !==
  a10zwei.ereignisse.map(function (e) { return e.was; }).join(),
  JSON.stringify([a10eins.ereignisse.map(function (e) { return e.was; }),
    a10zwei.ereignisse.map(function (e) { return e.was; })]));
const m10 = wirftFehler(function () { M.bericht(a10eins, 2); });
pruef('bericht(daten, 2) auf einem fuer Fall 1 gelesenen Export bricht ab',
  m10 != null && /gelesen wurde aber Fall 1/.test(m10), String(m10));
const b10eins = M.bericht(a10eins, 1);
const b10zwei = M.bericht(a10zwei, 2);
/* Fall 1 ist der NEUESTE - also der zweite, der gelaufen ist. */
pruef('jeder Bericht zeigt nur die Ereignisse SEINES Falls',
  /Zweiter Fall laeuft/.test(b10eins) && !/Erster Fall laeuft/.test(b10eins) &&
  /Erster Fall laeuft/.test(b10zwei) && !/Zweiter Fall laeuft/.test(b10zwei));
pruef('ohne zweiten Aufrufwert nimmt bericht() den gelesenen Fall',
  M.bericht(a10zwei) === b10zwei);
/*
 * Und die Wurzel des Befundes: es darf nur EINE Ereignisliste geben. daten.ereignisse ist
 * dieselbe Liste wie daten.fall.ereignisse, kein zweites Ergebnis daneben. Baute jemand hier
 * wieder eine eigene Liste (frueher: ereignisseZuFall(protokoll, fall)), koennten die beiden
 * auseinanderlaufen - und genau daraus entstand der Bericht mit fremden Ereignissen.
 */
pruef('es gibt nur EINE Ereignisliste - die am Fall selbst',
  a10eins.ereignisse === a10eins.fall.ereignisse && a10zwei.ereignisse === a10zwei.fall.ereignisse);

block('A11. B6: eine unbekannte Fallnummer erzeugt UEBERHAUPT keinen Bericht');

const a11 = M.exportLesen(p10, 99);
const m11 = wirftFehler(function () { M.bericht(a11, 99); });
pruef('bericht() bricht bei einer unbekannten Fallnummer ab, statt einen halben zu drucken',
  m11 != null && /Es gibt keinen Fall Nr\. 99/.test(m11), String(m11));
/* Der Befehlszeilenweg ist der, den der Tierarzt geht - er wird eigens gefahren.
 * Exitcode 2 wie bei tools/pds-feldsonde.js mit "--nur <unbekannt>". */
const cp = require('child_process');
const lauf99 = cp.spawnSync(process.execPath, [path.join(__dirname, 'veta-export-lesen.js'), p10, '--fall', '99'],
  { encoding: 'utf8' });
pruef('"--fall 99" endet mit Exitcode 2 und druckt weder Geraete-ID noch Fallzeiten',
  lauf99.status === 2 && !/Geraete-ID/.test(lauf99.stdout) && !/MAC-Adresse/.test(lauf99.stdout) &&
  /Diesen Fall gibt es nicht/.test(lauf99.stderr),
  'Exitcode ' + lauf99.status + ', stdout ' + lauf99.stdout.length + ' Zeichen');
const lauf1 = cp.spawnSync(process.execPath, [path.join(__dirname, 'veta-export-lesen.js'), p10, '--fall', '1'],
  { encoding: 'utf8' });
pruef('ein gueltiger Aufruf endet weiterhin mit Exitcode 0 und druckt den Bericht',
  lauf1.status === 0 && /MAC-Adresse/.test(lauf1.stdout), 'Exitcode ' + lauf1.status);

block('A12. B5: eine Versionsnummer der Form 6.5.0.0 ist keine Netzadresse');

/*
 * Der Kopf des Lesers behauptete, die fuehrende Null trenne Version und Adresse. Das ist
 * falsch: "6.5.0.0" (CO2-Modul im echten Export) hat keine fuehrende Null. Die 0 Fehltreffer
 * kamen daher, dass nur T_Data4 durchsucht wurde. Beides wird hier gemessen.
 */
pruef('die Regel ALLEIN haelt "6.5.0.0" fuer eine Adresse - das ist der Anlass',
  M.netzadressen([{ was: 'CO2-Modul', details: '6.5.0.0' }]).length === 1);
pruef('mit der Versionstabelle als Ausschluss ist sie es nicht mehr',
  M.netzadressen([{ was: 'CO2-Modul', details: '6.5.0.0' }], { '6.5.0.0': true }).length === 0);
pruef('eine Version mit fuehrender Null war und bleibt keine Adresse',
  M.netzadressen([{ was: 'Bundle-Version: 01.09.00.01 -> 01.10.00.01', details: '01.10.00.01 2025-05-16' }]).length === 0);

const A12 = baueExport({
  zeiten: ['2026-01-02<br>1:02 PM ', '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '],
  spalten: spaltenFuer(3),
  t2: ['ITEM', 'Version', 'Datum', 'Bundle-Version', '01.10.00.01', '---', 'CO2-Modul', '6.5.0.0', '---'],
  /* Eine ECHTE Adresse in einer anderen Tabelle - vorher sah der Melder dort gar nicht hin. */
  mehrTabellen: [['T_Data5', ['ITEM', 'Wert', 'Servicezugang', '10.0.0.7']]],
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:02 PM <br>']
  ]
});
const a12 = M.exportLesen(schreibe(temp, 'a12.html', A12), 1);
const b12txt = M.bericht(a12, 1);
pruef('die Versionstabelle wird gelesen und "6.5.0.0" als Version ausgenommen',
  a12.versionsBloecke.indexOf('6.5.0.0') >= 0, JSON.stringify(a12.versionsBloecke));
pruef('der Melder laeuft ueber ALLE Tabellen und findet die Adresse in T_Data5',
  a12.netzadressenSonst.some(function (n) { return n.tabelle === 'T_Data5' && n.adressen.indexOf('10.0.0.7') >= 0; }),
  JSON.stringify(a12.netzadressenSonst));
pruef('und meldet die Versionsnummer NICHT als Adresse',
  !a12.netzadressenSonst.some(function (n) { return n.adressen.indexOf('6.5.0.0') >= 0; }) &&
  /10\.0\.0\.7/.test(b12txt) && !/T_Data2 Feld \d+\s+6\.5\.0\.0/.test(b12txt),
  JSON.stringify(a12.netzadressenSonst));

block('A13. B7: faellt CreateTable weg, sagt der Bericht, dass nur EIN Weg ging');

const A13 = baueExport({
  zeiten: ['2026-01-02<br>1:02 PM ', '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '],
  spalten: spaltenFuer(3),
  ohneCreateTable: true,
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:02 PM <br>']
  ]
});
const a13 = M.exportLesen(schreibe(temp, 'a13.html', A13), 1);
const b13txt = M.bericht(a13, 1);
pruef('ohne den Aufruf bleibt die Breite richtig, aber der zweite Weg fehlt',
  a13.trend.breite === 4 && a13.trend.breiteAusAufruf === null && a13.trend.breiteAusFeld === 4,
  JSON.stringify([a13.trend.breite, a13.trend.breiteAusAufruf, a13.trend.breiteAusFeld]));
pruef('der Bericht nimmt die Zusage "zwei Wege" ausdruecklich zurueck',
  /NUR EIN WEG/.test(b13txt) && /NICHT gefahren/.test(b13txt));
pruef('mit dem Aufruf steht dort weiterhin, dass beide Wege stimmen',
  /beide Wege stimmen/.test(M.bericht(a8, 1)));
pruef('auch die JSON sagt, wieviele Wege die Breite tragen',
  M.fuerJson(a13).spaltenbreite.wege === 1 && M.fuerJson(a8).spaltenbreite.wege === 2);

block('A14. B8: Uhrzeiten in den Tabellen bekommen den Tag, wenn ein Fall ihn ueberschreitet');

const A14 = baueExport({
  zeiten: [
    '2026-01-03<br>12:01 AM ', '2026-01-03<br>12:00 AM ',
    '2026-01-02<br>11:59 PM ', '2026-01-02<br>11:58 PM '
  ],
  spalten: spaltenFuer(4),
  protokoll: [
    ['2026-01-03 12:01:30 AM', 'Fall beenden', 'Start <br>2026-01-02 11:58 PM <br>Ende <br>2026-01-03 12:01 AM <br>'],
    ['2026-01-02 11:58:10 PM', 'Mitten in der Nacht', 'Modus VS<br>']
  ]
});
const a14 = M.exportLesen(schreibe(temp, 'a14.html', A14), 1);
const b14txt = M.bericht(a14, 1);
pruef('ein Fall ueber Mitternacht: die Minutenwerte tragen den Tag',
  /02\.01\. 23:58/.test(b14txt) && /03\.01\. 00:01/.test(b14txt),
  b14txt.slice(b14txt.indexOf('MINUTENWERTE'), b14txt.indexOf('MINUTENWERTE') + 260));
pruef('auch die Ereignisse tragen ihn',
  /02\.01\. 23:58:10  Mitten in der Nacht/.test(b14txt));
/* Der Tag darf nicht IMMER dastehen - 240 Zeilen mit Datum liest niemand mehr. */
pruef('bleibt ein Fall an einem Tag, steht das Datum einmal in der Ueberschrift',
  /MINUTENWERTE  \(alle am 02\.01\.2026\)/.test(M.bericht(a8, 1)) &&
  /EREIGNISSE IN DIESEM FALL \(\d+\)  \(alle am /.test(M.bericht(a8, 1)));

block('A15. B9: zwei gleiche Fall-Eintraege sind ein Fall, und Dauer 0 wird benannt');

const A15 = baueExport({
  zeiten: ['2026-01-02<br>1:02 PM ', '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '],
  spalten: spaltenFuer(3),
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:02 PM <br>'],
    ['2026-01-02 1:02:31 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:02 PM <br>']
  ]
});
const a15 = M.exportLesen(schreibe(temp, 'a15.html', A15), 1);
const b15txt = M.bericht(a15, 1);
pruef('der doppelte Eintrag erzeugt keinen zweiten Fall',
  a15.faelle.length === 1 && a15.doppelte === 1 && a15.doppelteImFenster === 1,
  a15.faelle.length + ' Faelle, doppelte=' + a15.doppelte);
pruef('und der Bericht sagt, dass zusammengefasst wurde',
  /doppelte Fall-Eintraege des Protokolls zusammengefasst/.test(b15txt));

/* Dauer 0 ist KEIN Doppeleintrag, sondern ein Geraetartefakt - und muss anders behandelt
 * werden: nicht weglassen (sonst verschieben sich alle Fallnummern), aber benennen. */
/* Nachgebaut ist die Form des echten Exports: der Null-Minuten-Fall LIEGT IN einem laengeren
 * (dort 25.08.2026 09:02-09:02 in 09:02-09:57). Die Grenzminute traegt eine Protokollzeile -
 * sie ist der Anlass fuer A16 gleich darunter. */
const A15b = baueExport({
  zeiten: ['2026-01-02<br>1:02 PM ', '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '],
  spalten: spaltenFuer(3),
  protokoll: [
    ['2026-01-02 1:02:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:02 PM <br>'],
    ['2026-01-02 1:02:31 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:00 PM <br>'],
    ['2026-01-02 1:00:05 PM', 'Grenzminute', 'Modus VS<br>']
  ]
});
const a15b = M.exportLesen(schreibe(temp, 'a15b.html', A15b), 1);
const b15btxt = M.bericht(a15b, 1);
const leerFall = a15b.faelle.filter(function (f) { return f.punkte.length === 0; });
pruef('ein Fall der Dauer 0 bleibt in der Liste (die Nummern duerfen sich nicht verschieben)',
  a15b.faelle.length === 2 && leerFall.length === 1,
  JSON.stringify(a15b.faelle.map(function (f) { return [f.dauerMin, f.punkte.length]; })));
pruef('er wird als "keine Messminute" benannt statt als Narkose mitgezaehlt',
  /ohne eine einzige Messminute/.test(b15btxt) && /\(keine Messminute\)/.test(b15btxt) &&
  M.fuerJson(a15b).faelle.filter(function (f) { return f.ohneMessminute; }).length === 1);

block('A16. B10: eine Protokollzeile gehoert zu genau EINEM Fall');

/* Der Grenzfall des echten Exports, klein nachgebaut: ein Fall der Laenge 0 liegt in einem
 * laengeren. Alte Fassung: die Zeile 13:02 erschien in BEIDEN Fallberichten. */
const a16 = a15b;
const zugeordnet = {};
let mehrfach = 0;
a16.faelle.forEach(function (f) {
  f.ereignisse.forEach(function (e) {
    const k = e.zeit + '|' + e.was;
    if (zugeordnet[k]) mehrfach++;
    zugeordnet[k] = true;
  });
});
pruef('keine Protokollzeile steht in zwei Faellen',
  mehrfach === 0, mehrfach + ' Zeilen doppelt zugeordnet');
/* Die Minute 13:00 faellt in BEIDE Faelle. Ohne Zuordnung stuende ihre Zeile zweimal da -
 * genau die 16 Zeilen, die die Gegenpruefung am echten Export gefunden hat. */
pruef('die Zeile der ueberlappenden Minute geht an genau einen Fall - und zwar an den laengeren',
  a16.faelle[0].ereignisse.length + a16.faelle[1].ereignisse.length === 3 &&
  a16.faelle.filter(function (f) { return f.dauerMin === 0; })[0].ereignisse.length === 0 &&
  a16.faelle.filter(function (f) { return f.dauerMin > 0; })[0].ereignisse
    .some(function (e) { return e.was === 'Grenzminute'; }),
  JSON.stringify(a16.faelle.map(function (f) { return [f.dauerMin, f.ereignisse.length]; })));

block('A17. B11: Luecken werden gemessen, nicht aus "Dauer == Messminuten" geschlossen');

/*
 * Der Anlass, den die alte Plausibilitaetsprobe nicht sehen konnte: dieser Fall hat eine
 * echte Luecke (13:02 fehlt) UND es gilt trotzdem Dauer == Messminuten, weil die Startminute
 * hier eine Trendzeile traegt. Genau daran wuerde die Gleichheit vorbeigehen.
 */
const A17 = baueExport({
  zeiten: [
    '2026-01-02<br>1:04 PM ', '2026-01-02<br>1:03 PM ',
    '2026-01-02<br>1:01 PM ', '2026-01-02<br>1:00 PM '
  ],
  spalten: spaltenFuer(4),
  protokoll: [
    ['2026-01-02 1:04:30 PM', 'Fall beenden', 'Start <br>2026-01-02 1:00 PM <br>Ende <br>2026-01-02 1:04 PM <br>']
  ]
});
const a17 = M.exportLesen(schreibe(temp, 'a17.html', A17), 1);
const b17txt = M.bericht(a17, 1);
pruef('die Falle ist wirklich gestellt: Dauer und Messminuten sind gleich, obwohl eine Minute fehlt',
  a17.fall.dauerMin === 4 && a17.fall.punkte.length === 4,
  a17.fall.dauerMin + ' min / ' + a17.fall.punkte.length + ' Messminuten');
pruef('die Luecke wird trotzdem gefunden und im Bericht genannt',
  a17.fall.luecken.length === 1 && a17.fall.luecken[0].minuten === 1 &&
  /! Luecken/.test(b17txt), JSON.stringify(a17.fall.luecken));
pruef('ohne Luecke steht ausdruecklich "keine" - nicht gar nichts',
  a8.fall.luecken.length === 0 && /Luecken \.+ keine/.test(M.bericht(a8, 1)));
pruef('die Luecke steht auch in der JSON',
  M.fuerJson(a17).faelle[0].luecken.length === 1);

block('A18. B12: der Riegel gegen falsch umkodierte Dateien kennt mehr als zwei Zeichen');

/* Jede dieser Folgen entsteht, wenn UTF-8 als latin1 gelesen und wieder als UTF-8
 * gespeichert wird. Der o-Umlaut kommt im echten Protokoll vor ("Verzoegerung"), die
 * deutschen Anfuehrungszeichen je 197-mal - beide fehlten im alten Riegel. */
/*
 * ERZEUGT, NICHT ABGESCHRIEBEN. Die Muster werden hier aus dem RICHTIGEN Zeichen gerechnet:
 * UTF-8 kodieren, die Bytes als CP1252 lesen. Ein von Hand hingeschriebenes "\u00c3\u00a4" haette
 * denselben Fehler wie die alte Fassung - man prueft dann die Zeichen, an die man gedacht
 * hat. So kommen die sechs Muster aus den sechs Zeichen selbst.
 */
const CP1252 = {                                  /* nur die Stellen, an denen CP1252 von latin1 abweicht */
  0x80: 0x20AC, 0x82: 0x201A, 0x83: 0x0192, 0x84: 0x201E, 0x85: 0x2026, 0x86: 0x2020,
  0x87: 0x2021, 0x88: 0x02C6, 0x89: 0x2030, 0x8A: 0x0160, 0x8B: 0x2039, 0x8C: 0x0152,
  0x8E: 0x017D, 0x91: 0x2018, 0x92: 0x2019, 0x93: 0x201C, 0x94: 0x201D, 0x95: 0x2022,
  0x96: 0x2013, 0x97: 0x2014, 0x98: 0x02DC, 0x99: 0x2122, 0x9A: 0x0161, 0x9B: 0x203A,
  0x9C: 0x0153, 0x9E: 0x017E, 0x9F: 0x0178
};
function alsCp1252Gelesen(zeichen) {
  const bytes = Buffer.from(zeichen, 'utf8');
  let out = '';
  for (let i = 0; i < bytes.length; i++) out += String.fromCharCode(CP1252[bytes[i]] || bytes[i]);
  return out;
}
const MOJI = [
  ['a-Umlaut', alsCp1252Gelesen('\u00e4')],
  ['u-Umlaut', alsCp1252Gelesen('\u00fc')],
  ['o-Umlaut', alsCp1252Gelesen('\u00f6')],
  ['sz', alsCp1252Gelesen('\u00df')],
  ['grosses Ae', alsCp1252Gelesen('\u00c4')],
  ['grosses Ue', alsCp1252Gelesen('\u00dc')],
  ['oeffnendes deutsches Anfuehrungszeichen', alsCp1252Gelesen('\u201e')],
  ['schliessendes deutsches Anfuehrungszeichen', alsCp1252Gelesen('\u201c')]
];
const mojiFehler = [];
MOJI.forEach(function (mj) {
  const H = baueExport({
    zeiten: ['2026-01-02<br>1:00 PM '],
    spalten: spaltenFuer(1),
    protokoll: [['2026-01-02 1:00:10 PM', 'Test ' + mj[1] + ' Text', 'Modus VS<br>']]
  });
  const m = wirftFehler(function () { M.exportLesen(schreibe(temp, 'moji.html', H), 1); });
  if (!(m && /umkodiert/.test(m))) mojiFehler.push(mj[0] + ' -> ' + String(m));
});
pruef('alle ' + MOJI.length + ' Umkodierungsmuster werden abgewiesen',
  mojiFehler.length === 0, mojiFehler.join(' ; '));
/* Ohne diese Zeile koennte alsCp1252Gelesen() Unsinn liefern und der Block trotzdem gruen
 * sein - er wuerde dann nur beweisen, dass irgendein Zeichen abgewiesen wird. */
pruef('die Muster sind wirklich die erwarteten Folgen (Gegenprobe am Rechenweg)',
  MOJI[0][1] === '\u00c3\u00a4' && MOJI[2][1] === '\u00c3\u00b6' &&
  MOJI[6][1] === '\u00e2\u20ac\u017e',
  JSON.stringify(MOJI.map(function (m) { return m[1]; })));
/* Und die Gegenprobe: eine SAUBERE Datei mit denselben Umlauten darf nicht abgewiesen
 * werden - sonst waere der Riegel nur streng, nicht richtig. */
const A18ok = baueExport({
  zeiten: ['2026-01-02<br>1:00 PM '],
  spalten: spaltenFuer(1),
  /* Genau die Zeichen, die im echten Export vorkommen: o-Umlaut (1x), a-Umlaut, sz und die
   * deutschen Anfuehrungszeichen (je 197x). Das ASCII-Anfuehrungszeichen waere hier falsch -
   * es beendet das Feld im gebauten HTML. */
  protokoll: [['2026-01-02 1:00:10 PM',
    'Verz\u00f6gerung, Gebl\u00e4se, gro\u00df, \u201eAnf\u00fchrung\u201c', 'Modus VS<br>']]
});
const m18 = wirftFehler(function () { M.exportLesen(schreibe(temp, 'a18ok.html', A18ok), 1); });
pruef('richtig kodierte Umlaute und Anfuehrungszeichen gehen weiterhin durch',
  m18 === null, String(m18));

/* =====================================================================================
 * A19. Ein gekennzeichnetes CO2 verschwindet nicht mehr lautlos
 *
 * WARUM DAS EIN EIGENER ABSCHNITT IST, obwohl im echten Export kein einziger solcher Wert
 * vorkommt: der Dauerauftrag lautet, dass CO2 vom Veta Vorrang hat, WEIL es durch den
 * Schlauch gemessen ist. Die dokumentierte Kopplung Veta<->Monitor laeuft aber andersherum -
 * der Monitor liefert EtCO2 AN die Veta. Sobald gekoppelt wird, koennte im Export ein Wert
 * stehen, der in Wahrheit der Monitorwert ist. Ihm den Vorrang zu geben hiesse, denselben
 * Wert fuer eine zweite, bessere Messung zu halten.
 *
 * Bis heute fiel so ein Wert durch zahl() lautlos auf null - der Messwert war weg, und der
 * Grund stand nirgends. Das ist die Fehlerklasse "faellt still aus", nur an einer Stelle,
 * die klinisch zaehlt.
 *
 * Geprueft wird BEIDES: dass die Kennzeichnung erkannt wird UND dass ein gewoehnlicher Wert
 * sie nicht bekommt. Ohne die zweite Haelfte waere auch ein Leser gruen, der immer "fremd"
 * meldet - und der waere ebenso wertlos.
 * =================================================================================== */
block('A19. Ein gekennzeichnetes CO2 behaelt seine Zahl und traegt seine Herkunft');

const A19 = baueExport({
  zeiten: [
    '2026-01-02<br>1:02 PM ',
    '2026-01-02<br>1:01 PM ',
    '2026-01-02<br>1:00 PM '
  ],
  spalten: [
    /* Zeile 1 gewoehnlich, Zeile 2 mit dem in der Fremdrecherche genannten "+",
     * Zeile 3 mit einem ANDEREN Zeichen - der Leser darf sich nicht auf "+" versteifen. */
    ['Fi/Et CO2(mmHg)', ['1/40', '2/41+', '3/42*']],
    ['MAX(cmH2O)', ['10', '11', '12']],
    ['PEEP(cmH2O)', ['3', '4', '5']],
    ['Vt(ml)', ['100', '110', '120']],
    ['MV(l/min)', ['1.5', '1.6', '1.7']],
    ['AF(BPM)', ['12', '13', '14']]
  ],
  protokoll: [['2026-01-02 12:59:10 PM', 'Fall starten', 'Start <br>2026-01-02 12:59 PM <br>Ende <br>-------- --:-- <br>']]
});
const a19 = M.exportLesen(schreibe(temp, 'a19.html', A19), 1);
/* Der Export steht NEUESTE ZUERST, der Leser dreht auf chronologisch. Die Spaltenzeile 0
 * ("1/40") ist also die SPAETESTE Minute und landet hinten. Im ersten Entwurf hatte ich die
 * Reihenfolge andersherum angenommen und alle sechs Pruefungen rot bekommen - der Test war
 * falsch, nicht der Leser. Deshalb stehen die Minuten hier beim Namen und nicht als Index. */
const p19 = a19.trend.punkte;
const um1300 = p19[0], um1301 = p19[1], um1302 = p19[2];

pruef('die drei Minuten stehen chronologisch (sonst prueft alles Weitere die falsche Zeile)',
  p19.length === 3 && um1300.zeit === '2026-01-02T13:00:00' && um1302.zeit === '2026-01-02T13:02:00',
  JSON.stringify(p19.map(function (p) { return p.zeit; })));
pruef('der gekennzeichnete Wert behaelt seine Zahl (frueher fiel er auf null)',
  um1300.etco2 === 42 && um1301.etco2 === 41,
  JSON.stringify(p19.map(function (p) { return p.etco2; })));
pruef('… und auch der Fi-Anteil davor bleibt erhalten',
  um1300.fico2 === 3 && um1301.fico2 === 2,
  JSON.stringify(p19.map(function (p) { return p.fico2; })));
pruef('beide gekennzeichneten Minuten sind als fremd markiert',
  um1300.co2Fremd === true && um1301.co2Fremd === true);
pruef('das Zeichen wird mitgefuehrt, nicht gedeutet',
  um1301.co2Kennzeichen === '+' && um1300.co2Kennzeichen === '*',
  um1301.co2Kennzeichen + ' / ' + um1300.co2Kennzeichen);
pruef('GEGENPROBE: der gewoehnliche Wert traegt KEINE Herkunftskennzeichnung',
  um1302.etco2 === 40 && um1302.fico2 === 1 &&
  um1302.co2Fremd === undefined && um1302.co2Kennzeichen === undefined,
  JSON.stringify(um1302));
/* Und die Einzelteile fuer sich, damit ein Fehler nicht erst ueber den ganzen Leser sichtbar wird. */
pruef('markierung() trennt Zahl und Zeichen, auch bei negativen Werten',
  M.markierung('42+').rein === '42' && M.markierung('42+').zeichen === '+' &&
  M.markierung('-3').zeichen === null && M.markierung('---').zeichen === null,
  JSON.stringify([M.markierung('42+'), M.markierung('-3'), M.markierung('---')]));
pruef('"---/---" bleibt eine fehlende Messung und wird NICHT fremd',
  (function () { const c = M.co2Paar('---/---'); return c.etco2 === null && c.fremd === false; })());

/* =====================================================================================
 * ABSCHNITT B - der ECHTE Export
 * =================================================================================== */
block('B. Der echte Export vom 29.08.2026');

let echt = null;
if (!ECHT) {
  console.log('  UEBERSPRUNGEN: es liegt kein Beispielexport da.');
  console.log('     Gesucht wurde: $VETA_EXPORT, sonst ein Ordner "veta-export*" neben dem Baum.');
  console.log('     Er gehoert nicht ins Repo (2,4 MB Betriebsdaten einer Praxis) und ist');
  console.log('     deshalb auf keinem anderen Rechner da. Abschnitt A hat trotzdem gemessen.');
  uebersprungen = 1;
} else {
  echt = M.exportLesen(ECHT, 1);
  /* FINGERABDRUCK OHNE KENNUNG (29.08.2026 umgestellt).
   * Hier wurde gegen die Geraete-ID des Praxisgeraetes verglichen - ein fester Wert im
   * Quelltext, der mit tools/ in jedes oeffentliche Update-Zip gefahren ist. Er beantwortet
   * die Frage auch nicht besser als der Zuschnitt des Exports: 2880 Zeitpunkte schreibt das
   * Geraet immer, und der Tag der letzten Messminute sagt, welcher Auszug hier liegt. Passt
   * das nicht, sind die Zahlen unten an einem ANDEREN Export gemessen - dann wird
   * uebersprungen statt falsch rot oder falsch gruen gemeldet.
   * Dass der Leser die Geraete-ID richtig ausliest, misst B3 - gegen die Datei selbst. */
  const letzterTag = echt.trend.punkte.length
    ? echt.trend.punkte[echt.trend.punkte.length - 1].zeit.slice(0, 10) : '';
  if (echt.trend.zeilen !== 2880 || letzterTag !== '2026-08-29') {
    console.log('  UEBERSPRUNGEN: unter dem gefundenen Pfad liegt ein ANDERER Export');
    console.log('     erwartet 2880 Zeitpunkte bis zum 29.08.2026, gefunden ' +
      echt.trend.zeilen + ' bis ' + (letzterTag || '?'));
    console.log('     Die Zahlen in diesem Abschnitt sind an jenem einen Export gemessen');
    console.log('     und waeren fuer einen anderen kein Beleg.');
    uebersprungen = 1;
    echt = null;
  }
}

if (echt) {
  /* --------------------------------------------------------------------------------
   * B1. Aufbau
   * ------------------------------------------------------------------------------ */
  console.log('');
  pruef('2880 Zeitpunkte in der Trendliste',
    echt.trend.zeilen === 2880, 'gefunden: ' + echt.trend.zeilen);
  pruef('genau sechs Wertespalten, in der bekannten Benennung',
    echt.trend.spalten.length === 6 &&
    echt.trend.spalten.join('|') === 'Fi/Et CO2(mmHg)|MAX(cmH2O)|PEEP(cmH2O)|Vt(ml)|MV(l/min)|AF(BPM)',
    echt.trend.spalten.join('|'));
  pruef('2819 Messminuten und 61 "End Case"-Marken',
    echt.trend.punkte.length === 2819 && echt.trend.marken.length === 61,
    echt.trend.punkte.length + ' / ' + echt.trend.marken.length);
  pruef('keine einzige Marke traegt Messwerte (sonst gingen sie in der Kurve verloren)',
    echt.trend.marken.every(function (m) { return m.hatWerte === false; }));

  /*
   * WENN DIESE ZEILE EINES TAGES ROT WIRD, IST DAS EIN BEFUND UND KEIN DEFEKT.
   *
   * Rot heisst: in diesem Export steht CO2, das die Veta nicht selbst gemessen, sondern von
   * einem gekoppelten Monitor uebernommen hat. Dann faellt die Begruendung des Vorrangs weg
   * (Schlauchmessung) und die Quellenlogik gehoert nachgesehen, BEVOR der Export ins
   * Protokoll wandert. Deshalb steht hier eine Pruefung und keine blosse Ausgabe: eine Zeile,
   * die nur eine Zahl nennt, liest beim naechsten Mal niemand.
   *
   * Heute gemessen: 0 von 2819 Messminuten. Waehrend dieser Faelle war kein Monitor gekoppelt.
   */
  const fremdeMinuten = echt.trend.punkte.filter(function (p) { return p.co2Fremd; });
  pruef('kein CO2 in diesem Export stammt aus zweiter Hand (0 von ' + echt.trend.punkte.length + ')',
    fremdeMinuten.length === 0,
    fremdeMinuten.length + ' Minuten mit Kennzeichen, z. B. '
      + (fremdeMinuten[0] ? fremdeMinuten[0].zeit + ' "' + fremdeMinuten[0].co2Kennzeichen + '"' : ''));

  /* --------------------------------------------------------------------------------
   * B2. DIE STICHPROBE - unabhaengig am Bildschirm abgelesen, bevor es diesen Leser gab
   * ------------------------------------------------------------------------------ */
  const fall1 = echt.faelle[0];
  function minuteVon(fall, uhr) {
    return fall.punkte.filter(function (p) { return p.zeit.slice(11, 16) === uhr; })[0] || null;
  }
  const m23 = minuteVon(fall1, '00:23');
  const m24 = minuteVon(fall1, '00:24');

  pruef('letzter Fall: 29.08.2026 00:16 bis 00:33',
    fall1.start === M.minuteAus('2026-08-29', '12:16 AM').minute &&
    fall1.ende === M.minuteAus('2026-08-29', '12:33 AM').minute,
    JSON.stringify([fall1.start, fall1.ende]));
  /* Beide Zahlen sind gemessen und stimmen. Sie sind aber KEIN Beleg fuer Lueckenlosigkeit:
   * dass sie gleich sind, ist eine Zufallsgleichheit (siehe B11 weiter unten). */
  pruef('seine Dauer betraegt 17 Minuten und er hat 17 Messminuten',
    fall1.dauerMin === 17 && fall1.punkte.length === 17,
    fall1.dauerMin + ' min / ' + fall1.punkte.length + ' Minuten');
  pruef('STICHPROBE 00:23 - Vt 72, MV 8.0, AF 111',
    m23 != null && m23.vt === 72 && m23.mv === 8.0 && m23.af === 111,
    m23 ? JSON.stringify(m23) : 'die Minute 00:23 fehlt im Fall');
  pruef('STICHPROBE 00:24 - MAX 4, PEEP 3, Vt 13, MV 0.2, AF 8',
    m24 != null && m24.max === 4 && m24.peep === 3 && m24.vt === 13 && m24.mv === 0.2 && m24.af === 8,
    m24 ? JSON.stringify(m24) : 'die Minute 00:24 fehlt im Fall');
  pruef('STICHPROBE 00:33 - dort steht die Marke "End Case"',
    fall1.marke != null && fall1.marke.ereignis === 'End Case' &&
    fall1.marke.zeit === '2026-08-29T00:33:00',
    fall1.marke ? JSON.stringify(fall1.marke) : 'keine Marke am Fall');

  /* --------------------------------------------------------------------------------
   * B3. ZELLE FUER ZELLE GEGEN DIE DARSTELLUNG DER DATEI SELBST
   *
   * Nachgebaut ist die Zeichenroutine aus dem Kopf der HTML:
   *     for (i=0..Zeilen)  for (j=0..Spalten)   Zelle = Feld[i*Spalten + j]
   * Zeile 0 sind die Zeitstempel, Zeile 1..6 die Wertespalten. Die Zelle unter einem
   * Zeitstempel ist also Feld[i*Spalten + j] mit demselben j. Genau diese Zuordnung wird
   * gegen den Leser gehalten - fuer ALLE 2880 Spalten, nicht nur fuer die Stichprobe.
   * ------------------------------------------------------------------------------ */
  const rohText = fs.readFileSync(M.htmlFinden(ECHT), 'utf8');

  /* DIE GERAETE-ID: gemessen wird, dass der Leser sie RICHTIG HOLT - nicht, dass sie einen
   * bestimmten Wert hat (29.08.2026 umgestellt, Befund D der Freigabepruefung 1.27.0).
   * Der Wert ist die Kennung eines Praxisgeraetes und stand vorher fest im Quelltext.
   * Der Vergleichswert kommt jetzt aus der Datei selbst: T_Data0 steht paarweise
   * (Bezeichnung, Wert), die Kennung ist die Zelle NEBEN ihrer Bezeichnung. Ein Leser, der
   * nach Stellung greift statt nach Namen, faellt hier auf - wie in A2 bei den Spalten.
   * Die Meldung bei Fehlschlag nennt Laengen, nicht Werte: eine Testausgabe ist auch eine
   * Ausgabe. */
  const roh0 = M.jsFeld(rohText, 'T_Data0') || [];
  let idAusDatei = null;
  let macAusDatei = null;
  for (let i = 0; i + 1 < roh0.length; i += 2) {
    if (/-ID$|Device ID/.test(roh0[i])) idAusDatei = roh0[i + 1];
    if (/MAC/i.test(roh0[i])) macAusDatei = roh0[i + 1];
  }
  pruef('die Geraete-ID kommt aus der Zelle NEBEN ihrer Bezeichnung, nicht aus einer Stellung',
    idAusDatei != null && echt.geraet.id === idAusDatei,
    'in der Datei ' + (idAusDatei == null ? 'nicht gefunden' : String(idAusDatei).length + ' Zeichen') +
    ', gelesen ' + (echt.geraet.id == null ? 'null' : String(echt.geraet.id).length + ' Zeichen'));
  pruef('sie hat die Form, die das Geraet vergibt (nur Ziffern)',
    /^[0-9]{8,24}$/.test(String(echt.geraet.id)),
    echt.geraet.id == null ? 'null' : String(echt.geraet.id).length + ' Zeichen');
  pruef('dasselbe fuer die MAC-Adresse: Wert aus der Datei, Form geprueft',
    macAusDatei != null && echt.geraet.mac === macAusDatei &&
    /^([0-9A-F]{2}:){5}[0-9A-F]{2}$/i.test(String(echt.geraet.mac)));
  const rohFeld = M.jsFeld(rohText, 'T_Data3');
  const spaltenAnzahl = parseInt(/CreateTable\(\s*"T_Data3"\s*,\s*-?\d+\s*,\s*(\d+)\s*,/.exec(rohText)[1], 10);
  const zeilenAnzahl = rohFeld.length / spaltenAnzahl;
  const tabelle = [];
  for (let i = 0; i < zeilenAnzahl; i++) {
    const zeile = [];
    for (let j = 0; j < spaltenAnzahl; j++) zeile.push(rohFeld[i * spaltenAnzahl + j]);
    tabelle.push(zeile);
  }
  pruef('die nachgebaute Tabelle hat 7 Zeilen zu 2881 Spalten',
    zeilenAnzahl === 7 && spaltenAnzahl === 2881, zeilenAnzahl + ' x ' + spaltenAnzahl);

  /* Zeile der Tabelle -> Feld im Messpunkt */
  const zuordnung = { 'MAX(cmH2O)': 'max', 'PEEP(cmH2O)': 'peep', 'Vt(ml)': 'vt', 'MV(l/min)': 'mv', 'AF(BPM)': 'af' };
  const nachMinute = {};
  echt.trend.punkte.forEach(function (p) { nachMinute[p.minute] = p; });

  let verglichen = 0, abweichungen = [];
  for (let j = 1; j < spaltenAnzahl; j++) {
    const teile = tabelle[0][j].split('<br>');
    if ((teile[2] || '').trim()) continue;                 /* Markenspalte, kein Messpunkt */
    const t = M.minuteAus(teile[0], (teile[1] || '').trim());
    const p = nachMinute[t.minute];
    if (!p) { abweichungen.push('Minute ' + tabelle[0][j] + ' fehlt beim Leser'); continue; }
    for (let i = 1; i < zeilenAnzahl; i++) {
      const name = tabelle[i][0];
      const rohWert = tabelle[i][j];
      if (name === 'Fi/Et CO2(mmHg)') {
        const paar = M.co2Paar(rohWert);
        if (paar.fico2 !== p.fico2 || paar.etco2 !== p.etco2) {
          abweichungen.push(tabelle[0][j] + ' CO2 Zelle "' + rohWert + '" <-> ' + p.fico2 + '/' + p.etco2);
        }
      } else {
        const soll = M.zahl(rohWert);
        const ist = p[zuordnung[name]];
        if (soll !== ist) abweichungen.push(tabelle[0][j] + ' ' + name + ' Zelle "' + rohWert + '" <-> ' + ist);
      }
      verglichen++;
    }
  }
  pruef('alle 2819 x 6 Zellen stimmen mit der Darstellung der Datei ueberein',
    abweichungen.length === 0 && verglichen === 2819 * 6,
    abweichungen.length + ' Abweichungen (verglichen ' + verglichen + '), erste: ' + abweichungen.slice(0, 3).join(' ; '));

  /* --------------------------------------------------------------------------------
   * B4. "---" wird null - und zwar so oft, wie "---" in der Datei steht
   * ------------------------------------------------------------------------------ */
  const strichZaehler = {}, nullZaehler = {};
  Object.keys(zuordnung).forEach(function (n) { strichZaehler[n] = 0; nullZaehler[n] = 0; });
  for (let i = 1; i < zeilenAnzahl; i++) {
    const name = tabelle[i][0];
    if (!zuordnung[name]) continue;
    for (let j = 1; j < spaltenAnzahl; j++) {
      if ((tabelle[0][j].split('<br>')[2] || '').trim()) continue;
      if (tabelle[i][j] === '---') strichZaehler[name]++;
    }
  }
  echt.trend.punkte.forEach(function (p) {
    Object.keys(zuordnung).forEach(function (n) { if (p[zuordnung[n]] === null) nullZaehler[n]++; });
  });
  const strichFehler = Object.keys(zuordnung).filter(function (n) { return strichZaehler[n] !== nullZaehler[n]; });
  pruef('jedes "---" wird genau ein null - und nichts anderes wird null',
    strichFehler.length === 0,
    strichFehler.map(function (n) { return n + ': ' + strichZaehler[n] + ' Striche, ' + nullZaehler[n] + ' null'; }).join(' ; '));
  pruef('es gibt ueberhaupt "---" zu finden (sonst prueft die Zeile darueber nichts)',
    Object.keys(zuordnung).reduce(function (s, n) { return s + strichZaehler[n]; }, 0) > 1000,
    JSON.stringify(strichZaehler));
  const co2Leer = echt.trend.punkte.filter(function (p) { return p.fico2 === null && p.etco2 === null; });
  pruef('das eine "---/---" des Exports wird zu zwei null',
    co2Leer.length === 1, co2Leer.length + ' Minuten ohne CO2-Paar');

  /* --------------------------------------------------------------------------------
   * B5. Minutenabstand - und wo er WIRKLICH gilt
   *
   * Die Aufgabe verlangte "lueckenlos im Minutenabstand". Gemessen gilt das INNERHALB eines
   * Falls; ueber die ganze Liste gilt es nicht, weil das Geraet nur waehrend einer Narkose
   * schreibt. Beides wird hier festgehalten, damit die zweite Haelfte spaeter niemand als
   * Fehler "behebt".
   * ------------------------------------------------------------------------------ */
  let luecken = [];
  echt.faelle.forEach(function (f) {
    const s = f.punkte.map(function (p) { return p.minute; }).sort(function (a, b) { return a - b; });
    for (let k = 1; k < s.length; k++) {
      if (s[k] - s[k - 1] !== 1) luecken.push('Fall ' + f.nr + ': ' + (s[k] - s[k - 1]) + ' Minuten Sprung');
    }
  });
  pruef('innerhalb JEDES Falls liegen die Minuten lueckenlos hintereinander',
    luecken.length === 0, luecken.slice(0, 3).join(' ; '));
  const spanne = echt.trend.bis - echt.trend.von;
  pruef('die 2880 Zeilen sind NICHT 48 Stunden am Stueck (hier 32 Tage) - das ist kein Fehler',
    spanne > 44000 && echt.trend.punkte.length === 2819,
    'Spanne ' + spanne + ' Minuten, Messminuten ' + echt.trend.punkte.length);

  /* --------------------------------------------------------------------------------
   * B6. Faelle
   * ------------------------------------------------------------------------------ */
  pruef('64 Faelle im Trendzeitraum, Zeiten aus dem Ereignisprotokoll',
    echt.faelle.length === 64 && echt.ersatzweise === false,
    echt.faelle.length + ' Faelle, ersatzweise=' + echt.ersatzweise);
  pruef('jede Messminute gehoert zu genau einem Fall (keine Waisen)',
    echt.ohneFall.length === 0, echt.ohneFall.length + ' Minuten ohne Fall');
  const summe = echt.faelle.reduce(function (s, f) { return s + f.punkte.length; }, 0);
  pruef('die Fallminuten zusammen ergeben wieder alle Messminuten',
    summe === echt.trend.punkte.length, summe + ' statt ' + echt.trend.punkte.length);
  pruef('die Faelle stehen neueste zuerst und ueberlappen sich in der Zuordnung nicht',
    echt.faelle.every(function (f, i) { return i === 0 || echt.faelle[i - 1].ende >= f.ende; }));
  const ohneMarke = echt.faelle.filter(function (f) { return f.marke == null; }).length;
  pruef('drei Faelle haben KEINE End-Case-Marke - deshalb kommen die Zeiten aus dem Protokoll',
    ohneMarke === 3, ohneMarke + ' Faelle ohne Marke');
  pruef('die Ereignisse des letzten Falls enthalten "Fall starten" und "Fall beenden"',
    echt.ereignisse.some(function (e) { return e.was === 'Fall starten'; }) &&
    echt.ereignisse.some(function (e) { return e.was === 'Fall beenden'; }) &&
    echt.ereignisse.length === 19,
    echt.ereignisse.length + ' Ereignisse');
  pruef('das Ereignisprotokoll hat 13270 Zeilen',
    echt.protokollZeilen === 13270, String(echt.protokollZeilen));

  /* --------------------------------------------------------------------------------
   * B7. DATENSCHUTZ - die Zusagen des Dateikopfes nachgemessen
   * ------------------------------------------------------------------------------ */
  /*
   * WORTGRENZEN, nicht Teilzeichenketten. Ohne \b meldet diese Zeile einen Treffer, denn im
   * Export steht "Elektron. Waagenschalter" - darin steckt "halter". Genau so entsteht eine
   * Datenschutzmeldung, die niemand mehr ernst nimmt.
   */
  const NAMENSFELD = /\b(Patient|Patientin|Besitzer|Halter|Tiername|Nachname|Vorname|Familienname)\b/i;
  pruef('der Export nennt kein Feld "Patient", "Tiername", "Besitzer" oder "Halter"',
    !NAMENSFELD.test(rohText),
    'im Klartext der Datei gefunden: ' + String((rohText.match(NAMENSFELD) || [])[0]));
  /* Diese Suche muss auch etwas finden koennen - sonst ist ihr Gruen wertlos. */
  pruef('dieselbe Suche schlaegt an, wenn ein Namensfeld da WAERE (Gegenprobe)',
    NAMENSFELD.test('var T_Data0 = ["Patient","Bello","Besitzer","Meier",];') &&
    NAMENSFELD.test('Tiername: Minka') &&
    !NAMENSFELD.test('Elektron. Waagenschalter'));
  pruef('genau 4 Ereigniszeilen tragen eine Netzadresse der Praxis',
    echt.netzadressen.length === 4,
    echt.netzadressen.length + ': ' + echt.netzadressen.map(function (n) { return n.was; }).join(' ; '));
  /* Die SW-Versionen haben dieselbe Form wie eine IP ("01.10.00.01"). Erkennte der Melder sie
   * als Adresse, waere seine Zahl wertlos - und die Ausgabe voller Fehlalarme. */
  const versionsZeilen = M.netzadressen([{ was: 'Bundle-Version: 01.09.00.01 -> 01.10.00.01', details: '' },
  { was: 'Hostsoftware', details: '01.10.00.01 2025-05-16' }]);
  pruef('eine Versionsnummer wird NICHT fuer eine Netzadresse gehalten',
    versionsZeilen.length === 0, versionsZeilen.length + ' Fehlalarme');
  const b = M.bericht(echt, 1);
  /* GEMESSEN STATT ABGESCHRIEBEN (29.08.2026 umgestellt, Befund D der Freigabepruefung).
   * Hier standen eine IP des Praxisnetzes und die MAC des Praxisgeraetes als feste
   * Zeichenketten. Beides ist die Identitaet einer bestimmten Praxis, und tools/ faehrt
   * vollstaendig im oeffentlichen Update-Zip mit. Geprueft wird dieselbe Aussage gegen die
   * WERTE DIESES EXPORTS - und damit sogar schaerfer: vorher genuegte EINE der vier Zeilen,
   * jetzt muss jede gemessene Adresse auch im Bericht stehen. */
  const gemesseneAdressen = echt.netzadressen.reduce(function (a, n) { return a.concat(n.adressen); }, []);
  pruef('der Bericht traegt einen Datenschutz-Abschnitt, der die 4 Zeilen auffuehrt',
    /DATENSCHUTZ - AM GELESENEN EXPORT GEMESSEN/.test(b) &&
    /4 Zeile\(n\) des Ereignisprotokolls tragen eine NETZADRESSE/.test(b) &&
    gemesseneAdressen.length > 0 &&
    gemesseneAdressen.every(function (a) { return b.indexOf(a) >= 0; }),
    gemesseneAdressen.length + ' gemessene Adressen, davon im Bericht ' +
    gemesseneAdressen.filter(function (a) { return b.indexOf(a) >= 0; }).length);
  pruef('der Bericht nennt Geraet, Fall und die Minutenwerte der Stichprobe',
    echt.geraet.mac != null && b.indexOf(echt.geraet.mac) >= 0 &&
    /29\.08\.2026 00:16/.test(b) && /00:24/.test(b));

  /* --------------------------------------------------------------------------------
   * B8. DIE ZWOELF BEFUNDE DER GEGENPRUEFUNG - am ECHTEN Export nachgemessen
   *
   * Abschnitt A stellt jeden Anlass an einem gebauten Export nach. Hier steht, was der echte
   * Export dazu sagt: die Zahlen, mit denen die Gegenpruefung die Befunde belegt hat.
   * ------------------------------------------------------------------------------ */
  pruef('B1: die Namenssuche laeuft ueber ALLE Tabellen und findet dort nichts',
    echt.namen.felder === 60416 && echt.tabellenAnzahl === 11 && echt.namen.treffer === 0,
    echt.namen.felder + ' Felder, ' + echt.tabellenAnzahl + ' Tabellen, ' + echt.namen.treffer + ' Treffer');
  /* Beide alten Zusagen duerfen nicht zurueckkehren: weder die erste ("das Geraet fuehrt
   * kein Namensfeld", ohne zu suchen) noch die zweite ("ihr entgeht nur ein Name OHNE
   * Merkmal", was gemessen falsch war). Statt eines Wortlauts wird die Aussage geprueft -
   * Begruendung bei der gleichnamigen Pruefung in Abschnitt A7. */
  pruef('B1: der Bericht des echten Exports enthaelt keine der beiden alten Zusagen mehr',
    !/fuehrt KEIN Namensfeld/.test(b) &&
    !/blosser Name OHNE Merkmal - "Minka" allein/.test(b) &&
    /GESUCHT WURDE NACH/.test(b) && /KEINE ZUSAGE/i.test(b) &&
    /heisst NICHT, dass kein Name/i.test(b));
  pruef('B5: "6.5.0.0" steht in der Versionstabelle und wird deshalb nicht als Adresse gemeldet',
    echt.versionsBloecke.join() === '6.5.0.0' &&
    !echt.netzadressenSonst.some(function (n) { return n.adressen.indexOf('6.5.0.0') >= 0; }),
    JSON.stringify(echt.versionsBloecke) + ' / ' + JSON.stringify(echt.netzadressenSonst));
  pruef('B5: ausserhalb des Protokolls steht genau eine Adresse - die MAC des Geraetes selbst',
    echt.netzadressenSonst.length === 1 && echt.netzadressenSonst[0].tabelle === 'T_Data0' &&
    echt.netzadressenSonst[0].adressen[0] === echt.geraet.mac,
    JSON.stringify(echt.netzadressenSonst));
  /* Ohne diese Gegenprobe waere die Zeile darueber wertlos: sie wuerde auch dann gruen sein,
   * wenn der Melder in den uebrigen Tabellen ueberhaupt nicht suchte. */
  pruef('B5: ohne den Ausschluss WAERE die Version ein Fehlalarm (der Anlass ist echt)',
    M.netzfundeInTabellen(echt.tabellen, {}).some(function (n) {
      return n.tabelle === 'T_Data2' && n.adressen.indexOf('6.5.0.0') >= 0;
    }));
  pruef('B7: beim echten Export tragen beide Wege die Spaltenbreite',
    echt.trend.breiteAusAufruf === 2881 && echt.trend.breiteAusFeld === 2881 &&
    /beide Wege stimmen/.test(b));
  pruef('B9: genau ein Fall im Trendzeitraum hat keine Messminute (25.08.2026 09:02)',
    echt.faelle.filter(function (f) { return f.punkte.length === 0; }).length === 1 &&
    /ohne eine einzige Messminute/.test(b),
    JSON.stringify(echt.faelle.filter(function (f) { return f.punkte.length === 0; })
      .map(function (f) { return [f.nr, f.dauerMin]; })));
  pruef('B9: der eine doppelte Fall-Eintrag des Protokolls wurde zusammengefasst',
    echt.doppelte === 1 && echt.doppelteImFenster === 0,
    'doppelte=' + echt.doppelte + ', davon im Fenster ' + echt.doppelteImFenster);
  /* Vorher waren es 16 - Grenzminuten und der ueberlappende 09:02-Fall. */
  let doppeltZugeordnet = 0;
  const gesehenZeile = {};
  echt.faelle.forEach(function (f) {
    f.ereignisse.forEach(function (e) {
      const k = e.zeit + '|' + e.was + '|' + e.details;
      if (gesehenZeile[k]) doppeltZugeordnet++;
      gesehenZeile[k] = true;
    });
  });
  pruef('B10: keine der 13270 Protokollzeilen steht in mehr als einem Fall',
    doppeltZugeordnet === 0, doppeltZugeordnet + ' Zeilen doppelt zugeordnet');
  /*
   * B11: die Zufallsgleichheit steht hier NICHT als Probe, sondern als das, was sie ist -
   * eine Beobachtung. 61 von 64 Faellen erfuellen sie, drei nicht, und Fall 46 hat MEHR
   * Messminuten als Dauer. Wer sie als "lueckenlos"-Beleg liest, liegt falsch: gemessen wird
   * die Lueckenlosigkeit ueber die Minutenabstaende (Abschnitt B5 oben und f.luecken).
   */
  const gleich = echt.faelle.filter(function (f) { return f.dauerMin === f.punkte.length; }).length;
  pruef('B11: "Dauer == Messminuten" gilt nur in 61 von 64 Faellen - es ist keine Probe',
    gleich === 61, gleich + ' von ' + echt.faelle.length);
  pruef('B11: die direkt gemessenen Luecken sind der Beleg - hier hat kein Fall eine',
    echt.faelle.every(function (f) { return f.luecken.length === 0; }),
    JSON.stringify(echt.faelle.filter(function (f) { return f.luecken.length; })
      .map(function (f) { return [f.nr, f.luecken]; }).slice(0, 3)));
  pruef('B8: Fall 2 laeuft ueber Mitternacht - seine Minutenwerte tragen deshalb den Tag',
    /28\.08\. 23:5\d/.test(M.bericht(M.exportLesen(ECHT, 2), 2)));

  /* Kein Blick in die Logdateien des Herstellers - die sind nicht durchsucht worden. */
  const echteLeseAufrufe = [];
  const originalLesen = fs.readFileSync;
  fs.readFileSync = function (p) { echteLeseAufrufe.push(String(p)); return originalLesen.apply(fs, arguments); };
  try { M.exportLesen(ECHT, 1); } finally { fs.readFileSync = originalLesen; }
  const fremde = echteLeseAufrufe.filter(function (p) { return !/\.html?$/i.test(p); });
  pruef('beim Lesen wird KEINE der .log-Dateien neben der HTML geoeffnet',
    fremde.length === 0, fremde.join(' ; '));
}

/* =====================================================================================
 * Aufraeumen und Fazit
 * =================================================================================== */
try { fs.rmSync(temp, { recursive: true, force: true }); } catch (e) { /* Temp bleibt liegen - kein Grund, rot zu werden */ }
try { fs.rmSync(einzelOrdner, { recursive: true, force: true }); } catch (e) { /* dito */ }

console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + '):');
  fehler.forEach(function (f) { console.log('  x ' + f); });
  process.exit(1);
}
console.log('ALLE ' + ok + ' PRUEFUNGEN BESTANDEN' +
  (uebersprungen ? '  (Abschnitt B uebersprungen - kein passender Beispielexport gefunden)' : ''));
console.log('');
