'use strict';
/*
 * veta-export-lesen.js - liest den USB-Export des Narkosegeraets Veta 5 Plus (29.08.2026).
 *
 * WARUM ES DIESE DATEI GIBT:
 * Der Veta 5 Plus ist ueber das Netz stumm - Monate an Versuchen haben daran nichts geaendert
 * (siehe tools/veta5-mitschnitt.js). Er gibt seine Daten aber ueber "SysDat exp" auf einen
 * USB-Stick heraus. Was dort liegt, sieht aus wie ein Service-Bericht fuer Menschen, ist aber
 * maschinenlesbar: die HTML-Datei baut ihre Tabellen zur Anzeige aus JavaScript-Feldern
 * (var T_Data0..T_Data10) und enthaelt eine vollstaendige Trendliste ueber 2880 Minuten mit
 * allen sechs Beatmungswerten. Damit ist der Weg zu den Beatmungsdaten dieses Geraetes offen,
 * ohne dass es je ein Netzprotokoll herausgibt. Dieses Programm geht ihn.
 *
 * =======================================================================================
 * WAS AM ECHTEN EXPORT GEMESSEN WURDE (29.08.2026, Export vom 29.08.2026 00:35 Uhr)
 *
 * AUFBAU DER DATEI
 *   T_Data0  Geraetetyp, Geraete-ID, MAC          (6 Felder)
 *   T_Data1  Betriebszeiten                       (6 Felder)
 *   T_Data2  SW-Versionen                        (36 Felder)
 *   T_Data3  TRENDLISTE                       (20167 Felder = 7 x 2881)
 *   T_Data4  EREIGNISPROTOKOLL                (39813 Felder = 3 x 13271)
 *   T_Data5..T_Data10  Sensor- und Kalibrierwerte
 *
 * DIE TRENDLISTE STEHT ZEILENWEISE, NICHT SPALTENWEISE. Das ist die einzige wirklich
 * gefaehrliche Stelle dieses Programms:
 *     Feld 0            Kopf "Date<br>Time<br>Event"
 *     Feld 1..2880      die 2880 Zeitstempel, NEUESTE ZUERST
 *     Feld 2881         Spaltenname "Fi/Et CO2(mmHg)"
 *     Feld 2882..5761   die 2880 Werte dieser Spalte, in derselben Reihenfolge
 *     Feld 5762         Spaltenname "MAX(cmH2O)"   ... und so weiter, sechs Spalten
 * Ein Griff daneben um EINS verschiebt alle Werte um eine Minute, und man sieht es nicht:
 * die Zahlen bleiben plausibel, nur stehen sie an der falschen Minute. Genau das prueft
 * tools/veta-export-test.js an einer belegten Stichprobe nach (00:23 und 00:24 des letzten
 * Falls), und die Gegenprobe (Spaltenanfang absichtlich um eins verschoben) wurde gefahren.
 * Deshalb wird die Spaltenbreite hier NICHT als 2881 hineingeschrieben, sondern aus der
 * Datei selbst hergeleitet - auf ZWEI unabhaengigen Wegen, die uebereinstimmen muessen
 * (Aufruf CreateTable(...) am Dateiende und der Abstand der Spaltennamen im Feld).
 * Faellt der Aufruf CreateTable(...) weg - ein abgeschnittener Export, eine Firmware, die
 * ihre Tabelle anders zeichnet -, bleibt nur EIN Bein uebrig. Der Wert ist dann nicht falsch,
 * aber die Zusage "zwei Wege, die uebereinstimmen" ist zurueckgenommen. Bis zum 29.08.2026
 * geschah das wortlos; seither sagt der Bericht in der Zeile "Spaltenbreite", welche Wege
 * wirklich gegangen wurden.
 *
 * 2880 MINUTEN SIND HIER NICHT 48 STUNDEN AM STUECK.
 * Das Geraet schreibt nur eine Trendzeile, waehrend eine Narkose laeuft. Die 2880 Zeilen des
 * echten Exports decken 28.07.2026 19:50 bis 29.08.2026 00:33 ab - also 32 Tage. Zwischen den
 * Faellen klaffen Luecken bis 3950 Minuten. "Lueckenlos im Minutenabstand" gilt INNERHALB
 * eines Falls (gemessen: alle 64 Faelle des Exports lueckenlos), nicht ueber die ganze Liste.
 *
 * DIE FAELLE KOMMEN AUS DEM EREIGNISPROTOKOLL, NICHT AUS DEN "End Case"-MARKEN.
 * Naheliegend waere, an den 61 "End Case"-Marken der Trendliste zu trennen. Das ist falsch:
 * gemessen am echten Export fehlen DREI Marken (Faelle 19.08. 11:07, 04.08. 08:13,
 * 31.07. 12:02), und ihre Minuten landen dann im Block des Nachbarfalls - bis zu 116 Minuten
 * fremde Daten in einem Fall. Das Ereignisprotokoll dagegen fuehrt zu jedem Fall einen Eintrag
 * "Fall beenden" mit "Start <br>...<br>Ende <br>...", also die Zeiten, die das Geraet selbst
 * festhaelt. Damit ergibt sich der letzte Fall zu 29.08.2026 00:16 bis 00:33 - und jede der
 * 2880 Trendzeilen faellt in genau einen Fall (gemessen: 0 Waisen, 64 Faelle).
 * Die End-Case-Marken werden trotzdem gelesen und als Gegenprobe ausgewiesen. Eine Marke darf
 * um eine Minute abweichen (gemessen: 20.08.2026, Marke 12:26, Protokoll 12:27).
 * Nur wenn das Ereignisprotokoll gar keinen Fall zum Trendzeitraum hergibt, wird ersatzweise
 * an den Marken getrennt; dieser Weg hat im echten Export keinen Anlass und wird deshalb im
 * Test an einem eigens gebauten kleinen Export gefahren.
 *
 * WAS EIN PROTOKOLLEINTRAG ALLES SEIN KANN - und was daraus folgt (29.08.2026, nach einer
 * unabhaengigen Gegenpruefung):
 *   a) ENDE VOR START. Ein "Fall beenden", dessen Ende vor seinem Start liegt (Uhrsprung am
 *      Geraet, Zeitumstellung), ergab bis heute die Zeile "Dauer -2 min". Eine negative Dauer
 *      ist keine Messung, sondern ein kaputter Eintrag: er wird verworfen und im Bericht
 *      NAMENTLICH aufgezaehlt, nicht stillschweigend weggelassen. Denselben Schutz hatte der
 *      Zweig fuer nie beendete Faelle schon, der beendete nicht.
 *   b) ZWEI GLEICHE EINTRAEGE. Zwei identische "Fall beenden" ergaben zwei Faelle, den zweiten
 *      mit null Messminuten. Gleiche Start- UND Endzeit heisst derselbe Fall; er wird
 *      zusammengefasst und die Zahl der Zusammenfassungen steht im Bericht.
 *   c) DAUER NULL. Der echte Export hat 31 Eintraege mit Dauer 0 (von 437), einer davon liegt
 *      im Trendfenster und erscheint als "Fall 12" (25.08.2026 09:02, 0 min, 0 Messminuten).
 *      Die "64 Faelle" sind also 63 Narkosen plus ein Geraetartefakt. Weggelassen wird er
 *      nicht - dann verschoeben sich alle Fallnummern -, aber er wird als solcher benannt.
 *   d) EINE PROTOKOLLZEILE GEHOERT ZU GENAU EINEM FALL. Frueher filterte die Ereignisliste nur
 *      nach der Minute; 16 Zeilen des echten Exports landeten dadurch in zwei Faellen
 *      (Grenzminuten und der ueberlappende 09:02-Fall). Jetzt wird jede Zeile genauso
 *      zugeordnet wie eine Trendminute - erster Treffer in der Liste "neueste zuerst".
 *
 * "DAUER == MESSMINUTEN" IST KEINE PROBE, SONDERN EINE ZUFALLSGLEICHHEIT.
 * In 61 von 64 Faellen des echten Exports stimmen beide Zahlen ueberein, und das verleitet zu
 * der Annahme, damit sei "lueckenlos" geprueft. Es ist nicht so: Dauer = Ende - Start, der
 * Fall hat aber Ende - Start + 1 Minutenfaecher, und die Startminute traegt meist keine
 * Trendzeile. EINE Luecke im Fall bei gefuellter Startminute ergibt exakt dieselbe Gleichheit
 * (gemessen: Fall 46 hat 44 min Dauer und 45 Messminuten). Die Gleichheit kann ihren eigenen
 * Anlass also nicht sehen. Deshalb steht sie nirgends als Probe; statt dessen werden die
 * LUECKEN direkt gemessen (Abstand aufeinanderfolgender Messminuten) und im Bericht genannt.
 *
 * =======================================================================================
 * DATENSCHUTZ - GEMESSEN AM GELESENEN EXPORT, NICHT ZUGESAGT
 * (berichtigt 29.08.2026 nach einer unabhaengigen Gegenpruefung)
 *
 * WAS HIER FALSCH WAR. Bis zum 29.08.2026 druckte dieser Leser einen FESTEN Satz: "Das Geraet
 * fuehrt KEIN Namensfeld. Im gelesenen Export kommt kein Patienten-, Tier-, Besitzer- oder
 * Personenname vor." Gemessen wurden dabei nur die Netzadressen - der Satz war eine Zusage
 * ueber den einen Export, an dem er einmal geprueft worden war. Die Gegenpruefung hat einen
 * sonst identisch gebauten Export mit zwei Protokollzeilen gelesen:
 *     13:01:30  Anmeldung erfolgreich: Dr. A. Weber   Benutzer | a.weber
 *     13:02:00  Tiername: Minka, Besitzer Dr. Schulz  Modus VS
 * "Minka", "Dr. Schulz" und "Dr. A. Weber" standen im Bericht UND in der JSON - und sechs
 * Zeilen darunter stand, es gebe sie nicht. Keine Warnung, Exitcode 0.
 * Das ist die dritte Wiederholung derselben Fehlerklasse (siehe den Kopf von
 * tools/pds-feldsonde.js): EINE ZUSAGE BLEIBT GRUEN, WEIL IHR ANLASS IM GEPRUEFTEN EXEMPLAR
 * NICHT EINTRITT.
 *
 * WARUM NICHT MASKIERT WIRD - und warum das hier anders liegt als in tools/pds-feldsonde.js:
 * Die Feldsonde schreibt keinen einzigen Byte Geraetetext auf die Platte; sie beschreibt den
 * BAUPLAN einer Nachricht. Das geht dort, weil ihr Zweck die Struktur ist. Hier ist der Zweck
 * der INHALT: die Ereignistexte werden gebraucht ("Gewicht: 4.5 -> 2.0 kg", "Stellen Sie die
 * Spezies auf Hund ein"), ein Trendbericht ohne sie waere kein Bericht. Also wird nicht
 * gefiltert, sondern GEMESSEN und BERICHTET: der Abschnitt DATENSCHUTZ am Ende jedes Berichts
 * sagt, WONACH gesucht wurde, WIE VIEL durchsucht wurde und WAS dabei herauskam - auch dann,
 * wenn nichts gefunden wurde. Wird etwas gefunden, nennt er die Fundstellen einzeln und sagt,
 * dass der Bericht so nicht weitergegeben werden sollte.
 *
 * WONACH GESUCHT WIRD, UND WARUM GERADE DANACH.
 * Das Geraet fuehrt kein Namensfeld - ein Name kann also nur als FREITEXT in einer
 * Ereigniszeile stehen. Gesucht wird deshalb nach den MERKMALEN, an denen solcher Freitext
 * haengt: Feldbezeichnungen (Patient, Tiername, Besitzer, Halter ...), Anrede oder Titel vor
 * einem grossgeschriebenen Wort (Dr., Prof., Herr, Frau ...), Benutzer- und Anmeldenamen,
 * E-Mail-Adressen, Telefonnummern - dazu Netzadressen als eigene Suche.
 * Alle fuenf Namenssuchen sind am echten Export gemessen: 60416 Felder aller elf Tabellen
 * (T_Data0..T_Data10), 0 Treffer. Sie sind also nicht bloss vorsichtig formuliert, sie
 * schlagen an einem sauberen Bestand auch nicht falsch an.
 *
 * WAS VERWORFEN WURDE, obwohl es naheliegt - beides gemessen, beides untragbar:
 *   WORTSCHATZ-VERGLEICH (jedes Wort melden, das nur einmal vorkommt). Das Ereignisprotokoll
 *   des echten Exports hat 161 verschiedene Woerter, davon kommen 21 genau einmal vor: 11 sind
 *   Bruchstuecke von Hex-Werten (BA, BD, DD, DE, ED, EF, FB, FC ...), 10 sind gewoehnliche
 *   Woerter der Firmware. Sechs davon sind grossgeschrieben und damit genau die, die eine
 *   solche Regel als namensverdaechtig melden wuerde: Netzspannungsfehler, Hauptplatine,
 *   Austauscherinnerung, Verzoegerung, Dauer, Nur. Eine Regel, die an einem SAUBEREN Export
 *   sechs Fehlalarme wirft, wird nach dem dritten Bericht nicht mehr gelesen - und dann faellt
 *   der echte Fund auch nicht mehr auf.
 *   INITIALE + NAME ("A. Weber"). Trifft im echten Export 190-mal, jedes Mal auf denselben
 *   Geraetetext "K. Frischgas". Syntaktisch ist beides dasselbe.
 *
 * DIE GRENZE DER SUCHE STEHT IM BERICHT SELBST.
 * Diese Suchen finden einen Namen an seinem MERKMAL. Ein blosser Name ohne Merkmal - "Minka"
 * allein in einer Ereigniszeile - faellt ihnen NICHT auf. "Gefunden: nichts" heisst deshalb
 * "kein Merkmal gefunden" und ist KEIN Beweis, dass kein Name in der Datei steht. Genau dieser
 * Satz steht auch im Bericht. Eine Zusage, die mehr verspricht, gehoert dort nicht hin.
 *
 * WAS DER BERICHT AUSSERDEM ENTHAELT - ausdruecklich, nicht versehentlich:
 *   1. GERAETEKENNUNG: Geraetetyp, Geraete-ID und MAC-Adresse. Sie stehen im Bericht, weil ein
 *      Geraetebericht ohne das Geraet wertlos ist. Sie bezeichnen eine Maschine, keinen
 *      Patienten und keine Person. (Die MAC steht ohnehin schon im Dateinamen des Exports.)
 *   2. PATIENTENBEZOGENE MESSGROESSEN OHNE PATIENT: eingestelltes Koerpergewicht, Tierart,
 *      Beatmungswerte. Das sind die Daten, um derentwillen es dieses Programm gibt. Ohne Namen
 *      sind sie keiner Person zuzuordnen; wer den Bericht weitergibt, gibt Messwerte weiter.
 *   3. NETZADRESSEN DER PRAXIS: im Ereignisprotokoll des echten Exports stehen vier Zeilen der
 *      Form "IP-Adresse: 192.168.0.52" und "Standard-Gateway: 192.168.0.1". Sie werden einzeln
 *      aufgezaehlt, damit sie niemand uebersieht.
 *
 * NETZADRESSEN - DIE ALTE BEGRUENDUNG WAR FALSCH (berichtigt 29.08.2026).
 * Hier stand: "Ein Oktett mit fuehrender Null ist deshalb keine Adresse - damit trennen sich
 * Version und Adresse sauber (gemessen: 4 Adresszeilen, 0 Fehltreffer aus 36 Versionsfeldern)."
 * Die Gegenprobe mit denselben 36 Feldern ergibt EINEN Treffer: das CO2-Modul traegt die
 * Version "6.5.0.0" - keine fuehrende Null, passt auf jedes IPv4-Muster. Die 0 Fehltreffer
 * kamen nicht von der Regel, sondern daher, dass netzadressen() nur T_Data4 durchsuchte und
 * die Versionen in T_Data2 stehen. Wer den Melder auf alle Tabellen ausweitet - die
 * naheliegende Haertung -, erntet sofort einen Fehlalarm und findet hier die falsche Erklaerung.
 * Deshalb jetzt zweierlei: der Melder laeuft ueber ALLE Tabellen, und die Unterscheidung wird
 * nicht schaerfer GERATEN, sondern GEMESSEN. Eine fuehrende Null schliesst weiterhin aus
 * ("01.10.00.01"); zusaetzlich gilt jeder Vier-Zahlen-Block als Version, der WORTGLEICH in der
 * Versionstabelle T_Data2 desselben Exports steht. Syntaktisch sind "6.5.0.0" und
 * "192.168.0.52" nicht zu trennen - die Datei selbst weiss es aber, und sie wird gefragt.
 * Gemessen am echten Export: 4 Zeilen im Protokoll, 1 Fund in den uebrigen Tabellen (die MAC
 * des Geraetes in T_Data0), 0 Fehltreffer aus 36 Versionsfeldern.
 *
 * NICHT GELESEN werden die .log-Dateien neben der HTML (FrontGuiOperation.log, sys.log,
 * systemLog.log, vpmLog.log, batteryLog.log, VSPlusParam.log und die .lzo-Archive davon).
 * Sie sind Fehlersuche des Herstellers, sie sind hier nicht durchsucht worden, und dieses
 * Programm oeffnet sie nicht.
 * =======================================================================================
 *
 * Start:
 *   node tools/veta-export-lesen.js <Ordner ODER HTML-Datei>
 *   node tools/veta-export-lesen.js <Pfad> --fall 3
 *   node tools/veta-export-lesen.js <Pfad> --json C:\temp\fall.json
 */
const fs = require('fs');
const path = require('path');

/* =====================================================================================
 * 1. DIE DATEI FINDEN
 * Der Nutzer gibt den Ordner an, den "SysDat exp" auf den Stick geschrieben hat. Darin
 * liegen neben der HTML ein Dutzend Logdateien; die HTML traegt denselben Namen wie der
 * Ordner. Ein Ordner mit mehreren HTML-Dateien wird NICHT geraten, sondern gemeldet.
 * =================================================================================== */
function htmlFinden(ziel) {
  let st;
  try { st = fs.statSync(ziel); }
  catch (e) { throw new Error('Pfad nicht gefunden: ' + ziel); }

  if (st.isFile()) return ziel;

  const drin = fs.readdirSync(ziel).filter(function (n) { return /\.html?$/i.test(n); });
  if (drin.length === 0) throw new Error('In diesem Ordner liegt keine HTML-Datei: ' + ziel);
  if (drin.length === 1) return path.join(ziel, drin[0]);

  /* Mehrere: die, die so heisst wie der Ordner. Sonst aufgeben statt raten. */
  const wieOrdner = path.basename(ziel).replace(/\\+$/, '');
  const treffer = drin.filter(function (n) { return n.replace(/\.html?$/i, '') === wieOrdner; });
  if (treffer.length === 1) return path.join(ziel, treffer[0]);
  throw new Error('Mehrere HTML-Dateien im Ordner, keine heisst wie er: ' + drin.join(', '));
}

/* =====================================================================================
 * 2. LESEN UND DIE KODIERUNG PRUEFEN
 * Die Datei ist UTF-8 (das <meta> im Kopf sagt es auch). Wer sie als latin1 liest, bekommt
 * "GerAtedaten" statt "Geraetedaten" - und merkt es nicht, weil danach alles weiterlaeuft.
 * Deshalb wird hier NACH dem Lesen geprueft, ob die Kodierung aufgegangen ist: ein
 * Ersetzungszeichen U+FFFD oder eine der verraeterischen Folgen (so sehen Umlaute und
 * Anfuehrungszeichen aus, wenn UTF-8 als latin1 gelesen und wieder als UTF-8 gespeichert
 * wurde) bedeutet, dass falsch gelesen wurde. Beides ist ein Abbruch, keine Warnung: aus
 * falsch gelesenem Text entstehen sonst
 * falsch benannte Spalten, und ueber die Spaltennamen laeuft die ganze Zuordnung.
 *
 * WARUM DIE LISTE LAENGER IST ALS ZWEI (29.08.2026, nach einer Gegenpruefung):
 * Sie kannte nur "Ae" und "Ue" - also die Folgen fuer a-Umlaut und u-Umlaut. Nicht enthalten
 * waren der o-Umlaut (im Ereignisprotokoll des echten Exports 1x: "Verzoegerung") und die
 * deutschen Anfuehrungszeichen, die in der Datei je 197-mal stehen. Ein Export, in dem NUR
 * die verungluecken, waere wortlos durchgelaufen.
 * Aufgezaehlt wird deshalb nicht Zeichen fuer Zeichen, sondern nach Bauart: eine zweibyteige
 * UTF-8-Folge fuer einen Latin-1-Buchstaben faengt mit 0xC3 an, eine dreibyteige fuer die
 * typografischen Zeichen mit 0xE2 0x80. Falsch gelesen wird daraus "\u00C3" bzw. "\u00E2\u20AC"
 * plus ein zweites Zeichen. Genau das steht unten - und deckt damit auch die Umlaute ab, an
 * die hier niemand gedacht hat.
 * =================================================================================== */
/* Zweites Zeichen: 0xA0..0xBF stehen fuer sich selbst, 0x84/0x96/0x9C/0x9F liefern in
 * CP1252 die Zeichen fuer Ae, Oe, Ue und sz. Nach jedem davon steht ein falsch gelesener
 * Buchstabe - in gueltigem deutschem Text kommt "\u00C3" vor keinem von ihnen vor. */
const UMKODIERT = /\u00C3[\u00A0-\u00BF\u201E\u2013\u0153\u0178]|\u00E2\u20AC/;
function datenLesen(datei) {
  const roh = fs.readFileSync(datei);
  const text = roh.toString('utf8');
  if (text.indexOf('\uFFFD') >= 0) {
    throw new Error('Die Datei ist nicht durchgehend UTF-8 - sie enthaelt ungueltige Bytes.');
  }
  const um = UMKODIERT.exec(text);
  if (um) {
    throw new Error('Die Datei wurde offenbar schon einmal falsch umkodiert - gefunden: "' +
      um[0] + '" (U+' + um[0].charCodeAt(0).toString(16).toUpperCase() +
      ' U+' + um[0].charCodeAt(1).toString(16).toUpperCase() + ').');
  }
  return { text: text, bytes: roh.length };
}

/* =====================================================================================
 * 3. EIN JavaScript-FELD AUS DEM HTML HOLEN
 *
 * Von "var T_Data3 = [" bis zur PASSENDEN schliessenden Klammer. Die erste ] zu nehmen waere
 * falsch, sobald irgendwo eine Klammer in einem Text steht. Gezaehlt wird deshalb - und zwar
 * NUR ausserhalb von Zeichenketten, sonst wuerde eine Klammer im Text mitzaehlen.
 * Das Geraet schreibt " im Text als "&#34" (ohne Semikolon), es gibt also keine
 * maskierten Anfuehrungszeichen; der Backslash-Zweig steht trotzdem da, weil ein
 * Parser, der ihn nicht hat, bei der ersten Firmware mit Backslash still danebengreift.
 *
 * Zurueck kommen die Felder ROH (mit "<br>" und "&#34"). Entschluesselt wird erst beim
 * Anzeigen - sonst wuerde ein "&lt;br&gt;" im Text ploetzlich zu einer Zeilentrennung.
 * =================================================================================== */
function jsFeld(text, name) {
  const marke = 'var ' + name + ' = [';
  const a = text.indexOf(marke);
  if (a < 0) return null;

  let i = a + marke.length - 1;      /* steht auf der oeffnenden [ */
  let tiefe = 0;
  let imText = false;
  let ende = -1;
  const felder = [];
  let sammler = null;

  for (; i < text.length; i++) {
    const c = text[i];
    if (imText) {
      if (c === '\\') { sammler += c + text[i + 1]; i++; continue; }
      if (c === '"') { imText = false; felder.push(sammler); sammler = null; continue; }
      sammler += c;
      continue;
    }
    if (c === '"') { imText = true; sammler = ''; continue; }
    if (c === '[') { tiefe++; continue; }
    if (c === ']') { tiefe--; if (tiefe === 0) { ende = i; break; } continue; }
  }
  if (ende < 0) throw new Error('Die Klammer zu ' + name + ' wird in der Datei nie geschlossen.');
  return felder;
}

/* HTML-Sonderzeichen. Das Geraet schreibt "&#34" OHNE Semikolon - deshalb ist es optional. */
function entzeichnen(s) {
  return String(s)
    .replace(/&#(\d+);?/g, function (_, n) { return String.fromCharCode(parseInt(n, 10)); })
    .replace(/&quot;?/g, '"')
    .replace(/&lt;?/g, '<')
    .replace(/&gt;?/g, '>')
    .replace(/&amp;?/g, '&');
}

/* =====================================================================================
 * 4. ZEITEN
 *
 * Das Geraet schreibt seine ORTSZEIT im 12-Stunden-Format, ohne jede Zeitzone:
 *   Trendliste:        "2026-08-29<br>12:33 AM<br>End Case"   (12:33 AM = 00:33)
 *   Ereignisprotokoll: "2026-08-29 12:33:59 AM"
 * Gerechnet wird in MINUTEN seit 1970 ueber Date.UTC. Das ist Absicht: die Wanduhr des
 * Geraetes soll unveraendert bleiben. Wuerde man die Ortszeit dieses PCs benutzen, wuerde
 * eine Sommerzeitumstellung mitten in einer Narkose die Minutenabstaende verbiegen.
 * Aus demselben Grund traegt die ISO-Zeit in der JSON KEIN "Z" und keinen Zonenversatz:
 * es ist Geraetezeit, und was das Geraet nicht sagt, wird hier nicht erfunden.
 * =================================================================================== */
function minuteAus(datum, uhrzeit) {
  const d = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(datum).trim());
  const u = /^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)$/i.exec(String(uhrzeit).trim());
  if (!d || !u) return null;
  let std = parseInt(u[1], 10) % 12;
  if (/PM/i.test(u[4])) std += 12;
  const sek = u[3] ? parseInt(u[3], 10) : 0;
  const ms = Date.UTC(+d[1], +d[2] - 1, +d[3], std, +u[2], sek);
  if (!isFinite(ms)) return null;
  return { minute: Math.floor(ms / 60000), sekunde: sek, ms: ms };
}
function iso(minute, sek) {
  const d = new Date(minute * 60000 + (sek || 0) * 1000);
  return d.toISOString().slice(0, 19);          /* ohne Z: Geraetezeit, keine Zonenangabe */
}
function deutsch(minute) {
  const d = new Date(minute * 60000);
  function z2(n) { return (n < 10 ? '0' : '') + n; }
  return z2(d.getUTCDate()) + '.' + z2(d.getUTCMonth() + 1) + '.' + d.getUTCFullYear() +
    ' ' + z2(d.getUTCHours()) + ':' + z2(d.getUTCMinutes());
}
function nurUhr(minute) {
  const d = new Date(minute * 60000);
  function z2(n) { return (n < 10 ? '0' : '') + n; }
  return z2(d.getUTCHours()) + ':' + z2(d.getUTCMinutes());
}
/*
 * Uhrzeit MIT Tag - fuer Tabellen, in denen sich eine Uhrzeit sonst wiederholt (29.08.2026).
 * MINUTENWERTE und EREIGNISSE druckten nur HH:MM. Fall 2 des echten Exports laeuft ueber
 * Mitternacht, und auf dem Ersatzweg kann ein Fall Tage umspannen (Luecken bis 3950 min) -
 * dann steht dieselbe Uhrzeit zweimal in derselben Tabelle und niemand sieht, welche gemeint
 * ist. Der Tag wird nur dort gedruckt, wo er gebraucht wird; sonst bliebe von 240 Zeilen
 * Minutenwerten nichts mehr uebersichtlich.
 */
function tagUhr(minute) {
  const d = new Date(minute * 60000);
  function z2(n) { return (n < 10 ? '0' : '') + n; }
  return z2(d.getUTCDate()) + '.' + z2(d.getUTCMonth() + 1) + '. ' +
    z2(d.getUTCHours()) + ':' + z2(d.getUTCMinutes());
}
function nurTag(minute) {
  const d = new Date(minute * 60000);
  function z2(n) { return (n < 10 ? '0' : '') + n; }
  return z2(d.getUTCDate()) + '.' + z2(d.getUTCMonth() + 1) + '.' + d.getUTCFullYear();
}
function tagNummer(minute) { return Math.floor(minute / 1440); }
function dauerText(min) {
  if (min == null) return '-';
  if (min < 60) return min + ' min';
  const h = Math.floor(min / 60), m = min % 60;
  if (h < 24) return h + ' h ' + m + ' min';
  return Math.floor(h / 24) + ' d ' + (h % 24) + ' h ' + m + ' min';
}

/* =====================================================================================
 * 5. ZAHLEN
 * "---" heisst: das Geraet hat in dieser Minute nichts gemessen. Das ist NICHT 0 und wird zu
 * null. Fi/Et CO2 steht als Paar "0/0" bzw. "---/---" und wird in zwei Felder getrennt.
 * =================================================================================== */
function zahl(s) {
  const t = String(s == null ? '' : s).trim();
  if (t === '' || t === '---' || t === '--' || t === '-') return null;
  const n = Number(t.replace(',', '.'));
  return isFinite(n) ? n : null;
}
/*
 * =====================================================================================
 * CO2 KANN AUS ZWEITER HAND SEIN - UND DANN GILT DER VORRANG NICHT (29.08.2026)
 * =====================================================================================
 * Der Dauerauftrag des Nutzers lautet: CO2 und Atemfrequenz vom Veta haben Vorrang vor dem
 * Monitor, WEIL sie durch den Schlauch gemessen sind. Genau diese Begruendung faellt weg,
 * wenn das CO2 im Veta gar nicht vom Veta stammt: die dokumentierte Kopplung Veta<->Monitor
 * laeuft in DIESE Richtung - der Monitor liefert EtCO2 AN die Veta. Wer den Wert dann
 * bevorzugt, bevorzugt den Monitorwert ein zweites Mal und haelt ihn fuer eine unabhaengige,
 * bessere Messung. Ein Kreis, den man im Betrieb nicht sieht.
 *
 * WAS GEMESSEN IST und was nicht:
 *   - Im vorliegenden echten Export tragen 0 von 11.513 CO2-Eintraegen ein Zusatzzeichen.
 *     Das passt dazu, dass waehrend dieser Faelle kein Monitor gekoppelt war - es ist KEIN
 *     Beleg dafuer, dass es die Kennzeichnung nicht gibt.
 *   - Dass fremdes EtCO2 mit "+" gekennzeichnet wird, stammt aus einer Fremdrecherche zum
 *     Veta-5-Handbuch (29.08.2026) und ist an unserem Geraet NICHT nachgeprueft.
 *
 * DESHALB WIRD HIER KEIN "+" FEST EINGEBAUT. Erkannt wird, dass ueberhaupt ein Zeichen an der
 * Zahl haengt, das keine Zahl ist. Bisher fiel so ein Wert durch zahl() lautlos auf null -
 * ein gekennzeichneter Messwert waere also spurlos verschwunden, und niemand haette den
 * Grund erfahren. Jetzt bleibt die Zahl erhalten und traegt ihre Herkunft mit.
 */
/*
 * Der VORDERTEIL muss eine wirkliche Zahl sein, nicht bloss "ziffernaehnlich". Der erste
 * Entwurf liess `[-\d.,]*[\d-]` zu und zerlegte damit "---" (= nicht gemessen) in die Zahl
 * "--" und das Zeichen "-": eine FEHLENDE Messung waere als fremde gemeldet worden. Der Test
 * hat es gefunden, bevor es irgendwohin kam.
 */
function markierung(s) {
  const t = String(s == null ? '' : s).trim();
  const m = t.match(/^(-?\d+(?:[.,]\d+)?)\s*([^\s\d.,]+)$/);
  if (!m) return { rein: t, zeichen: null };
  return { rein: m[1], zeichen: m[2] };
}
function co2Paar(s) {
  const t = String(s == null ? '' : s).trim();
  if (t === '') return { fico2: null, etco2: null, fremd: false, kennzeichen: null };
  const teile = t.split('/');
  const roh = teile.length === 2 ? teile : [null, t];   /* ein Wert allein: der endexspiratorische */
  const a = markierung(roh[0]);
  const b = markierung(roh[1]);
  const zeichen = b.zeichen || a.zeichen;
  return {
    fico2: roh[0] == null ? null : zahl(a.rein),
    etco2: zahl(b.rein),
    /* fremd = der Wert traegt eine Herkunftskennzeichnung, stammt also nicht aus der
     * Schlauchmessung dieses Geraets. Wer ihn benutzt, darf ihm den Vorrang nicht geben. */
    fremd: zeichen != null,
    kennzeichen: zeichen
  };
}

/* =====================================================================================
 * 6. DIE TRENDLISTE
 *
 * Die sechs Spalten werden ueber ihren NAMEN zugeordnet, nicht ueber ihre Stellung. Wenn eine
 * kuenftige Firmware die Reihenfolge aendert oder eine Spalte ergaenzt, faellt das hier
 * lautstark auf ("unbekannte Trendspalte"), statt PEEP-Werte in die Vt-Spalte zu schreiben.
 * =================================================================================== */
const SPALTEN = {
  'Fi/Et CO2(mmHg)': 'co2',
  'MAX(cmH2O)': 'max',
  'PEEP(cmH2O)': 'peep',
  'Vt(ml)': 'vt',
  'MV(l/min)': 'mv',
  'AF(BPM)': 'af'
};

/*
 * Die Spaltenbreite (2881 = 1 Name + 2880 Werte) wird NICHT hineingeschrieben, sondern
 * hergeleitet - auf zwei Wegen, die uebereinstimmen muessen:
 *   a) aus dem Aufruf am Dateiende: CreateTable("T_Data3", -1, 2881, T_Data3);
 *   b) aus dem Feld selbst: die Stelle, an der der erste bekannte Spaltenname steht.
 * Weg b) allein wuerde genuegen; b) gegen a) zu pruefen kostet nichts und faengt genau die
 * Verschiebung ab, um die es hier geht.
 *
 * FEHLT DER AUFRUF, FAELLT WEG a) AUS - und das darf nicht wortlos geschehen (29.08.2026).
 * An einem abgeschnittenen Export blieb bisher ein Bein stehen: kein falscher Wert, aber die
 * Zusage "zwei unabhaengige Wege" war stillschweigend zurueckgenommen. Deshalb gibt diese
 * Funktion jetzt beide Ergebnisse zurueck, und der Bericht sagt, welche Wege gegangen wurden.
 */
function breiteFinden(text, felder) {
  let ausAufruf = null;
  const m = /CreateTable\(\s*"T_Data3"\s*,\s*-?\d+\s*,\s*(\d+)\s*,/.exec(text);
  if (m) ausAufruf = parseInt(m[1], 10);

  let ausFeld = null;
  for (let i = 1; i < felder.length; i++) {
    if (Object.prototype.hasOwnProperty.call(SPALTEN, entzeichnen(felder[i]))) { ausFeld = i; break; }
  }
  if (ausFeld == null) throw new Error('In T_Data3 steht kein bekannter Spaltenname - Aufbau unbekannt.');
  if (ausAufruf != null && ausAufruf !== ausFeld) {
    throw new Error('Die Trendliste widerspricht sich: CreateTable sagt ' + ausAufruf +
      ' Spalten, der erste Spaltenname steht auf ' + ausFeld + '.');
  }
  return { breite: ausFeld, ausAufruf: ausAufruf, ausFeld: ausFeld };
}

function trendLesen(text, felder) {
  const breiteBefund = breiteFinden(text, felder);
  const breite = breiteBefund.breite;
  const zeilen = felder.length / breite;
  if (zeilen !== Math.floor(zeilen)) {
    throw new Error('T_Data3 hat ' + felder.length + ' Felder, das ist kein Vielfaches von ' + breite + '.');
  }
  if (zeilen !== 7) {
    throw new Error('T_Data3 hat ' + zeilen + ' Zeilen erwartet werden 7 (Kopf + 6 Spalten).');
  }
  const anzahl = breite - 1;

  /* Welche Spalte steht in welcher Zeile? Ueber den Namen, nicht ueber die Stellung. */
  const wo = {};
  for (let z = 1; z < zeilen; z++) {
    const name = entzeichnen(felder[z * breite]);
    const schluessel = SPALTEN[name];
    if (!schluessel) throw new Error('unbekannte Trendspalte "' + name + '" in Zeile ' + z);
    if (wo[schluessel] != null) throw new Error('Trendspalte "' + name + '" kommt doppelt vor.');
    wo[schluessel] = z;
  }
  const fehlt = Object.keys(SPALTEN).filter(function (n) { return wo[SPALTEN[n]] == null; });
  if (fehlt.length) throw new Error('Diese Trendspalten fehlen: ' + fehlt.join(', '));

  function rohWert(schluessel, i) {
    const z = wo[schluessel];
    /*
     * DIE Stelle. i laeuft von 1 bis anzahl, z ist die Tabellenzeile der Spalte.
     * GEGENPROBE 29.08.2026: hier probeweise "+ 1" angehaengt -> tools/veta-export-test.js
     * meldete 11 von 50 Pruefungen rot, darunter die Stichprobenminute 00:24 (dort stand
     * dann Vt 72 / MV 8.0 / AF 111, also die Werte von 00:23) und der Zellenvergleich mit
     * 5966 Abweichungen. Die Stichprobe 00:23 blieb dabei GRUEN - 00:22 und 00:23 tragen
     * zufaellig dieselben Zahlen. Eine Pruefung nur auf 00:23 haette den Fehler durchgelassen.
     */
    const v = felder[z * breite + i];
    return v == null ? '' : v;
  }

  const punkte = [];
  const marken = [];
  const alle = [];
  for (let i = 1; i <= anzahl; i++) {
    const teile = String(felder[i]).split('<br>');
    const zeit = minuteAus(teile[0], (teile[1] || '').trim());
    if (!zeit) throw new Error('Zeitstempel Nr. ' + i + ' unlesbar: "' + felder[i] + '"');
    const ereignis = entzeichnen((teile[2] || '').trim());

    const co2 = co2Paar(rohWert('co2', i));
    const satz = {
      zeit: iso(zeit.minute),
      minute: zeit.minute,
      fico2: co2.fico2,
      etco2: co2.etco2,
      /* Nur setzen, wenn wirklich etwas dranhing - sonst traegt jede der 2880 Minuten ein
       * Feld, das immer dasselbe sagt, und das Auge lernt es zu ueberlesen. */
      co2Fremd: co2.fremd ? true : undefined,
      co2Kennzeichen: co2.kennzeichen || undefined,
      max: zahl(rohWert('max', i)),
      peep: zahl(rohWert('peep', i)),
      vt: zahl(rohWert('vt', i)),
      mv: zahl(rohWert('mv', i)),
      af: zahl(rohWert('af', i))
    };
    const leer = satz.fico2 == null && satz.etco2 == null && satz.max == null &&
      satz.peep == null && satz.vt == null && satz.mv == null && satz.af == null;

    /*
     * Eine Zeile mit Ereignistext ist eine MARKE, keine Messminute: sie traegt am echten
     * Export ausnahmslos leere Werte (gemessen: 61 von 61 leer, und keine einzige der 2819
     * Messzeilen ist ganz leer). Sie kaeme sonst als Minute voller null in jede Kurve.
     * Der Fall "Marke MIT Werten" wird nicht verschwiegen, sondern gezaehlt und gemeldet.
     */
    if (ereignis) {
      marken.push({ zeit: satz.zeit, minute: zeit.minute, ereignis: ereignis, hatWerte: !leer });
    } else {
      punkte.push(satz);
    }
    alle.push({ minute: zeit.minute, ereignis: ereignis });
  }

  punkte.sort(function (a, b) { return a.minute - b.minute; });   /* aelteste zuerst: so will es jede Kurve */
  marken.sort(function (a, b) { return a.minute - b.minute; });

  const minuten = alle.map(function (a) { return a.minute; });
  return {
    spalten: Object.keys(SPALTEN),
    breite: breite,
    breiteAusAufruf: breiteBefund.ausAufruf,   /* null = der Aufruf CreateTable(...) fehlt */
    breiteAusFeld: breiteBefund.ausFeld,
    zeilen: anzahl,
    punkte: punkte,
    marken: marken,
    von: Math.min.apply(null, minuten),
    bis: Math.max.apply(null, minuten)
  };
}

/* =====================================================================================
 * 7. DAS EREIGNISPROTOKOLL
 * Drei Spalten: Zeit, Informationen, Details. Die Kopfzeile wird uebergangen.
 * =================================================================================== */
function protokollLesen(felder) {
  if (felder.length % 3 !== 0) {
    throw new Error('T_Data4 hat ' + felder.length + ' Felder, das ist kein Vielfaches von 3.');
  }
  const zeilen = [];
  for (let r = 1; r < felder.length / 3; r++) {
    const rohZeit = String(felder[r * 3]).trim();
    const m = /^(\d{4}-\d{2}-\d{2})\s+(.+)$/.exec(rohZeit);
    const t = m ? minuteAus(m[1], m[2]) : null;
    zeilen.push({
      zeit: t ? iso(t.minute, t.sekunde) : null,
      minute: t ? t.minute : null,
      sekunde: t ? t.sekunde : 0,
      was: entzeichnen(felder[r * 3 + 1]),
      details: entzeichnen(felder[r * 3 + 2]),
      detailsRoh: felder[r * 3 + 2]
    });
  }
  return zeilen;
}

/* =====================================================================================
 * 8. DIE FAELLE
 *
 * Ein "Fall beenden" traegt in den Details die vom Geraet selbst gefuehrten Zeiten:
 *     "Start <br>2026-08-29 12:16 AM <br>Ende <br>2026-08-29 12:33 AM <br>"
 * Ein "Fall starten" traegt dieselbe Form mit "-------- --:--" als Ende - das ist ein Fall,
 * der (noch) nicht beendet wurde.
 * =================================================================================== */
function zeitenAusDetails(details) {
  const m = /Start\s*<br>\s*(\S+)\s+([^<]+?)\s*<br>\s*Ende\s*<br>\s*(\S+)\s+([^<]+?)\s*<br>/.exec(details);
  if (!m) return null;
  const s = minuteAus(m[1], m[2]);
  const e = minuteAus(m[3], m[4]);
  return { start: s ? s.minute : null, ende: e ? e.minute : null };
}

function faelleBilden(trend, protokoll) {
  const beendet = [];
  const offen = [];
  const fallEreignisMinuten = [];
  /* Was hier NICHT durchgeht, wird gezaehlt und im Bericht benannt - nie stillschweigend
   * weggelassen. Ein weggelassener Fall sieht in der Liste genauso aus wie ein Fall, den es
   * nie gab, und das ist der Unterschied zwischen "kein Eintrag" und "kaputter Eintrag". */
  const verworfen = [];
  let doppelte = 0;
  for (let i = 0; i < protokoll.length; i++) {
    const z = protokoll[i];
    if (z.was !== 'Fall beenden' && z.was !== 'Fall starten') continue;
    const zt = zeitenAusDetails(z.detailsRoh);
    if (!zt || zt.start == null) continue;
    if (z.minute != null) fallEreignisMinuten.push(z.minute);
    if (z.was === 'Fall beenden' && zt.ende != null) {
      /*
       * ENDE VOR START. Das Geraet schreibt seine Wanduhr; springt sie waehrend einer Narkose
       * zurueck (Zeitumstellung, Uhr von Hand gestellt), steht das Ende vor dem Start. Bis zum
       * 29.08.2026 ging dieser Eintrag ungeprueft durch und der Bericht druckte "Dauer -2 min".
       * Der Schutz gab es schon - aber nur im Zweig fuer nie beendete Faelle, eine Bildschirmseite
       * weiter unten. Eine negative Dauer ist keine Zahl, die man drucken darf.
       */
      if (zt.ende < zt.start) {
        verworfen.push({
          grund: 'Ende liegt vor dem Start (Uhrsprung am Geraet)',
          start: zt.start, ende: zt.ende, minute: z.minute
        });
        continue;
      }
      beendet.push({ start: zt.start, ende: zt.ende });
    } else if (z.was === 'Fall starten' && zt.ende == null) offen.push({ start: zt.start });
  }
  fallEreignisMinuten.sort(function (a, b) { return a - b; });

  /*
   * ZWEI GLEICHE EINTRAEGE SIND EIN FALL, nicht zwei (29.08.2026).
   * Zwei identische "Fall beenden" ergaben zwei Faelle, den zweiten mit null Messminuten -
   * die Minuten gehen ja alle an den ersten. Im Bericht stand dann ein Fall, den es nie gab.
   * Gleiche Start- UND Endzeit heisst derselbe Fall.
   */
  const gesehen = {};
  const eindeutig = [];
  const doppelteEintraege = [];
  beendet.forEach(function (f) {
    const k = f.start + '_' + f.ende;
    if (gesehen[k]) { doppelte++; doppelteEintraege.push(f); return; }
    gesehen[k] = true;
    eindeutig.push(f);
  });
  beendet.length = 0;
  eindeutig.forEach(function (f) { beendet.push(f); });

  /*
   * Ein "Fall starten" ohne zugehoeriges "Fall beenden" ist ein Fall, den das Geraet nie
   * abgeschlossen hat (Stromausfall, Neustart am Geraet). Er wird nicht unterschlagen -
   * aber sein Ende ist UNBEKANNT, und "unbekannt" darf nicht "bis jetzt" heissen.
   * Der echte Export hat genau einen solchen Fall (02.05.2026 20:57). Setzte man sein Ende
   * auf das Ende der Trendliste, verschlaenge er 2802 der 2819 Messminuten - alle Faelle
   * dahinter waeren leer, und der Bericht saehe trotzdem ordentlich aus. Deshalb endet ein
   * solcher Fall beim naechsten Fall-Ereignis des Protokolls; nur wenn danach gar keines
   * mehr kommt, laeuft er wirklich bis zum Ende der Trendliste.
   */
  const startBekannt = {};
  beendet.forEach(function (f) { startBekannt[f.start] = true; });
  const unbeendet = offen.filter(function (f) { return !startBekannt[f.start]; });

  let faelle = [];
  beendet.forEach(function (f) {
    faelle.push({ start: f.start, ende: f.ende, quelleZeiten: 'Ereignisprotokoll', beendet: true });
  });
  unbeendet.forEach(function (f) {
    let naechstes = null;
    for (let k = 0; k < fallEreignisMinuten.length; k++) {
      if (fallEreignisMinuten[k] > f.start) { naechstes = fallEreignisMinuten[k]; break; }
    }
    const ende = (naechstes == null) ? trend.bis : naechstes - 1;
    if (ende < f.start) {                             /* zwei Starts in derselben Minute */
      verworfen.push({ grund: 'Fall nie beendet, und schon in derselben Minute beginnt der naechste',
        start: f.start, ende: ende, minute: f.start });
      return;
    }
    faelle.push({
      start: f.start, ende: ende, beendet: false,
      quelleZeiten: 'Ereignisprotokoll (Fall nie beendet - Ende geschaetzt)'
    });
  });

  /* Nur was den Trendzeitraum beruehrt. Das Protokoll reicht viel weiter zurueck als der
   * Trendspeicher (echter Export: 437 Faelle im Protokoll, 64 davon im Trendzeitraum). */
  faelle = faelle.filter(function (f) { return f.ende >= trend.von && f.start <= trend.bis; });
  faelle.sort(function (a, b) { return b.ende - a.ende || b.start - a.start; });

  let ersatzweise = false;
  if (faelle.length === 0) {
    /*
     * ERSATZWEG: kein Fall im Protokoll (leeres oder abgeschnittenes Protokoll). Dann bleiben
     * nur die "End Case"-Marken. Sie sind schlechter - im echten Export fehlen drei -, aber
     * besser als gar keine Trennung. Der Bericht sagt, dass er diesen Weg gegangen ist.
     */
    ersatzweise = true;
    const m = trend.marken.slice().sort(function (a, b) { return b.minute - a.minute; });
    for (let k = 0; k < m.length; k++) {
      const aelter = (k + 1 < m.length) ? m[k + 1].minute : trend.von - 1;
      const start = aelter + 1;
      /*
       * ZWEI MARKEN IN DERSELBEN MINUTE (29.08.2026). Dann ist die aeltere nicht kleiner, und
       * der Anfang liegt HINTER dem Ende - der Bericht druckte "Dauer -1 min". Zwischen zwei
       * Marken derselben Minute liegt keine Messminute; da ist kein Fall, sondern ein zweiter
       * Marken-Eintrag. Er wird verworfen und benannt, nicht mit negativer Dauer gedruckt.
       */
      if (start > m[k].minute) {
        verworfen.push({ grund: 'zwei "End Case"-Marken in derselben Minute - dazwischen liegt kein Fall',
          start: start, ende: m[k].minute, minute: m[k].minute });
        continue;
      }
      faelle.push({ start: start, ende: m[k].minute, quelleZeiten: 'End-Case-Marken der Trendliste', beendet: true });
    }
    if (m.length) {
      const neueste = m[0].minute;
      if (trend.bis > neueste) {
        faelle.unshift({ start: neueste + 1, ende: trend.bis, quelleZeiten: 'End-Case-Marken der Trendliste (nicht beendet)', beendet: false });
      }
    }
    faelle.sort(function (a, b) { return b.ende - a.ende || b.start - a.start; });
  }

  faelle.forEach(function (f, i) {
    f.nr = i + 1;                                   /* 1 = der NEUESTE Fall */
    f.dauerMin = f.ende - f.start;
    f.punkte = [];
    f.ereignisse = [];
    f.marke = null;
    f.luecken = [];
  });

  /* Jede Messminute in genau einen Fall. Die Liste steht neueste-zuerst; der erste Treffer
   * gewinnt. Das entscheidet den einen gemessenen Grenzfall des echten Exports sauber:
   * am 25.08.2026 gibt es einen Fall der Laenge 0 (09:02 -> 09:02), der in einem laengeren
   * Fall (09:02 -> 09:57) liegt - die Minute geht an den laengeren. */
  const ohneFall = [];
  trend.punkte.forEach(function (p) {
    let ziel = null;
    for (let i = 0; i < faelle.length; i++) {
      if (p.minute >= faelle[i].start && p.minute <= faelle[i].ende) { ziel = faelle[i]; break; }
    }
    if (ziel) ziel.punkte.push(p); else ohneFall.push(p);
  });

  /*
   * EINE PROTOKOLLZEILE GEHOERT ZU GENAU EINEM FALL - genauso zugeordnet wie eine Messminute
   * (29.08.2026). Vorher filterte die Ereignisliste nur nach der Minute; 16 Zeilen des echten
   * Exports landeten dadurch in ZWEI Faellen (Grenzminuten und der ueberlappende 09:02-Fall).
   * Zwei Berichte nebeneinander gelegt zeigten dieselbe Zeile zweimal - und niemand konnte
   * sagen, zu welcher Narkose sie gehoert. Erster Treffer in der Liste "neueste zuerst"
   * gewinnt, so wie bei den Trendminuten; damit sind beide Zuordnungen dieselbe Regel.
   */
  protokoll.forEach(function (z) {
    z.fallNr = null;
    if (z.minute == null) return;
    for (let i = 0; i < faelle.length; i++) {
      if (z.minute >= faelle[i].start && z.minute <= faelle[i].ende) {
        z.fallNr = faelle[i].nr;
        faelle[i].ereignisse.push(z);
        return;
      }
    }
  });
  faelle.forEach(function (f) {
    f.ereignisse.sort(function (a, b) { return (a.minute - b.minute) || (a.sekunde - b.sekunde); });
  });

  /*
   * LUECKEN DIREKT MESSEN statt "Dauer == Messminuten" zu glauben (29.08.2026, Begruendung
   * im Dateikopf). Hier steht, wo innerhalb eines Falls Minuten fehlen - das ist die Angabe,
   * die die Gleichheit von Dauer und Messminutenzahl NICHT hergibt.
   */
  faelle.forEach(function (f) {
    const s = f.punkte.map(function (p) { return p.minute; }).sort(function (a, b) { return a - b; });
    for (let k = 1; k < s.length; k++) {
      if (s[k] - s[k - 1] !== 1) f.luecken.push({ von: s[k - 1], bis: s[k], minuten: s[k] - s[k - 1] - 1 });
    }
  });

  /*
   * Die End-Case-Marke als Gegenprobe an den Fall haengen. Eine Minute Abweichung ist erlaubt
   * und gemessen (20.08.2026: Marke 12:26, Protokoll 12:27).
   * ZWEI DURCHGAENGE, und das ist kein Schoenheitsfehler: die Toleranz von einer Minute laesst
   * sonst einen Nachbarfall die Marke stehlen. Gemessen am echten Export: der Fall
   * 25.08.2026 08:50-09:01 stand ohne Marke da, weil der Null-Minuten-Fall 09:02-09:02
   * dieselbe Marke mit Abstand 1 vorher abgeraeumt hatte. Erst die genauen Treffer, dann die
   * um eine Minute verschobenen - so bekommt jeder Fall die Marke, die wirklich seine ist.
   */
  const markenOhneFall = [];
  const offeneMarken = [];
  trend.marken.forEach(function (mk) {
    let ziel = null;
    for (let i = 0; i < faelle.length; i++) {
      if (faelle[i].ende === mk.minute && faelle[i].marke == null) { ziel = faelle[i]; break; }
    }
    if (ziel) ziel.marke = mk; else offeneMarken.push(mk);
  });
  offeneMarken.forEach(function (mk) {
    let ziel = null;
    for (let i = 0; i < faelle.length; i++) {
      if (Math.abs(faelle[i].ende - mk.minute) <= 1 && faelle[i].marke == null) { ziel = faelle[i]; break; }
    }
    if (ziel) ziel.marke = mk; else markenOhneFall.push(mk);
  });

  /*
   * FAELLE OHNE EINE EINZIGE MESSMINUTE. Der echte Export hat einen (25.08.2026 09:02, Dauer 0):
   * das Geraet hat einen Fall begonnen und in derselben Minute beendet. Die "64 Faelle" sind
   * also 63 Narkosen plus ein Geraetartefakt. Herausgenommen wird er NICHT - dann verschoeben
   * sich alle Fallnummern gegenueber jedem frueheren Bericht -, aber er wird benannt.
   */
  const ohneMessminute = faelle.filter(function (f) { return f.punkte.length === 0; });
  ohneMessminute.forEach(function (f) { f.ohneMessminute = true; });

  /* Wieviele der zusammengefassten Doppelten haetten den Trendzeitraum ueberhaupt beruehrt?
   * Ohne diese Zahl behauptet der Bericht eine Wirkung, die er nicht gemessen hat: der eine
   * Doppeleintrag des echten Exports liegt am 07.05.2026, also weit vor der Trendliste. */
  const doppelteImFenster = doppelteEintraege.filter(function (f) {
    return f.ende >= trend.von && f.start <= trend.bis;
  }).length;

  return {
    faelle: faelle, ohneFall: ohneFall, markenOhneFall: markenOhneFall, ersatzweise: ersatzweise,
    verworfen: verworfen, doppelte: doppelte, doppelteImFenster: doppelteImFenster,
    doppelteEintraege: doppelteEintraege, ohneMessminute: ohneMessminute
  };
}

/* =====================================================================================
 * 9. DATENSCHUTZ - AM GELESENEN EXPORT GEMESSEN
 *
 * Die ausfuehrliche Begruendung steht im Dateikopf. Kurz: bis zum 29.08.2026 druckte der
 * Bericht hier einen festen Satz ueber Namen und mass nur die Netzadressen. Jetzt misst er
 * beides, und der Bericht sagt, wonach gesucht wurde, wie viel durchsucht wurde und was
 * gefunden wurde - auch dann, wenn nichts gefunden wurde.
 *
 * NETZADRESSEN. Die Pruefung auf IPv4 muss enger sein als "vier Zahlen mit Punkten": die
 * SW-Versionen des Geraetes haben genau diese Form. Ein Oktett mit fuehrender Null ist keine
 * Adresse (das faengt "01.10.00.01"), aber es faengt NICHT "6.5.0.0" - so steht die Version
 * des CO2-Moduls im echten Export. Syntaktisch ist dieser Block von einer Adresse nicht zu
 * trennen; also wird die Datei gefragt: was wortgleich in der Versionstabelle T_Data2 steht,
 * ist eine Version. Damit traegt die Regel auch dann, wenn der Melder - wie jetzt - ueber
 * ALLE Tabellen laeuft und nicht mehr nur ueber das Ereignisprotokoll.
 * =================================================================================== */
const IPV4 = /\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b/g;
const MACADR = /\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\b/g;

/* Alle Vier-Zahlen-Bloecke, die in der Versionstabelle stehen. Was hier drin ist, ist eine
 * Version und keine Adresse - gemessen an DIESEM Export, nicht aus einer Liste geraten. */
function versionsBloecke(tabellen) {
  const raus = {};
  (tabellen || []).forEach(function (t) {
    if (t.name !== 'T_Data2') return;
    t.felder.forEach(function (f) {
      const s = entzeichnen(String(f == null ? '' : f));
      (s.match(IPV4) || []).forEach(function (a) { raus[a] = true; });
    });
  });
  return raus;
}

function adressenIn(text, ausschluss) {
  const raus = ausschluss || {};
  const gefunden = [];
  const schon = {};
  const s = String(text == null ? '' : text);
  (s.match(IPV4) || []).concat(s.match(MACADR) || []).forEach(function (a) {
    if (raus[a] || schon[a]) return;
    schon[a] = true;
    gefunden.push(a);
  });
  return gefunden;
}

function netzadressen(protokoll, ausschluss) {
  const treffer = [];
  protokoll.forEach(function (z) {
    const gefunden = adressenIn(z.was + ' ' + z.details, ausschluss);
    if (gefunden.length) {
      treffer.push({ minute: z.minute, zeit: z.zeit, was: z.was, details: z.details, adressen: gefunden });
    }
  });
  return treffer;
}

/* Der zweite Teil derselben Suche: alle uebrigen Tabellen. T_Data4 bleibt aussen vor - das
 * ist das Ereignisprotokoll, das netzadressen() schon Zeile fuer Zeile durchgeht. */
function netzfundeInTabellen(tabellen, ausschluss) {
  const treffer = [];
  (tabellen || []).forEach(function (t) {
    if (t.name === 'T_Data4') return;
    t.felder.forEach(function (f, i) {
      const gefunden = adressenIn(entzeichnen(String(f == null ? '' : f)), ausschluss);
      if (gefunden.length) treffer.push({ tabelle: t.name, feld: i, adressen: gefunden });
    });
  });
  return treffer;
}

/*
 * DIE NAMENSSUCHE. Wonach gesucht wird und warum gerade danach, steht im Dateikopf; dort
 * steht auch, was verworfen wurde (Wortschatz-Vergleich: 6 Fehlalarme am sauberen Export;
 * "Initiale + Name": 190 Fehlalarme auf "K. Frischgas").
 * Jede Suche traegt ihren eigenen Klartext mit - er wird im Bericht gedruckt, damit dort
 * WIRKLICH steht, wonach gesucht wurde, und nicht nur, dass gesucht wurde.
 */
const NAMENSMERKMALE = [
  /*
   * WORTSTAMM STATT GANZEM WORT (nachgeschaerft 29.08.2026).
   * Die erste Fassung verlangte "\\bPatient\\b" - und scheiterte damit an jedem deutschen
   * Kompositum. Eine unabhaengige Gegenpruefung hat gemessen, dass ihr unter anderem
   * "Patientenname: Minka", "Besitzername: Schulz" und "Tierbesitzer: Schulz" entgingen:
   * genau die Schreibweisen, in denen ein Namensfeld tatsaechlich auftaucht. Deshalb suchen
   * die eindeutigen Stuecke jetzt ohne Wortgrenze.
   * Die zweite Haelfte behaelt die Wortgrenze UND verlangt einen Doppelpunkt oder Strich
   * dahinter - "Kunde" ohne das waere in jedem "Sekunde" ein Fehlalarm, und "Name" in jedem
   * "Geraetename". So bleibt "Name: Minka" auffindbar, ohne dass der Bericht bei jedem
   * Firmwarewort Alarm schlaegt.
   */
  { kurz: 'Bezeichnung eines Namensfeldes',
    wonach: 'Patient\u2026, Tiername\u2026, Besitzer\u2026, Tierhalter\u2026, Eigentuemer\u2026, Vor-/Nach-/Familienname, ' +
      'Ownername, Pet/Animal name (auch als Wortteil); dazu Halter, Owner, Client, Kunde, ' +
      'Bediener, Tierarzt, Operator, Name - jeweils gefolgt von ":" oder "|"',
    re: new RegExp(
      '(?:patient|tiername|besitzer|tierhalter|eigent(?:u|ue|\u00fc)mer|nachname|vorname' +
      '|familienname|ownername|owner\\s*name|pet\\s*name|animal\\s*name)' +
      '|\\b(?:halter|halterin|owner|client|kunde|kundin|bediener|tierarzt|operator|name)' +
      '\\s*[:|]', 'i') },
  /*
   * ZWEI SCHREIBWEISEN, NICHT EINE (29.08.2026).
   * Gemessen entgingen der ersten Fassung "Dr.Schulz" (ohne Leerzeichen), "dr. schulz" und
   * "Dr. schulz" - sie verlangte ein Leerzeichen UND einen Grossbuchstaben und lief ohne
   * i-Flag. Jetzt zwei Zweige:
   *   MIT Punkt  -> Gross/Klein egal, Leerzeichen darf fehlen. Der Punkt ist das Merkmal.
   *   OHNE Punkt -> wie bisher Grossbuchstabe verlangt. Ohne diese Bedingung meldete der
   *                 Geraetetext "Fr Rate 12" und "Ms Wert" einen Fund (gemessen).
   */
  /*
   * ZWEI EINTRAEGE STATT EINES ODER-AUSDRUCKS - weil sie verschiedene Kennzeichen brauchen.
   * Der erste laeuft mit i-Flag (Gross/Klein egal, der PUNKT ist das Merkmal), der zweite
   * ohne (dort IST der Grossbuchstabe das Merkmal). In einem Ausdruck zusammengefasst gilt
   * das Flag fuer beide - genau daran ist die erste Fassung gescheitert: mit i-Flag waere
   * "fr rate" ein Fund gewesen, ohne i-Flag blieb "Dr.Schulz" unentdeckt (gemessen).
   */
  { kurz: 'Anrede mit Punkt',
    wonach: 'Dr. Prof. Herr Frau Hr. Fr. Mr. Mrs. Ms. Dipl. - mit Punkt, Gross/Klein egal, ' +
      'Leerzeichen darf fehlen ("Dr.Schulz")',
    re: /\b(?:dr|prof|herr|frau|hr|fr|mr|mrs|ms|dipl)\.\s*[a-z\u00e0-\u024f]/i },
  { kurz: 'Anrede ohne Punkt vor einem Grossbuchstaben',
    wonach: 'Dr Prof Herr Frau Hr Fr Mr Mrs Ms Dipl - ohne Punkt, dann ein Grossbuchstabe',
    /* Ohne den Grossbuchstaben meldete der Geraetetext "fr rate 12" einen Fund. MIT ihm
     * meldet "Fr Rate 12" weiterhin einen - das ist ein Fehlalarm, der bewusst in Kauf
     * genommen wird: dies ist ein HINWEIS, kein Filter. Ein Fehlalarm kostet einen Blick,
     * eine Luecke kostet einen Namen. Am echten Export: 0 Treffer. */
    re: /\b(?:Dr|Prof|Herr|Frau|Hr|Fr|Mr|Mrs|Ms|Dipl)\s+[A-Z\u00c4\u00d6\u00dc]/ },
  /*
   * FREMDE SCHRIFT (29.08.2026). Die Gegenpruefung setzte "\u041f\u0430\u0446\u0438\u0435\u043d\u0442: \u041c\u0443\u0440\u043a\u0430, \u0432\u043b\u0430\u0434\u0435\u043b\u0435\u0446 \u0410\u0445\u043c\u0435\u0442\u043e\u0432"
   * und "Hasta sahibi: Ayse Yilmaz" ein - beides ging durch, weil alle Muster oben deutsche
   * und englische Woerter suchen. Kyrillisch, Griechisch und arabische Schrift lassen sich
   * dagegen an ihrem Zeichenvorrat erkennen, ohne die Sprache zu kennen. Die Firmware dieses
   * Geraets schreibt ausschliesslich lateinisch (gemessen: 282 verschiedene Woerter, kein
   * einziges Zeichen ausserhalb) - ein Treffer ist hier also immer erklaerungsbeduerftig.
   * Tuerkisch faellt NICHT darunter: es ist lateinisch. Das steht so in den Grenzen.
   */
  { kurz: 'Schrift ausserhalb des lateinischen Alphabets',
    wonach: 'kyrillische, griechische, hebraeische oder arabische Zeichen',
    re: /[\u0370-\u03ff\u0400-\u04ff\u0590-\u05ff\u0600-\u06ff]/ },
  { kurz: 'Benutzer- oder Anmeldename',
    wonach: 'Benutzer(in), Anwender, Nutzer, User, Username, Login, Anmeldename, ' +
      '"angemeldet als", "logged in"',
    re: /\b(?:Benutzer|Benutzerin|Anwender|Nutzer|User|Username|Login|Anmeldename|angemeldet als|logged in)\b/i },
  /*
   * "ANMELDUNG" ALLEIN IST KEIN MERKMAL - die Kennung DAHINTER ist es (29.08.2026).
   *
   * Erster Versuch war, "Anmeldung" einfach in die Liste darueber aufzunehmen, weil die
   * Zeile "Anmeldung erfolgreich | aweber" sonst durchgeht. Am echten Export ergab das
   * sofort ZWOELF Treffer: das Geraet schreibt seine eigenen Anmeldungen genauso, nur mit
   * einer Rolle statt eines Namens ("System: Anmeldung erfolgreich"). Ein Bericht, der bei
   * jedem sauberen Export Alarm schlaegt, wird nach dem zweiten Mal nicht mehr gelesen -
   * und ist damit schaedlicher als keiner.
   *
   * Gesucht wird deshalb die FORM einer Benutzerkennung: das Wort, dann ein Trennzeichen,
   * dann eine kleingeschriebene Kennung aus Buchstaben, Ziffern, Punkt oder Strich.
   * "Anmeldung erfolgreich" allein passt darauf nicht, "Anmeldung erfolgreich | aweber"
   * schon. Am echten Export: 0 Treffer (gemessen).
   */
  { kurz: 'Benutzerkennung hinter einem Anmeldevermerk',
    wonach: 'Anmeldung/Login/angemeldet, dann ":" oder "|", dann eine kleingeschriebene ' +
      'Kennung wie "aweber" oder "a.weber"',
    re: /\b(?:Anmeldung|Login|angemeldet|logon|sign(?:ed)?[ -]?in)\b[^|:]{0,40}[|:]\s*[a-z][a-z0-9._-]{2,}/i },
  { kurz: 'E-Mail-Adresse',
    wonach: 'irgendwas@irgendwas.xy',
    re: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/ },
  { kurz: 'Telefonnummer',
    wonach: 'Laendervorwahl oder fuehrende 0, dann Vorwahl, Trennzeichen und mindestens drei Ziffern',
    re: /(?:\+\d{2,3}[ \/-]?|\b0)\d{2,5}[ \/-]\d{3,}/ }
];

/* Wo steht der Fund? Fuer das Ereignisprotokoll die Uhrzeit - danach kann der Tierarzt in
 * seinem eigenen Bericht nachsehen. Fuer alles andere Tabelle und Feldnummer. */
function fundOrt(tabelle, i, protokoll) {
  if (tabelle === 'T_Data4') {
    const r = Math.floor(i / 3);
    const z = (r >= 1 && protokoll) ? protokoll[r - 1] : null;
    if (z && z.minute != null) return 'Ereignisprotokoll ' + deutsch(z.minute);
    return 'Ereignisprotokoll Zeile ' + r;
  }
  return tabelle + ' Feld ' + i;
}

function namenSuchen(tabellen, protokoll) {
  const suchen = NAMENSMERKMALE.map(function (s) { return { kurz: s.kurz, wonach: s.wonach, treffer: [] }; });
  let felder = 0;
  const woerter = {};
  let verschieden = 0;
  (tabellen || []).forEach(function (t) {
    for (let i = 0; i < t.felder.length; i++) {
      const s = entzeichnen(String(t.felder[i] == null ? '' : t.felder[i])).replace(/<br>/g, ' ');
      felder++;
      /* Die Zahl der verschiedenen Woerter ist keine Pruefung, sondern die Angabe, WIE VIEL
       * durchsucht wurde. Ohne sie ist "0 Treffer" eine Zahl ohne Bezugsgroesse. */
      const w = s.split(/[^A-Za-z\u00c0-\u024f]+/);
      for (let q = 0; q < w.length; q++) {
        if (w[q] && !woerter[w[q]]) { woerter[w[q]] = true; verschieden++; }
      }
      for (let k = 0; k < NAMENSMERKMALE.length; k++) {
        const m = NAMENSMERKMALE[k].re.exec(s);
        if (!m) continue;
        suchen[k].treffer.push({
          ort: fundOrt(t.name, i, protokoll),
          fund: m[0],
          text: s.length > 70 ? s.slice(0, 69) + '.' : s
        });
      }
    }
  });
  let gesamt = 0;
  suchen.forEach(function (s) { gesamt += s.treffer.length; });
  return { suchen: suchen, felder: felder, woerter: verschieden, treffer: gesamt };
}

/* =====================================================================================
 * 10. DER BERICHT
 * =================================================================================== */
function paare(felder, spalten) {
  const out = [];
  for (let i = spalten; i + spalten - 1 < felder.length; i += spalten) {
    const zeile = [];
    for (let k = 0; k < spalten; k++) zeile.push(entzeichnen(felder[i + k]));
    out.push(zeile);
  }
  return out;
}

function ausrichten(s, n) { s = String(s); return s.length >= n ? s : s + new Array(n - s.length + 1).join(' '); }
/* Beschriftung mit Fuellpunkten, damit die Zahlen einer Spalte untereinander stehen.
 * Ein zu langer Name wird gekuerzt - lieber ein "..." als eine verrutschte Spalte. */
function punkteAuf(s, n) {
  s = String(s);
  if (s.length > n) return s.slice(0, n - 1) + '.';
  return s + ' ' + new Array(Math.max(1, n - s.length) + 1).join('.');
}
function rechts(s, n) { s = String(s); return s.length >= n ? s : new Array(n - s.length + 1).join(' ') + s; }
/* Umbruch an Wortgrenzen. Die Konsole des Praxis-PCs bricht sonst mitten im Wort um, und
 * gerade die Aufzaehlung, WONACH gesucht wurde, soll man lesen koennen. */
function umbrechen(text, breite, einzug) {
  const w = String(text).split(/\s+/);
  const zeilen = [];
  let z = '';
  w.forEach(function (x) {
    if (!z.length) { z = x; return; }
    if (z.length + 1 + x.length > breite) { zeilen.push(z); z = x; return; }
    z += ' ' + x;
  });
  if (z.length) zeilen.push(z);
  return zeilen.map(function (r) { return einzug + r; });
}
function wert(v, k) { return rechts(v == null ? '-' : String(v), k || 6); }

function statistik(punkte, feld) {
  let min = null, max = null, summe = 0, n = 0;
  punkte.forEach(function (p) {
    const v = p[feld];
    if (v == null) return;
    if (min == null || v < min) min = v;
    if (max == null || v > max) max = v;
    summe += v; n++;
  });
  return { min: min, max: max, mittel: n ? summe / n : null, n: n };
}

/*
 * DER BERICHT ZEIGT DEN FALL, DER GELESEN WURDE - keinen anderen (29.08.2026).
 * bericht() nahm den Fall aus daten.faelle[fallNr-1], die Ereignisse aber aus
 * daten.ereignisse, und die hatte exportLesen(ziel, fallNr) festgelegt. Wer
 * bericht(exportLesen(O, 1), 3) rief, bekam Kopf und Minutenwerte von Fall 3 und darunter
 * die 19 Ereignisse von Fall 1 (richtig waeren 28). Ueber die Befehlszeile war das nicht zu
 * erreichen, ueber module.exports sehr wohl - und beide Funktionen sind exportiert.
 * Zwei Quellen fuer dieselbe Frage sind der Fehler; deshalb gibt es jetzt nur noch eine
 * (daten.gewaehlt) und eine abweichende Nummer ist ein Abbruch, keine stille Mischung.
 * Aus demselben Grund ist eine unbekannte Fallnummer hier ein Fehler und kein halber
 * Bericht: frueher kehrte bericht() vorzeitig zurueck und liess Geraete-ID, MAC und alle
 * Fallzeiten stehen - ohne den Datenschutz-Abschnitt, der Rechenschaft darueber ablegt.
 */
function bericht(daten, fallNr) {
  const L = [];
  function z(s) { L.push(s == null ? '' : s); }

  const nr = (fallNr == null) ? daten.gewaehlt : fallNr;
  if (nr !== daten.gewaehlt) {
    throw new Error('bericht() soll Fall ' + nr + ' zeigen, gelesen wurde aber Fall ' +
      daten.gewaehlt + '. Die Ereignisse gehoerten dann zum falschen Fall. ' +
      'Erst exportLesen(<Pfad>, ' + nr + ') rufen, dann bericht().');
  }
  if (!daten.fall) {
    throw new Error('Es gibt keinen Fall Nr. ' + nr + '. Der Export enthaelt ' +
      daten.faelle.length + ' Faelle' +
      (daten.faelle.length ? '; waehlbar ist 1 bis ' + daten.faelle.length + ' (1 = der neueste).'
        : ' - zu diesem Trendzeitraum nennt weder das Ereignisprotokoll noch eine "End Case"-Marke einen Fall.'));
  }

  z('');
  z('===============================================================');
  z('  VETA 5 PLUS - USB-Export ("SysDat exp")');
  z('===============================================================');
  z('');

  /* --- Geraet ------------------------------------------------------------------ */
  const g = daten.geraet;
  z('GERAET');
  z('  Typ .................. ' + (g.typ || '-'));
  z('  Geraete-ID ........... ' + (g.id || '-'));
  z('  MAC-Adresse .......... ' + (g.mac || '-'));
  /* Die Beschriftung kommt vom Geraet ("Betriebszeit des Geraetes" ist laenger als die
   * Spalte oben) und wird deshalb NICHT in die Punktspalte gezwaengt: lieber eine eigene
   * Zeile als ein abgeschnittenes Wort. */
  g.betriebszeit.forEach(function (b) {
    z('  ' + b[0] + ': ' + b[1] + ' Std:Min');
  });
  if (g.software.length) z('  Bundle-Version ....... ' + (g.software[0][1] || '-'));
  z('');

  /* --- Trendliste --------------------------------------------------------------- */
  const t = daten.trend;
  const spanne = t.bis - t.von;
  z('TRENDLISTE');
  z('  Spalten .............. ' + t.spalten.join('  '));
  z('  Zeilen ............... ' + t.zeilen + '  (' + t.punkte.length + ' Messminuten + ' +
    t.marken.length + ' End-Case-Marken)');
  z('  Zeitraum ............. ' + deutsch(t.von) + ' bis ' + deutsch(t.bis));
  z('  aufgezeichnet ........ ' + dauerText(t.punkte.length) + ' Messung,');
  z('                         verteilt ueber ' + dauerText(spanne) + '.');
  z('                         Das Geraet schreibt nur waehrend einer Narkose.');
  /* Die Spaltenbreite entscheidet, ob die Werte an der richtigen Minute stehen. Wieviele
   * Wege sie belegen, gehoert deshalb in den Bericht und nicht nur in den Dateikopf. */
  if (t.breiteAusAufruf != null) {
    z('  Spaltenbreite ........ ' + t.breite + '  (CreateTable und Feldinhalt - beide Wege stimmen)');
  } else {
    z('  ! Spaltenbreite ...... ' + t.breite + '  - NUR EIN WEG. Der Aufruf CreateTable("T_Data3",');
    z('                         ...) steht nicht in dieser Datei, die Breite kommt allein aus');
    z('                         der Stellung des ersten Spaltennamens. Die Gegenprobe gegen');
    z('                         eine Verschiebung um eine Spalte ist damit NICHT gefahren.');
  }
  z('  Minuten ohne Fall .... ' + daten.ohneFall.length);
  const markenMitWerten = t.marken.filter(function (m) { return m.hatWerte; }).length;
  if (markenMitWerten) z('  ! ' + markenMitWerten + ' End-Case-Marken tragen Messwerte - sie fehlen in der Kurve.');
  z('');

  /* --- Faelle -------------------------------------------------------------------- */
  const F = daten.faelle;
  z('FAELLE (' + F.length + ' im Trendzeitraum)');
  if (daten.ersatzweise) {
    z('  ! Das Ereignisprotokoll nennt keinen Fall in diesem Zeitraum.');
    z('    Getrennt wurde deshalb an den "End Case"-Marken der Trendliste.');
    z('    Diese Marken sind unvollstaendig - Faelle koennen zusammengefasst sein.');
  } else {
    z('  Zeiten aus dem Ereignisprotokoll des Geraetes ("Fall beenden").');
  }
  /*
   * Was das Protokoll hergab, aber kein Fall ist. Diese drei Zeilen sind der Unterschied
   * zwischen "es gab nichts" und "es gab etwas Kaputtes, und wir haben es weggelassen".
   */
  if (daten.doppelte) {
    z('  Hinweis: ' + daten.doppelte + ' doppelte Fall-Eintraege des Protokolls zusammengefasst');
    z('           (gleiche Start- UND Endzeit; davon ' + daten.doppelteImFenster +
      ' im Trendzeitraum). Ohne das staende');
    z('           jeder von ihnen ein zweites Mal in der Liste unten - mit null Messminuten,');
    z('           weil die Minuten alle an den ersten gehen.');
  }
  if (daten.verworfen && daten.verworfen.length) {
    z('  ! ' + daten.verworfen.length + ' Eintrag/Eintraege verworfen, weil sie keine Dauer ergeben:');
    daten.verworfen.slice(0, 8).forEach(function (v) {
      z('      ' + deutsch(v.start) + ' -> ' + deutsch(v.ende) + '   ' + v.grund);
    });
    if (daten.verworfen.length > 8) z('      .. ' + (daten.verworfen.length - 8) + ' weitere.');
  }
  const leere = F.filter(function (f) { return f.punkte.length === 0; });
  if (leere.length) {
    z('  ! ' + leere.length + ' Fall (Nr ' + leere.map(function (f) { return f.nr; }).join(', ') +
      ') ohne eine einzige Messminute.');
    z('    Das Geraet hat hier einen Fall begonnen und (fast) sofort beendet. Er wird');
    z('    mitgezaehlt, damit die Fallnummern stabil bleiben - eine Narkose ist er nicht.');
  }
  z('');
  z('   Nr  Start              Ende               Dauer          Messminuten  Marke');
  z('   --  -----------------  -----------------  -------------  -----------  -----');
  const zeigen = Math.min(F.length, 20);
  for (let i = 0; i < zeigen; i++) {
    const f = F[i];
    z('   ' + rechts(f.nr, 2) + '  ' + ausrichten(deutsch(f.start), 17) + '  ' +
      ausrichten(deutsch(f.ende), 17) + '  ' + ausrichten(dauerText(f.dauerMin), 13) + '  ' +
      rechts(f.punkte.length, 11) + '  ' + (f.marke ? '  ja' : '  --') +
      (f.beendet ? '' : '   (nicht beendet)') +
      (f.punkte.length === 0 ? '   (keine Messminute)' : ''));
  }
  if (F.length > zeigen) z('   .. ' + (F.length - zeigen) + ' weitere, aeltere Faelle (alle in der JSON).');
  z('');

  /* --- der gewaehlte Fall --------------------------------------------------------- */
  const fall = daten.fall;
  /* Deckt der Fall mehr als einen Kalendertag ab, tragen die Tabellen unten den Tag mit. */
  const mehrtaegig = tagNummer(fall.start) !== tagNummer(fall.ende);
  function zeitSpalte(minute) { return mehrtaegig ? tagUhr(minute) : nurUhr(minute); }
  const zBreite = mehrtaegig ? 12 : 5;

  z('---------------------------------------------------------------');
  z('  FALL ' + fall.nr + (fall.nr === 1 ? '  (der letzte)' : ''));
  z('---------------------------------------------------------------');
  z('  Start ................ ' + deutsch(fall.start));
  z('  Ende ................. ' + deutsch(fall.ende));
  z('  Dauer ................ ' + dauerText(fall.dauerMin));
  z('  Messminuten .......... ' + fall.punkte.length);
  /*
   * LUECKEN, DIREKT GEMESSEN. Frueher lud die Gleichheit "Dauer == Messminuten" dazu ein,
   * Lueckenlosigkeit anzunehmen; sie kann ihren eigenen Anlass nicht sehen (Begruendung im
   * Dateikopf). Deshalb steht hier die gemessene Angabe - und wenn keine Minute fehlt, steht
   * das ausdruecklich da, statt dass die Zeile fehlt.
   */
  if (!fall.punkte.length) {
    z('  Luecken .............. nicht pruefbar (keine Messminute in diesem Fall)');
  } else if (!fall.luecken.length) {
    z('  Luecken .............. keine (die Messminuten liegen lueckenlos hintereinander)');
  } else {
    let fehlen = 0, groesste = fall.luecken[0];
    fall.luecken.forEach(function (l) { fehlen += l.minuten; if (l.minuten > groesste.minuten) groesste = l; });
    z('  ! Luecken ............ ' + fall.luecken.length + ' (' + fehlen +
      ' Minuten fehlen, groesste ' + groesste.minuten + ' min nach ' + zeitSpalte(groesste.von) + ')');
  }
  z('  Zeiten aus ........... ' + fall.quelleZeiten);
  z('  End-Case-Marke ....... ' + (fall.marke ? deutsch(fall.marke.minute) : 'keine'));
  z('');

  if (fall.punkte.length) {
    z('  UEBERSICHT (nur Minuten, in denen das Geraet gemessen hat)');
    z('    Wert              min     Mittel        max   gemessen');
    z('    ----------  ---------  ---------  ---------  ---------');
    const zeilen = [
      ['FiCO2 mmHg', 'fico2', 0], ['EtCO2 mmHg', 'etco2', 0],
      ['MAX cmH2O', 'max', 0], ['PEEP cmH2O', 'peep', 0],
      ['Vt ml', 'vt', 0], ['MV l/min', 'mv', 1], ['AF /min', 'af', 0]
    ];
    zeilen.forEach(function (r) {
      const s = statistik(fall.punkte, r[1]);
      z('    ' + ausrichten(r[0], 10) + '  ' + rechts(s.min == null ? '-' : s.min.toFixed(r[2]), 9) +
        '  ' + rechts(s.mittel == null ? '-' : s.mittel.toFixed(1), 9) +
        '  ' + rechts(s.max == null ? '-' : s.max.toFixed(r[2]), 9) +
        '  ' + rechts(s.n + '/' + fall.punkte.length, 9));
    });
    z('');

    z('  MINUTENWERTE' + (mehrtaegig ? '' : '  (alle am ' + nurTag(fall.start) + ')'));
    z('    ' + ausrichten('Zeit', zBreite) + '   FiCO2  EtCO2    MAX   PEEP     Vt     MV     AF');
    z('    ' + new Array(zBreite + 1).join('-') + '  ------ ------ ------ ------ ------ ------ ------');
    const grenze = 240;
    fall.punkte.slice(0, grenze).forEach(function (p) {
      z('    ' + ausrichten(zeitSpalte(p.minute), zBreite) + '  ' + wert(p.fico2) + ' ' + wert(p.etco2) + ' ' +
        wert(p.max) + ' ' + wert(p.peep) + ' ' + wert(p.vt) + ' ' +
        wert(p.mv == null ? null : p.mv.toFixed(1)) + ' ' + wert(p.af));
    });
    if (fall.punkte.length > grenze) {
      z('    .. ' + (fall.punkte.length - grenze) + ' weitere Minuten (vollstaendig nur in der JSON).');
    }
    z('');
  } else {
    z('  Zu diesem Fall steht keine einzige Trendminute im Speicher.');
    z('');
  }

  /* Die Ereignisse kommen aus dem Fall selbst, nicht aus einer zweiten Liste daneben -
   * siehe die Begruendung ueber bericht(). */
  const ev = fall.ereignisse;
  z('  EREIGNISSE IN DIESEM FALL (' + ev.length + ')' +
    (mehrtaegig ? '' : '  (alle am ' + nurTag(fall.start) + ')'));
  if (!ev.length) z('    keine');
  ev.forEach(function (e) {
    const kurz = e.details.replace(/<br>/g, ' | ').replace(/\s*\|\s*$/, '').replace(/\s+/g, ' ').trim();
    z('    ' + zeitSpalte(e.minute) + ':' + (e.sekunde < 10 ? '0' : '') + e.sekunde + '  ' +
      ausrichten(e.was, 34) + '  ' + kurz.slice(0, 90));
  });
  z('');

  /* --- Datenschutz ----------------------------------------------------------------
   * Hier stand bis zum 29.08.2026 ein FESTER Satz ("Das Geraet fuehrt KEIN Namensfeld ...").
   * Er war eine Zusage, keine Messung, und an einem nachgestellten Export mit Namen blieb er
   * unveraendert stehen, waehrend die Namen sechs Zeilen darueber im Bericht standen. Jetzt
   * wird gemessen; die Begruendung und die Grenzen stehen im Dateikopf. -------------- */
  const ns = daten.namen;
  z('---------------------------------------------------------------');
  z('  DATENSCHUTZ - AM GELESENEN EXPORT GEMESSEN');
  z('---------------------------------------------------------------');
  z('  Dieser Abschnitt behauptet nichts ueber das Geraet. Er sagt, wonach in DIESEM');
  z('  Export gesucht wurde, wie viel durchsucht wurde und was dabei herauskam.');
  z('');
  z('  Durchsucht: ' + ns.felder + ' Felder aller ' + daten.tabellenAnzahl + ' Tabellen' +
    ' (' + ns.woerter + ' verschiedene Woerter),');
  z('              darunter ' + daten.protokollZeilen + ' Zeilen des Ereignisprotokolls.');
  z('');
  /* Der Wortlaut jeder Suche steht MIT im Bericht. "Gesucht wurde nach Namensfeldern" ohne
   * die Woerter waere wieder eine Behauptung - nachpruefbar wird es erst durch die Liste. */
  z('  GESUCHT WURDE NACH                                    GEFUNDEN');
  ns.suchen.forEach(function (s) {
    z('    ' + punkteAuf(s.kurz, 48) + '  ' + (s.treffer.length ? s.treffer.length + ' Stelle(n)' : 'nichts'));
    umbrechen(s.wonach, 78, '        ').forEach(z);
  });
  const netz = daten.netzadressen;
  const netzSonst = daten.netzadressenSonst;
  z('    ' + punkteAuf('Netzadresse (IPv4 oder MAC)', 48) + '  ' +
    ((netz.length + netzSonst.length) ? (netz.length + netzSonst.length) + ' Stelle(n)' : 'nichts'));
  z('        vier Zahlen mit Punkten (ohne fuehrende Null) oder sechs Bytes mit Doppelpunkten');
  z('');

  if (ns.treffer) {
    z('  ! GEFUNDEN: ' + ns.treffer + ' Stelle(n), die auf einen Personen- oder Tiernamen deuten.');
    ns.suchen.forEach(function (s) {
      if (!s.treffer.length) return;
      z('    ' + s.kurz + ':');
      s.treffer.slice(0, 20).forEach(function (tr) {
        z('      ' + tr.ort + '   Treffer "' + tr.fund + '"');
        z('        ' + tr.text);
      });
      if (s.treffer.length > 20) z('      .. ' + (s.treffer.length - 20) + ' weitere.');
    });
    z('    DIESER BERICHT SOLLTE SO NICHT WEITERGEGEBEN WERDEN. Die Fundstellen stehen im');
    z('    Klartext in der Datei und - soweit sie in den gewaehlten Fall fallen - auch oben');
    z('    in der Ereignisliste und in der JSON. Erst pruefen, dann weitergeben.');
    z('');
  }

  /*
   * DIE UMGEDREHTE AUSSAGE (29.08.2026, dritte Fassung).
   *
   * Hier stand zweimal eine Zusage, und zweimal hat eine unabhaengige Messung sie
   * widerlegt. Die erste behauptete rundheraus, es komme kein Name vor - ohne zu suchen.
   * Die zweite suchte, nannte als einzige Luecke aber "ein Name OHNE Merkmal" - und eine
   * dritte Pruefung wies nach, dass ihr auch Namen MIT vollem Merkmal entgingen
   * ("Patientenname: Minka", "Name: Minka", "Dr.Schulz", kyrillische Schrift).
   *
   * Daraus die Lehre, die hier festgehalten gehoert: eine Mustersuche auf Namen wird NIE
   * vollstaendig. Jede weitere Runde haette dieselbe Form gehabt - eine Zusage, die beim
   * naechsten Gegenbeispiel faellt. Deshalb sagt dieser Abschnitt jetzt, was der Bericht
   * IST, statt zu behaupten, was er nicht enthaelt. Die Suche bleibt - aber als HINWEIS,
   * nicht als Zusage. Die Verantwortung liegt damit dort, wo sie hingehoert: beim
   * Menschen, der die Datei weitergibt.
   *
   * Verwandt: die Notiz "Bericht ohne Fremdtext" - dort steht dieselbe Fehlerklasse fuer
   * den Sondenbericht. Der Unterschied: DORT war Freitext verzichtbar und wurde restlos
   * entfernt. HIER ist er der Zweck (das Narkoseprotokoll besteht daraus), also bleibt nur
   * die ehrliche Ansage.
   */
  z('  WAS DIESER BERICHT IST - und was die Suche oben NICHT leistet:');
  z('');
  z('    Dieser Bericht enthaelt den FREITEXT DES GERAETES, ungefiltert. Die Ereignis-');
  z('    zeilen stehen so darin, wie das Geraet sie geschrieben hat. Das ist Absicht:');
  z('    genau daraus besteht das Narkoseprotokoll.');
  z('');
  z('    Die Suche oben ist ein HINWEIS, KEINE ZUSAGE. Am 29.08.2026 wurde gemessen,');
  z('    dass ihr unter anderem entgeht:');
  z('      - ein Name in einer Sprache, die sie nicht kennt, in lateinischer Schrift');
  z('        (etwa tuerkisch: "Hasta sahibi: Ayse Yilmaz")');
  z('      - eine Feldbezeichnung, an die niemand gedacht hat');
  z('      - ein blosser Name ohne jedes Merkmal - "Minka" allein in einer Zeile');
  z('');
  z('    "Gefunden: nichts" heisst deshalb NUR: keines der oben genannten Merkmale kam');
  z('    vor. Es heisst NICHT, dass kein Name in der Datei steht.');
  z('');
  z('    WER DIESEN BERICHT WEITERGIBT, LIEST IHN VORHER. Das ist die einzige Zusage,');
  z('    die hier ehrlich zu machen ist.');
  z('');
  z('  Dieser Bericht enthaelt ausserdem folgende Kennungen, und zwar mit Absicht:');
  z('    - Geraete-ID und MAC-Adresse (' + (g.mac || '-') + ') - sie bezeichnen die Maschine.');
  z('    - Koerpergewicht, Tierart und Beatmungswerte, soweit sie in den Ereignissen stehen.');
  if (netz.length) {
    z('    - ' + netz.length + ' Zeile(n) des Ereignisprotokolls tragen eine NETZADRESSE der Praxis:');
    netz.slice(0, 12).forEach(function (n) {
      /* Die Adresse steht meist schon in der Beschriftung ("IP-Adresse: 192.168.0.52"). Nur
       * was dort NICHT steht - eine Adresse aus der Detailspalte - wird angehaengt, sonst
       * stuende sie zweimal in derselben Zeile und man liest ueber beide hinweg. */
      const fehlend = n.adressen.filter(function (a) { return n.was.indexOf(a) < 0; });
      z('        ' + deutsch(n.minute) + '  ' + n.was + (fehlend.length ? '   ' + fehlend.join(', ') : ''));
    });
    if (netz.length > 12) z('        .. ' + (netz.length - 12) + ' weitere.');
    z('      Oben aufgezaehlt sind sie vollstaendig, damit sie niemand uebersieht. In die');
    z('      Ereignisliste des Berichts und in die JSON geraten sie nur, wenn sie in den');
    z('      gewaehlten Fall fallen; die JSON nennt sonst nur ihre Anzahl.');
  } else {
    z('    - keine Netzadresse im Ereignisprotokoll gefunden.');
  }
  /* Der Melder laeuft ueber ALLE Tabellen, nicht nur ueber das Protokoll - vorher sah er
   * nur T_Data4, und eine Adresse in einer anderen Tabelle waere still durchgegangen. */
  if (netzSonst.length) {
    z('    - ' + netzSonst.length + ' Fundstelle(n) in den uebrigen Tabellen:');
    netzSonst.slice(0, 12).forEach(function (n) {
      z('        ' + n.tabelle + ' Feld ' + n.feld + '   ' + n.adressen.join(', '));
    });
    if (netzSonst.length > 12) z('        .. ' + (netzSonst.length - 12) + ' weitere.');
  } else {
    z('    - keine Netzadresse in den uebrigen Tabellen.');
  }
  z('      Was wortgleich in der Versionstabelle T_Data2 steht, gilt als Versionsnummer und');
  z('      nicht als Adresse - hier ' + (daten.versionsBloecke.length
    ? daten.versionsBloecke.length + ': ' + daten.versionsBloecke.join(', ')
    : 'keine einzige') + '.');
  z('');
  z('  Die .log-Dateien neben der HTML werden von diesem Programm NICHT geoeffnet.');
  z('');
  return L.join('\n');
}

/* =====================================================================================
 * 11. DAS GANZE ZUSAMMEN - auch von aussen benutzbar (der Test ruft genau das hier)
 * =================================================================================== */
function exportLesen(ziel, fallNr) {
  const datei = htmlFinden(ziel);
  const roh = datenLesen(datei);
  const text = roh.text;

  /*
   * ALLE Tabellen einsammeln, nicht nur die fuenf gebrauchten (29.08.2026). Die
   * Datenschutz-Messung muss ueber den ganzen Bestand laufen: eine Adresse oder ein Name in
   * T_Data7 waere sonst nie gesucht worden, und "0 Treffer" haette dann nur geheissen, dass
   * dort niemand hingesehen hat. Welche es gibt, sagt die Datei selbst - hier wird nichts
   * durchgezaehlt und nichts angenommen.
   */
  const tabellen = [];
  const nachName = {};
  const reTab = /var (T_Data\d+) = \[/g;
  let mTab;
  while ((mTab = reTab.exec(text))) {
    if (nachName[mTab[1]]) continue;                 /* dieselbe Tabelle nur einmal */
    const felder = jsFeld(text, mTab[1]);
    if (!felder) continue;
    nachName[mTab[1]] = felder;
    tabellen.push({ name: mTab[1], felder: felder });
  }
  const f0 = nachName['T_Data0'] || null;
  const f1 = nachName['T_Data1'] || null;
  const f2 = nachName['T_Data2'] || null;
  const f3 = nachName['T_Data3'] || null;
  const f4 = nachName['T_Data4'] || null;
  if (!f3) throw new Error('In dieser Datei gibt es kein T_Data3 - das ist kein Veta-Export.');
  if (!f4) throw new Error('In dieser Datei gibt es kein T_Data4 - das ist kein Veta-Export.');

  /* T_Data0 ist eine Zwei-Spalten-Tabelle (Bezeichnung, Wert) mit Kopfzeile ab Feld 0.
   * Zugegriffen wird ueber die BEZEICHNUNG, nicht ueber die Stellung. */
  const geraetPaare = {};
  if (f0) for (let i = 0; i + 1 < f0.length; i += 2) geraetPaare[entzeichnen(f0[i])] = entzeichnen(f0[i + 1]);
  const geraet = {
    typ: geraetPaare['Ger\u00e4tetyp'] || geraetPaare['Device type'] || null,
    id: geraetPaare['Ger\u00e4te-ID'] || geraetPaare['Device ID'] || null,
    mac: geraetPaare['MAC-Adresse'] || geraetPaare['MAC address'] || null,
    betriebszeit: f1 ? paare(f1, 2) : [],
    software: f2 ? paare(f2, 3) : []
  };

  const trend = trendLesen(text, f3);
  const protokoll = protokollLesen(f4);
  const gebildet = faelleBilden(trend, protokoll);

  const nr = fallNr || 1;
  const fall = gebildet.faelle[nr - 1] || null;
  /* Nur EINE Quelle fuer die Ereignisse des gewaehlten Falls: die Liste am Fall selbst.
   * Eine zweite Liste daneben war genau der Grund, warum bericht(daten, 3) die Ereignisse
   * von Fall 1 drucken konnte. */
  const ereignisse = fall ? fall.ereignisse : [];

  const raus = versionsBloecke(tabellen);

  return {
    datei: datei,
    bytes: roh.bytes,
    geraet: geraet,
    trend: trend,
    tabellen: tabellen,
    tabellenAnzahl: tabellen.length,
    protokollZeilen: protokoll.length,
    protokoll: protokoll,
    faelle: gebildet.faelle,
    ohneFall: gebildet.ohneFall,
    markenOhneFall: gebildet.markenOhneFall,
    ersatzweise: gebildet.ersatzweise,
    verworfen: gebildet.verworfen,
    doppelte: gebildet.doppelte,
    doppelteImFenster: gebildet.doppelteImFenster,
    gewaehlt: nr,
    fall: fall,
    ereignisse: ereignisse,
    namen: namenSuchen(tabellen, protokoll),
    versionsBloecke: Object.keys(raus),
    netzadressen: netzadressen(protokoll, raus),
    netzadressenSonst: netzfundeInTabellen(tabellen, raus)
  };
}

/* Fuer die JSON: ohne die Rohtexte und ohne die doppelte Ablage aller Punkte.
 * Der gewaehlte Fall bekommt seine Minuten und Ereignisse VOLLSTAENDIG, die uebrigen Faelle
 * nur ihre Eckdaten - sonst stuende dieselbe Zahl zweimal in derselben Datei. */
function fuerJson(d) {
  return {
    erzeugtVon: 'tools/veta-export-lesen.js',
    hinweisZeitzone: 'Alle Zeiten sind die Ortszeit des Geraetes. Das Geraet exportiert keine Zeitzone; ' +
      'deshalb steht in den ISO-Zeiten weder Z noch ein Zonenversatz.',
    geraet: {
      typ: d.geraet.typ, id: d.geraet.id, mac: d.geraet.mac,
      betriebszeit: d.geraet.betriebszeit, software: d.geraet.software
    },
    trend: {
      spalten: d.trend.spalten,
      zeilen: d.trend.zeilen,
      messminuten: d.trend.punkte.length,
      marken: d.trend.marken,
      von: iso(d.trend.von), bis: iso(d.trend.bis),
      punkte: d.trend.punkte
    },
    spaltenbreite: {
      wert: d.trend.breite,
      ausCreateTable: d.trend.breiteAusAufruf,
      ausFeldinhalt: d.trend.breiteAusFeld,
      /* Ohne diese Zeile stuende in der JSON eine Breite, der man nicht ansieht, ob sie von
       * einem oder von zwei unabhaengigen Wegen getragen wird. */
      wege: d.trend.breiteAusAufruf == null ? 1 : 2
    },
    faelle: d.faelle.map(function (f) {
      return {
        nr: f.nr, start: iso(f.start), ende: iso(f.ende), dauerMin: f.dauerMin,
        quelleZeiten: f.quelleZeiten, beendet: f.beendet,
        messminuten: f.punkte.length,
        luecken: f.luecken.map(function (l) { return { nach: iso(l.von), vor: iso(l.bis), minuten: l.minuten }; }),
        ohneMessminute: f.punkte.length === 0,
        endCaseMarke: f.marke ? f.marke.zeit : null
      };
    }),
    faelleAus: d.ersatzweise ? 'End-Case-Marken der Trendliste' : 'Ereignisprotokoll',
    /* Was das Protokoll hergab und trotzdem kein Fall wurde - in der JSON genauso benannt
     * wie im Bericht, sonst waere die JSON die freundlichere Fassung derselben Daten. */
    verworfeneFallEintraege: (d.verworfen || []).map(function (v) {
      return { start: iso(v.start), ende: iso(v.ende), grund: v.grund };
    }),
    zusammengefassteDoppelEintraege: d.doppelte || 0,
    minutenOhneFall: d.ohneFall.length,
    gewaehlterFall: d.fall ? {
      nr: d.fall.nr, start: iso(d.fall.start), ende: iso(d.fall.ende), dauerMin: d.fall.dauerMin,
      punkte: d.fall.punkte,
      ereignisse: d.ereignisse.map(function (e) {
        return { zeit: e.zeit, was: e.was, details: e.details.replace(/<br>/g, ' | ') };
      })
    } : null,
    protokollZeilen: d.protokollZeilen,
    /*
     * DIE MESSUNG, NICHT DIE ZUSAGE. Die JSON kann den Praxis-PC genauso verlassen wie der
     * Bericht; also steht auch in ihr, wonach gesucht wurde und was gefunden wurde - samt der
     * Grenze. Eine JSON, die nur "netzadressenImProtokoll: 4" sagt, laesst den Leser glauben,
     * es sei nach mehr gesucht worden.
     */
    datenschutz: {
      durchsuchteFelder: d.namen.felder,
      durchsuchteTabellen: d.tabellenAnzahl,
      verschiedeneWoerter: d.namen.woerter,
      gesuchtNach: d.namen.suchen.map(function (s) {
        return { merkmal: s.kurz, treffer: s.treffer.length, fundstellen: s.treffer.map(function (t) { return t.ort; }) };
      }),
      grenze: 'Gesucht wird nach MERKMALEN (Feldbezeichnung, Anrede, @-Zeichen, Ziffernfolge). ' +
        'Ein blosser Name ohne Merkmal wird NICHT gefunden. "0 Treffer" heisst "kein Merkmal ' +
        'gefunden" und ist kein Beweis, dass kein Name in der Datei steht.',
      netzadressenImProtokoll: d.netzadressen.length,
      netzadressenInUebrigenTabellen: d.netzadressenSonst.length,
      alsVersionAusgenommen: d.versionsBloecke
    },
    netzadressenImProtokoll: d.netzadressen.length
  };
}

/* =====================================================================================
 * 12. AUFRUF VON DER BEFEHLSZEILE
 * =================================================================================== */
function hilfe() {
  console.log('');
  console.log('  Veta 5 Plus - USB-Export lesen');
  console.log('');
  console.log('  node tools/veta-export-lesen.js <Ordner ODER HTML-Datei> [--fall <n>] [--json <Datei>]');
  console.log('');
  console.log('    <Ordner>     der Ordner, den "SysDat exp" auf den Stick geschrieben hat.');
  console.log('                 Die HTML darin wird selbst gefunden.');
  console.log('    --fall <n>   welchen Fall zeigen. 1 = der letzte (Vorgabe).');
  console.log('    --json <D>   die Auswertung zusaetzlich als JSON schreiben.');
  console.log('');
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  let ziel = null, jsonZiel = null, fallNr = 1;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--json') { jsonZiel = argv[++i]; continue; }
    if (argv[i] === '--fall') { fallNr = parseInt(argv[++i], 10); continue; }
    if (argv[i] === '--hilfe' || argv[i] === '-h' || argv[i] === '--help') { hilfe(); process.exit(0); }
    if (!ziel) ziel = argv[i];
  }
  if (!ziel) { hilfe(); process.exit(1); }
  if (!(fallNr >= 1)) { console.error('  --fall braucht eine Zahl ab 1 (1 = der letzte Fall).'); process.exit(1); }

  let daten;
  try {
    daten = exportLesen(ziel, fallNr);
  } catch (e) {
    console.error('');
    console.error('  Der Export liess sich nicht lesen:');
    console.error('  ' + e.message);
    console.error('');
    process.exit(1);
  }

  /*
   * EINE UNBEKANNTE FALLNUMMER ERZEUGT KEINEN BERICHT (29.08.2026).
   * Frueher kehrte bericht() bei "--fall 99" mitten im Text zurueck. Uebrig blieben
   * Geraete-ID, MAC und elf Fallzeiten - ohne den Datenschutz-Abschnitt, der Rechenschaft
   * darueber ablegt, und mit Exitcode 0. So sieht ein Ergebnis aus, ist aber keines.
   * Exitcode 2 wie bei tools/pds-feldsonde.js mit "--nur <unbekannt>": falscher Aufruf.
   */
  if (!daten.fall) {
    console.error('');
    console.error('  Diesen Fall gibt es nicht: --fall ' + fallNr);
    if (daten.faelle.length) {
      console.error('  Der Export enthaelt ' + daten.faelle.length + ' Faelle; waehlbar ist 1 bis ' +
        daten.faelle.length + ' (1 = der letzte).');
    } else {
      console.error('  Der Export enthaelt ueberhaupt keinen Fall: weder das Ereignisprotokoll');
      console.error('  noch eine "End Case"-Marke nennt einen im Trendzeitraum.');
    }
    console.error('  Es wurde KEIN Bericht erzeugt und keine JSON geschrieben.');
    console.error('');
    process.exit(2);
  }

  console.log(bericht(daten, fallNr));

  /*
   * Der Fund steht mitten im Bericht - und wer ihn in eine Datei umleitet, sieht ihn dort
   * nicht. Deshalb dieselbe Warnung noch einmal auf den Fehlerkanal, der nicht mitumgeleitet
   * wird. KEIN Abbruch und kein Exitcode ungleich 0: der Bericht ist richtig, nur nicht zur
   * Weitergabe geeignet, und das zu entscheiden ist Sache des Tierarztes.
   */
  if (daten.namen.treffer) {
    console.error('  ! ' + daten.namen.treffer + ' Stelle(n) im Export deuten auf einen Personen- oder Tiernamen.');
    console.error('    Siehe den Abschnitt DATENSCHUTZ am Ende des Berichts. Vor dem Weitergeben pruefen.');
  }

  if (jsonZiel) {
    fs.writeFileSync(jsonZiel, JSON.stringify(fuerJson(daten), null, 2), 'utf8');
    console.log('  JSON geschrieben: ' + jsonZiel);
    console.log('');
  }
}

module.exports = {
  exportLesen: exportLesen,
  bericht: bericht,
  fuerJson: fuerJson,
  jsFeld: jsFeld,
  trendLesen: trendLesen,
  protokollLesen: protokollLesen,
  faelleBilden: faelleBilden,
  minuteAus: minuteAus,
  zahl: zahl,
  co2Paar: co2Paar,
  markierung: markierung,
  htmlFinden: htmlFinden,
  netzadressen: netzadressen,
  netzfundeInTabellen: netzfundeInTabellen,
  versionsBloecke: versionsBloecke,
  namenSuchen: namenSuchen,
  NAMENSMERKMALE: NAMENSMERKMALE,
  SPALTEN: SPALTEN
};
