'use strict';
/*
 * statik-server.js — reiner Dateiserver fuer die Vorschau der oeffentlichen Web-App.
 *
 * WARUM: die Projektregeln nennen "canis-web (Port 8792)" als Vorschauweg, und der dafuer
 * hinterlegte Starteintrag zeigte auf einen Arbeitsordner einer laengst beendeten Sitzung.
 * Ein dokumentierter Weg, der ins Leere zeigt, ist schlimmer als keiner - man haelt ihn
 * fuer vorhanden. Dieses Skript ersetzt ihn.
 *
 * Welche Datei diesen Eintrag traegt, steht hier seit dem 29.08.2026 mit Absicht nicht mehr:
 * es ist die Sitzungsdatei eines Entwicklungswerkzeugs, und tools/ faehrt vollstaendig im
 * oeffentlichen Update-Zip mit, das jede fremde Station laedt.
 *
 * Aufruf: node statik-server.js <wurzel> <port>
 * Nur GET, nur innerhalb der Wurzel, kein Verzeichnislisting.
 */
var http = require('http');
var fs = require('fs');
var path = require('path');

var WURZEL = path.resolve(process.argv[2] || '.');
var PORT = Number(process.argv[3] || 8792);

var TYPEN = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};

http.createServer(function (req, res) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405); res.end('nur GET'); return;
  }
  var rel = decodeURIComponent(String(req.url).split('?')[0]);
  if (rel === '/' || rel === '') rel = '/index.html';
  var ziel = path.normalize(path.join(WURZEL, rel));
  /* Pfaddurchbruch: startsWith allein passt auch auf einen Geschwisterordner, dessen Name mit
   * demselben Text beginnt - deshalb mit Trennzeichen vergleichen. */
  if (ziel !== WURZEL && ziel.indexOf(WURZEL + path.sep) !== 0) {
    res.writeHead(403); res.end('ausserhalb der Wurzel'); return;
  }
  fs.stat(ziel, function (e, s) {
    if (e || !s.isFile()) {
      if (!e && s.isDirectory()) { ziel = path.join(ziel, 'index.html'); }
      else { res.writeHead(404); res.end('nicht gefunden: ' + rel); return; }
    }
    fs.readFile(ziel, function (e2, d) {
      if (e2) { res.writeHead(404); res.end('nicht lesbar'); return; }
      res.writeHead(200, {
        'Content-Type': TYPEN[path.extname(ziel).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'no-cache',
      });
      res.end(req.method === 'HEAD' ? undefined : d);
    });
  });
}).listen(PORT, '127.0.0.1', function () {
  console.log('Statikserver: http://127.0.0.1:' + PORT + '  Wurzel: ' + WURZEL);
});
