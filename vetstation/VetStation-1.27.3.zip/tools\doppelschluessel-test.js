'use strict';
/*
 * doppelschluessel-test.js — bewacht eine Fehlerklasse, die KEIN anderer Test sieht:
 * dasselbe Feld zweimal in einem Objektliteral.
 *
 * WARUM ES DIESE DATEI GIBT, mit dem gemessenen Schaden vom 18.08.2026:
 *
 *   In ui/app/anaes-data.js endete der Naloxon-Eintrag fuer das Kaninchen auf
 *       ",notes:'',caution:''"
 *   Beim Nachtragen einer belegten Warnung wurde diese davor eingefuegt. In einem
 *   Objektliteral gewinnt der LETZTE Schluessel - der neue Text verschwand spurlos.
 *   Die Datei laedt fehlerfrei, "node --check" ist gruen, alle 83 Testdateien blieben gruen,
 *   und im Browser stand an der Stelle nichts. Aufgefallen ist es nur, weil danach die
 *   GELADENE Struktur nachgelesen wurde statt der Datei.
 *
 *   Das ist die gefaehrlichere Haelfte des Musters: bei einer Warnung faellt das Fehlen
 *   niemandem auf. Bei einer Dosis waere es dasselbe - "low:0.01,...,low:0.1" laedt genauso
 *   fehlerfrei und zeigt die zehnfache Zahl.
 *
 * WARUM EIN TOKENSTROM UND KEIN REGEX. Beim ersten Versuch meldete die Suche 162 Treffer im
 * Baum, von denen KEINER echt war. Drei Fallen, jede einzeln gemessen:
 *   - Zeichenketten und Kommentare: "Quelle: Plumb 1999a" ist kein Schluessel.
 *   - Ternaer: in "{ x: c ? lo : hi }" steht vor dem zweiten Doppelpunkt "lo". Das allein
 *     erklaerte den groessten Teil der 162.
 *   - Regexliteral mit Anfuehrungszeichen: ui/views/admin.js Zeile 15 enthaelt /[&<>"]/g.
 *     Wer das " fuer einen Zeichenkettenbeginn haelt, ist fuer den REST DER DATEI aus dem
 *     Takt und meldet danach beliebigen Unsinn. Das waren die letzten 5 Fehltreffer.
 * Deshalb steht unten eine Selbstprobe mit allen drei Fallen. Ein Sucher, der seine eigenen
 * Testfaelle nicht besteht, meldet beruhigende Nullen - genau das Muster, vor dem
 * die Projektregeln warnen.
 *
 * Start: node tools/doppelschluessel-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var BACKSLASH = String.fromCharCode(92);

var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

function istWortzeichen(c) { return /[A-Za-z0-9_$]/.test(c); }

/* Ein "/" beginnt nur dann ein Regexliteral, wenn davor kein Wert steht. Nach einem Wort,
   einer Zahl oder einer schliessenden Klammer ist es eine Division. */
function kannRegexBeginnen(vorher) {
  if (vorher == null) return true;
  return !/[A-Za-z0-9_$)\]]/.test(vorher);
}

function scanne(quelle) {
  var i = 0, n = quelle.length, treffer = [];
  var stapel = [{ keys: {}, fragen: 0 }];
  var wort = null, wortPos = -1, letztesBedeutend = null;
  function oben() { return stapel[stapel.length - 1]; }
  while (i < n) {
    var c = quelle[i];
    if (c === '/' && quelle[i + 1] === '/') { while (i < n && quelle[i] !== '\n') i++; continue; }
    if (c === '/' && quelle[i + 1] === '*') { var e = quelle.indexOf('*/', i + 2); i = (e < 0 ? n : e + 2); continue; }
    if (c === '/' && kannRegexBeginnen(letztesBedeutend)) {
      i++;                                   /* Regexliteral ueberspringen, Klassen beachten */
      var inKlasse = false;
      while (i < n) {
        if (quelle[i] === BACKSLASH) { i += 2; continue; }
        if (quelle[i] === '[') inKlasse = true;
        else if (quelle[i] === ']') inKlasse = false;
        else if (quelle[i] === '/' && !inKlasse) { i++; break; }
        else if (quelle[i] === '\n') break;   /* kein Regex - Notausstieg */
        i++;
      }
      while (i < n && /[gimsuy]/.test(quelle[i])) i++;
      wort = null; letztesBedeutend = ')'; continue;   /* zaehlt als Wert */
    }
    if (c === '"' || c === "'" || c === '`') {
      var q = c, start = i; i++;
      while (i < n) {
        if (quelle[i] === BACKSLASH) { i += 2; continue; }
        if (quelle[i] === q) { i++; break; }
        i++;
      }
      wort = quelle.slice(start + 1, i - 1); wortPos = start; letztesBedeutend = q; continue;
    }
    if (c === '{' || c === '(' || c === '[') { stapel.push({ keys: {}, fragen: 0 }); i++; wort = null; letztesBedeutend = c; continue; }
    if (c === '}' || c === ')' || c === ']') { if (stapel.length > 1) stapel.pop(); i++; wort = null; letztesBedeutend = c; continue; }
    if (c === '?') {
      if (quelle[i + 1] === '.' || quelle[i + 1] === '?') { i += 2; wort = null; letztesBedeutend = '?'; continue; }
      oben().fragen++; i++; wort = null; letztesBedeutend = '?'; continue;
    }
    if (c === ':') {
      var o = oben();
      if (o.fragen > 0) { o.fragen--; }
      else if (wort && wort !== 'case' && wort !== 'default') {
        if (Object.prototype.hasOwnProperty.call(o.keys, wort)) treffer.push({ k: wort, pos: wortPos, erste: o.keys[wort] });
        else o.keys[wort] = wortPos;
      }
      i++; wort = null; letztesBedeutend = ':'; continue;
    }
    if (c === ';') { oben().fragen = 0; i++; wort = null; letztesBedeutend = ';'; continue; }
    if (istWortzeichen(c)) {
      var j = i; while (j < n && istWortzeichen(quelle[j])) j++;
      wort = quelle.slice(i, j); wortPos = i; letztesBedeutend = quelle[j - 1]; i = j; continue;
    }
    if (/\s/.test(c)) { i++; continue; }
    wort = null; letztesBedeutend = c; i++;
  }
  return treffer;
}

function zeile(s, pos) { return s.slice(0, pos).split('\n').length; }

console.log('VetStation — doppelte Schluessel in Objektliteralen\n');

/* ---- 1) Der Sucher muss zuerst sich selbst bestehen ---- */
console.log('1) Selbstprobe des Suchers:');
var PROBEN = [
  ['var x={a:1,b:2,a:3};', 1, 'echte Doppelung'],
  ['var x={a:1,notes:2,caution:3,notes:4};', 1, 'der Fall vom 18.08.2026'],
  ["var s='nicht: hier';", 0, 'Doppelpunkt in Zeichenkette'],
  ['/* auch nicht: hier */ var y=1;', 0, 'Doppelpunkt im Kommentar'],
  ['var z={w: c ? lo : hi, v: 2};', 0, 'Ternaer im Wert'],
  ['var z={w: a?b:c, x: d?e:f};', 0, 'zwei Ternaere'],
  ['switch(k){case a: break; case b: break;}', 0, 'case-Marken'],
  ['var o={x:{a:1},y:{a:2}};', 0, 'gleicher Schluessel, andere Ebene'],
  ['var o={"a":1,"a":2};', 1, 'Schluessel in Anfuehrungszeichen'],
  ['var o={a:1, b: p?.q, c: r??s};', 0, 'Optional-Chaining und Nullish'],
  ['var f=String(s).replace(/[&<>"]/g,x); var o={a:1,b:2};', 0, 'Regexliteral mit Anfuehrungszeichen'],
  ['var o={a:1}; var q=b/c; var r={d:1,d:2};', 1, 'Division ist kein Regex'],
];
PROBEN.forEach(function (p) {
  var t = scanne(p[0]).length;
  ok(p[2] + ' → ' + p[1] + ' Treffer', t === p[1], 'bekommen: ' + t);
});

/* ---- 2) Der Baum selbst ---- */
console.log('\n2) Der Quellbaum:');
var dateien = [];
function sammle(dir) {
  fs.readdirSync(dir, { withFileTypes: true }).forEach(function (e) {
    var p = path.join(dir, e.name);
    if (e.isDirectory()) { if (!/node_modules|dist|[.]git/.test(p)) sammle(p); }
    else if (/[.]js$/.test(e.name) && !/[.]min[.]js$/.test(e.name)) dateien.push(p);
  });
}
['ui', 'bridge/src', 'updater', 'tools'].forEach(function (d) {
  var p = path.join(WURZEL, d);
  if (fs.existsSync(p)) sammle(p);
});

var funde = [];
dateien.forEach(function (p) {
  var s = fs.readFileSync(p, 'utf8');
  scanne(s).forEach(function (x) {
    funde.push(path.relative(WURZEL, p) + ':' + zeile(s, x.pos) + '  "' + x.k + '" schon in Zeile ' + zeile(s, x.erste));
  });
});
ok(dateien.length + ' Dateien durchsucht, kein doppelter Schluessel', funde.length === 0,
  funde.slice(0, 8).join(' | '));

/* ---- 3) Und die Stelle, an der es passiert ist, noch einmal ausdruecklich ---- */
console.log('\n3) Der Eintrag, an dem der Fehler auftrat:');
var win = {};
(new Function('window', fs.readFileSync(path.join(WURZEL, 'ui/app/anaes-data.js'), 'utf8')))(win);
var nal = (win.ANAES.drugs || []).filter(function (d) { return d.id === 'naloxon'; })[0];
var kan = nal && nal.species && nal.species.kaninchen;
ok('Naloxon/Kaninchen hat wieder eine Warnung', !!(kan && kan.caution && kan.caution.length > 40),
  'caution: ' + JSON.stringify(kan && kan.caution));
ok('und die Zahl steht unveraendert bei 0,01–0,1 mg/kg', !!(kan && kan.low === 0.01 && kan.high === 0.1),
  'gefunden: ' + (kan && kan.low) + '-' + (kan && kan.high));

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
