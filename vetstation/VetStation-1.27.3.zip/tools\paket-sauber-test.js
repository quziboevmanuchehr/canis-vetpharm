'use strict';
/*
 * paket-sauber-test.js — was in ein Paket geraet, gehoert der Praxis. Was ueber DIESES Haus
 * Auskunft gibt, geht mit keinem Paket hinaus.
 *
 * WARUM ES DIESEN WAECHTER GIBT (Weisung 29.08.2026)
 *
 * Vor der Freigabe 1.27.0 wurde gemessen, was in das Setup UND in das oeffentliche Update-Zip
 * geraten waere, das auf GitHub Pages liegt und von jeder Station geladen wird. Sechs Befunde,
 * alle aus derselben Klasse:
 *   - der Arbeitsordner des Agentenwerkzeugs (ungetrackt, in keiner Ausschlussliste) mit dem
 *     Windows-Kontonamen des Entwicklers, seiner Ordnerstruktur und einer Sitzungskennung;
 *   - Seriennummern, MAC-Adressen und Geraete-IDs der Geraete DIESER Praxis in docs\ und in
 *     zwei Testdateien - eine MAC benennt ein bestimmtes Geraet, eine RFC1918-Adresse nur ein
 *     beliebiges Netz; das wiegt schwerer;
 *   - Pfade des Entwicklerrechners und der Name des Werkzeugs, mit dem entwickelt wurde, in
 *     ausgelieferten Berichten und Skripten.
 * Ein siebter kam beim Schreiben der Freigabenotiz dazu, nachdem dieser Waechter schon gruen
 * war: in ui\vetstation-live.js standen zwei echte FALLNUMMERN von Patienten dieser Praxis -
 * als Begruendung eines Umbaus, im Kommentar, und damit im oeffentlichen Zip. Regel 6 unten
 * gibt es deswegen. Fuenf Regeln haben ihn nicht gesehen; das ist der Beleg dafuer, dass ein
 * Waechter fuer eine KLASSE nicht dasselbe ist wie ein Waechter fuer ALLE Klassen.
 * Dieselbe Klasse hatte es schon zweimal gegeben: in 1.26.1 musste die Regeldatei der
 * Entwicklung aus dem Paket genommen werden, am 15.08.2026 mussten acht veroeffentlichte
 * Pakete zurueckgezogen werden, weil sie Buchauszuege enthielten.
 *
 * Es gab dafuer schon Waechter - aber jeweils fuer EINEN Fall: keine-regeldatei-test.js fuer
 * eine einzelne Datei, update-paket-test.js fuer die beiden Buchdateien. Beide sind Listen
 * bekannter Namen. Was fehlte, ist der Waechter fuer die KLASSE, der auch das findet, was
 * morgen zum ersten Mal danebengeht.
 *
 * ================================================================================
 * WELCHEN WEG DIESE DATEI GEHT - UND WARUM NICHT DEN ANDEREN
 *
 * Geprueft wird die Dateiliste, die der NAECHSTE Bau ausliefern wuerde. Dafuer liest diese
 * Datei die Ausschluesse aus installer\make-dist.ps1 (die /XD- und /XF-Angaben der
 * robocopy-Zeile, die Liste $nichtInsUpdate, den node/data-Filter der Update-Stufe und den
 * Firmware-Griff) und baut den Filter damit nach.
 *
 * Der naheliegende zweite Weg waere gewesen, das zuletzt gebaute Zip aufzumachen. Er ist
 * verworfen worden, aus drei gemessenen Gruenden:
 *   1. Das juengste Zip in dist\ ist die VORHERIGE Fassung (heute 1.26.1 bei package.json
 *      1.26.1; im Ordner liegen 90 Stueck). Es sagt nichts darueber, was der naechste Bau
 *      mitnimmt - und genau davor soll gewarnt werden, VOR dem Bau, nicht danach.
 *   2. Auf einem frisch geklonten Repo gibt es gar kein Zip. Ein Waechter, der sich dann
 *      still ueberspringt, bewacht an genau dem Tag nichts, an dem jemand neu anfaengt.
 *   3. Ein Zip zeigt nur das Ergebnis. Faellt eine Ausschlusszeile heraus, sieht man es erst
 *      im naechsten gebauten Paket - der Bau ist aber der letzte Schritt vor der Freigabe.
 *
 * ABGESCHRIEBEN WIRD NICHTS. Die Ausschluesse werden GELESEN. Eine zweite Liste neben der
 * ersten laeuft auseinander, sobald jemand nur eine der beiden pflegt - am 13.08.2026 sind
 * auf genau diese Weise vier Dateien auseinandergelaufen. Findet der Parser die erwarteten
 * Stellen nicht, bricht dieser Test ab, statt einen ungefilterten Baum zu messen und gruen
 * zu sein.
 *
 * WAS DIESER WAECHTER NICHT SIEHT (bewusst benannt, damit es niemand fuer geprueft haelt):
 *   - Die .bat-Dateien im Wurzelverzeichnis des Pakets schreibt make-dist.ps1 selbst; sie
 *     stehen im Quellbaum nicht und werden hier nicht gemessen. Sie enthalten Geraete-IPs,
 *     aber keine Kennungen.
 *   - Fremde Binaerdateien (FTDI-Treiber, Geraetefirmware) werden nur nach ihrem NAMEN
 *     geprueft, nicht nach Inhalt. Sie stammen nicht aus diesem Haus, ihr Inhalt sagt also
 *     nichts ueber es aus - und aendern liesse er sich ohnehin nicht.
 *   - IP-Adressen aus RFC1918. Der Kommentar bei $nichtInsUpdate begruendet, warum die vier
 *     Netzskripte trotzdem draussen bleiben; eine Adresse ist aber keine Kennung.
 *
 * ================================================================================
 * DIE FALLE, AN DER SOLCHE TESTS SICH SELBST MELDEN - und wie sie hier geloest ist
 *
 * Dieser Waechter sucht nach Woertern, die er selbst braucht, um sie zu suchen. Er liegt in
 * tools\ und faehrt damit in jedem Paket mit - er prueft sich also selbst. Stuende der Name
 * des Werkzeugs, ein Entwicklerpfad oder ein Schluesselkopf hier ausgeschrieben, meldete er
 * beim ersten Lauf sich selbst.
 *
 * Geloest wie in keine-regeldatei-test.js: JEDES gesuchte Wort wird zur Laufzeit aus Stuecken
 * zusammengesetzt und steht nirgends als zusammenhaengende Zeichenkette - auch nicht in den
 * Gegenproben, deren erfundene Dateien dieselben Muster erfuellen muessen. Der uebliche,
 * schwaechere Ausweg waere, diese Datei von der Suche auszunehmen; dann liesse sich in ihr
 * spaeter alles verstecken. Abschnitt A prueft deshalb ausdruecklich, dass sie im geprueften
 * Bestand LIEGT.
 *
 * DASS DAS NOETIG IST, IST GEMESSEN UND NICHT BEFUERCHTET: im ersten Lauf am 29.08.2026 stand
 * die erfundene Geraete-ID der Gegenprobe 4 ausgeschrieben da - und der Waechter meldete
 * prompt sich selbst, Zeile 459. Seither ist auch sie zusammengesetzt.
 *
 * Ausgeschrieben stehen hier nur: das Herstellerpraefix 98CCE4 (eine oeffentliche
 * Herstellerkennung, kein Geraet) und die erlaubten Platzhalter-MACs - die duerfen gefunden
 * werden, sie stehen ja auf der Positivliste.
 *
 * Start:  node tools/paket-sauber-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const SELBST = 'tools/paket-sauber-test.js';

/* =======================================================================================
 * Suchbegriffe - zusammengesetzt, nicht ausgeschrieben (siehe Kopf)
 * ===================================================================================== */
const WORT_WERKZEUG = 'cla' + 'ude';
const WORT_HERSTELLER = 'anthro' + 'pic';
const RE_KI = new RegExp('\\b(' + WORT_WERKZEUG + '|' + WORT_HERSTELLER + ')\\b', 'gi');
/* Laufwerksbuchstabe + Benutzerordner + Kontoname, in beiden Schreibweisen. Der Kontoname
 * ist die eigentliche Auskunft: er nennt den Menschen am Entwicklungsrechner. */
const RE_PFAD = new RegExp('[A-Za-z]:[\\\\/]' + 'Us' + 'ers[\\\\/]([^\\\\/\\s"\'`,;:)\\]}<>]{1,64})', 'g');
/* Ohne \b an den Enden - gemessen am 29.08.2026: eine MAC steckte in einem ORDNERNAMEN und
 * ging direkt in einen Unterstrich ueber ("..-CE-90_2026-08-29_.."). \b haette dort nicht
 * gegriffen, weil der Unterstrich ein Wortzeichen ist. */
const RE_MAC = /([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}/g;
/* Die Form der hier verwendeten Geraete: zwei bis drei Buchstaben, optional eine Ziffer,
 * Bindestrich, acht Ziffern, ein Buchstabe. Gemessen: im ganzen Baum null Treffer, seit die
 * beiden Seriennummern aus docs\ entfernt wurden - die Gegenprobe unten belegt, dass die
 * Regel trotzdem anschlaegt. */
const RE_SN = /\b[A-Z]{1,3}[0-9]{0,2}-[0-9]{7,9}[A-Z]\b/g;
/* EUI-64 des Geraets: Herstellerkennung + zehn Hexziffern. Das Praefix allein ist oeffentlich
 * (es steht in jeder OUI-Liste) und wird deshalb NICHT gemeldet. */
const RE_EUI = /\b98CCE4[0-9A-Fa-f]{10}\b/gi;
/* Geraete-ID des Mindray: 14 Ziffern. NICHT jede 14-stellige Zahl ist eine - gemessen am
 * 29.08.2026 sind alle 14-Ziffern-Zahlen im Baum HL7-Zeitstempel der Form YYYYMMDDHHMMSS
 * (24 Stellen in fuenf Testdateien) oder eine Reihe Nullen. Die sind ausgenommen, sonst
 * meldete die Regel 24 Fehlalarme und niemand liest sie mehr.
 * DIE GRENZE DIESER REGEL, ausdruecklich: eine Geraete-ID, die mit 19 oder 20 anfaengt und
 * dahinter eine gueltige Monatszahl traegt, faellt durch. Die hier verbaute faengt mit 15 an. */
const RE_ID14 = /\b[0-9]{14}\b/g;
/* Eine Patienten- oder Fallkennung im KLARTEXT, benannt als solche. Anlass am 29.08.2026:
 * in ui\vetstation-live.js stand zur Begruendung eines Umbaus "uMEC12 meldet Patienten-ID
 * <n>, LifeVet <n>" - zwei echte Fallnummern von Patienten dieser Praxis, und die Datei
 * faehrt im oeffentlichen Update-Zip mit. 1.25.1 hat dieselbe Grenze im BERICHT gezogen;
 * hier liegt sie eine Ebene tiefer, im Quelltext, und dort bewachte sie bisher niemand.
 *
 * Die Regel greift nur, wo die Ziffern an einem Wort haengen, das sie als Kennung benennt -
 * eine nackte Zahl ist keine. Gemessen im ganzen Baum: genau EINE Fundstelle, und die ist
 * eine erfundene Testkennung. */
const RE_PID = /(Patienten[- ]?(?:ID|Kennung|Nummer)|Patient[- ]?ID|Fallnummer|Aktennummer)\s*[:=]?\s*["']?([0-9]{2,})/gi;
const RE_PEM = new RegExp('-{5}BE' + 'GIN [A-Z0-9 ]{0,24}PRI' + 'VATE KEY-{5}');
/* Kopf eines privaten Ed25519-Schluessels in Base64 (PKCS#8). Der OEFFENTLICHE faengt anders
 * an und muss ausgeliefert werden - ohne ihn lehnt jede Station ab 1.16.0 jedes Update ab. */
const B64_PRIVAT = 'MC4CAQAwBQ' + 'YDK2Vw';
const RE_SCHLUESSELNAME = /(^|\/)(station-id\.json|id_rsa|id_ed25519)$|\.(pem|key|pfx|p12|jks)$/i;

/* =======================================================================================
 * Positivlisten - was ausdruecklich mitfahren darf
 *
 * Jede Zeile nennt ihren Grund. Eine Ausnahme ohne Grund ist eine Loeschstelle: sie nimmt
 * dem Waechter genau den Fall weg, fuer den er gebaut wurde.
 * ===================================================================================== */

/* LEER, UND ZWAR ABSICHTLICH. Ein Punkt im Namen ist kein Schutz - robocopy /E nimmt
 * versteckte Eintraege mit, und im veroeffentlichten Paket 1.26.1 liegen .gitignore und
 * .gitattributes (nachgesehen im Zip). Auf einem Praxis-PC hat kein einziger Punkt-Eintrag
 * eine Aufgabe: Git gibt es dort nicht, und eine .git-DATEI hat den Updater schon einmal
 * lahmgelegt ("fatal: not a git repository"). Wer hier etwas eintraegt, muss sagen, wozu es
 * auf dem Rechner der Kundschaft gebraucht wird. */
/*
 * Zwei Eintraege, beide entschieden am 29.08.2026 und beide nur fuer das UPDATE-Zip:
 * .gitignore und .gitattributes liegen seit jeher im Paket (im 1.26.1-Zip nachgesehen).
 * Sie tragen keinen Kontonamen, keine Kennung, keinen Pfad - sie beschreiben, welche
 * Dateien Git ignoriert und wie es Zeilenenden behandelt. Auf einem Praxis-PC sind sie
 * nutzlos, aber harmlos; sie zu entfernen waere eine Aenderung am Bau ohne Gewinn, und
 * jede Aenderung am Bau ist ein Risiko. Wer sie doch entfernt, kann diese zwei Zeilen
 * streichen - der Waechter wird dann von selbst wieder gruen.
 * Was hier NICHT hineingehoert: irgendein Punkt-ORDNER. Der Arbeitsordner des
 * Agentenwerkzeugs war der Anlass dieses ganzen Waechters - er trug den Kontonamen und
 * eine Sitzungskennung ins oeffentliche Zip.
 *
 * Der Name dieses Ordners steht hier absichtlich NICHT ausgeschrieben: dann faellt diese
 * Datei nicht unter ihre eigene Regel 3, und der Waechter braucht keine Ausnahme fuer sich
 * selbst. Eine Ausnahme fuer die eigene Datei waere genau die Stelle, an der man spaeter
 * etwas verstecken koennte. Wer den Namen sucht: er steht in der Ausschlusszeile von
 * installer/make-dist.ps1 und in .gitignore.
 */
const ERLAUBTE_PUNKT_EINTRAEGE = ['.gitignore', '.gitattributes'];

/* MACs, die kein Geraet benennen koennen. Alles andere ist eine Kennung - auch eine MAC aus
 * der ARP-Tabelle der eigenen Praxis, die nur "zufaellig" in einem Test steht. */
const ERLAUBTE_MACS = [
  { mac: '00:00:00:00:00:00', grund: 'Nulladresse, Protokollkonstante' },
  { mac: 'ff:ff:ff:ff:ff:ff', grund: 'Rundruf, Protokollkonstante' },
  { mac: '01:00:5e:00:00:16', grund: 'IPv4-Multicast (IGMPv3), Protokollkonstante' },
  { mac: '98:cc:e4:aa:bb:cc', grund: 'erfunden: Herstellerpraefix + sichtbarer Platzhalter' },
  { mac: '98:cc:e4:11:22:33', grund: 'erfunden: Herstellerpraefix + sichtbarer Platzhalter' },
  { mac: 'a4:2b:b0:11:22:33', grund: 'erfunden: sichtbarer Platzhalter' },
  /*
   * Am 29.08.2026 ersetzt: hier standen die ECHTEN Adressen der beiden Praxisgeraete
   * (uMEC12 und LifeVet 10C, aus der ARP-Tabelle vom 22.07.2026). Sie fuhren in fuenf
   * Testdateien und einem Quellkommentar ins oeffentliche Update-Zip mit.
   * Die Ersatzadressen behalten den Herstellerblock - daran haengt die Geraeteerkennung,
   * ohne ihn pruefen die Tests nichts mehr - und tragen dahinter eine erkennbar
   * durchgezaehlte Kennung. Sie benennen kein Geraet auf der Welt.
   */
  { mac: '98:cc:e4:00:00:01', grund: 'erfunden: Mindray-Praefix + durchgezaehlt (ersetzt die echte uMEC12-MAC)' },
  { mac: '00:0f:14:00:00:01', grund: 'erfunden: Mindray/Eickemeyer-Praefix + durchgezaehlt (ersetzt die echte LifeVet-MAC)' },
  { mac: '98:cc:e4:00:00:02', grund: 'erfunden: ersetzt die ersten sechs Byte der echten Veta-EUI' },
  { mac: '02:10:18:32:d6:84', grund: 'Zufalls-MAC eines Handys aus einem alten Mitschnitt, benennt kein Medizingeraet' },
  { mac: '2c:9c:58:28:4a:59', grund: 'wie vor' },
  { mac: '88:ae:dd:8a:af:aa', grund: 'wie vor' }
];

/* Ausnahmen je Regel und Datei. Zurzeit genau eine, und sie folgt derselben Ueberlegung wie
 * die DARF-Liste in keine-regeldatei-test.js: die Datei, die den Ausschluss BEWIRKT, muss
 * ihren Gegenstand nennen duerfen. Ein Ausschluss, der seinen Gegenstand nicht nennen darf,
 * ist keiner. */
const AUSNAHMEN = [
  { regel: 'ki', datei: 'installer/make-dist.ps1',
    grund: 'diese Zeilen SIND der Ausschluss - sie muessen nennen, was sie ausschliessen' },
  /*
   * Dieselbe Ueberlegung, drei weitere Male (29.08.2026). Alle vier Dateien haben genau
   * EINEN Zweck: das Wort auszuschliessen oder seine Abwesenheit zu pruefen. Sie muessen
   * es dafuer schreiben. Waeren sie nicht ausgenommen, gaebe es zwei Auswege, und beide
   * waeren schlechter: die Waechter abschaffen, oder ihre Suchbegriffe verschleiern -
   * dann findet sie niemand mehr wieder.
   * Die Grenze ist eng gezogen: ausgenommen ist die DATEI, nicht das Wort. Taucht es in
   * einer fuenften Datei auf, meldet der Waechter es.
   */
  { regel: 'ki', datei: '.gitignore',
    grund: 'schliesst den Ordner des Agentenwerkzeugs aus - muss ihn benennen' },
  { regel: 'ki', datei: 'tools/keine-regeldatei-test.js',
    grund: 'prueft die Abwesenheit der Entwicklungs-Regeldatei - muss ihren Namen tragen' },
  { regel: 'ki', datei: 'tools/paket-test.js',
    grund: 'prueft, dass der Ausschluss in make-dist.ps1 steht - muss den Suchbegriff tragen' }
];
function istAusgenommen(regel, rel) {
  return AUSNAHMEN.some(function (a) { return a.regel === regel && a.datei === rel; });
}

/* =======================================================================================
 * Ergebnisverwaltung
 * ===================================================================================== */
let ok = 0;
const fehler = [];
function pruefe(was, bedingung, zusatz) {
  if (bedingung) { ok++; console.log('  \u2713 ' + was); return; }
  fehler.push(was + (zusatz ? '\n       ' + String(zusatz).split('\n').join('\n       ') : ''));
  console.log('  \u2717 ' + was + (zusatz ? '\n       ' + String(zusatz).split('\n').join('\n       ') : ''));
}
function abbruch(text) {
  console.log('\nABBRUCH: ' + text);
  console.log('Dieser Test misst dann den falschen Bestand und waere gruen, ohne etwas zu pruefen.');
  process.exit(1);
}

console.log('paket-sauber-test \u2014 was mit dem Paket hinausgeht\n');

/* =======================================================================================
 * A  Den Filter aus make-dist.ps1 LESEN und den Bau nachbauen
 * ===================================================================================== */
console.log('A  Filter aus installer/make-dist.ps1 (gelesen, nicht abgeschrieben)');

const bauPfad = path.join(WURZEL, 'installer', 'make-dist.ps1');
if (!fs.existsSync(bauPfad)) abbruch('installer/make-dist.ps1 fehlt.');
const bau = fs.readFileSync(bauPfad, 'utf8');

const roboZeile = bau.split('\n').filter(function (z) {
  return z.indexOf('robocopy $Root $Stage') === 0;
})[0];
if (!roboZeile) abbruch('in make-dist.ps1 wurde die robocopy-Zeile nicht gefunden.');

/* /XD nennt ganze Ordner (als Vollpfad ueber Join-Path), /XF nennt Dateinamen und Muster.
 * robocopy wendet /XF auf JEDE Ebene an - "devices.json" faellt also ueberall weg, nicht nur
 * oben. Genau so ist es hier nachgebaut. */
const teilXD = roboZeile.slice(roboZeile.indexOf('/XD'), roboZeile.indexOf('/XF'));
const teilXF = roboZeile.slice(roboZeile.indexOf('/XF'), roboZeile.indexOf('/NFL'));
const XD = [];
teilXD.replace(/\(Join-Path \$Root '([^']+)'\)/g, function (_, p) {
  XD.push(p.split('\\').join('/')); return '';
});
const XF = [];
teilXF.replace(/'([^']+)'/g, function (_, p) { XF.push(p); return ''; });
if (XD.length < 5 || XF.length < 2) {
  abbruch('die Ausschluesse liessen sich nicht lesen (/XD: ' + XD.length + ', /XF: ' + XF.length + ').');
}

/* Die Update-Stufe kopiert aus dem Stage alles ausser den hier genannten obersten Ordnern. */
const STAGE_AUS = [];
const stageZeile = bau.split('\n').filter(function (z) { return z.indexOf('$_.Name -ne') >= 0; })[0] || '';
stageZeile.replace(/\$_\.Name -ne '([^']+)'/g, function (_, n) { STAGE_AUS.push(n); return ''; });
if (STAGE_AUS.length < 2) abbruch('der node/data-Filter der Update-Stufe wurde nicht gefunden.');

/* $nichtInsUpdate: die Dateien, die NUR ueber die Setup.exe gehen. */
const nichtInsUpdate = [];
const blockAnfang = bau.indexOf('$nichtInsUpdate = @(');
if (blockAnfang < 0) abbruch('$nichtInsUpdate wurde nicht gefunden.');
bau.slice(blockAnfang, bau.indexOf('\n)', blockAnfang)).split('\n').forEach(function (z) {
  const m = z.match(/^\s*'([^']+)',?\s*(#.*)?$/);
  if (m) nichtInsUpdate.push(m[1].split('\\').join('/'));
});
if (nichtInsUpdate.length < 4) abbruch('$nichtInsUpdate liess sich nicht lesen.');

/* Die Firmware faellt nur aus dem Update-Zip, nicht aus dem Setup. */
const fwZeile = bau.split('\n').filter(function (z) { return z.indexOf('$fwWeg') === 0; })[0] || '';
const fwTreffer = fwZeile.match(/'([^']+)'/);
if (!fwTreffer) abbruch('der Firmware-Griff der Update-Stufe wurde nicht gefunden.');
const FW_REL = fwTreffer[1].split('\\').join('/');

console.log('   ' + XD.length + ' Ordner /XD, ' + XF.length + ' Dateimuster /XF, '
  + STAGE_AUS.length + ' Stage-Ordner, ' + nichtInsUpdate.length + ' Eintraege nichtInsUpdate');

/* ---- Baum durchgehen, genau wie robocopy es taete ---- */
function musterPasst(name, muster) {
  const re = new RegExp('^' + muster.replace(/[.+^${}()|[\]\\]/g, '\\$&').split('*').join('.*') + '$', 'i');
  return re.test(name);
}
function sammle(rel, aus) {
  let eintraege;
  try { eintraege = fs.readdirSync(path.join(WURZEL, rel), { withFileTypes: true }); }
  catch (e) { return aus; }
  eintraege.forEach(function (e) {
    const r = rel ? rel + '/' + e.name : e.name;
    if (e.isDirectory()) {
      if (XD.indexOf(r) >= 0) return;
      sammle(r, aus);
      return;
    }
    if (!e.isFile()) return;
    if (XF.some(function (m) { return musterPasst(e.name, m); })) return;
    aus.push(r);
  });
  return aus;
}
const setupListe = sammle('', []);
if (setupListe.length < 200) {
  abbruch('nur ' + setupListe.length + ' Dateien gefunden - das kann nicht der Baum sein.');
}

function imUpdate(rel) {
  if (STAGE_AUS.indexOf(rel.split('/')[0]) >= 0) return false;
  if (nichtInsUpdate.indexOf(rel) >= 0) return false;
  if (rel.indexOf(FW_REL + '/') === 0 && /\.BIN$/i.test(rel)) return false;
  return true;
}

const BINAER = /\.(dll|exe|sys|cat|bin|png|jpe?g|gif|ico|zip|7z|pdf|ttf|otf|woff2?|mp[34])$/i;
const dateien = setupListe.map(function (rel) {
  let inhalt = null;
  if (!BINAER.test(rel)) {
    try { inhalt = fs.readFileSync(path.join(WURZEL, rel), 'utf8'); } catch (e) { inhalt = null; }
  }
  return { rel: rel, inhalt: inhalt, imUpdate: imUpdate(rel) };
});
const updateListe = dateien.filter(function (d) { return d.imUpdate; });

function rohKB(liste) {
  let b = 0;
  liste.forEach(function (d) {
    try { b += fs.statSync(path.join(WURZEL, d.rel)).size; } catch (e) { /* egal */ }
  });
  return Math.round(b / 1024);
}
console.log('   Setup:  ' + dateien.length + ' Dateien, ' + rohKB(dateien) + ' KB roh');
console.log('   Update: ' + updateListe.length + ' Dateien, ' + rohKB(updateListe)
  + ' KB roh (die Groessengrenze des gepackten Zips bewacht paket-test.js)');

/* Ein Eintrag in $nichtInsUpdate, den es nicht gibt, bricht den BAU ab (make-dist.ps1 wirft).
 * Das faellt sonst erst beim Bauen auf, also im letzten Schritt vor der Freigabe. */
const totInListe = nichtInsUpdate.filter(function (r) { return setupListe.indexOf(r) < 0; });
pruefe('jeder Eintrag aus $nichtInsUpdate liegt wirklich im Baum (sonst bricht der Bau ab)',
  totInListe.length === 0, totInListe.join(', '));

/* Der Waechter prueft sich selbst mit - das ist der Beleg dafuer, dass die zusammengesetzten
 * Suchbegriffe wirken und dass er nicht heimlich von der Suche ausgenommen ist. */
pruefe('dieser Waechter liegt selbst im geprueften Bestand (er nimmt sich nicht aus)',
  setupListe.indexOf(SELBST) >= 0);

/* =======================================================================================
 * Die sechs Regeln - als Funktionen ueber einer Dateiliste, damit die Gegenprobe sie mit
 * erfundenen Dateien fuettern kann, ohne den Baum anzufassen.
 * ===================================================================================== */
function zeileVon(inhalt, index) { return inhalt.slice(0, index).split('\n').length; }

function jedeStelle(d, re, nimm) {
  const treffer = [];
  if (!d.inhalt) return treffer;
  re.lastIndex = 0;
  let m;
  while ((m = re.exec(d.inhalt)) !== null) {
    if (m[0].length === 0) { re.lastIndex++; continue; }
    const was = nimm(m);
    if (was) treffer.push({ rel: d.rel, zeile: zeileVon(d.inhalt, m.index), was: was, imUpdate: d.imUpdate });
  }
  return treffer;
}

/* --- Regel 1: Punkt-Eintraege ------------------------------------------------------- */
function regelPunktEintraege(liste) {
  const gefunden = {};
  liste.forEach(function (d) {
    const teile = d.rel.split('/');
    let bisher = '';
    for (let i = 0; i < teile.length; i++) {
      bisher = bisher ? bisher + '/' + teile[i] : teile[i];
      if (teile[i].charAt(0) !== '.') continue;
      if (ERLAUBTE_PUNKT_EINTRAEGE.indexOf(bisher) >= 0) return;
      if (istAusgenommen('punkt', bisher)) return;
      const art = (i === teile.length - 1) ? 'Punkt-Datei' : 'Punkt-Ordner';
      if (!gefunden[bisher]) {
        gefunden[bisher] = { rel: bisher, zeile: 0, was: art + ' faehrt mit', imUpdate: false };
      }
      if (d.imUpdate) gefunden[bisher].imUpdate = true;
      return;
    }
  });
  return Object.keys(gefunden).map(function (k) { return gefunden[k]; });
}

/* --- Regel 2: Entwicklerpfade -------------------------------------------------------- */
function istPlatzhalterKonto(n) {
  return /^[<%${]/.test(n) || /^(name|nutzer|benutzer|user|username|konto|kontoname)$/i.test(n);
}
function regelEntwicklerpfade(liste) {
  let treffer = [];
  liste.forEach(function (d) {
    if (istAusgenommen('pfad', d.rel)) return;
    treffer = treffer.concat(jedeStelle(d, RE_PFAD, function (m) {
      if (istPlatzhalterKonto(m[1])) return null;
      return 'Pfad des Entwicklerrechners (Kontoname "' + m[1] + '")';
    }));
  });
  return treffer;
}

/* --- Regel 3: KI-Spuren -------------------------------------------------------------- */
function regelKiSpuren(liste) {
  let treffer = [];
  liste.forEach(function (d) {
    if (istAusgenommen('ki', d.rel)) return;
    treffer = treffer.concat(jedeStelle(d, RE_KI, function (m) {
      return 'nennt das Entwicklungswerkzeug ("' + m[0] + '")';
    }));
  });
  return treffer;
}

/* --- Regel 4: Geraetekennungen ------------------------------------------------------- */
function macErlaubt(roh) {
  const norm = roh.toLowerCase().split('-').join(':');
  return ERLAUBTE_MACS.some(function (e) { return e.mac === norm; });
}
function regelGeraetekennungen(liste) {
  let treffer = [];
  liste.forEach(function (d) {
    if (istAusgenommen('geraet', d.rel)) return;
    treffer = treffer.concat(jedeStelle(d, RE_MAC, function (m) {
      if (macErlaubt(m[0])) return null;
      return 'vollstaendige MAC-Adresse ' + m[0];
    }));
    treffer = treffer.concat(jedeStelle(d, RE_SN, function (m) {
      return 'Seriennummer in Geraeteform ' + m[0];
    }));
    treffer = treffer.concat(jedeStelle(d, RE_EUI, function (m) {
      return 'EUI-64 des Geraets ' + m[0];
    }));
    treffer = treffer.concat(jedeStelle(d, RE_ID14, function (m) {
      if (/^(19|20)[0-9]{2}(0[1-9]|1[0-2])/.test(m[0])) return null;   // HL7-Zeitstempel
      if (/^0+$/.test(m[0])) return null;
      return 'Geraete-ID (14 Ziffern) ' + m[0];
    }));
  });
  return treffer;
}

/* --- Regel 5: private Schluessel und die Stationskennung -----------------------------
 *
 * WO DER ANLASS HERKOMMT, obwohl die Regel heute nichts findet: data\ steht in /XD und
 * *.pem/*.key stehen in .gitignore - beides muesste also erst wegfallen. Genau das ist die
 * Frage. Am 19.08.2026 hat der ZWEITE Bauweg (installer\vetstation-setup.iss) data\station-
 * id.json samt privatem Schluessel eingepackt, waehrend der erste sie richtig ausliess; den
 * .iss-Weg bewacht setup-sauber-test.js, diesen hier keiner. Und der Schluessel ist der
 * Angelpunkt der ganzen Update-Signatur: wer ihn veroeffentlicht, kann jeder Praxis fremden
 * Code schicken. Die Gegenprobe belegt, dass die Regel anschlaegt, wenn es soweit ist. */
function regelSchluessel(liste) {
  const treffer = [];
  liste.forEach(function (d) {
    if (istAusgenommen('schluessel', d.rel)) return;
    if (RE_SCHLUESSELNAME.test(d.rel)) {
      treffer.push({ rel: d.rel, zeile: 0, imUpdate: d.imUpdate,
        was: 'Schluessel- oder Kennungsdatei im Paket' });
    }
    if (!d.inhalt) return;
    const pem = d.inhalt.search(RE_PEM);
    if (pem >= 0) {
      treffer.push({ rel: d.rel, zeile: zeileVon(d.inhalt, pem), imUpdate: d.imUpdate,
        was: 'privater Schluessel im Klartext' });
    }
    const b64 = d.inhalt.indexOf(B64_PRIVAT);
    if (b64 >= 0) {
      treffer.push({ rel: d.rel, zeile: zeileVon(d.inhalt, b64), imUpdate: d.imUpdate,
        was: 'privater Ed25519-Schluessel (Base64)' });
    }
  });
  return treffer;
}

/* --- Regel 6: Patienten- und Fallkennungen im Klartext -------------------------------
 *
 * KEINE LISTE BEKANNTER NUMMERN, sondern eine EIGENSCHAFT: durchgelassen wird nur, was
 * erkennbar erfunden ist - eine Ziffer wiederholt (11111), oder eine luckenlos auf- bzw.
 * absteigende Reihe (12345, 987654). So etwas vergibt keine Praxisverwaltung fortlaufend,
 * und der Waechter braucht dafuer nirgends aufzuschreiben, welche Nummern echt sind - eine
 * solche Liste WAERE ja die Veroeffentlichung, die sie verhindern soll. */
function istOffensichtlichErfunden(z) {
  if (/^(\d)\1+$/.test(z)) return true;                    // 1111, 00000
  let auf = true, ab = true;
  for (let i = 1; i < z.length; i++) {
    const d = z.charCodeAt(i) - z.charCodeAt(i - 1);
    if (d !== 1) auf = false;
    if (d !== -1) ab = false;
  }
  return auf || ab;                                         // 12345, 987654
}
function regelPatientenkennungen(liste) {
  let treffer = [];
  liste.forEach(function (d) {
    if (istAusgenommen('patient', d.rel)) return;
    treffer = treffer.concat(jedeStelle(d, RE_PID, function (m) {
      if (istOffensichtlichErfunden(m[2])) return null;
      return 'Patienten- oder Fallkennung im Klartext (' + m[1] + ' ' + m[2] + ')';
    }));
  });
  return treffer;
}

const REGELN = [
  { nr: 1, name: 'Punkt-Eintraege', fn: regelPunktEintraege },
  { nr: 2, name: 'Entwicklerpfade', fn: regelEntwicklerpfade },
  { nr: 3, name: 'KI-Spuren', fn: regelKiSpuren },
  { nr: 4, name: 'Geraetekennungen', fn: regelGeraetekennungen },
  { nr: 5, name: 'Schluessel und Stationskennung', fn: regelSchluessel },
  { nr: 6, name: 'Patienten- und Fallkennungen', fn: regelPatientenkennungen }
];

/* =======================================================================================
 * B  Gegenproben
 *
 * "Eine Pruefung, deren Anlass im geprueften Bestand nicht eintreten kann, ist keine
 * Pruefung." Zwei Regeln finden heute nichts mehr (Seriennummern, private Schluessel) - ohne
 * Gegenprobe waere nicht zu unterscheiden, ob sie schweigen oder ob sie kaputt sind.
 *
 * Gemessen wird in BEIDE Richtungen: an einer erfundenen, vergifteten Datei muss die Regel
 * anschlagen, an einer erfundenen sauberen darf sie es nicht. Nur die erste Haelfte zu
 * pruefen liesse eine Regel durchgehen, die IMMER meldet - und die waere ebenso wertlos.
 * Die saubere Haelfte traegt absichtlich das Aehnliche mit: einen Platzhalter-Kontonamen,
 * eine Protokoll-MAC, einen HL7-Zeitstempel, den OEFFENTLICHEN Schluessel.
 *
 * Der Baum wird dabei nicht angefasst - die Dateien bestehen nur im Speicher.
 * ===================================================================================== */
console.log('\nB  Gegenproben (jede Regel an erfundenen Dateien, der Baum bleibt unberuehrt)');

function d(rel, inhalt) { return { rel: rel, inhalt: inhalt, imUpdate: true }; }

const SAUBER = [
  d('tools/harmlos.js', [
    'const heim = process.env.USERPROFILE;',
    'const vorlage = "E:' + '\\\\' + 'Us' + 'ers' + '\\\\' + '<Konto>' + '\\\\' + 'VetStation";',
    'const rundruf = "ff:ff:ff:ff:ff:ff";',
    'const platzhalter = "98:cc:e4:aa:bb:cc";',
    'const hl7Zeit = "20260829120000";',
    /* Die erfundene Testkennung, die im Baum wirklich vorkommt (tools/tafel-test.js). Sie
     * gehoert in die SAUBERE Haelfte: hier belegt sie, dass die Ziffernprobe von Regel 6
     * greift - ohne sie liefe dieser Zweig nie und koennte unbemerkt kaputtgehen. */
    'const patientId = "12345";',
    'const oeffentlich = "MCowBQ' + 'YDK2VwAyEA...";'
  ].join('\n')),
  d('updater/release-key.pub', 'MCowBQ' + 'YDK2VwAyEAkGwoMIXGGAznU6uq4THhNUkjbJwcBq+TC6eWt03RKtg=')
];

const GIFT = {
  1: d('.werkzeug/sitzung.json', '{ "sitzung": "abc" }'),
  /* "kontoname" waere hier falsch: das Wort steht auf der Platzhalterliste und die Regel
   * liesse es zu Recht durch - die Gegenprobe pruefte dann den Ausnahmezweig statt der Regel
   * (im ersten Lauf genau so passiert). */
  2: d('docs/bericht.md', 'gelesen aus D:' + '\\' + 'Us' + 'ers' + '\\' + 'mmuster' + '\\' + 'Projekt'),
  3: d('tools/hilfe.js', '/* erzeugt mit ' + WORT_WERKZEUG + ' am Dienstag */'),
  4: d('tools/geraet-test.js', [
    'const mac = "' + ['de', 'ad', 'be', 'ef', '01', '02'].join(':') + '";',
    'const mac2 = "' + ['de', 'ad', 'be', 'ef', '01', '03'].join('-') + '";',
    'const sn = "' + 'QQ' + '9-' + '12345678' + 'Z";',
    'const id = "' + '3141592' + '6535897' + '";'
  ].join('\n')),
  5: d('data/station-id' + '.json', '{ "priv": "' + B64_PRIVAT + 'AAAA" }'),
  /* Eine Nummer, die AUSSIEHT wie eine vergebene Fallnummer - nicht wiederholt, nicht
   * fortlaufend. Genau so lagen die beiden echten hier.
   * ZUSAMMENGESETZT wie alle anderen Gegenproben: ausgeschrieben meldete der Waechter beim
   * ersten Lauf sich selbst (Zeile 577) - dieselbe Falle wie bei Gegenprobe 4, und sie ist
   * beim Nachruesten prompt wieder zugeschnappt. */
  6: d('ui/anzeige.js', '/* gemessen: der Monitor meldet ' + 'Patienten-' + 'ID '
    + '407' + '913 */')
};

REGELN.forEach(function (r) {
  const leer = r.fn(SAUBER);
  pruefe('Gegenprobe ' + r.nr + ' (' + r.name + '): ein sauberer Bestand ergibt KEINEN Treffer',
    leer.length === 0, leer.map(function (t) { return t.rel + ': ' + t.was; }).join('\n'));
  const gift = r.fn(SAUBER.concat([GIFT[r.nr]]));
  /* Regel 1 meldet den Punkt-EINTRAG, nicht die Datei darunter - deshalb genuegt es, wenn der
   * Treffer der Anfang des vergifteten Pfades ist. */
  pruefe('Gegenprobe ' + r.nr + ' (' + r.name + '): die erfundene Datei wird gefunden',
    gift.some(function (t) {
      return t.rel === GIFT[r.nr].rel || GIFT[r.nr].rel.indexOf(t.rel + '/') === 0;
    }),
    'gefunden: ' + (gift.map(function (t) { return t.rel; }).join(', ') || 'nichts'));
});
/* Regel 4 muss ALLE vier Kennungsarten sehen, nicht nur die erste - sonst genuegte eine
 * einzige greifende Zeile, damit die Gegenprobe gruen wird. */
const g4 = regelGeraetekennungen([GIFT[4]]);
pruefe('Gegenprobe 4: MAC (beide Schreibweisen), Seriennummer, Geraete-ID einzeln erkannt',
  g4.length === 4, g4.map(function (t) { return t.was; }).join(' | '));
/* Und Regel 5 muss beide Wege sehen: den Namen und den Inhalt. */
const g5 = regelSchluessel([GIFT[5]]);
pruefe('Gegenprobe 5: Name UND Inhalt schlagen einzeln an', g5.length === 2,
  g5.map(function (t) { return t.was; }).join(' | '));

/* =======================================================================================
 * C  Die sechs Regeln am echten Bestand
 *
 * Getrennt nach Weg, weil die Empfaenger verschieden sind: das Update-Zip liegt oeffentlich
 * auf GitHub Pages, das Setup geht per USB auf die Praxis-PCs. Beides ist ausserhalb dieses
 * Hauses - deshalb ist beides ein Fehler, aber die erste Zeile ist die dringendere.
 * ===================================================================================== */
console.log('\nC  Die sechs Regeln am echten Bestand');

/* ZUSAMMENGEFASST STATT ZEILE FUER ZEILE: im ersten Lauf warf eine einzige Datei 57 gleich
 * lautende Zeilen aus, und die Meldung darunter war nicht mehr zu finden. Eine Liste, die
 * niemand zu Ende liest, meldet nichts. Je Datei stehen deshalb die erste Fundstelle und die
 * Zahl der uebrigen da - zum Nachsehen genuegt das, zum Uebersehen nicht. */
const HOECHSTENS = 15;
function fasseZusammen(treffer) {
  const proDatei = {};
  const reihe = [];
  treffer.forEach(function (t) {
    if (!proDatei[t.rel]) { proDatei[t.rel] = { erste: t, zahl: 0 }; reihe.push(t.rel); }
    proDatei[t.rel].zahl++;
  });
  const zeilen = reihe.slice(0, HOECHSTENS).map(function (rel) {
    const e = proDatei[rel];
    return rel + (e.erste.zeile ? ':' + e.erste.zeile : '') + '  ' + e.erste.was
      + (e.zahl > 2 ? '   (und ' + (e.zahl - 1) + ' weitere Stellen)' : '')
      + (e.zahl === 2 ? '   (und eine weitere Stelle)' : '');
  });
  if (reihe.length > HOECHSTENS) {
    zeilen.push('... und ' + (reihe.length - HOECHSTENS) + ' weitere Dateien');
  }
  return treffer.length + (treffer.length === 1 ? ' Stelle in ' : ' Stellen in ')
    + reihe.length + (reihe.length === 1 ? ' Datei:\n' : ' Dateien:\n') + zeilen.join('\n');
}
REGELN.forEach(function (r) {
  const alle = r.fn(dateien);
  const oeff = alle.filter(function (t) { return t.imUpdate; });
  const nurSetup = alle.filter(function (t) { return !t.imUpdate; });
  pruefe('Regel ' + r.nr + ' (' + r.name + '): nichts davon im OEFFENTLICHEN Update-Zip',
    oeff.length === 0, fasseZusammen(oeff));
  pruefe('Regel ' + r.nr + ' (' + r.name + '): nichts davon im Setup (Praxis-PCs)',
    nurSetup.length === 0, fasseZusammen(nurSetup));
});

/* ------------------------------------------------------------------------------------- */
console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + ' Pruefungen)');
  console.log('Jede Zeile oben nennt eine Datei, die mit dem Paket hinausginge.');
  process.exit(1);
}
console.log('ALLE ' + ok + ' PRUEFUNGEN BESTANDEN \u2014 das Paket traegt nichts ueber dieses Haus hinaus.');
