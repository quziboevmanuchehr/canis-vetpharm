'use strict';
/* =============================================================================================
 * beleg-kette-test.js — die Kette vom Rauschmass bis zum Beleg-Paket (25.08.2026)
 * =============================================================================================
 *
 * WAS HIER GEPRUEFT WIRD UND WARUM
 *
 * Ziel der Kette: hinterher entscheiden koennen, ob ein EKG-Befund echt war oder eine
 * Bewegungsspur. Dafuer muessen drei Dinge zusammenpassen, und alle drei fallen still aus:
 *
 *   1. Die Rauschzahlen muessen die Bridge ueberhaupt ERREICHEN. Bis 1.24.0 uebernahm sie
 *      allein `guete` — und die ist bauartbedingt blind (siehe unten). stoerAbschnitte() lief
 *      im Browser und ihr Ergebnis blieb dort liegen.
 *   2. Sie muessen in der PROTOKOLLZEILE stehen, sonst haengt der Befund in der Akte ohne die
 *      Angabe, wie verrauscht der Streifen war.
 *   3. Das Beleg-Paket darf den Menschen neben dem Tier NICHT mitnehmen.
 *
 * DER KERNBEFUND, DER DAS GANZE BEGRUENDET (heute gemessen, Abschnitt 1):
 * Auf einem 20-s-Streifen mit 2 s Bewegungsstoerung meldet die Auswertung "Salve breiter
 * Kammerkomplexe" — bei einer Guete von rund 172, also blitzsauber. Bei 5 s Stoerung STEIGT
 * die Guete sogar, weil die Stoerzacken im ZAEHLER des Guetemasses landen. Der Stoeranteil
 * fasst genau diese Faelle.
 *
 * NICHT geprueft wird, ob der Stoeranteil etwas SPERRT — er sperrt bewusst nichts. Der Versuch
 * faerbte 12 von 65 echten Rhythmusbefunden rot (ui/shared/ekg-analyse.js:1622). Hier wird
 * gemessen und mitgeschrieben, nicht entschieden.
 * ============================================================================================= */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const WURZEL = path.join(__dirname, '..');
const NODE = path.join(WURZEL, 'dist', 'VetStation', 'node', 'node.exe');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function ohneKommentar(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/^[ \t]*\/\/.*$/gm, ' ');
}

console.log('Vom Rauschmass bis zum Beleg-Paket — Selbsttest\n');

/* =============================================================================================
 * 1) DER ANLASS — echt gerechnet, nicht behauptet
 * ============================================================================================= */
console.log('1) Warum es die Rauschzahlen braucht (an einem gerechneten Streifen)');
const EKG = require(path.join(WURZEL, 'ui', 'shared', 'ekg-analyse.js'));
const HZ = 256;
function sauberStreifen(sek) {
  const n = HZ * sek, w = [];
  /* Fester Zufall: derselbe Streifen bei jedem Lauf, sonst flackert der Test unter Last.
   * (Ein eigener Generator, weil Math.random() nicht setzbar ist.) */
  let s = 12345;
  const zuf = () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff - 0.5; };
  for (let i = 0; i < n; i++) {
    const phase = ((i / HZ) % 0.6) / 0.6;
    let v = 0;
    if (phase > 0.10 && phase < 0.14) v = 900 * Math.sin((phase - 0.10) / 0.04 * Math.PI);
    w.push(v + zuf() * 20);
  }
  return w;
}
function mitSchub(w, sek) {
  const b = w.slice(), von = HZ * 7, bis = von + Math.round(HZ * sek);
  for (let i = von; i < bis && i < b.length; i++) b[i] += 2500 * Math.sin(2 * Math.PI * 5 * (i - von) / HZ);
  return b;
}
const rein = EKG.analysiere({ samples: sauberStreifen(20), hz: HZ }, { einheit: 'uV' });
const laut2 = EKG.analysiere({ samples: mitSchub(sauberStreifen(20), 2), hz: HZ }, { einheit: 'uV' });
const laut5 = EKG.analysiere({ samples: mitSchub(sauberStreifen(20), 5), hz: HZ }, { einheit: 'uV' });

ok('der saubere Streifen ergibt keinen Kammerbefund',
  !/Kammerkomplex|Tachykard/i.test(String(rein.rhythmus && rein.rhythmus.name)),
  'gemeldet: ' + (rein.rhythmus && rein.rhythmus.name));
ok('2 s Stoerung erzeugen einen Kammerbefund',
  /Kammerkomplex|Tachykard|Formfremd/i.test(String(laut2.rhythmus && laut2.rhythmus.name)),
  'gemeldet: ' + (laut2.rhythmus && laut2.rhythmus.name));
ok('… und die Guete haelt den Streifen dabei fuer sauber', laut2.guete >= 50,
  'Guete: ' + laut2.guete + ' — waere sie niedrig, braeuchte es die zweite Zahl nicht');
ok('… bei 5 s Stoerung steigt die Guete sogar', laut5.guete > rein.guete,
  'sauber ' + rein.guete + ' gegen gestoert ' + laut5.guete);
ok('DER STOERANTEIL fasst beide Faelle',
  laut2.stoerung.anteil > 0 && laut5.stoerung.anteil > laut2.stoerung.anteil,
  '2 s: ' + laut2.stoerung.anteil + '   5 s: ' + laut5.stoerung.anteil);
ok('… und bleibt auf dem sauberen Streifen bei null', rein.stoerung.anteil === 0,
  'sonst waere er ein Fehlalarm statt einer Messung');
ok('stoerMass ist ein absolutes Mass in der Einheit des Streifens',
  rein.stoerung.massstab > 0 && rein.stoerung.massstab < 50,
  'sauber gemessen: ' + rein.stoerung.massstab + ' uV');

/* =============================================================================================
 * 2) DIE ZAHLEN ERREICHEN DIE BRIDGE — BEIDE BAUWEGE
 * ============================================================================================= */
console.log('\n2) Beide Bauwege der Zusammenfassung tragen sie');
const model = ohneKommentar(fs.readFileSync(path.join(WURZEL, 'bridge', 'src', 'model.js'), 'utf8'));
const reg = ohneKommentar(fs.readFileSync(path.join(WURZEL, 'bridge', 'src', 'registry.js'), 'utf8'));
['stoerAnteil', 'stoerSek', 'stoerMass'].forEach((f) => {
  ok('model.js reicht ' + f + ' weiter', new RegExp(f + ':').test(model));
  ok('registry.js reicht ' + f + ' weiter', new RegExp(f + ':').test(reg));
});
/* Wenn nur EINER der beiden Wege sie traegt, haengt es am angeschlossenen Geraet, ob ein Beleg
 * spaeter etwas ueber das Rauschen sagen kann — und das faellt niemandem auf. */
ok('beide Wege nennen dieselben drei Felder',
  ['stoerAnteil', 'stoerSek', 'stoerMass'].every((f) => model.includes(f) && reg.includes(f)));

/* =============================================================================================
 * 3) DIE PROTOKOLLZEILE — echt geschrieben, nicht gelesen
 * ============================================================================================= */
console.log('\n3) Die Protokollzeile traegt Guete und Stoeranteil');
const { Registry } = require(path.join(WURZEL, 'bridge', 'src', 'registry'));
const stumm = { info() {}, warn() {}, error() {}, debug() {} };
const r = new Registry({ log: stumm });
r.protokollDatei = path.join(os.tmpdir(), 'vs-beleg-' + process.pid + '.json');
r.akteDatei = path.join(os.tmpdir(), 'vs-beleg-akte-' + process.pid + '.json');
/* Leeren, BEVOR etwas geschrieben wird — der Konstruktor laedt den echten Bestand. */
r.protokoll = {}; r.protokollKopf = {}; r._protokollSchmutzig = false;

r.protokollSchritt([{
  patientId: 'BEL-1', species: 'hund', weightKg: 12,
  vitals: { hr: 90, spo2: 97, etco2: 38, map: 70, temp: 38.1 },
  ekgAnalyse: { brauchbar: true, guete: 171.9, stoerAnteil: 0.09, stoerSek: 1.8, stoerMass: 4.5,
    rhythmus: { id: 'vt', name: 'Salve breiter Kammerkomplexe' } },
}]);
const Z = (r.protokoll['BEL-1'] || [])[0] || {};
ok('eine Zeile ist entstanden', !!Z.ts);
ok('sie traegt guete', Z.guete === 171.9);
ok('sie traegt stoer', Z.stoer === 0.09);
ok('der Rhythmus steht weiterhin im Befundtext', /Kammerkomplex/.test(String(Z.finding)));

/* Ohne EKG-Auswertung darf NICHTS dastehen — ein Feld mit 0 hiesse "war sauber", und das waere
 * eine Aussage, die niemand gemacht hat. */
r.protokollSchritt([{
  patientId: 'BEL-2', species: 'katze', weightKg: 4,
  vitals: { hr: 180, spo2: 98, etco2: 35, map: 80, temp: 38.5 },
}]);
const Z2 = (r.protokoll['BEL-2'] || [])[0] || {};
ok('ohne EKG-Auswertung bleibt guete null', Z2.guete === null);
ok('… und stoer ebenfalls', Z2.stoer === null,
  'eine 0 hiesse "der Streifen war sauber" — das waere erfunden');

/* Die Zeile muss uebertragbar bleiben: hoechstens zwei Ebenen. */
function tiefe(o, d) {
  if (!o || typeof o !== 'object') return d;
  let m = d;
  Object.keys(o).forEach((k) => { const t = tiefe(o[k], d + 1); if (t > m) m = t; });
  return m;
}
ok('die Messzeile bleibt einstufig', tiefe(Z, 0) === 1, 'gemessen: ' + tiefe(Z, 0));

/* =============================================================================================
 * 4) DAS BELEG-PAKET — das Werkzeug wirklich ausgefuehrt
 * ============================================================================================= */
console.log('\n4) Das Beleg-Paket');
const probe = path.join(os.tmpdir(), 'vs-arch-' + process.pid + '.json');
fs.writeFileSync(probe, JSON.stringify([
  { id: 'a1', sp: 'hund', rasse: 'Boxer', wt: 28, patId: 'C-077', hz: 256, sekunden: 20, kal: true,
    name2: 'Salve breiter Kammerkomplexe', anlass: 'auto', urteil: 'art', urteilTs: 2,
    befunde: [{ id: 'vt', name: 'VT', stufe: 3 }],
    mess: { hf: 353, qrs: 59, guete: 171.9, stoer: 0.09, stoerSek: 1.8, stoerMass: 4.5 } },
  { id: 'a2', sp: 'hund', rasse: 'Boxer', wt: 28, patId: 'C-077', hz: 256, sekunden: 10,
    name2: 'Sinusrhythmus', urteil: 'ok', urteilTs: 4, befunde: [],
    mess: { hf: 100, guete: 90, stoer: 0, stoerSek: 0, stoerMass: 4.4 } },
  { id: 'a3', sp: 'katze', rasse: 'BKH', wt: 4, patId: 'K-210', hz: 256,
    name2: 'Sinusrhythmus', befunde: [], mess: { hf: 180, guete: 60 } },
]), 'utf8');

let aus = '';
try {
  aus = execFileSync(NODE, [path.join(__dirname, 'beleg-paket.js'), '--aus', probe, '--zeigen'],
    { encoding: 'utf8' });
} catch (e) { aus = String((e && e.stdout) || ''); }

ok('das Werkzeug laeuft', /Beleg-Paket aus beurteilten Streifen/.test(aus));
ok('es zaehlt nur die beurteilten Streifen', /davon beurteilt:   2/.test(aus),
  'drei Streifen, einer ohne Urteil');
ok('ein Streifen OHNE Urteil wandert nicht mit', !/K-210|BKH/.test(aus),
  'lieber neunzig geurteilte Faelle als tausend geratene');
ok('die Verbotsliste meldet nichts', /Verbotene Felder:  keine/.test(aus));
ok('die Patientenkennung steht nicht im Klartext', !/C-077/.test(aus));
ok('die Rauschzahlen sind im Beleg', /"stoer": 0\.09/.test(aus) && /"stoerMass": 4\.5/.test(aus));
ok('das Urteil ist im Beleg', /"urteil": "art"/.test(aus));
ok('die Automatik-Aussage steht daneben', /"automatik": "Salve breiter Kammerkomplexe"/.test(aus),
  'ohne sie laesst sich nicht messen, WORIN sich Urteil und Automatik unterscheiden');

/* Die abgeleitete Kennung muss fuer dasselbe Tier gleich bleiben - sonst laesst sich spaeter
 * nicht nach PRAXIS/TIER trennen, und man misst Auswendiglernen statt Uebertragbarkeit. */
const kennungen = (aus.match(/"fall": "([0-9a-f]{12})"/g) || []);
ok('zwei Streifen desselben Tieres tragen dieselbe abgeleitete Kennung',
  kennungen.length >= 1, 'gefunden: ' + kennungen.length);

/* =============================================================================================
 * 5) DIE URTEILSKNOEPFE IN DER OBERFLAECHE
 * ============================================================================================= */
console.log('\n5) Die Urteilsknoepfe');
const app = ohneKommentar(fs.readFileSync(path.join(WURZEL, 'ui', 'app', 'index.html'), 'utf8'));
ok('es gibt genau drei Urteile', /URTEILE = \{ ok:'stimmt', art:'Artefakt', anders:'etwas anderes' \}/.test(app),
  'wer fuenf Stufen anbietet, bekommt die mittlere');
ok('die Knoepfe haengen am Archiveintrag', /urteilHtml\(r\)/.test(app));
ok('KEIN Urteil ist vorausgewaehlt',
  !/data-wert="ok"[^>]*class="[^"]*on/.test(app) && /u===k\?' on':''/.test(app),
  'ein voreingestelltes "stimmt" waere kein Urteil, sondern ein Klickzaehler');
ok('ein zweiter Klick nimmt das Urteil zurueck', /if\(list\[i\]\.urteil===wert\)\{ delete list\[i\]\.urteil/.test(app),
  'ein Fehlklick darf keine Aussage zementieren, die spaeter ein Modell anlernt');
ok('das Urteil wird sofort gespeichert', /archSave\(list\)[\s\S]{0,160}renderArch\(\)/.test(app));
ok('ein misslungenes Speichern wird NICHT verschwiegen',
  /Urteil NICHT gespeichert/.test(app), 'ein stiller Verlust ist das Schlimmste, was ein Archiv tun kann');
ok('der Archiveintrag fuehrt die drei Rauschzahlen',
  /stoer:\(B\.stoerung/.test(app) && /stoerSek:\(B\.stoerung/.test(app) && /stoerMass:\(B\.stoerung/.test(app));

console.log('\n---------------------------------------------');
console.log('  bestanden: ' + pass + '   fehlgeschlagen: ' + fail);
try { fs.unlinkSync(probe); } catch (_) { /* nie angelegt */ }
try { fs.unlinkSync(r.protokollDatei); } catch (_) { /* nie angelegt */ }
try { fs.unlinkSync(r.akteDatei); } catch (_) { /* nie angelegt */ }
if (fail) process.exit(1);
console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
