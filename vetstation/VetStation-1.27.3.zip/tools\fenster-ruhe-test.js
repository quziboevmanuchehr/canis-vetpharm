'use strict';
/*
 * fenster-ruhe-test.js — die Patientenfenster stehen still (Praxis-Wunsch 28.08.2026).
 *
 * WAS PASSIERT WAR
 * refresh() sortierte die Patienten bei JEDER patients-Nachricht nach `priority` und schrieb
 * daraus die CSS-Eigenschaft `order` jedes Fensters. `priority` ist aber keine Stufe, sondern
 * eine Fliesskommazahl direkt aus den Messwerten (brain.js:155). Nachgerechnet fuer zwei Hunde:
 * HF 30 -> 2,50000, SpO2 94 -> 2,51579, HF 29 -> 2,51667 — EIN Herzschlag dreht die Reihenfolge
 * um. Und der Takt ist nicht 500 ms: bridge/src/server.js:715-728 loest bei jedem verarbeiteten
 * Geraete-Frame einen Sofort-Rundruf aus (MIN_ABSTAND_MS 40), an einem 500-Hz-EKG also bis zu
 * 25×/s. Der Tierarzt steht im OP vor dem Schirm, und das Fenster, das er gerade liest, springt
 * weg. Sein Satz dazu: "Die Fenster muessen ruhig bleiben."
 *
 * WARUM DIESER TEST DIE DATEI AUSFUEHRT UND NICHT LIEST
 * tools/ui-flacker-test.js prueft dieselbe Datei rein statisch — und genau deshalb haette es den
 * Fehler nie gefunden: `w.wrap.style.order = ...` stand vorher wie nachher da, nur die ZAHL kam
 * aus einer anderen Quelle. Eine Zusage ueber das VERHALTEN muss man fahren. Also laeuft
 * ui/vetstation-live.js hier in einem vm-Kontext mit einer kleinen DOM-Attrappe, und die
 * Patienten-Nachrichten werden ueber die WebSocket-Attrappe eingespeist wie im Betrieb.
 *
 * DER ANLASS WIRD MITGEMESSEN
 * Ein Test "die Reihenfolge aendert sich nicht" ist wertlos, wenn die Prioritaeten sich in den
 * Proben gar nicht kreuzen (Notiz "Pruefung ohne Anlass"). Der Test zaehlt deshalb die
 * Kreuzungen der Rangfolge mit und faellt durch, wenn es keine gab.
 *
 * GEGENPROBE (von Hand gefahren am 28.08.2026)
 * In refresh() `String(platzVon(k))` durch die alte Rangnummer ersetzt -> Pruefung 2 und 4 rot
 * ("Reihenfolge wechselte in Takt 1"). Den Haltewert GEFAHR_HALTE_MS auf 0 gesetzt -> Pruefung 7
 * rot. Damit ist belegt, dass die Pruefungen ihren eigenen Anlass sehen.
 *
 * Start: node tools/fenster-ruhe-test.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

// ---------------------------------------------------------------------------
// Uhr, die sich vorstellen laesst: der Haltewert fuer "Gefahr" ist eine Zeitgroesse.
// Echtes Warten waere ein Test, der 8 Sekunden schlaeft — und der laeuft dann irgendwann
// unter Last anders (Notiz "Zeitmessungen unter Last").
// ---------------------------------------------------------------------------
const EchtDate = Date;
let versatz = 0;
class TestDate extends EchtDate {
  static now() { return EchtDate.now() + versatz; }
}

// ---------------------------------------------------------------------------
// DOM-Attrappe. Sie kann genau so viel, wie ui/vetstation-live.js beim Aktualisieren braucht:
// Elemente anlegen/einhaengen, class/style/innerHTML setzen und nach Klassen suchen. Was der
// Test misst, rechnet die Datei selbst aus (die order-Zeichenkette und die Kopfzeilen-HTML) —
// die Attrappe erfindet daran nichts.
// ---------------------------------------------------------------------------
function tokenHat(html, cls) {
  const re = /class="([^"]*)"/g;
  let m;
  while ((m = re.exec(html))) { if (String(m[1]).split(/\s+/).indexOf(cls) >= 0) return true; }
  return false;
}
class El {
  constructor(tag) {
    this.tagName = String(tag || 'div').toUpperCase();
    this.className = '';
    this.children = [];
    this.parentNode = null;
    this.style = { setProperty(k, v) { this['--' + k] = v; } };
    this.classList = {
      _s: {},
      toggle: (n, on) => { this.classList._s[n] = !!on; },
      contains: (n) => !!this.classList._s[n],
      add: (n) => { this.classList._s[n] = true; },
      remove: (n) => { delete this.classList._s[n]; },
    };
    this._html = '';
    // Jeder Schreibzugriff wird GEZAEHLT (28.08.2026). Erst damit laesst sich die Zusage
    // "die Kopfzeile wird nur bei echter Aenderung neu geschrieben" ueberhaupt pruefen — dass
    // ein Vergleich im Code steht, sagt nichts darueber, wie oft er anschlaegt (siehe Abschnitt 10).
    this._schreib = 0;
    this.contentDocument = null;
    this.contentWindow = null;
  }
  set innerHTML(v) { this._html = String(v); this._schreib++; }
  get innerHTML() { return this._html; }
  appendChild(c) { c.parentNode = this; this.children.push(c); return c; }
  removeChild(c) { const i = this.children.indexOf(c); if (i >= 0) this.children.splice(i, 1); c.parentNode = null; }
  addEventListener() {}
  removeEventListener() {}
  setAttribute(k, v) { this['attr_' + k] = String(v); }
  getAttribute(k) { return this['attr_' + k] == null ? null : this['attr_' + k]; }
  querySelector(sel) {
    if (sel.charAt(0) === '.' && tokenHat(this._html, sel.slice(1))) return new El('span');
    return null;
  }
  querySelectorAll(sel) {
    if (sel === '.vsx-pat') {
      const out = [];
      const re = /data-k="([^"]*)"/g;
      let m;
      while ((m = re.exec(this._html))) { const e = new El('div'); e.setAttribute('data-k', m[1]); out.push(e); }
      return out;
    }
    return [];
  }
}

function baueUmgebung() {
  const knoten = {};                       // Selektor -> festes Element (so bleibt $('#x') stabil)
  const dokument = {
    documentElement: new El('html'),
    body: new El('body'),
    createElement: (t) => new El(t),
    querySelector: (s) => (knoten[s] || (knoten[s] = new El('div'))),
    addEventListener() {},
    activeElement: null,
  };
  let letzteWS = null;
  class WS {
    constructor(url) { this.url = url; letzteWS = this; }
    send() {}
  }
  const ctx = {
    document: dokument,
    location: { protocol: 'http:', host: '127.0.0.1:8790' },
    WebSocket: WS,
    Date: TestDate,
    setTimeout: () => 0,
    clearTimeout: () => {},
    setInterval: () => 0,
    addEventListener: () => {},
    removeEventListener: () => {},
    console: { log() {}, warn() {}, error() {} },
    alert: () => {},
    fetch: () => { const t = { then: () => t, catch: () => t }; return t; },
    ANAES: { species: [{ id: 'hund', icon: 'H', name: 'Hund' }] },
    /*
     * Bewertung als Attrappe: die echte brain.js wird an anderer Stelle geprueft
     * (tools/priority-test.js). Hier zaehlt nur, dass die ANZEIGE nicht mehr an ihrem Ergebnis
     * haengt — also muss dieses Ergebnis frei steuerbar sein.
     */
    VS: {
      brain: {
        assess: (ANAES, pat) => ({
          cross: [], single: [], alarms: {}, alarmCount: 0, bands: {}, fehlt: [],
          priority: pat.prio || 0,
          top: pat.sev ? { sev: pat.sev, title: pat.titel || 'Befund', incident: 'test' } : null,
          // `leer` stellt den dritten Zustand nach: ein Tier, von dem GAR KEIN Messwert vorliegt.
          werteAnzahl: pat.leer ? 0 : 1, keineDaten: !!pat.leer, annahmen: {},
        }),
      },
    },
  };
  vm.createContext(ctx);
  ctx.window = ctx;
  ctx.globalThis = ctx;
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'ui/vetstation-live.js'), 'utf8'), ctx,
    { filename: 'ui/vetstation-live.js' });
  // Die Knoten werden erst beim ersten $('#…') angelegt — #vsxPatients gibt es also erst, wenn
  // die Leiste zum ersten Mal gezeichnet wurde. Deshalb Zugriffe, keine festen Verweise.
  return {
    ctx: ctx,
    knoten: knoten,
    grid: knoten['#vsxGrid'],
    leiste: () => knoten['#vsxPatients'],
    sortKnopf: () => knoten['#vsxSort'],
    sende: (pats) => letzteWS.onmessage({ data: JSON.stringify({ type: 'patients', patients: pats }) }),
  };
}

// Patient bauen. prio/sev/titel reisen in vitals mit — assess() reicht vitals unveraendert an
// die Bewertung durch, das ist also genau der Weg, den ein echter Messwert nimmt.
// `zus` (optional): { iso, leer } — Verdampferwert und "kein einziger Messwert".
function pat(key, name, prio, sev, titel, zus) {
  zus = zus || {};
  return {
    patientKey: key, patientId: key, patientName: name, species: 'hund', weightKg: 12,
    isoPct: zus.iso, devices: [{ deviceId: 'dev-' + key }],
    vitals: { hr: 90, prio: prio, sev: sev || 0, titel: titel || null, leer: zus.leer },
  };
}
// Die Fenster in der Reihenfolge, die der Bildschirm zeigt (CSS `order`), als Namensliste.
function bildschirm(u) {
  return u.grid.children.slice()
    .sort((a, b) => Number(a.style.order) - Number(b.style.order))
    .map((w) => (w.children[0]._html.match(/<b[^>]*>([^<]*)<\/b>/) || [])[1]);
}
function kopfVon(u, name) {
  const w = u.grid.children.filter((c) => c.children[0]._html.indexOf('>' + name + '<') >= 0)[0];
  return w ? w.children[0]._html : '';
}

console.log('VetStation — die Patientenfenster stehen still (Wunsch 28.08.2026)\n');

// ---------------------------------------------------------------------------
console.log('1) Ein neues Fenster bekommt seinen Platz und behaelt ihn:');
const u = baueUmgebung();
// Bella wird von der Bridge zuerst gemeldet, ist aber der WENIGER dringliche Fall.
u.sende([pat('A', 'Bella', 2.50), pat('B', 'Rex', 2.51)]);
ok('zwei Fenster sind offen', u.grid.children.length === 2, u.grid.children.length + '');
ok('sie stehen in der Reihenfolge, in der sie gemeldet wurden (nicht nach Dringlichkeit)',
  JSON.stringify(bildschirm(u)) === '["Bella","Rex"]', JSON.stringify(bildschirm(u)));
ok('… und der Anlass besteht wirklich: Rex ist der dringlichere Fall', 2.51 > 2.50);

// ---------------------------------------------------------------------------
console.log('\n2) Kreuzende Prioritaeten stellen nichts mehr um:');
const start = JSON.stringify(bildschirm(u));
let kreuzungen = 0, gesprungen = 0, letzterRang = 'B';
for (let i = 0; i < 40; i++) {
  // So flattert es in der Praxis: zwei Tiere, deren Bewertung sich dauernd ueberholt.
  const pa = 2.50 + (i % 2) * 0.02, pb = 2.51;
  const rang = pa > pb ? 'A' : 'B';
  if (rang !== letzterRang) { kreuzungen++; letzterRang = rang; }
  u.sende([pat('A', 'Bella', pa), pat('B', 'Rex', pb)]);
  if (JSON.stringify(bildschirm(u)) !== start) { gesprungen++; }
}
ok('die Rangfolge hat sich in den Proben wirklich gekreuzt (sonst prueft der Test nichts)',
  kreuzungen >= 10, kreuzungen + ' Kreuzungen');
ok('der Bildschirm blieb in allen 40 Takten unveraendert', gesprungen === 0,
  gesprungen + ' von 40 Takten sprangen');

// ---------------------------------------------------------------------------
console.log('\n3) Ein neuer Patient kommt HINTEN dran, auch wenn er der dringlichste ist:');
u.sende([pat('A', 'Bella', 2.50), pat('B', 'Rex', 2.51), pat('C', 'Moritz', 9.9, 5, 'Asystolie')]);
ok('drei Fenster', u.grid.children.length === 3, u.grid.children.length + '');
ok('Moritz steht hinten, obwohl er der Notfall ist',
  JSON.stringify(bildschirm(u)) === '["Bella","Rex","Moritz"]', JSON.stringify(bildschirm(u)));

// ---------------------------------------------------------------------------
console.log('\n4) Ein Notfall sortiert NICHTS um — er faerbt an Ort und Stelle:');
const vorNotfall = JSON.stringify(bildschirm(u));
u.sende([pat('A', 'Bella', 9.9, 5, 'Kammerflimmern – Kreislaufstillstand'), pat('B', 'Rex', 2.51), pat('C', 'Moritz', 2.5)]);
ok('die Reihenfolge steht auch beim Notfall still',
  JSON.stringify(bildschirm(u)) === vorNotfall, JSON.stringify(bildschirm(u)));
const kopfA = kopfVon(u, 'Bella');
ok('der Patientenname im betroffenen Fenster ist rot markiert',
  /<b class="gefahr">Bella<\/b>/.test(kopfA), kopfA.slice(0, 140));
ok('der Notfall steht daneben im Klartext',
  /<span class="alarm"[^>]*>⚠ Kammerflimmern – Kreislaufstillstand<\/span>/.test(kopfA), kopfA.slice(0, 200));
ok('er steht UNMITTELBAR neben dem Namen (nicht am Zeilenende)',
  kopfA.indexOf('</b><span class="alarm"') >= 0, kopfA.slice(0, 200));
ok('das Nachbarfenster bleibt unmarkiert',
  !/class="gefahr"/.test(kopfVon(u, 'Rex')) && !/class="alarm"/.test(kopfVon(u, 'Rex')));
ok('die Kopfzeile bleibt EINE Zeile (kein zweites Element mit Umbruch)',
  kopfA.indexOf('<br') < 0 && kopfA.indexOf('<div') < 0);

// ---------------------------------------------------------------------------
console.log('\n5) Die Patientenleiste ordnet sich ebenfalls nicht mehr um:');
const leiste = u.leiste()._html;
const iA = leiste.indexOf('data-k="A"'), iB = leiste.indexOf('data-k="B"'), iC = leiste.indexOf('data-k="C"');
ok('die Kacheln stehen in derselben festen Reihenfolge wie die Fenster',
  iA >= 0 && iA < iB && iB < iC, [iA, iB, iC].join(','));
ok('die Gefahr wird auch dort durch Farbe gezeigt', /<b class="gefahr">Bella<\/b>/.test(leiste));

// ---------------------------------------------------------------------------
console.log('\n6) Flatternde Gefahr fuehrt NICHT zum Blinken:');
let wechsel = 0;
let vorher = /class="gefahr"/.test(kopfVon(u, 'Bella'));
for (let i = 0; i < 30; i++) {
  // Der Befund kommt und geht im Takt der Messwerte — genau das, was eine Schwelle tut,
  // wenn der Wert auf ihr liegt.
  const sev = (i % 2) ? 5 : 0;
  u.sende([pat('A', 'Bella', 9.9, sev, 'Kammerflimmern – Kreislaufstillstand'), pat('B', 'Rex', 2.51), pat('C', 'Moritz', 2.5)]);
  const jetzt = /class="gefahr"/.test(kopfVon(u, 'Bella'));
  if (jetzt !== vorher) { wechsel++; vorher = jetzt; }
}
ok('die Rotfaerbung schaltete in 30 Takten kein einziges Mal um', wechsel === 0, wechsel + ' Wechsel');
ok('sie steht dabei auf ROT (der Befund lag ja an)', vorher === true);

// ---------------------------------------------------------------------------
console.log('\n7) Ist die Gefahr wirklich vorbei, geht die Farbe zurueck:');
u.sende([pat('A', 'Bella', 2.5), pat('B', 'Rex', 2.51), pat('C', 'Moritz', 2.5)]);
ok('kurz danach steht sie noch (Haltewert)', /class="gefahr"/.test(kopfVon(u, 'Bella')));
versatz += 9000;                                    // laenger als GEFAHR_HALTE_MS (8 s)
u.sende([pat('A', 'Bella', 2.5), pat('B', 'Rex', 2.51), pat('C', 'Moritz', 2.5)]);
ok('nach Ablauf des Haltewerts ist sie weg', !/class="gefahr"/.test(kopfVon(u, 'Bella')));
ok('der Alarmtext ist mit ihr verschwunden', !/class="alarm"/.test(kopfVon(u, 'Bella')));
ok('die Reihenfolge hat sich dabei nicht geaendert',
  JSON.stringify(bildschirm(u)) === vorNotfall, JSON.stringify(bildschirm(u)));

// ---------------------------------------------------------------------------
console.log('\n8) Der Handknopf ordnet EINMAL — und danach steht es wieder still:');
ok('es gibt einen Knopf', typeof u.sortKnopf().onclick === "function");
u.sende([pat('A', 'Bella', 1.0), pat('B', 'Rex', 2.0), pat('C', 'Moritz', 8.0)]);
u.sortKnopf().onclick();
ok('nach dem Knopfdruck steht der dringlichste vorn',
  JSON.stringify(bildschirm(u)) === '["Moritz","Rex","Bella"]', JSON.stringify(bildschirm(u)));
const nachKnopf = JSON.stringify(bildschirm(u));
let spaeterGesprungen = 0;
for (let i = 0; i < 20; i++) {
  u.sende([pat('A', 'Bella', 9.0 + i), pat('B', 'Rex', 2.0), pat('C', 'Moritz', 1.0)]);
  if (JSON.stringify(bildschirm(u)) !== nachKnopf) spaeterGesprungen++;
}
ok('danach sortiert sich wieder nichts von selbst um', spaeterGesprungen === 0,
  spaeterGesprungen + ' von 20 Takten sprangen');

// ---------------------------------------------------------------------------
console.log('\n9) Kein Blinken mehr in der Stilvorlage:');
const css = fs.readFileSync(path.join(ROOT, 'ui/vetstation-shell.css'), 'utf8');
const cssOhneKommentar = css.replace(/\/\*[\s\S]*?\*\//g, ' ');
ok('die Pulsanimation der Patientenkachel ist weg', !/animation:\s*vsxpulse/.test(cssOhneKommentar));
ok('es gibt ueberhaupt keine Animation mehr in der Stationsschale',
  !/@keyframes|animation:/.test(cssOhneKommentar));
ok('der rote Patientenname ist definiert', /b\.gefahr\s*\{[^}]*color:/.test(cssOhneKommentar));
ok('der Alarmtext darf schrumpfen statt die Knoepfe abzuschneiden',
  /\.vsx-winhead \.alarm/.test(cssOhneKommentar) && /min-width:\s*0/.test(cssOhneKommentar));
const shell = fs.readFileSync(path.join(ROOT, 'ui/index.html'), 'utf8');
ok('der Knopf steht in der Leiste', /id="vsxSort"/.test(shell) && /Dringlichkeit/.test(shell));

// ---------------------------------------------------------------------------
/*
 * 10) WIE OFT wird das Markup wirklich ersetzt?
 *
 * Diese Pruefform hat gefehlt, und deshalb sind vier Bewegungsquellen durch alle bisherigen
 * Tests gegangen: tools/ui-flacker-test.js prueft rein statisch, DASS `w.__headHtml !== html`
 * im Quelltext steht — nie, wie oft der Vergleich anschlaegt. Genau das wird hier gezaehlt.
 * Gemessen am 28.08.2026 an der Fassung von morgens (alles in 40 Takten):
 *     sev 0<->4 (der 👍/👎-Block hing am ROHEN Befund) .. 40 von 40 Kopfzeilen neu
 *     sev 2<->3 (Haltewert griff erst ab 4) ............ 39 von 40 Kopfzeilen UND Leisten neu
 *     Iso 1,4<->1,5 bei ruhigem Befund ................. 39 von 40 Kopfzeilen neu
 * Jedes Neuschreiben tauscht 👍/👎/✕ aus — ein Klick, der ueber einen Neuaufbau hinweggeht,
 * trifft einen Knopf, den es beim Loslassen nicht mehr gibt.
 *
 * GEGENPROBE (von Hand gefahren am 28.08.2026): GEFAHR_HALTE_MS auf 0 -> Pruefungen zu
 * sev 0<->4 und sev 2<->3 wieder rot (40/40 bzw. 39/40); ISO_TOTBAND auf 0 -> die Iso-Pruefung
 * rot (39/40). Die Pruefungen sehen ihren eigenen Anlass also wirklich.
 */
console.log('\n10) Das Markup wird nicht mehr im Gerätetakt ersetzt:');
function zaehleTakte(bauen, machen) {
  const uu = baueUmgebung();
  uu.sende(bauen(0));
  const kopf = uu.grid.children[0].children[0], leiste2 = uu.leiste();
  const k0 = kopf._schreib, l0 = leiste2._schreib;
  for (let i = 0; i < 40; i++) uu.sende(machen(i));
  return { kopf: kopf._schreib - k0, leiste: leiste2._schreib - l0, u: uu };
}
const zA = zaehleTakte(
  () => [pat('A', 'Bella', 2.0, 4, 'Kammertachykardie')],
  (i) => [pat('A', 'Bella', 2.0, i % 2 ? 4 : 0, 'Kammertachykardie')]);
ok('ein Befund, der 0<->4 flattert, schreibt die Kopfzeile kein einziges Mal neu',
  zA.kopf === 0, zA.kopf + ' von 40');
ok('… und die Patientenleiste auch nicht', zA.leiste === 0, zA.leiste + ' von 40');
const zB = zaehleTakte(
  () => [pat('A', 'Bella', 2.0, 2, 'Hypotonie')],
  (i) => [pat('A', 'Bella', 2.0, i % 2 ? 3 : 2, 'Hypotonie')]);
ok('auch UNTERHALB der Gefahrschwelle (sev 2<->3) bleibt die Kopfzeile stehen',
  zB.kopf <= 1, zB.kopf + ' von 40');
ok('… und mit ihr die Kacheln der Leiste (sonst wandern sie waagerecht)',
  zB.leiste <= 1, zB.leiste + ' von 40');
const zC = zaehleTakte(
  () => [pat('A', 'Bella', 2.0, 0, null, { iso: 1.4 })],
  (i) => [pat('A', 'Bella', 2.0, 0, null, { iso: i % 2 ? 1.5 : 1.4 })]);
ok('ein zitternder Verdampferwert (1,4<->1,5) schreibt die Kopfzeile nicht neu',
  zC.kopf === 0, zC.kopf + ' von 40');
// Das Totband darf keine echte Aenderung schlucken — sonst waere die Ruhe erkauft mit einer Luege.
const uIso = baueUmgebung();
uIso.sende([pat('A', 'Bella', 2.0, 0, null, { iso: 1.4 })]);
const kopfIso = uIso.grid.children[0].children[0];
uIso.sende([pat('A', 'Bella', 2.0, 0, null, { iso: 1.5 })]);
ok('… ein Zehntel wird gehalten', /Iso 1\.4%/.test(kopfIso._html), kopfIso._html.slice(0, 200));
uIso.sende([pat('A', 'Bella', 2.0, 0, null, { iso: 2.2 })]);
ok('… ein wirkliches Verstellen des Verdampfers kommt sofort durch',
  /Iso 2\.2%/.test(kopfIso._html), kopfIso._html.slice(0, 200));

// ---------------------------------------------------------------------------
/*
 * 11) Der dritte Zustand "KEINE WERTE" (22.07.2026) hatte den FENSTERKOPF nie erreicht.
 * Gemessen am 28.08.2026 an einem Tier ohne einen einzigen Messwert: in der Leiste stand grau
 * "KEINE WERTE", im Fensterkopf unmittelbar daneben gruen "stabil". Dieselbe Lage, zwei
 * Aussagen — und die falsche war die beruhigende.
 */
console.log('\n11) Ein Tier ohne Messwerte sagt ueberall dasselbe:');
const uLeer = baueUmgebung();
uLeer.sende([pat('A', 'Bella', 0, 0, null, { leer: 1 })]);
const kopfLeer = uLeer.grid.children[0].children[0]._html;
ok('der Fensterkopf sagt "KEINE WERTE"', /<span class="pr">KEINE WERTE<\/span>/.test(kopfLeer),
  kopfLeer.slice(0, 220));
ok('er sagt NICHT "stabil"', kopfLeer.indexOf('>stabil<') < 0, kopfLeer.slice(0, 220));
ok('die Leiste sagt dasselbe', /<span class="pr">KEINE WERTE<\/span>/.test(uLeer.leiste()._html));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
