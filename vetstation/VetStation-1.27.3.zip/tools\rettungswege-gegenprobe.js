'use strict';
/* =============================================================================================
 * rettungswege-gegenprobe.js — sieht rassen-test.js die Schaeden an den Rettungswegen? (24.08.2026)
 * =============================================================================================
 *
 * Die Rettungswege der Zwischenfallkarten koennen auf DREI Arten still ausfallen:
 *   1. toter Verweis      — die Karte nennt einen Weg, den es nicht gibt: nichts erscheint
 *   2. stumme Tierart     — die Karte traegt nur artgebundene Wege, rescueFor() filtert sie
 *                           fuer alle anderen Arten weg: der Block bleibt leer, wortlos
 *   3. Anzeige entkoppelt — die Daten stehen da, aber renderProto() haengt sie nicht mehr an
 * Keiner dieser drei faerbt von sich aus irgendetwas rot. Diese Datei setzt jeden einzeln und
 * verlangt, dass tools/rassen-test.js rot wird.
 *
 * VERAENDERT KURZ ECHTE QUELLDATEIEN und stellt sie danach wieder her — laeuft deshalb NICHT im
 * Sammellauf, sondern von Hand:
 *     dist/VetStation/node/node.exe tools/rettungswege-gegenprobe.js
 * ============================================================================================= */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const WURZEL = path.join(__dirname, '..');
const NODE = path.join(WURZEL, 'dist', 'VetStation', 'node', 'node.exe');
const TEST = path.join(__dirname, 'rassen-test.js');

const DATA = path.join(WURZEL, 'ui', 'app', 'anaes-data.js');
const APP = path.join(WURZEL, 'ui', 'app', 'index.html');

const ORIG = {};
[DATA, APP].forEach((f) => { ORIG[f] = fs.readFileSync(f, 'utf8'); });
function summe(s) { return crypto.createHash('sha256').update(s).digest('hex').slice(0, 12); }
const VORHER = {};
Object.keys(ORIG).forEach((f) => { VORHER[f] = summe(ORIG[f]); });

const SCHAEDEN = [
  [DATA, "rescue:['alpha2-ueberdosis','opioid-ueberhang','hyperkaliaemie','hypothermie','kaninchen-notfall'],", '',
    'eine Karte verliert ihre Wege ganz'],
  [DATA, "rescue:['mh-krise'],", "rescue:['mh-krise','gibt-es-nicht'],",
    'toter Verweis auf einen Weg, den es nicht gibt'],
  [DATA, "rescue:['mh-krise'],", "rescue:['kaninchen-notfall'],",
    'eine Karte traegt NUR einen artgebundenen Weg — fuer elf Arten stumm'],
  [DATA, "      causes:['Zu flache Narkose / Schmerz','Hyperkapnie (CO₂-Rückatmung, erschöpfter Atemkalk)'",
    "      rescue:['cpr'],\n      causes:['Zu flache Narkose / Schmerz','Hyperkapnie (CO₂-Rückatmung, erschöpfter Atemkalk)'",
    'die absichtlich leere Karte bekommt unbemerkt Wege'],
  [APP, 'html+=rettungHtml(i);', '',
    'die Anzeige haengt den Block nicht mehr an'],
  [APP, 'html+=rettungHtml(i);\n  box.innerHTML=html;', 'box.innerHTML=html;\n  html+=rettungHtml(i);',
    'der Block wird NACH box.innerHTML angehaengt — beim naechsten Takt weg'],
  [APP, '<details class="proto-rettung">', '<details class="proto-rettung" open>',
    'der Block startet aufgeklappt und schiebt die Schrittliste aus dem Bild'],
  [APP, 'class="proto-rettung"><summary class="sec-h"', 'class="proto-rettung"><summary style="color:#8a8"',
    'eine eigene Farbe statt der vermessenen Klasse'],
  [APP, "if(!VB||!VB.rescueFor||!i||!i.rescue||!i.rescue.length) return '';", 'if(!i) return \'\';',
    'der Rueckzieher faellt weg — ohne Katalog wirft die Anzeige'],
];

console.log('Gegenprobe: wird rassen-test.js bei jedem einzelnen Schaden rot?\n');

function testLaeuft() {
  try { execFileSync(NODE, [TEST], { stdio: 'pipe' }); return true; }
  catch (_) { return false; }
}

let gut = 0, schlecht = 0;
try {
  if (!testLaeuft()) {
    console.log('  ABBRUCH: rassen-test.js ist schon OHNE Schaden rot. Erst den beheben.');
    process.exit(1);
  }
  console.log('  (unveraendert: gruen — die Ausgangslage stimmt)\n');

  SCHAEDEN.forEach(([datei, suchen, ersetzen, was], i) => {
    const text = ORIG[datei];
    const treffer = text.split(suchen).length - 1;
    const nr = String(i + 1).padStart(2, ' ');
    if (treffer !== 1) {
      schlecht++;
      console.log('  ' + nr + ') ✗ ' + was + '\n         -> die Stelle kommt ' + treffer
        + '-mal vor, erwartet genau 1. Der Schaden waere gar nicht gesetzt worden.');
      return;
    }
    fs.writeFileSync(datei, text.replace(suchen, () => ersetzen), 'utf8');
    const rot = !testLaeuft();
    fs.writeFileSync(datei, text, 'utf8');
    if (rot) { gut++; console.log('  ' + nr + ') ✓ rot bei: ' + was); }
    else {
      schlecht++;
      console.log('  ' + nr + ') ✗ BLIND: ' + was + '\n         -> ' + path.basename(datei)
        + ', der Test blieb gruen.');
    }
  });
} finally {
  Object.keys(ORIG).forEach((f) => { fs.writeFileSync(f, ORIG[f], 'utf8'); });
}

console.log('\n---------------------------------------------');
let heil = true;
Object.keys(ORIG).forEach((f) => {
  if (summe(fs.readFileSync(f, 'utf8')) !== VORHER[f]) { heil = false; console.log('  !! NICHT WIEDERHERGESTELLT: ' + f); }
});
console.log('  Quelldateien unveraendert: ' + (heil ? 'ja' : 'NEIN — von Hand pruefen!'));
console.log('  Schaeden erkannt: ' + gut + ' von ' + SCHAEDEN.length + (schlecht ? '   BLIND: ' + schlecht : ''));
if (schlecht || !heil) process.exit(1);
console.log('  Der Test sieht jeden dieser Schaeden.');
