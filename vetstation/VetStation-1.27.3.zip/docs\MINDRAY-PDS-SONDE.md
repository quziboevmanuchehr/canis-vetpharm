# Der Monitor sendet keine laufenden Messwerte — so wird er befragt (PDS-SONDE.bat)

> # ⛔ WÄHREND EINER NARKOSE WIRD NICHT GEMESSEN
>
> Die Sonde baut **acht Verbindungen** zum Monitor auf (eine je Variante). Am **26.07.2026** wurde am
> echten Gerät beobachtet: **es weist eine zweite abfragende Verbindung ab, während die Station eine
> hält.** Daraus folgen zwei Dinge, und beide sind schlecht:
>
> * **Abgewiesen werden kann auch die Station.** Dann fehlen am narkotisierten Patienten für die Dauer
>   der Messung die Werte — also gut drei Minuten lang.
> * **Der Befund wäre wertlos.** Eine stumme Variante hieße dann nur „der Platz war belegt", nicht
>   „die Abfrage war falsch". Man misst drei Minuten und weiß hinterher nichts.
>
> **Richtig ist:** die Narkose zu Ende führen → **die VetStation beenden** → dann die Sonde starten.
>
> Die Sonde passt selbst auf: sie sieht nach, ob die Station auf diesem PC läuft, und **bricht ab**,
> wenn sie läuft — ohne zu messen und ohne eine Befunddatei zu schreiben. Nur wer **sicher** ist, dass
> **kein Patient angeschlossen** ist, kann sie mit `--trotzdem` erzwingen; dann steht dieser Umstand
> auch im Kopf des Befundes, damit der Entwickler ihn mitliest.
>
> *(Der Programmer's Guide nennt für den Realtime-Weg keine Höchstzahl gleichzeitiger Gegenstellen —
> §6.3.3 und §6.3.5 schweigen dazu. Für die andere Schnittstelle schreibt er es ausdrücklich: „Once the
> number of connected client sockets reaches the maximum, new client socket connection will be
> rejected" (§2.1.1). Maßgeblich ist hier aber nicht das Handbuch, sondern die **Beobachtung am echten
> Gerät vom 26.07.2026**.)*

> **Warum es diese Anleitung gibt (28.08.2026).** Am Praxis-PC hängt ein **Mindray uMEC12 Vet**.
> Gemessen ist: über HL7 kommen dort **Patientendaten, Blutdruck (NIBP) und Alarme** an — die
> **laufenden Messwerte** (Herzfrequenz 101, SpO₂ 160, Temperatur 200, CO₂ 220 …) kommen **nicht**.
> Woran das liegt, lässt sich am Entwicklungsrechner **nicht** feststellen: das Gerät steht in der
> Praxis. Jede Vermutung dazu ist bis heute unbelegt. `PDS-SONDE.bat` fragt das Gerät **selbst** und
> schreibt einen Befund. Diese Anleitung sagt, in welcher Reihenfolge das gemacht werden muss —
> denn eine halbe Vorbereitung erzeugt genau denselben stummen Monitor wie der echte Fehler.

---

## Was die Sonde tut, in einem Satz

Sie stellt dem Gerät **achtmal fast dieselbe Frage** und ändert dabei jedes Mal **genau eine
Kleinigkeit**. Die erste Frage, auf die Messwerte kommen, zeigt, welche Kleinigkeit gefehlt hat.

**Dauer:** gut drei Minuten (acht Varianten zu je 25 Sekunden).

## Was die Sonde NICHT tut

* Sie **verstellt am Gerät nichts** und schreibt nichts auf das Gerät. Sie fragt und hört zu.
* Sie **ändert an der Station nichts** — auch `bridge/config/devices.json` nicht.
* Der Befund enthält **keinen Patientennamen, keine Kennung, keine Aktennummer**. Die werden
  entfernt, bevor irgendetwas auf die Platte geht — auch aus der Maschinendatei `.json`.
* Sie ist **kein Ersatz für `GERAETE-PRUEFEN.bat`**. Das beantwortet in Sekunden „kommt überhaupt
  etwas an?“. Die Sonde beantwortet „warum kommen die laufenden Werte **nicht** an?“.

---

## Vorbereitung — bitte in dieser Reihenfolge

### 1. Kabel und Netz

PC und Geräte an **einen** Switch (siehe [LAN-SETUP.md](LAN-SETUP.md)). Am Monitor muss die
Netzwerkbuchse leuchten. Ein WLAN-Umweg oder ein Router dazwischen ist hier nicht vorgesehen.

### 2. `NETZWERK-EINRICHTEN.bat` doppelklicken

Liegt in `C:\VetStation` und im *Startmenü → VetStation*. Sie holt sich die Adminrechte selbst
(UAC mit **Ja** bestätigen) und setzt den PC auf **192.168.0.99** / 255.255.255.0, **kein Gateway**.
Vorgesehene Geräteadressen: **uMEC12 Vet = 192.168.0.50**, LifeVet = 192.168.0.51.

Im **isolierten** Gerätenetz (eigener Switch, kein Router) ist das der einzige nötige Netzschritt.

### 3. Gerät einschalten **und Sensoren anlegen**

Das ist kein Nebensatz, sondern die naheliegendste Fehlerquelle: **Wo nichts gemessen wird, kann auch
nichts gesendet werden.** Am Monitor müssen **Zahlen stehen** — mindestens Herzfrequenz und SpO₂.
Ein Monitor ohne Sensor am Tier beantwortet jede Abfrage korrekt und liefert trotzdem nichts. Der
Befund wäre dann eine Stille, die gar keine Störung ist.

Für eine Prüfung ohne Patient reicht ein **SpO₂-Clip am eigenen Finger** und, wenn vorhanden, der
**Demo-/Simulationsmodus** des Geräts.

### 4. Am Gerät die Netzwerkeinstellungen **ablesen** — nicht verstellen

Am uMEC12 Vet (Touch):
`Hauptmenü → Wartung/Maintenance → Benutzer-Wartung` — Passwort **888888**
(Werks-/Factory-Wartung `332888`, Demo `2088`) → `Netzwerk` / `Netzwerk-Setup`.

> ### ⛔ Hier wird nichts geändert
> Am **25.07.2026** wurde das Ziel unter `Gateway-Kommunikationseinst.` umgestellt — und das hat den
> **funktionierenden Blutdruckweg zerstört**. Der Blutdruck ist heute der einzige Messwert, der im OP
> zuverlässig ankommt. Diese Anleitung hat früher an dieser Stelle verlangt, **Port 3502**
> einzutragen. **Das ist gestrichen.** Am 28.08.2026 wurde am Gerät abgelesen, worauf es wirklich
> steht — und es steht bereits richtig.

So soll es aussehen (abgelesen am Praxisgerät, 28.08.2026). **Stimmt es, ist nichts zu tun:**

| Feld | Abgelesener Wert | Warum das passt |
|---|---|---|
| IP des Monitors | **192.168.0.50** | die Adresse, mit der die Sonde gestartet wird |
| Subnetzmaske | 255.255.255.0 | dasselbe Netz wie der PC aus Schritt 2 |
| Gateway | 192.168.0.1 | ohne Belang im isolierten Gerätenetz |
| Adresstyp | **Manuell** | eine feste IP wechselt nicht weg |
| `Gateway-Kommunikationseinst.` → Ziel | **192.168.0.99, Port 4601** | 4601 ist genau der Port, den die Sonde anspricht |
| `HL7 Compatibility` | **Ein** | der HL7-Schalter ist also **nicht** die Ursache |

**Weicht etwas davon ab: bitte nur abschreiben oder fotografieren und mitschicken.** Ändern soll das
der Entwickler entscheiden, nicht die Anleitung — an dieser Einstellung hängt der Blutdruck.

Die IP **des Geräts** wird gleich gebraucht — bitte notieren.

> Die Sonde spricht den Abfrageweg auf **Port 4601** an (Realtime-Ergebnisse). Das ist der Weg, auf
> dem die laufenden Messwerte kommen sollen.

### 5. Die VetStation beenden

Steht ganz oben im roten Kasten, gehört aber auch in die Reihenfolge: **läuft die Station, wird nicht
gemessen.** Fenster von `START-VetStation.bat` schließen (oder den Rechner neu starten und die Station
diesmal nicht starten). Die Sonde prüft das selbst nach und bricht ab, wenn die Station noch läuft.

### 6. Am Gerät `CaptureNetPackage` einschalten

Das ist neu und lohnt sich, denn es ist die **einzige Sicht aus dem Gerät heraus**, die wir haben.

Im selben Netzwerk-Menü wie in Schritt 4 steht `CaptureNetPackage` (im Normalbetrieb **aus**). Wird er
eingeschaltet, zeichnet der Monitor seinen **eigenen** Netzverkehr auf; mit `Export Net Package File`
kommt die Aufzeichnung auf einen **USB-Stick**.

**Warum das so wertvoll ist:** Schweigt das Gerät, kann der PC drei völlig verschiedene Fälle nicht
auseinanderhalten — „meine Frage kam nie an", „sie kam an und wurde verworfen", „sie kam an, war
richtig, und es hat trotzdem nichts gesendet". Der Monitor sieht in allen drei Fällen gleich stumm aus.
Der Mitschnitt **aus seiner Sicht** trennt sie.

**Jetzt also: `CaptureNetPackage` → ein.** (Nach der Messung wird er in Schritt 8 wieder ausgeschaltet.)

Ist der Punkt am Gerät nicht zu finden, ist das kein Beinbruch — dann einfach ohne ihn weitermachen und
es im Begleittext erwähnen. Die Sonde misst auch allein.

### 7. Erst jetzt: `PDS-SONDE.bat`

Doppelklick in `C:\VetStation`. **Mit der Geräte-IP ist es sicherer**, weil dann nichts gesucht
werden muss. Dazu die Datei aus der Eingabeaufforderung starten oder eine Verknüpfung anlegen, bei
der die IP hinter dem Dateinamen steht:

```
PDS-SONDE.bat 192.168.0.50
```

Ohne Angabe sucht das Programm die Adresse in der ARP-Tabelle des PCs — das gelingt nur, wenn der PC
vorher schon einmal mit dem Gerät gesprochen hat. Findet es nichts, **rät es nicht**, sondern sagt,
dass die IP mitzugeben ist.

> ⚠️ **Die IP bitte trotzdem mitgeben.** Die Suche erkennt Mindray-Geräte am Anfang ihrer
> MAC-Adresse (`98:CC:E4`) — und **Monitor und Narkosegerät fangen beide so an**. Am 28.08.2026 wurden
> beide Adressen an echten Geräten abgelesen: sie stimmen sogar noch im vierten Byte überein und
> unterscheiden sich erst im fünften. (Die vollständigen Adressen stehen hier nicht — sie benennen die
> Geräte einer einzelnen Praxis, und diese Anleitung geht mit jedem Update an jede Station; 29.08.2026.
> Für die Warnung genügt, dass die Suche die beiden nicht trennen kann.) Ohne Angabe kann die Sonde auf
> dem **Narkosegerät** landen und dort eine Stille messen, die über den Monitor gar nichts aussagt.
> Mit `PDS-SONDE.bat 192.168.0.50` kann das nicht passieren.

Das Fenster bitte offen lassen, bis „BITTE DIESE DATEI AN DEN ENTWICKLER SCHICKEN“ erscheint.

### 8. Nach der Messung: den Mitschnitt vom Gerät holen

Nur nötig, wenn Schritt 6 gemacht wurde:

1. Am Gerät `CaptureNetPackage` wieder auf **aus**.
2. **USB-Stick** anstecken → `Export Net Package File`.
3. Danach `Delete Net Package File`, damit der Gerätespeicher nicht vollläuft.
4. Die Datei vom Stick **zusammen mit den beiden Befunddateien** an den Entwickler schicken.

**Ehrlich dazu:** Wir wissen nicht, in welchem Format der Monitor diese Datei schreibt — im
Programmer's Guide steht das nicht. Es kann also sein, dass sie sich nicht auswerten lässt. Sie kostet
zwei Knopfdrücke, und wenn sie lesbar ist, beantwortet sie die Frage endgültig. Deshalb: mitschicken,
aber sich nicht darauf verlassen.

---

## Das Ergebnis

Die Sonde schreibt zwei Dateien nach `C:\VetStation\data`:

* `pds-befund-<Datum>-<Uhrzeit>.txt` — zum Lesen, reines ASCII
* `pds-befund-<Datum>-<Uhrzeit>.json` — dieselben Zahlen für den Entwickler

**Beide bitte an den Entwickler schicken.** Sie enthalten keine Patientendaten.

Unten im `.txt` steht unter **GESAMTURTEIL** einer von drei Sätzen.

### Ergebnis 1 — „Ab Variante N kamen laufende Messwerte“

**Das ist der gute Fall.** Die Ursache ist gefunden und steht im Klartext daneben (fehlende Kennung,
fehlendes Echo, falscher Zeitstempel …).

*Zu tun:* den Befund schicken. Unter **WAS JETZT ZU TUN IST** steht, was in
`bridge/config/devices.json` beim Eintrag des Monitors einzutragen ist — in der Regel
`"pdsStrict": true` **und** `"ack": false`. Danach die Station neu starten und im Cockpit nachsehen,
ob Herzfrequenz und SpO₂ laufen. Diesen Eintrag bitte **nicht an einem OP-Tag** ändern und vorher
eine Kopie von `devices.json` sichern: der Blutdruck läuft heute, und er soll auch morgen laufen.

### Ergebnis 2 — „KEINE der gefahrenen Varianten brachte laufende Messwerte“

Das Gerät **antwortet** (Patientendaten, Blutdruck und Alarme sind angekommen), sendet die laufenden
Werte aber auf keine der acht Fragen. Dann liegt es **nicht an der Form der Abfrage**.

*Zu tun:* zuerst Schritt 3 gegenprüfen — standen am Monitor wirklich Zahlen? Dann am Gerät prüfen,
ob die Ausgabe der laufenden Messwerte überhaupt freigeschaltet ist (der uMEC12 zeigt HL7 nicht in
jedem Menü; für die Realtime-Ausgabe kann eine **Lizenz** nötig sein — dann bei Eickemeyer
erfragen). Und den Befund schicken: er hält fest, ob das Gerät Fehlersegmente (MSA/ERR/QAK)
geschickt hat, und die sagen dem Entwickler direkt, was es beanstandet.

### Ergebnis 3 — „Das Gerät antwortet nicht … es kam überhaupt keine Verbindung zustande“

Es gibt keinen Kontakt. Der Befund ist dann in wenigen Sekunden fertig und nennt vier Prüfschritte:

1. Steckt das Netzwerkkabel am Monitor, und leuchtet die Buchse?
2. Stimmt die IP? Am Gerät nachsehen und die Sonde mit **dieser** Adresse noch einmal starten.
3. Ist am Gerät die Datenausgabe eingeschaltet und Port 4601 freigegeben?
4. Blockiert die Windows-Firewall des Praxis-PCs? → `FIREWALL-FREIGEBEN.bat`

*Zu tun:* die Punkte abarbeiten, dann noch einmal starten. Erst wenn Kontakt besteht, sagt die Sonde
überhaupt etwas über die Ursache.

> **Sonderfall.** Steht im Urteil „Das Gerät schickt laufende Messwerte AUCH OHNE jede Abfrage“, dann
> liegt der Fehler in der **Station**, nicht am Gerät: sie wertet Nachrichten nicht aus, die längst
> ankommen. Dann nur den Befund schicken; am Gerät ist nichts zu tun.

---

## Der Veta 5 Plus (das Narkosegerät)

**Dieselbe Sonde, andere IP:**

```
PDS-SONDE.bat 192.168.0.52
```

(`.52`, **nicht** `.50` — so ist es am Gerät unter `System → Setup → Netzwerk einr.` eingestellt.)

**Das gelbe Netzwerkkabel im CS-Anschluss steckt richtig.** Bis zum 28.08.2026 stand in unserer
Dokumentation, CS sei ausschließlich ein Anschluss für Firmware-Updates. Das war falsch, die Fotos des
Geräts zeigen ein vollständiges Netzwerk-Menü (feste IP, Maske, Gateway, DNS) und daneben
„CentralStation Verbindung". CS ist die **Netzwerkbuchse**.

**Trotzdem: hier ist kein Erfolg zu erwarten, und das ist kein Fehler.** Der Schalter im Gerätemenü
heißt **MD2** — das ist Mindrays eigenes, nicht veröffentlichtes Protokoll. Dafür gibt es keinen
öffentlichen Decoder, VetStation liest es nicht, und niemand sonst tut es. Was auf `.52` kommen kann:

* **„Keine Verbindung"** — dann spricht das Gerät auf diesem Weg nicht. Kein Defekt.
* **Etwas, das kein HL7 ist** — dann ist es mit hoher Wahrscheinlichkeit MD2. Auch dann sind wir
  nicht weiter, aber wir wissen es **belegt** statt vermutet.
* **HL7** — damit rechnet niemand, und es wäre die Überraschung des Jahres. Der Befund würde es zeigen.

**Die Sonde MISST dort also nur.** Sie sendet auch an das Narkosegerät nichts anderes als Abfrage, Echo
und Quittung; sie **verstellt nichts** und schaltet nichts ein. Ein Narkosegerät ist kein Ort für
Versuche — deshalb sei es ausdrücklich gesagt: **auch dieser Lauf gehört nicht in eine laufende
Narkose**, es gilt dieselbe Regel wie ganz oben.

Der Befund ist auch bei „keine Verbindung" wertvoll: er ist die **erste Messung**, die wir über dieses
Gerät überhaupt haben — bisher gibt es nur Handbuchlesen und Fotos.

## Der Kapnograph

**Dieselbe Sonde, andere IP:**

```
PDS-SONDE.bat 192.168.0.52
```

(die tatsächliche Adresse steht am Kapnographen im Netzwerk-Menü).

**Ehrlich dazugesagt:** Wir kennen **Fabrikat und Schnittstelle des Kapnographen noch nicht**. Ob er
überhaupt HL7 spricht, ob er auf 4601 hört und ob er die Mindray-Abfrage versteht, ist **ungeprüft**.
Deshalb gilt hier ausdrücklich:

* Die Sonde **misst dort erst einmal nur**. Sie sendet auch an ihn nichts anderes als Abfrage, Echo
  und Quittung — verstellen kann sie ihn also nicht.
* Kommt „keine Verbindung zustande“, ist das **kein Defekt und kein Beweis gegen das Gerät**. Es
  heißt nur: auf diesem Weg spricht es nicht. Dann brauchen wir Fabrikat und Modell vom Typenschild
  und das Netzwerk-Menü als Foto — damit lässt sich klären, welche Schnittstelle es überhaupt hat.
* Der Befund des Kapnographen ist auch dann wertvoll: er ist der erste belegte Stand über dieses
  Gerät, den wir haben.

Bitte **alle** Befunde schicken (Monitor, Narkosegerät, Kapnograph) — sie liegen nebeneinander im
Ordner `data`, und der Dateiname enthält Datum und Uhrzeit, sodass sie sich nicht überschreiben.

---

## Kurzfassung zum Ausdrucken

**0. KEINE NARKOSE. Kein Patient am Monitor.**

1. Kabel am Switch, Buchse leuchtet.
2. `NETZWERK-EINRICHTEN.bat` — der PC wird 192.168.0.99.
3. Gerät ein, **Sensoren anlegen, bis Zahlen am Monitor stehen**.
4. Am Gerät: Wartung (888888) → Netzwerk. **Nur ablesen, nichts umstellen** — Ziel steht auf
   192.168.0.99 Port 4601, Adresstyp manuell, HL7 Compatibility ein. Geräte-IP notieren
   (Monitor `192.168.0.50`).
5. **VetStation beenden.**
6. Am Gerät `CaptureNetPackage` → **ein** (falls vorhanden).
7. `PDS-SONDE.bat <Geräte-IP>` — gut drei Minuten warten.
8. `CaptureNetPackage` → **aus**, `Export Net Package File` auf USB, dann
   `Delete Net Package File`.
9. Die beiden Dateien aus `C:\VetStation\data` **und** die Datei vom USB-Stick an den Entwickler
   schicken.

Am Gerät wird dabei **nichts verstellt** (`CaptureNetPackage` ist eine Aufzeichnung, keine
Betriebseinstellung, und wird in Schritt 8 zurückgenommen), an der Station **nichts geändert**.
