'use strict';
/*
 * pds-streng-test.js — bewacht die PDS-Abfrage gegen ein STRENGES Testgeraet
 * (28.08.2026, auf die Messung am echten Geraet umgestellt am 29.08.2026).
 *
 * WARUM ES DIESE DATEI GIBT:
 * tools/hl7-client-test.js stellt ein nachgiebiges Fake-Geraet ("antwortet auf jede Nachricht,
 * in der irgendwo QRY steht"). Es kann weder den Ausfall des echten uMEC12 Vet nachstellen
 * noch seine Bedingungen — deshalb war jener Test seit jeher gruen, waehrend am Praxis-PC
 * gemessen NUR Patientendaten, NIBP und Alarme ankamen und die Periodik fehlte. Ein
 * Testgeraet, das den Ausfall nicht erzeugen kann, ist kein Zeuge.
 *
 * =======================================================================================
 * WAS SICH IN DER NACHT AUF DEN 29.08.2026 GEAENDERT HAT — UND WARUM DIESE DATEI UMGEBAUT
 * WURDE (der Abschnitt gehoert gelesen, bevor jemand hier etwas "aufraeumt"):
 *
 * Am echten uMEC12 Vet, mit Sensoren am Patienten, wurde gemessen: der VORGABE-Zweig von
 * bridge/src/adapters/hl7.js liefert HF, SpO2, Puls, Temperatur, Atemfrequenz und Blutdruck,
 * sobald zwei Zeichenfolgen stimmen, die vorher falsch waren:
 *   1. MSH-10 muss WOERTLICH "1203" sein (Guide 6.9.3 NOTE). Dort stand eine laufende Nummer.
 *   2. Hinter das LETZTE Segment gehoert ein <CR>. Auf der Leitung stand "...&222<FS><CR>"
 *      statt "...&222<CR><FS><CR>".
 * Beides ist im Vorgabe-Zweig behoben. Damit ist die Aussage, um derentwillen der Abschnitt
 * (a) dieser Datei frueher existierte, HINFAELLIG: er hiess "OHNE pdsStrict: das heutige
 * Krankheitsbild" und verlangte, das strenge Testgeraet VERWERFE die Vorgabe-Abfrage. Sie
 * wird jetzt angenommen. Eine Zusicherung, die eine angenagelte Entscheidung festhaelt statt
 * einer Aussage, wird rot, sobald die Entscheidung sich als falsch herausstellt — und genau
 * das ist hier passiert. Sie ist deshalb umgedreht, nicht abgeschaltet.
 *
 * DIE SPEZIFIKATIONSTREUE LESART IST DIE FALSCHE. Am selben Abend wurden die Varianten 3
 * bis 8 der Feldsonde mitgemessen — eine Abfrage je Verbindung, 1-Sekunden-Echo, KEINE
 * Quittung, also genau das, was "pdsStrict" tut. Sie lieferten NICHTS. Was liefert, ist der
 * alte Weg mit Wiederholung alle 5 s und Quittung auf jede Nachricht PLUS die beiden
 * Korrekturen oben. "pdsStrict" bleibt trotzdem im Baum und wird hier weiter gefahren —
 * aber als Bauteil, das mechanisch funktioniert, NICHT als der bessere Weg. Wer ihn zur
 * Vorgabe macht, weil er "endlich spezifikationstreu" ist, nimmt dem Tierarzt am
 * narkotisierten Patienten alle Messwerte weg.
 * =======================================================================================
 *
 * Dieser Test faehrt den ECHTEN Adapter (bridge/src/adapters/hl7.js) gegen das strenge
 * Testgeraet (tools/pds-testgeraet.js) und haelt sieben Aussagen fest:
 *
 *   (a) OHNE "pdsStrict" — der PRODUKTIVE Weg, und deshalb der wichtigste Abschnitt der
 *       Datei: das strenge Testgeraet NIMMT die Vorgabe-Abfrage AN (MSH-10 = 1203, <CR>
 *       hinter dem letzten Segment), die Periodik laeuft an, HF 88 / SpO2 96 / EtCO2 39
 *       kommen in der Station an. Geprueft wird an dem, was das GERAET empfangen hat, nicht
 *       am Quelltext des Adapters.
 *       Zweiter Befund im selben Abschnitt: das strenge Geraet trennt danach wegen unserer
 *       Quittung (Guide 6.3.3 Punkt 9). DAS ECHTE GERAET TUT DAS NICHT — dort laeuft genau
 *       dieser Weg mit Quittung seit dem 29.08.2026 im Dauerbetrieb. Die Regel ist eine
 *       Lesart des Guides, kein Befund; sie steht hier, damit niemand die Quittung aus dem
 *       Adapter entfernt und sich dabei auf "das Testgeraet trennt ja" beruft.
 *   (b) DERSELBE Adapterzweig gegen das Profil 'ohne-echopflicht' — die Lesart, die sich am
 *       echten Geraet bestaetigt hat (kein Echo verlangt, keine Trennung wegen der Quittung).
 *       Erst dort ist "liefert Periodik" ein STROM und nicht eine einzige Nachricht: das ist
 *       die Aussage, die dem Praxis-PC entspricht.
 *   (c) MIT "pdsStrict" funktioniert der zweite Zweig weiterhin mechanisch: das strenge
 *       Geraet nimmt auch ihn an, HF 88, SpO2 96, EtCO2 39 kommen an. Siehe die Warnung oben:
 *       am ECHTEN Geraet hat dieser Weg NICHTS geliefert.
 *   (d) Die Vorgabe-Abfrage ist auf der LEITUNG Byte fuer Byte der neue Sollwert: MSH-10 =
 *       1203, sechs QRF-Segmente mit den belegten Kennziffern, <CR> hinter dem letzten
 *       Segment — und OHNE die Kennziffer 302. Der frueher danebenstehende Vergleich gegen
 *       dist/VetStation/bridge/src/adapters/hl7.js ist ersatzlos entfallen: er hielt den
 *       Stand fest, "der am Praxis-PC laeuft", und genau dieser Stand ist seit dem
 *       29.08.2026 als der stumme erwiesen. Ein Bezugspunkt, der das Falsche festnagelt,
 *       ist schlimmer als keiner.
 *   (e) DAS <CR>-TOR am Testgeraet: dieselben Bytes einmal mit und einmal ohne
 *       abschliessendes <CR> — angenommen und verworfen, mit dem Grund im Bericht.
 *   (f) MIT "pdsStrict" trennt das Geraet NICHT, weil das 1-Sekunden-Echo laeuft (Guide 6.7).
 *   (g) AUF DEM LISTENER-WEG wirkt "pdsStrict" gar nicht. Der Schalter meint die PDS-Abfrage
 *       aus Kapitel 6; ein Listener ist der Push-Weg aus Kapitel 2 und hat keine Abfrage.
 *       Bis zum 28.08.2026 schaltete er dort still die Quittung ab — ein Schalter, der mehr
 *       tut als sein Name ankuendigt.
 *
 * ZEITEN (nachgezogen am 28.08.2026): Punkt (f) misst im Betrieb gegen eine Echo-Frist von
 * 10 s. Hier laeuft das Testgeraet mit echoFristMs = 3000; die Frist ist damit dieselbe
 * Aussage, nur um den Faktor 3,3 gestaucht. Vorher wurde nach 5000 ms nachgesehen — das
 * 1,67-fache der Frist, also 67 % Luft; die Echo-Zaehlung hatte bei gemessenen vier Echos
 * gegen eine Erwartung von drei sogar nur EINEN Takt Reserve. Unter Nebenlast ist das eine
 * Zeitmessung, die umkippt, ohne dass etwas kaputt ist (in diesem Projekt schon vorgekommen,
 * siehe ekg-analyse-test.js:228). Jetzt gilt:
 *   - Wo es ein EREIGNIS gibt, wird darauf gewartet, nicht auf die Uhr (warteBis()).
 *   - Wo nur Zeit vergehen kann — "das Geraet hat NICHT getrennt" ist so ein Fall —, wird
 *     die doppelte Frist abgewartet: 100 % Luft, nicht 67 %.
 * Dass die Frist WIRKLICH scharf ist, weist derselbe Abschnitt am selben Geraet mit einer
 * stillen Gegenprobe nach (eine Verbindung, die nicht echot, wird getrennt) — sonst waere
 * "trennungen === 0" eine Pruefung ohne Anlass.
 *
 * PORTS: das Betriebssystem gibt sie (listen(0)), abgelesen wird geraet.port. Feste Nummern
 * haben in dieser Sitzung ein EADDRINUSE erzeugt, als zwei Laeufe gleichzeitig liefen — rot,
 * ohne dass etwas kaputt war. Ein Port, den das System eben erst vergeben hat, kann mit
 * nichts kollidieren; die Hausregel "45600-45699" soll die Kollision mit echten Diensten
 * (Geraeteport 4601, Station 8770) verhindern, und die ist damit erst recht ausgeschlossen.
 * AUSNAHME (g): dort lauscht der ADAPTER selbst, und sein Konstruktor rechnet
 * `cfg.port || cfg.listenPort || 5000` — die 0 ist falsy, listen(0) wuerde also auf Port 5000
 * landen. Deshalb stehen dort zwei feste Nummern aus dem Hausbereich (45621/45622).
 *
 * Start:  dist/VetStation/node/node.exe tools/pds-streng-test.js
 */

const net = require('net');
const { starte } = require('./pds-testgeraet');
const { HL7Adapter } = require('../bridge/src/adapters/hl7');
const geraetefund = require('../bridge/src/geraetefund');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
const HOST = '127.0.0.1';
/* Die Echo-Frist des Testgeraets in (f) und die Wartezeit, die daraus folgt. Beide stehen
 * hier zusammen, damit niemand die eine aendert und die andere vergisst — genau so entsteht
 * eine Zeitmessung ohne Luft. */
const ECHO_FRIST_MS = 3000;
const OHNE_TRENNUNG_MS = ECHO_FRIST_MS * 2 + 500;

let bestanden = 0, fehlgeschlagen = 0;
function ok(bedingung, text, zusatz) {
  const z = zusatz === undefined || zusatz === null || zusatz === '' ? '' : '   [' + zusatz + ']';
  if (bedingung) { bestanden++; console.log('  ✓ ' + text + z); }
  else { fehlgeschlagen++; console.log('  ✗ FAIL: ' + text + z); }
}
function warte(ms) { return new Promise((r) => setTimeout(r, Math.max(0, ms))); }
/*
 * warteBis(pruefung, hoechstensMs) — auf das EREIGNIS warten statt auf die Uhr.
 *
 * Eine feste Frist misst zwei Dinge auf einmal: die Aussage und die Auslastung des Rechners.
 * Wo es etwas Zaehlbares gibt (drei Echos sind angekommen), wird deshalb nachgesehen, bis es
 * da ist. Die Hoechstwartezeit ist nur der Notausgang, nicht das Mass — sie darf deshalb
 * grosszuegig sein, ohne den Test langsam zu machen.
 */
async function warteBis(pruefung, hoechstensMs, taktMs) {
  const bis = Date.now() + hoechstensMs;
  while (Date.now() < bis) {
    if (pruefung()) return true;
    await warte(taktMs || 50);
  }
  return !!pruefung();
}
/* Mit eigener Frist: laesst sich der Port nicht binden (ein vergessenes Testgeraet, eine
 * laufende Station), meldet starte() das nur ueber onLog und bereit() kaeme NIE. Ohne diese
 * Frist liefe der Test stumm ins 90-s-Zeitlimit, und die Ursache staende nirgends. */
function bereit(g, log) {
  return new Promise((r, j) => {
    const frist = setTimeout(() => j(new Error('Testgeraet auf Port ' + g.port +
      ' wurde nicht bereit. Ist der Port belegt? ' + (log || []).join(' | '))), 5000);
    g.bereit((p) => { clearTimeout(frist); r(p); });
  });
}
function stoppe(g) { return new Promise((r) => g.stop(r)); }

function stillerCtx(sammler) {
  return { emit: (f) => sammler.push(f), log: { info() {}, warn() {}, error() {} } };
}
function adapter(cfg, sammler) {
  return new HL7Adapter(Object.assign(
    { id: 'umec12', mode: 'client', host: HOST, model: 'uMEC12 Vet', species: 'hund' }, cfg),
  stillerCtx(sammler));
}

/* Sammelt aus allen empfangenen Frames den zuletzt gesehenen Wert je Kanal. Ein einzelner
 * Frame genuegt nicht: die Patientennachricht und das Echo tragen gar keine Vitalwerte. */
function werteAus(frames) {
  const w = { hr: null, spo2: null, etco2: null, temp: null, sys: null };
  frames.forEach((f) => {
    const v = (f && f.vitals) || {};
    if (v.hr != null) w.hr = v.hr;
    if (v.spo2 != null) w.spo2 = v.spo2;
    if (v.etco2 != null) w.etco2 = v.etco2;
    if (v.temp != null) w.temp = v.temp;
    if (v.nibp && v.nibp.sys != null) w.sys = v.nibp.sys;
  });
  return w;
}

// ---------------------------------------------------------------------------------------
// (d) Sollwert der Vorgabe-Abfrage
// ---------------------------------------------------------------------------------------

/*
 * DER NEUE SOLLWERT (29.08.2026) — die Abfrage, die am echten uMEC12 Vet GELIEFERT HAT.
 *
 * Bis zum 28.08.2026 stand hier der Mitschnitt des Standes VOR dem Umbau, dazu ein zweiter
 * Vergleich gegen dist/VetStation/bridge/src/adapters/hl7.js ("der Stand, der wirklich am
 * Praxis-PC laeuft"). Beide sind ersatzlos entfallen, und zwar aus demselben Grund: dieser
 * Stand ist inzwischen als der STUMME erwiesen. Ein Wachposten, der das Falsche festnagelt,
 * schuetzt nicht, er verhindert die Berichtigung.
 *
 * <NR> ist die laufende Nummer QID.n in QRD-4, <ZEIT> der UTC-Zeitstempel aus ts14() — beide
 * sind von Lauf zu Lauf verschieden und deshalb ausgeklammert. MSH-10 ist AUSDRUECKLICH
 * NICHT ausgeklammert: dass dort woertlich 1203 steht, ist die halbe Aussage dieses Tests.
 *
 * DAS ABSCHLIESSENDE '\r' IST TEIL DES SOLLWERTS, nicht Schreibweise. Es ist die andere
 * Haelfte der Aussage; ohne es schweigt das Geraet (gemessen 29.08.2026).
 *
 * ALLES ANDERE muss Byte fuer Byte stimmen: an diesem Weg haengt am Praxis-PC alles, was der
 * Tierarzt am narkotisierten Patienten ueberhaupt zu sehen bekommt.
 */
const SOLL_VORGABE = [
  'MSH|^~\\&|||||||QRY^R02|1203|P|2.3.1',
  'QRD|<ZEIT>|R|I|Q<NR>|||||RES',
  'QRF|MON||||0&0^1^1^0^101&151&160&161',
  'QRF|MON||||0&0^1^1^0^170&171&172&200',
  'QRF|MON||||0&0^1^1^0^201&202&220&222',
  'QRF|MON||||0&0^1^1^0^250&251&268&269',
  'QRF|MON||||0&0^1^1^0^301&303&305&306',
  'QRF|MON||||0&0^1^1^0^309&310',
].join('\r') + '\r';

/*
 * DIE KENNZIFFERN, DIE AUF DER LEITUNG STEHEN MUESSEN — als Liste und nicht als Suchtext.
 *
 * Warum nicht mit indexOf('302') geprueft wird: '302' ist eine Ziffernfolge, die in einer
 * laufenden Nummer, einem Zeitstempel oder einer anderen Kennziffer zufaellig vorkommen
 * kann. Eine Suche danach waere je nach Uhrzeit gruen oder rot. Geprueft wird deshalb an den
 * ZERLEGTEN Gruppen, und die Gegenprobe unten weist nach, dass die Zerlegung eine 302
 * wirklich fiele.
 */
const SOLL_GRUPPEN = [
  ['101', '151', '160', '161'],
  ['170', '171', '172', '200'],
  ['201', '202', '220', '222'],
  ['250', '251', '268', '269'],
  ['301', '303', '305', '306'],
  ['309', '310'],
];

/*
 * 302 IST DER GRUND, WARUM DIESE PRUEFUNG EXISTIERT (Begruendung steht auch im Adapter):
 * Der Guide fuehrt 302 als PEEP, die CODE_MAP von bridge/src/adapters/hl7.js fuehrt '302'
 * als 'pvcs' (am echten uMEC/LifeVet belegt). Dieselbe Zahl bedeutet in den beiden Dialekten
 * Verschiedenes. Wer sie anfordert, ohne vorher zu klaeren, welcher Dialekt hier gilt, laesst
 * die Station eine BEATMUNGSZAHL als ventrikulaere Extrasystolen verbuchen — eine Zahl mit
 * klinischer Bedeutung, die niemand als falsch erkennt. Sie darf also nicht in der Abfrage
 * stehen, und das ist keine Geschmacksfrage.
 */
const VERBOTENE_ID = '302';

/* Zerlegt den Mitschnitt in die Kennziffern-Gruppen der QRF-Segmente. Gelesen wird, was
 * WIRKLICH rausging — nicht der Quelltext des Adapters. */
function gruppenAus(nutzlast) {
  return String(nutzlast).split('\r')
    .filter((z) => z.slice(0, 4) === 'QRF|')
    .map((z) => {
      const t = (z.split('|')[5] || '').split('^');
      return (t[4] || '').split('&').filter(Boolean);
    });
}

/*
 * maskiereNummern() — nur was sich von Lauf zu Lauf aendert.
 *
 * ACHTUNG, HIER SASS BIS ZUM 29.08.2026 EINE ZEILE, DIE DEN TEST BLIND GEMACHT HAETTE:
 * Solange MSH-10 eine laufende Nummer war, stand hier
 *     .replace(/\|QRY\^R02\|\d+\|/, '|QRY^R02|<NR>|')
 * Diese Regel trifft "|QRY^R02|1203|" genauso — sie haette also ausgerechnet die Zahl
 * ausgeklammert, um deretwillen es diesen Vergleich gibt. Sie ist entfernt, und die
 * Gegenprobe unten haelt fest, dass eine laufende Nummer an dieser Stelle wirklich auffaellt.
 */
function maskiereNummern(text) {
  return String(text)
    .replace(/QRD\|\d{14}\|/, 'QRD|<ZEIT>|')
    .replace(/\|Q\d+\|/, '|Q<NR>|');
}
function utc14() { return new Date().toISOString().replace(/\D/g, '').slice(0, 14); }
/* Dieselbe Rechnung wie ortszeit14() im Adapter, hier absichtlich NOCHMAL geschrieben: ein
 * Test, der seine Erwartung aus dem Pruefling importiert, prueft nur sich selbst. */
function orts14() {
  const t = new Date();
  const p = (n) => (n < 10 ? '0' + n : String(n));
  return String(t.getFullYear()) + p(t.getMonth() + 1) + p(t.getDate()) +
    p(t.getHours()) + p(t.getMinutes()) + p(t.getSeconds());
}

/* Ein roher Mitschreiber ohne jede HL7-Logik: er antwortet NICHT. Nur so ist sichtbar, was
 * der Adapter von sich aus auf die Leitung legt — ein antwortendes Geraet veraendert den
 * Ablauf (Quittungen, Trennungen) und damit den Mitschnitt. */
function mitschreiber() {
  const verbindungen = [];
  const server = net.createServer((sock) => {
    const stuecke = [];
    verbindungen.push(stuecke);
    sock.on('data', (c) => stuecke.push(c));
    sock.on('error', () => {});
  });
  const m = {
    port: 0,
    verbindungen: verbindungen,
    /* Port 0: das Betriebssystem sucht einen freien und sagt hinterher, welchen. Die Nummer
     * steht erst im Rueckruf fest — wer vorher verbindet, laeuft in ein Wettrennen. */
    start: () => new Promise((r) => server.listen(0, HOST, () => {
      m.port = server.address().port; r();
    })),
    stop: () => new Promise((r) => server.close(r)),
  };
  return m;
}

/*
 * einspielen(port, nutzlast) — EINEN fertigen Rahmen an das Testgeraet schicken und wieder
 * gehen. Kein Adapter, keine Quittung, kein Echo: nur die Bytes.
 *
 * Das ist die Messform fuer Abschnitt (e). Wuerde dort der Adapter gefahren, liesse sich das
 * abschliessende <CR> nur durch eine Aenderung an seinem Quelltext wegnehmen — und ein Test,
 * der seinen Pruefling umbaut, misst nicht mehr den Pruefling.
 */
function einspielen(port, nutzlast) {
  return new Promise((r) => {
    const c = net.connect(port, HOST, () => {
      c.write(Buffer.concat([Buffer.from([VT]), Buffer.from(nutzlast, 'latin1'),
        Buffer.from([FS, CR])]));
      /* Kurz warten: das Geraet muss den Rahmen lesen und beurteilen koennen, bevor die
       * Verbindung faellt. Es geht nur um den Eintrag im Bericht, nicht um eine Antwort —
       * eine verworfene Abfrage wird ja gerade KOMMENTARLOS verworfen. */
      setTimeout(() => { try { c.destroy(); } catch (e) {} r(); }, 300);
    });
    c.on('data', () => {});
    c.on('error', () => r());
  });
}

// ---------------------------------------------------------------------------------------

async function lauf() {
  console.log('\n== PDS: strenges Testgeraet gegen den echten Adapter ==\n');

  /* Das Geraetegedaechtnis ist ein Modul-Singleton. Steht dort ein Fund, greift in
   * _zielHost() der Zweig "dem Geraet folgen" und der Adapter verbindet sich woandershin.
   * In einem frischen Testprozess ist es leer — geleert wird es trotzdem, damit der Test
   * nicht von der Ladereihenfolge abhaengt. */
  geraetefund.leeren();

  // ------------------------------------------------------------------ (a)
  console.log('-- (a) OHNE pdsStrict: das strenge Geraet NIMMT die Vorgabe-Abfrage AN --');
  const logA = [];
  const geraetA = starte({
    port: 0, host: HOST, profil: 'streng',
    periodikMs: 300,        // dicht getaktet: in 3 s waeren ~10 Messwertnachrichten moeglich
    aperiodikMs: 700,
    onLog: (z) => logA.push(z),
  });
  const portA = await bereit(geraetA, logA);

  const framesA = [];
  const adapterA = adapter({ port: portA }, framesA);
  adapterA.connect();
  /* Auf das EREIGNIS warten: die angenommene Abfrage ist gezaehlt, sobald sie da ist. Die
   * 10 s sind der Notausgang, nicht das Mass. */
  await warteBis(() => geraetA.bericht().abfragen.length >= 1, 10000);
  await warteBis(() => geraetA.bericht().gesendetNm >= 1, 5000);
  await warte(300);                        // dem Adapter Zeit lassen, den Frame zu deuten
  adapterA.dispose();
  const berichtA = geraetA.bericht();
  const wA = werteAus(framesA);
  const abfrageA = berichtA.abfragen[0];

  ok(berichtA.abfragen.length >= 1, 'die Abfrage der Station kommt am Geraet an',
    berichtA.abfragen.length + ' Abfrage(n)');
  ok(!!abfrageA && abfrageA.gueltig === true,
    'das strenge Geraet NIMMT sie an — genau das war bis zum 29.08.2026 nicht so',
    abfrageA ? abfrageA.text.split('\r')[0] : '-');
  ok(!!abfrageA && abfrageA.gruende.length === 0,
    'und es hat nicht das Geringste daran zu beanstanden',
    abfrageA ? abfrageA.gruende.join(' | ') || '(keine Beanstandung)' : '-');
  /* Am EMPFAENGER gemessen, nicht am Quelltext des Senders: nur so ist belegt, dass die
   * beiden berichtigten Zeichenfolgen wirklich auf der Leitung ankamen. */
  ok(!!abfrageA && abfrageA.text.split('\r')[0].split('|')[9] === '1203',
    'beim Geraet kommt MSH-10 = 1203 an (Guide 6.9.3 NOTE)',
    abfrageA ? 'MSH-10=' + JSON.stringify(abfrageA.text.split('\r')[0].split('|')[9]) : '-');
  ok(!!abfrageA && abfrageA.text.slice(-1) === '\r',
    'und die Nachricht endet mit <CR> hinter dem letzten Segment',
    abfrageA ? 'letzte Zeichen: ' + JSON.stringify(abfrageA.text.slice(-12)) : '-');
  ok(berichtA.gesendetNm >= 1, 'daraufhin geht die Periodik raus',
    'gesendetNm=' + berichtA.gesendetNm);
  ok(wA.hr === 88 && wA.spo2 === 96 && wA.etco2 === 39,
    'HF 88, SpO2 96 und EtCO2 39 kommen in der Station an',
    'hr=' + wA.hr + ' spo2=' + wA.spo2 + ' etco2=' + wA.etco2);
  ok(wA.sys === 110 && berichtA.gesendetAperiodisch >= 2,
    'die aperiodische NIBP laeuft unveraendert daneben weiter',
    'sys=' + wA.sys + ', aperiodisch=' + berichtA.gesendetAperiodisch);
  /*
   * ZWEITER BEFUND — UND EINE WARNUNG AN DEN NAECHSTEN.
   * Das strenge Testgeraet trennt, sobald die Station quittiert (Guide 6.3.3 Punkt 9: "If
   * other message is sent, the device will disconnect the connection"). DAS ECHTE uMEC12 TUT
   * DAS NICHT — dort laeuft der Vorgabe-Weg MIT Quittung und mit Wiederholung alle 5 s seit
   * dem 29.08.2026 und liefert HF, SpO2, Puls, Temperatur, Atemfrequenz und Blutdruck.
   * Die Trennung ist also eine Lesart des Guides, kein Befund am Geraet. Sie wird hier
   * gemessen, damit sie sichtbar bleibt — und NICHT, damit jemand daraus schliesst, die
   * Quittung gehoere aus dem Adapter entfernt. Wie viel Periodik trotz dieser Trennung
   * fliesst, sagt Abschnitt (b) am passenderen Profil.
   */
  ok(berichtA.trennungen >= 1 && /fremde Nachricht/.test(logA.join(' ')),
    'zweiter Befund: DIESES Testgeraet trennt wegen unserer Quittung — das echte tut es nicht',
    berichtA.trennungen + ' Trennung(en)');

  await stoppe(geraetA);

  // ------------------------------------------------------------------ (b)
  /*
   * (b) DASSELBE AM PROFIL, DAS SICH AM ECHTEN GERAET BESTAETIGT HAT.
   *
   * 'ohne-echopflicht' verlangt Form und Kennung (also alles, woran die Abfrage frueher
   * scheiterte), aber es besteht weder auf dem 1-Sekunden-Echo noch trennt es wegen unserer
   * Quittung. Genau so verhaelt sich der uMEC12 in der Praxis. Erst hier ist "die Periodik
   * laeuft" ein STROM und nicht eine einzelne Nachricht — und das ist die Aussage, auf die
   * es am Praxis-PC ankommt.
   */
  console.log('\n-- (b) derselbe Zweig gegen die Lesart, die das echte Geraet bestaetigt --');
  const logB = [];
  const geraetB = starte({
    port: 0, host: HOST, profil: 'ohne-echopflicht',
    periodikMs: 300, aperiodikMs: 900,
    onLog: (z) => logB.push(z),
  });
  const portB = await bereit(geraetB, logB);

  const framesB = [];
  const adapterB = adapter({ port: portB }, framesB);
  adapterB.connect();
  const stromDa = await warteBis(() => geraetB.bericht().gesendetNm >= 5, 15000);
  await warte(300);
  adapterB.dispose();
  const berichtB = geraetB.bericht();
  const wB = werteAus(framesB);

  ok(stromDa && berichtB.gesendetNm >= 5,
    'die Periodik laeuft im STROM, nicht eine Nachricht lang',
    berichtB.gesendetNm + ' Messwertnachrichten');
  ok(berichtB.trennungen === 0 && berichtB.verbindungen === 1,
    'ohne die Trennregel bleibt EINE Verbindung stehen — kein Wiederverbinden',
    berichtB.verbindungen + ' Verbindung(en), ' + berichtB.trennungen + ' Trennung(en)');
  ok(wB.hr === 88 && wB.spo2 === 96 && wB.etco2 === 39 && wB.temp === 38.2,
    'HF 88, SpO2 96, EtCO2 39 und Temperatur 38,2 kommen in der Station an',
    'hr=' + wB.hr + ' spo2=' + wB.spo2 + ' etco2=' + wB.etco2 + ' temp=' + wB.temp);
  ok(wB.sys === 110, 'die NIBP laeuft unveraendert weiter', 'sys=' + wB.sys);

  await stoppe(geraetB);

  // ------------------------------------------------------------------ (c)
  /*
   * (c) "pdsStrict" FUNKTIONIERT WEITERHIN — ALS BAUTEIL, NICHT ALS DER BESSERE WEG.
   *
   * WICHTIG UND LEICHT ZU VERGESSEN: am ECHTEN uMEC12 Vet hat dieser Weg NICHTS geliefert.
   * Gemessen in der Nacht auf den 29.08.2026 als Varianten 3 bis 8 der Feldsonde (eine
   * Abfrage je Verbindung, 1-Sekunden-Echo, keine Quittung) — null Messwerte, in jeder der
   * sechs Varianten. Der Weg, der liefert, ist der Vorgabe-Zweig aus (a)/(b).
   * Dass er hier gruen ist, heisst also nur: er ist mechanisch heil und laesst sich messen.
   * Es heisst NICHT, dass er die Vorgabe werden sollte.
   */
  console.log('\n-- (c) MIT pdsStrict: mechanisch heil (am echten Geraet lieferte er NICHTS) --');
  const logC = [];
  const geraetC = starte({
    port: 0, host: HOST, profil: 'streng',
    periodikMs: 300, aperiodikMs: 900,
    onLog: (z) => logC.push(z),
  });
  const portC = await bereit(geraetC, logC);

  const framesC = [];
  const adapterC = adapter({ port: portC, pdsStrict: true }, framesC);
  adapterC.connect();
  const stromC = await warteBis(() => geraetC.bericht().gesendetNm >= 3, 15000);
  await warte(300);
  adapterC.dispose();
  const berichtC = geraetC.bericht();
  const wC = werteAus(framesC);
  const abfrageC = berichtC.abfragen[berichtC.abfragen.length - 1];

  ok(!!abfrageC && abfrageC.gueltig === true,
    'das strenge Geraet nimmt auch die strikte Abfrage an',
    abfrageC ? abfrageC.text.split('\r')[0] : '-');
  ok(stromC && berichtC.gesendetNm >= 3, 'die Periodik laeuft',
    berichtC.gesendetNm + ' Messwertnachrichten');
  ok(wC.hr === 88 && wC.spo2 === 96 && wC.etco2 === 39,
    'HF 88, SpO2 96 und EtCO2 39 kommen in der Station an',
    'hr=' + wC.hr + ' spo2=' + wC.spo2 + ' etco2=' + wC.etco2);
  ok(wC.sys === 110, 'die NIBP laeuft unveraendert weiter', 'sys=' + wC.sys);

  await stoppe(geraetC);

  // ------------------------------------------------------------------ (d)
  console.log('\n-- (d) die Vorgabe-Abfrage ist auf der Leitung byteweise der neue Sollwert --');
  const mit = mitschreiber();
  await mit.start();

  const utcVor = utc14();
  const adapterD1 = adapter({ port: mit.port }, []);
  adapterD1.connect();
  await warte(500);
  adapterD1.dispose();
  const utcNach = utc14();

  const ortsVor = orts14();
  const adapterD2 = adapter({ port: mit.port, pdsStrict: true }, []);
  adapterD2.connect();
  await warte(500);
  adapterD2.dispose();
  const ortsNach = orts14();
  await warte(50);
  await mit.stop();

  const rohVorgabe = Buffer.concat(mit.verbindungen[0] || []);
  const rohStrikt = Buffer.concat(mit.verbindungen[1] || []);
  const nutzVorgabe = rohVorgabe.length > 3
    ? rohVorgabe.slice(1, rohVorgabe.length - 2).toString('latin1') : '';
  const nutzStrikt = rohStrikt.length > 3
    ? rohStrikt.slice(1, rohStrikt.length - 2).toString('latin1') : '';
  const qrd1 = (nutzVorgabe.match(/QRD\|(\d{14})\|/) || [])[1] || '';

  ok(rohVorgabe.length > 3 && rohVorgabe[0] === VT &&
     rohVorgabe[rohVorgabe.length - 2] === FS && rohVorgabe[rohVorgabe.length - 1] === CR,
    'MLLP-Rahmen unveraendert: <VT> Nutzlast <FS><CR>',
    rohVorgabe.length + ' Byte Rahmen, ' + nutzVorgabe.length + ' Byte Nutzlast');
  /* Eigene Zusicherung, obwohl der Bytevergleich unten sie mitprueft: faellt der Sollwert
   * einmal ganz auseinander, soll im Bericht STEHEN, dass es das <CR> war — und nicht nur
   * "die Abfrage ist nicht mehr die alte". Das eine Zeichen ist die halbe Messung vom
   * 29.08.2026. */
  ok(nutzVorgabe.slice(-1) === '\r',
    'hinter dem letzten Segment steht ein <CR> (auf der Leitung: ...<CR><FS><CR>)',
    'letzte drei Bytes: ' + Array.prototype.slice.call(rohVorgabe.slice(-3))
      .map((b) => '0x' + b.toString(16)).join(' '));
  ok(maskiereNummern(nutzVorgabe) === SOLL_VORGABE,
    'die Abfrage ist Zeichen fuer Zeichen der neue Sollwert (Nummer und Zeit ausgeklammert)',
    maskiereNummern(nutzVorgabe) === SOLL_VORGABE ? '' : JSON.stringify(maskiereNummern(nutzVorgabe)));

  const gruppen = gruppenAus(nutzVorgabe);
  ok(JSON.stringify(gruppen) === JSON.stringify(SOLL_GRUPPEN),
    'sechs QRF-Segmente: die drei Vitalwert-Gruppen und die drei fuer Beatmung und Kapnografie',
    JSON.stringify(gruppen));
  const alleIds = gruppen.reduce((a, g) => a.concat(g), []);
  ok(alleIds.indexOf(VERBOTENE_ID) < 0,
    'die Kennziffer 302 wird NICHT angefordert (Guide: PEEP, CODE_MAP: PVC-Rate — dieselbe ' +
    'Zahl, zwei Bedeutungen; angefordert wuerde eine Beatmungszahl als Extrasystolen gebucht)',
    alleIds.length + ' Kennziffern insgesamt');
  /* ANLASS fuer die Zeile darueber: ohne diese Gegenprobe hiesse "302 ist nicht dabei" nur,
   * dass die Zerlegung nichts findet — auch dann, wenn sie gar nichts findet. */
  ok(gruppenAus(nutzVorgabe.replace('301&303', '302&303'))
       .reduce((a, g) => a.concat(g), []).indexOf(VERBOTENE_ID) >= 0,
    'Gegenprobe: die Zerlegung wuerde eine 302 wirklich sehen');

  ok(qrd1 !== '' && qrd1 >= utcVor && qrd1 <= utcNach,
    'QRD-1 steht im Vorgabe-Zweig weiterhin in UTC',
    'QRD-1=' + qrd1 + ', UTC-Fenster ' + utcVor + '..' + utcNach);
  /*
   * DER LEITUNGSMITSCHNITT DES STRIKTEN ZWEIGS (28.08.2026).
   * Das MSH-Segment muss Zeichen fuer Zeichen das Beispiel aus Guide 6.9.3 sein — sieben
   * leere Felder, dann QRY^R02, dann 1203. Geprueft wird an dem, was WIRKLICH rausging.
   */
  const mshStrikt = nutzStrikt.split('\r')[0];
  ok(mshStrikt === 'MSH|^~\\&|||||||QRY^R02|1203|P|2.3.1',
    'strikt: MSH-Segment ist woertlich das Beispiel aus Guide 6.9.3 (MSH-7 leer, MSH-10=1203)',
    mshStrikt);
  /* Nachgezaehlt statt angesehen: bei sieben Trennstrichen hintereinander verzaehlt man sich
   * beim Hinsehen. MSH-7 liegt in split('|') auf Index 6 (Index 0 ist "MSH"). */
  ok(mshStrikt.split('|')[6] === '',
    'strikt: Feld 7 des MSH-Segments ist nachgezaehlt leer',
    'MSH-7=' + JSON.stringify(mshStrikt.split('|')[6]));
  /*
   * Die Ortszeit steht weiterhin in QRD-1 — dort verlangt §6.9.4 ausdruecklich ein gueltiges
   * Zeitformat ("The 1st field must be in valid time format"). WELCHE Zeitzone gemeint ist,
   * sagt der Guide an keiner Stelle (die Woerter "local time", "UTC", "GMT", "time zone"
   * kommen im ganzen Dokument nicht vor); gemessen wird deshalb gegen die Uhr DIESES Rechners.
   * Steht der Rechner auf UTC, faellt die Aussage mit der des Vorgabe-Zweigs zusammen — dann
   * prueft diese Zeile nur noch das Format, und das ist ehrlicher als eine erfundene Differenz.
   */
  const qrd1Strikt = (nutzStrikt.match(/QRD\|(\d{14})\|/) || [])[1] || '';
  ok(qrd1Strikt !== '' && qrd1Strikt >= ortsVor && qrd1Strikt <= ortsNach,
    'strikt: QRD-1 traegt die Ortszeit dieses Rechners',
    'QRD-1=' + qrd1Strikt + ', Ortszeit-Fenster ' + ortsVor + '..' + ortsNach);
  /*
   * ZWEI GEGENPROBEN FUER DIE MASKE. Sie klammert Zeitstempel und laufende Nummer aus; wenn
   * sie zu viel ausklammert, ist der Bytevergleich darueber wertlos, ohne rot zu werden.
   * Die zweite ist die wichtigere: bis zum 29.08.2026 hat die Maske MSH-10 mit ausgeklammert
   * (siehe den Block bei maskiereNummern) — mit dieser Zeile faellt so etwas sofort auf.
   */
  ok(maskiereNummern(nutzVorgabe.replace('160&161', '160&999')) !== SOLL_VORGABE,
    'Gegenprobe: die Maske ist nicht blind — eine geaenderte Kennziffer faellt auf');
  ok(maskiereNummern(nutzVorgabe.replace('|QRY^R02|1203|', '|QRY^R02|42|')) !== SOLL_VORGABE,
    'Gegenprobe: eine laufende Nummer in MSH-10 faellt auf — genau das war der Fehler');

  // ------------------------------------------------------------------ (e)
  /*
   * (e) DAS <CR>-TOR DES TESTGERAETS (29.08.2026).
   *
   * WARUM ES DIESEN ABSCHNITT GIBT: das fehlende <CR> hat tools/pds-testgeraet.js WOCHENLANG
   * KLAGLOS ANGENOMMEN. Es ist aus derselben Lesart desselben Kapitels gebaut wie die Sonde
   * und der Adapter — "gruen" hiess dort "mit sich selbst einig", nicht "richtig". Deshalb
   * ist der Mangel niemandem aufgefallen, bis das echte Geraet ihn zeigte.
   * Seit heute verwirft das Profil 'streng' eine Abfrage ohne abschliessendes <CR>. Diese
   * Zusicherung belegt das an DENSELBEN Bytes: einmal so, wie der Adapter sie eben wirklich
   * gesendet hat, und einmal dieselben Bytes minus EIN Zeichen.
   * Gefahren wird der Mitschnitt aus (d) und nicht ein hier getippter Text: eine getippte
   * Abfrage waere nur die Erinnerung dessen, der sie getippt hat.
   */
  console.log('\n-- (e) das Testgeraet verwirft eine Abfrage OHNE abschliessendes <CR> --');
  const logE = [];
  const geraetE = starte({
    port: 0, host: HOST, profil: 'streng',
    periodikMs: 400, aperiodikMs: 5000,
    onLog: (z) => logE.push(z),
  });
  const portE = await bereit(geraetE, logE);

  const mitCR = nutzVorgabe;
  const ohneCR = nutzVorgabe.slice(0, -1);
  ok(mitCR.length - ohneCR.length === 1 && mitCR.slice(0, -1) === ohneCR && mitCR.slice(-1) === '\r',
    'die beiden Nachrichten unterscheiden sich in GENAU EINEM Zeichen — dem <CR>',
    mitCR.length + ' gegen ' + ohneCR.length + ' Byte');

  await einspielen(portE, mitCR);
  await einspielen(portE, ohneCR);
  const berichtE = geraetE.bericht();
  const eMit = berichtE.abfragen[0];
  const eOhne = berichtE.abfragen[1];

  ok(berichtE.abfragen.length === 2, 'beide Abfragen sind am Geraet angekommen',
    berichtE.abfragen.length + ' Abfrage(n)');
  ok(!!eMit && eMit.gueltig === true, 'MIT <CR>: angenommen',
    eMit ? eMit.gruende.join(' | ') || '(keine Beanstandung)' : '-');
  ok(!!eOhne && eOhne.gueltig === false, 'OHNE <CR>: verworfen');
  /* Der Grund muss der EINZIGE sein. Waere er bloss einer von mehreren, hiesse "das <CR> ist
   * die Ursache" eine Behauptung ueber etwas, das gar nicht allein gemessen wurde — genau
   * die Schaerfe, die dieser Datei am 28.08.2026 schon einmal gefehlt hat. */
  ok(!!eOhne && eOhne.gruende.length === 1 && /<CR>/.test(eOhne.gruende[0]),
    'und das fehlende <CR> ist der EINZIGE genannte Grund, im Klartext im Bericht',
    eOhne ? eOhne.gruende.length + ' Grund/Gruende: ' + eOhne.gruende[0].slice(0, 60) : '-');
  ok(/ABGELEHNT/.test(logE.join(' ')) && /Wagenruecklauf/.test(logE.join(' ')),
    'das Geraet sagt es auch in seinem Protokoll',
    (logE.filter((z) => /ABGELEHNT/.test(z))[0] || '-').slice(0, 90));

  await stoppe(geraetE);

  // ------------------------------------------------------------------ (f)
  console.log('\n-- (f) mit pdsStrict trennt das Geraet nicht (das Echo laeuft) --');
  const logF = [];
  const geraetF = starte({
    port: 0, host: HOST, profil: 'streng',
    echoFristMs: ECHO_FRIST_MS,   // gestauchte Frist, Begruendung im Dateikopf
    periodikMs: 500, aperiodikMs: 1000,
    onLog: (z) => logF.push(z),
  });
  const portF = await bereit(geraetF, logF);

  const framesF = [];
  const adapterF = adapter({ port: portF, pdsStrict: true }, framesF);
  const beginnF = Date.now();
  adapterF.connect();

  /* Auf das EREIGNIS warten, nicht auf die Uhr: der Adapter echot im Sekundentakt, drei
   * gezaehlte Echos sind also nach ~2 s da. Vorher stand hier eine feste Frist von 5000 ms
   * gegen eine Erwartung von drei bei gemessenen vier Echos — EIN Takt Reserve. */
  const echosDa = await warteBis(() => geraetF.bericht().echosEmpfangen >= 3, 15000);
  ok(echosDa, 'das Geraet hat die Echos der Station wirklich gezaehlt',
    geraetF.bericht().echosEmpfangen + ' Echos nach ' + (Date.now() - beginnF) + ' ms');

  /* "Es wurde NICHT getrennt" ist eine Aussage, auf die man nur warten kann. Also die
   * DOPPELTE Frist abwarten (100 % Luft) und erst dann nachsehen. */
  await warte(OHNE_TRENNUNG_MS - (Date.now() - beginnF));
  const berichtF = geraetF.bericht();
  adapterF.dispose();

  ok(berichtF.verbindungen === 1, 'genau eine Verbindung, kein Wiederverbinden',
    berichtF.verbindungen + ' Verbindung(en)');
  ok(berichtF.trennungen === 0,
    'nach ' + OHNE_TRENNUNG_MS + ' ms (mehr als der DOPPELTEN Echo-Frist von ' +
    ECHO_FRIST_MS + ' ms) hat das Geraet NICHT getrennt',
    'trennungen=' + berichtF.trennungen);

  /* ANLASS fuer die Aussage darueber: dieselbe Frist am selben Geraet, aber ohne Echo.
   * Ohne diese Gegenprobe hiesse "trennungen === 0" nur, dass die Uhr nicht laeuft.
   * Auch hier wird auf das Ereignis gewartet — die Trennung ist zaehlbar. */
  const still = net.connect(portF, HOST);
  still.on('data', () => {});
  still.on('error', () => {});
  const getrennt = await warteBis(() => geraetF.bericht().trennungen >= 1, ECHO_FRIST_MS * 4);
  const berichtF2 = geraetF.bericht();
  try { still.destroy(); } catch (e) {}

  ok(getrennt && berichtF2.trennungen === 1 && /kein Echo/.test(logF.join(' ')),
    'Gegenprobe: eine Verbindung OHNE Echo wird nach der Frist getrennt — und zwar genau die',
    'trennungen=' + berichtF2.trennungen);

  await stoppe(geraetF);

  // ------------------------------------------------------------------ (g)
  /*
   * (g) DER SCHALTER DARF NICHTS TUN, WAS SEIN NAME NICHT ANKUENDIGT (Folgebefund 28.08.2026).
   *
   * pdsStrict steht seit dem 28.08.2026 in ERLAUBTE_FELDER (geraeteeinrichtung.js) und ist damit
   * ueber die Oberflaeche auf JEDEM HL7-Adapter setzbar — auch auf einem Listener. Dort galt er
   * bis dahin mit: _handleMessage fragte nur `!this.pdsStrict`, ohne den Modus. Ein Listener ist
   * aber der ANDERE Weg (Guide Kapitel 2, "unsolicited results"): das Geraet verbindet sich zum
   * PC und pusht, es gibt keine QRY, kein Echo und keinen Punkt 9 aus 6.3.3. Der Schalter hat
   * dort still die Quittung abgeschaltet, obwohl der Kommentar bei "ack" in derselben Liste
   * ausdruecklich sagt, im Listener-Weg wirke ack weiter.
   *
   * Gemessen wird auf der Leitung: kommt die Quittung beim pushenden Geraet an?
   */
  console.log('\n-- (g) pdsStrict wirkt NICHT auf dem Listener-Weg --');
  const ORU_PUSH = 'MSH|^~\\&|Mindray|uMEC12 Vet|||20260828120000||ORU^R01|4711|P|2.3.1\r' +
    'PID|||T-1||Test^Tier\rOBX|1|NM|101^HR||88|bpm\r';

  /*
   * Ein pushendes Geraet nachstellen: verbinden, EINE ORU schicken, auf die Quittung horchen.
   *
   * HIER GEHT listen(0) NICHT, anders als beim Testgeraet oben: der Konstruktor rechnet
   * `cfg.port || cfg.listenPort || 5000`, und die 0 ist falsy — ein Adapter mit "port": 0
   * lauscht also auf 5000. Deshalb feste Nummern aus dem Hausbereich 45600-45699.
   */
  async function pushLauf(cfg, port) {
    const zeilen = [];
    const a = new HL7Adapter(Object.assign({ id: 'push', mode: 'listener', port: port }, cfg), {
      emit: () => {},
      log: { info: (s, m) => zeilen.push('info|' + m), warn: (s, m) => zeilen.push('warn|' + m), error: (s, m) => zeilen.push('err|' + m) },
    });
    await a.connect();
    /* Mit eigener Frist und eigener Fehlermeldung: laesst sich der Port nicht binden, meldet
     * der Adapter das nur ueber log.error, und der Test liefe sonst stumm ins Zeitlimit. */
    const lauscht = await warteBis(() => !!(a.server && a.server.address()), 5000);
    if (!lauscht) { a.dispose(); throw new Error('Listener auf Port ' + port + ' kam nicht hoch: ' + zeilen.join(' | ')); }
    const c = net.connect(a.server.address().port, HOST);
    let antwort = '';
    c.on('data', (d) => { antwort += d.toString('latin1'); });
    c.on('error', () => {});
    await new Promise((r) => c.on('connect', r));
    c.write(Buffer.concat([Buffer.from([VT]), Buffer.from(ORU_PUSH, 'latin1'), Buffer.from([FS, CR])]));
    /* Auf die Quittung warten, aber nicht ewig: im Gegenprobefall kommt absichtlich keine.
     * Dann laeuft die Frist ab — deshalb ist sie kurz und die Aussage haengt am Inhalt. */
    await warteBis(() => /MSA/.test(antwort), 1500);
    try { c.destroy(); } catch (e) {}
    a.dispose();
    return { antwort: antwort.replace(/[\x0b\x1c\r]/g, ' ').trim(), zeilen: zeilen, strikt: a.pdsStrict };
  }

  const gStrikt = await pushLauf({ ack: true, pdsStrict: true }, 45621);
  ok(gStrikt.strikt === false, '"pdsStrict": true ist auf einem Listener wirkungslos',
    'adapter.pdsStrict=' + gStrikt.strikt);
  ok(/ACK\^R01/.test(gStrikt.antwort),
    'die Quittung geht trotzdem raus — "ack": true wirkt auf diesem Weg unveraendert weiter',
    JSON.stringify(gStrikt.antwort));
  ok(gStrikt.zeilen.filter((z) => /pdsStrict/.test(z)).length === 1,
    'und die Station sagt GENAU EINMAL beim Start, dass der Schalter hier nichts tut',
    gStrikt.zeilen.filter((z) => /pdsStrict/.test(z)).length + ' Zeile(n)');
  ok(gStrikt.zeilen.some((z) => /^warn\|/.test(z) && /wirkt.*NICHT/.test(z) && /Listener/.test(z)),
    'die Zeile benennt den Weg im Klartext (Listener), nicht nur den Schalter',
    gStrikt.zeilen.join(' // ').slice(0, 200));

  /* ANLASS fuer die Aussage darueber: ohne diese Gegenprobe hiesse "die Quittung kam an" nur,
   * dass irgendetwas quittiert — nicht, dass "ack" sie weiterhin steuert. */
  const gOhneAck = await pushLauf({ ack: false, pdsStrict: true }, 45622);
  ok(!/ACK/.test(gOhneAck.antwort),
    'Gegenprobe: mit "ack": false schweigt derselbe Listener — die Quittung haengt wirklich an ack',
    JSON.stringify(gOhneAck.antwort) || '(nichts)');
}

const NOTAUS = setTimeout(() => {
  console.log('\nZEITLIMIT: der Test bricht nach 90 s ab (haengende node.exe blockiert den Bau).');
  process.exit(1);
}, 90000);
NOTAUS.unref();

lauf().then(() => {
  clearTimeout(NOTAUS);
  console.log('\n== Ergebnis: ' + bestanden + ' OK, ' + fehlgeschlagen + ' FAIL ==');
  // Hart beenden: ein vergessener Timer oder Socket haelt den Prozess sonst am Leben.
  process.exit(fehlgeschlagen ? 1 : 0);
}).catch((e) => {
  console.log('\nTestfehler: ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
