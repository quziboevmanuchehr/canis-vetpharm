'use strict';
/*
 * pds-feldsonde.js — der Tierarzt befragt das Geraet an meiner Stelle (28.08.2026).
 *
 * WARUM ES DIESE DATEI GIBT:
 * Am Praxis-PC haengt ein Mindray uMEC12 Vet (dazu ein Kapnograph). Ueber HL7 kommen dort
 * heute Patientendaten, NIBP und Alarme an — die laufenden Messwerte (HF 101, SpO2 160,
 * Temp 200, EtCO2 220 ...) fehlen vollstaendig. Woran es liegt, laesst sich vom
 * Entwicklungsrechner aus NICHT feststellen: das Geraet steht in der Praxis, nicht hier.
 * Jede Vermutung dazu — falscher Zeitstempel, fehlendes Echo, falsche Kennung — ist bis
 * heute unbelegt. Diese Sonde fragt das Geraet SELBST und schreibt einen Befund, den der
 * Entwickler danach liest. Sie ersetzt das Raten durch eine Messung.
 *
 * WIE SIE MISST:
 * Acht Varianten der Abfrage, NACHEINANDER, jede mit frischer TCP-Verbindung und eigenem
 * Zeitfenster. Variante 1 ist genau das, was die Station heute sendet; jede weitere aendert
 * GENAU EIN Stueck. Liefert eine Variante laufende Messwerte und die davor nicht, dann war
 * das dazwischen geaenderte Stueck die Ursache. Mehr sagt diese Sonde nicht — und weniger
 * auch nicht.
 *
 * =======================================================================================
 * DIE REGEL FUER DEN BEFUND (28.08.2026, dritter Anlauf — und der letzte, weil er ohne
 * Feldlisten auskommt):
 *
 *   ALLES, was in die .txt oder die .json geschrieben wird, stammt aus GENAU DREI QUELLEN:
 *     1. ZAHLEN, die die Sonde selbst gezaehlt, gemessen oder als Zahl eingelesen hat
 *        (Rahmen, Millisekunden, Trennungen, Anzahlen, Port, Zeitfenster).  -> zahl()
 *     2. KENNZIFFERN, die gegen ein festes Muster geprueft wurden, und zwar ausschliesslich
 *        /^[0-9]{1,6}$/ — keine Buchstaben, keine Unterstriche, keine Bindestriche.
 *                                                                  -> ziffernkennung()
 *     3. FESTE ZEICHENKETTEN aus dem Quelltext DIESER Datei.        -> festerText()
 *
 *   EIN BYTE, DAS DAS GERAET GESCHICKT HAT, GEHT NICHT AUF DIE PLATTE. Nicht gekuerzt,
 *   nicht gefiltert, nicht maskiert — gar nicht.
 *
 * WARUM DIE DRITTE FASSUNG SO AUSSIEHT UND NICHT WIEDER WIE DIE ZWEITE:
 * Zweimal wurde versucht, die Zusage mit einer MASKIERUNG einzuhalten, zuletzt mit einer
 * Positivliste der erlaubten FELDER je Segment. Zweimal fand eine unabhaengige Messung
 * Lecks — beim zweiten Mal fuenf: OBX-3 (beide Haelften), QAK-3, OBX-4, OBX-6, und
 * CE-Kennungen der Form GROSS_MIT_UNTERSTRICH kamen durch die ID-Pruefung. Der bewachende
 * Test war dabei gruen, weil er gegen sieben BEKANNTE Zeichenketten prueft.
 * Die Lehre daraus ist nicht "die Feldliste war unvollstaendig", sondern: EINE FELDLISTE IST
 * DER FALSCHE ANSATZ. Jedes neue Geraet und jede neue Firmware bringt ein Feld, an das
 * niemand gedacht hat. Solange irgendein Stueck GERAETETEXT in den Bericht gelangt, ist die
 * Zusage nicht haltbar — egal wie sorgfaeltig die Liste gepflegt wird.
 * Deshalb wird jetzt nicht mehr gefiltert, sondern BESCHRIEBEN: der Bericht enthaelt einen
 * BAUPLAN der Nachricht (welches Segment, wie viele Felder, welche davon gefuellt) statt
 * ihres Inhalts. Ein Bauplan besteht nur aus Zahlen und aus Namen, die die Sonde gegen ihre
 * EIGENEN Listen abgleicht.
 *
 * WO DER RIEGEL SITZT:
 * Es gibt genau drei Tore — zahl(), ziffernkennung(), festerText() — und jeder Wert geht
 * durch eines davon, BEVOR er in die Befundstruktur kommt. ausListe(), messzahl(), satz()
 * und fuege() sind KEIN vierter Weg: sie enden selbst wieder in einem der drei Tore.
 * Zusaetzlich laeuft pruefeBefund() vor dem Schreiben ueber die FERTIGE Struktur und weist
 * jede Zeichenkette zurueck, die weder aus unserem Quelltext stammt noch reine Ziffern ist.
 * Wer spaeter ein Feld ergaenzt, muss sich fuer eines der drei Tore entscheiden; nimmt er
 * keines, faellt der Wert beim Schreiben heraus und die Zahl der abgewiesenen Werte steht
 * im Bericht.
 * Es gibt nur EINE Struktur: die .txt wird aus ihr erzeugt, die .json IST sie. Damit kann es
 * keine zweite, laxere Ausgabe mehr geben — beim letzten Mal war genau die .json schlimmer
 * als die .txt.
 * =======================================================================================
 *
 * WARUM SIE IHRE TELEGRAMME SELBST BAUT (und nichts aus bridge/ einbindet):
 * Wuerde sie den Adapter aufrufen, pruefte sie den Code gegen sein eigenes Kriterium — genau
 * das ist diesem Projekt schon passiert (tools/hl7-client-test.js war jahrelang gruen,
 * waehrend das echte Geraet schwieg). Die Zeichenketten unten stehen deshalb doppelt: hier
 * und in bridge/src/adapters/hl7.js. Das ist Absicht.
 * EINZIGE Ausnahme: bei "--host auto" wird bridge/src/geraetefund.js gelesen. Das Modul ist
 * kein Adapter, es liest ausschliesslich die ARP-Tabelle des PCs (arp -a) und sendet nichts.
 *
 * SICHERHEIT — DIESE SONDE LIEST NUR:
 * Sie sendet ausschliesslich QRY^R02 (Abfrage), das TCP-Echo aus Guide 6.7 und in den beiden
 * "heute"-Varianten das HL7-ACK, das die Station heute ohnehin schickt. Keine
 * Steuernachricht, keine Einstellung am Geraet, kein Schreibzugriff. Sie ruehrt devices.json
 * nicht an und veraendert an der Station nichts. Der Bericht sagt das noch einmal, weil ihn
 * jemand liest, der diese Datei nicht aufmacht.
 *
 * WAS AUSSER GERAETETEXT NOCH NICHT IN DEN BERICHT GEHT:
 * die abgefragte IP-Adresse und die Pfade der Berichtsdateien. Beides ist kein Geraetetext,
 * faellt aber auch unter keine der drei Quellen — und beides steht beim Start ohnehin auf
 * dem Bildschirm des Tierarztes. Der PORT dagegen steht drin: er ist reine Ziffernfolge
 * (Quelle 2), und ohne ihn liesse sich "falscher Port" nicht beurteilen.
 *
 * Aufruf:
 *   node tools/pds-feldsonde.js --host 192.168.0.50 --port 4601
 *   node tools/pds-feldsonde.js --host auto --sekunden 25
 *   node tools/pds-feldsonde.js --host 192.168.0.50 --nur 4 --ordner data
 *   node tools/pds-feldsonde.js --host 192.168.0.50 --trotzdem   (nur ohne Patient!)
 */

const net = require('net');
const fs = require('fs');
const path = require('path');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;     // MLLP-Rahmen: <VT> Nutzlast <FS><CR>

function mllp(text) {
  return Buffer.concat([Buffer.from([VT]), Buffer.from(text, 'latin1'), Buffer.from([FS, CR])]);
}

function zwei(n) { return (n < 10 ? '0' : '') + n; }

/* Ortszeit, 14-stellig — die Uhr, die auch am Geraet steht. */
function ortszeit14(d) {
  const t = d || new Date();
  return String(t.getFullYear()) + zwei(t.getMonth() + 1) + zwei(t.getDate()) +
    zwei(t.getHours()) + zwei(t.getMinutes()) + zwei(t.getSeconds());
}

/* UTC, 14-stellig — Zeichen fuer Zeichen wie ts14() in hl7.js, damit Variante 1 wirklich
 * das auf die Leitung legt, was die Station heute sendet, und nicht etwas Aehnliches. */
function utc14(d) {
  return (d || new Date()).toISOString().replace(/\D/g, '').slice(0, 14);
}

/* Die Bestandteile der Uhrzeit EINZELN — jeder fuer sich eine kurze Ziffernfolge, die durch
 * ziffernkennung() passt. Nur so kommen Datum und Uhrzeit in den Bericht, ohne dass dafuer
 * ein viertes Tor aufgemacht werden muesste. */
function zeitTeile(d) {
  const t = d || new Date();
  return {
    jahr: String(t.getFullYear()), monat: zwei(t.getMonth() + 1), tag: zwei(t.getDate()),
    stunde: zwei(t.getHours()), minute: zwei(t.getMinutes()), sekunde: zwei(t.getSeconds()),
  };
}

// ---------------------------------------------------------------------------------------
// DIE DREI TORE — hier kommt JEDER Wert durch, bevor er in die Befundstruktur geht.
// ---------------------------------------------------------------------------------------

/*
 * Das Muster fuer Kennziffern. ES IST ABSICHTLICH SO ENG.
 * Die zweite Fassung liess zusaetzlich Grossbuchstaben-Marken mit Unterstrich zu
 * ("MDC_EVT_INOP", "PHY_ALM"), weil die im Alarmkatalog so vorkommen. Genau daran ist die
 * Gegenmessung vorbeigekommen: eine Marke der Form GROSS_MIT_UNTERSTRICH ist von einem
 * grossgeschriebenen Namen mit Unterstrich nicht zu unterscheiden. Reine Ziffern sind es.
 */
const ZIFFERN = /^[0-9]{1,6}$/;

/*
 * Das Register unserer eigenen Zeichenketten.
 *
 * Gefuellt wird es NUR beim Laden des Moduls, aus den Tabellen dieser Datei; danach schliesst
 * siegle() es zu. Eine Zeichenkette, die spaeter irgendwoher kommt — von der Leitung, aus
 * einer Datei, aus einer Fehlermeldung — kann sich also nicht nachtraeglich als "unsere"
 * anmelden. Das ist der Unterschied zu einer Positivliste von Feldern: hier steht nicht,
 * WELCHE FREMDEN Werte durchduerfen, sondern WELCHE EIGENEN es ueberhaupt gibt.
 *
 * ABGELEITET nimmt auf, was satz()/fuege() aus bereits geprueften Stuecken zusammensetzen.
 * Das ist keine zweite Tuer: hineinkommt dort nur, was Stueck fuer Stueck schon durch eines
 * der drei Tore gegangen ist.
 */
const EIGEN = Object.create(null);
const ABGELEITET = Object.create(null);
let registerOffen = true;

function melde(x) {
  if (!registerOffen) {
    /* Absichtlich ein Fehler und keine stille Rueckgabe: eine Anmeldung nach dem Siegeln
     * waere der Versuch, fremden Text zu unserem zu erklaeren. */
    throw new Error('Das Textregister ist geschlossen — nachtraegliche Anmeldung abgelehnt.');
  }
  if (typeof x === 'string') { EIGEN[x] = true; return x; }
  if (x && typeof x === 'object') {
    Object.keys(x).forEach(function (k) { melde(x[k]); });
  }
  return x;
}
function siegle() { registerOffen = false; }

/* Die Marke, die an die Stelle eines abgewiesenen Wertes tritt. Sie ist selbst fester Text,
 * damit ein zweiter Durchgang sie nicht noch einmal beanstandet. */
const MARKE = 'ABGEWIESEN';

/*
 * TOR 1 — zahl(x): nur echte, endliche Zahlen.
 *
 * Es wird NICHT aus einer Zeichenkette geparst. Wer aus Geraetetext eine Zahl machen will,
 * nimmt messzahl(); das ist ein eigener, enger Weg mit eigener Begruendung. Wuerde zahl()
 * selbst parsen, waere "4711" (eine Aktennummer) auf einmal eine Zahl.
 */
function zahl(x) {
  return (typeof x === 'number' && isFinite(x)) ? x : null;
}

/*
 * TOR 2 — ziffernkennung(x): ausschliesslich /^[0-9]{1,6}$/.
 * Alles andere faellt heraus, auch wenn es "wie eine Kennung aussieht".
 */
function ziffernkennung(x) {
  return (typeof x === 'string' && ZIFFERN.test(x)) ? x : null;
}

/*
 * TOR 3 — festerText(x): die Zeichenkette muss aus dem Quelltext dieser Datei stammen.
 *
 * Geprueft wird die Zugehoerigkeit zum Register, nicht die Form. Dass ein Geraet zufaellig
 * dieselben Bytes schickt (etwa "NM"), ist unschaedlich: weitergegeben wird die Zeichenkette
 * aus UNSERER Liste, und sie traegt nichts weiter als die Aussage "hat gepasst".
 */
function festerText(x) {
  return (typeof x === 'string' && (EIGEN[x] === true || ABGELEITET[x] === true)) ? x : MARKE;
}

/* stueck() — die gemeinsame Pruefung von satz() und fuege(). Genau die drei Quellen, in
 * derselben Reihenfolge wie im Dateikopf. */
function stueck(x) {
  if (typeof x === 'number' && isFinite(x)) return String(x);
  if (typeof x === 'string' &&
      (EIGEN[x] === true || ABGELEITET[x] === true || ZIFFERN.test(x))) return x;
  return MARKE;
}

/*
 * satz(...) und fuege(vorlage, werte) — die beiden Zusammensetzer.
 * KEIN viertes Tor: sie fuegen nur aneinander, was Stueck fuer Stueck schon geprueft ist,
 * und melden das Ergebnis als abgeleitet an. Ein direkt uebergebener fremder String wird zu
 * MARKE — sichtbar, nicht still.
 */
function satz() {
  let out = '';
  for (let i = 0; i < arguments.length; i++) out += stueck(arguments[i]);
  ABGELEITET[out] = true;
  return out;
}
function fuege(vorlage, werte) {
  if (!(typeof vorlage === 'string' && EIGEN[vorlage] === true)) return MARKE;
  const w = werte || [];
  let i = 0;
  const out = vorlage.replace(/\{\}/g, function () { return stueck(w[i++]); });
  ABGELEITET[out] = true;
  return out;
}

/*
 * ausListe(wert, liste, ersatz) — der einzige Weg, auf dem ein vom Geraet GEWAEHLTER Name in
 * den Bericht kommt: durch Gleichheit mit einem Eintrag unserer eigenen Liste.
 *
 * Zurueckgegeben wird der Eintrag AUS DER LISTE, nicht der Wert von der Leitung. Es gibt
 * hier kein Muster und keine Naeherung — nur Gleichheit. Genau daran waere die Marke
 * GROSS_MIT_UNTERSTRICH gescheitert, die durch eine Musterpruefung durchkam.
 */
function ausListe(wert, liste, ersatz) {
  for (let i = 0; i < liste.length; i++) {
    if (liste[i] === wert) return festerText(liste[i]);
  }
  return festerText(ersatz);
}

/*
 * messzahl(roh) — der Zahlenwert einer Messung (HF 88, SpO2 96, Temp 37,4).
 *
 * WARUM EINE ZAHL MIT DARF: eine Zahl ist keine Identitaet. Sie benennt niemanden, sie
 * gehoert zu keiner Person und laesst sich auf keine zurueckfuehren — sie ist der Messwert,
 * um den es in diesem ganzen Befund geht. Ohne ihn koennte der Entwickler nicht sehen, ob
 * das, was ankommt, ueberhaupt plausibel ist (88 gegen 0 gegen -32768).
 * WARUM SIE TROTZDEM DURCH EIN NADELOEHR GEHT: "4711" ist auch eine Zahl. Deshalb muss der
 * Wert VOLLSTAENDIG dem Zahlenmuster entsprechen — kein Buchstabe, kein Trennzeichen, kein
 * Anhaengsel — und er wird als ZAHL weitergegeben, nicht als Zeichenkette. Was danach im
 * Bericht steht, hat die Zeichenkette des Geraets nicht mehr beruehrt.
 */
const MESSZAHL = /^[-+]?[0-9]{1,9}([.,][0-9]{1,3})?$/;
function messzahl(roh) {
  const s = String(roh === null || roh === undefined ? '' : roh).trim();
  if (!MESSZAHL.test(s)) return null;
  return zahl(parseFloat(s.replace(',', '.')));
}

/*
 * pruefeBefund(knoten) — der Riegel VOR dem Schreiben, ueber die fertige Struktur.
 *
 * Er ist die Antwort auf die eine Frage, an der die beiden ersten Fassungen gescheitert
 * sind: "habe ich wirklich an jede Stelle gedacht?". Er denkt nicht mit, er geht ueber
 * ALLES, was geschrieben werden soll, und laesst nur durch, was reine Ziffern ist oder aus
 * unserem Quelltext stammt. Was uebrig bleibt, wird zu MARKE und gezaehlt — die Zahl steht
 * im Bericht, damit ein Fehler dieser Art nicht wieder unbemerkt bleibt.
 *
 * WARUM DIE SCHLUESSEL NICHT GEPRUEFT WERDEN: es gibt in dieser Datei keine einzige Stelle,
 * die aus empfangenen Daten einen Schluesselnamen macht. Alle Schluessel sind woertlich hier
 * hingeschrieben. Die eine Stelle, an der es frueher anders war (nmCodes, nach Parameter-ID
 * geschluesselt), ist heute eine LISTE — genau deshalb.
 */
function pruefeBefund(knoten, zaehler) {
  const z = zaehler || { n: 0 };
  if (Array.isArray(knoten)) {
    for (let i = 0; i < knoten.length; i++) knoten[i] = pruefeEinzeln(knoten[i], z);
  } else if (knoten && typeof knoten === 'object') {
    Object.keys(knoten).forEach(function (k) { knoten[k] = pruefeEinzeln(knoten[k], z); });
  }
  return z.n;
}
function pruefeEinzeln(w, z) {
  if (w === null || w === undefined || typeof w === 'boolean') return w;
  if (typeof w === 'number') {
    if (isFinite(w)) return w;
    z.n++;
    return null;
  }
  if (typeof w === 'string') {
    if (EIGEN[w] === true || ABGELEITET[w] === true || ZIFFERN.test(w)) return w;
    z.n++;
    return MARKE;
  }
  if (typeof w === 'object') { pruefeBefund(w, z); return w; }
  z.n++;                                   // Funktion, Symbol, ... gehoert nicht in einen Befund
  return null;
}

// ---------------------------------------------------------------------------------------
// UNSERE EIGENEN LISTEN. Alles, was ein Geraet AUSWAEHLEN, aber nicht SCHREIBEN darf.
// ---------------------------------------------------------------------------------------

/* Segmentnamen, die wir kennen. Ein Segment, das nicht in dieser Liste steht, erscheint im
 * Bericht als "(unbekanntes Segment)" mit seinem Feldprofil — nie mit seinem Namen.
 * WARUM NICHT EINFACH /^[A-Z]{3}$/: das waere wieder eine Musterpruefung auf Buchstaben, und
 * genau die hat beim letzten Mal Text durchgelassen. Wer ein neues Segment sehen will, traegt
 * es hier ein; das ist eine Zeile und eine bewusste Entscheidung. */
const SEGMENTNAMEN = ['MSH', 'MSA', 'ERR', 'QAK', 'QRD', 'QRF', 'QRI', 'PID', 'PD1', 'PV1',
  'PV2', 'NK1', 'OBR', 'OBX', 'NTE', 'EVN', 'ORC', 'DSC', 'ZDS', 'AL1', 'DG1'];
const SEG_UNBEKANNT = '(unbekanntes Segment)';
const SEG_KEINE_ZEILE = '(Zeile ohne Segmentnamen)';

/* OBX-2, der Werttyp. Feste HL7-Liste. */
const WERTTYPEN = ['NM', 'CE', 'ST', 'TX', 'FT', 'DT', 'TM', 'TS', 'ID', 'IS', 'SN', 'CWE'];
const TYP_ANDERER = '(anderer Werttyp)';

/* MSH-9, der Nachrichtentyp. */
const MELDUNGSTYPEN = ['ORU^R01', 'ORU^R32', 'ACK', 'ACK^R01', 'QRY^R02', 'QCK^Q02',
  'RSP^K11', 'ADT^A01', 'ADT^A08', 'MDM^T02'];
const TYP_ANDERE_MELDUNG = '(anderer Nachrichtentyp)';

/* MSA-1 und QAK-2: die Codes, an denen der Entwickler ablesen kann, ob das Geraet unsere
 * Abfrage angenommen (AA), inhaltlich beanstandet (AE) oder abgelehnt (AR) hat.
 * WARUM SIE MIT DUERFEN, OBWOHL SIE BUCHSTABEN SIND: sie kommen nicht als Text in den
 * Bericht, sondern als Treffer in dieser Liste — dieselbe Begruendung wie bei NM/CE/ST.
 * Ein Geraet, das dort etwas anderes hineinschreibt (auch einen Namen), trifft nicht. */
const ACK_CODES = ['AA', 'AE', 'AR', 'CA', 'CE', 'CR'];
const QAK_CODES = ['OK', 'NF', 'AE', 'AR', 'PD'];
const CODE_ANDERER = '(anderer Code)';

/* Netzwerkfehler kommen von Node, nicht vom Geraet — aber err.message kann die Adresse
 * enthalten ("connect ECONNREFUSED 192.168.0.50:4601"). Deshalb auch hier: Gleichheit gegen
 * unsere Liste, sonst ein fester Sammelbegriff. */
const NETZFEHLER = ['ECONNREFUSED', 'ECONNRESET', 'ECONNABORTED', 'EHOSTUNREACH',
  'ENETUNREACH', 'ETIMEDOUT', 'EPIPE', 'EACCES', 'EADDRNOTAVAIL', 'EADDRINUSE', 'ENOTFOUND',
  'EAI_AGAIN', 'EHOSTDOWN', 'ENETDOWN', 'ENOTCONN', 'EINVAL', 'EPROTO', 'EMFILE'];
const DATEIFEHLER = ['EACCES', 'EPERM', 'ENOENT', 'ENOSPC', 'EROFS', 'EBUSY', 'EMFILE',
  'ENAMETOOLONG', 'EIO', 'EEXIST', 'EDQUOT'];
const FEHLER_ANDERER = '(anderer Fehler)';

/*
 * Der Klartextname einer Messgroesse kommt AUS DIESER TABELLE und niemals aus dem, was das
 * Geraet in die zweite Haelfte von OBX-3 geschrieben hat. Genau dort stand bei der
 * Gegenmessung die Aktennummer ("101/HF LEAK_OBX3_TEXT_BELLA") — woertlich, in der
 * Klartextzeile des Berichts.
 * Quelle der Zuordnung: Programmer's Guide Anhang B.1, zusammengetragen in
 * docs/MINDRAY-HL7.md:399. Eine ID ohne Eintrag bleibt namenlos; das ist richtig so, denn
 * eine unbekannte ID ist selbst ein Befund.
 */
const PARAM_NAME = {
  '101': 'HF', '102': 'PVC', '151': 'AF', '160': 'SpO2', '161': 'PR', '170': 'NIBP sys',
  '171': 'NIBP dia', '172': 'NIBP mittel', '173': 'NIBP-Puls', '200': 'T1', '201': 'T2',
  '213': 'TB', '220': 'CO2', '221': 'FiCO2', '222': 'AwRR', '250': 'EtCO2', '251': 'FiCO2',
  '268': 'EtISO', '269': 'FiISO', '301': 'Pmean', '302': 'PEEP', '303': 'Pplat', '305': 'MV',
  '306': 'VTE', '309': 'Frequenz', '310': 'FiO2',
};

// ---------------------------------------------------------------------------------------
// TELEGRAMME. Alles hier ist von Hand gebaut (siehe Dateikopf).
// ---------------------------------------------------------------------------------------

/* Die IDs, die die Station heute erfragt — unveraendert uebernommen, damit die
 * Varianten 1..6 sich nur in dem einen absichtlich geaenderten Stueck unterscheiden.
 * (202 steht so im heutigen Code; im Guide-Anhang B.1 ist die ID nicht gefuehrt. Genau
 * deshalb faehrt Variante 7 zusaetzlich die vollstaendige, belegte Liste.)
 *
 * NACHGEZOGEN AM 29.08.2026 — von zwoelf auf zweiundzwanzig IDs:
 * Der Adapter fragt seit dem 28.08.2026 zusaetzlich Kapnografie und Beatmung ab
 * (250&251&268&269, 301&303&305&306, 309&310). Der Riegel in pds-feldsonde-test.js hat
 * genau das gemeldet — er liest _sendQuery() als Text und vergleicht; dafuer gibt es ihn.
 * Nachgezogen wird die Kopie, NICHT der Riegel entschaerft: sonst bildeten die Varianten
 * nicht mehr ab, was die Station wirklich sendet, und die Sonde maesse etwas anderes als
 * den Ist-Zustand.
 *
 * 302 FEHLT MIT ABSICHT UND MUSS WEITER FEHLEN. Der Guide fuehrt 302 als PEEP, die CODE_MAP
 * des Adapters fuehrt '302' als PVC-Rate (am echten uMEC/LifeVet belegt). Wer sie anfordert,
 * laesst eine Beatmungszahl als ventrikulaere Extrasystolen verbuchen. Variante 7 faehrt die
 * vollstaendige Liste (mit 302) ausdruecklich als MESSUNG — dort ist sie eine Frage an das
 * Geraet, hier waere sie eine Aussage der Station.
 *
 * WAS DIE VARIANTEN 1 UND 2 SEITHER BEDEUTEN — bitte vor dem naechsten Messlauf lesen:
 * Variante 1 ist NICHT MEHR "was die Station heute sendet", sondern der Stand VOR der
 * Berichtigung vom 29.08.2026: MSH-10 als laufende Nummer und ohne <CR> hinter dem letzten
 * Segment. Genau dieser Stand ist am echten uMEC12 als der STUMME erwiesen. Was die Station
 * heute sendet, ist Variante 2 — und die hat am Geraet geliefert. Die Leiter behaelt damit
 * ihren Sinn, nur ihre Mitte hat sich verschoben. */
const IDS_HEUTE = [
  ['101', '151', '160', '161'],
  ['170', '171', '172', '200'],
  ['201', '202', '220', '222'],
  ['250', '251', '268', '269'],
  ['301', '303', '305', '306'],
  ['309', '310'],
];

/* Vollstaendige Parameterliste aus Guide Anhang B.1, in Gruppen zu VIER.
 * Warum vier und nicht fuenf: 6.9.5.1 schreibt woertlich "The amount of <ID> in each Query
 * Filter is less than 5" — also hoechstens vier; kein Beispiel im ganzen Dokument nutzt
 * fuenf, und der Guide setzt hinterher, die Hoechstzahl sei je Geraetemodell verschieden.
 * Vier ist die belegte sichere Seite; mit fuenf risse Variante 7 an einer Regel, die wir
 * gar nicht messen wollen. */
const IDS_ALLE = [
  ['51', '52', '101', '102'],
  ['151', '160', '161', '170'],
  ['171', '172', '200', '201'],
  ['213', '220', '221', '222'],
  ['250', '251', '268', '269'],
  ['301', '302', '303', '305'],
  ['306', '309', '310'],
];

/*
 * Wortlaut aus Guide 6.7, einschliesslich des abschliessenden "|" — und seit dem 28.08.2026
 * auch mit dem <CR> dahinter. Begruendung steht bei baueAbfrage(): der Guide setzt hinter
 * JEDES Segment einen Wagenruecklauf, auch hinter das einzige einer Echo-Nachricht.
 */
const ECHO_TEXT = 'MSH|^~\\&|||||||ORU^R01|106|P|2.3.1|\r';

const NUMMER = { n: 1 };     // wie QID.n in hl7.js: laufende Nummer, beginnend bei 1

/*
 * naechsteNummer() — die laufende Nummer, aber NIE 1203.
 *
 * WARUM DIESE EINE ZAHL AUSGESPART WIRD: 1203 ist laut Guide 6.9.3 die feste Kennung, die
 * Variante 2 gegen Variante 1 abgrenzt ("must be 1203"). Variante 1 setzt in MSH-10 die
 * laufende Nummer — traefe die zufaellig 1203, sendete Variante 1 in Wahrheit Variante 2, das
 * Geraet naehme sie an, und der Befund nennte den falschen Schuldigen. Der Fall ist heute
 * fern (die Nummer wird je Abfrage um eins hochgezaehlt), aber "fern" ist kein Riegel: das
 * Modul-Singleton laeuft ueber alle Varianten und alle Wiederholungen eines Prozesses weiter.
 * Eine ausgesparte Zahl kostet nichts und macht den Fall unmoeglich statt unwahrscheinlich.
 */
const MSH10_FEST = '1203';
function naechsteNummer() {
  if (String(NUMMER.n) === MSH10_FEST) NUMMER.n++;
  return NUMMER.n++;
}

/* Die Platzhalter, die im BERICHT an der Stelle der veraenderlichen Stuecke der Abfrage
 * stehen. Sie sind fester Text aus dieser Datei — anders als ein 14-stelliger Zeitstempel
 * oder ein Zaehlerstand, die durch keines der drei Tore passen. Fuer den Entwickler ist die
 * FELDLAGE das Wertvolle ("steht 1203 in MSH-10 oder in MSH-9?"), nicht die Uhrzeit. */
const PLATZ_ZEIT = '<Zeitstempel>';
const PLATZ_KENNUNG = '<Kennung>';
const PLATZ_NUMMER = '<laufende Nummer>';

/* Die Bausteine der Abfrage, woertlich. Sie stehen einzeln da, weil aus DENSELBEN Stuecken
 * zweierlei entsteht: die Bytes fuer die Leitung und der Abdruck fuer den Bericht. Zwei
 * getrennte Bauwege wuerden auseinanderlaufen — und dann zeigte der Bericht eine Abfrage,
 * die so nie gesendet wurde. */
const ABF = melde({
  mshVor: 'MSH|^~\\&|||||',
  mshNach: '||QRY^R02|',
  mshEnde: '|P|2.3.1',
  qrdVor: 'QRD|',
  qrdMitte: '|R|I|',
  qrdEnde: '|||||RES',
  qrfSendall: 'QRF|MON||||0&0^1^1^1^',
  qrfListe: 'QRF|MON||||0&0^1^1^0^',
  und: '&',
  leer: '',
});

/*
 * abfrageStuecke(v, jetzt, nr) — die Abfrage als Liste von Segmenten, jedes Segment eine
 * Liste von Stuecken. Ein Stueck ist entweder feste Zeichenkette (dann geht sie unveraendert
 * auf die Leitung UND in den Bericht) oder ein Paar { leitung, bericht }.
 * MSH-Feldlage nachgezaehlt: MSH-7 = Index 6, MSH-9 = Index 8, MSH-10 = Index 9.
 */
function abfrageStuecke(v, jetzt, nr) {
  const msh10 = v.msh10 === MSH10_FEST
    ? MSH10_FEST                                   // reine Ziffern: darf woertlich mit
    : { leitung: String(nr), bericht: PLATZ_NUMMER };
  const msh7 = v.msh7
    ? { leitung: ortszeit14(jetzt), bericht: PLATZ_ZEIT }
    : ABF.leer;
  const qrd1 = { leitung: v.qrd1 === 'ortszeit' ? ortszeit14(jetzt) : utc14(jetzt),
    bericht: PLATZ_ZEIT };
  /* QRD-4 muss laut 6.9.4 nicht leer und unter 16 Byte sein; auf Eindeutigkeit prueft der
   * Server ausdruecklich nicht. Abschneiden ist die Zusicherung der Laenge, nicht Kosmetik. */
  const kennung = { leitung: ('Q' + nr).slice(0, 15), bericht: PLATZ_KENNUNG };
  const segs = [
    [ABF.mshVor, msh7, ABF.mshNach, msh10, ABF.mshEnde],
    [ABF.qrdVor, qrd1, ABF.qrdMitte, kennung, ABF.qrdEnde],
  ];
  if (v.filter === 'sendall') {
    // SendAll = 1: alles, was das Geraet hat. Dahinter steht dann KEINE Liste (6.9.5.1).
    segs.push([ABF.qrfSendall]);
  } else {
    const gruppen = v.filter === 'alle' ? IDS_ALLE : IDS_HEUTE;
    gruppen.forEach(function (g) {
      const teile = [ABF.qrfListe];
      g.forEach(function (id, i) {
        if (i) teile.push(ABF.und);
        teile.push(id);                              // reine Ziffern, Tor 2
      });
      segs.push(teile);
    });
  }
  return segs;
}

/*
 * Fuer die Leitung: die echten Bytes.
 *
 * DAS ABSCHLIESSENDE <CR> (Befund 28.08.2026, aus der Gegenpruefung des ersten Messlaufs):
 * Bis heute endete die Nachricht mit dem letzten Segment OHNE Wagenruecklauf, also
 *     ...&222<FS><CR>       statt      ...&222<CR><FS><CR>
 * Der Guide setzt in JEDEM Beispiel (6.9.2, 6.9.6, 6.7) ein <CR> hinter JEDES Segment, auch
 * hinter das letzte, und sagt zugleich (1.1.1), dass der Server verbotene Steuerzeichen
 * ausdruecklich NICHT gesondert behandelt - eine formwidrige Nachricht wird nach 6.9.7 ohne
 * jede Rueckmeldung verworfen. Genau das war das Krankheitsbild.
 *
 * Warum es niemandem aufgefallen ist: tools/pds-testgeraet.js ist aus DERSELBEN Lesart
 * desselben Kapitels gebaut und nimmt denselben Mangel an. Gruen hiess dort "mit sich selbst
 * einig", nicht "richtig" - dieselbe Falle wie beim Septum-Leck.
 *
 * VARIANTE 1 BEKOMMT ES BEWUSST NICHT. Sie ist die Vergleichsgroesse und muss weiterhin
 * byteweise das abbilden, was die Station heute sendet. Bekaeme sie das <CR> auch, waere die
 * Messung ihres eigenen Anlasses beraubt: dann liefe der Vergleich "richtig gegen richtig".
 */
function baueAbfrage(v) {
  const segs = abfrageStuecke(v, new Date(), naechsteNummer());
  const text = segs.map(function (teile) {
    return teile.map(function (t) { return typeof t === 'string' ? t : t.leitung; }).join('');
  }).join('\r');
  return v.nr === 1 ? text : text + '\r';
}

/* Fuer den Bericht: dieselben Segmente, aber jedes Stueck durch die Tore. */
function abfragePlan(v) {
  return abfrageStuecke(v, null, 0).map(function (teile) {
    return satz.apply(null, teile.map(function (t) {
      return typeof t === 'string' ? t : t.bericht;
    }));
  });
}

/*
 * baueAck(orig) — BYTEGLEICH zu _sendAck in bridge/src/adapters/hl7.js (Stand 28.08.2026),
 * einschliesslich des dort gemessenen Feldversatzes: nach "VetStation" stehen fuenf statt
 * vier Pipes, MSH-9 bleibt dadurch leer und "ACK^R01" landet in MSH-10.
 *
 * WARUM DER FEHLER HIER MITGEBAUT WIRD: Variante 1 soll beweisen, dass die Sonde das heutige
 * Krankheitsbild trifft. Schickte sie ein sauberes ACK, koennte sie sich anders verhalten als
 * die Station — und ein Unterschied, den ich selbst hineingebaut habe, waere kein Befund.
 * Verschickt wird das ACK deshalb auch NUR in den beiden "heute"-Varianten 1 und 2.
 *
 * DIESE FUNKTION SCHREIBT NICHTS AUF DIE PLATTE. Sie ist die einzige Stelle, die einen Wert
 * aus einer empfangenen Nachricht (die Control-ID) weiterverwendet — und der geht ZURUECK
 * ans Geraet, das ihn selbst geschickt hat, nicht in den Befund.
 */
function baueAck(orig) {
  const msh = (String(orig).split(/[\r\n]+/)[0] || '').split('|');
  const ctrlId = msh[9] || '1';
  return 'MSH|^~\\&|VetStation|||||' + utc14() + '||ACK^R01|' + ctrlId + '|P|2.3.1\rMSA|AA|' +
    ctrlId + '\r';
}

// ---------------------------------------------------------------------------------------
// DIE ACHT VARIANTEN. Jede aendert gegenueber der vorigen GENAU EIN Stueck — sonst liesse
// sich aus einem Erfolg nicht ablesen, WORAN es lag.
//
// WAS DER MESSLAUF VOM 29.08.2026 AM ECHTEN uMEC12 ERGEBEN HAT (bitte hier stehen lassen,
// sonst faehrt der Naechste die Leiter noch einmal von unten):
//   - Variante 2 hat GELIEFERT: SpO2, Puls, HF, AF im Sekundentakt.
//   - Die Varianten 3 bis 8 — also die spezifikationstreue Lesart mit einer Abfrage je
//     Verbindung, 1-Sekunden-Echo und OHNE Quittung — lieferten NICHTS. Alle sechs.
// Daraus folgt die Berichtigung im Adapter: MSH-10 = 1203 und ein <CR> hinter dem letzten
// Segment, sonst alles beim Alten (Wiederholung alle 5 s, Quittung auf jede Nachricht).
// Der Buchstabe des Guides ist an diesem Geraet die falsche Lesart. Wer das "aufraeumt",
// nimmt dem Tierarzt am narkotisierten Patienten alle Messwerte weg.
// ---------------------------------------------------------------------------------------

const VARIANTEN = [
  /* Der Kurzname bleibt 'heute', obwohl Variante 1 seit dem 29.08.2026 NICHT mehr das ist,
   * was die Station sendet: er ist im Textregister angemeldet und steht so in jedem frueher
   * abgelegten Befund. Was sie WIRKLICH ist, sagt der Fliesstext daneben — er wandert mit in
   * den Bericht und wird gelesen, der Kurzname ist nur eine Spaltenbeschriftung. */
  { nr: 1, kurz: 'heute', msh10: 'laufend', msh7: false, qrd1: 'utc', echo: false, ack: true,
    wiederholMs: 5000, filter: 'heute',
    was: 'der Stand VOR der Berichtigung vom 29.08.2026 — am echten Geraet der stumme: ' +
         'MSH-10 laufende Nummer, kein <CR> hinter dem letzten Segment, MSH-7 leer, ' +
         'QRD-1 in UTC, kein Echo, Abfrage alle 5 s, ACK auf jede Nachricht' },
  { nr: 2, kurz: 'msh10', msh10: '1203', msh7: false, qrd1: 'utc', echo: false, ack: true,
    wiederholMs: 5000, filter: 'heute',
    was: 'wie 1, aber MSH-10 = 1203 (Guide 6.9.3: "must be 1203") und mit <CR> hinter dem ' +
         'letzten Segment — das ist seit dem 29.08.2026 das, was die Station sendet, und ' +
         'die Variante, die am echten uMEC12 die laufenden Messwerte gebracht hat' },
  { nr: 3, kurz: 'msh10+echo', msh10: '1203', msh7: false, qrd1: 'utc', echo: true, ack: false,
    wiederholMs: 0, filter: 'heute',
    was: 'wie 2, plus 1-Sekunden-Echo (Guide 6.7), Abfrage nur EINMAL, kein ACK mehr' },
  { nr: 4, kurz: '+msh7', msh10: '1203', msh7: true, qrd1: 'utc', echo: true, ack: false,
    wiederholMs: 0, filter: 'heute',
    was: 'wie 3, plus gefuellter Zeitstempel MSH-7 in Ortszeit' },
  /*
   * ACHTUNG (28.08.2026): Variante 5 ist NICHT MEHR das, was "pdsStrict": true sendet.
   * Der Schalter legt MSH-7 seit heute LEER auf die Leitung — Guide 6.4.1.1 fuehrt das Feld
   * gar nicht als benutzt, alle QRY-Beispiele des Kapitels lassen es leer, und 6.9.3 verlangt
   * genau diese Form. Der Adapter faehrt damit "Variante 3 mit der Ortszeit aus Variante 5";
   * genau diese Mischung steht hier bewusst NICHT als eigene Variante, weil jede Variante
   * gegenueber der vorigen genau EIN Stueck aendern soll. Wer sie am Geraet pruefen will,
   * fuegt sie hier an — und aendert dann auch die Deutung unten.
   */
  { nr: 5, kurz: '+qrd1', msh10: '1203', msh7: true, qrd1: 'ortszeit', echo: true, ack: false,
    wiederholMs: 0, filter: 'heute',
    was: 'wie 4, plus QRD-1 in Ortszeit statt UTC' },
  { nr: 6, kurz: 'sendall', msh10: '1203', msh7: true, qrd1: 'ortszeit', echo: true, ack: false,
    wiederholMs: 0, filter: 'sendall',
    was: 'wie 5, aber QRF-5 SendAll = 1: alle Parameter, ohne Liste' },
  { nr: 7, kurz: 'einzeln', msh10: '1203', msh7: true, qrd1: 'ortszeit', echo: true, ack: false,
    wiederholMs: 0, filter: 'alle',
    was: 'wie 5, aber die vollstaendige Parameterliste des Guides, auf QRF-Segmente zu je ' +
         'hoechstens vier IDs verteilt' },
  { nr: 8, kurz: 'nur-lauschen', msh10: '1203', msh7: true, qrd1: 'ortszeit', echo: true,
    ack: false, wiederholMs: 0, filter: 'keine',
    was: 'KEINE Abfrage, nur zuhoeren (mit Echo, damit die Verbindung stehen bleibt). ' +
         'Referenzmessung: was schickt das Geraet von sich aus?' },
];

// ---------------------------------------------------------------------------------------
// EMPFANGENE NACHRICHTEN: NICHT ABDRUCKEN, SONDERN BESCHREIBEN
// ---------------------------------------------------------------------------------------

function segmente(text) {
  return String(text).split(/[\r\n]+/).map(function (s) { return s.trim(); }).filter(Boolean);
}
function felder(seg) { return String(seg).split('|'); }

/* Deckel. Ein Geraet, das eine Nachricht mit 4000 Segmenten schickt, soll den Bericht nicht
 * mit Zahlen zuschuetten — auch harmlose Zahlen machen einen Befund unlesbar. */
const MAX_SEGMENTE = 40;
const MAX_FELDNUMMERN = 40;

/*
 * segmentPlan(seg) — EIN Segment, ohne seinen Inhalt.
 *
 * Ergebnis zum Beispiel:
 *   { name: 'OBX', felder: 11, gefuellt: [2,3,5,11], typ: 'NM', kennziffer: '101' }
 *
 * Was hier herauskommt, ist entweder eine Zahl (Tor 1), eine reine Ziffernfolge (Tor 2) oder
 * ein Treffer in einer unserer Listen (Tor 3). Der Feldinhalt selbst wird nur daraufhin
 * angesehen, OB er leer ist — gelesen wird er nicht.
 *
 * FELDZAEHLUNG: HL7-Zaehlung, also PID-3 ist wirklich das dritte Feld. Bei MSH ist der Index
 * um eins verschoben, weil MSH-1 das Trennzeichen selbst IST (arr[i] = MSH-(i+1)).
 */
function segmentPlan(seg) {
  const f = felder(seg);
  const roh = String(f[0] || '');
  const istMsh = roh.toUpperCase() === 'MSH';
  const name = ausListe(roh.toUpperCase(), SEGMENTNAMEN,
    roh.length === 3 ? SEG_UNBEKANNT : SEG_KEINE_ZEILE);
  const gefuellt = [];
  for (let i = 1; i < f.length && gefuellt.length < MAX_FELDNUMMERN; i++) {
    if (f[i] !== '') gefuellt.push(zahl(istMsh ? i + 1 : i));
  }
  if (istMsh) gefuellt.unshift(zahl(1));         // MSH-1 ist das Trennzeichen, immer gesetzt
  const plan = {
    name: name,
    felder: zahl(istMsh ? f.length : f.length - 1),
    gefuellt: gefuellt,
    typ: null,
    kennziffer: null,
  };
  if (name === 'OBX') {
    plan.typ = ausListe(String(f[2] || ''), WERTTYPEN, TYP_ANDERER);
    plan.kennziffer = ziffernkennung(String(f[3] || '').split('^')[0]);
  }
  return plan;
}

/*
 * fehlerPlan(name, seg) — MSA/ERR/QAK, das Wertvollste im ganzen Lauf.
 *
 * Der Guide sagt unter 6.3.3 ausdruecklich, auf eine falsch geformte Abfrage komme gar keine
 * ACK/NACK zurueck. Kommt trotzdem eine, sagt sie dem Entwickler direkt, was das Geraet
 * beanstandet — deshalb wird sie ausfuehrlicher beschrieben als andere Segmente.
 * AUSFUEHRLICHER HEISST NICHT WOERTLICHER. Bei der Gegenmessung hat ein Geraet den Patienten
 * in seine Beanstandung geschrieben ("Abfrage abgelehnt fuer AKTE-99887", ERR-1 mit dem Text
 * "unbekannt fuer Bella^Muster") und damit Name und Aktennummer in beide Berichtsdateien
 * getragen. Die Ueberlegung "unsere Abfrage enthaelt keine Patientendaten, also kann die
 * Antwort darauf auch keine enthalten" war falsch: das Geraet antwortet mit SEINEM Wissen.
 * Uebernommen werden deshalb nur Zahlen und Treffer in unseren Codelisten.
 */
function fehlerPlan(name, seg) {
  const f = felder(seg);
  const plan = segmentPlan(seg);
  const codes = [];
  function nimm(feld, wert) {
    if (wert !== null && wert !== MARKE) codes.push({ feld: zahl(feld), wert: wert });
  }
  if (name === 'MSA') {
    nimm(1, ausListe(String(f[1] || ''), ACK_CODES, CODE_ANDERER));
    nimm(2, ziffernkennung(String(f[2] || '')));       // unsere eigene Control-ID, zurueckgespiegelt
    nimm(6, ziffernkennung(String(f[6] || '').split('^')[0]));
  } else if (name === 'QAK') {
    /* QAK-1 ist unser Query-Tag ("Q17") und faellt am Ziffernmuster heraus — richtig so:
     * es steht in der Abfrage weiter oben ohnehin schon drin. QAK-3 war beim letzten Mal
     * eines der fuenf offenen Felder; heute wird es gar nicht erst angesehen. */
    nimm(2, ausListe(String(f[2] || ''), QAK_CODES, CODE_ANDERER));
  } else if (name === 'ERR') {
    /* ERR-1: <Segment>^<Folge>^<Feld>^<Code>^<Text>. Segmentname gegen unsere Liste, die
     * drei Zahlen gegen das Ziffernmuster, der Text gar nicht. */
    const teil = String(f[1] || '').split('^');
    nimm(1, ausListe(String(teil[0] || ''), SEGMENTNAMEN, SEG_UNBEKANNT));
    nimm(2, ziffernkennung(String(teil[1] || '')));
    nimm(3, ziffernkennung(String(teil[2] || '')));
    nimm(4, ziffernkennung(String(teil[3] || '')));
  }
  plan.codes = codes;
  return plan;
}

/*
 * deute(roh) — was ist das fuer eine Nachricht, und was steht an Messwerten drin?
 *
 * WICHTIG: deute() bekommt den ROHTEXT von der Leitung — und gibt NUR gepruefte Werte
 * heraus. Bis heute bekam sie einen zuvor maskierten Text; das war der Versuch, den Rohtext
 * so weit zu entschaerfen, dass man ihn abdrucken kann. Genau der Versuch ist zweimal
 * gescheitert. Jetzt gilt umgekehrt: der Rohtext wird gelesen, aber nichts von ihm verlaesst
 * diese Funktion. Was herauskommt, sind Zahlen, Ziffernkennungen und Treffer in unseren
 * Listen — sonst nichts.
 *
 * ACHTUNG, MESSFALLE: die aperiodischen NIBP-Zeilen sind EBENFALLS vom Typ NM. Wer Periodik
 * am Wort "NM" misst, misst falsch und haelt eine tote Anbindung fuer lebendig — genau
 * dieser Irrtum steckt hinter dem heutigen Eindruck, "es kommt doch etwas an". Unterschieden
 * wird deshalb an der Message Control ID (204 periodisch, 503 aperiodisch) UND am Wort
 * APERIODIC in der OBX-Zeile; ein fremdes Geraet, das andere Control-IDs benutzt, faellt so
 * trotzdem richtig heraus. Beide Vergleiche sind VERGLEICHE — sie schreiben nichts.
 */
function deute(roh) {
  const segs = segmente(roh);
  const msh = felder(segs[0] || '');
  const rohTyp = msh[8] || '';
  const rohCtrl = msh[9] || '';
  const d = {
    typ: ausListe(rohTyp, MELDUNGSTYPEN, TYP_ANDERE_MELDUNG),
    ctrl: ziffernkennung(rohCtrl),
    echo: false, aperiodisch: false, patient: false, nameGesehen: false,
    nm: [], ce: [], ceOhneKennung: 0, nmOhneKennziffer: 0,
    fehler: [], plan: [],
  };

  // Echo (Guide 6.7): ORU^R01, Control-ID 106, keine weiteren Segmente.
  if (rohTyp === 'ORU^R01' && rohCtrl === '106' && segs.length === 1) {
    d.echo = true;
    return d;
  }

  segs.forEach(function (seg, i) {
    /* Die Segmentart kommt aus dem ERSTEN FELD, nicht aus den ersten drei Zeichen der Zeile.
     * Sonst gaelte "MSAX|..." als MSA — und dann stuenden unter dem Namen
     * "(unbekanntes Segment)" MSA-Codes, die von dort gar nicht stammen. */
    const art = String(felder(seg)[0] || '').toUpperCase();
    const istFehler = art === 'MSA' || art === 'ERR' || art === 'QAK';
    const plan = istFehler ? fehlerPlan(art, seg) : segmentPlan(seg);
    if (i < MAX_SEGMENTE) d.plan.push(plan);
    if (istFehler) {
      if (d.fehler.length < 10) d.fehler.push(plan);
      return;
    }
    if (art === 'PID') {
      d.patient = true;
      const f = felder(seg);
      /* Gefragt ist nur, OB ein Name kam — das sagt dem Entwickler, dass das Geraet
       * Patientendaten sendet. Gelesen wird der Name nicht, weitergegeben ein Ja/Nein. */
      if (f[5]) d.nameGesehen = true;
      return;
    }
    if (art !== 'OBX') return;
    const f = felder(seg);
    const wertTyp = String(f[2] || '');
    const kennziffer = ziffernkennung(String(f[3] || '').split('^')[0]);
    if (seg.indexOf('|APERIODIC') >= 0) d.aperiodisch = true;
    if (wertTyp === 'NM') {
      if (kennziffer === null) d.nmOhneKennziffer++;
      else d.nm.push({ kennziffer: kennziffer, wert: messzahl(String(f[5] || '').split('^')[0]) });
    } else if (wertTyp === 'CE') {
      /* Guide 2.2.7.4: OBX-5 ist hier "<ID>^<Text>" — die ID aus dem Alarmkatalog, der Text
       * frei und "in mehreren Sprachen". Der Bericht braucht den Alarm, nicht seinen
       * Wortlaut: gezaehlt wird er ohnehin, und mit der Nummer schlaegt der Entwickler im
       * Anhang nach. Passt die Nummer nicht auf reine Ziffern, wird der Alarm nur GEZAEHLT. */
      const alarm = ziffernkennung(String(f[5] || '').split('^')[0]);
      if (alarm === null) d.ceOhneKennung++;
      else d.ce.push(alarm);
    }
  });

  if (rohCtrl === '503') d.aperiodisch = true;
  return d;
}

// ---------------------------------------------------------------------------------------
// EINE VARIANTE FAHREN
// ---------------------------------------------------------------------------------------

/* Wie oft darf innerhalb eines Zeitfensters neu verbunden werden? Trennt das Geraet staendig,
 * ist das der Befund — eine unbegrenzte Schleife wuerde ihn nur mit Rauschen zudecken. */
const MAX_VERBINDUNGEN = 12;
const NEUVERBINDUNG_MS = 800;

/* Feste Bezeichnungen fuer die Umstaende eines Fehlschlags. Sie stehen hier, damit auch die
 * Fehlermeldungen aus unserem Quelltext kommen und nicht aus err.message. */
const F = melde({
  aufbau: 'Verbindungsaufbau fehlgeschlagen',
  abbruch: 'Verbindung abgebrochen',
  frist: 'Zeitueberschreitung beim Verbindungsaufbau',
  wegVorSenden: 'Verbindung war beim Senden schon weg',
  schreibfehler: 'Schreiben fehlgeschlagen',
  wofuerAbfrage: 'Abfrage',
  wofuerEcho: 'Echo',
  wofuerAck: 'Quittung',
  dateiBericht: 'Bericht (Text)',
  dateiMaschine: 'Bericht (Maschinenform)',
});

function fahreVariante(v, opt, fertig) {
  const start = Date.now();
  const ende = start + opt.fensterMs;
  const e = {
    nr: zahl(v.nr), kurz: festerText(v.kurz), was: festerText(v.was),
    /* filter gehoert ZUM ERGEBNIS, nicht in eine Nachbesserung durch laufe(): gesamturteil()
     * ist exportiert und liest e.filter. Wer es einzeln aufrief, bekam vorher ein Urteil auf
     * lauter undefined — und "undefined !== 'keine'" faellt nirgends auf. */
    filter: festerText(v.filter),
    verbindungen: 0, verbunden: false, verbindungsfehler: [],
    abfragenGesendet: 0, echosGesendet: 0, acksGesendet: 0, abfrageplan: [],
    sendefehler: [],
    rahmen: 0, echos: 0, periodikRahmen: 0, aperiodischeRahmen: 0, patientRahmen: 0,
    messwerte: [], messwerteAperiodisch: [], messwerteOhneKennziffer: 0,
    alarmAnzahl: 0, alarmKennungen: [], alarmeOhneKennung: 0,
    fehlerSegmente: [], nameGesehen: false,
    trennungen: 0, msBisErsteNachricht: null, msBisErstePeriodik: null,
    bauplaene: [], dauerMs: 0, urteil: '', stufe: '',
  };

  /* Waehrend der Messung wird nach Kennziffer gesammelt; die Kennziffer ist selbst schon
   * durch Tor 2 gegangen. In den Befund geht daraus eine LISTE — damit es in der ganzen
   * Struktur keinen einzigen Schluessel gibt, der aus Empfangenem entstanden ist. */
  const nmMap = Object.create(null);
  const apMap = Object.create(null);

  let sock = null;
  let tEcho = null, tAbfrage = null, tFenster = null, tVerbindeFrist = null, tNeu = null;
  let vonUnsBeendet = false, abgeschlossen = false;
  let puffer = Buffer.alloc(0);

  function timerWeg() {
    [tEcho, tAbfrage, tVerbindeFrist, tNeu].forEach(function (t) {
      if (t) { clearInterval(t); clearTimeout(t); }
    });
    tEcho = tAbfrage = tVerbindeFrist = tNeu = null;
  }

  function listeAus(map) {
    return Object.keys(map).sort(function (a, b) { return Number(a) - Number(b); })
      .map(function (id) {
        return {
          kennziffer: ziffernkennung(id),
          /* Der Klartextname kommt AUS UNSERER Tabelle, nie aus OBX-3. Genau dort stand bei
           * der Gegenmessung die Aktennummer. */
          name: PARAM_NAME[id] ? festerText(PARAM_NAME[id]) : null,
          anzahl: zahl(map[id].anzahl),
          letzter: zahl(map[id].letzter),
        };
      });
  }

  function schliesse() {
    if (abgeschlossen) return;
    abgeschlossen = true;
    vonUnsBeendet = true;
    timerWeg();
    if (tFenster) { clearTimeout(tFenster); tFenster = null; }
    if (sock) { try { sock.destroy(); } catch (_) {} sock = null; }
    e.messwerte = listeAus(nmMap);
    e.messwerteAperiodisch = listeAus(apMap);
    e.dauerMs = Date.now() - start;
    beurteile(v, e);
    fertig(e);
  }

  /*
   * sende(text, wofuer) — und WARUM der Fehlschlag aufgeschrieben wird.
   *
   * Bis 28.08.2026 stand hier "catch (_) { return false; }" und sonst nichts. Ging die Abfrage
   * nie hinaus (RST unmittelbar nach dem Handshake, halbgeschlossene Verbindung), zaehlte die
   * Variante als "stumm" — als haette das Geraet auf eine gesendete Abfrage geschwiegen. Aus
   * mehreren solchen Fehlschlaegen schrieb das Gesamturteil dann den Satz "Die Ursache steckt
   * damit nicht in der Form der Abfrage" und lieferte dem Entwickler einen falschen
   * Ausschluss. Ein Fehlschlag muss als Fehlschlag im Befund stehen, nicht als Messwert.
   * Der GRUND wird dabei gegen unsere Liste der Netzwerkfehler abgeglichen: err.message
   * enthaelt bei Node die Zieladresse, und die gehoert nicht in den Bericht.
   */
  function sende(text, wofuer) {
    if (!sock || sock.destroyed) {
      if (e.sendefehler.length < 10) {
        e.sendefehler.push({ wofuer: festerText(wofuer), grund: festerText(F.wegVorSenden) });
      }
      return false;
    }
    try { sock.write(mllp(text)); return true; } catch (err) {
      if (e.sendefehler.length < 10) {
        e.sendefehler.push({ wofuer: festerText(wofuer), grund: netzGrund(err) });
      }
      return false;
    }
  }

  function merkeBauplan(plan) {
    /* Hoechstens drei verschiedene Bauplaene je Variante. Verglichen wird die fertige
     * Struktur; sie besteht ausschliesslich aus Zahlen und Namen aus unseren Listen. */
    if (e.bauplaene.length >= 3) return;
    const kennung = JSON.stringify(plan);
    for (let i = 0; i < e.bauplaene.length; i++) {
      if (JSON.stringify(e.bauplaene[i]) === kennung) return;
    }
    e.bauplaene.push(plan);
  }

  /*
   * verarbeite(roh) — hier endet der Weg des Rohtextes.
   * Was diese Funktion in e schreibt, ist ausschliesslich das Ergebnis von deute(), und das
   * hat die drei Tore schon hinter sich. Der Rohtext selbst wird nur noch fuer EINE Sache
   * gebraucht: das ACK, das ZURUECK ans Geraet geht (Control-ID) — nicht auf die Platte.
   */
  function verarbeite(roh) {
    e.rahmen++;
    if (e.msBisErsteNachricht === null) e.msBisErsteNachricht = Date.now() - start;
    const d = deute(roh);
    if (d.nameGesehen) e.nameGesehen = true;
    if (d.echo) { e.echos++; return; }
    d.fehler.forEach(function (p) {
      if (e.fehlerSegmente.length < 10) e.fehlerSegmente.push(p);
    });
    if (d.patient) e.patientRahmen++;
    e.alarmAnzahl += d.ce.length + d.ceOhneKennung;
    e.alarmeOhneKennung += d.ceOhneKennung;
    d.ce.forEach(function (nummer) {
      if (e.alarmKennungen.length < 12 && e.alarmKennungen.indexOf(nummer) < 0) {
        e.alarmKennungen.push(nummer);
      }
    });
    e.messwerteOhneKennziffer += d.nmOhneKennziffer;
    if (d.nm.length) {
      const ziel = d.aperiodisch ? apMap : nmMap;
      d.nm.forEach(function (w) {
        if (!ziel[w.kennziffer]) ziel[w.kennziffer] = { anzahl: 0, letzter: null };
        ziel[w.kennziffer].anzahl++;
        if (w.wert !== null) ziel[w.kennziffer].letzter = w.wert;
      });
      if (d.aperiodisch) e.aperiodischeRahmen++;
      else {
        e.periodikRahmen++;
        if (e.msBisErstePeriodik === null) e.msBisErstePeriodik = Date.now() - start;
      }
    } else if (d.aperiodisch) {
      e.aperiodischeRahmen++;
    }
    merkeBauplan({ typ: d.typ, ctrl: d.ctrl, segmente: d.plan });
    /* ACK nur in den "heute"-Varianten: dort gehoert es zum nachgestellten Ist-Zustand.
     * Ab Variante 3 ist das Echo das Keepalive, und Guide 6.3.3 Punkt 9 laesst das Geraet
     * bei jeder anderen Nachricht trennen. */
    if (v.ack) { if (sende(baueAck(roh), F.wofuerAck)) e.acksGesendet++; }
  }

  function verbinde() {
    if (abgeschlossen) return;
    if (Date.now() >= ende) return schliesse();
    e.verbindungen++;
    puffer = Buffer.alloc(0);
    const s = net.connect({ host: opt.host, port: opt.port });
    sock = s;
    s.setNoDelay(true);

    /* Eigene Frist statt sock.setTimeout: setTimeout am Socket schlaegt auch bei einer
     * stehenden, aber stillen Verbindung zu — und Stille ist hier ein Messwert, kein Fehler.
     * Ein blockiertes SYN (Firewall) laeuft unter Windows sonst ~20 s, das kostete acht mal
     * eine halbe Minute Wartezeit fuer nichts. */
    tVerbindeFrist = setTimeout(function () {
      if (!e.verbunden) {
        e.verbindungsfehler.push({
          art: festerText(F.frist), grund: null,
          sekunden: zahl(Math.round(opt.verbindeFristMs / 1000)),
        });
        try { s.destroy(); } catch (_) {}
        schliesse();
      }
    }, opt.verbindeFristMs);

    s.on('connect', function () {
      e.verbunden = true;
      if (tVerbindeFrist) { clearTimeout(tVerbindeFrist); tVerbindeFrist = null; }
      opt.log('Variante ' + v.nr + ' (' + v.kurz + '): verbunden mit ' + opt.host + ':' +
        opt.port + ' (Verbindung ' + e.verbindungen + ').');
      if (v.echo) {
        // Guide 6.7: jede Sekunde, in BEIDE Richtungen. Sofort einmal, dann im Takt.
        if (sende(ECHO_TEXT, F.wofuerEcho)) e.echosGesendet++;
        tEcho = setInterval(function () {
          if (sende(ECHO_TEXT, F.wofuerEcho)) e.echosGesendet++;
        }, 1000);
      }
      if (v.filter !== 'keine') {
        const q = baueAbfrage(v);
        if (!e.abfrageplan.length) e.abfrageplan = abfragePlan(v);
        if (sende(q, F.wofuerAbfrage)) e.abfragenGesendet++;
        if (v.wiederholMs) {
          tAbfrage = setInterval(function () {
            const w = baueAbfrage(v);
            if (sende(w, F.wofuerAbfrage)) e.abfragenGesendet++;
          }, v.wiederholMs);
        }
      }
    });

    s.on('data', function (chunk) {
      puffer = Buffer.concat([puffer, chunk]);
      /* Mehrere Rahmen in einem Paket und halbe Rahmen ueber Paketgrenzen kommen am echten
       * Geraet beide vor. Ohne Pufferung zaehlte die Sonde Rahmen falsch — und eine falsche
       * Zaehlung im Befund waere schlimmer als gar keine. */
      let a;
      while ((a = puffer.indexOf(VT)) !== -1) {
        const b = puffer.indexOf(FS, a + 1);
        if (b === -1) break;
        const nutz = puffer.slice(a + 1, b).toString('latin1');
        puffer = puffer.slice(b + 2);
        verarbeite(nutz);
        if (abgeschlossen) return;
      }
      if (puffer.length > (1 << 20)) puffer = Buffer.alloc(0);
    });

    s.on('error', function (err) {
      if (!e.verbunden) {
        e.verbindungsfehler.push({ art: festerText(F.aufbau), grund: netzGrund(err),
          sekunden: null });
        /* Kein Wiederholen: antwortet auf diesem Port nichts, dann antwortet auch in 20 s
         * nichts. Die Sonde soll bei totem Geraet schnell fertig werden, nicht acht Fenster
         * lang warten. */
        try { s.destroy(); } catch (_) {}
        return schliesse();
      }
      e.verbindungsfehler.push({ art: festerText(F.abbruch), grund: netzGrund(err),
        sekunden: null });
    });

    s.on('close', function () {
      timerWeg();
      if (abgeschlossen || vonUnsBeendet) return;
      if (!e.verbunden) return;              // Fehlerfall ist oben schon behandelt
      e.trennungen++;
      opt.log('Variante ' + v.nr + ' (' + v.kurz + '): das Geraet hat die Verbindung ' +
        'getrennt (' + e.trennungen + '.).');
      if (Date.now() + NEUVERBINDUNG_MS >= ende || e.verbindungen >= MAX_VERBINDUNGEN) {
        return schliesse();
      }
      tNeu = setTimeout(verbinde, NEUVERBINDUNG_MS);
    });
  }

  tFenster = setTimeout(schliesse, opt.fensterMs);
  verbinde();
}

/* netzGrund(err) — der Code, wenn wir ihn kennen; sonst ein fester Sammelbegriff.
 * err.message wird NICHT uebernommen: bei Node steht dort die Zieladresse mit drin. */
function netzGrund(err) {
  const code = err && err.code ? String(err.code) : '';
  return ausListe(code, NETZFEHLER, FEHLER_ANDERER);
}
function dateiGrund(err) {
  const code = err && err.code ? String(err.code) : '';
  return ausListe(code, DATEIFEHLER, FEHLER_ANDERER);
}

/*
 * beurteile(v, e) — das Urteil je Variante.
 *
 * "Laufende Messwerte" heisst: MEHRERE periodische Nachrichten UND keine Trennung durch das
 * Geraet. Ein einzelner Messwert, dem sofort der Abbruch folgt, ist kein Erfolg — genau so
 * sieht es naemlich aus, wenn das Geraet die Abfrage zwar annimmt, uns aber gleich darauf
 * wegen einer anderen Regel hinauswirft (z. B. unser ACK, Guide 6.3.3 Punkt 9). Wer hier nur
 * "Periodik > 0" pruefte, bekaeme den falschen Schuldigen genannt.
 *
 * EIGENE STUFE FUER "NICHT GESENDET" (28.08.2026): sie steht bewusst VOR jeder Aussage ueber
 * Erfolg oder Stille. Eine Abfrage, die nie auf der Leitung war, kann weder beweisen, dass
 * diese Form geht, noch dass sie nicht geht — sie ist keine Messung, sondern ein Ausfall.
 *
 * DER UMBAU AUF DIE DREI TORE HAT AN DIESER LOGIK NICHTS GEAENDERT: sie rechnet mit Zahlen
 * (periodikRahmen, trennungen, abfragenGesendet, rahmen), und Zahlen sind dieselben
 * geblieben. Nur die Urteilssaetze sind jetzt feste Zeichenketten aus dieser Datei.
 */
const STUFE = melde({
  keineVerbindung: 'keine-verbindung',
  nichtGesendet: 'abfrage-nicht-gesendet',
  referenz: 'referenz',
  referenzMitPeriodik: 'referenz-mit-periodik',
  erfolg: 'erfolg',
  abriss: 'abriss',
  stumm: 'stumm',
  nichts: 'nichts',
});
const URTEIL = melde({
  keineVerbindung: 'keine Verbindung zum Geraet',
  nichtGesendet: 'Abfrage konnte nicht gesendet werden — diese Variante wurde NICHT gemessen',
  referenzMitPeriodik: 'Referenz: das Geraet sendet Messwerte SCHON OHNE Abfrage',
  referenz: 'Referenz: ohne Abfrage kommen nur Patientendaten, NIBP und Alarme',
  erfolg: 'laufende Messwerte',
  abriss: 'Messwerte kamen, der Strom riss aber ab',
  stumm: 'keine Messwerte (nur unaufgefordert Gesendetes)',
  nichts: 'gar keine Nachricht',
});

function beurteile(v, e) {
  const laeuft = e.periodikRahmen >= 2 && e.trennungen === 0;
  if (!e.verbunden) {
    e.stufe = festerText(STUFE.keineVerbindung);
    e.urteil = festerText(URTEIL.keineVerbindung);
  } else if (v.filter !== 'keine' && e.abfragenGesendet === 0) {
    e.stufe = festerText(STUFE.nichtGesendet);
    e.urteil = festerText(URTEIL.nichtGesendet);
  } else if (v.filter === 'keine') {
    // Referenzmessung: hier ist "keine Periodik" das ERWARTETE Ergebnis, kein Fehlschlag.
    e.stufe = festerText(e.periodikRahmen > 0 ? STUFE.referenzMitPeriodik : STUFE.referenz);
    e.urteil = festerText(e.periodikRahmen > 0
      ? URTEIL.referenzMitPeriodik : URTEIL.referenz);
  } else if (laeuft) {
    e.stufe = festerText(STUFE.erfolg);
    e.urteil = festerText(URTEIL.erfolg);
  } else if (e.periodikRahmen > 0) {
    e.stufe = festerText(STUFE.abriss);
    e.urteil = festerText(URTEIL.abriss);
  } else if (e.rahmen > 0) {
    e.stufe = festerText(STUFE.stumm);
    e.urteil = festerText(URTEIL.stumm);
  } else {
    e.stufe = festerText(STUFE.nichts);
    e.urteil = festerText(URTEIL.nichts);
  }
}

// ---------------------------------------------------------------------------------------
// GESAMTURTEIL
// ---------------------------------------------------------------------------------------

/* Was hat gefehlt, wenn Variante N die erste erfolgreiche ist? Ein Satz je Variante, in der
 * Sprache eines Menschen, der weder HL7 noch diesen Quelltext kennt. */
const FEHLTE_JE_VARIANTE = {
  1: 'Nichts an der Abfrage. Die Station sendet heute schon das Richtige — dann liegt die ' +
     'Ursache des Ausfalls woanders (Netz, Geraeteeinstellung, anderes Geraet).',
  2: 'Es fehlte nur die feste Kennung MSH-10 = 1203 in der Abfrage.',
  3: 'Es fehlten die feste Kennung MSH-10 = 1203 und das Echo, das jede Sekunde hin und ' +
     'zurueck gehen muss (und die staendige Wiederholung der Abfrage samt Quittung stoerte).',
  4: 'Es fehlte zusaetzlich der gefuellte Zeitstempel MSH-7.',
  5: 'Es fehlte zusaetzlich die Ortszeit in QRD-1 (bisher stand dort UTC, im Sommer zwei ' +
     'Stunden daneben).',
  6: 'Das Geraet liefert nur, wenn ALLE Parameter angefordert werden (SendAll = 1), nicht ' +
     'bei einer Liste einzelner Messgroessen.',
  7: 'Das Geraet liefert nur mit der vollstaendigen Parameterliste, verteilt auf mehrere ' +
     'QRF-Segmente zu je hoechstens vier IDs.',
};

/*
 * U — die Saetze des Gesamturteils, mit {} als Platzhalter fuer geprueften Zahlenstoff.
 *
 * DIE ADRESSE STEHT NICHT MEHR DARIN. Bis heute hiess es "Das Geraet antwortet nicht auf
 * 192.168.0.50:4601"; die Adresse faellt unter keine der drei Quellen. Der Port bleibt (reine
 * Ziffernfolge), denn ohne ihn liesse sich "falscher Port" nicht beurteilen. Welche Adresse
 * abgefragt wurde, weiss der Tierarzt — er hat sie eingegeben, und sie stand beim Start auf
 * dem Bildschirm.
 */
const U = {
  leer: 'Es wurde keine einzige Variante gefahren — dieser Lauf enthaelt keine Messung.',
  keineVerbindung: 'Das Geraet antwortet auf Port {} der angegebenen Adresse nicht — es kam ' +
    'ueberhaupt keine Verbindung zustande.',
  kabel: 'Steckt das Netzwerkkabel am Monitor, und leuchtet die Buchse?',
  ipPruefen: 'Stimmt die IP-Adresse? Am Geraet unter Netzwerk nachsehen und die Sonde mit ' +
    'dieser Adresse noch einmal starten: --host <IP>',
  ausgabeAn: 'Ist am Geraet die Datenausgabe (HL7 / Patient Data Share) eingeschaltet und ' +
    'Port 4601 freigegeben?',
  firewall: 'Blockiert die Windows-Firewall des Praxis-PCs die Verbindung?',
  referenz: 'Das Geraet schickt laufende Messwerte AUCH OHNE jede Abfrage (Variante 8). ' +
    'Dann liegt der Fehler nicht an der Abfrage, sondern daran, dass die Station diese ' +
    'Nachrichten nicht auswertet.',
  referenzTun: 'Diesen Befund an den Entwickler schicken — die Auswertung in der Station ' +
    'muss geaendert werden, nicht die Abfrage.',
  ausfall: 'Bei Variante {} ist die Abfrage gar nicht erst hinausgegangen (die Verbindung ' +
    'war beim Schreiben schon weg). Diese Varianten sind NICHT gemessen worden und sagen ' +
    'ueber die Abfrage nichts — weder dafuer noch dagegen. Fuer ein vollstaendiges Bild den ' +
    'Lauf wiederholen.',
  nurReferenz: 'Gefahren wurde nur die Referenzmessung (Variante 8), und die sendet ' +
    'absichtlich KEINE Abfrage. Dass keine laufenden Messwerte kamen, ist deshalb das ' +
    'erwartete Ergebnis und kein Befund: ueber die Form der Abfrage sagt dieser Lauf NICHTS.',
  nurReferenzTun: 'Fuer einen brauchbaren Befund die Sonde ohne "--nur" starten, dann laufen ' +
    'alle acht Varianten nacheinander.',
  nichtsGesendet: 'KEINE der Abfragen ist ueberhaupt auf die Leitung gekommen: die ' +
    'Verbindung stand zwar, war beim Absenden aber schon wieder weg. Damit ist dieser Lauf ' +
    'KEINE Messung der Abfrage — ueber ihre Form sagt er weder etwas dafuer noch dagegen.',
  nichtsGesendetTun1: 'Die Sonde noch einmal starten; bleibt es dabei, trennt das Geraet ' +
    'unmittelbar nach dem Verbindungsaufbau.',
  /* RICHTIGGESTELLT AM 28.08.2026: hier stand "der Monitor laesst am Realtime-Port nur eine
   * abfragende Gegenstelle zu" — als Tatsache. Im Programmer's Guide steht dieser Satz
   * NICHT (Kapitel 6 sagt zur Zahl gleichzeitiger Gegenstellen nichts; die einzige
   * Obergrenze im Dokument, §2.1.1, gilt der ANDEREN Schnittstelle). Belegt ist allein eine
   * eigene Beobachtung. Dieselbe Richtigstellung steht in bridge/src/adapters/hl7.js und in
   * docs/MINDRAY-PDS-SONDE.md. */
  nichtsGesendetTun2: 'Am Geraet nachsehen, ob eine ANDERE Verbindung die Schnittstelle ' +
    'belegt (die Station selbst, ein zweiter PC, ein Gateway). Am 26.07.2026 wurde an ' +
    'diesem Geraet beobachtet, dass eine zweite abfragende Verbindung abgewiesen wurde, ' +
    'waehrend die Station eine hielt — eine eigene Beobachtung, keine Herstellerangabe; der ' +
    'Programmer\'s Guide sagt zur Zahl gleichzeitiger Gegenstellen am Realtime-Port nichts.',
  anEntwickler: 'Diesen Befund an den Entwickler schicken.',
  stille: 'Die Verbindung kam zustande und die Abfragen gingen hinaus — aber das Geraet hat ' +
    'in KEINER Variante auch nur eine einzige Nachricht geschickt. Das spricht NICHT gegen ' +
    'die Form der Abfrage: laut Guide 6.3.3 sendet ein PDS-Geraet gleich nach dem ' +
    'Verbindungsaufbau ungefragt die Patientendaten (Punkt 1) und danach jede Sekunde die ' +
    'Alarme (Punkt 2); eine verworfene Abfrage kostet nur Punkt 3, die laufenden Messwerte. ' +
    'Voellige Stille heisst deshalb: auf Port {} der angegebenen Adresse nimmt zwar etwas ' +
    'die Verbindung an, aber es spricht dort kein PDS-Geraet.',
  stilleTun1: 'Ist es wirklich der Monitor? Ein Drucker, ein Router oder ein anderer Dienst ' +
    'nimmt eine TCP-Verbindung ebenso an und schweigt dann. Die IP am Geraet im ' +
    'Netzwerk-Menue ablesen und die Sonde damit noch einmal starten.',
  stilleTun2: 'Stimmt der Port? Am Bett ist die Realtime-Schnittstelle 4601. Andere Ports ' +
    'des Geraets sprechen ein anderes Protokoll.',
  stilleTun3: 'Am Geraet pruefen, ob die HL7-Ausgabe (Patient Data Share) ueberhaupt ' +
    'eingeschaltet und freigeschaltet ist — bei der N-Serie ist sie lizenzpflichtig.',
  stilleTun4: 'Haengt ein Gateway oder eine Zentrale dazwischen, gilt ein anderes Kapitel ' +
    'des Herstellerhandbuchs; das muss der Entwickler wissen.',
  verworfen: 'KEINE der gemessenen Abfragen brachte laufende Messwerte. Das Geraet schickt ' +
    'aber von sich aus Nachrichten (Patientendaten, Alarme, Einzelmessungen) — genau so ' +
    'sieht es nach Guide 6.3.3 aus, wenn die Abfrage verworfen wird: sie kostet NUR die ' +
    'laufenden Messwerte, alles Uebrige laeuft weiter. Die Ursache liegt damit sehr wohl im ' +
    'Umfeld der Abfrage, nur in keiner der acht gefahrenen Formen.',
  abriss: 'Bei Variante {} kamen Messwerte, dann trennte das Geraet die Verbindung. Das ' +
    'spricht fuer eine zweite Regel, an der wir scheitern — nicht fuer eine falsche Abfrage.',
  mitFehler: 'Das Geraet hat Fehlersegmente (MSA/ERR/QAK) geschickt — sie stehen weiter oben ' +
    'mit ihren Codes und sagen dem Entwickler, was es beanstandet.',
  ohneFehler: 'Auf die Abfragen selbst kam keine Antwort, auch keine Fehlermeldung. Das ist ' +
    'kein Widerspruch: der Guide sagt unter 6.3.3 ausdruecklich, auf eine falsch geformte ' +
    'Abfrage werde gar keine ACK/NACK zurueckgeschickt.',
  freischalten: 'Am Geraet pruefen, ob die Ausgabe der laufenden Messwerte ueberhaupt ' +
    'freigeschaltet ist (der uMEC12 zeigt HL7 nicht in jedem Menue).',
  abVariante: 'Ab Variante {} ({}) kamen laufende Messwerte. ',
  v5NichtGemessen: 'Zu Variante 5 sagt dieser Lauf nichts — ihre Abfrage ist nicht auf die ' +
    'Leitung gekommen. Sie unterscheidet sich vom Schalter "pdsStrict": true nur durch den ' +
    'gefuellten MSH-7. Bitte die Sonde noch einmal starten, bevor am Schalter etwas ' +
    'geaendert wird.',
  v5Laeuft: 'In bridge/config/devices.json beim Eintrag des Monitors (umec12) "pdsStrict": ' +
    'true setzen. Am Schluessel "ack" ist nichts zu tun: im strikten Modus quittiert die ' +
    'Station ohnehin nie (Guide 6.3.3 Punkt 9), und wenn dort noch true steht, sagt sie das ' +
    'beim Start in einer Zeile.',
  v5LaeuftDanach: 'Danach die Station neu starten und im Cockpit nachsehen, ob Herzfrequenz ' +
    'und SpO2 laufen.',
  v5LiefNicht: 'Variante 5 lief NICHT, wohl aber Variante {}. Der Schalter "pdsStrict": true ' +
    'sendet MSH-7 leer und ist damit naeher an Variante 3 als an 5 — ob er hier genuegt, ' +
    'sagt der naechste Hinweis.',
  nur3: 'Variante 3 lief, Variante 4 nicht: MSH-7 muss LEER bleiben — genau das tut ' +
    '"pdsStrict": true seit dem 28.08.2026. Der Schalter kann also gesetzt werden; am Code ' +
    'ist nichts zu aendern. Unterschied zu Variante 3 bleibt nur die Ortszeit in QRD-1, und ' +
    'zur Zeitzone sagt der Guide nichts.',
  nur4: 'Variante 4 lief, Variante 5 nicht: dann gehoert in QRD-1 die UTC-Zeit und nicht die ' +
    'Ortszeit.',
  filterAendern: 'Der Schalter "pdsStrict": true allein genuegt NICHT — zusaetzlich muss der ' +
    'QRF-Filter geaendert werden (Variante {}). Das gehoert in bridge/src/adapters/hl7.js, ' +
    '_sendQueryStrikt.',
  alles: 'Diesen Befund an den Entwickler schicken; er enthaelt alles Gemessene.',
  spaeter: 'Spaetere Varianten ({}) lieferten NICHT mehr — dort ist also eine Aenderung ' +
    'dabei, die das Geraet stoert.',
  komma: ', ',
  keine: 'keine',
};

/* nummernListe([3,5]) -> "3, 5". Jede Zahl einzeln durch Tor 1, das Komma ist fester Text. */
function nummernListe(zahlen) {
  if (!zahlen || !zahlen.length) return festerText(U.keine);
  const teile = [];
  for (let i = 0; i < zahlen.length; i++) {
    if (i) teile.push(U.komma);
    teile.push(zahl(zahlen[i]));
  }
  return satz.apply(null, teile);
}

/*
 * gesamturteil(ergebnisse, opt) — was der ganze Lauf zusammen sagt, und was er NICHT sagt.
 *
 * DIE DREI FEHLURTEILE, DIE HIER AM 28.08.2026 BEHOBEN WURDEN, hatten alle dieselbe Form: ein
 * Satz ueber etwas, das gar nicht gemessen worden war.
 *
 *  1. Varianten, deren Abfrage nie auf die Leitung kam, gingen als "stumm" in den Schluss
 *     "Die Ursache steckt damit nicht in der Form der Abfrage" ein. Ein Ausschluss aus einer
 *     ausgefallenen Messung ist schlimmer als kein Ausschluss: der Entwickler sucht danach
 *     an der falschen Stelle weiter.
 *  2. Voellige Stille wurde als "verworfene Abfrage" gedeutet. Guide 6.3.3 sagt das Gegenteil:
 *     nach dem Verbindungsaufbau kommen ungefragt Patientendaten (Punkt 1) und jede Sekunde
 *     die Alarme (Punkt 2); eine verworfene Abfrage kostet NUR Punkt 3. Wer gar nichts hoert,
 *     hat kein Abfrageproblem, sondern spricht mit dem falschen Gegenueber.
 *  3. Mit "--nur 8" (der Variante, die per Definition keine Abfrage sendet) stand derselbe
 *     Ausschlusssatz im Bericht, obwohl in diesem Lauf ueberhaupt keine Abfrage vorkam.
 *
 * Regel daraus: ueber die FORM der Abfrage darf nur reden, wer mindestens eine abfragende
 * Variante gefahren UND ihre Abfrage nachweislich abgeschickt hat.
 *
 * AN DIESER LOGIK HAT DER UMBAU VOM 28.08.2026 NICHTS GEAENDERT. Die Verzweigungen rechnen
 * mit denselben Zahlen wie vorher; nur die Saetze kommen jetzt aus U und werden mit fuege()
 * zusammengesetzt, damit auch das Urteil ausschliesslich aus unserem Quelltext besteht.
 */
function gesamturteil(ergebnisse, opt) {
  const u = { satz: '', handlung: [], hinweise: [] };
  const gefahren = (ergebnisse || []).filter(function (e) { return e; });
  const verbunden = gefahren.filter(function (e) { return e.verbunden; });
  const o = opt || {};
  const port = ziffernkennung(String(o.port === undefined ? '' : o.port));

  if (!gefahren.length) {
    /* Kann nur eintreten, wenn jemand gesamturteil() von aussen mit leerer Liste aufruft:
     * laufe() laesst einen Lauf ohne Varianten gar nicht erst zu (siehe dort). */
    u.satz = festerText(U.leer);
    return u;
  }

  if (!verbunden.length) {
    u.satz = fuege(U.keineVerbindung, [port]);
    u.handlung.push(festerText(U.kabel));
    u.handlung.push(festerText(U.ipPruefen));
    u.handlung.push(festerText(U.ausgabeAn));
    u.handlung.push(festerText(U.firewall));
    return u;
  }

  const referenz = gefahren.filter(function (e) { return e.stufe === STUFE.referenzMitPeriodik; });
  if (referenz.length) {
    u.satz = festerText(U.referenz);
    u.handlung.push(festerText(U.referenzTun));
    return u;
  }

  /* Die drei Mengen, auf denen ab hier ALLES beruht — auseinandergehalten, weil sie
   * verschieden viel beweisen:
   *   abfragend    = Varianten, die eine Abfrage senden SOLLTEN (Variante 8 gehoert nie dazu)
   *   abgefragt    = davon die, deren Abfrage nachweislich hinausging  -> nur die messen etwas
   *   nichtGesendet = davon die, bei denen sie es nicht tat            -> die messen NICHTS */
  const abfragend = gefahren.filter(function (e) { return e.filter !== 'keine'; });
  const abgefragt = abfragend.filter(function (e) {
    return e.verbunden && e.abfragenGesendet > 0;
  });
  const nichtGesendet = abfragend.filter(function (e) {
    return e.stufe === STUFE.nichtGesendet;
  });
  function ausfallHinweis() {
    if (!nichtGesendet.length) return;
    u.hinweise.push(fuege(U.ausfall,
      [nummernListe(nichtGesendet.map(function (e) { return e.nr; }))]));
  }

  const erfolge = abgefragt.filter(function (e) { return e.stufe === STUFE.erfolg; });
  if (!erfolge.length) {
    const abriss = abgefragt.filter(function (e) { return e.stufe === STUFE.abriss; });

    /* Befund E: mit "--nur 8" wurde gar keine Abfrage gefahren. Ueber die Form der Abfrage
     * darf dieser Lauf dann kein Wort sagen. */
    if (!abfragend.length) {
      u.satz = festerText(U.nurReferenz);
      u.handlung.push(festerText(U.nurReferenzTun));
      return u;
    }

    /* Befund B16: keine einzige Abfrage kam auf die Leitung. Dann ist NICHTS ueber die
     * Abfrage bekannt — auch nicht, dass sie in Ordnung waere. */
    if (!abgefragt.length) {
      u.satz = festerText(U.nichtsGesendet);
      u.handlung.push(festerText(U.nichtsGesendetTun1));
      u.handlung.push(festerText(U.nichtsGesendetTun2));
      u.handlung.push(festerText(U.anEntwickler));
      ausfallHinweis();
      return u;
    }

    /* Befund B17: "stumm" (nur Unaufgefordertes) und "nichts" (gar keine Nachricht) sind
     * zwei voellig verschiedene Befunde und brauchen zwei verschiedene Raete. */
    const gesprochen = abgefragt.filter(function (e) { return e.rahmen > 0; });
    if (!gesprochen.length) {
      u.satz = fuege(U.stille, [port]);
      u.handlung.push(festerText(U.stilleTun1));
      u.handlung.push(festerText(U.stilleTun2));
      u.handlung.push(festerText(U.stilleTun3));
      u.handlung.push(festerText(U.stilleTun4));
      u.handlung.push(festerText(U.anEntwickler));
      ausfallHinweis();
      return u;
    }

    u.satz = festerText(U.verworfen);
    if (abriss.length) {
      u.hinweise.push(fuege(U.abriss, [nummernListe(abriss.map(function (e) { return e.nr; }))]));
    }
    const mitFehler = abgefragt.filter(function (e) { return e.fehlerSegmente.length; });
    u.hinweise.push(festerText(mitFehler.length ? U.mitFehler : U.ohneFehler));
    u.handlung.push(festerText(U.anEntwickler));
    u.handlung.push(festerText(U.freischalten));
    ausfallHinweis();
    return u;
  }

  const erste = erfolge[0];
  u.satz = satz(fuege(U.abVariante, [zahl(erste.nr), festerText(erste.kurz)]),
    festerText(FEHLTE_JE_VARIANTE[erste.nr]));

  /*
   * Die Handlungsempfehlung haengt an den Varianten 3 UND 5 (nachgezogen 28.08.2026).
   *
   * Bis heute stand hier "Variante 5 und nur sie ist das, was der Schalter sendet". Das
   * stimmt nicht mehr: "pdsStrict": true legt MSH-7 seit dem 28.08.2026 LEER auf die
   * Leitung (Guide 6.4.1.1 fuehrt das Feld gar nicht als benutzt). Der Schalter faehrt damit
   * Variante 3 mit der Ortszeit aus Variante 5 — eine Mischung, die als eigene Variante
   * bewusst nicht gefahren wird (siehe Kommentar bei Variante 5).
   * Fuer die Empfehlung heisst das: laeuft 5, laeuft der Schalter erst recht, denn er
   * verlangt vom Geraet WENIGER (ein Feld weniger). Laeuft NUR 3, ist der Schalter trotzdem
   * die richtige Wahl — er unterscheidet sich von 3 dann nur noch in der Zeitzone von QRD-1,
   * und die nennt der Guide an keiner Stelle.
   */
  const v5 = gefahren.filter(function (e) { return e.nr === 5; })[0];
  const v5laeuft = v5 && v5.stufe === STUFE.erfolg;
  const v5gemessen = v5 && v5.verbunden && v5.stufe !== STUFE.nichtGesendet;
  if (v5 && !v5gemessen) {
    /* Ohne gemessene Variante 5 darf hier weder "der Schalter genuegt" noch "der Schalter
     * genuegt nicht" stehen. Beides waere eine Aussage ueber eine ausgefallene Messung. */
    u.handlung.push(festerText(U.v5NichtGemessen));
  } else if (v5laeuft) {
    u.handlung.push(festerText(U.v5Laeuft));
    u.handlung.push(festerText(U.v5LaeuftDanach));
  } else if (erste.nr <= 5) {
    u.handlung.push(fuege(U.v5LiefNicht, [zahl(erste.nr)]));
    if (erste.nr === 3) u.handlung.push(festerText(U.nur3));
    if (erste.nr === 4) u.hinweise.push(festerText(U.nur4));
  } else {
    u.handlung.push(fuege(U.filterAendern, [zahl(erste.nr)]));
  }
  u.handlung.push(festerText(U.alles));

  /* Nur GEMESSENE spaetere Varianten zaehlen hier: eine, deren Abfrage nie hinausging, hat
   * nichts "nicht mehr geliefert" — sie hat gar nicht gefragt. */
  const spaeter = abgefragt.filter(function (e) {
    return e.nr > erste.nr && e.stufe !== STUFE.erfolg;
  });
  if (spaeter.length) {
    u.hinweise.push(fuege(U.spaeter, [nummernListe(spaeter.map(function (e) { return e.nr; }))]));
  }
  ausfallHinweis();
  return u;
}

// ---------------------------------------------------------------------------------------
// BERICHT
// ---------------------------------------------------------------------------------------

function fuelle(s, n) {
  s = String(s);
  return s.length >= n ? s.slice(0, n) : s + ' '.repeat(n - s.length);
}
function rechts(s, n) {
  s = String(s);
  return s.length >= n ? s : ' '.repeat(n - s.length) + s;
}

const KURZURTEIL = {
  'erfolg': 'MESSWERTE', 'abriss': 'abgerissen', 'stumm': 'stumm', 'nichts': 'nichts',
  'keine-verbindung': 'keine Verb.', 'referenz': 'Referenz', 'referenz-mit-periodik': 'Referenz!',
  'abfrage-nicht-gesendet': 'NICHT GEMESSEN',
};

/* Fester Text, der NUR im .txt-Bericht vorkommt. Er wird nicht in die Struktur geschrieben,
 * sondern beim Ausdrucken danebengestellt — deshalb steht er hier und nicht in U. */
const B = melde({
  ja: 'ja', nein: 'nein', keine: 'keine', strich: '—',
});

/* Die Zusage im Bericht. SIE BEHAUPTET NICHT MEHR, ETWAS SEI ENTFERNT WORDEN.
 *
 * Beim letzten Mal stand hier "Patientenname, Kennung und Aktennummer sind entfernt" — und
 * die Aktennummer stand acht Zeilen weiter unten im Klartext. Eine Zusage ueber einen
 * Vorgang ("es wurde gefiltert") ist nur so gut wie der Vorgang. Diese Zusage sagt statt
 * dessen, WORAUS der Bericht besteht: das laesst sich am Bericht selbst nachpruefen, ohne
 * den Quelltext zu kennen. */
const ZUSAGE = [
  'Dieser Bericht enthaelt KEIN EINZIGES TEXTFELD DES GERAETS. Er ist kein gekuerzter,',
  'gefilterter oder maskierter Mitschnitt — er ist eine Beschreibung. Alles, was hier',
  'steht, stammt aus genau drei Quellen:',
  '',
  '  1. Zahlen, die die Sonde selbst gezaehlt oder gemessen hat: Nachrichten, Rahmen,',
  '     Millisekunden, Trennungen, Anzahlen, Feldnummern.',
  '  2. Kennziffern aus reinen Ziffern (hoechstens sechs Stellen), die gegen genau dieses',
  '     Muster geprueft wurden: Parameternummern wie 101, Alarmnummern, Fehlercodes.',
  '  3. Fester Text aus dem Quelltext der Sonde. Dazu gehoeren auch die Namen, die die',
  '     Sonde gegen ihre EIGENEN Listen abgleicht: Segmentnamen (PID, OBX, ...),',
  '     Werttypen (NM, CE, ST) und Antwortcodes (AA, AE, AR). Ein Wert, der nicht',
  '     woertlich in einer dieser Listen steht, kommt nicht in den Bericht.',
  '',
  'Empfangene Nachrichten werden deshalb nicht abgedruckt, sondern nur als BAUPLAN',
  'beschrieben: welches Segment kam, wie viele Felder es hatte und welche davon gefuellt',
  'waren. Was IN den Feldern stand, wird nicht uebernommen — auch nicht in Teilen.',
  '',
  'Es steht hier also nicht: Patientenname, Patientenkennung, Aktennummer, Geburtsdatum,',
  'Geschlecht, Anschrift, Name des Tierarztes, Station, Bett, Alarmtext, Geraetetext.',
  'Ebenfalls nicht: die abgefragte IP-Adresse und die Pfade der Berichtsdateien; beides',
  'stand beim Start auf dem Bildschirm.',
  'Der einzige Wert vom Geraet, der als ZAHL uebernommen wird, ist der Messwert selbst',
  '(z. B. HF 88) — eine Zahl benennt niemanden.',
  '',
  'Fuer die Datei in Maschinenform daneben gilt WORTGLEICH dasselbe: beide entstehen aus',
  'derselben einen Struktur. Es gibt keine zweite, laxere Ausgabe.',
];

const KOPF = melde({
  hinweisSicherheit: 'Diese Sonde hat NUR gelesen: gesendet wurden ausschliesslich ' +
    'QRY^R02-Abfragen, das TCP-Echo (Guide 6.7) und in den Varianten 1 und 2 das HL7-ACK, ' +
    'das die Station heute ohnehin sendet. Keine Steuernachricht, kein Schreibzugriff, ' +
    'keine Aenderung an devices.json oder am Geraet.',
  hinweisDatenschutz: 'Dieser Befund enthaelt kein Textfeld des Geraets. Alles darin ist ' +
    'entweder eine von der Sonde gezaehlte oder gemessene Zahl, eine gegen /^[0-9]{1,6}$/ ' +
    'gepruefte Kennziffer oder fester Text aus dem Quelltext der Sonde (einschliesslich der ' +
    'Namen, die gegen ihre eigenen Listen abgeglichen werden: Segmentnamen, Werttypen, ' +
    'Antwortcodes). Empfangene Nachrichten stehen nur als Bauplan darin — Segment, ' +
    'Feldanzahl, gefuellte Feldnummern —, nicht mit ihrem Inhalt.',
  werkzeug: 'tools/pds-feldsonde.js',
  stand: '28.08.2026',
  dateiVorlage: 'pds-befund-{}{}{}-{}{}{}.{}',
  endungTxt: 'txt',
  endungJson: 'json',
  zeitLesbar: '{}.{}.{}, {}:{} Uhr',
  zeitMaschine: '{}-{}-{}T{}:{}:{}',
});

/* absatz() haengt eine beschriftete, umgebrochene Angabe an den Bericht. Ohne Umbruch stehen
 * dort Zeilen mit ueber 300 Zeichen (die Liste aller Messwert-Codes) — im Editor des
 * Praxis-PCs ist das eine einzige unlesbare Wurst, und was niemand liest, wird nicht gemeldet. */
function absatz(L, einzug, beschriftung, text, breite) {
  const zeilen = umbruch(text, breite);
  const leer = ' '.repeat(beschriftung.length);
  zeilen.forEach(function (z, i) { L.push(einzug + (i === 0 ? beschriftung : leer) + z); });
}

function messwertZeile(liste) {
  if (!liste || !liste.length) return B.keine;
  return liste.map(function (m) {
    return m.kennziffer + (m.name ? '/' + m.name : '') + ' x' + m.anzahl +
      (m.letzter === null ? '' : ' (zuletzt ' + m.letzter + ')');
  }).join(', ');
}

function mehrzahl(n, eins, viele) { return n + ' ' + (n === 1 ? eins : viele); }

/* planZeile() — eine Zeile des Bauplans. Sie entsteht ERST HIER, aus Werten, die in der
 * Struktur schon geprueft liegen; die Struktur selbst enthaelt die Einzelteile. Damit sagen
 * .txt und .json dasselbe, und es gibt keine zweite Stelle, an der etwas hineingeraten
 * koennte. */
function planZeile(p) {
  let z = fuelle(p.name, 22) + rechts(p.felder === null ? '?' : p.felder, 3) + ' Felder';
  z += ', gefuellt: ' + (p.gefuellt && p.gefuellt.length ? p.gefuellt.join(',') : '-');
  if (p.typ) z += '   (Typ ' + p.typ + (p.kennziffer ? ', Kennziffer ' + p.kennziffer : '') + ')';
  else if (p.kennziffer) z += '   (Kennziffer ' + p.kennziffer + ')';
  if (p.codes && p.codes.length) {
    z += '   Codes: ' + p.codes.map(function (c) {
      return p.name + '-' + c.feld + '=' + c.wert;
    }).join(', ');
  }
  return z;
}

function baueText(befund) {
  const L = [];
  const o = befund.aufruf;
  L.push('=======================================================================');
  L.push(' VetStation — Befund der PDS-Feldsonde');
  L.push(' ' + befund.zeitLesbar);
  L.push('=======================================================================');
  L.push('');
  L.push('Port:              ' + o.port + '   (welche Adresse abgefragt wurde, steht');
  L.push('                   absichtlich nicht im Bericht — siehe DATENSCHUTZ)');
  L.push('Zeitfenster:       ' + o.fensterSekunden + ' s je Variante');
  L.push('Gefahren:          Variante ' + befund.ergebnisse.map(function (e) { return e.nr; }).join(', '));
  L.push('Gesamtdauer:       ' + Math.round(befund.dauerMs / 1000) + ' s');
  L.push('Sonde:             ' + befund.werkzeug + ', Stand ' + befund.stand);
  L.push('');
  /* Der Zustand der Station gehoert IN DEN KOPF, nicht nur auf den Bildschirm des Tierarztes:
   * gelesen wird dieser Bericht spaeter und woanders. Lief die Station mit, sind alle Zahlen
   * darunter unter Vorbehalt zu lesen. */
  if (befund.station && befund.station.geprueft) {
    if (befund.station.laeuft) {
      L.push('!! ACHTUNG: die VetStation LIEF WAEHREND DIESER MESSUNG (Port ' +
        befund.station.port + ').');
      L.push('   Der Lauf wurde mit "--trotzdem" erzwungen. Am 26.07.2026 wurde an diesem');
      L.push('   Geraet beobachtet, dass eine zweite abfragende Verbindung abgewiesen wurde,');
      L.push('   waehrend die Station eine hielt (eigene Beobachtung, keine Herstellerangabe;');
      L.push('   der Programmer\'s Guide sagt zur Zahl gleichzeitiger Gegenstellen am');
      L.push('   Realtime-Port nichts). Eine stumme Variante kann daher auch bedeuten, dass');
      L.push('   die Station den Platz belegt hielt, und nicht, dass die Abfrage falsch war.');
      L.push('   Im Zweifel bei GESTOPPTER Station wiederholen.');
      if (befund.station.aktive) {
        L.push('   Zum Zeitpunkt des Starts meldete die Station ' + befund.station.aktive +
          ' Geraet(e) mit anliegenden Werten.');
      }
      L.push('');
    } else {
      L.push('Station:           lief waehrend der Messung NICHT (auf Port ' +
        befund.station.port + ' antwortete nichts) — die Sonde hatte das Geraet allein.');
      L.push('');
    }
  }
  L.push('WORUM ES GEHT');
  L.push('  Am Monitor kommen Patientendaten, Blutdruck und Alarme an, die laufenden');
  L.push('  Messwerte (Herzfrequenz, SpO2, Temperatur, CO2) aber nicht. Diese Sonde hat das');
  L.push('  Geraet achtmal hintereinander gefragt und dabei jedes Mal genau ein Stueck der');
  L.push('  Frage veraendert. Die erste Variante, bei der Messwerte kommen, zeigt, welches');
  L.push('  Stueck gefehlt hat.');
  L.push('');
  L.push('SICHERHEIT — WAS DIESE SONDE GETAN HAT');
  L.push('  Sie hat NUR GELESEN. Gesendet wurden ausschliesslich Abfragen (QRY^R02), das');
  L.push('  vorgeschriebene Echo und in den ersten beiden Varianten die Quittung, die die');
  L.push('  Station ohnehin schickt. Am Geraet wurde NICHTS eingestellt und NICHTS');
  L.push('  geschrieben; an der Station wurde keine Datei veraendert (auch devices.json');
  L.push('  nicht).');
  L.push('');
  L.push('DATENSCHUTZ — WORAUS DIESER BERICHT BESTEHT');
  befund.zusage.forEach(function (z) { L.push(z ? '  ' + z : ''); });
  L.push('');
  L.push('DIE GEFAHRENEN VARIANTEN');
  befund.varianten.forEach(function (v) {
    absatz(L, '  ', v.nr + ' ' + fuelle(v.kurz, 14), v.was, 78);
  });
  L.push('');
  L.push('ERGEBNIS JE VARIANTE');
  L.push('  Nr Variante      Nachr. Messw. Blutdr. Alarme Echos Trenn. ms bis 1. Messw. Urteil');
  L.push('  -- ------------- ------ ------ ------- ------ ----- ------ ----------------- -----------');
  befund.ergebnisse.forEach(function (e) {
    L.push('  ' + rechts(e.nr, 2) + ' ' + fuelle(e.kurz, 13) + ' ' +
      rechts(e.rahmen, 6) + ' ' + rechts(e.periodikRahmen, 6) + ' ' +
      rechts(e.aperiodischeRahmen, 7) + ' ' + rechts(e.alarmAnzahl, 6) + ' ' +
      rechts(e.echos, 5) + ' ' + rechts(e.trennungen, 6) + ' ' +
      rechts(e.msBisErstePeriodik === null ? B.strich : e.msBisErstePeriodik, 17) + ' ' +
      (KURZURTEIL[e.stufe] || e.stufe));
  });
  L.push('');
  L.push('  Spalten: "Nachr." = alle empfangenen Nachrichten, "Messw." = laufende Messwerte');
  L.push('  (das Fehlende), "Blutdr." = Blutdruck und andere Einzelmessungen, die das Geraet');
  L.push('  von sich aus schickt. Die letzten beiden Spalten kommen auch ohne Abfrage an —');
  L.push('  daran erkennt man den Ausfall gerade NICHT.');
  L.push('');
  L.push('EINZELHEITEN JE VARIANTE');
  befund.ergebnisse.forEach(function (e) {
    L.push('');
    L.push('  ---- Variante ' + e.nr + ': ' + e.kurz + ' ' + '-'.repeat(
      Math.max(4, 52 - String(e.kurz).length)));
    absatz(L, '    ', '', e.was, 82);
    absatz(L, '    ', 'Urteil:             ', e.urteil, 60);
    L.push('    Verbindungen:       ' + mehrzahl(e.verbindungen, 'Verbindung', 'Verbindungen') +
      ', davon vom Geraet getrennt: ' + e.trennungen);
    L.push('    Gesendet:           ' + mehrzahl(e.abfragenGesendet, 'Abfrage', 'Abfragen') +
      ', ' + e.echosGesendet + ' Echos, ' + e.acksGesendet + ' Quittungen');
    if (e.sendefehler && e.sendefehler.length) {
      /* Ein verschluckter Schreibfehler war die Ursache dafuer, dass ein Ausfall wie ein
       * Messergebnis aussah. Er steht deshalb da, nicht als Randnotiz. */
      L.push('    NICHT hinausgekommen (' + e.sendefehler.length + '):');
      e.sendefehler.forEach(function (s) { L.push('      ' + s.wofuer + ': ' + s.grund); });
    }
    L.push('    Empfangen:          ' + e.rahmen + ' Nachrichten (' + e.echos + ' Echos, ' +
      e.patientRahmen + ' mit Patientendaten)');
    absatz(L, '    ', 'Laufende Messwerte: ', messwertZeile(e.messwerte), 58);
    absatz(L, '    ', 'Einzelmessungen:    ', messwertZeile(e.messwerteAperiodisch), 58);
    if (e.messwerteOhneKennziffer) {
      L.push('    Messwerte ohne auswertbare Kennziffer: ' + e.messwerteOhneKennziffer);
    }
    /* Nur Anzahl und Katalognummer, nie der Meldetext (Guide 2.2.7.4: der Text ist frei und
     * sprachabhaengig — er ist der Ort, an dem ein Name in den Bericht rutschen wuerde). */
    L.push('    Alarm-/Codezeilen:  ' + e.alarmAnzahl + ' insgesamt' +
      (e.alarmKennungen.length ? ', Katalognummern: ' + e.alarmKennungen.join(', ') : ''));
    if (e.alarmeOhneKennung) {
      L.push('    Alarm ohne auswertbare Kennziffer: ' + e.alarmeOhneKennung);
    }
    L.push('    Patientenname kam:  ' + (e.nameGesehen
      ? B.ja + ' (er steht nirgends in diesem Bericht)' : B.nein));
    if (e.msBisErsteNachricht !== null) {
      L.push('    Erste Nachricht:    nach ' + e.msBisErsteNachricht + ' ms');
    }
    if (e.msBisErstePeriodik !== null) {
      L.push('    Erster Messwert:    nach ' + e.msBisErstePeriodik + ' ms');
    }
    if (e.fehlerSegmente.length) {
      L.push('    Fehlermeldungen des Geraets (WICHTIG - Aufbau und Codes, kein Text):');
      e.fehlerSegmente.forEach(function (p) { L.push('      ' + planZeile(p)); });
    }
    if (e.verbindungsfehler.length) {
      L.push('    Verbindungsprobleme:');
      e.verbindungsfehler.forEach(function (f) {
        L.push('      ' + f.art + (f.grund ? ' (' + f.grund + ')' : '') +
          (f.sekunden === null ? '' : ' nach ' + f.sekunden + ' s'));
      });
    }
    if (e.abfrageplan.length) {
      L.push('    Gesendete Abfrage (Aufbau; <...> sind veraenderliche Stuecke):');
      e.abfrageplan.forEach(function (s) { L.push('      ' + s); });
    }
    if (e.bauplaene.length) {
      L.push('    Bauplan der empfangenen Nachrichten (Inhalte sind NICHT uebernommen):');
      e.bauplaene.forEach(function (b, i) {
        L.push('      [' + (i + 1) + '] Nachrichtentyp ' + b.typ +
          (b.ctrl ? ', Control-ID ' + b.ctrl : ''));
        b.segmente.forEach(function (p) { L.push('          ' + planZeile(p)); });
      });
    }
  });
  L.push('');
  L.push('=======================================================================');
  L.push(' GESAMTURTEIL');
  L.push('=======================================================================');
  L.push('');
  umbruch(befund.urteil.satz, 68).forEach(function (z) { L.push('  ' + z); });
  if (befund.urteil.hinweise.length) {
    L.push('');
    befund.urteil.hinweise.forEach(function (h) {
      umbruch(h, 66).forEach(function (z, i) { L.push('  ' + (i === 0 ? '- ' : '  ') + z); });
    });
  }
  if (befund.urteil.handlung.length) {
    L.push('');
    L.push('  WAS JETZT ZU TUN IST');
    befund.urteil.handlung.forEach(function (h, i) {
      umbruch(h, 64).forEach(function (z, k) {
        L.push('    ' + (k === 0 ? (i + 1) + '. ' : '   ') + z);
      });
    });
  }
  L.push('');
  /* Der Riegel meldet sich selbst. Steht hier etwas anderes als 0, hat jemand ein Feld
   * ergaenzt, ohne sich fuer eines der drei Tore zu entscheiden — dann fehlt an dieser
   * Stelle ein Wert, und man sieht es, statt es zu erraten. */
  L.push('  Riegel: ' + befund.riegel.abgewiesen + ' Wert(e) beim Schreiben abgewiesen ' +
    '(0 = alles kam aus den drei zugelassenen Quellen).');
  L.push('');
  L.push('-----------------------------------------------------------------------');
  /* Steht dieser Bericht nur auf dem Bildschirm, waere "bitte diese Datei schicken" ein
   * Verweis auf eine Datei, die es nicht gibt — und der Tierarzt sucht sie. */
  if (befund.schreibfehler && befund.schreibfehler.length) {
    L.push(' DIESER BEFUND KONNTE NICHT GESPEICHERT WERDEN:');
    befund.schreibfehler.forEach(function (f) { L.push('   ' + f.datei + ': ' + f.grund); });
    L.push(' Er steht deshalb nur hier auf dem Bildschirm. BITTE DIESEN GANZEN TEXT');
    L.push(' MARKIEREN, KOPIEREN UND AN DEN ENTWICKLER SCHICKEN - dann ist die Messung');
    L.push(' nicht verloren und muss nicht am Geraet wiederholt werden.');
  } else {
    L.push(' BITTE DIESE DATEI AN DEN ENTWICKLER SCHICKEN:');
    L.push('   ' + befund.dateien.txt);
    L.push(' Dazu gehoert die Datei mit denselben Zahlen in Maschinenform:');
    L.push('   ' + befund.dateien.json);
    L.push(' Beide liegen in dem Ordner, den die Sonde beim Speichern auf dem Bildschirm');
    L.push(' genannt hat.');
  }
  L.push('-----------------------------------------------------------------------');
  L.push('');
  return L.join('\n');
}

/*
 * nurAscii(text) — der Bericht wird auf einem fremden Rechner geoeffnet und per Mail
 * weitergereicht. Ein Gedankenstrich in UTF-8 ohne Vorspann wird in einem Editor mit
 * Windows-Zeichensatz zu "â€”"; dann sieht der Befund kaputt aus und man traut ihm nicht.
 * Reines ASCII ueberlebt jeden Editor und jedes Mailprogramm. Dieselbe Ueberlegung steht
 * hinter der ASCII-Regel fuer die .ps1-Dateien des Projekts.
 */
function nurAscii(text) {
  return String(text)
    /* Zuerst die Zeichen, fuer die es eine LESBARE Entsprechung gibt. Sie muessen vor dem
     * Auffangnetz stehen, sonst wuerde aus jedem Gedankenstrich ein Fragezeichen. */
    .replace(/[–—−]/g, '-')
    .replace(/[‘’‚]/g, "'")
    .replace(/[“”„]/g, '"')
    .replace(/…/g, '...')
    .replace(/[   ]/g, ' ')
    .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue')
    .replace(/Ä/g, 'Ae').replace(/Ö/g, 'Oe').replace(/Ü/g, 'Ue')
    .replace(/ß/g, 'ss')
    /* DAS AUFFANGNETZ, und es muss die LETZTE Ersetzung bleiben.
     * Warum nicht nur Umlaute und Anfuehrungszeichen genuegen: geschrieben wird mit Encoding
     * 'ascii', und Node nimmt dabei die unteren acht Bit jedes Zeichens. Aus einem
     * Gedankenstrich (U+2014) wuerde so nicht "?" sondern das Steuerzeichen 0x14 — im Editor
     * unsichtbar, im Mailprogramm ein Grund, die Datei fuer beschaedigt zu halten. Genauso
     * die Rahmenbytes 0x0b/0x1c aus MLLP, wenn je ein halber Rahmen im Bericht landete.
     * Erlaubt bleiben deshalb genau Tabulator, Zeilenumbruch, Wagenruecklauf und die
     * druckbaren ASCII-Zeichen; alles andere wird sichtbar zu "?". */
    .replace(/[^\x09\x0a\x0d\x20-\x7e]/g, '?');
}

/* Zeilenumbruch fuer den Fliesstext des Urteils — der Bericht wird im Editor gelesen, und
 * eine 300 Zeichen lange Zeile liest dort niemand. */
function umbruch(text, breite) {
  const worte = String(text).split(/\s+/);
  const zeilen = [];
  let z = '';
  worte.forEach(function (w) {
    if (!z.length) { z = w; return; }
    if ((z + ' ' + w).length > breite) { zeilen.push(z); z = w; } else { z += ' ' + w; }
  });
  if (z.length) zeilen.push(z);
  return zeilen;
}

// ---------------------------------------------------------------------------------------
// HOST FINDEN (--host auto)
// ---------------------------------------------------------------------------------------

/*
 * sucheHost(cb) — nur fuer "--host auto".
 * bridge/src/geraetefund.js ist ohne laufende Station benutzbar: aktualisiere() ruft "arp -a"
 * auf und filtert nach den Hersteller-Praefixen aus dem Geraetekatalog. Es sendet nichts.
 * ARP kennt aber nur Adressen, mit denen der PC KUERZLICH gesprochen hat — findet sich
 * nichts, wird hier NICHT geraten, sondern klar gesagt, dass eine IP mitgegeben werden muss.
 * Die gefundene Adresse geht auf den BILDSCHIRM, nicht in den Befund.
 */
function sucheHost(log, cb) {
  let fund = null;
  try {
    fund = require(path.join(__dirname, '..', 'bridge', 'src', 'geraetefund.js'));
  } catch (e) {
    log('Die Geraetesuche (bridge/src/geraetefund.js) laesst sich nicht laden: ' +
      (e && e.message ? e.message : String(e)));
    return cb(null);
  }
  log('Suche das Geraet in der ARP-Tabelle des PCs (es wird nichts gesendet) ...');
  let fertig = false;
  const frist = setTimeout(function () {
    if (fertig) return;
    fertig = true;
    log('Die Geraetesuche hat nicht rechtzeitig geantwortet.');
    cb(null);
  }, 8000);
  Promise.resolve()
    .then(function () { return fund.aktualisiere(); })
    .then(function (liste) {
      if (fertig) return;
      fertig = true;
      clearTimeout(frist);
      const ip = fund.beste(null);
      if (ip) {
        log('Gefunden: ' + ip + ' (' + (liste ? liste.length : 0) + ' Geraet(e) in der ARP-Tabelle).');
      }
      cb(ip || null);
    })
    .catch(function (e) {
      if (fertig) return;
      fertig = true;
      clearTimeout(frist);
      log('Die Geraetesuche ist fehlgeschlagen: ' + (e && e.message ? e.message : String(e)));
      cb(null);
    });
}

// ---------------------------------------------------------------------------------------
// LAEUFT DIE STATION? (Befund vom 26.07.2026)
// ---------------------------------------------------------------------------------------

/*
 * pruefeStation(cb) — fragt die eigene Station, ob sie ueberhaupt da ist.
 *
 * WARUM DAS SEIN MUSS: die Sonde oeffnet acht Verbindungen zu demselben Monitor und laeuft
 * drei Minuten. Am 26.07.2026 wurde an diesem Geraet beobachtet, dass eine ZWEITE abfragende
 * Verbindung abgewiesen wurde, waehrend die Station eine hielt. DAS IST EINE EIGENE
 * BEOBACHTUNG UND KEINE HERSTELLERANGABE (richtiggestellt 28.08.2026): der Programmer's
 * Guide sagt in Kapitel 6 zur Zahl gleichzeitiger Gegenstellen am Realtime-Port nichts; die
 * einzige Obergrenze im ganzen Dokument steht in §2.1.1 und gilt der ANDEREN Schnittstelle.
 * Ein Geraet, ein Fall — genug fuer den Riegel, zu wenig fuer einen Satz ueber "das
 * PDS-Geraet". Dieselbe Richtigstellung steht in bridge/src/adapters/hl7.js.
 * Wer die Sonde waehrend einer Narkose startet, riskiert also zweierlei: einen Befund, der
 * nur die eigene Station misst, und — schlimmer — ein Aussetzen der Werte am Patienten.
 * bridge/src/erstsuche.js sperrt aus genau diesem Grund den Suchlauf, solange ein Patient
 * anliegt, mit der Hausregel: eine Narkose hat immer Vorrang. Fuer die Sonde gilt sie genauso.
 *
 * WIE GEPRUEFT WIRD: ein kurzer HTTP-Aufruf an die lesende Route /api/state der Station. Sie
 * ist nur ueber 127.0.0.1 erreichbar (server.js), und die Sonde laeuft auf demselben PC.
 * Jeder Fehlschlag — kein Dienst, anderer Port, Zeitueberschreitung, unlesbare Antwort —
 * heisst schlicht "laeuft nicht"; im Zweifel wird also NICHT abgebrochen, denn ein Abbruch
 * ohne Grund brauchte der Tierarzt am wenigsten.
 *
 * WAS AUS DER ANTWORT GENOMMEN WIRD: ausschliesslich die ANZAHL der Geraete mit anliegenden
 * Werten. /api/state liefert die vollstaendige Geraeteakte samt Patientenname — nichts davon
 * darf in den Bericht, der den PC verlaesst. Zahlen sind das Einzige, was hier herauskommt.
 */
const STATION_PORT = 8770;        // bridge/src/erstsuche.js:136, bridge/src/index.js:66
const STATION_FRIST_MS = 1500;

function pruefeStation(cb) {
  const http = require('http');
  let fertig = false;
  function ende(lage) {
    if (fertig) return;
    fertig = true;
    lage.geprueft = true;
    lage.port = zahl(STATION_PORT);
    cb(lage);
  }
  let req;
  try {
    req = http.get({
      host: '127.0.0.1', port: STATION_PORT, path: '/api/state', timeout: STATION_FRIST_MS,
    }, function (res) {
      let roh = '';
      res.setEncoding('utf8');
      res.on('data', function (c) { if (roh.length < 400000) roh += c; });
      res.on('end', function () {
        let aktive = null, geraete = null;
        try {
          const st = JSON.parse(roh);
          const g = (st && st.devices) || [];
          geraete = zahl(g.length);
          aktive = zahl(g.filter(function (d) { return d && d.status === 'active'; }).length);
        } catch (_) {
          /* Antwortet dort etwas Unlesbares, genuegt fuer die Warnung schon, DASS es
           * antwortet: der Port ist belegt, also laeuft dort ein Dienst. */
        }
        ende({ laeuft: true, geraete: geraete, aktive: aktive });
      });
      res.on('error', function () { ende({ laeuft: true, geraete: null, aktive: null }); });
    });
  } catch (_) {
    return ende({ laeuft: false });
  }
  req.on('timeout', function () { try { req.destroy(); } catch (_) {} ende({ laeuft: false }); });
  req.on('error', function () { ende({ laeuft: false }); });
}

// ---------------------------------------------------------------------------------------
// ABLAUF
// ---------------------------------------------------------------------------------------

/*
 * pruefeSchreibziel(ordner) — der TEURSTE Zeitpunkt fuer einen Fehlschlag ist der letzte.
 *
 * Bis 28.08.2026 stand mkdirSync in einem try/catch, das den Fehler verschluckte, und der
 * writeFileSync dahinter ungeschuetzt. Lag der Zielordner schreibgeschuetzt (EACCES, ein
 * Ordner in OneDrive, ein Netzlaufwerk ohne Recht), gingen acht mal 25 Sekunden Messung
 * verloren und der Tierarzt sah einen ENOENT aus einem Rueckruf — eine Meldung, mit der er
 * nichts anfangen kann, nach drei Minuten Warten.
 *
 * Deshalb: Ordner anlegen, eine Probedatei schreiben, sie wieder loeschen — VOR der ersten
 * Verbindung. Nur das Schreiben beweist das Schreibrecht; ein existierender Ordner beweist
 * gar nichts.
 * Rueckgabe: null, wenn alles gut ist, sonst der Satz, der dem Tierarzt AUF DEM BILDSCHIRM
 * gesagt wird. Er enthaelt den Pfad — das ist richtig so: dieser Satz geht nicht in den
 * Befund, sondern an den Menschen, der davorsitzt.
 */
function pruefeSchreibziel(ordner) {
  function grund(err) {
    return err && err.code ? err.code : (err && err.message ? err.message : String(err));
  }
  try { fs.mkdirSync(ordner, { recursive: true }); } catch (err) {
    return 'Der Ordner fuer den Befund laesst sich nicht anlegen: ' + ordner +
      ' (' + grund(err) + ').';
  }
  const probe = path.join(ordner, '.pds-schreibprobe-' + process.pid + '.tmp');
  try {
    fs.writeFileSync(probe, 'Schreibprobe der PDS-Feldsonde\n', 'ascii');
  } catch (err) {
    return 'In den Ordner ' + ordner + ' darf nicht geschrieben werden (' + grund(err) + ').';
  }
  /* Bleibt die Probe liegen, ist das unschoen, aber kein Grund, die Messung zu verweigern:
   * geschrieben werden KONNTE, und nur darum ging es. */
  try { fs.unlinkSync(probe); } catch (_) {}
  return null;
}

/*
 * schreibeBericht() — und der Notausgang, wenn das Schreiben trotz aller Vorpruefung scheitert.
 *
 * Zwischen der Vorpruefung und diesem Augenblick liegen drei Minuten; in denen kann eine
 * Platte volllaufen oder ein Netzlaufwerk verschwinden. Dann ist der Bericht das einzige
 * Ergebnis von drei Minuten Messung am lebenden Geraet — er geht auf den Bildschirm, ohne
 * Ruecksicht auf "--still". Der Tierarzt kann ihn von dort kopieren; verloren ist er nicht.
 *
 * DER RIEGEL LAEUFT HIER, UNMITTELBAR VOR DEM SCHREIBEN, und zwar ueber DIESELBE Struktur,
 * aus der beide Dateien entstehen. Es gibt keinen Weg an ihm vorbei: die .json ist die
 * gepruefte Struktur, die .txt wird aus ihr gesetzt.
 */
function schreibeBericht(befund, ziel, log) {
  befund.riegel = { abgewiesen: zahl(pruefeBefund(befund)) };
  const text = nurAscii(baueText(befund));
  const fehler = [];
  try { fs.mkdirSync(path.dirname(ziel.json), { recursive: true }); } catch (_) {}
  try {
    fs.writeFileSync(ziel.json, JSON.stringify(befund, null, 2), 'utf8');
  } catch (err) {
    fehler.push({ datei: festerText(F.dateiMaschine), grund: dateiGrund(err) });
  }
  try {
    fs.writeFileSync(ziel.txt, text, 'ascii');
  } catch (err) {
    fehler.push({ datei: festerText(F.dateiBericht), grund: dateiGrund(err) });
  }
  befund.schreibfehler = fehler.length ? fehler : null;

  if (fehler.length) {
    console.log('');
    console.log(nurAscii('Der Befund liess sich NICHT speichern:'));
    console.log(nurAscii('  ' + ziel.txt));
    console.log(nurAscii('  ' + ziel.json));
    console.log(nurAscii('Damit die Messung nicht verloren ist, steht der ganze Befund hier.'));
    console.log(nurAscii('Bitte diesen Text vollstaendig kopieren und an den Entwickler schicken:'));
    console.log('');
    /* Neu gebaut, nicht der Text von oben: der Schlussblock verweist sonst auf eine Datei,
     * die es gar nicht gibt. befund.schreibfehler steht jetzt und aendert genau diesen Block. */
    console.log(nurAscii(baueText(befund)));
    return;
  }
  log('');
  log('Befund geschrieben:');
  log('  ' + ziel.txt);
  log('  ' + ziel.json);
  log('');
  log('BITTE DIESE DATEI AN DEN ENTWICKLER SCHICKEN: ' + ziel.txt);
}

function laufe(opt, fertig) {
  const start = new Date();
  const ergebnisse = [];
  const liste = VARIANTEN.filter(function (v) { return !opt.nur || v.nr === opt.nur; });

  /* BEIDE Pruefungen stehen VOR der ersten Verbindung und werfen, statt weiterzumachen.
   *
   * Ein Bericht ueber eine Messung, die nicht stattgefunden hat, ist das Schlimmste, was
   * dieses Werkzeug liefern kann — er sieht aus wie ein Ergebnis. "--nur 9" fuhr frueher
   * null Varianten und schrieb trotzdem einen Befund mit vier Pruefschritten.
   * Und ein Schreibrecht, das erst nach drei Minuten Messung geprueft wird, ist zu spaet
   * geprueft (siehe pruefeSchreibziel). */
  if (!liste.length) {
    throw new Error('Die Variante ' + opt.nur + ' gibt es nicht. Es gibt die Varianten 1 bis ' +
      VARIANTEN.length + '. Ohne "--nur" laufen alle nacheinander.');
  }
  const hindernis = pruefeSchreibziel(opt.ordner);
  if (hindernis) throw new Error(hindernis);

  /* Der Dateiname geht IN den Bericht (damit man weiss, welche Datei gemeint ist), der Pfad
   * NICHT (er nennt den Benutzer und die Ordnerstruktur des Praxis-PCs). Beide Namen werden
   * aus Ziffernstuecken zusammengesetzt — jedes fuer sich kurz genug fuer Tor 2. */
  const z = zeitTeile(start);
  const teile = [ziffernkennung(z.jahr), ziffernkennung(z.monat), ziffernkennung(z.tag),
    ziffernkennung(z.stunde), ziffernkennung(z.minute), ziffernkennung(z.sekunde)];
  const nameTxt = fuege(KOPF.dateiVorlage, teile.concat([festerText(KOPF.endungTxt)]));
  const nameJson = fuege(KOPF.dateiVorlage, teile.concat([festerText(KOPF.endungJson)]));
  const ziel = {
    txt: path.join(opt.ordner, nameTxt),
    json: path.join(opt.ordner, nameJson),
  };

  const befund = {
    werkzeug: festerText(KOPF.werkzeug),
    stand: festerText(KOPF.stand),
    hinweisSicherheit: festerText(KOPF.hinweisSicherheit),
    hinweisDatenschutz: festerText(KOPF.hinweisDatenschutz),
    zusage: ZUSAGE.map(function (s) { return festerText(s); }),
    zeit: fuege(KOPF.zeitMaschine, [ziffernkennung(z.jahr), ziffernkennung(z.monat),
      ziffernkennung(z.tag), ziffernkennung(z.stunde), ziffernkennung(z.minute),
      ziffernkennung(z.sekunde)]),
    zeitLesbar: fuege(KOPF.zeitLesbar, [ziffernkennung(z.tag), ziffernkennung(z.monat),
      ziffernkennung(z.jahr), ziffernkennung(z.stunde), ziffernkennung(z.minute)]),
    dateien: { txt: nameTxt, json: nameJson },
    /* Nur ZAHLEN aus der Stationsabfrage, nie Namen: /api/state liefert die ganze Geraeteakte
     * samt Patientenname — davon geht hier ausdruecklich nichts in den Bericht. */
    station: opt.station || { geprueft: false },
    /* Kein "host": eine IP-Adresse ist weder eine gemessene Zahl noch eine Ziffernkennung
     * noch fester Text aus dieser Datei. Der Port ist eine reine Ziffernfolge und bleibt. */
    aufruf: {
      port: ziffernkennung(String(opt.port)),
      fensterSekunden: zahl(Math.round(opt.fensterMs / 1000)),
      nur: zahl(opt.nur) || null,
    },
    varianten: liste.map(function (v) {
      return { nr: zahl(v.nr), kurz: festerText(v.kurz), was: festerText(v.was) };
    }),
    ergebnisse: ergebnisse,
    urteil: null,
    dauerMs: 0,
    riegel: { abgewiesen: 0 },
    schreibfehler: null,
  };

  let i = 0;
  function weiter() {
    if (i >= liste.length) {
      befund.dauerMs = zahl(Date.now() - start.getTime());
      befund.urteil = gesamturteil(ergebnisse, opt);
      schreibeBericht(befund, ziel, opt.log);
      return fertig(befund);
    }
    const v = liste[i++];
    opt.log('');
    opt.log('=== Variante ' + v.nr + ' (' + i + ' von ' + liste.length + '): ' + v.kurz +
      ' (' + (opt.fensterMs / 1000) + ' s) ===');
    opt.log('    ' + v.was);
    fahreVariante(v, opt, function (e) {
      ergebnisse.push(e);
      opt.log('    Ergebnis: ' + e.urteil + ' — ' + e.rahmen + ' Nachrichten, ' +
        e.periodikRahmen + ' mit laufenden Messwerten, ' + e.trennungen + ' Trennungen.');
      weiter();
    });
  }
  weiter();
  return befund;
}

/* ---------------------------------------------------------------------------------------
 * DAS REGISTER SCHLIESSEN. Ab hier kann sich keine Zeichenkette mehr als "unsere" anmelden.
 * Alles, was oben in Tabellen steht, ist jetzt angemeldet; alles, was spaeter kommt, muss
 * durch Tor 1 (Zahl) oder Tor 2 (Ziffernkennung) — oder es faellt heraus.
 * ------------------------------------------------------------------------------------ */
melde(VARIANTEN);
melde(FEHLTE_JE_VARIANTE);
melde(KURZURTEIL);
melde(ZUSAGE);
melde(U);
melde(SEGMENTNAMEN);
melde([SEG_UNBEKANNT, SEG_KEINE_ZEILE, TYP_ANDERER, TYP_ANDERE_MELDUNG, CODE_ANDERER,
  FEHLER_ANDERER, MARKE, PLATZ_ZEIT, PLATZ_KENNUNG, PLATZ_NUMMER, MSH10_FEST]);
melde(WERTTYPEN);
melde(MELDUNGSTYPEN);
melde(ACK_CODES);
melde(QAK_CODES);
melde(NETZFEHLER);
melde(DATEIFEHLER);
melde(PARAM_NAME);
melde(IDS_HEUTE);
melde(IDS_ALLE);
siegle();

module.exports = {
  // Die drei Tore und ihre Helfer — der ganze Riegel steht und faellt mit ihnen.
  zahl, ziffernkennung, festerText, ausListe, messzahl, satz, fuege, pruefeBefund,
  ZIFFERN, MARKE,
  // Messung und Deutung
  baueAbfrage, abfragePlan, baueAck, deute, segmentPlan, fehlerPlan, beurteile, gesamturteil,
  baueText, nurAscii, pruefeSchreibziel, pruefeStation, schreibeBericht,
  VARIANTEN, IDS_HEUTE, IDS_ALLE, ECHO_TEXT, MSH10_FEST, SEGMENTNAMEN, WERTTYPEN, PARAM_NAME,
  laufe,
};

// ---------------------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------------------

if (require.main === module) {
  const args = process.argv.slice(2);
  function arg(name, vorgabe) {
    const i = args.indexOf('--' + name);
    return i >= 0 && args[i + 1] !== undefined ? args[i + 1] : vorgabe;
  }
  if (args.indexOf('--hilfe') >= 0 || args.indexOf('--help') >= 0) {
    console.log('Aufruf: node tools/pds-feldsonde.js --host <IP|auto> [--port 4601] ' +
      '[--sekunden 25] [--nur 4] [--ordner data] [--trotzdem]');
    console.log('Fragt den Monitor achtmal mit leicht verschiedenen Abfragen und schreibt');
    console.log('einen Befund nach data/. Die Sonde LIEST NUR.');
    console.log('--nur <1..' + VARIANTEN.length + '> faehrt nur eine Variante.');
    /* RICHTIGGESTELLT AM 28.08.2026: hier stand "der Monitor laesst nur EINE abfragende
     * Gegenstelle zu" als Tatsache. Belegt ist nur die eigene Beobachtung vom 26.07.2026;
     * im Programmer's Guide steht dazu nichts. */
    console.log('--trotzdem misst auch dann, wenn die VetStation laeuft. NICHT waehrend einer');
    console.log('Narkose benutzen: am 26.07.2026 wurde beobachtet, dass das Geraet eine zweite');
    console.log('abfragende Verbindung abwies, waehrend die Station eine hielt.');
    process.exit(0);
  }

  const still = args.indexOf('--still') >= 0;
  /* Auch die Bildschirmausgabe geht durch nurAscii: die Konsole des Praxis-PCs laeuft in
   * einem Windows-Zeichensatz und machte aus jedem Gedankenstrich drei Zeichen Muell.
   * Der BILDSCHIRM darf die Adresse und die Pfade nennen — er verlaesst den PC nicht. */
  function log(z) { if (!still) console.log(nurAscii(z)); }

  const sekunden = Math.max(1, Number(arg('sekunden', 25)) || 25);
  const nur = Number(arg('nur', 0)) || 0;
  /* Eine unbekannte Nummer wird HIER abgefangen, vor jeder Ausgabe und vor jeder Messung.
   * Frueher fuhr "--nur 9" null Varianten und schrieb trotzdem einen vollstaendig
   * aussehenden Befund mit vier Pruefschritten — ein Bericht ueber eine Messung, die es nie
   * gegeben hat. Exitcode 2 wie bei der fehlenden Adresse: falscher Aufruf. */
  if (nur && !VARIANTEN.some(function (v) { return v.nr === nur; })) {
    console.log('Die Variante ' + nur + ' gibt es nicht.');
    console.log('Es gibt die Varianten 1 bis ' + VARIANTEN.length + ':');
    VARIANTEN.forEach(function (v) { console.log('  ' + v.nr + '  ' + v.kurz); });
    console.log('Ohne "--nur" laufen alle nacheinander. Es wurde NICHTS gemessen und kein');
    console.log('Befund geschrieben.');
    process.exit(2);
  }
  const ordnerArg = arg('ordner', '');
  const opt = {
    host: String(arg('host', '')).trim(),
    port: Number(arg('port', 4601)) || 4601,
    fensterMs: sekunden * 1000,
    verbindeFristMs: Math.max(2000, Math.min(sekunden * 1000, 8000)),
    nur: nur,
    /* Vorgabe ist der data-Ordner NEBEN dieser Datei, nicht der Ordner, aus dem gestartet
     * wurde: der Tierarzt startet die Sonde ueber eine Verknuepfung, und der Befund soll
     * trotzdem immer an derselben Stelle liegen. */
    ordner: ordnerArg ? path.resolve(ordnerArg) : path.join(__dirname, '..', 'data'),
    log: log,
  };

  log('VetStation — PDS-Feldsonde (28.08.2026). Diese Sonde LIEST NUR: sie sendet');
  log('ausschliesslich Abfragen, das vorgeschriebene Echo und die Quittung, die die Station');
  log('ohnehin schickt. Am Geraet wird nichts eingestellt, an der Station nichts geaendert.');
  log('Der Befund enthaelt kein Textfeld des Geraets - nur Zahlen, gepruefte Kennziffern');
  log('und festen Text der Sonde.');
  log('');

  function starteLauf() {
    if (!opt.host) {
      console.log('Es fehlt die Adresse des Geraets.');
      console.log('Bitte die IP des Monitors mitgeben, zum Beispiel:');
      console.log('  node tools/pds-feldsonde.js --host 192.168.0.50');
      console.log('Die IP steht am Geraet im Netzwerk-Menue. "--host auto" sucht sie in der');
      console.log('ARP-Tabelle des PCs, findet sie dort aber nur, wenn der PC vorher schon');
      console.log('einmal mit dem Geraet gesprochen hat.');
      process.exit(2);
    }
    /* Hartes Gesamtzeitlimit. Ohne das koennte ein Geraet, das die Verbindung annimmt und
     * dann schweigt, die Sonde beliebig lange festhalten — und eine haengende node.exe
     * blockiert spaeter den Paketbau (Projektregel). */
    const anzahl = nur ? 1 : VARIANTEN.length;
    const grenzeMs = anzahl * (opt.fensterMs + 2000) + 20000;
    const notaus = setTimeout(function () {
      console.log('');
      console.log('ZEITLIMIT: die Sonde bricht nach ' + Math.round(grenzeMs / 1000) +
        ' s ab. Der Befund enthaelt, was bis hierher gemessen wurde.');
      process.exit(3);
    }, grenzeMs);
    notaus.unref();

    /* laufe() wirft, wenn vor der Messung etwas nicht stimmt (unbekannte Variante, kein
     * Schreibrecht am Zielordner). Der Tierarzt bekommt dann EINEN klaren Satz und einen
     * Exitcode ungleich 0 — und keinen Befund, denn es wurde nichts gemessen. */
    try {
      laufe(opt, function () {
        clearTimeout(notaus);
        /* Ausdruecklich beenden: offene Sockets oder ein vergessener Timer wuerden den
         * Prozess am Leben halten. */
        process.exit(0);
      });
    } catch (e) {
      clearTimeout(notaus);
      console.log('');
      console.log(nurAscii('Die Sonde hat NICHT gemessen: ' +
        (e && e.message ? e.message : String(e))));
      console.log('Es wurde kein Befund geschrieben.');
      process.exit(4);
    }
  }

  /*
   * mitStationsPruefung() — der Riegel vor dem Start (Befund F).
   *
   * Die Warnung geht ueber console.log und nicht ueber log(): sie ist der Grund fuer den
   * Abbruch, und "--still" darf einen Grund nicht verschlucken.
   */
  function mitStationsPruefung(weiter) {
    pruefeStation(function (lage) {
      opt.station = lage;
      if (!lage.laeuft) return weiter();
      console.log('');
      console.log('ACHTUNG: auf diesem PC LAEUFT DIE VETSTATION (Port ' + lage.port + ').');
      if (lage.aktive) {
        console.log('Sie meldet gerade ' + lage.aktive + ' Geraet(e) mit anliegenden Werten.');
      }
      console.log('');
      console.log('Was passieren kann, wenn die Sonde jetzt misst:');
      console.log('  - Die Sonde baut acht Verbindungen zu demselben Monitor auf. Am');
      console.log('    26.07.2026 wurde an diesem Geraet beobachtet, dass es eine zweite');
      console.log('    abfragende Verbindung abwies, waehrend die Station eine hielt. Das ist');
      console.log('    eine eigene Beobachtung, keine Herstellerangabe - der Programmer\'s');
      console.log('    Guide sagt zur Zahl gleichzeitiger Gegenstellen am Realtime-Port');
      console.log('    nichts. Ein Fall genuegt aber, um es nicht am Patienten auszuprobieren.');
      console.log('  - Abgewiesen werden kann dabei auch die Station: dann fehlen am');
      console.log('    Patienten fuer die Dauer der Messung die Werte.');
      console.log('  - Und der Befund selbst wird wertlos: eine stumme Variante hiesse dann');
      console.log('    nur, dass der Platz belegt war, nicht dass die Abfrage falsch ist.');
      console.log('');
      console.log('WAEHREND EINER NARKOSE WIRD NICHT GEMESSEN. Eine Narkose hat immer Vorrang');
      console.log('vor Bequemlichkeit - dieselbe Regel gilt in der Station fuer den Suchlauf.');
      console.log('');
      console.log('Richtig ist: die Narkose zu Ende fuehren, dann die VetStation beenden, dann');
      console.log('die Sonde starten. Wer sicher ist, dass KEIN Patient angeschlossen ist,');
      console.log('kann sie mit "--trotzdem" erzwingen:');
      console.log('  node tools/pds-feldsonde.js --host ' + (opt.host || '<IP>') + ' --trotzdem');
      if (args.indexOf('--trotzdem') < 0) {
        console.log('');
        console.log('Es wurde NICHTS gemessen und kein Befund geschrieben.');
        process.exit(5);
      }
      console.log('');
      console.log('"--trotzdem" ist gesetzt - die Messung laeuft. Der Hinweis steht auch im');
      console.log('Kopf des Befundes, damit ihn der Entwickler spaeter mitliest.');
      console.log('');
      weiter();
    });
  }

  if (opt.host === 'auto') {
    sucheHost(log, function (ip) {
      if (!ip) {
        console.log('');
        console.log('Es wurde kein Geraet gefunden. Bitte die IP-Adresse des Monitors');
        console.log('mitgeben (sie steht am Geraet im Netzwerk-Menue):');
        console.log('  node tools/pds-feldsonde.js --host 192.168.0.50');
        console.log('Geraten wird hier ausdruecklich nicht - eine falsche Adresse ergaebe');
        console.log('einen Befund, der nur beweist, dass dort nichts steht.');
        process.exit(2);
      }
      opt.host = ip;
      mitStationsPruefung(starteLauf);
    });
  } else {
    mitStationsPruefung(starteLauf);
  }
}
