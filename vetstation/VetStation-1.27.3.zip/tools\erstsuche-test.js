'use strict';
/*
 * erstsuche-test.js — die Station findet Geraete und Nachbar-PCs von selbst (Wunsch 31.07.2026).
 *
 * Was hier geprueft wird, ist NICHT "findet sie etwas" — das haengt am Netz und laesst sich in
 * einem Test nicht ehrlich nachstellen. Geprueft wird das, was schiefgehen kann, ohne dass es
 * jemand merkt:
 *   - Sucht sie waehrend einer laufenden Narkose? (Darf sie nicht.)
 *   - Traegt sie ein Geraet doppelt ein, das der Verbindungs-Assistent schon bedient?
 *   - Haelt sie ein Geraet fuer einen Nachbar-PC oder sich selbst fuer einen Nachbarn?
 *   - Schaltet sie einen Eintrag wieder ab, der zwar antwortet, aber kein HL7 spricht?
 *
 * Start: node tools/erstsuche-test.js       (laeuft auch in `npm test`)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const E = require('../bridge/src/erstsuche');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e !== undefined ? '  -> ' + e : '')); } }
function gleich(n, a, b) { ok(n, JSON.stringify(a) === JSON.stringify(b), JSON.stringify(a) + ' != ' + JSON.stringify(b)); }

console.log('VetStation — automatische Suche beim ersten Start\n');

/* ------------------------------------------------------------------ *
 * 1) Wann darf ueberhaupt gesucht werden?
 * ------------------------------------------------------------------ */
console.log(' 1) Sperren');
ok('frischer PC ohne Patient darf suchen', E.darfSuchen({ aktiveGeraete: 0, echteKarten: 1 }).ok === true);
ok('WAEHREND EINER NARKOSE wird NICHT gesucht',
  E.darfSuchen({ aktiveGeraete: 1, echteKarten: 1 }).ok === false);
ok('und der Grund nennt den Patienten, nicht nur "geht nicht"',
  /Patient/.test(E.darfSuchen({ aktiveGeraete: 1, echteKarten: 1 }).grund));
ok('ohne echte Netzwerkkarte wird nicht gesucht',
  E.darfSuchen({ aktiveGeraete: 0, echteKarten: 0 }).ok === false);
ok('eine bereits laufende Suche wird nicht doppelt gestartet',
  E.darfSuchen({ aktiveGeraete: 0, echteKarten: 1, laeuftSchon: true }).ok === false);
ok('zwei aktive Geraete sperren ebenso', E.darfSuchen({ aktiveGeraete: 2, echteKarten: 3 }).ok === false);

/* ------------------------------------------------------------------ *
 * 2) Abstaende — wachsend, aber nicht ins Unendliche.
 * ------------------------------------------------------------------ */
console.log('\n 2) Wiederholungsabstand');
ok('erster Abstand ist der kuerzeste', E.abstandMs(0) === E.ABSTAENDE_MS[0]);
ok('der Abstand waechst', E.abstandMs(1) > E.abstandMs(0));
ok('und bleibt oben stehen (kein Ueberlauf)', E.abstandMs(99) === E.ABSTAENDE_MS[E.ABSTAENDE_MS.length - 1]);
ok('negative Zaehler klemmen auf den ersten Wert', E.abstandMs(-5) === E.ABSTAENDE_MS[0]);
ok('kein Abstand unter einer Minute', E.ABSTAENDE_MS.every((m) => m >= 60000));

/* ------------------------------------------------------------------ *
 * 3) Welcher Fund wird eingetragen — und welcher ausdruecklich nicht?
 * ------------------------------------------------------------------ */
console.log('\n 3) Adaptervorschlaege');

const LAUSCHT = { ip: '192.168.0.51', mac: '000f14aabbcc', hersteller: 'Mindray/Eickemeyer (LifeVet 10C)', datenPorts: [4601] };
const SENDET  = { ip: '192.168.0.50', mac: '98cce4000001', hersteller: 'Mindray', datenPorts: [], sendetVermutlich: true };

let v = E.adapterVorschlaege([LAUSCHT], [], {});
ok('ein LAUSCHENDES Geraet bekommt einen Client-Adapter', !!(v[0] && v[0].adapter));
ok('der Adapter zeigt auf die gefundene Adresse', v[0].adapter.host === '192.168.0.51');
ok('der Adapter ist eingeschaltet', v[0].adapter.enabled === true);
ok('der Adapter ist ein HL7-Client', v[0].adapter.type === 'hl7' && v[0].adapter.mode === 'client');
ok('der Eintrag sagt im Klartext, dass die Station ihn selbst gemacht hat',
  /erstsuche/.test(String(v[0].adapter._automatisch)));

v = E.adapterVorschlaege([SENDET], [], {});
ok('ein SENDENDES Geraet bekommt KEINEN zweiten Eintrag (der Assistent hat es schon)',
  v.length === 1 && v[0].adapter === null);
ok('und der Grund erklaert warum', /Verbindungs-Assistent/.test(v[0].grund));

v = E.adapterVorschlaege([LAUSCHT], [{ type: 'hl7', mode: 'client', enabled: true, host: 'auto', port: 4601 }], {});
ok('ein vorhandener "auto"-Adapter deckt den Fund ab — kein zweiter Eintrag', v[0].adapter === null);

v = E.adapterVorschlaege([LAUSCHT], [{ type: 'hl7', mode: 'client', enabled: true, host: '192.168.0.51', port: 4601 }], {});
ok('ein Adapter mit genau dieser IP deckt den Fund ab', v[0].adapter === null);

v = E.adapterVorschlaege([LAUSCHT], [{ type: 'hl7', mode: 'client', enabled: false, host: 'auto', port: 4601 }], {});
ok('ein AUSGESCHALTETER Adapter deckt nichts ab (er fragt ja nicht ab)', !!(v[0] && v[0].adapter));

v = E.adapterVorschlaege([LAUSCHT], [{ type: 'hl7', mode: 'listener', enabled: true, listenPort: 4601 }], {});
ok('ein Listener deckt ein lauschendes Geraet NICHT ab (beide warten dann aufeinander)', !!(v[0] && v[0].adapter));

v = E.adapterVorschlaege([LAUSCHT], [], { '192.168.0.51:4601': 'spricht kein HL7' });
ok('eine gesperrte Adresse wird nicht erneut eingetragen', v[0].adapter === null);
ok('und die Sperre steht als Grund da', /spricht kein HL7/.test(v[0].grund));

const VIELE = [];
for (let i = 1; i <= 7; i++) VIELE.push({ ip: '192.168.0.' + (100 + i), datenPorts: [4601], hersteller: 'x' });
v = E.adapterVorschlaege(VIELE, [], {});
ok('hoechstens ' + E.NEUE_ADAPTER_MAX + ' neue Eintraege je Lauf',
  v.filter((x) => x.adapter).length === E.NEUE_ADAPTER_MAX);
ok('die uebrigen Funde werden NICHT verschwiegen, sondern mit Grund gemeldet',
  v.filter((x) => !x.adapter && /Deckel/.test(x.grund)).length === VIELE.length - E.NEUE_ADAPTER_MAX);

v = E.adapterVorschlaege([{ ip: '192.168.0.60', datenPorts: [8770, 8771] }], [], {});
ok('Oberflaechen- und Nachbar-Port fuehren NIE zu einem Geraete-Adapter',
  v.filter((x) => x.adapter).length === 0);

/* ------------------------------------------------------------------ *
 * 4) Zweiter Praxis-PC — und die eigene Adresse.
 * ------------------------------------------------------------------ */
console.log('\n 4) Weitere Praxis-PCs');

const HOSTS = [
  { ip: '192.168.0.5', selbst: true, offenePorts: [8770] },
  { ip: '192.168.0.7', zweiteStation: true, offenePorts: [3502, 4601, 5000, 8830] },
  { ip: '192.168.0.9', offenePorts: [8771] },
  { ip: '192.168.0.51', offenePorts: [4601] },
  { ip: '192.168.0.99', offenePorts: [8770] },
];
let s = E.stationsVerdacht(HOSTS, ['192.168.0.99']);
const ips = s.map((x) => x.ip);
ok('der PC mit vielen Datenports gilt als zweite Station', ips.indexOf('192.168.0.7') >= 0);
ok('ein offener Nachbar-Port gilt als zweite Station', ips.indexOf('192.168.0.9') >= 0);
ok('ein Monitor auf 4601 gilt NICHT als zweite Station', ips.indexOf('192.168.0.51') < 0);
ok('die als "selbst" erkannte Adresse faellt raus', ips.indexOf('192.168.0.5') < 0);
ok('DIE EIGENE ADRESSE faellt raus (sonst spricht die Station mit sich selbst)',
  ips.indexOf('192.168.0.99') < 0);
gleich('die Liste ist nach dem letzten Oktett sortiert', ips, ['192.168.0.7', '192.168.0.9']);
ok('kein Fund behauptet, geprueft zu sein', s.every((x) => x.geprueft === false));
ok('jeder Fund traegt eine Begruendung', s.every((x) => x.gruende.length > 0));
ok('der Nachbar-Port wird gesondert vermerkt',
  s.filter((x) => x.ip === '192.168.0.9')[0].nachbarPort === true);

/* ------------------------------------------------------------------ *
 * 5) Der eine Satz fuer den Menschen davor.
 * ------------------------------------------------------------------ */
console.log('\n 5) Klartext');
let z = E.zusammenfassung({ geraete: [], eingetragen: [], stationen: [] });
ok('ohne Fund steht ehrlich "kein Medizingeraet gefunden"', /kein Medizingeraet gefunden/.test(z));
ok('und ebenso ehrlich "keine zweite VetStation"', /keine zweite VetStation/.test(z));
z = E.zusammenfassung({ geraete: [{ ip: '192.168.0.51' }], eingetragen: [{ id: 'a' }], stationen: [{ ip: '192.168.0.7' }] });
ok('mit Fund stehen die Adressen da', /192\.168\.0\.51/.test(z) && /192\.168\.0\.7/.test(z));
ok('und der Satz sagt, dass kein Neustart noetig ist', /kein Neustart/.test(z));

/* ------------------------------------------------------------------ *
 * 6) Der ganze Ablauf gegen einen erfundenen Suchlauf — ohne Netz.
 * ------------------------------------------------------------------ */
console.log('\n 6) Ablauf');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vetstation-erstsuche-'));
const konfig = path.join(tmp, 'devices.json');
const merk = path.join(tmp, 'erstsuche.json');
const nachbarn = path.join(tmp, 'nachbarn.json');

const geraeteliste = [];
const gestartet = [];
const meldungen = [];
const log = {
  info: (q, m) => meldungen.push(m), warn: (q, m) => meldungen.push(m), error: (q, m) => meldungen.push(m),
};
const registry = { getDevices: () => geraeteliste, adapters: [] };

const es = new E.Erstsuche({
  log: log, registry: registry,
  konfigPfad: konfig, beispielPfad: path.join(tmp, 'gibtsnicht.json'), merkPfad: merk, nachbarnPfad: nachbarn,
  scan: () => Promise.resolve({ hosts: HOSTS, geraete: [LAUSCHT, SENDET] }),
  /* Die eigene Adresse wird hier VORGEGEBEN. Ohne das haengt der Test daran, welche IP der
   * ausfuehrende PC gerade hat — und genau die Sperre "die eigene Adresse ist kein Nachbarsaal"
   * waere dann nie zuverlaessig geprueft. */
  kartenQuelle: () => [{ address: '192.168.0.99', virtuell: false }],
  adapterStarten: (a) => { gestartet.push(a.id); return true; },
});

es.laufen().then((erg) => {
  ok('der Lauf liefert ein Ergebnis', !!erg);
  ok('das lauschende Geraet wurde eingetragen', (erg.eingetragen || []).length === 1);
  ok('und sofort gestartet — ohne Neustart', gestartet.length === 1);
  ok('devices.json wurde wirklich geschrieben', fs.existsSync(konfig));
  const cfg = JSON.parse(fs.readFileSync(konfig, 'utf8'));
  ok('der Eintrag steht in der Datei', (cfg.adapters || []).some((a) => a.host === '192.168.0.51'));
  ok('nachbarn.json haelt die Kandidaten fest', fs.existsSync(nachbarn));
  const nb = JSON.parse(fs.readFileSync(nachbarn, 'utf8'));
  ok('beide verdaechtigen PCs stehen als Kandidaten drin', (nb.kandidaten || []).length === 2);
  ok('ein Kandidat traegt KEINEN Schluessel (Vertrauen entsteht erst im Handschlag)',
    (nb.kandidaten || []).every((k) => !k.pub && !k.sid));
  ok('das Log nennt die zweite VetStation im Klartext',
    meldungen.some((m) => /zweite VetStation/.test(m)));
  ok('das Log nennt das gemeinsame Praxis-Konto als Voraussetzung',
    meldungen.some((m) => /Praxis-Konto/.test(m)));

  /* Ein zweiter Lauf darf denselben Adapter NICHT noch einmal eintragen. */
  return es.laufen();
}).then(() => {
  const cfg = JSON.parse(fs.readFileSync(konfig, 'utf8'));
  ok('ein zweiter Lauf traegt dasselbe Geraet NICHT doppelt ein',
    (cfg.adapters || []).filter((a) => a.host === '192.168.0.51').length === 1);

  /*
   * BEWAEHRUNG — ZWEI VERSCHIEDENE FAELLE (ab 1.2.4, Befund 02.08.2026).
   *
   * Bis dahin fuehrten beide zum selben Ergebnis: dauerhafte Sperre. Der zweite Fall war damit
   * eine Falle — ein voellig intaktes Geraet, das beim ersten Versuch zufaellig laenger brauchte
   * (Neustart, wachsender Wiederholabstand, Sensor noch nicht angelegt), war fuer immer
   * ausgesperrt, denn die Sperrliste liegt in einer Datei und wurde nie gealtert.
   */
  meldungen.length = 0;
  es._bewaehrung = [{ id: cfg.adapters[0].id, ip: '192.168.0.51', port: 4601, bis: Date.now() - 1 }];
  es._bewaehrungPruefen();
  ok('hat sich NICHTS gemeldet, wird die Bewaehrung EINMAL verlaengert statt gleich gesperrt',
    es._bewaehrung.length === 1 && es._bewaehrung[0].verlaengert === true,
    JSON.stringify(es._bewaehrung));
  ok('und das Log sagt ausdruecklich, dass das noch KEIN Beweis gegen HL7 ist',
    meldungen.some((m) => /heisst NICHT/.test(m)), meldungen.join(' | ').slice(0, 200));
  ok('der Adapter laeuft waehrend der Verlaengerung weiter',
    JSON.parse(fs.readFileSync(konfig, 'utf8')).adapters[0].enabled !== false);

  /* Zweiter Ablauf: jetzt wird abgeschaltet und gesperrt. */
  meldungen.length = 0;
  es._bewaehrung[0].bis = Date.now() - 1;
  es._bewaehrungPruefen();
  const cfg2 = JSON.parse(fs.readFileSync(konfig, 'utf8'));
  ok('nach der zweiten Frist wird der Adapter wieder ABGESCHALTET',
    cfg2.adapters[0].enabled === false);
  const sperre = JSON.parse(fs.readFileSync(merk, 'utf8')).gesperrt['192.168.0.51:4601'];
  ok('und die Adresse wird gesperrt, damit sie nicht ewig neu eingetragen wird', !!sperre, String(sperre));
  ok('die Sperre traegt ein ABLAUFDATUM (ein Fehlschlag darf nicht fuer immer gelten)',
    /gilt bis \d{4}-\d{2}-\d{2}/.test(String(sperre)), String(sperre));
  ok('der Grund ist der ZUTREFFENDE (nichts gemeldet, nicht "spricht kein HL7")',
    /nicht gemeldet/.test(String(sperre)), String(sperre));

  /* Und der Fall, fuer den die Bewaehrung urspruenglich gebaut wurde: der Adapter WAR verbunden
   * (es gibt einen Registry-Eintrag), hat aber nichts Lesbares geliefert. Dort wird sofort
   * gesperrt, mit dem Verdacht "anderes Protokoll" — der Veta 5 auf 4601. */
  meldungen.length = 0;
  geraeteliste.push({ deviceId: 'stumm', status: 'offline', lastTs: null });
  es._bewaehrung = [{ id: 'stumm', ip: '192.168.0.61', port: 4601, bis: Date.now() - 1 }];
  es._bewaehrungPruefen();
  ok('war der Adapter dagegen VERBUNDEN und lieferte nichts Lesbares, wird SOFORT gesperrt',
    !!JSON.parse(fs.readFileSync(merk, 'utf8')).gesperrt['192.168.0.61:4601']);
  ok('das Log nennt dann den Verdacht "anderes Protokoll" statt eines stillen Abschaltens',
    meldungen.some((m) => /kein HL7/.test(m)), meldungen.join(' | ').slice(0, 200));

  /* Umgekehrt: liefert er Werte, bleibt er. */
  geraeteliste.push({ deviceId: 'bleibt', status: 'active', lastTs: Date.now() });
  es._bewaehrung = [{ id: 'bleibt', ip: '192.168.0.60', port: 4601, bis: Date.now() - 1 }];
  es._bewaehrungPruefen();
  ok('ein Adapter MIT Werten bleibt eingeschaltet',
    !JSON.parse(fs.readFileSync(merk, 'utf8')).gesperrt['192.168.0.60:4601']);

  /* Waehrend einer Narkose wird nicht gesucht — auch nicht ueber laufen(). */
  meldungen.length = 0;
  return es.laufen();
}).then(() => {
  ok('bei aktivem Geraet verschiebt laufen() die Suche statt sie durchzufuehren',
    meldungen.some((m) => /verschoben/.test(m)));
  es.stop();
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (_) {}

  /* ------------------------------------------------------------------ *
   * 7) Das Modul selbst.
   * ------------------------------------------------------------------ */
  console.log('\n 7) Bauform');
  const quelle = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'erstsuche.js'), 'utf8');
  ok('kein dgram/UDP (das ganze Projekt kommt ohne aus)', !/require\(['"]dgram['"]\)/.test(quelle));
  ok('kein require auf registry (die Suche kennt nur die Geraeteliste, die sie bekommt)',
    !/require\(['"]\.\/registry['"]\)/.test(quelle));
  ok('kein require auf cloud', !/require\(['"]\.\/cloud['"]\)/.test(quelle));
  ok('der Nachbar-Port steht NICHT in netscan.DATA_PORTS',
    require('../bridge/src/netscan').DATA_PORTS.indexOf(E.NACHBAR_PORT) < 0);
  ok('der Oberflaechen-Port steht NICHT in netscan.DATA_PORTS',
    require('../bridge/src/netscan').DATA_PORTS.indexOf(E.STATION_PORT) < 0);

  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
}).catch((e) => {
  console.log('  ✗ Ablauf abgebrochen: ' + (e && e.stack || e));
  process.exit(1);
});

/* ---------------------------------------------------------------------------
 * DIE NARKOSE-SPERRE HING AN EINEM 5-SEKUNDEN-FENSTER (Befund 01.08.2026)
 *
 * darfSuchen() zaehlte nur Geraete mit status 'active' — und 'active' ist ein Geraet laut
 * registry.js nur 5 SEKUNDEN nach seinem letzten Paket. Ein LifeVet 10C sendet ab Werk aber nur
 * alle ~30 s. Zwischen zwei Paketen galt der laufende Fall damit als "kein Patient da", und der
 * Suchlauf durfte losklopfen — mitten in der Narkose. Die Sperre, die genau das verhindern sollte,
 * war die meiste Zeit offen.
 * --------------------------------------------------------------------------- */
console.log('\nNarkose-Sperre: der Sendetakt des Geraets darf sie nicht aushebeln');
{
  /* Ein Monitor, der alle 30 s sendet: gerade ist er 'standby', nicht 'active'. Trotzdem haengt
   * ein Patient daran. */
  const zwischenZweiPaketen = E.darfSuchen({ aktiveGeraete: 0, geraeteMitDaten: 1, echteKarten: 1 });
  ok('ein Geraet, das vor 20 s gesendet hat, sperrt weiterhin', zwischenZweiPaketen.ok === false, JSON.stringify(zwischenZweiPaketen));
  ok('und der Grund nennt die Narkose', /Narkose/.test(zwischenZweiPaketen.grund));
  ok('ohne Geraetedaten ist der Weg frei',
    E.darfSuchen({ aktiveGeraete: 0, geraeteMitDaten: 0, echteKarten: 1 }).ok === true);
  /* Rueckfall: ein Aufrufer, der die neue Angabe nicht liefert, darf nicht stillschweigend
   * jede Sperre verlieren. */
  ok('ohne geraeteMitDaten gilt weiterhin aktiveGeraete',
    E.darfSuchen({ aktiveGeraete: 2, echteKarten: 1 }).ok === false);
  ok('die Frist ist benannt und liegt ueber dem langsamsten bekannten Sendetakt (30 s)',
    E.PATIENT_STILL_MS >= 60000, String(E.PATIENT_STILL_MS));
}

