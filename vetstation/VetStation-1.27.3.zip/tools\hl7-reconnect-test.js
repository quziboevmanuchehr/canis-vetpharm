'use strict';
/*
 * hl7-reconnect-test.js — KEINE Log-Flutung bei abwesendem Geraet (Befund 2.2 / 2.3, 21.07.2026).
 *
 * Was war:
 *   • HL7-Client: fest alle 3 s neu verbinden, ZWEI Warnzeilen je Versuch (error + close)
 *     = rund 40 Zeilen pro Minute, solange das Geraet aus ist — also genau im Normalzustand
 *     VOR der Inbetriebnahme.
 *   • Fern-Live: ~2 Fehlerzeilen pro Sekunde. Der Ringpuffer fasst 500 Zeilen — nach gut vier
 *     Minuten war er voll und SAEMTLICHE Verbindungsmeldungen daraus verdraengt.
 * Ausgerechnet das Log, das bei der Inbetriebnahme helfen soll, enthielt nur noch Dauerfehler.
 *
 * ABSCHNITT 4 KAM AM 28.08.2026 DAZU — und er ist der Beweis, dass Abschnitt 3 allein zu wenig
 * prueft: die Zusammenfassung im Logger greift nur, solange nichts anderes DAZWISCHEN loggt.
 * Gemessen an 100 Wiederverbindungen eines Adapters gegen ein Geraet, das annimmt und nie
 * Periodik sendet (der Veta-5-Fall): ohne Fremdlast wuchs der Ring um 1, mit Fremdlast um 200,
 * davon 100 Zeilen "HL7-Client WIEDER verbunden". Hochgerechnet ueber 2600 Zeilen am Tag —
 * dieselbe Groessenordnung wie beim Befund 2.3 vom 21.07.2026 (zwei Zeilen je Verbindungsversuch).
 *
 * Start: node tools/hl7-reconnect-test.js      (laeuft auch in `npm test`)
 */
const net = require('net');
const { HL7Adapter } = require('../bridge/src/adapters/hl7');
const { CloudPublisher } = require('../bridge/src/cloud');
const logger = require('../bridge/src/logger');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
/* Auf das EREIGNIS warten statt auf die Uhr: eine feste Frist misst sonst die Auslastung des
 * Rechners mit (in diesem Projekt schon vorgekommen, siehe ekg-analyse-test.js:228). */
async function warteBis(p, hoechstensMs) {
  const bis = Date.now() + hoechstensMs;
  while (Date.now() < bis) { if (p()) return true; await wait(5); }
  return !!p();
}

async function run() {
  console.log('VetStation — Diagnose-Log bleibt bei abwesendem Geraet brauchbar\n');

  /* ---------------- 1) HL7-Client gegen eine tote Adresse ---------------- */
  console.log('HL7-Client, Geraet ausgeschaltet:');
  const zeilen = [];
  const log = {
    info: (s, m) => zeilen.push('info|' + s + '|' + m),
    warn: (s, m) => zeilen.push('warn|' + s + '|' + m),
    error: (s, m) => zeilen.push('err|' + s + '|' + m),
  };
  // 127.0.0.1 auf einem sicher freien Port -> jeder Versuch wird sofort abgelehnt (ECONNREFUSED).
  const a = new HL7Adapter({ id: 'tot', mode: 'client', host: '127.0.0.1', port: 65123 }, { log: log, emit: () => {} });
  await a.connect();
  await wait(2500);          // in dieser Zeit haette der alte Code ~2 Versuche x 2 Zeilen geschrieben
  const nachher = zeilen.length;
  a.dispose();

  ok('hoechstens EINE Zeile, egal wie oft es fehlschlaegt', nachher <= 1, nachher + ' Zeilen: ' + zeilen.join(' // '));
  ok('die eine Zeile erklaert die Lage im Klartext',
    zeilen.some((z) => /antwortet nicht/.test(z)), zeilen.join(' // '));
  ok('sie sagt auch, dass weiter probiert wird', zeilen.some((z) => /versucht es weiter/.test(z)));
  ok('sie kuendigt die Unterdrueckung an', zeilen.some((z) => /unterdrueckt/.test(z)));
  ok('der Abstand waechst (nicht mehr fest 3 s)', a.wartenMs > 3000, 'wartenMs=' + a.wartenMs);
  ok('der Abstand ist gedeckelt', a.MAX_WARTEN === 60000);
  ok('error und close schreiben nicht mehr je eine Zeile',
    zeilen.filter((z) => /Client-Fehler/.test(z)).length === 0);

  /* ---------------- 2) Fern-Live gegen eine nicht existierende Datenbank ---------------- */
  console.log('\nFern-Live, Datenbank nicht angelegt (HTTP 404):');
  const cz = [];
  const clog = { info: (s, m) => cz.push('info|' + m), warn: (s, m) => cz.push('warn|' + m), error: (s, m) => cz.push('err|' + m) };
  const c = new CloudPublisher({
    enabled: true, provider: 'firebase', apiKey: 'x',
    dbUrl: 'http://127.0.0.1:65124', code: 'test', minIntervalMs: 1,
  }, { log: clog });
  c.start();

  ok('Konfigurationsfehler werden als solche erkannt (HTTP 404)',
    CloudPublisher._istKonfigFehler('HTTP 404: not found') === true);
  ok('voruebergehende Fehler NICHT (die heilen sich selbst)',
    CloudPublisher._istKonfigFehler('Zeitueberschreitung') === false);

  // Drei Fehlschlaege erzwingen (die Adresse nimmt niemand an -> ECONNREFUSED, kein Konfigfehler).
  // Fuer den Konfigfall die Fehlerbehandlung direkt fuettern:
  c._fehler(new Error('HTTP 404: Not Found'));
  const nachErstem = c.backoffMs;
  c._fehler(new Error('HTTP 404: Not Found'));
  ok('die Wartezeit verdoppelt sich', c.backoffMs === nachErstem * 2, nachErstem + ' -> ' + c.backoffMs);
  c._fehler(new Error('HTTP 404: Not Found'));
  ok('nach drei Konfigurationsfehlern schaltet Fern-Live sich selbst ab', c.abgeschaltet === true);
  ok('und sagt im Klartext WARUM', /noch nicht angelegt/.test(String(c.abschaltGrund)), String(c.abschaltGrund));
  ok('die Meldung stellt klar, dass die Geraete davon NICHT betroffen sind',
    cz.some((z) => /betrifft NICHT die Geraeteverbindung/.test(z)));
  ok('nach der Abschaltung wird nicht weiter geschrieben', (c.publish([]), c.inFlight === false));
  ok('der Status meldet die Abschaltung nach aussen', c.status().abgeschaltet === true);
  c.stop();

  /* ---------------- 3) Der Logger selbst fasst Wiederholungen zusammen ---------------- */
  console.log('\nLogger fasst identische Meldungen zusammen:');
  logger._reset();
  for (let i = 0; i < 200; i++) logger.warn('test', 'immer dieselbe Meldung');
  ok('200 identische Meldungen erzeugen EINEN Eintrag', logger.recent(500).length === 1,
    logger.recent(500).length + ' Eintraege');
  ok('der Eintrag zaehlt die Wiederholungen mit', logger.recent(1)[0].wiederholungen === 199,
    String(logger.recent(1)[0].wiederholungen));
  logger.warn('test', 'etwas anderes');
  const alle = logger.recent(500);
  ok('bei Themenwechsel wird die Serie mit einer Zeile abgeschlossen',
    alle.length === 3 && /199× wiederholt/.test(alle[1].msg), alle.map((x) => x.msg).join(' // '));
  ok('der Ringpuffer wird dadurch NICHT mehr geflutet', alle.length < 10);
  ok('verschiedene Meldungen werden weiterhin einzeln festgehalten',
    (logger._reset(), logger.warn('a', '1'), logger.warn('a', '2'), logger.warn('a', '3'), logger.recent(10).length === 3));
  ok('logger.once() meldet nur beim ersten Mal',
    (logger._reset(), logger.once('k', 'info', 'a', 'nur einmal'), logger.once('k', 'info', 'a', 'nur einmal'),
     logger.recent(10).length === 1));
  logger._reset();

  /* ---------------- 4) Wiederverbindungen fluten das Log auch mit Fremdlast nicht ---------------- */
  /*
   * ANLASS (28.08.2026): die Zusammenfassung aus Abschnitt 3 greift NUR, solange nichts anderes
   * dazwischen loggt. Gemessen an 100 Wiederverbindungen desselben Adapters: ohne Fremdlast
   * wuchs der Ring um 1, MIT Fremdlast um 200 — davon 100 Zeilen "HL7-Client WIEDER verbunden".
   * Genau das ist der Betriebsfall (ein Geraet, das auf 4601 antwortet und nie Periodik sendet,
   * laesst den Wachhund alle 30 s neu verbinden, und der Wachhund loggt selbst dazwischen).
   * Deshalb hat die Zeile seither eine eigene Bremse; hier wird nachgemessen, dass sie greift.
   *
   * Die Wiederverbindung wird ausgeloest wie vom Wachhund (wacheNeustart=true, sock.destroy()),
   * nur der Abstand ist auf 5 ms gestellt — mit den echten 30 s liefe dieser Abschnitt 50 min.
   */
  console.log('\n100 Wiederverbindungen, Fremdlast dazwischen:');
  const srv = net.createServer(() => { /* annehmen und schweigen: der Veta-5-Fall */ });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  logger._reset();
  const flap = new HL7Adapter(
    { id: 'veta5', mode: 'client', host: '127.0.0.1', port: srv.address().port, pdsStrict: true },
    { log: logger, emit: () => {} });
  await flap.connect();
  await warteBis(() => flap.connected, 5000);
  const vorher = logger.recent(500).length;
  let runden = 0;
  /* Der Logger schreibt jede Zeile auch auf die Konsole. 100 Fremdlastzeilen wuerden die
   * Ausgabe des Sammellaufs unlesbar machen — gemessen wird ohnehin am Ringpuffer. */
  const echtesLog = console.log, echterFehler = console.error;
  console.log = () => {}; console.error = () => {};
  for (let i = 0; i < 100; i++) {
    flap.wacheNeustart = true;         // so trennt der Wachhund
    flap.wartenMs = 5;
    try { flap.sock.destroy(); } catch (_) {}
    await warteBis(() => !flap.connected, 3000);
    logger.info('fremd', 'Fremdlast Nr. ' + i);   // etwas anderes dazwischen — der ganze Anlass
    if (await warteBis(() => flap.connected, 5000)) runden++;
  }
  console.log = echtesLog; console.error = echterFehler;
  const alle4 = logger.recent(500);
  const wieder = alle4.filter((z) => /WIEDER verbunden/.test(z.msg)).length;
  const zuwachs = alle4.length - vorher;
  flap.dispose();
  srv.close();
  logger._reset();

  ok('die 100 Wiederverbindungen haben wirklich stattgefunden (sonst prueft nichts)',
    runden === 100 && flap.wiederRunden === 100, 'runden=' + runden + ', wiederRunden=' + flap.wiederRunden);
  ok('sie erzeugen KEINE 100 Zeilen mehr', wieder <= 5, wieder + ' Zeilen "WIEDER verbunden"');
  ok('die ersten Male stehen weiterhin im Klartext da (nicht alles verschluckt)', wieder >= 1);
  ok('der Ringzuwachs ist im Wesentlichen die Fremdlast selbst', zuwachs <= 110,
    'Ringzuwachs ' + zuwachs + ' bei 100 Fremdlastzeilen');
  ok('die unterdrueckten Faelle sind nicht verloren, sie werden mitgezaehlt',
    flap.wiederStumm > 90, 'wiederStumm=' + flap.wiederStumm);

  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
}

run().catch((e) => { console.error('Testfehler:', e); process.exit(1); });
