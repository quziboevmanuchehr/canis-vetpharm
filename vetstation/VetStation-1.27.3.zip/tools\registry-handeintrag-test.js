'use strict';
/*
 * registry-handeintrag-test.js — ein Handeintrag darf die MESSWERTE nicht loeschen.
 *
 * DER BEFUND, 30.08.2026, in der Praxis am laufenden Geraet.
 * Der Tierarzt sah "keine Werte", waehrend der Mindray uMEC12 ununterbrochen HF 163, SpO2 96,
 * Puls 78 und AF 48 sendete. Die Auswertung schlug daraufhin Herzstillstand und CPR vor - bei
 * einem wachen Tier. Das ist der gefaehrlichste Ausgang, den diese Station nehmen kann: nicht
 * eine falsche Zahl, sondern gar keine, mit einer Handlungsempfehlung obendrauf.
 *
 * URSACHE (registry.js, gleicherPatient). Die Bedingung fragte, ob es UEBERHAUPT einen
 * Handeintrag gibt - nicht, ob er einen ANDEREN Patienten benennt. this.meta traegt aber drei
 * verschiedene Dinge: patientId (eine Zuordnung), species und weightKg (Angaben ZUM SELBEN
 * Patienten). Wer im Bild die Tierart "Hund" waehlte, fuellte this.meta; von da an galt jede
 * Nachricht als Patientenwechsel, rec.vitalHold wurde jedes Mal geleert, und weil das Geraet
 * seine Zahlen in Schueben sendet und danach Nachrichten ohne Zahlen, ueberlebte kein Wert bis
 * zum naechsten Rundruf. Gemessen: 171 Abfragen in 12 s, null davon mit Werten.
 *
 * WAS DIESER TEST FESTSCHREIBT:
 *   1. Ein Handeintrag zur TIERART loescht keine Werte.  (der Anlass)
 *   2. Ein Handeintrag zum GEWICHT ebenso wenig.
 *   3. Die Werte ueberleben Nachrichten OHNE Zahlen - genau dafuer gibt es den Haltespeicher.
 *   4. GEGENPROBE: ein wirklicher Patientenwechsel (andere ID) loescht sie SEHR WOHL. Ohne diese
 *      Haelfte bestuende der Test auch dann, wenn der Haltespeicher gar nichts mehr verwirft -
 *      und dann truege er die Werte des vorigen Tieres in die naechste Narkose.
 *   5. Die Angaben selbst (Tierart, Gewicht) kommen weiterhin an. Sonst waere der Fehler nur
 *      gegen einen anderen getauscht.
 *
 * GEMESSEN WIRD AN DEN ECHTEN MODULEN, mit echten Geraetenachrichten - nicht an einem Nachbau
 * der Bedingung. Ein Test, der die Regel nachbaut, prueft nur sich selbst.
 *
 * Start:  node tools/registry-handeintrag-test.js
 */
const path = require('path');
const { Registry } = require(path.join(__dirname, '..', 'bridge', 'src', 'registry.js'));
const { parseHL7Message } = require(path.join(__dirname, '..', 'bridge', 'src', 'adapters', 'hl7.js'));

const still = { info() {}, warn() {}, error() {}, debug() {} };
let ok = 0; const fehler = [];
function pruef(was, bedingung, zusatz) {
  if (bedingung) { ok++; console.log('  + ' + was); }
  else { fehler.push(was); console.log('  FEHLGESCHLAGEN: ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}

/* Woertlich so, wie der uMEC12 Vet sie am 30.08.2026 gesendet hat: die Zahlen kommen einzeln,
 * danach Nachrichten ganz ohne Zahlen. Genau diese Folge deckt den Fehler auf. */
const OPT = { deviceId: 'umec12-abfrage', model: 'uMEC12 Vet', role: 'combo', species: null, weightKg: null, patientId: null };
const HF    = 'MSH|^~\\&|||||||ORU^R01|204|P|2.3.1|\rOBX||NM|101^HF|2101|163||||||F\r';
const SPO2  = 'MSH|^~\\&|||||||ORU^R01|204|P|2.3.1|\rOBX||NM|160^SpO2|2103|96||||||F\rOBX||NM|161^PF|2103|78||||||F\r';
const RESP  = 'MSH|^~\\&|||||||ORU^R01|204|P|2.3.1|\rOBX||NM|151^RESP|2102|48||||||F\r';
const OHNE1 = 'MSH|^~\\&|||||||ORU^R01|56|P|2.3.1|\rOBX||CE|4||20^EKG lernen||||||F|\r';
const OHNE2 = 'MSH|^~\\&|||||||ORU^R01|56|P|2.3.1|\rOBX||CE|3||37^EKG-Rauschen||||||F|\r';

function lauf(meta, folge, opt) {
  const r = new Registry({ log: still });
  if (meta) r.meta['umec12-abfrage'] = meta;
  folge.forEach(function (t) {
    const f = parseHL7Message(t, opt || OPT, function () {});
    if (f) r.ingest(f);
  });
  const p = (r.getPatients() || [])[0] || {};
  const d = (r.getDevices() || [])[0] || {};
  return { vitals: p.vitals || {}, werte: d.werteAnzahl, species: d.species, weightKg: d.weightKg };
}

/* Die Folge endet ABSICHTLICH mit zwei Nachrichten ohne Zahlen: so sieht die Oberflaeche das
 * Geraet die meiste Zeit, und nur so faellt ein geleerter Haltespeicher ueberhaupt auf. */
const FOLGE = [HF, SPO2, RESP, OHNE1, OHNE2];

console.log('\nVetStation - ein Handeintrag darf keine Messwerte loeschen\n');

console.log('1) Ohne jeden Handeintrag (der Vergleichsfall):');
const a = lauf(null, FOLGE);
pruef('die Werte ueberleben die Nachrichten ohne Zahlen',
  a.vitals.spo2 === 96 && a.vitals.af === 48 && typeof a.vitals.hr === 'number',
  JSON.stringify(a.vitals));
pruef('das Geraet meldet sie auch als gezaehlte Werte', a.werte >= 3, String(a.werte));

console.log('\n2) DER ANLASS: Tierart von Hand gesetzt');
const b = lauf({ species: 'hund' }, FOLGE);
pruef('die Werte sind trotzdem da', b.vitals.spo2 === 96 && b.vitals.af === 48, JSON.stringify(b.vitals));
pruef('… und es sind dieselben wie ohne Handeintrag',
  JSON.stringify(b.vitals) === JSON.stringify(a.vitals),
  JSON.stringify(b.vitals) + ' gegen ' + JSON.stringify(a.vitals));
pruef('die Tierart kommt dabei weiterhin an', b.species === 'hund', String(b.species));

console.log('\n3) Gewicht von Hand gesetzt');
const c = lauf({ species: 'hund', weightKg: 5 }, FOLGE);
pruef('auch dann sind die Werte da', c.vitals.spo2 === 96 && c.vitals.af === 48, JSON.stringify(c.vitals));
pruef('und das Gewicht kommt an', c.weightKg === 5, String(c.weightKg));

console.log('\n4) GEGENPROBE: ein WIRKLICHER Patientenwechsel muss loeschen');
{
  /* Erst Werte unter Patient A sammeln, dann meldet das Geraet Patient B. Die Werte von A
   * duerfen NICHT bei B stehenbleiben - das waere die gefaehrlichere Haelfte des Fehlers. */
  const r = new Registry({ log: still });
  const optA = Object.assign({}, OPT, { patientId: 'A1' });
  const optB = Object.assign({}, OPT, { patientId: 'B2' });
  [HF, SPO2, RESP].forEach(function (t) { const f = parseHL7Message(t, optA, function () {}); if (f) r.ingest(f); });
  const vorher = ((r.getPatients() || []).find(function (p) { return p.patientId === 'A1'; }) || {}).vitals || {};
  /* Jetzt Patient B, und zwar mit einer Nachricht OHNE Zahlen: gaebe es keinen Riegel, trueg B
   * die Werte von A. */
  const fb = parseHL7Message(OHNE1, optB, function () {});
  if (fb) r.ingest(fb);
  const nachher = ((r.getPatients() || []).find(function (p) { return p.patientId === 'B2'; }) || {}).vitals || {};
  pruef('Patient A hatte Werte (sonst prueft die Gegenprobe nichts)',
    vorher.spo2 === 96, JSON.stringify(vorher));
  pruef('Patient B erbt sie NICHT',
    nachher.spo2 == null && nachher.af == null, JSON.stringify(nachher));
}

console.log('\n4b) Ein Geraet, das seine Kennung nur MANCHMAL mitsendet');
{
  /*
   * DIE LUECKE DER ERSTEN BEHEBUNG. Sie verglich stur "Kennung jetzt == Kennung vorher" - und
   * loeste damit bei jeder Nachricht OHNE Kennung einen Wechsel aus. Genau so baut das LifeVet
   * seine Nachrichten: die Datennachricht traegt die PID, die Alarmnachricht nicht. Die
   * Fehlerklasse waere damit nur verschoben statt behoben gewesen, und zwar auf ein Geraet,
   * das heute schon angeschlossen wird.
   */
  const r = new Registry({ log: still });
  const mitId = Object.assign({}, OPT, { patientId: 'A1' });
  const f1 = parseHL7Message(SPO2, mitId, function () {}); if (f1) r.ingest(f1);
  /* Jetzt eine Nachricht OHNE Kennung UND ohne Zahlen - so wie sie wirklich kommt. */
  const f2 = parseHL7Message(OHNE1, OPT, function () {}); if (f2) r.ingest(f2);
  const p = ((r.getPatients() || []).find(function (x) { return x.patientId === 'A1'; }) || {});
  pruef('die Werte ueberleben eine Nachricht ohne Kennung',
    (p.vitals || {}).spo2 === 96, JSON.stringify(p.vitals));
  pruef('… und die Patientenkennung ebenfalls',
    p.patientId === 'A1', String(p.patientId));
}

console.log('\n5) GEGENPROBE: eine von Hand gesetzte, ABWEICHENDE Patienten-ID loescht ebenfalls');
{
  const r = new Registry({ log: still });
  const optA = Object.assign({}, OPT, { patientId: 'A1' });
  [HF, SPO2, RESP].forEach(function (t) { const f = parseHL7Message(t, optA, function () {}); if (f) r.ingest(f); });
  /* Das Geraet meldet nichts mehr, aber jemand ordnet das Geraet von Hand einem anderen zu. */
  r.meta['umec12-abfrage'] = { patientId: 'C3' };
  const f = parseHL7Message(OHNE1, OPT, function () {});
  if (f) r.ingest(f);
  const p = (r.getPatients() || [])[0] || {};
  pruef('nach der Umzuordnung stehen die alten Werte nicht mehr da',
    (p.vitals || {}).spo2 == null, JSON.stringify(p.vitals));
}

console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + ')');
  process.exit(1);
}
console.log('ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
