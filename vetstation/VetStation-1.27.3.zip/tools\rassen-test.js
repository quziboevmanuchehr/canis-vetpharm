'use strict';
/*
 * rassen-test.js — sichert den Rassekatalog samt Erstwahl-Narkose und Rettungswegen.
 *
 * Wunsch des Nutzers (03.08.2026): das Modul soll ALLE Rassen aller gefuehrten Tierarten kennen,
 * beim Tippen im Rassefeld sofort die passenden Treffer der GEWAEHLTEN Tierart zeigen, und beim
 * Bestaetigen einer Gabe die rassespezifischen Erbkrankheiten und Risiken erkennen, davor warnen,
 * die Narkose erster Wahl vorschlagen und sagen, wie der Patient wieder stabil wird.
 *
 * Was dieser Test absichert — und warum genau das:
 *  - Ein Verweis auf eine Erkrankung/ein Protokoll, das es nicht gibt, faellt im Browser NICHT
 *    auf: die Karte bleibt einfach leer. Deshalb werden alle Schluessel gegengeprueft.
 *  - Eine Rasse, die zweimal im Katalog steht, ist gefaehrlicher als eine fehlende: der Tierarzt
 *    waehlt die eine Fassung, und die Warnung haengt an der anderen.
 *  - Die Warnung muss den Weg bis ins Protokoll gehen (App -> Shell -> Bridge). Faellt ein Glied
 *    aus, sieht der Bildschirm richtig aus und im Protokoll fehlt sie.
 *
 * Start: node tools/rassen-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const VB = require(path.join(WURZEL, 'ui/shared/breed-genetics.js'));
require(path.join(WURZEL, 'ui/shared/narkose-risiko.js'));
require(path.join(WURZEL, 'ui/shared/breed-katalog.js'));

const app = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
const shell = fs.readFileSync(path.join(WURZEL, 'ui/vetstation-live.js'), 'utf8');
const registry = fs.readFileSync(path.join(WURZEL, 'bridge/src/registry.js'), 'utf8');
const A = require(path.join(WURZEL, 'bridge/src/anaes')).loadAnaes();

let pass = 0, fail = 0, warn = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function note(n) { warn++; console.log('  ⚠ ' + n); }

console.log('Rassekatalog, Erstwahl-Narkose und Rettungswege — Selbsttest\n');

/* ------------------------------------------------------------------ 1) Umfang */
console.log('1) Umfang und Abdeckung der Tierarten:');
const proArt = VB.speciesWithBreeds();
ok('Rassekatalog geladen (' + VB.BREEDS.length + ' Rassen)', VB.BREEDS.length >= 400, String(VB.BREEDS.length));
A.species.forEach(function (s) {
  ok(s.name + ' hat Rassen im Katalog (' + (proArt[s.id] || 0) + ')', (proArt[s.id] || 0) > 0);
});
ok('Hund: mindestens 250 Rassen', (proArt.hund || 0) >= 250, String(proArt.hund));
ok('Katze: mindestens 40 Rassen', (proArt.katze || 0) >= 40, String(proArt.katze));
ok('Kaninchen: mindestens 40 Rassen', (proArt.kaninchen || 0) >= 40, String(proArt.kaninchen));

/* --------------------------------------------------------- 2) Innere Stimmigkeit */
console.log('\n2) Innere Stimmigkeit (kein toter Verweis, keine Doppelrasse):');
const ids = {}, doppelIds = [];
VB.BREEDS.forEach(function (b) { if (ids[b.id]) doppelIds.push(b.id); ids[b.id] = 1; });
ok('jede Rasse-Kennung kommt genau einmal vor', doppelIds.length === 0, doppelIds.slice(0, 5).join(', '));

const namen = {}, doppelNamen = [];
VB.BREEDS.forEach(function (b) {
  const k = b.sp + '|' + VB.norm(b.name);
  if (namen[k]) doppelNamen.push(b.sp + ' ' + b.name);
  namen[k] = 1;
});
ok('kein Rassename doppelt innerhalb einer Tierart', doppelNamen.length === 0, doppelNamen.slice(0, 5).join(', '));

/* Beinahe-Doppelte: „Collie Kurzhaar" und „Kurzhaarcollie" sind dasselbe Tier. Solche Paare
 * ganz zu verhindern ist nicht moeglich (Miniature Australian / American Shepherd sind
 * derselbe Hund unter zwei Verbandsnamen). Gefaehrlich ist nur der Fall, dass die eine Fassung
 * eine Warnung traegt und die andere nicht — der Tierarzt waehlt eine und sieht die halbe
 * Wahrheit. Genau das wird hier geprueft. */
const aliasIx = {};
VB.BREEDS.forEach(function (b) {
  (b.aliases || []).forEach(function (a) { const k = b.sp + '|' + VB.norm(a); (aliasIx[k] = aliasIx[k] || []).push(b.id); });
});
const ungleich = [];
VB.BREEDS.forEach(function (b) {
  const k = b.sp + '|' + VB.norm(b.name);
  (aliasIx[k] || []).forEach(function (id) {
    if (id === b.id) return;
    const z = VB.byId(id); if (!z) return;
    const a = (b.conditions || []).slice().sort().join(','), c = (z.conditions || []).slice().sort().join(',');
    if (a !== c) ungleich.push(b.name + ' vs ' + z.name);
  });
});
ok('Rassen, die dasselbe Tier meinen, tragen dieselben Erkrankungen', ungleich.length === 0, ungleich.slice(0, 4).join(' | '));

const ohneFeld = VB.BREEDS.filter(function (b) { return !b.name || !b.sp || !b.id; });
ok('jede Rasse hat Kennung, Name und Tierart', ohneFeld.length === 0, ohneFeld.length + ' ohne');

const bekannteArten = {}; A.species.forEach(function (s) { bekannteArten[s.id] = 1; });
const fremdeArt = VB.BREEDS.filter(function (b) { return !bekannteArten[b.sp]; });
ok('keine Rasse zeigt auf eine Tierart, die das Modul nicht kennt', fremdeArt.length === 0,
  fremdeArt.slice(0, 5).map(function (b) { return b.sp + '/' + b.name; }).join(', '));

const toteCond = [];
VB.BREEDS.forEach(function (b) {
  (b.conditions || []).forEach(function (k) { if (!VB.CONDITIONS[k]) toteCond.push(b.name + ' -> ' + k); });
  (b.groups || []).forEach(function (k) { if (!VB.GROUPS[k]) toteCond.push(b.name + ' -> Gruppe ' + k); });
});
ok('jede Rasse zeigt nur auf vorhandene Erkrankungen/Gruppen', toteCond.length === 0, toteCond.slice(0, 5).join(' | '));

const toteProt = [];
Object.keys(VB.CONDITIONS).forEach(function (k) {
  const c = VB.CONDITIONS[k];
  [].concat(c.protocol || []).forEach(function (p) { if (!VB.PROTOCOLS[p]) toteProt.push(k + ' -> Protokoll ' + p); });
  [].concat(c.rescue || []).forEach(function (r) { if (!VB.RESCUE[r]) toteProt.push(k + ' -> Rettung ' + r); });
});
Object.keys(VB.GROUPS).forEach(function (k) {
  const g = VB.GROUPS[k];
  [].concat(g.protocol || []).forEach(function (p) { if (!VB.PROTOCOLS[p]) toteProt.push('Gruppe ' + k + ' -> Protokoll ' + p); });
  [].concat(g.rescue || []).forEach(function (r) { if (!VB.RESCUE[r]) toteProt.push('Gruppe ' + k + ' -> Rettung ' + r); });
});
ok('jede Erkrankung/Gruppe zeigt nur auf vorhandene Protokolle und Rettungswege',
  toteProt.length === 0, toteProt.slice(0, 6).join(' | '));

const leereRettung = Object.keys(VB.RESCUE).filter(function (k) { return !(VB.RESCUE[k].schritte || []).length; });
ok('jeder Rettungsweg hat mindestens einen Schritt', leereRettung.length === 0, leereRettung.slice(0, 5).join(', '));

/* =============================================================================================
 * DIE ZWISCHENFALLKARTEN FUEHREN JETZT SELBST RETTUNGSWEGE (24.08.2026)
 *
 * Die Wege lagen seit jeher im Katalog, waren aber nur ueber das RASSEprofil erreichbar — also
 * ueber einen anderen Reiter, den im Zwischenfall niemand aufschlaegt. Seither traegt die Karte
 * sie selbst. Geprueft wird hier, WEIL zwei stille Ausfaelle moeglich sind:
 *   1. ein toter Verweis: die Karte zeigt auf einen Weg, den es nicht gibt -> nichts erscheint
 *   2. die Artfilterung in rescueFor(): ein Weg mit eigener Art faellt fuer alle anderen Arten
 *      heraus. Traegt eine Karte NUR artgebundene Wege, ist sie fuer die meisten Tiere leer —
 *      und zwar wortlos. Genau das ist bei 'frettchen-hypoglykaemie' angelegt: die automatische
 *      Variantensuche heisst <key>-<art>, also findet 'hypoglykaemie' beim Frettchen NIE den
 *      Frettchen-Weg. Deshalb wird hier je Karte UND je Art gezaehlt, nicht nur je Karte.
 * ============================================================================================= */
const ARTEN = ['hund', 'katze', 'kaninchen', 'meerschwein', 'reptil', 'frettchen',
  'ratte', 'maus', 'hamster', 'vogel', 'pferd', 'chinchilla'];
/* Mit Absicht ohne Wege: keiner der vorhandenen Rettungswege deckt ihre Ursachen (flache
 * Narkose, Hyperkapnie, Atelektase, zu leichte Beatmung). Lieber leer als schwach gefuellt —
 * steht die Karte eines Tages doch mit Wegen da, faellt dieser Test auf und verlangt eine
 * bewusste Entscheidung statt eines Versehens. */
const OHNE_WEGE = ['tachypnoe'];
const toteWege = [], stummeArten = [], unerwartetLeer = [];
(A.incidents || []).forEach(function (i) {
  const keys = i.rescue || [];
  keys.forEach(function (k) { if (!VB.RESCUE[k]) toteWege.push(i.id + ' -> ' + k); });
  if (!keys.length) { if (OHNE_WEGE.indexOf(i.id) < 0) unerwartetLeer.push(i.id); return; }
  if (OHNE_WEGE.indexOf(i.id) >= 0) { unerwartetLeer.push(i.id + ' (steht als absichtlich leer)'); return; }
  ARTEN.forEach(function (a) {
    if (!VB.rescueFor(keys, a).length) stummeArten.push(i.id + '/' + a);
  });
});
ok('jede Zwischenfallkarte zeigt nur auf vorhandene Rettungswege',
  toteWege.length === 0, toteWege.slice(0, 6).join(' | '));
ok('die Liste der absichtlich leeren Karten stimmt noch',
  unerwartetLeer.length === 0, unerwartetLeer.join(', '));
ok('keine Karte ist fuer eine Tierart stumm', stummeArten.length === 0,
  stummeArten.slice(0, 8).join(', ') + ' — dort traegt die Karte nur artgebundene Wege');
ok('zehn der elf Karten fuehren Wege',
  (A.incidents || []).filter(function (i) { return (i.rescue || []).length; }).length === 10,
  'gefunden: ' + (A.incidents || []).filter(function (i) { return (i.rescue || []).length; }).length);

/* Die Artfilterung muss auch WIRKEN, nicht nur nicht stoeren: der Kaninchen-Weg gehoert dem
 * Kaninchen und sonst niemandem. Ohne diese Pruefung waere ein rescueFor(), das die Art
 * ignoriert, gruen — und der Hund bekaeme eine Kaninchen-Anleitung. */
const braKan = VB.rescueFor(['alpha2-ueberdosis', 'kaninchen-notfall'], 'kaninchen').map(function (r) { return r.key; });
const braHund = VB.rescueFor(['alpha2-ueberdosis', 'kaninchen-notfall'], 'hund').map(function (r) { return r.key; });
ok('ein artgebundener Weg erscheint bei SEINER Art', braKan.indexOf('kaninchen-notfall') >= 0);
ok('… und bei keiner anderen', braHund.indexOf('kaninchen-notfall') < 0, braHund.join(','));

/* Die Anzeige: eingeklappt, in derselben Zeichenkette, ohne eigene Farbe. */
ok('renderProto haengt den Rettungsblock an', /html\+=rettungHtml\(i\);/.test(app));
ok('… VOR box.innerHTML, sonst waere er beim naechsten Takt weg',
  /html\+=rettungHtml\(i\);[\s\S]{0,80}box\.innerHTML=html;/.test(app));
ok('der Block startet eingeklappt', /<details class="proto-rettung">/.test(app)
  && !/<details class="proto-rettung" open/.test(app));
ok('er benutzt die vorhandenen Klassen statt neuer Farben',
  /class="proto-rettung"><summary class="sec-h"/.test(app) && /plan-card plan-rettung/.test(app));
ok('rettungHtml haelt sich zurueck, wenn es nichts zu zeigen gibt',
  /if\(!VB\|\|!VB\.rescueFor\|\|!i\|\|!i\.rescue\|\|!i\.rescue\.length\) return '';/.test(app));

const leereProt = Object.keys(VB.PROTOCOLS).filter(function (k) {
  const p = VB.PROTOCOLS[k];
  return !(p.praemed || p.einleitung || p.erhalt || p.ziele);
});
ok('jedes Protokoll sagt wenigstens etwas zu Prämedikation/Einleitung/Erhalt/Zielen',
  leereProt.length === 0, leereProt.slice(0, 5).join(', '));

const ohneText = Object.keys(VB.CONDITIONS).filter(function (k) { return !VB.CONDITIONS[k].short; });
ok('jede Erkrankung hat eine Kurzbeschreibung', ohneText.length === 0, ohneText.slice(0, 5).join(', '));

/* Der gefaehrlichste stille Fehler: ein Meerschweinchen bekommt den Kaninchenplan, ein Perser den
 * Hunde-BOAS-Plan, ein Frettchen das Hunde-DCM-Protokoll. Auf dem Bildschirm sieht das voellig
 * normal aus — es steht ja ein vollstaendiger Narkoseplan da, nur eben der einer anderen Tierart.
 * Genau das ist beim Bauen dreimal passiert, deshalb wird es hier hart geprueft. */
const artfremd = [];
VB.BREEDS.forEach(function (b) {
  VB.plan(b).erstwahl.forEach(function (e) {
    const p = VB.PROTOCOLS[e.key];
    if (p && p.sp && p.sp !== b.sp) artfremd.push(b.sp + '/' + b.name + ' bekommt ' + e.key + ' (' + p.sp + ')');
  });
});
ok('keine Rasse bekommt den Narkoseplan einer ANDEREN Tierart', artfremd.length === 0, artfremd.slice(0, 5).join(' | '));

/* Dasselbe fuer die RETTUNGSWEGE — und das ist der Fall, der wirklich passiert ist: die Maine Coon
 * traegt die ABCB1-Variante der Katze, landete darueber in der Gruppe „MDR1" und bekam von dort
 * den Ablauf „Makrozyklisches Lakton beim MDR1-HUND" angehaengt. Ein Notfallablauf der falschen
 * Tierart ist schlimmer als keiner: er liest sich vollkommen plausibel. */
/* BEIDE LISTEN PRUEFEN (nachgezogen 15.08.2026): plan() liefert seit der Trennung die
 * rassespezifischen Wege in .rettung und die artweiten in .rettungArt. Wer nur .rettung
 * ansieht, prueft die Haelfte — und meldete hier prompt 278 Rassen als "ohne Rettungsweg",
 * obwohl sie welche haben. Die Aussage der beiden Pruefungen ist unveraendert. */
function alleWege(b) { const p = VB.plan(b); return p.rettung.concat(p.rettungArt || []); }

const artfremdR = [];
VB.BREEDS.forEach(function (b) {
  alleWege(b).forEach(function (r) {
    const x = VB.RESCUE[r.key];
    if (x && x.sp && x.sp !== b.sp) artfremdR.push(b.sp + '/' + b.name + ' bekommt ' + r.key + ' (' + x.sp + ')');
  });
});
ok('keine Rasse bekommt den Rettungsweg einer ANDEREN Tierart', artfremdR.length === 0, artfremdR.slice(0, 5).join(' | '));

/* Jede Rasse braucht einen Weg zurueck. Die artweiten Ablaeufe (Reanimation, Hypothermie,
 * Unterzucker, Regurgitation, wacht nicht auf) gelten fuer jedes Tier — ohne sie stuende bei den
 * 200 Hunderassen ohne eingetragene Erbkrankheit unter „stabilisieren" nichts, ausgerechnet dort,
 * wo im Ernstfall nachgesehen wird. */
const ohneRettung = VB.BREEDS.filter(function (b) { return !alleWege(b).length; });
ok('jede Rasse hat mindestens einen Rettungsweg', ohneRettung.length === 0,
  ohneRettung.length + ' ohne, z. B. ' + ohneRettung.slice(0, 3).map(function (b) { return b.sp + '/' + b.name; }).join(', '));

/* NEU 15.08.2026: die artweiten Wege duerfen nicht mehr verdraengt werden koennen.
 * Vorher standen sie in derselben gedeckelten Liste und fielen bei den Rassen mit vielen
 * eigenen Eintraegen heraus — gemessen erreichte die Reanimation nur 497 von 747 Rassen.
 * Diese Pruefung haelt den Zustand fest: bei JEDEM Hund und JEDER Katze muessen alle
 * Artwege ankommen, unabhaengig davon, wie viele rassespezifische dazukommen. */
const artFehlt = [];
VB.BREEDS.forEach(function (b) {
  if (b.sp !== 'hund' && b.sp !== 'katze') return;
  const g = VB.GROUPS['art-' + b.sp];
  const soll = (g && g.rescue) ? [].concat(g.rescue) : [];
  /* IN WELCHER DER BEIDEN LISTEN, IST EGAL — verloren ist nur, was in KEINER steht.
   * Ein artweiter Weg kann auch von einer Erkrankung genannt werden (der Collie bekommt
   * 'opioid-ueberhang' ueber MDR1); rescueAdd entdoppelt ihn dann in die rassespezifische
   * Liste. Die erste Fassung dieser Pruefung verlangte ihn in rettungArt und meldete
   * deshalb 111 Rassen als betroffen, obwohl sie den Weg haben. */
  const ist = alleWege(b).map(function (r) { return r.key; });
  const weg = soll.filter(function (k) { return ist.indexOf(k) < 0; });
  if (weg.length) artFehlt.push(b.sp + '/' + b.name + ': ' + weg.join(', '));
});
ok('kein Hund und keine Katze verliert einen artweiten Rettungsweg', artFehlt.length === 0,
  artFehlt.length + ' betroffen, z. B. ' + artFehlt.slice(0, 3).join(' | '));

/* ------------------------------------------------------------------ 3) Suche */
console.log('\n3) Sofortsuche im Rassefeld (Tierart filtert, Treffer stehen oben):');
function ersteTreffer(text, sp, n) { return VB.search(text, sp, n || 3).map(function (t) { return t.breed.name; }); }
function findetOben(text, sp, erwartetTeil) {
  const t = VB.search(text, sp, 5);
  return t.length && VB.norm(t[0].breed.name).indexOf(VB.norm(erwartetTeil)) >= 0;
}
ok('„coll" (Hund) findet zuerst einen Collie', findetOben('coll', 'hund', 'collie'), ersteTreffer('coll', 'hund').join(' | '));
ok('„bkh" (Katze) findet Britisch Kurzhaar', findetOben('bkh', 'katze', 'britisch'), ersteTreffer('bkh', 'katze').join(' | '));
ok('„mops" (Hund) findet den Mops', findetOben('mops', 'hund', 'mops'), ersteTreffer('mops', 'hund').join(' | '));
ok('ein Buchstabe liefert schon Treffer', VB.search('m', 'hund', 10).length > 0);
ok('leere Eingabe liefert die Artenliste', VB.search('', 'katze', 10).length > 0);
const katzeTreffer = VB.search('a', 'katze', 40);
ok('die Suche mischt keine fremde Tierart hinein',
  katzeTreffer.every(function (t) { return t.breed.sp === 'katze'; }));
ok('eine Hunderasse ist unter Katze nicht zu finden', VB.search('mops', 'katze', 5).length === 0);
A.species.forEach(function (s) {
  if (!(proArt[s.id] || 0)) return;
  const bsp = VB.BREEDS.find(function (b) { return b.sp === s.id; });
  ok(s.name + ': voller Name findet genau diese Rasse',
    findetOben(bsp.name, s.id, bsp.name.split(' ')[0]), bsp.name);
});

/* --------------------------------------------------- 4) Narkoseplan und Warnung */
console.log('\n4) Narkoseplan der Rasse (erste Wahl · meiden · stabilisieren):');
const mitPlan = VB.BREEDS.filter(function (b) { const p = VB.plan(b); return p && p.erstwahl.length; });
ok('mindestens 90 % der Rassen haben eine Erstwahl-Empfehlung',
  mitPlan.length >= VB.BREEDS.length * 0.9, mitPlan.length + '/' + VB.BREEDS.length);
A.species.forEach(function (s) {
  if (!(proArt[s.id] || 0)) return;
  const einer = VB.BREEDS.find(function (b) { return b.sp === s.id && VB.plan(b).erstwahl.length; });
  ok(s.name + ': mindestens eine Rasse mit Narkoseplan', !!einer, einer ? einer.name : 'keine');
});

/* Der vom Nutzer genannte Beispielfall: BKH-Katze mit HCM und PKD. */
const bkh = VB.resolve('Britisch Kurzhaar', 'katze');
ok('Britisch Kurzhaar ist im Katalog', !!bkh);
if (bkh) {
  const p = VB.plan(bkh);
  ok('BKH: Risikostufe hoch', p.risk === 'hoch', String(p.risk));
  ok('BKH kennt HCM UND PKD', (bkh.conditions || []).indexOf('hcm-cat') >= 0 && (bkh.conditions || []).indexOf('pkd-cat') >= 0,
    (bkh.conditions || []).join(', '));
  ok('BKH: Herzempfehlung steht VOR der Nierenempfehlung',
    /HCM/i.test(p.erstwahl[0] && p.erstwahl[0].name || ''), (p.erstwahl[0] || {}).name);
  ok('BKH: es gibt einen Rettungsweg', p.rettung.length > 0);
  const k = VB.checkGabe(bkh, 'Ketamin');
  ok('Ketamin bei der BKH loest eine Warnung aus', !!k);
  ok('… und zwar die schaerfste Stufe (meiden)', k && k.level === 'avoid', k && k.level);
  ok('… und nennt gleich den Weg zurueck zur Stabilitaet', !!(k && k.rettung.length),
    k ? k.rettung.map(function (r) { return r.key; }).join(', ') : '');
  ok('… und der Rettungsweg hat konkrete Schritte', !!(k && k.rettung[0] && k.rettung[0].schritte.length >= 3));
  ok('Alfaxalon bei der BKH loest KEINE Meidewarnung aus',
    !(VB.checkGabe(bkh, 'Alfaxalon') || {}).level || VB.checkGabe(bkh, 'Alfaxalon').level !== 'avoid');
}
/* MDR1 */
const collie = VB.resolve('Collie', 'hund');
ok('Collie ist im Katalog', !!collie);
if (collie) {
  ok('Collie traegt MDR1', (collie.conditions || []).indexOf('mdr1') >= 0);
  const ace = VB.checkGabe(collie, 'Acepromazin');
  ok('Acepromazin beim Collie warnt (Dosis reduzieren)', !!ace && (ace.level === 'reduce' || ace.level === 'avoid'), ace && ace.level);
  ok('Collie: MDR1-Erstwahlprotokoll vorhanden',
    VB.plan(collie).erstwahl.some(function (e) { return /MDR1/i.test(e.name); }));
  /* Der Wirkstoff, wegen dem der MDR1-Test ueberhaupt gemacht wird. Die Erkrankungsbeschreibung
   * nannte ihn, aber es gab keine WIRKSTOFFREGEL — und checkGabe() liest nur die Regeln. Ergebnis
   * war: „Collie + Ivermectin -> keine Regel". Aufgefallen erst bei der Abnahme. */
  ['Ivermectin', 'Moxidectin', 'Selamectin', 'Loperamid'].forEach(function (w) {
    const t = VB.checkGabe(collie, w);
    ok('MDR1-Hund + ' + w + ' loest die schaerfste Warnung aus', !!t && t.level === 'avoid', t && t.level);
  });
  ok('… und nennt den Rettungsweg (Lipidemulsion, Beatmung, Pflege)',
    !!(VB.checkGabe(collie, 'Ivermectin') || {}).rettung.length);
}
/* Brachyzephal */
const fb = VB.resolve('Französische Bulldogge', 'hund') || VB.resolve('Franzoesische Bulldogge', 'hund');
ok('Französische Bulldogge ist im Katalog', !!fb);
if (fb) {
  ok('… als brachyzephal erkannt', (fb.groups || []).indexOf('brachy') >= 0, (fb.groups || []).join(','));
  ok('… mit BOAS-Erstwahlprotokoll', VB.plan(fb).erstwahl.some(function (e) { return /BOAS|Brachyzephal/i.test(e.name); }));
}
/* Eine Rasse ohne eingetragene Erbkrankheit bekommt trotzdem einen Artplan. */
['kaninchen', 'meerschwein', 'chinchilla', 'degu', 'frettchen', 'reptil'].forEach(function (spId) {
  if (!(proArt[spId] || 0)) return;
  const alle = VB.BREEDS.filter(function (b) { return b.sp === spId; });
  const ohne = alle.filter(function (b) { return !VB.plan(b).erstwahl.length; });
  ok(spId + ': JEDE Rasse hat einen Narkoseplan (Artgrundlagen greifen)', ohne.length === 0,
    ohne.slice(0, 3).map(function (b) { return b.name; }).join(', '));
});

/* Eine Warnung ohne Weg zurueck ist eine halbe Antwort — und der falsche Weg ist schlimmer als
 * keiner. Beides ist beim Bauen passiert: drugWarnings() reichte das rescue-Feld der Regel gar
 * nicht durch, deshalb fiel checkGabe() auf die Wege der ERKRANKUNG zurueck und zeigte unter
 * „Butorphanol gebucht" den Ivermectin-Ablauf. Hier wird der ganze Katalog gegen die gaengigen
 * Wirkstoffe durchgerechnet. */
console.log('\n4b) Jede Warnung nennt einen passenden Weg zurueck:');
const WIRKSTOFFE = ['Ketamin', 'Propofol', 'Alfaxalon', 'Acepromazin', 'Medetomidin', 'Dexmedetomidin',
  'Butorphanol', 'Methadon', 'Meloxicam', 'Atropin', 'Glycopyrrolat', 'Isofluran', 'Sevofluran',
  'Ivermectin', 'Midazolam', 'Fentanyl', 'Amoxicillin'];
let warnGesamt = 0; const ohneWeg = [], falscheArt = [];
VB.BREEDS.forEach(function (b) {
  WIRKSTOFFE.forEach(function (d) {
    const r = VB.checkGabe(b, d);
    if (!r) return;
    warnGesamt++;
    if (!r.rettung.length) ohneWeg.push(b.sp + '/' + b.name + ' + ' + d + ' (' + r.warnungen.map(function (w) { return w.id; }).join(',') + ')');
    r.rettung.forEach(function (x) {
      const e = VB.RESCUE[x.key];
      if (e && e.sp && e.sp !== b.sp) falscheArt.push(b.sp + '/' + b.name + ' + ' + d + ' -> ' + x.key);
    });
  });
});
ok('jede Wirkstoffwarnung nennt mindestens einen Rettungsweg (' + warnGesamt + ' geprueft)',
  ohneWeg.length === 0, ohneWeg.slice(0, 4).join(' | '));
ok('kein Rettungsweg einer fremden Tierart bei einer Gabe', falscheArt.length === 0, falscheArt.slice(0, 4).join(' | '));
/* Der konkrete Fall, der es aufgedeckt hat. */
const cb = VB.checkGabe(VB.resolve('Collie', 'hund'), 'Butorphanol');
ok('MDR1-Hund + Butorphanol nennt den OPIOID-Weg, nicht den Ivermectin-Weg',
  !!cb && cb.rettung.length > 0 && /Opioid/i.test(cb.rettung[0].name),
  cb && cb.rettung.map(function (x) { return x.name; }).join(' | '));
const ci = VB.checkGabe(VB.resolve('Collie', 'hund'), 'Ivermectin');
ok('MDR1-Hund + Ivermectin nennt den LAKTON-Weg', !!ci && /Lakton/i.test(ci.rettung[0].name),
  ci && ci.rettung.map(function (x) { return x.name; }).join(' | '));

/* ------------------------------------------------------- 5) Verdrahtung in der App */
console.log('\n5) Verdrahtung in der Oberflaeche:');
ok('das Rassefeld ist nicht mehr auf Hund/Katze festgenagelt', /speciesWithBreeds/.test(app));
ok('die alte <datalist>-Loesung ist raus', !/id="breedList"/.test(app));
ok('es gibt eine eigene Sofort-Trefferliste', /breedPopAuf/.test(app) && /id="breedPop"/.test(app));
ok('Tastatur: Pfeiltasten und Enter bedienen die Liste', /ArrowDown/.test(app) && /breedPopMarkiere/.test(app));
ok('die Trefferliste zeigt eine Risikofarbe', /breedRiskKlasse/.test(app));
ok('das Rasseprofil zeigt den Narkoseplan', /function planHtml/.test(app) && /VB\.plan/.test(app));
ok('Erstwahl, Meiden, Ziele und Rettung sind eigene Bloecke',
  /Narkose – erste Wahl/.test(app) && /Bei dieser Rasse meiden/.test(app) && /stabilisieren/.test(app));
ok('die Skripte sind eingebunden', /narkose-risiko\.js/.test(app) && /breed-katalog\.js/.test(app));

console.log('\n6) Die Warnung im Augenblick der bestaetigten Gabe:');
ok('medBuchen prueft die Rasse', /function medBuchen\(rec\)\{[\s\S]{0,600}gabePruefen\(rec\)/.test(app));
ok('gabePruefen fragt VETBREED.checkGabe', /function gabePruefen[\s\S]{0,600}VB\.checkGabe/.test(app));
ok('eine zurueckgenommene Gabe wird NICHT geprueft', /rec\.storno\) return null/.test(app));
ok('die Injektionskombination gibt ihre Wirkstoffe mit', /wirkstoffe:\(\(c&&c\.comp\)\|\|\[\]\)/.test(app));
ok('die Warnung erscheint als eigener Kasten', /function gabeWarnZeigen/.test(app) && /gabe-warn/.test(app));
ok('der Kasten zeigt auch den Rettungsweg', /Jetzt stabilisieren/.test(app));
ok('die Warnung haengt sich an die Protokollzeile', /rec\.warnLevel\s*=/.test(app) && /rec\.warnText\s*=/.test(app));
ok('die Rasse selbst geht mit', /rec\.breed\s*=/.test(app) && /rec\.breedName\s*=/.test(app));

console.log('\n7) Der Weg der Warnung bis ins Narkoseprotokoll:');
ok('die Shell reicht warnText/breed weiter', /warnText: gabe\.warnText/.test(shell) && /breed: gabe\.breedName/.test(shell));
ok('die Shell schreibt sie auch in den Klartext-Befund', /gabe\.warnLevel && gabe\.warnText/.test(shell));
ok('die Bridge legt sie in die Protokollzeile', /warnText: kurz\(gabe\.warnText/.test(registry));
ok('die Bridge schreibt sie in den Befundtext (damit jede vorhandene Ansicht sie zeigt)',
  /finding:[\s\S]{0,400}gabe\.warnLevel && gabe\.warnText/.test(registry));
ok('die Rasse steht mit in der Protokollzeile', /breed: kurz\(gabe\.breedName/.test(registry));

console.log('\n8) Groesse und Ladbarkeit:');
const katPfad = path.join(WURZEL, 'ui/shared/breed-katalog.js');
const kb = Math.round(fs.statSync(katPfad).size / 1024);
ok('breed-katalog.js bleibt unter der Paketgrenze von 2 MB (' + kb + ' KB)', kb < 2048, kb + ' KB');
ok('breed-katalog.js laedt ohne Grundmodul nicht durch (kein harter Absturz)',
  /if \(!VB \|\| !VB\.register\) return;/.test(fs.readFileSync(katPfad, 'utf8')));
ok('narkose-risiko.js ebenso',
  /if \(!VB \|\| !VB\.register\) return;/.test(fs.readFileSync(path.join(WURZEL, 'ui/shared/narkose-risiko.js'), 'utf8')));

console.log('\n---------------------------------------------');
console.log('  bestanden: ' + pass + '   fehlgeschlagen: ' + fail + (warn ? '   Hinweise: ' + warn : ''));
process.exit(fail ? 1 : 0);
