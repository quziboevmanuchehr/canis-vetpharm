'use strict';
/*
 * netzsuche-grund-test.js — wird die Netzwerksuche abgelehnt, muss der GRUND sichtbar werden.
 *
 * DER BEFUND, 30.08.2026, in der Praxis.
 * Der Tierarzt drueckte im Admin-Bereich "Netzwerk jetzt durchsuchen" und es passierte nichts.
 * Die Bridge hatte den Lauf abgelehnt, und zwar mit gutem Grund und in klaren Worten:
 *
 *     "An diesem PC haengt gerade ein Patient am Geraet (1 Geraet hat in den letzten 3 Minuten
 *      Werte geliefert). Der Suchlauf wartet, bis die Narkose vorbei ist — er wuerde sonst mit
 *      dem Empfang der Vitalwerte um dieselbe Netzkarte konkurrieren."
 *
 * Dieser Satz kam nie an. Der Knopf im Reiter "Netzwerk & Geraete" sah die Antwort gar nicht an
 * (`.then(function () { startNetzPoll(b); loadNetz(b); })`), sprang auf "startet..." und blieb
 * dann stumm. Also haelt man die Suche fuer kaputt und drueckt weiter.
 *
 * WAS DIESEN FALL BESONDERS MACHT: er war schon einmal behoben. Beim ZWEITEN Knopf (#gerScan
 * im Reiter "Geraete") steht die Behandlung seit dem 01.08.2026, mit einem Kommentar, der
 * genau dieses Verhalten voraussagt — "sonst klickt jemand im OP-Betrieb dreimal auf einen
 * Knopf, der stumm nichts tut". Die Behebung kam damals an EINER von ZWEI Stellen an.
 *
 * DESHALB PRUEFT DIESER TEST DIE EIGENSCHAFT, NICHT DIE ZWEI BEKANNTEN STELLEN: er sucht ALLE
 * Aufrufer von /api/netscan/start im Quelltext und verlangt von JEDEM, dass er die Antwort
 * auswertet und den Grund anzeigt. Wer morgen einen dritten Knopf ergaenzt, faellt hier durch,
 * auch wenn niemand diesen Test anfasst.
 *
 * Start:  node tools/netzsuche-grund-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
let ok = 0; const fehler = [];
function pruef(was, bedingung, zusatz) {
  if (bedingung) { ok++; console.log('  + ' + was); }
  else { fehler.push(was); console.log('  FEHLGESCHLAGEN: ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}

console.log('\nVetStation - eine abgelehnte Netzwerksuche muss ihren Grund nennen\n');

/* --------------------------------------------------------------------------------------
 * 1) Die Bridge lehnt ueberhaupt ab - und begruendet es.
 * ------------------------------------------------------------------------------------ */
console.log('1) Die Bridge nennt einen Grund:');
const server = fs.readFileSync(path.join(WURZEL, 'bridge', 'src', 'server.js'), 'utf8');
pruef('starteScan() gibt einen Grund zurueck', /grund\s*:/.test(server));
pruef('die Route reicht ihn nach aussen weiter',
  /netscan\/start[\s\S]{0,600}?gestartet:\s*r\.gestartet[\s\S]{0,80}?grund:\s*r\.grund/.test(server));

/* --------------------------------------------------------------------------------------
 * 2) JEDER Aufrufer in der Oberflaeche wertet die Antwort aus.
 *
 * Gesucht wird im Quelltext, weil der Fehler genau dort sass: nicht in einer Regel, sondern
 * in einem Aufrufer, den die Regel nie erreicht hat.
 * ------------------------------------------------------------------------------------ */
console.log('\n2) Jeder Knopf in der Oberflaeche wertet die Antwort aus:');
const ui = [];
(function sammle(dir) {
  fs.readdirSync(dir, { withFileTypes: true }).forEach(function (e) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (e.name !== 'shared') sammle(p); return; }
    if (/\.(js|html)$/i.test(e.name)) ui.push(p);
  });
})(path.join(WURZEL, 'ui'));

const aufrufer = [];
ui.forEach(function (p) {
  const t = fs.readFileSync(p, 'utf8');
  let i = 0;
  while ((i = t.indexOf('/api/netscan/start', i)) >= 0) {
    /* Das Stueck NACH dem Aufruf ist die Behandlung. Die Fensterbreite ist GEMESSEN, nicht
     * gewaehlt: beim ausfuehrlicheren der beiden Knoepfe (#gerScan) liegen zwischen dem Aufruf
     * und der Anzeige des Grundes 858 Zeichen, weil dazwischen der Warnkasten aufgebaut wird.
     * Mit 700 fiel genau dieser RICHTIGE Aufrufer durch - der Test war zu eng, nicht der Code.
     * 1400 laesst Luft fuer einen etwas laengeren Kasten und bleibt eng genug, dass eine
     * Anzeige irgendwo anders in der Datei nicht faelschlich mitzaehlt. */
    aufrufer.push({
      datei: path.relative(WURZEL, p).split('\\').join('/'),
      zeile: t.slice(0, i).split('\n').length,
      danach: t.slice(i, i + 1400),
    });
    i += 10;
  }
});

pruef('mindestens zwei Aufrufer gefunden (sonst greift die Suche ins Leere)',
  aufrufer.length >= 2, aufrufer.map(function (a) { return a.datei + ':' + a.zeile; }).join(', '));

aufrufer.forEach(function (a) {
  const stelle = a.datei + ':' + a.zeile;
  /* Zwei Dinge muessen dastehen: die Antwort wird gelesen (gestartet) UND der Grund wird
   * verwendet. Nur eines von beiden genuegt nicht - wer `gestartet` prueft und dann kommentarlos
   * abbricht, ist genauso stumm wie vorher. */
  pruef(stelle + ': liest, ob der Lauf gestartet wurde', /gestartet/.test(a.danach));
  pruef(stelle + ': zeigt den Grund an', /\.grund/.test(a.danach));
});

/* --------------------------------------------------------------------------------------
 * 3) GEGENPROBE: die Suche wuerde einen stummen Aufrufer wirklich finden.
 *
 * Ohne sie bestuende dieser Test auch dann, wenn die Suche gar nichts mehr findet - und
 * genau das ist die Fehlerform, um die es hier geht.
 * ------------------------------------------------------------------------------------ */
console.log('\n3) Gegenprobe an einem erfundenen, stummen Knopf:');
{
  const stumm = "fetch('/api/netscan/start', { method: 'POST' })\n"
    + "  .then(function () { startNetzPoll(b); loadNetz(b); });";
  pruef('ein Aufrufer ohne Auswertung wuerde durchfallen',
    !/gestartet/.test(stumm) && !/\.grund/.test(stumm));
  const gut = "fetch('/api/netscan/start', { method: 'POST' })\n"
    + "  .then(function (r) { return r.json(); })\n"
    + "  .then(function (a) { if (a && a.gestartet === false) { zeige(a.grund); return; } weiter(); });";
  pruef('… und ein Aufrufer MIT Auswertung besteht', /gestartet/.test(gut) && /\.grund/.test(gut));
}

console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + ')');
  process.exit(1);
}
console.log('ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
