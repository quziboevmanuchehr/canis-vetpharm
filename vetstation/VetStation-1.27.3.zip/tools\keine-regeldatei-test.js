'use strict';
/*
 * keine-regeldatei-test.js — die Regeldatei der Entwicklung bleibt im Repo und geht
 * weder auf einen Praxis-PC noch ins oeffentliche Netz. Auch ihr NAME nicht.
 *
 * WARUM ES DIESEN TEST GIBT (Weisung 27.08.2026)
 *
 * Die Datei mit den Arbeitsregeln enthaelt Testwege, die Freigabekette und das Verzeichnis
 * der Notizen. Auf einem Praxis-PC hat davon nichts einen Zweck - gelesen wurde sie dort nie.
 * Sie lag trotzdem in jedem Paket, weil robocopy den ganzen Baum nimmt und niemand daran
 * gedacht hatte. Gemessen am 27.08.2026: sie steckte in dist\VetStation\ UND im Update-Zip,
 * ging also mit jeder Auslieferung an jede Praxis.
 *
 * Und ihr Name stand in zwoelf Kommentaren, vier davon in ui\app\index.html - also in der
 * Web-App, die oeffentlich auf GitHub Pages und Firebase liegt. Ein Kommentar, der auf eine
 * Datei verweist, die es beim Empfaenger gar nicht gibt, ist ohnehin ein toter Verweis; hier
 * kam dazu, dass der Name mehr verraet als der Satz, in dem er steht.
 *
 * DIE FALLE BEIM SCHREIBEN DIESES TESTS - und wie sie hier umgangen ist:
 * Eine Pruefung "dieser Name kommt nicht mehr vor" schlaegt zuverlaessig an ihrer EIGENEN
 * Begruendung an. Genau das ist diesem Projekt schon einmal passiert (siehe den Kopf von
 * ekg-skala-test.js). Deshalb steht der gesuchte Name hier NIRGENDS als zusammenhaengende
 * Zeichenkette, sondern wird zur Laufzeit zusammengesetzt. Diese Datei kann sich damit selbst
 * pruefen, ohne sich selbst zu finden - und muss nicht von der Suche ausgenommen werden,
 * was die uebliche, schwaechere Loesung waere.
 *
 * Start:  node tools/keine-regeldatei-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
/* Zusammengesetzt, nicht ausgeschrieben - siehe Kopf. */
const NAME = 'CLAUDE' + '.md';
const HERSTELLER = /\banthropic\b/i;
const WERKZEUG = new RegExp('\\b' + 'claude' + '\\b', 'i');

let ok = 0;
const fehler = [];
function pruefe(was, bedingung, zusatz) {
  if (bedingung) { ok++; return; }
  fehler.push(was + (zusatz ? '\n     -> ' + zusatz : ''));
}

/* ---- Baum durchgehen, ohne die Ordner, die ohnehin nicht ausgeliefert werden ---- */
const AUSSEN = ['.git', 'node_modules', 'dist', 'data'];
function dateien(verz, sammler) {
  const eintraege = fs.readdirSync(verz, { withFileTypes: true });
  eintraege.forEach(function (e) {
    if (AUSSEN.indexOf(e.name) >= 0) return;
    const voll = path.join(verz, e.name);
    if (e.isDirectory()) { dateien(voll, sammler); return; }
    if (!/\.(js|html|css|json|md|ps1|bat|txt)$/i.test(e.name)) return;
    sammler.push(voll);
  });
  return sammler;
}

console.log('keine-regeldatei-test — die Regeldatei bleibt im Repo\n');

/* =======================================================================================
 * 1  Der Name kommt in keiner Datei des Baumes mehr vor.
 *
 * Die Regeldatei selbst ist die eine Ausnahme: sie darf sich nennen, wie sie heisst, und
 * sie wird nicht ausgeliefert (Abschnitt 3 erzwingt das).
 * ===================================================================================== */
/* ZWEI Dateien duerfen den Namen nennen, und beide aus demselben Grund: sie sind die
 * Stellen, die den Ausschluss BEWIRKEN. Ein Ausschluss, der seinen Gegenstand nicht nennen
 * darf, ist keiner. Abschnitt 3 prueft die Bauvorschrift dafuer positiv - sie steht hier
 * also nicht ungeprueft da, sondern nur unter einer anderen Frage. */
const DARF = ['installer/make-dist.ps1'];
const alle = dateien(WURZEL, []);
const treffer = [];
alle.forEach(function (f) {
  const rel = path.relative(WURZEL, f).replace(/\\/g, '/');
  if (rel === NAME) return;                       // die Datei selbst
  if (DARF.indexOf(rel) >= 0) return;
  let inhalt;
  try { inhalt = fs.readFileSync(f, 'utf8'); } catch (e) { return; }
  if (inhalt.indexOf(NAME) >= 0) {
    const zeile = inhalt.split('\n').findIndex(function (z) { return z.indexOf(NAME) >= 0; }) + 1;
    treffer.push(rel + ':' + zeile);
  }
});
pruefe('der Name der Regeldatei steht in keiner anderen Datei des Baumes',
  treffer.length === 0, treffer.join('\n     -> '));
console.log('  ' + alle.length + ' Dateien durchsucht');

/* =======================================================================================
 * 2  Auch der Hersteller- und Werkzeugname nicht - in dem, was VEROEFFENTLICHT wird.
 *
 * Bewusst enger gefasst als Abschnitt 1: geprueft wird nur, was die Web-App ausmacht.
 * Ein Wort in einer Notiz im Entwicklungsbaum geht niemanden etwas an.
 * ===================================================================================== */
['ui/app/index.html'].concat(
  fs.readdirSync(path.join(WURZEL, 'ui', 'shared'))
    .filter(function (n) { return /\.(js|css)$/.test(n); })
    .map(function (n) { return 'ui/shared/' + n; })
).forEach(function (rel) {
  const p = path.join(WURZEL, rel);
  if (!fs.existsSync(p)) return;
  const s = fs.readFileSync(p, 'utf8');
  pruefe(rel + ': nennt den Werkzeugnamen nicht', !WERKZEUG.test(s));
  pruefe(rel + ': nennt den Herstellernamen nicht', !HERSTELLER.test(s));
});

/* =======================================================================================
 * 3  Der Bau schliesst die Regeldatei aus.
 *
 * Quelltextpruefung an make-dist.ps1: ohne den Eintrag in der Ausschlussliste von robocopy
 * liegt sie beim naechsten Bau wieder in dist\ und damit in jedem Paket.
 * ===================================================================================== */
const bau = fs.readFileSync(path.join(WURZEL, 'installer', 'make-dist.ps1'), 'utf8');
const roboZeile = bau.split('\n').filter(function (z) { return z.indexOf('robocopy $Root $Stage') === 0; })[0] || '';
pruefe('make-dist.ps1: die Kopierzeile schliesst die Regeldatei aus',
  roboZeile.indexOf("'" + NAME + "'") >= 0,
  roboZeile ? 'gefunden: ' + roboZeile.slice(-90) : 'die robocopy-Zeile wurde nicht gefunden');

/* =======================================================================================
 * 4  Und das Ergebnis: weder im gebauten Baum noch im Update-Paket.
 *
 * Fehlt der Bau, wird uebersprungen - auf einem frisch geklonten Repo gibt es ihn nicht.
 * ===================================================================================== */
const distDir = path.join(WURZEL, 'dist', 'VetStation');
if (!fs.existsSync(distDir)) {
  console.log('  Hinweis: dist/VetStation fehlt - Abschnitt 4 uebersprungen.');
} else {
  pruefe('der gebaute Baum enthaelt die Regeldatei nicht',
    !fs.existsSync(path.join(distDir, NAME)), path.join(distDir, NAME));

  const version = JSON.parse(fs.readFileSync(path.join(WURZEL, 'package.json'), 'utf8')).version;
  const zip = path.join(WURZEL, 'dist', 'VetStation-' + version + '.zip');
  if (!fs.existsSync(zip)) {
    console.log('  Hinweis: ' + path.basename(zip) + ' fehlt - Zip-Pruefung uebersprungen.');
  } else {
    /* Die Namensliste steht im Zip unkomprimiert im Klartext; ein vollstaendiges Entpacken
     * waere fuer diese eine Frage unverhaeltnismaessig. */
    const roh = fs.readFileSync(zip).toString('latin1');
    pruefe('das Update-Paket enthaelt die Regeldatei nicht',
      roh.indexOf(NAME) < 0, path.basename(zip));
  }
}

/* ------------------------------------------------------------------------------------- */
console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + '):');
  fehler.forEach(function (f) { console.log('  x ' + f); });
  process.exit(1);
}
console.log('OK — ' + ok + ' Pruefungen. Die Regeldatei bleibt, wo sie hingehoert.');
