@echo off
setlocal
title VetStation - Monitor befragen (PDS-Sonde)
REM ---------------------------------------------------------------------------
REM ZUERST UND AM WICHTIGSTEN:
REM WAEHREND EINER NARKOSE WIRD NICHT GEMESSEN.
REM Diese Sonde baut acht Verbindungen zum Monitor auf, eine je Frage. Am
REM 26.07.2026 wurde am echten Geraet gesehen, dass es eine zweite abfragende
REM Verbindung abweist, waehrend die Station schon eine haelt. Abgewiesen werden
REM kann dabei auch die Station - dann fehlen am narkotisierten Patienten fuer
REM die Dauer der Messung, also gut drei Minuten, die Werte. Und der Befund
REM waere obendrein wertlos: eine stumme Frage hiesse dann nur, dass der Platz
REM belegt war, nicht dass die Frage falsch gestellt war.
REM
REM DESHALB VORHER DIE VETSTATION BEENDEN - das Fenster von START-VetStation.bat
REM schliessen. Laeuft sie noch, bricht dieses Programm von selbst ab, misst
REM nicht und schreibt keinen Befund. Das ist Absicht und kein Fehler.
REM Erzwingen laesst sich der Lauf nur mit "--trotzdem", und das gehoert
REM ausschliesslich an ein Geraet, an dem KEIN Patient haengt.
REM ---------------------------------------------------------------------------
REM WOZU: Am Narkosemonitor kommen heute nur die Patientendaten, der Blutdruck und
REM die Alarme an. Herzfrequenz, Sauerstoffsaettigung, Temperatur und CO2 fehlen.
REM Dieses Programm stellt dem Geraet acht Mal fast dieselbe Frage und aendert
REM dabei jedes Mal genau eine Kleinigkeit. Bei welcher Frage die Werte dann
REM kommen, zeigt, was gefehlt hat.
REM DAUER: gut drei Minuten. Bitte das Fenster so lange offen lassen.
REM AM GERAET WIRD NICHTS VERSTELLT. Es wird nur gefragt und zugehoert; auch am
REM Praxis-PC wird keine Einstellung veraendert.
REM VORHER: Geraet einschalten, Sensoren anlegen und warten, bis auf dem Monitor
REM wirklich Werte stehen. Wo nichts gemessen wird, kann auch nichts gesendet
REM werden - dann misst die Sonde eine Stille, die gar keine Stoerung ist.
REM ERGEBNIS: eine Textdatei im Ordner data (pds-befund-<Datum>.txt). Diese Datei
REM bitte an den Entwickler schicken. Patientenname und Kennung stehen NICHT
REM darin, sie werden vor dem Speichern entfernt.
REM AUFRUF MIT DER IP DES GERAETS (sie steht am Monitor im Netzwerk-Menue):
REM   PDS-SONDE.bat 192.168.0.50
REM Der Kapnograph wird genauso befragt, nur mit seiner eigenen IP; das
REM Narkosegeraet Veta 5 Plus steht auf 192.168.0.52.
REM BITTE DIE IP WIRKLICH MITGEBEN. Ohne Angabe sucht das Programm selbst, und
REM es erkennt Mindray-Geraete am Anfang der MAC-Adresse (98:CC:E4). Monitor und
REM Narkosegeraet fangen beide so an - die Suche kann sie nicht auseinander
REM halten und dann wird das falsche Geraet befragt.
REM ---------------------------------------------------------------------------
cd /d "%~dp0"
REM Das Messprogramm erwartet die Adresse als "--host <IP>". Der Tierarzt soll
REM aber nur die IP tippen muessen, deshalb wird das Wort hier davorgesetzt.
REM Faengt die Eingabe mit "--" an, ist es ein Fachaufruf und geht unveraendert
REM durch. Ohne jede Eingabe wird die Adresse im PC gesucht - das gelingt nur,
REM wenn der PC vorher schon einmal mit dem Geraet gesprochen hat.
set SONDE=%*
if "%SONDE%"=="" set SONDE=--host auto
if not "%SONDE:~0,2%"=="--" set SONDE=--host %SONDE%
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\pds-feldsonde.js" %SONDE%
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\pds-feldsonde.js" %SONDE%
:ende
echo.
pause
