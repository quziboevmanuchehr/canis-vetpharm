'use strict';
/*
 * pds-testgeraet.js — ein STRENGES Mindray-PDS-Testgeraet (28.08.2026).
 *
 * WARUM ES DIESE DATEI GIBT — der blinde Fleck, den sie schliesst:
 * tools/hl7-client-test.js stellt ein NACHGIEBIGES Fake-Geraet. Seine ganze Pruefung ist
 * `if (/QRY/.test(p))` — es antwortet also auf jede Nachricht, in der irgendwo "QRY" steht.
 * Deshalb war dieser Test seit jeher gruen, waehrend das echte uMEC12 Vet in der Praxis
 * schwieg: gemessen kommen dort Patientendaten, NIBP und Alarme an, die Periodik (HF 101,
 * SpO2 160, Temp 200, EtCO2 220 ...) fehlt vollstaendig. Ein Testgeraet, das den Fehler
 * nicht nachstellen kann, ist kein Zeuge.
 *
 * Dieses Geraet verhaelt sich wie das echte:
 *   - Es prueft die Abfrage gegen die belegten Formregeln aus dem Programmer's Guide
 *     (Mindray Patient Data Share Protocol, H-0010-20-43061-2, Rev. 14.0, Kapitel 6).
 *   - Eine formwidrige Abfrage wird KOMMENTARLOS verworfen: kein ACK, kein NACK, kein QAK,
 *     kein ERR (Guide 6.3.3 NOTE, 6.3.4 NOTE, 6.9.5.1 NOTE, 6.9.7 — viermal ausdruecklich).
 *   - Patientendaten, aperiodische NIBP und Alarme laufen TROTZDEM weiter (Guide 6.3.3
 *     Punkte 1, 2 und 5). Nur Punkt 3 haengt an der Abfrage: "Only when receives a QRY
 *     message from CIS ... this interface will send what CIS needs every one second."
 * Damit entsteht am Testplatz genau das Krankheitsbild, das der Tierarzt heute sieht.
 *
 * NACHGERUESTET AM 28.08.2026 — WARUM DIESES GERAET JETZT MEHR HINAUSSCHICKT:
 * Es sendete bis heute nur "PID|||T-4711||Bella^Muster|..." und traf damit ausgerechnet das
 * eine Segment, das die Maskierung der Feldsonde (tools/pds-feldsonde.js) schon immer
 * abgedeckt hat. Die drei Lecks, die dort am 28.08.2026 nachgewiesen wurden, konnte dieses
 * Geraet gar nicht ausloesen — ein Testgeraet, das den Fehler nicht erzeugen kann, ist auch
 * hier kein Zeuge. Es schickt deshalb jetzt zusaetzlich, alles nach dem Aufbau aus
 * docs/MINDRAY-HL7.md (Abschnitte "Was das Geraet im Live-Betrieb tatsaechlich sendet" und
 * "Warum Gewicht/Groesse fehlen") und Guide 6.5.1.6/6.8.4:
 *   - PV1 in JEDER Nachricht, mit Standort in PV1-3 und Tierarztnamen in PV1-7,
 *   - OBX||ST|2301^MRN|| mit der am Monitor eingegebenen Aktennummer beim Verbindungsaufbau,
 *   - einen Alarmtext, der den Patientennamen enthaelt (OBX-5 ist laut 2.2.7.4 Freitext),
 *   - auf Wunsch (opt.antwortAufFehler) MSA/ERR/QAK auf eine verworfene Abfrage, mit Namen
 *     und Aktennummer in den Freitextfeldern.
 * Die Namen sind erfunden und stehen ausschliesslich in dieser Testdatei.
 *
 * DER MARKENMODUS (opt.marken, nachgeruestet 28.08.2026) — und warum er sein musste:
 * Die Dichtheit des Befunds von tools/pds-feldsonde.js wurde bis heute gegen eine LISTE von
 * sieben bekannten Zeichenketten geprueft — genau denen, die eine frueher Messung als Leck
 * gefunden hatte. Diese Pruefung war 80 von 80 gruen, waehrend fuenf ANDERE Felder offen
 * standen (OBX-3 in beiden Haelften, OBX-4, OBX-6, QAK-3 und CE-Kennungen der Form
 * GROSS_MIT_UNTERSTRICH). Eine Ausschlussliste kann den naechsten Fehler nicht finden: sie
 * kennt nur die vorigen. Im Projekt ist das eine benannte Fehlerklasse.
 * Im Markenmodus schickt dieses Geraet deshalb in JEDES Feld JEDES Segments eine EINDEUTIGE
 * Marke der Form ZZ<Kennung><Feldnummer>ZZ, dazu je Feld eine zweite Komponente
 * ZZ<Kennung><Feldnummer>K2ZZ (das Leck OBX-3 sass in der ZWEITEN Haelfte eines Feldes — wer
 * nur je Feld eine Marke setzt, sieht diese Klasse nicht). Was der Bericht davon zeigt, ist
 * ein Leck; welches Feld es war, steht in der Marke.
 * Erzeugt wird alles aus MARKEN_PLAN und MARKEN_NACHRICHTEN. Beide sind exportiert, damit
 * der Test dieselben Marken AUSRECHNEN kann, statt sie abzutippen — und damit ein spaeter
 * hinzugefuegtes Feld ohne Zutun mitgeprueft wird.
 *
 * NACHGERUESTET AM 29.08.2026 — DAS ABSCHLIESSENDE <CR>, UND WARUM ES DIESES GERAET BLAMIERT:
 * Die Abfrage der Station ging wochenlang als "...&222<FS><CR>" hinaus statt als
 * "...&222<CR><FS><CR>" — hinter dem LETZTEN Segment fehlte der Wagenruecklauf. Das echte
 * uMEC12 hat sie deshalb kommentarlos verworfen; in der Nacht auf den 29.08.2026 wurde am
 * Geraet gemessen, dass genau dieses eine Zeichen (zusammen mit MSH-10 = 1203) den
 * Unterschied zwischen NICHTS und HF/SpO2/Puls/Temperatur/AF/Blutdruck macht.
 * DIESES TESTGERAET HAT DEN MANGEL KLAGLOS ANGENOMMEN. Es ist aus DERSELBEN Lesart
 * DESSELBEN Kapitels gebaut wie die Sonde und der Adapter — "gruen" hiess hier "mit sich
 * selbst einig", nicht "richtig". Dieselbe Falle wie beim Septum-Leck: der Pruefling und
 * sein Pruefer teilten den Irrtum.
 * Im Profil 'streng' (und NUR dort, siehe PROFILE) wird eine Abfrage ohne abschliessendes
 * <CR> deshalb jetzt verworfen, mit dem Grund im Bericht. In 'tolerant' darf sie es NICHT
 * sein: dort muss Variante 1 der Feldsonde — der Stand vor der Berichtigung, ohne <CR> —
 * weiterhin durchlaufen, sonst verliert die Blindheitsprobe ihren Gegenstand.
 * Belegt ist die Strenge durch tools/pds-streng-test.js, Abschnitt (f): dieselben Bytes
 * einmal mit und einmal ohne <CR>, angenommen und verworfen.
 *
 * WAS DIESES GERAET BEWUSST NICHT PRUEFT:
 *   - Ortszeit gegen UTC in QRD-1. Die Woerter "local time", "UTC", "GMT" und "time zone"
 *     kommen im ganzen Guide KEIN EINZIGES MAL vor; verlangt wird nur ein "valid time
 *     format". Wer hier UTC ablehnen laesst, baut sich eine Regel, die er selbst erfunden
 *     hat — und beweist damit spaeter etwas, das nicht gilt. Geprueft wird nur die FORM.
 *   - Die Laenge der Kennung QRD-4 wird geprueft, ihre Eindeutigkeit nicht (Guide 6.9.4
 *     sagt ausdruecklich, der Server pruefe das nicht).
 *
 * ZWEI WIDERSPRUECHE IM GUIDE, und wie hier entschieden wurde (beide sind schaltbar, damit
 * niemand auf eine Auslegung festgenagelt wird):
 *   1. Antwortet das Geraet auf eine ungueltige Abfrage? Sieben Zeilen-Textbausteine in
 *      6.9.4/6.9.5 sagen "an error message is returned", vier uebergreifende NOTEs sagen das
 *      Gegenteil. Das PRAXISGERAET schweigt — also schweigt dieses hier auch.
 *   2. QRD-3: Tabelle und alle neun Beispiele zeigen "I", der Fliesstext darunter "1".
 *      Beides wird angenommen; eine erfundene Ablehnung waere hier reine Willkuer.
 *
 * DER SCHALTER opt.antwortAufFehler:
 * Er entscheidet den ERSTEN der beiden Widersprueche oben andersherum — das Geraet antwortet
 * auf eine verworfene Abfrage doch mit MSA/ERR/QAK, so wie es die sieben Zeilen-Textbausteine
 * in 6.9.4/6.9.5 beschreiben. Vorgabe ist AUS (das Praxisgeraet schweigt). Er ist da, damit
 * ein Test beide Lesarten fahren kann, statt eine davon festzunageln.
 *
 * Aufruf als Modul:  const { starte } = require('./pds-testgeraet')
 * Aufruf als CLI:    node tools/pds-testgeraet.js --port 4601 --profil streng [--still]
 *                    [--sekunden 60]  (Selbstabschaltung — ein haengendes Testgeraet
 *                    blockiert spaeter den Paketbau, siehe Projektregeln)
 *
 * REIN LESEND/PASSIV: dieses Werkzeug oeffnet nur einen eigenen TCP-Port auf dem Testrechner.
 * Es spricht kein echtes Geraet an und aendert keine Konfiguration.
 */

const net = require('net');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;   // MLLP-Rahmen: <VT> payload <FS><CR>

function mllp(text) {
  return Buffer.concat([Buffer.from([VT]), Buffer.from(text, 'latin1'), Buffer.from([FS, CR])]);
}

/*
 * Modul-IDs (Guide Anhang B.3) — sie stehen in OBX-4 und sagen, WELCHES Modul den Wert
 * gemessen hat. Ohne sie saehe die Nachricht anders aus als am echten Geraet, und ein
 * Parser, der sich darauf stuetzt, wuerde am Testplatz gruen und in der Praxis rot.
 */
const MODUL_JE_ID = {
  '51': '2101', '52': '2101', '101': '2101', '102': '2101',
  '151': '2102',
  '160': '2103', '161': '2103',
  '200': '2104', '201': '2104', '213': '2104',
  '170': '2105', '171': '2105', '172': '2105',
  '220': '2109', '221': '2109', '222': '2109', '250': '2109', '251': '2109',
};
// Kurzname in OBX-3 (Code^Label), wie ihn der Guide in seinen Beispielen abdruckt.
const NAME_JE_ID = {
  '51': 'Weight', '52': 'Height', '101': 'HR', '102': 'PVCs', '151': 'RR',
  '160': 'SpO2', '161': 'PR', '170': 'NBP-S', '171': 'NBP-D', '172': 'NBP-M',
  '200': 'T1', '201': 'T2', '213': 'TB', '220': 'CO2', '221': 'INS',
  '222': 'AWRR', '250': 'CO2ET', '251': 'CO2FI',
};

/*
 * ANGABEN_VORGABE — die personenbezogenen Angaben, die dieses Geraet hinausschickt, an EINER
 * Stelle statt verstreut in fuenf Bauroutinen.
 *
 * WARUM AN EINER STELLE: ein Test, der die Dichtheit eines Berichts prueft, muss nach genau
 * diesen Werten suchen. Standen sie in fuenf Funktionen, suchte er nach abgetippten Kopien —
 * und eine spaeter geaenderte Angabe waere still ungeprueft geblieben. Ueber opt.angaben
 * setzt der Test eigene Werte ein und kann danach GENAU DIESE suchen.
 *
 * WARUM "Zwirbelhuber" UND NICHT "Muster": beim ersten Lauf der Dichtheitspruefung meldete
 * die Suche nach "Muster" zwei Fundstellen im Bericht — beide waren unser eigenes deutsches
 * Wort ("gegen dieses Muster geprueft") in der Zusage. Nicht der Riegel war blind, sondern
 * der mehrdeutige Suchbegriff. Ein Testname muss ein Wort sein, das in einem deutschen
 * Bericht nicht vorkommen kann.
 *
 * NICHT hier stehen Geschlecht ("W") und Tierart ("Hund"): nach einem einzelnen Buchstaben
 * laesst sich nicht suchen, eine Suche danach waere immer "gefunden" und damit wertlos.
 * Diese Felder deckt der MARKENMODUS ab — dort traegt jedes Feld jedes Segments eine
 * eindeutige, suchbare Marke.
 */
const ANGABEN_VORGABE = {
  rufname: 'Bella',
  nachname: 'Zwirbelhuber',
  kennung: 'T-4711',
  geburt: '20220101',
  akte: 'AKTE-99887',
  tierarzt: 'Dr. Schmitz',
  standort: 'OP1',
  anschrift: 'Hauptstrasse 7',
  telefon: '9988776655',
  alarmtext: 'SpO2 zu tief',
};

// ---------------------------------------------------------------------------------------
// MARKENMODUS — siehe Dateikopf. Alles hier ist ERZEUGEND, nichts ist aufgezaehlt.
// ---------------------------------------------------------------------------------------

/*
 * marke(kennung, feld, komponente) — der eindeutige Text EINES Feldes.
 * "ZZ" vorn und hinten, weil diese Folge in keinem HL7-Telegramm und in keinem deutschen
 * Berichtstext vorkommt: eine Fundstelle im Bericht ist damit immer ein Leck und nie ein
 * zufaelliges Wort (siehe die "Muster"-Falle oben).
 */
function marke(kennung, feld, komponente) {
  return 'ZZ' + kennung + feld + (komponente > 1 ? 'K' + komponente : '') + 'ZZ';
}

/*
 * MARKEN_PLAN — welche Segmente mit wie vielen Feldern erzeugt werden.
 *
 * "fest" nennt die Felder, die ihren ECHTEN Wert behalten muessen, weil die Sonde an ihnen
 * entscheidet, welchen Weg sie geht: ohne "NM" in OBX-2 liefe der NM-Zweig nie, und dann
 * pruefte die Dichtheitsmessung ausgerechnet die Stelle nicht, an der die Lecks sassen. Alle
 * uebrigen Felder tragen Marken.
 * Die Feldnummern sind HL7-Nummern (PID-3 ist wirklich das dritte Feld); bei MSH ist der
 * Index um eins verschoben, weil MSH-1 das Trennzeichen selbst IST.
 *
 * WER HIER EIN FELD ERGAENZT, muss nichts weiter tun: das Geraet erzeugt die Marke, und der
 * Test rechnet sie aus demselben Plan aus und sucht danach.
 */
const MARKEN_PLAN = {
  MSH:     { name: 'MSH', felder: 12, fest: {} },
  /* Dieselbe Nachricht, aber mit gueltigem Kopf: so laeuft sie in der Sonde durch die volle
   * Deutung (Typ, Control-ID, Messwert) — und die Marken in allen anderen Feldern muessen
   * auch DANN draussen bleiben. Ein Bauplan, den die Sonde gar nicht erst deutet, prueft
   * weniger als einer, den sie vollstaendig verarbeitet. */
  MSHECHT: { name: 'MSH', felder: 12, fest: { 9: 'ORU^R01', 10: '204' } },
  PID:     { name: 'PID', felder: 18, fest: {} },
  PV1:     { name: 'PV1', felder: 20, fest: {} },
  OBR:     { name: 'OBR', felder: 8,  fest: {} },
  OBXNM:   { name: 'OBX', felder: 14, fest: { 2: 'NM' } },
  OBXCE:   { name: 'OBX', felder: 14, fest: { 2: 'CE' } },
  OBXST:   { name: 'OBX', felder: 14, fest: { 2: 'ST' } },
  /* Ein Messwert, den die Sonde wirklich uebernehmen SOLL (Kennziffer 101, Wert 88) — und
   * ringsherum Marken. Damit prueft derselbe Lauf beide Richtungen: was raus muss, bleibt
   * draussen; was drinstehen soll, steht drin. */
  OBXECHT: { name: 'OBX', felder: 14, fest: { 2: 'NM', 3: '101^HR', 5: '88' } },
  NTE:     { name: 'NTE', felder: 4,  fest: {} },
  MSA:     { name: 'MSA', felder: 7,  fest: {} },
  ERR:     { name: 'ERR', felder: 3,  fest: {} },
  QAK:     { name: 'QAK', felder: 4,  fest: {} },
  /* Ein Segment, das die Sonde NICHT kennt. Sie darf davon nur "(unbekanntes Segment)" und
   * Feldzahlen melden — niemals den Namen und niemals einen Inhalt. */
  XYZ:     { name: 'XYZ', felder: 6,  fest: {} },
};

/* Welche Segmente in welcher Nachricht stehen. MSH gehoert in jede: ohne fuehrendes
 * MSH-Segment liest die Sonde den Kopf gar nicht erst. */
const MARKEN_NACHRICHTEN = [
  ['MSH', 'PID', 'PV1', 'OBR', 'OBXNM', 'OBXCE', 'OBXST', 'NTE', 'XYZ'],
  ['MSH', 'MSA', 'ERR', 'QAK'],
  ['MSHECHT', 'PID', 'PV1', 'OBR', 'OBXECHT', 'NTE'],
];

/*
 * markenSegment(kennung) — EIN Segment aus dem Plan.
 * Der Segmentname selbst (Feld 0) bleibt echt: er ist kein Datenfeld, und ohne ihn wuesste
 * die Sonde nicht, welches Segment sie beschreibt — dann pruefte der Lauf nicht die
 * Dichtheit, sondern nur die Unlesbarkeit.
 */
function markenSegment(kennung) {
  const p = MARKEN_PLAN[kennung];
  if (!p) return '';
  const teile = [p.name];
  for (let nr = 1; nr <= p.felder; nr++) {
    // MSH: arr[i] ist MSH-(i+1), das erste Datenfeld hinter dem Namen ist also MSH-2.
    const feldNr = p.name === 'MSH' ? nr + 1 : nr;
    if (Object.prototype.hasOwnProperty.call(p.fest, feldNr)) { teile.push(p.fest[feldNr]); continue; }
    teile.push(marke(kennung, feldNr) + '^' + marke(kennung, feldNr, 2));
  }
  return teile.join('|');
}

function markenNachricht(i) {
  return MARKEN_NACHRICHTEN[i].map(markenSegment).join('\r');
}

/*
 * PROFILE. 'tolerant' bildet ausdruecklich den ALTEN, blinden Zustand nach — es gibt ihn nur,
 * damit ein Test zeigen kann, dass er blind IST (eine Pruefung, die nie rot werden kann, ist
 * keine Pruefung). Wer damit misst, misst sein eigenes Testgeraet, nicht seinen Code.
 *
 * JEDES PROFIL WIRD VON EINEM TEST GEFAHREN (nachgezogen 28.08.2026). Vorher standen hier
 * 'tolerant' und 'ohne-echopflicht' unbenutzt herum — und der Dateikopf begruendete
 * 'tolerant' als Blindheitsprobe, die niemand eingeloest hat. Eine Datei darf keinen Anlass
 * behaupten, den sie nicht einloest; wo die Probe jetzt steht, ist je Profil vermerkt.
 *
 * periodikOhneAbfrage: das Geraet schickt die laufenden Messwerte, OHNE dass eine Abfrage
 * kam. Der Guide beschreibt so ein Geraet NICHT (6.3.3 Punkt 3 haengt die Periodik
 * ausdruecklich an die QRY). Die Feldsonde hat dafuer trotzdem einen eigenen Urteilszweig —
 * "der Fehler liegt nicht an der Abfrage, sondern an der Auswertung in der Station" —, und
 * dieser Zweig war im ganzen Bestand unerreichbar, weil sendePeriodik() ohne angenommene
 * Abfrage grundsaetzlich schwieg. Ein Urteil, das kein Testgeraet ausloesen kann, ist eine
 * unbelegte Behauptung; dieses Profil loest es aus.
 */
const PROFILE = {
  /* Der Regelfall, gefahren von pds-streng-test.js und pds-feldsonde-test.js. Seit dem
   * 29.08.2026 als EINZIGES Profil mit crPflicht — Begruendung im Dateikopf. */
  'streng':
    { formPflicht: true,  msh10Pflicht: true,  echoPflicht: true,  fremdTrennt: true,
      crPflicht: true,  maxIds: 4, periodikOhneAbfrage: false },
  /* Zweites bekanntes Fehlerbild in pds-feldsonde-test.js: dort laeuft schon Variante 2. */
  'nur-msh10':
    { formPflicht: false, msh10Pflicht: true,  echoPflicht: false, fremdTrennt: false,
      crPflicht: false, maxIds: 0, periodikOhneAbfrage: false },
  /* Probe "das Echo ist NICHT die Ursache": Form und Kennung muessen stimmen, das fehlende
   * Echo und das fremde ACK kosten aber nichts. Damit laeuft Variante 2 durch, obwohl sie
   * weder echot noch das ACK weglaesst — gegen 'streng' reisst genau sie ab.
   * Gefahren in pds-feldsonde-test.js — und seit dem 29.08.2026 auch in pds-streng-test.js,
   * Abschnitt (a2): dieses Profil ist die Lesart, die sich am ECHTEN uMEC12 bestaetigt hat
   * (er verlangt kein Echo und trennt nicht wegen unserer Quittung), und nur an ihm laeuft
   * die Periodik im Strom statt eine einzige Nachricht lang. */
  'ohne-echopflicht':
    { formPflicht: true,  msh10Pflicht: true,  echoPflicht: false, fremdTrennt: false,
      crPflicht: false, maxIds: 4, periodikOhneAbfrage: false },
  /* Die Blindheitsprobe. Gefahren in pds-feldsonde-test.js: dort muss schon Variante 1 —
   * der Stand VOR der Berichtigung vom 29.08.2026 — als Erfolg gemeldet werden. Genau
   * deshalb darf hier auch das <CR> nicht verlangt werden: Variante 1 hat keines. */
  'tolerant':
    { formPflicht: false, msh10Pflicht: false, echoPflicht: false, fremdTrennt: false,
      crPflicht: false, maxIds: 0, periodikOhneAbfrage: false },
  /* Das Geraet, das von sich aus sendet. Gefahren in pds-feldsonde-test.js mit Variante 8. */
  'sendet-von-selbst':
    { formPflicht: true,  msh10Pflicht: true,  echoPflicht: false, fremdTrennt: false,
      crPflicht: false, maxIds: 4, periodikOhneAbfrage: true },
};

function zwei(n) { return (n < 10 ? '0' : '') + n; }
/* Ortszeit, 14-stellig. Das Geraet selbst stempelt in seiner eigenen Zeit — welche das ist,
 * sagt der Guide nirgends, also nimmt das Testgeraet die des Rechners. */
function ts14() {
  const d = new Date();
  return String(d.getFullYear()) + zwei(d.getMonth() + 1) + zwei(d.getDate()) +
    zwei(d.getHours()) + zwei(d.getMinutes()) + zwei(d.getSeconds());
}

function felder(seg) { return seg.split('|'); }
function segmente(text) { return String(text).split(/[\r\n]+/).map((s) => s.trim()).filter(Boolean); }

/*
 * PRUEFUNG DER ABFRAGE.
 * Liefert { gueltig, gruende: [Klartext], ids: [...], sendAlle, sendTypen: [...] }.
 * Jeder Grund ist ein ganzer deutscher Satz, weil er im Bericht landet und dort jemand liest,
 * der den Guide NICHT vor sich hat.
 */
function pruefeAbfrage(text, regeln) {
  const gruende = [];
  const segs = segmente(text);
  const ids = [];
  const sendTypen = [];
  let sendAlle = false;

  if (!segs.length || segs[0].slice(0, 3) !== 'MSH') {
    return {
      gueltig: false, ids: [], sendAlle: false, sendTypen: [],
      gruende: ['Die Nachricht beginnt nicht mit einem MSH-Segment.'],
    };
  }

  const msh = felder(segs[0]);
  const typ = msh[8] || '';
  const ctrl = msh[9] || '';
  const version = msh[11] || '';

  if (typ !== 'QRY^R02') {
    gruende.push('MSH-9 ist "' + typ + '" statt "QRY^R02" — das ist keine Abfrage.');
  }
  /* Die 1203-Regel steht als NOTE in Guide 6.9.3: "the Message Control ID of the 10th field
   * must be 1203 Otherwise, it cannot be resolved." Genau hier scheitert die Abfrage, die
   * bridge/src/adapters/hl7.js heute sendet (dort steht eine laufende Nummer). */
  if (regeln.msh10Pflicht && ctrl !== '1203') {
    gruende.push('MSH-10 ist "' + ctrl + '" statt "1203". Das echte Geraet meldet dazu ' +
      '"cannot be resolved" und tut danach kommentarlos NICHTS.');
  }

  /*
   * DAS ABSCHLIESSENDE <CR> (nachgeruestet 29.08.2026) — siehe Dateikopf, Abschnitt
   * "gruen hiess mit sich selbst einig".
   *
   * Geprueft wird am ROHTEXT, nicht an segmente(): dort faellt ein leeres letztes Stueck
   * durch das filter(Boolean), ein fehlendes <CR> ist danach unsichtbar. Genau daran ist der
   * Mangel wochenlang unbemerkt geblieben.
   * Der Text ist die MLLP-NUTZLAST (alles zwischen <VT> und <FS>); das <CR> des Rahmens
   * gehoert NICHT dazu und kann hier nichts vortaeuschen.
   */
  if (regeln.crPflicht && String(text).slice(-1) !== '\r') {
    gruende.push('Hinter dem letzten Segment fehlt der Wagenruecklauf <CR>. Der Guide setzt ' +
      'ihn in jedem Beispiel (6.9.2, 6.9.6, 6.7) hinter JEDES Segment; eine formwidrige ' +
      'Nachricht wird nach 6.9.7 ohne jede Rueckmeldung verworfen. Am echten uMEC12 gemessen ' +
      '(29.08.2026): ohne dieses eine Zeichen kommt keine Periodik.');
  }

  if (regeln.formPflicht) {
    if (version && version !== '2.3.1') {
      gruende.push('MSH-12 (Version) ist "' + version + '" statt "2.3.1".');
    }

    const qrd = segs.filter((s) => s.slice(0, 3) === 'QRD');
    if (!qrd.length) {
      gruende.push('Es fehlt das QRD-Segment (die eigentliche Abfrage).');
    } else {
      const f = felder(qrd[0]);
      const zeit = f[1] || '';
      // NUR die Form, NICHT die Zeitzone — siehe Dateikopf.
      if (!/^\d{14}(\d{3})?$/.test(zeit)) {
        gruende.push('QRD-1 ist kein gueltiger Zeitstempel ("' + zeit + '"); erwartet sind ' +
          '14 oder 17 Ziffern (YYYYMMDDhhmmss[000]).');
      }
      if ((f[2] || '') !== 'R') {
        gruende.push('QRD-2 ist "' + (f[2] || '') + '" statt "R".');
      }
      // Widerspruch im Guide: Tabelle+Beispiele "I", Fliesstext "1". Beides gilt hier.
      if ((f[3] || '') !== 'I' && (f[3] || '') !== '1') {
        gruende.push('QRD-3 ist "' + (f[3] || '') + '" statt "I" (der Guide nennt an einer ' +
          'Stelle auch "1"; beides wird angenommen).');
      }
      const kennung = f[4] || '';
      if (!kennung) {
        gruende.push('QRD-4 (Abfragekennung) ist leer.');
      } else if (Buffer.byteLength(kennung, 'utf8') >= 16) {
        gruende.push('QRD-4 ist mit ' + Buffer.byteLength(kennung, 'utf8') +
          ' Byte zu lang (erlaubt sind unter 16 Byte).');
      }
      if ((f[9] || '') !== 'RES') {
        gruende.push('QRD-9 ist "' + (f[9] || '') + '" statt "RES".');
      }
    }

    const qrf = segs.filter((s) => s.slice(0, 3) === 'QRF');
    if (!qrf.length) {
      gruende.push('Es fehlt jedes QRF-Segment (der Filter, der sagt WAS gesendet werden soll).');
    }
    let ersteAdresse = null;
    const freqJeTyp = {};
    qrf.forEach((seg, i) => {
      const f = felder(seg);
      const nr = 'QRF-Segment ' + (i + 1) + ': ';
      if ((f[1] || '') !== 'MON') {
        gruende.push(nr + 'QRF-1 ist "' + (f[1] || '') + '" statt "MON".');
      }
      const filter = f[5] || '';
      if (!filter) { gruende.push(nr + 'QRF-5 ist leer.'); return; }
      const t = filter.split('^');
      if (t.length < 4) {
        gruende.push(nr + 'QRF-5 hat zu wenige Teile ("' + filter + '"); erwartet ist ' +
          '<IP>&<IPSeq>^<SendType>^<SendFreq>^<SendAll>^<Liste>.');
        return;
      }
      const adresse = t[0], sendType = t[1], sendFreq = t[2], sendAll = t[3], liste = t[4] || '';
      // Direkt am Bett steht dort 0&0; eine IP als 32-Bit-Zahl gilt nur ueber ein CMS/Gateway.
      if (adresse !== '0&0') {
        gruende.push(nr + 'die Zieladresse ist "' + adresse + '" statt "0&0" (direkt am Bett).');
      }
      if (ersteAdresse === null) ersteAdresse = adresse;
      else if (adresse !== ersteAdresse) {
        gruende.push(nr + 'die Zieladresse weicht vom ersten QRF-Segment ab — alle Filter ' +
          'einer Abfrage muessen dieselbe tragen.');
      }
      if (sendType === '0') {
        gruende.push(nr + 'SendType 0 ist ungueltig.');
      } else if (sendType === '2') {
        gruende.push(nr + 'SendType 2 ist im Guide als reserviert gekennzeichnet.');
      } else if (['1', '3', '4', '5'].indexOf(sendType) < 0) {
        gruende.push(nr + 'SendType "' + sendType + '" ist unbekannt (1=Parameter, ' +
          '3=physiologische Alarme, 4=technische Alarme, 5=Konfiguration).');
      }
      const freq = Number(sendFreq);
      if (!Number.isInteger(freq) || freq < 1 || freq > 3600) {
        gruende.push(nr + 'SendFreq "' + sendFreq + '" liegt ausserhalb 1..3600 Sekunden.');
      } else if (freqJeTyp[sendType] === undefined) {
        freqJeTyp[sendType] = freq;
      } else if (freqJeTyp[sendType] !== freq) {
        gruende.push(nr + 'fuer SendType ' + sendType + ' stehen zwei verschiedene Sendetakte ' +
          'in derselben Abfrage.');
      }
      if (sendAll !== '0' && sendAll !== '1') {
        gruende.push(nr + 'SendAll ist "' + sendAll + '" statt 0 (Liste gilt) oder 1 (alles).');
      }
      const teile = liste ? liste.split('&').filter(Boolean) : [];
      if (sendAll === '0' && !teile.length) {
        gruende.push(nr + 'SendAll ist 0, aber es steht keine Parameterliste dahinter.');
      }
      if (sendAll === '1' && teile.length) {
        gruende.push(nr + 'SendAll ist 1 (alles), trotzdem steht eine Parameterliste dahinter.');
      }
      /* Guide 6.9.5.1 woertlich: "The amount of <ID> in each Query Filter is less than 5" —
       * also hoechstens VIER. Kein Beispiel im ganzen Dokument nutzt fuenf. Der Guide setzt
       * gleich hinterher, die Hoechstzahl sei je Modell verschieden; vier ist die sichere Seite. */
      if (regeln.maxIds && teile.length > regeln.maxIds) {
        gruende.push(nr + teile.length + ' Parameter-IDs in einem Segment; erlaubt sind ' +
          'hoechstens ' + regeln.maxIds + ' (Guide: "less than 5").');
      }
      teile.forEach((id) => {
        if (!/^\d+$/.test(id)) gruende.push(nr + 'die Parameter-ID "' + id + '" ist keine Zahl.');
      });
      if (sendTypen.indexOf(sendType) < 0) sendTypen.push(sendType);
      if (sendType === '1') {
        if (sendAll === '1') sendAlle = true;
        teile.forEach((id) => { if (ids.indexOf(id) < 0) ids.push(id); });
      }
    });
  } else {
    /* Ohne Formpflicht wird der Wunsch trotzdem gelesen — sonst kaeme im Profil 'tolerant'
     * gar keine Periodik und der "blinde" Vergleichsfall waere selbst unbrauchbar. */
    segs.filter((s) => s.slice(0, 3) === 'QRF').forEach((seg) => {
      const t = (felder(seg)[5] || '').split('^');
      if (t[1] && sendTypen.indexOf(t[1]) < 0) sendTypen.push(t[1]);
      if (t[1] !== '1') return;
      if (t[3] === '1') sendAlle = true;
      (t[4] || '').split('&').filter(Boolean).forEach((id) => { if (ids.indexOf(id) < 0) ids.push(id); });
    });
    if (!sendTypen.length) { sendTypen.push('1'); sendAlle = true; }
  }

  return {
    gueltig: gruende.length === 0, gruende: gruende,
    ids: ids, sendAlle: sendAlle, sendTypen: sendTypen,
  };
}

/*
 * starte(opt) -> geraet
 * opt: { port, host, profil, echoMs, echoFristMs, periodikMs, aperiodikMs, werte,
 *        antwortAufFehler, onLog, onBereit }
 * port 0 heisst: das Betriebssystem sucht einen freien Port. Die Nummer steht danach in
 * geraet.port und wird an bereit(cb) uebergeben — feste Portnummern haben in dieser Sitzung
 * zweimal ein EADDRINUSE erzeugt, weil zwei Testlaeufe gleichzeitig liefen.
 */
function starte(opt) {
  opt = opt || {};
  const profilName = PROFILE[opt.profil] ? opt.profil : 'streng';
  const regeln = PROFILE[profilName];
  const host = opt.host || '127.0.0.1';
  const echoMs = opt.echoMs || 1000;
  const echoFristMs = opt.echoFristMs || 10000;
  const periodikMs = opt.periodikMs || 1000;
  const aperiodikMs = opt.aperiodikMs || 3000;
  const werte = opt.werte || {
    '101': 88, '151': 14, '160': 96, '161': 88, '170': 110, '171': 70,
    '172': 83, '200': 38.2, '220': 39, '222': 14,
  };
  const onLog = typeof opt.onLog === 'function' ? opt.onLog : function () {};
  /* onSende bekommt JEDE Nutzlast, die wirklich hinausgegangen ist. Ohne diesen Haken muesste
   * ein Dichtheitstest annehmen, dass die gesuchte Angabe auf der Leitung war — und eine
   * Suche, die nichts findet, weil der Begriff nie gesendet wurde, ist kein Nachweis,
   * sondern eine Pruefung ohne Anlass. */
  const onSende = typeof opt.onSende === 'function' ? opt.onSende : function () {};

  /* Die personenbezogenen Angaben. Vorgabe ist ANGABEN_VORGABE; ein Test setzt eigene ein
   * und sucht danach im Bericht. */
  const ang = {};
  Object.keys(ANGABEN_VORGABE).forEach(function (k) { ang[k] = ANGABEN_VORGABE[k]; });
  if (opt.angaben) {
    Object.keys(opt.angaben).forEach(function (k) { ang[k] = opt.angaben[k]; });
  }

  /* Markenmodus: statt Patientendaten, NIBP, Alarmen und Periodik gehen die Marken-
   * nachrichten hinaus — und sonst NICHTS. So enthaelt die Leitung ausschliesslich Marken,
   * und jede Fundstelle im Bericht ist eindeutig einem Feld zuzuordnen. */
  const marken = opt.marken === true;
  const markenMs = opt.markenMs || 250;

  /* Vorgabe AUS: das Praxisgeraet schweigt auf eine verworfene Abfrage (vier NOTEs im Guide).
   * Wer die andere Lesart messen will, schaltet sie ausdruecklich ein. */
  const antwortAufFehler = opt.antwortAufFehler === true;
  const zaehler = {
    abfragen: [], gesendetNm: 0, gesendetAperiodisch: 0, fehlerAntworten: 0,
    trennungen: 0, echosEmpfangen: 0, verbindungen: 0, gesendetMarken: 0,
  };
  const offen = new Set();          // alle lebenden Verbindungen, fuer stop()
  let gestoppt = false;

  function pid() {
    /* PID-10 traegt die Patientenkategorie — beim Tiermonitor die Tierart.
     * PID-11 (Anschrift) und PID-13 (Telefon) stehen seit 28.08.2026 dabei: der Guide fuehrt
     * sie in 6.5.1.5, und sie sind Angaben ueber den HALTER. Sie fehlten hier, also konnte
     * kein Test je zeigen, ob sie im Befund landen. */
    return 'PID|||' + ang.kennung + '||' + ang.rufname + '^' + ang.nachname + '||' +
      ang.geburt + '|W||Hund|' + ang.anschrift + '||' + ang.telefon + '|';
  }

  /*
   * PV1 — und warum es in JEDER Nachricht steht.
   * docs/MINDRAY-HL7.md haelt am gemessenen Mitschnitt des Praxis-LifeVet fest:
   * "MSH | PID (ID, Name, Geschlecht) | PV1 | OBR | OBX(...)" — PV1 kommt also immer mit.
   * Feldlage nach Guide 6.5.1.6: PV1-2 Patientenklasse ("I"), PV1-3 der Standort in der Form
   * <Abteilung>&<Bett>&<IP als 32-Bit-Zahl>&<Port>&<Aufnahmekennzeichen>, PV1-7 der
   * behandelnde Arzt (so abgedruckt in den Beispielen 2.2.5/4.3.8: "....|DoctorA|"),
   * PV1-18 die Patientenart. 3232235570 ist 192.168.0.50 — die im Haus abgelesene Adresse
   * des uMEC12 (docs/MINDRAY-HL7.md, Tabelle "Die Geraete, die wirklich in der Praxis
   * stehen"). Standort UND Arztname sind personenbezogen und duerfen in keinen Bericht.
   */
  function pv1() {
    return 'PV1||I|^^' + ang.standort + '&3&3232235570&4601&0||||' + ang.tierarzt +
      '|||||||||||A|';
  }

  function obxNm(id, wert) {
    // Aufbau wie im Guide 6.10.1.3 abgedruckt: OBX||NM|101^HR|2101|60||||||F
    const modul = MODUL_JE_ID[id] || '2101';
    const name = NAME_JE_ID[id] || ('P' + id);
    return 'OBX||NM|' + id + '^' + name + '|' + modul + '|' + wert + '||||||F';
  }

  function kopf(ctrlId) {
    return 'MSH|^~\\&|Mindray|uMEC12 Vet|||' + ts14() + '||ORU^R01|' + ctrlId + '|P|2.3.1|';
  }

  function sende(v, text) {
    if (!v.sock || v.sock.destroyed) return false;
    try {
      v.sock.write(mllp(text));
      /* Erst NACH dem erfolgreichen Schreiben melden: was nicht hinausging, darf ein Test
       * nicht als "war auf der Leitung" zaehlen. */
      onSende(text);
      return true;
    } catch (e) { return false; }
  }

  // ---- Nachrichten, die das Geraet von sich aus schickt -------------------------------

  function sendePatient(v) {
    /* Guide 6.3.3 Punkt 1: gleich nach dem Verbindungsaufbau, ohne jede Abfrage.
     * Der Aufbau ist der der "Patient Information Change"-Nachricht aus docs/MINDRAY-HL7.md:
     * sie kommt NUR beim Verbindungsaufbau und traegt neben Gewicht und Groesse die am
     * Monitor eingetippte Aktennummer in OBX||ST|2301^MRN|| (Guide Anhang B.4, dort woertlich
     * "OBX||ST|2301^||Mindray23445||||||F"). Genau dieses Feld ist eines der drei Lecks, an
     * denen die alte Maskierung der Feldsonde vorbeilief — die Sonde baut acht Verbindungen
     * auf und bekam die Nachricht damit achtmal. */
    sende(v, [
      kopf('103'), pid(), pv1(),
      'OBX||ST|2301^MRN||' + ang.akte + '||||||F',
    ].join('\r'));
  }

  /* sendeMarken(v) — der Markenmodus. Eine Nachricht je Eintrag in MARKEN_NACHRICHTEN,
   * gebaut aus MARKEN_PLAN. Nichts hier ist abgetippt: wer dem Plan ein Feld gibt, sendet es
   * ab dem naechsten Lauf mit. */
  function sendeMarken(v) {
    for (let i = 0; i < MARKEN_NACHRICHTEN.length; i++) {
      if (sende(v, markenNachricht(i))) zaehler.gesendetMarken++;
    }
  }

  /*
   * WARUM HIER KEIN GEWICHT UND KEINE GROESSE STEHEN — ein Befund vom 28.08.2026, der NICHT
   * in diese Datei gehoert und deshalb hier nur festgehalten wird:
   *
   * Die "Patient Information Change"-Nachricht des echten Geraets traegt neben der
   * Aktennummer auch "OBX||NM|51^Weight||15.0||||||F" und "OBX||NM|52^Height||62.0||||||F"
   * (docs/MINDRAY-HL7.md, Guide Anhang B.4). Beide sind vom Werttyp NM und tragen KEIN
   * "APERIODIC"; die Nachricht hat die Control-ID 103, nicht 204.
   *
   * tools/pds-feldsonde.js zaehlt jede Nachricht mit NM-Werten, die nicht als aperiodisch
   * erkannt ist, als LAUFENDEN MESSWERT (deute() + verarbeite(): periodikRahmen++). Gemessen:
   * fuegt man die beiden Zeilen hier ein, meldet Variante 8 am strengen Geraet
   * "referenz-mit-periodik" — also "das Geraet sendet Messwerte SCHON OHNE Abfrage" — und das
   * Gesamturteil schickt den Entwickler in die Auswertung der Station statt in die Abfrage.
   * Ein falsches Urteil aus einer Nachricht, die JEDES PDS-Geraet beim Verbindungsaufbau
   * schickt. Am Praxis-PC traefe es also mit hoher Wahrscheinlichkeit zu.
   *
   * Behoben werden muss das in der Sonde (Gewicht und Groesse sind Stammdaten, keine
   * Verlaufsmessung), nicht hier. Bis dahin bleiben die beiden Zeilen draussen, damit dieses
   * Testgeraet nicht einen Fehler NACHSTELLT, den kein Test beurteilen soll — wer sie
   * einfuegt, moege zuerst die Sonde nachziehen.
   */

  /*
   * sendeFehlerAntwort() — nur mit opt.antwortAufFehler, siehe Dateikopf.
   *
   * WARUM DIE PATIENTENDATEN AUSGERECHNET HIER STEHEN: sie stehen nicht zur Zierde da. Die
   * Ueberlegung "unsere Abfrage enthaelt keine Patientendaten, also kann die Beanstandung
   * daran auch keine enthalten" ist falsch — das Geraet antwortet mit SEINEM Wissen. MSA-3
   * (Textmeldung) und die fuenfte Komponente von ERR-1 sind Freitextfelder; ein Geraet darf
   * dort den Patienten hineinschreiben. Ein Testgeraet, das hier hoeflich bleibt, laesst die
   * Maskierung der Sonde ungeprueft.
   * Codes: MSA-1 "AR" = Application Reject, MSA-6 der Fehlercode, QAK-2 "AE" = Application
   * Error. Sie muessen im Bericht STEHEN BLEIBEN, denn sie sind der ganze Wert des Segments.
   */
  function sendeFehlerAntwort(v, ctrl, kennung) {
    const t = ts14();
    const name = ang.rufname + '^' + ang.nachname;
    const ok = sende(v, [
      'MSH|^~\\&|Mindray|uMEC12 Vet|||' + t + '||ACK^R01|' + ctrl + '|P|2.3.1|',
      'MSA|AR|' + ctrl + '|Abfrage abgelehnt fuer ' + name + ', Akte ' + ang.akte + '|||206',
      'ERR|QRD^1^10^206^unbekannte Kennung fuer ' + name,
      /* QAK-3 traegt hier den Namen. Es war eines der fuenf Felder, die am 28.08.2026 offen
       * standen, waehrend der bewachende Test gruen war — deshalb steht es jetzt ausdruecklich
       * gefuellt auf der Leitung, damit die Dichtheit dort einen Anlass hat. */
      'QAK|' + (kennung || '') + '|AE|' + name,
    ].join('\r'));
    if (ok) zaehler.fehlerAntworten++;
  }

  function sendeAperiodisch(v) {
    /* Guide 6.3.3 Punkte 2 und 5: NIBP und Alarme kommen UNAUFGEFORDERT. Genau das sieht der
     * Tierarzt heute — und genau deshalb sah es so aus, als "liefe" die Anbindung.
     * Achtung fuer Tests: auch die NIBP-Zeilen sind vom Typ NM. Periodik erkennt man NICHT
     * am Wort NM, sondern an der Message Control ID 204 bzw. am fehlenden "APERIODIC". */
    const t = ts14();
    const nibp = [kopf('503'), pid(), pv1(), 'OBR||||MON|||' + t + '|'];
    ['170', '171', '172'].forEach((id) => {
      if (werte[id] === undefined) return;
      const modul = MODUL_JE_ID[id], name = NAME_JE_ID[id];
      nibp.push('OBX||NM|' + id + '^' + name + '|' + modul + '|' + werte[id] +
        '||||||F||APERIODIC|' + t);
    });
    if (sende(v, nibp.join('\r'))) zaehler.gesendetAperiodisch++;

    /* Physiologischer Alarm im Format des uMEC: "PrioCode^Klartext".
     * Der Klartext traegt hier den PATIENTENNAMEN. Das ist kein ausgedachter Sonderfall:
     * OBX-5 ist laut Guide 2.2.7.4 Freitext ("in mehreren Sprachen"), und Monitore setzen in
     * ihre Alarmzeile regelmaessig den Bettnamen. Es ist das dritte der drei Lecks — und das
     * einzige, das eine "Ausschlussliste" niemals erwischt haette, weil hier ein ERLAUBTES
     * Segment (OBX) in einem ERLAUBTEN Feld (OBX-5) den Namen traegt. */
    const alarm = [kopf('54'), pid(), pv1(),
      'OBX||CE|1^ALARM|2103|10127^**' + ang.alarmtext + ' bei ' + ang.rufname +
      ' (' + ang.kennung + ')||||||F'];
    if (sende(v, alarm.join('\r'))) zaehler.gesendetAperiodisch++;
  }

  function sendePeriodik(v) {
    if (marken) return;                          // im Markenmodus geht nur Markentext hinaus
    if (!v.wunsch) return;                       // ohne gueltige Abfrage gibt es keine Periodik
    const ids = v.wunsch.sendAlle ? Object.keys(werte)
      : v.wunsch.ids.filter((id) => werte[id] !== undefined);
    if (!ids.length) return;
    const zeilen = [kopf('204'), pid(), pv1(), 'OBR||||MON|||' + ts14() + '|'];
    ids.forEach((id) => zeilen.push(obxNm(id, werte[id])));
    if (sende(v, zeilen.join('\r'))) zaehler.gesendetNm++;
  }

  function sendeEcho(v) {
    // Guide 6.7, woertlich abgedruckte Form. Kein Segment dahinter.
    sende(v, 'MSH|^~\\&|||||||ORU^R01|106|P|2.3.1|');
  }

  // ---- Verbindungsverwaltung ---------------------------------------------------------

  function trenne(v, grund) {
    if (v.tot) return;
    v.tot = true;
    zaehler.trennungen++;
    onLog('Verbindung ' + v.nr + ' getrennt: ' + grund);
    raeumeTimer(v);
    try { v.sock.destroy(); } catch (e) {}
    offen.delete(v);
  }

  function raeumeTimer(v) {
    [v.tEcho, v.tWacht, v.tPeriodik, v.tAperiodik].forEach((t) => { if (t) clearInterval(t); });
    v.tEcho = v.tWacht = v.tPeriodik = v.tAperiodik = null;
  }

  function behandle(v, text) {
    const segs = segmente(text);
    if (!segs.length) return;
    const msh = felder(segs[0]);
    const typ = msh[8] || '';
    const ctrl = msh[9] || '';

    // 1) Echo des Clients (Guide 6.7): ORU^R01 mit Control-ID 106 und ohne weitere Segmente.
    if (typ === 'ORU^R01' && ctrl === '106' && segs.length === 1) {
      zaehler.echosEmpfangen++;
      v.letztesEcho = Date.now();
      return;
    }

    // 2) Abfrage.
    if (/^QRY/.test(typ) || segs.some((s) => s.slice(0, 3) === 'QRD')) {
      const urteil = pruefeAbfrage(text, regeln);
      zaehler.abfragen.push({ text: text, gueltig: urteil.gueltig, gruende: urteil.gruende });
      if (!urteil.gueltig) {
        /* KOMMENTARLOS verwerfen — kein ACK, kein NACK, kein QAK, kein ERR. Genau das macht
         * das Praxisgeraet, und genau das konnte hl7-client-test.js nie nachstellen. */
        if (antwortAufFehler) {
          /* Die andere Lesart des Guides, ausdruecklich eingeschaltet. Die Kennung aus QRD-4
           * geht zurueck ins QAK — so steht es in 6.9.7. */
          const qrd = segs.filter((s) => s.slice(0, 3) === 'QRD')[0] || '';
          sendeFehlerAntwort(v, ctrl || '1', felder(qrd)[4] || '');
          onLog('Abfrage ' + zaehler.abfragen.length + ' ABGELEHNT, mit MSA/ERR/QAK ' +
            'beantwortet (opt.antwortAufFehler). Grund: ' + urteil.gruende.join(' | '));
          return;
        }
        onLog('Abfrage ' + zaehler.abfragen.length + ' ABGELEHNT (es geht keine Antwort raus, ' +
          'wie am echten Geraet). Grund: ' + urteil.gruende.join(' | '));
        onLog('   NIBP und Alarme laufen trotzdem weiter — das ist das heutige Krankheitsbild.');
        return;
      }
      v.wunsch = urteil;
      onLog('Abfrage ' + zaehler.abfragen.length + ' angenommen. Ab jetzt kommen die Messwerte ' +
        'im Takt: ' + (urteil.sendAlle ? 'alle Parameter' : urteil.ids.join(', ')));
      if (v.tPeriodik) clearInterval(v.tPeriodik);
      /* Sofort einmal senden: sonst haenge die erste Messung eine ganze Taktlaenge hinterher,
       * und ein kurzer Testlauf saehe wie ein stummes Geraet aus. */
      sendePeriodik(v);
      v.tPeriodik = setInterval(() => sendePeriodik(v), periodikMs);
      return;
    }

    /* 3) Alles andere. Guide 6.3.3 Punkt 9 woertlich: "If other message is sent, the device
     * will disconnect the connection." Erlaubt sind dem Client nur QRY und das Echo — ein
     * HL7-ACK gehoert NICHT dazu. Unser Adapter quittiert im Client-Modus heute jede
     * empfangene Nachricht (_sendAck); das ist ein zweiter, eigener Trenngrund neben dem
     * fehlenden Echo und muss getrennt sichtbar sein. */
    onLog('Verbindung ' + v.nr + ': fremde Nachricht empfangen (' + (typ || '?') + ').');
    if (regeln.fremdTrennt) {
      trenne(v, 'fremde Nachricht "' + (typ || '?') + '" — das echte Geraet trennt hier ' +
        '(Guide 6.3.3 Punkt 9). Ein HL7-ACK ist so eine fremde Nachricht.');
    }
  }

  const server = net.createServer((sock) => {
    zaehler.verbindungen++;
    const v = {
      nr: zaehler.verbindungen, sock: sock, buf: Buffer.alloc(0),
      wunsch: null, letztesEcho: Date.now(), tot: false,
      tEcho: null, tWacht: null, tPeriodik: null, tAperiodik: null,
    };
    offen.add(v);
    onLog('Verbindung ' + v.nr + ' von ' + (sock.remoteAddress || '?') +
      ' — Patientendaten gehen sofort raus, ganz ohne Abfrage.');
    sock.setNoDelay(true);
    if (marken) {
      /* Markenmodus: KEIN Patient, KEINE NIBP, KEINE Alarme — sonst laege neben den Marken
       * noch anderer Text auf der Leitung, und eine Fundstelle im Bericht waere nicht mehr
       * eindeutig einem Feld zuzuordnen. */
      sendeMarken(v);
      v.tAperiodik = setInterval(() => sendeMarken(v), markenMs);
    } else {
      sendePatient(v);
      sendeAperiodisch(v);
      v.tAperiodik = setInterval(() => sendeAperiodisch(v), aperiodikMs);
    }
    v.tEcho = setInterval(() => sendeEcho(v), echoMs);
    if (regeln.periodikOhneAbfrage) {
      /* Der Wunsch wird HIER gesetzt, nicht in sendePeriodik(): sonst muesste jede spaetere
       * Abfrage pruefen, ob sie einen erfundenen Wunsch ueberschreibt. So gilt die normale
       * Regel weiter — eine gueltige Abfrage ersetzt ihn, eine verworfene nicht. */
      v.wunsch = { gueltig: true, gruende: [], ids: [], sendAlle: true, sendTypen: ['1'] };
      sendePeriodik(v);
      v.tPeriodik = setInterval(() => sendePeriodik(v), periodikMs);
    }
    if (regeln.echoPflicht) {
      /* Guide 6.7: bleibt das Echo der Gegenseite 10 s aus, trennt das Geraet. Die Frist
       * laeuft ab dem Verbindungsaufbau — ein Client, der nie echot, faellt also von selbst
       * raus, auch wenn seine Abfrage tadellos war. */
      v.tWacht = setInterval(() => {
        if (Date.now() - v.letztesEcho > echoFristMs) {
          trenne(v, 'seit ' + Math.round(echoFristMs / 1000) + ' s kein Echo vom Rechner ' +
            '(Guide 6.7 verlangt es jede Sekunde in BEIDE Richtungen).');
        }
      }, Math.max(200, Math.min(500, echoFristMs / 4)));
    }

    sock.on('data', (chunk) => {
      v.buf = Buffer.concat([v.buf, chunk]);
      /* Mehrere Rahmen in EINEM Paket und halbe Rahmen ueber Paketgrenzen kommen am echten
       * Geraet beide vor — deshalb wird gepuffert, genau wie im Adapter (hl7.js). */
      let start;
      while ((start = v.buf.indexOf(VT)) !== -1) {
        const ende = v.buf.indexOf(FS, start + 1);
        if (ende === -1) break;                       // Rahmen noch nicht vollstaendig
        const payload = v.buf.slice(start + 1, ende).toString('latin1');
        v.buf = v.buf.slice(ende + 2);                // FS + CR ueberspringen
        behandle(v, payload);
        if (v.tot) return;
      }
      if (v.buf.length > (1 << 20)) v.buf = Buffer.alloc(0);   // Schutz gegen Muell
    });
    sock.on('error', () => {});
    sock.on('close', () => {
      raeumeTimer(v);
      offen.delete(v);
      if (!v.tot) { v.tot = true; onLog('Verbindung ' + v.nr + ' vom Rechner aus geschlossen.'); }
    });
  });

  server.on('error', (e) => { onLog('Serverfehler: ' + (e && e.message ? e.message : String(e))); });

  const geraet = {
    port: opt.port || 0,
    profil: profilName,
    bericht: function () {
      return {
        abfragen: zaehler.abfragen.map(function (a) {
          return { text: a.text, gueltig: a.gueltig, gruende: a.gruende.slice() };
        }),
        gesendetNm: zaehler.gesendetNm,
        gesendetAperiodisch: zaehler.gesendetAperiodisch,
        gesendetMarken: zaehler.gesendetMarken,
        fehlerAntworten: zaehler.fehlerAntworten,
        trennungen: zaehler.trennungen,
        echosEmpfangen: zaehler.echosEmpfangen,
        verbindungen: zaehler.verbindungen,
      };
    },
    /* bereit(cb) gibt es, weil geraet.port erst nach dem Binden feststeht (bei port 0 sucht
     * das Betriebssystem einen freien). Wer sofort nach starte() verbindet, laeuft sonst in
     * ein Wettrennen — das kostet spaeter eine Stunde Fehlersuche an der falschen Stelle. */
    bereit: function (cb) {
      if (!cb) return;
      if (server.listening) cb(geraet.port); else server.once('listening', () => cb(geraet.port));
    },
    stop: function (cb) {
      if (gestoppt) { if (cb) cb(); return; }
      gestoppt = true;
      offen.forEach((v) => { raeumeTimer(v); try { v.sock.destroy(); } catch (e) {} });
      offen.clear();
      try { server.close(() => { if (cb) cb(); }); } catch (e) { if (cb) cb(); }
    },
  };

  server.listen(opt.port || 0, host, () => {
    geraet.port = server.address().port;
    onLog('Testgeraet laeuft auf ' + host + ':' + geraet.port + ', Profil "' + profilName + '".');
    if (typeof opt.onBereit === 'function') opt.onBereit(geraet.port);
  });

  return geraet;
}

module.exports = {
  starte, pruefeAbfrage, PROFILE,
  /* Der Markenmodus und die Angaben sind ausdruecklich exportiert, damit ein Test die
   * gesuchten Zeichenketten AUSRECHNEN kann statt sie abzutippen. Eine abgetippte Liste
   * waere wieder eine Aufzaehlung — und genau daran ist die vorige Dichtheitspruefung
   * gescheitert. */
  ANGABEN_VORGABE, MARKEN_PLAN, MARKEN_NACHRICHTEN, marke, markenSegment, markenNachricht,
};

// ---- CLI ------------------------------------------------------------------------------

if (require.main === module) {
  const args = process.argv.slice(2);
  function arg(name, vorgabe) {
    const i = args.indexOf('--' + name);
    return i >= 0 && args[i + 1] !== undefined ? args[i + 1] : vorgabe;
  }
  const still = args.indexOf('--still') >= 0;
  const sekunden = Number(arg('sekunden', 0));
  const geraet = starte({
    port: Number(arg('port', 4601)),
    host: arg('host', '127.0.0.1'),
    profil: arg('profil', 'streng'),
    antwortAufFehler: args.indexOf('--fehlerantwort') >= 0,
    /* --marken: nur Markentext auf die Leitung. Damit laesst sich von Hand nachsehen, was
     * eine Sonde aus einem Feld macht, ohne dafuer echte Patientendaten zu erfinden. */
    marken: args.indexOf('--marken') >= 0,
    onLog: still ? function () {} : function (z) { console.log('[PDS] ' + z); },
  });
  if (!still) {
    console.log('[PDS] Ein strenges Mindray-Testgeraet. Es verwirft eine formwidrige Abfrage');
    console.log('[PDS] kommentarlos und schickt trotzdem Patient, NIBP und Alarme weiter —');
    console.log('[PDS] genau so, wie es das Geraet in der Praxis tut. Beenden mit Strg+C.');
  }
  /* Selbstabschaltung: ein vergessenes Testgeraet haelt node.exe fest und blockiert spaeter
   * den Paketbau (Projektregel). Ohne --sekunden laeuft es wie ein echtes Geraet weiter. */
  if (sekunden > 0) {
    setTimeout(() => {
      geraet.stop(() => {
        if (!still) console.log('[PDS] Zeitlimit erreicht, Testgeraet beendet.');
        process.exit(0);
      });
    }, sekunden * 1000).unref();
  }
  process.on('SIGINT', () => { geraet.stop(() => process.exit(0)); });
}
