'use strict';
/*
 * ekg2000.js — Leser fuer das Eickemeyer/Grimed EKG 2000 (PC-EKG) am USB.
 *
 * WARUM ES DIESE DATEI GIBT (16.08.2026):
 * Der Geraetekatalog nennt seit dem 12.08.2026 den Adapter "ekg2000", es gab ihn aber nicht.
 * Angesteckt wurde das Geraet von Windows eingerichtet, und die Station schwieg dazu.
 *
 * ================================================================================
 * DIE GANZE KETTE, IN DER REIHENFOLGE, IN DER SIE LAEUFT
 * ================================================================================
 *  1. Anschluss oeffnen mit 19200 8E1  (gemessen, siehe ekg2000-protokoll.js)
 *  2. Kennung abfragen: Byte 0x10 -> 0x20 = Bauart 1, 0x21/0x22 = Bauart 2
 *  3. Firmware in das Geraet laden. OHNE DIESEN SCHRITT SENDET ES NICHTS.
 *     Bootlader ":F"+0x80 -> "F_1.0.1", danach 16-Byte-Bloecke ab Adresse 0x8000.
 *     Die Dateien gehoeren dem Hersteller und liegen NICHT im Paket -> ekg2000-firmware.js.
 *  4. Auf 38400 8E1 umschalten (ohne den Anschluss zu schliessen: sonst faellt DTR/RTS ab
 *     und die eben uebertragene Firmware ist wieder weg).
 *  5. 0x90 senden, vier Antwortbytes lesen, 0x88 senden -> der Strom laeuft.
 *  6. Rahmen lesen: 0x80 + je Kanal EINE vorzeichenbehaftete Differenz, aufsummieren.
 *  7. Abtastrate MESSEN (Rahmen je Sekunde gegen die PC-Uhr).
 *
 * ================================================================================
 * WAS GEMELDET WIRD UND WAS NICHT — bitte diesen Absatz lesen, bevor jemand
 * "endlich auch die Vitalwerte" ergaenzt.
 * ================================================================================
 * Gemeldet wird die KURVE in Digits, mit gemessener Abtastrate, ausdruecklich als
 * UNGEEICHT gekennzeichnet (kalibriert:false).
 *
 * NICHT gemeldet werden Millivolt, Amplituden oder abgeleitete Befunde. Grund: die
 * Umrechnung Digit -> Mikrovolt steht NIRGENDS. Sie steht nicht im Handbuch (die
 * "Technischen Daten" nennen nur Empfindlichkeit 5/10/20/40 mm/mV und Vorschub, das ist
 * die Darstellung, nicht die Wandlung) und nicht als Konstante im Herstellerprogramm.
 *
 * Warum das mehr ist als Vorsicht: die EKG-Auswertung dieses Projekts rechnet in mV und ms.
 * Eine geratene Verstaerkung verschoebe JEDE Amplitude linear mit - P-Wellen-Hoehe,
 * R-Zacke, ST-Strecke, Niedervoltage. Das Ergebnis saehe aus wie ein befundetes EKG und
 * waere falsch. Genau diesen Fehlermodus hat das Projekt schon zweimal bezahlt.
 *
 * DER WEG ZUR EICHUNG IST VORBEREITET UND EHRLICH: jedes EKG-Geraet kann einen
 * 1-mV-Eichzacken ausgeben. Wird er einmal aufgezeichnet, ergibt seine Hoehe in Digits die
 * Umrechnung — gemessen, nicht geraten. Sobald cfg.eichungUvProDigit gesetzt ist (aus genau
 * dieser Messung), meldet der Adapter Millivolt und setzt kalibriert:true. Bis dahin
 * schweigt er dazu.
 *
 * HIER STAND "Siehe tools/ekg2000-eichen.js." — DIESE DATEI GIBT ES NICHT (26.08.2026).
 * Der Verweis stand seit dem Bau des Adapters da und zeigte ins Leere; gefunden hat ihn eine
 * fremde Analyse-Ernte, nachgeprueft wurde er hier (Suche nach *eichen* im ganzen Baum:
 * nur dosis-abgleich- und kopfbereich-Dateien). Wer dem Verweis folgte, suchte ein Werkzeug,
 * das nie geschrieben wurde — und haette den Eichablauf fuer erledigt halten koennen.
 * Der WEG oben stimmt weiterhin und ist von Hand gangbar: 1-mV-Eichzacken aufzeichnen
 * (tools/ekg2000-mitschnitt.js), seine Hoehe in Digits ablesen, den Kehrwert als
 * cfg.eichungUvProDigit eintragen. Ein Werkzeug, das das abnimmt, ist offen.
 *
 * STRIKT LESEND, mit zwei eng gefassten Ausnahmen:
 *   - die Auskunftsbytes 0x10 / 0x90 / 0x88 / 0x80 (Erlaubnisliste in seriell.js)
 *   - der Firmware-Upload ueber sendenRoh(), der nur mit firmwareErlaubt:true aufgeht
 * Beides veraendert am Geraet keine Einstellung; das EKG 2000 hat keine.
 *
 * Konfiguration:
 *   { id, type:'ekg2000', port:'COM5', model, kanaele:3|8, betrieb:'ruhe'|'monitor',
 *     firmwareOrdner, eichungUvProDigit, mitschnitt }
 */
const fs = require('fs');
const path = require('path');
const { Adapter } = require('./base');
const { SerielleVerbindung } = require('../seriell');
const P = require('../ekg2000-protokoll');
const FW = require('../ekg2000-firmware');
const format = require('../ekg2000-format');

/* Erst ab dieser Menge lohnt eine Aussage ueber den Aufbau. */
const DEUTUNG_AB_BYTE = 4096;
/* Wie oft die Kurve nach oben gereicht wird. 10/s ist fluessig genug fuers Auge und
 * belastet den Kiosk-i3 nicht - derselbe Takt wie bei den anderen Kurvenlieferanten. */
const AUSGABE_MS = 100;

class EKG2000Adapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.verb = null;
    this.kennung = null;
    this.deutung = null;
    this.bytes = 0;
    this.puffer = [];
    this.gesammelt = 0;
    this.aufbau = null;
    this.kanaeleErkannt = null;  /* am Geraet gemessen, siehe _leserStarten */
    this._erkennPuffer = [];
    this._erkennBytes = 0;
    this._erkennGemeldet = false;
    this.zustand = 'neu';        /* neu -> anmelden -> firmware -> erkennen -> messen -> aus */
    this.firmwareStand = null;
    this.leser = null;
    this.rate = new P.Ratenmesser();
    this.hz = null;
    this.proben = [];            /* seit der letzten Ausgabe gesammelte Rahmen */
    this._versuche = 0;
    this._timer = null;
    this._ausTimer = null;
    this._mitschnittPfad = null;
  }

  describe() {
    return { id: this.id, model: this.cfg.model || 'Eickemeyer EKG 2000', role: this.cfg.role || 'ekg' };
  }

  _log(art, text) {
    if (this.ctx && this.ctx.log && this.ctx.log[art]) this.ctx.log[art]('ekg2000', text);
  }

  /* Die GEMESSENE Kanalzahl hat Vorrang vor jeder Vorgabe - sie ist die einzige, die am
   * wirklich angesteckten Geraet ueberprueft wurde. Solange nichts gemessen ist, gilt die
   * Konfiguration, und ohne Konfiguration die erweiterte Ausfuehrung. */
  get kanaele() {
    if (this.kanaeleErkannt === 3 || this.kanaeleErkannt === 8) return this.kanaeleErkannt;
    return this.cfg.kanaele === 3 ? 3 : 8;
  }
  get betrieb() { return this.cfg.betrieb === 'monitor' ? 'monitor' : 'ruhe'; }

  async connect() {
    const port = String(this.cfg.port || '').toUpperCase();
    if (!/^COM\d+$/.test(port)) {
      this._log('warn', 'Adapter "' + this.id + '" ohne gueltigen Anschluss (port: '
        + JSON.stringify(this.cfg.port) + ') — nicht gestartet.');
      return;
    }

    this.verb = new SerielleVerbindung({
      art: 'com', port: port,
      baud: P.LEITUNG_ANMELDUNG.baud, datenbits: P.LEITUNG_ANMELDUNG.datenbits,
      paritaet: P.LEITUNG_ANMELDUNG.paritaet, stopbits: P.LEITUNG_ANMELDUNG.stopbits,
      /* Die vier Auskunftsbytes — mehr kann dieser Adapter auf dem normalen Weg nicht senden. */
      erlaubteBefehle: [
        Buffer.from([P.ANFRAGE_KENNUNG]), Buffer.from([P.BEFEHL_MELDEN]),
        Buffer.from([P.BEFEHL_START]), Buffer.from([P.BEFEHL_STOP]),
      ],
      /* Nur fuer den Firmware-Upload (sendenRoh). Steht hier sichtbar, damit die Zusage
       * "VetStation verstellt kein Geraet" nachpruefbar bleibt. */
      firmwareErlaubt: true,
    }, this.ctx);

    this.verb.beiDaten((d) => this._daten(d));
    this.verb.beiEnde(() => {
      this.connected = false;
      this._log('warn', 'Der Anschluss ' + port + ' wurde geschlossen.');
    });

    try { await this.verb.oeffnen(); }
    catch (e) {
      this._log('warn', 'Anschluss ' + port + ' liess sich nicht oeffnen: ' + (e && e.message)
        + '. Steckt das Geraet? Ist der Treiber eingespielt '
        + '(installer\\set-ekg-treiber.ps1 -Erzwingen als Administrator)?');
      return;
    }

    if (this.cfg.mitschnitt) this._mitschnittVorbereiten();
    this.zustand = 'anmelden';
    this._log('info', 'EKG 2000 an ' + port + ' geoeffnet (' + P.LEITUNG_ANMELDUNG.baud
      + ' Baud, 8 Datenbits, gerade Paritaet, 1 Stoppbit — so, wie es das Herstellerprogramm '
      + 'tut). Anmeldegespraech laeuft.');
    this._anfragen();
  }

  /* --- Schritt 2: Kennung --------------------------------------------------------- */
  _anfragen() {
    if (!this.verb || !this.verb.offen) return;
    if (this.zustand !== 'anmelden') return;
    if (this._versuche >= P.VERSUCHE_MAX) {
      this._log('warn', 'Das Geraet an ' + this.cfg.port + ' hat auf ' + P.VERSUCHE_MAX
        + ' Kennungsabfragen nicht verwertbar geantwortet. '
        + (this.deutung ? this.deutung.urteil : 'Es kam gar nichts zurueck.'));
      return;
    }
    this._versuche++;
    this.verb.senden(Buffer.from([P.ANFRAGE_KENNUNG]));
    this._timer = setTimeout(() => { this._timer = null; this._anfragen(); }, P.ANFRAGE_ABSTAND_MS);
    if (this._timer.unref) this._timer.unref();
  }

  /* --- Schritt 3: Firmware -------------------------------------------------------- */
  async _firmware() {
    const root = path.join(__dirname, '..', '..', '..');
    const fund = FW.suche(root, this.cfg.firmwareOrdner);
    const datei = FW.fuerBauart(fund, this.deutung.bauart, this.betrieb);
    if (!datei) {
      this.firmwareStand = 'fehlt';
      this._log('warn', 'Das Geraet ist bestaetigt (' + this.deutung.urteil + '), aber die '
        + 'passende Firmware fehlt auf diesem PC. ' + FW.anleitung(fund)
        + ' Ohne sie sendet das Geraet keine Messdaten — das ist eine Eigenschaft des '
        + 'Geraets, kein Fehler der Station.');
      return false;
    }

    this._log('info', 'Firmware ' + datei.name + ' gefunden (' + datei.zweck + ', '
      + datei.bytes.length + ' Byte) — wird in das Geraet geladen.');

    /* Bootlader ansprechen. Antwortet er nicht wie erwartet, wird NICHT geschrieben:
     * Bytes in einen Mikrocontroller zu schicken, der gar nicht im Ladebetrieb ist, ist
     * der eine Vorgang, der das Geraet wirklich beschaedigen koennte. */
    this._bootAntwort = null;
    this.verb.sendenRoh(P.BOOTLADER_ANFRAGE, 'Bootlader ansprechen');
    const antwort = await this._warteAufBytes(P.BOOTLADER_ANTWORT.length, 1500);
    if (!antwort || antwort.toString('latin1') !== P.BOOTLADER_ANTWORT) {
      this.firmwareStand = 'bootlader-schweigt';
      this._log('warn', 'Der Bootlader des Geraets hat nicht mit "' + P.BOOTLADER_ANTWORT
        + '" geantwortet (bekommen: ' + (antwort ? JSON.stringify(antwort.toString('latin1')) : 'nichts')
        + '). Es wird NICHTS in das Geraet geschrieben. Geraet aus- und wieder einstecken.');
      return false;
    }

    const bloecke = P.firmwareBloecke(datei.bytes.length);
    for (const b of bloecke) {
      /* Adresse (2 Byte) + Nutzlast, wie das Original: Zieladresse ab 0x8000, je 16 Byte. */
      const kopf = Buffer.alloc(2);
      kopf.writeUInt16BE(b.adresse, 0);
      const nutz = datei.bytes.slice(b.ab, b.ab + b.laenge);
      if (!this.verb.sendenRoh(Buffer.concat([kopf, nutz]), 'Firmwareblock 0x' + b.adresse.toString(16))) {
        this.firmwareStand = 'abgebrochen';
        return false;
      }
    }
    this.firmwareStand = datei.name;
    this._log('info', 'Firmware ' + datei.name + ' uebertragen (' + bloecke.length + ' Bloecke).');
    return true;
  }

  /* Wartet auf n Bytes aus dem Strom. Nutzt _wartet, das _daten() bedient. */
  _warteAufBytes(n, fristMs) {
    return new Promise((resolve) => {
      this._wartet = { n: n, buf: [], gesamt: 0, fertig: resolve };
      setTimeout(() => {
        if (this._wartet && this._wartet.fertig === resolve) {
          const w = this._wartet; this._wartet = null;
          resolve(w.gesamt ? Buffer.concat(w.buf).slice(0, n) : null);
        }
      }, fristMs).unref && true;
    });
  }

  /* --- Schritte 4 und 5: umschalten und starten ------------------------------------ */
  async _messbetrieb() {
    try { await this.verb.neuEinstellen(P.LEITUNG_BETRIEB); }
    catch (e) {
      this._log('warn', 'Umschalten auf ' + P.LEITUNG_BETRIEB.baud + ' Baud scheiterte: ' + e.message);
      return false;
    }
    this.verb.senden(Buffer.from([P.BEFEHL_MELDEN]));
    const meld = await this._warteAufBytes(P.MELDEN_ANTWORT_BYTES, P.MELDEN_FRIST_MS + 400);
    if (!meld) {
      this._log('warn', 'Auf 0x90 kamen keine vier Antwortbytes. Der Strom wird trotzdem '
        + 'gestartet — die Rahmenerkennung faengt einen falschen Anfang von selbst ab.');
    } else {
      this._log('info', 'Geraet meldet sich mit ' + meld.toString('hex') + '.');
    }
    /*
     * KANALZAHL MESSEN STATT EINSTELLEN LASSEN.
     * Das Handbuch kennt zwei Ausfuehrungen (3 Extremitaetenkanaele bzw. bis 8), und sie
     * senden verschieden lange Rahmen. Welche hier steckt, weiss niemand - der Anwender am
     * wenigsten. Also wird nach dem Start kurz zugehoert und die Laenge bestimmt; erst dann
     * beginnt das Zusammensetzen. Nur wenn die Konfiguration eine Zahl ausdruecklich vorgibt,
     * gilt sie ohne Messung.
     */
    this.zustand = 'erkennen';
    this.connected = true;
    this._erkennPuffer = [];
    this._erkennBytes = 0;
    this.verb.senden(Buffer.from([P.BEFEHL_START]));
    if (this.cfg.kanaele === 3 || this.cfg.kanaele === 8) {
      this._leserStarten(this.cfg.kanaele, 'aus der Konfiguration vorgegeben');
    }
    this._ausTimer = setInterval(() => this._ausgeben(), AUSGABE_MS);
    if (this._ausTimer.unref) this._ausTimer.unref();
    this._log('info', 'Messbetrieb laeuft (' + this.kanaele + ' Kanaele, ' + P.LEITUNG_BETRIEB.baud
      + ' Baud). Die Abtastrate wird gemessen; bis sie steht, wird keine Zeitangabe gemacht.');
    return true;
  }

  /* --- Datenempfang --------------------------------------------------------------- */
  _daten(d) {
    this.bytes += d.length;
    if (this._mitschnittPfad) { try { fs.appendFileSync(this._mitschnittPfad, d); } catch (_) {} }

    /* Wartet gerade jemand auf eine feste Zahl Bytes (Bootlader, Meldung)? Dann gehoert
     * der Strom ihm — sonst wuerde der Rahmenleser die Antwort verschlucken. */
    if (this._wartet) {
      this._wartet.buf.push(d); this._wartet.gesamt += d.length;
      if (this._wartet.gesamt >= this._wartet.n) {
        const w = this._wartet; this._wartet = null;
        w.fertig(Buffer.concat(w.buf).slice(0, w.n));
      }
      return;
    }

    if (this.zustand === 'anmelden') { this._anmeldeBytes(d); return; }

    /* Zuhoeren, bis die Rahmenlaenge feststeht. Die Bytes gehen dabei NICHT verloren: sie
     * werden gesammelt und nach der Erkennung durch den fertigen Leser geschickt. */
    if (this.zustand === 'erkennen') {
      this._erkennPuffer.push(d);
      this._erkennBytes += d.length;
      if (this._erkennBytes < P.ERKENNUNG_MIN_BYTES * 4) return;
      const roh = Buffer.concat(this._erkennPuffer);
      const erg = P.kanaeleErkennen(roh);
      if (!erg.sicher) {
        /* Nicht raten. Weiter sammeln - vielleicht laeuft der Strom gerade erst an. Nach
         * 64 KB ohne Ergebnis wird es gesagt, statt still weiterzuwarten. */
        if (this._erkennBytes > 65536 && !this._erkennGemeldet) {
          this._erkennGemeldet = true;
          this._log('warn', 'Die Ausfuehrung liess sich nicht bestimmen: ' + erg.urteil);
        }
        return;
      }
      this._leserStarten(erg.kanaele, erg.urteil);
      const nach = this.leser.schiebe(roh);
      if (nach.length) { this.rate.zaehle(nach.length, Date.now()); nach.forEach((r) => this.proben.push(r)); }
      return;
    }

    if (this.zustand === 'messen' && this.leser) {
      const rahmen = this.leser.schiebe(d);
      if (rahmen.length) {
        this.rate.zaehle(rahmen.length, Date.now());
        for (const r of rahmen) this.proben.push(r);
        if (!this.hz) {
          const g = P.gerundet(this.rate.hertz());
          if (g) {
            this.hz = g;
            this._log('info', 'Abtastrate gemessen: ' + Math.round(g.gemessen * 10) / 10 + ' Hz'
              + (g.eingerastet ? ' — eingerastet auf ' + g.hz + ' Hz' : ' (kein ueblicher Wert; '
              + 'es gilt der gemessene)') + '.');
          }
        }
      }
      return;
    }

    /* Vor dem Messbetrieb: mitzaehlen und einmal beurteilen. */
    if (this.gesammelt < DEUTUNG_AB_BYTE) {
      this.puffer.push(d); this.gesammelt += d.length;
      if (this.gesammelt >= DEUTUNG_AB_BYTE && !this.aufbau) {
        try { this.aufbau = format.deute(Buffer.concat(this.puffer)); } catch (_) {}
        this.puffer = [];
      }
    }
  }

  /* Den Rahmenleser scharf machen. Getrennte Funktion, weil es zwei Wege hierher gibt:
   * die Messung und die ausdrueckliche Vorgabe aus der Konfiguration. */
  _leserStarten(kanaele, grund) {
    this.kanaeleErkannt = kanaele;
    this.leser = new P.Rahmenleser(kanaele);
    this.zustand = 'messen';
    this._erkennPuffer = [];
    this._log('info', 'Rahmenlaenge steht: ' + kanaele + ' Kanaele (' + grund + ').');
  }

  _anmeldeBytes(d) {
    for (let i = 0; i < d.length; i++) {
      const urteil = P.deuteKennung(d[i]);
      if (!urteil.bereit && d[i] === P.ANTWORT_NICHT_BEREIT) continue;
      if (!urteil.bereit) { this.deutung = urteil; continue; }
      this.kennung = d[i];
      this.deutung = urteil;
      if (this._timer) { clearTimeout(this._timer); this._timer = null; }
      this.zustand = 'firmware';
      this._log('info', 'Geraet bestaetigt: ' + urteil.urteil);
      /* Ab hier laeuft es von selbst weiter. Faellt ein Schritt aus, bleibt die Station
       * stehen, wo sie ist, und sagt warum — sie meldet nie einen Wert, den sie nicht hat. */
      Promise.resolve()
        .then(() => this._firmware())
        .then((ok) => (ok ? this._messbetrieb() : false))
        .catch((e) => this._log('warn', 'Inbetriebnahme abgebrochen: ' + (e && e.message)));
      return;
    }
  }

  /* --- Ausgabe nach oben ----------------------------------------------------------- */
  _ausgeben() {
    if (!this.proben.length) return;
    const proben = this.proben;
    this.proben = [];
    const eich = Number(this.cfg.eichungUvProDigit) || 0;

    /* Kanalweise umsortieren: die Auswertung erwartet je Kanal eine Reihe, nicht je
     * Zeitpunkt eine Spalte. */
    const kurven = [];
    for (let k = 0; k < this.kanaele; k++) {
      const reihe = new Array(proben.length);
      for (let i = 0; i < proben.length; i++) {
        /* Kanal 1..8 im Original -> Index 0..7 hier. */
        reihe[i] = eich ? (proben[i][k + 1] || 0) * eich / 1000 : (proben[i][k + 1] || 0);
      }
      kurven.push(reihe);
    }

    this.emit({
      deviceId: this.id,
      deviceModel: this.cfg.model || 'Eickemeyer EKG 2000',
      deviceRole: 'ekg',
      ts: Date.now(),
      vitals: {},
      /* KEINE Vitalwerte. Die Kurve steht unter einem eigenen Schluessel, damit sie
       * niemand versehentlich als Messwert weiterreicht. */
      kurven: {
        ekg: {
          kanaele: this.kanaele,
          werte: kurven,
          einheit: eich ? 'mV' : 'digit',
          /* DIE WICHTIGSTE ANGABE DIESES RAHMENS. Wer sie ignoriert, rechnet mit Digits,
           * als waeren es Millivolt. */
          kalibriert: !!eich,
          abtastrateHz: this.hz ? this.hz.hz : null,
          abtastrateGemessen: this.hz ? this.hz.gemessen : null,
        },
      },
      _meta: {
        transport: 'USB/FTDI, 38400 8E1',
        firmware: this.firmwareStand,
        bauart: this.deutung ? this.deutung.bauart : null,
      },
    });
  }

  _mitschnittVorbereiten() {
    try {
      const ordner = path.join(__dirname, '..', '..', 'data');
      if (!fs.existsSync(ordner)) fs.mkdirSync(ordner, { recursive: true });
      this._mitschnittPfad = path.join(ordner, 'ekg2000-mitschnitt-' + this.id + '.bin');
      fs.writeFileSync(this._mitschnittPfad, Buffer.alloc(0));
      this._log('info', 'Mitschnitt laeuft nach ' + this._mitschnittPfad + '.');
    } catch (e) { this._mitschnittPfad = null; }
  }

  status() {
    return {
      verbunden: this.connected,
      zustand: this.zustand,
      port: this.cfg.port || null,
      kennung: this.kennung === null ? null : '0x' + this.kennung.toString(16).toUpperCase(),
      bauart: this.deutung ? this.deutung.bauart : null,
      urteil: this.deutung ? this.deutung.urteil : 'noch keine Antwort',
      firmware: this.firmwareStand,
      kanaele: this.kanaele,
      /* Getrennt ausgewiesen: gemessen ist nicht dasselbe wie eingestellt. */
      kanaeleGemessen: this.kanaeleErkannt,
      bytes: this.bytes,
      rahmen: this.leser ? this.leser.rahmen : 0,
      verworfen: this.leser ? this.leser.verworfen : 0,
      abtastrateHz: this.hz ? this.hz.hz : null,
      /* Ehrlich benannt und absichtlich hier sichtbar: Kurve ja, Millivolt nur nach Eichung. */
      kurve: this.zustand === 'messen',
      kalibriert: !!(Number(this.cfg.eichungUvProDigit) || 0),
      aufbau: this.aufbau ? this.aufbau.urteil : null,
    };
  }

  dispose() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (this._ausTimer) { clearInterval(this._ausTimer); this._ausTimer = null; }
    /* Dem Geraet noch "halt an" sagen, damit es nicht weiter in eine geschlossene
     * Schnittstelle sendet. Schlaegt es fehl, ist das kein Grund, nicht zu schliessen. */
    try { if (this.verb && this.verb.offen) this.verb.senden(Buffer.from([P.BEFEHL_STOP])); } catch (_) {}
    if (this.verb) { try { this.verb.schliessen(); } catch (_) {} }
    this.verb = null;
    this.connected = false;
    this.zustand = 'aus';
  }
}

module.exports = { EKG2000Adapter };
