'use strict';
/*
 * hl7.js — ECHTER Mindray-Live-Adapter ueber HL7 / "Patient Data Share" (PDS).
 *
 * Belegter Weg (Mindray PDS Protocol Programmer's Guide H-0010-20-43061 v14.2; VSCapture unterstuetzt
 * die uMEC-Serie gateway-frei): Der Monitor sendet HL7 v2.3.1 ORU^R01 ueber TCP mit MLLP-Framing.
 * PC = LISTENER/Server; der Monitor verbindet sich als Client zur "Serveradresse" (= PC-IP) und pusht.
 *
 * STRIKT READ-ONLY im Sinne von: es wird nichts am Geraet EINGESTELLT. QRY^R02 ist eine
 * Daten-Abfrage, ACK eine Protokoll-Quittung — beides steuert das Geraet nicht.
 *
 * WAS TATSAECHLICH RAUSGEHT, HAENGT AM WEG (berichtigt 28.08.2026). Hier stand pauschal
 * "standardmaessig AUS -> es wird per Default NICHTS gesendet". Fuer den Listener stimmt das;
 * fuer den Client-Weg war es falsch, und dort laeuft am Praxis-PC der Blutdruck:
 *
 *   LISTENER (kein "mode" oder "listener"; Guide Kapitel 2, "unsolicited results"): das Geraet
 *     verbindet sich zum PC und pusht von sich aus. Per Vorgabe geht wirklich NICHTS raus; nur
 *     "ack": true laesst einen HL7-ACK zurueckgehen. "pdsStrict" wirkt auf diesem Weg NICHT —
 *     es gibt hier keine Abfrage, die spezifikationstreu sein koennte (siehe Konstruktor).
 *
 *   CLIENT, Vorgabe (mode: "client"; Guide Kapitel 6, "PDS Realtime"): der PC FRAGT AB, also
 *     geht laufend etwas raus — eine QRY^R02 beim Verbindungsaufbau und danach alle 5 s erneut.
 *     Dazu wird JEDE empfangene Nachricht quittiert, und zwar UNABHAENGIG von "ack":
 *     _handleMessage quittiert schon wegen `|| this.mode === 'client'`, weil das Keepalive auf
 *     diesem Weg an der Quittung haengt. "ack": false schaltet sie hier also nicht ab.
 *
 *   CLIENT MIT "pdsStrict": true: genau EINE QRY^R02 je Verbindung, danach alle 1000 ms das
 *     TCP-Echo (Guide §6.7) — und NIE eine Quittung, auch nicht bei "ack": true. Guide §6.3.3
 *     Punkt 9 laesst das Geraet bei jeder anderen Nachricht als QRY und TCP-Echo trennen. Ein
 *     Wachhund wacht darueber, dass die einmalige Abfrage nicht unbemerkt verlorengeht —
 *     Begruendungen bei _handleMessage und _wacheStarten.
 *
 * OBX-Codes 1:1 aus der offiziellen PDS-Spezifikation (siehe docs/MINDRAY-HL7.md).
 *
 * Konfig: { id, listenPort=5000, model, role, species?, weightKg?, ack?:false, rawLog?:false }
 *   mode:'client' zusaetzlich { host, port=4601, pdsStrict?:false }. host darf "auto" sein: dann
 *   folgt die Abfrage dem tatsaechlich im Netz gefundenen Geraet (geraetefund.js) statt einer
 *   festen IP. pdsStrict steht bewusst NUR hier: auf einem Listener bleibt es wirkungslos.
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const { Adapter } = require('./base');
const geraetefund = require('../geraetefund');
/* Ein HL7-Port spricht kein HTTP. Steht in einer eigenen Datei, weil probe.js dieselbe Antwort
 * braucht — ein Sicherheitsriegel, der zweimal im Haus steht, ist gefaehrlich (wie herkunft.js). */
const geraeteriegel = require('../geraeteriegel');

const VT = 0x0b, FS = 0x1c, CR = 0x0d; // MLLP-Rahmen: <VT> ... <FS><CR>

/*
 * ZEICHENSATZ (Befund 23.07.2026 am echten LifeVet/N-Series): Das Geraet deklariert im MSH-18
 * "UNICODE UTF-8" und sendet den Patientennamen UTF-8-kodiert. Wurde der Rahmen als latin1 gelesen,
 * wurde aus "müller" ein "mÃ¼ller" - der Tierarzt sah einen verstuemmelten Namen.
 * Deshalb: sagt der Kopf UTF-8, wird als UTF-8 dekodiert; sonst latin1 (aeltere Bettmonitore).
 * ASCII ist in beiden Kodierungen identisch, darum ist die Kopf-Erkennung selbst robust.
 */
function decodePayload(buf) {
  const latin = buf.toString('latin1');
  if (/UNICODE\s*UTF-?8|\bUTF-?8\b/i.test(latin.slice(0, 600))) {
    try { return buf.toString('utf8'); } catch (_) { return latin; }
  }
  return latin;
}

// Numerischer OBX-Code -> internes Feld (Primärzuordnung).
/*
 * OBX-Code -> internes Feld. Deckt BEIDE Mindray-Dialekte ab (belegt aus dem Mindray Patient Data
 * Share Protocol Programmer's Guide v14.2 und dem mdpnp/IHE-PCD-Mapping, recherchiert 23.07.2026):
 *   • PRIVATER Bettmonitor-Dialekt: kleine, eigene Parameter-IDs (101=HR, 160=SpO2, 51=Weight ...).
 *   • MDC/IEEE-11073-Dialekt (eGateway, das LifeVet 10C sendet DIESEN): grosse Codes wie
 *     147842=MDC_ECG_HEART_RATE. Die MDC-NUMMERN sind zusaetzlich eingetragen, damit ein Wert auch
 *     dann aufloest, wenn das Label einmal fehlt - das Label-Fallback unten deckt sie ohnehin ab.
 */
const CODE_MAP = {
  // -- privater Mindray-Bettmonitor-Dialekt --
  '101': 'hr', '160': 'spo2', '161': 'hr', '173': 'hr',   // 161=SpO2-Puls, 173=NIBP-Puls (HF-Fallback)
  '170': 'sys', '171': 'dia', '172': 'map',      // NIBP
  '500': 'sys', '501': 'map', '502': 'dia',      // invasiver ART als Fallback
  '220': 'etco2', '221': 'fico2', '222': 'af', '250': 'etco2',  // Kapno (250=CO2Et laut PDS-Guide)
  '151': 'rr_imp',                               // Impedanz-Atmung (Fallback für af)
  '200': 'temp', '201': 'temp', '213': 'temp_tb', // T1 / T2 / Bluttemperatur
  '102': 'pvcs', '51': 'weightKg',
  // -- MDC/IEEE-11073-Dialekt (das LifeVet 10C nutzt diesen; belegt) --
  '147842': 'hr', '149530': 'hr', '149538': 'hr',        // MDC_ECG_HEART_RATE / PULS_OXIM_PULS_RATE
  '150456': 'spo2',                                      // MDC_PULS_OXIM_SAT_O2
  '150021': 'sys', '150022': 'dia', '150023': 'map',     // MDC_PRESS_BLD_NONINV_*
  '150301': 'sys', '150302': 'dia', '150303': 'map',     // MDC_PRESS_CUFF_*
  '151728': 'etco2', '151738': 'fico2',                  // MDC_AWAY_CO2_ET / _INSP_MIN
  '151562': 'af', '151570': 'af', '151578': 'af',        // MDC_RESP_RATE / MDC_AWAY_RESP_RATE / MDC_TTHOR_RESP_RATE (Impedanz-Atmung, am echten LifeVet belegt)
  '150344': 'temp',                                       // MDC_TEMP
  '148065': 'pvcs', '148066': 'pvcs', '352': 'pvcs', '302': 'pvcs', // MDC_ECG_V_P_C_CNT/_RATE, MNDRY VPB-/RonT-Rate (ventrikulaere Extrasystolen) — am echten uMEC/LifeVet belegt
};
// Label-Fallback (falls ein Nummerncode unbekannt ist, aber das Label sprechend). Schluessel KLEIN
// geschrieben; deckt Mindray-Kurznamen UND IEEE-11073-MDC-Nomenklatur (BeneView/BeneVision) ab.
const LABEL_MAP = {
  hr: 'hr', pr: 'hr', pulse: 'hr', nibp_pr: 'hr', mdc_ecg_heart_rate: 'hr', mdc_ecg_cardiac_rate: 'hr', mdc_puls_oxim_puls_rate: 'hr',
  spo2: 'spo2', mdc_puls_oxim_sat_o2: 'spo2',
  'nibp-sys': 'sys', sys: 'sys', 'nbp-s': 'sys', mdc_press_bld_noninv_sys: 'sys', mdc_press_cuff_sys: 'sys',
  'nibp-dia': 'dia', dia: 'dia', 'nbp-d': 'dia', mdc_press_bld_noninv_dia: 'dia', mdc_press_cuff_dia: 'dia',
  'nibp-mean': 'map', mean: 'map', 'nbp-m': 'map', mdc_press_bld_noninv_mean: 'map', mdc_press_cuff_mean: 'map',
  co2: 'etco2', etco2: 'etco2', co2et: 'etco2', mdc_co2_et: 'etco2', mdc_away_co2_et: 'etco2',
  fico2: 'fico2', insco2: 'fico2', mdc_co2_insp_min: 'fico2', mdc_away_co2_insp_min: 'fico2',
  awrr: 'af', mdc_co2_resp_rate: 'af', mdc_resp_rate: 'af', mdc_away_resp_rate: 'af', rr: 'rr_imp', resp: 'rr_imp',
  t1: 'temp', t2: 'temp', tb: 'temp_tb', temp: 'temp', mdc_temp: 'temp',
  pvcs: 'pvcs', weight: 'weightKg', mdc_body_weight: 'weightKg',

  /* =================================================================================
   * BEATMUNG UND NARKOSEGAS (additiv, 05.08.2026)
   *
   * WARUM NUR UEBER DAS LABEL UND NICHT UEBER ZAHLENCODES:
   * Fuer HF/SpO2/NIBP stehen die privaten Mindray-Nummern oben, weil sie am ECHTEN Geraet
   * dieser Praxis gemessen wurden. Fuer Paw/PEEP/Vt/MV/FiO2/Narkosegas gibt es hier KEINE
   * eigene Messung — die Geraete, die das senden (WATO EX-35Vet, Draeger MEDIBUS, Datex,
   * GE/Philips), stehen nicht in dieser Praxis. Eine ausgedachte Nummer waere genau das,
   * was der Geraetekatalog verbietet: ein Geruecht. Sie wuerde ausserdem stillschweigend
   * einen FREMDEN Parameter unter falschem Namen anzeigen, sobald ein Hersteller diese
   * Nummer anders belegt — am narkotisierten Tier der schlimmste Fehler.
   *
   * Die MDC-Bezeichner dagegen sind selbstbeschreibend und normiert (IEEE 11073-10101);
   * sie kommen bei genau diesen Geraeten mit JEDEM OBX mit (wie hier belegt an
   * "131330^MDC_ECG_ELEC_POTL_II"). Dazu die Kurznamen, die die Geraete auf ihrem eigenen
   * Bildschirm verwenden.
   *
   * ES AENDERT NICHTS AM BESTEHENDEN: LifeVet und uMEC12 senden keinen dieser Bezeichner —
   * fuer sie ist diese Tabelle wirkungslos.
   * ================================================================================= */
  ppeak: 'ppeak', pmax: 'ppeak', paw: 'ppeak', pip: 'ppeak', ppk: 'ppeak',
  mdc_press_away_insp_max: 'ppeak', mdc_press_resp_away_insp_max: 'ppeak',
  pmean: 'pmean', pmittel: 'pmean', mdc_press_away_mean: 'pmean', mdc_press_resp_away_mean: 'pmean',
  peep: 'peep', mdc_press_away_end_exp_pos: 'peep', mdc_press_resp_away_end_exp_pos: 'peep',
  vte: 'vte', tve: 'vte', vt_exp: 'vte',
  mdc_vol_away_tidal_exp: 'vte', mdc_vol_away_tidal: 'vte', mdc_vol_resp_away_tidal: 'vte',
  mv: 'mv', mve: 'mv', mvexp: 'mv', minvol: 'mv',
  mdc_vol_minute_away_exp: 'mv', mdc_vol_minute_away: 'mv', mdc_vol_minute_resp_away: 'mv',
  cdyn: 'compl', compl: 'compl', mdc_resp_compl: 'compl',
  fio2: 'fio2', o2insp: 'fio2', inso2: 'fio2', mdc_conc_away_o2_insp: 'fio2',
  etaa: 'etAgent', etiso: 'etAgent', etsev: 'etAgent', etdes: 'etAgent', ethal: 'etAgent', etagent: 'etAgent',
  mdc_conc_away_iso_et: 'etAgent', mdc_conc_away_sevo_et: 'etAgent', mdc_conc_away_des_et: 'etAgent',
  mdc_conc_away_halot_et: 'etAgent', mdc_conc_away_agent_et: 'etAgent',
  fiaa: 'fiAgent', fiiso: 'fiAgent', fisev: 'fiAgent', fides: 'fiAgent', fihal: 'fiAgent', fiagent: 'fiAgent',
  mdc_conc_away_iso_insp: 'fiAgent', mdc_conc_away_sevo_insp: 'fiAgent', mdc_conc_away_des_insp: 'fiAgent',
  mdc_conc_away_halot_insp: 'fiAgent', mdc_conc_away_agent_insp: 'fiAgent',
  etn2o: 'etn2o', mdc_conc_away_n2o_et: 'etn2o',
  mac: 'mac', mdc_conc_away_agent_mac: 'mac',
  pi: 'pi', perf: 'pi', perfusionsindex: 'pi', mdc_puls_perf_index: 'pi',
  /* BEWUSST NICHT `t2: 'temp2'`: weiter oben steht seit jeher `t2: 'temp'`, und die beiden
   * Geraete dieser Praxis senden ihre einzige Temperatur mitunter als T2. Wer das hier
   * umbiegt, laesst die Temperaturkachel leer laufen — das waere genau die Art stiller
   * Verschlechterung, die der Auftrag ausschliesst ("LifeVet und uMEC nicht stoeren").
   * Ein Geraet mit ZWEI echten Sonden meldet die zweite als "temp2". */
  temp2: 'temp2',
};

/*
 * OBX-Codes, die GAR KEINE Zahlenwerte sind: Kurvenpunkte, Geraete-Attribute und Alarm-/
 * Technikmeldungen der IEEE-11073-Nomenklatur.
 *
 * WARUM DIESE LISTE (Praxis-PC, 22.07.2026): Sobald das Geraet endlich sendete, schrieb die
 * Station im Sekundentakt "Unbekannter OBX-Code: 131330^MDC_ECG_ELEC_POTL_II (in hl7.js CODE_MAP
 * ergaenzen)". Das liest sich wie ein Programmfehler und wie "hier gehen Messwerte verloren" -
 * beides ist falsch: MDC_ECG_ELEC_POTL_II ist ein EKG-KURVENPUNKT, MDC_EVT_INOP eine technische
 * Alarmmeldung ("Sensor ab"). Es gibt dort schlicht keinen Vitalwert zu holen.
 * Solche Codes werden deshalb NICHT mehr als Fehlstelle gemeldet, sondern getrennt gezaehlt -
 * die Station sagt EINMAL, was das Geraet da schickt. Echte unbekannte Messwerte werden weiterhin
 * gemeldet, denn nur die gehoeren in die CODE_MAP.
 */
const KEINE_MESSWERTE = /^MDC_(ATTR_|EVT_|ECG_ELEC_POTL|CONC_AWAY_CO2$|IMPED_TTHOR|PULS_OXIM_PLETH|ECG_TIME_PD_QT)/i;
/*
 * ALARM-KONFIG-CODES des uMEC12 (belegt aus dem echten HL7-Strom 24.07.2026): der Monitor sendet mit
 * "HL7 Compatibility: Ein" auch Alarm-GRENZEN und Alarm-EINSTELLUNGEN als numerische OBX — das sind
 * KEINE Messwerte. 2002/2003 = obere/untere Alarmgrenze (mit Parameter-Sub-ID), 2013 Alarmlautstaerke,
 * 2014 Alarm-Mute, 2016 Alarm-Pause, 2027 Alarm aus, 2028 Ton-Pause, 2040/2041/2042 Alarm-Status.
 * Sie duerfen weder als Vitalwert gelten noch als "unbekannter Code" das Diagnose-Log fluten.
 */
const KONFIG_CODES = new Set(['2002', '2003', '2013', '2014', '2015', '2016', '2027', '2028', '2040', '2041', '2042']);
const KURVEN_KLARTEXT = {
  mdc_ecg_elec_potl_ii: 'EKG-Kurve (Ableitung II)',
  mdc_conc_away_co2: 'CO2-Kurve (Kapnogramm)',
  mdc_imped_tthor: 'Atemkurve (Thorax-Impedanz)',
  mdc_puls_oxim_pleth: 'Pleth-Kurve (SpO2)',
  mdc_evt_alarm: 'Alarmmeldung',
  mdc_evt_inop: 'technische Meldung (z. B. "Sensor ab")',
};

/*
 * TIERART AUS DEM GERAET (Befund 22.07.2026).
 * Im LifeVet 10C steht unter "Patientenverwaltung" die Patientenkategorie (z. B. "Hund") und das
 * Gewicht (z. B. 15,0 kg) - beides ist fuer JEDE Dosisberechnung noetig. Der Parser hat diese
 * Angaben nie gesehen, weil TEXT-Werte in OBX stillschweigend verworfen wurden (nur Zahlen zaehlten).
 * Die Station zeigte deshalb "? / ? kg" und konnte weder Normwerte noch mL-Mengen nennen.
 *
 * Bewusst tolerant gegenueber Sprache und Schreibweise, aber NIE ratend: erkannt wird nur, was
 * eindeutig einer Tierart entspricht. Alles andere bleibt null (und wird als Rohwert angezeigt).
 */
const TIERART_WORTE = [
  ['hund', /\b(hund|dog|canine|canis)\b/i],
  ['katze', /\b(katze|cat|feline|felis)\b/i],
  ['kaninchen', /\b(kaninchen|rabbit|oryctolagus)\b/i],
  ['meerschwein', /\b(meerschwein(chen)?|guinea[\s-]?pig|cavia)\b/i],
  ['chinchilla', /\bchinchilla\b/i],
  ['degu', /\bdegu\b/i],
  /* Reihenfolge zaehlt: 'rennmaus' und 'farbmaus' enthalten beide 'maus'. Die spezielleren
   * Muster stehen deshalb VOR dem allgemeinen Mausmuster, und dieses verlangt eine Wortgrenze. */
  ['rennmaus', /\b(rennmaus|renn-maus|gerbil|wuestenrennmaus|meriones)\b/i],
  ['hamster', /\b(hamster|goldhamster|zwerghamster|phodopus|mesocricetus|cricetulus)\b/i],
  ['ratte', /\b(ratte|farbratte|rat\b|rattus)\b/i],
  ['maus', /\b(maus|farbmaus|mouse|mus musculus)\b/i],
  ['frettchen', /\b(frettchen|ferret|mustela)\b/i],
  ['reptil', /\b(reptil|reptile|schildkr|turtle|tortoise|echse|lizard|schlange|snake|bartagame|gecko|leguan)/i],
];
function erkenneTierart(text) {
  const t = String(text || '');
  if (!t) return null;
  for (const [id, re] of TIERART_WORTE) if (re.test(t)) return id;
  return null;
}

/*
 * GEWICHT AUS DEM GERAET - sicherheitskritisch, deshalb streng.
 * Aus dem Gewicht folgen die Injektionsmengen in mL. Ein falsch uebernommener Wert waere
 * gefaehrlicher als gar keiner. Deshalb: nur aus einem ausdruecklich als Gewicht bezeichneten
 * Feld, Pfund nur bei ausgewiesener Einheit umrechnen, und ein Plausibilitaetsfenster.
 * Ausserhalb 0,05-200 kg wird NICHTS uebernommen (der Tierarzt traegt es dann selbst ein).
 */
const GEWICHT_LABEL = /(weight|gewicht|\bwt\b|body_?weight|pt_?weight)/i;
function gewichtAusOBX(label, wert, einheit) {
  if (!GEWICHT_LABEL.test(String(label || ''))) return null;
  const z = parseFloat(String(wert).replace(',', '.'));
  if (!Number.isFinite(z) || z <= 0) return null;
  const e = String(einheit || '').toLowerCase();
  let kg = z;
  if (/^(lb|lbs|pound)/.test(e)) kg = z * 0.45359237;
  else if (/^g$|gram/.test(e)) kg = z / 1000;
  if (kg < 0.05 || kg > 200) return null;    // unplausibel -> lieber nichts als falsch
  return Math.round(kg * 1000) / 1000;
}

/*
 * ALARM- UND TECHNIKMELDUNGEN im Klartext.
 * Das Geraet meldet z. B. "EKG-Ableitung ab" oder "Keine CO2-Wasserfalle" - genau die Saetze, die
 * am Monitor oben stehen. Sie kamen bisher NIRGENDS an, weil es Textwerte sind. Fuer den Tierarzt
 * sind sie aber die Erklaerung, warum ein Wert fehlt.
 */
const ALARM_CODE = /^MDC_(EVT_ALARM|EVT_INOP|ATTR_ALERT)/i;

/*
 * EINHEITEN PRUEFEN STATT ANNEHMEN - sicherheitskritisch.
 *
 * Der Parser hat die Einheit (OBX-6) nie angesehen und jeden Zahlenwert so genommen, wie er kam.
 * Zwei Beispiele, die beide in der Praxis vorkommen und in der Anzeige NICHT auffallen:
 *   • Ein auf kPa gestellter Kapnograf meldet EtCO2 = 5,3. Als mmHg gelesen sind das 5 mmHg -
 *     also scheinbar ein lebensbedrohlicher Abfall, obwohl der Patient bei 40 mmHg voellig normal
 *     beatmet ist. Die Station wuerde Alarm schlagen und eine falsche Empfehlung geben.
 *   • Eine Temperatur in Fahrenheit (98,6) wuerde als 98,6 Grad Celsius uebernommen.
 *
 * Deshalb: bekannte Einheiten werden umgerechnet, unbekannte fuehren dazu, dass der Wert NICHT als
 * Messwert uebernommen wird. Er bleibt als Rohwert sichtbar und es gibt eine Klartextmeldung.
 * Nicht uebernehmen ist hier sicherer als raten - der Tierarzt sieht dann eine Luecke statt einer
 * falschen Zahl.
 */
const EINHEIT_ERWARTET = {
  etco2: 'mmHg', fico2: 'mmHg', sys: 'mmHg', dia: 'mmHg', map: 'mmHg',
  temp: 'C', hr: '/min', af: '/min', rr_imp: '/min', spo2: '%',
  /* Beatmung/Gas (additiv 05.08.2026). Dieselbe Haltung wie oben: eine unbekannte Einheit
   * fuehrt dazu, dass der Wert NICHT uebernommen wird. Beispiel aus dem Alltag: ein Geraet,
   * das den Atemwegsdruck in kPa meldet (1 kPa = 10,2 cmH2O), wuerde sonst "1" statt "10"
   * anzeigen — ein bedrohlich hoher Spitzendruck saehe aus wie eine Idealeinstellung. */
  ppeak: 'cmH2O', pmean: 'cmH2O', peep: 'cmH2O',
  vte: 'ml', mv: 'L/min', temp2: 'C', pi: '%', fio2: '%',
  etAgent: 'vol%', fiAgent: 'vol%', etn2o: 'vol%',
  ibp: 'mmHg',
};
function normEinheit(e) { return String(e || '').replace(/[\[\]\s]/g, '').toLowerCase(); }

/*
 * DIE SPANNUNGSEINHEIT EINER KURVENAUFLOESUNG — UND WARUM SIE UEBERSETZT WERDEN MUSS.
 * (26.08.2026)
 *
 * ekg-analyse.js entscheidet ueber den Faktor 1000 mit einem einzigen Ausdruck:
 *     /uv|µv|mv/i.test(einheit)      -> ueberhaupt kalibriert?
 *     /mv/i.test(einheit) ? 1 : 0,001 -> welcher Faktor?
 * Die MDC-Nomenklatur schreibt aber MDC_DIM_MICRO_VOLT und MDC_DIM_MILLI_VOLT. Beide
 * enthalten weder "uv" noch "mv" — die Zeichenkette unveraendert weiterzureichen haette die
 * Auswertung also fuer JEDEN HL7-Monitor auf "unkalibriert" gestellt und die ST-Strecke
 * stillgelegt. Und model.js schneidet die Einheit auf 8 Zeichen: aus MDC_DIM_MICRO_VOLT
 * wuerde dort ohnehin "MDC_DIM_". Uebersetzt wird deshalb HIER, an der Quelle.
 *
 * UNBEKANNT IST NICHT uV. Steht in OBX-6 etwas, das keine Spannungseinheit ist, wird die
 * Zeichenkette gekuerzt weitergereicht — sie faellt dann durch die Pruefung oben und die
 * Auswertung schweigt zu Millivolt, statt eine Zahl zu erfinden. Das ist die Regel dieses
 * Projekts und gilt hier genauso wie bei rechneEinheit() darueber.
 */
function spannungsEinheit(e) {
  const n = normEinheit(e);
  if (!n) return null;                                   // nichts angegeben -> Vorgabe uV bleibt
  if (/^(uv|µv|mcv|mdc_dim_micro_volt|mdc_dim_microvolt)$/.test(n)) return 'uV';
  if (/^(mv|mdc_dim_milli_volt|mdc_dim_millivolt)$/.test(n)) return 'mV';
  return n.slice(0, 8);                                  // angegeben, aber keine Spannung
}

function rechneEinheit(key, wert, einheit) {
  const soll = EINHEIT_ERWARTET[key];
  if (!soll) return { wert: wert, ok: true };
  const e = normEinheit(einheit);
  if (!e) return { wert: wert, ok: true };            // keine Angabe -> Geraetestandard annehmen

  // MDC-Nomenklatur (IEEE 11073): das LifeVet/N-Series sendet Einheiten als "MDC_DIM_*" statt "%"
  // oder "/min" (Befund 23.07.2026 am echten Geraet: SpO2 kam mit MDC_DIM_PERCENT, HF mit
  // MDC_DIM_BEAT_PER_MIN). Ohne diese Zeilen verwarf die Einheitenpruefung JEDEN Messwert des
  // Monitors als "unbekannte Einheit" -> werteAnzahl=0, obwohl das Geraet sauber misst.
  if (soll === 'mmHg') {
    if (/^(mmhg|mm\(hg\)|torr|mdc_dim_mmhg)$/.test(e)) return { wert: wert, ok: true };
    if (/^(kpa|mdc_dim_kilo_pascal)$/.test(e)) return { wert: Math.round(wert * 7.50062 * 10) / 10, ok: true, umgerechnet: 'kPa' };
    if (/^(vol%|%|mdc_dim_percent)$/.test(e) && (key === 'etco2' || key === 'fico2')) {
      // Vol% bei etwa 1013 hPa: 1 Vol% entspricht rund 7,6 mmHg.
      return { wert: Math.round(wert * 7.6 * 10) / 10, ok: true, umgerechnet: 'Vol%' };
    }
    return { ok: false, grund: e };
  }
  if (soll === 'C') {
    if (/^(c|cel|degc|°c|mdc_dim_degc|mdc_dim_deg_c)$/.test(e)) return { wert: wert, ok: true };
    if (/^(f|degf|°f|mdc_dim_fahr|mdc_dim_deg_f)$/.test(e)) return { wert: Math.round(((wert - 32) * 5 / 9) * 10) / 10, ok: true, umgerechnet: 'Fahrenheit' };
    return { ok: false, grund: e };
  }
  if (soll === '/min') {
    if (/^(\/min|min-1|bpm|rpm|1\/min|puls\/min|beats\/min|mdc_dim_beat_per_min|mdc_dim_beats_per_min|mdc_dim_puls_per_min|mdc_dim_pulse_per_min|mdc_dim_resp_per_min|mdc_dim_breath_per_min|mdc_dim_breaths_per_min|mdc_dim_x_per_min)$/.test(e)) return { wert: wert, ok: true };
    return { ok: false, grund: e };
  }
  if (soll === '%') {
    if (/^(%|mdc_dim_percent)$/.test(e)) return { wert: wert, ok: true };
    return { ok: false, grund: e };
  }
  /* --- Beatmung/Gas (additiv 05.08.2026) --- */
  if (soll === 'cmH2O') {
    if (/^(cmh2o|cmh20|cm\(h2o\)|mdc_dim_cm_h2o)$/.test(e)) return { wert: wert, ok: true };
    // 1 mbar = 1 hPa = 1,0197 cmH2O — die Differenz von 2 % ist klinisch belanglos, aber sie
    // wird trotzdem gerechnet und gemeldet, damit nachvollziehbar bleibt, was geschehen ist.
    if (/^(mbar|hpa|mdc_dim_millibar|mdc_dim_hecto_pascal)$/.test(e)) return { wert: Math.round(wert * 1.0197 * 10) / 10, ok: true, umgerechnet: 'mbar/hPa' };
    if (/^(kpa|mdc_dim_kilo_pascal)$/.test(e)) return { wert: Math.round(wert * 10.197 * 10) / 10, ok: true, umgerechnet: 'kPa' };
    return { ok: false, grund: e };
  }
  if (soll === 'ml') {
    if (/^(ml|mdc_dim_milli_l|mdc_dim_x_ml)$/.test(e)) return { wert: wert, ok: true };
    if (/^(l|liter|mdc_dim_l)$/.test(e)) return { wert: Math.round(wert * 1000), ok: true, umgerechnet: 'Liter' };
    return { ok: false, grund: e };
  }
  if (soll === 'L/min') {
    if (/^(l\/min|lpm|mdc_dim_l_per_min|mdc_dim_x_l_per_min)$/.test(e)) return { wert: wert, ok: true };
    if (/^(ml\/min|mdc_dim_milli_l_per_min)$/.test(e)) return { wert: Math.round(wert / 1000 * 100) / 100, ok: true, umgerechnet: 'ml/min' };
    return { ok: false, grund: e };
  }
  if (soll === 'vol%') {
    if (/^(vol%|%|mdc_dim_percent|mdc_dim_x_pct)$/.test(e)) return { wert: wert, ok: true };
    // Manche Gasmodule melden den Partialdruck in kPa statt der Konzentration.
    if (/^(kpa|mdc_dim_kilo_pascal)$/.test(e)) return { wert: Math.round(wert / 1.013 * 100) / 100, ok: true, umgerechnet: 'kPa' };
    return { ok: false, grund: e };
  }
  return { wert: wert, ok: true };
}

/*
 * MINDRAY-KENNZEICHEN FUER "KEIN WERT": 32767 (0x7FFF), bei 8 Bit 255.
 *
 * AM PRAXISGERAET GEMESSEN (22.07.2026): Solange die EKG-Ableitung ab war, schickte das LifeVet
 * fuer jeden Kanal 32767. Der Parser nahm das als Zahl - eine "Herzfrequenz 32767" haette die
 * Station als extreme Tachykardie bewertet und Empfehlungen dazu ausgegeben. Solche Marker
 * duerfen NIE als Messwert durchgehen.
 */
const UNGUELTIG = [32767, -32768, 65535];
function istUngueltig(z) { return !Number.isFinite(z) || UNGUELTIG.indexOf(z) >= 0; }

/*
 * KURVENBLOECKE.
 *
 * Das Geraet packt Abtastwerte einer Kurve in EIN OBX-Feld, getrennt durch "^":
 *   OBX|..|131330^MDC_ECG_ELEC_POTL_II||-12^-9^-3^40^120^..|..
 * Direkt danach folgen zwei beschreibende OBX:
 *   MDC_ATTR_SAMP_RATE   = Abtastrate in Hz (gemessen: 256 fuer EKG/Impedanz, 40 fuer CO2)
 *   MDC_ATTR_NU_MSMT_RES = Aufloesung, mit der die Rohzahlen zu multiplizieren sind
 *
 * Bisher lief das durch parseFloat und wurde zur ERSTEN Zahl des Blocks - also ein erfundener
 * Einzelmesswert. Jetzt wird der Block als Kurve erkannt, mit Abtastrate und Skalierung.
 * Damit ist die echte EKG-Kurve des Geraets darstellbar, statt sie nur aus der Herzfrequenz
 * nachzuzeichnen.
 */
const MAX_SAMPLES = 512;   // Deckel je Kurve: bei 256 Hz sind das 2 s - genug fuers Bild, wenig RAM
function istKurvenblock(roh) {
  const s = String(roh);
  if (s.indexOf('^') < 0) return false;
  const teile = s.split('^');
  if (teile.length < 4) return false;
  // Alle Teile muessen Zahlen sein, sonst ist es ein zusammengesetztes Feld (z. B. Code^Text).
  return teile.every((t) => t !== '' && Number.isFinite(Number(t)));
}
function kurveAusBlock(roh) {
  return String(roh).split('^').slice(0, MAX_SAMPLES).map((t) => {
    const z = Number(t);
    return istUngueltig(z) ? null : z;      // Luecken bleiben Luecken, sie werden nicht geglaettet
  });
}

// Alltagsnamen fuer die Meldungen - im Bild soll kein Kuerzel stehen.
const KLARNAME = {
  hr: 'Herzfrequenz', spo2: 'Sauerstoffsaettigung', etco2: 'Kohlendioxid (EtCO2)',
  fico2: 'eingeatmetes CO2', af: 'Atemfrequenz', rr_imp: 'Atemfrequenz', temp: 'Temperatur',
  sys: 'Blutdruck systolisch', dia: 'Blutdruck diastolisch', map: 'Mitteldruck',
  ppeak: 'Spitzendruck im Atemweg', pmean: 'mittlerer Atemwegsdruck', peep: 'PEEP',
  vte: 'Atemzugvolumen', mv: 'Atemminutenvolumen', compl: 'Compliance',
  fio2: 'eingeatmeter Sauerstoff', etAgent: 'ausgeatmetes Narkosegas', fiAgent: 'eingeatmetes Narkosegas',
  mac: 'MAC-Vielfaches', etn2o: 'ausgeatmetes Lachgas', pi: 'Perfusionsindex', temp2: 'Temperatur (Sonde 2)',
  ibp: 'arterieller Druck (invasiv)',
};

function fieldsOf(seg) { return seg.split('|'); }

// HL7/PDS liefert KEINEN Rhythmus-Code direkt. Rhythmus aus PVC-Zaehler (OBX 102) + Arrhythmie-
// Alarmtexten der OBX-Segmente ableiten (gefaehrlichster zuerst). Konservativ, nur OBX-Inhalte
// (keine Geraetenamen aus MSH/OBR) -> keine Falschtreffer. Kurvenform-Feinheiten (Haiflosse) sind
// ohne Waveform-Stream nicht ableitbar und bleiben null (ehrlich).
function inferRhythm(obxText, pvcs) {
  const T = (obxText || '').toUpperCase();
  if (/ASYSTOL/.test(T)) return 'asys';
  if (/V[\s_-]?FIB|VFIB|KAMMERFLIMMERN/.test(T)) return 'vfib';
  if (/V[\s_-]?TAC|VTAC|VENT.{0,4}TACH|KAMMERTACH/.test(T)) return 'vtach';
  if (/A[\s_-]?FIB|AFIB|VORHOFFLIMMERN/.test(T)) return 'afib';
  if (/\bPVC|\bVES\b|VPB|R[\s_]?ON[\s_]?T|COUPLET|BIGEMIN/.test(T)) return 'ves';
  if (pvcs != null && pvcs > 0) return 'ves';
  return null;
}

/*
 * parseHL7Message(text, cfg) -> normalisiertes ingest-Frame (oder null).
 * Pure Funktion (auch für Tests). cfg liefert deviceId/model/role/species Defaults + unmapped-Callback.
 */
function parseHL7Message(text, cfg, onUnmapped) {
  cfg = cfg || {};
  const segs = text.split(/[\r\n]+/).map(s => s.trim()).filter(Boolean);
  if (!segs.length || segs[0].slice(0, 3) !== 'MSH') return null;

  // Kein voreiliger Ersatzname: sonst gewinnt "Mindray Monitor" gegen den Namen, den das Geraet
  // selbst meldet (MSH-3 / OBR-4) - und im Geraete-Menue stand fuer jedes Fabrikat dasselbe Wort.
  let sendingApp = null, deviceName = null;
  let patientId = null, weightFromPid = null, tsStr = null;
  let patientName = null, gebDatum = null, geschlecht = null, species = null;
  const vit = { pvcs: null };
  const obxTexts = [];   // Labels + nicht-numerische OBX-Werte (fuer Arrhythmie-Alarm-Erkennung)
  const kurven = [];     // Kurven-/Alarm-/Attributcodes: vorhanden, aber keine Vitalwerte
  const roh = [];        // JEDER OBX-Eintrag, zugeordnet oder nicht (damit nichts still verschwindet)
  const alarmTexte = []; // Klartextmeldungen des Geraets ("EKG-Ableitung ab")
  const umrechnungen = []; // nachvollziehbar machen, wenn eine Einheit umgerechnet wurde
  const kurvenDaten = []; // ECHTE Abtastwerte je Kurve (EKG, CO2, Atmung) mit Abtastrate
  let letzteKurve = null; // die zuletzt gelesene Kurve - die folgenden Attribute gehoeren zu ihr
  /*
   * PATIENTENAKTE aus dem Geraet (Foto der Patientenverwaltung, 22.07.2026):
   * Bett-Nr., ID, Nachname, Vorname, Besitzer, Arzt, Groesse(cm), Gewicht(kg), Geb.datum, Alter,
   * Patientenkategorie, Geschlecht, Pacer aktiv. Was das Geraet davon sendet, gehoert in die Akte
   * und ins Narkoseprotokoll - bisher wurde ausser ID und Name nichts davon uebernommen.
   */
  const akte = {};

  for (const seg of segs) {
    const type = seg.slice(0, 3);
    const f = fieldsOf(seg);
    if (type === 'MSH') { if (f[2]) sendingApp = f[2]; }
    else if (type === 'PID') {
      // Frueher wurde HIER NUR die Patienten-ID gelesen. Alles andere, was der Monitor unter
      // "Patientenverwaltung" fuehrt, ging verloren - obwohl es auf seinem Bildschirm steht.
      if (f[3]) patientId = f[3].split('^')[0] || null;
      if (f[5]) {
        // PID-5: Nachname^Vorname^... -> fuer die Anzeige zusammensetzen (bleibt LOKAL auf dem PC).
        // OHNE filter(Boolean) zerlegen, damit die Komponenten-POSITIONEN erhalten bleiben.
        const comp = f[5].split('^');
        const nach = (comp[0] || '').trim(), vor = (comp[1] || '').trim();
        if (nach || vor) patientName = (vor ? vor + ' ' : '') + nach;
        /*
         * BESITZER AUS PID-5 KOMPONENTE 3 (beobachtet am echten LifeVet 10C, 23.07.2026):
         * Das Geraet traegt in PID-5 "Nachname^Vorname^Besitzer" ein - im Mitschnitt stand dort
         * "müller^Muster^Musterman^^^^L" (Musterman = Besitzer aus der Patientenverwaltung).
         * Nur uebernehmen, wenn es kein einzelner Namenstyp-Code (z. B. "L"=Legal) ist. Ein echtes
         * GT1-Segment (falls vorhanden) darf spaeter gewinnen.
         */
        const c3 = (comp[2] || '').trim();
        if (c3 && c3.length > 1 && !akte.besitzer) akte.besitzer = c3;
      }
      if (f[7]) gebDatum = f[7];
      if (f[8]) geschlecht = f[8].split('^')[0] || null;
      // PID-19/PID-2: weitere Kennungen (Chipnummer, Praxisnummer) - anzeigen, nie deuten.
      if (f[19] && !akte.kennung2) akte.kennung2 = f[19].split('^')[0];
      // Manche Geraete tragen die Tierart in PID-10 (Rasse/Art) oder PID-35 ein.
      [f[10], f[35], f[22]].forEach((x) => { if (!species && x) species = erkenneTierart(x); });
    }
    else if (type === 'PV1') {
      // Patientenkategorie/Station - beim LifeVet steht die Tierart mitunter hier.
      f.forEach((x) => { if (!species && x) species = erkenneTierart(x); });
      // PV1-3 = Station/Zimmer/Bett -> am Geraet das Feld "Bett-Nr.".
      if (f[3]) { const b = f[3].split('^').filter(Boolean).join(' '); if (b) akte.bett = b; }
      // PV1-7 = behandelnder Arzt -> am Geraet das Feld "Arzt".
      if (f[7]) { const a = f[7].split('^').filter(Boolean); if (a.length) akte.arzt = (a[2] ? a[2] + ' ' : '') + (a[1] || a[0]); }
    }
    else if (type === 'GT1') {
      /*
       * GT1 = "Guarantor" - in der Tiermedizin genau der BESITZER (er haftet, nicht der Patient).
       * Das Geraet fuehrt das Feld "Besitzer" in der Patientenverwaltung; ob es gesendet wird,
       * haengt vom Geraet ab. Wird es gesendet, steht es hier - sonst bleibt es leer.
       */
      if (f[3]) { const g = f[3].split('^').filter(Boolean); if (g.length) akte.besitzer = (g[1] ? g[1] + ' ' : '') + g[0]; }
      if (f[6]) akte.telefon = f[6].split('^')[0] || null;
    }
    else if (type === 'OBR') {
      /*
       * OBR-4 ist die "Universal Service ID" - also WAS gemessen wurde, NICHT wer misst.
       * Das LifeVet traegt dort "CONTINUOUS WAVEFORM" ein. Als Geraetename uebernommen stand im
       * Geraete-Menue am 22.07.2026 tatsaechlich "CONTINUOUS WAVEFORM" statt eines Geraetenamens.
       * Der Name des sendenden Geraets steht in MSH-3 (Sending Application) - nur der zaehlt hier.
       * OBR-4 wird deshalb bewusst NICHT mehr als Modellname verwendet.
       */
      if (f[7]) tsStr = f[7];
    }
    else if (type === 'OBX') {
      // OBX|<seq>|<typ>|<code>^<label>|<subid>|<wert>|<einheit>|<refbereich>|<flag>|...|<status>|<zeit>
      const codeLabel = (f[3] || '').split('^');
      const code = codeLabel[0];
      const label = (codeLabel[1] || '').toLowerCase();
      const raw = f[5];
      // Einheit (OBX-6) kommt als "code^MDC_DIM_NAME^MDC" (z. B. "262688^MDC_DIM_PERCENT^MDC") ODER
      // als schlichtes Kurzzeichen ("%","/min"). Den MDC-Namen bevorzugen, sonst den ersten Teil.
      const einheitParts = (f[6] || '').split('^');
      const einheit = einheitParts.find((x) => /^MDC_DIM_/i.test(x)) || einheitParts[0] || null;
      const flag = f[8] || null;                 // Abnormal-Flag (H/L/HH/LL) = Geraetealarmstufe
      if (raw === undefined || raw === '') continue;

      /*
       * 1) KURVENBLOCK? Dann ist es KEIN Einzelmesswert (frueher wurde daraus die erste Zahl).
       *    Die beiden folgenden OBX (Abtastrate, Aufloesung) gehoeren zu dieser Kurve.
       */
      if (istKurvenblock(raw)) {
        const name = KURVEN_KLARTEXT[label] || codeLabel[1] || code;
        letzteKurve = { name: name, code: codeLabel[1] || code, samples: kurveAusBlock(raw), hz: null, skala: null };
        kurvenDaten.push(letzteKurve);
        if (kurven.indexOf(name) < 0) kurven.push(name);
        continue;
      }
      if (letzteKurve && /MDC_ATTR_SAMP_RATE/i.test(codeLabel[1] || '')) {
        const hz = Number(raw); if (Number.isFinite(hz) && hz > 0 && hz <= 2000) letzteKurve.hz = hz;
        continue;
      }
      if (letzteKurve && /MDC_ATTR_NU_MSMT_RES/i.test(codeLabel[1] || '')) {
        const sk = Number(raw); if (Number.isFinite(sk) && sk > 0) letzteKurve.skala = sk;
        /*
         * DIE EINHEIT DER AUFLOESUNG MITNEHMEN (26.08.2026).
         *
         * skala allein sagt nur "so viel je Digit" — WOVON, steht in OBX-6 dieses Eintrags.
         * Bisher wurde das Feld hier verworfen und weiter unten (model.js) fest 'uV'
         * angenommen. Der Kommentar an jener Stelle behauptet seit dem 07.08.2026, ein Geraet
         * mit anderer Einheit koenne die Annahme "ueberschreiben, statt still falsch gerechnet
         * zu werden" — es konnte nicht: die Einheit kam hier nie ins Objekt.
         *
         * Warum das zaehlt: ekg-analyse.js rechnet mit
         *     mV = wert * skala * (Einheit ist mV ? 1 : 0,001)
         * Ein in mV meldendes Geraet bekaeme also den FAKTOR 1000 zuviel — auf ST-Strecke,
         * P-Amplitude, T-Amplitude und die 0,05-mV-Grenze der QRS-Form. Das ist genau die
         * Sorte Zahl, die aussieht wie ein Befund und keiner ist.
         *
         * FEHLT OBX-6 ganz, bleibt es bei der bisherigen Annahme uV — MDC_ATTR_NU_MSMT_RES
         * ist bei HL7-Monitoren in Mikrovolt angegeben, das ist die belegte Vorgabe.
         */
        const se = spannungsEinheit(einheit);
        if (se) letzteKurve.einheit = se;
        continue;
      }

      const val0 = parseFloat(String(raw).replace(',', '.'));
      /*
       * 2) UNGUELTIG-MARKER abfangen, BEVOR daraus ein Messwert wird.
       *    32767 stand am Praxisgeraet fuer "Ableitung ab" - als Herzfrequenz gelesen waere das
       *    eine extreme Tachykardie samt falscher Empfehlung gewesen.
       */
      const val = istUngueltig(val0) ? NaN : val0;
      // Arrhythmie-Alarme stehen als Text (nicht numerisch) in OBX -> fuer inferRhythm sammeln.
      if (codeLabel[1]) obxTexts.push(codeLabel[1]);

      /*
       * ALLES MITSCHREIBEN (Kernaenderung 22.07.2026).
       * Bis hierher wurde jeder Wert verworfen, den die feste Zuordnungstabelle nicht kannte -
       * bei Textwerten sogar OHNE jede Meldung. Genau deshalb kamen Tierart, Gewicht und die
       * Klartext-Alarme des Geraets nie an, und der Tierarzt sah "liest ueberhaupt keine Daten".
       * Jetzt wandert JEDER OBX-Eintrag in roh[] und ist in der Oberflaeche sichtbar - zugeordnet
       * oder nicht. Was die Station nicht deuten kann, verschweigt sie nicht mehr, sondern zeigt
       * es unveraendert an.
       */
      roh.push({
        code: code || null,
        bezeichnung: codeLabel[1] || null,
        wert: raw,
        zahl: Number.isFinite(val) ? val : null,
        einheit: einheit,
        flag: flag || null,
      });

      // Klartext-Alarme des Geraets ("EKG-Ableitung ab", "Keine CO2-Wasserfalle").
      if (ALARM_CODE.test(codeLabel[1] || '') && !Number.isFinite(val)) {
        const txt = String(raw).trim();
        if (txt && alarmTexte.indexOf(txt) < 0) alarmTexte.push(txt);
      }

      // Tierart und Gewicht koennen in JEDEM OBX stecken - Geraete sind sich da nicht einig.
      if (!species) {
        const ausWert = Number.isFinite(val) ? null : erkenneTierart(raw);
        // Nur wenn das FELD auch nach Art/Kategorie klingt, sonst waere jeder Freitext eine Falle.
        if (ausWert && /(species|patient|categ|typ|kategorie|art|breed|rasse)/i.test(label)) species = ausWert;
      }
      if (weightFromPid == null) {
        const kg = gewichtAusOBX(label, raw, einheit);
        if (kg != null) weightFromPid = kg;
      }

      /*
       * WEITERE STAMMDATEN AUS DEM GERAET.
       * Die Patientenverwaltung des LifeVet fuehrt Groesse, Alter, Rasse und "Pacer aktiv". Wenn das
       * Geraet sie sendet, sollen sie in der Akte stehen - aber NUR, wenn das Feld auch eindeutig so
       * heisst. Ein Wert, dessen Bedeutung unklar ist, wandert nicht in die Akte, sondern bleibt
       * unter "Alle Werte vom Geraet" sichtbar. Raten waere hier so gefaehrlich wie beim Gewicht.
       */
      if (!akte.groesseCm && /(height|groesse|größe|\bhgt\b|body_?height)/i.test(label)) {
        const h = parseFloat(String(raw).replace(',', '.'));
        if (Number.isFinite(h) && h > 0 && h < 300) {
          akte.groesseCm = /^(m|meter)$/i.test(String(einheit || '')) ? Math.round(h * 100) : Math.round(h);
        }
      }
      // Achtung: "_" gilt als Wortzeichen, deshalb greift \bage\b bei MDC_ATTR_PT_AGE NICHT.
      if (!akte.alter && /(^|_)age$|(^|_)age(_|\b)|alter/i.test(label)) {
        const a = String(raw).trim();
        if (a && a.length < 24) akte.alter = a + (einheit ? ' ' + einheit : '');
      }
      if (!akte.rasse && /(breed|rasse)/i.test(label)) {
        const r = String(raw).trim();
        if (r && r.length < 40 && !Number.isFinite(Number(r))) akte.rasse = r;
      }
      // Schrittmacher: Mindray-Label ist "PACE_Switch" (Code 2303) - die alte Regex ohne "pace"
      // traf das nicht und verwarf den belegten Wert. Werte: "1^ON"/"0^Off".
      if (akte.pacer == null && /(pace|pacer|schrittmacher|paced)/i.test(label)) {
        const p = String(raw).split('^')[0].trim().toLowerCase();
        if (/^(1|ja|yes|on|true)$/.test(p)) akte.pacer = true;
        else if (/^(0|nein|no|off|false)$/.test(p)) akte.pacer = false;
      }
      // Blutgruppe (Mindray-Code 2302, "1^A") und echte Fallnummer/MRN (Code 2301) - belegt.
      if (!akte.blutgruppe && /(blood_?type|blutgruppe)/i.test(label)) {
        const bg = String(raw).split('^')[1] || String(raw).split('^')[0];
        if (bg && bg.length < 6) akte.blutgruppe = bg.trim();
      }
      if (code === '2301' && raw && String(raw).trim() && !akte.mrn) {
        // Die am Monitor eingegebene Patientennummer. PID-3 ist bei manchen Geraeten nur ein
        // bedeutungsloser GUID - dann ist DAS die echte ID. Wir merken sie und ziehen sie unten vor.
        akte.mrn = String(raw).split('^')[0].trim();
      }

      /*
       * uMEC-ALARM-/EREIGNISMELDUNGEN (Befund 23.07.2026, echtes uMEC12): der Monitor sendet Alarme
       * als OBX mit privatem Zahlencode (1/2/3/4) und dem Wert "PrioCode^Klartext", z. B.
       * "10127^***Asystole", "5^EKG Kabel Aus", "10076^**T1 zu tief", "2231^Batterie schwach".
       * So erscheinen die Geraetealarme 1:1 in der App (auch bevor Vitalwerte kommen).
       * BEWUSST nur als Anzeigemeldung — NICHT in die Rhythmus-/CPR-Logik: ein "Asystole" bei
       * abgezogenem EKG-Kabel ist ein TECHNIK-Alarm, kein Herzstillstand. Deshalb kein obxTexts.push.
       */
      if (!CODE_MAP[code] && !LABEL_MAP[label]) {
        const am = /^\d+\^(.+)$/.exec(String(raw));
        if (am) {
          const at = am[1].trim();
          if ((/\*/.test(at) || (/\s/.test(at) && at.length > 4)) && alarmTexte.indexOf(at) < 0) {
            alarmTexte.push(at);
            continue;   // als Alarm behandelt — nicht als (unbekannte) Vitalzahl weiterverarbeiten
          }
        }
      }

      if (!Number.isFinite(val)) { obxTexts.push(String(raw)); continue; }
      // LABEL vor Nummer: das MDC-Label (z. B. MDC_ECG_HEART_RATE) ist eindeutiger als die
      // Nummer und stimmt mit dem tatsaechlichen Parameter ueberein. Die Nummer ist nur der
      // Rueckfall, wenn kein Label vorhanden/bekannt ist (z. B. reiner privater Zahlencode).
      let key = LABEL_MAP[label] || CODE_MAP[code];
      if (!key) {
        // Kurven/Attribute/Alarme sind KEINE fehlende Zuordnung — nur getrennt zaehlen.
        if (KEINE_MESSWERTE.test(codeLabel[1] || '')) {
          // Reine Geraete-Attribute (Abtastrate, Aufloesung) gehoeren in KEINE Anzeige - sie sagen
          // dem Tierarzt nichts. Nur was er wiedererkennt, wird spaeter genannt; der Rest wird
          // still uebergangen (aber eben auch nicht als Fehler gemeldet).
          const klar = KURVEN_KLARTEXT[label];
          if (klar && kurven.indexOf(klar) < 0) kurven.push(klar);
          continue;
        }
        // Alarm-Grenzen/-Einstellungen des uMEC (2002/2003/2013…) sind keine Messwerte -> still uebergehen.
        if (KONFIG_CODES.has(code)) continue;
        // Beispielwert + Einheit mitgeben: nur so laesst sich ein privater Mindray-Code ("99MNDRY",
        // z. B. der uMEC sendet 2203/2213/... OHNE Label) sicher zuordnen — "2203 = 95 [%]" => SpO2.
        if (onUnmapped) onUnmapped(code + '^' + (codeLabel[1] || ''), String(raw).slice(0, 24) + (einheit ? ' [' + einheit + ']' : ''));
        continue;
      }
      if (key === 'weightKg') { const kg = gewichtAusOBX('weight', val, einheit); if (kg != null) weightFromPid = kg; continue; }

      // Einheit pruefen, bevor der Wert klinisch verwendet wird.
      const u = rechneEinheit(key, val, einheit);
      if (!u.ok) {
        const name = KLARNAME[key] || key;
        const meldung = name + ' kommt in einer unbekannten Einheit (' + einheit + ') — der Wert wird ' +
          'NICHT verwendet. Einstellung am Geraet pruefen.';
        if (alarmTexte.indexOf(meldung) < 0) alarmTexte.push(meldung);
        continue;   // lieber eine sichtbare Luecke als eine falsche Zahl
      }
      if (u.umgerechnet) {
        const hinweis = (KLARNAME[key] || key) + ' wurde von ' + u.umgerechnet + ' umgerechnet.';
        if (umrechnungen.indexOf(hinweis) < 0) umrechnungen.push(hinweis);
      }

      // Alarmstufe des Geraets (OBX-8): der Monitor hat den Wert selbst als kritisch markiert.
      if (flag && /^(H|HH|L|LL)$/i.test(String(flag).trim())) {
        const F = String(flag).trim().toUpperCase();
        const richtung = F.charAt(0) === 'H' ? 'zu hoch' : 'zu niedrig';
        const staerke = F.length > 1 ? ' (stark)' : '';
        const m = 'Geraet meldet: ' + (KLARNAME[key] || key) + ' ' + richtung + staerke;
        if (alarmTexte.indexOf(m) < 0) alarmTexte.push(m);
      }

      /*
       * HF = 0 ist praktisch immer "kein EKG-Signal" (Kabel verrauscht/ab), nicht echte Asystolie:
       * der Monitor liefert die HF dann ueber die PULSRATE (SpO2). Am echten LifeVet kam gleichzeitig
       * MDC_ECG_HEART_RATE=0 UND MDC_PULS_OXIM_PULS_RATE=72 - ohne diese Zeile ueberschriebe die 0 die
       * echte 72. Eine echte Asystolie kommt ueber Alarm/Rhythmus, nicht ueber die HF-Zahl.
       */
      if (key === 'hr' && u.wert === 0) continue;
      // uMEC12 sendet NIBP zwischen den Messungen als Platzhalter -100 (= "noch nicht gemessen",
      // belegt 24.07.2026). Ein Blutdruck <= 0 ist nie echt -> nicht uebernehmen (sonst -100/-100).
      if ((key === 'sys' || key === 'dia' || key === 'map') && u.wert <= 0) continue;
      // Mehrere OBX melden ventrikulaere Extrasystolen (PVC-Zahl, PVC-Rate, VPB-Rate, R-on-T): das
      // MAXIMUM nehmen, damit "eine davon > 0" die Arrhythmie sicher ausloest (inferRhythm -> ves).
      if (key === 'pvcs') { vit.pvcs = Math.max(vit.pvcs || 0, u.wert); continue; }
      /*
       * -100 IST KEIN MESSWERT, SONDERN "NOCH NICHT GEMESSEN" (29.08.2026).
       *
       * Fuer den Blutdruck ist dieser Platzhalter seit dem 24.07.2026 abgefangen (Zeile
       * darueber). Das Geraet benutzt ihn aber fuer JEDEN Parameter, dessen Modul gerade nicht
       * misst - am Praxis-Monitor gemessen: bei abgenommenen EKG-Elektroden kommt
       * "101^HR = -100" im Sekundentakt. Ohne diese Zeile wird daraus eine Herzfrequenz von
       * minus hundert, und mit der Rangfolge darunter haette sie sogar Vorrang vor dem
       * gueltigen Puls: aus 76 wuerde -100.
       *
       * Warum genau -100 und keine allgemeine "kleiner null"-Regel: 0 hat bei der Atemfrequenz
       * eine echte Bedeutung (Apnoe), und eine breitere Regel wuerde sie verschlucken. -100 ist
       * der dokumentierte Platzhalter, sonst nichts.
       */
      if (u.wert === -100) continue;
      /*
       * DIE HERZFREQUENZ KOMMT AUS DEM EKG, NICHT AUS DEM PULSOXIMETER (29.08.2026).
       *
       * Am uMEC12 stand auf dem Bildschirm gleichzeitig:  EKG 154  und  PF 191 (Quelle SpO2).
       * In der Station kam 191 an. Ursache: CODE_MAP bildet 101 (HF aus dem EKG), 161
       * (SpO2-Puls) und 173 (NIBP-Puls) ALLE auf 'hr' ab. Die Kommentare dort nennen 161 und
       * 173 ausdruecklich "HF-Fallback" - eine Rangfolge gab es aber nie: es gewann das
       * zuletzt gelesene OBX, und das ist bei diesem Geraet der Puls.
       *
       * Das ist keine Kosmetik. Bei schlechter Perfusion, Bewegung oder einer Arrhythmie
       * laufen EKG-Frequenz und Pulsrate auseinander - genau dann, wenn es zaehlt. An dieser
       * Zahl haengen Rhythmusdeutung, Arzneiempfehlung und Protokoll.
       *
       * Rangfolge: EKG (101 / MDC_ECG_HEART_RATE) vor SpO2-Puls (161) vor NIBP-Puls (173).
       * Ein niedrigerer Rang schreibt nur, wenn kein hoeherer geschrieben hat. Die Regel
       * "HF = 0 wird uebergangen" darueber bleibt: faellt das EKG aus, uebernimmt der Puls.
       */
      if (key === 'hr') {
        const rang = (code === '101' || /heart_rate|cardiac_rate/i.test(label)) ? 3
          : (code === '173') ? 1 : 2;
        if (vit.__hrRang != null && vit.__hrRang > rang) continue;
        vit.__hrRang = rang;
      }
      /*
       * T1 VOR T2 - UND T2 GEHT NICHT MEHR VERLOREN (Praxis-Befund 30.08.2026)
       *
       * CODE_MAP bildet 200 (T1) UND 201 (T2) auf 'temp' ab. Beide kommen beim uMEC12 in
       * DERSELBEN Nachricht, hintereinander - also gewann schlicht die zweite. Am Monitor
       * stand T1 23,5 / T2 23,6, in der Station 23,6. Der Monitor fuehrt T1 als Hauptwert;
       * wir zeigten also die falsche Sonde, und die zweite gar nicht.
       *
       * Warum nicht einfach 201 auf 'temp2' umbiegen: der Kommentar bei `temp2` weiter oben
       * haelt fest, dass beide Geraete dieser Praxis ihre EINZIGE Temperatur mitunter als T2
       * melden. Dann bliebe die Temperaturkachel leer - eine stille Verschlechterung genau der
       * Art, die hier ausgeschlossen ist.
       *
       * Also dieselbe Bauform wie bei der Herzfrequenz darueber: eine RANGFOLGE. T1 schlaegt
       * T2, aber T2 zaehlt weiterhin, solange kein T1 da ist. Und wenn beide kommen, wird T2
       * zusaetzlich als zweite Sonde gefuehrt - das Feld dafuer gibt es laengst (temp2), es
       * war nur nie verdrahtet.
       */
      if (key === 'temp') {
        const istT2 = (code === '201' || /(^|[^a-z0-9])t2([^0-9]|$)/i.test(label));
        /* T2 landet in seinem EIGENEN Feld und ruehrt `temp` nicht an. Was passiert, wenn ein
         * Geraet NUR T2 sendet, entscheidet die Zeile nach der Schleife - hier waere es zu
         * frueh: die T1-Nachricht kann noch kommen. Der erste Entwurf setzte beide Felder
         * sofort und schrieb bei einer einzigen Sonde denselben Wert zweimal hin. */
        if (istT2) { vit.temp2 = u.wert; continue; }
      }
      vit[key] = u.wert;
    }
    else if (type === 'NTE') {
      // Freitext-Kommentar des Geraets - oft die Klartextmeldung zu einem Alarm.
      const txt = (f[3] || '').trim();
      if (txt) { obxTexts.push(txt); if (alarmTexte.indexOf(txt) < 0 && txt.length < 120) alarmTexte.push(txt); }
    }
  }

  /* Der Rangzaehler der HF-Quelle ist Buchhaltung der Schleife, kein Messwert - er darf
   * nicht in den Werten landen (29.08.2026). */
  /*
   * DIE QUELLE DER HERZFREQUENZ WANDERT MIT (29.08.2026) - und warum das noetig ist:
   * am echten uMEC12 mitgeschnitten (528 Rahmen, rawLog) kommt JEDE Parametergruppe in einer
   * EIGENEN Nachricht:
   *     ID 204:  101=-100          <- EKG-Herzfrequenz, allein
   *     ID 204:  151=95            <- Atmung, allein
   *     ID 204:  160=97  161=77    <- SpO2 und Puls zusammen
   * EKG und Puls stehen NIE zusammen. Eine Rangfolge INNERHALB einer Nachricht kann deshalb
   * nichts ausrichten: die SpO2-Nachricht kommt als letzte und ueberschreibt. Der Vorrang
   * muss ueber Nachrichten hinweg gelten - dafuer braucht der Adapter die Quelle.
   */
  const hrQuelle = vit.__hrRang === 3 ? 'ekg' : vit.__hrRang === 1 ? 'nibp'
    : vit.__hrRang === 2 ? 'spo2' : null;
  delete vit.__hrRang;
  /*
   * EIN GERAET MIT NUR EINER SONDE MELDET SIE MITUNTER ALS T2 (Kommentar bei `temp2` oben).
   * Kam in dieser Nachricht kein T1, ruecke T2 auf den Hauptwert nach - sonst bliebe die
   * Temperaturkachel leer, obwohl eine Temperatur anliegt. Kamen BEIDE, bleibt T1 der
   * Hauptwert und T2 die zweite Sonde. Erst hier, nach der Schleife, steht fest, was da war.
   */
  if (vit.temp == null && vit.temp2 != null) { vit.temp = vit.temp2; delete vit.temp2; }

  // Zusammenbau ingest-Vitals (mit sinnvollen Fallbacks).
  const af = vit.af != null ? vit.af : vit.rr_imp;
  const temp = vit.temp != null ? vit.temp : vit.temp_tb;
  /* Rolle: wer Beatmungsdruecke oder Narkosegas meldet, ist ein Narkose-/Beatmungsgeraet.
   * Das ist nicht kosmetisch — matching.js gewichtet danach, WELCHES Geraet bei zwei Quellen
   * die Atemwerte liefert (Kapnograf vor Monitor). Vorher konnte ein Narkosegeraet nur ueber
   * die Konfiguration als solches erkannt werden. Bestehende Faelle bleiben unveraendert:
   * ohne diese Werte greift wie bisher etco2 -> combo, sonst monitor. */
  const beatmet = (vit.ppeak != null || vit.peep != null || vit.vte != null || vit.mv != null
    || vit.etAgent != null || vit.fiAgent != null || vit.fio2 != null);
  const role = cfg.role || (vit.etco2 != null ? 'combo' : (beatmet ? 'anesthesia' : 'monitor'));

  return {
    deviceId: cfg.deviceId || cfg.id || 'hl7',
    // Reihenfolge: ausdrueckliche Konfiguration > Geraetename aus OBR-4 > sendende Anwendung
    // (MSH-3) > neutraler Ersatz. So steht im Menue "LifeVet 10C" statt eines Sammelbegriffs.
    deviceModel: cfg.model || deviceName || sendingApp || 'Gerät' + (cfg.devicePort ? ' an Port ' + cfg.devicePort : ''),
    deviceRole: role,
    // Echte Fallnummer (MRN, Code 2301) vor dem PID-3-Wert - bei Mindray ist PID-3 mitunter nur ein
    // bedeutungsloser GUID. Ist keine MRN da, gilt PID-3 (bei diesem LifeVet ist PID-3 die echte ID).
    patientId: (akte.mrn || patientId) || cfg.patientId || null,
    // Reihenfolge bewusst: was in der Konfiguration steht, schlaegt das Geraet (der Tierarzt hat
    // das letzte Wort). Sonst nimmt die Station, was das Geraet selbst meldet.
    species: cfg.species || species || null,
    weightKg: cfg.weightKg != null ? cfg.weightKg : weightFromPid,
    // Woher Tierart/Gewicht stammen - die Oberflaeche kennzeichnet damit "vom Geraet uebernommen".
    // Bei einer Dosisangabe in mL muss nachvollziehbar sein, worauf sie sich stuetzt.
    herkunft: {
      species: cfg.species ? 'konfig' : (species ? 'geraet' : null),
      weightKg: cfg.weightKg != null ? 'konfig' : (weightFromPid != null ? 'geraet' : null),
    },
    patientName: patientName,
    gebDatum: gebDatum,
    geschlecht: geschlecht,
    // Vollstaendige Akte, soweit das Geraet sie liefert (Besitzer, Arzt, Bett, Groesse, Alter,
    // Rasse, Pacer). Alles rein zur Anzeige und fuers Protokoll - nichts davon fliesst in eine
    // Dosisberechnung ein ausser dem Gewicht, das oben streng geprueft wird.
    akte: Object.keys(akte).length ? akte : null,
    // Woher physisch: fuer das Geraete-Menue ("LifeVet 10C · 192.168.0.51 · Port 8830").
    deviceIp: cfg.deviceIp || null,
    devicePort: cfg.devicePort || null,
    transport: cfg.transport || 'HL7',
    ts: Date.now(),
    vitals: {
      hr: vit.hr, spo2: vit.spo2, etco2: vit.etco2, fico2: vit.fico2, af: af, temp: temp,
      // Beatmungs- und Gaskanaele (additiv 05.08.2026). Fehlt einer, bleibt er null und die
      // Oberflaeche zeigt "– –" — nie ein Ersatzwert.
      ppeak: vit.ppeak, pmean: vit.pmean, peep: vit.peep, vte: vit.vte, mv: vit.mv, compl: vit.compl,
      fio2: vit.fio2, etAgent: vit.etAgent, fiAgent: vit.fiAgent, mac: vit.mac, etn2o: vit.etn2o,
      pi: vit.pi, temp2: vit.temp2, ibp: vit.ibp,
      nibp: { sys: vit.sys, dia: vit.dia, map: vit.map },
      // Rhythmus aus PVC-Zaehler + Arrhythmie-Alarmtexten abgeleitet (HL7 hat keinen Rhythmus-Code).
      // capnoShape (Rueckatmung) wird zentral in model.js aus FiCO2 abgeleitet; Haiflosse braucht Waveforms.
      ekgRhythm: inferRhythm(obxTexts.join(' '), vit.pvcs),
    },
    // Klartextmeldungen des Geraets - sie erklaeren dem Tierarzt, WARUM ein Wert fehlt.
    alarms: alarmTexte.slice(0, 30).map((t) => ({ text: t, quelle: 'geraet' })),
    // Echte Kurven des Geraets. Nur Bloecke MIT Abtastrate und mit mindestens einem gueltigen Wert
    // sind darstellbar - der Rest waere eine leere Linie, die Messung vortaeuscht.
    kurvenDaten: kurvenDaten.filter((k) => k.samples.some((s) => s != null)),
    _meta: { pvcs: vit.pvcs, hl7Source: sendingApp, tsStr: tsStr, kurven: kurven, roh: roh, umrechnungen: umrechnungen, hrQuelle: hrQuelle },
  };
}

/*
 * Die Message Control ID der PDS-Abfrage ist KEIN frei waehlbarer Wert. Guide 6.9.3 NOTE,
 * woertlich: "the Message Control ID of the 10th field must be 1203 Otherwise, it cannot be
 * resolved." Am 28.08.2026 am echten uMEC12 gemessen: mit laufender Nummer kommen null
 * Messwerte, mit 1203 (und dem <CR> hinter dem letzten Segment) kommen SpO2 und Puls im
 * Sekundentakt. Die laufende Nummer bleibt in QRD-4, wo sie hingehoert.
 */
const MSH10_PDS = '1203';
const QID = { n: 1 };
function ts14() { return new Date().toISOString().replace(/\D/g, '').slice(0, 14); }

/*
 * ORTSZEIT statt UTC — ausschliesslich fuer den strikten PDS-Modus (28.08.2026).
 *
 * ts14() bleibt absichtlich unangetastet: daran haengt _sendAck, und der laeuft am Praxis-PC
 * im Listener-Weg produktiv. Eine neue Funktion daneben kann nichts kaputtmachen, eine
 * geaenderte alte schon.
 *
 * Warum ueberhaupt Ortszeit: der Mindray-Entwickler nennt als Grund fuer das Schweigen des
 * uMEC12 "den Zeitstempel". Der Guide (§6.9.4) verlangt fuer QRD-1 nur ein "valid time
 * format" und nennt an KEINER Stelle eine Zeitzone; das abgedruckte Beispiel 20060731145557
 * traegt keinen Versatz und ist damit die Uhr des Geraets. toISOString() liefert UTC und
 * weicht hier im Sommer um zwei Stunden davon ab. Belegt ist die Ortszeit damit NICHT —
 * sie ist die naheliegende Lesart, und genau deshalb faehrt tools/pds-feldsonde.js die
 * Varianten 3/4/5 einzeln, statt es zu raten.
 */
function ortszeit14(d) {
  const t = d || new Date();
  const p = (n) => (n < 10 ? '0' + n : String(n));
  return String(t.getFullYear()) + p(t.getMonth() + 1) + p(t.getDate()) +
    p(t.getHours()) + p(t.getMinutes()) + p(t.getSeconds());
}

/*
 * TCP-Echo, Wortlaut aus Guide §6.7 — einschliesslich des abschliessenden "|" (MSH-13 bleibt
 * dadurch leer, so steht es dort). "Both of the communication parties must send messages in
 * the following format every second to each other. If either party fails to receive the
 * message within 10 seconds, it ... takes the initiative to interrupt network connection."
 * Genau dieses Echo fehlt uns heute vollstaendig.
 */
/* Mit abschliessendem <CR> seit 28.08.2026 - Begruendung bei _sendQueryStrikt(). Das Echo
 * gibt es nur im strikten Zweig, der Vorgabe-Zweig ist davon nicht beruehrt. */
const PDS_ECHO = 'MSH|^~\\&|||||||ORU^R01|106|P|2.3.1|\r';

function mllp(text) { return Buffer.concat([Buffer.from([VT]), Buffer.from(text, 'latin1'), Buffer.from([FS, CR])]); }

/*
 * WIE LANGE DARF ES STILL SEIN, BEVOR DER WACHHUND ANSCHLAEGT (Befund B, 28.08.2026).
 *
 * Der strikte Zweig sendet genau EINE Abfrage je Verbindung. Das ist spezifikationstreu
 * (§6.3.3 Punkt 3: die Abfrage laeuft weiter), nimmt der Station aber die Selbstheilung, die
 * der Vorgabe-Zweig nebenbei hatte: dort wurde alle 5 s neu gefragt, eine verlorene
 * Abonnierung kam damit von selbst zurueck. Verliert das Geraet die Abonnierung, OHNE die
 * TCP-Verbindung zu trennen (zweites Auswerteprogramm, Patientenwechsel, unsere eigene
 * Feldsonde), schweigt die Station sonst dauerhaft und zeigt weiter "verbunden" — ohne eine
 * einzige Logzeile. Im OP ist das der schlimmste denkbare Ausfall: der Bildschirm sieht aus
 * wie immer, nur die Zahlen stehen still.
 *
 * 15 s = die Frist des Guides mal 1,5. §6.3.3 Punkt 3 laesst die Periodik jede Sekunde
 * kommen, §6.7 trennt das Geraet schon nach 10 s ohne Echo. Wer kuerzer misst, erneuert die
 * Abfrage bei jedem Netzruckler; wer laenger misst, laesst den Tierarzt laenger auf
 * eingefrorene Zahlen sehen als das Geraet selbst auf ein fehlendes Echo warten wuerde.
 */
const PERIODIK_FRIST_MS = 15000;

/*
 * DIE BREMSE FUER "HL7-Client WIEDER verbunden" (Befund 28.08.2026, gemessen).
 *
 * WARUM SIE NOETIG IST — die Zusammenfassung im logger.js reicht hier NICHT. Sie zaehlt nur
 * unmittelbar AUFEINANDERFOLGENDE gleiche Meldungen; sobald irgendetwas anderes dazwischen
 * loggt, beginnt eine neue Serie. Gemessen an 100 Wiederverbindungen desselben Adapters:
 *     nichts dazwischen  -> Ringzuwachs   1   (die Bremse des Loggers greift)
 *     Fremdlast dazwischen -> Ringzuwachs 200, davon 100× "WIEDER verbunden"
 * Genau der zweite Fall ist der Betriebsfall: ein Geraet, das auf 4601 antwortet und nie
 * Periodik sendet (der Veta 5 spricht dort MD2), laesst den Wachhund alle 30 s neu verbinden,
 * und zwischen zwei Wiederverbindungen liegt immer etwas anderes — die Wachhund-Warnung
 * selbst, der Fern-Versand, ein zweiter Adapter. Hochgerechnet 1,8 Zeilen je Minute, ueber
 * 2600 am Tag, unbegrenzt. Das ist dieselbe Groessenordnung, die 2026 schon einmal das
 * Diagnoseprotokoll unbrauchbar gemacht hat (siehe Konstruktor, Befund 2.3).
 *
 * WARUM EINE ZEITSCHRANKE UND NICHT "JEDE 20.": eine reine Zaehlregel hat keine Obergrenze in
 * der Zeit. Ein Geraet, das jede Sekunde ab- und wieder anmeldet, schriebe mit "jede 20."
 * immer noch drei Zeilen je Minute. Die Zeitschranke deckelt unabhaengig davon, wie schnell
 * das Geraet flattert: nach den ersten drei Malen hoechstens EINE Zeile je zehn Minuten.
 * Bei der gemessenen 30-s-Schleife des Veta-5-Falls ist das genau "jede 20.".
 *
 * DIE ERSTEN DREI STEHEN IM KLARTEXT DA. Eine einzelne Wiederverbindung ist eine echte
 * Auskunft ("das Kabel wackelt"), und sie darf nicht schon beim ersten Mal verschwinden —
 * dieselbe Abwaegung wie beim Wachhund, deshalb dieselbe Zahl.
 */
const WIEDER_LAUT = 3;
const WIEDER_STILLE_MS = 10 * 60 * 1000;

/*
 * IST DAS EINE LAUFENDE MESSWERTNACHRICHT? — die Frage, an der der Wachhund haengt.
 *
 * Er darf sich NICHT von den Nachrichten fuettern lassen, die auch OHNE gueltige Abfrage
 * kommen; sonst schlaegt er nie an, und genau das ist das Krankheitsbild am Praxis-PC
 * (Patientendaten, NIBP und Alarme kommen an, die Periodik fehlt).
 *   • Periodik traegt Message Control ID 204 (§6.10.1.3) — das ist der eindeutige Beleg.
 *   • Alarme (54/56, §6.10.4.4/§6.10.5.4) und die Parameter-Eigenschaften (207, §6.10.2.3)
 *     tragen OBX-2 = "CE" bzw. "ST", fallen also schon am Werttyp heraus.
 *   • NIBP (503) ist NM, ist aber in OBX-13 als "APERIODIC" gekennzeichnet (§6.10.3.3).
 *   • Alarmgrenzen (51, §6.10.7.3) sind NM OHNE APERIODIC und wuerden den Wachhund
 *     faelschlich fuettern — sie tragen aber die Konfigurations-IDs 2002/2003, die hier
 *     ohnehin schon als "keine Messwerte" gefuehrt werden.
 * Der Werttyp-Weg steht neben der 204 und nicht statt ihrer, weil die Geraete im Haus zwei
 * Dialekte sprechen (siehe CODE_MAP) und nicht jedes den Kopf sauber fuellt.
 */
function istPeriodisch(text) {
  const zeilen = String(text || '').split(/[\r\n]+/);
  if (((zeilen[0] || '').split('|')[9] || '') === '204') return true;
  for (let i = 0; i < zeilen.length; i++) {
    const z = zeilen[i];
    if (z.slice(0, 3) !== 'OBX') continue;
    const f = z.split('|');
    if ((f[2] || '').toUpperCase() !== 'NM') continue;      // OBX-2 Werttyp
    if (/APERIODIC/i.test(z)) continue;                     // OBX-13, aperiodische Messung
    const id = String(f[3] || '').split('^')[0];            // OBX-3 = <ID>^<Text>
    if (KONFIG_CODES.has(id)) continue;                     // Alarmgrenzen sind kein Messwert
    return true;
  }
  return false;
}

class HL7Adapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    // Modus: 'listener' (Geraet verbindet sich zum PC und pusht) ODER
    //        'client' (PC verbindet sich zum Geraet:4601, PDS Realtime, sendet QRY^R02 und empfaengt ORU).
    this.mode = cfg.mode === 'client' ? 'client' : 'listener';
    this.host = cfg.host || null;
    this.port = cfg.port || cfg.listenPort || (this.mode === 'client' ? 4601 : 5000);
    this.server = null; this.sock = null; this.qtimer = null; this.rtimer = null;
    /*
     * SCHALTER "pdsStrict" (28.08.2026). Vorgabe false/fehlt = HEUTIGES VERHALTEN, byteweise.
     * Die Begruendung dafuer steht ueber _sendQueryStrikt(); sie ist wichtiger als der Umbau
     * selbst. `=== true` und nicht `!!`: ein versehentliches "false" als Zeichenkette in
     * devices.json darf den strikten Modus nicht einschalten.
     */
    /*
     * ...UND NUR IM CLIENT-MODUS (Folgebefund 28.08.2026).
     *
     * WAS WAR: die Wirkung hing allein an `cfg.pdsStrict === true`, ohne den Modus zu fragen.
     * Seit derselbe Schluessel in ERLAUBTE_FELDER (geraeteeinrichtung.js) steht, ist er ueber
     * die Oberflaeche auf JEDEM HL7-Adapter setzbar — auch auf einem Listener. Dort unterdrueckte
     * er dann die Quittung (siehe _handleMessage), obwohl der Kommentar bei `ack` in derselben
     * Liste ausdruecklich sagt, im Listener-Weg wirke ack weiter.
     *
     * WARUM WIRKUNGSLOS UND NICHT "DOKUMENTIERT": pdsStrict ist die Regel aus Guide 6.3.3
     * Punkt 9, und die gilt fuer Kapitel 6 — den PDS-Realtime-Weg, auf dem der PC das Geraet
     * auf 4601 ABFRAGT. Der Listener ist der andere Weg (Kapitel 2, "unsolicited results"):
     * dort verbindet sich das GERAET zum PC und pusht von sich aus, es gibt keine QRY, kein
     * TCP-Echo und keinen Punkt 9. Der Name des Schalters sagt "spezifikationstreue
     * PDS-Abfrage" — auf einem Weg ohne Abfrage darf er nichts abschalten. Ein Schalter, der
     * mehr tut als sein Name ankuendigt, ist genau die Falle, die dieser Befund gefunden hat.
     *
     * Es reicht, ihn HIER wirkungslos zu machen: alles Weitere (Echo, Wachhund, strikte
     * Abfrage, unterdrueckte Quittung) fragt this.pdsStrict. Ein zweiter Riegel an jeder
     * einzelnen Stelle waere die Art von Regel, die man beim naechsten Umbau an einer Stelle
     * vergisst.
     */
    this.pdsStrict = cfg.pdsStrict === true && this.mode === 'client';
    /* Lautlos ignorieren waere falsch: dann sucht jemand die Wirkung am Geraet statt in dieser
     * Regel. EINE Zeile beim Start, wie bei der Kombination "ack" + "pdsStrict" darunter. */
    if (cfg.pdsStrict === true && this.mode !== 'client' && ctx && ctx.log && ctx.log.warn) {
      ctx.log.warn('hl7', this.id + ': "pdsStrict": true steht in der Konfiguration, wirkt auf diesem ' +
        'Adapter aber NICHT. Der Schalter gilt nur dem PDS-Realtime-Weg, auf dem der PC das Geraet ' +
        'abfragt (mode: "client", Guide Kapitel 6). Dieser Adapter ist ein Listener: das Geraet ' +
        'verbindet sich zum PC und sendet von sich aus (Guide Kapitel 2) — dort gibt es keine ' +
        'Abfrage, die spezifikationstreu sein koennte. "ack" wirkt hier unveraendert weiter.');
    }
    this.etimer = null;      // 1-s-Echo, NUR im strikten Modus (Guide 6.7)
    this.wtimer = null;      // Wachhund ueber die Periodik, NUR im strikten Modus (Befund B)
    this.letztePeriodik = 0; // Zeitpunkt der letzten laufenden Messwertnachricht
    this.wacheErneuert = false;      // in DIESER Verbindung wurde die Abfrage schon erneuert
    this.wacheNeustart = false;      // dieser Abbruch kam vom Wachhund, nicht vom Geraet
    this.wacheRunden = 0;            // wie oft insgesamt erneuert wurde (fuer die Log-Bremse)
    this.wacheNeuaufbauten = 0;      // wie oft der Wachhund die Verbindung neu aufgebaut hat
    this.wiederRunden = 0;           // wie oft insgesamt WIEDER verbunden wurde (Log-Bremse, siehe WIEDER_LAUT)
    this.wiederStumm = 0;            // davon seit der letzten geschriebenen Zeile unterdrueckt
    this.wiederZuletzt = 0;          // wann zuletzt eine "WIEDER verbunden"-Zeile geschrieben wurde
    this.beendet = false;    // ab dispose() wird nie wieder verbunden — siehe sock.on('close')

    /*
     * "ack": true UND "pdsStrict": true — EINE Zeile beim Start, und dann Ruhe (28.08.2026).
     *
     * Die Kombination ist keine Randlage, sie ist die VORGABE: devices.example.json traegt bei
     * lifevet/umec12/veta5 seit jeher "ack": true, und die Katalogvorlagen in geraetekatalog.js
     * setzen es ebenfalls. Wer den strikten Modus einschaltet, hat sie damit automatisch.
     * Bis heute hob dieser Eintrag den Schalter still wieder auf (siehe _handleMessage); jetzt
     * wird ack im strikten Modus ignoriert — aber lautlos ignorieren waere genauso falsch, denn
     * dann suchte jemand den Grund fuer die fehlende Quittung im Netz statt in dieser Regel.
     */
    if (this.pdsStrict && cfg.ack === true && ctx && ctx.log && ctx.log.warn) {
      ctx.log.warn('hl7', this.id + ': "ack": true steht in der Konfiguration und wird im strikten ' +
        'PDS-Modus BEWUSST ignoriert. Guide 6.3.3 Punkt 9: "If other message is sent, the device ' +
        'will disconnect the connection." — erlaubt sind dem Client auf diesem Weg nur QRY^R02 und ' +
        'das TCP-Echo. Das Keepalive ist also das Echo, nicht die Quittung; der Eintrag muss nicht ' +
        'geaendert werden.');
    }
    this.unmapped = new Set();
    // Wiederverbinden mit WACHSENDEM Abstand (Befund 2.3, 21.07.2026): frueher wurde fest alle
    // 3 s neu verbunden und dabei ZWEI Warnzeilen je Versuch geschrieben (error + close) = ~40
    // Zeilen pro Minute, solange das Geraet aus ist — also genau im Normalzustand VOR der
    // Inbetriebnahme. Das Diagnose-Log war dadurch unbrauchbar.
    this.wartenMs = 3000;
    this.MAX_WARTEN = 60000;
    this.versuche = 0;
    this.letzterFehler = null;
  }

  describe() { return { id: this.id, model: this.cfg.model || 'Mindray (HL7)', role: this.cfg.role || 'monitor' }; }

  /*
   * NACH dispose() MUSS connect() DEN ADAPTER WIEDER ZUM LEBEN BRINGEN (Befund C, 28.08.2026).
   *
   * Gemessen: nach dispose() holte KEIN Weg den Adapter zurueck. this.beendet blieb true, und
   * damit stieg jeder neue Verbindungsversuch in open() sofort wieder aus ("nach dispose() nie
   * wieder anklopfen"). Zwei Aufrufer schalten Geraete regelmaessig ab und wieder ein —
   * geraeteeinrichtung.entfernen()/einrichten() und erstsuche._adapterAbschalten() — und beide
   * meldeten dabei Erfolg, waehrend nichts mehr lief. Die eine Zeile hier ist die Umkehr des
   * Merkers, den dispose() setzt; ohne sie ist "abgeschaltet" gleichbedeutend mit "kaputt".
   */
  async connect() {
    this.beendet = false;
    if (this.mode === 'client') return this._connectClient();
    return this._listen();
  }

  _listen() {
    this.server = net.createServer((socket) => this._onClient(socket));
    this.server.on('error', (e) => this.ctx.log && this.ctx.log.error('hl7', 'Listener-Fehler: ' + e.message));
    this.server.listen(this.port, () => {
      this.connected = true;
      this.ctx.log && this.ctx.log.info('hl7', 'HL7-Listener auf Port ' + this.port + ' bereit (Monitor "Send HL7" -> Serveradresse=PC-IP, Port ' + this.port + ').');
    });
  }

  // PDS-Realtime-Client: PC verbindet sich zum Geraet und fragt Daten ab (QRY^R02 = nur Daten-Abfrage,
  // KEINE Geraetesteuerung), empfaengt ORU^R01, quittiert (ACK) als Keepalive, Reconnect bei Abbruch.
  /*
   * Welche Adresse wird JETZT angesprochen?
   *
   * "auto" (empfohlen) = der zuletzt im Netz gefundenen Medizin-MAC folgen. Am Praxis-PC stand am
   * 22.07.2026 fest "192.168.0.50" in der Konfiguration, das Geraet hing aber auf .51 (DHCP). Der
   * Adapter klopfte 60 s lang an eine tote Adresse, obwohl der Verbindungs-Assistent die richtige
   * bereits kannte. Bei jedem Verbindungsversuch neu aufgeloest — zieht das Geraet um, zieht die
   * Station mit.
   */
  _zielHost() {
    if (!this.host || this.host === 'auto') return geraetefund.beste(null);
    // Feste IP eingetragen: dabei bleiben, solange sie im Netz ist. Ist sie verschwunden und
    // steht stattdessen ein Geraet unter einer ANDEREN Adresse, dorthin wechseln statt ins Leere
    // zu laufen (der haeufigste Fall nach einem Router-/DHCP-Wechsel).
    return geraetefund.beste(this.host) || this.host;
  }

  _connectClient() {
    /*
     * DOPPELAUFRUF-RIEGEL (28.08.2026). connect() hatte keinen. Zwei offene Ketten bedeuten
     * zwei Sockets, zwei Abfragen — und seit es ihn gibt, zwei Echo-Timer und zwei Wachhunde
     * auf demselben Geraet.
     *
     * WIE SCHAEDLICH DIE ZWEITE KETTE IST, IST EINE EIGENE BEOBACHTUNG — KEINE HERSTELLER-
     * ANGABE (richtiggestellt 28.08.2026, Befund G). Hier stand bis heute "Das PDS-Geraet
     * laesst nur EIN abfragendes Programm zu". Im Programmer's Guide v14.2 steht dieser Satz
     * NICHT: Kapitel 6 sagt an keiner Stelle etwas ueber die Zahl gleichzeitiger Clients, und
     * <IP>&<IPSeq> in QRF-5 (§6.9.5.1) unterscheidet die BETTMONITORE hinter einem CMS/Gateway,
     * nicht die abfragenden Programme. Die einzige Obergrenze im ganzen Dokument steht in
     * §2.1.1 und gilt der ANDEREN Schnittstelle (Kapitel 2, "unsolicited results"): dort werden
     * neue Verbindungen abgewiesen, sobald die eingestellte Hoechstzahl erreicht ist — welche
     * Zahl das ist, sagt auch dort niemand.
     * Belegt ist nur eine eigene Messung vom 26.07.2026: an .50:4601 wurde eine zweite
     * Testverbindung abgewiesen, waehrend die Station eine hielt. Ein Geraet, ein Fall — genug
     * fuer den Riegel, zu wenig fuer einen Satz ueber "das PDS-Geraet".
     */
    if (this.sock || this.rtimer) return;
    if (!this.host) { this.ctx.log && this.ctx.log.warn('hl7', this.id + ': client-Modus ohne "host" -> deaktiviert (Geraete-IP setzen oder "auto" eintragen).'); return; }
    const self = this;
    const open = () => {
      if (self.beendet) return;              // nach dispose() nie wieder anklopfen
      const ziel = self._zielHost();
      if (!ziel) {
        // "auto" und noch kein Geraet gesehen: ruhig warten statt auf gut Glueck zu verbinden.
        if (self.versuche === 0 && self.ctx.log) {
          self.ctx.log.info('hl7', self.id + ': "auto" — es ist noch kein Geraet im Netz gefunden. ' +
            'Der Verbindungs-Assistent sucht weiter; sobald ein Monitor auftaucht, wird er automatisch abgefragt.');
        }
        self.versuche++;
        self.rtimer = setTimeout(open, self.wartenMs);
        self.wartenMs = Math.min(self.wartenMs * 2, self.MAX_WARTEN);
        return;
      }
      if (ziel !== self.host) {
        self.ctx.log && self.ctx.log.info('hl7', self.id + ': Geraet jetzt auf ' + ziel +
          (self.cfg.host && self.cfg.host !== 'auto' ? ' (konfiguriert war ' + self.cfg.host + ')' : '') +
          ' — die Abfrage folgt der neuen Adresse.');
        self.host = ziel;
      }
      const sock = net.connect(self.port, self.host, () => {
        const warAus = self.versuche > 0;
        self.connected = true;
        self.wartenMs = 3000; self.versuche = 0; self.letzterFehler = null;   // Erfolg -> Abstand zuruecksetzen
        self._meldeVerbunden(warAus);
        self._sendQuery(sock);
        if (self.pdsStrict) {
          /*
           * Genau EINE Abfrage je Verbindung, danach nur noch das Echo (Guide 6.3.3 Punkt 3:
           * die Abfrage laeuft weiter, sie muss nicht aufgefrischt werden). Der Timer haengt
           * an der LOKALEN `sock`, nicht an self.sock: nach einem Wiederverbinden zeigt
           * self.sock schon auf den neuen Socket, ein alter Timer wuerde dorthin schreiben.
           */
          self.etimer = setInterval(() => {
            if (sock.destroyed) return;
            try { sock.write(mllp(PDS_ECHO)); } catch (e) {
              /* Frueher schluckte der Sendeweg jeden Fehler. Solange alle 5 s neu abgefragt
               * wurde, fiel ein Fehlschlag nicht auf; hier bedeutet er, dass das Geraet nach
               * 10 s trennt — das muss im Log stehen, sonst schweigt die Station grundlos. */
              self.ctx.log && self.ctx.log.warn('hl7', self.id + ': TCP-Echo nicht gesendet (' +
                (e && e.message ? e.message : String(e)) + '). Ohne Echo trennt das Geraet nach 10 s.');
            }
          }, 1000);
          self._wacheStarten(sock);
        } else {
          self.qtimer = setInterval(() => { if (!sock.destroyed) self._sendQuery(sock); }, 5000);
        }
      });
      self.sock = sock;
      let buf = Buffer.alloc(0);
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (self.cfg.rawLog) self._rawDump(chunk);
        let start;
        while ((start = buf.indexOf(VT)) !== -1) {
          const end = buf.indexOf(FS, start + 1);
          if (end === -1) break;
          const payload = decodePayload(buf.slice(start + 1, end));
          buf = buf.slice(end + 2);
          self._handleMessage(payload, sock);
        }
        if (buf.length > 1 << 20) buf = Buffer.alloc(0);
      });
      // Der Fehler wird hier nur GEMERKT, nicht geloggt: auf jedes 'error' folgt ohnehin ein
      // 'close'. Frueher schrieben beide je eine Zeile — das war die Haelfte der Log-Flutung.
      sock.on('error', (e) => { self.letzterFehler = e && e.message ? e.message : String(e); });
      sock.on('close', () => {
        self.connected = false;
        if (self.qtimer) { clearInterval(self.qtimer); self.qtimer = null; }
        if (self.etimer) { clearInterval(self.etimer); self.etimer = null; }
        if (self.wtimer) { clearInterval(self.wtimer); self.wtimer = null; }
        /*
         * HIER endet die Kette nach dispose() (gemessen 28.08.2026, Befund: "Verbindungen
         * gesamt=2, davon NACH dispose=1"). dispose() ruft sock.destroy(); das 'close' kommt
         * DANACH und lief bisher weiter bis zur Zeile mit dem neuen Reconnect-Timer — der
         * "abgeschaltete" Adapter verband sich 3 s spaeter erneut. Bisher fiel das nicht auf,
         * weil danach nur eine Abfrage rausging; mit dem Echo waere es ein Timer, der bis zum
         * Prozessende jede Sekunde in einen fremden Socket schreibt. Genau diese Art Fehler
         * hat das Projekt schon einmal Wochen gekostet. Betrifft auch erstsuche.js:900, das
         * einen Adapter per dispose() "abschaltet" — bisher kam er von selbst zurueck.
         */
        if (self.beendet) return;
        /* Hat der Wachhund getrennt, ist "antwortet nicht" die falsche Auskunft: das Geraet
         * antwortet ja, es schweigt nur zur Abfrage. Den Grund hat der Wachhund selbst schon
         * in EINE Zeile geschrieben — eine zweite waere hier nur Rauschen. */
        const wachNeustart = self.wacheNeustart; self.wacheNeustart = false;
        self.versuche++;
        // EINMAL erklaeren, danach still weiterprobieren. Ein ausgeschaltetes Geraet ist vor der
        // Inbetriebnahme der Normalfall und darf das Log nicht fluten.
        if (!wachNeustart && self.versuche === 1 && self.ctx.log) {
          self.ctx.log.warn('hl7', 'Geraet ' + self.host + ':' + self.port + ' antwortet nicht' +
            (self.letzterFehler ? ' (' + self.letzterFehler + ')' : '') +
            '. VetStation versucht es weiter — der Abstand waechst auf bis zu ' +
            (self.MAX_WARTEN / 1000) + ' s. Weitere gleiche Meldungen werden unterdrueckt.');
        }
        self.rtimer = setTimeout(open, self.wartenMs);
        self.wartenMs = Math.min(self.wartenMs * 2, self.MAX_WARTEN);
      });
    };
    open();
  }

  /*
   * "Verbunden" bzw. "WIEDER verbunden" ins Log — mit der Bremse aus WIEDER_LAUT/WIEDER_STILLE_MS.
   *
   * DIE ERSTE Verbindung wird IMMER geschrieben: sie kommt je Adapter genau einmal, sie ist die
   * Zeile, nach der bei der Inbetriebnahme gesucht wird, und sie kann das Log nicht fluten.
   * Gebremst wird nur die WIEDERverbindung — die Begruendung und die Messung stehen bei
   * WIEDER_LAUT.
   *
   * Die unterdrueckten Faelle gehen nicht verloren, sie reisen mit der naechsten geschriebenen
   * Zeile mit. Eine Bremse, die nur schweigt, verwandelt eine Log-Flut in einen blinden Fleck —
   * dann steht am Ende NICHT im Protokoll, dass das Geraet 400-mal weggebrochen ist.
   */
  _meldeVerbunden(warAus) {
    const log = this.ctx.log;
    if (!log || !log.info) return;
    const wo = this.host + ':' + this.port + ' (PDS Realtime). Sende QRY^R02...';
    if (!warAus) { log.info('hl7', 'HL7-Client verbunden mit ' + wo); return; }

    this.wiederRunden++;
    const jetzt = Date.now();
    const laut = this.wiederRunden <= WIEDER_LAUT || (jetzt - this.wiederZuletzt) >= WIEDER_STILLE_MS;
    if (!laut) { this.wiederStumm++; return; }

    let text = 'HL7-Client WIEDER verbunden mit ' + wo;
    if (this.wiederStumm) {
      text += ' Seit der letzten Meldung wurden ' + this.wiederStumm +
        ' weitere Wiederverbindungen unterdrueckt (insgesamt ' + this.wiederRunden + ').';
    } else if (this.wiederRunden === WIEDER_LAUT) {
      text += ' Weitere gleiche Meldungen werden unterdrueckt (hoechstens eine je ' +
        (WIEDER_STILLE_MS / 60000) + ' Minuten).';
    }
    this.wiederStumm = 0;
    this.wiederZuletzt = jetzt;
    log.info('hl7', text);
  }

  /*
   * DER WACHHUND — er gibt dem strikten Zweig die Selbstheilung zurueck (Befund B, 28.08.2026).
   * ==========================================================================================
   *
   * DAS KRANKHEITSBILD, DAS ER FINDET: die TCP-Verbindung steht, das Echo laeuft, die Station
   * zeigt "verbunden" — und es kommt keine einzige laufende Zahl mehr. Das passiert, ohne dass
   * jemand ein Kabel zieht: ein zweites Auswerteprogramm fragt dasselbe Geraet ab, am Monitor
   * wird der Patient gewechselt, oder unsere eigene Feldsonde (tools/pds-feldsonde.js) haengt
   * sich dazwischen. Der Vorgabe-Zweig heilt das nebenbei, weil er ohnehin alle 5 s neu fragt.
   * Der strikte Zweig fragt genau EINMAL je Verbindung — ohne diesen Wachhund schwiege er
   * danach fuer immer, und zwar OHNE eine einzige Logzeile. Am narkotisierten Patienten ist
   * das der schlimmste denkbare Ausfall, weil er wie Normalbetrieb aussieht.
   *
   * ZWEI STUFEN, UND WARUM IN DIESER REIHENFOLGE:
   *   1. Abfrage erneuern. §6.3.3 Punkt 4 erlaubt das ausdruecklich: "CIS can send a new QRY
   *      message to this interface dynamically to refresh the parameters to be sent." Das ist
   *      der billige Weg — die Verbindung, das Echo und die Stammdaten bleiben stehen.
   *      Gesendet wird die VOLLSTAENDIGE Abfrage, nicht ein Nachtrag: §6.9.5.1 NOTE, woertlich
   *      "Every QRY message must contain all query conditions. When a new QRY message comes,
   *      the previous query condition will be refreshed." Eine halbe Abfrage wuerde die andere
   *      Haelfte also ABSCHALTEN. Genau deshalb ruft die Stufe _sendQueryStrikt() und baut
   *      nichts Eigenes zusammen.
   *   2. Hilft auch das binnen derselben Frist nicht, ist die Sitzung am Geraet verloren und
   *      nur ein neuer Verbindungsaufbau bringt sie zurueck (§6.3.3 Punkt 1: Stammdaten und
   *      Einstellungen kommen beim VERBINDUNGSaufbau). sock.destroy() genuegt — der
   *      'close'-Zweig oben baut von selbst neu auf und stellt Abfrage, Echo und Wachhund
   *      wieder her.
   *
   * NUR IM STRIKTEN MODUS. Der Vorgabe-Zweig braucht ihn nicht (er fragt alle 5 s neu), und
   * er darf sich nicht um ein Byte veraendern — darueber laeuft am Praxis-PC der Blutdruck.
   *
   * WARUM DIE LOG-BREMSE: ein Geraet, das auf 4601 antwortet, aber nie Periodik sendet (der
   * Veta 5 spricht dort MD2), durchliefe sonst dauerhaft alle 30 s zwei Meldungen — rund vier
   * Zeilen je Minute, bis das Diagnoseprotokoll unbrauchbar ist. Das ist derselbe Fehler, der
   * 2026 schon einmal die Wiederverbindung geflutet hat. Deshalb: dieselbe Haltung wie dort —
   * die ersten drei Male erklaeren, dann schweigen. Jede HANDLUNG bekommt trotzdem hoechstens
   * EINE Zeile, nie zwei.
   */
  _wacheStarten(sock) {
    const self = this;
    /* Die Frist laeuft ab der Abfrage, nicht ab Prozessstart: sonst schluege der Wachhund bei
     * einem Adapter an, der lange auf sein Geraet gewartet hat, noch bevor die erste Antwort
     * ueberhaupt kommen konnte. */
    self.letztePeriodik = Date.now();
    self.wacheErneuert = false;
    if (self.wtimer) { clearInterval(self.wtimer); self.wtimer = null; }
    self.wtimer = setInterval(() => {
      /* An der LOKALEN `sock` haengen, aus demselben Grund wie beim Echo-Timer: nach einem
       * Wiederverbinden zeigt self.sock schon auf den neuen Socket. */
      if (sock.destroyed) return;
      const still = Date.now() - self.letztePeriodik;
      if (still < PERIODIK_FRIST_MS) return;

      if (!self.wacheErneuert) {
        self.wacheErneuert = true;
        self.letztePeriodik = Date.now();       // die zweite Frist beginnt JETZT
        self.wacheRunden++;
        if (self.wacheRunden <= 3 && self.ctx.log) {
          self.ctx.log.warn('hl7', self.id + ': seit ' + Math.round(still / 1000) + ' s keine ' +
            'laufenden Messwerte, obwohl die Verbindung zu ' + self.host + ':' + self.port + ' steht. ' +
            'Die PDS-Abfrage wird EINMAL erneuert (Guide 6.3.3 Punkt 4 erlaubt das ausdruecklich).' +
            (self.wacheRunden === 3 ? ' Weitere gleiche Meldungen werden unterdrueckt.' : ''));
        }
        self._sendQueryStrikt(sock);
        return;
      }

      self.wacheNeuaufbauten++;
      if (self.wacheNeuaufbauten <= 3 && self.ctx.log) {
        self.ctx.log.warn('hl7', self.id + ': auch nach der erneuerten Abfrage kamen ' +
          Math.round(PERIODIK_FRIST_MS / 1000) + ' s lang keine Messwerte — die Verbindung zu ' +
          self.host + ':' + self.port + ' wird neu aufgebaut.' +
          (self.wacheNeuaufbauten === 3 ? ' Weitere gleiche Meldungen werden unterdrueckt.' : ''));
      }
      self.wacheNeustart = true;                // der 'close'-Zweig soll nicht "antwortet nicht" melden
      try { sock.destroy(); } catch (_) {}
    }, 1000);
  }

  _sendQuery(sock) {
    if (this.pdsStrict) return this._sendQueryStrikt(sock);
    // KORRIGIERTE Mindray-PDS-Realtime-Abfrage (Befund 25.07.2026, verifiziert aus VSCaptureMRay.dll
    // + PDS-Spec). Der fruehere Fehlversuch scheiterte NICHT am QRF, sondern an der QRD: Feld QRD-9
    // MUSS "RES" sein ("The 9th field must be RES, otherwise an error message is returned") — wir
    // hatten "MON", der Server verwarf die Query -> keine Periodik. NIBP+Alarme kommen unsolicited
    // auf einem eigenen Pfad und beweisen NICHT, dass die Query lief.
    // Format verbatim aus VSCaptureMRay.dll (liest Mindray-Periodik nachweislich): QRF SendType=1,
    // SendFreq=1s, SendAll=0 + explizite Parameter-IDs. IDs: 101=HF 151=AF 160=SpO2 161=PR
    // 170/171/172=NIBP 200/201/202=Temp 220/222=CO2/AwRR.
    /*
     * AM ECHTEN GERAET GEMESSEN, 28.08.2026, 23:13 — DAS IST DER WEG, DER LIEFERT.
     *
     * Acht Varianten am uMEC12 Vet (192.168.0.50), je 25 s, Sensoren am Patienten. Genau
     * EINE brachte die laufenden Werte, und zwar diese hier:
     *
     *     160/SpO2 x20 (zuletzt 97)   161/PR x20 (zuletzt 88)
     *     101/HF   x20 (-100)         151/AF x20 (-100)   <- EKG-Kabel ab, Platzhalter
     *
     * Zwei Dinge mussten dafuer zusammenkommen, beide waren hier falsch:
     *   1. MSH-10 muss WOERTLICH 1203 sein (Guide 6.9.3 NOTE: "the Message Control ID of the
     *      10th field must be 1203 Otherwise, it cannot be resolved"). Hier stand eine
     *      laufende Nummer.
     *   2. Hinter das LETZTE Segment gehoert ein <CR>. Auf der Leitung stand
     *      "...&222<FS><CR>" statt "...&222<CR><FS><CR>". Der Guide setzt in jedem Beispiel
     *      (6.9.2, 6.9.6, 6.7) hinter jedes Segment einen Wagenruecklauf und verwirft eine
     *      formwidrige Nachricht nach 6.9.7 OHNE Rueckmeldung - genau das beobachtete Bild.
     *
     * WAS BEWUSST BLEIBT, obwohl der Guide es anders liest: die Wiederholung alle 5 s und die
     * Quittung auf jede Nachricht. Die spezifikationstreue Lesart (EINE Abfrage + 1-s-Echo +
     * keine Quittung, siehe _sendQueryStrikt) wurde im selben Lauf mitgemessen - die
     * Varianten 3 bis 8 - und lieferte NICHTS. An diesem Geraet ist die woertliche Lesart
     * die falsche. Deshalb wird hier nichts "aufgeraeumt": der Weg, der misst, gewinnt.
     */
    const segs = [
      'MSH|^~\\&|||||||QRY^R02|' + MSH10_PDS + '|P|2.3.1',
      'QRD|' + ts14() + '|R|I|Q' + (QID.n++) + '|||||RES',
      'QRF|MON||||0&0^1^1^0^101&151&160&161',
      'QRF|MON||||0&0^1^1^0^170&171&172&200',
      'QRF|MON||||0&0^1^1^0^201&202&220&222',
      /*
       * BEATMUNG UND KAPNOGRAFIE MITFRAGEN (28.08.2026).
       * Bis heute standen diese Kennziffern in keiner Abfrage - wir haben sie nie angefordert
       * und daraus geschlossen, das Geraet habe sie nicht. Anlass: das Narkosegeraet Veta 5
       * Plus ist am Monitor angemeldet ("Monitor verbunden: M0001 -> 192.168.0.50"). Traegt
       * diese Kopplung seine Werte in den Monitor, liegen sie dort bereit. Kostet nichts:
       * kennt der Monitor eine Kennziffer nicht, bleibt sie leer wie jedes unbestueckte Modul.
       * Hoechstens VIER Kennziffern je Segment (Guide 6.9.5.1: "less than 5").
       */
      'QRF|MON||||0&0^1^1^0^250&251&268&269',
      /*
       * 302 IST BEWUSST NICHT DABEI (28.08.2026). Der Guide fuehrt 302 als PEEP. In CODE_MAP
       * oben steht '302': 'pvcs' - "MNDRY VPB-/RonT-Rate, am echten uMEC/LifeVet belegt".
       * Dieselbe Zahl bedeutet in den beiden Dialekten also Verschiedenes. Wer sie anfordert,
       * ohne die Zuordnung vorher zu klaeren, laesst die Station eine Beatmungszahl als
       * ventrikulaere Extrasystolen verbuchen - eine Zahl mit klinischer Bedeutung, die
       * niemand als falsch erkennt. Erst messen, welcher Dialekt hier gilt, dann anfordern.
       */
      'QRF|MON||||0&0^1^1^0^301&303&305&306',
      'QRF|MON||||0&0^1^1^0^309&310',
    ];
    try { sock.write(mllp(segs.join('\r') + '\r')); } catch (_) {}
  }

  /*
   * SPEZIFIKATIONSTREUE PDS-ABFRAGE — nur wenn "pdsStrict": true in devices.json steht.
   * ==================================================================================
   *
   * WARUM DER ZWEITE ZWEIG UEBERHAUPT (28.08.2026):
   * Am Praxis-PC kommen ueber diesen Weg heute Patientendaten, NIBP und Alarme an — die
   * Periodik (HF, SpO2, Temp, EtCO2) fehlt. Genau das sagt der Guide voraus: §6.3.3 Punkt 1
   * schickt Stammdaten und Einstellungen beim Verbindungsaufbau, Punkt 2 die Alarme jede
   * Sekunde unaufgefordert, Punkt 5 die aperiodischen Messungen (NIBP) sofort — und NUR
   * Punkt 3 haengt an der Abfrage: "Only when receives a QRY message from CIS ... this
   * interface will send what CIS needs every one second." Eine verworfene Abfrage kostet
   * also exakt die Periodik und sonst nichts. Der Befund am Geraet deckt sich Punkt fuer
   * Punkt mit einer verworfenen Abfrage.
   *
   * WAS UNSERE HEUTIGE ABFRAGE VERLETZT:
   *   • MSH-10 ist eine laufende Nummer. §6.9.3 NOTE, woertlich: "the Message Control ID of
   *     the 10th field must be 1203 Otherwise, it cannot be resolved." Steht dort etwas
   *     anderes, tut der Server kommentarlos NICHTS — kein ACK, kein QAK, kein ERR
   *     (§6.3.3 NOTE, §6.3.4 NOTE, §6.9.5.1 NOTE, §6.9.7 sagen das viermal ausdruecklich).
   *     Deshalb ist der bisherige Test immer gruen geblieben: ein Fake-Geraet, das auf jedes
   *     /QRY/ antwortet, kann dieses Schweigen gar nicht nachstellen.
   *   • Es gibt kein 1-s-Echo (§6.7). Ohne Echo trennt das Geraet nach 10 s.
   *   • QRD-1 kam aus toISOString(), also UTC.
   *
   * HEILIGE REGEL — WARUM DER SCHALTER UND NICHT EINFACH DIE KORREKTUR:
   * Ueber genau diesen Weg laeuft am Praxis-PC HEUTE der Blutdruck. Er ist im OP der einzige
   * Messwert, der ueberhaupt ankommt. Solange nicht am echten Geraet GEMESSEN ist, dass die
   * strikte Form mehr liefert, darf die alte Form sich nicht um ein Byte veraendern —
   * ein Fehler hier kostet den Tierarzt am narkotisierten Patienten den Blutdruck.
   * Deshalb: Vorgabe = alter Zweig, Wort fuer Wort; der neue Zweig steht daneben.
   *
   * MSH-7 BLEIBT LEER — die Anleitung widerlegt die fruehere Vorgabe (richtiggestellt
   * 28.08.2026, nachgeschlagen im Volltext des Guides v14.2):
   *   • §6.4.1.1 "Definition of MSH Segment" fuehrt genau die Felder 1, 2, 9, 10, 11, 12 und
   *     18 als "Used". MSH-7 (Date/Time of Message) steht dort GAR NICHT — es ist in diesem
   *     Kapitel kein benutztes Feld.
   *   • Alle neun QRY-Beispiele des Kapitels lassen es leer, u. a. §6.9.3 und §6.9.6:
   *     "MSH|^~\&|||||||QRY^R02|1203|P|2.3.1" — sieben leere Trennstriche vor QRY^R02.
   *   • §6.9.3 NOTE sagt dazu: "The MSH segment must be in the above format." Wer MSH-7
   *     fuellt, weicht also von der Form ab, die der Guide ausdruecklich verlangt.
   * Bis heute stand hier die Ortszeit, begruendet mit "WEIL die Aufgabe es so vorgibt" — das
   * war der einzige Grund, und er traegt gegen drei Fundstellen nicht.
   *
   * QRD-1 BLEIBT GEFUELLT, UND DIE ZEITZONE IST NICHT BELEGT:
   *   • §6.9.4, Verarbeitungsregeln: "The 1st field must be in valid time format. Otherwise,
   *     an error message is returned." QRD-1 ist also Pflicht — im Gegensatz zu MSH-7.
   *   • OB ORTSZEIT ODER UTC, SAGT DER GUIDE AN KEINER STELLE. Nachgezaehlt im Volltext: die
   *     Woerter "local time", "UTC", "GMT", "time zone" und "timezone" kommen KEIN EINZIGES
   *     Mal vor. Die Ortszeit bleibt damit eine Lesart, kein Beleg — begruendet nur dadurch,
   *     dass die abgedruckten Beispiele (19970731145557, 20060731145557) keinen Versatz
   *     tragen und deshalb die Uhr des Geraets zeigen. Wer das aendern will, misst es an
   *     einem echten Geraet, statt hier eine Zeile umzustellen.
   *   • Laenge: die Tabelle in §6.9.4 schreibt "YYYYmmDDhhMMss000" (17 Stellen), jedes
   *     Beispiel des Guides hat aber 14. Wir folgen den Beispielen.
   *
   * VERHAELTNIS ZU tools/pds-feldsonde.js: dieser Zweig ist jetzt Variante 3 (MSH-10=1203,
   * MSH-7 leer, Echo, kein ACK) mit der Ortszeit aus Variante 5 in QRD-1. Genau diese
   * Mischung faehrt die Sonde heute nicht als eigene Variante — wer sie am Geraet pruefen
   * will, muss sie dort ergaenzen.
   */
  _sendQueryStrikt(sock) {
    const id = QID.n++;
    const ts = ortszeit14();
    /* QRD-4 muss laut §6.9.4 nicht leer und UNTER 16 Byte sein; auf Eindeutigkeit prueft der
     * Server ausdruecklich nicht. Die Nummer waechst mit jeder Verbindung, das Abschneiden
     * ist also die Zusicherung der Laengengrenze, nicht Kosmetik. */
    const qid = ('Q' + id).slice(0, 15);
    /* Hoechstens 4 IDs je Segment: §6.9.5.1 schreibt "The amount of <ID> in each Query Filter
     * is less than 5" — also 4, nicht 5, und kein Beispiel im Guide nutzt mehr. Dieselben IDs
     * wie im Vorgabe-Zweig, damit die beiden Zweige vergleichbar bleiben. */
    const segs = [
      /* MSH-7 LEER — sieben Trennstriche, Wort fuer Wort wie im Beispiel des Guides
       * (§6.9.3, §6.9.6). Begruendung ausfuehrlich im Block ueber dieser Funktion. */
      'MSH|^~\\&|||||||QRY^R02|1203|P|2.3.1',
      'QRD|' + ts + '|R|I|' + qid + '|||||RES',
      'QRF|MON||||0&0^1^1^0^101&151&160&161',
      'QRF|MON||||0&0^1^1^0^170&171&172&200',
      'QRF|MON||||0&0^1^1^0^201&202&220&222',
    ];
    /*
     * DAS ABSCHLIESSENDE <CR> (28.08.2026): der Guide setzt in jedem Beispiel (6.9.2, 6.9.6,
     * 6.7) hinter JEDES Segment einen Wagenruecklauf, auch hinter das letzte. Bis heute ging
     * hier "...&222<FS><CR>" statt "...&222<CR><FS><CR>" raus. Eine formwidrige Nachricht
     * wird laut 6.9.7 ohne jede Rueckmeldung verworfen - also genau das beobachtete
     * Krankheitsbild.
     *
     * NACHGEZOGEN 29.08.2026: hier stand "Im VORGABE-Zweig (oben) bleibt es bewusst beim
     * alten Stand ... er wird erst geaendert, wenn die Messung zeigt, dass das <CR> wirklich
     * etwas bewirkt." Die Messung liegt seit der Nacht auf den 29.08.2026 vor - sie zeigt
     * genau das -, und der Vorgabe-Zweig traegt das <CR> seither ebenfalls. Der Satz war
     * damit eine Bedingung, die laengst eingetreten war; stehengeblieben haette er den
     * naechsten Leser glauben lassen, oben fehle es noch.
     * Bewacht wird beides von tools/pds-streng-test.js (Abschnitte (a), (d) und (e)).
     */
    try { sock.write(mllp(segs.join('\r') + '\r')); } catch (e) {
      /* Im Vorgabe-Zweig wird alle 5 s neu gefragt, ein geschluckter Fehlschlag faellt dort
       * nicht auf. Hier gibt es nur DIESE eine Abfrage: ein stiller Fehler bedeutete
       * dauerhaftes Schweigen ohne eine einzige Logzeile. */
      this.ctx.log && this.ctx.log.warn('hl7', this.id + ': PDS-Abfrage nicht gesendet (' +
        (e && e.message ? e.message : String(e)) + ') — es kommt keine Periodik.');
    }
  }

  _onClient(socket) {
    const ip = socket.remoteAddress;
    this.ctx.log && this.ctx.log.info('hl7', 'Monitor verbunden: ' + ip);
    let buf = Buffer.alloc(0);
    /* Bis zum ersten vollstaendigen Rahmen wird geprueft, ob hier HTTP gesprochen wird. */
    let riegelOffen = true;
    socket.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      if (this.cfg.rawLog) this._rawDump(chunk);
      /*
       * KEIN HTTP AUF DEM HL7-PORT (Befund 17.08.2026).
       *
       * Dieser Port ist der PRODUKTIVE Weg (in der laufenden Station "hl7 [umec12-abfrage]"), und
       * die Rahmensuche darunter arbeitet wie im probe mit indexOf ueber den ganzen Puffer: ein
       * Rahmen im Rumpf einer HTTP-Anfrage wird gefunden und geparst. Eine Seite im Browser des
       * Praxis-PCs konnte damit einen erfundenen Patienten einspeisen. Begruendung und die
       * Ueberlegung, warum NICHT die Rueckschleife gesperrt wird, stehen in
       * bridge/src/geraeteriegel.js — derselbe Riegel, dieselbe Datei, wie bei herkunft.js.
       */
      if (riegelOffen) {
        const methode = geraeteriegel.istHttpAnfrage(buf);
        if (methode) {
          this.ctx.log && this.ctx.log.warn('hl7', 'Port ' + this.port + ' (' + ip + '): ' + methode +
            '-Anfrage statt HL7. Ein Monitor spricht hier kein HTTP — Verbindung getrennt, nichts ' +
            'uebernommen. Von 127.0.0.1 aus war es eine Seite im Browser dieses PCs.');
          buf = Buffer.alloc(0);
          try { socket.destroy(); } catch (_) {}
          return;
        }
      }
      // MLLP-Rahmen extrahieren: <VT> payload <FS><CR>
      let start;
      while ((start = buf.indexOf(VT)) !== -1) {
        const end = buf.indexOf(FS, start + 1);
        if (end === -1) break;                          // Rahmen noch unvollstaendig
        const payload = decodePayload(buf.slice(start + 1, end)); // UTF-8 laut MSH-18, sonst latin1
        buf = buf.slice(end + 2);                        // FS + CR ueberspringen
        riegelOffen = false;                             // ab hier ist belegt: hier spricht ein Geraet
        this._handleMessage(payload, socket);
      }
      if (buf.length > 1 << 20) buf = Buffer.alloc(0);   // Schutz gegen Muell
    });
    socket.on('error', (e) => this.ctx.log && this.ctx.log.warn('hl7', 'Socketfehler ' + ip + ': ' + e.message));
    socket.on('close', () => this.ctx.log && this.ctx.log.warn('hl7', 'Monitor getrennt: ' + ip));
  }

  _handleMessage(text, socket) {
    // Roh-Ringpuffer AUCH im Client-Modus (bisher nur beim probe): so sind die uMEC-Nachrichten
    // ueber /api/rohnachrichten belegbar, egal ob das Geraet pusht oder der PC abfragt.
    this.letzteRoh = this.letzteRoh || [];
    this.letzteRoh.push({ ts: Date.now(), port: this.port, text: String(text).slice(0, 8000) });
    if (this.letzteRoh.length > 40) this.letzteRoh.shift();
    /* Den Wachhund fuettern, BEVOR geparst wird: er soll auch dann satt sein, wenn der Parser
     * an einer einzelnen Nachricht scheitert — sonst baute ein Parse-Fehler alle 30 s die
     * Verbindung neu auf, obwohl das Geraet einwandfrei sendet. Nur im strikten Modus, sonst
     * kostet die Zeile im Listener-Weg Rechenzeit fuer nichts. */
    if (this.pdsStrict && istPeriodisch(text)) this.letztePeriodik = Date.now();
    let frame;
    try {
      frame = parseHL7Message(text, {
        deviceId: this.cfg.deviceId || this.id, model: this.cfg.model, role: this.cfg.role,
        species: this.cfg.species, weightKg: this.cfg.weightKg, patientId: this.cfg.patientId,
      }, (u, info) => {
        if (!this.unmapped.has(u)) { this.unmapped.add(u); this.ctx.log && this.ctx.log.warn('hl7', 'Unbekannter OBX-Code (bitte in CODE_MAP ergaenzen): ' + u + (info ? ' (Beispielwert: ' + info + ')' : '')); }
      });
    } catch (e) { this.ctx.log && this.ctx.log.warn('hl7', 'Parse-Fehler: ' + e.message); return; }
    if (frame) this._hfVorrang(frame);
    if (frame) this.emit(frame);
    // HL7-ACK (Protokoll-Quittung, KEINE Geraetesteuerung). Im Client-Modus als Keepalive noetig.
    /*
     * IM STRIKTEN MODUS WIRD NIE QUITTIERT — AUCH NICHT BEI "ack": true (28.08.2026).
     *
     * Guide §6.3.3 Punkt 9, woertlich: "If other message is sent, the device will disconnect
     * the connection." Erlaubt sind dem Client auf diesem Weg nur QRY^R02 (§6.9) und das
     * TCP-Echo (§6.7) — das Keepalive ist also das Echo, nicht die Quittung. Ein HL7-ACK ist
     * fuer das Geraet genau so eine "other message".
     *
     * WARUM DIE FRUEHERE AUSNAHME WEG MUSS: hier stand `this.cfg.ack === true`, also "im
     * strikten Modus nur quittieren, wenn es ausdruecklich konfiguriert ist". Genau das WAR
     * die Vorgabe — devices.example.json trug bei lifevet/umec12/veta5 "ack": true, und die
     * Katalogvorlagen in geraetekatalog.js setzen es ebenfalls. Wer den Schalter einschaltete,
     * bekam damit automatisch die Kombination, die dieser Kommentar selbst als selbstaufhebend
     * beschrieben hat. Eine Regel, die ihre haeufigste Konfiguration als Ausnahme zulaesst,
     * ist keine Regel.
     *
     * DAS IST EIN SEHR GUTER KANDIDAT FUER DIE ECONNRESET-SCHLEIFEN, die seit Juli 2026 auf
     * .50:4601 beobachtet werden: die Station verbindet sich, quittiert die erste Nachricht
     * des Geraets, das Geraet trennt nach Punkt 9, die Station verbindet erneut — und der
     * Grund steht nirgends, weil das Geraet formwidrige Nachrichten kommentarlos behandelt
     * (§6.3.3 NOTE: kein ACK, kein NACK). Bewiesen ist das erst, wenn die Schleife am echten
     * Geraet ausbleibt; ausgeschlossen ist diese Ursache ab hier.
     *
     * Der Vorgabe-Zweig bleibt WOERTLICH stehen: an ihm haengt am Praxis-PC der Blutdruck.
     * Steht "ack": true zusammen mit "pdsStrict": true in der Konfiguration, sagt der
     * Konstruktor EINMAL beim Start, dass der Eintrag hier bewusst ignoriert wird.
     *
     * HIER FEHLT KEINE mode-BEDINGUNG (28.08.2026). this.pdsStrict ist im Listener-Modus schon
     * im Konstruktor false — die Begruendung steht dort und gehoert an genau EINE Stelle. Wer
     * hier ein zweites `this.mode === 'client'` einbaut, hat den Schalter an zwei Stellen zu
     * pflegen und vergisst beim naechsten Umbau eine davon.
     */
    if (!this.pdsStrict && (this.cfg.ack || this.mode === 'client')) this._sendAck(socket, text);
  }

  /*
   * ACHTUNG — DIESE ZEILE HAT EINEN FELDVERSATZ, UND ER STEHT HIER MIT ABSICHT (28.08.2026).
   *
   * GEMESSEN AUF DER LEITUNG, nicht am Quelltext geraten: der Adapter wurde gegen einen
   * lauschenden Testserver gefahren, der das ACK mitgeschnitten und Feld fuer Feld ausgezaehlt
   * hat. Nach "VetStation" stehen FUENF Pipes statt vier; ab MSH-7 rutscht dadurch alles um
   * genau ein Feld nach hinten:
   *     MSH-7  (Date/Time of Message)  LEER      statt des Zeitstempels
   *     MSH-8  (Security)              20260828164953
   *     MSH-9  (Message Type)          LEER      statt "ACK^R01"
   *     MSH-10 (Message Control ID)    ACK^R01   statt der Nummer der quittierten Nachricht
   *     MSH-11 (Processing ID)         4711  |  MSH-12 (Version ID) P  |  MSH-13  2.3.1
   * Das MSA-Segment daneben ist in Ordnung (MSA-1=AA, MSA-2=Kontrollnummer).
   *
   * WARUM ES HEUTE NICHT BEHOBEN WIRD — das ist eine Abwaegung, keine Nachlaessigkeit:
   *   • Dieser Zweig ist der PRODUKTIVE Weg am Praxis-PC. Ueber ihn kommt heute der Blutdruck.
   *     Am echten uMEC12/LifeVet ist nie gemessen worden, wie das Geraet auf ein KORREKT
   *     gefuelltes ACK reagiert — Guide §6.3.3 NOTE sagt ausdruecklich, dass es formwidrige
   *     Nachrichten kommentarlos behandelt (kein ACK, kein NACK). Ein "besseres" ACK kann also
   *     nicht am Testplatz, sondern nur am Geraet bestaetigt werden.
   *   • tools/pds-feldsonde.js baut denselben Versatz BEWUSST nach (dort baueAck()), damit die
   *     Sonde das heutige Krankheitsbild wirklich trifft, und tools/pds-feldsonde-test.js
   *     verlangt Bytegleichheit beider Stellen. Wer hier eine Pipe entfernt, muss beide
   *     Dateien mitziehen; wer nur eine anfasst, faerbt den Sammellauf rot ODER — schlimmer —
   *     laesst Sonde und Station auseinanderlaufen, ohne dass es auffaellt.
   *
   * WER ES SPAETER BEHEBT: eine einzige Pipe weniger ("VetStation||||" statt "VetStation|||||")
   * rueckt alles an seinen Platz. Vorher am ECHTEN Geraet messen, ob es die Periodik dann noch
   * liefert, und pds-feldsonde.js/-test.js im selben Zug nachziehen.
   */
  /*
   * DAS EKG SCHLAEGT DEN PULS - UEBER NACHRICHTENGRENZEN HINWEG (29.08.2026).
   *
   * Am Praxis-Monitor stand gleichzeitig EKG 154 und PF 191 (Quelle SpO2); in der Station kam
   * 191 an. Der Mitschnitt (528 Rahmen) zeigt warum: das Geraet sendet jede Parametergruppe
   * EINZELN - "101=-100" allein, "160=97 161=77" zusammen. Die SpO2-Nachricht kommt als
   * letzte, und die Registry behaelt den zuletzt gemeldeten Wert. Eine Rangfolge innerhalb
   * einer Nachricht (siehe parseHL7Message) greift deshalb nie. Erster Anlauf war genau dieser
   * Fehler: im Parser richtig, an der Wirklichkeit vorbei.
   *
   * Loesung: der Adapter merkt sich, WANN zuletzt eine gueltige EKG-Herzfrequenz kam. Solange
   * die nicht aelter als FRIST ist, wird eine puls-abgeleitete HF aus dem Frame ENTFERNT -
   * nicht ueberschrieben. Die Registry behaelt dann den EKG-Wert, statt eine falsche Zahl zu
   * bekommen. Faellt das EKG aus (Kabel ab, -100, 0), laeuft die Frist ab und der Puls
   * uebernimmt von selbst - genau das Verhalten, das ein Monitor auch zeigt.
   *
   * FRIST 6 s: das Geraet sendet die Gruppen im Sekundentakt; sechs verpasste Runden sind
   * sicher ein echter Ausfall und nicht eine verzoegerte Nachricht. Kuerzer waere ein
   * Flackern zwischen zwei Quellen, laenger hinge eine tote EKG-Zahl zu lange fest.
   *
   * Gemessen (vier Faelle, frischer Adapter je Fall):
   *   EKG 154 dann Puls 191            -> Puls entfernt, 154 bleibt
   *   EKG -100 dann Puls 76            -> 76 kommt durch
   *   EKG 154, 7 s Pause, dann Puls 76 -> 76 uebernimmt
   *   nur Puls 88                      -> 88
   */
  _hfVorrang(frame) {
    const FRIST = 6000;
    const v = frame && frame.vitals; if (!v || v.hr == null) return;
    const q = (frame._meta && frame._meta.hrQuelle) || null;
    const jetzt = Date.now();
    if (q === 'ekg') { this.letzteEkgHf = jetzt; return; }
    if (this.letzteEkgHf && (jetzt - this.letzteEkgHf) < FRIST) delete v.hr;
  }

  _sendAck(socket, orig) {
    try {
      const msh = (orig.split(/[\r\n]+/)[0] || '').split('|');
      const ctrlId = msh[9] || '1';
      const ack = 'MSH|^~\\&|VetStation|||||' + new Date().toISOString().replace(/\D/g, '').slice(0, 14) + '||ACK^R01|' + ctrlId + '|P|2.3.1\rMSA|AA|' + ctrlId + '\r';
      socket.write(Buffer.concat([Buffer.from([VT]), Buffer.from(ack, 'latin1'), Buffer.from([FS, CR])]));
    } catch (_) {}
  }

  _rawDump(chunk) {
    try {
      const dir = path.join(__dirname, '..', '..', 'data');
      fs.mkdirSync(dir, { recursive: true });
      fs.appendFileSync(path.join(dir, 'hl7-raw.log'), chunk.toString('latin1'));
    } catch (_) {}
  }

  dispose() {
    /* MUSS die erste Anweisung sein: sock.destroy() loest das 'close'-Ereignis aus, und dessen
     * Handler wuerde ohne diesen Merker sofort einen neuen Reconnect-Timer setzen. */
    this.beendet = true;
    if (this.server) { try { this.server.close(); } catch (_) {} }
    if (this.sock) { try { this.sock.destroy(); } catch (_) {} }
    if (this.qtimer) clearInterval(this.qtimer);
    if (this.etimer) clearInterval(this.etimer);
    if (this.wtimer) clearInterval(this.wtimer);
    if (this.rtimer) clearTimeout(this.rtimer);
    this.server = this.sock = this.qtimer = this.etimer = this.wtimer = this.rtimer = null;
    this.connected = false;
    /* Der Wachhund faengt bei der naechsten Verbindung von vorne an. Bliebe wacheErneuert
     * stehen, wuerde ein wiederbelebter Adapter (connect() nach dispose(), Befund C) beim
     * ersten Schweigen sofort die Verbindung neu aufbauen, statt es erst mit der billigen
     * Auffrischung zu versuchen. */
    this.wacheErneuert = false;
    this.wacheNeustart = false;
  }
}

module.exports = { HL7Adapter, parseHL7Message, decodePayload };
