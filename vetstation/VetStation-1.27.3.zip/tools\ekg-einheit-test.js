'use strict';
/*
 * ekg-einheit-test.js — die Einheit einer EKG-Kurve ueberlebt den Weg vom Geraet bis zur
 * Auswertung. Und wo sie fehlt oder unbekannt ist, wird geschwiegen statt gerechnet.
 *
 * WARUM ES DIESEN TEST GIBT (Befund 26.08.2026, gefunden ueber eine fremde Analyse-Ernte)
 *
 * ekg-analyse.js entscheidet ueber den FAKTOR 1000 an einer einzigen Stelle:
 *     mV = wert * skala * (Einheit ist mV ? 1 : 0,001)
 * Davon haengen ST-Strecke, P-Amplitude, T-Amplitude und die 0,05-mV-Grenze der QRS-Form ab —
 * also genau die Zahlen, die auf einem Befund stehen.
 *
 * Die Kette hatte DREI voneinander unabhaengige Bruchstellen, und alle drei sahen im Quelltext
 * richtig aus:
 *
 *   1. hl7.js las OBX-6 des Eintrags MDC_ATTR_NU_MSMT_RES gar nicht mit. Die Kurve trug
 *      "skala", aber nie "einheit".
 *   2. model.js fuehrt die Einheit seit dem 07.08.2026 in seiner Positivliste MIT — und der
 *      Kommentar dort verspricht ausdruecklich, ein Geraet mit anderer Einheit koenne die
 *      Annahme "ueberschreiben, statt still falsch gerechnet zu werden". Zwanzig Zeilen
 *      spaeter stand aber fest analysiere(kanal, { einheit: 'uV' }). Ueberschreiben konnte
 *      also nichts. Ein BESCHRIEBENER Schutz, der nicht greift, ist schlechter als keiner:
 *      man verlaesst sich darauf.
 *   3. registry.js ist der ZWEITE Bauweg derselben Auswertung (gepufferter 4-s-Streifen) und
 *      hatte dieselbe feste Zeile — und sein Puffer ist ebenfalls eine Positivliste, in der
 *      "einheit" fehlte.
 *
 * Eine vierte Falle steckt in der Behebung selbst: die MDC-Nomenklatur schreibt
 * MDC_DIM_MICRO_VOLT und MDC_DIM_MILLI_VOLT. Keine der beiden enthaelt "uv" oder "mv", und
 * model.js kuerzt die Einheit auf 8 Zeichen ("MDC_DIM_"). Waere die Zeichenkette unveraendert
 * weitergereicht worden, haette die Auswertung ab sofort JEDEN HL7-Monitor fuer unkalibriert
 * gehalten und zur ST-Strecke geschwiegen — eine Verschlimmbesserung, die kein Test bemerkt
 * haette, weil "schweigt" in diesem Projekt nie als Fehler zaehlt.
 *
 * Der Test faehrt deshalb den ECHTEN Parser und die ECHTE Auswertung, nicht nur den Quelltext.
 *
 * Start:  node tools/ekg-einheit-test.js
 */
const fs = require('fs');
const path = require('path');
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const { normalizeFrame } = require('../bridge/src/model');
const EKG = require('../ui/shared/ekg-analyse.js');

let ok = 0;
const fehler = [];
function pruefe(was, bedingung, zusatz) {
  if (bedingung) { ok++; console.log('  ok   ' + was); return; }
  fehler.push(was + (zusatz ? '   [' + zusatz + ']' : ''));
  console.log('  FEHL ' + was + (zusatz ? '   [' + zusatz + ']' : ''));
}

/*
 * EIN SYNTHETISCHES EKG MIT P, QRS UND T — und warum es genau so aussehen muss.
 *
 * Erster Entwurf: Grundlinie 0, ein Rechteck als QRS, danach eine angehobene ST-Strecke, und
 * geprueft wurde st.mv. Das ging schief, und zwar nicht ein bisschen: st.mv kam als 0 heraus,
 * und 0 mal 1000 ist wieder 0 — der Test waere gruen geworden, ohne irgendetwas zu zeigen.
 * Nachgemessen war der Grund lehrreich: grundlinieAbziehen() ENTFERNT eine laenger anhaltende
 * Anhebung, das ist ihre Aufgabe. Ein Testsignal, dessen Messgroesse der erste Verarbeitungs-
 * schritt wegfiltert, misst nur sich selbst.
 *
 * Deshalb wird hier dieselbe Wellenform benutzt wie in tools/p-welle-test.js: erhoehter
 * Kosinus mit exaktem Traeger, P und T als eigene Wellen. Gemessen wird an der P-AMPLITUDE —
 * sie ist kurz, ueberlebt die Grundlinienkorrektur und wird von ekg-analyse.js nach genau
 * derselben Formel in mV umgerechnet wie ST und T.
 *
 * Rueckgabe in Rohwerten, wie ein Geraet sie liefert (skala wird getrennt uebergeben).
 */
function welle(dt, t0, dauer) {
  if (dt < t0 || dt > t0 + dauer) return 0;
  return 0.5 * (1 - Math.cos(2 * Math.PI * (dt - t0) / dauer));
}
function streifen(hz, sek, hf) {
  const n = Math.round(hz * sek), rr = hz * 60 / hf;
  const s = new Array(n).fill(0);
  for (let r = Math.round(rr * 0.6); r < n - Math.round(rr * 0.3); r += Math.round(rr)) {
    for (let i = Math.max(0, r - Math.round(rr * 0.9)); i < Math.min(n, r + Math.round(rr * 0.6)); i++) {
      const dt = (i - r) / hz;
      let v = 0;
      v += 1.6 * welle(dt, -0.025, 0.050);        // QRS (Hauptausschlag)
      v += -0.35 * welle(dt, 0.025, 0.040);       // S
      v += 0.30 * welle(dt, 0.155, 0.090);        // T
      v += 0.25 * welle(dt, -0.025 - 0.100, 0.040); // P, PQ 100 ms
      s[i] += v;
    }
  }
  /* mV -> Rohwerte: 1000 Digits je mV, damit skala 1 uV je Digit stimmt. */
  return s.map(function (v) { return Math.round(v * 1000); });
}

function nachricht(einheitFeld, samples, skala) {
  const zeilen = [
    'MSH|^~\\&|Mindray|Gateway|||||ORU^R01|1|P|2.3.1|',
    'PID|||T-1||Test^||20200101|M|||^^^^|||',
    'OBR||||Mindray Monitor|||20260826120000|',
    'OBX||NA|4182^MDC_ECG_ELEC_POTL_II|1|' + samples.join('^') + '||||||F',
    'OBX||NM|0^MDC_ATTR_SAMP_RATE|1|250||||||F',
    'OBX||NM|0^MDC_ATTR_NU_MSMT_RES|1|' + skala + '|' + einheitFeld + '|||||F',
  ];
  return zeilen.join('\r');
}

console.log('== EKG-Einheitenkette ==\n');

/* ---------------------------------------------------------------------------------------
 * 1  Der Parser nimmt die Einheit mit — und uebersetzt die MDC-Schreibweise.
 * ------------------------------------------------------------------------------------- */
const proben = [
  ['MDC_DIM_MICRO_VOLT', 'uV', 'MDC-Schreibweise Mikrovolt'],
  ['MDC_DIM_MILLI_VOLT', 'mV', 'MDC-Schreibweise Millivolt'],
  ['uV', 'uV', 'Kurzzeichen uV'],
  ['mV', 'mV', 'Kurzzeichen mV'],
];
proben.forEach(function (p) {
  const f = parseHL7Message(nachricht(p[0], streifen(250, 4, 120), 1),
    { deviceId: 't', model: 'Test', species: 'hund' });
  const k = (f.kurvenDaten || [])[0];
  pruefe('Parser: ' + p[2] + ' -> "' + p[1] + '"', !!k && k.einheit === p[1],
    k ? 'bekommen: ' + k.einheit : 'keine Kurve');
});

/* Keine Einheit angegeben -> das Feld bleibt leer, damit die belegte HL7-Vorgabe uV weiter
 * gilt. Das ist bewusst NICHT dasselbe wie "unbekannte Einheit". */
{
  const f = parseHL7Message(nachricht('', streifen(250, 4, 120), 1),
    { deviceId: 't', model: 'Test', species: 'hund' });
  const k = (f.kurvenDaten || [])[0];
  pruefe('Parser: gar keine Einheit -> Feld bleibt leer (Vorgabe uV gilt weiter)',
    !!k && !k.einheit, k ? 'bekommen: ' + k.einheit : 'keine Kurve');
}

/* Angegeben, aber keine Spannung: "wir wissen es nicht" ist nicht "trifft nicht zu".
 * Die Zeichenkette muss durch die Kalibrierpruefung von ekg-analyse.js FALLEN. */
{
  const f = parseHL7Message(nachricht('MDC_DIM_KILO_PASCAL', streifen(250, 4, 120), 1),
    { deviceId: 't', model: 'Test', species: 'hund' });
  const k = (f.kurvenDaten || [])[0];
  pruefe('Parser: unbekannte Einheit wird NICHT zu uV gemacht',
    !!k && !!k.einheit && !/^(uv|µv|mv)$/i.test(k.einheit), k ? 'bekommen: ' + k.einheit : 'keine Kurve');
  pruefe('unbekannte Einheit faellt durch die Kalibrierpruefung von ekg-analyse.js',
    !/uv|µv|mv/i.test(String(k && k.einheit)), String(k && k.einheit));
}

/* ---------------------------------------------------------------------------------------
 * 2  Die Positivliste in model.js reicht sie weiter (sie kuerzt auf 8 Zeichen!).
 * ------------------------------------------------------------------------------------- */
{
  const roh = parseHL7Message(nachricht('MDC_DIM_MILLI_VOLT', streifen(250, 4, 120), 1),
    { deviceId: 't', model: 'Test', species: 'hund' });
  const frame = normalizeFrame(roh).frame;
  const k = (frame.kurvenDaten || [])[0];
  pruefe('model.js: die Einheit ueberlebt die Positivliste',
    !!k && k.einheit === 'mV', k ? 'bekommen: ' + k.einheit : 'keine Kurve');
  pruefe('model.js: die Einheit ueberlebt auch die Kuerzung auf 8 Zeichen',
    !!k && /^(uv|µv|mv)$/i.test(String(k.einheit)), k ? String(k.einheit) : '-');
}

/* ---------------------------------------------------------------------------------------
 * 3  Und jetzt das, worauf es ankommt: die Einheit AENDERT das Ergebnis wirklich.
 *
 * Ohne diese Pruefung koennte die ganze Kette stimmen und trotzdem folgenlos sein. Gemessen
 * wird an derselben Kurve, nur mit anderer Einheit — der Unterschied MUSS Faktor 1000 sein.
 * ------------------------------------------------------------------------------------- */
{
  const kurve = { samples: streifen(250, 6, 120), hz: 250, skala: 1 };
  const aUv = EKG.analysiere(kurve, { einheit: 'uV', bandHr: [1, 999] });
  const aMv = EKG.analysiere(kurve, { einheit: 'mV', bandHr: [1, 999] });
  const aUnbekannt = EKG.analysiere(kurve, { einheit: 'MDC_DIM', bandHr: [1, 999] });

  /* Gemessen wird an der P-Amplitude: sie ueberlebt die Grundlinienkorrektur (Begruendung
   * oben beim Generator) und wird nach genau derselben Formel umgerechnet wie ST und T. */
  const pUv = aUv.p && aUv.p.ampMv, pMv = aMv.p && aMv.p.ampMv;
  pruefe('die Auswertung liefert ueberhaupt eine Amplitude in mV (sonst prueft der Rest nichts)',
    pUv != null && pUv !== 0, 'p=' + JSON.stringify(aUv.p));
  if (pUv) {
    const faktor = pMv / pUv;
    pruefe('uV gegen mV ergibt genau den Faktor 1000 (das ist der ganze Punkt)',
      Math.abs(faktor - 1000) < 1,
      'gemessen: ' + Math.round(faktor) + '   (als uV: ' + pUv + ' mV / als mV: ' + pMv + ' mV)');
  }
  /* Und der Fall, der wirklich schuetzt: unbekannte Einheit -> gar keine mV-Zahl.
   * Bis zum 26.08.2026 konnte er ueberhaupt nicht eintreten, weil beide Bruecken 'uV'
   * erzwangen. */
  pruefe('unbekannte Einheit -> die Auswertung nennt KEINE Millivolt',
    !(aUnbekannt.p && aUnbekannt.p.ampMv != null),
    'p=' + JSON.stringify(aUnbekannt.p));
  pruefe('unbekannte Einheit -> auch die ST-Strecke nennt keine Millivolt, nur die Richtung',
    !!aUnbekannt.st && aUnbekannt.st.messbar !== true,
    'st=' + JSON.stringify(aUnbekannt.st));
}

/* ---------------------------------------------------------------------------------------
 * 4  BEIDE Bauwege ziehen mit. Quelltextpruefung, weil der zweite Weg (registry.js) einen
 *    laufenden Geraetestrom braucht — und weil genau das Auseinanderlaufen der Fehler war.
 * ------------------------------------------------------------------------------------- */
function ohneKommentare(s) { return s.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/(^|[^:])\/\/[^\n]*/g, '$1 '); }
const modelSrc = ohneKommentare(fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'model.js'), 'utf8'));
const regSrc = ohneKommentare(fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'registry.js'), 'utf8'));

pruefe('model.js: keine fest verdrahtete Einheit mehr am Aufruf',
  !/analysiere\([^)]*\{\s*einheit:\s*['"]uV['"]\s*\}/.test(modelSrc));
pruefe('registry.js: keine fest verdrahtete Einheit mehr am Aufruf',
  !/analysiere\([^)]*\{\s*einheit:\s*['"]uV['"]\s*\}/.test(regSrc));
pruefe('model.js: die Einheit kommt vom Kanal',
  /analysiere\(\s*ekgKanal\s*,\s*\{\s*einheit:\s*ekgKanal\.einheit\s*\|\|/.test(modelSrc));
pruefe('registry.js: die Einheit kommt vom Kanal',
  /analysiere\(\s*voll\s*,\s*\{\s*einheit:\s*voll\.einheit\s*\|\|/.test(regSrc));
pruefe('registry.js: der EKG-Puffer fuehrt die Einheit MIT (Positivliste!)',
  /rec\.ekgBuf\s*=\s*\{[^}]*einheit:/.test(regSrc) && /voll\s*=\s*\{[^}]*einheit:/.test(regSrc),
  'ohne sie geht sie im Puffer verloren, obwohl der Aufruf richtig aussieht');

/* ------------------------------------------------------------------------------------- */
console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + '):');
  fehler.forEach(function (f) { console.log('  x ' + f); });
  process.exit(1);
}
console.log('OK — ' + ok + ' Pruefungen. Die Einheit ueberlebt Geraet -> Puffer -> Auswertung.');
