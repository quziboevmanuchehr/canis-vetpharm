'use strict';
/* =============================================================================================
 * kennung-im-log-gegenprobe.js — sieht der Waechter jeden Rueckfall? (25.08.2026)
 * =============================================================================================
 *
 * Die Maskierung der Patientenkennung faellt auf VIER Arten still aus, und keine davon faerbt
 * von sich aus etwas rot: die Datei sieht unveraendert aus, kein Fenster bleibt leer.
 *   1. ein Ausgang maskiert nicht mehr (recent() oder der Sink)
 *   2. jemand schreibt die Kennung wieder in den Meldungstext
 *   3. das Kuerzel wird unsalziert (dann genuegt eine Liste ueblicher Aktennummern)
 *   4. die falsche Zusage kehrt in den Befundbericht zurueck
 *
 * Diese Datei setzt jeden Schaden EINZELN und verlangt, dass tools/kennung-im-log-test.js rot
 * wird. Sie veraendert kurz echte Quelldateien und stellt sie im finally-Zweig wieder her;
 * am Ende wird byteweise nachgerechnet. Laeuft NICHT im Sammellauf, sondern von Hand:
 *     dist/VetStation/node/node.exe tools/kennung-im-log-gegenprobe.js
 *
 * WARUM DAS NOETIG IST: am selben Tag war eine meiner Gegenproben wertlos, weil der Schaden
 * gar nicht ankam — ich pflanzte ein verbotenes Feld in ein Objekt, das eine Positivliste
 * ohnehin verwarf, und las das gruene Ergebnis als Erfolg. Deshalb zaehlt diese hier die
 * Treffer des Suchtextes und meldet ausdruecklich, wenn ein Schaden nicht gesetzt wurde.
 * ============================================================================================= */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const WURZEL = path.join(__dirname, '..');
const NODE = path.join(WURZEL, 'dist', 'VetStation', 'node', 'node.exe');
const TEST = path.join(__dirname, 'kennung-im-log-test.js');

const LOG = path.join(WURZEL, 'bridge', 'src', 'logger.js');
const SRV = path.join(WURZEL, 'bridge', 'src', 'server.js');
const EXP = path.join(__dirname, 'befund-export.js');
const KIOSK = path.join(WURZEL, 'kiosk', 'launch-kiosk.ps1');

const ORIG = {};
[LOG, SRV, EXP, KIOSK].forEach((f) => { ORIG[f] = fs.readFileSync(f, 'utf8'); });
const summe = (s) => crypto.createHash('sha256').update(s).digest('hex').slice(0, 12);
const VORHER = {};
Object.keys(ORIG).forEach((f) => { VORHER[f] = summe(ORIG[f]); });

const SCHAEDEN = [
  [LOG, '  recent(n) { return ring.slice(-(n || 100)).map(hinaus); },',
    '  recent(n) { return ring.slice(-(n || 100)); },',
    'recent() maskiert nicht mehr — /api/diag und der Befundbericht bekommen die Aktennummer'],
  [LOG, 'if (sink) { try { sink(hinaus(ev)); } catch (_) {} }',
    'if (sink) { try { sink(mitKennung(ev, true)); } catch (_) {} }',
    'der WebSocket-Sink reicht die Kennung lesbar an die Oberflaeche'],
  [LOG, "return '#' + crypto.createHash('sha256').update(salz() + '|' + String(id)).digest('hex').slice(0, 6);",
    "return '#' + crypto.createHash('sha256').update(String(id)).digest('hex').slice(0, 6);",
    'das Kuerzel wird unsalziert — durch Durchprobieren zurueckrechenbar'],
  [LOG, "  const kopie = { ts: ev.ts, level: ev.level, source: ev.source, msg: ev.msg + ' — Patient ' + k };",
    "  const kopie = { ts: ev.ts, level: ev.level, source: ev.source, msg: ev.msg + ' — Patient ' + ev.kennung };",
    'mitKennung() haengt ueberall die lesbare Kennung an, auch nach draussen'],
  [SRV, "logger.patient('protokoll', (g.storno ? 'Zurueckgenommen' : 'Gegeben') + ': ' + (g.name || '?')\n            + (g.dosis ? ' (' + g.dosis + ')' : ''), (m.patientId || m.patientKey));",
    "logger.info('protokoll', (g.storno ? 'Zurueckgenommen' : 'Gegeben') + ': ' + (g.name || '?')\n            + (g.dosis ? ' (' + g.dosis + ')' : '') + ' — Patient ' + (m.patientId || m.patientKey));",
    'die Gabe schreibt die Kennung wieder in den Text (der urspruengliche Fehler)'],
  [EXP, "  z('  Patienten-Kennungen erscheinen nur als abgeleitetes Kuerzel (#abc123): derselbe Patient');",
    "  z('  Patienten-Kennungen sind unkenntlich gemacht. Es sind KEINE Vitalwerte enthalten.');",
    'die alte, falsche Zusage kehrt zurueck'],
  [EXP, "  z(''); z('9) SELBSTNEUSTARTS UND UPDATES'); trenner();", "  if (false) {",
    'Abschnitt 9 faellt weg — Abstuerze und gescheiterte Updates sind wieder unsichtbar'],
  [KIOSK, '    if ((Test-Path $f) -and ((Get-Item $f).Length -gt 524288)) {', '    if ($false) {',
    'update.log waechst wieder unbegrenzt'],
];

console.log('Gegenprobe: wird kennung-im-log-test.js bei jedem einzelnen Rueckfall rot?\n');
const laeuft = () => { try { execFileSync(NODE, [TEST], { stdio: 'pipe' }); return true; } catch (_) { return false; } };

let gut = 0, schlecht = 0;
try {
  if (!laeuft()) { console.log('  ABBRUCH: der Waechter ist schon OHNE Schaden rot.'); process.exit(1); }
  console.log('  (unveraendert: gruen — die Ausgangslage stimmt)\n');

  SCHAEDEN.forEach(([datei, suchen, ersetzen, was], i) => {
    const text = ORIG[datei];
    const treffer = text.split(suchen).length - 1;
    const nr = String(i + 1).padStart(2, ' ');
    if (treffer !== 1) {
      schlecht++;
      console.log('  ' + nr + ') ✗ ' + was + '\n         -> die Stelle kommt ' + treffer
        + '-mal vor, erwartet genau 1. Der Schaden waere gar nicht gesetzt worden.');
      return;
    }
    fs.writeFileSync(datei, text.replace(suchen, () => ersetzen), 'utf8');
    const rot = !laeuft();
    fs.writeFileSync(datei, text, 'utf8');
    if (rot) { gut++; console.log('  ' + nr + ') ✓ rot bei: ' + was); }
    else {
      schlecht++;
      console.log('  ' + nr + ') ✗ BLIND: ' + was + '\n         -> ' + path.basename(datei)
        + ', der Waechter blieb gruen.');
    }
  });
} finally {
  Object.keys(ORIG).forEach((f) => { fs.writeFileSync(f, ORIG[f], 'utf8'); });
}

console.log('\n---------------------------------------------');
let heil = true;
Object.keys(ORIG).forEach((f) => {
  if (summe(fs.readFileSync(f, 'utf8')) !== VORHER[f]) { heil = false; console.log('  !! NICHT WIEDERHERGESTELLT: ' + f); }
});
console.log('  Quelldateien unveraendert: ' + (heil ? 'ja' : 'NEIN — von Hand pruefen!'));
console.log('  Schaeden erkannt: ' + gut + ' von ' + SCHAEDEN.length + (schlecht ? '   BLIND: ' + schlecht : ''));
if (schlecht || !heil) process.exit(1);
console.log('  Der Waechter sieht jeden dieser Rueckfaelle.');
