'use strict';
/*
 * erstsuche.js — DIE STATION SUCHT VON SELBST. Ohne Klick, ohne Anleitung, ohne IP-Eintrag.
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 31.07.2026, woertlich): "Das App bei der Installieren und
 * schon starten muss direkt die Andere OP Saal PC und auch die Geraete Monitor, Narkosegeraet etc
 * die direkt bei dem Netz verbunden sind automatisch finden."
 *
 * WAS VORHER WAR — und warum das nicht genuegte:
 * Alle Bausteine dafuer lagen bereits da, aber JEDER brauchte einen Menschen, der etwas anstoesst:
 *   - netscan.scan() findet Geraete zuverlaessig, wurde aber ausschliesslich aus dem Admin-Bereich
 *     gestartet (Admin -> Netzwerk & Geraete -> "Suche starten"). bridge/src/index.js sagt das im
 *     Kopfkommentar ausdruecklich: "Bewusst KEIN voller Netzwerkscan beim Start."
 *   - Der Verbindungs-Assistent (probe) nimmt Geraete entgegen, die VON SICH AUS zum PC senden.
 *     Ein Geraet, das nur LAUSCHT (offener Datenport, wartet auf die Abfrage des PCs), erreicht er
 *     nicht — dafuer braucht es einen Eintrag in bridge/config/devices.json. Die Datei existiert
 *     nach der Installation NICHT (Install-VetStation.ps1 schliesst sie per robocopy /XF aus), und
 *     im ganzen Quellcode gab es keine Stelle, die sie schreibt.
 * Ergebnis in der Praxis: ein frisch installierter zweiter OP-Saal stand da und fand nichts, obwohl
 * Monitor und Narkosegeraet im selben Netz haengen. Das behebt diese Datei.
 *
 * DIE GRENZE, DIE HIER NICHT VERSCHOBEN WIRD: gefunden wird automatisch, GERATEN wird nichts.
 * Ein Geraet, das auf einem Datenport antwortet, aber dort kein HL7 spricht (der Veta 5 Plus sendet
 * auf 4601 Mindray-MD2, siehe docs/VETA5-MITSCHNITT.md), wird nach einer Bewaehrungszeit wieder
 * abgeschaltet und ausdruecklich vermerkt — statt als "Geraet verbunden" ohne Werte stehenzubleiben.
 * Ein geratener Wert am narkotisierten Tier ist der schlimmste Fehler, den dieses Programm machen
 * kann; ein ehrliches "gefunden, spricht aber kein HL7" ist der zweitbeste Zustand nach Erfolg.
 *
 * WAS MIT DEM NACHBAR-SAAL IST — und warum hier kein zweiter Erkennungsweg entsteht:
 * Zwei Praxis-PCs finden einander ueber ihr GEMEINSAMES Praxis-Konto (tafel/<sid> und
 * verbund/lan/<sid> im selben Konto, siehe docs/PLAN-MEHRERE-SAELE.md). Das ist der Hauptweg und
 * braucht ueberhaupt keine Suche. Diese Datei ergaenzt ihn nur um das, was eine Suche beitragen
 * kann: sie SAGT im Klartext, dass auf 192.168.0.x offenbar eine zweite VetStation laeuft, und
 * traegt die Adresse als Kandidaten fuer den LAN-Weg (Port 8771) ein. Sie stellt damit KEIN
 * Vertrauen her — wer ein Nachbarsaal ist, entscheidet allein der signierte Handschlag in
 * bridge/src/nachbar.js. Eine Adresse ist ein Hinweis, kein Ausweis.
 *
 * STRIKT READ-ONLY gegenueber allen Geraeten: es wird geklopft (TCP-Verbindungsversuch) und die
 * ARP-Tabelle des PCs gelesen. An keinem Geraet wird etwas verstellt.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');

const netscan = require('./netscan');
const geraetefund = require('./geraetefund');

/* ------------------------------------------------------------------ *
 * Konstanten. Alle mit Begruendung — eine Zahl ohne Grund wird spaeter
 * von jemandem geaendert, der den Grund nicht kennt.
 * ------------------------------------------------------------------ */

/* Erster Lauf 20 s nach dem Start. Nicht sofort: der Geraeteempfang, die Oberflaeche und die
 * Fern-Anmeldung sollen zuerst stehen. Ein Suchlauf belegt ~250 kurze TCP-Versuche und wuerde
 * sonst mit dem Start konkurrieren. Nicht spaeter: wer eine Station aufstellt, steht davor und
 * wartet auf ein Lebenszeichen. */
const ERSTER_LAUF_MS = 20 * 1000;

/* Abstaende der Wiederholungen, solange NICHTS gefunden wurde. Wachsend, weil eine Praxis ohne
 * Geraete im Netz sonst jahrelang ihr eigenes Subnetz anklopft (derselbe Grund wie Befund B2-10
 * im Plan). Nach dem letzten Wert bleibt es bei 30 min. */
const ABSTAENDE_MS = [2 * 60 * 1000, 10 * 60 * 1000, 30 * 60 * 1000];

const BEWEIS_MS = 90 * 1000;

/* ------------------------------------------------------------------ *
 * DIE DAUERWACHE (02.08.2026) — die Station hoert nie ganz auf zu schauen.
 *
 * WAS VORHER WAR, und warum das im Praxisalltag nicht genuegt:
 * Hier stand  this.fertig = true  mit der Begruendung "ein laufender Betrieb braucht keine Suche".
 * Das stimmt fuer EIN Geraet. Der Nutzer hat am 02.08.2026 den wirklichen Fall beschrieben: das
 * Hausnetz haengt an einem LAN-Verteiler, Geraete kommen zu VERSCHIEDENEN Zeiten dazu (Monitor
 * frueh, Narkosegeraet spaeter, ein Leihgeraet mittags), teils ueber Kabel, teils ueber WLAN — und
 * das Programm soll JEDERZEIT ueberwachen und ein neu angestecktes Geraet SOFORT einbinden.
 * Mit der alten Regel war die Suche nach dem ERSTEN gelieferten Wert dauerhaft beendet: das zweite
 * Geraet wurde bis zum naechsten Neustart der Station nie gefunden. Kein Fehler, keine Meldung —
 * die Station meldete "es kommen Werte an" und schwieg.
 *
 * Die Wache steht auf zwei Beinen, absichtlich verschieden schnell und verschieden teuer:
 *
 *  1. DER SCHNELLE WEG (schnellpruefung, Sekunden): der Verbindungs-Assistent liest ohnehin alle
 *     30 s die ARP-Tabelle des PCs. Taucht dort eine Adresse auf, die vorher nicht da war, wird
 *     GENAU DIESE eine Adresse angeklopft — acht Ports, gleichzeitig, unter einer Sekunde. Das ist
 *     rund das Dreissigfache weniger Aufwand als ein Suchlauf und deshalb auch waehrend einer
 *     laufenden Narkose erlaubt (Begruendung bei schnellpruefung()).
 *
 *  2. DER GRUENDLICHE WEG (WACHE_MS): der volle Suchlauf wiederholt sich weiterhin, nur langsamer.
 *     Er ist noetig, weil Weg 1 eine Adresse nur bemerkt, wenn der PC mit ihr schon einmal geredet
 *     hat oder das Geraet von sich aus etwas schickt — ein stilles Geraet mit unbekanntem
 *     MAC-Praefix steht in keiner ARP-Tabelle. Waehrend einer Narkose bleibt er gesperrt.
 *
 * 15 Minuten sind der Ausgleich zwischen "findet ein neues Geraet ohne dass jemand klickt" und
 * "klopft nicht dauernd am Hausnetz". Zusammen mit Weg 1 liegt die uebliche Wartezeit bei Sekunden;
 * die 15 Minuten sind die Obergrenze fuer den seltenen Fall, dass Weg 1 nichts sieht. */
const WACHE_MS = 15 * 60 * 1000;

/* Wie oft die EIGENEN Netzkarten angesehen werden. Das kostet nichts (os.networkInterfaces() liest
 * aus dem Arbeitsspeicher, kein Netzverkehr), deshalb darf es haeufig sein. Wozu: wenn der PC von
 * Kabel auf WLAN wechselt, ein zweites Kabel dazukommt oder der Router eine neue Adresse vergibt,
 * ist das ganze bisherige Suchergebnis wertlos — die Geraete liegen dann moeglicherweise in einem
 * Netz, in dem noch nie gesucht wurde. Bis hierher rechnete die Station ihre Netzlage EINMAL beim
 * Start aus und nie wieder. */
const NETZWACHE_MS = 20 * 1000;

/* Hoechstens so viele Adressen je Schnellpruefung. Der Deckel ist keine Sparsamkeit, sondern eine
 * Sicherung: ein Netz mit vielen neuen Teilnehmern (Praxis-WLAN am Morgen, wenn alle Handys
 * aufwachen) darf keinen unbegrenzten Klopfsturm ausloesen. Was nicht hineinpasst, findet der
 * gruendliche Weg. */
const SCHNELL_MAX = 6;

/* Wie lange dieselbe Adresse nach einer gezielten Pruefung in Ruhe gelassen wird. Ein Geraet, das
 * sich abwechselnd meldet und wieder aus der ARP-Tabelle faellt (Stromsparen, WLAN-Schlaf), gilt
 * sonst alle 30 s erneut als "neu" und wuerde dauerhaft angeklopft. Zwei Minuten sind kurz genug,
 * dass ein wirklich neu angestecktes Geraet nicht wartet, und lang genug gegen Flattern. */
const SCHNELL_SPERRE_MS = 2 * 60 * 1000;

/* Wie lange eine Adresse nach einer nicht bestandenen Bewaehrung nicht erneut automatisch
 * eingetragen wird. Sieben Tage sind lang genug, dass die Station nicht jede Stunde dasselbe
 * versucht, und kurz genug, dass ein Geraet, das an dem Tag nur aus war, von selbst zurueckkommt.
 * Bis 1.2.3 galt die Sperre unbegrenzt — siehe _merkLesen(). */
const SPERRE_TAGE = 7;

/* Hoechstens so viele Adapter je Lauf neu eintragen. Ein Router-Netz mit vielen Teilnehmern
 * duerfte sonst die Konfiguration fluten. Vier ist eine Praxis mit Monitor, Narkosegeraet,
 * Kapnograph und einem Reservegeraet — mehr haengt an keinem OP-Tisch. */
const NEUE_ADAPTER_MAX = 4;

/* Der Nachbar-Port aus dem Plan (Stufe 2). Er steht hier NUR als Klopfziel und darf NIE in
 * netscan.DATA_PORTS wandern: ein Datenport macht einen Teilnehmer zum "sicheren Geraet", und
 * eine zweite VetStation ist kein Geraet. tools/paket-test.js erzwingt diese Trennung. */
const NACHBAR_PORT = 8771;

/* Der Oberflaechen-Port der Station. Antwortet ein FREMDER PC dort, laeuft dort sehr
 * wahrscheinlich VetStation. "Sehr wahrscheinlich" ist hier ehrlich und ausreichend: der Beweis
 * kommt aus dem signierten Handschlag, nicht aus einem offenen Port. */
const STATION_PORT = 8770;

const KLOPF_MS = 350;

/* ------------------------------------------------------------------ *
 * Reine Funktionen — einzeln pruefbar, ohne Netz, ohne Uhr, ohne Datei.
 * ------------------------------------------------------------------ */

/*
 * darfSuchen(lage) — die einzige Stelle, die "jetzt nicht" sagen darf.
 *
 * WICHTIGSTE REGEL: waehrend an einem Geraet ein Patient haengt (Status 'active') wird NICHT
 * gesucht. Der Suchlauf oeffnet in kurzer Folge hunderte TCP-Verbindungen; auf dem Kiosk-i3
 * konkurriert das mit dem Empfang der Vitalwerte. Eine Narkose hat immer Vorrang vor Bequemlichkeit.
 * Dieselbe Sperre gilt laut Plan-Schritt 3 auch fuer den Suchlauf aus dem Admin-Bereich.
 */
/*
 * WIE LANGE GILT EIN GERAET ALS "AM PATIENTEN"? (korrigiert 01.08.2026)
 *
 * Bis hierher zaehlte darfSuchen() nur Geraete mit status 'active' — und 'active' ist ein Geraet
 * laut registry.js nur 5 SEKUNDEN nach seinem letzten Paket. Ein LifeVet 10C sendet ab Werk aber
 * nur alle ~30 s. Zwischen zwei Paketen galt der laufende Fall damit als "kein Patient da", und
 * der Suchlauf durfte losklopfen — mitten in der Narkose. Die Sperre, die genau das verhindern
 * sollte, war die meiste Zeit offen.
 *
 * Massgeblich ist deshalb nicht der Status, sondern WANN ZULETZT etwas ankam. 3 Minuten decken
 * jeden ueblichen Sendetakt ab (das langsamste bekannte Geraet meldet sich alle 30 s) und sind
 * kurz genug, dass eine beendete Narkose die Suche nicht stundenlang blockiert.
 */
const PATIENT_STILL_MS = 3 * 60 * 1000;

function darfSuchen(lage) {
  const l = lage || {};
  if (l.laeuftSchon) return { ok: false, grund: 'Es laeuft bereits eine Suche.' };
  /* Die neue, belastbare Zahl: Geraete, von denen in den letzten 3 Minuten etwas kam.
   * `aktiveGeraete` bleibt als Rueckfall stehen — ein Aufrufer, der die neue Angabe nicht
   * liefert, soll nicht stillschweigend jede Sperre verlieren. */
  const belegt = Number.isFinite(l.geraeteMitDaten) ? l.geraeteMitDaten : (l.aktiveGeraete || 0);
  if (belegt > 0) {
    return { ok: false, grund: 'An diesem PC haengt gerade ein Patient am Geraet (' + belegt +
      ' Geraet' + (belegt === 1 ? '' : 'e') + ' hat in den letzten ' + Math.round(PATIENT_STILL_MS / 60000) +
      ' Minuten Werte geliefert). Der Suchlauf wartet, bis die Narkose vorbei ist — er wuerde sonst ' +
      'mit dem Empfang der Vitalwerte um dieselbe Netzkarte konkurrieren.' };
  }
  if (!l.echteKarten) {
    return { ok: false, grund: 'Dieser PC hat keine echte Netzwerkkarte (nur virtuell/VPN). ' +
      'Es gibt kein Netz, in dem gesucht werden koennte — LAN-Kabel oder WLAN pruefen.' };
  }
  return { ok: true, grund: null };
}

/*
 * abstandMs(versuche) — wie lange bis zum naechsten Lauf, wenn nichts gefunden wurde.
 * Waechst und bleibt dann stehen. Bewusst kein Zufall: der Abstand soll vorhersagbar sein,
 * damit ein Techniker vor Ort weiss, wann er wieder hinsehen muss.
 */
function abstandMs(versuche) {
  const i = Math.max(0, Number(versuche) || 0);
  return ABSTAENDE_MS[Math.min(i, ABSTAENDE_MS.length - 1)];
}

/* Deckt ein bereits eingeschalteter Adapter diese Adresse und diesen Port schon ab? */
function schonAbgedeckt(ip, port, vorhandene) {
  return (vorhandene || []).some((a) => {
    if (!a || a.enabled === false) return false;
    if (a.type !== 'hl7') return false;
    if (a.mode === 'listener') return false;
    const p = Number(a.port) || 0;
    if (p !== Number(port)) return false;
    /* "auto" folgt dem gefundenen Geraet (geraetefund.js) — es deckt jede Medizinadresse auf
     * diesem Port ab. Genau deshalb ist "auto" in devices.example.json empfohlen. */
    return a.host === 'auto' || a.host === ip;
  });
}

/*
 * adapterVorschlaege(geraete, vorhandene, gesperrt) — was muesste eingetragen werden?
 *
 * ZWEI FAELLE, und die Unterscheidung ist der ganze Witz dieser Funktion:
 *  (a) Das Geraet hat einen OFFENEN Datenport. Dann lauscht es und wartet darauf, dass der PC es
 *      abfragt. Der Verbindungs-Assistent erreicht es NIE (der lauscht selbst). Es braucht einen
 *      Client-Adapter — den tragen wir ein.
 *  (b) Das Geraet hat KEINEN offenen Datenport, ist aber an der MAC als Medizingeraet erkannt
 *      (netscan: 'sendetVermutlich'). Dann sendet es von sich aus zum PC, und der
 *      Verbindungs-Assistent nimmt es bereits entgegen. Ein zusaetzlicher Client-Adapter waere hier
 *      schaedlich: dasselbe physische Geraet erschiene zweimal, mit zwei Geraetesaetzen und zwei
 *      Patientenzeilen. Also NICHTS eintragen und das auch so begruenden.
 */
function adapterVorschlaege(geraete, vorhandene, gesperrt) {
  const aus = [];
  const sperre = gesperrt || {};
  (geraete || []).forEach((g) => {
    if (!g || !g.ip) return;
    const ports = (g.datenPorts || []).filter((p) => netscan.DATA_PORTS.indexOf(p) >= 0);
    if (!ports.length) {
      if (g.sendetVermutlich) {
        aus.push({ ip: g.ip, adapter: null,
          grund: 'sendet von sich aus zum PC — der Verbindungs-Assistent nimmt es bereits entgegen, ' +
                 'ein zweiter Eintrag wuerde dasselbe Geraet doppelt anzeigen' });
      }
      return;
    }
    ports.forEach((port) => {
      const schluessel = g.ip + ':' + port;
      if (sperre[schluessel]) {
        aus.push({ ip: g.ip, port: port, adapter: null,
          grund: 'schon einmal versucht: ' + sperre[schluessel] });
        return;
      }
      if (schonAbgedeckt(g.ip, port, vorhandene)) {
        aus.push({ ip: g.ip, port: port, adapter: null, grund: 'ein eingeschalteter Adapter deckt das bereits ab' });
        return;
      }
      aus.push({
        ip: g.ip, port: port,
        adapter: {
          type: 'hl7',
          id: 'auto-' + g.ip.split('.').join('-') + '-' + port,
          enabled: true,
          mode: 'client',
          host: g.ip,
          port: port,
          model: (g.hersteller ? g.hersteller : 'Geraet') + ' (automatisch gefunden)',
          role: 'combo',
          species: null,
          ack: true,
          /* Mit false eintragen, nicht weglassen (28.08.2026): false ist das heutige Verhalten,
           * aber der Schluessel muss in devices.json SICHTBAR sein. Sonst wirkt der Schalter
           * ausgerechnet bei den Geraeten nicht, die die Station selbst gefunden hat — dort
           * schaut naemlich nie jemand in die Beispieldatei. Erklaerung: devices.example.json. */
          pdsStrict: false,
          _automatisch: 'Von der Station selbst eingetragen (bridge/src/erstsuche.js), weil dieser ' +
            'Teilnehmer auf Datenport ' + port + ' antwortet. Liefert er binnen ' +
            Math.round(BEWEIS_MS / 1000) + ' s kein lesbares HL7, wird der Eintrag wieder ' +
            'abgeschaltet und der Grund vermerkt.',
        },
        grund: 'antwortet auf Datenport ' + port + ' und wird von keinem eingeschalteten Adapter abgefragt',
      });
    });
  });
  /* Deckel NACH der Begruendung: die uebrigen Funde bleiben in der Liste stehen (mit Grund), nur
   * eingetragen werden hoechstens NEUE_ADAPTER_MAX. Stilles Abschneiden waere eine Luege im Log. */
  let gebaut = 0;
  return aus.map((v) => {
    if (!v.adapter) return v;
    if (++gebaut > NEUE_ADAPTER_MAX) {
      return { ip: v.ip, port: v.port, adapter: null,
        grund: 'Deckel erreicht (hoechstens ' + NEUE_ADAPTER_MAX + ' automatische Eintraege je Lauf) — ' +
               'dieser Fund wird beim naechsten Lauf beruecksichtigt' };
    }
    return v;
  });
}

/*
 * stationsVerdacht(hosts, eigeneIps) — welche Teilnehmer sind vermutlich ein ZWEITER Praxis-PC?
 *
 * Zwei unabhaengige Merkmale, beide schon vorhanden:
 *  - netscan.classifyHost setzt zweiteStation:true, wenn ein Teilnehmer auf vier oder mehr
 *    Datenports gleichzeitig antwortet. Genau so verhaelt sich der Verbindungs-Assistent; ein
 *    echter Monitor oeffnet hoechstens einen Port (beobachtet 22.07.2026 an 192.168.0.233).
 *  - der offene Oberflaechen-Port 8770 oder der Nachbar-Port 8771.
 * Die EIGENEN Adressen fliegen raus. Ohne das spricht die Station mit sich selbst und beschriftet
 * es als Nachbarsaal — im Plan der toedliche Befund A2-8, und er ist hier besonders naheliegend,
 * weil docs/LAN-SETUP.md JEDEM Praxis-PC dieselbe 192.168.0.99 vorschreibt.
 */
function stationsVerdacht(hosts, eigeneIps) {
  const eigen = {};
  (eigeneIps || []).forEach((ip) => { eigen[ip] = true; });
  const aus = [];
  (hosts || []).forEach((h) => {
    if (!h || !h.ip || eigen[h.ip] || h.selbst) return;
    const offen = h.offenePorts || [];
    const gruende = [];
    if (h.zweiteStation) gruende.push('antwortet auf mehrere Datenports gleichzeitig — so verhaelt sich der Verbindungs-Assistent von VetStation');
    if (offen.indexOf(STATION_PORT) >= 0) gruende.push('Oberflaechen-Port ' + STATION_PORT + ' offen');
    if (offen.indexOf(NACHBAR_PORT) >= 0) gruende.push('Nachbar-Port ' + NACHBAR_PORT + ' offen');
    if (!gruende.length) return;
    aus.push({
      ip: h.ip,
      nachbarPort: offen.indexOf(NACHBAR_PORT) >= 0,
      gruende: gruende,
      /* Bewusst KEIN Vertrauen, kein Name, keine sid. Wer ein Nachbarsaal ist, entscheidet der
       * signierte Handschlag in nachbar.js — eine Adresse ist ein Hinweis, kein Ausweis. */
      geprueft: false,
    });
  });
  return aus.sort((a, b) => Number(a.ip.split('.')[3]) - Number(b.ip.split('.')[3]));
}

/*
 * zusammenfassung(...) — der EINE Satz, den ein Mensch nach dem Aufstellen lesen will.
 * Er steht im Log und im Admin-Bereich. Er nennt Zahlen, keine Stimmung.
 */
function zusammenfassung(erg) {
  const e = erg || {};
  const g = (e.geraete || []).length;
  const neu = (e.eingetragen || []).length;
  const st = (e.stationen || []).length;
  const teile = [];
  teile.push(g === 0 ? 'kein Medizingeraet gefunden'
    : g + ' Medizingeraet' + (g === 1 ? '' : 'e') + ' gefunden (' + (e.geraete || []).map((x) => x.ip).join(', ') + ')');
  if (neu) teile.push(neu + ' Geraet' + (neu === 1 ? '' : 'e') + ' selbst eingetragen — kein Neustart noetig');
  teile.push(st === 0 ? 'keine zweite VetStation im Netz gesehen'
    : st + ' weitere' + (st === 1 ? 'r' : '') + ' Praxis-PC im Netz (' + (e.stationen || []).map((x) => x.ip).join(', ') + ')');
  return teile.join('; ') + '.';
}

/* ------------------------------------------------------------------ *
 * Der Ablauf.
 * ------------------------------------------------------------------ */

class Erstsuche {
  /*
   * scan()          — liefert das Ergebnis eines Netzwerkdurchlaufs (server.js reicht seinen
   *                   eigenen Suchlauf herein, damit es NIE zwei gleichzeitige Suchen gibt).
   * registry        — nur zum Nachsehen: laufen Adapter, kommen Werte an?
   * adapterStarten  — Rueckruf, der einen frisch eingetragenen Adapter SOFORT in Betrieb nimmt.
   *                   Ohne ihn waere ein Neustart noetig, und genau den soll niemand brauchen.
   */
  constructor(opts) {
    const o = opts || {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    this.registry = o.registry || null;
    this.scan = o.scan || null;
    this.adapterStarten = o.adapterStarten || null;
    this.konfigPfad = o.konfigPfad || path.join(__dirname, '..', 'config', 'devices.json');
    this.beispielPfad = o.beispielPfad || path.join(__dirname, '..', 'config', 'devices.example.json');
    this.merkPfad = o.merkPfad || path.join(__dirname, '..', 'data', 'erstsuche.json');
    this.nachbarnPfad = o.nachbarnPfad || path.join(__dirname, '..', 'data', 'nachbarn.json');
    this.aus = o.enabled === false;
    /* Die eigenen Netzkarten kommen normalerweise vom Betriebssystem. Sie sind hier trotzdem
     * uebergebbar, weil an ihnen die Sperre "die eigene Adresse ist kein Nachbarsaal" haengt —
     * und eine Sperre, die sich nur auf dem Zielrechner pruefen laesst, wird nicht geprueft. */
    this.kartenQuelle = o.kartenQuelle || (() => netscan.localAdapters().filter((k) => !k.virtuell));

    this.laeuft = false;
    this.versuche = 0;
    this.letzte = null;          // Ergebnis des letzten Laufs
    this.letzteTs = 0;
    /* 'fertig' heisst seit der Dauerwache NICHT mehr "nie wieder suchen", sondern nur noch:
     * das erste Ziel ist erreicht, es kommen Werte an, der grosse Suchlauf geht in den ruhigen
     * Takt (WACHE_MS). Gesucht wird weiter — sonst faende die Station ein zweites Geraet, das
     * spaeter angesteckt wird, bis zum naechsten Neustart nie. */
    this.fertig = false;
    this.schnellLaeuft = false;  // eine gezielte Pruefung einzelner Adressen laeuft
    this.schnellFunde = 0;       // wie oft die Wache ein Geraet ohne Suchlauf eingebunden hat
    this.netzWechsel = 0;        // wie oft sich die Netzlage dieses PCs geaendert hat
    this._schnellVermerke = {};  // ip -> zuletzt gezielt geprueft (ms)
    this._netzStand = null;      // Fingerabdruck der eigenen Netzkarten
    this._netzTimer = null;
    this._timer = null;
    this._bewaehrung = [];       // { id, ip, port, bis }
    this._bewaehrungTimer = null;
    this.merk = this._merkLesen();
  }

  /* ---------------- Ablauf ---------------- */

  start() {
    if (this.aus) { this.log.info('erstsuche', 'Automatische Geraetesuche ist abgeschaltet (nachbarn/erstsuche in devices.json).'); return; }
    this._plane(ERSTER_LAUF_MS, 'erster Lauf nach dem Start');
    /* Die Netzwache laeuft ab dem ersten Augenblick, auch waehrend der grosse Suchlauf noch
     * wartet: ein Kabel wird oft genau in den ersten Minuten nach dem Einschalten umgesteckt. */
    this._netzWache();                                   // erster Aufruf setzt nur den Ausgangsstand
    this._netzTimer = setInterval(() => { try { this._netzWache(); } catch (_) {} }, NETZWACHE_MS);
    if (this._netzTimer.unref) this._netzTimer.unref();
  }

  stop() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (this._bewaehrungTimer) { clearInterval(this._bewaehrungTimer); this._bewaehrungTimer = null; }
    if (this._netzTimer) { clearInterval(this._netzTimer); this._netzTimer = null; }
  }

  _plane(ms, warum) {
    if (this._timer) clearTimeout(this._timer);
    this._timer = setTimeout(() => { this._timer = null; this.laufen().catch(() => {}); }, ms);
    if (this._timer.unref) this._timer.unref();
    this.log.info('erstsuche', 'Naechste automatische Suche in ' + Math.round(ms / 1000) + ' s (' + warum + ').');
  }

  lage() {
    const devs = this.registry ? this.registry.getDevices() : [];
    let karten = [];
    try { karten = this.kartenQuelle() || []; } catch (_) {}
    const jetzt = Date.now();
    return {
      laeuftSchon: this.laeuft,
      aktiveGeraete: devs.filter((d) => d.status === 'active').length,
      /* Siehe PATIENT_STILL_MS: der Status allein taugt nicht als Sperre, weil er nach 5 s
       * abfaellt, waehrend ein Monitor nur alle 30 s sendet. */
      geraeteMitDaten: devs.filter((d) => d.lastTs && (jetzt - d.lastTs) < PATIENT_STILL_MS).length,
      echteKarten: karten.length,
      eigeneIps: karten.map((k) => k.address),
    };
  }

  /*
   * laufen() — EIN Durchlauf. Wirft nie: alles, was hier schiefgehen kann, ist Komfort. Der
   * Geraeteempfang und das Narkoseprotokoll duerfen daran nicht haengen.
   */
  async laufen() {
    if (this.aus) return null;
    const lage = this.lage();
    const darf = darfSuchen(lage);
    if (!darf.ok) {
      this.log.info('erstsuche', 'Automatische Suche verschoben: ' + darf.grund);
      this._plane(abstandMs(this.versuche), 'Wiederholung');
      return null;
    }
    if (!this.scan) { this.log.warn('erstsuche', 'Kein Suchlauf hinterlegt — automatische Suche bleibt aus.'); return null; }

    this.laeuft = true;
    this.versuche++;
    let erg = { geraete: [], eingetragen: [], stationen: [], hinweise: [] };
    try {
      this.log.info('erstsuche', 'Automatische Suche laeuft (Lauf ' + this.versuche + '): eigenes Netz nach ' +
        'Medizingeraeten und weiteren Praxis-PCs absuchen. Das dauert etwa eine Minute und stoert nichts.');
      const netzErg = await this.scan();
      erg = await this._auswerten(netzErg, lage);
    } catch (e) {
      this.log.warn('erstsuche', 'Automatische Suche fehlgeschlagen: ' + (e && e.message) +
        '. Der Betrieb laeuft unveraendert weiter; der naechste Versuch kommt von selbst.');
    } finally {
      this.laeuft = false;
    }

    this.letzte = erg;
    this.letzteTs = Date.now();
    this.log.info('erstsuche', 'Automatische Suche fertig: ' + zusammenfassung(erg));
    (erg.hinweise || []).forEach((h) => this.log.info('erstsuche', h));

    /*
     * WIE ES WEITERGEHT. Bis 1.2.3 stand hier "fertig — nie wieder suchen", sobald EIN Geraet
     * Werte lieferte. Damit wurde ein zweites Geraet, das spaeter angesteckt wird, bis zum
     * naechsten Neustart nie gefunden (siehe DIE DAUERWACHE oben). Jetzt hoert die Suche nie ganz
     * auf; sie wird nur langsamer, sobald sie ihr erstes Ziel erreicht hat.
     */
    const werte = this._liefertJemandWerte();
    if (werte) {
      this.fertig = true;
      this._plane(WACHE_MS, 'Dauerwache — es kann jederzeit ein weiteres Geraet dazukommen');
      this.log.info('erstsuche', 'Es kommen Werte an. Die Station sucht ab jetzt in Ruhe weiter (alle '
        + Math.round(WACHE_MS / 60000) + ' min, und sofort, sobald ein neues Geraet im Netz auftaucht) — '
        + 'damit ein spaeter angestecktes zweites Geraet nicht bis zum naechsten Neustart wartet.');
    } else {
      this._plane(abstandMs(this.versuche), 'noch kein Geraet liefert Werte');
    }
    return erg;
  }

  _liefertJemandWerte() {
    if (!this.registry) return false;
    return this.registry.getDevices().some((d) => d.status === 'active' || d.status === 'connected');
  }

  /*
   * schnellpruefung(kandidaten, warum) — DER SCHNELLE WEG DER DAUERWACHE.
   *
   * Aufgerufen vom Verbindungs-Assistenten, sobald in der ARP-Tabelle eine Adresse auftaucht, die
   * vorher nicht da war (probe.js, alle 30 s). Es wird GENAU DIESE Adresse angeklopft, nicht das
   * Netz: die Datenports aus dem Gerätekatalog, alle gleichzeitig, mit derselben kurzen Frist wie
   * im grossen Suchlauf. Bei acht Ports und sechs Adressen sind das hoechstens 48 kurze
   * TCP-Versuche — ein voller Suchlauf oeffnet rund 250 und dauert eine Minute.
   *
   * WARUM DIESER WEG AUCH WAEHREND EINER NARKOSE ERLAUBT IST — und der grosse Suchlauf nicht:
   * Die Sperre in darfSuchen() gibt es, weil ein Suchlauf auf dem Kiosk-i3 mit dem Empfang der
   * Vitalwerte um dieselbe Netzkarte konkurriert. Diese Begruendung traegt hier nicht: 48 kurze
   * Verbindungsversuche ueber eine Sekunde sind gegen einen laufenden HL7-Strom nicht messbar.
   * Dagegen steht ein handfester klinischer Nutzen: der haeufigste Fall im OP ist, dass der
   * Monitor schon haengt und das NARKOSEGERAET spaeter dazukommt — also genau waehrend der
   * Narkose. Ein Weg, der ausgerechnet dann schweigt, wuerde den Zweck verfehlen.
   * Was hier NICHT passiert: es wird nichts an einem Geraet verstellt und nichts geraten. Ein
   * Teilnehmer, der antwortet, aber kein HL7 spricht, faellt durch dieselbe Bewaehrung wie sonst.
   *
   * Wirft nie und gibt zurueck, was getan wurde — ein stiller Rueckweg waere hier besonders
   * schaedlich, weil niemand sonst je nachsieht.
   */
  async schnellpruefung(kandidaten, warum) {
    if (this.aus) return { geprueft: [], eingetragen: [], grund: 'automatische Suche ist abgeschaltet' };
    if (!Array.isArray(kandidaten) || !kandidaten.length) return { geprueft: [], eingetragen: [], grund: 'keine Adresse' };
    /* Laeuft gerade der grosse Suchlauf, ist die Adresse in einer Minute ohnehin dabei — dann
     * hier nichts tun, statt dieselben Ports doppelt anzuklopfen. */
    if (this.laeuft) return { geprueft: [], eingetragen: [], grund: 'der grosse Suchlauf laeuft gerade' };
    if (this.schnellLaeuft) return { geprueft: [], eingetragen: [], grund: 'eine Schnellpruefung laeuft bereits' };

    const liste = kandidaten
      .filter((k) => k && k.ip && !this._schnellGeprueft(k.ip))
      .slice(0, SCHNELL_MAX);
    if (!liste.length) return { geprueft: [], eingetragen: [], grund: 'alle Adressen kuerzlich schon geprueft' };

    this.schnellLaeuft = true;
    const geraete = [];
    try {
      for (const k of liste) {
        this._schnellVermerken(k.ip);
        /* Alle Ports GLEICHZEITIG: nacheinander waeren es bei acht geschlossenen Ports acht mal
         * die Frist, also fast drei Sekunden je Adresse — und die Wartezeit ist genau das, was
         * hier klein bleiben soll. */
        const offen = [];
        await Promise.all(netscan.DATA_PORTS.map((p) => netscan.knock(k.ip, p, KLOPF_MS)
          .then((a) => { if (a && a.offen) offen.push(p); })
          .catch(() => {})));
        if (!offen.length) continue;
        offen.sort((a, b) => netscan.DATA_PORTS.indexOf(a) - netscan.DATA_PORTS.indexOf(b));
        geraete.push({
          ip: k.ip, mac: k.mac || null,
          hersteller: k.hersteller || (k.mac ? netscan.istMedizinMac(k.mac) ? 'Medizingeraet' : null : null),
          datenPorts: offen, stufe: 'sicher',
        });
      }
    } catch (e) {
      this.log.warn('erstsuche', 'Schnellpruefung fehlgeschlagen: ' + (e && e.message)
        + '. Der gruendliche Suchlauf holt es nach.');
    } finally {
      this.schnellLaeuft = false;
    }

    if (!geraete.length) {
      this.log.info('erstsuche', 'Neu im Netz: ' + liste.map((k) => k.ip).join(', ')
        + ' — dort ist kein Datenport offen. Das ist normal, wenn das Geraet von sich aus sendet: '
        + 'dann nimmt der Verbindungs-Assistent es entgegen, sobald am Geraet die PC-Adresse eingetragen ist.');
      return { geprueft: liste.map((k) => k.ip), eingetragen: [], grund: null };
    }

    this.log.info('erstsuche', 'Neues Geraet im Netz erkannt (' + (warum || 'Netzwache') + '): '
      + geraete.map((g) => g.ip + ' auf Port ' + g.datenPorts.join('/')).join(', ')
      + ' — wird sofort eingebunden, ohne Neustart und ohne Suchlauf.');

    let erg = { eingetragen: [], hinweise: [] };
    try { erg = await this._auswerten({ hosts: [], geraete: geraete }, this.lage()); }
    catch (e) { this.log.warn('erstsuche', 'Einbinden fehlgeschlagen: ' + (e && e.message)); }
    (erg.hinweise || []).forEach((h) => this.log.info('erstsuche', h));

    /* Der Fund gehoert auch in den Statusbericht — sonst steht im Reiter "Geraete" weiterhin das
     * Ergebnis des letzten grossen Suchlaufs, und der kennt dieses Geraet nicht. */
    this.letzte = this.letzte || { geraete: [], eingetragen: [], stationen: [], hinweise: [] };
    this.letzte.geraete = (this.letzte.geraete || [])
      .filter((g) => !geraete.some((n) => n.ip === g.ip))
      .concat(geraete.map((g) => ({ ip: g.ip, mac: g.mac, hersteller: g.hersteller, datenPorts: g.datenPorts })));
    this.letzte.eingetragen = (this.letzte.eingetragen || []).concat(erg.eingetragen || []);
    this.letzteTs = Date.now();
    this.schnellFunde++;
    return { geprueft: liste.map((k) => k.ip), eingetragen: erg.eingetragen || [], grund: null };
  }

  /* Dieselbe Adresse nicht alle 30 s erneut anklopfen. Der Verbindungs-Assistent meldet eine
   * Adresse als "neu", solange sie in der vorigen ARP-Runde fehlte — bei einem Geraet, das sich
   * abwechselnd meldet und wieder verschwindet, waere das sonst ein Dauerklopfen. */
  _schnellGeprueft(ip) {
    const bis = this._schnellVermerke[ip];
    return typeof bis === 'number' && (Date.now() - bis) < SCHNELL_SPERRE_MS;
  }

  _schnellVermerken(ip) {
    this._schnellVermerke[ip] = Date.now();
    /* Nicht unbegrenzt wachsen lassen: in einem Praxis-WLAN kommen im Lauf eines Tages leicht
     * hundert Adressen vorbei. Alles, was aelter als die Sperre ist, wird beim Eintragen entfernt. */
    const grenze = Date.now() - SCHNELL_SPERRE_MS;
    Object.keys(this._schnellVermerke).forEach((k) => {
      if (this._schnellVermerke[k] < grenze) delete this._schnellVermerke[k];
    });
  }

  /*
   * _netzWache() — merkt, wenn sich das NETZ DES PCs aendert.
   *
   * WOFUER (Wunsch 02.08.2026: "wenn das LAN-Kabel am Hausnetz durch WLAN oder LAN-Kabel oder
   * Internet verbunden ist, schnell in das App verbinden"): bis hierher rechnete die Station ihre
   * Netzlage einmal beim Start aus. Wer danach das Kabel umsteckt, auf WLAN wechselt oder eine
   * neue Adresse vom Router bekommt, hatte eine Station, die weiterhin im ALTEN Netz suchte — und
   * das gibt es nicht mehr. Ein Netzwechsel macht jedes bisherige Suchergebnis wertlos, deshalb
   * ist er der einzige Anlass, der einen vollen Suchlauf ausser der Reihe rechtfertigt.
   *
   * Kostet nichts: os.networkInterfaces() liest aus dem Arbeitsspeicher, es geht kein Paket ins
   * Netz. Deshalb alle 20 s statt alle 15 min.
   */
  _netzWache() {
    let jetzt = '';
    try {
      jetzt = (this.kartenQuelle() || []).map((k) => k.address + '/' + (k.netmask || ''))
        .sort().join(' ');
    } catch (_) { return; }
    if (jetzt === this._netzStand) return;
    const vorher = this._netzStand;
    this._netzStand = jetzt;
    if (vorher === null) return;               // erster Durchlauf: nur merken, nicht melden
    this.netzWechsel++;
    this.log.info('erstsuche', 'Die Netzlage dieses PCs hat sich geaendert (vorher: '
      + (vorher || 'keine Adresse') + ', jetzt: ' + (jetzt || 'keine Adresse')
      + '). Damit koennen die Geraete in einem anderen Netz liegen als bisher — die Station sucht '
      + 'deshalb sofort neu.');
    /* Das Fundgedaechtnis gilt fuer das alte Netz. Es NICHT zu leeren waere der Fehler, den
     * geraetefund.js am 01.08.2026 schon einmal hatte: hartnaeckig die alte Adresse zurueckgeben. */
    try { geraetefund.aufraeumen(); } catch (_) {}
    this.versuche = 0;                          // wieder von vorn: es ist ein neues Netz
    this.fertig = false;
    this._plane(3000, 'die Netzlage hat sich geaendert');
  }

  async _auswerten(netzErg, lage) {
    const hosts = (netzErg && netzErg.hosts) || [];
    const geraete = (netzErg && netzErg.geraete) || hosts.filter((h) => h.stufe === 'sicher');
    const hinweise = [];

    /* 1) Jeder Fund geht in das gemeinsame Gedaechtnis. Damit folgt JEDER Adapter mit
     *    "host": "auto" sofort der tatsaechlichen Adresse — auch ohne neuen Eintrag. */
    try { geraetefund.merke(geraete.map((g) => ({ ip: g.ip, mac: g.mac })), 'erstsuche'); } catch (_) {}

    /* 2) Adapter eintragen, wo einer fehlt. */
    const cfg = this._konfigLesen();
    const vorschlaege = adapterVorschlaege(geraete, (cfg && cfg.adapters) || [], this.merk.gesperrt || {});
    const eingetragen = [];
    vorschlaege.forEach((v) => {
      if (!v.adapter) { hinweise.push(v.ip + (v.port ? ':' + v.port : '') + ' — ' + v.grund); return; }
      if ((cfg.adapters || []).some((a) => a && a.id === v.adapter.id)) return;
      cfg.adapters = cfg.adapters || [];
      cfg.adapters.push(v.adapter);
      eingetragen.push(v.adapter);
      hinweise.push('Neu eingetragen: ' + v.adapter.id + ' -> ' + v.adapter.host + ':' + v.adapter.port +
        ' (' + v.grund + ').');
    });
    if (eingetragen.length) {
      if (this._konfigSchreiben(cfg)) {
        eingetragen.forEach((a) => this._sofortStarten(a));
      } else {
        hinweise.push('Die gefundenen Geraete konnten NICHT in bridge/config/devices.json geschrieben ' +
          'werden (Schreibrecht?). Sie laufen bis zum naechsten Neustart trotzdem.');
        eingetragen.forEach((a) => this._sofortStarten(a));
      }
    }

    /* 3) Weitere Praxis-PCs. Nur melden und vormerken — Vertrauen entsteht im Handschlag. */
    const verdacht = stationsVerdacht(hosts, lage.eigeneIps);
    const bestaetigt = await this._klopfeStationen(verdacht);
    if (bestaetigt.length) {
      bestaetigt.forEach((s) => {
        hinweise.push('Auf ' + s.ip + ' laeuft sehr wahrscheinlich eine zweite VetStation (' +
          s.gruende.join('; ') + '). Beide Saele sehen einander, sobald BEIDE mit DEMSELBEN ' +
          'Praxis-Konto angemeldet sind (Admin -> Fern-Live). Die Adresse ist als Nachbar-Kandidat ' +
          'vermerkt; wer wirklich dort sitzt, weist erst der signierte Handschlag nach.');
      });
      this._nachbarKandidaten(bestaetigt);
    }

    return { geraete: geraete.map((g) => ({ ip: g.ip, mac: g.mac, hersteller: g.hersteller, datenPorts: g.datenPorts || [] })),
      eingetragen: eingetragen, stationen: bestaetigt, hinweise: hinweise };
  }

  /*
   * Klopft gezielt an 8770 und 8771 der verdaechtigen Adressen. Der grosse Suchlauf kennt diese
   * Ports nicht und darf sie auch nicht kennen (sonst wuerde ein Praxis-PC als "sicheres Geraet"
   * eingestuft). Hier sind es hoechstens eine Handvoll Adressen — das kostet unter einer Sekunde.
   */
  async _klopfeStationen(verdacht) {
    const aus = [];
    for (const v of (verdacht || []).slice(0, 8)) {
      let trifft = v.gruende.slice();
      let nachbarPort = v.nachbarPort;
      try {
        const a = await netscan.knock(v.ip, STATION_PORT, KLOPF_MS);
        if (a && a.offen && trifft.indexOf('Oberflaechen-Port ' + STATION_PORT + ' offen') < 0) {
          trifft.push('Oberflaechen-Port ' + STATION_PORT + ' offen');
        }
        const b = await netscan.knock(v.ip, NACHBAR_PORT, KLOPF_MS);
        if (b && b.offen) { nachbarPort = true; if (trifft.indexOf('Nachbar-Port ' + NACHBAR_PORT + ' offen') < 0) trifft.push('Nachbar-Port ' + NACHBAR_PORT + ' offen'); }
      } catch (_) { /* Klopfen darf scheitern; der Verdacht bleibt dann beim Ausgangsbefund. */ }
      aus.push({ ip: v.ip, nachbarPort: nachbarPort, gruende: trifft, geprueft: true });
    }
    return aus;
  }

  /* ---------------- Dateien ---------------- */

  _konfigLesen() {
    /* Es gibt sie nach einer Installation NICHT. Dann wird sie aus dem Beispiel aufgebaut — mit
     * allen Hinweistexten, damit die Datei fuer einen Menschen lesbar bleibt. */
    for (const p of [this.konfigPfad, this.beispielPfad]) {
      try {
        const j = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (j && typeof j === 'object') { j.adapters = j.adapters || []; return j; }
      } catch (_) {}
    }
    return { port: 8770, host: '127.0.0.1', adapters: [] };
  }

  _konfigSchreiben(cfg) {
    try {
      fs.mkdirSync(path.dirname(this.konfigPfad), { recursive: true });
      /* Erst daneben schreiben, dann umbenennen: ein abgebrochener Schreibvorgang darf keine halbe
       * devices.json hinterlassen — die Station startet danach im Simulator-Rueckfall. */
      const tmp = this.konfigPfad + '.neu';
      fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2), 'utf8');
      fs.renameSync(tmp, this.konfigPfad);
      this.log.info('erstsuche', 'bridge/config/devices.json ergaenzt (die gefundenen Geraete stehen jetzt fest darin).');
      return true;
    } catch (e) {
      this.log.warn('erstsuche', 'devices.json nicht schreibbar: ' + (e && e.message));
      return false;
    }
  }

  /*
   * _merkLesen() — die Sperrliste, UND SIE ALTERT (02.08.2026).
   *
   * Bis 1.2.3 wurde sie nur gelesen und ergaenzt, nie geleert. Eine einmal gesperrte Adresse war
   * damit fuer immer gesperrt — auch nach jedem Neustart, denn die Liste liegt in einer Datei.
   * Ein Geraet, das beim allerersten Versuch zufaellig gerade aus war, kam nie wieder in die
   * Station. Das ist der schlechteste Ausgang, den eine "Sicherung" haben kann: sie schuetzt
   * gegen einen kleinen Fehler (ein Eintrag ohne Werte) mit einem grossen (ein Geraet fehlt).
   */
  _merkLesen() {
    try {
      const j = JSON.parse(fs.readFileSync(this.merkPfad, 'utf8'));
      const roh = j.gesperrt || {};
      const gesperrt = {};
      let abgelaufen = 0;
      const grenze = Date.now() - SPERRE_TAGE * 24 * 3600 * 1000;
      Object.keys(roh).forEach((k) => {
        /* Der Grund traegt das Datum im Klartext: "… (2026-08-01, gilt bis 2026-08-08)".
         * Ein Eintrag ohne lesbares Datum stammt aus einer aelteren Fassung — der faellt beim
         * ersten Start unter der neuen Regel heraus, und das ist richtig so. */
        const m = /\((\d{4}-\d{2}-\d{2})/.exec(String(roh[k]));
        const ts = m ? Date.parse(m[1]) : NaN;
        if (Number.isFinite(ts) && ts >= grenze) gesperrt[k] = roh[k];
        else abgelaufen++;
      });
      if (abgelaufen) this._abgelaufeneSperren = abgelaufen;
      return { gesperrt: gesperrt };
    } catch (_) { return { gesperrt: {} }; }
  }

  _merkSchreiben() {
    try {
      fs.mkdirSync(path.dirname(this.merkPfad), { recursive: true });
      fs.writeFileSync(this.merkPfad, JSON.stringify(this.merk, null, 2), 'utf8');
    } catch (_) {}
  }

  /*
   * Nachbar-Kandidaten anmerken. bridge/data/nachbarn.json gehoert bridge/src/nachbar.js —
   * hier wird ausschliesslich das Feld 'kandidaten' beschrieben und alles andere (insbesondere
   * gepinnte oeffentliche Schluessel) unangetastet uebernommen. Ein Suchlauf darf niemals einen
   * Schluessel setzen oder aendern.
   */
  _nachbarKandidaten(stationen) {
    let j = {};
    try { j = JSON.parse(fs.readFileSync(this.nachbarnPfad, 'utf8')) || {}; } catch (_) { j = {}; }
    const alt = Array.isArray(j.kandidaten) ? j.kandidaten : [];
    const nachIp = {};
    alt.forEach((k) => { if (k && k.ip) nachIp[k.ip] = k; });
    stationen.forEach((s) => {
      nachIp[s.ip] = { ip: s.ip, port: NACHBAR_PORT, gesehen: Date.now(), gruende: s.gruende, quelle: 'erstsuche' };
    });
    j.kandidaten = Object.keys(nachIp).map((ip) => nachIp[ip]).slice(0, 16);
    try {
      fs.mkdirSync(path.dirname(this.nachbarnPfad), { recursive: true });
      fs.writeFileSync(this.nachbarnPfad, JSON.stringify(j, null, 2), 'utf8');
    } catch (e) {
      this.log.warn('erstsuche', 'Nachbar-Kandidaten nicht speicherbar: ' + (e && e.message));
    }
  }

  /* ---------------- Adapter sofort in Betrieb nehmen ---------------- */

  /*
   * WARUM SOFORT UND NICHT BEIM NAECHSTEN START: wer eine Station aufstellt, steht davor. Ein
   * "bitte neu starten" ist an dieser Stelle die eine Sache, die den Eindruck 'es findet sich
   * selbst' zerstoert. Und ein Neustart mitten in einer Narkose ist ohnehin keine Option.
   */
  _sofortStarten(a) {
    if (!this.adapterStarten) return;
    let ok = false;
    try { ok = this.adapterStarten(a) !== false; }
    catch (e) { this.log.warn('erstsuche', 'Adapter ' + a.id + ' liess sich nicht starten: ' + (e && e.message)); }
    if (!ok) return;
    this.log.info('erstsuche', 'Adapter ' + a.id + ' laeuft jetzt (' + a.host + ':' + a.port + ').');
    this._bewaehrung.push({ id: a.id, ip: a.host, port: a.port, bis: Date.now() + BEWEIS_MS });
    if (!this._bewaehrungTimer) {
      this._bewaehrungTimer = setInterval(() => this._bewaehrungPruefen(), 10 * 1000);
      if (this._bewaehrungTimer.unref) this._bewaehrungTimer.unref();
    }
  }

  /*
   * DIE BEWAEHRUNGSPROBE — der Grund, warum diese Automatik nicht gefaehrlich ist.
   *
   * Ein offener Port beweist nur, dass dort JEMAND antwortet, nicht dass er HL7 spricht. Der
   * Veta 5 Plus antwortet auf 4601 und sendet dort Mindray-MD2 (Binaerprotokoll, siehe
   * docs/VETA5-MITSCHNITT.md). Ein Adapter, der daran haengt, wuerde als Geraet in der Liste
   * stehen und nie einen Wert liefern — ein stiller Zustand, und stille Zustaende sind in diesem
   * Programm das eigentliche Uebel. Deshalb: liefert ein selbst eingetragener Adapter binnen
   * 90 s nichts Lesbares, wird er wieder abgeschaltet, der Grund vermerkt und die Adresse fuer
   * kuenftige Laeufe gesperrt.
   */
  _bewaehrungPruefen() {
    if (!this._bewaehrung.length) {
      if (this._bewaehrungTimer) { clearInterval(this._bewaehrungTimer); this._bewaehrungTimer = null; }
      return;
    }
    const jetzt = Date.now();
    const devs = this.registry ? this.registry.getDevices() : [];
    const bleibt = [];
    this._bewaehrung.forEach((b) => {
      if (jetzt < b.bis) { bleibt.push(b); return; }
      const d = devs.filter((x) => x.deviceId === b.id)[0];
      const liefert = !!(d && d.status !== 'offline' && d.status !== 'error' && d.lastTs);
      if (liefert) {
        this.log.info('erstsuche', 'Bewaehrung bestanden: ' + b.id + ' liefert Werte.');
        return;
      }
      /*
       * ZWEI VERSCHIEDENE FAELLE, DIE BIS 1.2.3 DENSELBEN AUSGANG HATTEN (Befund 02.08.2026):
       *
       *   (a) Der Adapter WAR verbunden und hat Bytes bekommen, die kein HL7 waren.
       *       Das ist der Fall, fuer den die Bewaehrung gebaut wurde (der Veta 5 sendet auf 4601
       *       Mindray-MD2). Hier ist die Sperre richtig.
       *   (b) Es ist ueberhaupt nichts angekommen — es gibt gar keinen Registry-Eintrag.
       *       Dann steht nicht fest, dass das Geraet kein HL7 spricht. Es kann schlicht laenger
       *       gebraucht haben: ein Geraeteneustart, der wachsende Wiederholabstand des
       *       HL7-Clients (3/6/12/24/48/60 s), oder ein Monitor, der erst mit angelegtem Sensor
       *       sendet. Bis hierher wurde in diesem Fall dieselbe dauerhafte Sperre gesetzt — und
       *       die Sperrliste liegt in einer Datei, wird beim Start wieder eingelesen und an
       *       KEINER Stelle des Projekts je geleert oder gealtert. Ein voellig intaktes Geraet
       *       war damit fuer immer ausgesperrt, mit der zusaetzlich FALSCHEN Begruendung
       *       "antwortet zwar, liefert aber kein lesbares HL7".
       *
       * Fall (b) bekommt deshalb genau EINE Verlaengerung; erst wenn auch die verstreicht, wird
       * gesperrt — und dann mit dem richtigen Grund. Und jede Sperre bekommt ein Ablaufdatum:
       * ein einmaliger Fehlschlag darf ein Geraet nicht auf Lebenszeit ausschliessen.
       */
      const hatteVerbindung = !!d;
      if (!hatteVerbindung && !b.verlaengert) {
        b.verlaengert = true;
        b.bis = jetzt + BEWEIS_MS;
        bleibt.push(b);
        this.log.info('erstsuche', b.ip + ':' + b.port + ' hat sich in ' + Math.round(BEWEIS_MS / 1000) +
          ' s noch gar nicht gemeldet. Das heisst NICHT, dass dort kein HL7 spricht — ein Geraet ' +
          'kann laenger brauchen (Neustart, wachsender Wiederholabstand, Sensor noch nicht angelegt). ' +
          'Die Bewaehrung wird deshalb einmal um weitere ' + Math.round(BEWEIS_MS / 1000) + ' s verlaengert.');
        return;
      }
      const grund = hatteVerbindung
        ? 'antwortet, spricht aber kein HL7'
        : 'hat sich in ' + Math.round(2 * BEWEIS_MS / 1000) + ' s ueberhaupt nicht gemeldet';
      this.log.warn('erstsuche', b.ip + ':' + b.port + ' — ' + grund + '. ' +
        (hatteVerbindung
          ? 'Sehr wahrscheinlich spricht das Geraet dort ein anderes (herstellereigenes) Protokoll — der ' +
            'Veta 5 Plus tut das auf 4601. '
          : 'Moeglicherweise war es nur ausgeschaltet. ') +
        'Der automatische Eintrag ' + b.id + ' wird deshalb wieder abgeschaltet, damit kein Geraet ' +
        'ohne Werte in der Liste stehen bleibt. Die Adresse wird ' + Math.round(SPERRE_TAGE) +
        ' Tage lang nicht erneut automatisch eingetragen; danach versucht es die Station von selbst ' +
        'wieder. Von Hand einschalten geht jederzeit in bridge/config/devices.json.');
      this.merk.gesperrt[b.ip + ':' + b.port] = grund + ' (' + new Date(jetzt).toISOString().slice(0, 10) +
        ', gilt bis ' + new Date(jetzt + SPERRE_TAGE * 24 * 3600 * 1000).toISOString().slice(0, 10) + ')';
      this._merkSchreiben();
      this._adapterAbschalten(b.id);
    });
    this._bewaehrung = bleibt;
  }

  _adapterAbschalten(id) {
    const cfg = this._konfigLesen();
    (cfg.adapters || []).forEach((a) => { if (a && a.id === id) a.enabled = false; });
    this._konfigSchreiben(cfg);
    /*
     * DIE TOTE INSTANZ MUSS AUS registry.adapters RAUS (Befund C, 28.08.2026).
     *
     * Gemessen: dispose() beendete den Adapter, die Instanz blieb in der Liste stehen — und
     * index.js:adapterStarten() steigt bei einer bereits vorhandenen Instanz mit "laeuft
     * schon" aus und meldet TRUE zurueck. Ein hier abgeschaltetes Geraet kam damit nie
     * wieder, auch nicht, wenn die Suche es spaeter erneut fand und eintrug: die Station
     * meldete den Erfolg und blieb stumm. Genau darum geht es an dieser Stelle aber — die
     * Adresse wird nur zeitweise gesperrt (SPERRE_TAGE), danach soll es die Station "von
     * selbst wieder" versuchen.
     */
    const laufende = (this.registry && this.registry.adapters) || [];
    for (let i = laufende.length - 1; i >= 0; i--) {          // rueckwaerts: splice waehrend der Schleife
      const a = laufende[i];
      if (!a || a.id !== id) continue;
      if (typeof a.dispose === 'function') { try { a.dispose(); } catch (_) {} }
      laufende.splice(i, 1);
    }
  }

  /* ---------------- Auskunft ---------------- */

  status() {
    return {
      aus: this.aus,
      laeuft: this.laeuft,
      versuche: this.versuche,
      fertig: this.fertig,
      letzteTs: this.letzteTs || null,
      zusammenfassung: this.letzte ? zusammenfassung(this.letzte) : null,
      geraete: this.letzte ? this.letzte.geraete : [],
      stationen: this.letzte ? this.letzte.stationen : [],
      eingetragen: this.letzte ? (this.letzte.eingetragen || []).map((a) => a.id) : [],
      hinweise: this.letzte ? this.letzte.hinweise : [],
      gesperrt: this.merk.gesperrt,
      bewaehrung: this._bewaehrung.map((b) => ({ id: b.id, nochMs: Math.max(0, b.bis - Date.now()) })),
      /* Die Dauerwache gehoert sichtbar in den Reiter "Geraete". Was eine Station im Stillen tut,
       * glaubt ihr sonst niemand — und wer nicht weiss, dass weiter gesucht wird, steckt ein
       * Geraet an und startet vorsichtshalber neu. */
      wache: {
        aktiv: !this.aus,
        taktMs: this.fertig ? WACHE_MS : abstandMs(this.versuche),
        schnellLaeuft: this.schnellLaeuft,
        schnellFunde: this.schnellFunde,
        netzWechsel: this.netzWechsel,
        netzStand: this._netzStand,
      },
    };
  }
}

module.exports = {
  Erstsuche,
  darfSuchen, abstandMs, schonAbgedeckt, adapterVorschlaege, stationsVerdacht, zusammenfassung,
  ERSTER_LAUF_MS, ABSTAENDE_MS, BEWEIS_MS, NEUE_ADAPTER_MAX, NACHBAR_PORT, STATION_PORT, PATIENT_STILL_MS,
  WACHE_MS, NETZWACHE_MS, SCHNELL_MAX, SCHNELL_SPERRE_MS,
};
