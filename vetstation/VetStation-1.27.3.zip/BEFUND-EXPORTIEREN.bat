@echo off
title VetStation - Befund exportieren
REM Schreibt eine Textdatei mit Version, IP, Firewall, Geraetesuche, Empfang und Urteil.
REM Diese Datei kann man weitergeben oder an anderer Stelle auswerten lassen.
REM Patienten-Kennungen werden dabei unkenntlich gemacht, Vitalwerte sind NICHT enthalten.
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\befund-export.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\befund-export.js" %*
:ende
echo.
pause
