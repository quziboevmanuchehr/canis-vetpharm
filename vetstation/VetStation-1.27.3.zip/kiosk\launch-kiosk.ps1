<#
  launch-kiosk.ps1 - Startet VetStation als Appliance (wie ein IDEXX-Geraet):
  1) Bridge+UI (Node) starten (falls nicht laeuft) und auf Bereitschaft warten,
  2) Microsoft Edge (WebView2/Evergreen) im Vollbild-Kiosk auf die lokale UI oeffnen.

  Kein Rust/Tauri noetig - nutzt die bereits installierte Edge/WebView2-Runtime.
  Read-only: startet nur lokale Prozesse, sendet nie an Geraete.

  Aufruf:  powershell -ExecutionPolicy Bypass -File kiosk\launch-kiosk.ps1
  Optional: -Port 8770  -NoKiosk (nur Bridge)  -Watchdog (Selbstheilung)
#>
param(
  [int]$Port = 8770,
  [switch]$NoKiosk,
  [switch]$Watchdog
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path $PSScriptRoot -Parent
$Url  = "http://127.0.0.1:$Port"

function Find-Node {
  # 1) Mitgeliefertes portables Node (Installer-Bundle) hat Vorrang -> nichts extra installieren.
  foreach ($p in @("$Root\node\node.exe", "$PSScriptRoot\..\node\node.exe")) { if (Test-Path $p) { return (Resolve-Path $p).Path } }
  # 2) System-Node
  $n = (Get-Command node -ErrorAction SilentlyContinue)
  if ($n) { return $n.Source }
  foreach ($p in @("$env:ProgramFiles\nodejs\node.exe", "$env:LOCALAPPDATA\Programs\nodejs\node.exe")) { if (Test-Path $p) { return $p } }
  throw "Node.js nicht gefunden. Bitte das portable Node mitliefern (Ordner 'node\node.exe') oder Node 18+ installieren."
}

function Find-Edge {
  foreach ($p in @(
    "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")) {
    if (Test-Path $p) { return $p }
  }
  $c = Get-Command msedge -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  return $null
}

function Test-BridgeUp {
  try { $r = Invoke-WebRequest "$Url/healthz" -UseBasicParsing -TimeoutSec 2; return $r.StatusCode -eq 200 } catch { return $false }
}

function Apply-StagedUpdate {
  # Wendet ein per Admin geladenes & geprueftes App-Update an (VOR dem Bridge-Start),
  # damit keine laufenden Dateien ueberschrieben werden. Konfig/Daten bleiben erhalten.
  <#
    NIEMALS UEBER EINE LAUFENDE BRUECKE SCHREIBEN (Befund 17.08.2026).

    Der Satz oben - "VOR dem Bridge-Start" - stimmt fuer den Hauptlauf dieser Datei: dort steht
    Apply-StagedUpdate vor Start-Bridge. Er stimmt NICHT fuer den zweiten Aufrufer. Der Watchdog
    startet diese Datei auch dann, wenn nur der KIOSK-BROWSER fehlt und die Bruecke voellig
    gesund weiterlaeuft (watchdog.ps1: "if (-not (Test-EdgeUp)) { ... launch-kiosk.ps1 ... }").
    Dieser Zweig liegt ausserhalb der Bruecken-Pruefung und feuert bei jedem Takt, in dem der
    Browser weg ist - zugeklappt, abgestuerzt, vom Nutzer geschlossen.

    WAS DABEI HERAUSKAM, im Betriebslog dieser Station am 13.08.2026:
        22:59:50  Kiosk-Browser laeuft nicht -> wird gestartet.
        22:59:54  ANGEWENDET: Update vollstaendig eingespielt.
    Vier Sekunden, mitten in einer 70 Stunden langen Laufzeit desselben node-Prozesses. Danach
    trug die Platte die neue Fassung, im Speicher lief die alte, der Marker war geloescht, und
    es wurde nie wieder ein Anlauf genommen. Der Mischzustand hielt 2,5 Tage.

    Robocopy schuetzt davor NICHT zuverlaessig: es ersetzt alles, was das Betriebssystem
    freigibt. Node haelt seine bereits gelesenen .js-Dateien nicht offen - sie sind laengst
    geparst. Ersetzt werden sie trotzdem, und der laufende Prozess merkt davon nichts.

    DESHALB WIRD HIER VERSCHOBEN, NICHT ABGEBROCHEN. Marker und Zip bleiben liegen, damit der
    naechste ECHTE Neustart das Update anwendet - genau der Weg, den stop-kiosk.ps1 unter
    "Befund 02.08.2026, Schwere 5" fuer den anderen Aufrufer schon beschreibt.

    Test-BridgeUp ist derselbe Test, mit dem Start-Bridge weiter unten entscheidet, ob schon
    eine Bruecke laeuft. Zwei Antworten auf dieselbe Frage waeren eine zu viel.
  #>
  if (Test-BridgeUp) {
    Write-Host "Update bleibt bereitgestellt: die Bruecke laeuft noch, es wird nichts ersetzt."
    Schreibe-UpdateSpur ("VERSCHOBEN: die Bruecke lief noch (vermutlich nur der Kiosk-Browser " +
      "wurde nachgestartet). Es wurde KEINE Datei ersetzt; Marker und Zip bleiben liegen. " +
      "Der naechste echte Neustart wendet das Update an.")
    return
  }
  $pend = Join-Path $Root 'data\update-pending.json'
  $zip  = Join-Path $Root 'data\update-staged.zip'
  if ((Test-Path $pend) -and (Test-Path $zip)) {
    try {
      Write-Host "Wende bereitgestelltes App-Update an..."
      $tmp = Join-Path $env:TEMP ("vetstation-upd-" + [Guid]::NewGuid().ToString('N'))
      Expand-Archive -Path $zip -DestinationPath $tmp -Force
      $src = $tmp
      $entries = Get-ChildItem $tmp
      if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) { $src = $entries[0].FullName }
      # Programm-Dateien kopieren; lokale Konfig (devices.json) + data/ + node_modules + .git NICHT anfassen.
      robocopy $src $Root /E /XD "data" "node_modules" ".git" /XF "devices.json" | Out-Null
      <#
        DAS ERGEBNIS VON ROBOCOPY WIRD GEPRUEFT (Befund der Gegenpruefung 01.08.2026).

        Vorher wurde der Marker bedingungslos geloescht - egal, ob alles kopiert wurde. Robocopy
        meldet Fehler ueber den Rueckgabewert: 0-7 sind Erfolg (0 = nichts zu tun, 1 = kopiert,
        2 = Extras, 4 = veraltete Dateien; kombinierbar), ab 8 ist mindestens eine Datei NICHT
        kopiert worden - etwa weil ein Virenscanner, ein offener Editor oder eine noch laufende
        zweite node-Instanz sie haelt. Genau dieser Fall ist hier real: am 01.08.2026 lagen zwei
        liegengebliebene node-Prozesse aus dem Stationsordner herum.

        Die Folge war die schlimmstmoegliche: eine HALB aktualisierte Station - neue Dateien
        neben alten, die zueinander nicht passen - die sich fuer fertig aktualisiert haelt,
        weil der Marker weg ist. Kein Hinweis, kein zweiter Versuch, und die Fassungsnummer
        behauptet den neuen Stand.

        Jetzt: bei >= 8 bleiben Marker und Zip liegen, damit der naechste Start es erneut
        versucht, und es wird im Klartext gemeldet.
      #>
      $rcErgebnis = $LASTEXITCODE
      if ($rcErgebnis -ge 8) {
        Write-Warning ("Update NICHT vollstaendig angewendet (robocopy meldet $rcErgebnis). " +
          "Mindestens eine Datei liess sich nicht ersetzen - meist, weil sie noch von einem " +
          "Programm gehalten wird. Das Update bleibt bereitgestellt und wird beim naechsten " +
          "Start erneut versucht. Haelt das an: NEUSTART.bat, danach nochmals starten.")
        Schreibe-UpdateSpur ("FEHLGESCHLAGEN: robocopy meldet " + $rcErgebnis +
          " - mindestens eine Datei liess sich nicht ersetzen. Marker bleibt liegen, der naechste Start versucht es erneut.")
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        return
      }
      Remove-Item $pend, $zip -Force -ErrorAction SilentlyContinue
      Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
      Schreibe-UpdateSpur "ANGEWENDET: Update vollstaendig eingespielt."
      Write-Host "App-Update angewendet."
      <#
        TREIBER, DIE EIN UPDATE MITBRINGT, MUESSEN AUCH EINGESPIELT WERDEN.
        robocopy kopiert treiber\ nur als DATEIEN in den Stationsordner - im Windows-
        Treiberspeicher landet dadurch nichts. Ohne diesen Schritt braechte ein Update den
        neuen EKG-Treiber zwar mit, das Geraet bliebe am Praxis-PC aber unerkannt, und zwar
        ohne jede Meldung. Das Skript ist idempotent (Vermerk in data\treiber-ekg2000.json):
        bei einem Update ohne Treiberaenderung tut es nichts. Diese Aufgabe laeuft mit
        -RunLevel Highest, die noetigen Rechte sind also da.
      #>
      try {
        $trv = Join-Path $Root 'installer\set-ekg-treiber.ps1'
        if (Test-Path $trv) {
          & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $trv -Root $Root | Out-Null
        }
      } catch {
        Schreibe-UpdateSpur ("Treiberpruefung nach dem Update fehlgeschlagen: " + $_.Exception.Message)
      }
    } catch {
      Schreibe-UpdateSpur ("ABGEBROCHEN: " + $_.Exception.Message)
      Write-Warning "Update konnte nicht angewendet werden: $($_.Exception.Message)"
    }
  }
}

<#
  Schreibe-UpdateSpur - JEDES Ergebnis der Update-Anwendung landet in data\update.log.

  WARUM (Befund 02.08.2026): der ganze Ertrag der Absicherung vom 01.08.2026 war ein Write-Warning.
  Dieses Skript laeuft im Regelbetrieb mit -WindowStyle Hidden (so startet es die geplante Aufgabe
  und so startet es das Installationsprogramm) - die Meldung geht also in ein Fenster, das niemand
  sieht, und eine eigene Logdatei gab es hier nicht. Scheitert die Anwendung dauerhaft (robocopy
  meldet >= 8, weil ein Virenscanner oder eine liegengebliebene node-Instanz eine Datei haelt; oder
  die Zip ist beschaedigt), dann bleibt die Station fuer immer auf der alten Fassung, versucht es
  bei jedem Start erneut - und NIRGENDS ist das zu sehen, waehrend der Admin-Bereich unveraendert
  verspricht, das Update werde "beim naechsten Neustart" angewendet.
  Der Watchdog macht es seit 1.2.1 richtig vor (data\watchdog.log); hier fehlte es noch.

  Wirft nie: eine nicht schreibbare Spur darf den Start der Station nicht anhalten.
#>
function Schreibe-UpdateSpur([string]$Text) {
  try {
    $d = Join-Path $Root 'data'
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    $z = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $f = Join-Path $d 'update.log'
    # Deckel wie beim Watchdog (25.08.2026). Hier fehlte er als einziger: diese Datei wuchs
    # unbegrenzt. Im Normalfall sind das wenige Zeilen je Start - aber genau der Fall, fuer
    # den es die Spur gibt, ist der Dauerfehler: scheitert robocopy bei JEDEM Start, schreibt
    # sie bei jedem Start weiter, jahrelang. Ein volles Laufwerk auf dem Praxis-PC heisst,
    # dass sich das Narkoseprotokoll nicht mehr speichern laesst - dieselbe Begruendung wie
    # bei data\diag.log.
    if ((Test-Path $f) -and ((Get-Item $f).Length -gt 524288)) {
      $rest = Get-Content $f -Tail 500
      Set-Content -Path $f -Value $rest -Encoding utf8
    }
    Add-Content -Path $f -Value ($z + '  ' + $Text) -Encoding utf8
  } catch { }
}

function Start-Bridge {
  if (Test-BridgeUp) { Write-Host "Bridge laeuft bereits auf $Url"; return }
  $node = Find-Node
  Write-Host "Starte Bridge+UI: $node bridge\src\index.js (Port $Port)"
  $env:PORT = "$Port"
  Start-Process -FilePath $node -ArgumentList "bridge\src\index.js" -WorkingDirectory $Root -WindowStyle Hidden
  $tries = 0
  while (-not (Test-BridgeUp)) {
    Start-Sleep -Milliseconds 400; $tries++
    if ($tries -gt 40) { throw "Bridge nicht erreichbar nach 16 s." }
  }
  Write-Host "Bridge bereit."
}

function Start-Kiosk {
  $edge = Find-Edge
  $profile = Join-Path $env:LOCALAPPDATA "VetStation\EdgeProfile"
  New-Item -ItemType Directory -Force -Path $profile | Out-Null
  if ($edge) {
    Write-Host "Starte Kiosk (Edge): $Url"
    # --disable-popup-blocking ist KEIN Komfort, sondern Voraussetzung fuer die Anmeldung:
    # Google und Microsoft muessen ihr eigenes Fenster oeffnen duerfen. Der frueher benutzte
    # Weg ueber eine Weiterleitung funktioniert nicht mehr - Edge trennt den Speicher von
    # vet-station.firebaseapp.com vom Speicher der Station (127.0.0.1), und die Anmeldung kommt
    # leer zurueck. Das Risiko ist hier gering: der Kiosk zeigt ausschliesslich die eigene
    # Oberflaeche, es gibt keine fremden Seiten, die ein Fenster aufreissen koennten.
    $args = @(
      "--kiosk", $Url,
      "--edge-kiosk-type=fullscreen",
      "--no-first-run", "--no-default-browser-check",
      "--disable-session-crashed-bubble", "--disable-infobars",
      "--disable-features=Translate,msEdgeWelcomePage,msImplicitSignin",
      "--disable-popup-blocking",
      "--overscroll-history-navigation=0",
      "--user-data-dir=$profile"
    )
    Start-Process -FilePath $edge -ArgumentList $args
  } else {
    Write-Warning "Microsoft Edge nicht gefunden. Oeffne Standardbrowser (kein Kiosk)."
    Start-Process $Url
  }
}

Apply-StagedUpdate

<#
  EKG-2000-TREIBER BEI JEDEM START PRUEFEN - und zwar VOR dem Start der Bruecke.

  Zwei Gruende fuer genau diese Stelle:
  1. Ein Aufruf, der erst MIT einem Update dazukommt, laeuft beim Update selbst nicht:
     Apply-StagedUpdate arbeitet aus der alten Fassung dieser Datei und ersetzt sie dabei.
     Weil hier bei JEDEM Start geprueft wird, holt der naechste Neustart es nach.
  2. Wird ein COM-Port-Treiber neu eingespielt, verschwindet der Anschluss kurzzeitig. Das
     darf nicht geschehen, waehrend die Bruecke ihn schon liest - also davor, nie danach.

  Das Skript ist idempotent (Vermerk in data\treiber-ekg2000.json): steht der Treiber, kostet
  der Aufruf nichts. Ohne Adminrechte (START-VetStation.bat, NEUSTART.bat) vermerkt es das
  und beendet sich still - eine Station darf nie an einem Treiber scheitern.
#>
try {
  $trv = Join-Path $Root 'installer\set-ekg-treiber.ps1'
  if (Test-Path $trv) { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $trv -Root $Root | Out-Null }
} catch { Write-Warning ("EKG-Treiberpruefung uebersprungen: " + $_.Exception.Message) }

Start-Bridge
if (-not $NoKiosk) { Start-Kiosk }
if ($Watchdog) { & (Join-Path $PSScriptRoot 'watchdog.ps1') -Port $Port }
Write-Host "VetStation gestartet. UI: $Url"
