<#
  auf-usb-kopieren.ps1 - Legt das VOLLSTAENDIGE Projekt auf einen USB-Stick / eine externe Platte,
  damit an einem ANDEREN PC nahtlos weitergearbeitet werden kann.

  Warum ein Skript und kein blosses Kopieren:
   - Es muss GEPRUEFT sein. Eine unvollstaendige Kopie faellt sonst erst am fremden PC auf -
     dann steht man ohne Quellcode da.
   - Der Ordner soll DREI Dinge enthalten, die man leicht verwechselt:
       1. das fertige SETUP (zum Installieren)
       2. das UPDATE-Paket (fuer eine schon laufende Station)
       3. den vollstaendigen QUELLCODE inkl. Git-Historie (zum Weiterentwickeln)
   - Die Git-Historie ist der eigentliche Schatz: ohne sie kennt der naechste PC die Begruendung
     hinter keiner einzigen Zeile mehr.

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\auf-usb-kopieren.ps1 -Ziel "G:\Manu\VetStation"
#>
param(
  [string]$Ziel = "G:\Manu\VetStation",
  [switch]$OhnePruefung
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path $PSScriptRoot -Parent

function Zeile { param($t) Write-Host $t }

Zeile ""
Zeile "== VetStation auf einen anderen Datentraeger legen =="
Zeile "Quelle: $Root"
Zeile "Ziel:   $Ziel"

$laufwerk = Split-Path $Ziel -Qualifier
if (-not (Test-Path $laufwerk)) {
  throw "ABBRUCH: Laufwerk $laufwerk ist nicht eingebunden. Externe Platte angeschlossen?"
}
$frei = (Get-PSDrive -Name $laufwerk.TrimEnd(':')).Free
if ($frei -lt 400MB) {
  throw ("ABBRUCH: auf $laufwerk sind nur " + [math]::Round($frei/1MB) + " MB frei. Es werden mindestens 400 MB gebraucht.")
}
Zeile ("Platz auf {0} : {1} GB frei" -f $laufwerk, [math]::Round($frei/1GB,1))

$version = (Get-Content (Join-Path $Root 'package.json') -Raw | ConvertFrom-Json).version
Zeile "Version: $version"

# --- 1) Selbsttests: es wird NICHTS Kaputtes weitergegeben --------------------
if (-not $OhnePruefung) {
  Zeile ""
  Zeile "[1/5] Selbsttests ..."
  $node = Join-Path $Root 'node\node.exe'
  if (-not (Test-Path $node)) { $c = Get-Command node -ErrorAction SilentlyContinue; if ($c) { $node = $c.Source } }
  if (Test-Path $node) {
    & $node (Join-Path $Root 'tools\alle-tests.js') | Select-Object -Last 4
    if ($LASTEXITCODE -ne 0) { throw "ABBRUCH: Selbsttests fehlgeschlagen - es wird keine fehlerhafte Kopie abgelegt." }
  } else {
    Write-Warning "Kein Node gefunden - Selbsttests uebersprungen."
  }
}

New-Item -ItemType Directory -Force -Path $Ziel | Out-Null

# --- 2) Quellcode inkl. Git-Historie -----------------------------------------
Zeile ""
Zeile "[2/5] Quellcode + Git-Historie ..."
$quelle = Join-Path $Ziel 'quellcode'
# bridge\data MUSS ausgeschlossen bleiben (Befund der Sicherheitspruefung 08.08.2026).
# Ausgeschlossen war bisher nur das Wurzelverzeichnis data\ (Zugangsdaten und privater
# Schluessel). bridge\data\ stand NICHT in der Liste - dort liegen protokoll.json (der
# Narkoseverlauf mit Patientenkennung) und patient-akte.json. Beides wanderte damit bei
# jedem "Auf USB kopieren" auf einen Datentraeger, der das Haus verlaesst.
# make-dist.ps1 schliesst denselben Ordner seit dem 27.07.2026 aus, mit derselben
# Begruendung - hier war es schlicht vergessen worden.
# devices.json ebenfalls: sie traegt Geraeteadressen und den Saalnamen einer konkreten Praxis.
robocopy $Root $quelle /MIR /XD (Join-Path $Root 'dist') (Join-Path $Root 'node_modules') (Join-Path $Root 'data') (Join-Path $Root 'bridge\data') `
  /XF '*.log' 'devices.json' /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Kopieren des Quellcodes fehlgeschlagen (robocopy-Code $LASTEXITCODE)." }

# Gegenprobe statt Vertrauen: liegt trotzdem eine Betriebsdatei im Ziel, wird abgebrochen.
# Ein stiller Datenabfluss faellt sonst niemandem auf - der Stick sieht richtig aus.
$verboten = @('protokoll.json','patient-akte.json','devices.json','cloud-auth.json','station-id.json')
$gefunden = Get-ChildItem $quelle -Recurse -File -Force -ErrorAction SilentlyContinue |
            Where-Object { $verboten -contains $_.Name }
if ($gefunden) {
  $liste = ($gefunden | ForEach-Object { $_.FullName }) -join "; "
  throw "ABBRUCH: Betriebs- oder Patientendaten im Kopierziel gefunden: $liste"
}

$dateien = (Get-ChildItem $quelle -Recurse -File -Force | Measure-Object).Count
Zeile "      $dateien Dateien (inkl. .git, ohne Betriebsdaten)"

# --- 3) Fertiges Setup + Update-Paket ----------------------------------------
Zeile ""
Zeile "[3/5] Setup und Update-Paket ..."
$installOrdner = Join-Path $Ziel 'installieren'
New-Item -ItemType Directory -Force -Path $installOrdner | Out-Null
$mitgegeben = @()
foreach ($n in @('VetStation-Setup.exe', "VetStation-$version.zip", 'VetStation-Setup.zip')) {
  $q = Join-Path $Root "dist\$n"
  if (Test-Path $q) { Copy-Item $q (Join-Path $installOrdner $n) -Force; $mitgegeben += $n; Zeile "      + $n" }
  else { Write-Warning "      fehlt: $n  (vorher SETUP-BAUEN.bat ausfuehren)" }
}

# --- 4) Wegweiser, damit am fremden PC klar ist, was zu tun ist ---------------
Zeile ""
Zeile "[4/5] Wegweiser schreiben ..."
$sha = ''
$updZip = Join-Path $installOrdner "VetStation-$version.zip"
if (Test-Path $updZip) { $sha = (Get-FileHash -LiteralPath $updZip -Algorithm SHA256).Hash.ToLower() }

# NICHT COMMITTETE ARBEIT ERKENNEN. Das ist der gefaehrlichste Zustand bei einer Uebergabe:
# die Dateien sind da, aber die Git-Historie kennt sie nicht. Ein beilaeufiges
# "git checkout ." oder "git stash" am anderen PC wuerde sie ALLE loeschen.
$offen = @()
try {
  Push-Location $Root
  $offen = @(& git -c safe.directory=* status --porcelain 2>$null | Where-Object { $_ })
  Pop-Location
} catch { }
$warnung = ''
if ($offen.Count -gt 0) {
  $warnung = @"

!! WICHTIG - NICHT COMMITTETE AENDERUNGEN !!
-----------------------------------------------------------------
Im Quellcode liegen $($offen.Count) geaenderte oder neue Dateien, die NICHT im Git-Verlauf sind.
Sie sind vollstaendig mitkopiert und funktionieren - aber "git log" zeigt sie nicht.

  => Fuehre am anderen PC NIEMALS "git checkout .", "git reset --hard" oder "git stash" aus,
     bevor diese Aenderungen committet sind. Sie waeren sonst unwiderruflich weg.

  Zustand ansehen:   git status
  Sichern:           git add -A  und  git commit -m "Stand von der externen Platte"
"@
  Write-Warning "$($offen.Count) nicht committete Dateien - Hinweis steht in LIESMICH.txt."
}
# Der Text unten geht mit auf den Datentraeger. Er nennt deshalb keine Werkzeugnamen mehr
# (29.08.2026): installer/ faehrt im oeffentlichen Update-Zip mit, und welches Programm
# jemand zum Weiterarbeiten benutzt, gehoert nicht in eine Anleitung fuer fremde PCs.
$liesmich = @"
VetStation $version - Gesamtpaket
=================================================================
Erstellt am: $(Get-Date -Format 'dd.MM.yyyy HH:mm')
Quelle:      $Root

WAS LIEGT HIER?
-----------------------------------------------------------------
installieren\VetStation-Setup.exe    Erstinstallation auf einem neuen PC: DOPPELKLICKEN.
                                     Enthaelt portables Node - der Ziel-PC braucht nichts extra.
installieren\VetStation-$version.zip  Update fuer eine BEREITS laufende Station
                                     (Admin > Aktualisieren). sha256:
                                     $sha
                                     ACHTUNG: dieses Paket geht auch ueber das offene Netz und
                                     traegt deshalb die beiden Nachschlagewerke NICHT mit
                                     (Fachliteratur, Kardiologie-Regeln). Es nimmt einer
                                     Station nichts weg - der Updater loescht nichts -, aber
                                     wer sie neu haben will, nimmt die Setup.exe.
installieren\VetStation-Setup.zip    Derselbe Inhalt als Ordner - fuer PCs, auf denen Windows
                                     die .exe blockiert (Smart App Control). Entpacken und darin
                                     INSTALLIEREN.bat doppelklicken.
quellcode\                           Das komplette Projekt inkl. .git-Historie.

AM ANDEREN PC INSTALLIEREN
-----------------------------------------------------------------
1. installieren\VetStation-Setup.exe doppelklicken.
2. NETZWERK-EINRICHTEN.bat  (setzt die feste IP 192.168.0.99)
3. GERAETE-PRUEFEN.bat      (sagt im Klartext, ob und warum keine Daten ankommen)
Anleitung fuer die Geraete: quellcode\docs\GERAETE-EINSTELLEN.md

AM ANDEREN PC WEITERENTWICKELN
-----------------------------------------------------------------
1. Ordner "quellcode" auf die FESTPLATTE des anderen PCs kopieren,
   z. B. nach D:\VetStation  (NICHT direkt von der externen Platte arbeiten -
   Git und Node sind dort deutlich langsamer, und beim Abziehen geht Arbeit verloren).
2. Dort ein Terminal oeffnen.
3. Zum Einlesen genuegt:  docs\BEFUNDBERICHT-2026-07-21.md  und  README.md
4. Selbsttest:   node tools\alle-tests.js       (bzw. node\node.exe tools\alle-tests.js)
5. Neu bauen:    SETUP-BAUEN.bat  (Tests + Paket + Setup.exe in einem Schritt)

Die Git-Historie ist mitkopiert: "git log" zeigt jede Aenderung mit Begruendung.

Falls git meldet "detected dubious ownership": das ist KEIN Schaden. Git misstraut
Ordnern auf Wechseldatentraegern, weil dort keine Besitzrechte gespeichert werden.
Nach dem Kopieren auf die interne Festplatte ist es weg. Sonst einmalig:
    git config --global --add safe.directory <Pfad zum Ordner>
$warnung
WENN AN EINEM ANDEREN PC ETWAS NICHT GEHT
-----------------------------------------------------------------
Dort  BEFUND-EXPORTIEREN.bat  doppelklicken. Das schreibt EINE Textdatei mit
Version, IP, Firewall, Geraetesuche, Empfangslage und Urteil - genau das, was man
zur Ferndiagnose braucht. Die Datei liegt danach in  data\befund-<Datum>.txt  und
kann weitergegeben und an einem anderen PC ausgewertet werden. Patienten-Kennungen werden
dabei unkenntlich gemacht, Vitalwerte sind nicht enthalten.
"@
Set-Content -Encoding UTF8 -Path (Join-Path $Ziel 'LIESMICH.txt') -Value $liesmich

# --- 5) Nachpruefen: ist die Kopie wirklich vollstaendig? --------------------
Zeile ""
Zeile "[5/5] Kopie nachpruefen ..."
$fehlt = @()
foreach ($p in @('quellcode\package.json', 'quellcode\bridge\src\index.js', 'quellcode\bridge\src\netscan.js',
                 'quellcode\bridge\src\diagnose.js', 'quellcode\ui\vetstation-live.js', 'quellcode\tools\alle-tests.js',
                 'quellcode\installer\make-dist.ps1', 'quellcode\installer\make-setup-exe.ps1',
                 'quellcode\docs\GERAETE-EINSTELLEN.md', 'quellcode\SETUP-BAUEN.bat', 'quellcode\.git', 'LIESMICH.txt')) {
  if (-not (Test-Path (Join-Path $Ziel $p))) { $fehlt += $p }
}
$kopierteVersion = try { (Get-Content (Join-Path $Ziel 'quellcode\package.json') -Raw | ConvertFrom-Json).version } catch { '?' }
if ($kopierteVersion -ne $version) { $fehlt += "Version stimmt nicht ($kopierteVersion statt $version)" }

if ($fehlt.Count -gt 0) {
  Write-Warning "UNVOLLSTAENDIG - es fehlen:"
  $fehlt | ForEach-Object { Write-Warning "   $_" }
  exit 1
}

$gesamt = (Get-ChildItem $Ziel -Recurse -File -Force | Measure-Object -Property Length -Sum)
Zeile ""
Zeile "FERTIG - Kopie geprueft und vollstaendig."
Zeile ("  Ordner:  {0}" -f $Ziel)
Zeile ("  Inhalt:  {0} Dateien, {1} MB" -f $gesamt.Count, [math]::Round($gesamt.Sum/1MB,1))
Zeile ("  Version: {0}" -f $version)
Zeile ("  Setup:   {0}" -f ($mitgegeben -join ', '))
Zeile ""
Zeile "  Am anderen PC zuerst LIESMICH.txt lesen."
exit 0
