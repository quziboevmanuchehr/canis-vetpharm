'use strict';
/*
 * kopfbereich-test.js — der klebende Kopfbereich: Haftpunkte, Ueberbau, Nachziehen.
 *
 * WARUM ES DIESEN TEST GIBT (Befund 26.08.2026, aus der Praxis gemeldet:
 * "beim Runterscrollen rutscht die Leiste runter, manchmal zittert die ganze Web-App")
 *
 * Der Kopfbereich besteht aus DREI klebenden Lagen uebereinander: header, .patient, .navbar.
 * Ihre Haftpunkte sind keine Zahlen im CSS, sondern zwei Variablen, die kopfMessen() aus der
 * tatsaechlichen Hoehe rechnet. Das ist richtig so — aber es heisst, dass jede Lage falsch
 * klebt, sobald die Variablen und die wirklichen Hoehen auch nur ein Bild lang auseinander
 * sind. Genau das war der Fehler, und er faerbte KEINEN der 101 vorhandenen Tests rot: es gab
 * bis heute keine einzige Zeile im Baum, die den Kopfbereich prueft.
 *
 * Gemessen in echtem Chrome bei 1251x1222, EINE Radraste nach unten, Reiter "notfall":
 *
 *   VORHER                                              NACHHER
 *   133 ms  data-kopf=klein, .patient endet bei 161      332 ms  Wechsel und Haftpunkte im
 *           .navbar klebt aber noch bei 209                      SELBEN Bild, Luecke 0 px
 *           -> 57 px zu tief, 48 px Loch darueber
 *   174 ms  Haftpunkte nachgezogen, schnappt zurueck
 *   groesste Luecke ueber den ganzen Rollweg: 57 px      groesste Luecke: 0 px (VetStation)
 *                                                        bzw. 4,8 px (Web-App mit Fern-Leiste)
 *
 * Und ein zweiter Befund derselben Familie, in der Web-App: position:sticky misst vom
 * FENSTERRAND, nicht vom Elternelement. Die feste Fern-Leiste (#vetlive-bar) legte sich
 * deshalb ueber den ganzen Kopf — gemessen: header 0..40,7 unter einer Leiste 0..134,5, also
 * 100 % unsichtbar, und die Patientenzeile zu 93,5 %. Der CPR-Knopf war beim Rollen nicht
 * mehr erreichbar. Dagegen steht --ueberbau.
 *
 * WAS HIER GEPRUEFT WIRD — und warum es Quelltextpruefungen sind:
 * Haftpunkte sind Layout. Layout laesst sich in node nicht messen, und in der Vorschau dieses
 * Projekts laesst es sich ueberhaupt nicht messen (requestAnimationFrame feuerte am 26.08.2026
 * gar nicht, document.visibilityState war 'hidden' — siehe [[vetstation-leinwand-messfalle]]).
 * Der Test bewacht deshalb die VORAUSSETZUNGEN, die im Browser nachgemessen wurden, und vor
 * allem die Stellen, die PAARWEISE stimmen muessen und sonst still auseinanderlaufen.
 *
 * Gegenprobe von Hand gefahren: jede der neun Pruefungen einmal absichtlich zerbrochen
 * (Variable aus einer Regel entfernt, kopfMessen() aus dem Wechselblock genommen, die
 * --ueberbau-Zeile neben paddingTop geloescht, den Bau nicht neu gefahren) — alle neun
 * wurden rot.
 *
 * Start:  node tools/kopfbereich-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const APP = path.join(WURZEL, 'ui', 'app', 'index.html');
const FERN = path.join(WURZEL, 'tools', 'web-fern-modul.html');
/* Der Bau schreibt die Web-App NEBEN das Repo. Fehlt sie, ist das kein Fehler dieses Baumes. */
const WEBAPP = path.join(WURZEL, '..', '..', 'canis-vetpharm', 'canis-anaesthesie', 'index.html');

/* Blockkommentare RAUS, bevor irgendetwas gesucht wird. Dieser Test erklaert seinen eigenen
 * Anlass in den Dateien, die er prueft — eine Pruefung auf "--ueberbau kommt vor" wuerde sonst
 * an der Begruendung anschlagen statt an der Regel. Dieselbe Falle wie in ekg-skala-test.js. */
function ohneKommentare(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, ' ');
}
function lies(p) { return fs.readFileSync(p, 'utf8'); }

const appRoh = lies(APP);
const app = ohneKommentare(appRoh);
const fern = ohneKommentare(lies(FERN));

let ok = 0;
const fehler = [];
function pruefe(was, bedingung, zusatz) {
  if (bedingung) { ok++; return; }
  fehler.push(was + (zusatz ? '\n     -> ' + zusatz : ''));
}

/* Holt den Rumpf einer Funktion aus dem Quelltext, ueber Klammerzaehlung. Ein Regex kann das
 * nicht: die Funktionen hier enthalten selbst geschweifte Klammern in Zeichenketten. */
function rumpf(quelle, name) {
  const start = quelle.indexOf('function ' + name);
  if (start < 0) return null;
  const auf = quelle.indexOf('{', start);
  if (auf < 0) return null;
  let tiefe = 0;
  for (let i = auf; i < quelle.length; i++) {
    const c = quelle[i];
    if (c === '{') tiefe++;
    else if (c === '}') { tiefe--; if (tiefe === 0) return quelle.slice(auf, i + 1); }
  }
  return null;
}

/* Holt eine CSS-Regel "auswahl{...}" als Text. */
function regel(quelle, auswahl) {
  const i = quelle.indexOf('\n' + auswahl + '{');
  if (i < 0) return null;
  const auf = quelle.indexOf('{', i);
  const zu = quelle.indexOf('}', auf);
  return zu < 0 ? null : quelle.slice(auf + 1, zu);
}

console.log('kopfbereich-test — klebender Kopfbereich\n');

/* ---------------------------------------------------------------------------------------
 * 1..3  Alle DREI klebenden Lagen kennen den Ueberbau.
 *
 * Eine einzelne vergessene Lage faellt nicht auf: die anderen beiden sitzen richtig, und die
 * dritte liegt einfach unter der fremden Leiste — sichtbar nur, wenn ueberhaupt eine da ist,
 * also nur in der Web-App und nur nach der Anmeldung.
 * ------------------------------------------------------------------------------------- */
[
  ['header', 'header'],
  ['.patient', 'Patientenzeile'],
  ['.navbar', 'Reiterleiste']
].forEach(function (paar) {
  const r = regel(app, paar[0]);
  pruefe(paar[1] + ' (' + paar[0] + ') ist klebend und kennt --ueberbau',
    !!r && /position:\s*sticky/.test(r) && r.indexOf('--ueberbau') >= 0,
    r ? 'gefunden: top:' + (/top:([^;]*)/.exec(r) || [, '(kein top)'])[1]
      : 'Regel "' + paar[0] + '{...}" nicht gefunden');
});

/* ---------------------------------------------------------------------------------------
 * 4  Der Ersatzwert ist 0px.
 *
 * Ohne Fern-Leiste — also in VetStation selbst und in der Web-App vor der Anmeldung — darf
 * sich gegenueber frueher NICHTS aendern. Stuende hier eine Zahl, haette der Kopf in
 * VetStation ein Loch ueber sich, das niemand je fuellt.
 * ------------------------------------------------------------------------------------- */
pruefe('--ueberbau hat ueberall den Ersatzwert 0px (ohne fremde Leiste aendert sich nichts)',
  /var\(--ueberbau,\s*0px\)/.test(app) &&
  !/var\(--ueberbau,\s*(?!0px)[^)]/.test(app),
  'jeder Aufruf muss var(--ueberbau,0px) lauten');

/* ---------------------------------------------------------------------------------------
 * 5  kopfScroll() misst beim Zustandswechsel SYNCHRON nach.
 *
 * Das ist der Kern der Behebung. data-kopf wirkt sofort (der CSS-Uebergang ist absichtlich
 * entfernt), die Haftpunkte kamen aber erst im naechsten Bild — dazwischen lag das Rutschen.
 * Gesucht wird ein blosser Aufruf kopfMessen(), NICHT einer in einer Uhr: der Aufruf in
 * setTimeout(...,200) stand schon vorher da und hat den Fehler nicht verhindert.
 * ------------------------------------------------------------------------------------- */
const kopfScroll = rumpf(app, 'kopfScroll');
pruefe('kopfScroll() gibt es', !!kopfScroll);
if (kopfScroll) {
  /* Alles, was in einer Uhr oder einem Rueckruf steht, zaehlt hier NICHT. */
  const ohneUhren = kopfScroll.replace(/setTimeout\s*\([\s\S]*?\)\s*;/g, ' ')
    .replace(/requestAnimationFrame\s*\([\s\S]*?\)\s*;/g, ' ');
  pruefe('kopfScroll(): beim Wechsel von data-kopf wird SOFORT nachgemessen, nicht erst im naechsten Bild',
    /setAttribute\(\s*['"]data-kopf['"]/.test(ohneUhren) && /(^|[^.\w])kopfMessen\s*\(\s*\)/.test(ohneUhren),
    'ein kopfMessen() nur in setTimeout/requestAnimationFrame reicht nicht — genau so war der Fehler');
}

/* ---------------------------------------------------------------------------------------
 * 6  kopfPlanen() hat eine Notuhr NEBEN requestAnimationFrame.
 *
 * Der alte Rueckfall griff nur, wenn es requestAnimationFrame gar nicht GIBT. Der Fall, der
 * vorkommt, ist: es gibt die Funktion, sie feuert nicht (verborgener Reiter, Kiosk im
 * Ruhezustand, die Vorschau dieses Projekts). Dann bliebe kopfStand.geplant fuer immer auf
 * true stehen und JEDE weitere Aenderung des Kopfes waere wirkungslos.
 * ------------------------------------------------------------------------------------- */
const kopfPlanen = rumpf(app, 'kopfPlanen');
pruefe('kopfPlanen() gibt es', !!kopfPlanen);
if (kopfPlanen) {
  /* Die Notuhr steht AUSSERHALB des if/else um requestAnimationFrame. Wir erkennen sie daran,
   * dass nach dem letzten "else setTimeout(...)" noch ein setTimeout folgt. */
  const nachDerWeiche = kopfPlanen.slice(kopfPlanen.lastIndexOf('requestAnimationFrame'));
  pruefe('kopfPlanen(): Notuhr auch dann, wenn requestAnimationFrame vorhanden ist, aber nicht feuert',
    /setTimeout\s*\(\s*kopfMessen/.test(nachDerWeiche.replace(/else\s+setTimeout\s*\([^)]*\)\s*;/, ' ')),
    'nach der requestAnimationFrame-Weiche muss ein eigenes setTimeout(kopfMessen, ...) stehen');
  pruefe('kopfMessen() raeumt die Notuhr wieder ab (sonst misst es doppelt)',
    /clearTimeout\s*\(\s*kopfStand\.wecker\s*\)/.test(rumpf(app, 'kopfMessen') || ''));
}

/* ---------------------------------------------------------------------------------------
 * 7  Ein Groessenwaechter auf Kopf UND Patientenzeile.
 *
 * Die zwei Uhren in kopfBinden() sind geratene Zeitpunkte fuer EINEN bekannten Fall
 * (vetpharm-ui.js haengt Knoepfe ein). Der Kopf aendert seine Hoehe aber auch beim
 * Reiterwechsel, beim Rassebalken, bei nachgeladener Schrift. Gemessen 26.08.2026: nach dem
 * Wechsel vom Geraete- auf den Notfall-Reiter wuchs die Patientenzeile von 126 auf 148,3 px,
 * --navbar-top blieb auf 191 — die Reiterleiste schnitt die Patientenzeile um 18,3 px an.
 * ------------------------------------------------------------------------------------- */
const kopfBinden = rumpf(app, 'kopfBinden');
pruefe('kopfBinden() gibt es', !!kopfBinden);
if (kopfBinden) {
  pruefe('kopfBinden(): ResizeObserver auf header UND .patient',
    /new\s+ResizeObserver/.test(kopfBinden) &&
    /querySelector\(\s*['"]header['"]\s*\)/.test(kopfBinden) &&
    /querySelector\(\s*['"]\.patient['"]\s*\)/.test(kopfBinden),
    'ohne Waechter folgen die Haftpunkte nur den geratenen Zeitpunkten');
  pruefe('kopfBinden(): der Waechter misst DIREKT, nicht ueber kopfPlanen()',
    /new\s+ResizeObserver\s*\(\s*function\s*\([^)]*\)\s*\{\s*kopfMessen\s*\(\s*\)/.test(kopfBinden),
    'ResizeObserver ruft nach dem Layout und vor dem Zeichnen zurueck — ueber requestAnimationFrame waere es wieder ein Bild zu spaet');
}

/* ---------------------------------------------------------------------------------------
 * 8  Polsterung und Ueberbau laufen NICHT auseinander.
 *
 * Das ist die eigentliche Falle dieser Aenderung, und es ist eine Form, an der sich dieses
 * Projekt schon mehrfach verbrannt hat: zwei Stellen, die dasselbe bedeuten, aber getrennt
 * gepflegt werden. body{padding-top} schiebt den FLUSS, --ueberbau schiebt den HAFTPUNKT.
 * Wer eine der beiden setzt oder leert und die andere vergisst, bekommt entweder ein Loch
 * ueber dem Kopf oder eine Leiste ueber dem Kopf — beides sieht im Quelltext richtig aus.
 * ------------------------------------------------------------------------------------- */
const zeilen = fern.split('\n');
const polsterZeilen = [];
const ueberbauZeilen = [];
zeilen.forEach(function (z, i) {
  /* NUR die Polsterung des KOERPERS zaehlt. "padding-top" allein traefe auch die Trennlinie
   * unter einer Tabellenfusszeile — gemessen beim ersten Lauf: drei solcher Fehlalarme
   * (#druckvorschau .fuss, #druckblatt .fuss, .vetlive-saal .s-geraete). Ein Waechter, der
   * bei jedem Randabstand anschlaegt, wird abgeschaltet und bewacht dann gar nichts mehr. */
  if (/style\.paddingTop\s*=/.test(z) || (/\bbody\b/.test(z) && /padding-top\s*:/.test(z))) polsterZeilen.push(i);
  if (z.indexOf('--ueberbau') >= 0) ueberbauZeilen.push(i);
});
pruefe('Fern-Modul: es gibt ueberhaupt Stellen, die polstern (sonst prueft der Rest nichts)',
  polsterZeilen.length >= 3, 'gefunden: ' + polsterZeilen.length);
polsterZeilen.forEach(function (i) {
  /* Der Partner muss in unmittelbarer Naehe stehen — dieselbe Zeile oder die naechsten drei.
   * Weiter auseinander waere es beim Lesen nicht mehr als Paar erkennbar. */
  const nah = ueberbauZeilen.some(function (j) { return j >= i - 1 && j <= i + 4; });
  pruefe('Fern-Modul Zeile ' + (i + 1) + ': neben der Polsterung steht auch --ueberbau',
    nah, zeilen[i].trim().slice(0, 100));
});
pruefe('Fern-Modul: das Abmelden nimmt den Ueberbau zurueck',
  /removeProperty\(\s*['"]--ueberbau['"]\s*\)/.test(rumpf(fern, 'zurueckZumTraining') || ''),
  'sonst behaelt der Kopf nach dem Abmelden ein Loch in Hoehe einer Leiste, die es nicht mehr gibt');
pruefe('Fern-Modul: die gemessene Leistenhoehe geht in BEIDE — Polsterung und Ueberbau',
  /offsetHeight[\s\S]{0,220}--ueberbau/.test(rumpf(fern, 'polsterSetzen') || ''),
  'beide muessen aus DERSELBEN Messung kommen');

/* ---------------------------------------------------------------------------------------
 * 9  Die GEBAUTE Web-App traegt dieselben Regeln.
 *
 * Der Bau ist ein eigener Schritt (tools/web-app-bauen.js). Wer die Quelle aendert und nicht
 * neu baut, hat die Behebung in VetStation und NICHT in der Web-App — und die Web-App ist
 * genau die, in der die Fern-Leiste ueberhaupt vorkommt. Der Fehler waere also ausgerechnet
 * dort noch da, wo er gemeldet wurde.
 * ------------------------------------------------------------------------------------- */
if (!fs.existsSync(WEBAPP)) {
  console.log('  Hinweis: die gebaute Web-App liegt nicht unter ' + WEBAPP + ' — Abschnitt 9 uebersprungen.');
} else {
  const web = ohneKommentare(lies(WEBAPP));
  ['header', '.patient', '.navbar'].forEach(function (auswahl) {
    const r = regel(web, auswahl);
    pruefe('gebaute Web-App: ' + auswahl + ' kennt --ueberbau',
      !!r && r.indexOf('--ueberbau') >= 0,
      'nach einer Aenderung an ui/app/index.html muss tools/web-app-bauen.js laufen');
  });
  pruefe('gebaute Web-App: das Fern-Modul setzt --ueberbau',
    web.indexOf('--ueberbau') >= 0 && /style\.setProperty\(\s*['"]--ueberbau['"]/.test(web));
}

/* ------------------------------------------------------------------------------------- */
console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + '):');
  fehler.forEach(function (f) { console.log('  x ' + f); });
  process.exit(1);
}
console.log('OK — ' + ok + ' Pruefungen. Kopfbereich: Haftpunkte, Ueberbau, Nachziehen.');
