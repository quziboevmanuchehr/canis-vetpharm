# Welche Narkose- und Monitorgeräte lassen sich anbinden? — Recherche 01.08.2026

Acht Herstellerfamilien, jede von einem zweiten Agenten gegengeprüft. Rund 120 Modelle gesichtet.
Die verwertbaren Ergebnisse stehen als Daten in [`bridge/src/geraetekatalog.js`](../bridge/src/geraetekatalog.js);
dieses Dokument ist die Begründung dazu und die Sammlung der Quellen.

> **Lesart der Vertrauensstufen** — ● belegt = im Herstellerdokument nachgelesen oder am Gerät
> gemessen · ● wahrscheinlich = gut begründet, nicht nachgemessen · ● unbestätigt = Hinweis aus
> zweiter Hand. Kein Port, kein Menüpfad und keine Baudrate in diesem Dokument ist geraten.

---

## 1. Kurzfassung

### Ohne Zusatzkosten anbindbar
| Gerät | Weg | Vertrauen |
|---|---|---|
| **Mindray WATO EX-35Vet** (Vet-Narkosegerät!) | HL7 über Netzwerk **und** RS-232 | ● belegt |
| **Bionet BM3/5/7 Vet — Pro und Elite** | HL7, Ziel-IP **und Port frei wählbar** | ● belegt |
| **EDAN iM50/60/70/80 (+ Vet)** | HL7 — aber Verschlüsselung ab Werk auf TLS | ● belegt |
| **SurgiVet Advisor V9200/V9204** | RS-232, Klartext-CSV, 25 Spalten dokumentiert | ● belegt |
| **Eickemeyer LifeVet 10C** | HL7 auf 8830 (in Ihrer Praxis erprobt) | ● belegt |
| **Mindray uMEC12 Vet** | HL7-Abfrage — aber nur NIBP + Alarme | ● belegt |
| **Datex-Ohmeda 7900 SmartVent** (Aestiva/Aespire) | RS-232, offener Quellcode als Referenz | ● belegt |
| **Philips IntelliVue** | Data Export über LAN, frei dokumentiert | ● belegt |
| **Dräger Fabius / Primus / Perseus** | MEDIBUS über RS-232 | ● belegt |
| **Mindray A-Serie** (A3–A9) | HL7 v2.6 (IHE PCD) über LAN oder RS-232 | ● belegt |

### Nur mit Zusatzkasten oder Abonnement
| Gerät | Was fehlt |
|---|---|
| Mindray **Vet**-Monitore (ePM Vet, iPM Vet, iMEC Vet, PM-9000Vet, LifeVet 10M) | Kein HL7 in der Vet-Firmware. Und: die eGateway-Kompatibilitätsliste nennt **kein** Vet-Gerät |
| Comen C50-V / C80-V / C86-V | HL7 gibt es erst auf der Zentralstation STAR8800 |
| Contec CMS6000Vet / CMS8000Vet | Nur herstellereigene Zentrale (plus Sicherheitsproblem, siehe unten) |
| Midmark Multiparameter Monitor | Sendet auf Port 2528 — Empfänger ist ein Jahresabonnement |
| Mediana YM6000 | LAN geht nur mit nachgerüstetem TCP/IP-Modul |
| Dräger Vista 120 | HL7 nur über das separate „Vista 120 Gateway" |

### Gar nicht — und das ist der Normalfall
Rein mechanisch-pneumatisch, **keine Elektronik, kein Anschluss**: Midmark Matrx VMS/VMR,
Dispomed Moduflex, Hallowell EMC 2000/2002/PRO, Hallowell AWS 2770, Vetland LAS-4000,
RWD R500-Reihe, DRE Integra SP, Supera M-Reihe.
Ebenso ohne nutzbaren Ausgang: **Mindray Veta 5 / Veta 5 Plus** (drei Buchsen, keine gibt Messwerte
aus), **Veta 3** (unbestätigt, aber nichts spricht dafür), **Cardell Insight** (RJ45 laut Handbuch
„future use"), **Tafonius** (nur manueller USB-Export), **petMAP** (nur SD-Karte).

> **Häufigster Irrtum:** „Digitalanzeige" heißt Ziffernanzeige, nicht digitale Schnittstelle. Das
> steht so bei der Hallowell-2002-Familie und den Midmark-2024-PRO-Ventilatoren.

---

## 2. Die drei Befunde, die am meisten ändern

### 2.1 Es gibt doch ein Vet-Narkosegerät mit offener Schnittstelle
Der Satz „kein Veterinär-Narkosegerät gibt Daten heraus" galt in diesem Projekt lange. Er stimmt
für den Veta 5 — aber nicht für die WATO-Reihe. Das **WATO EX-35Vet** (in Deutschland u. a. über
Eickemeyer) nennt im Operator's Manual auf der Rückseite unter „Communication Ports" wörtlich:

> „B. Network port (Connect with the anesthesia information system through HL7 protocol)"

Dazu ein RS-232-Anschluss. Und die Tabelle „Software Function Activation" im selben Handbuch listet
**alle** per Code freischaltbaren Funktionen auf (P-mode, PCV, PSV, SIMV, Spirometrie-Schleifen,
PCV-VG …) — HL7 steht **nicht** darunter. Es ist also keine kostenpflichtige Option.

### 2.2 Ihr LifeVet M ist ein EDAN, kein Mindray
Das Eickemeyer-Handbuch (Artikel 321870, April 2012) trägt im PDF-Titel
**„iM8 VET Series Veterinary Monitor User Manual"** und die EDAN-Dokumentnummer 01.54.455558. Das
Gerät spricht mit **MFM-CMS** — EDANs eigener Zentralstation, ein herstellereigener Binärstrom.

Damit ist erklärt, warum die Suche nach einem HL7-Menü an diesem Gerät nicht enden konnte: **es gibt
dort keines.** Der gesamte HL7-Code von VetStation hilft hier nicht. Konkret:

- Menüweg: `SYSTEM MENU → MAINTAIN → Passwort ABC → USER MAINTAIN`
- Werkseinstellung **SERVER IP = 202.114.4.119** — eine Adresse, die in keiner Praxis existiert
- Achtung beim Verkabeln: der **Schwesternruf liegt auf Pin 7/8 desselben RJ45-Steckers** wie das Netzwerk

Nächster sinnvoller Schritt: SERVER IP auf die PC-Adresse setzen, Port 5510 stehen lassen, und den
Strom mitschneiden lassen. Der Mitschnitt ist die Grundlage, um bei Eickemeyer/EDAN gezielt nach
einer offenen Schnittstelle zu fragen — statt weiter Menüs zu durchsuchen.

### 2.3 Sicherheitswarnung: Contec CMS8000
Die US-Behörde CISA hat im Januar 2025 im Humanmodell CMS8000 eine **Hintertür** gefunden: das Gerät
verbindet sich nach dem Start selbsttätig zu einer fest einprogrammierten fremden Adresse, streamt
dorthin Patienten- und Sensordaten und kann darüber Code nachladen; die Netzwerkschnittstelle
schaltet sich dabei selbst ein (CVE-2025-0626, CVE-2025-0683). CISA hat **nur** das Humangerät
untersucht — ob die Vet-Variante dieselbe Firmware hat, ist weder belegt noch widerlegt.
**Empfehlung: ein solches Gerät gehört in ein isoliertes Netz ohne Weg ins Internet.**

---

## 3. Je Protokollfamilie: was VetStation bauen müsste

| Familie | Aufwand | Stand |
|---|---|---|
| **HL7 v2 / MLLP** (Mindray, Bionet, EDAN, WATO, Philips-nah) | **keiner** | Läuft. Jedes Gerät, das HL7 auf einen unserer Ports schickt, wird schon heute gelesen |
| **RS-232 als Transport** | gebaut | [`seriell.js`](../bridge/src/seriell.js): COM-Port direkt **oder** Geräteserver, mit Sendesperre |
| **Klartext-CSV über RS-232** (SurgiVet Advisor) | klein | Zeilenparser gegen die dokumentierte 25-Spalten-Tabelle. Der aussichtsreichste nächste Adapter |
| **Dräger MEDIBUS** | mittel | Verlangt aktives Fragen: alle 2 s ein Lebenszeichen, Antwort binnen 10 s, Pause > 3 s bricht ab. Referenzen: `wokai/xenon` (Node.js!), OpenICE, VSCapture |
| **Datex-Ohmeda COM 1.0** (7900 SmartVent) | mittel | Referenz `patnatha/DownVent` + begutachtete Veröffentlichung. Braucht zwei Startkommandos |
| **GE S/5 (DRI)** | groß | Besser über VSCapture-CSV als selbst nachbauen |
| **Philips Data Export** | groß | Vollständige Spezifikation frei verfügbar, aber eigener Verbindungsaufbau |
| **Proprietär-binär** (Mindray MD2, EDAN MFM-CMS, Comen, Contec, Digicare, Vetronic) | — | **Wird nicht gebaut.** Kein öffentliches Protokoll; ein geratener Wert am narkotisierten Tier ist der schlimmste Fehler dieses Programms |

---

## 4. Transportwege

| Lage | Lösung |
|---|---|
| Gerät hat RJ45, PC steht daneben | Direkt in denselben Switch. Der erprobte Normalfall |
| Gerät hat RJ45, PC hängt im WLAN | **WLAN-Client-Bridge** (Access Point im Client-Modus) an die LAN-Buchse. Für die Station ändert sich nichts |
| Gerät hat **nur RS-232** | **Geräteserver** (RS-232→LAN): Moxa NPort, USR-TCP232, Waveshare, HF2211 — etwa 30–80 €. Kein Treiber nötig, das Gerät darf stehen bleiben, und VetStation liest es über den erprobten Netzweg. **Das ist die Empfehlung** |
| Gerät hat nur RS-232, kein Budget | Direkt an einen COM-Anschluss des PCs. Öffnen und Einstellen sind erprobt (COM1, 01.08.2026), das Lesen eines echten Geräts noch nicht |
| Zweiter Standort / von zu Hause | Firebase Realtime Database, gemessen ~150 ms Ende zu Ende (siehe [FERN-LIVE.md](FERN-LIVE.md)) |
| Zweiter OP-Saal im Haus | Beide Stationen melden sich mit **demselben** Praxis-Konto an; zusätzlich der direkte Weg auf Port 8771 (siehe [MEHRERE-SAELE.md](MEHRERE-SAELE.md)) |

**Kabelwarnungen aus den Handbüchern — beide können Hardware kosten:**
- **SurgiVet Advisor:** Pin 6 des DB9 führt **+5 Volt**; auf einem PC-COM-Port liegt dort DSR.
  Nur ein dreiadriges Kabel (Pins 2, 3, 5) verwenden.
- **Dräger:** die 9-poligen Buchsen tragen Pin 2 = RXD, Pin 3 = TXD — DTE-Belegung wie am PC.
  Es wird also sehr wahrscheinlich ein **Nullmodem-Kabel** gebraucht. Beim Perseus ist ein
  dokumentierter Praxisfall bekannt, in dem nur mit Nullmodem etwas ankam.

---

## 5. Die Portliste und ihre Begründung

| Port | Wofür | Herkunft |
|---|---|---|
| 3502 | Mindray Gateway-Kommunikation (Werkseinstellung im uMEC12-Menü) | am Gerät abgelesen |
| 4601 | HL7-Abfrage / VSCapture | am Gerät gemessen |
| 8830 | Werksziel der HL7-Konfiguration im LifeVet 10C | am Gerät abgelesen |
| 5000 | HL7-Push vieler Mindray-Modelle; OpenICE nennt ihn als Vorgabe für die A-Serie | Handbuch + Quellcode |
| 5510 | Server-Port des LifeVet M (EDAN) | am Gerät abgelesen |
| 24105 | Philips IntelliVue Data Export | Herstellerspezifikation |
| 2575 | IANA-Standardport für HL7/MLLP | Standard |
| **2528** | **neu:** Werks-Zielport des Midmark Multiparameter Monitor | Handbuch 003-10464-00 |

Frei konfigurierbare Geräte (Bionet, WATO, A-Serie, EDAN) bekommen in der Anleitung **einen dieser
Ports genannt** — dann muss auf der PC-Seite nichts geändert werden.

**Nicht aufgenommen:** Port 515. Dort läuft die Contec-Hintertür, und 515 ist zugleich der
Drucker-Port (LPD) — ihn zu belegen würde in jeder Praxis Drucker stören.

---

## 6. Service-Passwörter aus den Handbüchern

| Hersteller | Passwort | Menü |
|---|---|---|
| Mindray uMEC / ePM | `888888` | Benutzer-Wartung |
| Mindray BeneVision N-Serie | `MIN888` | User Maintenance |
| EDAN / Eickemeyer LifeVet M, C | `ABC` | USER MAINTAIN |
| Midmark Multiparameter Monitor | `2013` | User Maintenance (Demo-Modus: `5555`) |
| SurgiVet Advisor | `ADVISOR` | Service Menu |

---

## 7. Was nur der Händler beantworten kann

1. **Eickemeyer/Mindray:** Gibt es für die Vet-Firmware der ePM-/uMEC-/iPM-Reihe eine Fassung mit
   HL7-Ausgang? (Für Ihr uMEC12 Vet: Software 01.13.00. Die **Seriennummer beim Anruf vom Typenschild
   des eigenen Geräts ablesen** — sie steht hier nicht, weil dieses Dokument im Update-Paket an jede
   Station geht und eine Seriennummer genau ein Gerät in genau einer Praxis benennt; 29.08.2026.)
2. **Eickemeyer/EDAN:** Existiert für das LifeVet M eine offene Schnittstelle, oder gibt es das
   „HL7 Communication Protocol Service Manual" von EDAN?
3. **Mindray Animal:** Welchen Port und welches Menü nutzt der HL7-Ausgang des WATO EX-35Vet?
4. **Dräger:** Muss der COM-Anschluss am Gerät durch einen Techniker freigeschaltet werden?
5. **Midmark:** Welches Format läuft auf TCP 2528?

---

## 8. Quellen — Entwickleranleitungen und Handbücher

**Protokollspezifikationen (die eigentlichen Entwicklerdokumente)**
- Mindray *Patient Data Share Protocol Programmer's Guide* v14.2, H-0010-20-43061-2, 03-2020
- Mindray *Communication Protocol Interface Guide — A-Series Anesthesia System*, PN 046-012418-00
- Dräger *Protocol Definition RS 232 MEDIBUS* Rev. 6.00, Best.-Nr. 90 28 258
- Dräger *MEDIBUS.X Profile Definition*, Best.-Nr. 9052608, Edition 20, 2022-04
- Dräger *MEDIBUS for Dräger Intensive Care Devices* und *… Pediatric Devices* (90 29 205)
- Philips *IntelliVue Data Export Interface Programming Guide*, Dok. 453564588011
- Datex-Ohmeda *COM 1.0 Serial Protocol*, Version 1.5 (14.08.2001)
- IHE *Devices Technical Framework Vol. 2* (PCD-01/DEC), Rev. 10.0, 2024-11-04
- ISO/IEEE 11073-10101 (MDC-Nomenklatur)

**Gerätehandbücher mit Schnittstellenkapitel**
- Mindray WATO EX-35Vet Operator's Manual — Rückseite „Communication Ports", Kap. 4.4.2
- Mindray ePM 12M Vet H-046-021061-00 · iPM12 Vet H-046-008141-00 · iMEC8 Vet H-046-008143-00
- Mindray VS-900 Operator's Manual Rev. 15.0, Kap. 14.3 („Data Send Method")
- Bionet BM7Vet Pro User's Manual Rev. 3.x · BM Vet Elite Series IFU · BM5VET Rev. 2.53
- EDAN iM50/iM60/iM70/iM80/M50/M80 User Manual, P/N 01.54.457239, Kap. 4.7
- Eickemeyer LifeVet M User Manual, Art. 321870 (= EDAN 01.54.455558) · LifeVet 10M Art. 321915
- Smiths Medical *Advisor Vital Signs Monitor Operation Manual — Veterinary Advisor*, Kap. 14
- Midmark 003-10464-00 (Multiparameter) · 003-2647-00 (Cardell Touch) · 003-2981-00 (Insight) · 21-02-0286 (Cardell 9401/9402)
- Comen C50-V/C80-V/C86-V Instruction Manual · Mediana YM6000 Service Manual
- Dräger Perseus A500 IFU · Fabius Tiro Technical Service Manual 6020.002 Rev. B · Primus IFU SW 4.5n

**Offener Quellcode als Referenzimplementierung**
- `wokai/xenon` — MEDIBUS über die serielle Schnittstelle, **in Node.js**; direkt übertragbar
- `mdpnp/mdpnp` (OpenICE) — reifste öffentliche MEDIBUS-Implementierung, dazu `MindrayA5App`
- `patnatha/DownVent` — Datex-Ohmeda 7900, begleitet von einer begutachteten Veröffentlichung (PMC10805220)
- `rasmuxo/apollo-sim` — MEDIBUS.X-Simulator; erlaubt Tests ohne Gerät
- VSCapture (SourceForge) — Mindray HL7, GE S/5, Dräger; schreibt CSV, die VetStation mitliest

**Sicherheit**
- CISA Fact Sheet *„Contec CMS8000 Contains a Backdoor"*, TLP:CLEAR, 30.01.2025

---

## 9. Was in dieser Recherche offen blieb

- Zwei Agenten (Endsynthese und eine Gegenprüfung) fielen ins Sitzungslimit. Die Rohdaten aller
  acht Cluster sind vollständig; die Zusammenführung steht in diesem Dokument und im Katalog.
- **Fritz Stephan GmbH** konnte gar nicht mehr recherchiert werden.
- Für **Vetland, Burtons-Eigenmarken, Henry-Schein- und Kruuse-Rebrands** waren keine technischen
  Unterlagen auffindbar — dort muss zuerst der eigentliche Hersteller bestimmt werden.
- Kein einziges öffentliches Projekt liest ein **Veterinär**-Narkose- oder Beatmungsgerät aus.
  Für Humangeräte gibt es mehrere.

Siehe auch: [GERAETE-KATALOG.md](GERAETE-KATALOG.md) · [MINDRAY-HL7.md](MINDRAY-HL7.md) ·
[DEVICE-ADAPTERS.md](DEVICE-ADAPTERS.md)
