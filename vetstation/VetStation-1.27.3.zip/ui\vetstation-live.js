/*
 * vetstation-live.js — VetStation Narkose-Ueberwachung (Live-Schicht ueber der Anaesthesie-App).
 * - erkennt jedes eingeschaltete/verbundene Geraet automatisch und oeffnet je Patient EIN Fenster
 *   (komplette Anaesthesie-App, live gefahren: Monitor + "Brain"-Empfehlungen + Geraete-Soll);
 * - Benutzer kann Fenster frei oeffnen/schliessen (Multifunktion);
 * - fuehrt ein OP-Protokoll und exportiert Parameter + Protokoll als PDF;
 * - blendet Fremd-Menues aus (nur Anaesthesie). Read-only: nie Geraetebefehle.
 */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var VS = window.VS || {};
  var grid = $('#vsxGrid');
  var state = { patients: [], devices: [] };
  var windows = {};          // patientKey -> { wrap, frame, head, drive, switched }
  var closed = {};           // patientKey -> true (vom Benutzer geschlossen)
  var log = {}, meta = {};   // Protokoll je Patient + Stammdaten
  var ws = null, wsReady = false;
  var pairingOpen = false, pairSel = {};   // Geräte-/Koppel-Overlay (§6)
  // Schonfrist, bevor ein Fenster wegen fehlender Daten geschlossen wird. Ein kurzer Aussetzer
  // (Kabel wackelt, Gerät sendet eine Lücke) darf das Fenster NICHT zerstören — das Neuaufbauen
  // würde die Anästhesie-App im iframe komplett neu laden und die Anzeige unterbrechen.
  var GRACE_MS = 20000;
  /*
   * FESTE PLAETZE STATT DAUERNDEM UMSORTIEREN (Praxis-Befund 28.08.2026).
   *
   * Bis heute stand in refresh() `pats.sort(nach priority)` und unmittelbar danach wurde daraus
   * die CSS-Eigenschaft `order` JEDES Fensters geschrieben. Beides lief an jeder
   * patients-Nachricht. Wie oft das ist, wurde nachgesehen statt geschaetzt:
   *   bridge/src/server.js:629      BROADCAST_MS   = 350 ms Grundtakt
   *   bridge/src/server.js:715-728  MIN_ABSTAND_MS =  40 ms Sofort-Rundruf bei registry.onNeu
   *   bridge/src/registry.js:996    onNeu feuert bei JEDEM verarbeiteten Geraete-Frame
   * An einem EKG mit 500 Hz laeuft refresh() also bis zu 25× je Sekunde. Die aelteren Kommentare
   * in dieser Datei sagen "500-ms-Takt" bzw. "2×/s" — das ist um Faktor ~12 veraltet.
   *
   * Und `priority` ist keine Stufe, sondern eine Fliesskommazahl direkt aus den Messwerten: ohne
   * Kreuzbefund gilt brain.js:155  min(4, 1 + single[0].score/4)  mit
   * score = Gewicht * (1 + (Bandgrenze - Messwert)/Bandgrenze). Nachgerechnet fuer zwei Hunde
   * (Baender hr [60,140], spo2 [95,100]):
   *   Patient A, HF 30   -> score 6,0000  -> priority 2,50000
   *   Patient B, SpO2 94 -> score 6,0632  -> priority 2,51579
   *   Patient A, HF 29   -> score 6,0667  -> priority 2,51667
   * EIN Herzschlag dreht die Reihenfolge um. Es braucht keinen Alarm, der kommt und geht.
   * Im Betrieb haengen ausserdem zwei Monitore am selben Tier und melden dafuer JEDER eine
   * eigene Patientenkennung — zwei Fenster mit zwei Teilmengen derselben Messung, deren
   * Prioritaeten deshalb staendig kreuzen. (Die beiden gemessenen Kennungen standen hier bis
   * zum 29.08.2026 im Klartext. Sie sind echte Fallnummern von Patienten dieser Praxis, und
   * diese Datei faehrt im oeffentlichen Update-Zip mit — dieselbe Grenze wie in 1.25.1, nur
   * eine Ebene tiefer: nicht im Bericht, sondern im Quelltext. Fuer die Begruendung des
   * Umbaus braucht es die Zahlen nicht, nur die Tatsache zweier Kennungen.)
   *
   * Der Tierarzt steht waehrenddessen im OP vor dem Schirm und verliert das Fenster, das er
   * gerade liest. Deshalb: die Platznummer wird EINMAL vergeben — beim ersten Auftauchen des
   * Patienten, in der Reihenfolge, in der die Bridge ihn meldet — und bleibt, solange es ihn
   * gibt. Neue Patienten kommen hinten dran. Umgeordnet wird nur noch auf Knopfdruck
   * (ordneNachDringlichkeit), nie von selbst.
   */
  var plaetze = {};          // patientKey -> Platznummer (klein = weiter vorn)
  var platzZaehler = 0;
  /*
   * GEFAHR STEHT STILL (Wunsch 28.08.2026).
   *
   * Der Notfall wird AN ORT UND STELLE gezeigt: roter Patientenname im Kopf des betroffenen
   * Fensters, daneben der wichtigste Befund im Klartext. Kein Blinken, kein Wandern, kein
   * Groessenwechsel.
   *
   * WARUM EIN HALTEWERT UND KEINE reine "sev >= 4"-Abfrage: refresh() laeuft bis 25×/s (oben
   * gemessen), und der Befund entsteht aus stetigen Messwerten. Ein Wert, der um seine Schwelle
   * herum zittert, wuerde die Farbe im selben Takt an- und ausschalten — das IST Blinken, nur
   * unregelmaessig, und genau das soll hier aufhoeren. Rot bleibt deshalb nach dem letzten
   * gefaehrlichen Takt noch GEFAHR_HALTE_MS stehen.
   *
   * 8 s, weil ein Blick vom Tier zum Schirm und zurueck ungefaehr so lange dauert: kuerzer, und
   * die Meldung ist wieder weg, bevor sie gelesen wurde; laenger, und eine wirklich behobene
   * Gefahr stuende unangenehm lange rot da. Bewusst KUERZER als GRACE_MS (20 s): ein Fenster,
   * das sich schliesst, waehrend es noch rot leuchtet, waere die schlechtere Ueberraschung.
   *
   * Schwelle sev >= 4: das sind genau die Stufen, die prTxt "DRINGEND" und "CPR" nennt, und sie
   * entstehen ausschliesslich aus den Kreuzregeln R1-R5 (brain.js:71-105) — Kreislaufstillstand,
   * Kammertachykardie, ventrikulaere Extrasystolen, Bradykardie bei zu tiefer Narkose. Ein
   * Einzelwert-Befund traegt fest sev 2 (brain.js:175) und faerbt hier also nichts ROT.
   *
   * NACHGEMESSEN, GLEICHER TAG: DER HALTEWERT WAR ZU HOCH ANGESETZT (28.08.2026).
   *
   * Die Schwelle 4 haelt nur den roten Namen ruhig. Sichtbar wechselt die Kopfzeile aber schon
   * eine Stufe darunter, denn prTxt/priColor unterscheiden bereits bei 3:
   *     sev 2 -> "stabil"  gruen  #35d69a
   *     sev 3 -> "ACHTUNG" gelbgruen #a3e635
   * sev 3 entsteht aus den Kreuzregeln R5 (Hypotonie bei tiefer Narkose) und R6 (Bronchospasmus,
   * brain.js:92-105) — beide haengen an stetigen Messwerten (map, capnoShape) und kommen und
   * gehen. Nachgestellt mit sev 2<->3 ueber 40 Takte: 39 Kopfzeilen UND 39 Patientenleisten
   * wurden neu geschrieben. Auf dem Schirm heisst das: der 4-px-Randstreifen der Kachel wechselt
   * die Farbe, und weil "ACHTUNG" ein Zeichen breiter ist als "stabil", rutschen alle Kacheln
   * rechts davon waagerecht mit. Genau das "Belaestigen der Augen", nur eine Stufe tiefer.
   *
   * Deshalb gilt der Haltewert seit heute fuer JEDE angezeigte Stufe, nicht erst ab 4:
   * hinauf sofort (eine Verschaerfung darf nie warten), hinunter erst, wenn die niedrigere
   * Stufe GEFAHR_HALTE_MS lang ununterbrochen anlag. GEFAHR_SEV entscheidet ab jetzt nur noch,
   * ab wann der Name rot wird und der Alarmtext daneben steht.
   *
   * AUCH DER BEFUNDTEXT WIRD GEHALTEN, und zwar nach derselben Regel: wechseln zwei GLEICH
   * schwere Befunde einander ab, bliebe sonst zwar die Farbe stehen, aber die Schrift zappelte
   * im 40-ms-Raster — dieselbe Unruhe, nur kleiner. Ein anderer Befund gleicher Schwere loest
   * den gezeigten deshalb erst ab, wenn dieser GEFAHR_HALTE_MS lang gar nicht mehr gemeldet
   * wurde; eine echte Verschaerfung kommt dagegen sofort durch. (Die alte Fassung ersetzte den
   * Text NUR bei Verschaerfung — ein still abgeloester Befund gleicher Schwere waere damit
   * unbegrenzt lange stehen geblieben.)
   */
  var GEFAHR_SEV = 4;
  var GEFAHR_HALTE_MS = 8000;
  // patientKey -> { sev: gezeigte Stufe, sevBis: fruehestes Absenken,
  //                 top: gezeigter Befund (oder null), topBis: fruehestes Ersetzen des Textes }
  var anzeige = {};
  // Identität eines Patienten über seine GERÄTE (stabil, auch wenn der Patientenschlüssel wechselt).
  function devKey(p) {
    return (p.devices || []).map(function (d) { return d.deviceId; }).sort().join('|');
  }
  // Perf (§2): nicht sichtbare Fenster pausieren (rAF im iframe stoppen) via postMessage.
  var visObs = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      var w = en.target.__vsw; if (!w || !w.frame || !w.frame.contentWindow) return;
      var show = en.isIntersecting && en.intersectionRatio > 0.05;
      try { w.frame.contentWindow.postMessage({ vsMon: show ? 'resume' : 'pause' }, '*'); } catch (e) {}
    });
  }, { threshold: [0, 0.06, 0.5] }) : null;

  function A() { return window.ANAES; }

  // ---------- WebSocket ----------
  function connect() {
    var proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(proto + '://' + location.host + '/ws');
    ws.onopen = function () { wsReady = true; setConn(true, 'verbunden'); };
    ws.onclose = function () { wsReady = false; setConn(false, 'getrennt – neu…'); setTimeout(connect, 1500); };
    ws.onerror = function () { setConn(false, 'Fehler'); };
    ws.onmessage = function (e) {
      var m; try { m = JSON.parse(e.data); } catch (_) { return; }
      // Bewusst KEIN refresh() im devices-Zweig: daran haengt der komplette Fensterlebenszyklus
      // samt iframes. renderBar() zeichnet nur die Leiste neu - das genuegt fuer den Leerzustand.
      if (m.type === 'devices') { state.devices = m.devices || []; updateDeviceBtn(); updateTestBanner(); if (!state.patients.length) renderBar([]); if (pairingOpen) renderPairing(); }
      else if (m.type === 'patients') { state.patients = m.patients || []; refresh(); }
      else if (m.type === 'diag') { if (VS.feedback) VS.feedback.diag(m.event); if (window.VSADMIN && window.VSADMIN.onDiag) window.VSADMIN.onDiag(m.event); }
      /*
       * NACHBARSAELE — und der ganze Zweig endet hier.
       *
       * Bewusst wird state.patients und state.devices NICHT angefasst. Daran haengt der gesamte
       * eigene Betrieb: refresh() oeffnet und schliesst Fenster, drive() faehrt die Narkose-App,
       * renderPairing() bietet Geraete zum Koppeln an, doExportPDF() druckt das Narkoseprotokoll.
       * Wuerde ein fremder Patient dort einsickern, muesste JEDE dieser Stellen einzeln pruefen,
       * ob der Patient ueberhaupt zu diesem PC gehoert — und eine davon wuerde es vergessen.
       * Ein eigener, abgeschlossener Zweig ist die einzige Bauform, die die Zusage "nur Ansicht"
       * wirklich haelt: die Nachricht geht ausschliesslich an ui/vetstation-nachbarn.js.
       */
      else if (m.type === 'fremd') { state.fremd = m; if (window.VetNachbarn) window.VetNachbarn.setze(m); }
    };
  }
  function send(o) { if (wsReady) try { ws.send(JSON.stringify(o)); } catch (_) {} }
  function setConn(ok, t) { var d = $('#vsxDot'); if (d) d.className = 'vsx-dot ' + (ok ? 'on' : 'off'); var s = $('#vsxConn'); if (s) s.textContent = t; }

  // ---------- Bewertung ----------
  function assess(p) {
    /*
     * KEIN ERSATZWERT AN DIESER STELLE (Befund 17.08.2026).
     *
     * Hier stand "species: p.species || 'hund', weightKg: p.weightKg || 10". Das war doppelt
     * und schaedlich zugleich:
     *
     *   DOPPELT, weil brain.js dieselben Rueckfaelle selbst hat (brain.js:assess() setzt
     *   "var sp = patient.species || 'hund'" und "var wt = patient.weightKg || 10"). Das
     *   Urteil aendert sich durch diese Zeile also nicht - nachgemessen mit HF 38, SpO2 88,
     *   etCO2 20, MAP 52: fuer 10 kg, 3 kg, 35 kg und null kam dreimal dasselbe heraus
     *   (Prioritaet 2,67, oberster Befund "End-CO2 zu niedrig", null Kreuzbefunde).
     *
     *   SCHAEDLICH, weil brain.js sich MERKT, woher die beiden Angaben kommen:
     *       annahmen: { species: patient.species ? 'gemeldet' : 'ersatz',
     *                   weightKg: patient.weightKg ? 'gemeldet' : 'ersatz' }
     *   Wer hier vorher 'hund' und 10 einsetzt, laesst dieses Merkmal IMMER "gemeldet" sagen -
     *   auch wenn kein Geraet je eine Tierart oder ein Gewicht geliefert hat. Die Bewertung
     *   verliert damit die einzige Stelle, an der sie eine Annahme von einer Messung
     *   unterscheiden koennte.
     *
     * Also wird durchgereicht, was wirklich da ist. Fehlt etwas, faellt brain.js weiterhin
     * selbst zurueck - nur weiss es dann, dass es ein Rueckfall war.
     *
     * OFFEN, ausdruecklich benannt: "annahmen" wird von brain.js zurueckgegeben, aber von
     * NIEMANDEM gelesen (geprueft am 17.08.2026 ueber alle .js und .html). Es waere der
     * richtige Platz fuer einen Hinweis im PDF-Kopf und in der Saalkachel - dann stuende dort
     * "Gewicht: Ersatzwert" statt einer Zahl, die wie eine Messung aussieht.
     */
    var pat = Object.assign({ species: p.species, weightKg: p.weightKg, isoPct: p.isoPct }, p.vitals || {});
    /*
     * DER AUS DER ECHTEN EKG-KURVE ERKANNTE RHYTHMUS speist die Zwischenfall-Logik (23.07.2026).
     * Liefert das Geraet einen EKG-Streifen und die Analyse einen belastbaren Rhythmus (z. B.
     * "vorzeitige Schlaege" -> ves, "Kammertachykardie" -> vtach), wird der der Bewertung
     * zugrunde gelegt - so entsteht die Empfehlung aus dem, was das Herz WIRKLICH tut, nicht aus
     * einer nachgezeichneten Kurve. Nur bei belastbarer Analyse; sonst bleibt es beim Gerätewert.
     */
    if (p.ekgAnalyse && p.ekgAnalyse.brauchbar && p.ekgAnalyse.rhythmus && p.ekgAnalyse.rhythmus.id) {
      pat.ekgRhythm = p.ekgAnalyse.rhythmus.id;
    }
    try { return VS.brain.assess(A(), pat, { iso: p.isoPct }); } catch (e) { return { top: null, cross: [], priority: 0 }; }
  }
  function priColor(sev) { return sev >= 5 ? '#ff4d4d' : sev >= 4 ? '#ff8c3c' : sev >= 3 ? '#a3e635' : '#35d69a'; }
  function prTxt(sev) { return sev >= 5 ? 'CPR' : sev >= 4 ? 'DRINGEND' : sev >= 3 ? 'ACHTUNG' : 'stabil'; }
  /*
   * DRITTER ZUSTAND: "KEINE WERTE" (22.07.2026).
   * Bisher gab es nur die Stufen CPR/DRINGEND/ACHTUNG/stabil. Ein Patient, von dem GAR KEIN
   * Messwert vorliegt, landete damit zwangslaeufig bei sev 0 - also gruen und "stabil". Genau das
   * stand am Praxis-PC auf dem Bildschirm, waehrend am Monitor kein einziger Fuehler angelegt war.
   * Grau statt Gruen, und ein Wort, das keine Sicherheit vortaeuscht.
   */
  /*
   * Der zweite Parameter ist die ANGEZEIGTE Stufe (28.08.2026). Sie kann hoeher sein als die
   * gerade gemessene, weil eine erkannte Gefahr GEFAHR_HALTE_MS lang gehalten wird — sonst
   * wechselte zwar der Name nicht mehr die Farbe, wohl aber das Zustandswort daneben, und
   * damit flackerte dieselbe Kopfzeile weiter. Fehlt der Parameter, gilt wie bisher der Befund.
   */
  function zustandFarbe(res, sev) { return res && res.keineDaten ? '#8b93a7' : priColor(sev != null ? sev : (res && res.top ? res.top.sev : 0)); }
  function zustandText(res, sev) { return res && res.keineDaten ? 'KEINE WERTE' : prTxt(sev != null ? sev : (res && res.top ? res.top.sev : 0)); }
  function spOf(id) { return (A().species || []).find(function (s) { return s.id === id; }) || { icon: '🐾', name: id || '?' }; }
  // Geschlecht ausschreiben: das Geraet sendet in PID-8 den Code (F/M/U); im Bild und im Protokoll
  // soll "weiblich"/"maennlich" stehen (wie am Monitor selbst: W/M) — nicht das rohe "F".
  function geschlechtText(g) {
    if (g == null || g === '') return null;
    var s = String(g).trim().toUpperCase();
    if (/^(W|F|WEIBLICH|FEMALE)$/.test(s)) return 'weiblich';
    if (/^(M|MALE|MÄNNLICH|MAENNLICH)$/.test(s)) return 'männlich';
    if (/^(U|UNKNOWN|UNBEKANNT|O|OTHER)$/.test(s)) return 'unbekannt';
    return String(g);
  }
  // Geb.datum: das Geraet sendet HL7-Format "20100405" (YYYYMMDD) - lesbar als TT.MM.JJJJ schreiben
  // (wie am Monitor "05-04-2010"). Uhrzeit-Anhaenge (falls vorhanden) werden ignoriert.
  function datumText(s) {
    if (s == null || s === '') return null;
    var m = String(s).match(/^\s*(\d{4})(\d{2})(\d{2})/);
    if (m) return m[3] + '.' + m[2] + '.' + m[1];
    return String(s);
  }
  /*
   * ALTER AUS DEM GEBURTSDATUM (Wunsch 24.07.2026): Das Geraet liefert in der Patientenverwaltung
   * das Geb.datum (PID-7, HL7 "YYYYMMDD"). Die Station rechnet daraus das Alter und schreibt es dem
   * Patienten OBEN an die Leiste. Tiermedizinisch lesbar: ab 2 Jahren in Jahren, sonst Monate, sonst
   * Wochen/Tage. Ein Datum in der Zukunft oder aelter als 120 Jahre (z. B. Platzhalter 1900) gilt als
   * Fehleingabe -> nichts anzeigen (nie ein Alter erfinden).
   */
  function alterAusGeb(s) {
    if (s == null || s === '') return null;
    var m = String(s).match(/^\s*(\d{4})(\d{2})(\d{2})/);
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    var geb = new Date(y, mo - 1, d);
    if (isNaN(geb.getTime()) || geb.getFullYear() !== y || (geb.getMonth() + 1) !== mo || geb.getDate() !== d) return null;
    var now = new Date();
    if (geb > now) return null;
    var monate = (now.getFullYear() - y) * 12 + (now.getMonth() - (mo - 1));
    if (now.getDate() < d) monate--;
    if (monate < 0) return null;
    var jahre = Math.floor(monate / 12);
    if (jahre > 120) return null;
    if (jahre >= 2) return jahre + ' J';
    if (monate >= 1) return monate + ' Mon';
    var tage = Math.floor((now - geb) / 86400000);
    var wochen = Math.floor(tage / 7);
    if (wochen >= 1) return wochen + ' Wo';
    return Math.max(0, tage) + ' Tg';
  }
  // Anzuzeigendes Alter: bevorzugt aus dem Geburtsdatum berechnet, sonst das vom Geraet gelieferte
  // Alter (akte.alter, falls der Monitor es als Fertigwert schickt). Sonst null.
  function alterText(p) {
    var a = alterAusGeb(p && p.gebDatum);
    if (a) return a;
    var ak = (p && p.akte) || {};
    return (ak.alter != null && ak.alter !== '') ? String(ak.alter) : null;
  }
  /*
   * DER VERDAMPFERWERT IM FENSTERKOPF BEKOMMT EIN TOTBAND (Befund 28.08.2026).
   *
   * Gemessen: bei ruhigem Befund und einem isoPct, das nur zwischen 1,4 und 1,5 wandert, wurden
   * in 40 Takten 39 Kopfzeilen komplett neu geschrieben — die Zahl steht im Markup, also schlug
   * `w.__headHtml !== html` bei jedem Zehntel an, und mit der Zeile wurden 👍/👎/✕ ausgetauscht.
   * Die Quelle wackelt wirklich in Zehnteln: bridge/src/adapters/simulator.js:115 rundet den Wert
   * auf eine Nachkommastelle, und ein echter Gasmonitor liefert eine GEMESSENE Konzentration.
   *
   * Der Kopf ist ein Schild (Tierart · Rasse · kg · Iso), kein Messgeraet. Deshalb bleibt die
   * einmal gezeigte Zehntelzahl stehen, bis der neue Wert um mindestens ISO_TOTBAND davon
   * abweicht — also um zwei Anzeigeschritte. Ein Zittern um ein Zehntel kommt damit gar nicht
   * mehr an, ein wirkliches Verstellen des Verdampfers sofort.
   *
   * WICHTIG: das gilt NUR fuer diese eine Beschriftung. Der rohe Wert geht unveraendert in die
   * Bewertung (assess), in das Narkoseprotokoll (logSnapshot, `iso: p.isoPct`), ins PDF und an
   * das Geraetebild im Fenster — dort wird nichts geglaettet.
   *
   * Der Merker haengt am FENSTER (w.__isoZeig), nicht am Patienten: er soll mit dem Fenster
   * entstehen und mit ihm verschwinden.
   */
  var ISO_TOTBAND = 0.2;
  function isoRuhig(w, roh) {
    if (roh == null || isNaN(roh)) { w.__isoZeig = null; return null; }
    if (w.__isoZeig == null || Math.abs(roh - w.__isoZeig) >= ISO_TOTBAND) {
      w.__isoZeig = Math.round(roh * 10) / 10;
    }
    return w.__isoZeig;
  }

  // ---------- feste Plaetze (28.08.2026, Begruendung oben bei `plaetze`) ----------
  // Vergibt einmalig eine Platznummer und gibt sie ab dann unveraendert zurueck. Der Aufruf
  // MUSS ausserhalb eines Sortiervergleichs stehen: wer erst beim Vergleichen vergibt, macht die
  // Vergabe von der Vergleichsreihenfolge abhaengig — also wieder vom Messwert.
  function platzVon(k) {
    if (plaetze[k] == null) { plaetze[k] = platzZaehler; platzZaehler++; }
    return plaetze[k];
  }
  function nachPlatz(a, b) { return platzVon(a.patientKey) - platzVon(b.patientKey); }
  /*
   * ordneNachDringlichkeit — die EINZIGE Stelle, die die Reihenfolge noch aendert, und sie
   * verlangt dafuer einen Knopfdruck (Knopf "↕ Nach Dringlichkeit ordnen" in ui/index.html).
   * Danach steht das Bild wieder still: die neu vergebenen Plaetze sind ab da wieder fest.
   */
  function ordneNachDringlichkeit() {
    var pats = state.patients.slice();
    pats.forEach(function (p) { if (!p._res) p._res = assess(p); });
    pats.sort(function (a, b) { return (b._res.priority || 0) - (a._res.priority || 0); });
    var neu = {}, n = 0;
    pats.forEach(function (p) { if (neu[p.patientKey] == null) { neu[p.patientKey] = n; n++; } });
    // Fenster in der Schonfrist melden gerade keinen Patienten mehr (Geraet wackelt). Sie duerfen
    // ihren Platz trotzdem nicht verlieren, sonst springt ausgerechnet das Fenster, dessen
    // Verbindung ohnehin schon stoert. Sie haengen sich hinten an, untereinander in der
    // bisherigen Reihenfolge.
    Object.keys(plaetze).sort(function (a, b) { return plaetze[a] - plaetze[b]; }).forEach(function (k) {
      if (neu[k] == null) { neu[k] = n; n++; }
    });
    plaetze = neu; platzZaehler = n;
    refresh();
    flashToast('Fenster einmalig nach Dringlichkeit geordnet — sie bleiben ab jetzt wieder stehen.');
  }

  // ---------- Gefahr an Ort und Stelle (28.08.2026, Begruendung oben bei `anzeige`) ----------
  /*
   * Fuehrt die ANGEZEIGTE Stufe und den angezeigten Befund je Patient nach. Genau einmal je
   * Takt aufgerufen (aus refresh()), niemals aus dem Zeichnen heraus — sonst verlaengerte jedes
   * Neuzeichnen den Haltewert um weitere 8 s und die Anzeige kaeme nie wieder herunter.
   */
  function anzeigeNachfuehren(p) {
    var k = p.patientKey, jetzt = Date.now();
    var top = (p._res && p._res.top) || null;
    var sev = top ? top.sev : 0;
    var a = anzeige[k];
    if (!a) { anzeige[k] = { sev: sev, top: top, sevBis: jetzt + GEFAHR_HALTE_MS, topBis: jetzt + GEFAHR_HALTE_MS }; return; }
    if (sev >= a.sev) {
      // Verschaerfung sofort — mit ihrem Text. Gleiche Stufe: nur den Haltewert auffrischen.
      if (sev > a.sev) { a.sev = sev; a.top = top; a.topBis = jetzt + GEFAHR_HALTE_MS; }
      a.sevBis = jetzt + GEFAHR_HALTE_MS;
    } else if (jetzt >= a.sevBis) {
      // Entwarnung erst, wenn die niedrigere Stufe GEFAHR_HALTE_MS lang ununterbrochen anlag.
      a.sev = sev; a.top = top;
      a.sevBis = jetzt + GEFAHR_HALTE_MS; a.topBis = jetzt + GEFAHR_HALTE_MS;
    }
    // Der TEXT getrennt: solange derselbe Befund weiter gemeldet wird, bleibt er stehen. Ein
    // ANDERER Befund gleicher Schwere loest ihn erst ab, wenn der gezeigte GEFAHR_HALTE_MS lang
    // ausgeblieben ist (Begruendung oben bei `anzeige`).
    if (top && a.top && top.title === a.top.title) { a.topBis = jetzt + GEFAHR_HALTE_MS; }
    else if (top && top.sev === a.sev && (!a.top || jetzt >= a.topBis)) { a.top = top; a.topBis = jetzt + GEFAHR_HALTE_MS; }
  }
  // Nur LESEN — beides. Die gezeigte Stufe (Farbe, Zustandswort) und, davon getrennt, die
  // GEFAHR (roter Name + Alarmtext): letztere gibt es nur ab GEFAHR_SEV und nur mit Befund.
  function zeigeStufe(k, sev) { var a = anzeige[k]; return a ? a.sev : (sev || 0); }
  function gefahrJetzt(k) {
    var a = anzeige[k];
    return (a && a.sev >= GEFAHR_SEV && a.top) ? { sev: a.sev, top: a.top, text: a.top.title || prTxt(a.sev) } : null;
  }

  // ---------- zentrale Aktualisierung ----------
  function refresh() {
    var pats = state.patients.slice();
    // ZUERST die Plaetze, und zwar in der Reihenfolge, in der die Bridge die Patienten meldet.
    // Nach dem Sortieren unten waere die Erstvergabe wieder von einem Messwert abhaengig.
    pats.forEach(function (p) { platzVon(p.patientKey); });
    pats.forEach(function (p) { p._res = assess(p); anzeigeNachfuehren(p); });
    /*
     * Diese Liste ist seit 28.08.2026 NUR NOCH die Dringlichkeits-RANGFOLGE. Sie geht ins
     * Protokoll und in den Knopf "nach Dringlichkeit ordnen" — sie stellt die Anzeige nicht mehr
     * um. Genau dieses sort() war ueber die Zeile `w.wrap.style.order = String(i)` weiter unten
     * die Ursache des Springens (Begruendung und Rechnung oben bei `plaetze`).
     */
    pats.sort(function (a, b) { return (b._res.priority || 0) - (a._res.priority || 0); });
    logSnapshot(pats);

    var live = {};
    pats.forEach(function (p) { live[p.patientKey] = 1; });

    // (a) SCHLÜSSELWECHSEL ABFANGEN.
    // Der Patientenschlüssel wird aus der Patienten-ID abgeleitet, ersatzweise aus Tierart+Gewicht,
    // ersatzweise aus der Geräte-ID. Liefert ein Gerät die ID mal mit und mal nicht, wechselt der
    // Schlüssel — und das Fenster würde geschlossen und neu geöffnet, also das iframe neu geladen.
    // Sind die GERÄTE dieselben, ist es derselbe Patient: das vorhandene Fenster wird übernommen.
    pats.forEach(function (p) {
      if (windows[p.patientKey]) return;
      var dk = devKey(p); if (!dk) return;
      for (var alt in windows) {
        if (live[alt] || windows[alt].__devs !== dk) continue;
        windows[p.patientKey] = windows[alt];
        delete windows[alt];
        if (closed[alt]) { closed[p.patientKey] = true; delete closed[alt]; }
        // Platz und Anzeige-Merker (gehaltene Stufe + Befundtext) gehen MIT (28.08.2026). Sonst bekaeme
        // derselbe Patient beim Schluesselwechsel eine neue Platznummer — das Fenster spraenge also
        // genau bei dem Ereignis nach hinten, das dieser Block gerade abfaengt.
        if (plaetze[alt] != null) { plaetze[p.patientKey] = plaetze[alt]; delete plaetze[alt]; }
        if (anzeige[alt]) { anzeige[p.patientKey] = anzeige[alt]; delete anzeige[alt]; }
        break;
      }
    });

    pats.forEach(function (p) {
      if (!closed[p.patientKey]) ensureWindow(p);
      var w = windows[p.patientKey];
      if (w) { w.__devs = devKey(p) || w.__devs; w.__weg = 0; }
    });

    // (b) SCHONFRIST STATT SOFORTIGEM SCHLIESSEN.
    // Fällt ein Gerät kurz aus (genau der Praxisfall bei wackeliger Verbindung), verschwand der
    // Patient sofort, das Fenster wurde zerstört — und beim Wiederkommen komplett neu geladen.
    // Jetzt bleibt das Fenster GRACE_MS stehen und lebt einfach weiter, wenn die Daten zurückkommen.
    var jetzt = Date.now();
    Object.keys(windows).forEach(function (k) {
      if (live[k]) return;
      var w = windows[k];
      if (!w.__weg) { w.__weg = jetzt; return; }        // Verschwinden merken, noch nicht schliessen
      if (jetzt - w.__weg > GRACE_MS) removeWindow(k);
    });
    // offene Fenster aktualisieren
    pats.forEach(function (p) { if (windows[p.patientKey]) { updateHead(windows[p.patientKey], p); drive(windows[p.patientKey], p); } });

    // Fenster an ihren FESTEN Platz setzen.
    //
    // ZWEITER BEFUND AN DERSELBEN STELLE (Praxis-Befund 28.08.2026): hier stand
    // `pats.forEach(function (p, i) { ... style.order = String(i) })` auf der nach `priority`
    // sortierten Liste. Der DOM blieb dabei zwar in Ruhe (siehe unten), die FENSTER aber nicht:
    // sie tauschten bei jeder Prioritaetskreuzung die Plaetze, bis zu 25× je Sekunde. Der
    // Tierarzt steht im OP vor dem Schirm — ein Ueberwachungsbild, das von selbst umspringt, ist
    // dort unbrauchbar. Die Platznummer kommt seither aus platzVon() und haengt an KEINEM
    // Messwert. Die Rechnung dazu steht oben bei `plaetze`.
    //
    // ACHTUNG, HIER LAG DER SCHWERSTE ANZEIGEFEHLER (Praxis-Befund 22.07.2026):
    // Früher stand hier `grid.appendChild(w.wrap)`. Das VERSCHIEBT den Knoten im DOM — und ein
    // verschobenes <iframe> verliert seinen Browsing-Kontext und LÄDT KOMPLETT NEU. Weil das bei
    // JEDER Patienten-Nachricht lief (alle 500 ms), wurden alle Fenster zweimal pro Sekunde neu
    // geladen. Zusammen mit dem load-Handler (der wieder refresh() rief) ergab das eine
    // Endlosschleife. Folge am Praxis-PC: die Oberfläche flackerte ununterbrochen, war nicht
    // bedienbar, und die Anästhesie-App im Fenster kam nie so weit, Werte auszuwerten
    // ("wird nicht bewertet, Daten werden nicht gelesen").
    //
    // #vsxGrid ist ein CSS-Grid. Die Reihenfolge lässt sich deshalb über die CSS-Eigenschaft
    // `order` steuern — rein visuell, OHNE den DOM anzufassen. Das iframe bleibt am Leben.
    // NIEMALS wieder appendChild/insertBefore auf einem Fenster mit iframe verwenden.
    // Ueber ALLE Fenster, nicht ueber `pats`: ein Fenster in der Schonfrist meldet gerade keinen
    // Patienten mehr und behielte sonst einen Platz, den inzwischen ein anderes Fenster hat.
    Object.keys(windows).forEach(function (k) {
      var w = windows[k];
      var o = String(platzVon(k));
      if (w.wrap.style.order !== o) w.wrap.style.order = o;
    });

    var n = Object.keys(windows).length;
    var cols = Math.min(3, Math.max(1, Math.ceil(Math.sqrt(n))));
    // Auch das nur bei echter Änderung: eine CSS-Variable neu zu setzen macht das ganze Raster
    // ungültig und kostet bei jedem Takt unnötig Layout-Arbeit.
    if (grid.__cols !== cols) { grid.style.setProperty('--cols', cols); grid.__cols = cols; }
    // Ebenfalls nur bei echter Aenderung (28.08.2026): ein Schreibzugriff auf `display` macht das
    // Layout ungueltig, auch wenn derselbe Wert daraufsteht.
    var hint = $('#vsxHint'), hd = n ? 'none' : '';
    if (hint && hint.style.display !== hd) hint.style.display = hd;
    // Platz und Anzeige-Merker eines Patienten freigeben, der weder gemeldet wird noch ein Fenster
    // hat. Kommt er spaeter wieder, faengt er hinten an — dann ist es ein neuer Fall.
    Object.keys(plaetze).forEach(function (k) {
      if (!live[k] && !windows[k]) { delete plaetze[k]; delete anzeige[k]; }
    });
    updateTestBanner();
    updateDeviceBtn();
    if (pairingOpen) renderPairing();
    // Auch die Patientenleiste bekommt die FESTE Reihenfolge (Wunsch 28.08.2026, Punkt 4):
    // renderBar() bekam bisher dieselbe nach priority sortierte Liste, die Kacheln wanderten
    // also im selben Takt wie die Fenster — und `host.innerHTML = html` baut sie dabei komplett
    // neu, sodass ein Klick beim Loslassen ins Leere gehen kann.
    renderBar(pats.slice().sort(nachPlatz));
  }
  function updateDeviceBtn() {
    var b = $('#vsxDevices'); if (!b) return;
    var d = state.devices || [], act = d.filter(function (x) { return x.status === 'active'; }).length;
    var t = '🔌 Geräte (' + act + '/' + d.length + ')';
    // Nur bei echter Aenderung schreiben (28.08.2026). Die Zeile lief bisher bei JEDEM refresh,
    // also bis 25×/s. Sie steht in der obersten Leiste und aendert dabei wirklich ihren Inhalt:
    // bridge/src/registry.js:48 stuft ein Geraet nach 5 s ohne Frame auf "standby" zurueck, ein
    // Geraet mit Sendetakt um diese Grenze zaehlt sich also im Sekundentakt hin und her — und
    // weil "(0/1)" und "(1/1)" unterschiedlich breit sein koennen, wandern die Knoepfe daneben.
    if (b.textContent !== t) b.textContent = t;
  }
  // Test-/Demo-Modus erkennen: Simulator-Geräte tragen "(Sim)" im Modellnamen.
  function updateTestBanner() {
    var sim = (state.devices || []).some(function (x) { return /\(Sim\)/i.test(x.model || ''); });
    var tb = $('#vsxTestBanner'); if (tb) tb.hidden = !sim;
    document.documentElement.classList.toggle('vsx-test', sim);
  }

  function renderBar(pats) {
    var host = $('#vsxPatients'); if (!host) return;
    if (!pats.length) {
      /*
       * EHRLICHER LEERZUSTAND (22.07.2026).
       * Auf dem Praxis-PC stand "warte auf Geräte…" DIREKT NEBEN dem Knopf "Geräte (1/1)" - die
       * Oberflaeche widersprach sich also selbst, und genau das las sich als "die App liest
       * ueberhaupt keine Daten". Der Wortlaut bleibt fuer den Fall "wirklich kein Geraet", sonst
       * wird gesagt, was tatsaechlich los ist.
       */
      var d = state.devices || [];
      var leer;
      if (!d.length) {
        leer = '<span class="lead">warte auf Geräte…</span>';
      } else {
        var namen = d.map(function (x) { return esc(x.model || x.deviceId); }).join(', ');
        leer = '<span class="lead">' + namen + ' verbunden — es kommen noch keine Messwerte.</span>' +
          '<span class="muted">Fühler am Tier anlegen (z. B. SpO₂-Clip); Details unter 🔌 Geräte.</span>';
      }
      if (host.__sig !== leer) { host.__sig = leer; host.innerHTML = leer; }
      return;
    }
    var html = '<span class="lead">Geräte/Patienten:</span>' + pats.map(function (p) {
      var sp = spOf(p.species), sev = p._res.top ? p._res.top.sev : 0;
      // Gefahr wird auch hier durch FARBE gezeigt, nicht durch Umsortieren (Wunsch 28.08.2026).
      // Die gehaltene Stufe zaehlt, sonst wechselten Farbe und Zustandswort der Kachel weiter im
      // 40-ms-Raster, waehrend der Name im Fenster daneben ruhig rot steht. Sie gilt seit heute
      // fuer JEDE Stufe (vorher erst ab 4): gemessen wechselten sonst bei sev 2<->3 in 40 Takten
      // 39-mal Randfarbe UND Wort — und weil "ACHTUNG" breiter ist als "stabil", rutschten dabei
      // alle Kacheln rechts davon waagerecht mit.
      var g = gefahrJetzt(p.patientKey);
      var zeigeSev = zeigeStufe(p.patientKey, sev);
      var col = zustandFarbe(p._res, zeigeSev);
      var open = !!windows[p.patientKey];
      // Tierart/Gewicht ohne Angabe NIE stillschweigend ersetzen: "?" sagt die Wahrheit, und die
      // Kopfzeile im Fenster nennt die Folge (Mengenangaben nicht belastbar).
      var art = p.species ? esc(sp.name) : '<span class="fehlt">Tierart ?</span>';
      var gew = p.weightKg ? (p.weightKg + ' kg') : '<span class="fehlt">Gewicht ?</span>';
      // Name des Tieres/Patienten anzeigen, wenn das Geraet ihn liefert (Foto: Nachname/Vorname).
      // Bisher stand hier nur die ID - der am Geraet eingegebene Name war zwar gelesen, aber
      // nirgends sichtbar (Befund 23.07.2026). Genau das las sich als "erkennt keine Patientendaten".
      var titel = p.patientName ? esc(p.patientName) : esc(p.patientId || 'Patient');
      var unterId = (p.patientName && p.patientId) ? '<span class="muted">ID ' + esc(p.patientId) + '</span>' : '';
      // Alter OBEN an die Patientenleiste (Wunsch 24.07.2026) — aus dem am Monitor eingegebenen
      // Geburtsdatum berechnet. Fehlt es, bleibt der Platz leer (nichts erfinden).
      var alterTxt = alterText(p);
      var altBadge = alterTxt ? '<span class="vsx-age" title="' + (p.gebDatum ? 'geboren ' + esc(datumText(p.gebDatum)) : 'Alter') + '">' + esc(alterTxt) + '</span>' : '';
      var kachelTitel = (g ? 'NOTFALL: ' + g.text + ' — ' : '') + (open ? 'Fenster schließen' : 'Fenster öffnen');
      return '<div class="vsx-pat ' + (open ? 'open' : 'closed') + '" data-k="' + p.patientKey + '" data-sev="' + zeigeSev + '" style="--pc:' + col + '" title="' + esc(kachelTitel) + '">' +
        '<span class="ic">' + sp.icon + '</span><b' + (g ? ' class="gefahr"' : '') + '>' + titel + '</b>' + unterId + altBadge +
        '<span class="muted">' + art + ' ' + gew + '</span>' +
        '<span class="pr">' + zustandText(p._res, zeigeSev) + '</span></div>';
    }).join('');

    // Auch die Patientenleiste nur bei echter Änderung neu aufbauen — sie wurde bisher 2×/s
    // komplett ersetzt und flackerte dadurch mit.
    if (host.__sig === html) return;
    host.__sig = html;
    host.innerHTML = html;
    host.querySelectorAll('.vsx-pat').forEach(function (el) {
      el.onclick = function () { var k = el.getAttribute('data-k'); if (windows[k]) { closed[k] = true; removeWindow(k); } else { delete closed[k]; refresh(); } };
    });
  }

  // ---------- Fenster ----------
  function ensureWindow(p) {
    if (windows[p.patientKey]) return;
    var key = p.patientKey;
    var wrap = document.createElement('div'); wrap.className = 'vsx-win';
    var head = document.createElement('div'); head.className = 'vsx-winhead';
    var f = document.createElement('iframe'); f.src = 'app/index.html?kiosk=1'; f.title = 'Anaesthesie';
    // Dieses appendChild ist in Ordnung: das Fenster wird HIER ZUM ERSTEN MAL eingehängt.
    // Gefährlich ist nur das spätere Verschieben eines bereits eingehängten iframes (siehe refresh).
    wrap.appendChild(head); wrap.appendChild(f); grid.appendChild(wrap);
    var w = { wrap: wrap, frame: f, head: head, drive: {}, switched: false };
    // Nach dem Laden NUR DIESES Fenster nachführen. Früher stand hier setTimeout(refresh, 700) —
    // das ordnete alle Fenster neu ein, lud dadurch alle iframes neu, deren load-Handler wieder
    // refresh() rief: eine Endlosschleife, die die Station unbedienbar machte.
    f.addEventListener('load', function () {
      w.switched = false; w.drive = {}; w.__kurvenSig = null; injectKiosk(f); attachManualMeta(w, f);
      setTimeout(function () {
        if (windows[key] !== w) return;                       // Fenster inzwischen geschlossen
        var cur = null;
        for (var i = 0; i < state.patients.length; i++) {
          if (state.patients[i].patientKey === key) { cur = state.patients[i]; break; }
        }
        if (!cur) return;
        if (!cur._res) cur._res = assess(cur);
        updateHead(w, cur); drive(w, cur);
      }, 300);
    });
    windows[key] = w;
    wrap.__vsw = w; if (visObs) visObs.observe(wrap);
    updateHead(w, p);
  }
  function removeWindow(k) { var w = windows[k]; if (!w) return; if (visObs && w.wrap) visObs.unobserve(w.wrap); if (w.wrap.parentNode) w.wrap.parentNode.removeChild(w.wrap); delete windows[k]; }
  function updateHead(w, p) {
    var sp = spOf(p.species), top = p._res.top, sev = top ? top.sev : 0;
    /*
     * DIE GEHALTENE STUFE STEUERT DAS AUSSEHEN (28.08.2026).
     * Rahmenfarbe, Zustandswort und Namensfarbe haengen ab jetzt an derselben Zahl. Vorher
     * sprang der rote Rahmen (.sev5) und das Wort im Takt des Messwerts — bis 25× je Sekunde,
     * siehe Rechnung oben bei `plaetze`. Jetzt geht alles gemeinsam an und gemeinsam wieder aus.
     */
    var g = gefahrJetzt(p.patientKey);
    var zeigeSev = zeigeStufe(p.patientKey, sev);
    var a = anzeige[p.patientKey];
    var zeigeTop = (a && a.top) || null;              // der GEHALTENE Befund, siehe oben
    w.wrap.classList.toggle('sev5', zeigeSev >= 5);
    /*
     * DER DRITTE ZUSTAND KOMMT JETZT AUCH HIER AN (Befund 28.08.2026).
     * Hier stand priColor(zeigeSev)/prTxt(zeigeSev) — also die reinen Stufenfunktionen, die den
     * am 22.07.2026 eingefuehrten Zustand "KEINE WERTE" gar nicht kennen. Nachgestellt mit einem
     * Tier ohne einen einzigen Messwert: in der Leiste stand grau "KEINE WERTE", im Fensterkopf
     * unmittelbar daneben gruen "stabil". Dieselbe Lage, zwei Aussagen, und die falsche war die
     * beruhigende. zustandFarbe/zustandText sagen beides einheitlich (live.js:186-187).
     * Liegt gleichzeitig eine gehaltene Gefahr an, gewinnt fuer Wort und Farbe der Leerbefund
     * (es kommt gerade WIRKLICH nichts an) — der rote Name und der Alarmtext daneben tragen
     * weiterhin, was zuletzt gemessen wurde.
     */
    w.head.style.setProperty('--pc', zustandFarbe(p._res, zeigeSev));
    /*
     * Klinische Rückmeldung nur, wenn eine Empfehlung vorliegt. §14 Kategorie 1.
     *
     * DIE KNOEPFE HINGEN AM ROHEN BEFUND (Befund 28.08.2026): hier stand `top ? … : ''`. Fiel
     * `top` einen einzigen Takt aus — genau der Fall, fuer den der Haltewert gebaut ist —,
     * verschwand das ganze <span class="fb">, `w.__headHtml !== html` schlug an und die
     * KOMPLETTE Kopfzeile wurde neu geschrieben, samt ✕. Nachgestellt mit sev 0<->4 ueber
     * 40 Takte: 40 von 40 Kopfzeilen neu, obwohl Name, Alarmtext und Zustandswort dank
     * Haltewert stillstanden; der einzige Unterschied im Markup war dieser fb-Block. Das ist
     * wortwoertlich der Fehler, den der Kommentar weiter unten fuer erledigt erklaert — ein
     * Klick auf 👍/👎/✕ traf einen Knopf, den es im Moment des Loslassens nicht mehr gab.
     * Also haengt die ANZEIGE der Knoepfe an der gehaltenen Empfehlung.
     */
    var fb = zeigeTop ? '<span class="fb"><button class="fbh" title="Empfehlung war hilfreich">👍</button><button class="fbo" title="Empfehlung nicht passend">👎</button></span>' : '';
    // Name des Tieres in den Fensterkopf (bisher stand hier nur die ID — genau der Punkt
    // "erkennt keine Patientendaten"). Rasse aus der Akte an die Tierart anhaengen, wenn vorhanden.
    var titel = p.patientName ? esc(p.patientName) : esc(p.patientId || 'Patient');
    var ak = p.akte || {};
    var rasse = ak.rasse ? ' · ' + esc(ak.rasse) : '';
    // Alter auch in den Fensterkopf — aus dem Geburtsdatum der Patientenverwaltung berechnet.
    var alterTxt = alterText(p);
    var altBadge = alterTxt ? '<span class="age" title="' + (p.gebDatum ? 'geboren ' + esc(datumText(p.gebDatum)) : 'Alter') + '">' + esc(alterTxt) + '</span>' : '';
    /*
     * DER NOTFALL STEHT AN ORT UND STELLE — im Kopf DIESES Fensters, dort wo die Knoepfe sind
     * (Wunsch 28.08.2026). Der Patientenname wird rot, unmittelbar daneben steht der wichtigste
     * Befund im Klartext. Nur der wichtigste: p._res.top ist bereits der schwerste (brain.js
     * sortiert cross nach sev), und eine Liste in einer 30 px hohen Zeile liest im OP niemand.
     *
     * WARUM ES EINE ZEILE BLEIBT: .vsx-winhead ist 30 px hoch und flex:0 0 auto, das iframe
     * daneben flex:1 1 auto (vetstation-shell.css:97/113). Eine ZWEITE Kopfzeile bei Gefahr
     * wuerde das iframe verkleinern — die App darin rechnet dann mon._resize()/cockpitHoehe()
     * neu, und genau beim Notfall spraenge der Inhalt des Fensters um. Der Alarm ist deshalb ein
     * weiteres Element IN der bestehenden Zeile; die schrumpfbaren Teile (.muted, .alarm) tragen
     * dafuer in vetstation-shell.css min-width:0 und text-overflow, damit rechts weiterhin die
     * Knoepfe stehen und nicht abgeschnitten werden.
     */
    var alarmHtml = g ? '<span class="alarm" title="' + esc(g.text) + '">⚠ ' + esc(g.text) + '</span>' : '';
    var iso = isoRuhig(w, p.isoPct);
    var html = '<span class="ic">' + sp.icon + '</span><b' + (g ? ' class="gefahr"' : '') + '>' + titel + '</b>' + alarmHtml +
      (p.patientName && p.patientId ? '<span class="muted">ID ' + esc(p.patientId) + '</span>' : '') + altBadge +
      '<span class="muted">' + esc(sp.name) + rasse + ' · ' + (p.weightKg || '?') + ' kg' + (iso != null ? ' · Iso ' + iso + '%' : '') + '</span>' +
      '<span class="pr">' + zustandText(p._res, zeigeSev) + '</span>' + fb + '<span class="x" title="Fenster schließen">✕</span>';

    // Die Kopfzeile NUR neu schreiben, wenn sich wirklich etwas geändert hat.
    // Vorher wurde sie bei jedem Takt (2×/s) komplett ersetzt. Das flimmerte sichtbar UND es
    // zerstörte laufend die Knöpfe: ein Klick auf 👍/👎/✕ traf gelegentlich einen Knopf, den es
    // im Moment des Loslassens schon nicht mehr gab.
    if (w.__headHtml !== html) {
      w.__headHtml = html;
      w.head.innerHTML = html;
      w.head.querySelector('.x').onclick = function () { closed[p.patientKey] = true; removeWindow(p.patientKey); refresh(); };
    }
    /*
     * Die Klick-Handler zeigen immer auf die AKTUELLEN Werte, auch wenn das Markup gleich blieb.
     * Und sie nehmen bewusst den ROHEN Befund `top`, nicht den gehaltenen: die Rueckmeldung
     * "hilfreich"/"nicht passend" landet mit der Fallkennung im Verbesserungs-Protokoll
     * (recFeedback -> VS.feedback), sie muss also den Befund meinen, der GERADE anliegt. Nur
     * wenn im Moment des Klicks keiner anliegt (Haltewert), gilt der gehaltene — sonst zeigte
     * ein sichtbarer Knopf ins Leere.
     */
    var fbTop = top || zeigeTop;
    if (fbTop) {
      var bh = w.head.querySelector('.fbh'), bo = w.head.querySelector('.fbo');
      if (bh) bh.onclick = function (e) { e.stopPropagation(); recFeedback('helpful', p, fbTop); };
      if (bo) bo.onclick = function (e) { e.stopPropagation(); recFeedback('override', p, fbTop); };
    }
  }
  function recFeedback(verdict, p, top) {
    try { VS.feedback && VS.feedback.feedback({ verdict: verdict, incident: top && top.incident, title: top && top.title, species: p.species }); } catch (e) {}
    flashToast(verdict === 'helpful' ? '👍 Rückmeldung „hilfreich" gespeichert' : '👎 „nicht passend" gespeichert – fließt in Admin ▸ Verbesserungen');
  }
  var toastTimer = null;
  function flashToast(msg) {
    var t = $('#vsxToast'); if (!t) { t = document.createElement('div'); t.id = 'vsxToast'; document.body.appendChild(t); }
    t.textContent = msg; t.className = 'show';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = ''; }, 2200);
  }
  function injectKiosk(f) {
    try {
      var doc = f.contentDocument || f.contentWindow.document;
      var stl = doc.createElement('style');
      // Nur Anaesthesie: Fremd-Modul-Menue + Hub-Ruecklink ausblenden.
      // ZUSAETZLICH (0.5.1): Auf der Station gibt es die Nachbarmodule NICHT - die liegen nur auf
      // der Webseite. Jeder Link "../canis-*" bzw. "../" landete im SPA-Fallback, und der Tierarzt
      // sass in einer Sackgasse (Edge-Kiosk hat keinen Zurueck-Knopf).
      //  - reine Navigations-Chips: ausblenden
      //  - Verweise INNERHALB eines Befundes: sichtbar lassen (die Begruendung ist klinisch
      //    wertvoll), aber nicht mehr klickbar
      stl.textContent =
        'header a[href*="index.html"],header .back,header a[href="../"]{display:none!important}' +
        '.vp-hamburger,.vp-nav-overlay,.vp-nav-panel,.vp-qlinks{display:none!important}' +
        'a.chip[href^="../"]{display:none!important}' +
        'a[href^="../"]{pointer-events:none!important;cursor:default!important;text-decoration:none!important;opacity:.9}';
      doc.head.appendChild(stl);

      // "(Klick -> Blutwerte-Atlas)" verspricht auf der Station etwas, das es hier nicht gibt.
      // Der Hinweistext wird deshalb entschaerft, sobald ein Befund eingeblendet wird.
      var entschaerfen = function () {
        var g = doc.querySelectorAll('.vp-cause .grt');
        for (var i = 0; i < g.length; i++) {
          var t = g[i].textContent;
          if (t.indexOf('Klick') >= 0) g[i].textContent = t.replace(/\s*\(Klick[^)]*\)/, '');
        }
      };
      entschaerfen();
      if (doc.body && typeof MutationObserver === 'function') {
        new MutationObserver(entschaerfen).observe(doc.body, { childList: true, subtree: true });
      }
    } catch (e) {}
  }

  // ---------- die App live fahren ----------
  function ready(doc) { return !!(doc && doc.readyState === 'complete' && doc.getElementById('tabs')); }
  function fire(el, type) { try { el.dispatchEvent(new (el.ownerDocument.defaultView.Event)(type, { bubbles: true })); } catch (e) {} }
  /*
   * setInput — einen Wert ins virtuelle Geraet schreiben.
   *
   * WICHTIGE AENDERUNG 22.07.2026: val == null hiess bisher "Feld in Ruhe lassen". Das klingt
   * harmlos, war aber die stillste Erfindung der ganzen Station: das virtuelle Geraet belegt seine
   * Felder beim Oeffnen mit den NORMWERTEN der Tierart vor (istInit, Mittelwert des Normbands).
   * Ein Parameter, den kein Sensor misst - etwa die Temperatur ohne Sonde -, blieb damit auf einem
   * unauffaelligen Normwert stehen und war im Bild von einer echten Messung nicht zu unterscheiden.
   * Der Tierarzt sah "38,0 °C", gemessen hatte das niemand.
   *
   * Jetzt wird ein nicht geliefertes Feld GELEERT. Die App zeigt dafuer "– –" - also ehrlich
   * nichts. Nur im Livebetrieb (Kiosk) ist das richtig; im Handbetrieb bleibt die Eingabe des
   * Tierarztes selbstverstaendlich stehen.
   */
  function setInput(doc, key, val) {
    var inp = doc.querySelector('#monInputs input[data-p="' + key + '"]');
    if (!inp) return;
    if (val == null) {
      if (inp.value !== '') { inp.value = ''; fire(inp, 'input'); }
      return;
    }
    if (parseFloat(inp.value) !== val) { inp.value = val; fire(inp, 'input'); }
  }
  /*
   * setInputHold — wie setInput, aber HAELT den letzten Wert, wenn gerade keiner kommt.
   * Fuer NIBP (Blutdruck): der Monitor misst APERIODISCH (nur auf Knopfdruck/Intervall), zwischen
   * den Messungen steht im HL7-Strom KEIN Blutdruck. Mit setInput wuerde die Anzeige nach 1 s wieder
   * auf leer springen; ein echter Monitor haelt den letzten Wert bis zur naechsten Messung.
   * Gilt fuer LifeVet UND uMEC12 gleichermassen (aendert keine Geraetedaten, nur die Anzeige-Haltung).
   */
  function setInputHold(doc, key, val) {
    if (val == null) return;                                  // kein neuer Wert -> alten stehen lassen
    var inp = doc.querySelector('#monInputs input[data-p="' + key + '"]');
    if (!inp) return;
    if (parseFloat(inp.value) !== val) { inp.value = val; fire(inp, 'input'); }
  }
  /*
   * ventModeIdFromName — uebersetzt den vom ECHTEN Narkosegeraet gemeldeten Modusnamen
   * (z. B. "SIMV", "Druckkontrolliert", "VCV", "Manuell") in die Modus-ID der App
   * (vcv/pcv/simv/vs/vsplus/psv/cpap/manual). NUR fuer echte Geraetedaten - so zeigt das
   * virtuelle Geraet exakt den am Geraet eingestellten Modus ("uebernehmen und genau so zeigen").
   * Ein rein allgemeiner Hinweis wie "Kreissystem"/"Circle"/"Auto" ist KEIN spezifischer Modus
   * und liefert null (dann bleibt die Modus-Wahl unangetastet, nur Auto/Manuell wird gesetzt).
   */
  function ventModeIdFromName(name) {
    if (!name) return null;
    var s = String(name).toLowerCase().replace(/[\s._/+-]/g, '');
    if (/(manu|hand|beutel|bag)/.test(s)) return 'manual';
    if (/simv/.test(s)) return 'simv';
    if (/(vsplus|vspls|volumesupportplus|adaptive|adaptiv)/.test(s)) return 'vsplus';
    if (/(psv|pressuresupport|druckunterst)/.test(s)) return 'psv';
    if (/(cpap|peeponly|nurpeep|spontanpeep)/.test(s)) return 'cpap';
    if (/(pcv|druckkontroll|pressurecontrol)/.test(s)) return 'pcv';
    if (/(vcv|volumenkontroll|volumecontrol|ippv|cmv)/.test(s)) return 'vcv';
    if (/(vs|volumesupport|volumensupport)/.test(s)) return 'vs';
    return null;
  }
  function drive(w, p) {
    var doc; try { doc = w.frame.contentDocument || w.frame.contentWindow.document; } catch (e) { return; }
    if (!ready(doc)) return;
    // Tierart/Gewicht NUR treiben, wenn eine Angabe vorliegt (vom Geraet ODER als Handeintrag).
    // Frueher wurde bei fehlender Angabe fest "hund" gesetzt und im 500-ms-Takt erzwungen — dann
    // liess sich die Tierart in der App nicht mehr aendern (jede Wahl wurde sofort zurueckgedreht).
    // w.__driving markiert die programmatische Aenderung, damit sie NICHT als Handeintrag zaehlt.
    w.__driving = true;
    if (p.species) {
      var chip = doc.querySelector('#spChips .sp-chip[data-sp="' + p.species + '"]');
      if (chip && !chip.classList.contains('active')) chip.click();
    }
    /*
     * GEWICHT INS FENSTER — und zwar so, dass das Fenster es auch als GESETZT verbucht.
     *
     * WARUM DIE ZWEITE BEDINGUNG (17.08.2026): das Fenster startet mit 10 im Feld, damit die
     * Regler etwas anzuzeigen haben; erst der 'input'-Zuhoerer setzt state.wtGesetzt. Der
     * frühere Vergleich feuerte nur bei ABWEICHUNG — bei einem Patienten, der wirklich 10 kg
     * wiegt, stand die 10 schon im Feld, es wurde nicht gefeuert, und das Fenster hielt das
     * Gewicht weiter fuer unbekannt. Seit doseLine() ohne gesetztes Gewicht keine Mengen mehr
     * ausgibt, waere daraus ein echter Ausfall geworden: genau beim 10-kg-Tier keine Dosis.
     * Deshalb wird auch dann einmal gefeuert, wenn der Wert stimmt, das Merkmal aber noch fehlt.
     * Danach greift der Abweichungsvergleich wieder, es gibt also kein Dauerfeuer.
     */
    var wt = doc.getElementById('wt');
    /*
     * NICHT HINEINSCHREIBEN, WAEHREND JEMAND TIPPT (Befund 19.08.2026).
     * Dieser Rundruf laeuft alle 500 ms. Wer "28" tippte, sah die Zahl nach einem halben
     * Takt wieder auf den alten Wert springen - fuer den Tierarzt "das Gewicht laesst sich
     * nicht eingeben". Deshalb zwei Sperren: das Feld hat den Fokus, oder es wurde in den
     * letzten 8 Sekunden von Hand angefasst (Zeitstempel setzt attachManualMeta).
     * 8 s sind bewusst reichlich: ein Komma und drei Ziffern dauern laenger als man denkt,
     * und ein zu kurzes Fenster ist genau der Fehler, der hier behoben wird.
     */
    var tippt = false;
    try {
      tippt = (doc.activeElement === wt) ||
        (wt && wt.__vsHandEingabe && (Date.now() - wt.__vsHandEingabe) < 8000);
    } catch (e) {}
    if (wt && p.weightKg != null && !tippt) {
      var fensterZustand = doc.defaultView && doc.defaultView.state;
      var merkmalFehlt = !(fensterZustand && fensterZustand.wtGesetzt);
      if (parseFloat(wt.value) !== p.weightKg || merkmalFehlt) { wt.value = p.weightKg; fire(wt, 'input'); }
    }
    w.__driving = false;
    if (!w.switched) { var tab = doc.querySelector('#tabs .tab[data-view="geraet"]'); if (tab) { tab.click(); w.switched = true; } }
    var v = p.vitals || {};
    setInput(doc, 'hr', v.hr); setInput(doc, 'spo2', v.spo2); setInput(doc, 'etco2', v.etco2);
    setInput(doc, 'rr', v.af); setInput(doc, 'temp', v.temp);
    // NIBP wird gehalten (aperiodisch): letzter Blutdruck bleibt stehen bis zur naechsten Messung.
    setInputHold(doc, 'sys', v.sys); setInputHold(doc, 'dia', v.dia);
    /*
     * BEATMUNGS- UND GASKANAELE (05.08.2026, universelles virtuelles Geraet).
     * FiCO2, Spitzendruck, PEEP, gemessenes Vt, FiO2 und die ausgeatmete Gaskonzentration gehen
     * denselben Weg wie die sieben Monitorwerte. Sie kommen ueber __setMesswerte statt ueber die
     * Eingabefelder, weil nicht jedes Modell jeden Kanal HAT: die App entscheidet anhand des
     * gewaehlten Geraeteprofils, welche davon ueberhaupt existieren, und ignoriert den Rest.
     * null = "kein Geraet liefert das" -> das Feld wird geleert, nie mit einem Normwert gefuellt.
     */
    var winA; try { winA = w.frame.contentWindow; } catch (e) { winA = null; }
    if (winA && typeof winA.__setMesswerte === 'function') {
      /*
       * ALLES WEITERGEBEN, WAS IRGENDEIN GERAET DIESES PATIENTEN LIEFERT.
       *
       * Frueher stand hier eine feste Feldliste. Eine feste Liste ist genau die Bauform, an der
       * im Juli 2026 der Datenport 5510 fast gescheitert ist: sie muss bei jedem neuen Kanal an
       * einer weiteren Stelle nachgetragen werden, und die vergessene Stelle meldet sich nie —
       * das Geraet liefert, und niemand zeigt es an.
       *
       * Jetzt geht JEDER Zahlenwert aus dem zusammengefuehrten Patienten mit (matching.js hat die
       * Werte aller angeschlossenen Geraete bereits rollen-gewichtet vereinigt). Ausgenommen sind
       * nur die sieben, die weiter oben schon ueber die Eingabefelder gesetzt werden — sonst
       * schriebe man denselben Wert auf zwei Wegen. Was die App mit einem Kanal anfaengt, den das
       * gewaehlte Modell nicht hat, entscheidet sie selbst (__setMesswerte filtert).
       */
      var UEBER_EINGABE = { hr: 1, spo2: 1, etco2: 1, af: 1, rr: 1, temp: 1, sys: 1, dia: 1, map: 1, nibp: 1 };
      var mw = {}, hatMw = false;
      Object.keys(v).forEach(function (k) {
        if (UEBER_EINGABE[k]) return;
        var x = v[k];
        if (x != null && typeof x !== 'number') return;      // Formen/Texte (capnoShape, ekgRhythm) gehen andere Wege
        mw[k] = (x == null ? null : x);
        if (x != null) hatMw = true;
      });
      var msig = JSON.stringify(mw);
      // Nur bei echter Aenderung setzen — sonst baut die App die Eingabefelder bei jedem Rundruf neu.
      if (w.__messSig !== msig) { w.__messSig = msig; try { winA.__setMesswerte(mw); } catch (e) {} }
      if (hatMw) w.__hatMess = true;
      /* Die Falluhr laeuft mit dem DATENFLUSS, nicht mit einem Knopf: sobald das erste Paket eines
       * Patienten da ist, laeuft sie. Ein "Fall starten" waere ein zweiter Schalter fuer etwas,
       * das am Geraet bereits gestartet wurde. */
      if (typeof winA.__setFallLauf === 'function') { try { winA.__setFallLauf(p.ts || Date.now()); } catch (e) {} }
    }
    /*
     * MODELLERKENNUNG: das Geraet sagt selbst, was es ist (HL7 MSH-3/OBR-4, sonst der
     * Katalogeintrag aus devices.json). Der Tierarzt soll das Modell nicht suchen muessen.
     * Eine HANDwahl in der App gewinnt immer — das entscheidet die App selbst (__setGeraetProfil).
     */
    if (winA && typeof winA.__setGeraetProfil === 'function') {
      var mon = null, nark = null;
      (p.devices || []).forEach(function (d) {
        if (!d || !d.model) return;
        if (d.role === 'anesthesia' || d.role === 'capno') { if (!nark) nark = d.model; }
        else if (!mon) mon = d.model;
      });
      var gsig = (mon || '') + '|' + (nark || '');
      if (gsig !== '|' && w.__gsig !== gsig) { w.__gsig = gsig; try { winA.__setGeraetProfil({ mon: mon, nark: nark }); } catch (e) {} }
    }
    if (v.ekgRhythm && w.drive.rhythm !== v.ekgRhythm) { var rc = doc.querySelector('#rhythmChips .chip[data-r="' + v.ekgRhythm + '"]'); if (rc) { rc.click(); w.drive.rhythm = v.ekgRhythm; } }

    /*
     * VIRTUELLES NARKOSEGERAET LIVE (22.07.2026).
     *
     * Bisher wurden nur die sieben Monitorwerte uebertragen. Verdampfer, Frischgasfluss und
     * Beatmungsmodus blieben reine HANDBEDIENUNG - das virtuelle Narkosegeraet zeigte also nie,
     * was am echten Geraet eingestellt ist. Das hatte eine Nebenwirkung, die kaum jemand vermutet:
     * die Kreuzregeln R4/R5 (Bradykardie/Hypotonie bei zu tiefer Narkose) pruefen "Verdampfer zu
     * hoch". Ohne uebertragenen Iso-Wert konnten sie GAR NICHT ausloesen.
     *
     * Nur setzen, wenn ein Geraet den Wert wirklich liefert: sonst wuerde die Station die
     * Handeingabe des Tierarztes ueberschreiben - das waere schlimmer als keine Anzeige.
     */
    var win; try { win = w.frame.contentWindow; } catch (e) { win = null; }
    if (win && win.state && win.state.dev) {
      var d = win.state.dev, geaendert = false;
      d.mirror = d.mirror || {};   // welche Felder kommen LIVE vom Geraet (nicht Handeingabe)
      d.__last = d.__last || {};   // zuletzt vom Geraet GELIEFERTE Werte (Flankenerkennung)
      /*
       * FLANKENGETRIEBEN: nur spiegeln, wenn sich der GERAETEWERT gegenueber dem letzten
       * geaendert hat. Dazwischen bleibt die Handeinstellung des Tierarztes stehen (er darf
       * am virtuellen Geraet drehen/waehlen). Aendert sich der Wert AM ECHTEN GERAET erneut,
       * uebernimmt die Station wieder ("uebernehmen und genau so zeigen").
       */
      if (p.isoPct != null && p.isoPct !== d.__last.iso) {
        d.__last.iso = p.isoPct;
        if (d.iso !== p.isoPct) { d.iso = p.isoPct; geaendert = true; }
        d.mirror.iso = true; d.live = true;
      }
      if (p.o2Flow != null && p.o2Flow !== d.__last.o2) {
        d.__last.o2 = p.o2Flow;
        if (d.o2 !== p.o2Flow) { d.o2 = p.o2Flow; geaendert = true; }
        d.mirror.o2 = true; d.live = true;
      }
      if (p.ventMode && p.ventMode !== d.__last.mode) {
        d.__last.mode = p.ventMode;
        // Exakten Modus des echten Geraets spiegeln (nur wenn er als App-Modus existiert).
        var id = ventModeIdFromName(p.ventMode);
        var modes = (win.ANAES && win.ANAES.machine && win.ANAES.machine.ventModes) || [];
        if (id && modes.some(function (m) { return m.id === id; })) {
          if (d.mode !== id) { d.mode = id; geaendert = true; }
          d.mirror.mode = true;
        }
        var autoAn = !/manu|hand/i.test(p.ventMode);
        if (d.auto !== autoAn) { d.auto = autoAn; geaendert = true; }
        d.live = true;
      }
      // Beatmungsparameter spiegeln (Vt, AF, PEEP, Pinsp, Tinsp, I:E, ΔPsupp, Trigger ...).
      if (p.ventParams && typeof p.ventParams === 'object') {
        var sig; try { sig = JSON.stringify(p.ventParams); } catch (e) { sig = null; }
        if (sig && sig !== d.__last.vp) {
          d.__last.vp = sig; d.vp = d.vp || {}; d.mirror.vp = d.mirror.vp || {};
          Object.keys(p.ventParams).forEach(function (k) {
            var val = p.ventParams[k];
            if (val == null) return;
            if (d.vp[k] !== val) { d.vp[k] = val; geaendert = true; }
            d.mirror.vp[k] = true;
          });
          d.live = true;
        }
      }
      // Nur bei echter Aenderung neu zeichnen - sonst flackert das Geraetebild im 500-ms-Takt.
      if (geaendert) {
        try { if (typeof win.renderMachine === 'function') win.renderMachine(); } catch (e) {}
        try { if (typeof win.renderDevCtrl === 'function') win.renderDevCtrl(); } catch (e) {}
        try { if (typeof win.renderVentPanel === 'function') win.renderVentPanel(); } catch (e) {}
        try { if (typeof win.renderVentModes === 'function') win.renderVentModes(); } catch (e) {}
      }
    }

    /*
     * AF-QUELLE anzeigen: die Bridge markiert, ob die Atemfrequenz vom KAPNOGRAPH/Narkosegeraet
     * (genauer, aus der CO2-Wellenform) oder nur vom Monitor (Impedanz) kommt. Der virtuelle
     * Monitor zeigt das am AF-Feld an, damit der Tierarzt die sicherere Quelle erkennt.
     */
    if (win && typeof win.__setAfSource === 'function') { try { win.__setAfSource(p.afSource || null); } catch (e) {} }

    /*
     * ECHTE GERAETEKURVE (statt Nachbildung). Aendert sich die kompakte Kurven-Signatur (neuer
     * Streifen vom Geraet), holt die Station die realen Abtastwerte EINMALIG ueber /api/kurven und
     * gibt sie dem virtuellen Monitor. Ohne echte Kurve bleibt es bei der synthetisierten Anzeige.
     */
    if (win && typeof win.__setRealWave === 'function') {
      var sig = p.kurvenSig || '';
      if (sig && w.__kurvenSig !== sig) {
        w.__kurvenSig = sig;
        fetch('api/kurven?key=' + encodeURIComponent(p.patientKey)).then(function (r) { return r.json(); }).then(function (o) {
          if (windows[p.patientKey] !== w) return;            // Fenster inzwischen geschlossen/getauscht
          var arr = (o && o.kurven) || [], map = {};
          arr.forEach(function (kd) {
            var id = ((kd.code || '') + ' ' + (kd.name || '')).toLowerCase();
            /* Reihenfolge zaehlt: "MDC_PRESS_AWAY_..." enthaelt kein "co2", aber "awrr"/"resp"
             * steckt in mehreren Bezeichnern. Die spezifischen Muster stehen deshalb vorn —
             * derselbe Fehler wie bei den Tierarten ("Rennmaus" enthaelt "maus"). */
            var lane = /ecg|ekg|elec_potl/.test(id) ? 'ekg'
              : (/co2|capno|kapno/.test(id) ? 'capno'
                : (/pleth|oxim/.test(id) ? 'pleth'
                  : (/press_away|paw|airway_press|atemwegsdruck/.test(id) ? 'paw'
                    : (/flow|fluss/.test(id) ? 'flow'
                      : (/imped|resp/.test(id) ? 'resp' : null)))));
            /*
             * SKALA UND EINHEIT MUESSEN MIT (07.08.2026).
             * Hier standen nur { hz, samples }. Die Verstaerkung (skala, aus
             * MDC_ATTR_NU_MSMT_RES) wurde also GENAU an dieser Stelle abgeschnitten, obwohl
             * die Bridge sie ueber /api/kurven ausliefert und __setRealWave sie erwartet.
             * Folge: das Diagnostik-EKG konnte nie kalibriert rechnen — es hielt jeden echten
             * Streifen fuer "Verstaerkung unbekannt" und verweigerte (richtigerweise) jede
             * Angabe in mV. Der Fehler war nicht zu sehen: die Kurve lief, nur die Zahl fehlte.
             */
            if (lane && kd.samples && kd.samples.length && !map[lane]) {
              map[lane] = { hz: kd.hz, samples: kd.samples, skala: kd.skala, einheit: kd.einheit, quelle: kd.code || kd.name || null };
            }
          });
          /*
           * DER PATIENTENSCHLUESSEL MUSS MIT (09.08.2026).
           * Das EKG-Submodul haelt seit heute einen Rohpuffer in Geraeteaufloesung, aus dem
           * archivierte Streifen gebaut werden. Er MUSS beim Patientenwechsel geleert werden,
           * sonst enthaelt ein Streifen Werte zweier Tiere - und sieht dabei tadellos aus.
           * Im iframe selbst ist die Kennung nicht zu haben (state.patientId wird dort nie
           * gesetzt), und ausgerechnet hier oben wird ein bestehendes Fenster an einen NEUEN
           * Schluessel uebergeben, wenn die Geraete dieselben sind (Abschnitt "(a)
           * SCHLUESSELWECHSEL ABFANGEN") - das ist der Praxisfall "naechstes Tier am selben
           * Monitor". Nur diese Ebene kennt also den Wechsel; also nennt sie ihn.
           */
          try { win.__setRealWave(Object.keys(map).length ? map : null, p.patientKey || null); } catch (e) {}
        }).catch(function () {});
      } else if (!sig && w.__kurvenSig) {
        w.__kurvenSig = null;
        try { win.__setRealWave(null); } catch (e) {}
      }
    }

    // ALLE Geraete-Alarme (physiologisch + technisch) live in den virtuellen Monitor spiegeln.
    // Die Registry sammelt sie ueber die Zeit auf (getrennte HL7-Nachrichten) - hier nur bei echter
    // Aenderung neu setzen, sonst wuerde die Liste im 350-ms-Takt unnoetig neu gebaut.
    if (win && typeof win.__setDeviceAlarms === 'function') {
      var asig = (p.alarms || []).map(function (a) { return a && a.text ? a.text : a; }).join('|');
      if (w.__alarmSig !== asig) { w.__alarmSig = asig; try { win.__setDeviceAlarms(p.alarms || []); } catch (e) {} }
    }
  }

  /*
   * HANDEINTRAG DIREKT IN DER APP (23.07.2026).
   * Waehlt der Tierarzt IM Fenster eine Tierart (Chip) oder aendert das Gewicht, wird das als
   * dauerhafter Handeintrag an die Bridge gemeldet (setMeta) — es ueberlebt Neustarts (an die
   * Patienten-ID gebunden) und treibt danach BEIDE Geraete des Patienten (Monitor + Narkose).
   * Ohne diese Rueckmeldung wuerde drive() die Auswahl im 500-ms-Takt wieder ueberschreiben.
   * Automatik zuerst: liefert das Geraet Tierart/Gewicht, stehen sie ohnehin da; dies ist der
   * Fallback fuer alles, was das Geraet NICHT sendet (Tierart ist keine HL7-Groesse).
   */
  function attachManualMeta(w, f) {
    var doc; try { doc = f.contentDocument || f.contentWindow.document; } catch (e) { return; }
    if (!doc || doc.__vsMetaHooked) return; doc.__vsMetaHooked = true;
    doc.addEventListener('click', function (e) {
      if (w.__driving) return;                               // programmatische Aenderung ignorieren
      var t = e.target; var chip = t && t.closest ? t.closest('#spChips .sp-chip') : null;
      if (!chip) return;
      var sp = chip.getAttribute('data-sp'); if (sp) sendMetaForWindow(w, { species: sp });
    }, true);
    /*
     * AUF 'input' HOEREN, NICHT NUR AUF 'change' (Befund 19.08.2026).
     * 'change' feuert bei einem Zahlenfeld erst beim Verlassen. Wer das Gewicht eintippt und
     * weiterarbeitet, hatte es nie uebernommen. Jetzt wird 700 ms nach dem letzten Anschlag
     * uebernommen - lange genug, dass aus "2" nicht sofort ein 2-kg-Tier wird, kurz genug,
     * dass es sich sofort anfuehlt. 'change' bleibt zusaetzlich: Enter und Verlassen sollen
     * weiterhin unmittelbar wirken.
     */
    function gewichtVon(t) {
      var val = parseFloat(String(t.value).replace(',', '.'));
      return (isFinite(val) && val > 0) ? val : null;
    }
    var wtTimer = null;
    doc.addEventListener('input', function (e) {
      if (w.__driving) return;
      var t = e.target; if (!t || t.id !== 'wt') return;
      t.__vsHandEingabe = Date.now();          // drive() haelt sich daran fern
      if (wtTimer) clearTimeout(wtTimer);
      wtTimer = setTimeout(function () {
        var v = gewichtVon(t);
        if (v != null) sendMetaForWindow(w, { weightKg: v });
      }, 700);
    }, true);
    doc.addEventListener('change', function (e) {
      if (w.__driving) return;
      var t = e.target; if (!t || t.id !== 'wt') return;
      t.__vsHandEingabe = Date.now();
      if (wtTimer) { clearTimeout(wtTimer); wtTimer = null; }
      var v = gewichtVon(t);
      if (v != null) sendMetaForWindow(w, { weightKg: v });
    }, true);
  }
  function sendMetaForWindow(w, meta) {
    var key = null; for (var kk in windows) if (windows[kk] === w) { key = kk; break; }
    if (!key) return;
    var p = null; for (var i = 0; i < state.patients.length; i++) if (state.patients[i].patientKey === key) { p = state.patients[i]; break; }
    if (!p) return;
    // Optimistisch lokal setzen, damit drive() die Wahl nicht kurz zurueckdreht, bis die Bridge bestaetigt.
    if (meta.species) p.species = meta.species;
    if (meta.weightKg != null) p.weightKg = meta.weightKg;
    var ids = (p.devices || []).map(function (d) { return d.deviceId; });
    /*
     * OHNE GERAET NICHT MEHR STILL VERWERFEN (Befund 19.08.2026).
     * Hier stand "if (!ids.length) return;" VOR dem Senden und vor der Rueckmeldung. Ohne
     * angeschlossenes Geraet gab es also kein Ziel, keine Meldung und kein Speichern - der
     * eingetippte Wert war beim naechsten Takt weg, ohne dass irgendetwas es sagte.
     * Jetzt geht er ueber die Patienten-ID in die Krankenakte der Bruecke (setAkte), also
     * genau dorthin, wo setMeta ihn bei vorhandenem Geraet auch ablegt.
     */
    if (ids.length) {
      ids.forEach(function (id) { send({ type: 'setMeta', deviceId: id, meta: meta }); });
    } else if (p.patientId) {
      send({ type: 'setAkte', patientId: String(p.patientId), meta: meta });
    }
    var wohin = ids.length ? ' — gespeichert' :
      (p.patientId ? ' — gespeichert (noch kein Gerät angeschlossen)'
                   : ' — nur für dieses Fenster (kein Gerät und keine Patienten-ID)');
    flashToast(meta.species ? '🐾 Tierart übernommen' + wohin
      : '⚖ Gewicht ' + meta.weightKg + ' kg übernommen' + wohin);
  }

  // ---------- OP-Protokoll ----------
  function logSnapshot(pats) {
    var now = Date.now();
    pats.forEach(function (p) {
      var k = p.patientKey; meta[k] = { patientId: p.patientId, species: p.species, weightKg: p.weightKg };
      var L = log[k] || (log[k] = []);
      var top = p._res.top ? p._res.top.title : null;
      var last = L[L.length - 1];
      if (!last || now - last.ts > 12000 || (last.finding || '') !== (top || '')) {
        var v = p.vitals || {};
        L.push({ ts: now, hr: v.hr, spo2: v.spo2, etco2: v.etco2, af: v.af, map: v.map, sys: v.sys, dia: v.dia, temp: v.temp, rhythm: v.ekgRhythm, iso: p.isoPct, finding: top });
        fensterProtokollDeckeln(L);
      }
    });
  }

  /*
   * fensterProtokollDeckeln(L) — der Rueckfall-Speicher dieses Fensters, ohne die Gabe zu verlieren.
   *
   * An zwei Stellen wurde die Liste vorne abgeschnitten. Das ist GENAU die Bauart, die
   * bridge/src/registry.js am 21.08.2026 ausdruecklich verworfen hat: shift() nimmt die
   * AELTESTE Zeile, und das ist die Einleitung — der klinisch wichtigste Teil eines
   * Narkoseprotokolls. An der zweiten Stelle (logMed) kann die herausfallende Zeile sogar eine
   * MEDIKAMENTENGABE sein, und ein Nachweisdokument, aus dem Gaben verschwinden, ist als
   * Nachweis wertlos.
   *
   * Dass es hier nur der RUECKFALL ist (die Bridge fuehrt das verbindliche Protokoll), macht es
   * nicht harmloser: er greift genau dann, wenn die Bridge nichts liefert — also im Stoerfall,
   * fuer den er gedacht ist.
   *
   * Ausgeduennt wird deshalb die AELTERE HAELFTE der Messzeilen (jede zweite faellt weg, die
   * Aufzeichnung wird dort groeber und reicht trotzdem bis zum ersten Wert zurueck). Gaben und
   * die allererste Zeile werden NIE verworfen. Dieselbe Regel wie registry._protokollAusduennen.
   */
  function fensterProtokollDeckeln(L) {
    if (L.length <= 1200) return;
    var haelfte = Math.floor(L.length / 2), behalten = [], mess = 0;
    for (var i = 0; i < L.length; i++) {
      var z = L[i];
      if (i === 0 || i >= haelfte || (z && z.art === 'med')) { behalten.push(z); continue; }
      if ((mess++ % 2) === 0) behalten.push(z);
    }
    /* Fast nur Gaben? Dann faellt doch die aelteste MESSzeile heraus — unbegrenzt wachsen darf
     * es nicht, aber eine Gabe geht auch dann nicht verloren. */
    if (behalten.length >= L.length) {
      for (var k = 1; k < behalten.length; k++) {
        if (!behalten[k] || behalten[k].art !== 'med') { behalten.splice(k, 1); break; }
      }
    }
    L.length = 0;
    Array.prototype.push.apply(L, behalten);
  }

  // ---------- PDF-Export ----------
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hhmmss(ts) { var d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); }
  function nn(x) { return x == null ? '–' : x; }

  // Öffnet den Auswahldialog (Patient nach Name/ID wählen) und exportiert dann nur dessen Protokoll.
  function exportPDF() { openExportDialog(); }

  /*
   * WEN KANN MAN AUSDRUCKEN?
   *
   * Drei Quellen, und die dritte ist neu und der eigentliche Punkt: bis 1.2.2 kannte diese Liste
   * nur, was gerade angeschlossen ist ODER was dieses BROWSERFENSTER seit seinem letzten Laden
   * mitgeschrieben hat. Nach einem F5 (oder einem Kiosk-Neustart) war die Narkose von heute
   * morgen also nicht mehr ausdruckbar, obwohl die Station sie durchgehend protokolliert hat.
   * protokollBestand wird beim Öffnen des Dialogs aus der Bridge geholt (data/protokoll.json,
   * 30 Tage) und hier dazugelegt.
   */
  var protokollBestand = [];
  function exportablePatients() {
    var seen = {}, out = [];
    (state.patients || []).forEach(function (p) { seen[p.patientKey] = 1; out.push({ key: p.patientKey, patientId: p.patientId, species: p.species, weightKg: p.weightKg, live: true }); });
    Object.keys(log).forEach(function (k) { if (seen[k] || !(log[k] || []).length) return; seen[k] = 1; var m = meta[k] || {}; out.push({ key: k, patientId: m.patientId, species: m.species, weightKg: m.weightKg, live: false }); });
    protokollBestand.forEach(function (e) {
      // Schon dabei? Ein Patient kann unter seinem patientKey ODER seiner Kennung gelistet sein.
      if (seen[e.patientId]) return;
      if (out.some(function (o) { return o.patientId && String(o.patientId) === String(e.patientId); })) return;
      var k = (e.kopf || {});
      out.push({ key: e.patientId, patientId: e.patientId, species: k.species, weightKg: k.weightKg, live: false, ausBridge: true });
    });
    return out;
  }
  function holeProtokollBestand() {
    return fetch('api/protokoll')
      .then(function (r) { return r.json(); })
      .then(function (j) { protokollBestand = (j && j.liste) || []; })
      .catch(function () { protokollBestand = []; });
  }

  function openExportDialog() {
    // Erst zeichnen, dann nachtragen: der Dialog soll sofort aufgehen, auch wenn die Auskunft
    // der Bridge hängt. Kommt sie, wird die Liste einmal neu aufgebaut.
    zeichneExportDialog();
    holeProtokollBestand().then(function () {
      var h = $('#exportDlg');
      if (h && h.classList.contains('open')) zeichneExportDialog();
    });
  }
  function zeichneExportDialog() {
    var host = $('#exportDlg');
    if (!host) { host = document.createElement('div'); host.id = 'exportDlg'; host.className = 'vsx-pairing'; document.body.appendChild(host); }
    var list = exportablePatients();
    var rows = list.length ? list.map(function (p, i) {
      var s = spOf(p.species);
      return '<label class="pdev exp-row"><input type="radio" name="exp-sel" value="' + esc(p.key) + '"' + (i === 0 ? ' checked' : '') + '>' +
        '<span class="pstat" style="--sc:' + (p.live ? '#35d69a' : '#8ba0b6') + '"></span>' +
        '<div class="pinfo"><b>' + esc(p.patientId || ('Patient · ' + s.name)) + '</b>' +
        '<div class="pmuted">' + s.icon + ' ' + esc(s.name) + ' · ' + (p.weightKg || '?') + ' kg' + (p.patientId ? (' · ID ' + esc(p.patientId)) : '') + (p.live ? '' : ' · (aus Verlauf)') + '</div></div></label>';
    }).join('') : '<p class="pmuted" style="padding:16px">Kein Patient mit Protokoll vorhanden.</p>';
    host.innerHTML = '<div class="pbox"><div class="phead"><h2>⤓ PDF-Protokoll exportieren</h2><div style="flex:1"></div><button class="vsx-btn" id="expClose">✕</button></div>' +
      '<p class="pmuted" style="margin:0 0 8px">Patient nach <b>Name/ID</b> wählen — es wird nur dessen Narkoseprotokoll exportiert.</p>' +
      '<div class="plist">' + rows + '</div>' +
      '<div class="pfoot"><button class="vsx-btn" id="expOne">⤓ Gewählten Patienten exportieren</button>' +
      (list.length > 1 ? '<button class="vsx-btn" id="expAll">Alle Patienten</button>' : '') +
      '<div style="flex:1"></div><button class="vsx-btn" id="expClose2">Abbrechen</button></div></div>';
    host.classList.add('open');
    var close = function () { host.classList.remove('open'); };
    host.querySelector('#expClose').onclick = host.querySelector('#expClose2').onclick = close;
    host.querySelector('#expOne').onclick = function () { var s = host.querySelector('input[name="exp-sel"]:checked'); if (!s) { alert('Bitte einen Patienten wählen.'); return; } close(); doExportPDF([s.value]); };
    var all = host.querySelector('#expAll'); if (all) all.onclick = function () { close(); doExportPDF(list.map(function (p) { return p.key; })); };
  }

  /*
   * DAS PROTOKOLL KOMMT AUS DER BRIDGE, NICHT AUS DIESEM BROWSERFENSTER.
   *
   * Bis hierher wurde fuer den Ausdruck die Variable log{} benutzt — eine reine Closure im
   * Kiosk-Browser. Ein F5, ein Kiosk-Neustart oder ein Absturz mitten in der Narkose, und der
   * Ausdruck war leer, obwohl die Station durchgehend mitgeschrieben hat. Seit dem 27.07.2026
   * fuehrt die Bridge dasselbe Protokoll dauerhaft (bridge/data/protokoll.json, an die
   * PATIENTEN-ID gebunden) — und seit heute stehen dort auch die bestaetigten Medikamentengaben.
   * Deshalb wird zuerst DORT gefragt; log{} bleibt der Rueckfall, wenn die Auskunft ausfaellt
   * oder noch leer ist (z. B. Patient ohne Kennung).
   */
  function pidVonKey(key) {
    var p = (state.patients || []).find(function (x) { return x.patientKey === key; });
    if (p && p.patientId) return p.patientId;
    if (meta[key] && meta[key].patientId) return meta[key].patientId;
    /* Ein Patient, den NUR die Bridge noch kennt (nach F5 oder Kiosk-Neustart), wird in der
     * Auswahlliste unter seiner Kennung gefuehrt — dann IST der Schluessel die Kennung. Ohne
     * diesen Zweig fiele der Ausdruck auf das leere Fensterprotokoll zurueck und das Blatt
     * enthielte genau die Stammdaten und sonst nichts. */
    if (protokollBestand.some(function (e) { return String(e.patientId) === String(key); })) return key;
    return null;
  }
  function holeProtokolle(keys) {
    return Promise.all(keys.map(function (key) {
      var pid = pidVonKey(key);
      if (!pid) return Promise.resolve(null);
      return fetch('api/protokoll?id=' + encodeURIComponent(pid))
        .then(function (r) { return r.json(); })
        .then(function (j) { return (j && j.eintraege && j.eintraege.length) ? j : null; })
        .catch(function () { return null; });
    })).then(function (arr) {
      var m = {}; keys.forEach(function (k, i) { m[k] = arr[i]; }); return m;
    });
  }

  // Professionelles tiermedizinisches Narkoseprotokoll (jsPDF) für die gewählten Patienten.
  function doExportPDF(keys) {
    var jsPDF = window.jspdf && window.jspdf.jsPDF; if (!jsPDF) { alert('PDF-Bibliothek nicht geladen.'); return; }
    holeProtokolle(keys).then(function (protMap) { baueExportPDF(keys, protMap); })
      .catch(function () { baueExportPDF(keys, {}); });
  }
  function baueExportPDF(keys, protMap) {
    var jsPDF = window.jspdf && window.jspdf.jsPDF; if (!jsPDF) { alert('PDF-Bibliothek nicht geladen.'); return; }
    protMap = protMap || {};
    var doc = new jsPDF({ unit: 'mm', format: 'a4' });
    // JEDE Textausgabe durch den Latin-1-Filter: jsPDF/helvetica kann nur Latin-1 - Subscripts (₂),
    // Pfeile (↑↓→) und Emojis wurden sonst zu Muell ("O₂"->"O ‚", "↑"->"!'"). pdfSan ersetzt sie.
    var _pdfText = doc.text.bind(doc);
    doc.text = function () { if (arguments.length) arguments[0] = pdfSan(arguments[0]); return _pdfText.apply(doc, arguments); };
    var W = 210, H = 297, M = 14, y = M, pageNo = 0;
    var TEAL = [18, 110, 120], INK = [33, 41, 51], MUT = [120, 130, 140], LINE = [214, 220, 226];

    function setC(c) { doc.setTextColor(c[0], c[1], c[2]); }
    function T(s, x, size, style, c, align) { doc.setFont('helvetica', style || 'normal'); doc.setFontSize(size || 10); setC(c || INK); doc.text(String(s), x == null ? M : x, y, align ? { align: align } : undefined); }
    function band() { pageNo++; doc.setFillColor(TEAL[0], TEAL[1], TEAL[2]); doc.rect(0, 0, W, 20, 'F');
      doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.text('VetStation', M, 9.5);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5); doc.text('Anästhesie- / Narkoseüberwachungsprotokoll', M, 15.5);
      doc.setFontSize(8); doc.text('Erstellt: ' + new Date().toLocaleString(), W - M, 9.5, { align: 'right' }); y = 27; }
    function footer() { doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.2); doc.line(M, H - 12, W - M, H - 12);
      doc.setFont('helvetica', 'italic'); doc.setFontSize(7.2); setC([150, 80, 80]);
      doc.text('Entscheidungs-/Trainingshilfe — kein zugelassener Patientenmonitor-Ersatz. Read-only. Der Tierarzt entscheidet und handelt.', M, H - 8);
      setC(MUT); doc.setFont('helvetica', 'normal'); doc.text('Seite ' + pageNo, W - M, H - 8, { align: 'right' }); }
    /*
     * DER SPALTENKOPF MUSS AUF JEDER FOLGESEITE WIEDER OBEN STEHEN (Praxis-Befund 06.08.2026).
     *
     * Auf dem ausgedruckten Protokoll hat die Tierärztin auf Seite 2 mit rotem Stift
     * "Zeit · HF · SpO2 · AF · Befund" über die Spalten geschrieben — weil dort nichts stand.
     * Der Grund: need() brach die Seite um und rief band() (den blauen Titelbalken), aber der
     * Spaltenkopf der laufenden Tabelle wurde nie wiederholt. Bei einer einstündigen Narkose
     * sind das seitenweise nackte Zahlenkolonnen, und niemand kann sagen, welche Spalte die
     * Sauerstoffsättigung ist und welche die Atemfrequenz. In einem Narkoseprotokoll, das in
     * die Akte geht, ist das kein Schönheitsfehler.
     *
     * Jetzt merkt sich der Aufbau die laufende Tabelle und zeichnet ihren Kopf nach jedem
     * Seitenwechsel erneut, mit dem Zusatz "(Fortsetzung)". Die ERSTE Seite bleibt unverändert.
     * kopfLaeuft ist der Rekursionsschutz: der Wiederholungskopf darf nicht selbst wieder einen
     * Seitenwechsel und damit einen weiteren Kopf auslösen.
     */
    var laufendeTabelle = null, kopfLaeuft = false;
    function kopfZeichnen(cells, cols, fortsetzung) {
      doc.setFillColor(TEAL[0], TEAL[1], TEAL[2]); doc.rect(M, y - 4, W - 2 * M, 6, 'F');
      doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(8.4);
      var x = M + 2; cells.forEach(function (c, i) { doc.text(String(c), x, y); x += cols[i]; });
      if (fortsetzung) { doc.setFont('helvetica', 'italic'); doc.setFontSize(7.2); doc.text('(Fortsetzung)', W - M - 2, y, { align: 'right' }); }
      y += 6.6;   // bewusst kein nl(): darin steckt need(), und das wäre die Rekursion
    }
    function seitenwechsel() {
      footer(); doc.addPage(); band();
      if (laufendeTabelle && !kopfLaeuft) {
        kopfLaeuft = true; kopfZeichnen(laufendeTabelle.cells, laufendeTabelle.cols, true); kopfLaeuft = false;
      }
    }
    function need(h) { if (y + h > H - 16) seitenwechsel(); }
    function nl(h) { y += (h || 6); need(0); }
    function sectionTitle(t) { tabelleEnde(); need(11); doc.setFillColor(238, 244, 245); doc.rect(M, y - 4.2, W - 2 * M, 6.6, 'F'); T(t, M + 2, 10.5, 'bold', TEAL); nl(8); }
    function bands(sp) { return (A().vitals || {})[sp] || {}; }
    function rng(a) { return (a && a.length === 2) ? (a[0] + '–' + a[1]) : '–'; }
    /* Kopf + mindestens eine Zeile müssen zusammen passen (6,6 + 5,8) — ein Spaltenkopf als
     * letzte Zeile einer Seite ist so unbrauchbar wie gar keiner. */
    function tableHead(cells, cols) { laufendeTabelle = null; need(13); laufendeTabelle = { cells: cells, cols: cols }; kopfZeichnen(cells, cols, false); }
    /* Nach der letzten Zeile einer Tabelle: ab hier darf kein Kopf mehr nachgezogen werden. */
    function tabelleEnde() { laufendeTabelle = null; }
    function tableRow(cells, cols, size) { need(5.8); doc.setFont('helvetica', 'normal'); doc.setFontSize(size || 8.6); setC(INK);
      var x = M + 2; cells.forEach(function (c, i) { var t = String(c); if (i === cells.length - 1) { t = doc.splitTextToSize(t, cols[i] - 2)[0] || t; } doc.text(t, x, y); x += cols[i]; });
      doc.setDrawColor(238, 240, 243); doc.setLineWidth(0.1); doc.line(M, y + 1.7, W - M, y + 1.7); nl(5.5); }
    function wrapT(s, x, size, c) { doc.setFont('helvetica', 'normal'); doc.setFontSize(size || 9); setC(c || INK); var lines = doc.splitTextToSize(String(s), W - M - x); lines.forEach(function (ln) { need(5); doc.text(ln, x, y); nl(4.4); }); }

    var gedruckteZeilen = {};   /* key -> {zeilen, gaben, name}, gefuellt beim Aufbau des Blattes */
    keys.forEach(function (key, idx) {
      var p = (state.patients || []).find(function (x) { return x.patientKey === key; });
      var m = meta[key] || {};
      /* artGemeldet haelt fest, ob die Tierart WIRKLICH von irgendwoher kam oder ob der
       * Rueckfall auf 'hund' gegriffen hat. Der Ausdruck sagt es dann (17.08.2026). */
      var artGemeldet = !!((p && p.species) || m.species);
      var speciesId = (p && p.species) || m.species || 'hund';
      var sp = spOf(speciesId);
      var weightKg = (p && p.weightKg) || m.weightKg || null;
      var patientId = (p && p.patientId) || m.patientId || null;
      // Vollstaendige Akte vom Geraet (Besitzer, Arzt, Rasse, Alter ...) — bisher nur im Geraete-Dialog,
      // jetzt auch im Narkoseprotokoll, damit die 1:1-Uebernahme belegt und dokumentiert ist.
      var akte = (p && p.akte) || {};
      var patientName = (p && p.patientName) || null;
      var geschlecht = (p && p.geschlecht) || null;
      var gebDatum = (p && p.gebDatum) || null;
      var v = (p && p.vitals) || {};
      var res = p ? assess(p) : { cross: [], priority: 0 };
      // Bridge-Protokoll bevorzugt (ueberdauert F5/Neustart und enthaelt die Medikamentengaben),
      // das Fenster-Protokoll nur als Rueckfall.
      var bp = protMap[key];
      var L = (bp && bp.eintraege && bp.eintraege.length) ? bp.eintraege : (log[key] || []);
      /* Merken, was WIRKLICH auf dem Blatt steht — der Ausdruck-Vermerk nannte sonst die Zahl
       * aus dem Fenster-Rueckfall. Beim Drucken aus dem 30-Tage-Bestand ist der leer, und fern
       * stand dann "0 Zeilen, 0 Gaben" ueber einem Protokoll mit vierhundert Eintraegen. */
      gedruckteZeilen[key] = { zeilen: L.length,
        gaben: L.filter(function (e) { return e && e.art === 'med'; }).length,
        name: (bp && bp.patientName) || (meta[key] && meta[key].patientName) || '' };
      var bkopf = (bp && bp.kopf) || {};
      /* Der Protokollkopf ist die dritte Quelle. Kommt die Art von dort, ist sie GEMELDET —
       * artGemeldet muss mitwandern, sonst stuende "(angenommen)" an einer belegten Angabe. */
      if (!(p && p.species) && !m.species && bkopf.species) {
        speciesId = bkopf.species; sp = spOf(speciesId); artGemeldet = true;
      }
      if (!patientName && bkopf.patientName) patientName = bkopf.patientName;
      if (!patientId && bkopf.patientId) patientId = bkopf.patientId;
      if (weightKg == null && bkopf.weightKg != null) weightKg = bkopf.weightKg;
      if (!gebDatum && bkopf.gebDatum) gebDatum = bkopf.gebDatum;
      if (!geschlecht && bkopf.geschlecht) geschlecht = bkopf.geschlecht;
      if ((!akte || !Object.keys(akte).length) && bkopf.akte) akte = bkopf.akte;

      band();

      // Patienten-Stammdaten-Box — vollstaendige Akte, soweit das Geraet sie geliefert hat.
      var paare = [
        ['Patient/Name', patientName || patientId || '—'],
        ['Patienten-ID', patientId || '—'],
        /*
         * KEIN Emoji: die PDF-Schrift (helvetica) kann Emojis nicht darstellen -> wurde zu "Ø=Ü"
         *
         * "(angenommen)" DAZU, WENN NIEMAND DIE ART GEMELDET HAT (17.08.2026). speciesId faellt
         * weiter oben auf 'hund' zurueck, wenn weder der Patient noch die Kopfdaten noch der
         * Protokollkopf eine Art tragen. Der Ausdruck behauptete dann "Tierart: Hund" als
         * Tatsache - und rechnet auch die Normbaender, die Dosen und die Geraete-Sollwerte
         * danach. Ein abgezeichnetes Protokoll darf eine Annahme nicht wie eine Angabe fuehren.
         *
         * Die Abschnitte werden dabei ABSICHTLICH NICHT unterdrueckt: anders als beim Gewicht,
         * wo eine fehlende Zahl nur eine Zahl kostet, waere ein Ausdruck ohne Bewertung fuer
         * den Tierarzt wertlos. Benennen ist hier richtig, Schweigen nicht.
         */
        ['Tierart', sp.name + (artGemeldet ? '' : '  (angenommen, nichts gemeldet)')],
        ['Gewicht', weightKg != null ? weightKg + ' kg' : '—']
      ];
      function addKV(label, val) { if (val != null && val !== '') paare.push([label, String(val)]); }
      addKV('Rasse', akte.rasse);
      addKV('Geschlecht', geschlechtText(geschlecht));
      // Alter bevorzugt aus dem Geb.datum berechnet (sonst das vom Geraet gelieferte Alter).
      addKV('Alter', alterText({ gebDatum: gebDatum, akte: akte }));
      addKV('Geb.datum', datumText(gebDatum));
      addKV('Größe', akte.groesseCm != null ? akte.groesseCm + ' cm' : null);
      addKV('Besitzer', akte.besitzer);
      addKV('Telefon', akte.telefon);
      addKV('Arzt', akte.arzt);
      addKV('Bett-Nr.', akte.bett);
      addKV('Blutgruppe', akte.blutgruppe);
      addKV('Schrittmacher', akte.pacer == null ? null : (akte.pacer ? 'ja' : 'nein'));
      paare.push(['Station', station()]);
      paare.push(['Datum/Zeit', new Date().toLocaleString()]);

      var rows2 = Math.ceil(paare.length / 2), rowH = 6.6, boxY = y;
      doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.3);
      doc.roundedRect(M, y, W - 2 * M, rowH * rows2 + 4, 2, 2, 'S'); y += 5.5;
      function kv(label, val, col) { var x = col === 1 ? M + 4 : (M + (W - 2 * M) / 2 + 2);
        doc.setFont('helvetica', 'normal'); doc.setFontSize(8); setC(MUT); doc.text(label, x, y);
        doc.setFont('helvetica', 'bold'); doc.setFontSize(10); setC(INK);
        var t = doc.splitTextToSize(String(val == null ? '—' : val), (W - 2 * M) / 2 - 32)[0] || '—';
        doc.text(t, x + 28, y); }
      for (var pi = 0; pi < paare.length; pi += 2) {
        kv(paare[pi][0], paare[pi][1], 1);
        if (paare[pi + 1]) kv(paare[pi + 1][0], paare[pi + 1][1], 2);
        nl(rowH);
      }
      y = boxY + rowH * rows2 + 4; nl(7);

      // Narkose-Parameter
      /*
       * MITTELWERT STATT LETZTEM WERT (Befund 19.08.2026 - siehe scratchpad-Kommentar oben).
       * mittel() rechnet je Parameter ab dessen ERSTER Messung. Die Zaehlung wird
       * mitgegeben, damit unter der Tabelle steht, worauf der Wert beruht.
       */
      function mittel(feld) {
        var summe = 0, anzahl = 0;
        for (var i = 0; i < L.length; i++) {
          var e = L[i];
          if (!e || e.art === 'med') continue;
          var x = e[feld];
          if (x == null || x === '' || typeof x === 'string') continue;
          if (!isFinite(x)) continue;
          summe += Number(x); anzahl++;
        }
        return { n: anzahl, wert: anzahl ? (summe / anzahl) : null };
      }
      function zeig(m, stellen) {
        if (!m.n) return '—';
        var f = (stellen === 1) ? Math.round(m.wert * 10) / 10 : Math.round(m.wert);
        return String(f);
      }
      var mHr = mittel('hr'), mSpo2 = mittel('spo2'), mEt = mittel('etco2'), mFi = mittel('fico2');
      var mAf = mittel('af'), mSys = mittel('sys'), mDia = mittel('dia'), mMap = mittel('map');
      var mTemp = mittel('temp');
      var nGesamt = Math.max(mHr.n, mSpo2.n, mEt.n, mAf.n, mMap.n, mTemp.n);

      sectionTitle('Narkose-Parameter — Mittelwert über den Verlauf');
      var b = bands(speciesId);
      var params = [
        ['Herzfrequenz (HF)', zeig(mHr, 0), '/min', rng(b.hr), mHr.n],
        ['SpO₂', zeig(mSpo2, 0), '%', rng(b.spo2), mSpo2.n],
        ['EtCO₂', zeig(mEt, 0), 'mmHg', rng(b.etco2), mEt.n],
        ['FiCO₂ (Rückatmung)', zeig(mFi, 0), 'mmHg', '≈0', mFi.n],
        ['Atemfrequenz (AF)', zeig(mAf, 0), '/min', rng(b.rr), mAf.n],
        ['Blutdruck NIBP', (zeig(mSys, 0) + '/' + zeig(mDia, 0)), 'mmHg', (b.nibp ? rng(b.nibp) : '—'), Math.max(mSys.n, mDia.n)],
        ['MAP', zeig(mMap, 0), 'mmHg', rng(b.map), mMap.n],
        ['Temperatur', zeig(mTemp, 1), '°C', rng(b.temp), mTemp.n],
        ['EKG-Rhythmus (zuletzt)', nn(v.ekgRhythm), '', 'Sinus', null],
        ['Isofluran (zuletzt)', (p && p.isoPct != null ? p.isoPct : '—'), 'Vol%', '—', null],
        ['Beatmung (zuletzt)', (p && p.ventMode) || '—', '', '—', null]
      ];
      tableHead(['Parameter', 'Mittelwert', 'Messungen', 'Narkose-Norm'], [58, 26, 24, 54]);
      params.forEach(function (r) {
        tableRow([r[0], String(r[1]) + (r[2] ? ' ' + r[2] : ''), (r[4] == null ? '—' : String(r[4])), r[3]], [58, 26, 24, 54]);
      });
      tabelleEnde();
      nl(1);
      wrapT('Mittelwert je Parameter über alle Messungen dieser Narkose, jeweils ab der ersten '
        + 'Messung dieses Parameters (die Kanäle beginnen nicht gleichzeitig). Steht dort ein '
        + 'Strich, wurde für diesen Parameter nichts gemessen — geschätzt wird nichts. Die '
        + 'einzelnen Werte stehen im Verlaufsprotokoll' + (nGesamt ? ' (' + nGesamt + ' Messzeitpunkte)' : '') + '.',
        M + 2, 8, MUT);
      nl(4);

      // Zwischenfälle & Empfehlungen
      sectionTitle('Zwischenfälle & Empfehlungen');
      if (res.cross && res.cross.length) {
        res.cross.forEach(function (f) {
          need(12); var col = priColor(f.sev).match(/\w\w/g).map(function (h) { return parseInt(h, 16); });
          doc.setFillColor(col[0], col[1], col[2]); doc.circle(M + 2, y - 1.4, 1.3, 'F');
          T(f.title + (f.tag ? '  [' + f.tag + ']' : ''), M + 6, 9.6, 'bold', col); nl(4.8);
          if (f.fix) { wrapT('Sofort: ' + f.fix, M + 6, 9, INK); }
          /*
           * KEINE GEDRUCKTEN MENGEN OHNE GEWICHT (17.08.2026).
           *
           * Hier stand "weightKg || 10". Der Kopf desselben Ausdrucks schreibt bei fehlendem
           * Gewicht ehrlich "Gewicht: —" (siehe oben) — und wenige Zeilen darunter stand dann
           * eine auf 10 kg gerechnete Milliliterzahl, in derselben Schrift wie eine belegte.
           * Ein Ausdruck wird abgezeichnet und abgelegt; eine erfundene Zahl darauf ist
           * schlimmer als im Bildschirm, weil sie den Zweifel nicht mitnimmt.
           *
           * d.note WIRD JETZT MITGEDRUCKT. Es traegt die Einschraenkung des Eintrags
           * (z. B. "Nur bei Kreislaufstillstand"). Sie fehlte im Ausdruck, waehrend die Menge
           * darin stand — genau daran hing der Adrenalin-Befund. ui/app.js macht es seit dem
           * 22.07.2026 richtig; hier war es nie nachgezogen worden.
           */
          if (f.incident && weightKg == null) {
            wrapT('Mengen: Gewicht fehlt — im Geräte-Menü eintragen, dann stehen hier die mL.',
              M + 6, 9, [120, 90, 40]);
          } else if (f.incident) {
            var inj = VS.dose.injectionsFor(A(), f.incident, speciesId, weightKg).filter(function (x) { return x.available; });
            inj.forEach(function (d) {
              // d.takt tragt "/min" bzw. "/h" — eine Rate darf im Ausdruck nicht wie eine
              // Einzelgabe dastehen (17.08.2026). Bei Einzelgaben ist es eine leere Zeichenkette.
              var ml = d.mlLo != null ? VS.dose.fmtRange(d.mlLo, d.mlHi) + ' mL' + (d.takt || '') : '';
              wrapT('Injektion ' + d.name + ':  ' + ml + (d.route ? '  ' + d.route : '') + (d.conc ? '  (@ ' + d.conc + ')' : ''), M + 6, 9, [40, 70, 110]);
              if (d.note) { wrapT('    ⓘ ' + d.note, M + 6, 8.4, [120, 90, 40]); }
            });
          }
          nl(1.6);
        });
      } else { T('Keine kritische Kreuz-Analyse — Werte im Normbereich.', M + 2, 9, 'italic', MUT); nl(6); }

      // Geräte-Sollwerte
      try {
        /*
         * OHNE GEWICHT KEINE SOLLWERTE (17.08.2026).
         *
         * Hier stand "weightKg || 10". Zwei der vier Zeilen haengen am Gewicht (O2-Fluss und
         * Atemsystem) — bei einem unbekannten Gewicht waeren sie fuer ein 10-kg-Tier gedruckt
         * worden. Ein null durchzureichen hilft NICHT und ist nachgemessen sogar schlechter:
         * compare() rechnet dann mit 0 kg und druckt "0,5-0,5 L/min / Nicht-Rueckatmung",
         * also eine andere erfundene Antwort statt keiner.
         * Deshalb entfaellt der ganze Abschnitt, mit einer Zeile, die den Grund nennt.
         * Der Rechenweg selbst bleibt unberuehrt.
         */
        if (weightKg == null) {
          sectionTitle('Geräte-Sollwerte');
          wrapT('Gewicht fehlt — die gewichtsabhängigen Sollwerte (O₂-Fluss, Atemsystem) werden '
            + 'nicht geschätzt. Gewicht im Geräte-Menü eintragen.', M + 2, 9, [120, 90, 40]);
          nl(1);
        } else {
          var cmp = VS.deviceTarget.compare(A(), speciesId, weightKg, { iso: p && p.isoPct, o2: null });
          sectionTitle('Geräte-Sollwerte');
          cmp.rows.forEach(function (r) { need(5.5); T('•  ' + r.name, M + 2, 9, 'bold'); T(String(r.target || '—'), M + 46, 9, 'normal', [70, 90, 110]); nl(5); });
          nl(1);
        }
      } catch (e) {}

      /*
       * VERABREICHTE MEDIKAMENTE — eigener Abschnitt, weil es die Frage ist, die man einem
       * Narkoseprotokoll zuerst stellt: was hat das Tier bekommen, wann, wie viel.
       *
       * Hier steht AUSSCHLIESSLICH, was der Tierarzt in der App als „gegeben" bestaetigt hat.
       * Die berechneten Empfehlungen der Station (Dosisrechner, Zwischenfall-Protokolle) stehen
       * bewusst NICHT hier — er kann jede davon uebergehen, und ein Ausdruck, der Vorschlaege als
       * Gaben fuehrt, waere eine falsche Krankenakte. Eine zurueckgenommene Markierung wird als
       * solche gedruckt statt entfernt: eine Dokumentation, aus der sich Zeilen loeschen lassen,
       * ist keine.
       */
      var medsAlle = L.filter(function (e) { return e && e.art === 'med' && e.med; });
      /*
       * FEHLEINGABEN AUS DEM AUSDRUCK NEHMEN (Befund 19.08.2026, siehe Kopf dieser Aenderung).
       * Eine Ruecknahme innerhalb von KORRFRIST loescht sich und ihre Gabe aus dem Ausdruck.
       * Spaetere Ruecknahmen bleiben beide sichtbar: das ist dann ein Verlauf, kein Tippfehler.
       */
      var KORRFRIST = 120000;
      var weg = {};
      medsAlle.forEach(function (e, i) {
        if (!e.med || !e.med.storno) return;
        for (var j = i - 1; j >= 0; j--) {
          var f = medsAlle[j];
          if (!f.med || f.med.storno || weg[j]) continue;
          if (f.med.name !== e.med.name) continue;
          if ((e.ts || 0) - (f.ts || 0) > KORRFRIST) break;
          weg[i] = 1; weg[j] = 1; break;
        }
      });
      var korrigiert = Object.keys(weg).length / 2;
      var meds = medsAlle.filter(function (e, i) { return !weg[i]; });
      sectionTitle('Verabreichte Medikamente / Narkosemittel (' + meds.length + ')');
      if (meds.length) {
        var mcols = [22, 34, 46, 62];
        tableHead(['Zeit', 'Art', 'Mittel', 'Dosis / Weg'], mcols);
        meds.forEach(function (e) {
          var md = e.med || {};
          var dosis = (md.dosis || '') + (md.route ? '  ' + md.route : '');
          tableRow([hhmmss(e.ts), (md.storno ? 'zurückgen.' : (md.kindText || md.kind || '')),
            (md.storno ? '(' + md.name + ')' : md.name), dosis], mcols, 8);
        });
        tabelleEnde();
        nl(1);
        wrapT('Nur vom Tierarzt bestätigte Gaben. Von der Station berechnete Empfehlungen erscheinen '
          + 'in dieser Liste nicht.'
          + (korrigiert ? '  ' + korrigiert + ' sofort zurückgenommene Fehleingabe(n) sind hier nicht '
              + 'aufgeführt; die vollständige Aufzeichnung bleibt in der Station gespeichert.' : ''),
          M + 2, 8, MUT);
      } else {
        T('Keine Gabe bestätigt. (Empfehlungen werden nicht automatisch protokolliert — es wurde also '
          + 'entweder nichts gegeben oder nichts markiert.)', M + 2, 8.6, 'italic', MUT);
        nl(6);
      }
      nl(2);

      // Verlaufsprotokoll
      if (L.length) {
        sectionTitle('Verlaufsprotokoll — Messwerte (' + L.filter(function (e) { return !e || e.art !== 'med'; }).length + ' Einträge)');
        var cols = [22, 15, 16, 20, 16, 14, 17, 60];
        tableHead(['Zeit', 'HF', 'SpO₂', 'EtCO₂', 'MAP', 'AF', 'Temp', 'Befund / Rhythmus'], cols);
        /*
         * AUSGEDUENNT WIRD NUR DER MESSVERLAUF. Bei einer langen Narkose wird jede n-te Messzeile
         * gedruckt, sonst waeren es hunderte Seiten.
         *
         * GABEN STEHEN HIER NICHT MEHR (Befund 19.08.2026). Bis dahin wurden sie eingemischt -
         * mit der Begruendung, sie seien der Grund, aus dem sich die Werte danach aendern. Am
         * ausgedruckten Blatt sah das anders aus: jede Gabe stand zweimal auf derselben Seite,
         * einmal in der Tabelle darueber mit Dosis und Weg und einmal hier ohne beides. Die
         * Tabelle "Verabreichte Medikamente" ist die vollstaendigere Fuehrung, und sie steht
         * mit Uhrzeit direkt darueber - der Zusammenhang zu den Werten bleibt also ablesbar.
         */
        var vit = L.filter(function (e) { return !e || e.art !== 'med'; });
        var step = Math.max(1, Math.ceil(vit.length / 60));
        var zeilen = [];
        for (var i = 0; i < vit.length; i += step) zeilen.push(vit[i]);
        zeilen.forEach(function (e) {
          if (e.art === 'med') {
            var md2 = e.med || {};
            tableRow([hhmmss(e.ts), '', '', '', '', '', '',
              (md2.storno ? '[zurückgenommen] ' : '[GEGEBEN] ') + md2.name + (md2.dosis ? ' - ' + md2.dosis : '')], cols, 7.8);
            return;
          }
          tableRow([hhmmss(e.ts), String(nn(e.hr)), String(nn(e.spo2)), String(nn(e.etco2)), String(nn(e.map)), String(nn(e.af)), String(nn(e.temp)), (e.finding || nn(e.rhythm) || '')], cols, 7.8);
        });
        tabelleEnde();
      }

      if (idx < keys.length - 1) { tabelleEnde(); footer(); doc.addPage(); }
    });
    footer();

    /*
     * WESSEN NARKOSEPROTOKOLL IST DAS? (Nachbesserung N10/oberflaechen, 31.07.2026)
     *
     * Hier stand bis 1.0.3 die harte Konstante 'VetStation'. Solange es je Praxis genau einen
     * Kiosk gab, war das nur unschoen. Mit mehreren OP-Saelen im selben Praxis-Konto ist es ein
     * Mangel am DOKUMENT: zwei Ausdrucke desselben Tages, aus verschiedenen Saelen, mit
     * derselben Kopfzeile — und keine Angabe, welcher PC welchen geschrieben hat.
     *
     * Der Name kommt aus GET /api/station, also aus data/station-id.json, also aus derselben
     * einen Quelle wie Tafel, Spiegel und Fern-Ansicht (stationsName()). Die Kennung steht
     * daneben, weil zwei Saele denselben Namen tragen KOENNEN — sie ist das, was sie
     * unterscheidet. Ist noch nichts geladen, bleibt es beim alten Wort: ein Ausdruck ohne
     * Saalnamen ist besser als ein Ausdruck, der auf eine Antwort wartet.
     */
    function station() {
      var s = state.saal;
      if (!s || !s.name) return 'VetStation';
      return s.name + (s.kurz ? ' · ' + s.kurz : '');
    }

    var one = keys.length === 1;
    var fid = one ? ((meta[keys[0]] && meta[keys[0]].patientId) || ((state.patients.find(function (x) { return x.patientKey === keys[0]; }) || {}).patientId) || 'Patient') : 'Alle-Patienten';
    var datei = 'Narkoseprotokoll_' + String(fid).replace(/[^\w-]+/g, '-') + '_' + new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-') + '.pdf';
    /*
     * DER FERN-ANSICHT SAGEN, DASS HIER GERADE EIN PROTOKOLL ENTSTANDEN IST (21.08.2026).
     *
     * Wunsch aus der Praxis, woertlich: "wenn in Vetstation ein Protokoll gespeichert oder
     * ausgedruckt oder erstellt wird, muss es direkt auch in der Web-App ankommen, damit man es
     * ueberall ausdrucken kann."
     *
     * WARUM HIER UND NICHT ERST BEIM KLICK AUF "DRUCKEN": das Dokument entsteht in dieser Zeile.
     * Ob es danach gedruckt, gespeichert oder nur angesehen wird, aendert nichts daran, dass es
     * existiert — und wer es fern drucken will, wartet dann nicht darauf, dass am Praxis-PC
     * ausserdem noch jemand auf den Drucker klickt. Die spaeteren Knoepfe melden ihre eigene Art
     * zusaetzlich (siehe zeigePdfVorschau), damit fern ablesbar ist, was wirklich geschah.
     *
     * ES WIRD KEIN PDF UEBERTRAGEN, sondern die Anforderung, die ZEILEN vollstaendig zu
     * uebertragen. Die Datenbankregeln begrenzen jede Zeichenkette unter einem Saal auf 12000
     * Zeichen; ein base64-kodiertes Protokoll waere ein Vielfaches davon und wuerde still
     * abgewiesen. Die Fern-Ansicht setzt ihr Blatt aus denselben Zeilen selbst zusammen.
     */
    keys.forEach(function (k) { protokollGemeldet(k, 'erstellt', datei, gedruckteZeilen[k]); });
    zeigePdfVorschau(doc, datei, keys);
  }

  /*
   * protokollGemeldet(key, art, datei) — EIN Weg, drei Anlaesse (erstellt / gedruckt / gespeichert).
   *
   * Absichtlich eine eigene Funktion und nicht dreimal derselbe send(): die Zuordnung
   * patientKey -> patientId ist hier nicht trivial (die Kennung kann aus dem laufenden Patienten,
   * aus den gemerkten Stammdaten oder aus dem Protokollbestand kommen), und sie an drei Stellen
   * zu wiederholen ist genau die Bauart, bei der eine davon spaeter vergessen wird.
   */
  function protokollGemeldet(key, art, datei, zahlen) {
    try {
      var p = (state.patients || []).find(function (x) { return x.patientKey === key; }) || {};
      var m = meta[key] || {};
      var pid = m.patientId || p.patientId || key;
      if (!pid) return;
      /* Bevorzugt die Zahlen des tatsaechlich gesetzten Blattes; der Fenster-Rueckfall nur,
       * wenn es keine gibt. Sonst meldet ein Ausdruck aus dem Bestand "0 Zeilen". */
      var L = (log[key] || []);
      send({
        /* Zeichenkette statt Konstante: diese Datei laedt bridge/src/model.js nicht (sie laeuft
         * im Browser). Der Wert steht dort als MSG.PROTOKOLL_ERZEUGT und muss gleich lauten —
         * tools/protokoll-fern-test.js haelt beide Stellen gegeneinander. */
        type: 'protokollErzeugt',
        patientId: pid, patientKey: key,
        patientName: (zahlen && zahlen.name) || m.patientName || p.patientName || '',
        art: art || 'erstellt', datei: datei || '',
        zeilen: (zahlen && zahlen.zeilen != null) ? zahlen.zeilen : L.length,
        gaben: (zahlen && zahlen.gaben != null) ? zahlen.gaben : L.filter(function (e) { return e && e.art === 'med'; }).length,
      });
    } catch (e) { /* Ein Ausdruck darf nie an einer Meldung scheitern. */ }
  }

  /* =====================================================================
   * PDF-ANSICHT MIT RUECKWEG
   * =====================================================================
   * Hier stand bis 1.2.2 nur doc.save(). Am Praxis-PC laeuft die Station in einem Edge OHNE
   * Fensterrahmen (kiosk/launch-kiosk.ps1 startet ihn mit --kiosk). Ein gespeichertes PDF oeffnet
   * dort im PDF-Betrachter — und in dem gibt es keine Adresszeile, keinen Zurueck-Pfeil und keine
   * Reiter. Wer den Ausdruck ansah, kam ohne Tastenkuerzel nicht mehr zum Dashboard zurueck: eine
   * Sackgasse mitten in einer Narkose. Genau dieselbe Ueberlegung steht schon bei injectKiosk()
   * ueber den ausgeblendeten Fremdlinks — sie war dort nur nicht zu Ende gefuehrt.
   *
   * Deshalb bleibt das PDF INNERHALB der Station: es wird in ein eigenes Fenster ueber dem
   * Dashboard gelegt, mit einer Kopfzeile, die drei Wege anbietet — zurueck zum Dashboard,
   * blaettern zwischen mehreren Patienten, und erst dann Drucken/Speichern. Esc geht ebenfalls
   * zurueck. Kann der Browser das Blob nicht anzeigen (sehr alter Betrachter), bleibt der alte
   * Weg als Rueckfall erhalten — dann ist ein Ausdruck immer noch besser als keiner.
   */
  var pdfStand = null;   // { doc, datei, keys, idx }
  function zeigePdfVorschau(doc, datei, keys) {
    var host = $('#pdfView');
    if (!host) { host = document.createElement('div'); host.id = 'pdfView'; host.className = 'vsx-pdf'; document.body.appendChild(host); }
    var url = null;
    try { url = doc.output('bloburl'); } catch (e) { url = null; }
    if (!url) { try { doc.save(datei); } catch (e2) { alert('Das PDF konnte nicht erzeugt werden.'); } return; }

    var liste = exportablePatients();
    var idx = (keys.length === 1) ? liste.findIndex(function (p) { return p.key === keys[0]; }) : -1;
    var titel = (keys.length === 1) ? patientTitel(keys[0]) : 'Alle Patienten (' + keys.length + ')';
    pdfStand = { datei: datei, keys: keys, url: url };

    host.innerHTML =
      '<div class="pdfbox">' +
        '<div class="pdfhead">' +
          '<button class="vsx-btn pdfback" id="pdfBack" title="Zurück zum Dashboard (Esc)">← Zurück zum Dashboard</button>' +
          '<button class="vsx-btn" id="pdfPrev" title="Voriger Patient"' + (idx > 0 ? '' : ' disabled') + '>‹ Voriger</button>' +
          '<span class="pdftitle">⤓ Narkoseprotokoll · ' + esc(titel) + '</span>' +
          '<button class="vsx-btn" id="pdfNext" title="Nächster Patient"' + (idx >= 0 && idx < liste.length - 1 ? '' : ' disabled') + '>Nächster ›</button>' +
          '<div style="flex:1"></div>' +
          '<button class="vsx-btn" id="pdfPrint" title="Drucken">🖨 Drucken</button>' +
          '<button class="vsx-btn" id="pdfSave" title="Als Datei speichern">⤓ Speichern</button>' +
          '<button class="vsx-btn" id="pdfClose" title="Schließen (Esc)">✕</button>' +
        '</div>' +
        '<iframe class="pdfframe" id="pdfFrame" title="Narkoseprotokoll"></iframe>' +
        '<div class="pdffoot">Diese Ansicht bleibt in der VetStation — der Kiosk-Browser hat keinen eigenen Zurück-Knopf. ' +
          'Esc oder „Zurück zum Dashboard“ führt zurück, ohne dass etwas verloren geht.</div>' +
      '</div>';
    host.querySelector('#pdfFrame').src = url;
    host.classList.add('open');

    host.querySelector('#pdfBack').onclick = host.querySelector('#pdfClose').onclick = schliessePdf;
    host.querySelector('#pdfPrint').onclick = function () {
      /* Zusaetzlich zur Meldung beim Erzeugen: fern soll ablesbar sein, ob ein Blatt wirklich
       * auf Papier ging oder nur angesehen wurde. Ein Nachtrag, der schon laeuft, wird dadurch
       * nicht doppelt angestossen (cloud.protokollNachtragen kehrt dann sofort zurueck). */
      keys.forEach(function (k) { protokollGemeldet(k, 'gedruckt', datei); });
      var fr = $('#pdfFrame');
      // Aus dem eingebetteten Betrachter drucken; klappt das nicht (manche Betrachter erlauben
      // kein print() von aussen), das Blob in einem eigenen Fenster oeffnen — dort gibt es dann
      // wieder eine Browserleiste, und das Dashboard bleibt darunter unveraendert stehen.
      try { fr.contentWindow.focus(); fr.contentWindow.print(); }
      catch (e) { try { window.open(url, '_blank'); } catch (e2) { doc.save(datei); } }
    };
    host.querySelector('#pdfSave').onclick = function () {
      keys.forEach(function (k) { protokollGemeldet(k, 'gespeichert', datei); });
      try { doc.save(datei); } catch (e) {}
    };
    var pv = host.querySelector('#pdfPrev'), nx = host.querySelector('#pdfNext');
    if (pv && idx > 0) pv.onclick = function () { schliessePdf(); doExportPDF([liste[idx - 1].key]); };
    if (nx && idx >= 0 && idx < liste.length - 1) nx.onclick = function () { schliessePdf(); doExportPDF([liste[idx + 1].key]); };
  }
  function schliessePdf() {
    var host = $('#pdfView'); if (!host) return;
    host.classList.remove('open');
    var fr = $('#pdfFrame'); if (fr) fr.src = 'about:blank';
    // Blob wieder freigeben: bei jedem Ausdruck entsteht ein neues, sonst bleiben sie bis zum
    // Neuladen der Seite im Speicher liegen (auf einem Kiosk-PC laeuft die Seite tagelang).
    if (pdfStand && pdfStand.url) { try { URL.revokeObjectURL(pdfStand.url); } catch (e) {} }
    pdfStand = null;
    host.innerHTML = '';
  }
  function patientTitel(key) {
    var p = (state.patients || []).find(function (x) { return x.patientKey === key; });
    var m = meta[key] || {};
    return (p && (p.patientName || p.patientId)) || m.patientId || key;
  }
  // Esc fuehrt aus JEDEM Overlay zurueck — dieselbe Taste, gleich wo man steht.
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var pv = $('#pdfView'); if (pv && pv.classList.contains('open')) { schliessePdf(); return; }
    var ex = $('#exportDlg'); if (ex && ex.classList.contains('open')) { ex.classList.remove('open'); return; }
    var pr = $('#pairing'); if (pr && pr.classList.contains('open')) { closePairing(); return; }
    var ad = $('#admin');
    if (ad && ad.classList.contains('open') && window.VSADMIN && window.VSADMIN.close) { window.VSADMIN.close(); return; }
  });

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  /*
   * pdfSan — Text fuer jsPDF (helvetica = Latin-1/WinAnsi) auf darstellbare Zeichen bringen.
   * Ohne das wurden Subscripts, Pfeile und Sonderzeichen zu Muell (O₂ -> "O ‚", ↑ -> "!'"), und die
   * ganze Zeile verrutschte. Bekannte Zeichen werden sinnvoll ersetzt, alles uebrige Nicht-Latin-1
   * (inkl. Emojis) entfernt. Umlaute/°/· bleiben (die sind in Latin-1 und werden korrekt gedruckt).
   */
  function pdfSan(s) {
    if (Array.isArray(s)) return s.map(pdfSan);
    return String(s == null ? '' : s)
      .replace(/₀/g, '0').replace(/₁/g, '1').replace(/₂/g, '2').replace(/₃/g, '3').replace(/₄/g, '4')
      .replace(/₅/g, '5').replace(/₆/g, '6').replace(/₇/g, '7').replace(/₈/g, '8').replace(/₉/g, '9')
      .replace(/[↑⬆]/g, ' hoch').replace(/[↓⬇]/g, ' tief').replace(/→/g, '->').replace(/←/g, '<-').replace(/↔/g, '<->')
      .replace(/[–—―]/g, '-').replace(/[‘’‚‛]/g, "'").replace(/[“”„‟]/g, '"').replace(/…/g, '...')
      .replace(/[•●]/g, '-').replace(/≈/g, '~').replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/×/g, 'x')
      .replace(/[^\x00-\xFF]/g, '');
  }
  function cssEsc(s) { return String(s).replace(/["\\]/g, '\\$&'); }

  // ---------- Geräte-Übersicht & manuelles Koppeln (§6) ----------
  function statusTxt(s) { return s === 'active' ? 'aktiv' : s === 'standby' ? 'Standby' : s === 'connected' ? 'verbunden' : s === 'error' ? 'Fehler' : 'offline'; }
  function statusCol(s) { return s === 'active' ? '#35d69a' : s === 'standby' ? '#ffc23c' : s === 'error' ? '#ff5470' : '#8ba0b6'; }
  function roleTxt(r) { return r === 'monitor' ? 'Monitor' : r === 'anesthesia' ? 'Narkose/Kapno' : r === 'capno' ? 'Kapnograf' : 'Kombi'; }
  function openPairing() { pairingOpen = true; var el = $('#pairing'); if (el) el.classList.add('open'); renderPairing(); }
  function closePairing() { pairingOpen = false; var el = $('#pairing'); if (el) el.classList.remove('open'); }

  function renderPairing() {
    var host = $('#pairing'); if (!host) return;
    var devs = state.devices || [];
    var rows = devs.map(function (d) {
      var sp = spOf(d.species), m = d.meta || {};
      var pat = d.patientId ? esc(d.patientId) : (d.species ? (sp.name + ' ' + (d.weightKg || '?') + 'kg') : '—');
      var paired = d.manualKey ? '<span class="pk">🔗 gekoppelt</span>' : '';
      /*
       * WAS HIER NEU IST (22.07.2026): Adresse, Port, Uebertragungsweg, Anzahl anliegender
       * Messwerte und die Klartextmeldungen des Geraets. Vorher stand hier nur ein interner Name -
       * die Frage "welches Geraet haengt gerade dran und kommen Daten?" war aus der Oberflaeche
       * heraus nicht zu beantworten, obwohl die Bridge all das laengst kennt.
       * "zuletzt vor X s" steht bewusst in einem eigenen Knoten (.pzeit) und wird NICHT ueber die
       * Neuaufbau-Signatur gefuehrt - ein sekuendlich wandernder Wert wuerde den Tippschutz unten
       * aushebeln und den Dialog dauernd neu bauen.
       */
      var adresse = d.ip ? (esc(d.ip) + (d.port ? ':' + d.port : '')) : 'Adresse unbekannt';
      var weg = d.transport ? ' · ' + esc(d.transport) : '';
      var werte = d.werteAnzahl > 0
        ? '<span class="pok">' + d.werteAnzahl + ' Messwerte</span>'
        : '<span class="pfehlt">keine Messwerte</span>';
      var kurven = (d.kurven && d.kurven.length) ? ' · ' + esc(d.kurven.join(', ')) : '';
      var meldungen = (d.alarms || []).slice(0, 30).map(function (a) {
        return '<div class="palarm">⚠ ' + esc(a && a.text ? a.text : a) + '</div>';
      }).join('');
      /*
       * PATIENTENAKTE DES GERAETS ANZEIGEN (23.07.2026).
       * Der Ausloeser: der Tierarzt sagte wiederholt "erkennt keine Patientendaten". Tatsaechlich
       * las die Bridge Name, Geschlecht, Alter usw. - die Oberflaeche zeigte davon aber NICHTS
       * (0 Treffer im Quelltext). Was nicht im Bild steht, gilt als nicht erkannt. Hier steht jetzt
       * die vollstaendige Akte, soweit das Geraet sie liefert. Was fehlt, wird als fehlend gezeigt,
       * nicht erfunden.
       */
      var ak = d.akte || {};
      var akteZeilen = [];
      function feld(label, wert) { if (wert != null && wert !== '') akteZeilen.push('<span class="pakf"><i>' + label + '</i> ' + esc(String(wert)) + '</span>'); }
      feld('Name', d.patientName);
      feld('Besitzer', ak.besitzer);
      feld('Tierart', d.species ? spOf(d.species).name : null);
      feld('Rasse', ak.rasse);
      feld('Gewicht', d.weightKg != null ? d.weightKg + ' kg' : null);
      feld('Größe', ak.groesseCm != null ? ak.groesseCm + ' cm' : null);
      // Alter bevorzugt aus dem Geb.datum berechnen (sonst das vom Geraet gelieferte Alter).
      feld('Alter', alterText({ gebDatum: d.gebDatum, akte: ak }));
      feld('Geschlecht', geschlechtText(d.geschlecht));
      feld('Geb.', datumText(d.gebDatum));
      feld('Blutgruppe', ak.blutgruppe);
      feld('Schrittmacher', ak.pacer == null ? null : (ak.pacer ? 'ja' : 'nein'));
      feld('Arzt', ak.arzt);
      feld('Bett', ak.bett);
      feld('Telefon', ak.telefon);
      // Herkunft der sicherheitskritischen Angaben kennzeichnen (Geraet vs. von Hand gesetzt).
      var hk = d.herkunft || {};
      var quelle = '';
      if (hk.weightKg === 'manuell' || hk.species === 'manuell') quelle = '<span class="pmuted"> (Tierart/Gewicht von Hand gesetzt)</span>';
      else if (hk.weightKg === 'geraet' || hk.species === 'geraet') quelle = '<span class="pmuted"> (vom Gerät übernommen)</span>';
      // Fehlt Tierart oder Gewicht, ist das KEIN Fehler: das LifeVet sendet diese Angaben
      // nachweislich nicht über HL7 (nur ID, Name, Geschlecht). Sie werden einmal von Hand gesetzt
      // und bleiben danach für diesen Patienten erhalten (an die ID gebunden, überlebt Neustarts).
      var fehltDosisbasis = !d.species || d.weightKg == null;
      var hinweis = fehltDosisbasis
        ? '<div class="pfehlt" style="margin-top:2px">Dieses Gerät sendet Tierart und Gewicht nicht mit — unten eintragen. Der Eintrag bleibt für Patient ' + esc(d.patientId || '?') + ' gespeichert.</div>'
        : '';
      var akteBlock = (akteZeilen.length
        ? '<div class="pakte">' + akteZeilen.join('') + quelle + '</div>'
        : '<div class="pmuted">Noch keine Patientendaten. Am Gerät die Patientenverwaltung mit OK bestätigen (sendet ID/Name) — Tierart/Gewicht unten von Hand setzen.</div>') + hinweis;
      // EKG-AUSWERTUNG (QRS/Rhythmus/ST) auf der echten Kurve - nur zeigen, wenn belastbar.
      var ekgBlock = '';
      var ea = d.ekgAnalyse;
      if (ea) {
        if (ea.brauchbar) {
          var r = ea.rhythmus || {};
          var teile = [];
          if (ea.hf != null) teile.push('<i>HF</i> ' + ea.hf + '/min');
          if (ea.qrsBreiteMs != null) teile.push('<i>QRS</i> ' + ea.qrsBreiteMs + ' ms');
          if (r.name) teile.push('<i>Rhythmus</i> ' + esc(r.name) + (r.sicherheit === 'Verdacht' ? ' ⚠' : ''));
          if (ea.st && ea.st.messbar) teile.push('<i>ST</i> ' + esc(ea.st.richtung) + ' (' + ea.st.mv + ' mV)');
          else if (ea.st && ea.st.richtung) teile.push('<i>ST</i> ' + esc(ea.st.richtung));
          ekgBlock = '<div class="pekg"><b>EKG-Analyse</b> ' + teile.join(' · ') +
            (r.begruendung ? '<div class="pmuted">' + esc(r.begruendung) + '</div>' : '') + '</div>';
        } else if (ea.warum) {
          ekgBlock = '<div class="pekg pmuted"><b>EKG-Analyse:</b> ' + esc(ea.warum) + '</div>';
        }
      }
      akteBlock += ekgBlock;
      return '<div class="pdev" data-id="' + esc(d.deviceId) + '">' +
        '<label class="pcheck"><input type="checkbox" data-sel="' + esc(d.deviceId) + '"' + (pairSel[d.deviceId] ? ' checked' : '') + '></label>' +
        '<span class="pstat" style="--sc:' + statusCol(d.status) + '" title="' + statusTxt(d.status) + '"></span>' +
        '<div class="pinfo"><b>' + esc(d.model || 'Gerät') + '</b> <span class="prole">' + roleTxt(d.role) + '</span> ' + paired +
        '<div class="pmuted">' + adresse + weg + ' · ' + statusTxt(d.status) +
        ' · <span class="pzeit" data-zeit="' + esc(d.deviceId) + '"></span></div>' +
        akteBlock +
        '<div class="pmuted">' + werte + kurven + '</div>' +
        meldungen +
        '<button class="vsx-btn palle" data-alle="' + esc(d.deviceId) + '">Alle Werte vom Gerät anzeigen</button>' +
        '<div class="prohbox" data-roh="' + esc(d.deviceId) + '" hidden></div></div>' +
        '<div class="pmeta">' + spSelect(m.species || d.species) +
        '<input class="pw" type="number" step="0.1" placeholder="kg" value="' + (m.weightKg || '') + '" data-mw="' + esc(d.deviceId) + '">' +
        '<input class="pid" placeholder="Patient-ID" value="' + esc(m.patientId || '') + '" data-mid="' + esc(d.deviceId) + '">' +
        '<button class="vsx-btn pmset" data-meta="' + esc(d.deviceId) + '">✓ setzen</button></div></div>';
    }).join('') || '<p class="pmuted" style="padding:16px">Noch keine Geräte erkannt. Sobald ein Monitor/Kapnograf verbunden ist (Serveradresse am Gerät = PC-IP), erscheint er hier.</p>';
    /*
     * GRUPPEN SICHTBAR MACHEN (23.07.2026): Geraete, die zu EINEM Patienten gehoeren, laufen in
     * EINEM Fenster zusammen. Der Tierarzt soll auf einen Blick sehen, welche das sind - egal ob
     * automatisch (gleiche Patienten-ID vom Geraet) oder von Hand gekoppelt.
     */
    var gruppen = {};
    (state.patients || []).forEach(function (p) {
      if ((p.devices || []).length >= 2) {
        gruppen[p.patientKey] = { name: p.patientName || p.patientId || 'Patient', geraete: p.devices.map(function (x) { return x.model; }) };
      }
    });
    var gruppenHinweis = Object.keys(gruppen).map(function (k) {
      var g = gruppen[k];
      return '<div class="pgrp">🔗 <b>' + esc(g.name) + '</b>: ' + esc(g.geraete.join(' + ')) + ' — laufen in einem Fenster.</div>';
    }).join('');

    var neu = '<div class="pbox"><div class="phead"><h2>🔌 Geräte &amp; Koppeln</h2><div style="flex:1"></div>' +
      '<button class="vsx-btn" id="pClose">✕</button></div>' +
      '<p class="pmuted" style="margin:0 0 10px">Geräte werden automatisch erkannt und pro Patient zusammengeführt (gleiche Patienten-ID = ein Fenster). Stimmt die Zuordnung nicht — z.B. Narkosegerät und Monitor haben verschiedene IDs: die Geräte ankreuzen und <b>koppeln</b>. Oder Tierart/Gewicht/ID direkt setzen.</p>' +
      gruppenHinweis +
      '<div class="plist">' + rows + '</div>' +
      '<div class="pfoot"><button class="vsx-btn" id="pMerge">🔗 Ausgewählte zu 1 Patienten koppeln</button>' +
      '<button class="vsx-btn" id="pUnmerge">✂ Kopplung aufheben</button>' +
      '<div style="flex:1"></div><button class="vsx-btn" id="pClose2">Schließen</button></div></div>';

    // NUR bei echter Änderung neu aufbauen. Dieser Dialog wird aus refresh() heraus im
    // 500-ms-Takt aufgerufen; wurde er dabei jedes Mal komplett neu geschrieben, verlor der
    // Anwender beim TIPPEN sofort Feld und Fokus — Gewicht und Patienten-ID liessen sich
    // praktisch nicht eingeben. Das war der zweite Teil von "man kann gar nicht mit der App
    // arbeiten" und blieb auch nach der Behebung des iframe-Neuladens bestehen.
    //
    // Die Signatur kommt NUR aus den Gerätedaten vom Server — nicht aus der lokalen Auswahl
    // (Häkchen). Sonst würde ein Klick auf ein Kästchen den ganzen Dialog neu bauen.
    var sig = devs.map(function (d) {
      var m = d.meta || {};
      return [d.deviceId, d.model, d.role, d.status, d.patientId, d.species, d.weightKg,
        d.manualKey, m.species, m.weightKg, m.patientId,
        // Neu, aber allesamt STABILE Werte. seitMs/taktMs fehlen hier bewusst: sie ändern sich
        // sekündlich und würden den Dialog dauernd neu bauen — genau der Fokusverlust, der früher
        // das Tippen unmöglich machte. Sie werden unten per textContent nachgeführt.
        d.ip, d.port, d.transport, d.werteAnzahl, (d.kurven || []).join(','),
        // Patientenakte in die Signatur: aendert sie sich, wird der Akte-Block neu gezeichnet.
        d.patientName, d.geschlecht, d.gebDatum, JSON.stringify(d.akte || {}), JSON.stringify(d.herkunft || {}),
        // EKG-Analyse in die Signatur (aendert sich nur je Streifen, ~alle 30 s - kein Flackern).
        d.ekgAnalyse ? (d.ekgAnalyse.hf + '/' + d.ekgAnalyse.qrsBreiteMs + '/' + (d.ekgAnalyse.rhythmus && d.ekgAnalyse.rhythmus.name) + '/' + d.ekgAnalyse.brauchbar) : '',
        (d.alarms || []).map(function (a) { return a && a.text ? a.text : a; }).join('|')].join('');
    }).join('');
    if (host.__sig === sig) { aktualisierePairingZeiten(); return; }

    // Zusätzliche Sicherung: solange der Anwender in einem Feld dieses Dialogs schreibt, wird
    // NICHT neu gebaut. Eine halb getippte Patienten-ID darf nie verlorengehen.
    var fokus = document.activeElement;
    if (fokus && host.contains(fokus) && /^(INPUT|SELECT|TEXTAREA)$/.test(fokus.tagName)) { aktualisierePairingZeiten(); return; }

    host.__sig = sig;
    host.innerHTML = neu;
    host.querySelector('#pClose').onclick = host.querySelector('#pClose2').onclick = closePairing;
    host.querySelectorAll('[data-sel]').forEach(function (cb) { cb.onchange = function () { pairSel[cb.getAttribute('data-sel')] = cb.checked; }; });
    host.querySelectorAll('[data-meta]').forEach(function (b) { b.onclick = function () { applyMeta(b.getAttribute('data-meta'), host); }; });
    host.querySelectorAll('[data-alle]').forEach(function (b) { b.onclick = function () { zeigeAlleWerte(b.getAttribute('data-alle'), host, b); }; });
    aktualisierePairingZeiten();
    host.querySelector('#pMerge').onclick = mergeSelected;
    host.querySelector('#pUnmerge').onclick = unmergeSelected;
  }
  /*
   * Sekündlich wandernde Angaben NUR per textContent nachführen — nie über innerHTML.
   * Der Dialog darf dabei nicht neu gebaut werden, sonst verliert der Anwender beim Tippen
   * sofort Feld und Fokus (der Fehler, der das Eingeben von Gewicht/Patienten-ID unmöglich machte).
   */
  function aktualisierePairingZeiten() {
    var host = $('#pairing'); if (!host) return;
    var devs = state.devices || [];
    devs.forEach(function (d) {
      var el = host.querySelector('[data-zeit="' + cssEsc(d.deviceId) + '"]');
      if (!el) return;
      var t = '';
      if (d.seitMs == null) t = 'noch keine Daten';
      else if (d.seitMs < 2000) t = 'Daten kommen gerade';
      else t = 'zuletzt vor ' + Math.round(d.seitMs / 1000) + ' s';
      if (d.taktMs) t += ' · sendet etwa alle ' + Math.max(1, Math.round(d.taktMs / 1000)) + ' s';
      if (el.textContent !== t) el.textContent = t;
    });
  }

  /*
   * "Alle Werte vom Gerät" — die Antwort auf "liest die App überhaupt etwas?".
   * Holt die Rohwerte auf Abruf (nicht im 500-ms-Takt, sonst würde die Liste ständig neu gebaut)
   * und zeigt JEDEN Eintrag, den das Gerät geschickt hat — auch den, den die Station nicht deuten
   * kann. Nichts wird weggelassen.
   */
  function zeigeAlleWerte(id, host, btn) {
    var box = host.querySelector('[data-roh="' + cssEsc(id) + '"]');
    if (!box) return;
    if (!box.hidden) { box.hidden = true; btn.textContent = 'Alle Werte vom Gerät anzeigen'; return; }
    box.hidden = false;
    btn.textContent = 'Werte ausblenden';
    box.innerHTML = '<p class="pmuted">wird geladen…</p>';
    fetch('api/geraet?id=' + encodeURIComponent(id)).then(function (r) { return r.json(); }).then(function (o) {
      var roh = (o && o.roh) || [];
      if (!roh.length) { box.innerHTML = '<p class="pmuted">Das Gerät hat bisher keine Einzelwerte geschickt.</p>'; return; }
      box.innerHTML = '<table class="proh"><tr><th>Bezeichnung</th><th>Wert</th><th>Einheit</th></tr>' +
        roh.map(function (x) {
          return '<tr><td>' + esc(x.bezeichnung || x.code || '—') + '</td><td>' + esc(x.wert) +
            (x.flag ? ' <b>' + esc(x.flag) + '</b>' : '') + '</td><td>' + esc(x.einheit || '') + '</td></tr>';
        }).join('') + '</table>';
    }).catch(function () { box.innerHTML = '<p class="pmuted">Werte konnten nicht geladen werden.</p>'; });
  }

  function spSelect(cur) {
    var opts = (A().species || []).map(function (s) { return '<option value="' + s.id + '"' + (s.id === cur ? ' selected' : '') + '>' + s.icon + ' ' + s.name + '</option>'; }).join('');
    return '<select class="psp"><option value="">Art…</option>' + opts + '</select>';
  }
  function applyMeta(id, host) {
    var row = host.querySelector('.pdev[data-id="' + cssEsc(id) + '"]'); if (!row) return;
    var sp = row.querySelector('.psp').value || null;
    var w = parseFloat(row.querySelector('.pw').value); if (isNaN(w)) w = null;
    var pid = row.querySelector('.pid').value.trim() || null;
    send({ type: 'setMeta', deviceId: id, meta: { species: sp, weightKg: w, patientId: pid } });
    var btn = row.querySelector('.pmset'); if (btn) { btn.textContent = '✓ gesetzt'; setTimeout(function () { btn.textContent = '✓ setzen'; }, 1400); }
  }
  function selectedIds() { return Object.keys(pairSel).filter(function (k) { return pairSel[k]; }); }
  function mergeSelected() { var ids = selectedIds(); if (!ids.length) return; send({ type: 'pair', deviceIds: ids, patientKey: 'pair:' + ids[0] }); pairSel = {}; }
  function unmergeSelected() {
    var keys = {};
    (state.devices || []).forEach(function (d) { if (pairSel[d.deviceId] && d.manualKey) keys[d.manualKey] = 1; });
    Object.keys(keys).forEach(function (k) { send({ type: 'unpair', patientKey: k }); });
    pairSel = {};
  }

  /* =====================================================================
   * BESTAETIGTE MEDIKAMENTENGABEN AUS DEN PATIENTENFENSTERN
   * =====================================================================
   * Jedes Fenster ist eine eigene Anaesthesie-App in einem iframe. Klickt der Tierarzt dort
   * „als gegeben", meldet die App das per postMessage nach oben (ui/app/index.html: medBuchen).
   * Diese Schicht weiss als EINZIGE, zu welchem Patienten das Fenster gehoert — die App im
   * iframe kennt nur Tierart und Gewicht, nicht die Patientenkennung. Deshalb wird hier
   * zugeordnet und dann an die Bridge weitergereicht, wo die Gabe ins dauerhafte OP-Protokoll
   * geht (und von dort in den PDF-Ausdruck und in die Fern-Ansicht).
   *
   * WARUM UEBER e.source UND NICHT UEBER EINE KENNUNG IN DER NACHRICHT: die Zuordnung darf nicht
   * von etwas abhaengen, das im iframe steht. Bei zwei gleichzeitigen Narkosen wuerde eine
   * verwechselte Kennung die Gabe dem falschen Tier zuschreiben. Das sendende Fenster ist die
   * einzige Angabe, die der Browser selbst setzt und die niemand faelschen kann.
   *
   * Nachrichten von fremden Fenstern (Browsererweiterungen, andere Seiten) treffen ins Leere:
   * ohne Treffer in windows{} passiert nichts.
   */
  function fensterVonQuelle(quelle) {
    for (var k in windows) {
      var w = windows[k];
      var cw = null; try { cw = w && w.frame && w.frame.contentWindow; } catch (e) { cw = null; }
      if (cw && cw === quelle) return { key: k, w: w };
    }
    return null;
  }
  function medEmpfangen(quelle, gabe) {
    var t = fensterVonQuelle(quelle);
    if (!t || !gabe || typeof gabe !== 'object' || !gabe.name) return;
    var p = null;
    for (var i = 0; i < state.patients.length; i++) {
      if (state.patients[i].patientKey === t.key) { p = state.patients[i]; break; }
    }
    var pid = (p && p.patientId) || (meta[t.key] && meta[t.key].patientId) || t.key;
    // Sofort in das Fenster-Protokoll: der Ausdruck soll die Gabe auch dann zeigen, wenn die
    // Bridge gerade nicht antwortet (sie ist die dauerhafte Quelle, nicht die einzige).
    logMed(t.key, gabe);
    send({ type: 'medGabe', patientKey: t.key, patientId: pid, gabe: gabe });
    flashToast((gabe.storno ? '↩ zurückgenommen: ' : '💉 protokolliert: ') + gabe.name);
  }
  function logMed(key, gabe) {
    var L = log[key] || (log[key] = []);
    var ts = Date.now();
    for (var i = L.length - 1; i >= 0 && i >= L.length - 50; i--) { if (L[i] && L[i].ts >= ts) ts = L[i].ts + 1; }
    L.push({
      ts: ts, art: 'med',
      med: { name: gabe.name, kind: gabe.kind, kindText: gabe.kindText, wirkstoffId: gabe.id,
        dosis: gabe.dosis, route: gabe.route, kg: gabe.kg, storno: gabe.storno === true,
        breed: gabe.breedName || gabe.breed || null, warnLevel: gabe.warnLevel || null, warnText: gabe.warnText || null,
        // Die Herkunft muss hier mitlaufen (24.08.2026): dieses Fensterprotokoll ist der Weg
        // in den AUSDRUCK, die Registry der Weg in die Akte. Steht die Herkunft nur in einem
        // von beiden, widersprechen sich hinterher zwei Papiere derselben Narkose.
        incId: gabe.incId ? String(gabe.incId).slice(0, 40) : null,
        incName: gabe.incName ? String(gabe.incName).slice(0, 80) : null,
        quelle: gabe.quelle ? String(gabe.quelle).slice(0, 24) : null,
        rang: (gabe.rang != null && isFinite(Number(gabe.rang))) ? Number(gabe.rang) : null },
      // Auch hier jeden Anteil kappen — dieselbe Begruendung wie in registry.medikamentGabe:
      // die Zeile geht in dieselbe Liste und faellt unter dieselbe 2000-Zeichen-Regel.
      finding: (gabe.storno ? '↩ zurückgenommen: ' : '💉 gegeben: ') + String(gabe.name).slice(0, 120)
        + (gabe.dosis ? ' — ' + String(gabe.dosis).slice(0, 400) : '')
        + (!gabe.storno && gabe.warnLevel && gabe.warnText
            ? '  ⚠️ ' + String(gabe.breedName || gabe.breed || 'Rasse').slice(0, 80) + ': ' + String(gabe.warnText).slice(0, 400) : ''),
      hr: null, spo2: null, etco2: null, af: null, map: null, sys: null, dia: null, temp: null,
      rhythm: null, iso: null,
    });
    fensterProtokollDeckeln(L);
  }
  window.addEventListener('message', function (e) {
    var d = e && e.data;
    if (!d || typeof d !== 'object' || !d.vsMed) return;
    try { medEmpfangen(e.source, d.vsMed); } catch (err) {}
  });

  // ---------- Boot ----------
  window.VSAPP = { getDevices: function () { return state.devices; }, getPatients: function () { return state.patients; }, send: send };
  var ab = $('#vsxAdmin'); if (ab) ab.onclick = function () { if (window.VSADMIN) window.VSADMIN.open(); };
  var pb = $('#vsxPdf'); if (pb) pb.onclick = exportPDF;
  var db = $('#vsxDevices'); if (db) db.onclick = openPairing;
  // Umsortieren gibt es nur noch HIER, auf ausdruecklichen Wunsch (28.08.2026). Von selbst
  // passiert es nie mehr — Begruendung und Rechnung oben bei `plaetze`.
  var sb = $('#vsxSort'); if (sb) sb.onclick = ordneNachDringlichkeit;

  /*
   * WER IST DIESER SAAL? Einmal beim Start holen, danach alle 60 s nachziehen.
   *
   * Nachziehen ist noetig, weil der Saalname im laufenden Betrieb gesetzt werden kann (der Balken
   * beim ersten Start, der Admin-Bereich) — ein PDF, das eine Minute spaeter gedruckt wird, soll
   * den neuen Namen tragen und nicht den Stand des Seitenaufbaus. Faellt die Antwort aus, bleibt
   * der alte Wert stehen; der Ausdruck faellt dann auf 'VetStation' zurueck, aber nichts haengt.
   * Die Auskunft ist 127.0.0.1-only und verlangt die Kopfzeile X-VetStation (jsonPrivat).
   */
  function holeSaal() {
    try {
      fetch('api/station', { headers: { 'X-VetStation': '1' } })
        .then(function (r) { return r.json(); })
        .then(function (j) { if (j && j.bereit) state.saal = { name: j.name, kurz: j.kurz, sid: j.sid }; })
        .catch(function () {});
    } catch (_) {}
  }
  holeSaal();
  setInterval(holeSaal, 60000);

  /*
   * Das Band der Nachbarsaele anmelden. Es ist ein ZUSATZ: fehlt die Datei, laeuft der eigene
   * Saal unveraendert weiter — deshalb steht hier eine Pruefung und kein harter Zugriff.
   */
  if (window.VetNachbarn) {
    var nb = $('#vsxNachbarn');
    if (nb) window.VetNachbarn.montiere(nb, {
      /* "OP 2 oeffnen" fuehrt in die Fern-Ansicht, NICHT in den eigenen Arbeitsbereich. Ein
       * fremder Patient bekommt hier nie ein Fenster: er haengt an einem anderen PC, und ein
       * zweites Fenster daneben waere die Einladung, ihn von hier aus zu fahren. */
      beimOeffnen: function (sid, saal) {
        alert('Dieser Patient wird in ' + (saal && saal.name ? saal.name : 'einem anderen OP-Saal') +
          ' betreut, an einem anderen PC.\n\nHier ist nur die Ansicht. Vollstaendig sehen (mit Kurven ' +
          'und Protokoll) laesst er sich in der Fern-Ansicht — dort denselben Saal auswaehlen.');
      },
      log: function (m) { if (window.console && console.log) console.log('[nachbarn] ' + m); },
    });
  }

  connect();
})();
