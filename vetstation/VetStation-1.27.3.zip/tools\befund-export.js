'use strict';
/*
 * befund-export.js — schreibt EINE Textdatei mit allem, was man zur Ferndiagnose braucht.
 *
 * WOFUER: Wenn an einem anderen PC etwas nicht geht, ist die muehsamste Arbeit, den Zustand
 * ueberhaupt zu erfahren: Welche Version? Welche IP? Firewall offen? Was hat die Suche gefunden?
 * Kommen Werte an? Diese Datei beantwortet das in einem Rutsch — zum Weitergeben oder Einlesen
 * am anderen PC.
 *
 * KEIN WERKZEUGNAME MEHR IN DIESER DATEI (29.08.2026). Hier stand der Name des
 * Entwicklungswerkzeugs - zweimal, hier und in der Schlusszeile der Ausgabe. tools/ faehrt
 * vollstaendig im oeffentlichen Update-Zip mit, das jede fremde Station von GitHub Pages
 * laedt; der Befund gehoert dem, der ihn liest, und sagt nichts darueber, womit er
 * ausgewertet wird.
 *
 * DATENSCHUTZ (§10): Patienten-IDs werden UNKENNTLICH gemacht. Uebertragen werden nur
 * technische Angaben, Vitalwert-VORHANDENSEIN (nicht die Werte selbst) und Geraetedaten.
 *
 * Start:  BEFUND-EXPORTIEREN.bat doppelklicken
 *         node tools/befund-export.js [--schnell]
 *         --schnell = keine eigene Netzsuche, nur das Ergebnis der laufenden Station benutzen
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const ROOT = path.join(__dirname, '..');
const netscan = require('../bridge/src/netscan');
const firewall = require('../bridge/src/firewall');
const { diagnose } = require('../bridge/src/diagnose');
const { appVersion, pruefe: pruefeVersion } = require('../bridge/src/version');

const schnell = process.argv.indexOf('--schnell') >= 0;
const Z = [];
function z(t) { Z.push(t == null ? '' : String(t)); }
function trenner() { z('-'.repeat(74)); }

// Patienten-/Tier-Kennungen nie im Klartext exportieren.
function anonym(s) {
  if (!s) return '(keine)';
  const t = String(s);
  return t.length <= 2 ? '**' : t.slice(0, 1) + '*'.repeat(Math.min(6, t.length - 1));
}

function holen(pfad, port) {
  return new Promise((resolve) => {
    const req = http.get({ host: '127.0.0.1', port: port, path: pfad, timeout: 4000 }, (r) => {
      let b = '';
      r.on('data', (c) => { b += c; });
      r.on('end', () => { try { resolve(JSON.parse(b)); } catch (_) { resolve(null); } });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
  });
}

async function laufendeStation() {
  for (const p of [8770, 8771, 8791]) {
    const v = await holen('/api/version', p);
    if (v && v.version) return { port: p, version: v.version };
  }
  return null;
}

async function run() {
  const t0 = Date.now();
  z('==========================================================================');
  z('  VetStation - BEFUNDBERICHT DIESES PCs');
  z('  ' + new Date().toISOString().replace('T', ' ').slice(0, 19));
  z('==========================================================================');

  /* ---- 1) Was ist installiert? ---- */
  z(''); z('1) INSTALLATION'); trenner();
  const v = pruefeVersion();
  z('  Version (Wurzel-package.json): ' + appVersion());
  z('  Versionsnummern stimmig:       ' + (v.stimmig ? 'ja' : 'NEIN -> ' + v.abweichungen.map((a) => a.datei + '=' + a.wert).join(', ')));
  z('  Ordner:                        ' + ROOT);
  z('  Windows:                       ' + os.release() + ' (' + os.arch() + ')');
  z('  Node:                          ' + process.version);
  const dj = path.join(ROOT, 'bridge', 'config', 'devices.json');
  z('  Eigene devices.json vorhanden: ' + (fs.existsSync(dj) ? 'ja' : 'nein (es gilt die Vorlage devices.example.json)'));

  /* ---- 2) Laeuft die Station? ---- */
  z(''); z('2) LAEUFT DIE STATION?'); trenner();
  const st = await laufendeStation();
  if (st) {
    z('  ja - antwortet auf Port ' + st.port + ', meldet Version ' + st.version);
    if (st.version !== appVersion()) {
      z('  ACHTUNG: es LAEUFT ' + st.version + ', installiert ist aber ' + appVersion() + '.');
      z('           -> NEUSTART.bat doppelklicken.');
    }
  } else {
    z('  nein - auf 127.0.0.1:8770 antwortet nichts.');
    z('  (Fuer den vollstaendigen Befund bitte VetStation starten und erneut exportieren.)');
  }

  /* ---- 3) Netzwerk dieses PCs ---- */
  z(''); z('3) DIESER PC IM NETZ'); trenner();
  const karten = netscan.localAdapters();
  if (!karten.length) z('  KEINE Netzwerkkarte gefunden.');
  karten.forEach((k) => z('  ' + (k.virtuell ? '(virtuell) ' : '           ') + k.name + ': ' + k.address +
    '  Maske ' + k.netmask + '  MAC ' + k.mac));

  /* ---- 4) Firewall ---- */
  z(''); z('4) WINDOWS-FIREWALL (Datenports)'); trenner();
  const fw = await firewall.pruefe().catch(() => null);
  if (!fw) z('  nicht lesbar.');
  else fw.ports.forEach((p) => z('  TCP ' + String(p.port).padEnd(6) +
    (p.zustand === 'frei' ? 'freigegeben' + (p.anzahl > 1 ? '  (' + p.anzahl + ' Regeln - doppelt)' : '')
      : p.zustand === 'fehlt' ? 'FEHLT - Windows verwirft die Daten lautlos'
        : 'unklar (nicht lesbar)')));

  /* ---- 5) Netzsuche ---- */
  z(''); z('5) GERAETESUCHE'); trenner();
  let scan = null;
  const laufend = st ? await holen('/api/netscan', st.port) : null;
  if (laufend && laufend.ergebnis) {
    scan = laufend.ergebnis;
    z('  (Ergebnis der laufenden Station, zuletzt geprueft ' +
      (laufend.ts ? new Date(laufend.ts).toISOString().replace('T', ' ').slice(0, 19) : '?') + ')');
  } else if (!schnell) {
    z('  (eigene Suche laeuft ...)');
    scan = await netscan.scan({});
  } else {
    z('  uebersprungen (--schnell und keine laufende Station).');
  }
  if (scan) {
    z('  Netz: ' + ((scan.netz && scan.netz.base) || '?') + '1-254   Dauer: ' + Math.round((scan.dauerMs || 0) / 1000) + ' s');
    if (!scan.hosts.length) z('  KEIN Teilnehmer hat geantwortet.');
    scan.hosts.forEach((h) => {
      z('  [' + h.stufe + '] ' + h.ip + (h.mac ? '  ' + h.mac : ''));
      (h.gruende || []).forEach((g) => z('        ' + g));
    });
  }

  /* ---- 6) Kommen Werte an? ---- */
  z(''); z('6) KOMMEN WERTE AN?'); trenner();
  let empfang = { aktiv: false, geraete: 0, letzteDatenVorMs: null };
  if (st) {
    const s = await holen('/api/state', st.port);
    if (s) {
      const aktiv = (s.devices || []).filter((d) => d.status !== 'offline');
      const letzte = aktiv.reduce((m, d) => Math.max(m, d.lastTs || 0), 0);
      empfang = { aktiv: aktiv.length > 0, geraete: aktiv.length, letzteDatenVorMs: letzte ? Date.now() - letzte : null };
      z('  Geraete gesamt: ' + (s.devices || []).length + '   davon liefernd: ' + aktiv.length);
      (s.devices || []).forEach((d) => z('    - ' + (d.model || '?') + '  [' + d.deviceId + ', ' + d.role + ', ' + d.status + ']' +
        '  Patient ' + anonym(d.patientId) + '  ' + (d.species || '?') + ' ' + (d.weightKg || '?') + 'kg'));
      z('  Patienten: ' + (s.patients || []).length);
      (s.patients || []).forEach((p) => {
        const vi = p.vitals || {};
        const da = ['hr', 'spo2', 'etco2', 'af', 'temp'].filter((k) => vi[k] != null);
        z('    - ' + anonym(p.patientId) + '  ' + (p.species || '?') + ' ' + (p.weightKg || '?') + 'kg' +
          '  vorhandene Messwerte: ' + (da.length ? da.join(',') : 'KEINE'));
      });
    }
  } else {
    z('  Station laeuft nicht - nicht feststellbar.');
  }

  /* ---- 7) Urteil ---- */
  z(''); z('7) URTEIL DER DIAGNOSE'); trenner();
  const lage = diagnose({ scan: scan, firewall: fw, empfang: empfang });
  z('  [' + lage.urteil.toUpperCase() + '] ' + lage.kurz);
  z('');
  lage.befunde.filter((x) => x.code !== 'EMPFANG_OK').forEach((x, i) => {
    z('  ' + (i + 1) + '. [' + (x.schwere >= 3 ? 'BLOCKIERT' : x.schwere === 2 ? 'WAHRSCHEINLICH' : 'Hinweis') + '] ' + x.titel);
    z('     ' + x.warum.replace(/\s+/g, ' '));
    (x.tun || []).forEach((t) => z('     -> ' + t));
    z('');
  });

  /* ---- 8) Letzte Meldungen ---- */
  z('8) LETZTE MELDUNGEN DER STATION'); trenner();
  if (st) {
    const d = await holen('/api/diag', st.port);
    const ev = (d && d.events) || [];
    if (!ev.length) z('  (keine)');
    ev.slice(-40).forEach((e) => z('  ' + new Date(e.ts).toISOString().slice(11, 19) + ' [' + e.level + '] ' + e.source + ': ' + e.msg));
  } else {
    z('  Station laeuft nicht.');
  }

  /* ---- 9) Abstuerze und Updates ----
   * NEU 25.08.2026. Diese zwei Dateien fehlten hier — und in ihnen steht genau das, wonach
   * man bei einer Fernhilfe zuerst fragt: ob sich die Station selbst neu gestartet hat
   * (watchdog.log) und ob ein Update dauerhaft scheitert (update.log). Beide schreibt
   * PowerShell (kiosk\watchdog.ps1, kiosk\launch-kiosk.ps1), deshalb kennt sie das
   * Diagnoseprotokoll der Station nicht. */
  z(''); z('9) SELBSTNEUSTARTS UND UPDATES'); trenner();
  [['watchdog.log', 'Selbstneustarts'], ['update.log', 'Update-Versuche']].forEach(([name, was]) => {
    const p = path.join(ROOT, 'data', name);
    let zeilen = null;
    try { zeilen = fs.readFileSync(p, 'utf8').split(/\r?\n/).filter(Boolean); } catch (_) { zeilen = null; }
    if (!zeilen) { z('  ' + was + ' (' + name + '): keine Datei — noch nie vorgekommen.'); return; }
    z('  ' + was + ' (' + name + '): ' + zeilen.length + ' Zeilen, die letzten 12:');
    zeilen.slice(-12).forEach((l) => z('    ' + l.slice(0, 160)));
  });

  z(''); trenner();
  z('  Erstellt in ' + Math.round((Date.now() - t0) / 1000) + ' s.');
  /* DIE ZUSAGE WAR FALSCH (berichtigt 25.08.2026).
   * Hier stand "Patienten-Kennungen sind unkenntlich gemacht" — und Abschnitt 8 hing die
   * Meldungen ROH an, in denen die Aktennummer samt Wirkstoff und Dosis stand (echtes
   * Beispiel aus data\diag.log.1: "Gegeben: Atropin (0.084-0.168 mg ...) - Patient C-077").
   * Die Kennung wird jetzt an der QUELLE aus dem Text herausgehalten (bridge/src/logger.js)
   * und erscheint hier nur noch als stabiles Kuerzel. Die Zusage nennt seither auch, was
   * SEHR WOHL drinsteht — eine Zusage, die verschweigt, ist wieder dieselbe Falle. */
  z('  Patienten-Kennungen erscheinen nur als abgeleitetes Kuerzel (#abc123): derselbe Patient');
  z('  bleibt erkennbar, die Aktennummer steht nicht darin. Keine Vitalwerte, kein Besitzer,');
  z('  kein Telefon, kein Tiername.');
  z('  ENTHALTEN sind dagegen: Tierart und Gewicht, Geraetemodelle mit IP- und MAC-Adressen');
  z('  des Praxisnetzes, sowie Wirkstoff und Dosis der protokollierten Gaben.');

  const dir = path.join(ROOT, 'data');
  try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {}
  const datei = path.join(dir, 'befund-' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.txt');
  const text = Z.join('\r\n');
  fs.writeFileSync(datei, text, 'utf8');

  console.log(text);
  console.log('');
  console.log('  ==> Gespeichert als: ' + datei);
  console.log('      Diese Datei weitergeben bzw. am anderen PC einlesen lassen.');
}

run().catch((e) => { console.error('Fehler beim Export:', e && e.message); process.exit(1); });
