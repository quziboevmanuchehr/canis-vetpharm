/*
 * vetstation-nachbarn.js — das BAND der fremden OP-Saele im Kiosk (Stufe 1, ab 1.1.0).
 *
 * WOZU DIESE DATEI DA IST: Ein Tierarzt in OP 1 soll sehen, wie es in OP 2 steht, ohne den eigenen
 * Arbeitsbereich dafuer herzugeben. Deshalb ist der Nachbarsaal hier ein ZUSATZSTREIFEN am unteren
 * Rand und niemals ein Patientenfenster: kein iframe, kein Eingabefeld, kein "setzen"-Knopf, keine
 * Kurve. Was hier steht, ist reine Ansicht — die Geraete haengen an einem ANDEREN PC.
 *
 * WAS DIESE DATEI NICHT ANFASST: state.patients und state.devices in ui/vetstation-live.js. Daran
 * haengt der komplette eigene Betrieb (refresh oeffnet und schliesst Fenster, drive faehrt die
 * Narkose-App, renderPairing bietet Geraete zum Koppeln an, doExportPDF druckt das Protokoll).
 * Sickerte ein fremder Patient dort ein, muesste JEDE dieser Stellen einzeln pruefen, ob der
 * Patient ueberhaupt zu diesem PC gehoert — und eine davon wuerde es vergessen. Die Nachricht
 * 'fremd' endet deshalb in diesem Modul, und dieses Modul hat keinen Weg zurueck.
 *
 * WARUM DIE HOEHE NUR NACH EINEM KLICK WECHSELT (Befund C2-9): #vsxGrid ist position:fixed mit
 * bottom:0 und grid-auto-rows:1fr. Jede Hoehenaenderung im unteren Bereich bricht ALLE
 * Patienten-iframes neu um — und ein neu umgebrochenes iframe laedt die Anaesthesie-App neu und
 * unterbricht die Anzeige waehrend einer laufenden Narkose. Deshalb zwei feste Hoehen (HOEHE_ZU,
 * HOEHE_AUF), umgeschaltet ausschliesslich durch einen Klick, gemerkt in localStorage.
 * ZUSAETZLICH, UND STAERKER ALS DER PLAN VERLANGT: das Band liegt als OVERLAY (position:fixed,
 * bottom:0, eigener z-index) und ruehrt #vsxGrid gar nicht an. Die naheliegende Alternative waere,
 * aus dieser Datei heraus '#vsxGrid { bottom: <bandhoehe> }' zu setzen; dagegen sprechen zwei
 * Gruende: dann brechen beim Auf- und Zuklappen doch alle iframes um, und die Datei griffe in das
 * Gestaltungsblatt eines fremden Bausteins (ui/vetstation-shell.css). Der Preis, ehrlich benannt:
 * das aufgeklappte Band verdeckt die unteren 176 px der Patientenfenster. Es ist standardmaessig
 * eingeklappt und geht mit einem Klick wieder zu.
 *
 * WARUM NEU GEZEICHNET NUR BEI GEAENDERTER SIGNATUR WIRD (Muster host.__sig aus renderBar,
 * ui/vetstation-live.js Z.277-279): die Nachricht kommt im Sekundentakt. Wer bei jeder Nachricht
 * den Streifen neu aufbaut, laesst ihn flackern, wirft die Bildlaufstelle weg und erzeugt in einem
 * stillen Saal Arbeit fuer nichts. Die Signatur traegt deshalb NUR, was wirklich anders aussieht —
 * und ausdruecklich NICHTS ZEITABHAENGIGES (siehe signatur()).
 *
 * WOHER DAS SEKUENDLICHE ALTER KOMMT: aus einem EIGENEN Zeitgeber in dieser Datei, nicht aus der
 * Nachricht. Er rechnet je Saal 'uebertragungMs + (jetzt - Eingang der Nachricht)' und schreibt das
 * Ergebnis ueber CSS-Klassen und das textContent EINZELNER Knoten — nie ueber innerHTML des
 * Streifens. Das Wort innerHTML kommt in dieser Datei nicht vor; tools/nachbarn-test.js prueft das
 * am Quelltext. Damit altert das Band auch dann weiter, wenn die Nachricht ganz ausbleibt: nach
 * 12 s wird der Saal gelb, nach 60 s heisst er offline und seine Zahlen werden ERSETZT.
 *
 * WARUM DIE UHR EIN ARGUMENT IST: opts.jetzt. Ohne das waere jede Alterungsstufe nur durch echtes
 * Warten pruefbar (60 s je Pruefung), und tools/nachbarn-test.js koennte nicht ohne Uhr laufen.
 * Vorgabe bleibt Date.now — der Einbetter muss nichts uebergeben.
 *
 * DIE ZEIT WIRD AUSSCHLIESSLICH LOKAL GERECHNET. In dieser Datei wird nie ein fremder Zeitstempel
 * gegen die eigene Uhr gehalten; das hat bridge/src/fremdstore.js bereits getan und liefert das
 * Ergebnis als DAUER (uebertragungMs, altMs). Hier kommt nur die Zeit seit dem Eingang der
 * Nachricht dazu — eine Differenz zweier Ablesungen DERSELBEN Uhr. Eine fremde Uhr, die vorgeht,
 * kann das Band deshalb nicht juenger machen, als es ist.
 *
 * KEIN NETZ. Diese Datei ruft weder fetch noch XMLHttpRequest, insbesondere kein
 * 'api/kurven?key=...' fuer einen fremden Schluessel: das liefe still auf {kurven:[]} hinaus, wuerde
 * die Signatur trotzdem merken und dem eigenen Saal Rechenzeit wegnehmen. Alles, was das Band
 * zeigt, steht in der Nachricht.
 *
 * WORTLAUT: die Saetze zu Alterung und Deckel stehen wortgleich in bridge/src/fremdstore.js
 * (ersatzText, hinweisText, kappeSaele). Sie werden hier NACHGEBILDET und nicht erfunden, weil das
 * Band sekuendlich weiterrechnen muss, waehrend die Nachricht steht. Deshalb auch der Verzicht auf
 * Umlaute in den angezeigten Texten: die fertigen Zeilen aus hinweise[] kommen umlautfrei vom
 * Rechner nebenan, und zwei Schreibweisen desselben Satzes nebeneinander lesen sich wie zwei
 * verschiedene Meldungen.
 *
 * Schnittstelle:
 *   window.VetNachbarn.montiere(behaelter, opts)   opts: { beimOeffnen(sid, saal), log, jetzt }
 *   window.VetNachbarn.setze(nachricht)            die WS-Nachricht { type:'fremd', ts, saele, mehr, hinweise }
 *   window.VetNachbarn.aus()                       Band leeren und Zeitgeber stoppen
 *   window.VetNachbarn.pur                         die reinen Funktionen, fuer tools/nachbarn-test.js
 */
(function (root) {
  'use strict';

  // ---------------------------------------------------------------- Zahlen an EINER Stelle

  var STIL_ID = 'vsn-stil';
  var SPEICHER = 'vetstation.nachbarn.v1';

  /*
   * Dieselben Alterungsschwellen wie in bridge/src/tafel.js (STUFE_LIVE_MS, STUFE_OFFLINE_MS,
   * STUFE_WEG_MS). Sie stehen hier ein zweites Mal, weil eine Kiosk-Datei nichts aus bridge/
   * laden kann; dass beide Zahlenreihen gleich bleiben, prueft tools/nachbarn-test.js gegen den
   * Quelltext von tafel.js. Ein Saal darf nicht auf einem Bildschirm "live" und auf dem anderen
   * "offline" heissen.
   */
  var STUFE_LIVE_MS = 12000;
  var STUFE_OFFLINE_MS = 60000;
  var STUFE_WEG_MS = 12 * 3600 * 1000;

  var TAKT_MS = 1000;

  /*
   * Die Deckel aus Nachbesserung N17. bridge/src/fremdstore.js kappt bereits — hier wird trotzdem
   * gekappt, und zwar mit DEMSELBEN Satz. Grund: das Band ist die letzte Stelle vor dem Bildschirm.
   * Kaeme eine Nachricht mit 40 Saelen an (aeltere Bridge, veraenderte Grenzwerte, ein zweiter
   * Schreiber im Praxiskonto), wuerde ein ungedeckeltes Band 40 Karten bauen und den Kiosk-PC
   * lahmlegen. Lautlos verschwinden darf trotzdem keiner: was der Deckel abschneidet, steht als
   * Zeile in der Kopfzeile.
   */
  var DECKEL_SAELE = 8;
  var DECKEL_KACHELN = 12;
  var DECKEL_GERAETE = 16;

  // Die zwei erlaubten Hoehen des Bandes, in Pixeln. Mehr gibt es nicht — siehe Kopfkommentar.
  var HOEHE_ZU = 26;
  var HOEHE_AUF = 176;

  // Laengengrenzen wie in bridge/src/tafel.js (GRENZEN.tafelText, GRENZEN.sid, GRENZEN.adresse).
  var MAX_TEXT = 40;
  var MAX_SID = 24;
  var MAX_IP = 45;

  var NAME_UNBENANNT = 'OP-Saal (ohne Namen)';
  var TEXT_UNBEKANNT = 'Alter unbekannt';

  // ---------------------------------------------------------------- Zustand des Bandes

  var behaelter = null;         // der vom Einbetter uebergebene Knoten (#vsxNachbarn)
  var einst = {};               // opts des Einbetters
  var uhr = null;               // opts.jetzt oder Date.now
  var nachricht = null;         // die letzte gueltige Nachricht, bereits genommen (siehe nimm())
  var eingang = null;           // lokale Uhrzeit ihres Eingangs — Bezugspunkt der Alterung
  var sig = null;               // Signatur des zuletzt gezeichneten Standes
  var zeitgeber = null;
  var offen = false;            // Band aufgeklappt?
  var geraeteOffen = {};        // sid -> true: Geraetezeile dieses Saals ausgeklappt
  var zeiger = [];              // was der Zeitgeber anfasst, ohne den Baum zu durchsuchen
  var jemalsSaal = false;       // stand hier schon einmal ein Nachbar? (siehe zeichne)

  var wurzel = null, kopfKnopf = null, kopfWarn = null, koerper = null;

  // ---------------------------------------------------------------- reine Bausteine

  /*
   * text(s, max) — ein Textfeld aus fremder Hand, gekuerzt und von Steuerzeichen befreit.
   *
   * Gegen HTML muss hier nichts getan werden: dieses Modul schreibt ausschliesslich textContent,
   * ein '<' bleibt also ein '<'. Steuerzeichen fallen trotzdem weg — sie kommen ueber den Bildschirm
   * nicht an, koennen aber eine Zeile zerreissen, und der Wert stammt von einem Geraet, das jede
   * Gegenstelle annimmt (die Datenports binden ohne Host-Argument).
   */
  function text(s, max) {
    if (s == null) return '';
    var t = String(s).replace(/[\u0000-\u001f\u007f]/g, ' ');
    var m = max || MAX_TEXT;
    return t.length > m ? t.slice(0, m) : t;
  }

  /*
   * zahl(x) — eine Zahl oder null, nie NaN, nie Unendlich, und NIE 0 fuer einen fehlenden Wert.
   *
   * 31.07.2026, Gegenpruefung: die leere Zeichenkette kam hier als 0 heraus (Number('') ist 0, und
   * '' ist typeof 'string'). Gemessen stand danach 'HF 0' auf einer Kachel, deren Wert in Wahrheit
   * fehlt — genau die 0, die werteText() ausdruecklich nie schreiben soll. Bei uebertragungMs war
   * es schlimmer: altersStufe('') ergab 'live', ein Saal ohne jede Altersangabe waere also gruen
   * gewesen. Die naheliegende Alternative, Zeichenketten ganz abzulehnen, geht nicht: eine aeltere
   * Bridge-Fassung darf '88' schicken, und dann ist 88 gemeint.
   */
  function zahl(x) {
    if (typeof x === 'string' && x.replace(/\s/g, '') === '') return null;
    var n = Number(x);
    return (typeof x === 'number' || typeof x === 'string') && isFinite(n) ? n : null;
  }

  // Deutsches Dezimalkomma. Ein Punkt liest sich am Kiosk wie ein Tausendertrenner.
  function komma(n) { return String(n).replace('.', ','); }

  /*
   * sidKurz(sid) — die Kurzform, die auf JEDER Karte steht (Plan: "Saalname UND sid-Kurzform").
   *
   * Dieselbe Ableitung wie bridge/src/stationsid.js sidKurz(): die ersten sechs Hexzeichen nach
   * dem 'st'. Die dortige SUFFIXFORM (st<12hex>-<4hex>) bekommt ihre Kurzform aus einem sha256 —
   * das ist hier ohne Bibliothek nicht nachbaubar, und eine SELBST ERFUNDENE Kurzform waere
   * schlimmer als gar keine: im Admin-Bereich stuende dann eine andere Kennung als auf der Karte,
   * und genau daran soll der Tierarzt zwei gleichnamige Saele auseinanderhalten. Deshalb steht in
   * diesem Fall die vollstaendige Kennung da — laenger, aber wahr.
   */
  function sidKurz(sid) {
    var s = text(sid, MAX_SID);
    if (/^st[0-9a-f]{12}$/.test(s)) return s.slice(2, 8);
    return s;
  }

  /*
   * altersStufe(ms) — der Zustand, den die Anzeige aus einem Alter macht. Wortgleich mit
   * bridge/src/tafel.js altersStufe().
   *   'live'      < 12 s   die Zahlen gelten
   *   'alt'      12-60 s   "keine neuen Daten (Xs)", die Zahlen bleiben stehen
   *   'offline'  > 60 s    "<Saal> offline seit X min", die Zahlen werden ERSETZT
   *   'weg'      > 12 h    aus der Liste geworfen hat den Saal bereits fremdstore.js — HIER aber
   *                        nicht, denn der oertliche Zeitgeber rechnet weiter, waehrend die
   *                        Nachricht steht. 31.07.2026, Gegenpruefung: 'weg' wird deshalb im
   *                        Stilblatt genau wie 'offline' behandelt. Die Karte wird NICHT vom
   *                        Zeitgeber entfernt — er baut und loescht grundsaetzlich keine Knoten.
   *   'unbekannt'          kein berechenbares Alter
   * Ein NEGATIVES Alter ergibt 'unbekannt' und niemals 0 (Nachbesserung N16): ein Saal, dessen
   * Zeitstempel vor unserer Uhr liegt, waere sonst dauerhaft brandaktuell — gruen, mit seinen
   * letzten Vitalwerten. Genau das darf ein toter OP-Saal nicht koennen.
   */
  function altersStufe(ms) {
    var n = zahl(ms);
    if (n == null || n < 0) return 'unbekannt';
    if (n < STUFE_LIVE_MS) return 'live';
    if (n < STUFE_OFFLINE_MS) return 'alt';
    if (n < STUFE_WEG_MS) return 'offline';
    return 'weg';
  }

  /*
   * ersatzText(ms) — was ANSTELLE der Zahlen steht, sobald ein Saal offline ist. Wortgleich mit
   * bridge/src/fremdstore.js ersatzText().
   *
   * Aufgerundet auf ganze Minuten, mindestens 1: "Stand vor 0 min" behauptet eine Genauigkeit, die
   * eine Schaetzung ueber zwei Uhren nicht hat.
   */
  function ersatzText(ms) {
    var n = zahl(ms);
    if (n == null || n < 0) return TEXT_UNBEKANNT;
    return 'Stand vor ' + Math.max(1, Math.round(n / 60000)) + ' min';
  }

  /*
   * alterText(stufe, ms, name) — der Satz im Saalkopf. Wortlaut aus dem Plan-Abschnitt
   * oberflaechen bzw. aus fremdstore.hinweisText(), damit Band, Web-App und Log fuer denselben
   * Zustand denselben Satz zeigen. 'live' bekommt bewusst nur ein Wort: ein ganzer Satz im
   * Normalfall trainiert das Wegsehen.
   */
  function alterText(stufe, ms, name) {
    var n = zahl(ms);
    if (stufe === 'unbekannt' || n == null) return TEXT_UNBEKANNT;
    if (stufe === 'live') return 'live';
    if (stufe === 'alt') return 'keine neuen Daten (' + Math.round(n / 1000) + 's)';
    return (name ? name + ' ' : '') + 'offline seit ' + Math.max(1, Math.round(n / 60000)) + ' min';
  }

  // Kurze Dauer fuer die Marke an einer Kachel oder Geraetezeile. '?' statt einer erfundenen Zahl.
  function dauerKurz(ms) {
    var n = zahl(ms);
    if (n == null || n < 0) return '?';
    if (n < 60000) return Math.round(n / 1000) + ' s';
    return Math.max(1, Math.round(n / 60000)) + ' min';
  }

  /*
   * priKlasse(pri) — die Prioritaetsfarbe als Klassenname (nicht als style-Attribut, damit alles
   * Aussehen in dem EINEN Stilblatt steht). Dieselben Schwellen wie priColor()/prTxt() in
   * ui/vetstation-live.js: 5 CPR, 4 dringend, 3 achtung, sonst stabil.
   * OHNE pri gibt es GRAU, nicht Gruen — ein Patient ohne jeden Messwert ist nicht "stabil",
   * sondern unbekannt (derselbe dritte Zustand wie zustandFarbe() in vetstation-live.js).
   */
  function priKlasse(pri) {
    var n = zahl(pri);
    if (n == null) return 'p-';
    if (n >= 5) return 'p5';
    if (n >= 4) return 'p4';
    if (n >= 3) return 'p3';
    return 'p0';
  }

  /*
   * hatAlarm(saal) — soll diese Karte pulsieren?
   *
   * Ja, wenn eine Kachel eine Alarmzahl traegt oder ihre Prioritaet DRINGEND/CPR erreicht. Der
   * Alarm eines OFFLINE-Saals zaehlt NICHT: dessen Zahlen sind gerade durch "Stand vor X min"
   * ersetzt worden, und eine pulsierende Karte ohne Werte schickt jemanden in einen Saal, ueber
   * den wir seit zwei Minuten nichts wissen. Das entscheidet nicht diese Funktion, sondern der
   * Zeitgeber — die Stufe aendert sich sekuendlich, die Kacheln nicht.
   */
  function hatAlarm(saal) {
    var s = saal || {};
    var p = s.patients || [];
    for (var i = 0; i < p.length; i++) {
      if (zahl(p[i].al) > 0) return true;
      if (zahl(p[i].pri) >= 4) return true;
    }
    return false;
  }

  /*
   * werteText(p) — die Messwertzeile EINER Kachel.
   *
   * Nur vorhandene Werte. Ein fehlender Wert wird NIE durch 0 oder '-' ersetzt: die Kachel steht
   * neben einer laufenden Narkose, und eine 0 an der Stelle von EtCO2 ist eine Aussage, kein
   * Platzhalter. Liegt gar nichts vor, sagt die Zeile genau das.
   */
  function werteText(p) {
    var w = p || {};
    var teile = [];
    var hr = zahl(w.hr), sp = zahl(w.sp), et = zahl(w.et), af = zahl(w.af);
    var sys = zahl(w.sys), dia = zahl(w.dia), map = zahl(w.map), t = zahl(w.t);
    if (hr != null) teile.push('HF ' + komma(hr));
    if (sp != null) teile.push('SpO2 ' + komma(sp) + ' %');
    if (et != null) teile.push('EtCO2 ' + komma(et));
    if (af != null) teile.push('AF ' + komma(af));
    if (sys != null && dia != null) teile.push('RR ' + komma(sys) + '/' + komma(dia) + (map != null ? ' (' + komma(map) + ')' : ''));
    else if (map != null) teile.push('MAP ' + komma(map));
    if (t != null) teile.push('T ' + komma(t) + ' °C');
    if (w.rh) teile.push(text(w.rh, 24));
    return teile.length ? teile.join(' · ') : 'keine Messwerte';
  }

  /*
   * geraeteText(z) — EINE Geraetezeile (Nachbesserung N13): Modell, Rolle, Status, ip.
   *
   * Die Feldnamen sind wortgleich die aus registry.getDevices() bzw. tafel.geraeteSatz() — fern
   * soll dasselbe stehen wie im Koppel-Dialog vor Ort. Fehlt das Modell, steht die Geraetekennung
   * da; ein Geraet ohne jede Bezeichnung waere eine Zeile, die nichts sagt.
   */
  function geraeteText(z) {
    var g = z || {};
    var teile = [];
    teile.push(text(g.model, MAX_TEXT) || text(g.id, MAX_TEXT) || 'Geraet');
    if (g.role) teile.push(text(g.role, 24));
    if (g.ip) teile.push(text(g.ip, MAX_IP) + (zahl(g.port) != null ? ':' + zahl(g.port) : ''));
    else if (g.transport) teile.push(text(g.transport, 24));
    return teile.join(' · ');
  }

  function statusText(s) {
    var t = String(s == null ? '' : s);
    if (t === 'active') return 'sendet';
    if (t === 'standby') return 'still';
    if (t === 'offline') return 'offline';
    return t || 'unbekannt';
  }

  /*
   * nimm(m) — aus einer WebSocket-Nachricht wird ein Stand, den das Band zeigen darf.
   *
   * ALLES WIRD GEPRUEFT UND GEKAPPT, obwohl bridge/src/fremdstore.js das bereits getan hat. Der
   * Grund ist nicht Misstrauen gegen die Bridge, sondern die Reihenfolge der Auslieferung: Kiosk
   * und Bridge werden gemeinsam aktualisiert, aber nicht gleichzeitig gestartet, und ein
   * Feldbestand aus einer anderen Fassung darf hoechstens fehlen — nie den Streifen zerlegen.
   * Was der Deckel hier abschneidet, wird gezaehlt und erscheint als Zeile (N17).
   */
  function nimm(m) {
    var raus = { ts: null, saele: [], mehr: 0, hinweise: [] };
    if (!m || typeof m !== 'object') return raus;
    raus.ts = zahl(m.ts);
    var ein = Array.isArray(m.saele) ? m.saele : [];
    var mehr = zahl(m.mehr);
    raus.mehr = (mehr != null && mehr > 0) ? Math.floor(mehr) : 0;
    if (Array.isArray(m.hinweise)) {
      for (var h = 0; h < m.hinweise.length && h < 24; h++) {
        var zeile = text(m.hinweise[h], 200);
        if (zeile) raus.hinweise.push(zeile);
      }
    }
    var eigenGekappt = 0;
    for (var i = 0; i < ein.length; i++) {
      var s = ein[i];
      if (!s || typeof s !== 'object') continue;
      var sid = text(s.sid, MAX_SID);
      if (!sid) continue;                                  // ohne Kennung gibt es keine Karte
      if (raus.saele.length >= DECKEL_SAELE) { eigenGekappt++; continue; }
      raus.saele.push(nimmSaal(s, sid));
    }
    if (eigenGekappt > 0) {
      raus.mehr += eigenGekappt;
      raus.hinweise.push(eigenGekappt + ' weitere OP-Saele werden nicht angezeigt — Deckel erreicht');
    }
    return raus;
  }

  function nimmSaal(s, sid) {
    var quelle = String(s.quelle == null ? '' : s.quelle);
    if (quelle !== 'lan' && quelle !== 'cloud') quelle = 'aus';
    var saal = {
      sid: sid,
      kurz: sidKurz(sid),
      name: text(s.name, MAX_TEXT),
      quelle: quelle,
      uebertragungMs: zahl(s.uebertragungMs),
      widerspruch: !!s.widerspruch,
      blind: !!s.blind,
      patients: [],
      geraete: [],
      mehr: 0,
      mehrGeraete: 0,
    };
    var p = Array.isArray(s.patients) ? s.patients : [];
    var k;
    for (k = 0; k < p.length; k++) {
      if (!p[k] || typeof p[k] !== 'object') continue;
      if (saal.patients.length >= DECKEL_KACHELN) { saal.mehr++; continue; }
      saal.patients.push(nimmKachel(p[k]));
    }
    var g = Array.isArray(s.geraete) ? s.geraete : [];
    for (k = 0; k < g.length; k++) {
      if (!g[k] || typeof g[k] !== 'object') continue;
      if (saal.geraete.length >= DECKEL_GERAETE) { saal.mehrGeraete++; continue; }
      saal.geraete.push(nimmGeraet(g[k]));
    }
    // Die Deckel der Vorstufe uebernehmen — sonst verschwaende genau die Zahl, die N17 sichtbar
    // haben will, auf dem Weg zum Bildschirm.
    var vorK = zahl(s.mehr), vorG = zahl(s.mehrGeraete);
    if (vorK != null && vorK > 0) saal.mehr += Math.floor(vorK);
    if (vorG != null && vorG > 0) saal.mehrGeraete += Math.floor(vorG);
    saal.count = saal.patients.length;
    saal.alarm = hatAlarm(saal);
    return saal;
  }

  function nimmKachel(p) {
    var k = {
      key: text(p.key, 200),
      pid: text(p.pid, MAX_TEXT),
      n: text(p.n, MAX_TEXT),
      a: text(p.a, 24),
      g: zahl(p.g),
      hr: zahl(p.hr), sp: zahl(p.sp), et: zahl(p.et), af: zahl(p.af),
      sys: zahl(p.sys), dia: zahl(p.dia), map: zahl(p.map), t: zahl(p.t),
      rh: text(p.rh, 24),
      pri: zahl(p.pri),
      top: text(p.top, MAX_TEXT),
      al: zahl(p.al),
      altMs: zahl(p.altMs),
      auch: [],
    };
    if (Array.isArray(p.auch)) {
      for (var i = 0; i < p.auch.length && i < 4; i++) {
        var w = text(p.auch[i], MAX_TEXT);
        if (w) k.auch.push(w);
      }
    }
    return k;
  }

  function nimmGeraet(z) {
    return {
      id: text(z.id, MAX_TEXT),
      model: text(z.model, MAX_TEXT),
      role: text(z.role, 24),
      status: text(z.status, 16),
      ip: text(z.ip, MAX_IP),
      port: zahl(z.port),
      transport: text(z.transport, 24),
      altMs: zahl(z.altMs),
    };
  }

  /*
   * doppelteNamen(saele) — die Warnzeile bei gleichem Saalnamen.
   *
   * Sie steht NICHT in hinweise[]: bridge/src/fremdstore.js sieht die Namen zwar, aber die Zusage
   * "Saele bleiben unterscheidbar" wird an der Oberflaeche eingeloest, und nur hier ist bekannt,
   * welche Karten nebeneinander stehen. Die betroffenen Karten bekommen zusaetzlich eine Marke —
   * eine Warnung in der Kopfzeile ohne Hinweis darauf, WELCHE zwei Karten gemeint sind, laesst den
   * Tierarzt suchen.
   *
   * Die Zaehlung laeuft ueber '#'+name, damit ein Saal namens 'constructor' nicht in einem geerbten
   * Feld des Objekts landet.
   */
  function doppelteNamen(saele) {
    var liste = Array.isArray(saele) ? saele : [];
    var nachName = {}, folge = [], i;
    for (i = 0; i < liste.length; i++) {
      var n = String(liste[i] && liste[i].name != null ? liste[i].name : '').trim();
      if (!n) continue;
      var s = '#' + n;
      if (!nachName[s]) { nachName[s] = []; folge.push(s); }
      nachName[s].push(liste[i].kurz || sidKurz(liste[i].sid));
    }
    var zeilen = [], betroffen = {};
    for (i = 0; i < folge.length; i++) {
      var eintrag = nachName[folge[i]];
      if (eintrag.length < 2) continue;
      betroffen[folge[i]] = true;
      zeilen.push(eintrag.length + ' OP-Saele heissen gleich: "' + folge[i].slice(1) + '" ('
        + eintrag.join(', ') + ') — auseinanderhalten laesst sie nur die Kennung.');
    }
    return { zeilen: zeilen, betroffen: betroffen };
  }

  /*
   * warnzeile(stand, doppelt) — eine Zeile fuer die Kopfzeile, der Rest in den Tooltip.
   *
   * Die Kopfzeile ist im eingeklappten Zustand ALLES, was vom Band zu sehen ist. Deshalb steht dort
   * die erste Warnung im Klartext und nicht "3 Hinweise" — eine Zahl, die man erst aufklappen muss,
   * um sie zu lesen, ist im OP keine Meldung. Die eigenen Zeilen (gleicher Saalname) stehen vorn:
   * sie betreffen die Verwechslungsgefahr, um die es beim ganzen Umbau geht.
   */
  function warnzeile(stand, doppelt) {
    var alle = (doppelt && doppelt.zeilen ? doppelt.zeilen : []).concat(stand && stand.hinweise ? stand.hinweise : []);
    if (!alle.length) return { kurz: '', voll: '' };
    return {
      kurz: '⚠ ' + alle[0] + (alle.length > 1 ? '   (+' + (alle.length - 1) + ' weitere)' : ''),
      voll: alle.join('\n'),
    };
  }

  /*
   * signatur(stand) — woran erkannt wird, dass sich das BILD geaendert hat.
   *
   * WAS DRIN STEHT: alles, was die Karten baut — Reihenfolge, Kennung, Name, Quelle, Zaehler,
   * Deckel, Widerspruch, jeder Messwert jeder Kachel, jede Geraetezeile.
   *
   * WAS AUSDRUECKLICH FEHLT UND WARUM: jedes zeitabhaengige Feld — ts, uebertragungMs, altMs,
   * stufe, hinweis, ersatz, lesestandMs. Diese Felder aendern sich bei JEDER Nachricht, also
   * jede Sekunde, auch in einem voellig stillen Saal. Stuenden sie in der Signatur, waere sie
   * sekuendlich anders, der Streifen wuerde sekuendlich neu gebaut, und der Zeitgeber, der genau
   * das verhindern soll, waere sinnlos. Die Zeit steht deshalb NICHT in der Signatur, sondern in
   * den Zeigern, die der Zeitgeber anfasst.
   *
   * Ebenfalls draussen: hinweise[]. Die Zeile "offline seit 3 min" darin aendert sich im
   * Minutentakt, und die Kopfzeile ist ein EINZELNER Textknoten, den der Zeitgeber ohnehin
   * schreibt — dafuer muss nichts neu gezeichnet werden.
   *
   * Der Trenner ist U+0001, weil er in keinem gekappten Text vorkommen kann (text() ersetzt alle
   * Steuerzeichen). Ohne einen solchen Trenner koennten zwei verschiedene Staende dieselbe
   * Zeichenkette ergeben.
   */
  function signatur(stand) {
    if (!stand || !stand.saele) return '';
    var t = [];
    t.push('S' + stand.saele.length, 'M' + stand.mehr);
    for (var i = 0; i < stand.saele.length; i++) {
      var s = stand.saele[i];
      t.push('|', s.sid, s.name, s.quelle, String(s.count), String(s.mehr),
        String(s.mehrGeraete), s.widerspruch ? '1' : '0', s.blind ? '1' : '0', s.alarm ? '1' : '0');
      var k;
      for (k = 0; k < s.patients.length; k++) {
        var p = s.patients[k];
        t.push('k', p.key, p.pid, p.n, p.a, String(p.g), String(p.hr), String(p.sp), String(p.et),
          String(p.af), String(p.sys), String(p.dia), String(p.map), String(p.t), p.rh,
          String(p.pri), p.top, String(p.al), p.auch.join(','));
      }
      for (k = 0; k < s.geraete.length; k++) {
        var g = s.geraete[k];
        t.push('g', g.id, g.model, g.role, g.status, g.ip, String(g.port), g.transport);
      }
    }
    return t.join('\u0001');
  }

  // ---------------------------------------------------------------- Stilblatt

  /*
   * Das ganze Aussehen des Bandes entsteht hier zur Laufzeit, in EINEM <style>-Element. Grund: die
   * Datei soll allein lauffaehig sein — wer sie einhaengt, muss nicht daran denken, ausserdem
   * ui/vetstation-shell.css zu aendern. Ein fehlendes Gestaltungsblatt waere hier kein
   * Schoenheitsfehler, sondern ein Band ohne feste Hoehe, und damit genau der Umbruch aller
   * iframes, den der Kopfkommentar ausschliesst.
   *
   * Die Farben sind dieselben wie in ui/vetstation-shell.css (Hintergrund #0e141c, Rand #1a2330,
   * Schrift #e8eef6, gedaempft #8ba0b6, Prioritaeten aus priColor()) — der Streifen soll wie ein
   * Teil derselben Oberflaeche aussehen und nicht wie ein Fremdkoerper.
   */
  function stil() {
    return [
      /* Der Halter ist das Overlay. pointer-events:none, damit der unsichtbare Bereich neben dem
         Band keine Klicks auf die Patientenfenster abfaengt; das Band selbst nimmt sie wieder an. */
      '.vsn-halter{position:fixed;left:0;right:0;bottom:0;z-index:9996;pointer-events:none;}',
      '.vsn{pointer-events:auto;box-sizing:border-box;height:' + HOEHE_ZU + 'px;overflow:hidden;'
        + 'background:#0b1017;border-top:1px solid #1a2330;color:#e8eef6;'
        + 'font:12px "Segoe UI",Inter,sans-serif;}',
      '.vsn.auf{height:' + HOEHE_AUF + 'px;}',
      '.vsn.leer{display:none;}',

      '.vsn-kopf{height:' + (HOEHE_ZU - 1) + 'px;display:flex;align-items:center;gap:8px;padding:0 8px;box-sizing:border-box;}',
      '.vsn-klapp{cursor:pointer;flex:0 0 auto;border:1px solid rgba(120,150,180,.22);background:rgba(255,255,255,.04);'
        + 'color:#e8eef6;border-radius:7px;padding:2px 9px;font:600 11.5px "Segoe UI",Inter,sans-serif;}',
      '.vsn-klapp:hover{border-color:#23c7bb;}',
      /* Die Warnzeile darf schrumpfen und abschneiden, der Knopf nie — sonst gibt es einen Hinweis
         ohne Ausweg (dieselbe Ueberlegung wie bei #vsxSaalHint in vetstation-shell.css). */
      '.vsn-warn{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;'
        + 'color:#ffd166;font-size:11.5px;}',

      '.vsn-koerper{display:none;height:' + (HOEHE_AUF - HOEHE_ZU) + 'px;box-sizing:border-box;'
        + 'padding:0 6px 6px;gap:6px;overflow-x:auto;overflow-y:hidden;}',
      '.vsn.auf .vsn-koerper{display:flex;}',
      '.vsn-leerzeile{color:#8ba0b6;font-size:11.5px;padding:8px;}',

      '.vsn-karte{position:relative;flex:0 0 340px;height:' + (HOEHE_AUF - HOEHE_ZU - 6) + 'px;'
        + 'display:flex;flex-direction:column;min-width:0;box-sizing:border-box;'
        + 'background:#0e141c;border:1px solid #1a2330;border-radius:8px;overflow:hidden;}',
      /*
       * DER ALARM STEHT STILL (Wunsch 28.08.2026).
       *
       * Hier stand:
       *   '.vsn-karte.alarm{border-color:#ff4d4d;animation:vsn-puls 1.1s ease-in-out infinite;}'
       *   '@keyframes vsn-puls{0%,100%{box-shadow:0 0 0 0 …;}50%{box-shadow:0 0 0 3px …;}}'
       * Nach dem Umbau der Patientenfenster war das die EINZIGE verbliebene Animation der ganzen
       * Station (in vetstation-shell.css ist vsxpulse am selben Tag ersatzlos entfallen, siehe
       * den Kommentar dort).
       *
       * Und sie hat nicht einmal pulsiert. zeichne() baut den Streifen bei jeder Aenderung der
       * Signatur komplett neu (leere(koerper) + baueKarte -> NEUE Knoten), und in der Signatur
       * steht jeder Vitalwert (hr, sp, et, af, sys, dia, map, t, pri). Gemessen ueber 60 s an
       * einem lebenden Nachbarsaal mit wandernder HF: 60 Neubauten in 60 s (Gegenprobe mit
       * unveraenderten Werten: 0 — der Zaehler sieht also wirklich nur echte Aenderungen). Eine
       * 1,1-s-Animation, die jede Sekunde von vorn anfaengt, ist kein Pulsieren, sondern ein
       * Zucken. Der Tierarzt steht im OP vor dem Schirm; sein Satz war "es belaestigt die Augen".
       *
       * Ersatz: ein STEHENDER roter Ring. Er liegt bewusst als `outline` mit negativem Versatz
       * INNEN — ein aeusserer box-shadow waere oben abgeschnitten worden, weil die Karte die
       * Inhaltshoehe von .vsn-koerper (overflow-y:hidden, kein oberer Innenabstand) genau
       * ausfuellt. `outline` braucht keinen Platz im Layout und laesst die Bandhoehe unberuehrt.
       */
      '.vsn-karte.alarm{border-color:#ff4d4d;outline:2px solid rgba(255,77,77,.55);outline-offset:-2px;}',

      '.vsn-kkopf{flex:0 0 auto;height:22px;display:flex;align-items:center;gap:6px;padding:0 6px;'
        + 'box-sizing:border-box;background:#111926;border-bottom:1px solid #1a2330;}',
      '.vsn-kname{font-weight:700;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:130px;}',
      '.vsn-ksid{font:10px Consolas,monospace;color:#8ba0b6;flex:0 0 auto;}',
      '.vsn-karte.dop .vsn-ksid{color:#1a1204;background:#ffc23c;border-radius:4px;padding:0 4px;}',
      '.vsn-marke{font:10px Consolas,monospace;color:#cfe3ff;background:rgba(90,150,225,.16);'
        + 'border:1px solid rgba(120,170,235,.38);border-radius:5px;padding:0 5px;flex:0 0 auto;}',
      '.vsn-marke.warn{color:#1a1204;background:#ffc23c;border-color:#c78f16;}',
      '.vsn-alter{margin-left:auto;font:700 10px Consolas,monospace;flex:0 0 auto;'
        + 'border-radius:5px;padding:0 6px;color:#0d1a14;background:#35d69a;}',
      '.vsn-karte.s-alt .vsn-alter{background:#ffd166;color:#1a1200;}',
      '.vsn-karte.s-offline .vsn-alter{background:#ff8c3c;color:#1a1200;}',
      '.vsn-karte.s-unbekannt .vsn-alter{background:#8b93a7;color:#0b1017;}',
      /* 31.07.2026, Gegenpruefung: die Stufe 'weg' (ueber 12 h) hatte hier KEINE einzige Regel.
         Gemessen: die Marke fiel damit auf ihre Grundfarbe zurueck — GRUEN, wie 'live' — waehrend
         daneben "offline seit 780 min" stand. Erreichbar ohne Wartezeit: fremdstore.js:1007 setzt
         ersetzt nur bei 'offline', und fremdstore.js:984 wirft einen Saal erst weg, wenn BEIDE
         Quellen ueber 12 h alt sind. Eine 13 h alte Cloud-Momentaufnahme, die bei Widerspruch
         gegen das frische LAN gewinnt, kommt also mit vollen Vitalwerten hier an. */
      '.vsn-karte.s-weg .vsn-alter{background:#8b93a7;color:#0b1017;}',
      '.vsn-kbtn{cursor:pointer;flex:0 0 auto;border:1px solid rgba(120,150,180,.22);background:rgba(255,255,255,.04);'
        + 'color:#e8eef6;border-radius:6px;padding:1px 7px;font:11px "Segoe UI",Inter,sans-serif;}',
      '.vsn-kbtn:hover{border-color:#23c7bb;}',

      /* Das Schloss und der Satz stehen auf JEDER Karte, nicht nur einmal am Band: die Karte ist
         das, was der Tierarzt ansieht, und die Zusage gilt fuer jeden einzelnen Patienten darin. */
      '.vsn-sperr{flex:0 0 auto;height:15px;line-height:15px;padding:0 6px;font-size:10.5px;color:#8ba0b6;'
        + 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',

      '.vsn-kacheln{flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;padding:0 4px 4px;}',
      '.vsn-kachel{border-left:3px solid #8b93a7;background:rgba(255,255,255,.03);border-radius:5px;'
        + 'margin-top:4px;padding:2px 5px;}',
      '.vsn-kachel.p5{border-left-color:#ff4d4d;}',
      '.vsn-kachel.p4{border-left-color:#ff8c3c;}',
      '.vsn-kachel.p3{border-left-color:#a3e635;}',
      '.vsn-kachel.p0{border-left-color:#35d69a;}',
      '.vsn-z1{display:flex;align-items:center;gap:5px;height:15px;}',
      '.vsn-z2{display:flex;align-items:center;gap:5px;height:14px;}',
      '.vsn-tier{font-weight:600;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
      '.vsn-art{color:#8ba0b6;font-size:10.5px;white-space:nowrap;}',
      '.vsn-chip{margin-left:auto;font:10px Consolas,monospace;color:#8ba0b6;flex:0 0 auto;}',
      '.vsn-werte{font:11px Consolas,monospace;color:#cfe3ff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1 1 auto;min-width:0;}',
      '.vsn-top{font-size:10.5px;color:#ffb2b2;flex:0 0 auto;max-width:120px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
      /* ERSETZT, NICHT NUR EINGEFAERBT: ab 60 s verschwinden die Zahlen und an ihre Stelle tritt
         "Stand vor X min". Ein Blutdruck von 112/64 ist eine Aussage ueber JETZT — zwei Minuten
         alt ist diese Aussage falsch, und Grau macht sie nicht richtiger. */
      '.vsn-ersatz{display:none;font:11px Consolas,monospace;color:#ffb37a;}',
      /* 'weg' steht hier ueberall neben 'offline'. 31.07.2026, Gegenpruefung: stand nur 'offline'
         da, kamen die eingefrorenen Zahlen nach 12 h WIEDER ZUM VORSCHEIN, weil takte() die Klasse
         s-offline gegen s-weg tauscht. Ein Blutdruck, der zwei Minuten lang zu alt zum Zeigen war,
         ist nach dreizehn Stunden nicht wieder wahr. */
      '.vsn-karte.s-offline .vsn-werte,.vsn-karte.s-offline .vsn-top,.vsn-karte.s-offline .vsn-chip,'
        + '.vsn-karte.s-weg .vsn-werte,.vsn-karte.s-weg .vsn-top,.vsn-karte.s-weg .vsn-chip{display:none;}',
      '.vsn-karte.s-offline .vsn-ersatz,.vsn-karte.s-weg .vsn-ersatz{display:block;}',
      '.vsn-mehr{color:#ffd166;font-size:10.5px;padding:4px 3px 0;}',

      /* Die Geraetezeile liegt ALS OVERLAY ueber den Kacheln, sie schiebt sie nicht weg. Sonst
         waere ihr Aufklappen eine Hoehenaenderung der Karte — und die Karte haelt ihre Hoehe. */
      '.vsn-gpanel{display:none;position:absolute;left:0;right:0;top:22px;bottom:0;'
        + 'background:#0b1017;overflow-y:auto;padding:4px 6px;box-sizing:border-box;}',
      '.vsn-karte.gauf .vsn-gpanel{display:block;}',
      '.vsn-gzeile{display:flex;align-items:center;gap:6px;height:16px;font-size:11px;}',
      '.vsn-gtext{flex:1 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#cfe3ff;}',
      '.vsn-gstatus{flex:0 0 auto;font:10px Consolas,monospace;border-radius:4px;padding:0 5px;background:#8b93a7;color:#0b1017;}',
      '.vsn-gstatus.st-active{background:#35d69a;}',
      '.vsn-gstatus.st-standby{background:#ffd166;color:#1a1200;}',
      '.vsn-gstatus.st-offline{background:#8b93a7;}',
      '.vsn-galter{flex:0 0 auto;font:10px Consolas,monospace;color:#8ba0b6;width:48px;text-align:right;}',
      '.vsn-gkopf{font-size:10.5px;color:#8ba0b6;padding-bottom:3px;}',
    ].join('\n');
  }

  // ---------------------------------------------------------------- DOM-Handgriffe

  function neu(tag, klasse, inhalt) {
    var e = root.document.createElement(tag);
    if (klasse) e.className = klasse;
    if (inhalt != null) e.textContent = inhalt;
    return e;
  }

  // Leeren OHNE innerHTML — das Wort kommt in dieser Datei nicht vor, und der Test prueft das.
  function leere(e) {
    if (!e) return;
    while (e.firstChild) e.removeChild(e.firstChild);
  }

  function melde(m) {
    if (einst && typeof einst.log === 'function') { try { einst.log(m); } catch (e) {} }
  }

  // ---------------------------------------------------------------- Aufbau

  function stilEinhaengen() {
    var d = root.document;
    if (d.getElementById(STIL_ID)) return;
    var s = d.createElement('style');
    s.id = STIL_ID;
    s.textContent = stil();
    (d.head || d.documentElement).appendChild(s);
  }

  function ladeOffen() {
    try { return !!(root.localStorage && root.localStorage.getItem(SPEICHER) === 'auf'); } catch (e) { return false; }
  }
  function sichereOffen(a) {
    try { if (root.localStorage) root.localStorage.setItem(SPEICHER, a ? 'auf' : 'zu'); } catch (e) {}
  }

  function baueRahmen() {
    wurzel = neu('div', 'vsn leer');
    var kopf = neu('div', 'vsn-kopf');
    kopfKnopf = neu('button', 'vsn-klapp', '');
    kopfKnopf.onclick = function () { klappe(!offen); };
    kopfWarn = neu('div', 'vsn-warn', '');
    kopf.appendChild(kopfKnopf);
    kopf.appendChild(kopfWarn);
    koerper = neu('div', 'vsn-koerper');
    wurzel.appendChild(kopf);
    wurzel.appendChild(koerper);
    behaelter.appendChild(wurzel);
  }

  /*
   * klappe(auf) — die EINZIGE Stelle, an der das Band seine Hoehe aendert. Sie haengt an einem
   * Klick und an nichts sonst; kein Datenweg fuehrt hierher. Der Zustand bleibt in localStorage,
   * damit ein Kiosk-PC nach dem Neustart so aussieht, wie die Praxis ihn eingestellt hat.
   */
  function klappe(auf) {
    offen = !!auf;
    if (wurzel) {
      if (offen) wurzel.classList.add('auf'); else wurzel.classList.remove('auf');
    }
    sichereOffen(offen);
    kopfSchreiben();
    melde('Band ' + (offen ? 'aufgeklappt' : 'eingeklappt') + ' (Hoehe '
      + (offen ? HOEHE_AUF : HOEHE_ZU) + ' px)');
  }

  // ---------------------------------------------------------------- Zeichnen

  function zeichne() {
    if (!wurzel) return;
    var neuSig = signatur(nachricht);
    if (neuSig === sig) return;                 // nichts hat sich geaendert — nicht anfassen
    sig = neuSig;

    var saele = nachricht ? nachricht.saele : [];
    if (saele.length) jemalsSaal = true;
    /*
     * Ein Einzelplatz-PC soll KEIN Band sehen. Erst wenn in dieser Sitzung ueberhaupt einmal ein
     * Nachbar da war, bleibt der Streifen stehen — auch wenn der Nachbar spaeter ausfaellt. Sonst
     * verschwaende und erschiene das Band bei jedem Aussetzer, und ein Band, das kommt und geht,
     * ist am Bildschirm eine Bewegung ohne Aussage. Zulaessig ist beides nur, weil das Band ein
     * Overlay ist: es bricht auch beim Erscheinen kein einziges Patientenfenster um.
     */
    if (jemalsSaal) wurzel.classList.remove('leer'); else wurzel.classList.add('leer');

    // Die Bildlaufstelle gehoert dem Benutzer. Wer sie beim Neuzeichnen verliert, schiebt dem
    // Tierarzt den Saal weg, den er gerade ansieht.
    var scroll = koerper.scrollLeft || 0;
    leere(koerper);
    zeiger = [];

    var dop = doppelteNamen(saele);
    if (!saele.length) {
      koerper.appendChild(neu('div', 'vsn-leerzeile', 'Kein anderer OP-Saal meldet sich gerade.'));
    } else {
      for (var i = 0; i < saele.length; i++) koerper.appendChild(baueKarte(saele[i], dop));
    }
    koerper.scrollLeft = scroll;
    kopfSchreiben();
  }

  function baueKarte(s, dop) {
    var karte = neu('div', 'vsn-karte');
    karte.setAttribute('data-sid', s.sid);
    if (s.alarm) karte.classList.add('alarm');
    if (dop && dop.betroffen['#' + s.name]) karte.classList.add('dop');
    if (geraeteOffen[s.sid]) karte.classList.add('gauf');

    var name = s.name || NAME_UNBENANNT;

    // ---- Kopf der Karte: Saalname UND sid-Kurzform, auf JEDER Karte (Plan, oberflaechen)
    var kkopf = neu('div', 'vsn-kkopf');
    kkopf.appendChild(neu('span', 'vsn-kname', name));
    var ksid = neu('span', 'vsn-ksid', '· ' + s.kurz);
    ksid.title = 'Stationskennung ' + s.sid;
    kkopf.appendChild(ksid);
    kkopf.appendChild(neu('span', 'vsn-marke', s.quelle === 'lan' ? 'LAN'
      : (s.quelle === 'cloud' ? 'Cloud' : 'keine Quelle')));
    if (s.widerspruch) {
      var wid = neu('span', 'vsn-marke warn', 'Widerspruch');
      wid.title = 'Quellen widersprechen sich — es gilt die Cloud.';
      kkopf.appendChild(wid);
    }
    if (s.blind) {
      /* Befund C3 aus tafelabo: wer "offline" anzeigt, MUSS sagen koennen, ob der Nachbar steht
         oder der EIGENE Leseweg abgerissen ist. Sonst schickt das Band jemanden in einen Saal,
         in dem alles in Ordnung ist. */
      var bl = neu('span', 'vsn-marke warn', 'eigener Leseweg');
      bl.title = 'Nicht der Nachbar schweigt — dieser PC liest gerade nicht.';
      kkopf.appendChild(bl);
    }
    var alterKnoten = neu('span', 'vsn-alter', '');
    kkopf.appendChild(alterKnoten);

    var gKnopf = neu('button', 'vsn-kbtn', 'Geraete (' + s.geraete.length
      + (s.mehrGeraete ? '+' + s.mehrGeraete : '') + ')');
    gKnopf.title = 'Geraete in ' + name + ' anzeigen — nur Ansicht';
    gKnopf.onclick = (function (sid, k) {
      return function () {
        var an = !geraeteOffen[sid];
        if (an) geraeteOffen[sid] = true; else delete geraeteOffen[sid];
        if (an) k.classList.add('gauf'); else k.classList.remove('gauf');
      };
    }(s.sid, karte));
    kkopf.appendChild(gKnopf);

    /*
     * "OP 2 oeffnen" loest AUSSCHLIESSLICH den Rueckruf des Einbetters aus. Dieses Modul navigiert
     * nirgendwohin und oeffnet kein Fenster: der Patient haengt an einem anderen PC, und ein
     * Fenster daneben waere die Einladung, ihn von hier aus zu fahren.
     */
    var oKnopf = neu('button', 'vsn-kbtn', name + ' oeffnen');
    oKnopf.onclick = (function (saal) {
      return function () {
        if (einst && typeof einst.beimOeffnen === 'function') {
          try { einst.beimOeffnen(saal.sid, saal); } catch (e) { melde('beimOeffnen hat geworfen: ' + e); }
        } else {
          melde('kein beimOeffnen gesetzt — "' + saal.sid + ' oeffnen" bleibt ohne Wirkung');
        }
      };
    }(s));
    kkopf.appendChild(oKnopf);
    karte.appendChild(kkopf);

    karte.appendChild(neu('div', 'vsn-sperr',
      '🔒 Nur Ansicht — dieser Patient haengt am PC in ' + name));

    // ---- Kacheln
    var kacheln = neu('div', 'vsn-kacheln');
    var ersatzKnoten = [], chipKnoten = [];
    if (!s.patients.length) {
      kacheln.appendChild(neu('div', 'vsn-mehr', s.quelle === 'aus'
        ? 'Von diesem Saal kommt gerade nichts an.'
        : 'Kein Patient in diesem Saal.'));
    }
    for (var i = 0; i < s.patients.length; i++) {
      var p = s.patients[i];
      var kachel = neu('div', 'vsn-kachel ' + priKlasse(p.pri));
      var z1 = neu('div', 'vsn-z1');
      z1.appendChild(neu('span', 'vsn-tier', p.n || p.pid || 'Patient'));
      var art = [];
      if (p.a) art.push(p.a);
      if (p.g != null) art.push(komma(p.g) + ' kg');
      z1.appendChild(neu('span', 'vsn-art', art.length ? art.join(' ') : 'Tierart ?'));
      if (p.auch.length) {
        var au = neu('span', 'vsn-marke warn', 'auch in ' + p.auch.join(', '));
        au.title = 'Dieser Patient ist in mehreren OP-Saelen gefuehrt.';
        z1.appendChild(au);
      }
      var chip = neu('span', 'vsn-chip', '');
      chip.title = 'Alter der Geraetedaten dieses Patienten';
      z1.appendChild(chip);
      chipKnoten.push({ knoten: chip, altMs: p.altMs });
      kachel.appendChild(z1);

      var z2 = neu('div', 'vsn-z2');
      z2.appendChild(neu('span', 'vsn-werte', werteText(p)));
      if (p.top) z2.appendChild(neu('span', 'vsn-top', p.top + (p.al ? ' · ' + p.al + ' Alarm' : '')));
      var ers = neu('span', 'vsn-ersatz', '');
      z2.appendChild(ers);
      ersatzKnoten.push({ knoten: ers, altMs: p.altMs });
      kachel.appendChild(z2);
      kacheln.appendChild(kachel);
    }
    if (s.mehr > 0) {
      kacheln.appendChild(neu('div', 'vsn-mehr',
        s.mehr + ' weitere Patienten werden nicht angezeigt — Deckel erreicht'));
    }
    karte.appendChild(kacheln);

    // ---- Geraetezeile (N13), ausklappbar, reine Ansicht
    var gp = neu('div', 'vsn-gpanel');
    gp.appendChild(neu('div', 'vsn-gkopf', 'Geraete in ' + name + ' — nur Ansicht, keine Bedienung'));
    var gKnoten = [];
    if (!s.geraete.length) {
      gp.appendChild(neu('div', 'vsn-gzeile', 'Dieser Saal meldet keine Geraete.'));
    }
    for (i = 0; i < s.geraete.length; i++) {
      var g = s.geraete[i];
      var zeile = neu('div', 'vsn-gzeile');
      zeile.appendChild(neu('span', 'vsn-gtext', geraeteText(g)));
      zeile.appendChild(neu('span', 'vsn-gstatus st-' + (g.status || 'unbekannt'), statusText(g.status)));
      var galter = neu('span', 'vsn-galter', '');
      zeile.appendChild(galter);
      gKnoten.push({ knoten: galter, altMs: g.altMs });
      gp.appendChild(zeile);
    }
    if (s.mehrGeraete > 0) {
      gp.appendChild(neu('div', 'vsn-mehr',
        s.mehrGeraete + ' weitere Geraete werden nicht angezeigt — Deckel erreicht'));
    }
    karte.appendChild(gp);

    zeiger.push({
      karte: karte, name: name, alarm: s.alarm,
      uebertragungMs: s.uebertragungMs,
      alterKnoten: alterKnoten,
      ersatz: ersatzKnoten, chips: chipKnoten, geraete: gKnoten,
      stufe: null,
    });
    return karte;
  }

  function kopfSchreiben() {
    if (!kopfKnopf) return;
    var n = nachricht ? nachricht.saele.length : 0;
    var mehr = nachricht ? nachricht.mehr : 0;
    kopfKnopf.textContent = (offen ? '▾' : '▴') + ' Nachbarsaele (' + n
      + (mehr ? '+' + mehr : '') + ')';
    kopfKnopf.title = offen ? 'Band einklappen' : 'Band aufklappen';
  }

  // ---------------------------------------------------------------- Zeitgeber

  /*
   * takte() — das sekuendliche Altern. Es fasst AUSSCHLIESSLICH CSS-Klassen und das textContent
   * einzelner Knoten an; keine Karte wird gebaut, keine entfernt, keine Hoehe geaendert.
   *
   * Der Bezugspunkt ist der EINGANG der Nachricht, gemessen mit derselben Uhr wie 'jetzt'. Damit
   * ist der Zuschlag eine Differenz zweier Ablesungen DERSELBEN Uhr — eine fremde Uhr, die
   * vorgeht, kann das Band nicht juenger machen, und ein Zeitsprung der eigenen Uhr (NTP nach
   * leerer CMOS-Batterie) wird auf 0 geklemmt, statt das Band um Stunden altern zu lassen.
   */
  function takte() {
    if (!wurzel || !nachricht) return;
    var jetzt = uhr();
    var seit = (eingang == null) ? 0 : (jetzt - eingang);
    if (!(seit >= 0)) seit = 0;

    for (var i = 0; i < zeiger.length; i++) {
      var z = zeiger[i];
      var ueb = (z.uebertragungMs == null || z.uebertragungMs < 0) ? null : z.uebertragungMs + seit;
      var stufe = altersStufe(ueb);
      if (stufe !== z.stufe) {
        if (z.stufe) z.karte.classList.remove('s-' + z.stufe);
        z.karte.classList.add('s-' + stufe);
        z.stufe = stufe;
        /* Ein Alarm zaehlt nur, solange die Zahlen gelten. Ist der Saal offline, sind sie gerade
           durch "Stand vor X min" ersetzt worden — dann waere ein pulsierender Rand eine Meldung
           ueber einen Zustand, den wir nicht mehr kennen. */
        if (z.alarm && (stufe === 'live' || stufe === 'alt')) z.karte.classList.add('alarm');
        else z.karte.classList.remove('alarm');
      }
      z.alterKnoten.textContent = alterText(stufe, ueb, z.name);

      var k;
      for (k = 0; k < z.chips.length; k++) {
        z.chips[k].knoten.textContent = dauerKurz(zuschlag(z.chips[k].altMs, seit));
      }
      for (k = 0; k < z.ersatz.length; k++) {
        z.ersatz[k].knoten.textContent = ersatzText(zuschlag(z.ersatz[k].altMs, seit));
      }
      for (k = 0; k < z.geraete.length; k++) {
        z.geraete[k].knoten.textContent = dauerKurz(zuschlag(z.geraete[k].altMs, seit));
      }
    }
    schreibeWarn();
  }

  // Ein unbekanntes Alter bleibt unbekannt. 'null + seit' waere eine Zahl — und damit eine
  // erfundene Altersangabe fuer einen Wert, von dem wir das Alter gerade nicht kennen.
  function zuschlag(altMs, seit) {
    if (altMs == null || altMs < 0) return null;
    return altMs + seit;
  }

  /*
   * frischeZeiger() — die ZEITEN aus der neuen Nachricht in die vorhandenen Knoten nachziehen.
   *
   * WARUM DAS SEIN MUSS, obwohl der Streifen stehen bleibt: die Signatur enthaelt absichtlich kein
   * zeitabhaengiges Feld. Bleibt sie gleich, wird nicht neu gezeichnet — und dann steht in den
   * Zeigern noch das uebertragungMs der ERSTEN Nachricht, waehrend der Bezugspunkt 'eingang' bei
   * jeder Nachricht nachrueckt. Nachgerechnet ist das genau der toedliche Fall: der Nachbar
   * verstummt, unsere Bridge schickt weiter im Sekundentakt dieselben (alten) Werte mit
   * wachsendem uebertragungMs, und das Band zeigt den toten Saal dauerhaft als "live", weil es
   * 500 ms + (jetzt - gerade eben) rechnet. Die Zuordnung ueber den Index ist sicher: die Zeiger
   * werden in derselben Reihenfolge gebaut, und Reihenfolge und Anzahl stehen in der Signatur —
   * aendert sich eine davon, ist ohnehin neu gezeichnet worden.
   */
  function frischeZeiger() {
    var saele = nachricht ? nachricht.saele : [];
    for (var i = 0; i < zeiger.length && i < saele.length; i++) {
      var z = zeiger[i], s = saele[i], k;
      z.uebertragungMs = s.uebertragungMs;
      for (k = 0; k < z.chips.length && k < s.patients.length; k++) z.chips[k].altMs = s.patients[k].altMs;
      for (k = 0; k < z.ersatz.length && k < s.patients.length; k++) z.ersatz[k].altMs = s.patients[k].altMs;
      for (k = 0; k < z.geraete.length && k < s.geraete.length; k++) z.geraete[k].altMs = s.geraete[k].altMs;
    }
  }

  function schreibeWarn() {
    if (!kopfWarn) return;
    var w = warnzeile(nachricht, doppelteNamen(nachricht ? nachricht.saele : []));
    if (kopfWarn.textContent !== w.kurz) kopfWarn.textContent = w.kurz;
    kopfWarn.title = w.voll;
  }

  function starteTakt() {
    if (zeitgeber != null) return;
    zeitgeber = root.setInterval(takte, TAKT_MS);
  }
  function stoppeTakt() {
    if (zeitgeber == null) return;
    root.clearInterval(zeitgeber);
    zeitgeber = null;
  }

  // ---------------------------------------------------------------- Schnittstelle

  /*
   * montiere(behaelterKnoten, opts) — Band anlegen. Mehrfaches Montieren ist erlaubt und baut neu
   * auf; das Stilblatt bleibt stehen (es haengt an seiner id und ist fuer jedes Band dasselbe).
   */
  function montiere(behaelterKnoten, opts) {
    if (!behaelterKnoten) return;
    if (wurzel) aus();
    behaelter = behaelterKnoten;
    einst = opts || {};
    uhr = (typeof einst.jetzt === 'function') ? einst.jetzt : function () { return Date.now(); };
    stilEinhaengen();
    behaelter.classList.add('vsn-halter');
    baueRahmen();
    offen = ladeOffen();
    if (offen) wurzel.classList.add('auf');
    kopfSchreiben();
    starteTakt();
    melde('Band montiert, ' + (offen ? 'aufgeklappt' : 'eingeklappt'));
  }

  /*
   * setze(m) — die Nachricht 'fremd' uebernehmen.
   *
   * Reihenfolge mit Absicht: erst zeichnen (nur wenn sich das Bild geaendert hat), dann takten.
   * So tragen frisch gebaute Knoten sofort ihr Alter und nicht erst nach einer Sekunde — sonst
   * stuende auf einer neuen Karte eine Sekunde lang gar nichts.
   */
  function setze(m) {
    if (!wurzel) return;
    if (!m || m.type !== 'fremd') return;
    nachricht = nimm(m);
    eingang = uhr();
    zeichne();
    frischeZeiger();
    takte();
  }

  function aus() {
    stoppeTakt();
    if (behaelter) {
      if (wurzel && wurzel.parentNode === behaelter) behaelter.removeChild(wurzel);
      behaelter.classList.remove('vsn-halter');
    }
    wurzel = null; kopfKnopf = null; kopfWarn = null; koerper = null;
    nachricht = null; eingang = null; sig = null; zeiger = []; geraeteOffen = {};
    jemalsSaal = false;
    melde('Band aus');
  }

  root.VetNachbarn = {
    montiere: montiere,
    setze: setze,
    aus: aus,
    /*
     * Die reinen Funktionen, damit tools/nachbarn-test.js jede einzeln pruefen kann, ohne Netz,
     * ohne Bridge und ohne Uhr. Sie halten keinen Zustand und fragen keine Uhr — jede Zeit ist
     * ein Argument.
     */
    pur: {
      text: text, sidKurz: sidKurz, komma: komma,
      altersStufe: altersStufe, alterText: alterText, ersatzText: ersatzText, dauerKurz: dauerKurz,
      priKlasse: priKlasse, hatAlarm: hatAlarm, werteText: werteText, geraeteText: geraeteText,
      statusText: statusText, nimm: nimm, signatur: signatur,
      NAME_UNBENANNT: NAME_UNBENANNT, TEXT_UNBEKANNT: TEXT_UNBEKANNT,
      doppelteNamen: doppelteNamen, warnzeile: warnzeile, zuschlag: zuschlag, stil: stil,
      STUFE_LIVE_MS: STUFE_LIVE_MS, STUFE_OFFLINE_MS: STUFE_OFFLINE_MS, STUFE_WEG_MS: STUFE_WEG_MS,
      DECKEL_SAELE: DECKEL_SAELE, DECKEL_KACHELN: DECKEL_KACHELN, DECKEL_GERAETE: DECKEL_GERAETE,
      HOEHE_ZU: HOEHE_ZU, HOEHE_AUF: HOEHE_AUF, TAKT_MS: TAKT_MS, SPEICHER: SPEICHER,
    },
  };
}(typeof window !== 'undefined' ? window : this));
