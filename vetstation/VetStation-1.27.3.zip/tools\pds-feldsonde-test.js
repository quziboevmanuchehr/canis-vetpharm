'use strict';
/*
 * pds-feldsonde-test.js — faehrt die Feldsonde gegen bekannte Geraete (28.08.2026).
 *
 * WARUM ES DIESE DATEI GIBT:
 * tools/pds-feldsonde.js laeuft am Praxis-PC, und was sie dort meldet, entscheidet, was der
 * Entwickler danach in bridge/src/adapters/hl7.js aendert. Eine Sonde, die IMMER dasselbe
 * sagt, waere schlimmer als keine: sie wuerde eine Vermutung mit dem Anschein einer Messung
 * versehen. Genau das ist dem Projekt schon einmal passiert (der alte hl7-client-test war
 * jahrelang gruen, weil sein Fake-Geraet auf jede Nachricht antwortete).
 *
 * Deshalb wird die Sonde an SECHS Geraeten mit BEKANNTEM Verhalten gefahren und muss jedes
 * Mal das richtige — und ein jeweils ANDERES — Urteil faellen:
 *
 *   "streng"            MSH-10 = 1203, 1-Sekunden-Echo, trennt bei jeder fremden Nachricht
 *                       (also auch beim ACK der Station).  Erwartet: erst ab Variante 3.
 *   "nur-msh10"         verlangt NUR die feste Kennung.     Erwartet: schon Variante 2.
 *   "ohne-echopflicht"  verlangt Form und Kennung, aber weder Echo noch Verzicht auf das
 *                       ACK.                                Erwartet: schon Variante 2.
 *   "tolerant"          nimmt alles an.                     Erwartet: schon Variante 1.
 *   "sendet-von-selbst" schickt Messwerte OHNE jede Abfrage. Erwartet: "Referenz!".
 *   (kein Geraet)       geschlossener Port.                 Erwartet: "keine Verbindung".
 *
 * =======================================================================================
 * DER UMBAU VOM 28.08.2026 — DIE DICHTHEITSPRUEFUNG IST JETZT ERZEUGEND, NICHT AUFZAEHLEND
 *
 * Bis heute stand hier eine Liste GEHEIM mit sieben bekannten Zeichenketten: genau denen,
 * die eine frueher Messung als Leck gefunden hatte. Diese Pruefung war 80 von 80 gruen,
 * waehrend fuenf ANDERE Felder offen standen (OBX-3 in beiden Haelften, OBX-4, OBX-6, QAK-3
 * und CE-Kennungen der Form GROSS_MIT_UNTERSTRICH). Eine Ausschlussliste kann den naechsten
 * Fehler nicht finden — sie kennt nur die vorigen. Im Projekt ist das eine benannte
 * Fehlerklasse ("Prüfung ohne Anlass", "blinde passt-Pruefung").
 *
 * Der Wachposten wird deshalb nicht mehr aufgezaehlt, sondern ERZEUGT:
 *
 *   LAUF A (Marken).  Das Testgeraet schreibt in JEDES Feld JEDES Segments eine eindeutige
 *     Marke ZZ<Kennung><Feldnummer>ZZ, dazu je Feld eine zweite Komponente ...K2ZZ (das Leck
 *     OBX-3 sass in der ZWEITEN Haelfte eines Feldes). Der Test TIPPT diese Marken nicht ab,
 *     er RECHNET sie aus MARKEN_PLAN und MARKEN_NACHRICHTEN aus — denselben Tabellen, aus
 *     denen das Geraet sie baut. Wer dem Geraet ein Feld hinzufuegt, hat es damit ohne jedes
 *     Zutun mitgeprueft.
 *     Zusicherung: KEINE EINZIGE dieser Marken steht in .txt oder .json.
 *     Dazu zwei Gegenrichtungen, ohne die die Zusicherung nichts wert waere:
 *       (1) Jede errechnete Marke muss auf der LEITUNG gewesen sein. Eine Suche, die nichts
 *           findet, weil der Begriff nie gesendet wurde, ist kein Nachweis.
 *       (2) Jede Marke, die auf der Leitung liegt, muss im errechneten Satz vorkommen —
 *           sonst schickt das Geraet etwas, wovon der Test nichts weiss, und die Zusicherung
 *           deckt weniger ab, als sie zu decken vorgibt.
 *     Und ein drittes Netz: im Bericht darf ueberhaupt kein ZZ...ZZ stehen, auch keines, das
 *     der Plan nicht vorhersagt.
 *
 *   LAUF B (echte Angaben).  Name, Nachname, Kennung, Geburtsdatum, Aktennummer,
 *     Tierarztname, Anschrift, Telefon, Standort, Alarmtext. Ebenfalls errechnet: die Werte
 *     kommen aus EINEM Objekt, das der Test dem Geraet uebergibt und danach durchsucht; die
 *     Schluessel stammen aus ANGABEN_VORGABE des Geraets, ein dort ergaenztes Feld wird also
 *     automatisch mitgesucht.
 *
 *   UMKEHRPROBE.  Ein Bericht, der NICHTS zeigt, ist dicht und wertlos. Geprueft wird
 *     deshalb im selben Atemzug, dass die Dinge, die er zeigen SOLL, noch dastehen:
 *     Kennziffer 101 mit dem Namen HR, der Messwert 88 als Zahl, die Zaehlungen der
 *     Ergebnistabelle, die Katalognummer des Alarms, die Codes der Beanstandung, der Bauplan
 *     und die gesendete Abfrage. In Lauf A steckt beides in DERSELBEN Nachricht (OBXECHT:
 *     Kennziffer 101, Wert 88, alle uebrigen Felder Marken) — das ist die schaerfste Form:
 *     dieselbe Zeile, und die Sonde muss das eine nehmen und das andere lassen.
 *
 *   POSITIVLISTE.  Zusaetzlich wird jede Zeichenkette der .json gegen die Tore der Sonde
 *     selbst gehalten (festerText/ZIFFERN): sie muss registriert oder reine Ziffernfolge
 *     sein. Das findet einen Schreibweg, der am Riegel vorbeilaeuft (etwa ein Feld, das erst
 *     NACH pruefeBefund an den Befund gehaengt wird). Es ist ausdruecklich nur die zweite
 *     Aussage — sie fragt den Code nach seiner eigenen Meinung. Der Beweis ist die
 *     Markensuche, die nichts davon kennt.
 *
 * GEGENPROBE (Pflicht, ausgefuehrt am 28.08.2026): in die Sonde wurden nacheinander vier
 * Lecks eingebaut — eines in ein Feld, an das beim Schreiben dieses Tests niemand gedacht
 * hat (NTE-4), eines in die zweite Komponente eines Feldes (OBX-3), eines am Riegel vorbei
 * (Zuweisung an den Befund NACH pruefeBefund) und eines nur im .txt (Ausdruck aus einer
 * Nebenvariablen, die der Riegel gar nicht sieht). Jedes hat diesen Test rot gefaerbt;
 * danach zurueckgedreht und wieder gruen. Ohne diesen Nachweis waere der Wachposten nur eine
 * Behauptung.
 * =======================================================================================
 *
 * WEITERE LUECKEN, DIE EINE GEGENPRUEFUNG GEFUNDEN HAT (und die hier geschlossen bleiben):
 *
 *  B) Drei Urteilszweige der Sonde hatte nie ein Test durchlaufen: "referenz-mit-periodik",
 *     "keine-verbindung" und — ueber die Profile 'tolerant' und 'ohne-echopflicht' — die
 *     Blindheitsprobe, die der Kopf von pds-testgeraet.js ausdruecklich verspricht.
 *  C) Alle Zusicherungen lasen nur e.stufe und urteil.satz, also das Erzeugnis genau des
 *     Codes, der geprueft werden soll. Verrutschte eine Schwelle in beurteile(), blieb alles
 *     gruen. Jetzt werden zusaetzlich die ROHZAHLEN geprueft (periodikRahmen, trennungen,
 *     messwerte, abfragenGesendet) und gegen die unabhaengige Zaehlung DES GERAETS gehalten.
 *  D) Die ASCII-Pruefung lief gegen /[^\x00-\x7F]/ und war damit blind fuer die Zeichen,
 *     deretwegen es sie gibt: beim Schreiben mit Encoding 'ascii' wird aus einem
 *     Gedankenstrich das Steuerzeichen 0x14, und 0x14 liegt in \x00-\x7F.
 *  G) baueAck, IDS_HEUTE und ECHO_TEXT sind ausdrueckliche KOPIEN aus hl7.js. Aendert dort
 *     jemand etwas, bildet Variante 1 den Ist-Zustand nicht mehr ab, ohne rot zu werden.
 *     Dagegen steht ein Riegel, der die Quelle liest.
 *
 * ZEITEN: alle acht Laeufe laufen GLEICHZEITIG, jeder an seinem eigenen Port und mit eigenem
 * Berichtsordner; die beiden langen bestimmen die Gesamtdauer (~18 s). Das ist gefahrlos,
 * weil die Urteile der Sonde aus ZAEHLUNGEN entstehen (Nachrichten, Trennungen) und nicht
 * aus Zeitmessungen — anders als bei der Zackensuche, wo Nebenlast schon einmal einen Test
 * hat umkippen lassen.
 *
 * PORTS: das Betriebssystem gibt sie (listen(0)), abgelesen wird geraet.port. Feste Nummern
 * haben in dieser Sitzung ein EADDRINUSE erzeugt, als zwei Laeufe gleichzeitig liefen — rot,
 * ohne dass etwas kaputt war. Ein Port, den das System eben erst vergeben hat, kann mit
 * nichts kollidieren; die Hausregel "45600-45699" soll die Kollision mit echten Diensten
 * (4601, 8770) verhindern, und die ist damit erst recht ausgeschlossen.
 *
 * Der Berichtsordner ist ein Wegwerf-Verzeichnis im Temp-Bereich und wird am Ende geloescht:
 * data/ ist der Ordner mit echten Befunden, dort haben Testlaeufe nichts verloren.
 *
 * Start:  dist/VetStation/node/node.exe tools/pds-feldsonde-test.js
 */

const fs = require('fs');
const os = require('os');
const net = require('net');
const path = require('path');
const { starte, MARKEN_PLAN, MARKEN_NACHRICHTEN, marke, ANGABEN_VORGABE } =
  require('./pds-testgeraet');
const { laufe, VARIANTEN, IDS_HEUTE, ECHO_TEXT, baueAck, festerText, ZIFFERN, MARKE,
  PARAM_NAME } = require('./pds-feldsonde');

const HOST = '127.0.0.1';

let bestanden = 0, fehlgeschlagen = 0;
function ok(bedingung, text, zusatz) {
  const z = zusatz === undefined || zusatz === null || zusatz === '' ? '' : '   [' + zusatz + ']';
  if (bedingung) { bestanden++; console.log('  ✓ ' + text + z); }
  else { fehlgeschlagen++; console.log('  ✗ FAIL: ' + text + z); }
}
/* Mit eigener Frist: laesst sich der Port nicht binden, meldet starte() das nur ueber onLog
 * und bereit() kaeme NIE. Ohne diese Frist liefe der Test stumm ins Zeitlimit, und die
 * Ursache staende nirgends. */
function bereit(g, log) {
  return new Promise((r, j) => {
    const frist = setTimeout(() => j(new Error('Testgeraet wurde nicht bereit. ' +
      (log || []).join(' | '))), 5000);
    g.bereit((p) => { clearTimeout(frist); r(p); });
  });
}
function stoppe(g) { return new Promise((r) => g.stop(r)); }

/*
 * geschlossenerPort() — eine Portnummer, auf der GARANTIERT nichts lauscht.
 * Das Betriebssystem vergibt sie (listen(0)), dann wird sofort wieder zugemacht. Eine frei
 * ausgedachte Nummer waere genau das, was hier geprueft werden soll: eine Vermutung.
 */
function geschlossenerPort() {
  return new Promise((r, j) => {
    const s = net.createServer();
    s.on('error', j);
    s.listen(0, HOST, () => {
      const p = s.address().port;
      s.close(() => r(p));
    });
  });
}

/* vorkommen(heu, nadel) — wie oft steht die Nadel im Heu? Die ZAHL, nicht das Ja/Nein: sie
 * ist zugleich der Nachweis des Anlasses ("war ueberhaupt auf der Leitung") und, im Bericht,
 * das Mass des Lecks. */
function vorkommen(heu, nadel) {
  if (!nadel) return 0;
  let n = 0, i = 0;
  for (;;) {
    const p = String(heu).indexOf(nadel, i);
    if (p < 0) return n;
    n++;
    i = p + 1;
  }
}

/*
 * Ein Durchgang: Testgeraet im gegebenen Profil starten, die Sonde fahren lassen, Geraet
 * stoppen. Zurueck kommt AUCH der Bericht des Geraets — er ist die zweite, unabhaengige
 * Zaehlung, gegen die sich die Zahlen der Sonde halten lassen (Befund C: ein Test, der nur
 * das Urteil liest, prueft den Code gegen sein eigenes Erzeugnis).
 *
 * UND: alles, was das Geraet wirklich hinausgeschickt hat (onSende), wird mitgeschrieben.
 * Ohne diesen Mitschnitt muesste die Dichtheitspruefung ANNEHMEN, dass die gesuchte Angabe
 * ueberhaupt auf der Leitung lag — und eine Suche ohne Anlass ist auch dann gruen, wenn der
 * Riegel gar nicht existiert.
 *
 * Der Periodik-Takt ist dichter als am echten Geraet (300 statt 1000 ms), damit die Sonde in
 * ihrem kurzen Fenster sicher MEHRERE Messwertnachrichten sieht — ihr Erfolgskriterium ist
 * "laufender Strom" (>= 2 Nachrichten), nicht "eine kam an".
 */
const LEITUNG_HOECHSTENS = 8 * 1024 * 1024;   // Deckel: der Mitschnitt darf den Test nicht sprengen

async function durchgang(o) {
  const log = [];
  const leitung = [];
  let leitungsBytes = 0;
  const geraet = starte({
    port: 0, host: HOST, profil: o.profil,
    antwortAufFehler: o.antwortAufFehler === true,
    marken: o.marken === true,
    angaben: o.angaben || null,
    periodikMs: 300, aperiodikMs: 900, markenMs: 250,
    onLog: (z) => { if (log.length < 400) log.push(z); },
    onSende: (t) => {
      if (leitungsBytes >= LEITUNG_HOECHSTENS) return;
      leitungsBytes += t.length;
      leitung.push(t);
    },
  });
  const port = await bereit(geraet, log);

  const befund = await new Promise((fertig) => {
    laufe({
      host: HOST, port: port,
      fensterMs: o.fensterMs || 2000,
      verbindeFristMs: 1500,
      nur: o.nur || 0,
      ordner: o.ordner,
      log: () => {},           // die Sonde schreibt sonst ihren ganzen Befund auf den Schirm
    }, fertig);
  });

  const bericht = geraet.bericht();
  await stoppe(geraet);
  return {
    befund: befund, geraet: bericht, log: log, port: port, ordner: o.ordner,
    leitung: leitung.join('\n'), leitungsBytes: leitungsBytes,
  };
}

/* Derselbe Ablauf ohne Geraet — fuer den Zweig "gar keine Verbindung". */
function durchgangOhneGeraet(port, ordner) {
  return new Promise((fertig) => {
    laufe({
      host: HOST, port: port, fensterMs: 800, verbindeFristMs: 1200,
      nur: 0, ordner: ordner, log: () => {},
    }, (b) => fertig({ befund: b, geraet: null, ordner: ordner }));
  });
}

/* Der Ersatz, wenn eine Variante gar nicht im Befund steht: er hat DIESELBEN Felder wie ein
 * echtes Ergebnis, aber lauter unmoegliche Werte. Ein fehlendes Ergebnis faellt damit auf,
 * statt an einer Zeile "cannot read property of undefined" den ganzen Test abzubrechen. */
function ergebnis(befund, nr) {
  return befund.ergebnisse.filter((e) => e.nr === nr)[0] ||
    { stufe: '(fehlt)', urteil: '(fehlt)', messwerte: [], messwerteAperiodisch: [],
      alarmKennungen: [], alarmAnzahl: -1, alarmeOhneKennung: -1, messwerteOhneKennziffer: -1,
      fehlerSegmente: [], verbindungsfehler: [], bauplaene: [], abfrageplan: [],
      sendefehler: [], periodikRahmen: -1, aperiodischeRahmen: -1, patientRahmen: -1,
      trennungen: -1, abfragenGesendet: -1, rahmen: -1, nameGesehen: false };
}
function stufenZeile(befund) {
  return befund.ergebnisse.map((e) => e.nr + ':' + e.stufe).join(' ');
}
function summe(befund, feld) {
  return befund.ergebnisse.reduce((n, e) => n + (e[feld] || 0), 0);
}
/* Ein Messwert aus der LISTE (frueher ein Objekt mit der Kennziffer als Schluessel — das ist
 * seit dem Umbau bewusst keine Struktur mehr, in der ein Schluessel aus Empfangenem
 * entstehen koennte). */
function messwert(e, kennziffer) {
  return (e.messwerte || []).filter((m) => m.kennziffer === kennziffer)[0] || null;
}
function fehlerSegment(e, name) {
  return (e.fehlerSegmente || []).filter((p) => p.name === name)[0] || null;
}
function code(plan, feld) {
  if (!plan || !plan.codes) return null;
  const t = plan.codes.filter((c) => c.feld === feld)[0];
  return t ? t.wert : null;
}

function lies(r) {
  const b = r.befund;
  return {
    txt: fs.readFileSync(path.join(r.ordner, b.dateien.txt), 'utf8'),
    json: fs.readFileSync(path.join(r.ordner, b.dateien.json), 'utf8'),
  };
}

/*
 * ZUERST: liegt ueberhaupt ein Bericht vor?
 * "Das Wort steht nicht drin" und "der Befund ist reines ASCII" sind beide gruen, wenn die
 * Datei leer ist — also muss vor beiden stehen, dass sie es nicht ist. Ein vollstaendiger
 * Befund hat ueber 2000 Zeichen und traegt sein Gesamturteil; alles darunter ist ein Abbruch
 * und kein Messergebnis.
 */
function pruefeVollstaendig(titel, d) {
  ok(d.txt.length > 2000 && /GESAMTURTEIL/.test(d.txt) && d.json.length > 2000,
    titel + ': es liegt ueberhaupt ein vollstaendiger Befund vor (sonst waere alles ' +
    'Folgende gruen, weil nichts dasteht)',
    d.txt.length + ' Zeichen .txt, ' + d.json.length + ' Zeichen .json');
  /* Reines ASCII ist keine Kosmetik: die Konsole und der Editor des Praxis-PCs laufen in
   * einem Windows-Zeichensatz, und ein Befund, der kaputt aussieht, wird nicht geglaubt.
   * Geprueft wird gegen dieselbe Klasse, gegen die nurAscii() filtert. /[^\x00-\x7F]/ waere
   * blind fuer den eigentlichen Anlass: geschrieben wird mit Encoding 'ascii', und aus einem
   * Gedankenstrich (U+2014) wird dabei nicht "?", sondern das Steuerzeichen 0x14. */
  const boese = d.txt.match(/[^\x09\x0a\x0d\x20-\x7e]/g);
  ok(!boese, titel + ': der Befund ist reines druckbares ASCII (Editor des Praxis-PCs)',
    boese ? boese.length + ' Zeichen, erstes 0x' + boese[0].charCodeAt(0).toString(16) : '');
}

// ---------------------------------------------------------------------------------------
// LAUF A: DIE MARKEN — ERRECHNET, NICHT GETIPPT
// ---------------------------------------------------------------------------------------

/*
 * markenAusPlan() — jede Marke, die das Geraet im Markenmodus erzeugt, aus DEMSELBEN Plan
 * gerechnet, aus dem es sie baut.
 *
 * WARUM NICHT DIE FERTIGE LISTE VOM GERAET HOLEN: dann pruefte der Test den Erzeuger gegen
 * sein eigenes Erzeugnis — der Fehler, der diesem Projekt den jahrelang gruenen
 * hl7-client-test eingebracht hat. Gerechnet wird deshalb hier, aus Segmentnamen und
 * Feldzahl; dass beide Rechnungen zusammenpassen, weist der Abgleich mit der LEITUNG nach
 * (in beide Richtungen, siehe unten).
 */
function markenAusPlan() {
  const benutzt = {};
  MARKEN_NACHRICHTEN.forEach((n) => n.forEach((k) => { benutzt[k] = true; }));
  const liste = [];
  Object.keys(benutzt).forEach((kennung) => {
    const p = MARKEN_PLAN[kennung];
    if (!p) return;
    for (let nr = 1; nr <= p.felder; nr++) {
      // MSH: arr[i] ist MSH-(i+1), weil MSH-1 das Trennzeichen selbst IST.
      const feldNr = p.name === 'MSH' ? nr + 1 : nr;
      if (Object.prototype.hasOwnProperty.call(p.fest, feldNr)) continue;
      liste.push({ ort: kennung + '-' + feldNr, text: marke(kennung, feldNr) });
      liste.push({ ort: kennung + '-' + feldNr + ' (2. Komponente)',
        text: marke(kennung, feldNr, 2) });
    }
  });
  return liste;
}

/* Alle ZZ...ZZ, die IRGENDWO in einem Text stehen — ohne jede Kenntnis des Plans. Damit
 * findet der Test auch eine Marke, die er selbst nicht vorhergesagt hat. */
function markenIm(text) {
  const gefunden = {};
  const treffer = String(text).match(/ZZ[A-Za-z0-9]+ZZ/g) || [];
  treffer.forEach((t) => { gefunden[t] = (gefunden[t] || 0) + 1; });
  return gefunden;
}

// ---------------------------------------------------------------------------------------
// POSITIVLISTE: jede Zeichenkette der .json gegen die Tore der Sonde
// ---------------------------------------------------------------------------------------

function textstellen(knoten, pfad, raus) {
  if (typeof knoten === 'string') { raus.push({ pfad: pfad, wert: knoten }); return raus; }
  if (Array.isArray(knoten)) {
    knoten.forEach((k, i) => textstellen(k, pfad + '[' + i + ']', raus));
    return raus;
  }
  if (knoten && typeof knoten === 'object') {
    Object.keys(knoten).forEach((k) => textstellen(knoten[k], pfad + '.' + k, raus));
    return raus;
  }
  return raus;
}

/*
 * pruefePositivliste() — die ZWEITE Aussage ueber die Dichtheit, und ausdruecklich nur die
 * zweite: sie fragt den Code nach seiner eigenen Meinung (festerText/ZIFFERN sind SEINE
 * Tore). Der Beweis ist die Markensuche, die davon nichts weiss.
 *
 * Was sie kann und die Markensuche nicht: sie findet einen Schreibweg, der am Riegel
 * vorbeilaeuft — etwa ein Feld, das erst NACH pruefeBefund an den Befund gehaengt wird, oder
 * eine Zeichenkette, die zwar kein Geraetetext ist, aber auch aus keiner der drei Quellen
 * stammt (ein Dateipfad, eine IP, eine err.message).
 */
function pruefePositivliste(titel, d, r) {
  const stellen = textstellen(JSON.parse(d.json), 'befund', []);
  const fremd = stellen.filter((s) => s.wert !== MARKE &&
    festerText(s.wert) !== s.wert && !ZIFFERN.test(s.wert));
  const abgewiesen = stellen.filter((s) => s.wert === MARKE);
  ok(stellen.length > 60,
    titel + ': die Positivliste hat ueberhaupt etwas zu pruefen',
    stellen.length + ' Zeichenketten in der .json');
  ok(fremd.length === 0,
    titel + ': JEDE Zeichenkette der .json ist registrierter Text der Sonde oder eine reine ' +
    'Ziffernfolge — es gibt keinen vierten Weg hinein',
    fremd.length ? fremd.slice(0, 3).map((s) => s.pfad + '="' + s.wert + '"').join('  |  ')
      : stellen.length + ' geprueft');
  ok(abgewiesen.length === 0,
    titel + ': keine Stelle traegt die Marke "' + MARKE + '" (dort haette ein Wert gestanden, ' +
    'der durch kein Tor passte)',
    abgewiesen.length ? abgewiesen.slice(0, 3).map((s) => s.pfad).join(', ') : 'keine');
  ok(r.befund.riegel && r.befund.riegel.abgewiesen === 0,
    titel + ': und der Riegel der Sonde selbst hat beim Schreiben NICHTS abgewiesen',
    'riegel.abgewiesen=' + (r.befund.riegel ? r.befund.riegel.abgewiesen : '(fehlt)'));
}

// ---------------------------------------------------------------------------------------
// RIEGEL GEGEN DIE KOPIEN AUS hl7.js (Befund G)
// ---------------------------------------------------------------------------------------

/*
 * baueAck(), IDS_HEUTE und ECHO_TEXT stehen in pds-feldsonde.js ABSICHTLICH doppelt: eine
 * Sonde, die den Adapter einbindet, prueft den Code gegen sein eigenes Kriterium (dieser
 * Fehler hat dem Projekt den jahrelang gruenen hl7-client-test eingebracht). Der Preis der
 * Doppelung ist, dass die beiden Staende auseinanderlaufen koennen — und dann bildet
 * Variante 1 nicht mehr ab, was die Station heute sendet, ohne dass irgendetwas rot wird.
 * Der Riegel liest deshalb die QUELLE als Text und vergleicht.
 *
 * Warum als Text und nicht mit require(): dann laege der Adapter im Testprozess, und der
 * naechste, der "es ist ja schon geladen" denkt, holt sich seine Erwartung von dort. Die
 * Doppelung ist gewollt; ueberwacht werden soll sie, nicht abgeschafft.
 *
 * ACHTUNG, bekannte Falle des Projekts: Quellpruefungen lesen auch KOMMENTARE, und in
 * hl7.js steht das MSH-Beispiel des Guides mehrfach im Fliesstext. Deshalb werden Kommentare
 * vorher entfernt und alle Anker sitzen auf Code-Zeilen.
 */
const QUELLE_ADAPTER = path.join(__dirname, '..', 'bridge', 'src', 'adapters', 'hl7.js');

function ohneKommentare(quelle) {
  return String(quelle)
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .split('\n').filter((z) => z.trim().slice(0, 2) !== '//').join('\n');
}

/*
 * alsLiteral(text) — die SICHERE Richtung.
 *
 * Verglichen wird nicht der entschluesselte Quelltext mit dem Laufzeitwert, sondern
 * umgekehrt: aus dem Laufzeitwert der Sonde wird das JS-Literal gebaut, das im Adapter
 * stehen muesste. Eine Zeichenkette zu ESCAPEN ist eindeutig; sie zu ENT-escapen ist eine
 * kleine Sprache mit Sonderfaellen, und ein Fehler darin verfaelschte genau das Ergebnis,
 * um dessentwillen dieser Riegel existiert. Der erste Entwurf ist an dieser Stelle
 * tatsaechlich gescheitert — aus jedem Leerzeichen wurde ein Rueckstrich.
 */
function alsLiteral(text) {
  return "'" + String(text)
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\r/g, '\\r')
    .replace(/\n/g, '\\n') + "'";
}

function pruefeKopien() {
  console.log('\n-- Riegel: die Kopien aus bridge/src/adapters/hl7.js sind noch aktuell --');
  const quelle = ohneKommentare(fs.readFileSync(QUELLE_ADAPTER, 'utf8'));

  // 1) Das Echo aus Guide 6.7.
  const mEcho = quelle.match(/\nconst PDS_ECHO = ('(?:[^'\\]|\\.)*');/);
  ok(!!mEcho, 'PDS_ECHO ist in hl7.js gefunden worden (sonst prueft der Riegel nichts)');
  ok(!!mEcho && mEcho[1] === alsLiteral(ECHO_TEXT),
    'ECHO_TEXT der Sonde ist Zeichen fuer Zeichen das PDS_ECHO des Adapters',
    mEcho ? mEcho[1] : '-');

  // 2) Die zwoelf Parameter-IDs des Vorgabe-Zweigs.
  const iQuery = quelle.indexOf('_sendQuery(sock) {');
  const block = iQuery < 0 ? '' : quelle.slice(iQuery, quelle.indexOf('];', iQuery));
  const gruppen = (block.match(/'QRF\|MON\|\|\|\|0&0\^1\^1\^0\^[0-9&]+'/g) || [])
    .map((s) => (s.match(/\^([0-9&]+)'$/) || ['', ''])[1].split('&'));
  ok(gruppen.length === IDS_HEUTE.length && gruppen.length > 0,
    'aus _sendQuery() sind ' + IDS_HEUTE.length + ' QRF-Gruppen ausgelesen worden',
    gruppen.length + ' gefunden');
  ok(JSON.stringify(gruppen) === JSON.stringify(IDS_HEUTE),
    'IDS_HEUTE der Sonde sind genau die IDs, die der Adapter heute abfragt',
    JSON.stringify(gruppen));

  /*
   * 3) Die Quittung, EINSCHLIESSLICH des dort gemessenen Feldversatzes.
   *
   * Beide Seiten bauen sie aus festen Stuecken und zwei berechneten Werten (Zeitstempel,
   * Control-ID). Im Quelltext des Adapters werden die beiden Rechnungen durch die Marken
   * '@ZEIT@' und '@ID@' ersetzt, dann werden alle Zeichenketten-Literale der Zuweisung
   * aneinandergehaengt — das ergibt genau die Vorlage, die zur Laufzeit entsteht, und zwar
   * in der ESCAPTEN Schreibweise des Quelltexts. Von der Sonde kommt dieselbe Vorlage, indem
   * ihre fertige Quittung dieselben Marken bekommt und danach escaped wird.
   *
   * WARUM NICHT EINFACH "alle Literale zaehlen": in der Zuweisung steht
   * ".replace(/\D/g, '')" — das leere Paar Anfuehrungszeichen ist ein FUENFTES Literal und
   * gehoert nicht zur Nachricht. Ein Vergleich ueber die Anzahl der Stuecke ging genau
   * daran vorbei (gemessen: Adapter 5, Sonde 4). Nach der Ersetzung faellt es nicht mehr ins
   * Gewicht, weil es leer ist und beim Aneinanderhaengen nichts beitraegt.
   * "@ZEIT@" und "@ID@" sind als Marken gewaehlt, weil "@" in keinem der beteiligten
   * HL7-Telegramme vorkommt.
   */
  const mAck = quelle.match(/\n\s*const ack = ([^;]*);/);
  ok(!!mAck, '_sendAck() ist in hl7.js gefunden worden');
  const norm = !mAck ? '' : String(mAck[1])
    .replace(/new Date\(\)\.toISOString\(\)\.replace\(\/\\D\/g, ''\)\.slice\(0, 14\)/, "'@ZEIT@'")
    .replace(/\bctrlId\b/g, "'@ID@'");
  const sollAck = (norm.match(/'(?:[^'\\]|\\.)*'/g) || [])
    .map((s) => s.slice(1, -1)).join('');
  const istAck = baueAck('MSH|^~\\&|Mindray|uMEC12 Vet|||20260828120000||ORU^R01|7788|P|2.3.1|')
    .replace(/\d{14}/, '@ZEIT@').replace(/7788/g, '@ID@');
  const istRoh = alsLiteral(istAck).slice(1, -1);
  /* ANLASS: waeren beide Vorlagen leer oder haette die Ersetzung nicht gegriffen, waere der
   * Vergleich darunter trotzdem gruen. Also erst nachweisen, dass etwas dasteht. */
  ok(/@ZEIT@/.test(sollAck) && /@ID@/.test(sollAck) && sollAck.length > 40,
    'aus _sendAck() ist eine vollstaendige Vorlage mit beiden Rechenstellen ausgelesen worden',
    sollAck.length + ' Zeichen');
  ok(sollAck !== '' && sollAck === istRoh,
    'baueAck() der Sonde ist bytegleich zu _sendAck() des Adapters (samt Feldversatz)',
    istRoh);
  /* ANLASS fuer die Zeile darueber: ohne diese Gegenprobe hiesse Gleichheit nur, dass beide
   * Seiten leer sind. Der Feldversatz (MSH-9 leer, "ACK^R01" erst in MSH-10) ist der Grund,
   * warum die Sonde ihn ueberhaupt nachbaut — er muss also wirklich drinstehen. */
  ok(/\|\|ACK\^R01\|/.test(istAck) && istAck.split('|')[8] === '',
    'und dieser Feldversatz steckt wirklich darin: MSH-9 ist leer, "ACK^R01" liegt in MSH-10',
    'MSH-9=' + JSON.stringify(istAck.split('|')[8]) +
    ', MSH-10=' + JSON.stringify(istAck.split('|')[9]));
}

// ---------------------------------------------------------------------------------------
// DIE ECHTEN ANGABEN FUER LAUF B
// ---------------------------------------------------------------------------------------

/*
 * ECHT — was ein Monitor am Bett wirklich hinausschickt, hier erfunden und ausschliesslich
 * in dieser Datei vorhanden.
 *
 * JEDES WORT IST BEWUSST EINDEUTIG. Beim ersten Lauf dieser Pruefung meldete die Suche nach
 * "Muster" zwei Fundstellen im Bericht — und beide waren unser eigenes deutsches Wort
 * ("gegen dieses Muster geprueft") in der Zusage. Nicht der Riegel war blind, sondern der
 * mehrdeutige Suchbegriff. Ein Wert, der auch ein normales deutsches Wort sein kann, macht
 * diese Pruefung unbrauchbar; deshalb "Zwirbelhuber" und nicht "Muster".
 *
 * Die SCHLUESSEL kommen aus ANGABEN_VORGABE des Testgeraets, nicht von hier: wer dem Geraet
 * eine weitere Angabe gibt, bekommt sie automatisch mitgesucht (mit einem erzeugten,
 * ebenso eindeutigen Wert, falls hier keiner dafuer steht).
 */
const ECHT = {
  rufname: 'Bella',
  nachname: 'Zwirbelhuber',
  kennung: 'PATID-778899',
  geburt: '20190314',
  akte: 'AKTE-99887',
  tierarzt: 'Wiesinger',
  standort: 'OP-Saal-Nord',
  anschrift: 'Quellenweg-77',
  telefon: '9988776655',
  alarmtext: 'Apnoegrenze',
};
function echteAngaben() {
  const a = {};
  Object.keys(ANGABEN_VORGABE).forEach((k) => {
    /* Fuer ein Feld, das im Testgeraet neu ist und hier noch keinen Wert hat, wird einer
     * ERZEUGT — sonst fiele es stillschweigend aus der Suche heraus, und genau so entstehen
     * die Luecken, deretwegen diese Datei umgebaut wurde. */
    a[k] = ECHT[k] || ('Unbelegtesfeld' + k.charAt(0).toUpperCase() + k.slice(1));
  });
  return a;
}

// ---------------------------------------------------------------------------------------

async function lauf() {
  console.log('\n== PDS-Feldsonde gegen sechs Geraete mit bekanntem Verhalten ==\n');

  const ordner = {};
  ['streng', 'msh10', 'echofrei', 'tolerant', 'selbst', 'tot', 'marken', 'echt']
    .forEach((k) => {
      ordner[k] = fs.mkdtempSync(path.join(os.tmpdir(), 'vetstation-pds-' + k + '-'));
    });
  const totPort = await geschlossenerPort();
  const angaben = echteAngaben();

  const [streng, nurMsh10, echofrei, tolerant, selbst, tot, markenLauf, echtLauf] =
    await Promise.all([
      durchgang({ profil: 'streng', ordner: ordner.streng, fensterMs: 2000 }),
      durchgang({ profil: 'nur-msh10', ordner: ordner.msh10, fensterMs: 2000 }),
      /* Ein Lauf, zwei Anlaesse: Variante 1 wird verworfen und mit MSA/ERR/QAK beantwortet,
       * Variante 2 laeuft durch (das Echo ist NICHT die Ursache). Beides an einem Geraet, in
       * einem Fenster. */
      durchgang({ profil: 'ohne-echopflicht', antwortAufFehler: true,
        ordner: ordner.echofrei, fensterMs: 1500 }),
      durchgang({ profil: 'tolerant', nur: 1, ordner: ordner.tolerant, fensterMs: 2000 }),
      durchgang({ profil: 'sendet-von-selbst', nur: 8, ordner: ordner.selbst, fensterMs: 2000 }),
      durchgangOhneGeraet(totPort, ordner.tot),
      /* LAUF A: Marken in jedem Feld jedes Segments. Kurze Fenster genuegen — gemessen wird
       * hier nicht das Urteil, sondern was auf die Platte geht. */
      durchgang({ profil: 'streng', marken: true, ordner: ordner.marken, fensterMs: 400 }),
      /* LAUF B: echte Angaben, und das Geraet antwortet auf die verworfene Abfrage mit
       * MSA/ERR/QAK — dort standen Name und Aktennummer im Freitext. */
      durchgang({ profil: 'streng', antwortAufFehler: true, angaben: angaben,
        ordner: ordner.echt, fensterMs: 600 }),
    ]);

  // ---------------------------------------------------------------- Profil "streng"
  console.log('-- Profil "streng": MSH-10, Echo und kein fremdes ACK --');
  console.log('   Stufen: ' + stufenZeile(streng.befund));
  ok(streng.befund.ergebnisse.length === VARIANTEN.length,
    'alle acht Varianten wurden gefahren', streng.befund.ergebnisse.length + ' Ergebnisse');
  const s1 = ergebnis(streng.befund, 1), s2 = ergebnis(streng.befund, 2),
        s3 = ergebnis(streng.befund, 3), s8 = ergebnis(streng.befund, 8);
  ok(s1.stufe === 'stumm',
    'Variante 1 (was die Station heute sendet) bleibt ohne Messwerte', s1.urteil);
  ok(s2.stufe === 'abriss',
    'Variante 2 (nur MSH-10) liefert, reisst aber ab — das ACK laesst das Geraet trennen',
    s2.urteil);
  ok(s3.stufe === 'erfolg', 'Variante 3 (MSH-10 + Echo) liefert laufende Messwerte', s3.urteil);
  ok(s8.stufe === 'referenz',
    'Variante 8 (nur lauschen) sieht ohne Abfrage KEINE Messwerte', s8.urteil);
  ok(/^Ab Variante 3 \(msh10\+echo\)/.test(streng.befund.urteil.satz),
    'GESAMTURTEIL nennt Variante 3', streng.befund.urteil.satz.slice(0, 72) + '...');

  /*
   * DIE ROHZAHLEN UNTER DEM URTEIL (Befund C).
   * Bis 28.08.2026 lasen alle Zusicherungen nur e.stufe und urteil.satz — also genau das
   * Erzeugnis des Codes, der geprueft werden soll. Verrutschte eine Schwelle in beurteile()
   * (etwa von ">= 2 periodischen Nachrichten" auf ">= 1"), blieb der ganze Test gruen.
   * Geprueft werden deshalb die Zaehler, aus denen das Urteil entsteht.
   */
  console.log('   -- die Zahlen unter dem Urteil --');
  ok(s1.abfragenGesendet >= 1,
    'Variante 1: die Abfrage war wirklich auf der Leitung (sonst waere "stumm" kein Messwert)',
    s1.abfragenGesendet + ' Abfrage(n)');
  ok(s1.periodikRahmen === 0 && s1.messwerte.length === 0,
    'Variante 1: NULL periodische Nachrichten und kein einziger Messwert',
    'periodikRahmen=' + s1.periodikRahmen + ', Messwerte=' + s1.messwerte.length);
  ok(s1.aperiodischeRahmen >= 2 && s1.messwerteAperiodisch.length >= 3,
    'Variante 1: die Einzelmessungen kamen trotzdem — daran erkennt man den Ausfall NICHT',
    'aperiodisch=' + s1.aperiodischeRahmen + ', Codes=' +
    s1.messwerteAperiodisch.map((m) => m.kennziffer).join('/'));
  ok(s2.periodikRahmen >= 1 && s2.trennungen >= 1,
    'Variante 2: Messwerte kamen UND das Geraet hat getrennt (beides zusammen ist "abriss")',
    'periodikRahmen=' + s2.periodikRahmen + ', trennungen=' + s2.trennungen);
  ok(s3.periodikRahmen >= 2 && s3.trennungen === 0,
    'Variante 3: mehrere periodische Nachrichten und KEINE Trennung',
    'periodikRahmen=' + s3.periodikRahmen + ', trennungen=' + s3.trennungen);
  const hf = messwert(s3, '101'), spo2 = messwert(s3, '160');
  ok(!!hf && hf.letzter === 88 && hf.name === PARAM_NAME['101'] &&
     !!spo2 && spo2.letzter === 96,
    'Variante 3: HF 88 und SpO2 96 stehen als ZAHL in der Messwertliste, mit dem Namen aus ' +
    'der eigenen Tabelle der Sonde',
    '101=' + (hf ? hf.name + '/' + hf.letzter + ' (' + typeof hf.letzter + ')' : '-') +
    ', 160=' + (spo2 ? spo2.letzter : '-'));
  ok(s8.periodikRahmen === 0 && s8.abfragenGesendet === 0,
    'Variante 8: keine Abfrage gesendet und folgerichtig keine Periodik',
    'abfragen=' + s8.abfragenGesendet + ', periodikRahmen=' + s8.periodikRahmen);

  /*
   * ZWEITE, UNABHAENGIGE ZAEHLUNG: was das GERAET gesendet hat. Die Sonde kann nie MEHR
   * Nachrichten gezaehlt haben, als hinausgingen. Weniger schon: das Fenster schliesst
   * mitten im Strom, der letzte Rahmen je Variante kann verlorengehen. Genau so weit — und
   * keinen Schritt weiter — ist die Toleranz gefasst.
   */
  const gezaehlt = summe(streng.befund, 'periodikRahmen');
  ok(gezaehlt <= streng.geraet.gesendetNm &&
     gezaehlt >= streng.geraet.gesendetNm - VARIANTEN.length,
    'die Sonde zaehlt so viele Messwertnachrichten, wie das Geraet gesendet hat (bis auf ' +
    'hoechstens eine je Variante am Fensterrand)',
    'Sonde=' + gezaehlt + ', Geraet=' + streng.geraet.gesendetNm);
  const gefragt = summe(streng.befund, 'abfragenGesendet');
  ok(streng.geraet.abfragen.length <= gefragt &&
     streng.geraet.abfragen.length >= gefragt - VARIANTEN.length,
    'und das Geraet hat so viele Abfragen empfangen, wie die Sonde abgeschickt hat',
    'Sonde=' + gefragt + ', Geraet=' + streng.geraet.abfragen.length);

  const handlung = streng.befund.urteil.handlung.join(' ');
  ok(/pdsStrict/.test(handlung), 'die Handlungsempfehlung nennt pdsStrict (Variante 5 lief mit)');
  /*
   * ERWARTUNG NACHGEZOGEN (28.08.2026). Hier stand bis heute: die Empfehlung muss pdsStrict
   * UND "ack": false nennen. Das war richtig, solange der strikte Modus bei "ack": true
   * trotzdem quittierte — und genau diese Ausnahme ist entfallen (Guide 6.3.3 Punkt 9 laesst
   * das Geraet bei jeder anderen Nachricht als QRY und Echo trennen, also darf sie es nie).
   * Geprueft wird deshalb die AUSSAGE, nicht mehr die Zeichenkette.
   */
  ok(!/"ack": false setzen|UND dort "ack"/.test(handlung) && /"ack"/.test(handlung),
    'sie verlangt keine Handarbeit an "ack" mehr, sagt aber warum',
    handlung.slice(0, 96) + '...');

  // ---------------------------------------------------------------- Profil "nur-msh10"
  console.log('\n-- Profil "nur-msh10": das Geraet verlangt NUR die feste Kennung --');
  console.log('   Stufen: ' + stufenZeile(nurMsh10.befund));
  const m1 = ergebnis(nurMsh10.befund, 1), m2 = ergebnis(nurMsh10.befund, 2);
  ok(m1.stufe === 'stumm', 'Variante 1 bleibt auch hier ohne Messwerte', m1.urteil);
  ok(m2.stufe === 'erfolg', 'Variante 2 liefert hier schon laufende Messwerte', m2.urteil);
  ok(m1.periodikRahmen === 0 && m2.periodikRahmen >= 2 && m2.trennungen === 0,
    'auch hier stimmen die Zahlen unter dem Urteil',
    'V1 periodik=' + m1.periodikRahmen + ', V2 periodik=' + m2.periodikRahmen +
    ' trennungen=' + m2.trennungen);
  ok(/^Ab Variante 2 \(msh10\)/.test(nurMsh10.befund.urteil.satz),
    'GESAMTURTEIL nennt Variante 2', nurMsh10.befund.urteil.satz.slice(0, 72) + '...');
  ok(/nur die feste Kennung MSH-10/.test(nurMsh10.befund.urteil.satz),
    'und sagt im Klartext, dass NUR die feste Kennung gefehlt hat');

  // -------------------------------------------------- Profil "ohne-echopflicht" (Befund B)
  console.log('\n-- Profil "ohne-echopflicht": Form ja, Echo und ACK egal --');
  console.log('   Stufen: ' + stufenZeile(echofrei.befund));
  const e1 = ergebnis(echofrei.befund, 1), e2 = ergebnis(echofrei.befund, 2);
  ok(e1.stufe === 'stumm',
    'Variante 1 bleibt ohne Messwerte — die falsche Kennung MSH-10 genuegt allein zum Ausfall',
    e1.urteil);
  ok(e2.stufe === 'erfolg' && e2.trennungen === 0,
    'Variante 2 laeuft hier durch, OBWOHL sie weder echot noch auf das ACK verzichtet: ' +
    'gegen "streng" reisst genau sie ab',
    'stufe=' + e2.stufe + ', trennungen=' + e2.trennungen);
  ok(/^Ab Variante 2 \(msh10\)/.test(echofrei.befund.urteil.satz),
    'GESAMTURTEIL nennt Variante 2', echofrei.befund.urteil.satz.slice(0, 60) + '...');

  // ----------------------------------------------- Profil "tolerant": die Blindheitsprobe
  console.log('\n-- Profil "tolerant": die Blindheitsprobe des Testgeraets --');
  const t1 = ergebnis(tolerant.befund, 1);
  ok(t1.stufe === 'erfolg' && t1.periodikRahmen >= 2,
    'gegen ein tolerantes Geraet meldet schon Variante 1 Erfolg — genau deshalb ist ein ' +
    'nachgiebiges Fake-Geraet als Zeuge wertlos',
    'stufe=' + t1.stufe + ', periodikRahmen=' + t1.periodikRahmen);
  ok(/^Ab Variante 1 \(heute\)/.test(tolerant.befund.urteil.satz),
    'und das Gesamturteil sagt: an der Abfrage liegt es dann nicht',
    tolerant.befund.urteil.satz.slice(0, 70) + '...');

  // ------------------------------------- Profil "sendet-von-selbst": referenz-mit-periodik
  console.log('\n-- Profil "sendet-von-selbst": Messwerte ohne jede Abfrage --');
  const z8 = ergebnis(selbst.befund, 8);
  ok(z8.stufe === 'referenz-mit-periodik',
    'Variante 8 erkennt: das Geraet sendet Messwerte SCHON OHNE Abfrage', z8.urteil);
  ok(z8.abfragenGesendet === 0 && z8.periodikRahmen >= 2 && z8.messwerte.length >= 3,
    'die Zahlen dazu: keine Abfrage gesendet, trotzdem mehrere Messwertnachrichten',
    'abfragen=' + z8.abfragenGesendet + ', periodikRahmen=' + z8.periodikRahmen +
    ', Messwerte=' + z8.messwerte.length);
  ok(selbst.geraet.gesendetNm >= 2,
    'das Geraet bestaetigt das aus seiner eigenen Zaehlung',
    'gesendetNm=' + selbst.geraet.gesendetNm);
  ok(/AUCH OHNE jede Abfrage/.test(selbst.befund.urteil.satz) &&
     /Auswertung in der Station/.test(selbst.befund.urteil.handlung.join(' ')),
    'das Gesamturteil schickt den Entwickler in die Auswertung, nicht in die Abfrage',
    selbst.befund.urteil.satz.slice(0, 70) + '...');

  // ----------------------------------------------- kein Geraet: der wahrscheinlichste Fall
  console.log('\n-- geschlossener Port: falsche IP, falscher Port, Firewall --');
  ok(tot.befund.ergebnisse.length === VARIANTEN.length &&
     tot.befund.ergebnisse.every((e) => e.stufe === 'keine-verbindung'),
    'jede der acht Varianten meldet "keine Verbindung"', stufenZeile(tot.befund));
  /* Die Laenge steht bei JEDEM every() davor: ueber einer leeren Liste ist every() wahr,
   * und dann pruefte diese Zeile nichts. */
  ok(tot.befund.ergebnisse.length === VARIANTEN.length &&
     tot.befund.ergebnisse.every((e) => e.verbunden === false && e.rahmen === 0 &&
     e.abfragenGesendet === 0),
    'und keine einzige hat etwas gesendet oder empfangen',
    tot.befund.ergebnisse.length + ' Varianten geprueft');
  const totFehler = (ergebnis(tot.befund, 1).verbindungsfehler || [])[0] || {};
  ok(totFehler.art === 'Verbindungsaufbau fehlgeschlagen' && !!totFehler.grund,
    'der Grund steht im Befund — als Code aus der eigenen Liste, nicht als err.message ' +
    '(dort staende die Zieladresse)',
    totFehler.art + ' / ' + totFehler.grund);
  /*
   * DIE ADRESSE STEHT NICHT MEHR IM URTEIL, der Port schon. Bis zum Umbau hiess es "Das
   * Geraet antwortet nicht auf 127.0.0.1:45xxx" — eine IP faellt unter keine der drei
   * Quellen. Beides wird hier geprueft: dass der Port genannt wird (sonst liesse sich
   * "falscher Port" nicht beurteilen) UND dass die Adresse fehlt.
   */
  ok(/antwortet auf Port \d+ der angegebenen Adresse nicht/.test(tot.befund.urteil.satz) &&
     tot.befund.urteil.satz.indexOf(String(totPort)) >= 0,
    'das Gesamturteil nennt den Port', tot.befund.urteil.satz.slice(0, 70) + '...');
  ok(tot.befund.urteil.satz.indexOf(HOST) < 0 && tot.befund.aufruf.host === undefined,
    'aber NICHT die abgefragte Adresse — weder im Urteil noch im Kopf des Befunds',
    'aufruf=' + JSON.stringify(tot.befund.aufruf));
  ok(tot.befund.urteil.handlung.length >= 3 &&
     /Firewall/.test(tot.befund.urteil.handlung.join(' ')) &&
     /Stimmt die IP/.test(tot.befund.urteil.handlung.join(' ')),
    'und rueckt Kabel, IP, Geraeteeinstellung und Firewall heraus',
    tot.befund.urteil.handlung.length + ' Schritte');

  // ---------------------------------------------------------------- alle Laeufe zusammen
  console.log('\n-- alle Laeufe zusammen --');
  const saetze = [streng, nurMsh10, tolerant, selbst, tot].map((r) => r.befund.urteil.satz);
  ok(new Set(saetze).size === saetze.length,
    'die Sonde faellt an fuenf verschiedenen Geraeten FUENF verschiedene Urteile (sie ' +
    'antwortet nicht auswendig)',
    saetze.length + ' Laeufe, ' + new Set(saetze).size + ' Urteile');

  // =====================================================================================
  // LAUF A — MARKEN IN JEDEM FELD JEDES SEGMENTS
  // =====================================================================================
  console.log('\n== LAUF A: eine eindeutige Marke in JEDEM Feld JEDES Segments ==');
  const plan = markenAusPlan();
  const dA = lies(markenLauf);

  /* Erst der Plan selbst: sind die Marken ueberhaupt unterscheidbar? Waere eine Marke im
   * Text einer anderen enthalten (ZZPV11ZZ in ZZPV111ZZ), zaehlte ein Leck an der falschen
   * Stelle mit — die Zusicherung wuerde dann etwas anderes messen, als sie behauptet. */
  const texte = plan.map((m) => m.text);
  const doppelt = texte.filter((t, i) => texte.indexOf(t) !== i);
  const verschachtelt = texte.filter((a) => texte.some((b) => a !== b && b.indexOf(a) >= 0));
  ok(plan.length >= 200 && !doppelt.length && !verschachtelt.length,
    'der Markenplan ist brauchbar: genug Marken, jede einmalig, keine in einer anderen ' +
    'enthalten',
    plan.length + ' Marken aus ' + Object.keys(MARKEN_PLAN).length + ' Segmentbauplaenen' +
    (doppelt.length ? ', DOPPELT: ' + doppelt[0] : '') +
    (verschachtelt.length ? ', VERSCHACHTELT: ' + verschachtelt[0] : ''));

  /* ANLASS, RICHTUNG 1: jede errechnete Marke muss wirklich auf der Leitung gelegen haben.
   * Ohne diese Zeile waere die ganze Dichtheitspruefung auch dann gruen, wenn das Geraet gar
   * nichts sendet — die bekannte "Pruefung ohne Anlass". */
  const nichtGesendet = plan.filter((m) => vorkommen(markenLauf.leitung, m.text) === 0);
  ok(nichtGesendet.length === 0,
    'ANLASS: jede der ' + plan.length + ' errechneten Marken lag wirklich auf der Leitung',
    nichtGesendet.length
      ? nichtGesendet.length + ' fehlten, u. a. ' + nichtGesendet[0].ort
      : Math.round(markenLauf.leitungsBytes / 1024) + ' KB Mitschnitt');

  /* ANLASS, RICHTUNG 2: das Geraet darf nichts senden, wovon dieser Test nichts weiss —
   * sonst deckt die Zusicherung weniger ab, als sie zu decken vorgibt. */
  const aufLeitung = markenIm(markenLauf.leitung);
  const unbekannt = Object.keys(aufLeitung).filter((t) => texte.indexOf(t) < 0);
  ok(unbekannt.length === 0,
    'und umgekehrt: JEDE Marke auf der Leitung ist auch im errechneten Satz — der Test ' +
    'kennt alles, was das Geraet schickt',
    unbekannt.length ? unbekannt.length + ' unbekannt, u. a. ' + unbekannt[0]
      : Object.keys(aufLeitung).length + ' verschiedene Marken gezaehlt');

  pruefeVollstaendig('Marken', dA);

  // DIE ZUSICHERUNG.
  const lecks = plan.map((m) => ({
    ort: m.ort, text: m.text,
    txt: vorkommen(dA.txt, m.text), json: vorkommen(dA.json, m.text),
  })).filter((m) => m.txt || m.json);
  ok(lecks.length === 0,
    'KEINE EINZIGE der ' + plan.length + ' Marken steht in .txt oder .json',
    lecks.length
      ? lecks.length + ' Leck(s): ' + lecks.slice(0, 4).map((l) =>
          l.ort + ' ("' + l.text + '") ' + l.txt + 'x txt / ' + l.json + 'x json').join(' | ')
      : '0 Fundstellen bei ' + plan.length + ' Marken x 2 Dateien');

  /* Das dritte Netz: es kennt den Plan gar nicht. Faende der Bericht eine Marke, die dieser
   * Test nicht vorhergesagt hat, schluege trotzdem hier etwas an. */
  const zzTxt = Object.keys(markenIm(dA.txt)), zzJson = Object.keys(markenIm(dA.json));
  ok(!zzTxt.length && !zzJson.length,
    'und ueberhaupt kein ZZ...ZZ im Bericht — auch keines, das der Plan nicht vorhersagt',
    zzTxt.concat(zzJson).slice(0, 4).join(', ') || 'keines');

  pruefePositivliste('Marken', dA, markenLauf);

  /*
   * DIE UMKEHRPROBE, und zwar an DERSELBEN Nachricht.
   * Die dritte Markennachricht traegt einen gueltigen Kopf (ORU^R01/204) und ein OBX mit
   * Kennziffer 101 und dem Wert 88 — ringsherum nur Marken. Ein Bericht, der hier nichts
   * mehr zeigt, waere dicht und wertlos: dann haette man einen leeren Bericht und nennte das
   * Datenschutz.
   */
  console.log('   -- Umkehrprobe: was der Bericht zeigen SOLL, zeigt er noch --');
  const mAlle = markenLauf.befund.ergebnisse.map((e) => messwert(e, '101')).filter(Boolean);
  ok(mAlle.length >= 1 &&
     mAlle.every((m) => m.letzter === 88 && typeof m.letzter === 'number'),
    'die Kennziffer 101 und der Wert 88 stehen als ZAHL im Befund — aus derselben Zeile, ' +
    'aus der alle anderen Felder herausgefallen sind',
    mAlle.length + ' Variante(n), zuletzt=' + (mAlle[0] ? mAlle[0].letzter : '-') +
    ' (' + (mAlle[0] ? typeof mAlle[0].letzter : '-') + ')');
  /*
   * DER SCHAERFSTE EINZELNACHWEIS DIESES TESTS.
   * Auf der Leitung steht OBX-3 = "101^HR" — das "HR" ist die Beschriftung DES GERAETS. Die
   * eigene Tabelle der Sonde nennt dieselbe ID "HF". Steht im Bericht "HF", kommt der Name
   * aus PARAM_NAME; staende dort "HR", kaeme er aus OBX-3 — und genau dort stand bei der
   * Gegenmessung die Aktennummer ("101/HF LEAK_OBX3_TEXT_BELLA"). Zwei Zeichen, an denen die
   * ganze Frage haengt, woher der Text stammt.
   */
  ok(PARAM_NAME['101'] === 'HF' && mAlle.every((m) => m.name === PARAM_NAME['101']),
    'der Name kommt aus der eigenen Tabelle der Sonde (HF), nicht aus OBX-3',
    'Bericht="' + (mAlle[0] ? mAlle[0].name : '-') + '", Leitung="HR"');
  ok(dA.txt.indexOf('101/HR') < 0 && dA.txt.indexOf('^HR') < 0 &&
     dA.json.indexOf('HR') < 0,
    'und die Beschriftung des GERAETS ("HR") steht in keiner der beiden Dateien',
    (dA.txt.match(/Laufende Messwerte:[^\n]*/) || ['-'])[0].slice(0, 60));
  ok(/101\/HF/.test(dA.txt) && /zuletzt 88/.test(dA.txt),
    'im lesbaren Bericht steht der Messwert ausgeschrieben',
    (dA.txt.match(/Laufende Messwerte:[^\n]*/) || ['-'])[0].slice(0, 60));
  ok(/\(unbekanntes Segment\)/.test(dA.txt),
    'das unbekannte Segment XYZ erscheint als "(unbekanntes Segment)" — beschrieben, nicht ' +
    'benannt',
    (dA.txt.match(/\(unbekanntes Segment\)[^\n]*/) || ['-'])[0].slice(0, 62));
  ok(dA.txt.indexOf('XYZ') < 0,
    'und sein Name steht nirgends im Bericht (auch er ist Text vom Geraet)');
  ok(/Bauplan der empfangenen Nachrichten/.test(dA.txt) &&
     /OBX\s+\d+ Felder, gefuellt: [\d,]+/.test(dA.txt),
    'der Bauplan nennt Segment, Feldzahl und die gefuellten Feldnummern',
    (dA.txt.match(/OBX\s+\d+ Felder, gefuellt: [^\n]*/) || ['-'])[0].slice(0, 66));

  // =====================================================================================
  // LAUF B — ECHTE ANGABEN
  // =====================================================================================
  console.log('\n== LAUF B: Name, Geburtsdatum, Aktennummer, Tierarzt, Anschrift, Telefon ==');
  const dB = lies(echtLauf);
  pruefeVollstaendig('echte Angaben', dB);

  /* ANLASS zuerst, wieder in beide Richtungen: die Angabe muss auf der Leitung gewesen sein,
   * und die Wege, ueber die sie kommt, muessen wirklich gelaufen sein. */
  const b1 = ergebnis(echtLauf.befund, 1);
  ok(b1.nameGesehen === true,
    'ANLASS: die Nachricht MIT dem Patientennamen ist wirklich angekommen',
    'nameGesehen=' + b1.nameGesehen);
  ok(b1.alarmKennungen.indexOf('10127') >= 0,
    'ANLASS: der Alarm mit dem Namen im Meldetext kam an — im Bericht steht nur die ' +
    'Katalognummer', 'Alarme: ' + b1.alarmKennungen.join(', '));
  ok(echtLauf.geraet.fehlerAntworten >= 1 && b1.fehlerSegmente.length >= 3,
    'ANLASS: das Geraet hat MSA/ERR/QAK mit Name und Aktennummer geschickt',
    'gesendet=' + echtLauf.geraet.fehlerAntworten + ', empfangen=' + b1.fehlerSegmente.length);

  const angabenListe = Object.keys(angaben).map((k) => ({
    feld: k, wert: angaben[k],
    leitung: vorkommen(echtLauf.leitung, angaben[k]),
    txt: vorkommen(dB.txt, angaben[k]), json: vorkommen(dB.json, angaben[k]),
  }));
  angabenListe.forEach((a) => {
    ok(a.leitung > 0 && a.txt === 0 && a.json === 0,
      'die Angabe "' + a.feld + '" lag auf der Leitung und steht in KEINER der beiden Dateien',
      '"' + a.wert + '"  Leitung: ' + a.leitung + 'x' +
      (a.leitung === 0 ? '  — NIE GESENDET, die Suche haette keinen Anlass' : '') +
      (a.txt ? '  — ' + a.txt + 'x IM .TXT!' : '') +
      (a.json ? '  — ' + a.json + 'x IM .JSON!' : ''));
  });
  ok(angabenListe.length === Object.keys(ANGABEN_VORGABE).length && angabenListe.length >= 8,
    'geprueft wurde JEDE Angabe, die das Testgeraet kennt (die Liste kommt aus ihm, nicht ' +
    'von hier — ein dort ergaenztes Feld ist damit automatisch mitgeprueft)',
    angabenListe.length + ' Angaben');

  pruefePositivliste('echte Angaben', dB, echtLauf);

  /* Umkehrprobe fuer die Beanstandung: die CODES sind das Wertvollste im ganzen Lauf und
   * muessen stehen bleiben, waehrend der Freitext daneben faellt. */
  console.log('   -- Umkehrprobe: die Codes der Beanstandung stehen noch da --');
  const msa = fehlerSegment(b1, 'MSA'), err = fehlerSegment(b1, 'ERR'),
        qak = fehlerSegment(b1, 'QAK');
  ok(!!msa && code(msa, 1) === 'AR' && code(msa, 6) === '206',
    'MSA: der Ablehnungscode AR und die Fehlernummer 206 stehen im Befund',
    msa ? JSON.stringify(msa.codes) : '(kein MSA)');
  ok(!!err && code(err, 1) === 'QRD' && code(err, 4) === '206',
    'ERR: Segmentname und Fehlernummer stehen da, der Freitext dahinter nicht',
    err ? JSON.stringify(err.codes) : '(kein ERR)');
  ok(!!qak && code(qak, 2) === 'AE' && (qak.codes || []).length === 1,
    'QAK: nur der Antwortcode AE — QAK-1 (unser Query-Tag) und QAK-3 (dort stand der Name) ' +
    'werden gar nicht erst angesehen',
    qak ? JSON.stringify(qak.codes) : '(kein QAK)');
  ok(/MSA\s+\d+ Felder, gefuellt: [\d,]+/.test(dB.txt) && /MSA-1=AR/.test(dB.txt),
    'und im lesbaren Bericht steht die Beanstandung mit Aufbau und Codes',
    (dB.txt.match(/MSA\s+\d+ Felder[^\n]*/) || ['-'])[0].slice(0, 72));

  // =====================================================================================
  // UMKEHRPROBE AM VOLLEN LAUF: die Zaehlungen und die gesendete Abfrage
  // =====================================================================================
  console.log('\n-- Umkehrprobe am vollen Lauf: der Bericht ist nicht leer --');
  const dS = lies(streng);
  pruefeVollstaendig('streng', dS);
  /* Die Ergebnistabelle traegt die Zahlen, um derentwillen es den ganzen Befund gibt. Sie
   * werden HIER gegen die Struktur gehalten: ein Bericht, dessen Tabelle etwas anderes sagt
   * als seine eigene .json, waere schlimmer als gar keiner. */
  /* Der Anker muss die ZAHLENZEILE treffen und nicht die gleichlautende Zeile aus "DIE
   * GEFAHRENEN VARIANTEN" darueber (dort folgt auf denselben Kopf der Fliesstext). Deshalb
   * verlangt das Muster hinter dem Kurznamen zwei Zahlenspalten. */
  /* Die Spalten werden EINZELN gefangen und nicht mit /\d+/g eingesammelt: im Kurznamen
   * "msh10+echo" steckt selbst eine Zahl, und die zaehlte als erste Spalte mit — die
   * Zusicherung verglich dann Spalte 1 mit Spalte 2 und war rot, ohne dass etwas kaputt war. */
  const treffer3 = dS.txt.match(
    /\n\s+3 msh10\+echo\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)[^\n]*/);
  const zeile3 = treffer3 ? treffer3[0] : '';
  const zahlen3 = treffer3 ? treffer3.slice(1, 7).map(Number) : [];
  ok(zahlen3.length === 6 && zahlen3[0] === s3.rahmen &&
     zahlen3[1] === s3.periodikRahmen && zahlen3[2] === s3.aperiodischeRahmen &&
     zahlen3[3] === s3.alarmAnzahl && zahlen3[5] === s3.trennungen,
    'die Ergebnistabelle zeigt fuer Variante 3 genau die Zahlen aus der Struktur',
    'Tabelle: ' + zahlen3.join('/') + '   Struktur: ' + s3.rahmen + '/' + s3.periodikRahmen +
    '/' + s3.aperiodischeRahmen + '/' + s3.alarmAnzahl + '/' + s3.echos + '/' + s3.trennungen);
  ok(/MESSWERTE/.test(zeile3),
    'und das Kurzurteil daneben', zeile3.trim().slice(-24));
  ok(/Gesendete Abfrage/.test(dS.txt) && /QRY\^R02/.test(dS.txt) &&
     /<Zeitstempel>/.test(dS.txt) && /QRY\^R02\|1203\|/.test(dS.txt),
    'die gesendete Abfrage steht mit ihrem Aufbau darin — feste Stuecke woertlich, ' +
    'veraenderliche als <...>',
    (dS.txt.match(/MSH[^\n]*QRY\^R02[^\n]*/) || ['-'])[0].slice(0, 70));
  ok(/Katalognummern: 10127/.test(dS.txt),
    'der Alarm steht mit seiner Katalognummer da (der Meldetext daneben nicht)',
    (dS.txt.match(/Alarm-\/Codezeilen:[^\n]*/) || ['-'])[0].slice(0, 66));
  ok(/Riegel: 0 Wert\(e\) beim Schreiben abgewiesen/.test(dS.txt),
    'und der Riegel meldet sich im Bericht selbst',
    (dS.txt.match(/Riegel:[^\n]*/) || ['-'])[0].slice(0, 66));
  ok(dS.txt.indexOf(ordner.streng) < 0 && dS.json.indexOf(ordner.streng) < 0 &&
     dS.txt.indexOf(streng.befund.dateien.txt) > 0,
    'der DATEINAME steht im Bericht, der Pfad dorthin nicht (er nennt Benutzer und ' +
    'Ordnerstruktur des Praxis-PCs)',
    streng.befund.dateien.txt);

  pruefeKopien();

  Object.keys(ordner).forEach((k) => {
    try { fs.rmSync(ordner[k], { recursive: true, force: true }); } catch (e) {}
  });
}

const NOTAUS = setTimeout(() => {
  console.log('\nZEITLIMIT: der Test bricht nach 120 s ab (haengende node.exe blockiert den Bau).');
  process.exit(1);
}, 120000);
NOTAUS.unref();

lauf().then(() => {
  clearTimeout(NOTAUS);
  console.log('\n== Ergebnis: ' + bestanden + ' OK, ' + fehlgeschlagen + ' FAIL ==');
  // Hart beenden: offene Sockets oder ein vergessener Timer halten den Prozess sonst am Leben.
  process.exit(fehlgeschlagen ? 1 : 0);
}).catch((e) => {
  console.log('\nTestfehler: ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
