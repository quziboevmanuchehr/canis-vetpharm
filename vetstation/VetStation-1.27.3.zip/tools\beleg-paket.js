'use strict';
/* =============================================================================================
 * beleg-paket.js — aus BEURTEILTEN Streifen ein kleines Paket schnueren (25.08.2026)
 * =============================================================================================
 *
 * WARUM ES DIESE DATEI GIBT
 *
 * Die Frage war: "sollen die Praxis-PCs Kurven und Werte zu mir schicken?" Die Antwort aus dem
 * Konzept vom 20.08.2026 lautet NEIN fuer den Dauerstrom und JA fuer beurteilte Faelle:
 *
 *     "Der Engpass ist nicht die Leitung, sondern das Urteil. Hundert befundete Faelle sind
 *      mehr wert als ein Jahr unbefundeter Daueruebertragung."
 *
 * Gemessen dazu (25.08.2026, tools/fern-durchsatz-test.js am Baum 1.24.0):
 *     Dauerstrom heute        6,6 KB/s  = 23,2 MB je Narkosestunde  (davon 4,2 KB/s Kurven)
 *     100 beurteilte Faelle   rund 0,65 MB   — ein Sechsunddreissigstel EINER Stunde
 * Das Paket ist mengenmaessig kein Thema. Teuer ist das Urteil, nicht die Leitung.
 *
 * WAS HINEINKOMMT UND WAS NICHT
 *
 * Hinein kommt, was ein Modell braucht: Art, Rasse, Gewicht, Alter, Geraet, die Messgroessen
 * der Auswertung, die drei Rauschzahlen und das Urteil des Tierarztes.
 *
 * NICHT hinein kommt der Mensch daneben. Kein Besitzer, kein Telefon, keine Aktennummer, kein
 * Untersucher. Und ausdruecklich auch NICHT der Tiername: er bringt einem Modell nichts (es
 * lernt aus Art, Rasse, Gewicht, Alter, Geraet) und ist der groesste Angriffspunkt. Ihn
 * wegzulassen kostet fachlich nichts.
 *
 * Die Patientenkennung wird durch eine ABGELEITETE Kennung ersetzt (sha256 aus Stations-ID und
 * Patientenkennung, 12 Zeichen). Damit lassen sich mehrere Streifen desselben Tieres weiterhin
 * zusammenfuehren — was fuer die Trennung "nach Praxis, nicht nach Streifen" noetig ist —, ohne
 * dass die Kennung selbst mitreist. Genau der Fehler, den der Befund-Export heute noch macht:
 * er verspricht "Patienten-Kennungen sind unkenntlich gemacht" und haengt in Abschnitt 8 die
 * letzten 40 Logmeldungen roh an, in denen die Kennung samt Wirkstoff und Dosis steht.
 *
 * OHNE URTEIL KEIN BELEG. Ein Streifen ohne Urteil wandert nicht mit. Lieber neunzig geurteilte
 * Faelle als tausend geratene — ein ungeurteilter Streifen passt die Auswertung nur an ihre
 * eigene Ausgabe an.
 *
 * AUFRUF
 *     node tools/beleg-paket.js                     schreibt data/belege/beleg-<Zeit>.json
 *     node tools/beleg-paket.js --aus <datei.json>  liest ein ausgeleitetes Archiv statt data/
 *     node tools/beleg-paket.js --zeigen            schreibt nichts, zeigt nur was mitginge
 * ============================================================================================= */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const WURZEL = path.join(__dirname, '..');
const DATA = path.join(WURZEL, 'data');
const ZIEL = path.join(DATA, 'belege');

function arg(name, vorgabe) {
  const i = process.argv.indexOf(name);
  return (i >= 0 && process.argv[i + 1]) ? process.argv[i + 1] : vorgabe;
}
const nurZeigen = process.argv.includes('--zeigen');

/* Die Stations-ID ist der Salzwert. Sie liegt oertlich und geht NICHT mit — mit ihr liesse sich
 * die Ableitung sonst zurueckrechnen, sobald jemand beide Teile hat. */
function stationsSalz() {
  try {
    const d = JSON.parse(fs.readFileSync(path.join(DATA, 'station-id.json'), 'utf8'));
    return String(d.sid || d.fp || 'ohne-station');
  } catch (_) { return 'ohne-station'; }
}
function abgeleitet(salz, wert) {
  if (!wert) return null;
  return crypto.createHash('sha256').update(salz + '|' + String(wert)).digest('hex').slice(0, 12);
}

/* Das Archiv liegt im BROWSER (localStorage). Ein Node-Werkzeug kommt nicht daran heran — es
 * liest deshalb eine Datei, die die Oberflaeche ueber ihren Ausleiten-Knopf schreibt, oder
 * data/ekg-archiv.json, falls die Station eine Kopie abgelegt hat. Das ist kein Umweg, sondern
 * die Grenze: der Browser gibt seinen Speicher nicht von sich aus heraus. */
function archivLesen() {
  const eigen = arg('--aus', null);
  const kandidaten = eigen ? [eigen]
    : [path.join(DATA, 'ekg-archiv.json'), path.join(WURZEL, 'bridge', 'data', 'ekg-archiv.json')];
  for (const p of kandidaten) {
    try {
      const roh = JSON.parse(fs.readFileSync(p, 'utf8'));
      const liste = Array.isArray(roh) ? roh : (roh.archiv || roh.list || []);
      if (Array.isArray(liste)) return { pfad: p, liste };
    } catch (_) { /* naechster Kandidat */ }
  }
  return { pfad: null, liste: [] };
}

/* Ein Beleg. Feste Feldliste — eine POSITIVLISTE, damit nicht bei der naechsten Erweiterung des
 * Archivs still etwas mitwandert, das niemand geprueft hat. Genau die Fehlerart, die med{} in
 * registry.js schon einmal hatte. */
function beleg(r, salz) {
  const m = r.mess || {};
  return {
    /* Was beurteilt wurde */
    urteil: r.urteil,                       // 'ok' | 'art' | 'anders'
    urteilTs: r.urteilTs || null,
    automatik: r.name2 || r.rhythm || null, // was die Station gesagt hatte
    befunde: (r.befunde || []).map((x) => x.id).slice(0, 8),
    anlass: r.anlass || null,               // hand | auto | takt

    /* Das Tier — ohne den Menschen daneben und ohne Namen */
    tier: r.sp || null,
    rasse: r.rasse || null,
    kg: r.wt != null ? r.wt : null,
    alterMon: r.alterMon != null ? r.alterMon : null,
    fall: abgeleitet(salz, r.patId),

    /* Das Geraet und die Aufzeichnung */
    hz: r.hz != null ? r.hz : null,
    rohHz: (r.roh && r.roh.hz) || null,
    sekunden: r.sekunden != null ? r.sekunden : null,
    kalibriert: !!r.kal,
    geraet: r.geraet || null,

    /* Die Messgroessen, die die Auswertung ohnehin schon gerechnet hat */
    hf: m.hf != null ? m.hf : (r.hr != null ? r.hr : null),
    qrsMs: m.qrs != null ? m.qrs : null,
    rrMs: m.rr != null ? m.rr : null,
    pqMs: m.pq != null ? m.pq : null,
    qtMs: m.qt != null ? m.qt : null,
    qtcMs: m.qtc != null ? m.qtc : null,
    sdnnMs: m.sdnn != null ? m.sdnn : null,

    /* Die drei Rauschzahlen — der eigentliche Grund fuer das ganze Paket */
    guete: m.guete != null ? m.guete : null,
    stoer: m.stoer != null ? m.stoer : null,
    stoerSek: m.stoerSek != null ? m.stoerSek : null,
    stoerMass: m.stoerMass != null ? m.stoerMass : null,
  };
}

const salz = stationsSalz();
const { pfad, liste } = archivLesen();
const geurteilt = liste.filter((r) => r && r.urteil && URTEIL_GUELTIG(r.urteil));
function URTEIL_GUELTIG(u) { return u === 'ok' || u === 'art' || u === 'anders'; }

console.log('Beleg-Paket aus beurteilten Streifen\n');
if (!pfad) {
  console.log('  Kein Archiv gefunden.');
  console.log('  Erwartet wird eine der beiden Dateien:');
  console.log('    data/ekg-archiv.json');
  console.log('    bridge/data/ekg-archiv.json');
  console.log('  oder --aus <datei.json> mit einem in der Oberflaeche ausgeleiteten Archiv.');
  process.exit(0);
}
console.log('  Archiv:            ' + pfad);
console.log('  Streifen gesamt:   ' + liste.length);
console.log('  davon beurteilt:   ' + geurteilt.length
  + (liste.length ? '  (' + Math.round(geurteilt.length / liste.length * 100) + ' %)' : ''));

const zaehl = { ok: 0, art: 0, anders: 0 };
geurteilt.forEach((r) => { zaehl[r.urteil]++; });
console.log('    stimmt ' + zaehl.ok + ' · Artefakt ' + zaehl.art + ' · etwas anderes ' + zaehl.anders);

if (!geurteilt.length) {
  console.log('\n  Nichts zu packen. Im EKG-Archiv der Station beurteilen (✓ / 〰 / ?),');
  console.log('  dann dieses Werkzeug noch einmal aufrufen.');
  process.exit(0);
}

const belege = geurteilt.map((r) => beleg(r, salz));
const paket = {
  art: 'vetstation-belege',
  fassung: 1,
  erzeugt: new Date().toISOString(),
  station: abgeleitet(salz, 'station'),   /* auch die Station nur abgeleitet */
  anzahl: belege.length,
  belege,
};
const text = JSON.stringify(paket, null, 1);

console.log('\n  Paketgroesse:      ' + Math.round(text.length / 102.4) / 10 + ' KB'
  + '   (' + Math.round(text.length / belege.length) + ' Byte je Beleg)');
console.log('  Zum Vergleich:     eine Narkosestunde Dauerstrom sind rund 23,2 MB.');

/* Die Gegenprobe an der eigenen Zusage: steht irgendwo noch ein Klartextfeld drin, das nicht
 * hineingehoert? Das wird GEMESSEN und nicht behauptet - die Zusage des Befund-Exports war
 * genau deshalb falsch. */
const VERBOTEN = ['besitzer', 'owner', 'telefon', 'phone', 'tierName', 'patientName', 'name',
  'akte', 'arzt', 'untersucher', 'patId', 'email'];
const gefunden = [];
(function pruefe(o, weg) {
  if (!o || typeof o !== 'object') return;
  Object.keys(o).forEach((k) => {
    if (VERBOTEN.indexOf(k) >= 0) gefunden.push(weg + '/' + k);
    pruefe(o[k], weg + '/' + k);
  });
})(paket, '');
console.log('  Verbotene Felder:  ' + (gefunden.length ? ('!! ' + gefunden.join(', ')) : 'keine'));
if (gefunden.length) { console.log('\n  ABBRUCH — das Paket wird nicht geschrieben.'); process.exit(1); }

if (nurZeigen) {
  console.log('\n  --zeigen: nichts geschrieben. Ein Beleg sieht so aus:\n');
  console.log('  ' + JSON.stringify(belege[0], null, 1).split('\n').join('\n  '));
  process.exit(0);
}

fs.mkdirSync(ZIEL, { recursive: true });
const datei = path.join(ZIEL, 'beleg-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json');
fs.writeFileSync(datei, text, 'utf8');
console.log('\n  Geschrieben:       ' + datei);
console.log('\n  WOHIN JETZT: diese eine Datei weitergeben. Sie enthaelt keinen Besitzer, kein');
console.log('  Telefon, keine Aktennummer und keinen Tiernamen — nachgerechnet, siehe oben.');
