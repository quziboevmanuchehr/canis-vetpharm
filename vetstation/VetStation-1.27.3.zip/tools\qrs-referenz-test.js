'use strict';
/*
 * qrs-referenz-test.js — die Zackensuche an ECHTEN Hundesignalen mit menschlicher
 * Goldreferenz messen. Die erste Messung dieser Art im Projekt.
 *
 * WARUM ES DIESEN TEST GIBT (26.08.2026)
 *
 * findeQRS() ist die tragendste Funktion der ganzen EKG-Kette: Herzfrequenz, Rhythmus,
 * QRS-Breite, ST, P-Welle, Extrasystolen — alles haengt daran, dass die Schlaege gefunden
 * werden. Geprueft wurde sie bis heute AUSSCHLIESSLICH an synthetischen Signalen, die dieses
 * Projekt selbst erzeugt. Ein Generator kann aber nur die Fehler zeigen, an die sein Autor
 * gedacht hat.
 *
 * Seit dem 26.08.2026 liegen 17 oeffentliche Hundeaufzeichnungen vor (PhysioZoo/PhysioNet,
 * 500 Hz, wache Tiere ohne Medikamente) mit 10.860 vom Menschen korrigierten R-Zacken.
 * Das ist eine Wahrheit, die nicht aus diesem Projekt stammt.
 *
 * WAS DIE ERSTE MESSUNG ERGAB — und was daraufhin geaendert wurde:
 *
 *                            VORHER              NACHHER
 *     Aufnahmen mit 100 %       11 von 17           11 von 17
 *     Dog_02                     0,00 %              87,90 %
 *     Dog_03                     0,00 %              94,23 %
 *     Dog_04                     0,00 %              93,69 %
 *     Dog_10                    53,99 %             100,00 %
 *     Dog_13                     0,24 %              96,86 %
 *     Dog_17                     0,00 %              97,57 %
 *     ----------------------------------------------------------
 *     GESAMT Sensitivitaet      66,73 %              98,03 %
 *     GESAMT PPV                99,96 %              99,75 %
 *     Fehlalarme                     3                   27
 *
 * Die Ursache lag im BEZUGSRAUM der Schwelle: findeQRS() setzte sie auf "Median + 25 % des
 * Abstands zum HOECHSTWERT des ganzen Streifens". Enthaelt eine Aufnahme EINEN grossen
 * Stoerausschlag, richtet sich die Schwelle nach ihm. Gemessen an Dog_04: Energie an den
 * echten Schlaegen im Median 2,08e6, Schwelle 2,22e8 — Faktor 107 zu hoch. Bei Dog_02
 * Faktor 119, bei Dog_03 91, bei Dog_17 69. Genau diese vier Aufnahmen haben Abtastwerte am
 * Anschlag des Wandlers (Dog_04 0,30 % aller Werte).
 *
 * UND DAS WAR DER TEIL, DER ZAEHLTE: die Anwendung schwieg dazu NICHT. An 30-s-Ausschnitten
 * derselben Aufnahmen gemessen, mit ihrer echten Verstaerkung:
 *     Dog_04 -> "Verdacht auf ventrikulaere Tachykardie" (184/min) bei Guete 183,5
 *     Dog_13 -> "AV-Block II"
 *     Dog_17 -> "Sinusarrest / SA-Block"
 *     Dog_10 -> "AV-Block II"
 * Vier schwere Befunde an wachen, unbehandelten Hunden, deren Goldmarken ausnahmslos
 * "Normal" lauten. Es ist dieselbe Fehlerform, die [[vetstation-artefakt-blindheit]] und
 * [[vetstation-guete-blind-gemessen]] schon beschreiben — hier zum ersten Mal an ECHTEN
 * Tierdaten mit fremder Wahrheit gemessen statt an nachgestelltem Rauschen.
 *
 * DIE BEHEBUNG steht in ekg-analyse.js: die Schwelle gilt seither je 10-Sekunden-Abschnitt.
 * Ein Quantil statt des Hoechstwerts waere die naheliegende Alternative gewesen und ist
 * durchgemessen worden — 97,35 % Sensitivitaet, aber 135 statt 27 Fehlalarme. Die
 * Abschnittsschwelle ist in beiden Richtungen besser. Der Live-Weg (4-Sekunden-Fenster)
 * rechnet unveraendert, weil ein Streifen unter Abschnittslaenge genau EINEN Abschnitt
 * bekommt.
 *
 * WAS DIE BEHEBUNG NICHT LEISTET: Dog_02, Dog_03 und Dog_04 bleiben unter 95 %. Ein
 * verstoerter Abschnitt wird nicht gut, nur weil die anderen es sind. Genau deshalb steht
 * unten eine Pruefung, die diese drei beim Namen nennt, statt sie in einem Mittelwert
 * verschwinden zu lassen.
 *
 * WO DIE DATEN LIEGEN — UND WARUM NICHT IM REPO:
 *     ..\..\werkzeuge\ekg-referenz\physiozoo-dog-1.0.0\   (6,1 MB, 52 Dateien)
 * Ausserhalb von quellcode\, also ausserhalb der Bauwurzel von installer\make-dist.ps1 und
 * damit NICHT im Update-Paket. Zwei Gruende: 6 MB in jedem Update fuer einen reinen
 * Entwicklerbeleg waeren Verschwendung, und die Lizenz (Open Data Commons Attribution,
 * ODC-By v1.0) verlangt bei jeder Weitergabe die Namensnennung — die gehoert dann bewusst
 * gesetzt und nicht beilaeufig mitgepackt.
 * Fehlen die Daten, endet dieser Test mit einem Hinweis und OHNE Fehler. Auf dem Praxis-PC
 * gibt es sie nicht, und das ist richtig so.
 *
 * MESSREGELN, die nicht beliebig sind:
 *   • Treffer innerhalb 150 ms (ANSI/AAMI EC57 fuer QRS-Detektoren).
 *   • Annotationsluecken ueber 2 s werden AUSGENOMMEN — dort hat der Mensch nicht markiert
 *     (fuenf solche Luecken, bis 25,8 s, in genau den vier Aufnahmen mit Anschlagswerten).
 *     Ohne diese Ausnahme wuerde der Detektor fuer Schlaege bestraft, die niemand zaehlt.
 *   • Jede Goldmarke wird hoechstens EINEM Fund zugeordnet, gierig nach Naehe.
 *
 * Start:  node tools/qrs-referenz-test.js
 */
const fs = require('fs');
const path = require('path');
const VS = require('../ui/shared/ekg-analyse.js');

const DIR = path.join(__dirname, '..', '..', 'werkzeuge', 'ekg-referenz', 'physiozoo-dog-1.0.0');
const TOL_MS = 150;
const LUECKE_S = 2.0;

if (!fs.existsSync(DIR)) {
  console.log('qrs-referenz-test — uebersprungen.');
  console.log('  Die offenen Hundeaufzeichnungen liegen nicht unter:');
  console.log('  ' + DIR);
  console.log('  Das ist auf einem Praxis-PC der Normalfall und KEIN Fehler.');
  console.log('  Quelle: PhysioZoo auf PhysioNet, Lizenz ODC-By v1.0.');
  process.exit(0);
}

let ok = 0;
const fehler = [];
function pruefe(was, bedingung, zusatz) {
  if (bedingung) { ok++; return; }
  fehler.push(was + (zusatz ? '   [' + zusatz + ']' : ''));
}

/* ---- WFDB lesen. Eigener Leser, absichtlich. ---------------------------------------
 * Der Ernte lag ein fertiger Leser bei; sie meldet in ihm selbst einen Feldversatz um eins
 * beim Verstaerkungsfeld. Dieser hier wird gegen die Angaben im Kopf GEPRUEFT: erster
 * Abtastwert und 16-Bit-Pruefsumme stehen dort und muessen herauskommen. Ein Leser, der
 * seine eigene Datei nicht nachrechnen kann, ist keine Referenz.
 * -------------------------------------------------------------------------------------- */
function kopf(datei) {
  const z = fs.readFileSync(datei, 'utf8').split(/\r?\n/).filter((x) => x && x[0] !== '#');
  const a = z[0].trim().split(/\s+/), b = z[1].trim().split(/\s+/);
  const m = /^([-0-9.eE+]+)(?:\(([-0-9]+)\))?(?:\/(\S+))?$/.exec(b[2]);
  return {
    name: a[0], hz: Number(a[2]), n: Number(a[3]),
    datei: b[0], format: Number(b[1]),
    gain: m ? Number(m[1]) : null,
    baseline: m && m[2] != null ? Number(m[2]) : 0,
    einheit: m && m[3] ? m[3] : null,
    ersterWert: Number(b[5]), pruefsumme: Number(b[6]),
  };
}
function signal(datei, n) {
  const b = fs.readFileSync(datei);
  const o = new Array(Math.min(n, Math.floor(b.length / 2)));
  for (let i = 0; i < o.length; i++) o[i] = b.readInt16LE(i * 2);
  return o;
}
/* MIT-Annotationen: je Eintrag 16 Bit, code = wort>>10, Abstand zum vorigen = wort & 0x3FF.
 * 59 (SKIP) traegt den Abstand in den naechsten vier Byte, 63 (AUX) einen Text, 0 beendet. */
function annot(datei) {
  const b = fs.readFileSync(datei);
  const marken = [];
  let i = 0, t = 0;
  while (i + 1 < b.length) {
    const w = b.readUInt16LE(i); i += 2;
    if (w === 0) break;
    let code = w >> 10, abstand = w & 0x3FF;
    if (code === 59) {
      if (i + 5 >= b.length) break;
      const hoch = b.readInt16LE(i), tief = b.readUInt16LE(i + 2); i += 4;
      abstand = (hoch << 16) | tief;
      const w2 = b.readUInt16LE(i); i += 2;
      code = w2 >> 10;
    } else if (code === 63) {
      const laenge = w & 0x3FF;
      i += laenge + (laenge % 2);
      continue;
    }
    t += abstand;
    if (code === 1) marken.push(t);       // 1 = Normal; andere Codes tragen keine Schlagzeit
  }
  return marken;
}

/* ---- Messen ------------------------------------------------------------------------- */
function messeEine(nr) {
  const h = kopf(path.join(DIR, nr + '.hea'));
  const roh = signal(path.join(DIR, h.datei), h.n);
  const gold = annot(path.join(DIR, nr + '.qrs'));
  const tol = Math.round(h.hz * TOL_MS / 1000);

  /* Der Leser rechnet den Kopf nach. */
  let summe = 0;
  for (let i = 0; i < roh.length; i++) summe = (summe + roh[i]) & 0xFFFF;
  const ps = (summe << 16) >> 16;

  const luecken = [];
  for (let i = 1; i < gold.length; i++) {
    if (gold[i] - gold[i - 1] > h.hz * LUECKE_S) luecken.push([gold[i - 1] + tol, gold[i] - tol]);
  }
  luecken.push([0, Math.max(0, gold[0] - tol)]);
  luecken.push([gold[gold.length - 1] + tol, h.n]);
  function inLuecke(t) {
    for (let i = 0; i < luecken.length; i++) if (t >= luecken[i][0] && t <= luecken[i][1]) return true;
    return false;
  }

  const w = VS.grundlinieAbziehen(roh, h.hz);
  const gef = VS.findeQRS(w, h.hz);

  const benutzt = new Array(gef.length);
  const gewertet = gold.filter(function (g) { return !inLuecke(g); });
  let tp = 0, fn = 0, j = 0;
  gewertet.forEach(function (g) {
    while (j < gef.length && gef[j] < g - tol) j++;
    let besteI = -1, besteD = Infinity;
    for (let q = j; q < gef.length && gef[q] <= g + tol; q++) {
      if (benutzt[q]) continue;
      const d = Math.abs(gef[q] - g);
      if (d < besteD) { besteD = d; besteI = q; }
    }
    if (besteI >= 0) { benutzt[besteI] = true; tp++; } else fn++;
  });
  let fp = 0;
  for (let q = 0; q < gef.length; q++) if (!benutzt[q] && !inLuecke(gef[q])) fp++;

  let anschlag = 0;
  for (let i = 0; i < roh.length; i++) if (roh[i] >= 32767 || roh[i] <= -32768) anschlag++;

  return {
    nr: nr, hz: h.hz, n: h.n, gain: h.gain, kopfOk: (roh[0] === h.ersterWert && ps === h.pruefsumme),
    gold: gold.length, gewertet: gewertet.length, luecken: luecken.length - 2,
    gefunden: gef.length, tp: tp, fn: fn, fp: fp, anschlag: anschlag,
    se: gewertet.length ? 100 * tp / gewertet.length : 0,
    ppv: (tp + fp) ? 100 * tp / (tp + fp) : 0,
  };
}

console.log('qrs-referenz-test — findeQRS gegen 10.860 menschlich korrigierte Schlaege\n');
console.log('Aufnahme   Gold  gewertet Luecken  gefunden    TP   FN   FP   Se %    PPV %  Anschlag');

const alle = [];
for (let k = 1; k <= 17; k++) {
  const nr = 'Dog_' + (k < 10 ? '0' + k : '' + k);
  if (!fs.existsSync(path.join(DIR, nr + '.hea'))) continue;
  const r = messeEine(nr);
  alle.push(r);
  console.log(r.nr + '    ' + String(r.gold).padStart(5) + String(r.gewertet).padStart(9) +
    String(r.luecken).padStart(8) + String(r.gefunden).padStart(10) +
    String(r.tp).padStart(6) + String(r.fn).padStart(5) + String(r.fp).padStart(5) +
    r.se.toFixed(2).padStart(8) + r.ppv.toFixed(2).padStart(9) + String(r.anschlag).padStart(9));
}
console.log('');

pruefe('alle 17 Aufnahmen sind da', alle.length === 17, 'gefunden: ' + alle.length);

/* 1) Der Leser muss seine eigenen Dateien nachrechnen koennen. Ohne das ist jede weitere
 *    Zahl wertlos — der Test wuerde dann nur seinen eigenen Lesefehler messen. */
const kopfFalsch = alle.filter(function (r) { return !r.kopfOk; });
pruefe('jeder Kopf rechnet sich nach (erster Abtastwert + 16-Bit-Pruefsumme)',
  kopfFalsch.length === 0, kopfFalsch.map(function (r) { return r.nr; }).join(', '));

/* 2) Die Goldreferenz selbst: 10.860 Schlaege. Aendert sich diese Zahl, ist der
 *    Annotationsleser kaputt und nicht der Detektor. */
const goldSumme = alle.reduce(function (s, r) { return s + r.gold; }, 0);
pruefe('die Goldreferenz umfasst 10.860 Schlaege', goldSumme === 10860, 'gezaehlt: ' + goldSumme);
pruefe('alle Aufnahmen laufen mit 500 Hz',
  alle.every(function (r) { return r.hz === 500; }));

/* 3) Die Annotationsluecken sind da und werden ausgenommen — sonst misst der Test Unsinn. */
const mitLuecke = alle.filter(function (r) { return r.luecken > 0; });
pruefe('die bekannten Annotationsluecken werden erkannt und ausgenommen',
  mitLuecke.length === 4, mitLuecke.map(function (r) { return r.nr + '(' + r.luecken + ')'; }).join(' '));

/* 4) DER EIGENTLICHE WAECHTER: die elf sauberen Aufnahmen muessen sauber bleiben.
 *    Hier wird nichts beschoenigt — die Liste ist die gemessene, nicht die gewuenschte. */
const SAUBER = ['Dog_01', 'Dog_05', 'Dog_06', 'Dog_07', 'Dog_08', 'Dog_09',
  'Dog_11', 'Dog_12', 'Dog_14', 'Dog_15', 'Dog_16'];
SAUBER.forEach(function (nr) {
  const r = alle.filter(function (x) { return x.nr === nr; })[0];
  if (!r) { fehler.push(nr + ' fehlt'); return; }
  pruefe(nr + ': Sensitivitaet bleibt bei 100 %', r.se >= 99.5, r.se.toFixed(2) + ' %');
  pruefe(nr + ': hoechstens 3 Fehlalarme', r.fp <= 3, 'FP=' + r.fp);
});

/* 5) Die Gesamtzahlen als Untergrenze. Sie duerfen BESSER werden, nie schlechter. */
const TP = alle.reduce(function (s, r) { return s + r.tp; }, 0);
const FP = alle.reduce(function (s, r) { return s + r.fp; }, 0);
const G = alle.reduce(function (s, r) { return s + r.gewertet; }, 0);
const se = 100 * TP / G, ppv = 100 * TP / (TP + FP);
console.log('GESAMT   Sensitivitaet ' + se.toFixed(2) + ' %   PPV ' + ppv.toFixed(2) +
  ' %   (' + TP + ' getroffen, ' + (G - TP) + ' verfehlt, ' + FP + ' Fehlalarme von ' + G + ')');
pruefe('Sensitivitaet ueber alles faellt nicht unter den gemessenen Stand (98,0 %)',
  se >= 97.5, se.toFixed(2) + ' %');
pruefe('PPV ueber alles bleibt ueber 99,5 %', ppv >= 99.5, ppv.toFixed(2) + ' %');
pruefe('hoechstens 35 Fehlalarme insgesamt (gemessen 27)', FP <= 35, 'FP=' + FP);

/* 6) DIE SECHS, DIE DEN ANLASS GABEN — einzeln beim Namen genannt.
 *
 * Ein Mittelwert von 98 % kann drei Totalausfaelle verstecken; genau so sah es vor dem
 * 26.08.2026 aus (66,7 % im Mittel, aber fuenf Aufnahmen bei null). Deshalb steht hier je
 * Aufnahme eine eigene Untergrenze, gesetzt zwei Prozentpunkte unter dem gemessenen Wert.
 * Dass Dog_02, Dog_03 und Dog_04 dabei unter 95 % bleiben, ist kein Versehen, sondern der
 * ehrliche Stand: ihre Stoerstrecken sind wirklich gestoert. */
const UNTERGRENZE = { Dog_02: 85, Dog_03: 92, Dog_04: 91, Dog_10: 98, Dog_13: 94, Dog_17: 95 };
Object.keys(UNTERGRENZE).forEach(function (nr) {
  const r = alle.filter(function (x) { return x.nr === nr; })[0];
  if (!r) { fehler.push(nr + ' fehlt'); return; }
  pruefe(nr + ': Sensitivitaet mindestens ' + UNTERGRENZE[nr] + ' %',
    r.se >= UNTERGRENZE[nr], r.se.toFixed(2) + ' %');
});

/* 7) Der Zusammenhang, der den Anlass erklaerte, wird weiter MITGESCHRIEBEN — aber nicht
 *    mehr als Bedingung. Vor der Behebung fielen genau die Aufnahmen mit Anschlagswerten
 *    durch; nach der Behebung gilt das nur noch fuer drei der vier (Dog_17 liegt bei 97,6 %).
 *    Die Zeile steht da, damit die Zahl beim naechsten Umbau sichtbar bleibt. */
const mitAnschlag = alle.filter(function (r) { return r.anschlag > 20; }).map(function (r) { return r.nr; });
const schlecht = alle.filter(function (r) { return r.se < 95; }).map(function (r) { return r.nr; });
console.log('\nAufnahmen mit Werten am Wandleranschlag: ' + (mitAnschlag.join(', ') || '—'));
console.log('Aufnahmen unter 95 % Sensitivitaet:      ' + (schlecht.join(', ') || '—'));
pruefe('jede Aufnahme unter 95 % hat Anschlagswerte (umgekehrt gilt es nicht mehr)',
  schlecht.every(function (nr) { return mitAnschlag.indexOf(nr) >= 0; }),
  'schlecht: ' + schlecht.join(',') + '  Anschlag: ' + mitAnschlag.join(','));

/* ---------------------------------------------------------------------------------------
 * 8  DER LIVE-WEG, GETRENNT GEMESSEN.
 *
 * Die laufende Ueberwachung wertet nicht ganze Aufnahmen aus, sondern gleitende
 * 4-Sekunden-Fenster (registry.js). Das ist KUERZER als ein Schwellenabschnitt — jedes
 * Fenster bekommt also genau einen, und die Rechnung ist Wert fuer Wert dieselbe wie vor der
 * Aenderung vom 26.08.2026. Das ist ein Beweis aus der Bauart; hier steht die Messung dazu,
 * weil ein Beweis aus der Bauart schon oefter an einer Annahme haengen geblieben ist.
 *
 * Gemessen wird ueber ALLE 17 Aufnahmen in 4-s-Schritten, Stoerstrecken ausgenommen. Der
 * Wert ist naturgemaess schlechter als der ueber ganze Aufnahmen: in einem 4-s-Fenster stehen
 * nur wenige Schlaege, und die Raender schneiden welche an.
 * ------------------------------------------------------------------------------------- */
var liveTP = 0, liveG = 0, liveFP = 0;
alle.forEach(function (r) {
  const h = kopf(path.join(DIR, r.nr + '.hea'));
  const roh = signal(path.join(DIR, h.datei), h.n);
  const gold = annot(path.join(DIR, r.nr + '.qrs'));
  const tol = Math.round(h.hz * TOL_MS / 1000);
  const luecken = [];
  for (let i = 1; i < gold.length; i++) {
    if (gold[i] - gold[i - 1] > h.hz * LUECKE_S) luecken.push([gold[i - 1] + tol, gold[i] - tol]);
  }
  function inLuecke(t) {
    for (let i = 0; i < luecken.length; i++) if (t >= luecken[i][0] && t <= luecken[i][1]) return true;
    return false;
  }
  const fen = h.hz * 4;
  /* Nur jedes achte Fenster, sonst kostet dieser Abschnitt mehr Rechenzeit als der
   * ganze uebrige Test — die Stichprobe umfasst so immer noch ueber 300 Fenster. */
  for (let von = 0; von + fen < h.n; von += fen * 8) {
    const teil = roh.slice(von, von + fen);
    const w = VS.grundlinieAbziehen(teil, h.hz);
    const gef = VS.findeQRS(w, h.hz);
    /* Nur Goldmarken mit vollem Sicherheitsabstand zu den Fensterraendern werten. */
    const gw = gold.filter(function (g) {
      return g >= von + tol && g <= von + fen - tol && !inLuecke(g);
    }).map(function (g) { return g - von; });
    const benutzt = new Array(gef.length);
    let j = 0;
    gw.forEach(function (g) {
      while (j < gef.length && gef[j] < g - tol) j++;
      let bi = -1, bd = Infinity;
      for (let q = j; q < gef.length && gef[q] <= g + tol; q++) {
        if (benutzt[q]) continue;
        const d = Math.abs(gef[q] - g);
        if (d < bd) { bd = d; bi = q; }
      }
      if (bi >= 0) { benutzt[bi] = true; liveTP++; }
    });
    liveG += gw.length;
    for (let q = 0; q < gef.length; q++) {
      if (benutzt[q]) continue;
      const abs = gef[q] + von;
      if (abs < von + tol || abs > von + fen - tol || inLuecke(abs)) continue;
      liveFP++;
    }
  }
});
const liveSe = liveG ? 100 * liveTP / liveG : 0;
const livePpv = (liveTP + liveFP) ? 100 * liveTP / (liveTP + liveFP) : 0;
console.log('\nLive-Weg (4-s-Fenster, Stichprobe): Sensitivitaet ' + liveSe.toFixed(2) +
  ' %   PPV ' + livePpv.toFixed(2) + ' %   (' + liveTP + ' von ' + liveG + ', ' + liveFP + ' Fehlalarme)');
pruefe('die Stichprobe ist gross genug, um etwas auszusagen', liveG >= 1000, 'Schlaege: ' + liveG);
pruefe('Live-Weg: Sensitivitaet mindestens 95 %', liveSe >= 95, liveSe.toFixed(2) + ' %');
pruefe('Live-Weg: PPV mindestens 98 %', livePpv >= 98, livePpv.toFixed(2) + ' %');

console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + '):');
  fehler.forEach(function (f) { console.log('  x ' + f); });
  process.exit(1);
}
console.log('OK — ' + ok + ' Pruefungen an echten Hundesignalen.');
console.log('Daten: PhysioZoo (PhysioNet), Open Data Commons Attribution License v1.0.');
