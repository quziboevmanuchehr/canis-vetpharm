'use strict';
/*
 * model.js — Gemeinsames normalisiertes Datenmodell (Schicht 1 -> Schicht 2/3).
 * Jeder Geraete-Adapter liefert Frames GENAU in diesem Format ("ingest"-Modell aus §5 des Auftrags).
 * Species-IDs sind identisch zur Web-App (anaes-data.js), damit die Brain-Logik 1:1 wiederverwendet wird.
 */

// EKG-Auswertung (QRS/Rhythmus/ST) - dieselbe Datei, die auch die Oberflaeche nutzt (UMD-Modul).
// Wird bridge-seitig auf die ECHTE EKG-Kurve angewandt, sobald das Geraet einen Streifen sendet.
let ekgEngine = null;
try { ekgEngine = require('../../ui/shared/ekg-analyse.js'); } catch (_) { ekgEngine = null; }

// Kanonische Tierart-IDs (identisch zu window.ANAES.species in der Web-App).
const SPECIES = ['hund', 'katze', 'kaninchen', 'meerschwein', 'chinchilla', 'degu',
  'ratte', 'maus', 'hamster', 'rennmaus', 'frettchen', 'reptil'];

// Gueltige EKG-Rhythmus-IDs (= window.ANAES.ekg[].id). Die Brain-Regeln keyen darauf.
const EKG_RHYTHMS = ['sinus', 'sinusbrady', 'sinustachy', 'avb1', 'avb2a', 'avb2b', 'avb3', 'sves', 'ves', 'vtach', 'afib', 'aflutter', 'vfib', 'asys'];

// Kapnograf-Kurvenformen (= wCapno-Typen der Web-App). 'shark'/'baseline' schalten die Bronchospasmus-/Rueckatmungs-Analyse frei.
const CAPNO_SHAPES = ['normal', 'high', 'low', 'baseline', 'shark', 'flat'];

// Pleth-Formen (SpO2-Kurve).
const PLETH_SHAPES = ['normal', 'weak', 'flat'];

// Geraeterollen.
const DEVICE_ROLES = ['monitor', 'anesthesia', 'capno', 'combo'];

// Verbindungsstatus wie an einer IDEXX-Station.
const STATUS = ['connected', 'active', 'standby', 'error', 'offline'];

// WebSocket-Nachrichtentypen (Bridge -> UI und UI -> Bridge).
const MSG = {
  HELLO: 'hello',        // Bridge -> UI: Begruessung + Version
  DEVICES: 'devices',    // Bridge -> UI: aktuelle Geraeteliste (+Status)
  PATIENTS: 'patients',  // Bridge -> UI: pro-Patient zusammengefuehrte Datensaetze
  FRAME: 'frame',        // Bridge -> UI: einzelner Roh-Frame (optional/Diagnose)
  DIAG: 'diag',          // Bridge -> UI: Diagnose-/Verbindungsereignis (fuer Admin)
  /*
   * FREMD — die anderen OP-Saele dieser Praxis, als REINE ANSICHT.
   *
   * Warum ein EIGENER Nachrichtentyp und nicht ein Feld in PATIENTS: 'patients' ist der eigene
   * Arbeitsbereich. Alles, was dort steht, wird gefahren, gekoppelt, protokolliert und ins PDF
   * gedruckt. Ein fremder Patient darf davon nichts beruehren — er gehoert einem anderen PC, an
   * dem ein anderer Mensch steht. Ein getrennter Zweig ist die einzige Bauform, bei der man sich
   * darauf VERLASSEN kann, statt es an jeder einzelnen Stelle neu zu pruefen.
   *
   * Er kommt aus einem EIGENEN 1-Hz-Zeitgeber, nicht aus dem 350-ms-Rundruf: die Nachbarn
   * aendern sich langsam, und der Rundruf gehoert dem eigenen Saal.
   */
  FREMD: 'fremd',        // Bridge -> UI: Nachbarsaele (Tafel), nur Ansicht
  // UI -> Bridge (Steuerung — veraendert NUR die Bridge/Zuordnung, NIE die Geraete):
  PAIR: 'pair',          // manuelles Koppeln Monitor<->Kapno<->Patient
  UNPAIR: 'unpair',
  SET_META: 'setMeta',   // Tierart/Gewicht/Patient-ID nachtragen, wenn Geraet sie nicht liefert
  /* Wie SET_META, aber an die PATIENTEN-ID statt an ein Geraet. Noetig, weil setMeta ohne
   * deviceId sofort zurueckkehrt: solange noch kein Geraet angeschlossen ist, wurde ein von
   * Hand eingetragenes Gewicht dadurch still verworfen (Befund 19.08.2026). */
  SET_AKTE: 'setAkte',
  SCENARIO: 'scenario',  // Simulator-Szenario setzen (nur Test/Demo)
  /*
   * PROTOKOLL ERZEUGT / GEDRUCKT / GESPEICHERT (21.08.2026, Wunsch aus der Praxis).
   *
   * Warum ein eigener Nachrichtentyp und kein Feld an einer bestehenden Nachricht: das hier ist
   * ein EREIGNIS, kein Zustand. Es passiert genau einmal, in dem Augenblick, in dem ein Mensch
   * auf "PDF" oder "Drucken" klickt — und es loest zwei Dinge aus, die sonst nie passieren:
   * den vollstaendigen Nachtrag der Protokollzeilen in die Fern-Ansicht (auch der Zeilen von vor
   * einem Neustart) und einen Vermerk, DASS hier ein Dokument entstanden ist. Beides an einen
   * Zustand zu haengen hiesse, es bei jedem Takt erneut auszuloesen.
   */
  PROTOKOLL_ERZEUGT: 'protokollErzeugt',
  /*
   * MED — eine vom Tierarzt BESTAETIGTE Medikamenten-/Narkosemittelgabe.
   *
   * Der einzige Weg, auf dem ein Wirkstoff ins Narkoseprotokoll kommt. Empfehlungen der App
   * (Dosisrechner, Zwischenfall-Protokolle, Beatmungsberater) laufen NIE hierher — der Tierarzt
   * kann jede davon uebergehen, und ein Protokoll, das Vorschlaege als Gaben fuehrt, waere eine
   * falsche Krankenakte. Ausgeloest wird die Nachricht ausschliesslich vom Klick auf
   * „als gegeben" (ui/app/index.html), weitergereicht von ui/vetstation-live.js.
   *
   * Wie PAIR/SET_META veraendert sie NUR die Bridge, nie ein Geraet: read-only bleibt read-only.
   */
  MED: 'medGabe',
  ACK: 'ack',
};

function isSpecies(s) { return SPECIES.indexOf(s) >= 0; }

function num(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : parseFloat(String(v).replace(',', '.'));
  return Number.isFinite(n) ? n : null;
}

function clamp(v, lo, hi) {
  if (v === null) return null;
  return Math.max(lo, Math.min(hi, v));
}

/*
 * BEATMUNGS- UND GASKANAELE (additiv 05.08.2026, "universelles virtuelles Geraet").
 *
 * Bis hierher kannte das Datenmodell den Atemweg nur als etco2/fico2/paw. Der Bildschirm eines
 * echten Narkosegeraets (Veta 5 Plus, WATO, Draeger, Datex) zeigt daneben Spitzendruck, PEEP,
 * gemessenes Atemzugvolumen, Minutenvolumen, FiO2 und die ausgeatmete Narkosegaskonzentration —
 * alles Groessen, aus denen der Tierarzt handelt. Sie muessen denselben Weg gehen wie HF und
 * SpO2, sonst kommen sie in der Fern-Ansicht und im Protokoll nicht an.
 *
 * Jede Grenze hier ist ein PLAUSIBILITAETSFENSTER, kein Sollwert: sie faengt Muellzahlen ab
 * (Mindrays 32767, ein Vorzeichenfehler), veraendert aber keinen gueltigen Messwert.
 */
const VENT_FELDER = {
  ppeak: [0, 120],     // cmH2O — 120 ist jenseits jeder Beatmung, aber unterhalb von Muellwerten
  pmean: [0, 120],
  peep: [-10, 60],     // negativ ist moeglich (Sog/Nullpunktdrift) und wird gemeldet, nicht verworfen
  vte: [0, 5000],      // ml — Grosstier eingeschlossen
  mv: [0, 100],        // L/min
  compl: [0, 2000],    // ml/cmH2O
  fio2: [0, 100],      // %
  etAgent: [0, 25],    // Vol% — Desfluran laeuft bis 18
  fiAgent: [0, 25],
  mac: [0, 10],
  etn2o: [0, 100],     // %
  pi: [0, 30],         // %
  temp2: [5, 46],      // °C — wie temp
  ibp: [0, 400],       // mmHg (Mitteldruck invasiv)
};

function emptyVitals() {
  const v = {
    hr: null, ekgRhythm: null, spo2: null, pleth: null,
    etco2: null, fico2: null, paw: null, af: null,
    nibp: { sys: null, dia: null, map: null }, temp: null, capnoShape: null,
  };
  Object.keys(VENT_FELDER).forEach((k) => { v[k] = null; });
  return v;
}

/*
 * normalizeFrame(raw) -> { frame, warnings }
 * Vervollstaendigt Defaults, coerct Typen, plausibilisiert Werte, leitet MAP aus SYS/DIA ab.
 * warnings[] wird als Diagnose an den Admin-Bereich gemeldet (Datenqualitaet §14.5).
 */
function normalizeFrame(raw) {
  const warnings = [];
  const v = raw.vitals || {};
  const nibp = v.nibp || {};

  let sys = num(nibp.sys);
  let dia = num(nibp.dia);
  let map = num(nibp.map);
  if (map === null && sys !== null && dia !== null) {
    map = Math.round(dia + (sys - dia) / 3); // MAP ~= DIA + (SYS-DIA)/3 (wie Web-App)
  }

  let species = raw.species;
  if (species && !isSpecies(species)) {
    warnings.push('unbekannte Tierart "' + species + '" -> null');
    species = null;
  }

  let rhythm = v.ekgRhythm;
  if (rhythm && EKG_RHYTHMS.indexOf(rhythm) < 0) {
    warnings.push('unbekannter EKG-Rhythmus "' + rhythm + '"');
    rhythm = null;
  }
  let capnoShape = v.capnoShape;
  if (capnoShape && CAPNO_SHAPES.indexOf(capnoShape) < 0) {
    warnings.push('unbekannte Kapno-Form "' + capnoShape + '"');
    capnoShape = null;
  }

  // Plausibilitaet (nur warnen, Werte nicht verwerfen — der Tierarzt entscheidet).
  const spo2 = clamp(num(v.spo2), 0, 100);
  const hr = clamp(num(v.hr), 0, 400);
  const etco2 = clamp(num(v.etco2), 0, 150);
  const af = clamp(num(v.af != null ? v.af : v.rr), 0, 120);
  const temp = clamp(num(v.temp), 5, 46);
  const fico2 = clamp(num(v.fico2), 0, 60);

  // Kapno-Form aus Messwerten ableiten, wenn das Geraet keine Kurvenform liefert (echte HL7-Geraete):
  // erhoehtes eingeatmetes CO2 (FiCO2 > 5 mmHg) = RUECKATMUNG -> 'baseline' (Absorber/Frischgas pruefen).
  // 'shark' (Bronchospasmus) braucht eine Waveform-Steilheitsanalyse und bleibt daher geraeteabhaengig.
  if (capnoShape == null && fico2 != null && fico2 > 5) capnoShape = 'baseline';

  // Datenqualitaet (§14): unplausible/widerspruechliche Rohwerte melden (nur warnen, nie verwerfen).
  const rSpo2 = num(v.spo2), rHr = num(v.hr), rEt = num(v.etco2), rTemp = num(v.temp), rAf = num(v.af != null ? v.af : v.rr);
  if (rSpo2 != null && (rSpo2 < 0 || rSpo2 > 100)) warnings.push('SpO2 unplausibel (' + rSpo2 + ' %) — Sensor/Parser pruefen');
  if (rHr != null && (rHr < 0 || rHr > 400)) warnings.push('HF unplausibel (' + rHr + '/min)');
  if (rEt != null && rEt > 150) warnings.push('EtCO2 unplausibel (' + rEt + ' mmHg)');
  if (rTemp != null && (rTemp < 5 || rTemp > 46)) warnings.push('Temperatur unplausibel (' + rTemp + ' °C)');
  if (rAf != null && rAf > 120) warnings.push('Atemfrequenz unplausibel (' + rAf + '/min)');
  if ((rHr === 0 || rHr == null) && rSpo2 != null && rSpo2 > 50) warnings.push('SpO2 vorhanden trotz fehlender Pulsrate — Sensor/Bewegungsartefakt pruefen');

  /*
   * Beatmungs-/Gaskanaele: gleiche Behandlung wie oben — Zahl erzwingen, Fenster anlegen, bei
   * Ueberschreitung WARNEN statt still zu verwerfen. Ein verworfener Wert ohne Meldung ist das,
   * was am 22.07.2026 die Tierart und den Patientennamen unsichtbar verschwinden liess.
   */
  const ventWerte = {};
  Object.keys(VENT_FELDER).forEach((k) => {
    const roh = num(v[k]);
    if (roh == null) { ventWerte[k] = null; return; }
    const [lo, hi] = VENT_FELDER[k];
    if (roh < lo || roh > hi) {
      warnings.push((k) + ' unplausibel (' + roh + ') — Sensor/Einheit am Geraet pruefen');
      ventWerte[k] = null;         // lieber eine sichtbare Luecke als eine falsche Zahl
      return;
    }
    ventWerte[k] = roh;
  });
  /* Rueckatmung nochmals belegen: liefert ein Geraet FiCO2 nicht, wohl aber einen PEEP-nahen
   * CO2-Grundwert, bleibt es beim oben abgeleiteten capnoShape. Hier NICHTS erfinden. */

  const frame = {
    deviceId: String(raw.deviceId || 'unknown'),
    deviceModel: raw.deviceModel || 'Unbekannt',
    deviceRole: DEVICE_ROLES.indexOf(raw.deviceRole) >= 0 ? raw.deviceRole : 'monitor',
    patientId: raw.patientId != null ? String(raw.patientId) : null,
    species: species || null,
    weightKg: num(raw.weightKg),
    ts: num(raw.ts) || Date.now(),
    vitals: Object.assign({
      hr, ekgRhythm: rhythm || null, spo2,
      pleth: PLETH_SHAPES.indexOf(v.pleth) >= 0 ? v.pleth : null,
      etco2, fico2,
      paw: num(v.paw), af,
      nibp: { sys, dia, map }, temp,
      capnoShape: capnoShape || null,
    }, ventWerte),
    ventMode: raw.ventMode || null,
    isoPct: num(raw.isoPct),
    o2Flow: num(raw.o2Flow),
    ventParams: (raw.ventParams && typeof raw.ventParams === 'object') ? raw.ventParams : null,
    alarms: Array.isArray(raw.alarms) ? raw.alarms.slice(0, 30) : [],
    /*
     * DURCHREICHEN STATT WEGFILTERN (Kernaenderung 22.07.2026).
     * normalizeFrame() war eine Positivliste: alles, was hier nicht ausdruecklich stand, war nach
     * dieser Zeile verschwunden - auch dann, wenn der Adapter es sauber gelesen hatte. Genau so
     * gingen Tierart-Herkunft, Patientenname und die Rohwerte des Geraets verloren.
     * Diese Felder sind ANZEIGE-Beiwerk und werden bewusst NICHT plausibilisiert: sie fliessen in
     * keine Dosisberechnung ein, sondern belegen nur, was das Geraet geschickt hat.
     */
    herkunft: raw.herkunft || null,
    patientName: raw.patientName || null,
    gebDatum: raw.gebDatum || null,
    geschlecht: raw.geschlecht || null,
    // Patientenakte des Geraets (Besitzer, Arzt, Bett, Groesse, Alter, Rasse, Pacer, Telefon).
    // Reine Anzeige- und Protokolldaten - sie fliessen in KEINE Berechnung ein.
    akte: raw.akte && typeof raw.akte === 'object' ? raw.akte : null,
    deviceIp: raw.deviceIp || null,
    devicePort: raw.devicePort || null,
    transport: raw.transport || null,
    // Rohwerte des Geraets (jeder OBX-Eintrag) - Grundlage der Ansicht "Alle Werte vom Geraet".
    // Gedeckelt, damit ein dauersendendes Geraet den Speicher nicht volllaufen laesst.
    roh: (raw._meta && Array.isArray(raw._meta.roh)) ? raw._meta.roh.slice(0, 60) : [],
    kurven: (raw._meta && Array.isArray(raw._meta.kurven)) ? raw._meta.kurven.slice(0, 10) : [],
    /*
     * ECHTE KURVEN des Geraets (Abtastwerte + Abtastrate).
     * Die Architektur verzichtete bewusst auf Kurvenuebertragung und liess die Oberflaeche die
     * Kurven aus Herzfrequenz und Rhythmus NACHZEICHNEN. Am 22.07.2026 stellte sich heraus, dass
     * das LifeVet die Kurven sehr wohl liefert (EKG/Impedanz 256 Hz, CO2 40 Hz) - eine
     * NACHGEZEICHNETE Kurve kann aber keine QRS-Form und keine Haifischflosse zeigen, also genau
     * das, was am Kurvenbild klinisch zaehlt.
     * Deshalb werden sie jetzt uebertragen, aber streng gedeckelt: hoechstens 4 Kurven mit je 512
     * Werten (bei 256 Hz = 2 s). Das sind wenige KB je Aktualisierung, kein Dauerstrom.
     */
    kurvenDaten: Array.isArray(raw.kurvenDaten)
      ? raw.kurvenDaten.slice(0, 4).map((k) => ({
        name: String(k.name || '').slice(0, 40),
        code: k.code || null,
        hz: num(k.hz),
        skala: num(k.skala),
        /*
         * EINHEIT MITFUEHREN (07.08.2026).
         * Diese Liste ist eine POSITIVLISTE — was hier nicht steht, existiert hinter dieser
         * Stelle nicht mehr. Bis hierher fehlte die Einheit, und damit war jede Angabe in mV
         * unmoeglich: die Auswertung (ekg-analyse.js stMessung) verlangt Skala UND Einheit,
         * sonst nennt sie bewusst nur die Richtung. Unten wird seit jeher fest 'uV'
         * angenommen (Zeile ~278) — genau diese Annahme steht jetzt AM KANAL, statt an einer
         * einzelnen Aufrufstelle versteckt zu sein, und ein Geraet mit anderer Einheit kann
         * sie ueberschreiben, statt still falsch gerechnet zu werden.
         * MDC_ATTR_NU_MSMT_RES (die Quelle von skala) ist bei HL7-Monitoren in uV angegeben.
         */
        einheit: k.einheit ? String(k.einheit).slice(0, 8) : (num(k.skala) ? 'uV' : null),
        samples: Array.isArray(k.samples) ? k.samples.slice(0, 512) : [],
      }))
      : [],
    // ECHTE Kurven (kurvenDaten oben) werden jetzt gezeichnet: die UI holt die Abtastwerte bei
    // geaenderter Signatur ueber /api/kurven und spielt sie im virtuellen Monitor ab. Nur wenn ein
    // Kanal KEINE echte Kurve liefert, synthetisiert die UI sie aus den Vitalwerten (wEkg/wCapno/wPleth).
  };

  /*
   * EKG-AUSWERTUNG auf der ECHTEN Kurve (23.07.2026).
   * Sobald das Geraet einen EKG-Streifen sendet, werden QRS-Breite, Rhythmus (inkl. Extrasystolen),
   * Herzfrequenz aus den RR-Abstaenden und - bei bekannter Verstaerkung - die ST-Strecke berechnet.
   * Bewusst OHNE Tierart-Band hier (model.js kennt die Normbaender nicht): die Kernaussagen
   * (QRS, Unregelmaessigkeit, ST) haengen nicht davon ab; brady/tachy benennt die Oberflaeche
   * anhand der Herzfrequenz. Ergebnis wird an den Frame gehaengt; die Analyse SCHWEIGT im Zweifel.
   */
  const ekgKanal = frame.kurvenDaten.find((k) => /ECG|EKG|ELEC_POTL/i.test((k.code || '') + (k.name || '')));
  if (ekgEngine && ekgKanal && ekgKanal.hz && (ekgKanal.samples || []).some((s) => s != null)) {
    try {
      const a = ekgEngine.analysiere(ekgKanal, { einheit: 'uV' });
      frame.ekgAnalyse = {
        brauchbar: !!a.brauchbar, warum: a.warum || null,
        hf: a.hf != null ? a.hf : null,
        qrsBreiteMs: a.qrsBreiteMs != null ? a.qrsBreiteMs : null,
        rhythmus: a.rhythmus || null,
        st: a.st || null,
        guete: a.guete != null ? a.guete : null,
        /* DAS FENSTERWEISE STOERMASS KOMMT MIT (25.08.2026)
         * `guete` ist ein Median ueber den GANZEN Streifen und bauartbedingt blind: jede
         * Stoerung, die selbst Zacken erzeugt, wird als QRS gefunden und landet im ZAEHLER —
         * je heftiger sie stoert, desto sauberer sieht der Streifen aus. Gemessen: 100 von 100
         * Bewegungsspuren ergaben einen Herzbefund bei einer Guete von 71 bis 76.
         * stoerAbschnitte() misst statt dessen fensterweise (250 ms) die Ruhe ZWISCHEN den
         * Zacken. Das Ergebnis lag bisher nur im Arbeitsspeicher der Oberflaeche und kam hier
         * gar nicht an — die Bridge uebernahm allein `guete`.
         * NUR DIE DREI ZAHLEN, nicht die Fensterliste: die Liste hat je Streifen bis zu 80
         * Eintraege und wuerde als drittes Ebenenglied die Fern-Uebertragung sprengen.
         * AENDERT NICHTS AM VERHALTEN: gesperrt wird weiterhin allein ueber `guete`. Der
         * Stoeranteil an `sauber` zu haengen faerbte 12 von 65 echten Rhythmusbefunden rot
         * (Begruendung ausfuehrlich in ui/shared/ekg-analyse.js:1622). Hier wird gemessen und
         * mitgeschrieben, nicht entschieden. */
        stoerAnteil: (a.stoerung && a.stoerung.anteil != null) ? Math.round(a.stoerung.anteil * 100) / 100 : null,
        stoerSek: (a.stoerung && a.stoerung.sekundenGestoert != null) ? a.stoerung.sekundenGestoert : null,
        stoerMass: (a.stoerung && a.stoerung.massstab) ? Math.round(a.stoerung.massstab * 10) / 10 : null,
        sekunden: a.sekunden || null,
        ts: frame.ts,
      };
    } catch (_) { /* eine EKG-Analyse darf die Datenaufnahme nie stoppen */ }
  }
  return { frame, warnings };
}

/*
 * patientKey(frame) — Schluessel fuer die Patienten-Zuordnung (§6).
 * 1) Patienten-ID vom Geraet (bevorzugt), sonst
 * 2) Tierart + gerundetes Gewicht (Bucket), sonst
 * 3) Geraet bleibt ungepaart (eigener Patient = deviceId).
 */
function patientKey(frame) {
  if (frame.patientId) return 'id:' + frame.patientId;
  if (frame.species && frame.weightKg) {
    return 'sw:' + frame.species + ':' + roundWeightBucket(frame.weightKg);
  }
  return 'dev:' + frame.deviceId;
}

function roundWeightBucket(w) {
  // Tolerante Buckets: kleine Tiere fein, grosse grob (Gewicht schwankt am Monitor).
  if (w < 1) return Math.round(w * 10) / 10;      // 0.1 kg Schritte
  if (w < 10) return Math.round(w * 2) / 2;       // 0.5 kg Schritte
  return Math.round(w);                            // 1 kg Schritte
}

module.exports = {
  SPECIES, EKG_RHYTHMS, CAPNO_SHAPES, PLETH_SHAPES, DEVICE_ROLES, STATUS, MSG, VENT_FELDER,
  isSpecies, num, clamp, emptyVitals, normalizeFrame, patientKey, roundWeightBucket,
};
