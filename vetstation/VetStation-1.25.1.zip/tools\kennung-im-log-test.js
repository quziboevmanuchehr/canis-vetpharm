'use strict';
/* =============================================================================================
 * kennung-im-log-test.js — die Aktennummer verlaesst den Praxis-PC nicht (25.08.2026)
 * =============================================================================================
 *
 * WAS WAR: tools/befund-export.js schreibt am Ende woertlich "Patienten-Kennungen sind
 * unkenntlich gemacht" — und hing in Abschnitt 8 die letzten 40 Diagnosemeldungen ROH an.
 * Darin stand (echtes Beispiel aus data\diag.log.1 dieses Rechners):
 *
 *     protokoll: Gegeben: Atropin (0.084-0.168 mg = 0.168-0.336 mL IV/IM/SC) - Patient C-077
 *
 * Aktennummer, Wirkstoff und Dosis im Klartext — in genau der Datei, die dem Tierarzt mit
 * "Diese Datei weitergeben" in die Hand gedrueckt wird. Die Zusage war falsch, und sie war es
 * seit es sie gibt: anonym() wurde nur in Abschnitt 6 angewandt (:142, :147), nicht in :173.
 *
 * WIE ES BEHOBEN IST: die Kennung steht nicht mehr im Meldungstext, sondern in einem eigenen,
 * nicht-enumerierbaren Feld des Ereignisses. Die DATEI data/diag.log haengt sie lesbar an
 * (sie bleibt auf dem Praxis-PC, dort ist "welcher Patient" die richtige Frage); jeder AUSGANG
 * ersetzt sie durch ein stabiles Kuerzel #abc123.
 *
 * WARUM DIESER TEST: es gibt DREI Ausgaenge (WebSocket-Sink, recent() fuer /api/diag, und der
 * Erstversand an einen neu verbundenen Browser). Sie sehen im Code nicht gleich aus, und wer
 * einen vierten anbaut, denkt an die Maskierung nicht. Ausserdem faellt ein Rueckfall STILL
 * aus: die Datei sieht unveraendert aus, kein Fenster bleibt leer, nichts wird rot.
 * ============================================================================================= */

const fs = require('fs');
const path = require('path');
const WURZEL = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function ohneKommentar(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/^[ \t]*\/\/.*$/gm, ' ');
}

console.log('Die Aktennummer verlaesst den Praxis-PC nicht — Selbsttest\n');

/* =============================================================================================
 * 1) DER LOGGER — echt ausgefuehrt
 * ============================================================================================= */
console.log('1) Beide Ausgaenge des Loggers');
const logger = require(path.join(WURZEL, 'bridge', 'src', 'logger.js'));
logger._reset();
const sink = [];
logger.setSink((ev) => sink.push(ev));

logger.patient('protokoll', 'Gegeben: Atropin (0,04 mg/kg IV)', 'C-077');
logger.patient('protokoll', 'Gegeben: Propofol (4 mg/kg IV)', 'C-077');
logger.patient('protokoll', 'Gegeben: Atropin (0,04 mg/kg IV)', 'K-210');
logger.info('netz', 'Monitor 192.168.0.50 antwortet');

const alleTexte = JSON.stringify(sink) + JSON.stringify(logger.recent(20));
ok('der Sink (WebSocket an die Oberflaeche) traegt die Kennung NICHT',
  !/C-077|K-210/.test(JSON.stringify(sink)));
ok('recent() (das liest /api/diag und der Befundbericht) ebenfalls nicht',
  !/C-077|K-210/.test(JSON.stringify(logger.recent(20))));
ok('… und auch sonst steht sie in keinem Ausgang', !/C-077|K-210/.test(alleTexte));

const kuerzel = logger.recent(20).map((e) => {
  const m = /#([0-9a-f]{6})/.exec(e.msg); return m ? m[1] : null;
}).filter(Boolean);
ok('drei Meldungen tragen ein Kuerzel', kuerzel.length === 3, 'gefunden: ' + kuerzel.length);
ok('derselbe Patient ergibt dasselbe Kuerzel', kuerzel[0] === kuerzel[1],
  'sonst laesst sich im Bericht nicht mehr sehen, dass es dasselbe Tier war');
ok('ein anderer Patient ein anderes', kuerzel[2] !== kuerzel[0]);
ok('eine Meldung ohne Patient bekommt keins angehaengt',
  !/Patient/.test(String(logger.recent(1)[0].msg)),
  'sonst stuende an jeder Netzmeldung ein erfundener Patientenbezug');

/* Das Kuerzel darf nicht zurueckrechenbar sein, indem man kurze Kennungen durchprobiert —
 * deshalb ist es gesalzen. Ohne Salz waere es eine blosse Umbenennung. */
ok('das Kuerzel ist gesalzen (nicht der nackte Hash der Kennung)', (() => {
  const nackt = require('crypto').createHash('sha256').update('C-077').digest('hex').slice(0, 6);
  return logger._kuerzel('C-077') !== '#' + nackt;
})(), 'sonst genuegt eine Liste der ueblichen Aktennummern');

/* =============================================================================================
 * 2) DIE QUELLE — niemand schreibt die Kennung mehr in den Text
 * ============================================================================================= */
console.log('\n2) Die Quelle in server.js');
const srv = ohneKommentar(fs.readFileSync(path.join(WURZEL, 'bridge', 'src', 'server.js'), 'utf8'));
ok('die Gabe meldet ueber logger.patient()', /logger\.patient\('protokoll'/.test(srv));
ok('… und nicht mehr ueber logger.info mit der Kennung im Text',
  !/logger\.info\('protokoll'[\s\S]{0,300}patientId/.test(srv));
/* Die allgemeine Fassung: keine logger-Meldung darf patientId/patientKey in ihren Text
 * einbauen. Das ist die Regel, nicht der eine Fall — wer die naechste Meldung schreibt,
 * faellt hier auf, nicht erst im Befundbericht eines Tierarztes. */
const verdaechtig = (srv.match(/logger\.(info|warn|error)\([^;]{0,400};/g) || [])
  .filter((s) => /patientId|patientKey|\bpid\b/.test(s));
ok('KEINE logger.info/warn/error baut eine Patientenkennung in ihren Text',
  verdaechtig.length === 0,
  verdaechtig.length + ' Stelle(n): ' + verdaechtig.map((s) => s.slice(0, 70)).join(' || '));

/* =============================================================================================
 * 3) DER BEFUNDBERICHT — die Zusage muss stimmen
 * ============================================================================================= */
console.log('\n3) Der Befundbericht');
const exp = fs.readFileSync(path.join(WURZEL, 'tools', 'befund-export.js'), 'utf8');
ok('die alte, falsche Zusage steht nicht mehr da',
  !/Patienten-Kennungen sind unkenntlich gemacht/.test(ohneKommentar(exp)),
  'sie war falsch, solange Abschnitt 8 die Meldungen roh anhaengte');
ok('die neue Zusage nennt das Kuerzel', /abgeleitetes Kuerzel/.test(exp));
/* Eine Zusage, die nur das Gute nennt, ist wieder dieselbe Falle. */
ok('… und sie nennt auch, was SEHR WOHL enthalten ist',
  /ENTHALTEN sind dagegen/.test(exp) && /IP- und MAC-Adressen/.test(exp));
/* GEGEN DEN CODE, NICHT GEGEN DEN KOMMENTAR. Der erste Entwurf pruefte `exp` roh — und der
 * Begruendungsblock ueber Abschnitt 9 nennt beide Dateinamen. Die Gegenprobe schnitt darauf
 * den ganzen Abschnitt heraus und der Test blieb gruen: er las den Kommentar, der beschrieb,
 * was der geloeschte Code getan haette. Genau die Falle aus CLAUDE.md. */
const expCode = ohneKommentar(exp);
ok('Abschnitt 9 nimmt watchdog.log und update.log mit',
  /watchdog\.log/.test(expCode) && /update\.log/.test(expCode)
  && /SELBSTNEUSTARTS UND UPDATES/.test(expCode),
  'dort steht, ob die Station abgestuerzt ist oder ein Update dauernd scheitert');
ok('… und liest sie wirklich, statt sie nur zu nennen',
  /readFileSync\(p, 'utf8'\)\.split/.test(expCode));

/* =============================================================================================
 * 4) DER DECKEL AUF update.log
 * ============================================================================================= */
console.log('\n4) Kein Log waechst mehr unbegrenzt');
const kiosk = fs.readFileSync(path.join(WURZEL, 'kiosk', 'launch-kiosk.ps1'), 'utf8');
ok('update.log wird gekappt', /update\.log[\s\S]{0,600}524288/.test(kiosk)
  || /\$f = Join-Path \$d 'update\.log'[\s\S]{0,400}524288/.test(kiosk),
  'ein volles Laufwerk heisst: das Narkoseprotokoll laesst sich nicht mehr speichern');
ok('… mit derselben Grenze wie der Watchdog', (() => {
  const w = fs.readFileSync(path.join(WURZEL, 'kiosk', 'watchdog.ps1'), 'utf8');
  return /524288/.test(w) && /524288/.test(kiosk);
})());
/* Die Projektregel: .ps1 muss reines ASCII sein. Ein Gedankenstrich hat hier schon einmal
 * die ganze Testreihe gekippt. */
ok('launch-kiosk.ps1 ist weiterhin reines ASCII', (() => {
  const b = fs.readFileSync(path.join(WURZEL, 'kiosk', 'launch-kiosk.ps1'));
  for (let i = 0; i < b.length; i++) if (b[i] > 127) return false;
  return true;
})());

console.log('\n---------------------------------------------');
console.log('  bestanden: ' + pass + '   fehlgeschlagen: ' + fail);
if (fail) process.exit(1);
console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
