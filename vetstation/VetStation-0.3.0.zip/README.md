# VetStation — Narkose-Zentralstation (Windows-Kiosk)

Eine **IDEXX-artige Narkose-Zentralstation**: erkennt mehrere Narkose-Monitore/Narkosegeräte über LAN,
ordnet Monitor + Kapnograf (+ Narkose) per Patienten-ID demselben Patienten zu, überwacht **mehrere
Patienten in getrennten Fenstern**, erkennt Narkosezwischenfälle (EKG, Atmung/Kapno, Kreislauf) in
Echtzeit und nennt sofort **Injektion (mL) + optimale Geräteeinstellung** zur Stabilisierung —
**read-only, mehrere Tierarten, Windows 10/11**.

> Die komplette **klinische Logik und das Design** stammen aus der bestehenden Web-App
> (canis-vetpharm / canis-anaesthesie) und werden **wiederverwendet, nicht neu erfunden**. Nur die
> Datenquelle wechselt von manueller Eingabe auf **Live**.

⚠️ **Entscheidungs-/Trainingshilfe — kein zugelassener Patientenmonitor-Ersatz.** Nur anzeigen &
empfehlen; der Tierarzt entscheidet und handelt. Die App sendet **niemals** Befehle an Geräte.

---

## Schnellstart (Entwicklung/Test, ohne Geräte)

Voraussetzung: **Node.js 18+** (hier v24 vorhanden). Keine weiteren Abhängigkeiten (`npm install` nicht nötig).

```bash
cd D:\VetStation
node bridge/src/index.js        # startet Bridge + UI auf http://127.0.0.1:8770
```
Dann Browser auf **http://127.0.0.1:8770** öffnen. Der **Simulator** liefert zwei Patienten
(Hund 22 kg + Katze 4.2 kg, je Monitor + Kapno). Über das Dropdown „Szenario (Test)" pro Patient
Zwischenfälle schalten (Bradykardie/tief, MAP 50, VES+SpO₂↓, Apnoe, Bronchospasmus, Kammerflimmern …).

**Klinik-Selbsttest (headless):**
```bash
node tools/smoke-test.js        # 17 Prüfungen: Brain-Regeln + mL-Dosen je Tierart
```

**Kiosk (Appliance) starten:**
```powershell
powershell -ExecutionPolicy Bypass -File kiosk\launch-kiosk.ps1
```
→ startet die Bridge und öffnet **Edge (WebView2) im Vollbild-Kiosk**. Autostart/Watchdog:
`kiosk\install-autostart.ps1`, Details in [kiosk/assigned-access.md](kiosk/assigned-access.md).

---

## 🔌 Geräte anschließen & Verbindung testen (uMEC12 Vet · Veta 5 Plus · LifeVet 10C)

**Aufbau:** PC + Monitor + Narkosegerät in **denselben** Gigabit-Switch (eigenes, isoliertes Netz),
gleicher IP-Bereich (z. B. PC `192.168.2.10`, Monitor `192.168.2.20`).

**Verbindung prüfen — sagt im Klartext, was klappt und was fehlt:**
```bash
node tools/geraete-check.js                 # sucht Geräte automatisch (ARP) + Lauschphase
node tools/geraete-check.js 192.168.2.20    # eine Geräte-IP direkt prüfen
```
Der Check zeigt deine **PC-IP** (= „Serveradresse" am Gerät), findet Mindray-Geräte per MAC,
testet Ping + Datenports (4601/5000/24105/2575), macht einen **HL7-Handshake** und meldet
`✓ HL7 ERKANNT [HR=… SpO2=… …]` — oder nennt die genaue Ursache + nächsten Schritt. **Nur lesen.**

**Am Gerät die Datenausgabe aktivieren** (uMEC12 / LifeVet): Wartung → Benutzer-Wartung
(Passwort `888888`) → Netzwerk → EMR-Kommunikation → Server-IP = PC-IP, Port 4601, Protokoll HL7,
„Real Data Send" EIN. (Veta 5 Plus hat keinen offenen Datenausgang → Kapno-Werte kommen über den
Monitor bzw. via BeneLink.) Details: [docs/MINDRAY-HL7.md](docs/MINDRAY-HL7.md), [docs/LAN-SETUP.md](docs/LAN-SETUP.md).

**Ohne echte Geräte prüfen (Selbsttest der ganzen Kette):**
```bash
node tools/drei-geraete-test.js    # simuliert alle 3 Gerätetypen (echtes HL7) durch den Adapter-Code
```

---

## 💿 Installieren & Aktualisieren (andere PCs)

**Erstinstallation auf einem neuen PC (Win10/11):**
`dist\VetStation-Setup.exe` (~19 MB, enthält portables Node — Ziel-PC braucht **nichts** extra)
auf USB-Stick/Netzlaufwerk kopieren → **doppelklicken** → fertig (Start-Menü + Autostart).

**Späteres Update — ein Klick, ohne USB:**
In der Station **Admin ▸ 🔄 Aktualisieren** → „Update laden & anwenden". Die Station lädt das
Paket, prüft die **sha256-Prüfsumme**, legt es bereit und wendet es beim **nächsten Start** an
(`launch-kiosk.ps1` → `Apply-StagedUpdate`; Konfiguration `devices.json` + `data\` bleiben erhalten).

**Neues Release veröffentlichen (Entwickler-PC):**
```powershell
# 1) Version hochzählen in updater\version.json  ("app": "0.3.0")
powershell -ExecutionPolicy Bypass -File installer\make-dist.ps1          # 2) Paket + portables Node
& "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe" installer\vetstation-setup.iss   # 3) Setup.exe
# 4) Update-Zip (App-Dateien OHNE node\ und data\) + Prüfsumme:
Get-FileHash dist\VetStation-0.3.0.zip -Algorithm SHA256
```
Dann Zip nach `canis-vetpharm/vetstation/` legen und `vetstation-version.json` (Repo-Root)
auf die neue `app`-Version + `zipUrl` + `sha256` setzen → alle Stationen sehen das Update.

---

## 📡 Fern-Live — Monitor & Werte über das Internet ansehen

Der Praxis-PC kann die Live-Werte **und die Empfehlungen** zusätzlich ~1×/s ins Internet
schreiben, sodass sie in der öffentlichen Web-App **von zu Hause** angezeigt werden:
`…/canis-anaesthesie/?live=<code>`. Read-only, nur Vitalwerte/Tierart/Gewicht/Befund
(keine Personendaten), Zugriff nur mit dem Code.

- **Aktivieren:** `bridge/config/devices.json` → `cloud`-Block auf `enabled:true` + Firebase-Daten.
  Vollständige Anleitung: **[docs/FERN-LIVE.md](docs/FERN-LIVE.md)**, Regeln: [installer/firebase-rtdb-rules.json](installer/firebase-rtdb-rules.json).
- **Link kopieren:** im Kiosk unter **Admin → 📡 Fern-Live**.
- **Testen ohne Firebase:** Viewer offline `…/canis-anaesthesie/?livedemo=1`; Publisher
  `npm run test:cloud` (bzw. `node tools/cloud-test.js` + `node tools/cloud-integration-test.js`).

---

## Was v1 kann (live verifiziert)
- **Auto-Discovery** mehrerer Geräte (Modell + Rolle + Status active/standby/offline).
- **Patienten-Zuordnung**: Monitor + Kapno mit gleicher Patienten-ID → ein Datensatz zusammengeführt
  (sonst Tierart+Gewicht; manuelles Koppeln als Fallback).
- **Mehrere Tierarten**: Hund, Katze, Kaninchen, Meerschwein, Chinchilla, Degu, Frettchen, Reptil —
  mit artspezifischen Normwerten, Dosen (mg/kg → mL) und Geräteeinstellungen.
- **Live-Monitorbild** pro Patient (EKG/Pleth/Kapno-Kurven, große Vitalzahlen HF/SpO₂/EtCO₂/NIBP/AF/Temp),
  lokal synthetisiert aus Vitalwerten (sehr RAM-schonend).
- **„Brain"-Kreuz-Analyse** live: priorisierte Zwischenfälle mit (1) Sofortmaßnahme,
  (2) Geräte-Korrektur („Iso von X auf Soll Y senken"), (3) **Injektion mit fertiger mL-Menge**.
- **Zwei-Fenster-/Split-View** mit „gefährlichste Warnung nach oben".
- **Geräte-Soll-Vergleich** (Iso/O₂/System/APL) mit ⚠-Abweichung.
- **Admin-Bereich (PIN)**: Verbesserungsvorschläge, Verbindungs-/Fehler-Log, Feedback (hilfreich/nicht
  passend), fehlende Inhalte, anonymisierter **Ein-Klick-Export** (§14).
- **Klinische Daten aktualisieren sich zur Laufzeit** vom Live-canis-vetpharm (Pull + lokaler Fallback).

## Noch offen (dokumentiert)
- **Echte Geräte-Adapter** (Mindray uMEC12 Vet / Veta 5 Plus, Eickemeyer LifeVet 10C): **Gerüst vorhanden**,
  Parser **blockiert bis zum Protokoll** von Eickemeyer/Mindray → siehe [docs/DEVICE-ADAPTERS.md](docs/DEVICE-ADAPTERS.md).
  Bis dahin decken **Simulator** und **Playback** (VitalRecorder/VSCapture) den Test ab.
- **Tauri-MSI + signiertes Auto-Update**: Gerüst in [tauri-shell/](tauri-shell/README.md) (benötigt Rust-Toolchain).

---

## Projektstruktur
```
bridge/        Schicht 1: Acquisition-Bridge (Node, read-only) — WebSocket + Geräte-Adapter
  src/wsserver.js        abhängigkeitsfreier WebSocket-Server (RFC 6455)
  src/model.js           normalisiertes Frame-/ingest-Modell (§5)
  src/registry.js        Auto-Discovery + Status + Steuerung
  src/matching.js        Patienten-Zusammenführung (§6)
  src/adapters/          simulator, playback, mindray (STUB), lifevet (STUB)
ui/            Schicht 2/3: Kiosk-UI (reused Engine + Design)
  index.html, app.js     Zentralstation, Split-View, Live-Feed
  engine/                dose, device-target, brain (R1..R6), waveforms  ← wiederverwendete Web-Logik
  views/admin.js         Admin-/Selbstdiagnose (§14)
  vendor/                lokale Kopien (glass.css, vetpharm-ui.js, anaes-data.js) als Offline-Fallback
kiosk/         Appliance: launch/watchdog/autostart (Edge-WebView2-Kiosk)
tauri-shell/   Produktions-Packaging (MSI + Auto-Update) — Gerüst, benötigt Rust
updater/       App-Update-Kanal (klinische Daten laufen automatisch)
tools/         smoke-test.js (Klinik-Selbsttest)
docs/          Architektur, Geräte-Adapter, Kiosk-Setup, QA, Roadmap
```

## Sicherheit / Recht (§10, nicht verhandelbar)
- **Strikt read-only** — es werden nie Befehle an Geräte gesendet.
- **Isoliertes Geräte-Netz** (eigener Switch), Patientendaten bleiben **lokal** auf dem PC.
- Als **Trainings-/Entscheidungshilfe** gekennzeichnet, kein zugelassener Monitor-Ersatz.

Siehe [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) für die 3-Schichten-Architektur und die Wiederverwendungs-Strategie.
