'use strict';
/*
 * drei-geraete-test.js — ECHTE Praxis-Konstellation end-to-end pruefen:
 *   1) Mindray uMEC12 Vet      (Monitor)              — PC verbindet sich zum Geraet (PDS-Client, QRY^R02)
 *   2) Mindray Veta 5 Plus     (Narkose + Kapnograph) — Geraet pusht zum PC (Listener, "Serveradresse=PC-IP")
 *   3) Eickemeyer LifeVet 10C  (Monitor + Kapno)      — PC verbindet sich zum Geraet (PDS-Client)
 *
 * Die Mock-Geraete sprechen ECHTES HL7 v2.3.1 ueber MLLP mit den realen Mindray-OBX-Codes.
 * Geprueft wird die KOMPLETTE Kette: Adapter -> ingest-Modell -> Registry/Auto-Discovery ->
 * Patienten-Zusammenfuehrung (uMEC12+Veta = EIN Patient) -> Brain (Befund + mL).
 *
 * Beweist, dass die Software mit allen 3 Geraetetypen umgehen kann. Ob das ECHTE Geraet HL7
 * sendet, haengt an Firmware/Freischaltung -> dafuer: node tools/geraete-check.js (in der Praxis).
 *
 * Start: node tools/drei-geraete-test.js
 */
const net = require('net');
const { Registry } = require('../bridge/src/registry');
const { HL7Adapter } = require('../bridge/src/adapters/hl7');
const brain = require('../ui/engine/brain');
const dose = require('../ui/engine/dose');
const A = require('../bridge/src/anaes').loadAnaes();

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }
function mllp(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }

// --- Echte Mindray-OBX-Codes (PDS-Spezifikation) ---
function oru(sendingApp, patientId, obx) {
  return 'MSH|^~\\&|' + sendingApp + '|||||20260720120000||ORU^R01|1|P|2.3.1\r' +
    'PID|||' + patientId + '\r' +
    'OBR|1||||' + sendingApp + '\r' + obx.join('\r');
}
const UMEC_OBX = ['OBX|1|NM|101^HR||92', 'OBX|2|NM|160^SpO2||96', 'OBX|3|NM|170^NIBP-SYS||104',
  'OBX|4|NM|171^NIBP-DIA||62', 'OBX|5|NM|200^T1||37.9'];
const VETA_OBX = ['OBX|1|NM|220^CO2||58', 'OBX|2|NM|221^InsCO2||8', 'OBX|3|NM|222^AWRR||9'];
const LIFEVET_OBX = ['OBX|1|NM|101^HR||150', 'OBX|2|NM|160^SpO2||98', 'OBX|3|NM|220^CO2||41',
  'OBX|4|NM|221^InsCO2||1', 'OBX|5|NM|222^AWRR||18', 'OBX|6|NM|170^NIBP-SYS||122', 'OBX|7|NM|171^NIBP-DIA||80'];

// Mock-Geraet als SERVER (PDS): wartet auf QRY vom PC und antwortet mit ORU (wie uMEC12/LifeVet).
function mockPdsServer(app, patientId, obx) {
  return new Promise((resolve) => {
    const srv = net.createServer((sock) => {
      sock.on('error', () => {});   // Verbindungsabbruch beim Testende ignorieren
      sock.on('data', () => { try { sock.write(mllp(oru(app, patientId, obx))); } catch (_) {} });
      setTimeout(() => { if (!sock.destroyed) { try { sock.write(mllp(oru(app, patientId, obx))); } catch (_) {} } }, 120);
    });
    srv.on('error', () => {});
    srv.listen(0, '127.0.0.1', () => resolve({ srv, port: srv.address().port }));
  });
}
// Mock-Geraet als CLIENT: verbindet sich zum PC und PUSHT ORU (wie "Send HL7 -> Serveradresse=PC-IP").
function mockPushDevice(port, app, patientId, obx) {
  const sock = net.connect(port, '127.0.0.1', () => {
    const send = () => { try { sock.write(mllp(oru(app, patientId, obx))); } catch (_) {} };
    send(); sock._t = setInterval(send, 400);
  });
  sock.on('error', () => {});
  return sock;
}

async function run() {
  console.log('VetStation — Praxis-Konstellation: uMEC12 Vet + Veta 5 Plus + LifeVet 10C\n');
  const logger = { info() {}, warn() {}, error() {} };
  const registry = new Registry({ log: logger });
  const ctx = { emit: (raw) => registry.ingest(raw), log: logger };

  // --- Geraet 1 + 3: PDS-Server (PC verbindet sich hin) ---
  const umec = await mockPdsServer('uMEC12 Vet', 'OP-1', UMEC_OBX);
  const lifevet = await mockPdsServer('LifeVet 10C', 'OP-2', LIFEVET_OBX);
  // --- Geraet 2: pusht zum PC (Listener-Port) ---
  const VETA_LISTEN = 45601;

  const aUmec = new HL7Adapter({ id: 'umec12', mode: 'client', host: '127.0.0.1', port: umec.port,
    model: 'uMEC12 Vet', role: 'monitor', species: 'hund', weightKg: 10, ack: false }, ctx);
  const aVeta = new HL7Adapter({ id: 'veta5', mode: 'listener', listenPort: VETA_LISTEN,
    model: 'Veta 5 Plus', role: 'anesthesia', species: 'hund', weightKg: 10, patientId: 'OP-1' }, ctx);
  const aLife = new HL7Adapter({ id: 'lifevet', mode: 'client', host: '127.0.0.1', port: lifevet.port,
    model: 'LifeVet 10C', role: 'combo', species: 'katze', weightKg: 4.2, ack: false }, ctx);

  registry.addAdapter(aUmec); registry.addAdapter(aVeta); registry.addAdapter(aLife);
  await registry.start();
  await wait(300);
  const push = mockPushDevice(VETA_LISTEN, 'Veta 5 Plus', 'OP-1', VETA_OBX);
  await wait(1200);

  // ---------- 1) Auto-Discovery: alle 3 Geraete erkannt ----------
  console.log('1) Auto-Discovery (§6.1) — werden alle 3 Geraete erkannt?');
  const devs = registry.getDevices();
  ok('3 Geraete erkannt', devs.length === 3, 'gefunden=' + devs.length + ' [' + devs.map((d) => d.model).join(', ') + ']');
  const byModel = {}; devs.forEach((d) => { byModel[d.model] = d; });
  ok('uMEC12 Vet erkannt, Rolle Monitor, aktiv', !!byModel['uMEC12 Vet'] && byModel['uMEC12 Vet'].role === 'monitor' && byModel['uMEC12 Vet'].status === 'active');
  ok('Veta 5 Plus erkannt, Rolle Narkose/Kapno, aktiv', !!byModel['Veta 5 Plus'] && byModel['Veta 5 Plus'].role === 'anesthesia' && byModel['Veta 5 Plus'].status === 'active');
  ok('LifeVet 10C erkannt, Rolle Kombi, aktiv', !!byModel['LifeVet 10C'] && byModel['LifeVet 10C'].role === 'combo' && byModel['LifeVet 10C'].status === 'active');

  // ---------- 2) Werte korrekt geparst (echte OBX-Codes) ----------
  console.log('\n2) Werte aus echtem HL7 geparst (Mindray-OBX-Codes)');
  const pats = registry.getPatients();
  const p1 = pats.find((p) => p.patientId === 'OP-1');
  const p2 = pats.find((p) => p.patientId === 'OP-2');
  ok('Patient OP-1 vorhanden (uMEC12 + Veta)', !!p1);
  ok('Patient OP-2 vorhanden (LifeVet)', !!p2);
  if (p1) {
    ok('uMEC12: HF 92 (OBX 101)', p1.vitals.hr === 92, 'hr=' + p1.vitals.hr);
    ok('uMEC12: SpO2 96 (OBX 160)', p1.vitals.spo2 === 96, 'spo2=' + p1.vitals.spo2);
    ok('uMEC12: NIBP 104/62 + MAP berechnet', p1.vitals.sys === 104 && p1.vitals.dia === 62 && p1.vitals.map === 76, p1.vitals.sys + '/' + p1.vitals.dia + ' MAP=' + p1.vitals.map);
    ok('uMEC12: Temp 37.9 (OBX 200)', p1.vitals.temp === 37.9, 'temp=' + p1.vitals.temp);
    ok('Veta: EtCO2 58 (OBX 220)', p1.vitals.etco2 === 58, 'etco2=' + p1.vitals.etco2);
    ok('Veta: FiCO2 8 (OBX 221)', p1.vitals.fico2 === 8, 'fico2=' + p1.vitals.fico2);
    ok('Veta: AF 9 (OBX 222)', p1.vitals.af === 9, 'af=' + p1.vitals.af);
  }

  // ---------- 3) Patienten-Zusammenfuehrung (Kernanforderung §6) ----------
  console.log('\n3) Zusammenfuehrung: Monitor + Narkosegeraet = EIN Patient');
  ok('genau 2 Patienten (nicht 3 Einzelgeraete)', pats.length === 2, 'patients=' + pats.length);
  if (p1) {
    ok('OP-1 vereint 2 Geraete (uMEC12 + Veta)', p1.devices.length === 2, 'devices=' + p1.devices.length);
    ok('OP-1 hat Kreislauf (Monitor) UND Atmung (Kapno) zusammen', p1.vitals.hr != null && p1.vitals.etco2 != null);
  }
  if (p2) ok('OP-2 (LifeVet) getrennt, mit eigenen Werten', p2.devices.length === 1 && p2.vitals.hr === 150 && p2.vitals.etco2 === 41);

  // ---------- 4) Rueckatmung aus FiCO2 abgeleitet (echte Geraete liefern keine Kurvenform) ----------
  console.log('\n4) Kapno-Auswertung aus Messwerten');
  if (p1) ok('FiCO2 8 mmHg -> Rueckatmung erkannt (capnoShape=baseline)', p1.vitals.capnoShape === 'baseline', 'capnoShape=' + p1.vitals.capnoShape);
  if (p2) ok('FiCO2 1 mmHg -> keine Rueckatmung', p2.vitals.capnoShape == null, 'capnoShape=' + p2.vitals.capnoShape);

  // ---------- 5) Brain + Dosis auf den LIVE-Daten ----------
  console.log('\n5) Brain-Bewertung + Injektion (mL) aus den Live-Werten');
  if (p1) {
    const flat = Object.assign({ species: p1.species || 'hund', weightKg: p1.weightKg || 10 }, p1.vitals);
    const res = brain.assess(A, flat, {});
    ok('Brain bewertet OP-1 ohne Fehler', !!res && typeof res.priority === 'number');
    ok('EtCO2 58 + AF 9 -> Befund erkannt (Hypoventilation/Einzelwert)', res.priority > 0 || res.single.length > 0, 'pri=' + res.priority + ' single=' + res.single.length);
    const inj = dose.injectionsFor(A, 'bradykardie', p1.species || 'hund', p1.weightKg || 10).find((x) => x.id === 'atropin');
    ok('Injektion liefert mL fuer diesen Patienten', !!inj && inj.mlLo != null, inj && dose.fmtRange(inj.mlLo, inj.mlHi) + ' mL');
  }

  // ---------- 6) Read-only nachweisen ----------
  console.log('\n6) Sicherheit: strikt read-only');
  ok('Adapter besitzen keine Steuerfunktion (kein send/setzen an Geraete)',
    typeof aUmec.setVaporizer === 'undefined' && typeof aVeta.setVaporizer === 'undefined' && typeof aLife.write === 'undefined');

  // Aufraeumen
  try { clearInterval(push._t); push.destroy(); } catch (_) {}
  registry.dispose(); umec.srv.close(); lifevet.srv.close();
  await wait(150);

  console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
  process.exit(fail ? 1 : 0);
}

run().catch((e) => { console.error('TESTFEHLER:', e); process.exit(1); });
