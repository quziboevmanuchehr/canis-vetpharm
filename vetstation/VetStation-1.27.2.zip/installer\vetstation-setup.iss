; vetstation-setup.iss - Inno Setup Skript fuer einen echten Doppelklick-Installer VetStation-Setup.exe
; Voraussetzung: vorher `installer\make-dist.ps1` ausfuehren (erzeugt dist\VetStation inkl. portablem Node).
; Bauen: iscc installer\vetstation-setup.iss   (Inno Setup: https://jrsoftware.org/isinfo.php)

; ACHTUNG: AppVersion muss zur Wurzel-package.json passen - tools/version-test.js erzwingt das.
#define AppName "VetStation"
#define AppVersion "1.27.2"
#define AppPublisher "VetStation"
#define SrcDir "..\dist\VetStation"

[Setup]
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName=C:\VetStation
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputBaseFilename=VetStation-Setup
OutputDir=..\dist
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern

[Languages]
Name: "de"; MessagesFile: "compiler:Languages\German.isl"

[Files]
; ACHTUNG - data\ MUSS ausgeschlossen bleiben (Befund 18.08.2026).
; dist\VetStation ist auf dem Entwicklerrechner AUCH eine laufende Station. Sie legt dort
;   data\station-id.json  an - mit dem Feld "priv", dem PRIVATEN Schluessel dieser Station,
;   data\diag.log         mit dem Betriebsprotokoll.
; Ohne diesen Ausschluss traegt jedes Setup denselben privaten Schluessel und dieselbe
; Stationskennung auf jeden Praxis-PC - im Mehrsaal-Verbund erscheinen die Saele dann als
; ein und dieselbe Station. Auf dem ZIEL-PC ist data\ ohnehin der Ordner des Kunden und
; darf von einem Update nie ueberschrieben werden.
Source: "{#SrcDir}\*"; DestDir: "{app}"; Excludes: "data\*,*.log"; \
  Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
; ACHTUNG - VERBOTENE ZEICHEN IN VERKNUEPFUNGSNAMEN:
; Eine Verknuepfung wird als .lnk-DATEI gespeichert. In Windows-Dateinamen sind
;   \ / : * ? " < > |
; verboten. Der Name "2 Geraete pruefen (kommen Daten an?)" liess das Setup deshalb mit
;   IPersistFile::Save schlug fehl; Code 0x8007007B
; abbrechen - und zwar NACH dem Kopieren der Dateien, sodass eine halb eingerichtete Station
; zurueckblieb, die auf einem PC ein installiertes 0.6.x wieder auf 0.5.2 zurueckgesetzt hat.
; tools/paket-test.js prueft alle Namen hier gegen diese Zeichen.
Name: "{group}\VetStation starten"; Filename: "{app}\START-VetStation.bat"
Name: "{group}\1 Netzwerk einrichten (feste IP)"; Filename: "{app}\NETZWERK-EINRICHTEN.bat"
Name: "{group}\2 Geraete pruefen (kommen Daten an)"; Filename: "{app}\GERAETE-PRUEFEN.bat"
Name: "{group}\3 Firewall freigeben"; Filename: "{app}\FIREWALL-FREIGEBEN.bat"
Name: "{group}\4 VetStation neu starten"; Filename: "{app}\NEUSTART.bat"
Name: "{group}\5 Internet einrichten (nur fuer Update-Fern-Live)"; Filename: "{app}\INTERNET-EINRICHTEN.bat"
Name: "{group}\LAN-Anleitung"; Filename: "{app}\docs\LAN-SETUP.md"
Name: "{commondesktop}\VetStation"; Filename: "{app}\START-VetStation.bat"; Tasks: desktopicon
Name: "{commondesktop}\VetStation - Netzwerk einrichten"; Filename: "{app}\NETZWERK-EINRICHTEN.bat"; Tasks: desktopicon
Name: "{commondesktop}\VetStation - Geraete pruefen"; Filename: "{app}\GERAETE-PRUEFEN.bat"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Desktop-Verknuepfung"; Flags: unchecked
Name: "autostart"; Description: "Autostart-Kiosk beim Anmelden einrichten (empfohlen)"

[Run]
; Windows-Firewall fuer die Geraete-Ports oeffnen (SONST kommen keine Vitaldaten an - Windows
; verwirft sie LAUTLOS). Frueher standen hier fuenf einzelne "netsh add rule"-Zeilen OHNE
; vorheriges Loeschen; zusammen mit Install-VetStation.ps1 kam pro Neuinstallation ein weiterer
; Satz dazu - auf dem Praxis-PC standen so 10 statt 5 Regeln (Befund 1.3 / 2.5).
; Jetzt EINE gemeinsame, wiederholbare Stelle, die Altbestaende mit aufraeumt:
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\set-firewall.ps1"" -Leise"; \
  Flags: runhidden; StatusMsg: "Gebe die Geraete-Datenports in der Firewall frei..."
; USB-Treiber des EKG 2000 (Eickemeyer/Grimed) still vorinstallieren. Damit entfaellt am
; Praxis-PC das zweite Setup: EKG anstecken genuegt, Windows richtet es selbst ein. Das Skript
; ist idempotent und bricht die Installation nie ab (PrivilegesRequired=admin gilt hier bereits).
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\set-ekg-treiber.ps1"" -Root ""{app}"""; \
  Flags: runhidden; StatusMsg: "Installiere USB-Treiber fuer das EKG 2000..."
; Autostart-Kiosk + Watchdog registrieren
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\kiosk\install-autostart.ps1"" -Port 8770"; \
  Tasks: autostart; Flags: runhidden; StatusMsg: "Richte Autostart-Kiosk ein..."
; Direkt nach Installation einmal starten (optional)
Filename: "{app}\START-VetStation.bat"; Description: "VetStation jetzt starten"; Flags: postinstall shellexec skipifsilent

[UninstallRun]
; Station beenden, BEVOR Dateien entfernt werden.
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\kiosk\stop-kiosk.ps1"""; Flags: runhidden; RunOnceId: "StopStation"
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\kiosk\install-autostart.ps1"" -Remove"; Flags: runhidden; RunOnceId: "RemoveAutostart"
; Firewall-Regeln wieder entfernen (dieselbe gemeinsame Stelle, damit nichts uebrig bleibt)
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\set-firewall.ps1"" -Entfernen -Leise"; Flags: runhidden; RunOnceId: "FwRemove"

[Code]
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Rc: Integer;
  Skript: String;
begin
  Result := '';
  { Bei einer Erstinstallation gibt es nichts anzuhalten - dann fehlt das Skript. }
  Skript := ExpandConstant('{app}\kiosk\stop-kiosk.ps1');
  if FileExists(Skript) then
  begin
    Exec('powershell.exe',
      '-NoProfile -ExecutionPolicy Bypass -File "' + Skript + '"',
      '', SW_HIDE, ewWaitUntilTerminated, Rc);
    { Der Rueckgabewert wird bewusst NICHT geprueft: laeuft die Station gar nicht, meldet
      das Skript einen Fehler, und ein Abbruch hier waere schlimmer als der Weiterlauf.
      Kurz warten, damit Windows die Dateihandles wirklich freigibt. }
    Sleep(2500);
  end;
end;
