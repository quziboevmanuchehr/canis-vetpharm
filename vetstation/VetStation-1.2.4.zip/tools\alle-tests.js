'use strict';
/*
 * alle-tests.js — faehrt ALLE Selbsttests der Reihe nach und fasst sie zusammen.
 *
 * Warum als eigenes Programm statt einer langen npm-Zeile:
 *   • Auf dem PRAXIS-PC gibt es KEIN npm — nur node\node.exe. `npm test` ist dort nicht
 *     ausfuehrbar, dieses Programm schon:  node\node.exe tools\alle-tests.js
 *   • Mehrere Tests belegen TCP-Ports. Sie muessen NACHEINANDER laufen, sonst behindern sie
 *     sich gegenseitig und melden Fehler, die keine sind.
 *   • Am Ende steht EINE Zeile, die man ohne Suchen lesen kann.
 *
 * Start: node tools/alle-tests.js      (oder npm test)
 */
const path = require('path');
const { spawnSync } = require('child_process');

const TESTS = [
  ['smoke-test.js', 'Grundfunktionen'],
  ['species-test.js', 'Tierarten/Dosen'],
  ['matching-test.js', 'Geraete->Patient zusammenfuehren'],
  ['priority-test.js', 'Prioritaet/Befunde'],
  ['version-test.js', 'EINE Quelle der Wahrheit fuer die Version'],
  ['netscan-test.js', 'Geraetesuche + Einstufung'],
  ['stationsid-test.js', 'Stationskennung (mehrere OP-Saele)'],
  ['doppelstart-test.js', 'zweiter Start derselben Station'],
  ['watchdog-test.js', 'Selbstheilung bei EINGEFRORENER Station'],
  ['diagnose-test.js', 'Klartext-Diagnose "wo liegt das Problem"'],
  ['geraetefund-test.js', 'Station folgt dem Geraet (statt toter IP)'],
  ['geraetekatalog-test.js', 'Geraetekatalog (Ports, MAC, Menuepfade)'],
  ['geraeteerkennung-test.js', 'Modellerkennung (schlaegt vor, raet nie)'],
  ['verbindungsberater-test.js', 'Verbindungsberater (Anleitung + Empfehlung)'],
  ['geraeteeinrichtung-test.js', 'Geraet einrichten, ohne Bestehendes zu schaedigen'],
  ['seriell-test.js', 'serieller Weg (RS-232/Geraeteserver, Sendesperre)'],
  ['surgivet-test.js', 'SurgiVet Advisor CSV (25 Spalten, Skalierung gemessen)'],
  ['medibus-test.js', 'Draeger MEDIBUS (Rahmen, Zeitregeln, Sendesperre)'],
  ['erstsuche-test.js', 'findet Geraete + Nachbar-PCs von selbst'],
  ['vollauslesung-test.js', 'Station liest ALLES vom Geraet'],
  ['ekg-analyse-test.js', 'EKG-Analyse (QRS, Rhythmus, ST)'],
  ['hl7-test.js', 'HL7 lesen'],
  ['temp-co2-test.js', 'Temperatur + CO2 (Kabel angeschlossen)'],
  ['umec12-nibp-test.js', 'uMEC12 Zahlen (HL7 Compatibility Ein)'],
  ['hl7-client-test.js', 'HL7-Client'],
  ['hl7-reconnect-test.js', 'kein Log-Fluten bei abwesendem Geraet'],
  ['probe-test.js', 'Verbindungs-Assistent'],
  ['check-haengt-nicht-test.js', 'Verbindungs-Check haengt nie'],
  ['ui-flacker-test.js', 'Oberflaeche flackert nicht'],
  ['port3502-test.js', 'Gateway-Port 3502'],
  ['vscapture-test.js', 'VSCapture-Fallback'],
  ['drei-geraete-test.js', 'drei Geraete gleichzeitig'],
  ['paket-test.js', 'Bedienbarkeit am Praxis-PC'],
  ['update-paket-test.js', 'ausgeliefertes Update-Paket'],
  ['cloud-test.js', 'Fern-Live'],
  ['cloud-integration-test.js', 'Fern-Live Ende zu Ende'],
  ['tafel-test.js', 'Saal-Tafel (Kacheln, Alterung, Modus)'],
  ['tafelabo-test.js', 'Tafel lesen (Nachbarsaele)'],
  ['fremdstore-test.js', 'Nachbarsaele zusammenfuehren (Alter, Quelle)'],
  ['nachbar-test.js', 'Nachbar-Port 8771 (Handschlag, Deckel)'],
  ['nachbarn-test.js', 'Kiosk-Band der Nachbarsaele'],
  ['saalname-test.js', 'Saalname + Stationskennung von Hand'],
  ['regeln-test.js', 'Sicherheitsregeln der Datenbank'],
  ['regeln-vertrag-test.js', 'Regeln gegen ECHTE Daten (Vertrag)'],
  ['firebase-regeln-test.js', 'Firebase-Datenbankregeln (Form + was die Station schreibt)'],
  // Laeuft hier mit der kurzen Vorgabe (8 s), damit die Suite zuegig bleibt; fuer eine
  // aussagekraeftige Messung von Hand mit "--sekunden 30" starten.
  // Schuetzt vor allem die Zusicherung "kein Kurvenstreifen geht doppelt ueber die Leitung".
  ['fern-durchsatz-test.js', 'Fern-Durchsatz (Werte + Kurven)'],
  ['veta5-mirror-test.js', 'Veta 5 Beatmungsmodus/-werte live spiegeln'],
  ['af-quelle-test.js', 'AF-Quelle: Kapnograph vor Monitor'],
  ['drug-context-test.js', 'Medikamenten-bewusste Beatmungsanalyse'],
  ['gaben-protokoll-test.js', 'NUR bestaetigte Gaben ins Protokoll + Rueckweg'],
  ['webapp-fern-test.js', 'Fern-Ansicht auf mehrere OP-Saele'],
  ['logumbruch-test.js', 'Diagnose-Log laeuft nicht voll'],
  ['dauerwache-test.js', 'Dauerwache: spaeter angestecktes Geraet wird gefunden'],
];

const nurEins = process.argv[2];
const liste = nurEins ? TESTS.filter((t) => t[0].indexOf(nurEins) >= 0) : TESTS;

console.log('\n===============================================================');
console.log('  VetStation - Selbsttests (' + liste.length + ' Dateien)');
console.log('===============================================================\n');

const gut = [], schlecht = [];
for (const [datei, was] of liste) {
  const p = path.join(__dirname, datei);
  process.stdout.write(('  ' + was).padEnd(52, '.') + ' ');
  const r = spawnSync(process.execPath, [p], { encoding: 'utf8' });
  const text = String(r.stdout || '') + String(r.stderr || '');
  if (r.status === 0) {
    const m = text.match(/ALLE (\d+) PRUEFUNGEN BESTANDEN/) || text.match(/(\d+) OK/);
    console.log('OK' + (m ? '  (' + m[1] + ')' : ''));
    gut.push(datei);
  } else {
    console.log('FEHLGESCHLAGEN');
    schlecht.push([datei, text]);
  }
}

if (schlecht.length) {
  console.log('\n---------------------------------------------------------------');
  console.log('  FEHLGESCHLAGEN - Ausgabe im Einzelnen:');
  console.log('---------------------------------------------------------------');
  schlecht.forEach(([datei, text]) => {
    console.log('\n### ' + datei + ' ###');
    // Nur die Fehlerzeilen und das Fazit zeigen - der Rest ist Rauschen.
    const zeilen = text.split('\n').filter((l) => /✗|FEHLGESCHLAGEN|FAIL|Error|Testfehler/.test(l));
    console.log(zeilen.length ? zeilen.join('\n') : text.slice(-1500));
  });
}

console.log('\n===============================================================');
if (schlecht.length) {
  console.log('  ERGEBNIS: ' + schlecht.length + ' von ' + liste.length + ' Testdateien FEHLGESCHLAGEN');
  console.log('  Es sollte KEIN Setup gebaut werden, solange das so ist.');
} else {
  console.log('  ERGEBNIS: alle ' + gut.length + ' Testdateien bestanden.');
}
console.log('===============================================================\n');
process.exit(schlecht.length ? 1 : 0);
