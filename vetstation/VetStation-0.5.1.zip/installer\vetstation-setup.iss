; vetstation-setup.iss — Inno Setup Skript fuer einen echten Doppelklick-Installer VetStation-Setup.exe
; Voraussetzung: vorher `installer\make-dist.ps1` ausfuehren (erzeugt dist\VetStation inkl. portablem Node).
; Bauen: iscc installer\vetstation-setup.iss   (Inno Setup: https://jrsoftware.org/isinfo.php)

#define AppName "VetStation"
#define AppVersion "0.5.1"
#define AppPublisher "VetStation"
#define SrcDir "..\dist\VetStation"

[Setup]
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName=C:\VetStation
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputBaseFilename=VetStation-Setup
OutputDir=..\dist
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern

[Languages]
Name: "de"; MessagesFile: "compiler:Languages\German.isl"

[Files]
Source: "{#SrcDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\VetStation starten"; Filename: "{app}\START-VetStation.bat"
; Doppelklick-Verknuepfungen statt getippter Befehle — ein relativer Pfad in PowerShell
; (Start in C:\Windows\System32) findet die Skripte sonst nicht.
Name: "{group}\1 Netzwerk einrichten (feste IP)"; Filename: "{app}\NETZWERK-EINRICHTEN.bat"
Name: "{group}\2 Geraete pruefen (kommen Daten an?)"; Filename: "{app}\GERAETE-PRUEFEN.bat"
Name: "{group}\LAN-Anleitung"; Filename: "{app}\docs\LAN-SETUP.md"
Name: "{commondesktop}\VetStation"; Filename: "{app}\START-VetStation.bat"; Tasks: desktopicon
Name: "{commondesktop}\VetStation — Netzwerk einrichten"; Filename: "{app}\NETZWERK-EINRICHTEN.bat"; Tasks: desktopicon
Name: "{commondesktop}\VetStation — Geraete pruefen"; Filename: "{app}\GERAETE-PRUEFEN.bat"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Desktop-Verknuepfung"; Flags: unchecked
Name: "autostart"; Description: "Autostart-Kiosk beim Anmelden einrichten (empfohlen)"

[Run]
; Windows-Firewall fuer die Geraete-Ports oeffnen (SONST kommen keine Vitaldaten an!)
; 3502 = Mindray Gateway-Kommunikation (uMEC12 Vet), 4601 = HL7/VSCapture, 5000/24105/2575 = weitere HL7-Ports.
Filename: "netsh.exe"; Parameters: "advfirewall firewall add rule name=""VetStation Geraetedaten TCP 3502"" dir=in action=allow protocol=TCP localport=3502"; \
  Flags: runhidden; StatusMsg: "Gebe Geraete-Port 3502 frei..."
Filename: "netsh.exe"; Parameters: "advfirewall firewall add rule name=""VetStation Geraetedaten TCP 4601"" dir=in action=allow protocol=TCP localport=4601"; \
  Flags: runhidden; StatusMsg: "Gebe Geraete-Port 4601 frei..."
Filename: "netsh.exe"; Parameters: "advfirewall firewall add rule name=""VetStation Geraetedaten TCP 5000"" dir=in action=allow protocol=TCP localport=5000"; \
  Flags: runhidden; StatusMsg: "Gebe Geraete-Port 5000 frei..."
Filename: "netsh.exe"; Parameters: "advfirewall firewall add rule name=""VetStation Geraetedaten TCP 24105"" dir=in action=allow protocol=TCP localport=24105"; \
  Flags: runhidden; StatusMsg: "Gebe Geraete-Port 24105 frei..."
Filename: "netsh.exe"; Parameters: "advfirewall firewall add rule name=""VetStation Geraetedaten TCP 2575"" dir=in action=allow protocol=TCP localport=2575"; \
  Flags: runhidden; StatusMsg: "Gebe Geraete-Port 2575 frei..."
; Autostart-Kiosk + Watchdog registrieren
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\kiosk\install-autostart.ps1"" -Port 8770"; \
  Tasks: autostart; Flags: runhidden; StatusMsg: "Richte Autostart-Kiosk ein..."
; Direkt nach Installation einmal starten (optional)
Filename: "{app}\START-VetStation.bat"; Description: "VetStation jetzt starten"; Flags: postinstall shellexec skipifsilent

[UninstallRun]
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\kiosk\install-autostart.ps1"" -Remove"; Flags: runhidden; RunOnceId: "RemoveAutostart"
; Firewall-Regeln wieder entfernen
Filename: "netsh.exe"; Parameters: "advfirewall firewall delete rule name=""VetStation Geraetedaten TCP 3502"""; Flags: runhidden; RunOnceId: "FwDel3502"
Filename: "netsh.exe"; Parameters: "advfirewall firewall delete rule name=""VetStation Geraetedaten TCP 4601"""; Flags: runhidden; RunOnceId: "FwDel4601"
Filename: "netsh.exe"; Parameters: "advfirewall firewall delete rule name=""VetStation Geraetedaten TCP 5000"""; Flags: runhidden; RunOnceId: "FwDel5000"
Filename: "netsh.exe"; Parameters: "advfirewall firewall delete rule name=""VetStation Geraetedaten TCP 24105"""; Flags: runhidden; RunOnceId: "FwDel24105"
Filename: "netsh.exe"; Parameters: "advfirewall firewall delete rule name=""VetStation Geraetedaten TCP 2575"""; Flags: runhidden; RunOnceId: "FwDel2575"
