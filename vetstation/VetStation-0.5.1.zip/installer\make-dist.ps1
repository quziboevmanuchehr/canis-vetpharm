<#
  make-dist.ps1 - Baut auf DIESEM (Entwickler-)PC ein fertiges, kopierbares Paket
  `dist\VetStation\`, das **portables Node** enthaelt, sodass auf dem Ziel-PC NICHTS extra
  installiert werden muss. Das Paket auf USB-Stick/Netz kopieren und dort `Install-VetStation.ps1`
  ausfuehren (oder `START-VetStation.bat` doppelklicken).

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\make-dist.ps1
  Optional: -NodeVersion 20.18.1   -OutDir <pfad>
#>
param(
  [string]$NodeVersion = '20.18.1',
  [string]$OutDir = "$PSScriptRoot\..\dist"
)
$ErrorActionPreference = 'Stop'
$Root  = Split-Path $PSScriptRoot -Parent
$Stage = Join-Path $OutDir 'VetStation'

Write-Host "== VetStation-Paket bauen =="

# Bereits heruntergeladenes portables Node retten, BEVOR der Stage-Ordner geloescht wird.
# Sonst steht das Paket ohne node.exe da, wenn der Download spaeter fehlschlaegt (offline).
$savedNode = $null
$oldNode = Join-Path $Stage 'node\node.exe'
if (Test-Path $oldNode) {
  $savedNode = Join-Path $env:TEMP 'vetstation-node-cache.exe'
  Copy-Item $oldNode $savedNode -Force
  Write-Host "Vorhandenes node.exe zwischengespeichert (Fallback bei Offline-Build)."
}

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Stage | Out-Null

# 1) App-Dateien kopieren (ohne .git, node_modules, data, dist)
Write-Host "Kopiere App-Dateien ..."
robocopy $Root $Stage /E /XD (Join-Path $Root '.git') (Join-Path $Root 'node_modules') (Join-Path $Root 'data') (Join-Path $Root 'dist') /XF '*.log' /NFL /NDL /NJH /NJS /NP | Out-Null

# 2) Portables Node holen und als node\node.exe ablegen
$nodeDir = Join-Path $Stage 'node'
New-Item -ItemType Directory -Force -Path $nodeDir | Out-Null
$zipName = "node-v$NodeVersion-win-x64"
$zipUrl  = "https://nodejs.org/dist/v$NodeVersion/$zipName.zip"
$zipPath = Join-Path $env:TEMP "$zipName.zip"
Write-Host "Lade portables Node $NodeVersion ..."
try {
  Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing
  $tmp = Join-Path $env:TEMP "vetstation-node"
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive -Path $zipPath -DestinationPath $tmp -Force
  Copy-Item (Join-Path $tmp "$zipName\node.exe") (Join-Path $nodeDir 'node.exe') -Force
  Write-Host "node.exe eingebettet."
} catch {
  Write-Warning "Node-Download fehlgeschlagen ($($_.Exception.Message))."
  if ($savedNode -and (Test-Path $savedNode)) {
    Copy-Item $savedNode (Join-Path $nodeDir 'node.exe') -Force
    Write-Host "Zwischengespeichertes node.exe wiederhergestellt - Paket bleibt lauffaehig."
  } else {
    Write-Warning "Kein Fallback vorhanden. Bitte node.exe manuell nach $nodeDir kopieren."
  }
}
if (-not (Test-Path (Join-Path $nodeDir 'node.exe'))) {
  throw "ABBRUCH: node\node.exe fehlt im Paket - der Ziel-PC koennte VetStation nicht starten."
}

# 3) Doppelklick-Starter + Installer-Starter ins Paket
@"
@echo off
title VetStation
REM VetStation starten (ECHTE Geraete). Fuer Dauerbetrieb: Install-VetStation.ps1 ausfuehren.
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
REM Nur im FEHLERFALL anhalten. Sonst schliesst sich das Fenster in derselben Sekunde und der
REM Tierarzt sieht Meldungen wie "Node.js nicht gefunden" oder "Bridge nicht erreichbar" nie.
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo     Netzwerk/Geraete pruefen: GERAETE-PRUEFEN.bat doppelklicken.
  echo.
  pause
)
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-VetStation.bat')

@"
@echo off
REM DEMO/TEST OHNE Geraete: schaltet den Simulator zu (zwei Demo-Patienten Hund+Katze).
set VETSTATION_SIM=1
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-TESTMODUS.bat')

@"
@echo off
REM VetStation installieren (Autostart-Kiosk). Einfach DOPPELKLICKEN - der Installer holt sich
REM die Adminrechte selbst (UAC-Abfrage bestaetigen). Laeuft auf Windows 10 UND Windows 11.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\Install-VetStation.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'INSTALLIEREN.bat')

# 3b) Netzwerk + Geraetepruefung als DOPPELKLICK-Dateien.
#     Grund: In PowerShell startet der Nutzer in C:\Windows\System32 - ein RELATIVER Pfad
#     ("-File installer\set-static-ip.ps1") schlaegt dort fehl. Diese .bat benutzen IMMER
#     ihren eigenen Ordner (%~dp0) und sind damit vom Startverzeichnis unabhaengig.
@"
@echo off
title VetStation - Netzwerk einrichten
REM Setzt die feste IP 192.168.0.99 fuer das isolierte Geraete-Netz (Ziel im Monitor).
REM Einfach DOPPELKLICKEN. Adminrechte holt sich das Skript selbst (UAC bestaetigen).
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-static-ip.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'NETZWERK-EINRICHTEN.bat')

@"
@echo off
title VetStation - Geraete pruefen
REM Prueft, ob Monitor/Kapnograf Daten senden. Benutzt das mitgelieferte portable Node -
REM auf dem Praxis-PC gibt es KEIN npm, deshalb NICHT "npm run check" verwenden.
REM Optional laesst sich eine Geraete-IP mitgeben:  GERAETE-PRUEFEN.bat 192.168.0.50
REM Ohne Parameter sucht das Programm die Geraete selbst (MAC-Suche + Lauschphase).
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\geraete-check.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\geraete-check.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'GERAETE-PRUEFEN.bat')

# 4) Optional zippen
$zipOut = Join-Path $OutDir 'VetStation-Setup.zip'
if (Test-Path $zipOut) { Remove-Item $zipOut -Force }
Compress-Archive -Path $Stage -DestinationPath $zipOut
Write-Host ""
Write-Host "FERTIG:"
Write-Host "  Ordner: $Stage"
Write-Host "  Zip:    $zipOut"
Write-Host "Auf den Ziel-PC kopieren -> INSTALLIEREN.bat (als Admin) oder START-VetStation.bat (Test)."
