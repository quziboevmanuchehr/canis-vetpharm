'use strict';
/*
 * p-welle-test.js — Selbsttest der P-Wellen- und PQ-Erkennung (ui/shared/ekg-analyse.js).
 *
 * WARUM DIESER TEST SO STRENG IST:
 * Die P-Welle ist klein — beim Hund 0,2–0,4 mV, bei der Katze bis 0,2 mV, also in der
 * Groessenordnung von Muskelzittern. Ein zu eifriger Detektor "findet" sie ueberall: in der
 * T-Welle des vorigen Schlages, im Rauschen, in einer flimmernden Grundlinie. Jede erfundene
 * P hat klinische Folgen — sie schliesst Vorhofflimmern faelschlich aus und macht aus einer
 * gesunden Ueberleitung einen AV-Block I.
 *
 * Deshalb prueft dieser Test BEIDE Richtungen: dass die P gefunden wird, wo sie ist, UND dass
 * sie NICHT gemeldet wird, wo keine ist. Die Signale sind synthetisch, damit die Wahrheit
 * bekannt ist. Alle Zufallsanteile sind mit festem Startwert erzeugt (kein Math.random) —
 * ein Test, der bei jedem Lauf ein anderes Ergebnis liefert, ist kein Test.
 *
 * Aufruf:  node tools/p-welle-test.js
 */
const path = require('path');
const VS = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-analyse.js'));

let gruen = 0, rot = 0;
function pruef(name, bed, zusatz) {
  if (bed) { gruen++; console.log('  ✓ ' + name); }
  else { rot++; console.log('  ✗ ' + name + (zusatz ? '   -> ' + zusatz : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

/* Fester Pseudozufall — reproduzierbar, im Gegensatz zu Math.random. */
function rnd(seed) {
  let s = seed >>> 0;
  return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296 - 0.5; };
}
function gauss(x, mu, s) { const d = (x - mu) / s; return Math.exp(-0.5 * d * d); }

/*
 * WELLE MIT ECHTEM ANFANG UND ENDE (Befund 08.08.2026).
 * Erst stand hier eine Gauss-Kurve. Die hat KEINEN definierten Anfang - sie laeuft nach beiden
 * Seiten unendlich aus. Der Detektor sucht aber genau den Punkt, an dem die Welle die
 * Grundlinie verlaesst, und fand ihn folgerichtig weiter aussen als die Stelle, die der Test
 * fuer "Anfang" hielt. Ergebnis: PQ schien um rund 30 ms zu lang, obwohl der Detektor richtig
 * mass - die WAHRHEIT des Testsignals war unscharf, nicht die Messung.
 * Jetzt: erhoehter Kosinus mit exaktem Traeger [t0, t0+dauer]. Damit ist der Anfang eindeutig,
 * und der Test prueft die Messung statt einer Definitionsluecke.
 */
function welle(dt, t0, dauer) {
  if (dt < t0 || dt > t0 + dauer) return 0;
  return 0.5 * (1 - Math.cos(2 * Math.PI * (dt - t0) / dauer));
}

/*
 * Baut ein EKG mit bekannter Wahrheit.
 * pAmp/pDauer in mV bzw. Sekunden; pq = Abstand P-BEGINN bis QRS-BEGINN in Sekunden.
 * Rueckgabe in Mikrovolt (skala 1, einheit uV) — so, wie ein Geraet liefert.
 */
function baueEKG(o) {
  const hz = o.hz, sek = o.sek, hf = o.hf;
  const n = Math.round(hz * sek), rr = hz * 60 / hf;
  const stoer = rnd(o.seed == null ? 42 : o.seed);
  const s = new Array(n).fill(0);
  const rIdx = [];
  for (let r = Math.round(rr * 0.6); r < n - Math.round(rr * 0.2); r += Math.round(rr)) rIdx.push(r);
  for (const r of rIdx) {
    for (let i = Math.max(0, r - Math.round(rr * 0.9)); i < Math.min(n, r + Math.round(rr * 0.6)); i++) {
      const dt = (i - r) / hz;                       // Sekunden relativ zur R-Spitze
      let v = 0;
      /* QRS mit exaktem Beginn bei -qrsBreite/2. R-Spitze liegt damit bei dt = 0. */
      v += o.rAmp * welle(dt, -o.qrsBreite / 2, o.qrsBreite);
      v += -o.rAmp * 0.22 * welle(dt, o.qrsBreite / 2, o.qrsBreite * 0.8);
      // T-Welle
      if (o.tAmp) v += o.tAmp * welle(dt, o.tLage - o.tBreite, o.tBreite * 2);
      /* P-Welle: BEGINN liegt pq vor dem QRS-Beginn. Das ist die Wahrheit, gegen die
       * die gemessene PQ-Zeit geprueft wird. */
      if (o.pAmp) {
        const pBeginn = -o.qrsBreite / 2 - o.pq;   // PQ laeuft vom P-ANFANG bis QRS-Anfang
        v += o.pAmp * welle(dt, pBeginn, o.pDauer);
      }
      s[i] += v;
    }
  }
  if (o.rauschen) for (let i = 0; i < n; i++) s[i] += stoer() * o.rauschen;
  if (o.flimmern) for (let i = 0; i < n; i++) s[i] += o.flimmern * Math.sin(i * 0.9) * (0.5 + 0.5 * Math.sin(i * 0.13));
  return { samples: s.map((v) => v * 1000), hz: hz, skala: 1, einheit: 'uV' };   // mV -> uV
}

// ---------------------------------------------------------------------------
block('1. Sauberes Hunde-EKG: P muss gefunden werden');
const hund = baueEKG({ hz: 500, sek: 8, hf: 120, rAmp: 1.6, qrsBreite: 0.050,
  pAmp: 0.25, pDauer: 0.040, pq: 0.100, tAmp: 0.30, tLage: 0.20, tBreite: 0.045, rauschen: 0.004 });
const eHund = VS.analysiere(hund, {});
pruef('Streifen ist auswertbar', eHund.brauchbar === true, eHund.warum || '');
pruef('P-Auswertung liefert ein Ergebnis', !!eHund.p);
pruef('P wird als vorhanden gemeldet', eHund.p.vorhanden === true, JSON.stringify(eHund.p).slice(0, 130));
pruef('P in der grossen Mehrzahl der Schlaege', eHund.p.anteil >= 80, eHund.p.anteil + ' %');
pruef('P-Dauer nahe 40 ms (Toleranz 20)', Math.abs(eHund.p.dauerMs - 40) <= 20, eHund.p.dauerMs + ' ms');
pruef('PQ nahe 100 ms (Toleranz 25)', Math.abs(eHund.p.pqMs - 100) <= 25, eHund.p.pqMs + ' ms');
pruef('P-Amplitude in mV genannt (Signal ist kalibriert)', eHund.p.ampMv != null, String(eHund.p.ampMv));
pruef('P-Amplitude nahe 0,25 mV', eHund.p.ampMv != null && Math.abs(eHund.p.ampMv - 0.25) <= 0.12, String(eHund.p.ampMv));
pruef('PQ-Verlauf als konstant erkannt', eHund.p.pqVerlauf === 'konstant', eHund.p.pqVerlauf);
pruef('P ist positiv (nicht als negativ gemeldet)', eHund.p.negativ === false);

// ---------------------------------------------------------------------------
block('2. Katze: kleine P bei hoher Frequenz');
const katze = baueEKG({ hz: 500, sek: 8, hf: 200, rAmp: 0.8, qrsBreite: 0.035,
  pAmp: 0.15, pDauer: 0.035, pq: 0.070, tAmp: 0.16, tLage: 0.13, tBreite: 0.035, rauschen: 0.003 });
const eKatze = VS.analysiere(katze, {});
pruef('Streifen auswertbar', eKatze.brauchbar === true, eKatze.warum || '');
pruef('P auch bei 200/min gefunden', eKatze.p.vorhanden === true, JSON.stringify(eKatze.p).slice(0, 120));
pruef('PQ nahe 70 ms (Toleranz 25)', eKatze.p.pqMs != null && Math.abs(eKatze.p.pqMs - 70) <= 25, eKatze.p.pqMs + ' ms');
pruef('P-Amplitude klein und plausibel (< 0,4 mV)', eKatze.p.ampMv != null && eKatze.p.ampMv < 0.4, String(eKatze.p.ampMv));

// ---------------------------------------------------------------------------
block('3. DIE WICHTIGSTEN FAELLE: wo KEINE P gemeldet werden darf');
/* Vorhofflimmern-artig: keine P, dafuer flimmernde Grundlinie. Ein naiver Detektor findet
 * hier "P" im Flimmern - und schliesst damit ausgerechnet die Diagnose aus, um die es geht. */
const vhf = baueEKG({ hz: 500, sek: 8, hf: 150, rAmp: 1.4, qrsBreite: 0.045,
  pAmp: 0, tAmp: 0.25, tLage: 0.19, tBreite: 0.045, flimmern: 0.06, rauschen: 0.01, seed: 7 });
const eVhf = VS.analysiere(vhf, {});
pruef('bei fehlender P wird KEINE P behauptet', !(eVhf.p && eVhf.p.vorhanden === true),
  JSON.stringify(eVhf.p).slice(0, 150));
pruef('und der Grund wird genannt', !!(eVhf.p && eVhf.p.warum), (eVhf.p && eVhf.p.warum || '').slice(0, 90));
pruef('der Grund nennt Vorhofflimmern als Moeglichkeit, ohne sie zu behaupten',
  !!(eVhf.p && /Vorhofflimmern/.test(eVhf.p.warum || '')));

/* Grosse T-Welle bei kurzem RR: die T des VORIGEN Schlages darf nicht als P gelten. */
const tFalle = baueEKG({ hz: 500, sek: 8, hf: 180, rAmp: 1.2, qrsBreite: 0.040,
  pAmp: 0, tAmp: 0.55, tLage: 0.16, tBreite: 0.050, rauschen: 0.004, seed: 11 });
const eT = VS.analysiere(tFalle, {});
pruef('eine grosse T-Welle wird NICHT als P gemeldet', !(eT.p && eT.p.vorhanden === true),
  JSON.stringify(eT.p || {}).slice(0, 140));

/* Reines Rauschen: die Zackensuche findet dort irgendetwas, die P-Auswertung darf nicht
 * zusaetzlich eine P behaupten. */
const nurRausch = { samples: (function () { const r = rnd(3), a = []; for (let i = 0; i < 4000; i++) a.push(r() * 200); return a; })(), hz: 500, skala: 1, einheit: 'uV' };
const eR = VS.analysiere(nurRausch, {});
pruef('reines Rauschen: keine P-Behauptung', !(eR.p && eR.p.vorhanden === true),
  eR.brauchbar ? JSON.stringify(eR.p).slice(0, 110) : ('Streifen bereits verworfen: ' + (eR.warum || '').slice(0, 60)));

// ---------------------------------------------------------------------------
block('4. Abtastrate: unter 100 Hz wird geschwiegen (Nyquist)');
const langsam = baueEKG({ hz: 80, sek: 10, hf: 120, rAmp: 1.6, qrsBreite: 0.050,
  pAmp: 0.25, pDauer: 0.040, pq: 0.100, tAmp: 0.3, tLage: 0.2, tBreite: 0.045, rauschen: 0.003 });
const eLang = VS.analysiere(langsam, {});
pruef('bei 80 Hz wird die P-Messung verweigert',
  !!(eLang.p && eLang.p.messbar === false), JSON.stringify(eLang.p || {}).slice(0, 110));
pruef('und die Abtastrate wird als Grund genannt',
  !!(eLang.p && /Abtastrate/.test(eLang.p.warum || '')), (eLang.p && eLang.p.warum || '').slice(0, 80));
pruef('die Grenze ist als Konstante gefuehrt', VS.P_MIN_HZ === 100);

// ---------------------------------------------------------------------------
block('5. PQ-Verlauf: Wenckebach gegen Mobitz II — der eigentliche Zugewinn');
/* Wenckebach: die Ueberleitungszeit waechst von Schlag zu Schlag. Genau daran unterscheidet
 * er sich vom Mobitz II - und genau das konnte die Station bisher nicht sehen. */
function baueMitPQ(pqListe, hz, hf) {
  const rr = hz * 60 / hf, n = Math.round(rr * (pqListe.length + 1.5));
  const s = new Array(n).fill(0);
  for (let k = 0; k < pqListe.length; k++) {
    const r = Math.round(rr * (k + 1));
    for (let i = Math.max(0, r - Math.round(rr * 0.9)); i < Math.min(n, r + Math.round(rr * 0.5)); i++) {
      const dt = (i - r) / hz;
      s[i] += 1.6 * welle(dt, -0.025, 0.050) - 0.35 * welle(dt, 0.025, 0.040);
      s[i] += 0.30 * welle(dt, 0.155, 0.090);
      const pBeginn = -0.025 - pqListe[k];
      s[i] += 0.25 * welle(dt, pBeginn, 0.040);
    }
  }
  const r2 = rnd(5);
  for (let i = 0; i < n; i++) s[i] += r2() * 0.004;
  return { samples: s.map((v) => v * 1000), hz: hz, skala: 1, einheit: 'uV' };
}
const wenck = VS.analysiere(baueMitPQ([0.100, 0.125, 0.150, 0.175, 0.100, 0.125, 0.150, 0.175], 500, 100), {});
pruef('Wenckebach: P gefunden', wenck.p && wenck.p.vorhanden === true, JSON.stringify(wenck.p || {}).slice(0, 110));
pruef('Wenckebach: PQ-Spanne ist deutlich (>= 40 ms)', wenck.p && wenck.p.pqSpanneMs >= 40, (wenck.p && wenck.p.pqSpanneMs) + ' ms');
pruef('Wenckebach wird NICHT als konstant gemeldet', wenck.p && wenck.p.pqVerlauf !== 'konstant', wenck.p && wenck.p.pqVerlauf);

const mobitz = VS.analysiere(baueMitPQ([0.140, 0.140, 0.140, 0.140, 0.140, 0.140, 0.140, 0.140], 500, 100), {});
pruef('Mobitz II: P gefunden', mobitz.p && mobitz.p.vorhanden === true);
pruef('Mobitz II: PQ als KONSTANT erkannt', mobitz.p && mobitz.p.pqVerlauf === 'konstant',
  mobitz.p && (mobitz.p.pqVerlauf + ', Spanne ' + mobitz.p.pqSpanneMs + ' ms'));
pruef('Mobitz II: PQ nahe 140 ms', mobitz.p && Math.abs(mobitz.p.pqMs - 140) <= 30, mobitz.p && (mobitz.p.pqMs + ' ms'));
pruef('die beiden sind damit unterscheidbar',
  wenck.p && mobitz.p && wenck.p.pqVerlauf !== mobitz.p.pqVerlauf,
  (wenck.p && wenck.p.pqVerlauf) + ' vs ' + (mobitz.p && mobitz.p.pqVerlauf));

// ---------------------------------------------------------------------------
block('6. Ohne Kalibrierung keine mV-Zahl');
const ohneSkala = baueEKG({ hz: 500, sek: 8, hf: 120, rAmp: 1.6, qrsBreite: 0.050,
  pAmp: 0.25, pDauer: 0.040, pq: 0.100, tAmp: 0.3, tLage: 0.2, tBreite: 0.045, rauschen: 0.004 });
delete ohneSkala.skala; delete ohneSkala.einheit;
const eOhne = VS.analysiere(ohneSkala, { einheit: null });
pruef('P wird trotzdem gefunden (die Form ist unabhaengig von der Eichung)', eOhne.p && eOhne.p.vorhanden === true);
pruef('aber KEINE Amplitude in mV', eOhne.p && eOhne.p.ampMv == null, String(eOhne.p && eOhne.p.ampMv));
pruef('Zeiten bleiben gueltig (PQ trotzdem genannt)', eOhne.p && eOhne.p.pqMs > 0, String(eOhne.p && eOhne.p.pqMs));

// ---------------------------------------------------------------------------
block('7. QRS-Beginn: die PQ endet am Komplexanfang, nicht an der R-Spitze');
const wq = VS.grundlinieAbziehen(hund.samples, hund.hz);
const zq = VS.findeQRS(wq, hund.hz);
pruef('Zacken gefunden', zq.length >= 5, zq.length + ' Zacken');
const qb = VS.qrsBeginn(wq, zq[2], hund.hz);
pruef('QRS-Beginn liegt VOR der R-Spitze', qb < zq[2], 'Beginn ' + qb + ', R ' + zq[2]);
pruef('und hoechstens 90 ms davor', (zq[2] - qb) / hund.hz * 1000 <= 90,
  Math.round((zq[2] - qb) / hund.hz * 1000) + ' ms');
/* Gegenprobe: wuerde man bis zur R-SPITZE messen, kaeme eine deutlich zu lange PQ heraus —
 * genau der Fehler, der aus einem gesunden Tier einen AV-Block I macht. */
const pqBisSpitze = eHund.p.pqMs + Math.round((zq[2] - qb) / hund.hz * 1000);
pruef('bis zur R-Spitze gemessen waere die PQ deutlich laenger (Fehler vermieden)',
  pqBisSpitze > eHund.p.pqMs + 8, eHund.p.pqMs + ' ms gegen ' + pqBisSpitze + ' ms');

// ---------------------------------------------------------------------------
block('8. Die T-Welle ist HOEHER als die P — der Maximumsuche-Fehler');
/*
 * BEFUND DER FACHRECHERCHE (08.08.2026): "Die T-Welle ist im Hund oft hoeher als die
 * P-Welle - eine Maximumsuche greift systematisch daneben." Genau das tat die erste Fassung:
 * sie nahm den groessten Ausschlag im Suchfenster. Jetzt wird von der QRS-Seite her der
 * NAECHSTE gueltige Kandidat genommen. Dieser Test baut den Fall absichtlich: T doppelt so
 * hoch wie P, beide im Fenster.
 */
const tHoch = baueEKG({ hz: 500, sek: 8, hf: 100, rAmp: 1.6, qrsBreite: 0.050,
  pAmp: 0.22, pDauer: 0.040, pq: 0.100, tAmp: 0.50, tLage: 0.22, tBreite: 0.060, rauschen: 0.004, seed: 21 });
const eTH = VS.analysiere(tHoch, { art: 'hund' });
pruef('P wird gefunden, obwohl die T doppelt so hoch ist', eTH.p && eTH.p.vorhanden === true,
  JSON.stringify(eTH.p || {}).slice(0, 130));
pruef('und es ist die P, nicht die T (PQ nahe 100 ms)',
  eTH.p && eTH.p.pqMs != null && Math.abs(eTH.p.pqMs - 100) <= 30, eTH.p && (eTH.p.pqMs + ' ms'));
pruef('die gemessene Dauer passt zur P (nicht zur breiten T)',
  eTH.p && eTH.p.dauerMs <= 60, eTH.p && (eTH.p.dauerMs + ' ms'));
pruef('die gemessene Amplitude passt zur P, nicht zur T',
  eTH.p && eTH.p.ampMv != null && eTH.p.ampMv < 0.40, String(eTH.p && eTH.p.ampMv));

block('9. Dauerband trennt P von T — tierartlich');
pruef('Artentabelle gefuehrt', !!(VS.P_ART && VS.P_ART.hund && VS.P_ART.katze && VS.P_ART.pferd));
pruef('Hund/Katze: enges Band (obere Grenze <= 60 ms)',
  VS.P_ART.hund.dauer[1] <= 60 && VS.P_ART.katze.dauer[1] <= 60,
  VS.P_ART.hund.dauer.join('-') + ' / ' + VS.P_ART.katze.dauer.join('-'));
pruef('Pferd: weites Band (P ist dort 90-170 ms normal)', VS.P_ART.pferd.dauer[1] >= 200,
  VS.P_ART.pferd.dauer.join('-'));
pruef('Katzenfenster kuerzer als Hundefenster (hoehere Frequenz)',
  VS.P_ART.katze.wHinten < VS.P_ART.hund.wHinten);
pruef('Pferdefenster deutlich laenger (PQ 210-410 ms)', VS.P_ART.pferd.wHinten >= 0.4);

block('10. Pferd: der Grundlinienabzug darf die P nicht loeschen');
/*
 * Die Pferde-P ist 90-170 ms breit. Ein gleitender Median mit 200 ms Fenster haelt sie fuer
 * Grundlinie und zieht sie ab - die Suche laeuft dann auf einem Signal, aus dem die gesuchte
 * Welle bereits entfernt ist. Dieser Test misst genau das nach.
 */
const pferd = baueEKG({ hz: 500, sek: 16, hf: 36, rAmp: 1.8, qrsBreite: 0.090,
  pAmp: 0.35, pDauer: 0.130, pq: 0.280, tAmp: 0.55, tLage: 0.42, tBreite: 0.110, rauschen: 0.004, seed: 31 });
const w200 = VS.grundlinieAbziehen(pferd.samples, pferd.hz, 0.2);
const w600 = VS.grundlinieAbziehen(pferd.samples, pferd.hz, 0.6);
const z600 = VS.findeQRS(w600, pferd.hz);
function pGipfelHoehe(w, z, hz) {
  // Hoehe rund 300 ms vor dem zweiten QRS - dort liegt die Pferde-P
  const r = z[2], i0 = r - Math.round(hz * 0.42), i1 = r - Math.round(hz * 0.16);
  let m = 0; for (let i = i0; i <= i1; i++) if (Math.abs(w[i]) > m) m = Math.abs(w[i]);
  return m;
}
const h200 = pGipfelHoehe(w200, z600, pferd.hz), h600 = pGipfelHoehe(w600, z600, pferd.hz);
/* WAHRHEIT DES SIGNALS: die P wurde mit 0,35 mV = 350 uV gebaut. Geprueft wird gegen DIESE
 * Zahl, nicht gegen eine geratene Prozentschwelle (erster Anlauf verlangte 20 % Verlust und
 * mass 12 % - der Effekt war echt, meine Erwartung war willkuerlich). */
pruef('600-ms-Fenster gibt die Pferde-P nahezu unverfaelscht wieder (350 uV +/- 8 %)',
  Math.abs(h600 - 350) <= 28, h600.toFixed(0) + ' uV');
pruef('200-ms-Fenster rechnet sie messbar kleiner — der Median frisst die breite P',
  h200 < h600 - 20, '200 ms: ' + h200.toFixed(0) + ' uV gegen 600 ms: ' + h600.toFixed(0) + ' uV');
const ePferd = VS.analysiere(pferd, { art: 'pferd' });
pruef('mit Tierart Pferd wird die P gefunden', ePferd.p && ePferd.p.vorhanden === true,
  JSON.stringify(ePferd.p || {}).slice(0, 140));
pruef('PQ nahe 280 ms (Toleranz 60)', ePferd.p && Math.abs(ePferd.p.pqMs - 280) <= 60,
  ePferd.p && (ePferd.p.pqMs + ' ms'));
pruef('P-Dauer im Pferdebereich (>= 80 ms)', ePferd.p && ePferd.p.dauerMs >= 80,
  ePferd.p && (ePferd.p.dauerMs + ' ms'));

block('11. RR/2-Deckel: bei sehr hoher Frequenz wird geschwiegen');
/* Hund 240/min: RR/2 = 125 ms liegt unter der oberen PQ-Norm von 130 ms — dort ist die P
 * nicht mehr sicher vom vorigen Schlag zu trennen, und das Verfahren soll das zugeben. */
const schnell = baueEKG({ hz: 500, sek: 8, hf: 240, rAmp: 1.4, qrsBreite: 0.040,
  pAmp: 0.22, pDauer: 0.035, pq: 0.070, tAmp: 0.45, tLage: 0.11, tBreite: 0.035, rauschen: 0.004, seed: 41 });
const eS = VS.analysiere(schnell, { art: 'hund' });
pruef('bei 240/min wird entweder geschwiegen oder eine plausible PQ gemeldet',
  !eS.p || eS.p.vorhanden !== true || (eS.p.pqMs > 20 && eS.p.pqMs < 140),
  JSON.stringify(eS.p || {}).slice(0, 130));

// ---------------------------------------------------------------------------
console.log('\n' + (rot === 0
  ? 'ALLE ' + gruen + ' PRUEFUNGEN BESTANDEN'
  : rot + ' FEHLGESCHLAGEN von ' + (gruen + rot)));
process.exit(rot === 0 ? 0 : 1);
