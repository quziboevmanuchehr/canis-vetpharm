'use strict';
/*
 * geraete-profil-test.js — DAS UNIVERSELLE VIRTUELLE GERAET.
 *
 * Geprueft wird nicht "laeuft es durch", sondern die Fehler, die dieses Bild WIRKLICH gefaehrlich
 * machen wuerden. Jeder Block unten steht fuer einen Fehler, der schon einmal passiert ist oder der
 * im Browser voellig normal aussieht:
 *
 *   1  Ein Kanal im Profil, den es nicht gibt      -> leere Kachel, faellt niemandem auf
 *   2  Ein Kanal, den das ECHTE Geraet nicht hat   -> vorgetaeuschte Messung (LifeVet M ohne CO2)
 *   3  Toter Verweis in den Geraetekatalog         -> "Wie schliesse ich es an?" fuehrt ins Leere
 *   4  Reihenfolge haengt an der Auswahlreihenfolge-> das Bild sortiert sich beim Modellwechsel um
 *   5  Modellerkennung RAET                        -> blendet Kanaele aus, die das Geraet hat
 *   6  MAC des falschen Gases                      -> 2 Vol% sind Iso-Erhaltung und Des-Viertel-MAC
 *   7  Gerechnet aus unvollstaendigen Eingaben     -> erfundene Messung
 *   8  Normband haengt nicht am Gewicht            -> Vt-Alarm fuer das falsche Tier
 *   9  Die Bridge reicht die Kanaele nicht durch   -> fern unsichtbar, ohne eine einzige Logzeile
 *  10  Bestehende Zuordnung still veraendert       -> LifeVet/uMEC verlieren einen Wert
 *  11  Kurvenformel kaputt                         -> gezeichnete Linie, die nichts mehr aussagt
 *  12  App und Web-App laufen auseinander          -> fern ein anderes Bild als am Praxis-PC
 *
 * Start:  node tools/geraete-profil-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const VG = require(path.join(WURZEL, 'ui/shared/geraete-profile.js'));
const katalog = require(path.join(WURZEL, 'bridge/src/geraetekatalog.js'));
const model = require(path.join(WURZEL, 'bridge/src/model.js'));
const matching = require(path.join(WURZEL, 'bridge/src/matching.js'));

let ok = 0, fail = 0;
function pruef(name, bedingung, zusatz) {
  if (bedingung) { ok++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (zusatz ? '  -> ' + zusatz : '')); }
}
function abschnitt(t) { console.log('\n' + t); }

/* ================================================================= 1 */
abschnitt('1) Selbstpruefung des Moduls (Daten in sich stimmig)');
const fehler = VG.pruefe();
pruef('pruefe() meldet nichts', fehler.length === 0, fehler.join(' | '));
pruef('mindestens 20 Profile', VG.PROFILE.length >= 20, 'nur ' + VG.PROFILE.length);
pruef('Monitor- UND Narkoseauswahl nicht leer', VG.alle('monitor').length > 3 && VG.alle('narkose').length > 3);
pruef('jedes Profil ist ueber nachId erreichbar', VG.PROFILE.every((p) => VG.nachId(p.id) === p));

/* ================================================================= 2 */
abschnitt('2) Was ein Geraet NICHT kann, darf nicht im Bild stehen');
const lifevetM = VG.nachId('eickemeyer-lifevet-m');
pruef('LifeVet M hat KEIN EtCO2 (kein CO2-Modul verbaut, Foto 31.07.2026)', lifevetM.kanaele.indexOf('etco2') < 0);
pruef('LifeVet M hat auch keine Kapno-Kurve', lifevetM.kurven.indexOf('capno') < 0);
const veta5 = VG.nachId('mindray-veta-5-plus');
['etco2', 'fico2', 'ppeak', 'peep', 'vte', 'mv', 'rr'].forEach((k) => {
  pruef('Veta 5 Plus zeigt ' + k + ' (steht so auf dem Bildschirm)', veta5.kanaele.indexOf(k) >= 0);
});
pruef('Veta 5 Plus hat die Paw-Kurve', veta5.kurven.indexOf('paw') >= 0);
pruef('Veta 5 Plus beschriftet Ppeak als "MAX" (wie auf dem Foto)', VG.abbrFuer(VG.zusammen(null, veta5), 'ppeak') === 'MAX');
pruef('Veta 5 Plus kennt Falluhr und Insp. Hold', veta5.fallTimer === true && veta5.inspHold === true);
pruef('Veta 5 Plus hat KEIN Gasmodul (kein EtAA)', veta5.kanaele.indexOf('etAgent') < 0);
const mech = VG.nachId('mechanisch-vet-narkose');
pruef('rein mechanisches Narkosegeraet misst GAR NICHTS', mech.kanaele.length === 0 && mech.kurven.length === 0);
pruef('... hat aber trotzdem Handbeatmung', mech.ventModi.indexOf('manual') >= 0);
const kapno = VG.nachId('kapnograf-standalone');
pruef('eigenstaendiger Kapnograf ist KEIN Ventilator', kapno.ventModi.length === 0);
pruef('... steht trotzdem in der Narkose-Auswahl', VG.alle('narkose').some((p) => p.id === 'kapnograf-standalone'));

/* ================================================================= 3 */
abschnitt('3) Verweise in den Geraetekatalog sind lebendig');
VG.PROFILE.filter((p) => p.katalogId).forEach((p) => {
  pruef('katalogId "' + p.katalogId + '" (' + p.id + ') existiert', !!katalog.nachId(p.katalogId));
});
pruef('nachKatalogId findet das Veta-5-Profil', (VG.nachKatalogId('mindray-veta-5', 'narkose') || {}).id === 'mindray-veta-5-plus');

/* ================================================================= 4 */
abschnitt('4) Das Bild sortiert sich nicht um');
const a = VG.zusammen(VG.nachId('mindray-umec12-vet'), VG.nachId('mindray-veta-5-plus'));
const b = VG.zusammen(VG.nachId('mindray-umec12-vet'), VG.nachId('mindray-veta-5-plus'));
pruef('gleiche Wahl -> gleiche Reihenfolge', a.kanaele.join() === b.kanaele.join());
const rang = { kreislauf: 1, atmung: 2, beatmung: 3, gas: 4, temperatur: 5 };
let letzter = 0, sortiert = true;
a.kanaele.forEach((id) => { const r = rang[VG.kanal(id).art]; if (r < letzter) sortiert = false; letzter = r; });
pruef('Kreislauf -> Atmung -> Beatmung -> Gas -> Temperatur', sortiert, a.kanaele.join());
pruef('EtCO2 steht direkt vor FiCO2', a.kanaele.indexOf('fico2') === a.kanaele.indexOf('etco2') + 1);
const reihe = ['ekg', 'pleth', 'capno', 'paw', 'flow', 'resp'];
let kl = -1, kSort = true;
a.kurven.forEach((id) => { const i = reihe.indexOf(id); if (i < kl) kSort = false; kl = i; });
pruef('Kurvenbahnen: Herz oben, Druck unten', kSort, a.kurven.join());
pruef('kein Kanal doppelt', new Set(a.kanaele).size === a.kanaele.length);
const uni = VG.zusammen(VG.standard('monitor'), VG.standard('narkose'));
pruef('Universalgeraet zeigt JEDEN Kanal des Katalogs', uni.kanaele.length === VG.KANAELE.filter((k) => k.id !== 'o2flow' && k.id !== 'ie').length,
  uni.kanaele.length + ' von ' + VG.KANAELE.length);
pruef('Universalgeraet zeigt jede Kurvenbahn', uni.kurven.length === VG.KURVEN.length);

/* ================================================================= 5 */
abschnitt('5) Modellerkennung schlaegt vor, raet aber nie');
[['Mindray Veta 5 Plus', 'narkose', 'mindray-veta-5-plus'],
 ['uMEC12 Vet', 'monitor', 'mindray-umec12-vet'],
 ['Eickemeyer LifeVet 10C', 'monitor', 'eickemeyer-lifevet-10c'],
 ['LifeVet M', 'monitor', 'eickemeyer-lifevet-m'],
 ['WATO EX-35Vet', 'narkose', 'mindray-wato-ex35-vet'],
 ['Draeger Fabius', 'narkose', 'draeger-narkose'],
 ['BIONET BM5Vet', 'monitor', 'bionet-bm-vet'],
].forEach(([txt, rolle, erwartet]) => {
  const t = VG.erkenne(txt, rolle);
  pruef('erkenne("' + txt + '") = ' + erwartet, t && t.id === erwartet, t ? t.id : 'nichts');
});
['Blubb 3000', 'Monitor', 'X', ''].forEach((txt) => {
  pruef('erkenne("' + txt + '") raet NICHT', VG.erkenne(txt, 'monitor') === null,
    (VG.erkenne(txt, 'monitor') || {}).id);
});
/* Das LifeVet 10C darf NICHT auf das LifeVet M treffen und umgekehrt — beide heissen "LifeVet",
 * aber das eine hat ein CO2-Modul und das andere nicht. Eine Verwechslung blendet den Kapnografen
 * aus oder taeuscht einen vor. */
pruef('"LifeVet 10C" trifft nicht das LifeVet M', VG.erkenne('LifeVet 10C', 'monitor').id === 'eickemeyer-lifevet-10c');
pruef('"LifeVet M" trifft nicht das 10C', VG.erkenne('LifeVet M', 'monitor').id === 'eickemeyer-lifevet-m');

/* ================================================================= 6 */
abschnitt('6) MAC gehoert zum GAS und zur TIERART');
const spHund = { iso: { mac: 1.3 }, tvMlKg: [10, 15], rr: [8, 12], pip: 15 };
pruef('Iso-MAC kommt aus der gepflegten Artangabe', VG.macFuer('iso', 'hund', spHund) === 1.3);
const sevo = VG.macInfo('sevo', 'hund', spHund);
pruef('Sevofluran Hund 2,36 (publiziert, nicht abgeleitet)', sevo.wert === 2.36 && sevo.abgeleitet === false);
const sevoDegu = VG.macInfo('sevo', 'degu', { iso: { mac: 1.4 } });
pruef('Sevofluran Degu ist ABGELEITET und wird so gekennzeichnet', sevoDegu.abgeleitet === true);
pruef('... und liegt deutlich ueber dem Iso-MAC', sevoDegu.wert > 2);
pruef('Desfluran-Skala geht bis 18, Iso nur bis 6', VG.gas('des').max === 18 && VG.gas('iso').max === 6);
pruef('jedes Gas nennt seine Quelle', VG.GASE.every((g) => !!g.quelle));
pruef('unbekanntes Gas faellt auf Isofluran zurueck statt zu raten', VG.macFuer('xyz', 'hund', spHund) === 1.3);

/* ================================================================= 7 */
abschnitt('7) Gerechnet wird nur mit vollstaendigen Eingaben');
const ctx = { sp: 'hund', wt: 10, spSet: spHund, gas: 'iso', ie: '1:2' };
const d1 = VG.ableiten({ vte: 100, rr: 12, ppeak: 12, peep: 3, etAgent: 1.3 }, ctx);
pruef('MV = Vt x AF', d1.mv === 1.2, String(d1.mv));
pruef('Compliance = Vt / (Ppeak - PEEP)', Math.abs(d1.compl - 100 / 9) < 0.1, String(d1.compl));
pruef('Pmean aus I:E 1:2 = PEEP + (Ppeak-PEEP)/3', Math.abs(d1.pmean - 6) < 0.1, String(d1.pmean));
pruef('MAC = EtAA / MAC der Art', d1.mac === 1, String(d1.mac));
const d2 = VG.ableiten({ vte: 100 }, ctx);
pruef('ohne AF KEIN Minutenvolumen', d2.mv === undefined);
pruef('ohne Druecke KEINE Compliance', d2.compl === undefined && d2.pmean === undefined);
const d3 = VG.ableiten({ vte: 100, rr: 12, ppeak: 5, peep: 5 }, ctx);
pruef('Ppeak == PEEP -> keine Division durch Null', d3.compl === undefined);
const d4 = VG.ableiten({ etAgent: 2.4 }, { sp: 'hund', spSet: spHund, gas: 'sevo' });
pruef('MAC rechnet mit dem GEWAEHLTEN Gas (Sevo, nicht Iso)', Math.abs(d4.mac - 2.4 / 2.36) < 0.02, String(d4.mac));
const d5 = VG.ableiten({ ppeak: 12, peep: 3 }, { sp: 'hund', spSet: spHund, ie: '1:4' });
pruef('laengere Exspiration -> niedrigerer Mitteldruck', d5.pmean < d1.pmean, d5.pmean + ' vs ' + d1.pmean);

/* ================================================================= 8 */
abschnitt('8) Normbaender haengen am Patienten, nicht an einer festen Zahl');
const vitHund = { hr: [60, 140], rr: [8, 20], spo2: [95, 100], etco2: [30, 55], map: [70, 120], temp: [37.5, 39.2] };
const b10 = VG.bandFuer('vte', { sp: 'hund', wt: 10, spSet: spHund, vitals: vitHund });
const b40 = VG.bandFuer('vte', { sp: 'hund', wt: 40, spSet: spHund, vitals: vitHund });
pruef('Vt-Band skaliert mit dem Gewicht', b40[0] === b10[0] * 4 && b40[1] === b10[1] * 4, JSON.stringify([b10, b40]));
pruef('Vt-Band beginnt bei 8 ml/kg (lungenschonend)', b10[0] === 80, JSON.stringify(b10));
pruef('MV-Band = Vt-Band x AF-Band (dieselben Zahlen wie die Nachbarkacheln)',
  Math.abs(VG.bandFuer('mv', { sp: 'hund', wt: 10, spSet: spHund, vitals: vitHund })[1] - b10[1] * vitHund.rr[1] / 1000) < 0.01,
  JSON.stringify(VG.bandFuer('mv', { sp: 'hund', wt: 10, spSet: spHund, vitals: vitHund })));
pruef('HF-Band kommt aus der Tierart-Tabelle', JSON.stringify(VG.bandFuer('hr', { sp: 'hund', vitals: vitHund })) === '[60,140]');
pruef('FiCO2-Band ist eng (Rueckatmung ab ~3 mmHg)', VG.bandFuer('fico2', {})[1] <= 3);
pruef('Ppeak-Band endet beim art-/gewichtsgerechten Grenzdruck', VG.bandFuer('ppeak', { spSet: spHund })[1] === 15);
pruef('Kanal ohne Band liefert null statt einer erfundenen Norm', VG.bandFuer('fiAgent', {}) === null);

/* ================================================================= 9 */
abschnitt('9) Die Bridge reicht die neuen Kanaele durch');
const NEU = ['ppeak', 'pmean', 'peep', 'vte', 'mv', 'compl', 'fio2', 'etAgent', 'fiAgent', 'mac', 'etn2o', 'pi', 'temp2', 'ibp'];
const leer = model.emptyVitals();
NEU.forEach((k) => pruef('emptyVitals kennt ' + k, k in leer));
const norm = model.normalizeFrame({
  deviceId: 'x', deviceRole: 'anesthesia', species: 'hund', weightKg: 10,
  vitals: { etco2: 45, fico2: 8, ppeak: 12, peep: 3, vte: 100, mv: 1.2, fio2: 95, etAgent: 1.3, pi: 4, temp2: 37.5, ibp: 80 },
});
NEU.filter((k) => ['pmean', 'compl', 'mac', 'fiAgent', 'etn2o'].indexOf(k) < 0)
  .forEach((k) => pruef('normalizeFrame traegt ' + k + ' ein', norm.frame.vitals[k] != null, String(norm.frame.vitals[k])));
pruef('FiCO2 > 5 setzt weiterhin capnoShape = baseline (Rueckatmung)', norm.frame.vitals.capnoShape === 'baseline');
const mull = model.normalizeFrame({ deviceId: 'x', vitals: { ppeak: 32767, vte: -5, fio2: 400 } });
pruef('Mindrays 32767 wird NICHT als Spitzendruck uebernommen', mull.frame.vitals.ppeak === null);
pruef('negatives Volumen wird verworfen', mull.frame.vitals.vte === null);
pruef('FiO2 400 % wird verworfen', mull.frame.vitals.fio2 === null);
pruef('... und jede Verwerfung wird GEMELDET, nicht verschwiegen', mull.warnings.length >= 3, JSON.stringify(mull.warnings));

// Zusammenfuehren: das beatmende Geraet gewinnt bei den Beatmungswerten.
const zus = matching.mergePatients([
  { deviceId: 'MON', frame: model.normalizeFrame({ deviceId: 'MON', deviceRole: 'monitor', patientId: '1', species: 'hund', weightKg: 10, ts: 2, vitals: { hr: 90, ppeak: 99, vte: 999 } }).frame },
  { deviceId: 'NARK', frame: model.normalizeFrame({ deviceId: 'NARK', deviceRole: 'anesthesia', patientId: '1', species: 'hund', weightKg: 10, ts: 1, vitals: { ppeak: 12, vte: 100, etco2: 44 } }).frame },
], {});
pruef('bei zwei Quellen liefert das NARKOSEGERAET den Spitzendruck', zus[0].vitals.ppeak === 12, String(zus[0].vitals.ppeak));
pruef('... und das gemessene Atemzugvolumen', zus[0].vitals.vte === 100, String(zus[0].vitals.vte));
pruef('... der Monitor bleibt fuer die Herzfrequenz zustaendig', zus[0].vitals.hr === 90);
pruef('MERGE_FELDER ist EINE Liste (kein zweiter Ort zum Vergessen)', matching.MERGE_FELDER.length >= 20 && NEU.every((k) => matching.MERGE_FELDER.indexOf(k) >= 0));

/* ================================================================= 9b */
abschnitt('9b) Die Datenbankregel nimmt JEDEN neuen Kanal an (1.4.2)');
/*
 * WARUM DAS HIER GEPRUEFT WIRD UND NICHT NUR IN DER KONSOLE NACHGESEHEN:
 * cloud.js schaltet die Fern-Uebertragung nach DREI abgewiesenen Schreibvorgaengen dauerhaft ab.
 * Der Saal saehe fern weiter „live" aus — mit eingefrorenen Zahlen. Ein neuer Messkanal, den die
 * Regel nicht kennt, ist damit kein Schoenheitsfehler, sondern ein stiller Totalausfall der
 * Fern-Ansicht. Deshalb wird die ECHTE Regel (aus installer/firebase-rtdb-rules.json) gegen ein
 * ECHTES Wertepaket (aus cloud.js:_buildSnapshot) gerechnet — bei jedem Testlauf, nicht einmalig.
 */
{
  const regelDatei = fs.readFileSync(path.join(WURZEL, 'installer/firebase-rtdb-rules.json'), 'utf8');
  const ohneKommentar = regelDatei.replace(/^\s*\/\/.*$/gm, '');
  const mVit = /"vitals"\s*:\s*\{[^}]*?"\$feld"\s*:\s*\{\s*"\.validate"\s*:\s*"([^"]+)"/s.exec(ohneKommentar);
  pruef('die vitals-Regel ist auffindbar', !!mVit);
  if (mVit) {
    const ausdruck = mVit[1];
    pruef('sie benutzt einen PLATZHALTER ($feld), keine Namensliste', /\$feld/.test(ohneKommentar.slice(ohneKommentar.indexOf('"vitals"'), ohneKommentar.indexOf('"vitals"') + 400)));
    // Die Regelsprache nachbilden, so weit dieser eine Ausdruck sie braucht.
    const bewerte = (wert) => {
      const newData = {
        isString: () => typeof wert === 'string',
        isNumber: () => typeof wert === 'number' && Number.isFinite(wert),
        isBoolean: () => typeof wert === 'boolean',
        val: () => wert,
      };
      return new Function('newData', 'return (' + ausdruck + ');')(newData);
    };
    const { CloudPublisher } = require(path.join(WURZEL, 'bridge/src/cloud.js'));
    const f = model.normalizeFrame({
      deviceId: 'NARK', deviceModel: 'Beatmung', deviceRole: 'anesthesia', patientId: '7',
      species: 'katze', weightKg: 4.3, ts: Date.now(),
      vitals: { hr: 150, spo2: 97, etco2: 75, fico2: 8, af: 16, temp: 37.9, temp2: 36.4, pi: 3,
        ppeak: 7, pmean: 4.3, peep: 3, vte: 36, mv: 0.58, compl: 9, fio2: 95, etAgent: 1.4,
        fiAgent: 1.6, mac: 1.08, etn2o: 0, ibp: 68, nibp: { sys: 113, dia: 44 } },
      isoPct: 1.8, o2Flow: 1, ventMode: 'VCV', ventParams: { vt: 40, af: 14, ie: '1:2', peep: 3 },
    }).frame;
    const pats = matching.mergePatients([{ deviceId: 'NARK', frame: f }], {});
    const cp = new CloudPublisher({ dbUrl: 'https://x.example.com', authFile: null });
    const snap = cp._buildSnapshot(pats, [], {});
    const vit = snap.patients[Object.keys(snap.patients)[0]].vitals;
    const felder = Object.keys(vit);
    pruef('das Fern-Paket traegt alle Kanaele (>= 25 Felder)', felder.length >= 25, String(felder.length));
    NEU.forEach((k) => pruef('Regel nimmt "' + k + '" an', vit[k] === null || bewerte(vit[k]) === true, JSON.stringify(vit[k])));
    const abgewiesen = felder.filter((k) => vit[k] !== null && bewerte(vit[k]) !== true);
    pruef('KEIN einziges Feld des echten Pakets wird abgewiesen', abgewiesen.length === 0, abgewiesen.join());
    /* Gegenprobe: die Regel ist nicht einfach immer wahr — sonst waere der Test wertlos. */
    pruef('ein Objekt WIRD abgewiesen (die Regel ist scharf)', bewerte({ a: 1 }) !== true);
    pruef('ein ueberlanger Text WIRD abgewiesen', bewerte('x'.repeat(2001)) !== true);
    pruef('eine Zahl wird angenommen', bewerte(42) === true);
  }
}

/* ================================================================= 10 */
abschnitt('10) Bestehendes bleibt unveraendert (LifeVet / uMEC12)');
const hl7src = fs.readFileSync(path.join(WURZEL, 'bridge/src/adapters/hl7.js'), 'utf8');
[["'101': 'hr'", 'HF 101'], ["'160': 'spo2'", 'SpO2 160'], ["'170': 'sys'", 'NIBP 170'],
 ["'220': 'etco2'", 'EtCO2 220'], ["'221': 'fico2'", 'FiCO2 221'], ["'200': 'temp'", 'T1 200'],
].forEach(([s, n]) => pruef('CODE_MAP unveraendert: ' + n, hl7src.indexOf(s) >= 0));
pruef('t2 zeigt WEITERHIN auf temp (nicht auf temp2)', /t1: 'temp', t2: 'temp'/.test(hl7src));
pruef('temp2 gibt es trotzdem als eigenes Label', /temp2: 'temp2'/.test(hl7src));
['ppeak', 'peep', 'vte', 'mv', 'fio2', 'etAgent', 'fiAgent', 'mac', 'pi'].forEach((k) => {
  pruef('LABEL_MAP kennt ' + k, new RegExp("[: ]'" + k + "'").test(hl7src));
});
pruef('MDC-Bezeichner fuer den Atemwegsdruck eingetragen', hl7src.indexOf('mdc_press_away_insp_max') >= 0);
pruef('cmH2O wird gegen mbar und kPa geprueft', hl7src.indexOf("soll === 'cmH2O'") >= 0 && hl7src.indexOf('10.197') >= 0);
pruef('Liter werden in ml umgerechnet', hl7src.indexOf("soll === 'ml'") >= 0);
/* Der Kern der Zusage "LifeVet und uMEC nicht stoeren": es wurde KEIN privater Zahlencode
 * fuer die neuen Kanaele erfunden. Zahlen sind belegt, Bezeichner sind selbstbeschreibend. */
const codeMapBlock = hl7src.slice(hl7src.indexOf('const CODE_MAP'), hl7src.indexOf('// Label-Fallback'));
pruef('KEIN geratener Zahlencode fuer die neuen Kanaele', !/ppeak|peep|'vte'|etAgent|fio2/.test(codeMapBlock));

/* ================================================================= 11 */
abschnitt('11) Die Kurvenformeln rechnen wirklich (nicht nur vorhanden)');
const appHtml = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
function holeFunktion(name) {
  const i = appHtml.indexOf('function ' + name + '(');
  if (i < 0) return null;
  let tiefe = 0, gestartet = false;
  for (let j = i; j < appHtml.length; j++) {
    const c = appHtml[j];
    if (c === '{') { tiefe++; gestartet = true; }
    else if (c === '}') { tiefe--; if (gestartet && tiefe === 0) return appHtml.slice(i, j + 1); }
  }
  return null;
}
const srcCapno = holeFunktion('wCapno');
pruef('wCapno ist auffindbar', !!srcCapno);
if (srcCapno) {
  const wCapno = new Function('return ' + srcCapno)();
  const grund0 = wCapno(0.1, 'normal', 40, 0);
  const grund8 = wCapno(0.1, 'normal', 40, 8);
  pruef('FiCO2 8 hebt die Kapno-GRUNDLINIE an (das Bild vom Foto)', grund8 > grund0 + 0.05, grund0 + ' -> ' + grund8);
  pruef('FiCO2 0 -> Grundlinie auf der Nulllinie', Math.abs(grund0 - 0.12) < 0.001);
  const plateau40 = wCapno(0.6, 'normal', 40, 0), plateau75 = wCapno(0.6, 'normal', 75, 0);
  pruef('hoeheres EtCO2 -> hoeheres Plateau', plateau75 > plateau40);
  pruef('Plateau ist flach (Ende = Mitte)', Math.abs(wCapno(0.5, 'normal', 40, 0) - wCapno(0.9, 'normal', 40, 0)) < 0.001);
  pruef('Haifischflosse hat KEIN flaches Plateau', wCapno(0.9, 'shark', 40, 0) > wCapno(0.5, 'shark', 40, 0) + 0.05);
  pruef('flache Kurve bleibt flach', wCapno(0.1, 'flat', 40, 0) === wCapno(0.9, 'flat', 40, 0));
  pruef('Kurve bleibt in der Bahn (0..1)', [0, 0.3, 0.5, 0.95].every((p) => {
    const y = wCapno(p, 'normal', 75, 10); return y >= 0 && y <= 1;
  }));
}
const srcPaw = holeFunktion('wPaw');
pruef('wPaw ist auffindbar', !!srcPaw);
if (srcPaw) {
  const stubs = { ventVal: (k) => ({ peep: 3, ie: '1:2', pinsp: 10 }[k]), vnum: (v) => (typeof v === 'number' ? v : parseFloat(String(v)) || null) };
  function pawFuer(modus, r) {
    const state = { dev: { mode: modus } }, mon = { beatN: 0 };
    const f = new Function('state', 'mon', 'ventVal', 'vnum', 'return ' + srcPaw)(state, mon, stubs.ventVal, stubs.vnum);
    return (ph) => f(ph, r);
  }
  const rV = { peep: 3, ppeak: 12 };
  const vcv = pawFuer('vcv', rV), pcv = pawFuer('pcv', rV);
  pruef('VCV: Druck steigt als RAMPE (Mitte < Ende der Inspiration)', vcv(0.15) < vcv(0.3), vcv(0.15) + ' / ' + vcv(0.3));
  pruef('PCV: Druck steht als RECHTECK', Math.abs(pcv(0.15) - pcv(0.3)) < 0.01, pcv(0.15) + ' / ' + pcv(0.3));
  pruef('Exspiration faellt auf PEEP zurueck', vcv(0.8) < vcv(0.3));
  pruef('hoeherer Spitzendruck -> hoeherer Ausschlag', pawFuer('pcv', { peep: 3, ppeak: 20 })(0.2) > pcv(0.2));
  pruef('PEEP hebt die Grundlinie', pawFuer('pcv', { peep: 8, ppeak: 20 })(0.8) > pcv(0.8));
  pruef('Spontanmodus zeigt den Sog VOR dem Hub', pawFuer('psv', rV)(0.01) < pawFuer('psv', rV)(0.3));
  pruef('Kurve bleibt in der Bahn (0..1)', [0, 0.2, 0.5, 0.9].every((p) => { const y = vcv(p); return y >= 0 && y <= 1; }));
}
const srcFlow = holeFunktion('wFlow');
if (srcFlow) {
  const f = new Function('state', 'ventVal', 'return ' + srcFlow)({ dev: { mode: 'vcv' } }, (k) => ({ ie: '1:2' }[k]));
  pruef('Flow: Einatmung positiv, Ausatmung negativ', f(0.1, {}) > 0.5 && f(0.5, {}) < 0.5);
  pruef('Obstruktion: Ausatemfluss erreicht die Null NICHT (Air-Trapping)',
    Math.abs(f(0.95, { capno: 'shark' }) - 0.5) > Math.abs(f(0.95, { capno: 'normal' }) - 0.5));
}

/* ================================================================= 12 */
abschnitt('12) App und Fern-Web-App zeigen dasselbe');
const webWurzel = path.join(WURZEL, '..', '..', 'canis-vetpharm');
const webApp = path.join(webWurzel, 'canis-anaesthesie/index.html');
const webModul = path.join(webWurzel, 'shared/geraete-profile.js');
if (!fs.existsSync(webApp)) {
  console.log('  (uebersprungen: die Web-App liegt nicht neben diesem Ordner)');
} else {
  const web = fs.readFileSync(webApp, 'utf8');
  ['__setMesswerte', '__setGeraetProfil', 'geraete-profile.js', 'renderDevHead', 'wPaw', 'istNachziehen', 'grenzeOf']
    .forEach((s) => pruef('Web-App enthaelt ' + s, web.indexOf(s) >= 0));
  pruef('Web-App behaelt den Fern-Seam (applyLive)', web.indexOf('function applyLive(') >= 0);
  pruef('Web-App behaelt den Saalwechsel (neuerPatient)', web.indexOf('function neuerPatient(') >= 0);
  pruef('Fern-Seam speist die neuen Messwerte ein', /__setMesswerte\(mw\)/.test(web));
  /*
   * DER WICHTIGSTE PUNKT DIESES ABSCHNITTS.
   * Eine Kopie neben dem Original ist eine Zeitbombe mit Zufallszuender: bridge/src/anaes.js zog
   * jahrelang eine ANDERE anaes-data.js als der Browser, und es fiel erst auf, als vier neue
   * Tierarten in der einen Datei standen und die andere sie nicht sah. Diese Pruefung erzwingt,
   * dass die Fern-Web-App exakt dieselbe Geraetebeschreibung benutzt wie die Station.
   */
  const quellModul = fs.readFileSync(path.join(WURZEL, 'ui/shared/geraete-profile.js'), 'utf8');
  pruef('Web-App hat das Geraeteprofil-Modul', fs.existsSync(webModul));
  if (fs.existsSync(webModul)) {
    pruef('... und es ist ZEICHENGLEICH mit der Quelle', fs.readFileSync(webModul, 'utf8') === quellModul,
      'Kopie weicht ab -> Station und Fern-Ansicht zeigen verschiedene Geraete');
  }
  const quellDaten = fs.readFileSync(path.join(WURZEL, 'ui/app/anaes-data.js'), 'utf8');
  pruef('anaes-data.js ist zeichengleich', fs.readFileSync(path.join(webWurzel, 'canis-anaesthesie/anaes-data.js'), 'utf8') === quellDaten);
}

/* App-Verdrahtung: der Spiegel muss AUFRUFBAR sein, nicht nur vorhanden.
 * (Der Veta-5-Spiegel war einmal vollstaendig da und trotzdem tot, weil state/render nicht auf
 *  window lagen — seitdem wird das ausdruecklich geprueft.) */
abschnitt('12b) Die Bruecken zur Station sind nach aussen sichtbar');
['window.__setMesswerte=', 'window.__setGeraetProfil=', 'window.curGeraet=', 'window.state=']
  .forEach((s) => pruef('index.html legt ' + s.replace('window.', '').replace('=', '') + ' auf window', appHtml.indexOf(s) >= 0));
const liveJs = fs.readFileSync(path.join(WURZEL, 'ui/vetstation-live.js'), 'utf8');
pruef('vetstation-live.js speist die Messwerte ein', liveJs.indexOf('__setMesswerte') >= 0);
pruef('vetstation-live.js meldet das erkannte Modell', liveJs.indexOf('__setGeraetProfil') >= 0);
pruef('vetstation-live.js ordnet auch Paw-/Flow-Kurven einer Bahn zu', /press_away\|paw/.test(liveJs));
pruef('index.html laedt das Profilmodul', appHtml.indexOf('shared/geraete-profile.js') >= 0);

/* ================================================================= 13 */
abschnitt('13) Cockpit: eine Kurve nur, wo sie etwas aussagt (1.4.1)');
/*
 * aktiveBahnen() liegt in index.html und braucht curGeraet(). Statt die Funktion nachzubauen
 * (dann prueft der Test seine eigene Kopie), wird sie hier mit einem Stub-curGeraet aus der
 * Datei geholt und gerechnet — dieselbe Bauart wie Block 11.
 */
const srcBahnen = holeFunktion('aktiveBahnen');
pruef('aktiveBahnen ist auffindbar', !!srcBahnen);
if (srcBahnen) {
  const bahnenFuer = (mon, nark) => {
    const g = VG.zusammen(VG.nachId(mon), nark ? VG.nachId(nark) : null);
    return new Function('curGeraet', 'return ' + srcBahnen)(() => g)();
  };
  const veta = bahnenFuer('mindray-umec12-vet', 'mindray-veta-5-plus');
  pruef('uMEC12 + Veta 5: EKG, Pleth, CO2, Paw', veta.join() === 'ekg,pleth,capno,paw', veta.join());
  pruef('... KEINE Impedanz-Atemkurve neben dem Kapnogramm', veta.indexOf('resp') < 0);
  const lvm = bahnenFuer('eickemeyer-lifevet-m', null);
  pruef('LifeVet M (kein CO2-Modul): keine Kapno-Bahn', lvm.indexOf('capno') < 0, lvm.join());
  pruef('... dafuer die Impedanz-Atemkurve (einzige Atemquelle)', lvm.indexOf('resp') >= 0, lvm.join());
  const pm = bahnenFuer('petmap', null);
  pruef('petMAP (nur Blutdruck): GAR KEINE Kurve statt einer leeren schwarzen Flaeche', pm.length === 0, pm.join());
  const mech = bahnenFuer('mindray-umec12-vet', 'mechanisch-vet-narkose');
  pruef('rein mechanisches Narkosegeraet fuegt keine Druckkurve hinzu', mech.indexOf('paw') < 0, mech.join());
  const kap = bahnenFuer('mindray-umec12-vet', 'kapnograf-standalone');
  pruef('eigenstaendiger Kapnograf bringt keine Paw-Bahn mit', kap.indexOf('paw') < 0, kap.join());
}
const srcTitel = holeFunktion('geraetTitel');
pruef('geraetTitel ist auffindbar', !!srcTitel);
if (srcTitel) {
  const titelFuer = (mon, nark, slot) => {
    const g = VG.zusammen(VG.nachId(mon), nark ? VG.nachId(nark) : null);
    return new Function('curGeraet', 'VG', 'return ' + srcTitel)(() => g, VG)(slot);
  };
  /* Der Wunsch war ausdruecklich: auf dem Geraeteschild steht, WAS es ist — nicht der
   * Aufdruck eines fremden Apparats. Ein Herstellername auf einem Bild, das die Station
   * selbst zeichnet, laesst den Betrachter glauben, er sehe den echten Bildschirm. */
  pruef('Schild nennt das virtuelle Geraet, nicht den Hersteller',
    titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'mon') === 'Monitor & Kapnograph');
  pruef('Monitor ohne CO2-Modul heisst nur "Monitor"',
    titelFuer('eickemeyer-lifevet-m', null, 'mon') === 'Monitor', titelFuer('eickemeyer-lifevet-m', null, 'mon'));
  pruef('Veta 5 Plus = Narkose- & Beatmungsgeraet mit Kapnograph',
    titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'nark') === 'Narkose- & Beatmungsgerät mit Kapnograph');
  pruef('eigenstaendiger Kapnograf heisst Kapnograph, nicht Beatmungsgeraet',
    titelFuer('mindray-umec12-vet', 'kapnograf-standalone', 'nark') === 'Kapnograph',
    titelFuer('mindray-umec12-vet', 'kapnograf-standalone', 'nark'));
  pruef('rein mechanisches Geraet heisst schlicht Narkosegeraet',
    titelFuer('mindray-umec12-vet', 'mechanisch-vet-narkose', 'nark') === 'Narkosegerät',
    titelFuer('mindray-umec12-vet', 'mechanisch-vet-narkose', 'nark'));
  ['mindray', 'Mindray', 'uMEC', 'Veta', 'Draeger', 'EDAN'].forEach((h) => {
    pruef('kein "' + h + '" im Schild', [
      titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'mon'),
      titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'nark'),
      titelFuer('edan-im-vet', 'draeger-narkose', 'mon'),
      titelFuer('edan-im-vet', 'draeger-narkose', 'nark'),
    ].every((t) => t.indexOf(h) < 0));
  });
}

/* ================================================================= 14 */
abschnitt('14) Alarmgrenzen stellt die App selbst (1.4.1)');
const srcAnp = holeFunktion('alarmAnpassung');
pruef('alarmAnpassung ist auffindbar', !!srcAnp);
if (srcAnp) {
  const anpFuer = (alter, breed) => {
    const state = { age: alter };
    const curBreed = () => breed || null;
    return new Function('state', 'curBreed', 'VB', 'return ' + srcAnp)(state, curBreed, null)();
  };
  const leer = anpFuer('adult', null);
  pruef('erwachsenes Tier ohne Rassebefund: keine Anpassung', leer.length === 0);
  const jung = anpFuer('pediatric', null);
  pruef('Jungtier wird erkannt', jung.length === 1 && jung[0].id === 'jung');
  pruef('... Frequenzobergrenze steigt (Auswurf haengt an der Frequenz)', jung[0].hr([60, 140])[1] === 175);
  pruef('... Spitzendruck wird gedeckelt (kleine Lunge, Volutrauma)', jung[0].ppeak([6, 15])[1] === 12);
  pruef('... Temperaturalarm kommt frueher', jung[0].temp([37.5, 39.2])[0] > 37.5);
  const alt = anpFuer('senior', null);
  pruef('geriatrisch: Blutdruckuntergrenze steigt', alt[0].map([70, 120])[0] === 75);
  const boas = anpFuer('adult', { groups: ['brachy'], conditions: ['boas'] });
  pruef('brachyzephal wird ueber b.groups erkannt (nicht ueber groupsOf)', boas.length === 1 && boas[0].id === 'boas');
  pruef('... SpO2 alarmiert frueher', boas[0].spo2([95, 100])[0] === 96);
  pruef('... EtCO2-Obergrenze enger', boas[0].etco2([30, 55])[1] === 50);
  const wind = anpFuer('adult', { groups: ['sighthound'], conditions: ['sighthound'] });
  pruef('Windhund-Typ: Temperaturalarm frueher', wind.length === 1 && wind[0].temp([37.5, 39.2])[0] === 37.9);
  const hcm = anpFuer('adult', { groups: [], conditions: ['hcm-cat'] });
  pruef('HCM-Katze: Frequenzobergrenze runter (Diastole ist die Fuellzeit)', hcm[0].hr([100, 180])[1] === 160);
  pruef('... und Blutdruckuntergrenze mindestens 70', hcm[0].map([60, 120])[0] === 70);
  const beides = anpFuer('senior', { groups: ['brachy'], conditions: [] });
  pruef('mehrere Befunde greifen zusammen', beides.length === 2);
  pruef('jede Anpassung nennt ihre Begruendung im Klartext', beides.every((a) => a.regel && a.regel.length > 20));
  /* Die Grenze darf NIE weiter werden als das Normband — eine Automatik, die einen Alarm
   * spaeter ausloest als die Artnorm, ist genau das Gegenteil dessen, was hier gewollt ist. */
  const alle = ['pediatric', 'senior', 'adult'].flatMap((a) =>
    [null, { groups: ['brachy'] }, { groups: ['sighthound'] }, { conditions: ['hcm-cat'] }].map((b) => anpFuer(a, b)));
  let weiter = 0;
  alle.flat().forEach((a) => {
    ['hr', 'spo2', 'etco2', 'temp', 'map', 'ppeak'].forEach((k) => {
      if (typeof a[k] !== 'function') return;
      const basis = { hr: [60, 140], spo2: [95, 100], etco2: [30, 55], temp: [37.5, 39.2], map: [70, 120], ppeak: [6, 15] }[k];
      const neu = a[k](basis.slice());
      if (neu[0] < basis[0] || neu[1] > basis[1]) {
        // Die Frequenzobergrenze beim Jungtier ist die EINE gewollte Ausweitung: eine hohe
        // Frequenz ist dort physiologisch, ein Alarm darauf waere ein Fehlalarm im Minutentakt.
        if (!(a.id === 'jung' && k === 'hr')) weiter++;
      }
    });
  });
  pruef('keine Anpassung zieht eine Grenze WEITER als die Artnorm (ausser Jungtier-Frequenz)', weiter === 0, weiter + ' Faelle');
}
pruef('Alarmgrenzen werden NICHT mehr gespeichert (sie gehoeren zum Patienten)',
  appHtml.indexOf('grenzen:state.alarmGrenzen') < 0 && appHtml.indexOf('state.alarmGrenzen') < 0);
/* Auf die KNOPF-IDs pruefen, nicht auf die Woerter: die Begruendung, WARUM ein Knopf weg ist,
 * gehoert als Kommentar in die Datei — sonst baut ihn der naechste Leser wieder ein. */
['dbAlim', 'dbHold', 'dbFall', 'devBtns', 'alimGrid', 'renderAlim', 'renderDevBtns', 'mon._hold'].forEach((s) => {
  pruef('entfernt: ' + s, appHtml.indexOf(s) < 0);
});
pruef('die Falluhr laeuft stattdessen mit dem Datenfluss', appHtml.indexOf('__setFallLauf') >= 0);
pruef('vetstation-live.js setzt die Falluhr', liveJs.indexOf('__setFallLauf') >= 0);
pruef('Cockpit misst seine Hoehe zur Laufzeit', appHtml.indexOf('function cockpitHoehe') >= 0);
pruef('Eingabefelder verschwinden im Livebetrieb', appHtml.indexOf('liveDaten()') >= 0);
pruef('vetstation-live.js schickt ALLE Zahlenkanaele (keine feste Liste)',
  /Object\.keys\(v\)\.forEach/.test(liveJs) && liveJs.indexOf('UEBER_EINGABE') >= 0);

/* ================================================================= 14b */
abschnitt('14b) Die Zahl steht bei ihrer Kurve — und KEIN Wert faellt dabei durch (1.4.2)');
/*
 * Die Zuordnung Bahn -> Werte ist eine reine Datenregel und laesst sich hier vollstaendig
 * durchrechnen. Das Entscheidende ist nicht, dass es huebsch aussieht, sondern dass jeder Kanal
 * GENAU EINMAL im Bild steht: zweimal laedt zum Vergleichen ein und laesst einen Unterschied
 * suchen, den es nicht gibt — keinmal ist ein verschwundener Messwert.
 */
const mLane = /var LANE_WERTE=(\{[^;]*\});/.exec(appHtml);
pruef('LANE_WERTE ist auffindbar', !!mLane);
if (mLane && srcBahnen) {
  const LANE_WERTE = new Function('return ' + mLane[1])();
  VG.KURVEN.forEach((k) => pruef('Bahn "' + k.id + '" hat einen zugeordneten Wert', Array.isArray(LANE_WERTE[k.id]) && LANE_WERTE[k.id].length > 0));
  Object.keys(LANE_WERTE).forEach((b) => {
    pruef('LANE_WERTE.' + b + ' zeigt auf echte Kanaele', LANE_WERTE[b].every((id) => !!VG.kanal(id)));
    pruef('... und auf eine echte Bahn', !!VG.kurve(b));
  });
  const paare = [['mindray-umec12-vet', 'mindray-veta-5-plus'], ['eickemeyer-lifevet-10c', 'mindray-wato-ex35-vet'],
    ['eickemeyer-lifevet-m', null], ['petmap', null], ['universal-monitor', 'universal-narkose'],
    ['ge-datex-s5', 'draeger-narkose'], ['mindray-umec12-vet', 'kapnograf-standalone']];
  paare.forEach(([mon, nark]) => {
    const g = VG.zusammen(VG.nachId(mon), nark ? VG.nachId(nark) : null);
    const bahnen = new Function('curGeraet', 'return ' + srcBahnen)(() => g)();
    /* Genau die Rechnung, die renderLaneWerte macht: erster vorhandener Wert der Bahn ist der
     * Hauptwert, die weiteren sind Zweitwerte — und Zweitwerte gelten NUR als gezeigt, wenn die
     * Bahn hoch genug ist. Der Test rechnet beide Faelle durch (hohe und flache Bahn). */
    [true, false].forEach((zeigeZusatz) => {
      const inBahn = new Set();
      bahnen.forEach((b) => {
        const ids = (LANE_WERTE[b] || []).filter((i) => g.kanaele.indexOf(i) >= 0);
        if (!ids.length) return;
        inBahn.add(ids[0]);
        if (zeigeZusatz) ids.slice(1).forEach((i) => inBahn.add(i));
      });
      const kacheln = g.kanaele.filter((k) => !inBahn.has(k));
      const alle = [...inBahn, ...kacheln];
      const fehlend = g.kanaele.filter((k) => alle.indexOf(k) < 0);
      const doppelt = g.kanaele.filter((k) => inBahn.has(k) && kacheln.indexOf(k) >= 0);
      pruef(mon + (nark ? '+' + nark : '') + (zeigeZusatz ? ' (hohe Bahn)' : ' (flache Bahn)') + ': jeder Kanal genau einmal sichtbar',
        fehlend.length === 0 && doppelt.length === 0, 'fehlt: ' + fehlend.join() + ' doppelt: ' + doppelt.join());
    });
  });
  /* Ein Geraet ohne Kurven zeigt ALLES als Kachel — sonst waere die halbe Anzeige leer. */
  const pm = VG.zusammen(VG.nachId('petmap'), null);
  const pmB = new Function('curGeraet', 'return ' + srcBahnen)(() => pm)();
  pruef('ohne Kurve steht jeder Wert als Kachel', pmB.length === 0 && pm.kanaele.length > 0);
}
pruef('die Kurve endet VOR der Zahlenspalte (sonst laeuft die Linie unter die Zahl)',
  /var RESERVE=Math\.round\(\(mon\.reservePx\|\|206\)\*mon\.dpr\), WZ=/.test(appHtml) && appHtml.indexOf('i*(WZ/(b.length-1))') >= 0);
/* War frueher "laneH * 0,40". Eine Faustzahl trifft irgendwann daneben: bei 34 px Bahn ergab
 * sie eine 15er Schrift, die mit Kopfzeile und Innenabstand auf 34,25 px kam — ein Viertel-
 * pixel zu viel, und die Zahl wurde abgeschnitten. Jetzt wird der Platz verteilt statt
 * geschaetzt; Block 14f rechnet die Verteilung fuer jede Bahnhoehe nach. */
pruef('die Schriftgroesse wird aus dem freien Platz GERECHNET, nicht geschaetzt',
  !/laneH\*0\.40/.test(appHtml) && /var fz=Math\.max\(FZ_ENG,Math\.min\(FZ_MAX,Math\.floor\(frei\/1\.15\)\)\)/.test(appHtml) && appHtml.indexOf('--lane-fz') >= 0);
pruef('Alarmgrenzen sitzen absolut in der Ecke (sonst wird die Kopfzeile zweizeilig)',
  /\.mon-lane \.ml-kopf i\{position:absolute/.test(appHtml));
pruef('die feste Notfallleiste wird von der Cockpithoehe abgezogen',
  appHtml.indexOf("querySelector('.nf-dock')") >= 0 && /dockH=dr\.height/.test(appHtml));
pruef('helles Thema: Modellwahl und Erlaeuterung sind lesbar',
  /html\[data-theme="light"\] \.gwahl select\{background:#fff/.test(appHtml) && /html\[data-theme="light"\] \.gw-note b/.test(appHtml));

/* ================================================================= 14c */
abschnitt('14c) Ein Bildschirm, keine Rollbalken, eingetippt wird am Wert (1.4.3)');
pruef('die Zahlenspalte ist DECKEND (Kurve laeuft nicht darunter durch)',
  /\.mon-lanes\{[^}]*background:#05080d/.test(appHtml) && /\.mon-lane\{[^}]*background:#05080d/.test(appHtml));
pruef('die Leinwand reserviert die GEMESSENE Spaltenbreite, keine feste Zahl',
  appHtml.indexOf('mon.reservePx=host.getBoundingClientRect().width') >= 0
  && /RESERVE=Math\.round\(\(mon\.reservePx\|\|206\)\*mon\.dpr\)/.test(appHtml));
pruef('die alte Eingabezeile ist im Geraetefeld ausgeblendet',
  /\.ck-links \.mon-inputs\{display:none !important\}/.test(appHtml));
pruef('... bleibt aber im Baum — vetstation-live.js schreibt dort hinein',
  appHtml.indexOf('id="monInputs"') >= 0 && liveJs.indexOf("#monInputs input[data-p=") >= 0);
pruef('die rollende Rhythmusleiste ist ausgeblendet',
  /\.ck-links #rhythmChips\{display:none !important\}/.test(appHtml));
pruef('... und durch EIN Auswahlfeld ersetzt', appHtml.indexOf('id="rhySel"') >= 0 && appHtml.indexOf('function renderRhySel') >= 0);
pruef('... das die verborgenen Chips anklickt (der erprobte Weg bleibt)',
  /#rhythmChips \.chip\[data-r="'\+sel\.value\+'"\]/.test(appHtml));
pruef('getippt wird IN der Kachel', appHtml.indexOf("wertFeld(p, state.istVals[p.id], 'mt-in')") >= 0);
pruef('... und IN der Zahl an der Kurve', appHtml.indexOf("wertFeld(haupt, state.istVals[haupt.id], 'ml-in')") >= 0);
pruef('... und im ZWEITWERT der Bahn (sonst waere FiCO2 nicht eingebbar)',
  appHtml.indexOf("wertFeld(q, state.istVals[q.id], 'ml-in ml-zwin')") >= 0);
pruef('der Blutdruck bekommt zwei Felder (SYS/DIA), der Mitteldruck folgt daraus',
  appHtml.indexOf('function wertFeldPaar') >= 0 && /data-p="sys"[\s\S]{0,200}data-p="dia"/.test(appHtml));
pruef('die Schreibmarke ueberlebt den Neuaufbau', appHtml.indexOf('function fokusMerken') >= 0 && appHtml.indexOf('fokusZurueck(fok)') >= 0);
pruef('Getipptes wird ins verborgene Feld gespiegelt (ohne dessen Ereignis)',
  /#monInputs input\[data-p="'\+k\+'"\]/.test(appHtml) && appHtml.indexOf('h.value=roh') >= 0);
pruef('der Kopfbereich schrumpft auf dem Geraet-Reiter',
  /html\[data-view="geraet"\] \.sp-chip\{/.test(appHtml) && appHtml.indexOf("setAttribute('data-view', v)") >= 0);
/*
 * OPT_SENSOR: EINE Liste fuer Alarm UND Analyse. Zwei getrennte Listen haben genau den Fehler
 * erzeugt, den das Bildschirmfoto zeigte: "ART ↓ 0 mmHg — Hypotension" samt Ephedrin-Dosis fuer
 * ein Tier, an dem gar kein invasiver Druck gemessen wurde.
 */
{
  const mOpt = /var OPT_SENSOR=(\[[^\]]*\]);/.exec(appHtml);
  pruef('OPT_SENSOR ist auffindbar', !!mOpt);
  if (mOpt) {
    const OPT = new Function('return ' + mOpt[1])();
    ['ibp', 'pi', 'temp2', 'vte', 'ppeak', 'fio2', 'etAgent', 'peep'].forEach((k) =>
      pruef('optionaler Sensor erkannt: ' + k, OPT.indexOf(k) >= 0));
    /* Diese drei duerfen NIE darin stehen: dort ist die Null ein Befund. */
    ['hr', 'etco2', 'nibp', 'spo2'].forEach((k) =>
      pruef('bei "' + k + '" ist die Null ein BEFUND und muss alarmieren', OPT.indexOf(k) < 0));
    pruef('dieselbe Liste gilt fuer Alarm UND Analyse',
      (appHtml.match(/OPT_SENSOR\.indexOf\(p\.id\)>=0/g) || []).length >= 2);
    OPT.forEach((k) => pruef('OPT_SENSOR."' + k + '" ist ein echter Kanal', !!VG.kanal(k)));
  }
}

/* ================================================================= 14d */
abschnitt('14d) Bedienteil gross, Kurven flach und breit, Hellmodus lesbar (1.4.4)');
/*
 * Der Wunsch war deutlich: das Narkose- und Beatmungsgeraet muss GROSS sein, die Kurven duerfen
 * dafuer flacher und breiter werden. Der Grund liegt in der Bedienung — am Verdampfer wird
 * gedreht, die Modusknoepfe werden mitten in der Narkose getroffen, notfalls mit Handschuhen.
 * Eine Kurve dagegen liest man in der Waagerechten: Form, Anstieg, Plateau.
 */
pruef('die Geraetespalte ist deutlich breiter als die Analysespalte',
  /\.cockpit\{[^}]*grid-template-columns:minmax\(0,1\.9fr\) minmax\(258px,\.46fr\)/.test(appHtml));
/* Die Untergrenze steht jetzt an der Leinwand (110 px) statt am ganzen Block. Am Block war
 * sie eine ERLAUBNIS zum Stauchen: 140 px Kasten mit 210 px Inhalt, und die Wertekacheln
 * lagen im Narkosegeraet (gemessen bei 1400x900). Siehe Block 14f. */
pruef('die Kurvenflaeche darf flacher werden — aber nie flacher als ihr Inhalt',
  /\.ck-schirm\{[^}]*min-height:auto/.test(appHtml) && /\.ck-schirm \.mon-screen\{[^}]*min-height:110px/.test(appHtml));
[['svg.flowmeter{height:142px', 'Flowmeter 142 px hoch'],
 ['svg.vaporizer{height:142px;width:142px', 'Verdampfer 142 px'],
 ['.mc-step{width:34px;height:34px', 'Schrittknoepfe 34 px (mit Handschuh treffbar)'],
 ['.mc-modes button{padding:5px 11px;font-size:12px', 'Modusknoepfe gross genug'],
 ['.mc-toggle button{height:30px', 'Manuell/Auto gross genug'],
 ['.mc-flush{height:34px', 'O2-Flush gross genug'],
].forEach(([s, n]) => pruef(n, appHtml.indexOf(s) >= 0));
/*
 * DER FLOWMETER WAR 30 PUNKTE BREIT (gemessen 05.08.2026: 30 x 96 auf dem Bildschirm).
 * Eine 30 Punkte breite Saeule trifft man mit der Maus kaum und mit dem Finger gar nicht.
 * Die Zeichnung ist deshalb von 66 auf 96 Einheiten verbreitert worden — der Test rechnet
 * nach, wie breit das AUF DEM BILDSCHIRM wird, statt nur zu pruefen, dass die Zahl da steht.
 */
{
  const mVb = /viewBox="0 0 (\d+) '\+H\+'"/.exec(appHtml);
  pruef('Flowmeter-Zeichenflaeche ist verbreitert', !!mVb && Number(mVb[1]) >= 96, mVb ? mVb[1] : 'nicht gefunden');
  if (mVb) {
    const breite = 142 * (Number(mVb[1]) / 210);   // Hoehe aus dem CSS x Seitenverhaeltnis
    pruef('… ergibt auf dem Bildschirm >= 60 px Greifbreite (vorher 30)', breite >= 60, Math.round(breite) + ' px');
  }
  pruef('die GANZE Flaeche ist Greifflaeche, nicht nur die gezeichnete Saeule',
    /<rect x="0" y="0" width="96" height="'\+H\+'" fill="transparent"\/>/.test(appHtml)
    && appHtml.indexOf('<rect x="0" y="0" width="136" height="136" fill="transparent"/>') >= 0);
  pruef('der Schwimmer ist groesser (r 11 -> 15)', /r="15" fill="#ff4d4d"/.test(appHtml));
  pruef('der Verdampferzeiger ist dicker (4,5 -> 6)', /stroke="#e23b3b" stroke-width="6"/.test(appHtml));
  pruef('Touchscreen: die Wischgeste geht an den Regler, nicht an die Seite',
    /svg\.flowmeter,\.machine svg\.vaporizer\{touch-action:none/.test(appHtml));
  pruef('beide Regler melden sich als Schieberegler (Screenreader/Tastatur)',
    (appHtml.match(/role="slider"/g) || []).length >= 2);
  pruef('die Wertekacheln passen in EINE Reihe (Hoehe fuer die Regler)',
    /grid-template-columns:repeat\(auto-fit,minmax\(86px,1fr\)\)/.test(appHtml));
  /* Der Regler steht NEBEN seiner Beschriftung statt darueber — so wird er hoeher, ohne dass
   * der ganze Block hoeher wird. Gemessen: Bedienteil 190 px trotz 142-px-Reglern. */
  pruef('Regler und Beschriftung stehen nebeneinander (mc-knob)',
    /\.ck-links \.mc-knob\{display:grid/.test(appHtml) && appHtml.indexOf('class="mc-item mc-knob"') >= 0);
}
pruef('der APL-Hinweis ist wieder da (er passt jetzt)', !/\.ck-links \.mc-hint\{display:none\}/.test(appHtml));
pruef('die Wertekacheln sind groesser geworden', /\.ck-links \.mon-tiles \.mt-v\{font-size:22px/.test(appHtml));
/*
 * HELLMODUS. Das Geraetebild bleibt in BEIDEN Schemata dunkel — ein Patientenmonitor ist
 * dunkel, und ein heller waere im OP nicht lesbar. Gemessen 05.08.2026: im hellen Schema kam
 * die Wertekachel ganz OHNE Hintergrund heraus (backgroundColor transparent), und damit stand
 * bernsteinfarbene Schrift auf weissem Grund — Kontrast 1,3 statt 10. Welche fremde Regel den
 * Grund wegnimmt, ist gleichgueltig; deshalb steht hier !important.
 */
pruef('Wertekacheln bleiben in BEIDEN Schemata dunkel', /background:linear-gradient\(90deg,color-mix[^;]*\) !important/.test(appHtml));
/*
 * DIESE ZEILE NAGELTE BIS ZUM 17.08.2026 GENAU DEN FEHLER FEST.
 *
 * Sie verlangte woertlich "background:rgba(255,77,77,.16) !important" — also die
 * Kurzschreibweise, die background-image auf none setzt und damit den deckenden Grund #0b1017
 * der gesunden Kachel WEGNIMMT. Unter der Ueberschrift "bleiben in BEIDEN Schemata dunkel"
 * stand damit die Forderung, dass die Alarmkachel eben NICHT dunkel bleibt. Gemessen im hellen
 * Schema: Kontrast 1,93 statt 7,56 — ausgerechnet die alarmierende Kachel war die
 * unleserlichste des Bildes.
 *
 * Jetzt wird nicht mehr eine bestimmte Farbe verlangt, sondern das, worauf es ankommt: im
 * Alarmgrund MUSS eine deckende Grundfarbe stehenbleiben. Bewusst als POSITIVE Pruefung auf dem
 * herausgeschnittenen Regelblock — eine Negativpruefung ("kommt nicht mehr vor") wuerde am
 * Begruendungskommentar darueber anschlagen, weil Quellpruefungen in diesem Projekt auch
 * Kommentare lesen.
 */
{
  const iAlarm = appHtml.indexOf('.ck-links .mon-tiles .mon-tile.alarm{');
  const block = iAlarm >= 0 ? appHtml.slice(iAlarm, appHtml.indexOf('}', iAlarm) + 1) : '';
  pruef('... auch im Alarmzustand (der deckende Grund #0b1017 bleibt DRIN)',
    iAlarm >= 0 && /background:[^;}]*#0b1017[^;}]*!important/.test(block),
    'Alarmblock: ' + block.replace(/\s+/g, ' ').slice(0, 150));
}
pruef('die Zahlenspalte ebenfalls', /\.mon-lanes\{[^}]*background:#05080d !important/.test(appHtml));
pruef('Hellmodus: "alles im Normbereich" ist lesbar', /html\[data-theme="light"\] \.assess-ok\{color:#0a5c3a/.test(appHtml));
pruef('Hellmodus: die Vertrauens-Marken sind lesbar',
  /html\[data-theme="light"\] \.gw-v\.belegt/.test(appHtml)
  && /html\[data-theme="light"\] \.gw-v\.wahrscheinlich/.test(appHtml)
  && /html\[data-theme="light"\] \.gw-v\.unbestaetigt/.test(appHtml));
pruef('Reiterleiste und Hinweiszeile geben auf dem Geraet-Reiter Hoehe ab',
  /html\[data-view="geraet"\] \.tab\{height:30px/.test(appHtml) && /html\[data-view="geraet"\] \.disc\{padding:3px 0\}/.test(appHtml));

/* ================================================================= 14e */
abschnitt('14e) Sauerstoff und Verdampfer lassen sich WIRKLICH ziehen (1.4.5)');
/*
 * DER FEHLER, DEN DIESER BLOCK FESTNAGELT (gemessen im Browser am 05.08.2026):
 * dragCtrl bekam frueher das ELEMENT und merkte es sich. Beim Ziehen ruft der Rueckruf aber
 * renderMachine() auf, und das baut die Geraeteleiste per innerHTML NEU — das gemerkte Element
 * ist danach aus dem Baum. Jeder weitere pointermove rechnete mit einem Rechteck von 0 x 0:
 * sy = 0, Division durch null, frac = -Infinity, gedeckelt auf 0.
 * GEMESSEN: Ziehen ins obere Viertel ergab O2 = 0,0 statt 7,5; Drehen nach rechts UND nach
 * links ergab beide Male 6,0. Der Regler war also nicht "zu klein" — er war kaputt, sobald man
 * den Finger bewegte. Ein Groessen-Test allein haette das nie gefunden.
 */
const srcDrag = holeFunktion('dragCtrl');
pruef('dragCtrl ist auffindbar', !!srcDrag);
if (srcDrag) {
  pruef('dragCtrl nimmt einen SELEKTOR, kein Element', /function dragCtrl\(auswahl, onMove\)/.test(srcDrag));
  pruef('der Horcher haengt an der Leiste, die nicht ersetzt wird', /host\.addEventListener\('pointerdown'/.test(srcDrag));
  pruef('je Regler nur EIN Horcher, auch nach Neuaufbau', /if\s*\(host\.__drag\[auswahl\]\)\s*return;/.test(srcDrag));
  pruef('auch pointercancel beendet das Ziehen (Finger verlaesst den Schirm)', /pointercancel/.test(srcDrag));

  /* Jetzt wirklich durchspielen: Element beim Zeigen greifen, dazwischen "neu bauen",
   * und pruefen, dass die Bewegung das FRISCHE Element bekommt. */
  let neuGebaut = 0;
  const frisch = () => ({ __id: 'frisch' + (++neuGebaut), getBoundingClientRect: () => ({ top: 0, left: 0, width: 65, height: 142 }) });
  const altesDetachtes = { __id: 'alt', getBoundingClientRect: () => ({ top: 0, left: 0, width: 0, height: 0 }) };
  const host = {
    __drag: null,
    _h: {},
    addEventListener(t, f) { this._h[t] = f; },
    querySelector() { return frisch(); },
  };
  const doc = { _h: {}, addEventListener(t, f) { this._h[t] = f; }, removeEventListener(t) { delete this._h[t]; } };
  const bekommen = [];
  const drag = new Function('$', 'document', 'return ' + srcDrag)(() => host, doc);
  drag('.flowmeter', (e, el) => { bekommen.push(el.getBoundingClientRect().height); });
  host._h.pointerdown({ target: { closest: () => altesDetachtes }, preventDefault() {}, pointerId: 1 });
  pruef('schon der erste Griff holt das Element frisch (ein Weg, kein Sonderfall)',
    bekommen.length === 1 && bekommen[0] === 142, JSON.stringify(bekommen));
  // Zwischen den Bewegungen wird die Leiste neu gebaut — genau das war der Ausloeser.
  doc._h.pointermove({ clientY: 40 });
  doc._h.pointermove({ clientY: 20 });
  pruef('jede Bewegung bekommt ein FRISCHES Element (nie 0 x 0)',
    bekommen.length === 3 && bekommen.every((h) => h === 142), JSON.stringify(bekommen));
  pruef('... und es wird bei JEDEM Schritt neu gesucht', neuGebaut === 3, String(neuGebaut));
  doc._h.pointerup();
  pruef('nach dem Loslassen horcht nichts mehr mit', !doc._h.pointermove && !doc._h.pointerup);
  host.__drag = null;
  const zweimal = new Function('$', 'document', 'return ' + srcDrag)(() => host, doc);
  zweimal('.flowmeter', () => {}); zweimal('.flowmeter', () => {});
  pruef('zweimaliges Einhaengen legt keinen zweiten Horcher an', host.__drag['.flowmeter'] === 1);
}
/* Die Rueckrufe muessen das uebergebene Element benutzen — nicht wieder eines aus der Closure. */
pruef('der O2-Rueckruf rechnet mit dem uebergebenen Element',
  /dragCtrl\('\.flowmeter', function\(e, el\)\{[\s\S]{0,120}el\.getBoundingClientRect\(\)/.test(appHtml));
pruef('der Verdampfer-Rueckruf ebenfalls',
  /dragCtrl\('\.vaporizer', function\(e, el\)\{[\s\S]{0,120}el\.getBoundingClientRect\(\)/.test(appHtml));
pruef('ein Rechteck ohne Hoehe wird abgefangen (statt durch null zu teilen)',
  (appHtml.match(/if\(!r\.height\) return;/g) || []).length >= 2);
/* Groesse und Greifbarkeit — der zweite Teil des Wunsches. */
pruef('Flowmeter und Verdampfer sind 142 px gross',
  /svg\.flowmeter\{height:142px/.test(appHtml) && /svg\.vaporizer\{height:142px;width:142px/.test(appHtml));
pruef('die Regler stehen QUER (Regler links, Wert rechts) — Breite statt Hoehe',
  /\.ck-links \.mc-knob\{display:grid/.test(appHtml) && /grid-template-areas:"regler beschriftung"/.test(appHtml));
pruef('die ganze Reglerflaeche ist greifbar, nicht nur die schmale Saeule',
  appHtml.indexOf('ganze Flaeche greifbar') >= 0);
pruef('auf dem Beruehrungsbildschirm scrollt die Seite beim Ziehen nicht weg',
  /touch-action:none/.test(appHtml));
pruef('Schrittknoepfe und Wertanzeige sind mitgewachsen',
  /\.mc-step\{width:34px;height:34px/.test(appHtml) && /\.mc-val\{font-size:17px/.test(appHtml));

/* ================================================================= 14f */
abschnitt('14f) Keine Zahl liegt auf einer anderen — bei JEDER Fenstergroesse (1.4.6)');
/*
 * DIE VIER FEHLER, DIE DIESER BLOCK FESTNAGELT (im Browser gemessen am 05.08.2026, an
 * zwoelf Fenstergroessen von 1920x1080 bis 640x720, hell und dunkel):
 *
 * 1. DIE ALARMGRENZEN LAGEN AUF DER EINHEIT. Sie standen absolut in der Ecke der Kachel;
 *    absolut heisst: sie reservieren keinen Platz. Im Bildschirmfoto stand "mm¹²⁰Hg".
 * 2. DAS EINGABEFELD WAR HOEHER ALS SEIN TEXT (gemessen 21 px bei 15 px Zeilenhoehe). Die
 *    Bahn wurde dadurch zu hoch, das Flex-Layout stauchte die Kopfzeile von 13 auf 10 px —
 *    und deren Buchstaben ragten 3 px tief in die Zahl darunter.
 * 3. DIE LEINWAND WUCHS SICH SELBST AUF. Ohne CSS-Hoehe bestimmt ihr height-Attribut die
 *    Layouthoehe, und das Attribut wird aus der gemessenen Hoehe gesetzt: eine Rueckkopplung.
 *    Gemessen: 590 px Leinwand in einem 663 px hohen Feld, das dadurch rollen musste.
 * 4. DIE KURVENFLAECHE DURFTE UNTER IHREN INHALT GESTAUCHT WERDEN (min-height:140px). Bei
 *    1400x900 enthielt der 140 px hohe Block 210 px, und die Wertekacheln lagen 62 px tief
 *    im Narkosegeraet.
 *
 * Der Block prueft nicht nur, DASS die Regeln dastehen, sondern rechnet die Bahnaufteilung
 * fuer jede Bahnhoehe von 17 bis 200 px nach — sie muss IMMER hineinpassen.
 */
pruef('das Eingabefeld ist genau so hoch wie sein Text (nicht hoeher)',
  /\.mt-in,\.ml-in\{[^}]*box-sizing:border-box;height:1\.15em/.test(appHtml));
pruef('... und es steht als Block, verrutscht also nicht auf der Grundlinie',
  /\.mt-in,\.ml-in\{[^}]*display:block;line-height:1/.test(appHtml));
pruef('die Kopfzeile der Bahn wird NIE gestaucht (flex:0 0 auto)',
  /\.mon-lane \.ml-kopf\{[^}]*flex:0 0 auto/.test(appHtml));
/* center, nicht baseline: bei Grundlinienausrichtung wird die Zeile hoeher als ihr hoechstes
 * Kind (Grundlinienversatz plus Unterlaenge) — gemessen 27 statt 24 px bei 21 px Schrift, und
 * die Bahn schnitt 2 px ab. Mittig stimmt die Zeilenhoehe mit der Rechnung ueberein. */
pruef('Kuerzel und Zahl stehen NEBENEINANDER, mittig statt auf der Grundlinie',
  /\.mon-lane \.ml-v\{display:flex;align-items:center/.test(appHtml));
pruef('die Kopfzeile weicht den Grenzen in der Ecke aus (padding-right)',
  /\.mon-lane \.ml-kopf\{[^}]*padding-right:38px/.test(appHtml));
pruef('die Alarmgrenzen der Kachel haben eine EIGENE Zeile (kein Platzstreit mit der Einheit)',
  /\.ck-links \.mon-tiles \.mt-lim\{flex:1 0 100%/.test(appHtml));
pruef('... und die Grenzen stehen im Fluss, nicht absolut in der Kachelecke',
  /\.mon-tile \.mt-lim\{flex:0 0 auto/.test(appHtml) && !/\.mon-tile \.mt-lim\{position:absolute/.test(appHtml));
pruef('die Kurvenflaeche darf nicht unter ihren Inhalt gestaucht werden',
  /\.ck-schirm\{[^}]*min-height:auto/.test(appHtml) && !/\.ck-schirm\{[^}]*min-height:140px/.test(appHtml));
pruef('die Leinwand fuellt ihren Schirm, statt ihn zu bestimmen (Rueckkopplung)',
  /\.ck-schirm \.mon-screen>canvas\{position:absolute;inset:0;width:100%;height:100%/.test(appHtml));
pruef('... und die Notmasse fuer die gestapelte Ansicht bleibt DORT',
  /if\(window\.innerWidth<=1000\)\{ if\(rect\.height<40\)/.test(appHtml));
pruef('das kleine Fenster wird NACHGEMESSEN, nicht geschaetzt',
  /links\.scrollHeight>links\.clientHeight\+8/.test(appHtml));
pruef('... und im engen Fenster rollt die Seite als Ganzes statt in zwei Guckloechern',
  /\.cockpit\.ck-eng>\.card\{overflow:visible\}/.test(appHtml) && /\.cockpit\.ck-eng \.ck-schirm\{flex:0 0 auto\}/.test(appHtml));
pruef('der Innenabstand der Bahn steht an EINER Stelle (CSS und Rechnung derselbe Wert)',
  /padding:var\(--lane-pad,2px\)/.test(appHtml) && /setProperty\('--lane-pad'/.test(appHtml));
/* Und jetzt die Rechnung selbst — mit den Zahlen aus der Datei, nicht mit abgeschriebenen. */
{
  const m = appHtml.match(/var LP=\(laneH>=28\)\?2:1;[\s\S]*?host\.style\.setProperty\('--lane-pad', LP\+'px'\);/);
  pruef('die Bahnaufteilung ist in der Datei auffindbar', !!m);
  if (m) {
    const teile = new Function('laneH', 'var host={style:{setProperty:function(){}}};' + m[0] +
      'return {PAD:PAD,KOPF:zeigeKopf?KOPF_H:0,ZUS:zeigeZusatz?ZUSATZ_H:0,fz:fz};');
    let engste = null, kleinsteSchrift = 99, kopfAb = null;
    for (let h = 17; h <= 200; h += 0.5) {
      const t = teile(h);
      /* 1,15 ist die gemessene Hoehe des Eingabefeldes je Schriftgroesse — dieselbe Zahl wie
       * im Stylesheet. Passt das nicht, wird die Zahl unten abgeschnitten. */
      const gebraucht = t.PAD + t.KOPF + t.ZUS + t.fz * 1.15;
      if (gebraucht > h + 0.001) { engste = h + ' braucht ' + gebraucht.toFixed(2); break; }
      if (t.fz < kleinsteSchrift) kleinsteSchrift = t.fz;
      if (t.KOPF === 0 && kopfAb === null) kopfAb = h;
    }
    pruef('jede Bahnhoehe von 17 bis 200 px traegt ihren Inhalt', engste === null, String(engste));
    pruef('die Zahl bleibt auch in der engsten Bahn lesbar (>= 11 px)', kleinsteSchrift >= 11, String(kleinsteSchrift));
    pruef('wird es eng, faellt die Kopfzeile — nicht die Zahl', kopfAb !== null && kopfAb < 21, String(kopfAb));
    const gross = teile(120);
    pruef('bei viel Platz wird die Schrift gedeckelt (sonst fuellt eine Ziffer die Bahn)', gross.fz === 34, String(gross.fz));
    pruef('... und die Zusatzzeile ist dann da', gross.ZUS === 12, String(gross.ZUS));
  }
}

/* ================================================================= 14g */
abschnitt('14g) Verlaufsgedaechtnis: die Station sieht die Richtung, nicht nur den Augenblick');
/*
 * DER BEFUND AUS DEM PRAXISPROTOKOLL (06.08.2026), der diesen Block noetig gemacht hat:
 * Eine Stunde lang steht in jeder Zeile "Ventrikulaere Extrasystolen". Die Herzfrequenz faellt
 * dabei langsam von 123 auf 113, die Saettigung steht bei 97 — KEIN Wert verlaesst sein Band.
 * Die Analyse hatte in jedem einzelnen Augenblick recht, wenn sie schwieg. Um 09:24 bricht die
 * SpO2 auf 90 ein. Der Zusammenbruch war eine Stunde lang im ANSTIEG sichtbar und im
 * MOMENTANWERT nie. Deshalb wird jetzt mitgeschrieben — und deshalb wird hier gerechnet und
 * nicht nachgesehen, ob die Funktion existiert.
 */
const srcMerken = holeFunktion('verlaufMerken');
const srcTrend = holeFunktion('trend');
const srcHaelt = holeFunktion('haeltAn');
pruef('verlaufMerken/trend/haeltAn sind auffindbar', !!srcMerken && !!srcTrend && !!srcHaelt);
if (srcMerken && srcTrend && srcHaelt) {
  const grenzen = appHtml.match(/var VERLAUF_MAX_MS=([^,]+), VERLAUF_MIN_ABSTAND_MS=([^,]+), VERLAUF_LUECKE_MS=([^;]+);/);
  pruef('die drei Fenstergroessen stehen an EINER Stelle', !!grenzen);
  const TAKT = 5000;   // so schnell laeuft renderMonValues am liefernden Geraet wirklich
  const bauen = () => {
    const st = { monMode: 'ist', verlauf: [] };
    let uhr = 1754460000000;                       // fester Startzeitpunkt, kein Date.now()
    const umgebung = new Function('state', 'Date', 'VERLAUF_MAX_MS', 'VERLAUF_MIN_ABSTAND_MS', 'VERLAUF_LUECKE_MS', 'Math', `
      ${srcMerken}
      ${srcTrend}
      ${srcHaelt}
      return { verlaufMerken: verlaufMerken, trend: trend, haeltAn: haeltAn };
    `);
    const api = umgebung(st, { now: () => uhr }, 30 * 60 * 1000, 4000, 45000, Math);
    return { st, api, vor: (ms) => { uhr += ms; }, jetzt: () => uhr };
  };

  // ---- Der echte Verlauf aus dem Ausdruck: 09:01 HF 121 ... 09:20 HF 113, SpO2 97 ----
  // Die Werte sind die des Protokolls, der Takt der des Programms (das Protokoll DRUCKT nur
  // jede n-te Zeile; aufgezeichnet wird viel dichter).
  {
    const w = bauen();
    const HF = [121, 123, 122, 120, 119, 118, 117, 116, 116, 115, 115, 114, 114, 113];
    HF.forEach((hr, k) => {
      const bis = (k < HF.length - 1) ? HF[k + 1] : hr;
      for (let s = 0; s < 17; s++) {                       // 17 x 5 s = 85 s je Protokollzeile
        w.api.verlaufMerken({ hr: Math.round(hr + (bis - hr) * (s / 17)), spo2: 97, ekg: 'ves' });
        w.vor(TAKT);
      }
    });
    const t = w.api.trend('hr', 20);
    pruef('der Trend ueber 20 min findet den Abfall auf 113', !!t && t.bis === 113 && t.delta < 0, t ? JSON.stringify(t) : 'null');
    pruef('... und rechnet ihn auf die Minute um (langsames Absacken, nicht Bolus)',
      !!t && t.proMinute < 0 && t.proMinute > -1.2, t ? String(t.proMinute) : '-');
    const s = w.api.trend('spo2', 20);
    pruef('die unveraenderte Saettigung ergibt Trend 0 (kein Rauschen erfunden)', !!s && s.delta === 0, s ? String(s.delta) : 'null');
    const dauer = w.api.haeltAn((p) => p.ekg === 'ves');
    pruef('die Ektopie steht seit fast zwanzig Minuten an', dauer >= 1180, String(dauer) + ' s');
  }

  // ---- Was der Trend NICHT tun darf ----
  {
    const w = bauen();
    pruef('ohne Aufzeichnung gibt es keinen Trend (nicht 0, sondern null)', w.api.trend('hr', 10) === null);
    w.api.verlaufMerken({ hr: 120 }); w.vor(5000);
    w.api.verlaufMerken({ hr: 100 });
    pruef('zwei Punkte sind kein Trend', w.api.trend('hr', 10) === null);
    w.vor(5000); w.api.verlaufMerken({ hr: 90 });
    pruef('drei Punkte ueber 10 s sind fuer ein 10-min-Fenster immer noch kein Trend',
      w.api.trend('hr', 10) === null);
  }
  /* DER FEHLER, DEN DIE FACHPRUEFUNG GEFUNDEN HAT (06.08.2026): die erste Fassung verlangte
   * Math.min(120, minuten*30) Sekunden — fuer JEDES Fenster ab 4 Minuten genau 120. Eine
   * Zwei-Minuten-Stichprobe kam damit als "Trend ueber 30 Minuten" heraus. */
  {
    const w = bauen();
    for (let i = 0; i < 45; i++) { w.api.verlaufMerken({ hr: 120 - i * 0.5 }); w.vor(TAKT); }  // 220 s
    pruef('knapp vier Minuten Aufzeichnung sind KEIN Trend ueber 30 Minuten', w.api.trend('hr', 30) === null);
    pruef('... aber ein Trend ueber 10 Minuten (ein Drittel des Fensters reicht)', w.api.trend('hr', 10) !== null);
    for (let i = 0; i < 90; i++) { w.api.verlaufMerken({ hr: 100 - i * 0.05 }); w.vor(TAKT); }  // +450 s
    pruef('ueber elf Minuten ergeben dann auch den 30-Minuten-Trend', w.api.trend('hr', 30) !== null);
    pruef('ein Kanal, den kein Geraet liefert, ergibt keinen erfundenen Trend', w.api.trend('compl', 30) === null);
  }
  // ---- Bildwiederholungen duerfen den Speicher nicht fluten ----
  {
    const w = bauen();
    for (let i = 0; i < 200; i++) { w.api.verlaufMerken({ hr: 100 }); w.vor(50); }   // 50 ms Takt
    pruef('200 Bildwiederholungen in 10 s ergeben hoechstens 3 Punkte', w.st.verlauf.length <= 3, String(w.st.verlauf.length));
  }
  // ---- Der Ringspeicher laeuft nicht voll ----
  {
    const w = bauen();
    for (let i = 0; i < 2000; i++) { w.api.verlaufMerken({ hr: 100 + (i % 5) }); w.vor(TAKT); }  // 2,7 Stunden
    const spanne = (w.st.verlauf[w.st.verlauf.length - 1].t - w.st.verlauf[0].t) / 1000;
    pruef('nach 2,7 Stunden bleiben hoechstens 30 Minuten stehen', spanne <= 30 * 60 + 10, Math.round(spanne) + ' s');
    pruef('... und der Speicher bleibt klein', w.st.verlauf.length <= 460, String(w.st.verlauf.length));
  }
  // ---- haeltAn zaehlt nur UNUNTERBROCHEN ----
  {
    const w = bauen();
    ['ves', 'ves', 'sinus', 'ves', 'ves', 'ves'].forEach((e) => {
      for (let s = 0; s < 6; s++) { w.api.verlaufMerken({ hr: 100, ekg: e }); w.vor(TAKT); }   // je 30 s
    });
    const d = w.api.haeltAn((p) => p.ekg === 'ves');
    pruef('eine Unterbrechung setzt die Uhr zurueck (nicht 150, sondern 90 s)', d >= 80 && d <= 95, String(d) + ' s');
    w.api.verlaufMerken({ hr: 100, ekg: 'sinus' });
    pruef('endet der Zustand, ist die Dauer 0', w.api.haeltAn((p) => p.ekg === 'ves') === 0);
  }
  /* ZWEITER FEHLER DER FACHPRUEFUNG: wer weggeschaut hat, darf keine Dauer behaupten.
   * Im Uebungs-Szenario, beim Reiterwechsel und beim schweigenden Geraet entsteht ein Loch —
   * ohne Lueckenmarke spannt haeltAn() darueber hinweg. */
  {
    const w = bauen();
    for (let s = 0; s < 24; s++) { w.api.verlaufMerken({ hr: 100, ekg: 'ves' }); w.vor(TAKT); }  // 2 min beobachtet
    w.vor(10 * 60 * 1000);                                                                      // 10 min weggeschaut
    for (let s = 0; s < 12; s++) { w.api.verlaufMerken({ hr: 100, ekg: 'ves' }); w.vor(TAKT); }  // 1 min beobachtet
    const d = w.api.haeltAn((p) => p.ekg === 'ves');
    pruef('eine Luecke von 10 min wird NICHT als beobachtete Dauer mitgezaehlt', d <= 70, String(d) + ' s');
    pruef('... die Luecke ist im Speicher als solche vermerkt', w.st.verlauf.some((p) => p.luecke === true));
    const t = w.api.trend('hr', 20);
    pruef('der TREND bleibt ueber die Luecke gueltig (zwei echte Messpunkte, echter Abstand)', t !== null);
  }
  // ---- Im Szenario-Modus wird NICHT mitgeschrieben (sonst stuende Erfundenes im Verlauf) ----
  {
    const w = bauen();
    w.st.monMode = 'sim';
    for (let i = 0; i < 10; i++) { w.api.verlaufMerken({ hr: 100 }); w.vor(60000); }
    pruef('im Uebungs-Szenario wird nichts aufgezeichnet', w.st.verlauf.length === 0, String(w.st.verlauf.length));
  }
  // ---- Der invasive Druck gehoert in den Speicher (fehlte in der ersten Fassung) ----
  {
    const w = bauen();
    for (let i = 0; i < 40; i++) { w.api.verlaufMerken({ hr: 100, nibp: 70, ibp: 58 }); w.vor(TAKT); }
    pruef('der invasive Druck wird mitgeschrieben, nicht nur die Manschette',
      w.api.haeltAn((p) => p.ibp > 0 && p.ibp < 60) >= 180);
  }
}
pruef('renderAssess schreibt den Verlauf bei jedem Durchgang mit',
  /var v=monVitals\(\), iv=state\.istVals, items=\[\], r0=monResolve\(\);\s*\n\s*verlaufMerken\(r0\);/.test(appHtml));

/* ================================================================= 14h */
abschnitt('14h) Ventrikulaere Ektopie: die Leiter entscheidet, und Lidocain ist gesperrt (1.4.7)');
/*
 * DER GEFAEHRLICHSTE BEFUND DER FACHRECHERCHE (06.08.2026):
 * Hier standen zwei Zeilen, die bei JEDER Form ventrikulaerer Ektopie feuerten und beide mit
 * "dann Lidocain (Hund) langsam IV" endeten — ohne Frequenz, ohne Blutdruck, ohne Tierart.
 * Damit stand die Lidocain-Empfehlung auch
 *   - beim ventrikulaeren ERSATZrhythmus (HF 35): dort ist der Kammerrhythmus der letzte
 *     verbliebene Schrittmacher; wer ihn unterdrueckt, erzeugt eine Asystolie;
 *   - bei der KATZE, fuer die RECOVER 2024 ausdruecklich abraet — und die Dosiszeile im
 *     Katalog stand speziesblind auf 2 mg/kg statt 0,25–0,5, also das Vier- bis Achtfache;
 *   - beim beschleunigten idioventrikulaeren Rhythmus, der haeufigsten Ueberbehandlung der
 *     Kleintiermedizin.
 *
 * Dieser Block prueft nicht, ob die Woerter dastehen, sondern FUEHRT DIE LEITER AUS und sieht
 * nach, WELCHE Sprosse bei welcher Messlage greift und was auf der Karte steht.
 */
const iLeiter = appHtml.indexOf('    if(vent){');
pruef('die Leiter ist auffindbar', iLeiter >= 0);
if (iLeiter >= 0) {
  let tiefe = 0, ende = -1;
  for (let j = appHtml.indexOf('{', iLeiter); j < appHtml.length; j++) {
    if (appHtml[j] === '{') tiefe++;
    else if (appHtml[j] === '}') { tiefe--; if (tiefe === 0) { ende = j; break; } }
  }
  const codeLeiter = appHtml.slice(iLeiter, ende + 1);
  pruef('sie ist eine AUSSCHLIESSENDE Kette (else if), nicht eine Reihe unabhaengiger Karten',
    (codeLeiter.match(/else if\(/g) || []).length >= 4 && /\belse\s*\{/.test(codeLeiter),
    'else-if: ' + (codeLeiter.match(/else if\(/g) || []).length);

  /* Die Leiter mit Stellvertretern wirklich laufen lassen. */
  const lauf = (lage) => {
    const karten = [];
    const st = { sp: lage.sp || 'hund', wt: lage.wt || 12, medGaben: lage.gaben || [] };
    const v = { hr: [70, 140], spo2: [95, 100], etco2: [30, 55], map: [70, 120], temp: [37.5, 39.2], rr: [8, 20] };
    if (lage.sp === 'katze') { v.hr = [100, 200]; v.temp = [37.8, 39.5]; }
    const r = Object.assign({ ekg: 'ves', hr: 100, spo2: 98, etco2: 40, nibp: 80, ibp: 0, temp: 38.2, fico2: 0, mac: 0, fio2: 0 }, lage.r || {});
    /*
     * sperrLage ist seit dem 21.08.2026 dabei. Die erste Sprosse der Leiter (ventrikulaerer
     * Ersatzrhythmus) setzt darin ein Kennzeichen, das arzneiSperre() braucht: dort — und nur
     * dort — ist bekannt, dass der Kammerrhythmus der LETZTE verbliebene Schrittmacher ist.
     * Ohne dieses Kennzeichen strich die Druckregel ausgerechnet das Atropin, das die Karte
     * daneben als erste Massnahme nennt, und die Erstwahl-Liste zeigte sechs durchgestrichene
     * Arzneien und keine einzige Handlung.
     *
     * Der Stellvertreter wird MITGEPRUEFT (weiter unten, Fall 1): dass die Sprosse ihn wirklich
     * setzt, ist Teil der Zusage. Ihn hier nur stumm bereitzustellen waere die halbe Arbeit.
     */
    const sperrLage = { stillstand: false, hypoton: (r.ibp > 0 ? r.ibp : r.nibp) < 70, druckBekannt: true, ersatzrhythmus: false };
    const fn = new Function('xc', 'r', 'v', 'state', 'fmt', 'haeltAn', 'gabeMin', 'gabeMinAny', 'trend',
      'isoTgt', 'spo2Lo', 'etco2Arr', 'mapM', 'hypo60', 'tiefe', 'flach', 'tempLo', 'ersatzHF', 'ektSek', 'vent', 'cross', 'fio2Bek', 'sperrLage', 'Math',
      codeLeiter);
    const mapM = (r.ibp > 0 ? r.ibp : r.nibp);
    const tempLo = v.temp[0] - 1.5;
    fn(
      (sev, color, title, tag, cause, fix, inc, kanal) => karten.push({ sev, title, tag, cause, fix, inc, kanal }),
      r, v, st, (x) => String(x),
      (p) => (lage.dauer != null ? lage.dauer : 999),          // Bestandsdauer frei waehlbar
      (id) => (lage.lidoMin != null && id === 'lidocain_iv' ? lage.lidoMin : null),
      () => null, () => null,
      { iso: '1,5–2,5' },
      lage.spo2Lo || 95, 45, mapM, (mapM > 0 && mapM < 60),
      !!lage.tiefe, !!lage.flach, tempLo,
      (st.sp === 'hund' || st.sp === 'katze') ? 45 : null,
      lage.ektSek || 0, true, karten, (lage.fio2Bek != null ? lage.fio2Bek : null), sperrLage, Math,
    );
    karten.sperrLage = sperrLage;
    return karten;
  };

  // 1) ERSATZRHYTHMUS — der toedliche Fall
  {
    const k = lauf({ sp: 'hund', r: { ekg: 'ves', hr: 35, nibp: 62 } });
    pruef('HF 35 mit Kammerkomplexen -> Ersatzrhythmus-Karte, Schwere 5',
      k.length === 1 && k[0].sev === 5 && /Ersatzrhythmus/.test(k[0].title), JSON.stringify(k.map((x) => x.title)));
    pruef('... und sie verbietet Lidocain ausdruecklich',
      k.length === 1 && /KEIN Lidocain/.test(k[0].fix) && !/dann Lidocain/.test(k[0].fix));
    pruef('... und sie schaltet die HF-Einzelkarte stumm (sonst stuende Atropin darunter)',
      k.length === 1 && k[0].kanal === 'hr');
    /*
     * DIE SPROSSE MUSS DIE LAGE KENNZEICHNEN (21.08.2026).
     *
     * Die Karte verlangt ausdruecklich "Atropin 0,02-0,04 mg/kg IV bei Vagotonus". Die
     * Anticholinergikum-Sperre in arzneiSperre() strich es aber, weil der Druck traegt (62 mmHg
     * bei Normband ab 70 — hier sogar hypoton, aber bei 80 waere es gestrichen worden). Gemessen
     * zeigte die Erstwahl-Liste dort SECHS durchgestrichene Arzneien und keine einzige Handlung,
     * waehrend die Karte daneben Atropin als erste Massnahme nannte.
     *
     * Die Begruendung der Druckregel traegt hier auch inhaltlich nicht: sie warnt davor, eine
     * alpha2-bedingte Bradykardie bei tragendem Druck anzuheben. Beim Ersatzrhythmus ist die
     * Frequenz nicht die Antwort auf einen hohen Widerstand, sondern das Letzte, was das Herz
     * noch zustande bringt.
     */
    pruef('... und sie kennzeichnet die Lage, damit Atropin nicht gesperrt wird',
      k.sperrLage.ersatzrhythmus === true,
      'ohne dieses Kennzeichen streicht arzneiSperre() genau das Mittel, das die Karte verlangt');
  }
  // 1b) Die Gegenprobe: eine ANDERE Sprosse darf das Kennzeichen NICHT setzen.
  {
    const k = lauf({ sp: 'hund', r: { ekg: 'vtach', hr: 200, nibp: 45 }, dauer: 60 });
    pruef('eine andere Sprosse setzt das Ersatzrhythmus-Kennzeichen NICHT',
      k.sperrLage.ersatzrhythmus === false,
      'sonst waere die Atropin-Sperre bei jeder ventrikulaeren Lage aufgehoben');
  }
  // 2) KATZE — RECOVER 2024 raet ab
  {
    const k = lauf({ sp: 'katze', r: { ekg: 'vtach', hr: 230, nibp: 85 } });
    pruef('Katze mit Kammertachykardie -> Lidocain-Sperre statt Hundedosis',
      k.length === 1 && /Lidocain-Sperre/.test(k[0].title) && /KEIN Standard-Lidocain/.test(k[0].fix), JSON.stringify(k.map((x) => x.title)));
    pruef('... und sie nennt Amiodaron als Ausweg', k.length === 1 && /Amiodaron 5 mg\/kg/.test(k[0].fix));
  }
  // 3) HUND, behandlungspflichtige VT — hier IST Lidocain richtig
  {
    const k = lauf({ sp: 'hund', r: { ekg: 'vtach', hr: 220, nibp: 75 } });
    pruef('Hund mit VT 220/min -> jetzt behandeln, mit Dosis',
      k.length === 1 && k[0].sev === 5 && /Lidocain 2 mg\/kg/.test(k[0].fix), JSON.stringify(k.map((x) => x.title)));
    pruef('... mit Hoechstmenge und Abbruchkriterien', k.length === 1 && /8 mg\/kg/.test(k[0].fix) && /Nystagmus/.test(k[0].fix));
  }
  // 3b) dieselbe VT, aber erst seit 10 s -> KEINE Antiarrhythmikum-Empfehlung
  {
    const k = lauf({ sp: 'hund', r: { ekg: 'vtach', hr: 220, nibp: 75 }, dauer: 10 });
    pruef('dieselbe VT nach 10 Sekunden loest noch KEINE Dosis aus (Ausreisserschutz)',
      k.length === 1 && !/Lidocain 2 mg\/kg/.test(k[0].fix), k.length ? k[0].title : '-');
  }
  // 3c) Lidocain steht seit 20 min und die Ektopie besteht -> NICHT nachdosieren
  {
    const k = lauf({ sp: 'hund', r: { ekg: 'vtach', hr: 220, nibp: 75 }, lidoMin: 20 });
    pruef('Lidocain seit 20 min ohne Wirkung -> nicht nachdosieren, sondern Magnesium und Elektrolyte',
      k.length === 1 && /NICHT nachdosieren/.test(k[0].fix) && /Magnesium/.test(k[0].fix));
  }
  // 4) AIVR — die haeufigste Ueberbehandlung
  {
    const k = lauf({ sp: 'hund', r: { ekg: 'ves', hr: 110, nibp: 85, spo2: 98, temp: 38.2 } });
    pruef('stabiler Kammerrhythmus bei gutem Druck -> AIVR, nur beobachten',
      k.length === 1 && /idioventrikul/.test(k[0].title) && k[0].sev === 2, JSON.stringify(k.map((x) => x.title)));
    pruef('... und ausdruecklich KEIN Lidocain', k.length === 1 && /KEIN Lidocain/.test(k[0].fix));
  }
  // 5) Ursachenkette steht VOR der Massnahme und in fester Reihenfolge
  {
    const k = lauf({ sp: 'hund', r: { ekg: 'ves', hr: 100, nibp: 85, spo2: 90, etco2: 58, fico2: 8, temp: 35.2 }, spo2Lo: 95 });
    pruef('offene Ursachen erscheinen nummeriert auf der Karte',
      k.length === 1 && /①/.test(k[0].fix) && /②/.test(k[0].fix) && /③/.test(k[0].fix) && /⑥/.test(k[0].fix), k.length ? k[0].fix.slice(0, 90) : '-');
    pruef('... und der Atemkalk steht VOR der Ventilation (① vor ③)',
      k.length === 1 && k[0].fix.indexOf('①') < k[0].fix.indexOf('③'));
  }
  // 6) Jede Messlage ergibt GENAU EINE Karte — keine sich widersprechenden Doppelmeldungen
  {
    const lagen = [
      { sp: 'hund', r: { ekg: 'ves', hr: 35, nibp: 40 } },
      { sp: 'hund', r: { ekg: 'vtach', hr: 200, nibp: 45 } },
      { sp: 'katze', r: { ekg: 'ves', hr: 30, nibp: 50 } },
      { sp: 'katze', r: { ekg: 'ves', hr: 180, nibp: 90 } },
      { sp: 'hund', r: { ekg: 'ves', hr: 120, nibp: 55 } },
      { sp: 'hund', r: { ekg: 'ves', hr: 90, nibp: 95, spo2: 99 } },
      { sp: 'hund', r: { ekg: 'vtach', hr: 60, nibp: 80 } },
    ];
    const mehr = lagen.map((l, i) => [i, lauf(l).length]).filter((x) => x[1] !== 1);
    pruef('sieben verschiedene Messlagen ergeben jeweils GENAU EINE Rhythmuskarte',
      mehr.length === 0, mehr.map((x) => 'Lage ' + x[0] + ': ' + x[1] + ' Karten').join(' · '));
    /* Jede Sprosse muss den HF-Kanal beanspruchen — sonst steht unter der Rhythmuskarte noch
     * "HF ↑ 220 → Fentanyl" bzw. "HF ↓ 35 → Atropin". Genau das war im Browser zu sehen. */
    const ohneHR = lagen.map((l, i) => [i, lauf(l)[0]]).filter((x) => x[1] && [].concat(x[1].kanal || []).indexOf('hr') < 0);
    pruef('JEDE Sprosse schaltet die HF-Einzelkarte stumm (keine zweite, widersprechende Dosis)',
      ohneHR.length === 0, ohneHR.map((x) => 'Lage ' + x[0] + ': ' + x[1].title).join(' · '));
    // und in KEINER darf bei HF unter 45 eine Lidocain-Dosis stehen
    const boese = lagen.filter((l) => (l.r.hr || 0) < 45).map((l) => lauf(l)[0])
      .filter((k) => k && /Lidocain \d/.test(k.fix));
    pruef('bei HF unter 45 steht in KEINER Lage eine Lidocain-Dosis', boese.length === 0);
  }
}
/* ---- Die vier Sperren vor der Dosiszeile der Einzelwert-Karten ---- */
/* Die Sperren haengen am MITTEL, nicht am Zwischenfall: dieselbe Naloxon-Zeile haengt an zwei
 * Zwischenfaellen (Hypoventilation UND Apnoe), und eine Sperre auf den einen liess die andere
 * offen — im Browser stand Naloxon prompt unter "AF ↓ 6/min".
 *
 * SEIT DEM 21.08.2026 STEHEN SIE IN arzneiSperre(lage) UND NICHT MEHR ALS VIER if-ZEILEN IN
 * DER KARTENSCHLEIFE. Anlass war die neue Erstwahl-Liste im Medikamenten-Reiter: sie stellt
 * dieselbe Frage, und eine Kopie waere der "zweite Rechenweg" aus CLAUDE.md gewesen — eine
 * spaeter verschaerfte Sperre haette dann nur an einer der beiden Stellen gegolten.
 *
 * DIESE VIER PRUEFUNGEN SIND DESHALB UMGESCHRIEBEN WORDEN, UND ZWAR NACH OBEN: sie fragen nicht
 * mehr nach dem Wortlaut von vier if-Zeilen, sondern (a) ob die Bedingung in arzneiSperre()
 * steht und (b) ob die Kartenschleife sie WIRKLICH ANRUFT. Der Wortlaut-Test haette den Umbau
 * rot gefaerbt, obwohl die Sperren vollstaendig erhalten sind — und schlimmer: er waere gruen
 * geblieben, wenn jemand die vier if-Zeilen stehen laesst und die Karte gar nicht mehr durch
 * sie hindurchfuehrt. Was die Sperren TUN, faehrt tools/erstwahl-test.js in beide Richtungen
 * durch (Abschnitte 2 und 3); hier steht nur, dass die eine Stelle die eine Stelle bleibt. */
{
  const sperreFn = holeFunktion('arzneiSperre') || '';
  pruef('es gibt GENAU EINE Stelle, die ueber Arznei-Sperren entscheidet',
    !!sperreFn && (appHtml.match(/function arzneiSperre\(/g) || []).length === 1);
  pruef('Adrenalin erscheint nur noch bei Kreislaufstillstand',
    /id==='adrenalin' && !lage\.stillstand/.test(sperreFn));
  pruef('Atropin und Glykopyrrolat nur bei Bradykardie MIT Hypotonie',
    /\(id==='atropin'\|\|id==='glyco'\) && !lage\.hypoton/.test(sperreFn));
  /* Die Lage wird an EINER Stelle gebaut, aus den Messwerten — sonst koennten Kartenschleife
   * und Erstwahl-Liste dieselbe Frage verschieden beantworten. */
  /*
   * "hypoton" heisst: IRGENDEIN gemessener Druck liegt unter dem Normband (geaendert 21.08.2026).
   *
   * Vorher stand hier nur mapM (invasiv vor Manschette). Die Bradykardie-Karte prueft aber
   * r.nibp — beide urteilten also ueber zwei verschiedene Zahlen, und die Erstwahl-Liste schrieb
   * "Der Blutdruck traegt", waehrend die Karte daneben "niedriger MAP" meldete. Jetzt gehen alle
   * verfuegbaren Druckwerte in dieselbe Entscheidung.
   */
  pruef('… und "hypoton" bedeutet weiterhin: ein gemessener Druck unter dem Normband',
    /var druckWerte = \[mapM, r\.nibp, r\.ibp\]\.filter/.test(appHtml) &&
    /hypoton:druckWerte\.some\(function\(x\)\{ return x<v\.map\[0\]; \}\)/.test(appHtml));
  pruef('… und "druckBekannt" haengt daran, dass ueberhaupt einer gemessen wurde',
    /druckBekannt:druckWerte\.length>0/.test(appHtml),
    'sonst behauptet die Station etwas ueber einen Druck, den sie nicht kennt');
  pruef('… "stillstand" weiterhin: flaches oder chaotisches EKG',
    /stillstand:!!\(W\.flat\|\|W\.chaos\)/.test(appHtml));
  pruef('Naloxon nur, wenn ein Opioid wirklich protokolliert ist',
    /id==='naloxon' && gabeMinAny\(\['fentanyl'/.test(sperreFn));
  pruef('... dasselbe fuer Flumazenil und Atipamezol (Gegenmittel ohne Mittel)',
    /id==='flumazenil' && gabeMinAny\(\['midazolam','diazepam'\]\)==null/.test(sperreFn)
    && /id==='atipamezol' && gabeMinAny\(\['dexmedetomidin','medetomidin','xylazin'\]\)==null/.test(sperreFn));
  /* DAS EIGENTLICHE GLIED DER KETTE. Ohne diesen Aufruf stuende arzneiSperre() vollstaendig und
   * richtig in der Datei — und die Einzelwert-Karte zeigte trotzdem wieder Adrenalin am
   * schlagenden Herzen. Genau diese Sorte stiller Ausfall ist in diesem Baum schon mehrfach
   * vorgekommen (siehe den Kommentar am direkten Hausweg in cloud.js). */
  pruef('die Einzelwert-Karte RUFT die Sperre auch wirklich an',
    /if\(drug && arzneiSperre\(drug\.id, sperrLage\)\) drug=null;/.test(appHtml));
  /* Und die Erstwahl-Liste ebenso — sie ist der zweite Verbraucher, wegen dem der Umbau kam. */
  pruef('… und die Erstwahl-Liste benutzt DIESELBE Stelle',
    /sp2\[id\] \|\| arzneiSperre\(id, lage\)/.test(appHtml));
}
{
  /* gabeMin wirklich rechnen lassen — die Ruecknahme muss zaehlen. */
  const src = holeFunktion('gabeMin');
  pruef('gabeMin ist auffindbar', !!src);
  if (src) {
    const jetzt = 1754460000000;
    const bau = (L) => new Function('state', 'Date', 'Math', 'return ' + src)({ medGaben: L }, { now: () => jetzt }, Math);
    pruef('nie gegeben -> null', bau([])('fentanyl') === null);
    pruef('vor 12 min gegeben -> 12', bau([{ id: 'fentanyl', ts: jetzt - 12 * 60000 }])('fentanyl') === 12);
    pruef('zurueckgenommen -> null (die LETZTE Handlung entscheidet)',
      bau([{ id: 'fentanyl', ts: jetzt - 12 * 60000 }, { id: 'fentanyl', ts: jetzt - 60000, storno: true }])('fentanyl') === null);
    pruef('nach der Ruecknahme erneut gegeben -> wieder eine Zahl',
      bau([{ id: 'fentanyl', ts: jetzt - 12 * 60000 }, { id: 'fentanyl', ts: jetzt - 6 * 60000, storno: true },
        { id: 'fentanyl', ts: jetzt - 3 * 60000 }])('fentanyl') === 3);
  }
}
/* ---- Der Katalog: speziesblinde Dosen und fehlende Mittel ---- */
{
  /* anaes-data.js selbst laden — dieser Test prueft die DATEN, nicht den Quelltext darum herum. */
  global.window = global.window || {};
  const AD = (() => { const m = require(path.join(WURZEL, 'ui/app/anaes-data.js')); return global.window.ANAES || m; })();
  const dose = (id) => (AD.drugs || []).find((d) => d.id === id);
  const inc = (id) => (AD.incidents || []).find((x) => x.id === id);
  const A = AD;
  pruef('Lidocain im Zwischenfall nimmt wieder die Speziesspalte (Katze bekam das 4- bis 8-Fache)',
    (inc('tachykardie').drugs || []).some((d) => d.id === 'lidocain_iv' && d.low === null && d.high === null));
  pruef('... und die Katzenspalte steht auf 0,25–0,5 mg/kg',
    dose('lidocain_iv').species.katze.low === 0.25 && dose('lidocain_iv').species.katze.high === 0.5);
  pruef('Adrenalin steht nicht mehr im Zwischenfall Hypoxaemie', (inc('hypoxaemie').drugs || []).length === 0);
  ['fentanyl', 'dopamin', 'dobutamin', 'atipamezol', 'noradrenalin'].forEach((id) => {
    const treffer = (A.incidents || []).flatMap((x) => x.drugs || []).filter((d) => d.id === id);
    pruef(id + ': keine speziesblinde Zahl mehr in den Zwischenfaellen',
      treffer.length > 0 && treffer.every((d) => d.low === null && d.high === null),
      JSON.stringify(treffer.map((d) => d.low + '-' + d.high)));
  });
  pruef('Amiodaron bei der Katze auf 5 mg/kg (RECOVER 2024)',
    dose('amiodaron').species.katze.low === 5 && dose('amiodaron').species.katze.high === 5);
  /*
   * BIS 19.08.2026 STAND HIER: "Atipamezol bei der Katze halbiert", high === 0.1.
   *
   * Diese Erwartung trug keine Quelle, und sie war falsch. CliniPharm/vetpharm nennt fuer
   * die Katze (adult, i.m.): 0,04-0,5 mg/kg als Antagonist allgemein (Greene 1999a),
   * 0,2 mg/kg gegen Xylazin (Paddleford 1999a), 0,2-0,4 mg/kg gegen Medetomidin
   * (Thurmon 1996e), 0,2 mg/kg gegen 0,04 mg/kg Dexmedetomidin (Granholm 2006a).
   * Die bisherige Obergrenze 0,1 lag damit UNTER jedem einzelnen katzenspezifischen Wert,
   * und die Untergrenze 0,025 unter dem kleinsten publizierten ueberhaupt.
   *
   * Der Test hielt also den Fehler fest, statt ihn zu finden. Jetzt haelt er die belegten
   * Enden - und ausdruecklich auch, dass die Katze nicht unter dem Hund liegt: genau das
   * war die Form des Fehlers.
   */
  pruef('Atipamezol Katze steht auf den belegten 0,04-0,2 mg/kg (vetpharm)',
    dose('atipamezol').species.katze.low === 0.04 && dose('atipamezol').species.katze.high === 0.2);
  pruef('... und die Obergrenze liegt nicht unter der des Hundes',
    dose('atipamezol').species.katze.high >= dose('atipamezol').species.hund.high,
    'Katze ' + dose('atipamezol').species.katze.high + ' gegen Hund ' + dose('atipamezol').species.hund.high);
  pruef('Noradrenalin endet bei 1 µg/kg/min (vetpharm, Kraft 2003a) - nicht bei 2',
    dose('noradrenalin').species.hund.high === 1 && dose('noradrenalin').species.katze.high === 1);
  pruef('Vitamin K blieb dabei unangetastet (2,5–5 mg/kg)',
    dose('vitk').species.katze.low === 2.5 && dose('vitk').species.katze.high === 5);
  ['magnesiumsulfat', 'procainamid', 'esmolol', 'kaliumchlorid', 'phenylephrin', 'terbutalin'].forEach((id) => {
    pruef('der Katalog kennt jetzt ' + id, !!dose(id));
  });
  pruef('Procainamid ist fuer die Katze ausdruecklich gesperrt',
    dose('procainamid').species.katze.low === null && /nicht verwenden/i.test(dose('procainamid').species.katze.caution));
  pruef('Kaliumchlorid traegt die Obergrenze, an der es toedlich wird',
    /0,5 mmol\/kg\/h/.test(dose('kaliumchlorid').species.hund.caution));
  ['atropin', 'glyco', 'dobutamin', 'ephedrin', 'noradrenalin', 'fentanyl'].forEach((id) => {
    const d = dose(id);
    ['hund', 'katze'].forEach((a) => {
      if (!d.species[a]) return;
      pruef(id + '/' + a + ' hat eine Gegenanzeige', !!String(d.species[a].caution || '').trim());
    });
  });
  pruef('die α2-Klausel steht bei Atropin fuer beide Tierarten',
    /α2/.test(dose('atropin').species.hund.caution) && /α2/.test(dose('atropin').species.katze.caution));
  pruef('die Quellenliste ist gewachsen und nennt RECOVER 2024 und ACVAA 2025',
    (A.sources || []).length >= 20
    && (A.sources || []).some((q) => /RECOVER 2024/.test(q.title))
    && (A.sources || []).some((q) => /ACVAA/.test(q.title)));
}

/* ================================================================= 15 */
abschnitt('15) Millisekunden-Takt: der Wert geht raus, sobald er da ist');
const regSrc = fs.readFileSync(path.join(WURZEL, 'bridge/src/registry.js'), 'utf8');
const srvSrc = fs.readFileSync(path.join(WURZEL, 'bridge/src/server.js'), 'utf8');
pruef('registry meldet jeden neuen Frame (onNeu)', /this\.onNeu\s*=\s*null/.test(regSrc) && /if \(this\.onNeu\)/.test(regSrc));
pruef('... und ein Fehler im Haken stoppt die Datenaufnahme nicht', /if \(this\.onNeu\) \{ try \{/.test(regSrc));
pruef('server haengt sich ein und buendelt', srvSrc.indexOf('registry.onNeu =') >= 0 && srvSrc.indexOf('MIN_ABSTAND_MS') >= 0);
pruef('Buendelung entspricht der Bildrate des Monitors (40 ms)', /MIN_ABSTAND_MS = 40/.test(srvSrc));
pruef('der 350-ms-Zeitgeber bleibt (Protokoll, Fern-Live, Lastbremse)', /BROADCAST_MS = 350/.test(srvSrc));
pruef('beim Beenden wird abgemeldet (kein Senden auf geschlossenen Socket)',
  /registry\.onNeu = null;[\s\S]{0,120}clearTimeout\(sofortTimer\)/.test(srvSrc));
// wirklich ausfuehren: ein Frame -> ein Ruf, zehn Frames -> nicht zehn Rufe
{
  const { Registry } = require(path.join(WURZEL, 'bridge/src/registry.js'));
  const r = new Registry({ log: { info() {}, warn() {}, error() {} } });
  let rufe = 0;
  r.onNeu = () => { rufe++; };
  for (let i = 0; i < 5; i++) {
    r.ingest({ deviceId: 'X', deviceModel: 'M', deviceRole: 'monitor', patientId: '1', species: 'hund', weightKg: 10, ts: Date.now(), vitals: { hr: 90 + i } });
  }
  pruef('jeder eingehende Frame meldet sich (5 Frames -> 5 Meldungen)', rufe === 5, String(rufe));
  const r2 = new Registry({ log: { info() {}, warn() {}, error() {} } });
  r2.onNeu = () => { throw new Error('absichtlich'); };
  let ueberlebt = true;
  try { r2.ingest({ deviceId: 'Y', deviceRole: 'monitor', ts: Date.now(), vitals: { hr: 80 } }); } catch (_) { ueberlebt = false; }
  pruef('ein werfender Haken bringt die Datenaufnahme NICHT um', ueberlebt);
}

console.log('\n== Ergebnis: ' + ok + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
