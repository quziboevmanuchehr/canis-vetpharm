'use strict';
/*
 * seriell.js — der Weg zu Geraeten, die KEIN Netzwerk haben.
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 01.08.2026: "es muss viel Moeglichkeiten zu Verbindung sein"):
 * Bis hierher konnte VetStation ausschliesslich ueber TCP/IP lesen. Ein grosser Teil der Geraete,
 * die in Tierkliniken und OPs stehen, hat aber gar keine Netzwerkbuchse — sie geben ihre Werte
 * ueber eine serielle Schnittstelle (RS-232) heraus. Das gilt fuer die gesamte MEDIBUS-Familie von
 * Draeger, fuer die Datex-Ohmeda-/GE-S-5-Reihe und fuer viele aeltere Monitore. Ohne diesen Weg
 * bleiben sie unerreichbar, egal wie gut das Netz eingerichtet ist.
 *
 * ZWEI WEGE, UND DER EMPFOHLENE IST DER ZWEITE:
 *
 *   art: 'tcp'  — GERAETESERVER (empfohlen).
 *       Ein kleiner Kasten (Moxa NPort, USR-TCP232, Waveshare u. a., ~30-80 EUR) haengt am
 *       seriellen Anschluss des Geraets und stellt den Datenstrom als rohen TCP-Port bereit.
 *       Fuer VetStation ist das dann eine ganz normale Netzverbindung — derselbe erprobte Weg wie
 *       bei allen anderen Geraeten, ohne Treiber, ohne Windows-Eigenheiten, und das Geraet darf
 *       stehen, wo es steht (der PC muss nicht daneben stehen). WLAN-Ausfuehrungen gibt es auch.
 *
 *   art: 'com'  — DIREKT AN EINEN COM-ANSCHLUSS DES PCs.
 *       Ohne npm-Modul (auf diesem Rechner ist kein npm vorhanden — es gibt nur node.exe) geht das
 *       unter Windows so: die Schnittstellenparameter mit `mode.com` setzen und die Schnittstelle
 *       danach wie eine Datei lesen (\\.\COM3). Das FUNKTIONIERT, ist aber empfindlicher als der
 *       Geraeteserver: Zeitgrenzen, Puffer und USB-Seriell-Wandler verhalten sich unterschiedlich.
 *
 *       EHRLICHE EINORDNUNG, so genau wie sie sich hier machen laesst (Stand 01.08.2026):
 *         NACHGEWIESEN auf diesem Rechner: Windows meldet COM1; `mode.com` stellt die
 *           Schnittstelle fehlerfrei ein; \\.\COM1 laesst sich als Lesestrom oeffnen.
 *           (`node tools/seriell-pruefen.js --com COM1` — Oeffnen erfolgreich, 0 Bytes, weil
 *           nichts angeschlossen ist.)
 *         NICHT NACHGEWIESEN: das Lesen eines ECHTEN Geraets, weil hier keines am seriellen
 *           Anschluss haengt. Ob Puffergroessen, Zeitverhalten und USB-Seriell-Wandler mitspielen,
 *           zeigt erst das erste echte Geraet.
 *       Deshalb sagt der Log beim Oeffnen genau das — statt so zu tun, als sei der ganze Weg
 *       gemessen. Wer ihn benutzt, prueft zuerst mit `node tools/seriell-pruefen.js`.
 *
 * STRIKT READ-ONLY — und hier ist die Regel schaerfer als sonst:
 * Eine serielle Leitung ist beidseitig. Manche Protokolle (MEDIBUS) verlangen, dass der PC eine
 * ANFRAGE schickt, sonst schweigt das Geraet. Das ist erlaubt und bleibt Mitlesen. NICHT erlaubt
 * ist alles, was am Geraet etwas VERSTELLT. Deshalb geht Senden ausschliesslich ueber senden()
 * MIT einer ausdruecklichen Erlaubnisliste (cfg.erlaubteBefehle): was nicht darin steht, wird
 * verworfen und protokolliert. Ein Adapter kann sich also nicht versehentlich das Recht nehmen,
 * einen Verdampfer zu verstellen — er muesste die Erlaubnisliste dafuer sichtbar erweitern.
 */
const fs = require('fs');
const net = require('net');
const { execFile } = require('child_process');

/* Werkseinstellungen, die bei Medizingeraeten am haeufigsten vorkommen. Bewusst konservativ:
 * 9600/8N1 ist die Vorgabe, die praktisch jedes Geraet beherrscht. Der genaue Wert steht im
 * Handbuch des Geraets und gehoert in den Katalogeintrag, nicht in eine Vermutung hier. */
const VORGABE = { baud: 9600, datenbits: 8, paritaet: 'n', stopbits: 1 };

/* ------------------------------------------------------------------ *
 * 1) Welche seriellen Schnittstellen kennt dieser PC?
 * ------------------------------------------------------------------ */

/*
 * schnittstellenAusRegistry(text) — pure Funktion, deshalb ohne Windows testbar.
 * Erwartet die Ausgabe von:  reg query HKLM\HARDWARE\DEVICEMAP\SERIALCOMM
 * Die Zeilen sehen so aus:
 *     \Device\Serial0    REG_SZ    COM1
 *     \Device\VCP0       REG_SZ    COM7
 */
function schnittstellenAusRegistry(text) {
  const aus = [];
  String(text || '').split(/\r?\n/).forEach((z) => {
    const m = z.match(/\\Device\\(\S+)\s+REG_SZ\s+(COM\d+)/i);
    if (!m) return;
    aus.push({ name: m[2].toUpperCase(), geraet: m[1] });
  });
  return aus;
}

/* ------------------------------------------------------------------ *
 * 1b) USB-SERIELLE GERAETE MIT NAMEN — wer steckt da eigentlich?
 *
 * WARUM DAS NOETIG IST (12.08.2026):
 * SERIALCOMM sagt nur, DASS es COM5 gibt. Es sagt nicht, was daran haengt. Fuer einen fest
 * eingebauten Anschluss ist das egal, fuer einen USB-Wandler nicht: die Station liefert seit
 * dem 07.08.2026 den Treiber des Eickemeyer/Grimed EKG 2000 mit und installiert ihn still vor
 * (installer/set-ekg-treiber.ps1). Steckt der Anwender das Geraet an, richtet Windows es
 * ohne Nachfrage ein - und die Station schwieg dazu bisher vollstaendig. Wer nichts sagt,
 * laesst den Anwender den Fehler bei sich suchen.
 *
 * WO DIE KENNUNG STEHT: Windows legt jedes FTDI-Geraet unter
 *   HKLM\SYSTEM\CurrentControlSet\Enum\FTDIBUS\VID_xxxx+PID_yyyy+<Seriennummer>A\0000
 * ab; der zugeteilte Anschluss steht darunter in "Device Parameters" als PortName.
 * Die Kennungen sind NICHT geraten - sie stehen woertlich in der mitgelieferten
 * treiber/ekg2000/ftdibus.inf:
 *   USB\VID_0403&PID_8AC8 = "EKG 2000"
 *   USB\VID_0403&PID_8AC9 = "VETNAR 2200"
 *
 * WAS DIESE FUNKTION NICHT TUT: sie liest keine Messwerte. Das Datenformat des EKG 2000 ist
 * unbekannt (siehe Katalogeintrag eickemeyer-ekg-2000). Sie sagt nur, DASS ein bekanntes
 * Geraet an welchem Anschluss haengt - und genau das fehlte.
 * ------------------------------------------------------------------ */

/* VID+PID -> was es ist. Klein gehalten und aus der INF belegt; alles andere bleibt 'unbekannt',
 * statt geraten zu werden. */
/*
 * ZWEI GERAETEGENERATIONEN, UND NUR EINE IST ABGEDECKT (Befund 16.08.2026).
 *
 * Im Installationsarchiv des Herstellers liegen ZWEI Treiberpakete, und sie nennen
 * VERSCHIEDENE Hardware-Kennungen fuer dasselbe Geraet:
 *   WHQL_USB_driver   (CDM 2.12.36.20, WHQL-signiert, ftdibus.inf + ftdiport.inf)
 *                     PID_8AC8 "EKG 2000", PID_8AC9 "VETNAR 2200"   <- liegt im Paket
 *   USB_driver_2.08.02 (nur ftdibus.inf, KEINE .cat-Datei, kein VCP)
 *                     PID_6003 "EKG 2000", PID_6004 "VETMON 2150"   <- liegt NICHT im Paket
 *
 * Das aeltere Paket laesst sich auf Windows 11 x64 nicht vorinstallieren: ohne Katalogdatei
 * fehlt die Signatur des Treiberpakets, und pnputil weist es ab. (Die einzelnen .sys/.dll
 * sind zwar von FTDI signiert — das genuegt der Treibersignaturpflicht aber nicht, sie
 * verlangt den signierten Katalog fuer das PAKET.) Eine geaenderte INF, in die man die alten
 * Kennungen eintraegt, macht es nicht besser: damit stimmt der Katalog der WHQL-Dateien nicht
 * mehr, und das ganze Paket ist unsigniert.
 *
 * DESHALB steht die alte Generation hier TROTZDEM drin. Nicht damit sie laeuft, sondern damit
 * die Station sie BENENNEN kann. Der schlechteste aller Zustaende ist der bisherige: der
 * Anwender steckt sein EKG an, Windows meldet ein unbekanntes Geraet, und VetStation sagt
 * gar nichts. Mit diesem Eintrag sagt sie: "das ist ein EKG 2000 aelterer Bauart, dafuer
 * bringt VetStation keinen Treiber mit — hier ist der Weg".
 */
const USB_KENNUNGEN = {
  '0403:8ac8': { name: 'EKG 2000', katalogId: 'eickemeyer-ekg-2000', treiberMitgeliefert: true },
  '0403:8ac9': { name: 'VETNAR / VETMON 2200', katalogId: 'eickemeyer-ekg-2000', treiberMitgeliefert: true },
  '0403:6003': { name: 'EKG 2000 (aeltere Bauart)', katalogId: 'eickemeyer-ekg-2000', treiberMitgeliefert: false },
  '0403:6004': { name: 'VETMON 2150 (aeltere Bauart)', katalogId: 'eickemeyer-ekg-2000', treiberMitgeliefert: false },
};

/* Reine Funktion — deshalb mit aufgezeichnetem Text testbar, ohne dass ein Geraet steckt.
 * Erwartet die Ausgabe von:  reg query "HKLM\SYSTEM\CurrentControlSet\Enum\FTDIBUS" /s */
function usbSeriellAusRegistry(text) {
  const aus = [];
  let vid = null, pid = null, serie = null;
  String(text || '').split(/\r?\n/).forEach((z) => {
    /* Eine Schluesselzeile setzt den Zusammenhang fuer alle folgenden Wertzeilen. */
    const k = z.match(/\\FTDIBUS\\VID_([0-9A-F]{4})\+PID_([0-9A-F]{4})\+([^\\\s]*)/i);
    if (k) { vid = k[1].toLowerCase(); pid = k[2].toLowerCase(); serie = k[3]; return; }
    if (!vid) return;
    const p = z.match(/^\s*PortName\s+REG_SZ\s+(\S+)/i);
    if (!p) return;
    const schluessel = vid + ':' + pid;
    const bekannt = USB_KENNUNGEN[schluessel] || null;
    aus.push({
      port: p[1].toUpperCase(),
      vid: vid, pid: pid, serie: (serie || '').replace(/A$/i, ''),
      name: bekannt ? bekannt.name : null,
      katalogId: bekannt ? bekannt.katalogId : null,
      /* Ehrlich benannt: erkannt heisst ERKANNT, nicht lesbar. */
      erkannt: !!bekannt,
      treiberMitgeliefert: bekannt ? bekannt.treiberMitgeliefert !== false : null,
    });
  });
  return aus;
}

/* ------------------------------------------------------------------ *
 * 1c) ANGESTECKT, ABER OHNE ANSCHLUSS — der Fall, den bisher niemand sah.
 *
 * WARUM DAS NOETIG IST (16.08.2026):
 * usbSeriellAusRegistry() liest den Zweig FTDIBUS. Dorthin kommt ein Geraet aber ERST, wenn
 * der Treiber laeuft und einen COM-Anschluss erzeugt hat. Genau der haeufigste Notfall faellt
 * damit durch: das EKG steckt, Windows kennt es nicht, es steht als unbekanntes Geraet im
 * Geraete-Manager — und beide bisherigen Wege der Station melden "nichts gefunden". Der
 * Anwender sucht den Fehler dann beim Kabel.
 *
 * Der Zweig USB dagegen fuehrt JEDES angesteckte Geraet, auch das ohne Treiber. Nur dort
 * laesst sich "steckt, aber laeuft nicht" von "steckt gar nicht" unterscheiden — und das ist
 * der Unterschied zwischen einer brauchbaren und einer nutzlosen Meldung.
 *
 * Reine Funktion; erwartet die Ausgabe von
 *   reg query "HKLM\SYSTEM\CurrentControlSet\Enum\USB" /s
 * ------------------------------------------------------------------ */
function usbRohAusRegistry(text) {
  const aus = {};
  let vid = null, pid = null, inst = null;
  String(text || '').split(/\r?\n/).forEach((z) => {
    const k = z.match(/\\USB\\VID_([0-9A-F]{4})&PID_([0-9A-F]{4})(?:\\([^\\\s]*))?\s*$/i);
    if (k) {
      vid = k[1].toLowerCase(); pid = k[2].toLowerCase(); inst = k[3] || null;
      /* Eine reine Geraeteklassen-Zeile ohne Instanz ist nur eine Ueberschrift. */
      if (!inst) return;
      const schluessel = vid + ':' + pid;
      const bekannt = USB_KENNUNGEN[schluessel];
      if (!bekannt) return;
      const id = schluessel + '+' + inst;
      if (!aus[id]) {
        aus[id] = {
          vid: vid, pid: pid, serie: inst,
          name: bekannt.name, katalogId: bekannt.katalogId,
          treiberMitgeliefert: bekannt.treiberMitgeliefert !== false,
          /* Wird von der naechsten Service-Zeile gefuellt. Kein Dienst = kein Treiber. */
          dienst: null,
        };
      }
      return;
    }
    if (!inst) return;
    const s = z.match(/^\s*Service\s+REG_SZ\s+(\S+)/i);
    if (!s) return;
    const id = vid + ':' + pid + '+' + inst;
    if (aus[id]) aus[id].dienst = s[1];
  });
  return Object.keys(aus).map((k) => {
    const g = aus[k];
    /* FTDIBUS ist der Bustreiber aus dem mitgelieferten Paket. Steht er da, ist alles gut;
     * steht gar nichts da, hat Windows das Geraet nicht einrichten koennen. */
    g.treiberLaeuft = !!g.dienst;
    g.hinweis = g.treiberLaeuft
      ? null
      : (g.treiberMitgeliefert
        ? 'Das Geraet steckt, Windows hat aber keinen Treiber dafuer geladen. '
          + 'Nachholen: installer\\set-ekg-treiber.ps1 -Erzwingen (als Administrator).'
        : 'Das Geraet steckt, ist aber die AELTERE Bauart (' + g.vid + ':' + g.pid + '). '
          + 'Fuer sie bringt VetStation keinen Treiber mit: das Herstellerpaket 2.08.02 hat '
          + 'keine Katalogdatei und laesst sich unter Windows 11 nicht vorinstallieren. '
          + 'Hier hilft nur das Original-Setup von Eickemeyer.');
    return g;
  });
}

/* Fragt Windows nach ALLEN angesteckten Geraeten der bekannten Kennungen — auch nach denen
 * ohne Treiber. Wirft nie; ein leeres Ergebnis kommt immer MIT Grund. */
function usbRohGeraete() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') {
      return resolve({ ok: false, grund: 'Dieser Weg ist bisher nur fuer Windows gebaut.', liste: [] });
    }
    execFile('reg', ['query', 'HKLM\\SYSTEM\\CurrentControlSet\\Enum\\USB', '/s'],
      { timeout: 12000, windowsHide: true, maxBuffer: 24 * 1024 * 1024 }, (err, stdout) => {
        if (err && !stdout) {
          return resolve({ ok: false, grund: 'Der USB-Zweig der Registry liess sich nicht lesen.', liste: [] });
        }
        resolve({ ok: true, grund: null, liste: usbRohAusRegistry(stdout) });
      });
  });
}

/* Fragt Windows nach USB-seriellen Geraeten. Wie schnittstellen(): nie ein stilles "nichts da". */
function usbSerielleGeraete() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') {
      return resolve({ ok: false, grund: 'Dieser Weg ist bisher nur fuer Windows gebaut.', liste: [] });
    }
    execFile('reg', ['query', 'HKLM\\SYSTEM\\CurrentControlSet\\Enum\\FTDIBUS', '/s'],
      { timeout: 8000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout) => {
        if (err && !stdout) {
          /* Kein FTDIBUS-Schluessel heisst: an diesem PC steckte noch NIE ein FTDI-Geraet.
           * Das ist ein gueltiger Zustand und kein Fehler - der Treiber kann trotzdem liegen. */
          return resolve({
            ok: true,
            grund: 'Windows kennt keinen einzigen FTDI-USB-Anschluss (kein FTDIBUS-Schluessel). ' +
              'Das heisst: an diesem PC war noch nie ein solches Geraet angesteckt. Der ' +
              'mitgelieferte Treiber kann trotzdem bereitliegen - er wirkt erst beim Anstecken.',
            liste: [],
          });
        }
        resolve({ ok: true, grund: null, liste: usbSeriellAusRegistry(stdout) });
      });
  });
}

/* Fragt Windows nach den vorhandenen COM-Anschluessen. Schlaegt der Aufruf fehl, gibt es eine
 * leere Liste UND einen Grund — nie ein stilles "keine gefunden". */
function schnittstellen() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') {
      return resolve({ ok: false, grund: 'Dieser Weg ist bisher nur fuer Windows gebaut.', liste: [] });
    }
    execFile('reg', ['query', 'HKLM\\HARDWARE\\DEVICEMAP\\SERIALCOMM'], { timeout: 5000, windowsHide: true }, (err, stdout) => {
      if (err && !stdout) {
        // Kein Schluessel = kein einziger serieller Anschluss am PC. Das ist ein gueltiger Zustand.
        return resolve({ ok: true, grund: 'Windows meldet keinen einzigen seriellen Anschluss (kein SERIALCOMM-Eintrag). ' +
          'Ein USB-Seriell-Wandler muss eingesteckt und sein Treiber installiert sein.', liste: [] });
      }
      resolve({ ok: true, grund: null, liste: schnittstellenAusRegistry(stdout) });
    });
  });
}

/* ------------------------------------------------------------------ *
 * 2) Die Verbindung
 * ------------------------------------------------------------------ */

/*
 * modeBefehl(port, p) — die Argumente fuer mode.com. Pure Funktion, damit die Zeile geprueft
 * werden kann, ohne eine Schnittstelle zu besitzen.
 *
 * to=off  ist wichtig: ohne diese Angabe laesst Windows Lesevorgaenge in eine Zeitgrenze laufen
 *         und meldet Fehler, sobald das Geraet einmal eine Sekunde schweigt — bei einem Monitor,
 *         der nur alle paar Sekunden sendet, waere das der Normalfall.
 * xon/odsr/octs/dtr/rts: Flusssteuerung AUS. Medizingeraete verlangen sie in aller Regel nicht,
 *         und eine eingeschaltete Steuerleitung, die niemand bedient, laesst die Leitung
 *         stillstehen — ein Fehlerbild, das wie "Geraet sendet nicht" aussieht.
 */
function modeBefehl(port, p) {
  const c = Object.assign({}, VORGABE, p || {});
  return [
    String(port).toUpperCase() + ':',
    'BAUD=' + c.baud, 'PARITY=' + String(c.paritaet).toLowerCase(),
    'DATA=' + c.datenbits, 'STOP=' + c.stopbits,
    'to=off', 'xon=off', 'odsr=off', 'octs=off', 'dtr=on', 'rts=on',
  ];
}

class SerielleVerbindung {
  /*
   * cfg = {
   *   art:  'com' | 'tcp'
   *   port: 'COM3'                 (bei art 'com')
   *   host, tcpPort                (bei art 'tcp' — der Geraeteserver)
   *   baud, datenbits, paritaet, stopbits
   *   erlaubteBefehle: [Buffer|String]  AUSDRUECKLICHE Erlaubnisliste fuers Senden
   * }
   * ctx = { log }
   */
  constructor(cfg, ctx) {
    this.cfg = cfg || {};
    this.ctx = ctx || { log: { info() {}, warn() {}, error() {} } };
    this.art = this.cfg.art === 'com' ? 'com' : 'tcp';
    this.offen = false;
    this._strom = null;
    this._socket = null;
    this._onDaten = null;
    this._onZu = null;
    this.gelesen = 0;
  }

  beiDaten(fn) { this._onDaten = fn; return this; }
  beiEnde(fn) { this._onZu = fn; return this; }

  oeffnen() {
    return this.art === 'com' ? this._oeffnenCom() : this._oeffnenTcp();
  }

  /* --- Geraeteserver: eine ganz normale TCP-Verbindung. Der erprobte Weg. --- */
  _oeffnenTcp() {
    return new Promise((resolve, reject) => {
      const host = this.cfg.host;
      const port = Number(this.cfg.tcpPort || this.cfg.port);
      if (!host || !port) return reject(new Error('Fuer den Geraeteserver fehlen Adresse oder Port.'));
      const s = net.createConnection({ host: host, port: port });
      s.setNoDelay(true);
      s.once('connect', () => {
        this.offen = true; this._socket = s;
        this.ctx.log.info('seriell', 'Geraeteserver ' + host + ':' + port + ' verbunden. ' +
          'Von hier an ist es fuer die Station eine gewoehnliche Netzverbindung.');
        resolve(this);
      });
      s.on('data', (d) => { this.gelesen += d.length; if (this._onDaten) this._onDaten(d); });
      s.on('error', (e) => { if (!this.offen) reject(e); else this.ctx.log.warn('seriell', 'Geraeteserver: ' + e.message); });
      s.on('close', () => { this.offen = false; if (this._onZu) this._onZu(); });
    });
  }

  /* --- Direkt am COM-Anschluss. Unerprobt an echter Hardware — siehe Kopfkommentar. --- */
  _oeffnenCom() {
    const port = String(this.cfg.port || '').toUpperCase();
    if (!/^COM\d+$/.test(port)) return Promise.reject(new Error('Kein gueltiger COM-Anschluss: "' + this.cfg.port + '"'));
    if (process.platform !== 'win32') return Promise.reject(new Error('Der direkte COM-Weg ist bisher nur fuer Windows gebaut.'));

    return new Promise((resolve, reject) => {
      /* Schritt 1: die Schnittstellenparameter setzen. OHNE DAS liest man Buchstabensalat —
       * eine falsche Baudrate erzeugt Bytes, die aussehen wie ein unbekanntes Protokoll. Genau
       * diese Verwechslung waere hier teuer: sie wuerde als "Geraet spricht etwas Fremdes"
       * protokolliert, obwohl nur die Geschwindigkeit nicht stimmt. */
      execFile('mode', modeBefehl(port, this.cfg), { timeout: 6000, windowsHide: true, shell: true }, (err, stdout, stderr) => {
        if (err) {
          return reject(new Error('Die Schnittstelle ' + port + ' liess sich nicht einstellen (' +
            String(stderr || err.message).trim() + '). Gibt es sie? node tools/seriell-pruefen.js zeigt es.'));
        }
        try {
          /* Schritt 2: lesen. Unter Windows ist ein COM-Anschluss als Datei ansprechbar. */
          const strom = fs.createReadStream('\\\\.\\' + port);
          strom.on('open', () => {
            this.offen = true; this._strom = strom;
            this.ctx.log.warn('seriell', 'Serielle Schnittstelle ' + port + ' geoeffnet (' +
              (this.cfg.baud || VORGABE.baud) + ' Baud). HINWEIS: das Oeffnen und Einstellen ist ' +
              'erprobt, das Lesen eines echten Geraets ueber diesen direkten Weg noch nicht. ' +
              'Kommt nichts oder Unlesbares an, zuerst Baudrate und Kabel (Nullmodem?) pruefen, ' +
              'und im Zweifel einen Geraeteserver (RS-232 auf LAN) verwenden: der laeuft ueber den ' +
              'erprobten Netzweg.');
            resolve(this);
          });
          strom.on('data', (d) => { this.gelesen += d.length; if (this._onDaten) this._onDaten(d); });
          strom.on('error', (e) => { if (!this.offen) reject(e); else this.ctx.log.warn('seriell', port + ': ' + e.message); });
          strom.on('close', () => { this.offen = false; if (this._onZu) this._onZu(); });
        } catch (e) { reject(e); }
      });
    });
  }

  /*
   * senden(daten) — NUR was ausdruecklich erlaubt ist.
   *
   * Die Erlaubnisliste steht in der Konfiguration des jeweiligen Adapters, nicht hier. Damit ist
   * an genau einer, sichtbaren Stelle nachlesbar, was die Station je an ein Geraet schickt. Ein
   * Adapter, der einen Verdampfer verstellen wollte, muesste den Befehl dort eintragen — und das
   * faellt in jeder Durchsicht auf. Ohne Liste wird nichts gesendet.
   */
  senden(daten) {
    const erlaubt = this.cfg.erlaubteBefehle;
    if (!erlaubt || !erlaubt.length) {
      this.ctx.log.warn('seriell', 'Senden abgelehnt: fuer diese Verbindung ist keine Erlaubnisliste ' +
        'hinterlegt. VetStation schickt grundsaetzlich nichts an ein Geraet, was nicht ausdruecklich ' +
        'als Datenanfrage erlaubt wurde.');
      return false;
    }
    const b = Buffer.isBuffer(daten) ? daten : Buffer.from(String(daten), 'latin1');
    const passt = erlaubt.some((e) => {
      const eb = Buffer.isBuffer(e) ? e : Buffer.from(String(e), 'latin1');
      return eb.equals(b);
    });
    if (!passt) {
      this.ctx.log.warn('seriell', 'Senden abgelehnt: "' + b.toString('hex') + '" steht nicht in der ' +
        'Erlaubnisliste. Erlaubt sind ausschliesslich Datenanfragen — nie eine Einstellung am Geraet.');
      return false;
    }
    try {
      if (this._socket) { this._socket.write(b); return true; }
      if (this._strom) {
        /* Zum Schreiben braucht die Schnittstelle einen eigenen Griff — der Lesestrom ist
         * ausdruecklich nur lesend geoeffnet. */
        const fd = fs.openSync('\\\\.\\' + String(this.cfg.port).toUpperCase(), 'w');
        fs.writeSync(fd, b);
        fs.closeSync(fd);
        return true;
      }
    } catch (e) {
      this.ctx.log.warn('seriell', 'Senden fehlgeschlagen: ' + e.message);
    }
    return false;
  }

  /*
   * neuEinstellen(p) — die Leitungsparameter aendern, OHNE die Verbindung zu schliessen.
   *
   * WARUM DAS GEBRAUCHT WIRD (16.08.2026): das EKG 2000 meldet sich bei 19200 an und wird
   * fuer die Messung auf 38400 umgeschaltet. Schloesse man dafuer den Anschluss, fielen DTR
   * und RTS ab - viele USB-Seriell-Wandler setzen das Geraet damit zurueck, und die gerade
   * uebertragene Firmware waere wieder weg. mode.com wirkt auch auf einen offenen Anschluss.
   */
  neuEinstellen(p) {
    return new Promise((resolve, reject) => {
      if (this.art !== 'com') return resolve(this);
      const port = String(this.cfg.port || '').toUpperCase();
      Object.assign(this.cfg, p || {});
      execFile('mode', modeBefehl(port, this.cfg), { timeout: 6000, windowsHide: true, shell: true },
        (err, stdout, stderr) => {
          if (err) return reject(new Error('Umschalten auf ' + this.cfg.baud + ' Baud scheiterte: '
            + String(stderr || err.message).trim()));
          this.ctx.log.info('seriell', port + ' auf ' + this.cfg.baud + ' Baud umgestellt (Anschluss blieb offen).');
          resolve(this);
        });
    });
  }

  /*
   * sendenRoh(buf, grund) — der EINE Weg an der Erlaubnisliste vorbei, und er ist absichtlich
   * unbequem.
   *
   * WARUM ES IHN GIBT: eine Firmware besteht aus hunderten verschiedener Bytes. Sie in eine
   * Erlaubnisliste zu schreiben, ist unmoeglich - und eine Liste, die alles erlaubt, waere
   * keine. Statt die Liste aufzuweichen (dann waere sie ueberall wertlos), gibt es hier eine
   * ZWEITE Tuer, die
   *   - nur aufgeht, wenn die Verbindung ausdruecklich mit firmwareErlaubt:true gebaut wurde,
   *   - jeden Vorgang mit Grund und Byteanzahl protokolliert,
   *   - und ausschliesslich von ekg2000.js benutzt wird.
   * Damit bleibt die Zusage "VetStation verstellt kein Geraet" ueberpruefbar: wer sie brechen
   * wollte, muesste firmwareErlaubt setzen, und das steht sichtbar in der Konfiguration.
   *
   * Das EKG 2000 ist der einzige Fall, in dem Schreiben ueberhaupt noetig ist - ohne
   * Firmware sendet es nichts. Es wird dabei nichts VERSTELLT: das Geraet hat keine
   * Einstellungen, die eine Behandlung beeinflussen koennten.
   */
  sendenRoh(buf, grund) {
    if (!this.cfg.firmwareErlaubt) {
      this.ctx.log.warn('seriell', 'Rohsenden abgelehnt: diese Verbindung ist nicht mit '
        + 'firmwareErlaubt gebaut. ' + (grund || ''));
      return false;
    }
    const b = Buffer.isBuffer(buf) ? buf : Buffer.from(String(buf), 'latin1');
    try {
      if (this._socket) { this._socket.write(b); return true; }
      if (this._strom) {
        const fd = fs.openSync('\\\\.\\' + String(this.cfg.port).toUpperCase(), 'w');
        fs.writeSync(fd, b);
        fs.closeSync(fd);
        return true;
      }
    } catch (e) {
      this.ctx.log.warn('seriell', 'Rohsenden fehlgeschlagen: ' + e.message);
    }
    return false;
  }

  schliessen() {
    this.offen = false;
    try { if (this._strom) this._strom.destroy(); } catch (_) {}
    try { if (this._socket) this._socket.destroy(); } catch (_) {}
    this._strom = null; this._socket = null;
  }
}

module.exports = {
  SerielleVerbindung, schnittstellen, schnittstellenAusRegistry, modeBefehl, VORGABE,
  usbSerielleGeraete, usbSeriellAusRegistry, USB_KENNUNGEN,
  usbRohGeraete, usbRohAusRegistry,
};
