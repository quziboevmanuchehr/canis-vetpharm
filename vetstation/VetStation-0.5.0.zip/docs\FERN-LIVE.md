# Fern-Live — Werte & Monitor über das Internet ansehen

Der Praxis-PC (VetStation) liest die Geräte, berechnet die Empfehlungen **und** schreibt
die Live-Werte ~1×/Sekunde in ein Cloud-Relay (Firebase). Die öffentliche Web-App
`quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/` liest sie und zeigt
denselben Monitor + dieselben Empfehlungen **fern** an — z. B. von zu Hause.

- **Read-only:** Fern-Zuschauer können die Geräte niemals steuern.
- **Datensparsam:** Es werden nur Vitalwerte, Tierart, Gewicht, Iso % und der Befundtext
  übertragen — **keine Klarnamen/Personendaten**.
- **Zugriff nur mit Code:** Der Code ist Teil des Links. Wer den Link nicht hat, sieht nichts.

```
Praxis-PC (VetStation-Bridge)            Firebase Realtime DB            Web-App (GitHub Pages)
  liest Geräte  ─►  Brain/Empfehlung ─►  /live/<code>  ◄─ abonniert ─►  Fern-Ansicht (?live=<code>)
                    schreibt ~1×/s                                       Monitor + Empfehlungen live
```

---

## Einmalige Einrichtung (~10 Minuten)

### 1) Realtime Database aktivieren
[console.firebase.google.com](https://console.firebase.google.com) → Projekt **vet-station**
→ **Build → Realtime Database → Datenbank erstellen** → Region **europe-west1** (Frankfurt)
→ **im gesperrten Modus** starten.
Notiere die **Datenbank-URL** oben, z. B.
`https://vet-station-default-rtdb.europe-west1.firebasedatabase.app`.

### 2) (entfällt) — keine Anmeldung nötig
Der Praxis-PC schreibt **ohne Anmeldung** (Zugriff wird über den unratbaren Code + die Regeln
geschützt). Du musst in Authentication **nichts** einrichten.

### 3) Sicherheitsregeln setzen
**Realtime Database → Regeln** → den kompletten Inhalt von
[`installer/firebase-rtdb-rules.json`](../installer/firebase-rtdb-rules.json) einfügen → **Veröffentlichen**.
(Lesen: jeder mit dem Code. Schreiben: nur der angemeldete Praxis-PC, und nur unter dem eigenen Code.)

### 4) Web-API-Key holen
**Projekteinstellungen (Zahnrad) → Allgemein → Deine Apps → Web-App → SDK-Konfiguration.**
Kopiere `apiKey` und `databaseURL`.
(Falls noch keine Web-App existiert: **App hinzufügen → Web**, Namen z. B. „canis-anaesthesie", registrieren.)

### 5) Praxis-PC konfigurieren (VetStation)
`bridge/config/devices.json` öffnen (falls nicht vorhanden: `bridge/config/devices.example.json`
kopieren nach `devices.json`) und den `cloud`-Block ausfüllen:

```json
"cloud": {
  "enabled": true,
  "provider": "firebase",
  "apiKey": "<dein Web-API-Key>",
  "dbUrl": "https://vet-station-default-rtdb.europe-west1.firebasedatabase.app",
  "code": "praxis-op1-Xy7k3",
  "station": "Praxis OP 1",
  "minIntervalMs": 1000
}
```
- **`code`** unratbar wählen (Buchstaben/Ziffern/Bindestrich). Er ist der Zugangs-Link.
- VetStation **neu starten**. Im Log erscheint: `cloud: Fern-Live AKTIV → https://…?live=<code>`.
- Der fertige Link steht auch im **Admin → 📡 Fern-Live → „Kopieren"**.

### 6) Web-App einmalig konfigurieren (Repo `canis-vetpharm`)
In `canis-anaesthesie/index.html` das Objekt **`window.VETLIVE_CFG`** mit `apiKey` und
`databaseURL` füllen (identisch zu Schritt 4/5). `authDomain`/`projectId` sind bereits gesetzt.
Danach die Web-App wie üblich zu GitHub Pages deployen.

> Hinweis: `apiKey` und `databaseURL` sind **öffentliche** Firebase-Web-Werte (kein Geheimnis) —
> sie stehen bei jeder Firebase-Web-App im Browser. Die Sicherheit kommt aus den Regeln + dem Code.

### 7) Fern schauen
Zuhause im Browser öffnen:
```
https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/?live=<code>
```
Oben erscheint die Leiste **📡 FERN-ANSICHT** mit Verbindungsstatus und — bei mehreren
Patienten — einem Umschalter. Der Monitor (EKG/Kapno/Werte) und die Empfehlungen laufen live.

---

## Testen ohne Geräte / ohne Firebase
- **Web-Viewer offline** (synthetische Werte, kein Firebase):
  `…/canis-anaesthesie/?livedemo=1`
- **Publisher-Selbsttest:** `node tools/cloud-test.js` (Mock-Firebase, 26 Prüfungen)
- **Ende-zu-Ende (Bridge→Cloud):** `node tools/cloud-integration-test.js` (echte Bridge + Simulator)

## Sicherheit & Abschalten
- Teile den Link nur mit befugten Personen. Wer den Code hat, kann mitlesen (nicht steuern).
- **Abschalten:** `cloud.enabled = false` in `devices.json` → neu starten. Oder den `code`
  ändern → alle alten Links sind sofort tot.
- Der Refresh-Token des Praxis-PCs liegt lokal in `data/cloud-auth.json` (ist git-ignoriert).

## Fehlersuche
| Symptom (Web-App-Leiste) | Ursache / Lösung |
|---|---|
| „Firebase nicht konfiguriert" | `window.VETLIVE_CFG` in index.html noch mit Platzhalter → Schritt 6. |
| „Verbindungsfehler" | `databaseURL` falsch/Region stimmt nicht, oder Regeln nicht veröffentlicht. |
| „keine neuen Daten (Xs)" | Praxis-PC sendet nicht: VetStation läuft nicht, `cloud.enabled`? Log prüfen. |
| Log: `Schreibfehler … 401/403` | Anonyme Anmeldung nicht aktiviert (Schritt 2) oder Regeln (Schritt 3). |
| Fern-Leiste bleibt leer | Es sind (noch) keine Geräte/Patienten am Praxis-PC aktiv. |
