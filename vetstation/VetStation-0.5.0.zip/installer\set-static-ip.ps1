<#
  set-static-ip.ps1 — Richtet die statische IP fuer das ISOLIERTE Geraete-Netz ein (§ LAN-Setup).
  Interaktiv: zeigt die Netzwerkkarten, du waehlst die Karte, die am Geraete-Switch haengt.
  Setzt standardmaessig 192.168.0.99/24 OHNE Gateway (isoliert, kein Router).

  WARUM 192.168.0.99? Im uMEC12 Vet steht unter "Gateway-Kommunikationseinst." bereits
  Ziel 192.168.0.99 Port 3502. Wenn der PC GENAU diese IP bekommt, muss am Geraet nichts
  umgestellt werden ausser der eigenen Geraete-IP (DHCP schlaegt ohne Router fehl!).

  WICHTIG: Nur die Karte auswaehlen, die zum Geraete-Switch geht — NICHT die Karte mit
  Internet/Praxisnetz. Als Administrator ausfuehren.

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\set-static-ip.ps1
  Nicht-interaktiv:  -Adapter "Ethernet 2" -IP 192.168.0.99 -Prefix 24
#>
param(
  [string]$Adapter,
  [string]$IP = '192.168.0.99',
  [int]$Prefix = 24
)

Write-Host "== Statische IP fuer das isolierte Geraete-Netz =="
Write-Host "Im Monitor steht als Ziel bereits:  192.168.0.99  Port 3502  (Gateway-Kommunikationseinst.)"
Write-Host "-> Der PC bekommt deshalb GENAU diese IP: $IP /$Prefix (kein Gateway, isoliert)."
Write-Host "   Dann musst du am Geraet nur noch die EIGENE Geraete-IP fest eintragen."
Write-Host ""
Write-Host "ACHTUNG - haeufigste Ursache 'verbindet nicht':"
Write-Host "   Der Monitor stand auf DHCP und hat KEINE IP bekommen (0.0.0.0,"
Write-Host "   Meldung 'Abrufen der Netzwerkadr. fehlgeschlagen') - ohne Router gibt es keinen DHCP."
Write-Host "   Loesung: am Monitor Adresstyp auf 'Manuell/Statisch' stellen (siehe Schritte unten)."
Write-Host ""

$nics = Get-NetAdapter | Where-Object Status -in @('Up','Disconnected') | Sort-Object Name
if (-not $Adapter) {
  Write-Host "Verfuegbare Netzwerkkarten:"
  $i = 0; $nics | ForEach-Object { Write-Host ("  [{0}] {1}  ({2}, {3})" -f $i, $_.Name, $_.InterfaceDescription, $_.Status); $i++ }
  $sel = Read-Host "Nummer der Karte am GERAETE-Switch"
  if ($sel -notmatch '^\d+$' -or [int]$sel -ge $nics.Count) { Write-Warning "Ungueltige Auswahl."; exit 1 }
  $Adapter = $nics[[int]$sel].Name
}

Write-Host ""
Write-Host "Setze auf Karte '$Adapter':  IP $IP /$Prefix, kein Gateway (isoliert)."
$ok = Read-Host "Fortfahren? (j/N)"
if ($ok -notmatch '^(j|y)') { Write-Host "Abgebrochen."; exit 0 }

try {
  # Vorhandene statische IPs/Routen dieser Karte entfernen, dann setzen
  Get-NetIPAddress -InterfaceAlias $Adapter -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object PrefixOrigin -eq 'Manual' | Remove-NetIPAddress -Confirm:$false -ErrorAction SilentlyContinue
  New-NetIPAddress -InterfaceAlias $Adapter -IPAddress $IP -PrefixLength $Prefix -ErrorAction Stop | Out-Null
  # DNS leeren (isoliert)
  Set-DnsClientServerAddress -InterfaceAlias $Adapter -ResetServerAddresses -ErrorAction SilentlyContinue
  Write-Host "OK. '$Adapter' hat jetzt $IP/$Prefix."
  Write-Host ""
  Write-Host "NAECHSTE SCHRITTE AM MONITOR (uMEC12 Vet) - genau in dieser Reihenfolge:"
  Write-Host "  1) Hauptmenue -> Wartung -> Benutzer-Wartung  (Passwort 888888)"
  Write-Host "  2) Netzwerk -> Monitornetzwerk-Setup:"
  Write-Host "       Netzwerktyp : LAN"
  Write-Host "       Adresstyp   : Manuell / Statisch   <-- NICHT DHCP (sonst 0.0.0.0!)"
  Write-Host "       IP-Adresse  : 192.168.0.50"
  Write-Host "       Subn.maske  : 255.255.255.0"
  Write-Host "       Gateway     : 192.168.0.1   (oder 0.0.0.0, wenn kein Router)"
  Write-Host "     -> OK. Die IP darf danach NICHT mehr 0.0.0.0 sein."
  Write-Host "  3) Netzwerk -> Gateway-Kommunikationseinst.:  IP $IP   Port 3502   -> OK"
  Write-Host "  4) Zweites Geraet (LifeVet) analog: IP 192.168.0.51, gleiches Ziel $IP."
  Write-Host "  5) Am PC pruefen:   npm run check      (zeigt, ob Daten ankommen)"
  Write-Host "  - Details: docs\LAN-SETUP.md"
} catch {
  Write-Warning "Fehler: $($_.Exception.Message)"
  Write-Host "Alternativ manuell: Systemsteuerung -> Netzwerkadapter -> IPv4 -> feste IP $IP, Maske 255.255.255.0, kein Gateway."
}
