# LAN-Aufbau — PC + Monitor + Kapnograf verbinden

> ## ⭐ ZUERST LESEN: die 3 Gründe, warum „es verbindet nicht"
> Am 21.07.2026 direkt an den Praxis-Fotos des uMEC12 Vet festgestellt:
>
> **1. Der Monitor hatte KEINE IP-Adresse.** Im Menü *Monitornetzwerk-Setup* stand
> `Adresstyp: DHCP` und `IP-Adresse 0.0.0.0`, dazu die Meldung
> **„Abrufen der Netzwerkadr. fehlgeschlagen"**. Ohne Router gibt es keinen DHCP-Server,
> der Adressen vergibt → das Gerät bleibt auf `0.0.0.0` und kann **nichts** senden.
> **Lösung:** Adresstyp auf **Manuell/Statisch** stellen (Werte unten).
>
> **2. Der Monitor sendet an Port 3502 — dort lauschte VetStation nicht.** Unter
> *Gateway-Kommunikationseinst.* steht das Ziel **`192.168.0.99 : 3502`**. VetStation
> hörte bis 0.4.0 nur auf 4601/5000/24105/2575. **Ab 0.5.0 wird 3502 zuerst gelauscht.**
>
> **3. Die Windows-Firewall blockierte eingehende Verbindungen.** Ohne Freigabe verwirft
> Windows die Gerätedaten lautlos. **Der Installer legt die Regeln jetzt automatisch an**
> (TCP 3502/4601/5000/24105/2575).
>
> ### Einstellungen, die zusammenpassen müssen
> | Wo | Einstellung | Wert |
> |---|---|---|
> | **PC** | feste IP (isoliert) | **192.168.0.99** / 255.255.255.0 |
> | **Monitor** → Monitornetzwerk-Setup | Adresstyp | **Manuell** (nicht DHCP!) |
> | **Monitor** → Monitornetzwerk-Setup | IP-Adresse | **192.168.0.50** / 255.255.255.0 |
> | **Monitor** → Gateway-Kommunikationseinst. | Ziel-IP / Port | **192.168.0.99** / **3502** |
> | 2. Gerät (LifeVet) | IP-Adresse | 192.168.0.51 (gleiches Ziel) |
>
> **Ablauf:** `installer\set-static-ip.ps1` (PC auf .99) → am Monitor die 4 Werte eintragen →
> VetStation starten → **`npm run check`** zeigt, ob Daten ankommen.
> Menüweg am Gerät: *Hauptmenü → Wartung → Benutzer-Wartung (Passwort **888888**) → Netzwerk*.

Dein PC hat **nur einen LAN-Anschluss** — deshalb ist ein **kleiner LAN-Switch/Hub Pflicht**, um
3–5 Geräte zusammenzubinden. Aufbau:

```
   [uMEC12 Vet Monitor] --LAN(CS)--\
   [Veta 5 Plus]         --LAN(CS)-- >--[ kleiner Gigabit-Switch ]--LAN--[ Windows-PC: VetStation ]
   (weitere Geräte)      ----------/
```

## Was du brauchst (günstig)
- **1 kleiner Gigabit-Switch** (5–8 Ports, ~15–25 €) — ein **eigenes, isoliertes** Geräte-Netz.
- **LAN-Kabel** für jedes Gerät + den PC.
- Der **Windows-10-Pro-PC** (i3/8 GB genügt).

## Netzwerk (feste IPs, passend zu deinen Geräten)
Deine Geräte stehen laut Foto schon auf **192.168.23.x** (z. B. Veta `192.168.23.250`, Maske `255.255.255.0`).
Am einfachsten: **den PC in dasselbe Netz** setzen — dann musst du an den Geräten die IP **nicht** ändern.

| Gerät | IP | Maske |
|---|---|---|
| **PC (VetStation)** | `192.168.23.10` | `255.255.255.0` (/24) |
| Veta 5 Plus | `192.168.23.250` (unverändert) | /24 |
| uMEC12 Vet Monitor | z. B. `192.168.23.251` | /24 |

- PC-IP setzen: `installer\set-static-ip.ps1` (setzt `192.168.23.10`, Karte auswählen).
- Geräte-IP ablesen/ändern am Gerät: `System → Setup → IP-Adresse` (IP automatisch beziehen = AUS).

> **Wichtig — alle Geräte in EIN Netz:** Laut deinen Fotos stehen die Geräte auf **verschiedenen**
> Subnetzen (uMEC/Veta: `192.168.23.x`, LifeVet 10C: `192.168.2.x`). Für VetStation müssen PC **und alle
> Geräte im selben Subnetz** sein. Am einfachsten: alle auf `192.168.23.x` setzen — z. B. LifeVet von
> `192.168.2.x` auf `192.168.23.240` ändern (am LifeVet: `Wartung → … → Netzwerk`), PC bleibt `192.168.23.10`.
> Der Verbindungs-Assistent erkennt beide Mindray-Typen automatisch (MAC-Präfixe 98:CC:E4 und 00:0F:14).
- **Kein Gateway/Internet nötig** — isoliertes Netz. (Ohne Internet nutzt VetStation die **lokal
  mitgelieferte** Klinik-Datenbasis; das ist voll funktionsfähig. Updates ziehen sich nur, wenn der PC
  zusätzlich Internet hat, z. B. über WLAN.)

## Verbinden & einstellen (der eigentliche Knackpunkt)
**Ehrliche Lage:** Der **LifeVet 10C** (Mindray-Monitor) hat einen **dokumentierten HL7-Menüpunkt** — er ist
der beste Weg. Der **uMEC12 Vet** sendet evtl. nur proprietäres MD2; das zeigt der **Verbindungs-Assistent**.
Vorgehen:

1. Alles verkabeln (ein Switch, ein Subnetz), PC-IP `192.168.23.10` setzen.
2. **VetStation starten** (Verbindungs-Assistent läuft automatisch, lauscht auf 4601/5000/24105/2575).
3. **Am LifeVet 10C zuerst**: `Wartung → Benutzer-Wartung (Passwort 888888) → Netzwerk → EMR-Kommunikation`
   → **Server-IP = 192.168.23.10, Protokoll = HL7, „Real Data Send" = EIN, Port = 4601**.
   **Am uMEC12 Vet**: `… → Netzwerk → Gateway-Comm-Setup` → IP=192.168.23.10, Port=4601 (testen). Details: [MINDRAY-HL7.md](MINDRAY-HL7.md).
4. **VetStation-Admin → „Verbindung/Fehler"** ansehen:
   - „✓ HL7 ERKANNT auf Port 4601" → läuft, Patient erscheint. **Fertig.**
   - „KEIN HL7 erkannt" → Gerät sendet proprietär → Fallback (VSCapture/eGateway), siehe MINDRAY-HL7.md.

`ping 192.168.23.250` vom PC muss klappen → physisches Netz steht.

## Sicherheit (§10)
- **Nur lesen** — VetStation sendet **nie** etwas an die Geräte (kein Verstellen von Verdampfer/Beatmung).
- **Isoliertes Geräte-Netz** (eigener Switch). Patientendaten bleiben **lokal** auf dem PC.

## Mit dem Händler klären
1. Sendet der uMEC **HL7 über LAN (Port 4601)** oder nur **MD2** an die BeneVision CMS Vet? Menüpfad/Port? **Freigeschaltet/Lizenz?**
2. Gibt es einen **offenen Datenausgang (HL7/eGateway)** für Monitor und/oder Veta — und was kostet die Freischaltung?
