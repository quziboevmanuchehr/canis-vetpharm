'use strict';
/*
 * usb-geraete-test.js — erkennt die Station ein angestecktes USB-Diagnostik-EKG?
 *
 * WARUM ES DIESEN TEST GIBT (12.08.2026):
 * Die Station liefert seit dem 07.08.2026 den USB-Treiber des Eickemeyer/Grimed EKG 2000 mit
 * und installiert ihn still vor. Beim Anstecken richtet Windows das Geraet daraufhin ohne
 * Nachfrage ein - und die Station sagte dazu bis heute GAR NICHTS. Der Anwender sah einen
 * neuen COM-Anschluss im Geraete-Manager und in VetStation nichts, ohne jeden Hinweis,
 * woran es liegt. usbSeriellAusRegistry() schliesst diese Luecke.
 *
 * WAS HIER GEPRUEFT WIRD UND WAS NICHT - der Unterschied ist wichtig genug fuer den Kopf:
 *   GEPRUEFT wird das LESEN der Windows-Registry-Ausgabe: findet die Funktion Kennung,
 *     Seriennummer und Anschluss, ordnet sie dem richtigen Katalogeintrag zu, und schweigt
 *     sie bei fremden Kennungen statt zu raten?
 *   NICHT GEPRUEFT wird, ob sich vom EKG 2000 Messwerte lesen lassen. Das Datenformat ist
 *     unbekannt (siehe Katalogeintrag eickemeyer-ekg-2000). "Erkannt" heisst hier ERKANNT,
 *     nicht lesbar - und der Test haelt genau diese Unterscheidung fest.
 *
 * HERKUNFT DER PROBEDATEN, ehrlich benannt:
 * An diesem Entwicklungsrechner steckt kein FTDI-Geraet (nachgesehen 12.08.2026: der
 * Schluessel HKLM\SYSTEM\CurrentControlSet\Enum\FTDIBUS existiert nicht). Der Probetext ist
 * deshalb NICHT von einem Geraet mitgeschnitten, sondern nach der von Windows verwendeten
 * Ablage aufgebaut; die Kennungen VID_0403/PID_8AC8 und PID_8AC9 stehen woertlich in der
 * mitgelieferten treiber/ekg2000/ftdibus.inf. Sobald ein echtes Geraet an einem Praxis-PC
 * haengt, gehoert dessen echte Ausgabe hier hinein - bis dahin sagt dieser Absatz, worauf
 * der Test wirklich beruht.
 *
 * Start: node tools/usb-geraete-test.js
 */
const S = require('../bridge/src/seriell.js');
const K = require('../bridge/src/geraetekatalog.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

/* Der Rueckwaertsstrich wird hier zusammengesetzt statt geschrieben: eine Zeichenkette voller
 * "\\" ist in diesem Projekt schon einmal beim Durchreichen durch eine Shell zerfallen, und
 * der Test war danach gruen, weil er gar nichts mehr enthielt, was haette scheitern koennen. */
const BS = String.fromCharCode(92);
function reg() { return Array.prototype.slice.call(arguments).join(BS); }

const PROBE = [
  reg('HKEY_LOCAL_MACHINE', 'SYSTEM', 'CurrentControlSet', 'Enum', 'FTDIBUS'),
  '',
  reg('HKEY_LOCAL_MACHINE', 'SYSTEM', 'CurrentControlSet', 'Enum', 'FTDIBUS', 'VID_0403+PID_8AC8+EK2K0017A'),
  '',
  reg('HKEY_LOCAL_MACHINE', 'SYSTEM', 'CurrentControlSet', 'Enum', 'FTDIBUS', 'VID_0403+PID_8AC8+EK2K0017A', '0000'),
  '    FriendlyName    REG_SZ    EKG 2000 Serial Port (COM5)',
  '',
  reg('HKEY_LOCAL_MACHINE', 'SYSTEM', 'CurrentControlSet', 'Enum', 'FTDIBUS', 'VID_0403+PID_8AC8+EK2K0017A', '0000', 'Device Parameters'),
  '    PortName    REG_SZ    COM5',
  '',
  /* Ein zweites Geraet derselben Familie ... */
  reg('HKEY_LOCAL_MACHINE', 'SYSTEM', 'CurrentControlSet', 'Enum', 'FTDIBUS', 'VID_0403+PID_8AC9+VN22A004A', '0000', 'Device Parameters'),
  '    PortName    REG_SZ    COM7',
  '',
  /* ... und ein FREMDER FTDI-Wandler (der Allerweltschip FT232R). Er MUSS auftauchen, aber
   * ohne Namen: sonst wuerde jeder beliebige USB-Seriell-Adapter als EKG gemeldet. */
  reg('HKEY_LOCAL_MACHINE', 'SYSTEM', 'CurrentControlSet', 'Enum', 'FTDIBUS', 'VID_0403+PID_6001+A50285BIA', '0000', 'Device Parameters'),
  '    PortName    REG_SZ    COM9',
].join('\r\n');

console.log('\nVetStation - USB-Geraete am seriellen Weg\n');

block('1. der Probetext wird ueberhaupt gelesen');
const liste = S.usbSeriellAusRegistry(PROBE);
console.log('    gefunden: ' + liste.map((g) => g.port + '=' + (g.name || 'unbekannt')).join(', '));
pruef('drei Geraete gefunden', liste.length === 3, String(liste.length));

block('2. das EKG 2000 wird namentlich erkannt');
const ekg = liste.filter((g) => g.port === 'COM5')[0];
pruef('COM5 ist vorhanden', !!ekg);
if (ekg) {
  pruef('COM5 heisst EKG 2000', ekg.name === 'EKG 2000', String(ekg.name));
  pruef('COM5 traegt die Kennung 0403:8ac8', ekg.vid === '0403' && ekg.pid === '8ac8', ekg.vid + ':' + ekg.pid);
  pruef('die Seriennummer ist ohne das angehaengte A uebernommen', ekg.serie === 'EK2K0017', ekg.serie);
  pruef('COM5 zeigt auf den Katalogeintrag', ekg.katalogId === 'eickemeyer-ekg-2000', String(ekg.katalogId));
  pruef('und ist als erkannt ausgewiesen', ekg.erkannt === true);
}
const vetnar = liste.filter((g) => g.port === 'COM7')[0];
pruef('das VETNAR 2200 wird ebenfalls erkannt', !!vetnar && /VETNAR/.test(vetnar.name || ''), vetnar ? String(vetnar.name) : 'fehlt');

block('3. ein fremder Wandler wird NICHT als EKG ausgegeben');
/* Das ist die eigentlich wichtige Pruefung. Der FT232R sitzt in unzaehligen Adaptern. Wuerde
 * er als EKG gemeldet, bekaeme der Anwender an einem beliebigen USB-Adapter die Aufforderung,
 * sein EKG anzuschliessen - und misstraute der Erkennung danach zu Recht ueberall. */
const fremd = liste.filter((g) => g.port === 'COM9')[0];
pruef('COM9 taucht auf (der Anschluss existiert ja)', !!fremd);
if (fremd) {
  pruef('COM9 bekommt KEINEN Namen angedichtet', fremd.name === null, String(fremd.name));
  pruef('COM9 zeigt auf KEINEN Katalogeintrag', fremd.katalogId === null, String(fremd.katalogId));
  pruef('COM9 gilt als nicht erkannt', fremd.erkannt === false);
}

block('4. leere und kaputte Eingaben');
[['', 0], [null, 0], [undefined, 0], ['voelliger Unsinn ohne Registrytext', 0],
  ['    PortName    REG_SZ    COM3', 0]].forEach(([t, n]) => {
  const r = S.usbSeriellAusRegistry(t);
  pruef('"' + String(t).slice(0, 28) + '" ergibt ' + n + ' Geraete', r.length === n, String(r.length));
});
/* Eine PortName-Zeile OHNE vorangehende Schluesselzeile darf nichts erzeugen - sonst
 * entstuende ein Geraet ohne Kennung, und das waere schlimmer als keins. */

block('5. die Kennungen stimmen mit der mitgelieferten INF ueberein');
const fs = require('fs');
const path = require('path');
const infPfad = path.join(__dirname, '..', 'treiber', 'ekg2000', 'ftdibus.inf');
if (fs.existsSync(infPfad)) {
  const inf = fs.readFileSync(infPfad, 'latin1');
  Object.keys(S.USB_KENNUNGEN).forEach((k) => {
    const [vid, pid] = k.split(':');
    const gesucht = new RegExp('VID_' + vid + '&PID_' + pid, 'i');
    pruef('Kennung ' + k + ' steht wirklich in ftdibus.inf', gesucht.test(inf));
  });
  /* Und andersherum: steht in der INF eine Kennung, die die Station nicht kennt, waere das
   * ein Geraet, das der mitgelieferte Treiber einrichtet und niemand benennt. */
  const inInf = (inf.match(/VID_0403&PID_([0-9A-F]{4})/gi) || [])
    .map((s) => s.slice(-4).toLowerCase());
  const unbekannt = inInf.filter((pid) => !S.USB_KENNUNGEN['0403:' + pid]);
  pruef('kein Geraet der INF bleibt ohne Namen', unbekannt.length === 0,
    'ohne Namen: ' + unbekannt.join(', '));
} else {
  pruef('treiber/ekg2000/ftdibus.inf ist vorhanden', false, infPfad);
}

block('6. der Katalogeintrag dahinter sagt die Wahrheit');
const g = K.nachId('eickemeyer-ekg-2000');
pruef('der Katalogeintrag existiert', !!g);
if (g) {
  pruef('er steht unter der Kategorie ekg, nicht monitor', g.kategorie === 'ekg', g.kategorie);
  /* DIE WICHTIGSTE PRUEFUNG DIESER DATEI. Solange das Datenformat unbekannt ist, DARF der
   * Katalog nicht behaupten, das Geraet liefere Werte. Wer diese Zeile rot macht, indem er
   * "liefert" schoenredet, ohne das Protokoll zu kennen, baut genau die stille Falschaussage
   * ein, die dieses Projekt an anderer Stelle schon zweimal gekostet hat. */
  const weg = (g.wege || [])[0];
  pruef('der Weg ist als unbestaetigt ausgewiesen', weg && weg.vertrauen === 'unbestaetigt',
    weg ? weg.vertrauen : 'kein Weg');
  pruef('und sagt ausdruecklich, dass noch nichts gelesen wird',
    weg && /NOCH NICHTS/.test(weg.liefert), weg ? weg.liefert.slice(0, 60) : '-');
  pruef('der Lizenzcode wird als Software-Code erklaert, nicht als Geraetepasswort',
    /kein Geraetepasswort|KEIN GERAETEPASSWORT/i.test(g.fallstricke || ''));
  pruef('die Kennung VID_0403/PID_8AC8 steht im Eintrag',
    /8AC8/i.test(JSON.stringify(g)));
}

console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
