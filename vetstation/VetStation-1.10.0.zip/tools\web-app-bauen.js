'use strict';
/*
 * web-app-bauen.js — baut canis-vetpharm/canis-anaesthesie/index.html neu aus der Quelle.
 *
 * WARUM ES DIESES WERKZEUG GIBT:
 * Die Fern-Web-App IST die App der Station plus zwei additive Teile:
 *   1) FERN-LIVE-SEAM  — laeuft INNERHALB der Motor-IIFE (braucht state/istInit/MON),
 *                        liegt daneben als tools/web-fern-seam.js
 *   2) FERN-MODUL      — alles ab dem Marker "<!-- ===== FERN-LIVE Ansicht",
 *                        eigener Gueltigkeitsbereich, wird aus der bisherigen Fassung uebernommen
 *
 * Bis 1.3.4 war das ein Merksatz in der Dokumentation: "beim Aktualisieren neu kopieren und Modul
 * + applyLive-Seam wieder anfuegen". Ein Merksatz ist kein Verfahren — wer ihn einmal uebersieht,
 * liefert eine Fern-Ansicht aus, die entweder alt ist oder gar keine Werte mehr annimmt. Jetzt ist
 * es ein Programm, das danach NACHSIEHT, ob wirklich alles drin ist.
 *
 * Aufruf:
 *   node tools/web-app-bauen.js ui/app/index.html ../../canis-vetpharm/canis-anaesthesie/index.html
 *
 * Es kopiert ausserdem anaes-data.js und shared/geraete-profile.js zeichengleich mit — eine Kopie,
 * die man abschreibt statt kopiert, ist eine Zeitbombe mit Zufallszuender (Befund 04.08.2026:
 * die Bridge las jahrelang eine ANDERE anaes-data.js als der Browser).
 * tools/geraete-profil-test.js prueft die Zeichengleichheit bei jedem Testlauf.
 */
const fs = require('fs');
const path = require('path');

const QUELL = process.argv[2];
const WEB = process.argv[3];
const SEAM_DATEI = path.join(__dirname, 'web-fern-seam.js');

const MARKER_ENDE = '\n<!-- ================= FERN-LIVE Ansicht';
const ANKER = '}catch(e){}\n})();\n</script>';

const src = fs.readFileSync(QUELL, 'utf8');
const alt = fs.readFileSync(WEB, 'utf8');
const seam = fs.readFileSync(SEAM_DATEI, 'utf8');

const i = alt.indexOf(MARKER_ENDE);
if (i < 0) { console.error('FEHLER: Fern-Modul-Marker nicht gefunden — Abbruch, nichts geschrieben.'); process.exit(1); }
const fernModul = alt.slice(i);

const j = src.indexOf(ANKER);
if (j < 0) { console.error('FEHLER: Anker "}catch(e){}\\n})();" in der Quelle nicht gefunden — Abbruch.'); process.exit(1); }
if (src.indexOf(ANKER, j + 1) >= 0) { console.error('FEHLER: Anker kommt MEHRFACH vor — Abbruch (sonst landet der Seam an der falschen Stelle).'); process.exit(1); }

const vorher = src.slice(0, j + '}catch(e){}\n'.length);
const nachher = src.slice(j + '}catch(e){}\n'.length);   // beginnt mit "})();\n</script>"

// Alles nach </script> bis zum Fern-Marker aus der QUELLE uebernehmen (dort stehen die
// zusaetzlichen Style-/Skriptbloecke der App), das Fern-Modul aus der bisherigen Web-Fassung.
const neu = vorher + seam + nachher.replace(/\s*$/, '\n') + fernModul;

fs.writeFileSync(WEB, neu);

// Mitgelieferte Dateien 1:1 kopieren — NIE abschreiben (siehe Kopf).
const webWurzel = path.join(path.dirname(WEB), '..');
const quellWurzel = path.join(path.dirname(QUELL), '..');   // .../ui
[['app/anaes-data.js', 'canis-anaesthesie/anaes-data.js'],
 ['shared/geraete-profile.js', 'shared/geraete-profile.js'],
 // Diagnostik-EKG (07.08.2026): die App laedt beide ueber ../shared/. Sie MUESSEN mitkopiert
 // werden — sonst laedt die Fern-Web-App zwei Dateien, die es dort nicht gibt: der PDF-Knopf
 // meldet dann "PDF-Bibliothek nicht geladen" und die Messung faellt still auf das Modell zurueck.
 ['shared/jspdf.umd.min.js', 'shared/jspdf.umd.min.js'],
 ['shared/ekg-analyse.js', 'shared/ekg-analyse.js'],
 // Wissensbasis (203 belegte Befundregeln) - die Web-App zeigt dasselbe Nachschlagewerk.
 ['shared/ekg-befunde.js', 'shared/ekg-befunde.js'],
 // Beschriftete Achsen (08.08.2026). Fehlt sie, zeichnet die Fern-App zwar noch Raster und
 // Kurve, aber ohne jede Beschriftung - und der PDF-Ausdruck verliert seine Sekunden- und
 // mV-Marken still, weil sekundenmarken()/mvmarken() ohne VS.skala nichts tun.
 ['shared/ekg-skala.js', 'shared/ekg-skala.js'],
 // Alter und die EKG-Schicht ueber den Rassekatalog (09.08.2026). Ohne sie laedt die
 // Fern-App zwei Dateien, die es dort nicht gibt: das Altersfeld rechnet dann nichts
 // (alterJetzt() gibt null) und die rassebezogenen Herzhinweise bleiben still aus -
 // beides ohne jede Fehlermeldung, weil beide Aufrufe abgesichert sind.
 ['shared/patient-alter.js', 'shared/patient-alter.js'],
 ['shared/rasse-herz.js', 'shared/rasse-herz.js'],
].forEach(([q, z]) => {
  const von = path.join(quellWurzel, q), nach = path.join(webWurzel, z);
  fs.copyFileSync(von, nach);
  console.log('  kopiert  ' + q + ' -> ' + z + (fs.readFileSync(von, 'utf8') === fs.readFileSync(nach, 'utf8') ? ' (zeichengleich)' : ' (ABWEICHUNG!)'));
});

// --- Gegenpruefung: ist wirklich alles drin? ---
const p = fs.readFileSync(WEB, 'utf8');
const pruef = [
  ['Fern-Seam applyLive', p.indexOf('function applyLive(') >= 0],
  ['Fern-Seam neuerPatient', p.indexOf('function neuerPatient(') >= 0],
  ['Fern-Seam __anaesLive', p.indexOf('window.__anaesLive=') >= 0],
  ['Fern-Modul vorhanden', p.indexOf('FERN-LIVE Ansicht') >= 0],
  ['Geraeteprofil-Modul geladen', p.indexOf('../shared/geraete-profile.js') >= 0],
  ['universelles Geraet', p.indexOf('__setGeraetProfil') >= 0 && p.indexOf('__setMesswerte') >= 0],
  ['Seam VOR dem IIFE-Ende', p.indexOf('function applyLive(') < p.lastIndexOf('})();')],
  /* Reihenfolge der Skripte: rasse-herz.js schlaegt zur Laufzeit in VETBREED.CONDITIONS nach.
   * Stuende es VOR breed-katalog.js, waere das kein Fehler beim Laden - die Herzhinweise
   * blieben nur immer leer. Genau so ein stiller Ausfall soll hier auffallen. */
  ['Rasse-Herz nach dem Katalog geladen',
    p.indexOf('shared/rasse-herz.js') > p.indexOf('shared/breed-katalog.js') &&
    p.indexOf('shared/breed-katalog.js') > 0],
  ['Alter-Modul geladen', p.indexOf('shared/patient-alter.js') >= 0],
];
let ok = true;
pruef.forEach(([n, v]) => { if (!v) ok = false; console.log((v ? '  OK   ' : '  FEHLT') + '  ' + n); });
console.log(ok ? ('\nGeschrieben: ' + WEB + ' (' + p.split('\n').length + ' Zeilen)') : '\nUNVOLLSTAENDIG');
process.exit(ok ? 0 : 1);
