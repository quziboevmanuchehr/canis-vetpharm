'use strict';
/*
 * rasse-herz-test.js — die EKG-Schicht ueber den Rassekatalog.
 *
 * WAS DIESER TEST WIRKLICH BEWACHT, und es sind drei verschiedene Dinge:
 *
 * 1. DASS DIE SCHLUESSEL NOCH PASSEN. shared/rasse-herz.js haengt sich an Schluessel aus
 *    shared/breed-katalog.js. Wird dort ein Schluessel umbenannt, faellt der Eintrag hier
 *    STILL aus: kein Fehler, keine Meldung, der Hinweis erscheint nur nie wieder. Genau
 *    diese Sorte Ausfall hat dieses Projekt mehrfach getroffen.
 *
 * 2. DASS NICHTS VERSPROCHEN WIRD, WAS DAS GERAET NICHT KANN. Es zeichnet EINE Ableitung
 *    auf (II, beim Pferd Basis-Spitze). Eine Achsenbestimmung, eine Schenkelblockzuordnung
 *    oder Brustwandkriterien sind damit nicht zu haben. Ein Hinweis, der so etwas ankuendigt,
 *    ist schlimmer als gar keiner: der Untersucher haelt das Thema fuer abgehandelt.
 *
 * 3. DASS "WIR WISSEN ES NICHT" NICHT ZU "TRIFFT NICHT ZU" WIRD. Fehlt das Alter, darf ein
 *    altersgebundener Hinweis NICHT verschwinden - sonst faellt eine Warnung weg, weil ein
 *    Feld leer ist, und niemand erfaehrt davon.
 *
 * Start: node tools/rasse-herz-test.js
 */
const fs = require('fs');
const path = require('path');

const W = path.join(__dirname, '..');
const RH = require('../ui/shared/rasse-herz.js');
const AL = require('../ui/shared/patient-alter.js');

/* Der Katalog haengt sich ueber VETBREED.register() an breed-genetics.js - beide zusammen
 * in einem Gueltigkeitsbereich ausfuehren, wie es der Browser auch tut. */
const root = {};
new Function('root', 'window', 'module',
  fs.readFileSync(path.join(W, 'ui/shared/breed-genetics.js'), 'utf8') + '\n' +
  fs.readFileSync(path.join(W, 'ui/shared/breed-katalog.js'), 'utf8'))(root, root, {});
const VB = root.VETBREED;

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Rasse, Herz und EKG\n');

/* ================================================================================
 * 1. JEDER SCHLUESSEL MUSS IM KATALOG VORKOMMEN — sonst ist der Eintrag tot
 * ============================================================================== */
block('1. Schluessel treffen den Katalog');
pruef('der Katalog ist geladen', !!(VB && VB.CONDITIONS && VB.BREEDS && VB.BREEDS.length > 500),
  VB ? String(VB.BREEDS.length) + ' Rassen' : 'VETBREED fehlt');
RH.SCHICHT.forEach((s) => {
  pruef('Schluessel "' + s.schluessel + '" gibt es im Katalog', !!VB.CONDITIONS[s.schluessel]);
});
RH.SCHICHT.forEach((s) => {
  const n = VB.BREEDS.filter((b) => (b.conditions || []).indexOf(s.schluessel) >= 0).length;
  /* Ein Schluessel ohne eine einzige Rasse kann nie erscheinen. Er ist kein Fehler, aber er
   * ist auch keine Wirkung - und das soll man sehen statt es zu glauben. */
  pruef('Schluessel "' + s.schluessel + '" ist mindestens einer Rasse zugeordnet', n > 0, n + ' Rassen');
});
RH.GRUPPEN.forEach((g) => {
  pruef('Gruppe "' + g.gruppe + '" gibt es im Katalog', !!VB.GROUPS[g.gruppe]);
  const n = VB.BREEDS.filter((b) => (b.groups || []).indexOf(g.gruppe) >= 0).length;
  pruef('Gruppe "' + g.gruppe + '" hat Mitglieder', n > 0, n + ' Rassen');
});

/* ================================================================================
 * 2. ES WIRD NICHTS VERSPROCHEN, WAS EINE ABLEITUNG II NICHT HERGIBT
 * ============================================================================== */
block('2. keine Zusage jenseits einer Ableitung');
RH.SCHICHT.forEach((s) => {
  pruef('"' + s.schluessel + '" hat einen Beleg', !!s.beleg && s.beleg.length > 8);
  pruef('"' + s.schluessel + '" sagt, was im EKG zu sehen ist', !!s.ekg && s.ekg.length > 20);
  pruef('"' + s.schluessel + '" sagt, was zu tun ist', !!s.vorgehen && s.vorgehen.length > 20);
});
{
  /* Wo von der elektrischen ACHSE die Rede ist, MUSS ekgSichtbar false sein oder der Satz
   * die Unmoeglichkeit ausdruecklich benennen - eine Achse braucht mehrere echte Ableitungen. */
  const heikel = RH.SCHICHT.filter((s) => /achse/i.test(s.ekg));
  pruef('es gibt Eintraege, die die Achse ansprechen (sonst prueft der Test nichts)', heikel.length > 0,
    String(heikel.length));
  heikel.forEach((s) => {
    pruef('"' + s.schluessel + '" verspricht keine Achsenbestimmung',
      s.ekgSichtbar === false || /nicht|kann.*nicht|braucht/i.test(s.ekg), s.ekg.slice(0, 90));
  });
}
{
  /* Und die Gegenrichtung: wo ekgSichtbar false steht, muss der Text das auch SAGEN.
   * Ein "false" im Datensatz nuetzt nichts, wenn daneben ein zuversichtlicher Satz steht. */
  RH.SCHICHT.filter((s) => s.ekgSichtbar === false).forEach((s) => {
    pruef('"' + s.schluessel + '" sagt im Klartext, dass das EKG nichts hergibt',
      /nicht|nichts|kaum|schlecht geeignet|unauffaellig sein|unauffällig sein/i.test(s.ekg), s.ekg.slice(0, 90));
  });
}
{
  /* Kein Eintrag darf eine DIAGNOSE behaupten. Eine Praedisposition sagt, worauf man schaut. */
  const verboten = /\b(hat eine|liegt vor|ist erkrankt|diagnostiziert|beweist)\b/i;
  RH.SCHICHT.forEach((s) => {
    pruef('"' + s.schluessel + '" behauptet nichts ueber DIESES Tier',
      !verboten.test(s.ekg) && !verboten.test(s.vorgehen));
  });
}

/* ================================================================================
 * 3. AUSWAHL FUER EINEN PATIENTEN
 * ============================================================================== */
block('3. was gilt fuer dieses Tier');
{
  const dobi = VB.byId(VB.resolve('Dobermann', 'hund').id);
  pruef('Dobermann wird gefunden', !!dobi, dobi && dobi.name);
  pruef('und traegt eine Herzbedingung', RH.hatHerz(dobi) === true);
  const r = RH.fuerPatient({ breed: dobi, VB: VB, alter: AL.ausUngefaehr(6, 0) });
  pruef('die DCM des Dobermanns kommt heraus',
    r.praedispositionen.some((p) => p.schluessel === 'dcm-dobermann'),
    r.praedispositionen.map((p) => p.schluessel).join(','));
  const dcm = r.praedispositionen.filter((p) => p.schluessel === 'dcm-dobermann')[0];
  pruef('mit dem Namen aus dem KATALOG, nicht doppelt gepflegt',
    dcm.name === VB.CONDITIONS['dcm-dobermann'].name, dcm.name);
  pruef('mit 6 Jahren liegt der Hund im Screening-Fenster', dcm.imFenster === true);
}
{
  const dobi = VB.resolve('Dobermann', 'hund');
  const jung = RH.fuerPatient({ breed: dobi, VB: VB, alter: AL.ausUngefaehr(1, 0) });
  const d = jung.praedispositionen.filter((p) => p.schluessel === 'dcm-dobermann')[0];
  pruef('mit 1 Jahr liegt er ausserhalb', d.imFenster === false);
  /* ER VERSCHWINDET ABER NICHT. Der Hinweis bleibt sichtbar und traegt nur den Vermerk -
   * sonst waere aus "noch nicht im Screening-Alter" ein "kein Thema" geworden. */
  pruef('der Hinweis verschwindet trotzdem nicht', !!d);
}
{
  const dobi = VB.resolve('Dobermann', 'hund');
  const ohne = RH.fuerPatient({ breed: dobi, VB: VB, alter: null });
  const d = ohne.praedispositionen.filter((p) => p.schluessel === 'dcm-dobermann')[0];
  pruef('ohne Alter: imFenster null, nicht false', d.imFenster === null, String(d.imFenster));
  pruef('und es wird vermerkt, dass das Alter fehlt', ohne.ohneAlter === true);
  pruef('null ist NICHT false', d.imFenster !== false);
}
{
  const mc = VB.resolve('Maine Coon', 'katze');
  const r = RH.fuerPatient({ breed: mc, VB: VB, alter: AL.ausUngefaehr(5, 0) });
  pruef('Maine Coon: HCM-Eintraege kommen',
    r.praedispositionen.some((p) => /hcm/.test(p.schluessel)),
    r.praedispositionen.map((p) => p.schluessel).join(','));
  /* DER WICHTIGSTE SATZ DES GANZEN MODULS: bei der Katze schliesst ein unauffaelliges EKG
   * eine HCM nicht aus. Wenn dieser Vorbehalt je verlorengeht, wiegt die Anwendung den
   * Untersucher in Sicherheit. */
  const hcm = r.praedispositionen.filter((p) => p.schluessel === 'hcm-mybpc3-a31p')[0];
  pruef('und sagen ausdruecklich, dass das EKG die HCM nicht ausschliesst',
    hcm.ekgSichtbar === false && /unauffaellig|unauffällig|schlecht geeignet/i.test(hcm.ekg), hcm.ekg.slice(0, 80));
}
{
  /* Sortierung: was das EKG zeigen kann, steht oben. */
  const boxer = VB.resolve('Boxer', 'hund');
  const r = RH.fuerPatient({ breed: boxer, VB: VB, alter: AL.ausUngefaehr(7, 0) });
  pruef('Boxer bringt mehrere Eintraege', r.praedispositionen.length >= 2,
    r.praedispositionen.map((p) => p.schluessel).join(','));
  let letzterSichtbar = true;
  r.praedispositionen.forEach((p) => { if (!p.ekgSichtbar) letzterSichtbar = false; else if (!letzterSichtbar) letzterSichtbar = null; });
  pruef('sichtbare Befunde stehen VOR den unsichtbaren', letzterSichtbar !== null,
    r.praedispositionen.map((p) => p.schluessel + (p.ekgSichtbar ? '+' : '-')).join(' '));
}
{
  const r = RH.fuerPatient({ breed: null, VB: VB, alter: null });
  pruef('ohne Rasse: leere Listen statt eines Fehlers',
    r.praedispositionen.length === 0 && r.normvarianten.length === 0);
}

/* ================================================================================
 * 4. NORMVARIANTEN — sie verhindern Fehlalarme, duerfen aber nichts wegreden
 * ============================================================================== */
block('4. Rassegruppen');
{
  const grey = VB.resolve('Greyhound', 'hund');
  pruef('Greyhound wird gefunden', !!grey, grey && grey.name);
  const r = RH.fuerPatient({ breed: grey, VB: VB, alter: null });
  pruef('Windhundtyp wird erkannt', r.normvarianten.some((v) => v.gruppe === 'sighthound'),
    r.normvarianten.map((v) => v.gruppe).join(','));
}
{
  const mops = VB.resolve('Mops', 'hund');
  const r = RH.fuerPatient({ breed: mops, VB: VB, alter: null });
  pruef('Mops gilt als brachyzephal', r.normvarianten.some((v) => v.gruppe === 'brachy'),
    r.normvarianten.map((v) => v.gruppe).join(','));
}
{
  const dogge = VB.resolve('Deutsche Dogge', 'hund');
  const r = RH.fuerPatient({ breed: dogge, VB: VB, alter: null });
  pruef('Deutsche Dogge traegt die DCM der Riesenrassen',
    r.praedispositionen.some((p) => p.schluessel === 'dcm-riesenrassen'));
}
{
  /* ================================================================================
   * DIE KATALOGGRUPPE "giant" WIRD BEWUSST NICHT ALS NORMVARIANTE BENUTZT.
   *
   * Sie sieht nach einer Groessenklasse aus und ist keine: 75 Rassen, darunter Boxer,
   * Dobermann, Akita - und der Affenpinscher mit vier Kilogramm. Ihre Beschreibung im
   * Katalog lautet "Kardiomyopathie- und GDV-Neigung; Anaesthetika nach Magermasse
   * dosieren", sie ist also eine NARKOSERISIKO-Gruppe.
   *
   * Haette rasse-herz.js daraus eine breitere QRS-Grenze gemacht, waere sie fuer einen
   * Boxer und selbst fuer einen Affenpinscher auf Riesenrassenmass gestiegen - und ein
   * wirklich verbreiterter Kammerkomplex waere unauffaellig geblieben. Dieser Test haelt
   * die Entscheidung fest, damit sie nicht aus Versehen zurueckgenommen wird.
   * ============================================================================== */
  const affe = VB.resolve('Affenpinscher', 'hund');
  pruef('der Affenpinscher steht wirklich in der Katalog-Gruppe "giant"',
    !!affe && (affe.groups || []).indexOf('giant') >= 0,
    affe ? (affe.groups || []).join(',') : 'nicht gefunden');
  pruef('"giant" ist deshalb KEINE Normvariante dieser Datei',
    !RH.GRUPPEN.some((g) => g.gruppe === 'giant'),
    RH.GRUPPEN.map((g) => g.gruppe).join(','));
  pruef('und der Affenpinscher bekommt folgerichtig keine Groessen-Ausnahme',
    RH.fuerPatient({ breed: affe, VB: VB, alter: null }).normvarianten
      .every((v) => v.gruppe !== 'giant'));
  /* Dasselbe fuer "toy": eine hoehere Frequenzobergrenze bei Zwergrassen ist plausibel,
   * aber es gibt keine belegte Kilogrammgrenze dafuer. Ohne Beleg keine Ausnahme. */
  pruef('"toy" ebenfalls nicht', !RH.GRUPPEN.some((g) => g.gruppe === 'toy'));
}
{
  /* Und die Art muss passen: "brachy" enthaelt auch Perser und Britisch Kurzhaar, die
   * Aussage ueber den hohen Vagotonus ist aber eine HUNDE-Aussage. Bei der Katze ist eine
   * ausgepraegte Sinusarrhythmie gerade nicht die Regel - sie dort als normal auszugeben
   * waere ein weggeredeter Befund. */
  const perser = VB.resolve('Perser', 'katze');
  pruef('der Perser steht in der Gruppe "brachy"',
    !!perser && (perser.groups || []).indexOf('brachy') >= 0,
    perser ? (perser.groups || []).join(',') : 'nicht gefunden');
  const r = RH.fuerPatient({ breed: perser, VB: VB, alter: null });
  pruef('bekommt aber NICHT die Hunde-Normvariante der Sinusarrhythmie',
    !r.normvarianten.some((v) => v.gruppe === 'brachy'),
    r.normvarianten.map((v) => v.gruppe).join(','));
  const mops = VB.resolve('Mops', 'hund');
  pruef('der Mops bekommt sie dagegen schon',
    RH.fuerPatient({ breed: mops, VB: VB, alter: null }).normvarianten.some((v) => v.gruppe === 'brachy'));
}
RH.GRUPPEN.forEach((g) => {
  /* JEDE Normvariante braucht ihre GRENZE. Eine Ausnahme ohne Grenze redet frueher oder
   * spaeter einen echten Befund weg - und das ist der schlimmere der beiden Fehler. */
  pruef('Gruppe "' + g.gruppe + '" nennt ihre Grenze', !!g.grenze && g.grenze.length > 30,
    (g.grenze || '').slice(0, 60));
  pruef('Gruppe "' + g.gruppe + '" nennt, worauf sie wirkt', !!(g.wirkt && g.wirkt.length));
  pruef('Gruppe "' + g.gruppe + '" hat einen Beleg', !!g.beleg);
});

/* ================================================================================
 * 5. REICHWEITE — wie viele Tiere erreicht das ueberhaupt?
 * Eine Zahl, keine Meinung: sie zeigt, ob sich der Aufwand in der Praxis auswirkt.
 * ============================================================================== */
block('5. Reichweite');
{
  const alle = RH.rassenMitHerz(VB);
  const hunde = RH.rassenMitHerz(VB, 'hund');
  const katzen = RH.rassenMitHerz(VB, 'katze');
  console.log('    ' + alle.length + ' Rassen mit hinterlegter Herzbedingung (' +
    hunde.length + ' Hunde, ' + katzen.length + ' Katzen) von ' + VB.BREEDS.length);
  pruef('mindestens 50 Rassen sind erfasst', alle.length >= 50, String(alle.length));
  pruef('darunter Hunde und Katzen', hunde.length > 10 && katzen.length > 10);
}

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
