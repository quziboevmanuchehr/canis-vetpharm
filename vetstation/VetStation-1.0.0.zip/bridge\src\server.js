'use strict';
/*
 * server.js — Ein Prozess, ein Port: liefert die Kiosk-UI (statisch) UND den lokalen WebSocket
 * (Schicht 2 wird von Schicht 1 gefuettert). Plus kleine JSON-API fuer Diagnose/Updater.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { createWsServer } = require('./wsserver');
const { MSG } = require('./model');
const { listScenarios } = require('./scenarios');
const logger = require('./logger');
const updater = require('../../updater/updater');
const netscan = require('./netscan');
const firewall = require('./firewall');
const { diagnose } = require('./diagnose');
const { fuerRundruf } = require('./matching');

const UI_DIR = path.join(__dirname, '..', '..', 'ui');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.map': 'application/json',
};

function startServer({ port, host, registry, version, cloud }) {
  // --- Selbsttest des Netzwerks (§ "die App prueft ihr Netz selbst") ---
  // Ein Suchlauf dauert ~30-60 s. Er laeuft deshalb im Hintergrund; die Oberflaeche fragt den
  // Fortschritt ab, statt auf eine einzelne, minutenlange HTTP-Antwort zu warten.
  const netz = { laufend: false, fortschritt: null, ergebnis: null, firewall: null, internet: null, diagnose: null, ts: 0 };

  // Woran erkennt die Station, dass wirklich Werte ankommen? An echten Geraeten, die zuletzt
  // gesendet haben. Das ist die Tatsache, die vorher NIRGENDS stand (Kernbefund).
  function empfangslage() {
    const devs = registry.getDevices().filter((d) => d.status !== 'offline');
    const letzte = devs.reduce((m, d) => Math.max(m, d.lastTs || 0), 0);
    return {
      aktiv: devs.length > 0,
      geraete: devs.length,
      letzteDatenVorMs: letzte ? (Date.now() - letzte) : null,
    };
  }

  // Datenports, die ein FREMDES Programm belegt (der Verbindungs-Assistent merkt sich das).
  function fremdBelegt() {
    const out = [];
    (registry.adapters || []).forEach((a) => {
      (a && a.belegt ? a.belegt : []).forEach((p) => { if (out.indexOf(p) < 0) out.push(p); });
    });
    return out;
  }

  // Welche Geraete-Adressen stehen in devices.json? Nur so kann die Diagnose sagen "eingetragen
  // ist .50, gefunden wurde .51" — der Fall, der am 22.07.2026 zwei Stunden Suche gekostet hat.
  function konfigHosts() {
    const out = [];
    (registry.adapters || []).forEach((a) => {
      const h = a && a.cfg && a.cfg.host;
      if (h && out.indexOf(h) < 0) out.push(h);
    });
    return out;
  }

  function lageOhneScan() {
    return diagnose({
      scan: netz.ergebnis, firewall: netz.firewall, empfang: empfangslage(),
      cloud: cloud ? cloud.status() : null, fremdBelegt: fremdBelegt(),
      konfigHosts: konfigHosts(), internet: netz.internet,
    });
  }

  function starteScan() {
    if (netz.laufend) return;
    netz.laufend = true;
    netz.fortschritt = { phase: 'start', getan: 0, gesamt: 1, text: 'Suche wird gestartet …' };
    logger.info('netz', 'Netzwerksuche gestartet (aktive Suche .1-.254 + Portscan).');
    Promise.resolve()
      .then(() => netscan.scan({ onProgress: (p) => { netz.fortschritt = p; } }))
      .then((erg) => { netz.ergebnis = erg; return firewall.pruefe().catch(() => null); })
      .then((fw) => {
        netz.firewall = fw;
        // Zusaetzlich pruefen, ob dieser PC ueberhaupt ins Internet kommt (Update/Fern-Live).
        // Schlaegt die Pruefung fehl, bleibt netz.internet null = "nicht geprueft" statt "in Ordnung".
        return netscan.internetLage().catch(() => null);
      })
      .then((inet) => {
        netz.internet = inet;
        netz.diagnose = lageOhneScan();
        netz.ts = Date.now();
        const e = netz.ergebnis;
        logger.info('netz', 'Netzwerksuche fertig: ' + e.hosts.length + ' Teilnehmer, ' +
          e.geraete.length + ' sicheres/sichere Geraet(e), Urteil: ' + netz.diagnose.kurz);
      })
      .catch((e) => { logger.error('netz', 'Netzwerksuche fehlgeschlagen: ' + e.message); })
      .then(() => { netz.laufend = false; });
  }

  const httpServer = http.createServer(handleHttp);
  const ws = createWsServer(httpServer, { path: '/ws', onConnect, onMessage });

  // Diagnose-Ereignisse an alle UIs weiterreichen (Admin-Bereich).
  logger.setSink((ev) => ws.broadcast({ type: MSG.DIAG, event: ev }));

  // Broadcast-Takt: Geraeteliste + zusammengefuehrte Patienten (UI animiert Kurven lokal).
  // Dieselben zusammengefuehrten Patienten gehen (throttled) auch an die Cloud (Fern-Live).
  // 350 ms statt 500 (Befund 23.07.2026): schnellere, fluessigere Live-Anzeige von HF/SpO2/EKG-Analyse
  // und Haemodynamik. Der Rundruf ist bewusst schlank (fuerRundruf streift Kurven/Rohwerte ab), daher
  // ist der hoehere Takt auch auf dem Kiosk-i3 unproblematisch. GROESSTER Faktor bleibt aber der
  // Sendetakt AM GERAET (Data Interval): kleiner stellen = schnellere Werte.
  const BROADCAST_MS = 350;
  // Der Befundtitel fuer das Protokoll kommt aus derselben Brain-Bewertung wie die Fern-Ansicht.
  const befund = cloud ? (p) => cloud.befundTitel(p) : null;
  const timer = setInterval(() => {
    const patients = registry.getPatients();
    /*
     * Protokollschritt GENAU HIER — einmal je Runde. Nicht in registry.getPatients() und nicht im
     * Cloud-Zeitgeber unten: getPatients() laeuft pro Runde mehrfach, das Protokoll wuerde sonst
     * doppelt zaehlen und die 12-Sekunden-Schwelle waere wirkungslos.
     */
    try { registry.protokollSchritt(patients, befund); } catch (e) { logger.warn('protokoll', e.message); }
    if (cloud) {
      try { cloud.publish(patients, registry.getDevices(), registry.protokollFuerCloud()); }
      catch (e) { logger.warn('cloud', 'publish: ' + e.message); }
    }
    if (!ws.clients.size) return;
    ws.broadcast({ type: MSG.DEVICES, devices: registry.getDevices() });
    // fuerRundruf() streift roh[] und kurvenDaten[] ab - sie werden hier nie gelesen und waeren
    // ueber 100 KB/s bei drei Patienten (gemessen 22.07.2026). Abruf stattdessen ueber /api/geraet.
    ws.broadcast({ type: MSG.PATIENTS, patients: fuerRundruf(patients), ts: Date.now() });
  }, BROADCAST_MS);

  /*
   * EIGENER, SCHNELLERER TAKT FUER DIE FERN-UEBERTRAGUNG (27.07.2026).
   * Die Fern-Ansicht haengt bisher am 350-ms-Rundruf der lokalen Oberflaeche - sie konnte also nie
   * schneller sein als diese, obwohl sie inzwischen nur noch Deltas (wenige hundert Byte) schreibt.
   * Deshalb bekommt sie einen eigenen Takt aus cloud.minIntervalMs. Er laeuft mit der halben
   * Periode, weil cloud.publish() selbst noch einmal auf minIntervalMs drosselt: bei gleichem Takt
   * wuerde jeder zweite Durchlauf durch Zeitjitter verworfen und die tatsaechliche Rate halbiert.
   * Die lokale Anzeige bleibt bei 350 ms - sie braucht nicht mehr und der Kiosk-i3 auch nicht.
   */
  let cloudTimer = null;
  /*
   * Bedingung bewusst NICHT an cloud.started: seit der Einfuehrung der Praxis-Konten steht beim
   * Start noch nicht fest, ob eine Anmeldung vorliegt — sie kann jederzeit im Admin-Bereich
   * nachgeholt werden. Waere der Zeitgeber an started gebunden, liefe die Fern-Uebertragung nach
   * einer solchen Anmeldung bis zum naechsten Neustart nur im langsamen 350-ms-Rundruf.
   * cloud.publish() prueft Anmeldung und Takt ohnehin selbst.
   */
  if (cloud && cloud.cfg && cloud.cfg.enabled && cloud.minInterval < BROADCAST_MS) {
    const CLOUD_MS = Math.max(50, Math.round(cloud.minInterval / 2));
    cloudTimer = setInterval(() => {
      try { cloud.publish(registry.getPatients(), registry.getDevices(), registry.protokollFuerCloud()); }
      catch (e) { logger.warn('cloud', 'publish: ' + e.message); }
    }, CLOUD_MS);
    logger.info('cloud', 'Fern-Takt: alle ' + cloud.minInterval + ' ms (eigener Zeitgeber, unabhaengig vom lokalen Rundruf).');
  }

  httpServer.listen(port, host, () => {
    logger.info('server', 'VetStation UI+Bridge: http://' + host + ':' + port + '  (WebSocket /ws)');
  });
  httpServer.on('error', (e) => logger.error('server', 'HTTP-Fehler: ' + e.message));

  function onConnect(client) {
    client.sendJSON({ type: MSG.HELLO, bridgeVersion: version, ts: Date.now(), scenarios: listScenarios() });
    client.sendJSON({ type: MSG.DEVICES, devices: registry.getDevices() });
    client.sendJSON({ type: MSG.PATIENTS, patients: fuerRundruf(registry.getPatients()), ts: Date.now() });
    logger.recent(50).forEach((ev) => client.sendJSON({ type: MSG.DIAG, event: ev }));
  }

  function onMessage(client, text) {
    let m; try { m = JSON.parse(text); } catch (_) { return; }
    switch (m.type) {
      case MSG.PAIR: registry.pair(m.deviceIds, m.patientKey); ack(client, m, true); break;
      case MSG.UNPAIR: registry.unpair(m.patientKey); ack(client, m, true); break;
      case MSG.SET_META: registry.setMeta(m.deviceId, m.meta); ack(client, m, true); break;
      case MSG.SCENARIO: ack(client, m, registry.setScenario(m.patientId, m.scenarioId)); break;
      default: break;
    }
  }
  function ack(client, m, ok) { client.sendJSON({ type: MSG.ACK, of: m.type, ok: ok !== false }); }

  function handleHttp(req, res) {
    const u = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
    const pathname = decodeURIComponent(u.pathname);

    /*
     * --- PRAXIS-ANMELDUNG (nur vom Praxis-PC selbst) ---
     *
     * Diese Endpunkte tragen Zugangsdaten und den Anmeldezustand. Sie duerfen deshalb NICHT ueber
     * json() gehen: dieser Helfer setzt pauschal "Access-Control-Allow-Origin: *", womit JEDE
     * beliebige Webseite, die im Browser des Praxis-PCs geoeffnet ist, die Antwort auslesen
     * koennte. jsonPrivat() setzt diese Kopfzeile nicht und beantwortet ausserdem nur Anfragen
     * von 127.0.0.1 — ein Rechner im Praxisnetz kommt hier nicht heran.
     */
    if (pathname === '/api/praxis' || pathname === '/api/praxis/anmelden' || pathname === '/api/praxis/abmelden') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      if (!cloud) return jsonPrivat(res, { fehler: 'Fern-Live ist in dieser Fassung nicht verfuegbar.' });

      if (pathname === '/api/praxis') return jsonPrivat(res, cloud.status(true));

      if (pathname === '/api/praxis/abmelden') {
        if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
        try { return jsonPrivat(res, { ok: true, status: cloud.abmelden() }); }
        catch (e) { return jsonPrivat(res, { ok: false, fehler: e.message }); }
      }

      // Anmelden: Zugangsdaten ausschliesslich im Koerper, NIE in der Adresszeile — sonst stuenden
      // sie im Browserverlauf und in jedem Server-Log.
      if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
      let roh = '';
      let zuGross = false;
      req.on('data', (c) => {
        roh += c;
        if (roh.length > 4096) { zuGross = true; req.destroy(); }   // Schutz gegen Endlos-Koerper
      });
      req.on('end', () => {
        if (zuGross) return;
        let m; try { m = JSON.parse(roh); } catch (_) { return jsonPrivat(res, { ok: false, fehler: 'Ungueltige Anfrage.' }); }
        cloud.anmelden(m && m.email, m && m.passwort)
          .then((st) => jsonPrivat(res, { ok: true, status: st }))
          .catch((e) => jsonPrivat(res, { ok: false, fehler: klartextFehler(e && e.message) }));
      });
      return;
    }

    // Protokoll eines Patienten (fuer den PDF-Export). Nur lokal.
    if (pathname === '/api/protokoll') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      const pid = u.searchParams.get('id');
      return jsonPrivat(res, pid ? registry.protokollVon(pid) : { liste: registry.protokollListe() });
    }

    // --- kleine JSON-API ---
    if (pathname === '/api/state') return json(res, { devices: registry.getDevices(), patients: registry.getPatients() });
    /*
     * /api/geraet?id=<deviceId> — ALLE Rohwerte EINES Geraets, auf Abruf.
     *
     * Bewusst NICHT im 500-ms-Rundruf: 60 Eintraege je Geraet zweimal pro Sekunde zu verschicken
     * waere Verschwendung, und die staendig wechselnden Daten wuerden den Koppel-Dialog dauernd
     * neu bauen (Fokusverlust beim Tippen). Auf Klick geholt ist es genau einmal noetig.
     * Rein lesend.
     */
    if (pathname === '/api/geraet') {
      const id = u.searchParams.get('id') || '';
      const dev = registry.getDevices().find((d) => d.deviceId === id) || null;
      return json(res, { geraet: dev, roh: id ? registry.getRoh(id) : [] });
    }
    /*
     * /api/kurven?key=<patientKey> — die ECHTEN Abtastwerte (EKG/CO2 ...) EINES Patienten, auf Abruf.
     * Wie /api/geraet bewusst NICHT im 500-ms-Rundruf (zu gross). Die Oberflaeche holt sie nur, wenn
     * die kompakte kurvenSig (aus fuerRundruf) sich aendert - also wenn ein neuer Streifen ankommt.
     * Rein lesend.
     */
    if (pathname === '/api/kurven') {
      const key = u.searchParams.get('key') || '';
      const pat = registry.getPatients().find((p) => p.patientKey === key) || null;
      return json(res, { kurven: pat ? (pat.kurvenDaten || []) : [] });
    }
    // Die letzten unveraenderten HL7-Nachrichten (Speicher-Ringpuffer) - fuer die Fehlersuche,
    // um zu belegen, in welchen Feldern das Geraet die Stammdaten sendet. Nur lokal (127.0.0.1).
    if (pathname === '/api/rohnachrichten') {
      return json(res, { nachrichten: registry.getRohNachrichten ? registry.getRohNachrichten() : [] });
    }
    if (pathname === '/api/diag') return json(res, { events: logger.recent(200) });
    if (pathname === '/api/scenarios') return json(res, { scenarios: listScenarios() });
    if (pathname === '/api/cloud') return json(res, cloud ? cloud.status() : { enabled: false });
    // --- Netzwerk-Selbsttest: suchen, Zustand abfragen ---
    if (pathname === '/api/netscan/start') { starteScan(); return json(res, { gestartet: true, laufend: netz.laufend }); }
    if (pathname === '/api/netscan') {
      return json(res, {
        laufend: netz.laufend, fortschritt: netz.fortschritt, ts: netz.ts,
        ergebnis: netz.ergebnis, firewall: netz.firewall,
        // Die Diagnose immer FRISCH rechnen: die Empfangslage aendert sich sekuendlich, auch
        // wenn der letzte Suchlauf schon eine Weile her ist.
        diagnose: lageOhneScan(),
      });
    }
    // In-App-Update (§13): Status prüfen bzw. anwenden/stagen. Nur lokal erreichbar (Kiosk).
    if (pathname === '/api/update/check') { updater.check().then((r) => json(res, r)).catch((e) => json(res, { error: e.message })); return; }
    if (pathname === '/api/update/apply') { logger.info('update', 'Update angefordert (Admin).'); updater.apply().then((r) => { logger.info('update', r.msg || (r.ok ? 'ok' : 'fehlgeschlagen')); json(res, r); }).catch((e) => json(res, { ok: false, msg: e.message })); return; }
    if (pathname === '/api/version') return json(res, { version });
    if (pathname === '/healthz') return json(res, { ok: true, ts: Date.now() });

    // --- statische UI ---
    let rel = pathname === '/' ? '/index.html' : pathname;
    const filePath = path.normalize(path.join(UI_DIR, rel));
    if (!filePath.startsWith(UI_DIR)) { res.writeHead(403); return res.end('403'); }
    fs.readFile(filePath, (err, data) => {
      if (err) {
        // SPA-Fallback auf index.html
        if (path.extname(filePath) === '') {
          return fs.readFile(path.join(UI_DIR, 'index.html'), (e2, d2) => {
            if (e2) { res.writeHead(404); return res.end('404'); }
            res.writeHead(200, { 'Content-Type': MIME['.html'] }); res.end(d2);
          });
        }
        res.writeHead(404); return res.end('404 ' + rel);
      }
      const ext = path.extname(filePath).toLowerCase();
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(data);
    });
  }

  function json(res, obj) {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(obj));
  }

  /*
   * jsonPrivat — fuer alles, was Zugangsdaten, Anmeldezustand oder Patientenprotokolle enthaelt.
   *
   * Unterschied zu json(): KEIN "Access-Control-Allow-Origin: *". Diese Kopfzeile erlaubt jeder
   * fremden Webseite, die im Browser des Praxis-PCs offen ist, die Antwort dieser Adresse zu lesen
   * (fetch('http://127.0.0.1:8770/...')). Fuer die Geraeteanzeige ist das harmlos, fuer die
   * Anmeldung waere es ein Ausleseweg. Zusaetzlich verbietet no-store das Zwischenspeichern.
   */
  function jsonPrivat(res, obj) {
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(JSON.stringify(obj));
  }

  // Nur der Praxis-PC selbst. IPv6-Schreibweise von localhost (::1 bzw. ::ffff:127.0.0.1) mitdenken.
  function istLokal(req) {
    const a = (req.socket && (req.socket.remoteAddress || '')) || '';
    return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
  }

  /*
   * Firebase antwortet auf Anmeldefehler mit Kuerzeln wie INVALID_LOGIN_CREDENTIALS. Die haben auf
   * dem Bildschirm eines Tierarztes nichts verloren — hier steht, was zu tun ist.
   */
  function klartextFehler(msg) {
    const s = String(msg || '');
    if (/EMAIL_NOT_FOUND|INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD/i.test(s)) {
      return 'E-Mail oder Passwort stimmt nicht. Gross-/Kleinschreibung beim Passwort beachten.';
    }
    if (/USER_DISABLED/i.test(s)) return 'Dieses Praxis-Konto ist gesperrt.';
    if (/TOO_MANY_ATTEMPTS|RESET_PASSWORD/i.test(s)) return 'Zu viele Fehlversuche. Bitte einige Minuten warten.';
    if (/MISSING_PASSWORD|MISSING_EMAIL/i.test(s)) return 'Bitte E-Mail und Passwort eingeben.';
    if (/ENOTFOUND|EAI_AGAIN|Zeitueberschreitung/i.test(s)) return 'Keine Internetverbindung zum Anmeldedienst.';
    if (/apiKey/i.test(s)) return s;
    return s;
  }

  return { httpServer, ws, stop() { clearInterval(timer); if (cloudTimer) clearInterval(cloudTimer); ws.close(); try { httpServer.close(); } catch (_) {} } };
}

module.exports = { startServer };
