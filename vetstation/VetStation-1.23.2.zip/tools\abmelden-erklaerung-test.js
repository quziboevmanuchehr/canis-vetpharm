'use strict';
/*
 * abmelden-erklaerung-test.js — drei Befunde vom 19.08.2026.
 *
 * 1) ABMELDEN GAB DIE TRAININGSFELDER NICHT WIEDER FREI.
 *    activate() setzt <html class="vetlive-on">; daran haengt die Regel, die Tierart, Gewicht,
 *    Alter, Rasse und die Monitor-Eingaben sperrt - richtig, solange die Werte vom Praxis-PC
 *    kommen. abmelden() hat die Klasse aber stehen lassen und den Einstiegsknopf nicht
 *    zurueckgeholt (activate() entfernt ihn). Im Browser nachgestellt: vor dem Oeffnen war das
 *    Gewichtsfeld bedienbar und der Knopf da; danach war beides weg - und blieb es.
 *
 * 2) DER SENDETAKT LAG BEI 500 ms.
 *    Gemessen mit tools/fern-durchsatz-test.js: Laufzeit durch die Software 36/210/401 ms.
 *    Mit 40 ms: 18/66/97 ms. Die Datenmenge bleibt praktisch gleich (7,1 -> 7,3 KB/s), weil
 *    die Paketrate am GERAET haengt (1 Paket/s) und nicht am Takt - der Takt entfernt nur die
 *    Wartezeit. Diese Zahl war die Ueberraschung der Messung; ich hatte selbst mit einer
 *    Vervielfachung gerechnet.
 *
 * 3) DIE WERTERKLAERUNGEN WURDEN NIE ANGEZEIGT.
 *    Jeder der 23 Kanaele in ui/shared/geraete-profile.js traegt seit dem 05.08.2026 ein Feld
 *    "explain" mit einem fachlichen Satz. Angezeigt wurde er nirgends - geschrieben, aber nie
 *    gelesen.
 *
 * Start: node tools/abmelden-erklaerung-test.js
 */
var fs = require('fs');
var path = require('path');
var vm = require('vm');

var WURZEL = path.join(__dirname, '..');
var WA = path.join(WURZEL, '..', '..', 'canis-vetpharm', 'canis-anaesthesie', 'index.html');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function lies(p) { return fs.readFileSync(p, 'utf8'); }
function ohneK(s) { return s.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/<!--[\s\S]*?-->/g, ' '); }

console.log('VetStation — Abmelden, Sendetakt, Werterklaerungen\n');

/* ---------------------------------------------------------- 1) Abmelden */
console.log('1) Abmelden gibt die Trainingsfelder wieder frei:');
if (!fs.existsSync(WA)) {
  console.log('  ! die Fern-App liegt nicht neben dem Quellbaum - Abschnitt uebersprungen');
} else {
  var wa = lies(WA), waC = ohneK(wa);
  ok('es gibt zurueckZumTraining()', /function zurueckZumTraining\(\)\{/.test(waC));
  ok('abmelden() ruft es auf', /connState='auth';\s*\n?\s*zurueckZumTraining\(\);/.test(waC),
    'Sonst bleibt die Sperre nach dem Abmelden stehen');
  [['die Sperr-Klasse wird entfernt', /classList\.remove\('vetlive-on'\)/],
   ['die Polsterung geht zurueck', /document\.body\.style\.paddingTop=''/],
   ['die Fern-Leiste verschwindet', /if\(bar\)\{ bar\.remove\(\); bar=null; \}/],
   ['activate() darf wieder laufen', /activated=false;/],
   ['und der Einstiegsknopf kommt zurueck', /if\(!document\.getElementById\('vetlive-launch'\)\) injectLauncher\(\)/]
  ].forEach(function (t) {
    ok(t[0], new RegExp(t[1].source).test(waC),
      'Ohne das kaeme man nicht in die Fern-Ansicht zurueck');
  });
  /*
   * NACHGESCHAERFT AM 21.08.2026, aus der Praxis gemeldet.
   *
   * Hier stand die Sperre an der Klasse vetlive-on - und die setzt activate(), also schon
   * beim OEFFNEN der Fern-Ansicht. Gemessen im Browser, Fern-Ansicht offen und NICHT
   * angemeldet: Tierart, Gewicht, Alter, Rasse und Narkosetyp alle auf pointer-events:none,
   * waehrend die Kopfzeile 'nicht angemeldet' und 'bitte anmelden...' meldete. Gesperrt
   * gegen Werte, die es gar nicht gab - dabei ist die Anwendung ohne Anmeldung genau das,
   * was sie sein soll: eine Simulation, in der jeder alles eintragen kann.
   *
   * Die Sperre ist weiterhin richtig, aber ihre Bedingung ist eine andere: nicht
   * 'angemeldet', sondern 'es liegt ein Patient vom Praxis-PC an'. Nur dann waere eine
   * Aenderung hier eine zweite Wahrheit neben der Station.
   */
  ok('die Sperre haengt an vetlive-fremd, nicht mehr an vetlive-on',
    /html\.vetlive-fremd #spChips,html\.vetlive-fremd #wt/.test(wa) &&
    !/html\.vetlive-on #spChips/.test(wa),
    'gesperrt wird gegen echte Werte, nicht gegen eine offene Ansicht');
  ok('render() setzt sie nach der Lage (Patient da oder nicht)',
    /var liegtAn = !!\(sel && pats\[sel\]\);/.test(waC) &&
    /classList\.toggle\('vetlive-fremd', liegtAn\)/.test(waC),
    'ohne diese Zeile kaeme die Sperre wieder blind aus activate()');
  ok('zurueckZumTraining() raeumt auch die neue Klasse ab',
    /classList\.remove\('vetlive-fremd'\)/.test(waC),
    'render() laeuft ohne Leiste nicht mehr und koennte sie sonst nie zuruecknehmen');
  ok('die Kopfzeile nennt beide Zustaende beim Namen',
    wa.indexOf('nur Ansicht') >= 0 && wa.indexOf('Simulation') >= 0,
    'wer nichts angeschlossen hat, muss lesen koennen, dass er frei einstellen darf');

  /*
   * ============================================================================
   * DIE LEISTE DARF DEN AUSGANG NICHT VERDECKEN (Befund 21.08.2026, aus der Praxis)
   * ============================================================================
   * Im gewoehnlichen Betrieb SCHIEBT die Leiste die App nach unten (padding-top) und
   * verdeckt nichts. Im Vollbild ist .cockpit aber position:fixed;inset:0 und nimmt keine
   * Polsterung an - die Leiste (z-index 9999) liegt dann ueber dem Cockpit (9000).
   *
   * GEMESSEN bei 1920x700, Vollbild, Fern-Ansicht offen:
   *     Leiste 68 px hoch; #dmVoll, #gwMon, #gwNark alle bei y=35
   *     elementFromPoint auf dem Zurueck-Knopf -> .vetlive-pats, also NICHT klickbar
   * Der Tierarzt kam aus dem Vollbild nicht mehr heraus.
   */
  ok('im Vollbild ist die Leiste ausgeblendet',
    /body\.mon-voll #vetlive-bar{display:none/.test(wa),
    'sonst liegt sie ueber der Zeile mit dem Zurueck-Knopf');
  ok('dafuer gibt es den kleinen Anker unten links',
    wa.indexOf('vetlive-mini') >= 0 && /body\.mon-voll #vetlive-mini{display:inline-flex/.test(wa),
    'im Vollbild sagt sonst nichts mehr, dass fern gearbeitet wird');
  ok('der Anker klickt den Knopf der Anwendung, statt selbst umzuschalten',
    /getElementById\('dmVoll'\); if\(v\) v\.click\(\)/.test(waC),
    'ein zweiter Weg aus dem Vollbild waere der zweite Rechenweg');
  ok('die Polsterung wird im Vollbild NICHT auf 0 gesetzt',
    /if\(document\.body\.classList\.contains\('mon-voll'\)\) return;/.test(waC),
    'sonst stuende die App nach dem Verlassen des Vollbilds unter der Leiste');
  ok('ohne Anmeldung bleibt oben nichts stehen',
    /if\(\!nutzer\) zurueckZumTraining\(\);/.test(waC),
    'die Leiste zeigte sonst dauerhaft nur "nicht angemeldet" - und im Vollbild ueber dem Ausgang');
}

/* ---------------------------------------------------------- 2) Sendetakt */
console.log('\n2) Sendetakt:');
var cl = lies(path.join(WURZEL, 'bridge/src/cloud.js'));
ok('die Vorgabe steht auf 40 ms',
  /this\.minInterval = Math\.max\(40, Number\(this\.cfg\.minIntervalMs\) \|\| 40\);/.test(cl),
  'Gemessen: Laufzeit 210 -> 66 ms im Mittel, Datenmenge 7,1 -> 7,3 KB/s');
ok('die Einstellung bleibt bestehen (wer sparen muss, dreht hoch)',
  /Number\(this\.cfg\.minIntervalMs\)/.test(cl));
var dt = lies(path.join(WURZEL, 'tools/fern-durchsatz-test.js'));
ok('der Durchsatz-Test faehrt nicht mehr auf einer festverdrahteten 200',
  dt.indexOf('minIntervalMs: 200,') < 0,
  'Sonst meldet die Freigabezahl einen Takt, den es im Betrieb nicht gibt');
ok('… sondern nimmt den Takt der Station und laesst ihn einstellen (--takt)',
  /const SENDETAKT =/.test(dt) && /minIntervalMs: SENDETAKT/.test(dt));

/* ---------------------------------------------------------- 3) Erklaerungen */
console.log('\n3) Jeder Wert erklaert sich beim Darauflegen:');
var sb = { window: {}, self: null };
sb.self = sb.window;
vm.createContext(sb);
vm.runInContext(lies(path.join(WURZEL, 'ui/shared/geraete-profile.js')), sb);
var K = sb.window.VETGERAET && sb.window.VETGERAET.KANAELE;
ok('die Kanaele lassen sich laden', !!(K && K.length));
if (K) {
  var ohne = K.filter(function (c) { return !c.explain || c.explain.length < 15; });
  ok('alle ' + K.length + ' Kanaele tragen eine Erklaerung',
    ohne.length === 0, ohne.map(function (c) { return c.id; }).join(', '));
}
var ix = lies(path.join(WURZEL, 'ui/app/index.html'));
var ixC = ohneK(ix);
ok('es gibt EINE Stelle, die den Text baut', /function wertErklaerung\(id\)\{/.test(ixC),
  'Sonst laufen Kachel und Kurvenzahl auseinander');
ok('sie holt ihn aus dem Kanal, nicht aus einer zweiten Liste',
  /VETGERAET\.kanal\(id\)/.test(ixC) && /k\.explain/.test(ixC));
ok('fehlt ausnahmsweise ein explain, bleibt der Name - nichts wird erfunden',
  /var t = k\.name \|\| "";/.test(ixC));
ok('die Kacheln tragen ihn', /data-p="'\+p\.id\+'"'\+erklaerAttr\(p\.id\)/.test(ixC));
ok('die Kurvenzahlen ebenfalls', /wertErklaerung\(haupt\.id\)/.test(ixC));
ok('als title UND als data-vp-tip (Browser-Rueckfall und eigenes System)',
  /title="' \+ e \+ '" data-vp-tip="' \+ e \+ '"/.test(ixC));

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
