'use strict';
/*
 * watchdog-test.js — sichert die Selbstheilung ab (kiosk/watchdog.ps1, ab 1.2.1).
 *
 * DER BEFUND, DEN DIESER TEST FESTNAGELT (01.08.2026, am laufenden Praxis-PC gemessen):
 * Die Bridge (PID 17332) hielt Port 8770 und alle sieben Geraeteports, nahm TCP-Verbindungen an
 * und beantwortete kein einziges Byte — ihre Ereignisschleife stand. Der Watchdog erkannte die
 * Unerreichbarkeit richtig und startete daraufhin einen ZWEITEN Prozess. Der fand jeden Port
 * belegt, konnte nichts binden und blieb als Leiche stehen. Anschliessend starb der Watchdog am
 * 'throw' aus launch-kiosk.ps1. Ergebnis: ueber zwei Stunden tote Station, ohne jeden Hinweis.
 *
 * Was hier NIE wieder passieren darf:
 *   • Eine EINGEFRORENE Bridge fuehrt zu 'starten' statt zu 'beenden-und-starten'. Das ist genau
 *     der Fehler von damals: neu starten, ohne die Ports freizumachen, heilt nichts und erzeugt
 *     nur eine zweite Leiche.
 *   • Ein FREMDES Programm auf dem Port wird beendet. Ein Watchdog, der fremde Prozesse toetet,
 *     ist ein Schaedling — hier muss 'fremd' herauskommen und sonst nichts.
 *   • Ein einzelner Aussetzer beendet die Station. Unterhalb der Schwelle darf ausschliesslich
 *     'warten' herauskommen; waehrend einer Narkose waere ein voreiliger Abschuss schlimmer als
 *     eine kurze Verzoegerung.
 *   • Stop-Process steht irgendwo, ohne dass vorher geprueft wurde, ob es UNSER Prozess ist.
 *   • Die Watchdog-Schleife kann wieder sterben (fehlendes try/catch) — dann ueberwacht nach dem
 *     ersten Fehlschlag niemand mehr irgendetwas, und das faellt keinem auf.
 *
 * Die Entscheidung selbst steht bewusst in einer eigenen Datei (kiosk/watchdog-entscheidung.ps1)
 * und ist nebenwirkungsfrei: dieser Test ruft sie mit erfundenen Lagen auf. Es wird dabei kein
 * einziger Prozess angefasst und kein Port geoeffnet.
 *
 * Start: node tools/watchdog-test.js      (laeuft auch in `node tools/alle-tests.js`)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const KIOSK = path.join(__dirname, '..', 'kiosk');
const ENTSCHEIDUNG = path.join(KIOSK, 'watchdog-entscheidung.ps1');
const ERKENNUNG = path.join(KIOSK, 'watchdog-erkennung.ps1');
const WATCHDOG = path.join(KIOSK, 'watchdog.ps1');

/* Fuehrt PowerShell-Code aus und liefert die Ausgabe. Die Station laeuft ausschliesslich auf
 * Windows (Kiosk, netsh, Get-NetFirewallRule) — PowerShell ist also da, und ein Fehlschlag hier
 * ist ein echter Fehlschlag, kein Grund zum Ueberspringen. */
function ps(code) {
  const datei = path.join(os.tmpdir(), 'vetstation-wd-' + process.pid + '-' + (ps._n = (ps._n || 0) + 1) + '.ps1');
  try {
    fs.writeFileSync(datei, code, 'utf8');
    const r = spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', datei],
      { encoding: 'utf8', timeout: 90000 });
    if (r.error) return { fehler: r.error.message };
    if (r.status !== 0) return { fehler: 'Ende mit ' + r.status + ': ' + String(r.stderr || '').slice(0, 400) };
    return { aus: String(r.stdout || '') };
  } catch (e) {
    return { fehler: e.message };
  } finally {
    try { fs.unlinkSync(datei); } catch (_) {}
  }
}

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

console.log('watchdog-test: Selbstheilung bei eingefrorener Station\n');

/* ------------------------------------------------------------------ *
 * 1) Die Entscheidungstabelle — ausgefuehrt, nicht nur gelesen.
 * ------------------------------------------------------------------ */

/*
 * Jede Zeile: was der Watchdog sieht -> was er tun MUSS.
 * PortInhaber === null heisst "niemand horcht auf dem Port" (abgestuerzt).
 */
const FAELLE = [
  { name: 'antwortet -> nichts tun',
    erreichbar: true, folge: 0, schwelle: 3, inhaber: null, unsere: false, erwartet: 'ok' },

  { name: 'antwortet, obwohl vorher Fehler gezaehlt wurden -> Erreichbarkeit schlaegt alles',
    erreichbar: true, folge: 99, schwelle: 3, inhaber: 1234, unsere: true, erwartet: 'ok' },

  { name: 'erster Aussetzer -> nur warten, nichts beenden',
    erreichbar: false, folge: 1, schwelle: 3, inhaber: 1234, unsere: true, erwartet: 'warten' },

  { name: 'zweiter Aussetzer -> immer noch warten',
    erreichbar: false, folge: 2, schwelle: 3, inhaber: 1234, unsere: true, erwartet: 'warten' },

  { name: 'abgestuerzt (niemand haelt den Port) -> einfach starten',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: null, unsere: false, erwartet: 'starten' },

  // Das ist der Fall vom 01.08.2026. Frueher kam hier 'starten' heraus, und nichts wurde geheilt.
  { name: 'EINGEFROREN (unser Prozess haelt den Port) -> erst beenden, dann starten',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: 17332, unsere: true, erwartet: 'beenden-und-starten' },

  { name: 'fremdes Programm auf dem Port -> NICHT anfassen',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: 4711, unsere: false, erwartet: 'fremd' },

  { name: 'weit ueber der Schwelle und eingefroren -> weiterhin beenden-und-starten',
    erreichbar: false, folge: 50, schwelle: 3, inhaber: 17332, unsere: true, erwartet: 'beenden-und-starten' },

  { name: 'Schwelle 1 -> greift schon beim ersten Fehlschlag',
    erreichbar: false, folge: 1, schwelle: 1, inhaber: 17332, unsere: true, erwartet: 'beenden-und-starten' },

  /* Gegenpruefung 01.08.2026: Get-PortInhaber verschluckte jeden Fehler und meldete "niemand da".
   * Scheitert die Abfrage im entscheidenden Takt, haette der Watchdog "abgestuerzt" geschlossen
   * und neu gestartet — waehrend die eingefrorene Bridge die Ports weiter haelt. Also genau die
   * zweite Leiche, diesmal von der Selbstheilung erzeugt. Nichtwissen ist kein Grund zu handeln. */
  { name: 'Portabfrage gescheitert (-1) -> NICHTS tun, nicht "abgestuerzt" annehmen',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: -1, unsere: false, erwartet: 'lage-unklar' },

  { name: 'Portabfrage gescheitert, aber Station antwortet -> ok schlaegt alles',
    erreichbar: true, folge: 0, schwelle: 3, inhaber: -1, unsere: false, erwartet: 'ok' },

  { name: 'Portabfrage gescheitert unterhalb der Schwelle -> weiterhin nur warten',
    erreichbar: false, folge: 1, schwelle: 3, inhaber: -1, unsere: false, erwartet: 'warten' },

  /* Beide Schreibweisen muessen dasselbe ergeben. Die erste Fassung pruefte den TYP
   * (`-is [int]`) — und fiel still aus, weil PowerShell `-PortInhaber -1` in Befehlsschreibweise
   * als String bindet (nachgemessen: System.String). Eine Sicherung, die je nach Schreibweise
   * wirkt oder nicht, ist keine. */
  { name: 'Portabfrage gescheitert, als Zahl uebergeben -> ebenfalls lage-unklar',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: '(-1)', roh: true, unsere: false, erwartet: 'lage-unklar' },
];

function psBool(b) { return b ? '$true' : '$false'; }
function psPfad(p) { return "'" + p.replace(/'/g, "''") + "'"; }

const zeilen = FAELLE.map((f, i) => {
  /* roh:true heisst "so einsetzen, wie es dasteht" — damit sich beide PowerShell-Schreibweisen
   * pruefen lassen: -PortInhaber -1 (bindet als String) und -PortInhaber (-1) (bindet als Zahl). */
  const inh = (f.inhaber === null) ? '$null' : String(f.inhaber);
  return '$r' + i + ' = Get-WatchdogEntscheidung -Erreichbar ' + psBool(f.erreichbar) +
    ' -FehlerFolge ' + f.folge + ' -Schwelle ' + f.schwelle +
    ' -PortInhaber ' + inh + ' -InhaberIstUnsere ' + psBool(f.unsere) + '; ' +
    'Write-Output ("' + i + '=" + $r' + i + ')';
});

const lauf1 = ps(['$ErrorActionPreference = "Stop"', '. ' + psPfad(ENTSCHEIDUNG)].concat(zeilen).join('\n'));
const psFehler = lauf1.fehler || null;

if (psFehler) {
  ok('PowerShell laesst sich aufrufen', false, psFehler);
} else {
  const antwort = {};
  lauf1.aus.split('\n').forEach((z) => {
    const m = z.trim().match(/^(\d+)=(.*)$/);
    if (m) antwort[m[1]] = m[2].trim();
  });
  FAELLE.forEach((f, i) => {
    ok(f.name, antwort[i] === f.erwartet, 'kam: ' + JSON.stringify(antwort[i]) + ', erwartet: ' + f.erwartet);
  });
}

/* ------------------------------------------------------------------ *
 * 1b) Die HERKUNFTSPRUEFUNG wird AUSGEFUEHRT, nicht im Quelltext gesucht.
 *
 * Der schwerste Befund der Gegenpruefung vom 01.08.2026 lautete: Test-IstUnsereBridge stand in
 * watchdog.ps1, und weil dort am Dateiende eine Endlosschleife laeuft, konnte kein Test sie je
 * aufrufen. Geprueft wurde nur, ob ihr Name vorkommt — ein Umbau auf `return $true` waere gruen
 * durchgegangen und haette den Watchdog zum Schaedling gemacht. Seit 1.2.2 steht sie in
 * kiosk/watchdog-erkennung.ps1 und wird hier mit erfundenen Lagen aufgerufen.
 *
 * Get-Process, Get-CimInstance und Get-NetTCPConnection werden dabei durch eigene Funktionen
 * ersetzt. In PowerShell haben Funktionen Vorrang vor Cmdlets — es wird also kein einziger
 * echter Prozess angefasst und kein Port geoeffnet.
 * ------------------------------------------------------------------ */
const ROOT_TEST = 'C:\\VetStation';

/*
 * name    = Prozessname laut Get-Process
 * pfad    = ExecutablePath laut CIM ($null = Windows gibt keine Auskunft)
 * adresse = LocalAddress des Listen-Eintrags ($null = horcht gar nicht auf diesem Port)
 */
const ERKENNUNG_FAELLE = [
  { name: 'mitgeliefertes Node im Stationsordner -> unsere',
    proz: 'node', pfad: 'C:\\VetStation\\node\\node.exe', adresse: '127.0.0.1', erwartet: true },

  /* GENAU DER BEFUND: Find-Node in launch-kiosk.ps1 nimmt ausdruecklich ein System-Node, wenn
   * kein node\node.exe mitgeliefert wurde. Frueher kam hier $false heraus -> 'fremd' -> die
   * Station waere nie geheilt worden, mit beruhigender Zeile im Protokoll. */
  { name: 'SYSTEM-Node (C:\\Program Files\\nodejs) auf Loopback -> trotzdem unsere',
    proz: 'node', pfad: 'C:\\Program Files\\nodejs\\node.exe', adresse: '127.0.0.1', erwartet: true },

  { name: 'Pfad nicht lesbar, aber Loopback -> unsere',
    proz: 'node', pfad: null, adresse: '127.0.0.1', erwartet: true },

  { name: 'Pfad nicht lesbar, IPv6-Loopback -> unsere',
    proz: 'node', pfad: null, adresse: '::1', erwartet: true },

  /* Die Gegenrichtung muss genauso stimmen, sonst wird der Watchdog zum Schaedling. */
  { name: 'fremdes Programm (kein node) -> NICHT unsere',
    proz: 'nginx', pfad: 'C:\\nginx\\nginx.exe', adresse: '127.0.0.1', erwartet: false },

  { name: 'fremdes node ausserhalb, horcht auf allen Adressen (0.0.0.0) -> NICHT unsere',
    proz: 'node', pfad: 'C:\\Entwicklung\\meinprojekt\\node.exe', adresse: '0.0.0.0', erwartet: false },

  { name: 'fremdes node ausserhalb, horcht gar nicht auf diesem Port -> NICHT unsere',
    proz: 'node', pfad: 'C:\\Entwicklung\\meinprojekt\\node.exe', adresse: null, erwartet: false },

  { name: 'Prozess existiert nicht mehr -> NICHT unsere',
    proz: null, pfad: null, adresse: null, erwartet: false },

  /* Eckige Klammern sind in -like PLATZHALTER. Mit dem alten Vergleich haette die eigene
   * Station in so einem Ordner als fremd gegolten. StartsWith kennt keine Platzhalter. */
  { name: 'Stationsordner mit eckigen Klammern im Pfad -> trotzdem unsere',
    proz: 'node', pfad: 'C:\\Praxis [alt]\\VetStation\\node\\node.exe', adresse: null,
    root: 'C:\\Praxis [alt]\\VetStation', erwartet: true },
];

const erkZeilen = ERKENNUNG_FAELLE.map((f, i) => {
  const root = f.root || ROOT_TEST;
  const prozTeil = f.proz
    ? '[pscustomobject]@{ ProcessName = ' + psPfad(f.proz) + ' }'
    : '$null';
  const cimTeil = f.pfad
    ? '[pscustomobject]@{ ExecutablePath = ' + psPfad(f.pfad) + ' }'
    : (f.proz ? '[pscustomobject]@{ ExecutablePath = $null }' : '$null');
  const netzTeil = f.adresse
    ? '@([pscustomobject]@{ OwningProcess = 4711; LocalAddress = ' + psPfad(f.adresse) + ' })'
    : '@()';
  return [
    'function Get-Process { param($Id, $Name, $ErrorAction) return ' + prozTeil + ' }',
    'function Get-CimInstance { param($ClassName, $Filter, $ErrorAction) return ' + cimTeil + ' }',
    'function Get-NetTCPConnection { param($LocalPort, $State, $ErrorAction) return ' + netzTeil + ' }',
    '$e' + i + ' = Test-IstUnsereBridge 4711 8770 ' + psPfad(root),
    'Write-Output ("' + i + '=" + $e' + i + ')',
  ].join('\n');
});

const lauf2 = ps([
  '$ErrorActionPreference = "Stop"',
  '. ' + psPfad(ERKENNUNG),
].concat(erkZeilen).join('\n'));

if (lauf2.fehler) {
  ok('Herkunftspruefung laesst sich ausfuehren', false, lauf2.fehler);
} else {
  const antw = {};
  lauf2.aus.split('\n').forEach((z) => {
    const m = z.trim().match(/^(\d+)=(.*)$/);
    if (m) antw[m[1]] = m[2].trim();
  });
  ERKENNUNG_FAELLE.forEach((f, i) => {
    const kam = antw[i] === 'True' ? true : (antw[i] === 'False' ? false : antw[i]);
    ok('Erkennung: ' + f.name, kam === f.erwartet, 'kam: ' + JSON.stringify(antw[i]));
  });
}

/* Mutationsprobe: wird die Herkunftspruefung durch ein pauschales $true ersetzt, MUESSEN die
 * Gegenrichtungs-Faelle oben umkippen. Faellt diese Probe aus, misst der Test nichts. */
const mutiert = ps([
  '$ErrorActionPreference = "Stop"',
  '. ' + psPfad(ERKENNUNG),
  'function Test-IstUnsereBridge { param($Kennung, $P, $Stammordner) return $true }',
  'function Get-Process { param($Id, $Name, $ErrorAction) return [pscustomobject]@{ ProcessName = "nginx" } }',
  'function Get-CimInstance { param($ClassName, $Filter, $ErrorAction) return [pscustomobject]@{ ExecutablePath = "C:\\nginx\\nginx.exe" } }',
  'function Get-NetTCPConnection { param($LocalPort, $State, $ErrorAction) return @() }',
  'Write-Output ("mutiert=" + (Test-IstUnsereBridge 4711 8770 ' + psPfad(ROOT_TEST) + '))',
].join('\n'));
ok('Mutationsprobe: ein pauschales $true wuerde auffallen (fremdes nginx gilt dann als unsere)',
  !mutiert.fehler && /mutiert=True/.test(mutiert.aus || ''),
  mutiert.fehler || String(mutiert.aus || '').trim());

/* ------------------------------------------------------------------ *
 * 2) Der Watchdog selbst — die Eigenschaften, die man nicht "aufrufen" kann.
 * ------------------------------------------------------------------ */
const w = fs.readFileSync(WATCHDOG, 'utf8').replace(/\r\n/g, '\n');

/*
 * Fuer alle Pruefungen, die den CODE meinen, werden Kommentare entfernt. Sonst zaehlt der
 * erklaerende Text mit: die Begruendung ueber Test-IstUnsereBridge nennt "Stop-Process", und die
 * Zaehlung unten fand es prompt zweimal. Genau dieselbe Falle wie in paket-test.js — eine Datei,
 * die ihr eigenes Verhalten beschreibt, darf nicht an ihrer Beschreibung gemessen werden.
 *
 * Grenze: ein '#' INNERHALB einer Zeichenkette wuerde hier faelschlich als Kommentar gelten.
 * In dieser Datei kommt keines vor; sollte je eines dazukommen, faellt es hier als Fehlschlag auf.
 */
function ohneKommentare(t) {
  return t.replace(/<#[\s\S]*?#>/g, '').replace(/#.*$/gm, '');
}
const wCode = ohneKommentare(w);

/*
 * ALLE folgenden Pruefungen messen wCode, also den Text OHNE Kommentare.
 * Befund der Gegenpruefung: zehn von dreizehn massen vorher den Text MIT Kommentaren. Wer die
 * Heilungszeile oder das Dot-Source zum Fehlersuchen auskommentiert und das Zuruecknehmen
 * vergisst, haette einen vollstaendig gruenen Test und eine Station, die sich nie mehr selbst
 * heilt. Ein auskommentierter Aufruf ist kein Aufruf.
 */
ok('watchdog.ps1 laedt die pruefbare Entscheidung statt sie nachzubauen',
  /\.\s*\(Join-Path \$PSScriptRoot 'watchdog-entscheidung\.ps1'\)/.test(wCode));

ok('watchdog.ps1 laedt die pruefbare Herkunftserkennung',
  /\.\s*\(Join-Path \$PSScriptRoot 'watchdog-erkennung\.ps1'\)/.test(wCode));

ok('die Schleife faengt Fehler ab und kann nicht mehr sterben',
  /while \(\$true\) \{[\s\S]*?\n  try \{/.test(wCode) && /\n  \} catch \{[\s\S]*?\n  \}\n  Start-Sleep/.test(wCode));

ok('der Aufruf von launch-kiosk.ps1 liegt in try/catch (dort steht ein throw)',
  /try \{\s*\n\s*& \(Join-Path \$PSScriptRoot 'launch-kiosk\.ps1'\)[\s\S]{0,200}?\} catch \{/.test(wCode));

/* Stop-Process darf nur an EINER Stelle stehen, und nur in der Funktion, die vorher geprueft hat,
 * dass es unsere Bridge ist. Sonst waere die Sicherung umgehbar. */
const stopStellen = (wCode.match(/Stop-Process/g) || []).length;
ok('Stop-Process kommt im Code genau einmal vor', stopStellen === 1, 'gefunden: ' + stopStellen);

ok('beendet wird nur nach der Entscheidung "beenden-und-starten"',
  /if \(\$was -eq 'beenden-und-starten'\) \{[\s\S]{0,200}?Stop-EingefroreneBridge/.test(wCode));

/*
 * Der Rueckgabewert von Stop-EingefroreneBridge MUSS ausgewertet werden. Frueher stand dort
 * [void](...) — der Neustart lief auch nach gescheitertem Beenden und erzeugte bei jedem Takt
 * eine weitere Instanz ohne Ports. Der alte Test schrieb diese Form sogar als Sollzustand fest.
 */
ok('das Ergebnis des Beendens wird NICHT weggeworfen (kein [void])',
  !/\[void\]\s*\(\s*Stop-EingefroreneBridge/.test(wCode));

ok('gestartet wird nur, wenn das Beenden geglueckt ist',
  /if \(Stop-EingefroreneBridge \$inhaber\) \{[\s\S]{0,120}\$darfStarten = \$true/.test(wCode) &&
  /if \(\$darfStarten\) \{/.test(wCode));

ok('vor dem Beenden wird geprueft, ob der Prozess zu VetStation gehoert',
  /\$unsere = Test-IstUnsereBridge \$inhaber \$Port \$Root/.test(wCode));

/*
 * Stop-Process darf nur die GEPRUEFTE Kennung treffen. Ein Umbau auf "Stop-Process -Name node"
 * — etwa als vermeintliche Verbesserung, weil eine PID veralten kann — wuerde jeden node auf dem
 * Rechner beenden und waere von einer blossen Zaehlung nicht zu unterscheiden.
 */
ok('Stop-Process trifft ausschliesslich die geprüfte Prozesskennung (-Id $Kennung)',
  /Stop-Process -Id \$Kennung -Force/.test(wCode) && !/Stop-Process\s+-Name/.test(wCode));

ok('unmittelbar vor dem Beenden wird nochmals geprueft (PID-Wiederverwendung)',
  /\$jetzt = Get-PortInhaber \$Port/.test(wCode) &&
  /if \(\$jetzt -ne \$Kennung\)/.test(wCode) &&
  /if \(-not \(Test-IstUnsereBridge \$Kennung \$Port \$Root\)\)/.test(wCode));

ok('ein fremder Prozess wird nirgends beendet',
  !/\$was -eq 'fremd'[\s\S]{0,120}Stop-Process/.test(wCode));

ok('nach dem Beenden wird gewartet, bis der Port wirklich frei ist',
  /Get-PortInhaber \$Port\)\) \{ Schreibe "Prozess \$Kennung beendet, Port \$Port ist frei/.test(wCode));

ok('eine gescheiterte Portabfrage wird nicht als "Port frei" ausgelegt',
  /return -1/.test(wCode) && /\$inhaber -ne -1/.test(wCode));

ok('der Kiosk wird an seinem eigenen Profil erkannt, nicht an irgendeinem Edge',
  /VetStation\\\\EdgeProfile/.test(wCode) && !/\[bool\]\(Get-Process msedge/.test(wCode));

ok('es gibt eine Schwelle, damit ein einzelner Aussetzer nichts beendet',
  /\[int\]\$FehlerBisEingriff = 3/.test(wCode));

ok('die Zeitgrenze der Pruefung ist grosszuegiger als die alten 2 s',
  /-TimeoutSec 4/.test(wCode));

ok('jeder Eingriff hinterlaesst eine Spur in data\\watchdog.log',
  /watchdog\.log/.test(wCode) && /Add-Content -Path \$LogDatei/.test(wCode));

ok('das Protokoll waechst nicht unbegrenzt',
  /Get-Item \$LogDatei\)\.Length -gt 524288/.test(wCode));

/*
 * DER VERTRAG ZUR BRIDGE. Der Watchdog beurteilt "lebt sie?" allein an GET /healthz. Wird der
 * Endpunkt in der Bridge umbenannt, ohne watchdog.ps1 mitzuziehen, antwortet eine voellig
 * gesunde Station nie wieder — und die Selbstheilung, die es seit 1.2.1 gibt, beendet sie alle
 * 30 Sekunden. Aus einer Verbesserung wuerde eine Dauer-Abschussschleife. Deshalb wird hier
 * gegen den ECHTEN Server geprueft, nicht gegen eine Zeichenkette in derselben Datei.
 */
const server = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'server.js'), 'utf8');
ok('die Bridge bedient wirklich /healthz (sonst schiesst der Watchdog eine gesunde Station ab)',
  /pathname === '\/healthz'/.test(server));
ok('watchdog.ps1 fragt genau diesen Endpunkt ab',
  /Invoke-WebRequest "\$Url\/healthz"/.test(wCode));
ok('launch-kiosk.ps1 fragt denselben Endpunkt ab',
  /\$Url\/healthz/.test(ohneKommentare(fs.readFileSync(path.join(KIOSK, 'launch-kiosk.ps1'), 'utf8'))));
/* Ohne -UseBasicParsing versucht Invoke-WebRequest die Antwort mit der Internet-Explorer-Engine
 * zu zerlegen. Auf einem PC ohne IE-Erstkonfiguration wirft das — die Station gaelte als tot. */
ok('die Abfrage kommt ohne Internet-Explorer aus (-UseBasicParsing)',
  /-UseBasicParsing/.test(wCode));

/* PowerShell 5.1: die Pipeline-Operatoren && und || gibt es dort nicht. Ein Tippfehler dieser Art
 * wuerde den Watchdog beim Start mit einem Parserfehler beenden — und niemand saehe es, weil das
 * Fenster versteckt ist. */
ok('kein && oder || (in Windows PowerShell 5.1 ein Parserfehler)',
  !/&&|\|\|/.test(wCode));

/* Der eigentliche Beweis, dass die Datei fuer PowerShell 5.1 gueltig ist. */
if (!psFehler) {
  const p = spawnSync('powershell', ['-NoProfile', '-Command',
    '$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile(' +
    "'" + WATCHDOG.replace(/'/g, "''") + "'" + ', [ref]$null, [ref]$e); ' +
    'if ($e -and $e.Count) { $e[0].Message; exit 1 } else { "ok" }'],
    { encoding: 'utf8', timeout: 60000 });
  ok('watchdog.ps1 ist syntaktisch gueltig', p.status === 0, String(p.stdout || p.stderr || '').trim().slice(0, 200));

  const p2 = spawnSync('powershell', ['-NoProfile', '-Command',
    '$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile(' +
    "'" + ENTSCHEIDUNG.replace(/'/g, "''") + "'" + ', [ref]$null, [ref]$e); ' +
    'if ($e -and $e.Count) { $e[0].Message; exit 1 } else { "ok" }'],
    { encoding: 'utf8', timeout: 60000 });
  ok('watchdog-entscheidung.ps1 ist syntaktisch gueltig', p2.status === 0, String(p2.stdout || p2.stderr || '').trim().slice(0, 200));
}

/* ------------------------------------------------------------------ *
 * 3) stop-kiosk.ps1 — raeumt es auch die LIEGENGEBLIEBENE zweite Instanz weg?
 *
 * Am 01.08.2026 lag neben der eingefrorenen Station ein zweiter node-Prozess (PID 14440), den
 * der Watchdog gestartet hatte. Er hielt keinen einzigen Port — und wurde deshalb von
 * stop-kiosk.ps1 nie gefunden. Er haette jeden "Neustart" ueberlebt.
 * ------------------------------------------------------------------ */
const STOP = path.join(KIOSK, 'stop-kiosk.ps1');
const s = ohneKommentare(fs.readFileSync(STOP, 'utf8').replace(/\r\n/g, '\n'));

ok('stop-kiosk.ps1 sucht node-Prozesse auch OHNE Port',
  /Get-CimInstance Win32_Process -Filter "Name='node\.exe'"/.test(s));

ok('dabei wird nur node aus dem Stationsordner beendet (kein fremdes node)',
  /\$pfad -like \(Join-Path \$Root '\*'\)/.test(s));

ok('ohne lesbaren Pfad wird nichts beendet',
  /if \(\$pfad -and /.test(s));

/* Der Pfad darf NICHT ueber (Get-Process).Path gelesen werden: das wirft bei unzugaenglichen
 * Prozessen, und das noetige leere catch ist in dieser Datei seit 0.5.1 verboten (paket-test.js).
 * ExecutablePath aus CIM ist einfach leer, wenn Windows nichts sagt. */
ok('der Pfad wird ohne Ausnahme gelesen (kein leeres catch noetig)',
  /\$pfad = \$_\.ExecutablePath/.test(s) && !/catch\s*\{\s*\}/.test(s));

ok('die Rueckmeldung zaehlt die Rest-Instanzen mit',
  /Rest-Instanzen: \$reste/.test(s) && /\$reste -eq 0/.test(s));

if (!psFehler) {
  const p3 = spawnSync('powershell', ['-NoProfile', '-Command',
    '$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile(' +
    "'" + STOP.replace(/'/g, "''") + "'" + ', [ref]$null, [ref]$e); ' +
    'if ($e -and $e.Count) { $e[0].Message; exit 1 } else { "ok" }'],
    { encoding: 'utf8', timeout: 60000 });
  ok('stop-kiosk.ps1 ist syntaktisch gueltig', p3.status === 0, String(p3.stdout || p3.stderr || '').trim().slice(0, 200));
}

console.log('\n' + pass + ' bestanden, ' + fail + ' fehlgeschlagen');
process.exit(fail ? 1 : 0);
