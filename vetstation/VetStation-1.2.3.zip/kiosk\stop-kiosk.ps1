<#
  stop-kiosk.ps1 - Kiosk sauber beenden (Wartung). Stoppt den Kiosk-Edge und die Bridge.
  Hinweis: Der PIN-Schutz liegt IN der App (Admin-Bereich). Dieses Skript ist fuer die
  Wartung am dedizierten PC gedacht (z. B. nach Anmeldung als Admin).

  ADMINRECHTE: Der Autostart-Kiosk wird von install-autostart.ps1 als geplante Aufgabe mit
  -RunLevel Highest registriert - Bridge (node) und Edge laufen dadurch ERHOEHT. Aus einer
  normalen PowerShell scheitert Stop-Process dann mit "Zugriff verweigert". Frueher steckten
  die Aufrufe in try{}catch{}: es erschien trotzdem "VetStation gestoppt.", obwohl nichts
  gestoppt wurde. Deshalb ab 0.5.1: Rechte selbst anfordern und ehrlich berichten.

  Aufruf:  powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\stop-kiosk.ps1"
#>
param([int]$Port = 8770)

# --- Adminrechte sicherstellen -------------------------------------------------
$__id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
  try {
    Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass',
      '-File', ('"' + $PSCommandPath + '"'), '-Port', $Port)
  } catch {
    Write-Warning "Adminrechte noetig. Bitte PowerShell rechtsklicken -> 'Als Administrator ausfuehren'."
    Start-Sleep 6
  }
  exit
}

$edge = 0; $bridge = 0; $reste = 0; $fehler = @()
# Der Stationsordner - Massstab dafuer, was hier ueberhaupt beendet werden darf.
$Root = Split-Path $PSScriptRoot -Parent

# Kiosk-Edge (nur die VetStation-Instanz mit eigenem Profil) beenden
Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -match 'VetStation\\EdgeProfile' } |
  ForEach-Object {
    try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $edge++ }
    catch { $fehler += "Edge (PID $($_.ProcessId)): $($_.Exception.Message)" }
  }

<#
  Bridge (Node auf dem Port) beenden - aber nur, wenn es AUCH unsere ist.

  BEFUND DER GEGENPRUEFUNG (01.08.2026): Hier wurde bisher jeder Prozess beendet, der auf Port
  8770 horcht - ohne einen einzigen Blick darauf, WAS das ist. Und dieses Skript laeuft
  ausdruecklich ERHOEHT (es besorgt sich oben selbst Adminrechte), kann also praktisch alles
  abschiessen. Haelt den Port ein fremdes Programm - ein Entwicklungsserver, ein Hersteller-
  Werkzeug, ein VPN- oder Container-Proxy, ein Windows-Dienst, der ihn aus dem dynamischen
  Bereich erwischt hat -, beendet ein Doppelklick auf NEUSTART.bat dieses fremde Programm.
  Dass der Port "uns gehoert", ist eine Annahme, keine Tatsache.

  Geprueft wird jetzt dasselbe wie im Watchdog: der Prozess muss node heissen UND entweder aus
  dem Stationsordner stammen oder auf der Loopback-Adresse dieses Ports horchen. Trifft das
  nicht zu, wird er NICHT angefasst, sondern gemeldet - erhoehte Rechte sind ein Grund fuer mehr
  Sorgfalt, nicht fuer weniger.
#>
$c = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
foreach ($pidNr in ($c | ForEach-Object { $_.OwningProcess } | Select-Object -Unique)) {
  $w = Get-CimInstance Win32_Process -Filter "ProcessId=$pidNr" -ErrorAction SilentlyContinue
  $istNode = ($w -and $w.Name -eq 'node.exe')
  $imOrdner = ($w -and $w.ExecutablePath -and $w.ExecutablePath.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase))
  $loopback = @($c | Where-Object { $_.OwningProcess -eq $pidNr -and ($_.LocalAddress -eq '127.0.0.1' -or $_.LocalAddress -eq '::1') }).Count -gt 0
  if (-not $istNode -or -not ($imOrdner -or $loopback)) {
    $fehler += "Port $Port wird von einem FREMDEN Programm gehalten (PID $pidNr, $(if ($w) { $w.Name } else { 'unbekannt' })) - nicht beendet."
    continue
  }
  try { Stop-Process -Id $pidNr -Force -ErrorAction Stop; $bridge++ }
  catch { $fehler += "Bridge (PID $pidNr): $($_.Exception.Message)" }
}

<#
  LIEGENGEBLIEBENE ZWEITE INSTANZEN (Befund 01.08.2026, docs/BEFUND-EINGEFROREN-2026-08-01.md):
  Oben wird nur beendet, wer den PORT haelt. Am 01.08. lag daneben ein zweiter node-Prozess
  (PID 14440): der Watchdog hatte ihn gegen die eingefrorene Station gestartet, er fand jeden
  Port belegt, konnte nichts binden - und blieb liegen. Ohne Port wird er oben nie gefunden,
  ueberlebt jeden "Neustart" und verwirrt die naechste Fehlersuche.

  Warum die Erkennung hier ueber den PFAD gehen darf: dieses Skript hat sich oben Adminrechte
  besorgt. Erhoeht liefert Windows .Path auch fuer Prozesse aus der geplanten Aufgabe - anders
  als im Watchdog, der ohne Erhoehung laeuft und deshalb strenger pruefen muss.
  Beendet wird ausschliesslich node aus DIESEM Ordner. Fremde node-Prozesse (Entwicklung,
  andere Programme) liegen woanders und werden nicht angefasst.
#>
# Der Pfad wird ueber CIM gelesen, NICHT ueber (Get-Process).Path: die Eigenschaft wirft bei einem
# unzugaenglichen Prozess eine Ausnahme, und ein leeres catch waere hier genau der Fehler, den
# diese Datei seit 0.5.1 nicht mehr machen darf (lautloses Verschlucken). ExecutablePath ist
# schlicht leer, wenn Windows keine Auskunft gibt - dann wird nichts beendet.
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
  $pfad = $_.ExecutablePath
  if ($pfad -and ($pfad -like (Join-Path $Root '*'))) {
    try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $reste++ }
    catch { $fehler += "Rest-Instanz (PID $($_.ProcessId)): $($_.Exception.Message)" }
  }
}
if ($reste -gt 0) { Write-Host "Zusaetzlich beendet: $reste liegengebliebene VetStation-Instanz(en) ohne Port." }

# Ehrliche Rueckmeldung statt pauschalem "gestoppt."
if ($fehler.Count -gt 0) {
  Write-Warning "NICHT alles konnte beendet werden:"
  $fehler | ForEach-Object { Write-Warning "  - $_" }
  Write-Host "Der Kiosk laeuft moeglicherweise WEITER."
} elseif ($edge -eq 0 -and $bridge -eq 0 -and $reste -eq 0) {
  Write-Host "Es lief nichts: weder Kiosk-Edge noch Bridge auf Port $Port gefunden."
} else {
  Write-Host "VetStation gestoppt (Edge-Fenster: $edge, Bridge-Prozesse: $bridge, Rest-Instanzen: $reste)."
}
