<#
  launch-kiosk.ps1 - Startet VetStation als Appliance (wie ein IDEXX-Geraet):
  1) Bridge+UI (Node) starten (falls nicht laeuft) und auf Bereitschaft warten,
  2) Microsoft Edge (WebView2/Evergreen) im Vollbild-Kiosk auf die lokale UI oeffnen.

  Kein Rust/Tauri noetig - nutzt die bereits installierte Edge/WebView2-Runtime.
  Read-only: startet nur lokale Prozesse, sendet nie an Geraete.

  Aufruf:  powershell -ExecutionPolicy Bypass -File kiosk\launch-kiosk.ps1
  Optional: -Port 8770  -NoKiosk (nur Bridge)  -Watchdog (Selbstheilung)
#>
param(
  [int]$Port = 8770,
  [switch]$NoKiosk,
  [switch]$Watchdog
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path $PSScriptRoot -Parent
$Url  = "http://127.0.0.1:$Port"

function Find-Node {
  # 1) Mitgeliefertes portables Node (Installer-Bundle) hat Vorrang -> nichts extra installieren.
  foreach ($p in @("$Root\node\node.exe", "$PSScriptRoot\..\node\node.exe")) { if (Test-Path $p) { return (Resolve-Path $p).Path } }
  # 2) System-Node
  $n = (Get-Command node -ErrorAction SilentlyContinue)
  if ($n) { return $n.Source }
  foreach ($p in @("$env:ProgramFiles\nodejs\node.exe", "$env:LOCALAPPDATA\Programs\nodejs\node.exe")) { if (Test-Path $p) { return $p } }
  throw "Node.js nicht gefunden. Bitte das portable Node mitliefern (Ordner 'node\node.exe') oder Node 18+ installieren."
}

function Find-Edge {
  foreach ($p in @(
    "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")) {
    if (Test-Path $p) { return $p }
  }
  $c = Get-Command msedge -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  return $null
}

function Test-BridgeUp {
  try { $r = Invoke-WebRequest "$Url/healthz" -UseBasicParsing -TimeoutSec 2; return $r.StatusCode -eq 200 } catch { return $false }
}

function Apply-StagedUpdate {
  # Wendet ein per Admin geladenes & geprueftes App-Update an (VOR dem Bridge-Start),
  # damit keine laufenden Dateien ueberschrieben werden. Konfig/Daten bleiben erhalten.
  $pend = Join-Path $Root 'data\update-pending.json'
  $zip  = Join-Path $Root 'data\update-staged.zip'
  if ((Test-Path $pend) -and (Test-Path $zip)) {
    try {
      Write-Host "Wende bereitgestelltes App-Update an..."
      $tmp = Join-Path $env:TEMP ("vetstation-upd-" + [Guid]::NewGuid().ToString('N'))
      Expand-Archive -Path $zip -DestinationPath $tmp -Force
      $src = $tmp
      $entries = Get-ChildItem $tmp
      if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) { $src = $entries[0].FullName }
      # Programm-Dateien kopieren; lokale Konfig (devices.json) + data/ + node_modules + .git NICHT anfassen.
      robocopy $src $Root /E /XD "data" "node_modules" ".git" /XF "devices.json" | Out-Null
      <#
        DAS ERGEBNIS VON ROBOCOPY WIRD GEPRUEFT (Befund der Gegenpruefung 01.08.2026).

        Vorher wurde der Marker bedingungslos geloescht - egal, ob alles kopiert wurde. Robocopy
        meldet Fehler ueber den Rueckgabewert: 0-7 sind Erfolg (0 = nichts zu tun, 1 = kopiert,
        2 = Extras, 4 = veraltete Dateien; kombinierbar), ab 8 ist mindestens eine Datei NICHT
        kopiert worden - etwa weil ein Virenscanner, ein offener Editor oder eine noch laufende
        zweite node-Instanz sie haelt. Genau dieser Fall ist hier real: am 01.08.2026 lagen zwei
        liegengebliebene node-Prozesse aus dem Stationsordner herum.

        Die Folge war die schlimmstmoegliche: eine HALB aktualisierte Station - neue Dateien
        neben alten, die zueinander nicht passen - die sich fuer fertig aktualisiert haelt,
        weil der Marker weg ist. Kein Hinweis, kein zweiter Versuch, und die Fassungsnummer
        behauptet den neuen Stand.

        Jetzt: bei >= 8 bleiben Marker und Zip liegen, damit der naechste Start es erneut
        versucht, und es wird im Klartext gemeldet.
      #>
      $rcErgebnis = $LASTEXITCODE
      if ($rcErgebnis -ge 8) {
        Write-Warning ("Update NICHT vollstaendig angewendet (robocopy meldet $rcErgebnis). " +
          "Mindestens eine Datei liess sich nicht ersetzen - meist, weil sie noch von einem " +
          "Programm gehalten wird. Das Update bleibt bereitgestellt und wird beim naechsten " +
          "Start erneut versucht. Haelt das an: NEUSTART.bat, danach nochmals starten.")
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        return
      }
      Remove-Item $pend, $zip -Force -ErrorAction SilentlyContinue
      Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
      Write-Host "App-Update angewendet."
    } catch { Write-Warning "Update konnte nicht angewendet werden: $($_.Exception.Message)" }
  }
}

function Start-Bridge {
  if (Test-BridgeUp) { Write-Host "Bridge laeuft bereits auf $Url"; return }
  $node = Find-Node
  Write-Host "Starte Bridge+UI: $node bridge\src\index.js (Port $Port)"
  $env:PORT = "$Port"
  Start-Process -FilePath $node -ArgumentList "bridge\src\index.js" -WorkingDirectory $Root -WindowStyle Hidden
  $tries = 0
  while (-not (Test-BridgeUp)) {
    Start-Sleep -Milliseconds 400; $tries++
    if ($tries -gt 40) { throw "Bridge nicht erreichbar nach 16 s." }
  }
  Write-Host "Bridge bereit."
}

function Start-Kiosk {
  $edge = Find-Edge
  $profile = Join-Path $env:LOCALAPPDATA "VetStation\EdgeProfile"
  New-Item -ItemType Directory -Force -Path $profile | Out-Null
  if ($edge) {
    Write-Host "Starte Kiosk (Edge): $Url"
    # --disable-popup-blocking ist KEIN Komfort, sondern Voraussetzung fuer die Anmeldung:
    # Google und Microsoft muessen ihr eigenes Fenster oeffnen duerfen. Der frueher benutzte
    # Weg ueber eine Weiterleitung funktioniert nicht mehr - Edge trennt den Speicher von
    # vet-station.firebaseapp.com vom Speicher der Station (127.0.0.1), und die Anmeldung kommt
    # leer zurueck. Das Risiko ist hier gering: der Kiosk zeigt ausschliesslich die eigene
    # Oberflaeche, es gibt keine fremden Seiten, die ein Fenster aufreissen koennten.
    $args = @(
      "--kiosk", $Url,
      "--edge-kiosk-type=fullscreen",
      "--no-first-run", "--no-default-browser-check",
      "--disable-session-crashed-bubble", "--disable-infobars",
      "--disable-features=Translate,msEdgeWelcomePage,msImplicitSignin",
      "--disable-popup-blocking",
      "--overscroll-history-navigation=0",
      "--user-data-dir=$profile"
    )
    Start-Process -FilePath $edge -ArgumentList $args
  } else {
    Write-Warning "Microsoft Edge nicht gefunden. Oeffne Standardbrowser (kein Kiosk)."
    Start-Process $Url
  }
}

Apply-StagedUpdate
Start-Bridge
if (-not $NoKiosk) { Start-Kiosk }
if ($Watchdog) { & (Join-Path $PSScriptRoot 'watchdog.ps1') -Port $Port }
Write-Host "VetStation gestartet. UI: $Url"
