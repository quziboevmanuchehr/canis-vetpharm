'use strict';
/*
 * monitor-nachbau.js — der PC gibt sich als Mindray-MONITOR aus, damit sich das
 * Narkosegeraet Veta 5 Plus zu IHM verbindet.                        (29.08.2026)
 *
 * WARUM ES DIESE DATEI GIBT
 *
 * Der Veta 5 Plus gibt seine Werte ueber das Netz nicht her — als ZENTRALSTATION erreicht man
 * ihn nicht. Das ist gemessen und abgeschlossen (28./29.08.2026):
 *   - 24 Ports abgeklopft: KEINE offene Tuer. Er ist kein Server, er verbindet sich selbst.
 *   - "MD2: Ein" + Serveradresse 192.168.0.99, mit laufendem Fall UND nach Geraeteneustart:
 *     zwei Wachposten je 10 Minuten, NULL Verbindungen.
 *   - Kein Rundruf von ihm auf UDP 4600 / 4679 / 4620 / 4678 / 5100 / 4602.
 *
 * ABER: als MONITOR erreicht man ihn. Auf seiner Seite "System -> Setup -> Monitor verbunden"
 * stand am 28.08.2026 woertlich:
 *
 *     Geraetename   IP-Adresse Monitor
 *     M0001         192.168.0.50          ->  "Verbindung erfolgreich"
 *
 * Er hat sich also von sich aus zum uMEC12 verbunden. Und der uMEC12 ruft jede Sekunde ins
 * Netz — UDP 4600, 596 Byte, MLLP-gerahmtes HL7 "MSH|^~\&|||||||ADT^A01|101|P|2.3.1", darin
 * "OBX ST 2304^MonitorName = M0001". Das ist DIESELBE Zeichenkette, die der Veta in seiner
 * Liste anzeigt. Daraus folgt die Vermutung, die dieses Werkzeug pruefen soll:
 *
 *     Der Veta findet Monitore ueber den ADT^A01-Rundruf auf UDP 4600.
 *     Wer diesen Rundruf sendet, taucht in seiner Liste auf — auch dieser PC.
 *
 * Das ist KEIN Rateversuch am Protokoll. Es ist der Kanal, von dem gemessen feststeht, dass
 * der Veta ihn benutzt.
 *
 * WORAUF GELAUSCHT WIRD, UND WARUM AUF 4601
 * Der uMEC12 hat GENAU EINE offene Tuer: TCP 4601 (24 Ports abgeklopft). Wenn der Veta sich
 * zu ihm verbunden hat, dann dorthin. Deshalb lauscht dieser Nachbau auf 4601 — und
 * zusaetzlich auf ein paar Nachbarports, falls die Annahme nicht traegt.
 *
 * EHRLICHE ERWARTUNG
 * Was der Veta dann sendet, ist mit hoher Wahrscheinlichkeit MD2 — Mindrays Binaerformat.
 * Lesbar ist es damit noch NICHT. Der Gewinn waere trotzdem gross: zum ersten Mal ein
 * echter, sich VERAENDERNDER Strom von diesem Geraet statt der 26 identischen
 * Keepalive-Rahmen vom Juli. Genau das ist die Voraussetzung, um ein Format zu entziffern.
 * Der Mitschnitt landet deshalb so auf der Platte, dass tools/binaer-analyse.js ihn
 * unmittelbar auswerten kann.
 *
 * WAS DIESES WERKZEUG NICHT TUT
 * Es sendet KEINE Messwerte und KEINE Steuerung an den Veta — es ruft nur seinen Namen und
 * hoert zu. Ein Narkosegeraet bekommt von hier nichts gesagt.
 *
 * WAS EINE FREMDE RECHERCHE ZUM VETA-5-HANDBUCH DAZU BEITRAEGT (29.08.2026)
 * Nicht selbst am Geraet nachgeprueft, aber es raeumt eine Erwartung zurecht und spart am
 * Praxis-PC womoeglich einen ganzen Anlauf:
 *
 *   a) DIE RICHTUNG. Der dokumentierte Zweck dieser Kopplung ist, dass die Veta EtCO2 VOM
 *      Monitor BEZIEHT — sie ist der Nehmende, nicht der Gebende. Es ist also gut moeglich,
 *      dass sie nach dem Verbinden vor allem abonniert und wartet, statt Beatmungswerte zu
 *      senden. Der Gewinn bleibt derselbe (erstmals ein echter Strom von diesem Geraet), aber
 *      "verbunden" heisst nicht automatisch "sie erzaehlt uns Vt und PEEP".
 *      Steht der Monitor auf Standby, kommt laut Handbuch gar kein CO2 an der Veta an.
 *   b) DAS MENUE liegt im SYSTEMBEREICH und ist nur aus dem STANDBY erreichbar, hinter dem
 *      Systemkennwort (dokumentierter Werkswert 1234; das Handbuch verlangt, es nach der
 *      Installation zu aendern). Wer den Weg im laufenden Betrieb sucht, findet ihn nicht.
 *   c) Veta und "Monitor" muessen im SELBEN Netzabschnitt liegen UND dieselbe Subnetzmaske
 *      tragen. Bei uns ist das erfuellt (192.168.0.0/24), aber es erklaert, warum der Veta
 *      im Juli nichts fand: da stand der PC noch in 192.168.2.x.
 *   d) Erfolgreich ist es erst, wenn unten "Verbunden" steht — die blosse Anzeige in der
 *      Liste ist nur der Fund, nicht die Verbindung.
 *   e) Uebernommenes, also fremdes EtCO2 kennzeichnet die Veta in Historie und Export.
 *      Fuer den Leser des USB-Exports ist das gebaut (tools/veta-export-lesen.js, co2Paar):
 *      ein gekennzeichneter Wert behaelt seine Zahl, traegt aber `co2Fremd` — und darf den
 *      Vorrang "Schlauchmessung" dann NICHT bekommen, sonst zaehlt der Monitorwert zweimal.
 *
 * NICHT UEBERNOMMEN wurde aus derselben Recherche der Rat, den Veta gar nicht anzusprechen
 * und auf eine Herstellerspezifikation zu warten, sowie der Rat, TCP 4601 am uMEC erst noch
 * zu verifizieren: das ist seit dem 28.08.2026 gemessen erledigt, und dieselbe Recherche
 * raet ausdruecklich von der Abfrage ab, die bei uns als einzige funktioniert.
 *
 * NUTZUNG (am Praxis-PC, Geraete im selben Netz)
 *   1. Die VetStation anhalten — sie belegt Port 4601 mit ihrem Verbindungs-Assistenten:
 *        powershell -ExecutionPolicy Bypass -File C:\VetStation\kiosk\stop-kiosk.ps1
 *   2. node tools/monitor-nachbau.js --name VETSTATION --minuten 10
 *   3. Am Veta, im STANDBY:  Setup -> System -> Kennwort -> "Monitor verbunden"
 *      -> "Aktualisieren". Taucht der Name aus Schritt 2 auf: auswaehlen -> "Verbinden",
 *      und auf "Verbunden" warten.
 *   4. Zusehen, was hier ankommt. Danach am Veta "Trennen", Station wieder starten.
 *
 * WENN ES NICHT KLAPPT, ist der naechste Schritt NICHT, Ports zu raten, sondern zuzusehen:
 * Veta und uMEC12 offiziell miteinander koppeln (dieser Weg ist belegt und hat am 28.08.2026
 * funktioniert) und den Verkehr an einem Switch mit Port-Spiegelung mitschneiden. Dann sieht
 * man das echte Gespraech mit einem Gegenueber, von dem feststeht, dass es passt — statt
 * eines geratenen. Ein Managed Switch ist dafuer noetig; der vorhandene kann es nicht.
 */

const dgram = require('dgram');
const net = require('net');
const fs = require('fs');
const os = require('os');
const path = require('path');

const VT = 0x0b, FS_ = 0x1c, CR = 0x0d;

/* ---------------------------------------------------------------------------------------
 * Der Rundruf.
 *
 * Aufbau und Feldbelegung sind am 28.08.2026 vom echten uMEC12 abgehoert und entschluesselt
 * worden (596 Byte, 18 Segmente). Nachgebaut werden nur die Felder, die dort belegt waren;
 * erfunden wird nichts. Die Kennziffern stammen aus demselben Mitschnitt:
 *   2304 MonitorName (ST)      2308 BedNoStr (ST)        4529 Softwarestand (ST)
 *   2305/2306/2307/4526 (CE)   4527 (ST, 24 Nullen)      2319 (ST, Merkmalsfeld)
 *   2211/4524 (NM)             4528/4530/2320 (CE)
 *
 * Die Werte der Zustandsfelder werden aus dem Mitschnitt uebernommen. Sie zu VERSTEHEN war
 * nicht noetig und waere geraten — dieses Werkzeug will nur erkannt werden, nicht behaupten,
 * ein Monitor zu sein.
 */
function rundruf(name, ipZahl) {
  const seg = [
    'MSH|^~\\&|||||||ADT^A01|101|P|2.3.1',
    'EVN||' + stempel(),
    'PID|||' + name + '||' + name + '^|',
    'PV1|1|I|' + name + '|',
    'OBX||ST|2304^MonitorName||' + name + '||||||F',
    'OBX||CE|2305||0^||||||F',
    'OBX||CE|2306||3^||||||F',
    'OBX||CE|4526||1^||||||F',
    'OBX||CE|2307||2^||||||F',
    'OBX||NM|2211||0||||||F',
    'OBX||NM|4524||0||||||F',
    'OBX||ST|2308^BedNoStr||||||||F',
    'OBX||ST|4527||000000000000000000000000||||||F',
    'OBX||CE|4528||16^||||||F',
    'OBX||ST|4529||' + ipZahl + '||||||F',
    'OBX||CE|4530||1^||||||F',
    'OBX||ST|2319||001152204228000213235000000000000000000000000000||||||F',
    'OBX||CE|2320||7^||||||F',
  ];
  /* Jedes Segment mit <CR> abgeschlossen, auch das letzte. Genau daran ist die PDS-Abfrage
   * wochenlang gescheitert (siehe hl7.js, Befund 29.08.2026) — derselbe Fehler wird hier
   * nicht wiederholt. */
  const text = seg.join('\r') + '\r';
  return Buffer.concat([Buffer.from([VT]), Buffer.from(text, 'latin1'), Buffer.from([FS_, CR])]);
}

function stempel(d) {
  const t = d || new Date();
  const z = (n, b) => String(n).padStart(b || 2, '0');
  return t.getFullYear() + z(t.getMonth() + 1) + z(t.getDate()) +
    z(t.getHours()) + z(t.getMinutes()) + z(t.getSeconds());
}

/* Die eigenen IPv4-Adressen samt Rundrufadresse des jeweiligen Netzes. Der Rundruf muss in
 * DAS Netz gehen, in dem die Geraete stehen — auf diesem PC gibt es zwei (Hausnetz und
 * Geraetenetz, siehe die Notiz "zwei Netze, ein Kabel"). */
function netze() {
  const raus = [];
  const alle = os.networkInterfaces();
  Object.keys(alle).forEach(function (name) {
    (alle[name] || []).forEach(function (a) {
      if (a.family !== 'IPv4' || a.internal) return;
      const ip = a.address.split('.').map(Number);
      const mask = String(a.netmask || '255.255.255.0').split('.').map(Number);
      const rund = ip.map((o, i) => (o & mask[i]) | (~mask[i] & 255)).join('.');
      raus.push({ karte: name, ip: a.address, maske: a.netmask, rundruf: rund });
    });
  });
  return raus;
}

function argw(name, ersatz) {
  const i = process.argv.indexOf('--' + name);
  return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : ersatz;
}

function main() {
  if (process.argv.indexOf('--hilfe') > 0) {
    console.log('node tools/monitor-nachbau.js [--name VETSTATION] [--minuten 10] [--ordner data]');
    console.log('  Gibt den PC als Mindray-Monitor aus und schneidet mit, was sich verbindet.');
    console.log('  Sendet NUR den Namensrundruf - keine Messwerte, keine Steuerung.');
    return;
  }
  const name = argw('name', 'VETSTATION');
  const minuten = Math.max(1, Math.min(120, Number(argw('minuten', 10)) || 10));
  const ordner = argw('ordner', path.join(__dirname, '..', 'data'));
  const PORTS = [4601, 5000, 8830, 3502, 5100];

  const netz = netze();
  console.log('=======================================================================');
  console.log(' VetStation - Monitor-Nachbau   (der PC gibt sich als Monitor aus)');
  console.log('=======================================================================');
  console.log('');
  console.log('Name im Netz:      ' + name);
  console.log('Laufzeit:          ' + minuten + ' Minuten');
  console.log('Eigene Adressen:');
  netz.forEach(function (n) {
    console.log('   ' + n.ip.padEnd(16) + ' Karte ' + n.karte + '   Rundruf an ' + n.rundruf);
  });
  if (!netz.length) {
    console.log('   KEINE - dieser PC hat keine Netzadresse. Abgebrochen.');
    process.exit(2);
  }
  console.log('');

  /* --- Mitschnitt vorbereiten. Ein Ordner, der sich nicht beschreiben laesst, faellt SOFORT
   * auf und nicht erst nach zehn Minuten Messung. --- */
  let datei = null;
  try {
    fs.mkdirSync(ordner, { recursive: true });
    const probe = path.join(ordner, '.schreibprobe-' + process.pid);
    fs.writeFileSync(probe, 'x'); fs.unlinkSync(probe);
    datei = path.join(ordner, 'veta-mitschnitt-' + stempel() + '.bin');
  } catch (e) {
    console.log('Der Ordner ' + ordner + ' laesst sich nicht beschreiben: ' + e.message);
    console.log('Abgebrochen - ohne Mitschnitt waere die Messung verloren.');
    process.exit(3);
  }
  console.log('Mitschnitt:        ' + datei);
  console.log('');

  /* --- Zuhoeren, bevor gerufen wird: sonst verpasst man eine Verbindung, die sofort kommt. */
  const server = [];
  let verbindungen = 0, bytes = 0;
  PORTS.forEach(function (p) {
    const s = net.createServer(function (sock) {
      verbindungen++;
      const wer = sock.remoteAddress + ':' + sock.remotePort;
      console.log('');
      console.log('*** ' + uhr() + '  VERBINDUNG auf Port ' + p + ' von ' + wer + ' ***');
      sock.on('data', function (b) {
        bytes += b.length;
        try { fs.appendFileSync(datei, b); } catch (_) {}
        console.log('   ' + uhr() + '  ' + String(b.length).padStart(5) + ' Byte   ' + deute(b));
      });
      sock.on('error', function () {});
      sock.on('close', function () { console.log('   ' + uhr() + '  Verbindung von ' + wer + ' beendet.'); });
    });
    s.on('error', function (e) {
      console.log('Port ' + p + ' laesst sich nicht belegen (' + e.code + ')' +
        (e.code === 'EADDRINUSE' ? ' - laeuft die VetStation noch? Sie muss dafuer angehalten werden.' : ''));
    });
    s.listen(p, function () { console.log('lausche auf TCP ' + p); });
    server.push(s);
  });

  /* --- Der Rundruf, im Sekundentakt wie beim echten Geraet. --- */
  const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  sock.on('error', function (e) { console.log('UDP-Fehler: ' + e.message); });
  sock.bind(function () {
    try { sock.setBroadcast(true); } catch (_) {}
    console.log('');
    console.log('rufe jede Sekunde auf UDP 4600 ...');
    console.log('');
    console.log('JETZT am Veta:  System -> Setup -> "Monitor verbunden" -> "Aktualisieren"');
    console.log('                Taucht "' + name + '" auf: auswaehlen und "Verbinden".');
    console.log('');
  });

  let rufe = 0;
  const takt = setInterval(function () {
    netz.forEach(function (n) {
      const b = rundruf(name, '001013000001');
      sock.send(b, 0, b.length, 4600, n.rundruf, function () {});
      sock.send(b, 0, b.length, 4600, '255.255.255.255', function () {});
    });
    rufe++;
  }, 1000);

  const ende = setTimeout(function () {
    clearInterval(takt);
    try { sock.close(); } catch (_) {}
    server.forEach(function (s) { try { s.close(); } catch (_) {} });
    console.log('');
    console.log('=======================================================================');
    console.log(' Fertig. ' + rufe + ' Rundrufe gesendet.');
    if (!verbindungen) {
      console.log('');
      console.log(' KEINE Verbindung. Der Veta hat sich nicht gemeldet.');
      console.log('');
      console.log(' WAS DAS HEISST - und was es NICHT heisst:');
      console.log('   Es heisst NICHT, dass der Weg falsch ist. Es heisst nur, dass DIESER');
      console.log('   Rundruf nicht genuegt hat. Moegliche Gruende, in dieser Reihenfolge:');
      console.log('   1. Am Veta wurde "Aktualisieren" nicht gedrueckt oder der Name stand');
      console.log('      nicht in der Liste - dann hat der Rundruf ihn nicht erreicht');
      console.log('      (falsches Netz? Firewall? "GERAETE-PRUEFEN.bat" zeigt das Netz).');
      console.log('   2. Der Name stand da, "Verbinden" schlug fehl - dann stimmt der Port');
      console.log('      nicht; dieser Nachbau lauscht auf ' + PORTS.join(', ') + '.');
      console.log('   3. Der Veta prueft mehr als den Namen (Kennung, Version, Antwort auf');
      console.log('      eine Rueckfrage). Dann braucht es einen Mitschnitt der ECHTEN');
      console.log('      Anmeldung zwischen Veta und uMEC12 - siehe "CaptureNetPackage" im');
      console.log('      Netzwerk-Setup des Monitors.');
    } else {
      console.log('');
      console.log(' ' + verbindungen + ' Verbindung(en), ' + bytes + ' Byte empfangen.');
      console.log(' Mitschnitt: ' + datei);
      console.log('');
      console.log(' NAECHSTER SCHRITT:');
      console.log('   node tools/binaer-analyse.js "' + datei + '"');
      console.log('   Sie sagt, ob es HL7 ist (dann liest VetStation es direkt) oder Binaer');
      console.log('   (dann zeigt sie, welche Byte-Stellen sich AENDERN - das sind die');
      console.log('   Kandidaten fuer Datenfelder).');
    }
    console.log('=======================================================================');
    process.exit(0);
  }, minuten * 60000);
  ende.unref && null;
}

function uhr() {
  const t = new Date();
  const z = (n) => String(n).padStart(2, '0');
  return z(t.getHours()) + ':' + z(t.getMinutes()) + ':' + z(t.getSeconds());
}

/*
 * Eine erste Einordnung des Empfangenen - mehr nicht. HL7 ueber MLLP beginnt zwingend mit
 * 0x0B; Mindrays MD2 hat den Rahmen 0x02 (STX) und das Sync-Wort A5 5A (belegt aus
 * probe-*.log, Juli 2026). Alles andere heisst "unbekannt" und wird NICHT gedeutet.
 */
function deute(b) {
  if (!b.length) return '(leer)';
  const hex = b.slice(0, 12).toString('hex').replace(/(..)/g, '$1 ').trim();
  if (b[0] === VT) return 'HL7/MLLP   ' + b.slice(1, 60).toString('latin1').replace(/[\r\n]/g, ' ');
  if (b[0] === 0x02) return 'MD2? (STX) ' + hex;
  if (b.indexOf(Buffer.from([0xa5, 0x5a])) >= 0) return 'MD2? (Sync A5 5A) ' + hex;
  if (/^MSH\|/.test(b.slice(0, 4).toString('latin1'))) return 'HL7 ohne Rahmen  ' + b.slice(0, 60).toString('latin1');
  return 'unbekannt  ' + hex;
}

if (require.main === module) main();
module.exports = { rundruf, netze, deute, stempel };
