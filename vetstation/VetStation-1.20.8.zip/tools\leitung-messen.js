'use strict';
/*
 * leitung-messen.js — was die Strecke zur Firebase-Datenbank wirklich hergibt.
 *
 * FRAGE (19.08.2026): "Es muss Millisekunden-Uebertragung sein." Die Softwarekette ist mit
 * tools/fern-durchsatz-test.js gemessen (Mitte 118 ms, langsamste 203 ms). Was fehlt, ist die
 * NETZSTRECKE. Ohne angeschlossenes Geraet laesst sie sich trotzdem messen: gefragt ist die
 * Leitung, nicht die Quelle.
 *
 * GEMESSEN WIRD, was ohne Anmeldung messbar ist und die Untergrenze setzt:
 *   1. DNS-Aufloesung des Datenbank-Wirts
 *   2. TCP+TLS-Handschlag (einmalig je Verbindung)
 *   3. Umlaufzeit einer HTTPS-Anfrage an denselben Wirt, mehrfach, ueber eine OFFENE
 *      Verbindung (so wie der Dauerkanal der Station arbeitet)
 * Die Anfrage wird ohne Anmeldung abgewiesen - das ist gewollt und aendert an der ZEIT
 * nichts: gemessen wird der Weg hin und zurueck, nicht was am Ende steht.
 *
 * WAS DAS NICHT MISST: die Schreibzeit in der Datenbank selbst und die Zustellung an einen
 * zweiten Zuhoerer. Beides liegt oberhalb dieser Zahl, nie darunter - als UNTERGRENZE ist die
 * Messung also belastbar.
 */
var https = require('https');
var dns = require('dns');
var tls = require('tls');

var WIRT = 'vet-station-default-rtdb.europe-west1.firebasedatabase.app';
var RUNDEN = 12;

function ms(a) { return Math.round((Number(process.hrtime.bigint() - a) / 1e6) * 10) / 10; }
function mitte(a) { var b = a.slice().sort(function (x, y) { return x - y; }); return b[Math.floor(b.length / 2)]; }

console.log('LEITUNG ZUR FERN-DATENBANK — gemessen ' + new Date().toISOString().slice(0, 16).replace('T', ' '));
console.log('  Wirt: ' + WIRT + '\n');

var t0 = process.hrtime.bigint();
dns.lookup(WIRT, function (e, adr) {
  var dnsMs = ms(t0);
  if (e) { console.log('  DNS: FEHLER ' + e.message); return; }
  console.log('  1) DNS-Aufloesung      ' + dnsMs + ' ms   -> ' + adr);

  var t1 = process.hrtime.bigint();
  var sock = tls.connect({ host: WIRT, port: 443, servername: WIRT }, function () {
    var tlsMs = ms(t1);
    console.log('  2) TCP + TLS          ' + tlsMs + ' ms   (einmalig je Verbindung)');
    sock.end();

    /* 3) Umlaufzeiten ueber eine OFFENE Verbindung - so arbeitet der Dauerkanal. */
    var agent = new https.Agent({ keepAlive: true, maxSockets: 1 });
    var zeiten = [];
    var koerper = JSON.stringify({ s: new Array(250).join('AB') });   /* ~500 Byte, Groesse eines Kurvenpakets */
    console.log('  3) Umlaufzeiten ueber eine offene Verbindung (' + RUNDEN + ' Runden, Rumpf ' + koerper.length + ' Byte):');

    function runde(i) {
      if (i >= RUNDEN) return fertig();
      var t = process.hrtime.bigint();
      var req = https.request({
        host: WIRT, port: 443, path: '/__vetstation_messung.json', method: 'PUT', agent: agent,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(koerper) }
      }, function (res) {
        res.resume();
        res.on('end', function () { zeiten.push(ms(t)); setTimeout(function () { runde(i + 1); }, 40); });
      });
      req.on('error', function (err) { console.log('     Runde ' + (i + 1) + ': Fehler ' + err.message); runde(i + 1); });
      req.end(koerper);
    }

    function fertig() {
      agent.destroy();
      if (!zeiten.length) { console.log('     keine Messung zustande gekommen'); return; }
      var min = Math.min.apply(null, zeiten), max = Math.max.apply(null, zeiten), m = mitte(zeiten);
      console.log('     schnellste ' + min + ' ms · Mitte ' + m + ' ms · langsamste ' + max + ' ms');
      console.log('');
      console.log('  WAS DARAUS FOLGT');
      console.log('    Untergrenze fuer EINEN Weg (hin oder zurueck): rund ' + Math.round(m / 2) + ' ms.');
      console.log('    Ein Wert vom Geraet bis auf den Schirm zu Hause braucht mindestens');
      console.log('    Softwarekette + Hinweg + Datenbank + Rueckweg. Mit der gemessenen');
      console.log('    Softwarezeit (Mitte 118 ms) sind das rund ' + (118 + m) + ' ms im besten Fall.');
      console.log('');
      console.log('    Fuer eine EKG-Kurve mit 250 Abtastwerten je Sekunde und 4 Bahnen bedeutet');
      console.log('    ein Paket je 40 ms: 25 Pakete/s. Bei ' + m + ' ms Umlauf und einer offenen');
      console.log('    Verbindung ist das erreichbar; die Grenze ist dann nicht die Zeit, sondern');
      console.log('    die Datenmenge - siehe die Rechnung im Bericht.');
    }
    runde(0);
  });
  sock.on('error', function (err) { console.log('  2) TCP + TLS: FEHLER ' + err.message); });
});
