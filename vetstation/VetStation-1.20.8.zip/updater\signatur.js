'use strict';
/*
 * signatur.js — die Signatur des Update-Pakets: EINE Stelle fuer Bilden und Pruefen.
 *
 * WARUM EINE EIGENE DATEI (13.08.2026):
 * Signiert wird beim Freigeben (tools/paket-signieren.js), geprueft wird auf jedem Praxis-PC
 * (updater/updater.js). Stuende die Vorschrift zweimal im Haus, wuerde eine Haelfte
 * irgendwann anders rechnen als die andere - und das faellt nicht auf, sondern es faellt AUS:
 * entweder nimmt die Station gefaelschte Pakete an, oder sie lehnt die echten ab. Beides
 * bemerkt man erst am Praxis-PC. Deshalb steht die Vorschrift genau einmal, hier.
 *
 * WAS SIGNIERT WIRD - und warum nicht bloss die Pruefsumme:
 *
 *     vetstation-update-v1\n<version>\n<sha256 in Kleinbuchstaben>
 *
 * Die naheliegende Loesung waere, nur den sha256 zu signieren. Sie hat eine Luecke: die
 * VERSIONSNUMMER stuende dann unsigniert im Manifest und liesse sich frei aendern. Ein
 * Angreifer, der irgendein ALTES, echt signiertes Paket kennt, koennte es unter einer hohen
 * Nummer neu anbieten - Signatur gueltig, Pruefsumme gueltig - und jede Station "aktualisiert"
 * sich auf einen alten Stand mit alten, laengst behobenen Fehlern. Weil die Nummer danach
 * hoeher steht, bekommt sie die echte Fassung nie wieder angeboten.
 * Version und Inhalt zusammen zu signieren schliesst das: das Paar ist unteilbar.
 *
 * Das Praefix 'vetstation-update-v1' bindet die Signatur an DIESEN Zweck und an diese
 * Fassung der Vorschrift. Wird das Format je erweitert, heisst es v2 - eine alte Signatur
 * kann dann nicht mehr fuer den neuen Zweck durchgehen.
 *
 * Ed25519, weil es in Node ohne jede Abhaengigkeit steckt und kurze Signaturen liefert.
 * Es ist NICHT post-quanten-sicher; warum das hier vertretbar ist und was der naechste
 * Schritt waere, steht in docs/SICHERHEIT-POSTQUANTEN.md, Abschnitt 4.
 */
const crypto = require('crypto');

const PRAEFIX = 'vetstation-update-v1';

/* Die zu signierende Aussage. Streng: fehlt eines von beidem, gibt es keine Aussage -
 * lieber ein Abbruch beim Freigeben als eine Signatur ueber "undefined". */
function aussage(version, sha256) {
  const v = String(version || '').trim();
  const h = String(sha256 || '').trim().toLowerCase();
  if (!/^\d+\.\d+\.\d+$/.test(v)) throw new Error('Version fehlt oder ist keine Nummer der Form 1.2.3: "' + v + '"');
  if (!/^[0-9a-f]{64}$/.test(h)) throw new Error('sha256 fehlt oder ist kein 64-stelliger Hexwert');
  return Buffer.from(PRAEFIX + '\n' + v + '\n' + h, 'utf8');
}

/* Signieren mit dem PRIVATEN Schluessel (nur beim Freigeben, nie auf einer Station). */
function signiere(version, sha256, privatPem) {
  const key = crypto.createPrivateKey(privatPem);
  if (key.asymmetricKeyType !== 'ed25519') throw new Error('Der private Schluessel ist kein Ed25519-Schluessel.');
  return crypto.sign(null, aussage(version, sha256), key).toString('base64');
}

/*
 * Pruefen mit dem OEFFENTLICHEN Schluessel. Gibt { ok, grund } zurueck - nie einen Wurf:
 * diese Funktion laeuft auf dem Praxis-PC, und eine unbehandelte Ausnahme im Updater ist
 * dort schlimmer als ein abgelehntes Update.
 *
 * ALLES, WAS NICHT AUSDRUECKLICH GUT IST, IST SCHLECHT. Kein Schluessel, keine Signatur,
 * unlesbare Signatur, falsche Aussage - jeder dieser Faelle ist ein ABBRUCH. Ein Riegel,
 * der bei fehlender Angabe durchlaesst, ist kein Riegel: der Angreifer laesst die Angabe
 * dann einfach weg.
 */
function pruefe(version, sha256, signaturBase64, oeffentlichPem) {
  if (!oeffentlichPem) return { ok: false, grund: 'Der oeffentliche Freigabeschluessel fehlt in dieser Installation.' };
  if (!signaturBase64) return { ok: false, grund: 'Das Manifest enthaelt keine Signatur (Feld sigEd25519).' };
  let key;
  try {
    key = crypto.createPublicKey(oeffentlichPem);
  } catch (e) { return { ok: false, grund: 'Der oeffentliche Freigabeschluessel ist unlesbar: ' + e.message }; }
  if (key.asymmetricKeyType !== 'ed25519') return { ok: false, grund: 'Der Freigabeschluessel ist kein Ed25519-Schluessel.' };
  let daten;
  try {
    daten = aussage(version, sha256);
  } catch (e) { return { ok: false, grund: e.message }; }
  let sig;
  try {
    sig = Buffer.from(String(signaturBase64), 'base64');
    /* Ed25519-Signaturen sind immer genau 64 Byte. Base64 verschluckt Unfug klaglos -
     * ohne diese Laengenpruefung ginge "Hallo" als (falsche) Signatur durch und der
     * Fehlertext hiesse "ungueltig" statt "unlesbar". */
    if (sig.length !== 64) return { ok: false, grund: 'Die Signatur hat ' + sig.length + ' statt 64 Byte.' };
  } catch (e) { return { ok: false, grund: 'Die Signatur ist kein gueltiges Base64.' }; }
  let gut = false;
  try {
    gut = crypto.verify(null, daten, key, sig);
  } catch (e) { return { ok: false, grund: 'Die Signaturpruefung ist gescheitert: ' + e.message }; }
  if (!gut) {
    return { ok: false, grund: 'Die Signatur passt NICHT zu Version ' + version + ' und dieser Pruefsumme. '
      + 'Das Paket stammt nicht von der Stelle, die dieses Programm ausliefert.' };
  }
  return { ok: true, grund: null };
}

/* Kurzer Fingerabdruck eines oeffentlichen Schluessels - zum Vergleichen in Protokollen
 * und Tests, ohne den ganzen Schluessel auszugeben. */
function fingerabdruck(oeffentlichPem) {
  return crypto.createHash('sha256').update(String(oeffentlichPem)).digest('hex').slice(0, 16);
}

module.exports = { PRAEFIX, aussage, signiere, pruefe, fingerabdruck };
