'use strict';
/*
 * webapp-fern-test.js — prueft den Fern-Live-Baustein der ausgelieferten Web-App, KOPFLOS.
 *
 * Warum es diesen Test ueberhaupt gibt (Nachbesserung N15 der Vorgabe docs/PLAN-MEHRERE-SAELE.md):
 * Der Umbau auf mehrere OP-Saele (Plan-Schritt 19) ist die groesste Einzelaenderung des Vorhabens
 * und hatte als einzige Pruefung Handarbeit "mit zwei Demo-Saelen". Kein Test im Projekt fasst die
 * Web-App an, es gibt dort keine Bau-Kette und kein Modulsystem — der letzte script-Block ist eine
 * IIFE in einer 4200-Zeilen-HTML-Datei. Ausfuehren laesst er sich ohne Browser, ohne DOM und ohne
 * Firebase nicht. Deshalb prueft dieser Test ihn ALS TEXT, und zusaetzlich einmal als Programm
 * (new Function), damit ein Syntaxfehler nicht erst beim Tierarzt im Browser auffaellt.
 *
 * Was hier NIE wieder passieren darf:
 *   • Ein gemeinsamer Skalar lastRecv/laufzeit fuer ALLE Saele. Dann laesst ein weiterlaufender
 *     Saal einen ausgefallenen frisch erscheinen, und ein schwaches WLAN in OP 2 treibt die
 *     Laufzeitanzeige von OP 1 auf 1200 ms. (Plan, Feld "oberflaechen", WEB-APP)
 *   • Ein Saalwechsel ohne Ruecksetzen. Befund B2-1, als toedlich eingestuft: sv() in applyLive
 *     weist nur nicht-leere Werte zu, iv.nibp faellt auf iv.nibp||0 zurueck, und die
 *     Aenderungssignatur ist bei zwei 22-kg-Hunden identisch. Ohne Ruecksetzen stehen EtCO2, Temp
 *     und AF des Tiers aus OP 1 unter dem NAMEN des Tiers aus OP 2 — ausgewiesen als gemessene
 *     Istwerte — und gehen in Dosis- und Beatmungsempfehlung ein.
 *   • Ein onValue-Ergebnis, das weggeworfen wird. Dann laesst sich kein Abonnement mehr abbauen:
 *     jeder Saalwechsel legt ein weiteres 5-Hz-Dauerabonnement dazu, und das Protokoll bleibt nach
 *     erneutem Anmelden dauerhaft leer (der Merkzettel protAbos stand noch auf true).
 *   • Ein Datenbankstring, der ohne esc() in ein data-Attribut interpoliert wird. Bis 1.0.3 war
 *     data-k genau so gebaut — eine offene Luecke, denn der patientKey kommt aus der Datenbank.
 *   • handleSnapshot als zweite, ungepflegte Zuordnungslogik neben dem echten Weg.
 *
 * Laeuft OHNE Netz, ohne Browser und ohne Uhr. Es wird kein Zeitpunkt gemessen, nur Text gelesen.
 *
 * ANDERES REPO: die Web-App liegt NICHT in diesem Projekt. Fehlt sie (anderer PC, nur VetStation
 * ausgecheckt), UEBERSPRINGT dieser Test mit Klartext und endet mit 0. Rot waere dort eine
 * Falschmeldung — und tools/alle-tests.js:90 verbietet bei rot den Setup-Bau.
 *
 * Start: node tools/webapp-fern-test.js
 */
const fs = require('fs');
const path = require('path');

/* Pfad zur Web-App. Relativ hergeleitet, damit er auf jedem PC stimmt, auf dem beide
 * Arbeitsordner nebeneinander liegen: <...>/Manu/VetStation/quellcode/tools -> <...>/Manu. */
const WEBAPP = path.resolve(__dirname, '..', '..', '..', 'canis-vetpharm', 'canis-anaesthesie', 'index.html');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

if (!fs.existsSync(WEBAPP)) {
  console.log('UEBERSPRUNGEN: Die Web-App liegt in einem anderen Arbeitsordner und ist hier nicht vorhanden.');
  console.log('  Erwartet: ' + WEBAPP);
  console.log('  Das ist kein Fehler. Auf einem PC, auf dem nur VetStation ausgecheckt ist, gibt es die Datei nicht.');
  process.exit(0);
}

/*
 * ZEILENENDEN NORMALISIEREN (Befund 01.08.2026 — dieselbe Klasse wie Befund 2.12 in paket-test.js).
 *
 * Die Web-App liegt in einem EIGENEN Git-Repo. Sobald git sie anfasst (auschecken, zusammenfuehren),
 * schreibt es unter Windows CRLF hinein. Der Schnitt weiter unten sucht aber woertlich nach
 * '\n<script>\n' — nach einem Merge findet er nichts mehr, und der Test meldete "letzter
 * script-Block gefunden -> 0 Zeichen" samt zwanzig Folgefehlern. Ein Fehler, der keiner ist: an
 * der Datei hatte sich inhaltlich nichts geaendert.
 *
 * Gemeint ist der Inhalt, nicht das Zeilenende.
 */
const html = fs.readFileSync(WEBAPP, 'utf8').replace(/\r\n/g, '\n');

/* ---------------------------------------------------------------------------
 * 1. DEN LETZTEN SCRIPT-BLOCK HERAUSSCHNEIDEN
 * Nur er gehoert der Fern-Ansicht. Alles davor ist Motor, Oberflaeche und Stil und wird von
 * diesem Umbau ausdruecklich NICHT angefasst.
 * --------------------------------------------------------------------------- */
const AUF = '\n<script>\n', ZU = '\n</script>\n';
const a = html.lastIndexOf(AUF);
const z = html.lastIndexOf(ZU);
const block = (a >= 0 && z > a) ? html.slice(a + AUF.length, z + 1) : '';

console.log('\n== 1. Der letzte script-Block ==');
ok('letzter script-Block gefunden', block.length > 5000, block.length + ' Zeichen');
ok('es ist der Fern-Live-Baustein', /VETLIVE_CFG/.test(block) && /vetlive-bar/.test(block));

/*
 * KOMMENTARE ENTFERNEN — zeichenweise mit Texterkennung, weil ein '//' innerhalb einer Adresse
 * ('https://...') kein Kommentar ist. Uebernommen aus tools/tafel-test.js, samt der dortigen
 * Begruendung: die Texterkennung wird an JEDEM Zeilenende zurueckgesetzt, weil diese Datei kein
 * JS-Zerleger ist und ein Anfuehrungszeichen auch in einem regulaeren Ausdruck steht. Der Irrtum
 * bleibt damit auf SEINE Zeile beschraenkt und wirkt in die sichere Richtung: im Zweifel bleibt
 * Text stehen, ein Verbot findet also eher ein Vorkommen zu viel (Test wird rot) als eines zu
 * wenig (Test bliebe gruen). Abschnitt 10 prueft nach, dass nichts verloren geht.
 */
function ohneKommentare(t) {
  const zeilen = String(t == null ? '' : t).split('\n');
  let out = '', imBlock = false;
  for (let i = 0; i < zeilen.length; i++) {
    const zeile = zeilen[i];
    let neu = '', text = null;
    for (let j = 0; j < zeile.length; j++) {
      const c = zeile[j], c2 = zeile[j + 1];
      if (imBlock) { if (c === '*' && c2 === '/') { imBlock = false; j++; } continue; }
      if (text) { neu += c; if (c === '\\') { if (c2 !== undefined) { neu += c2; j++; } continue; } if (c === text) text = null; continue; }
      if (c === '"' || c === "'" || c === '`') { text = c; neu += c; continue; }
      if (c === '/' && c2 === '/') break;
      if (c === '/' && c2 === '*') { imBlock = true; j++; continue; }
      neu += c;
    }
    out += neu + '\n';
  }
  return out;
}
const code = ohneKommentare(block);

/* ---------------------------------------------------------------------------
 * 2. HANDLESNAPSHOT IST WEG
 * Sie war eine zweite Zuordnungslogik neben dem echten Abonnementweg — ungepflegt, aber
 * vollstaendig aussehend. Der Plan streicht sie ersatzlos.
 * --------------------------------------------------------------------------- */
console.log('\n== 2. Toter Code ==');
ok('handleSnapshot kommt im Block nicht mehr vor (auch nicht als Kommentar)',
  block.indexOf('handleSnapshot') === -1);

/* ---------------------------------------------------------------------------
 * 3. KEIN SKALAR MEHR FUER ALLE SAELE
 * Aus lastRecv, laufzeit, laufzeitMin und laufzeitMax werden Abbildungen JE SID. Geprueft wird
 * die ZUWEISUNG: ein blosses Lesen des alten Namens gaebe es ohnehin nicht mehr, eine Zuweisung
 * waere dagegen genau der Rueckfall in den gemeinsamen Zaehler.
 * --------------------------------------------------------------------------- */
console.log('\n== 3. Abbildungen je sid statt Skalaren ==');
[['lastRecv', 'lastRecvSid'], ['laufzeit', 'laufzeitSid'],
 ['laufzeitMin', 'laufzeitMinSid'], ['laufzeitMax', 'laufzeitMaxSid']].forEach(function (paar) {
  const bloss = new RegExp('(^|[^A-Za-z0-9_$.])' + paar[0] + '\\s*=[^=]');
  ok('kein blosses "' + paar[0] + ' =" mehr', !bloss.test(code),
    (code.match(bloss) || [''])[0].trim());
  ok('dafuer die Abbildung ' + paar[1], code.indexOf(paar[1]) >= 0);
});
ok('die Abbildungen werden auch je sid GELESEN (Index mit einer Variablen)',
  /lastRecvSid\[/.test(code) && /laufzeitSid\[/.test(code));
/*
 * Gemessen 31.07.2026 (Mutationsprobe): laufzeitSid[sid] durch laufzeitSid[selSaal] zu ersetzen
 * liess den Test gruen — dabei ist das genau der Fehler, gegen den die Abbildung ueberhaupt
 * gebaut wurde (schwaches WLAN in OP 2 treibt die Laufzeitanzeige von OP 1 auf 1200 ms).
 * Deshalb wird jetzt geprueft, dass die Messung mit IHREM EIGENEN Parameter indiziert wird.
 */
ok('messeLaufzeit schreibt unter den uebergebenen Saal, nicht unter den gefuehrten',
  /function\s+messeLaufzeit\s*\(\s*sid\s*,[\s\S]{0,600}?laufzeitSid\[sid\]\s*=/.test(code) &&
  !/laufzeitSid\[\s*selSaal\s*\]\s*=/.test(code));
ok('zaehleTakt ebenso', /function\s+zaehleTakt\s*\(\s*sid\s*\)[\s\S]{0,400}?lastRecvSid\[sid\]\s*=/.test(code));

/* ---------------------------------------------------------------------------
 * 4. JEDES onValue-ERGEBNIS WIRD FESTGEHALTEN
 * Die Rueckgabe von onValue IST die Abmeldefunktion (off). Bis 1.0.3 wurde sie weggeworfen —
 * deshalb konnte waehleSaal() gar nicht gebaut werden, und protAbos war nur ein Merkzettel.
 * --------------------------------------------------------------------------- */
console.log('\n== 4. Abonnements sind abbaubar ==');
const onValues = code.match(/[^\n]*\bonValue\s*\(/g) || [];
ok('es gibt ueberhaupt onValue-Aufrufe', onValues.length >= 4, onValues.length + ' gefunden');
const ohneZuweisung = onValues.filter(function (zeile) { return !/=\s*[A-Za-z0-9_$.]*onValue\s*\($/.test(zeile.trim()); });
ok('JEDES onValue-Ergebnis steht in einer Variablen (fuer off())',
  ohneZuweisung.length === 0, ohneZuweisung.join(' | '));
ok('und es wird auch wirklich abbestellt', /function\s+abbestellen/.test(code) && /abbestellen\s*\(/.test(code));
ok('waehleSaal baut das Patienten-Abo ab, bevor es das neue setzt',
  /function\s+waehleSaal[\s\S]{0,900}abbauPatientenAbo\s*\(/.test(code));
ok('Abmelden raeumt ALLE Abonnements ab (behebt das dauerhaft leere Protokoll)',
  /function\s+abmelden[\s\S]{0,400}abbauAlleAbos\s*\(/.test(code));

/* ---------------------------------------------------------------------------
 * 5. JEDER DATENBANKSTRING GEHT DURCH esc()
 * Geprueft wird jedes data-Attribut, dessen Wert INTERPOLIERT wird (also aus Daten stammt).
 * Feste Werte wie data-anb="google.com" sind unbedenklich und werden nicht angefasst.
 * --------------------------------------------------------------------------- */
console.log('\n== 5. esc() auf allen Datenattributen ==');
const attrRe = /data-[a-z][a-z0-9-]*="\s*'\s*\+([\s\S]{0,14})/g;
let m, roh = [], zahl = 0;
while ((m = attrRe.exec(code)) !== null) { zahl++; if (m[1].indexOf('esc(') === -1) roh.push(m[0].replace(/\s+/g, ' ')); }
ok('es gibt interpolierte data-Attribute', zahl >= 4, zahl + ' gefunden');
ok('JEDES davon geht durch esc() — auch data-k und data-sid', roh.length === 0, roh.join(' | '));
ok('data-k wird escaped', /data-k="'\+esc\(/.test(code.replace(/\s+/g, '')));
ok('data-sid wird escaped', /data-sid="'\+esc\(/.test(code.replace(/\s+/g, '')));

/* ---------------------------------------------------------------------------
 * 6. DIE RUECKSETZLISTE BEIM SAALWECHSEL IST VOLLSTAENDIG (Befund B2-1)
 *
 * Vier Namen muessen in der Ruecksetzung vorkommen. Zwei davon — __liveSig und __liveAlarmSig —
 * liegen in der IIFE des Motor-Blocks und sind von diesem Block aus baulich NICHT setzbar; der
 * Umbau darf ausschliesslich den letzten script-Block aendern. Sie stehen deshalb dort mit
 * Begruendung und mit dem, was an ihrer Stelle wirklich passiert: der teure Vollaufbau wird ueber
 * die exportierten Zeichenfunktionen ERZWUNGEN. Genau dieses Erzwingen wird hier mitgeprueft —
 * ohne es waere die Begruendung eine Behauptung.
 * --------------------------------------------------------------------------- */
console.log('\n== 6. Saalwechsel setzt zurueck ==');
const rIdx = block.indexOf('RUECKSETZEN BEIM SAALWECHSEL');
const rEnd = block.indexOf('function applySelected');
const ruecksetz = (rIdx >= 0 && rEnd > rIdx) ? block.slice(rIdx, rEnd) : '';
ok('der Ruecksetz-Abschnitt ist vorhanden', ruecksetz.length > 400, ruecksetz.length + ' Zeichen');
['istVals', 'dev.mirror', '__liveSig', '__liveAlarmSig', 'kurvenSigGezeigt', '__setRealWave'].forEach(function (n) {
  ok('Ruecksetzliste nennt ' + n, ruecksetz.indexOf(n) >= 0);
});
ok('istVals wird feldweise auf null gesetzt (nicht auf 0 — 0 ist ein MESSWERT)',
  /st\.istVals\[k\]\s*=\s*null/.test(code));
ok('state.dev.mirror wird geleert', /st\.dev\.mirror\s*=\s*\{\}/.test(code));
ok('der Vollaufbau wird erzwungen, weil __liveSig hier nicht loeschbar ist',
  /function\s+saalNeuZeichnenErzwingen/.test(code) && /renderMonValues/.test(code));
ok('zurueckgesetzt wird VOR applyLive (im selben Durchlauf wie apply)',
  /saalRuecksetzen\s*\([^)]*\)\s*;[\s\S]{0,200}__anaesLive\.apply/.test(code));
/*
 * GEGENPRUEFUNG 31.07.2026, im Browser nachgestellt: das blosse Leeren auf null war ein ZWEITER
 * Fehler, nicht die Loesung. Der Motor rechnet mit Zahlen — null < band[0] ist wahr, und
 * iv.nibp||0 macht aus null die Zahl 0. Fuer ein gesundes Tier in einem Saal ohne Manschette und
 * ohne Temperatursonde standen danach DREI erfundene Notfallbefunde samt Wirkstoffdosis auf dem
 * Schirm ("MAP 0 mmHg - Hypotension", "Apnoe", "Hypothermie"). Der Wechsel muss deshalb im MOTOR
 * ausgefuehrt werden (istInit mit den Baendern der neuen Tierart) — das Fern-Modul sieht istInit
 * gar nicht, es laeuft in einem anderen Gueltigkeitsbereich.
 */
ok('der Wechsel bekommt den NEUEN Patienten uebergeben (Tierart/Gewicht vor istInit)',
  /saalRuecksetzen\s*\(\s*pats\s*\[\s*sel\s*\]\s*\)/.test(code));
ok('und wird im Motor ausgefuehrt, nicht im Fern-Modul nachgebaut',
  /__anaesLive[\s\S]{0,80}neuerPatient/.test(code));
ok('der Motor stellt neuerPatient ueberhaupt bereit (sonst greift nur der Rueckfall)',
  /neuerPatient\s*:\s*neuerPatient/.test(html));
ok('neuerPatient setzt die Kanaele ueber istInit, nicht auf null',
  /function\s+neuerPatient[\s\S]{0,700}istInit\s*\(\s*\)/.test(html));
/* Die drei Felder, die applyLive nur BEDINGT zuweist und die sonst aus dem vorigen Saal
 * stehenblieben: Gewicht (jede Dosis), Tierart (alle Normbereiche) und EKG-Rhythmus (ein 'flat'
 * von dort ergibt "Asystolie - CPR - Verdampfer AUF NULL" fuer ein gesundes Tier). */
['state.sp', 'state.wt', 'state.rhythm'].forEach(function (f) {
  ok('neuerPatient setzt ' + f + ' neu',
    new RegExp('function\\s+neuerPatient[\\s\\S]{0,700}' + f.replace('.', '\\.') + '\\s*=').test(html));
});
ok('und setzt den Verdampfer auf die Vorgabe zurueck (sonst gilt der Wert des vorigen Saals)',
  /function\s+neuerPatient[\s\S]{0,700}dv\.iso\s*=\s*2/.test(html));
/*
 * GEGENPRUEFUNG 31.07.2026 — die drei Pruefungen darunter kamen aus einer Mutationsprobe.
 * Gemessen wurde: das Entfernen von "wechselFrisch = true;" aus waehleSaal() stellt Befund B2-1
 * VOLLSTAENDIG wieder her (kein Saalwechsel setzt mehr zurueck), und der Test blieb mit 71 von 71
 * gruen. Dasselbe galt fuer 'temp' aus IST_FELDER streichen und fuer laufzeitSid[selSaal] statt
 * laufzeitSid[sid]. Die vorhandenen Pruefungen fragen nur, OB der Ruecksetz-Code dasteht — nicht,
 * ob er je ausgeloest wird und ob er alle acht Kanaele trifft. Genau das wird hier nachgeholt.
 */
ok('waehleSaal SCHALTET das Ruecksetzen ueberhaupt erst scharf (wechselFrisch)',
  /function\s+waehleSaal[\s\S]{0,900}wechselFrisch\s*=\s*true\s*;/.test(code));
/* Jedes Loeschen der Merke MUSS unmittelbar das Ruecksetzen ausloesen — sonst verfaellt der
 * Auftrag still und der Saalwechsel setzt nicht zurueck. Die Erstbelegung in der
 * Variablenzeile (var wechselFrisch = false) zaehlt dabei nicht mit. */
const loeschtMerke = (code.replace(/var\s+wechselFrisch\s*=\s*false\s*;/, '')
  .match(/wechselFrisch\s*=\s*false/g) || []).length;
const loeschtUndSetztZurueck = (code.match(/wechselFrisch\s*=\s*false\s*;\s*saalRuecksetzen\s*\([^)]*\)/g) || []).length;
ok('und die Merke wird nur beim Ausfuehren des Ruecksetzens wieder geloescht',
  loeschtMerke > 0 && loeschtMerke === loeschtUndSetztZurueck,
  loeschtUndSetztZurueck + ' von ' + loeschtMerke);
/* Die Liste MUSS alle acht Kanaele nennen. Fehlt einer, steht sein Wert aus dem VORIGEN Saal
 * unter dem Namen des Tiers im neuen — genau der toedliche Befund B2-1. */
['hr', 'spo2', 'etco2', 'rr', 'temp', 'sys', 'dia', 'nibp'].forEach(function (f) {
  ok('IST_FELDER nennt ' + f, new RegExp("IST_FELDER\\s*=\\s*\\[[^\\]]*'" + f + "'").test(code));
});
ok('der Wechsel fragt zurueck', /window\.confirm\s*\(/.test(code));
ok('und die Rueckfrage nennt BEIDE Tiere',
  /function\s+waehleSaal[\s\S]{0,900}tierText\s*\(\s*selSaal[\s\S]{0,300}tierText\s*\(\s*sid/.test(code));

/* ---------------------------------------------------------------------------
 * 7. TAFEL: FESTE REIHENFOLGE, KEIN SPRUNG UEBER SAALGRENZEN
 * --------------------------------------------------------------------------- */
console.log('\n== 7. Tafel und Saalwahl ==');
ok('die Saele stehen in einem eigenen Zustand', /var\s+saele\s*=/.test(code) && /var\s+selSaal/.test(code) && /var\s+patientsSaal/.test(code));
const sortRe = /function\s+saalListe\s*\(\s*\)\s*\{[\s\S]*?\n\}/;
const sortFn = (code.match(sortRe) || [''])[0];
ok('saalListe() sortiert nach SAALNAME', sortFn.indexOf('saalName(') >= 0, sortFn.slice(0, 90));
ok('und NIE nach Prioritaet', sortFn.indexOf('pri') === -1, sortFn.slice(0, 200));
ok('die Tafel kommt aus dem EINEN Abonnement auf tafel', /['"]\/tafel['"]|\+\s*['"]\/tafel['"]/.test(code));
ok('die pri-Automatik waehlt nur INNERHALB des gewaehlten Saals',
  (code.match(/\.pri\s*\|\|\s*0\)\s*>/g) || []).length === 1 &&
  /function\s+aboPatienten[\s\S]{0,1600}pats\[best\]\.pri/.test(code));
ok('ein ausgefallener gefuehrter Saal wird NICHT automatisch gewechselt',
  /function\s+waehleSaalWennKeiner\s*\(\s*\)\s*\{\s*if\s*\(\s*selSaal\s*\)\s*return\s*;/.test(code));
ok('ein Alarm im Nachbarsaal bietet nur an, ihn zu oeffnen', /data-oeffne/.test(code) && /alarm/.test(code));
ok('Deckel sichtbar statt stiller Verwerfung (N17)',
  /DECKEL_SAELE/.test(code) && block.indexOf('Deckel erreicht') >= 0);
/* Mutationsprobe 31.07.2026: slice(0, DECKEL_SAELE) durch slice(0) zu ersetzen liess den Test
 * gruen — die Konstante allein beweist nichts, sie muss auch angewandt werden. */
ok('und die Deckel werden wirklich angewandt',
  /\.slice\(\s*0\s*,\s*DECKEL_SAELE\s*\)/.test(code) && /\.slice\(\s*0\s*,\s*DECKEL_KACHELN\s*\)/.test(code));

/* ---------------------------------------------------------------------------
 * 8. ZWEI ALTERSANZEIGEN MIT VERSCHIEDENEN TEXTEN UND DEN RICHTIGEN SCHWELLEN
 * --------------------------------------------------------------------------- */
console.log('\n== 8. Alter ==');
ok('Schwelle 12 s vorhanden', /SCHWELLE_GELB\s*=\s*12000/.test(code));
ok('Schwelle 60 s vorhanden', /SCHWELLE_TOT\s*=\s*60000/.test(code));
ok('die Uebertragung wird aus jetzt - sv gerechnet', /jetztServer\s*\(\s*\)\s*-\s*sv/.test(code));
ok('jetzt enthaelt den Uhrversatz vom Server', /Date\.now\s*\(\s*\)\s*\+\s*uhrVersatz/.test(code) && /serverTimeOffset/.test(code));
ok('die Geraetedaten werden aus altMs + (jetzt - sv) gerechnet', /altMs\s*\+\s*d\b/.test(code));
ok('negatives Alter wird NIE auf 0 geklemmt, sondern unbekannt',
  /if\s*\(\s*d\s*<\s*0\s*\)\s*return\s+null\s*;/.test(code) && block.indexOf('Alter unbekannt') >= 0);
ok('bei > 60 s werden die Zahlen ERSETZT', block.indexOf('Stand vor ') >= 0);
ok('und der Saal wird als offline benannt', block.indexOf('offline seit ') >= 0);
ok('die beiden Alterstexte sind VERSCHIEDEN',
  block.indexOf('bertragung') >= 0 && block.indexOf('tedaten') >= 0);

/* ---------------------------------------------------------------------------
 * 9. PROTOKOLL, DRUCK, VERLEGUNG, PSEUDO-SAAL, SAALNAME IM RECHNENDEN BEREICH
 * --------------------------------------------------------------------------- */
console.log('\n== 9. Protokoll, Druck und Altbestand ==');
ok('der Protokollschluessel traegt Saal UND Patient', /return\s+String\(sid\)\s*\+\s*'\|'\s*\+\s*String\(pid\)/.test(code));
ok('protAbos speichert die Abmeldefunktion, nicht "true"', !/protAbos\[[^\]]+\]\s*=\s*true/.test(code));
ok('protAbos wird beim Verschwinden abgebaut', /verschwundeneAufraeumen[\s\S]{0,700}abbestellen\(protAbos\[/.test(code));
ok('der Druckkopf nennt Saalname und sid-Kurzform', /function\s+druckKopf[\s\S]{0,200}saalName\(sid\)[\s\S]{0,60}sid6\(/.test(code));
ok('die alte harte Zeile meta.station im Druckkopf ist weg', !/meta\.station\s*\|\|\s*'VetStation'/.test(code));
ok('Verlegung wird an gleicher, NICHT LEERER Kennung erkannt',
  /function\s+verlegungSaele[\s\S]{0,700}!==\s*''/.test(code));
ok('der gemeinsame Ausdruck hat eine fuehrende Spalte Saal', /mitSaal\s*\?\s*'<th class="l">Saal<\/th>'/.test(code));
ok('und die Kopfzeile sagt, dass es zwei Saele sind', block.indexOf('zusammengestellt') >= 0);
ok('zusammengefuehrt wird nur das Papier — kein Knoten wird geschrieben',
  !/\bset\s*\(/.test(code) && !/\bupdate\s*\(\s*D\.ref/.test(code) && !/\bpush\s*\(\s*D\.ref/.test(code));
ok('die alte flache Ebene bleibt als Pseudo-Saal sichtbar', /FLACH\s*=\s*'__flach'/.test(code));
ok('Saalname steht in den rechnenden Bereichen', /RECHNENDE_ANSICHTEN/.test(code) &&
  /'notfall'/.test(code) && /'geraet'/.test(code) && /'medis'/.test(code));
ok('und das Band traegt Saal, Tierart und Gewicht', /renderSaalBand[\s\S]{0,600}tierText\s*\(/.test(code));

/* ---------------------------------------------------------------------------
 * 10. ZWEI-SAAL-DEMO (N15) — ohne sie ist Schritt 19 nicht von Hand pruefbar
 * --------------------------------------------------------------------------- */
console.log('\n== 10. Demobetrieb mit zwei Saelen ==');
ok('?livedemo=2 schaltet den zweiten Saal frei', /demo\s*===\s*'2'/.test(code));
ok('es sind zwei Demo-Saele hinterlegt', (code.match(/sid:'st[0-9a-f]{12}'/g) || []).length === 2);
ok('BEIDE Demo-Patienten liegen unter demselben patientKey sw_hund_22',
  (code.match(/sw_hund_22/g) || []).length >= 3);
ok('genau ein Demo-Saal hat KEINE Temperatursonde',
  (code.match(/temp:false/g) || []).length === 1 && (code.match(/temp:true/g) || []).length === 1);
ok('ein Schalter haelt GENAU EINEN Saal an', /demoAus\[/.test(code) && /data-demo-stopp/.test(code));
ok('der angehaltene Saal friert sein sv ein (deshalb altert nur SEINE Karte)',
  /if\s*\(\s*demoAus\[[^\]]+\]\s*\)\s*return\s*;/.test(code));

/* ---------------------------------------------------------------------------
 * 10b. ALLE GERAETE DES KONTOS IM SELBEN DASHBOARD (Forderung 01.08.2026)
 *
 * WAS HIER SCHIEFGING: Die Station schreibt seit 1.1.0 je Saal eine Zeile pro Geraet nach
 * tafel/<sid>/geraete — Modell, Rolle, Status, Adresse, Port, Uebertragungsweg. In der Web-App
 * kam dieser Zweig an und wurde beim Umbau des Saalobjekts STILLSCHWEIGEND WEGGELASSEN:
 *     neu[sid] = { meta: e.meta || {}, uebersicht: e.uebersicht || {} };
 * Die Geraete der anderen Saele waren also im Konto vorhanden und auf keinem Bildschirm zu sehen.
 * Nichts hat es gemeldet, weil nichts fehlte — es wurde nur nicht gelesen.
 * Genau diese Sorte stiller Verlust wird hier festgenagelt.
 * --------------------------------------------------------------------------- */
console.log('\n== 10b. Geraete aller Saele ==');
/* Nicht [^}]* verwenden: die Zuweisung enthaelt selbst geschweifte Klammern (e.meta || {}),
 * und der Ausdruck bricht dann VOR dem gesuchten Feld ab — er meldete "fehlt", obwohl es da war. */
ok('das Tafel-Abonnement UEBERNIMMT den Geraetezweig',
  /neu\[sid\]\s*=\s*\{[\s\S]{0,220}?geraete\s*:/.test(code),
  (code.match(/neu\[sid\]\s*=\s*\{[\s\S]{0,220}?;/) || ['(nicht gefunden)'])[0]);
ok('die Saalkarte baut eine Geraeteliste', /s-geraete/.test(code) && /Geräte in diesem Saal/.test(code));
ok('sie liest aus saele[sid].geraete (nicht aus einer zweiten Quelle)',
  /saele\[sid\]\s*&&\s*saele\[sid\]\.geraete/.test(code));
ok('je Geraet werden Modell UND Zustand gezeigt',
  /d\.model/.test(code) && /d\.status/.test(code));
ok('Adresse und Uebertragungsweg stehen dabei', /d\.ip/.test(code) && /d\.transport/.test(code));
/* Ein Deckel ist noetig (die Tafel laesst bis zu 16 Geraete je Saal zu), aber er muss SICHTBAR
 * sein — stilles Abschneiden waere hier dieselbe Luege wie das Weglassen oben. */
ok('ein Deckel schneidet nicht still ab, sondern sagt es',
  /weitere Geräte werden nicht angezeigt/.test(code));
ok('die Geraeteliste haengt in der Saalkarte (nicht nur in der Vollansicht)',
  /\+\s*deckelZeile\s*\+\s*geraeteZeilen/.test(code));
/* Und die Demo muss den Zweig mitliefern — sonst laesst sich die Anzeige ohne zwei echte
 * Praxis-PCs gar nicht pruefen, und genau daran ist es beim ersten Mal vorbeigelaufen. */
ok('die Demo liefert Geraetezeilen je Saal', /saele\[d\.sid\]\.geraete\s*=/.test(code));

/* Dieselbe Sorte stiller Verlust bei den MESSWERTEN: die Kachel traegt sys, dia, rh und al,
 * gezeigt wurden nur sechs Felder. Der Blutdruck ist der Wert, wegen dem man ueberhaupt auf eine
 * fremde Saalkarte sieht (ein Mitteldruck allein sagt nicht, ob 60/40 oder 120/20 dahintersteht),
 * und die Alarmzahl ist der Grund, warum man ueberhaupt hinsieht. */
ok('der Blutdruck (sys/dia) steht auf der Saalkarte', /\['RR'\s*,\s*rr\]/.test(code) && /e\.sys/.test(code) && /e\.dia/.test(code));
ok('der EKG-Rhythmus steht dabei', /e\.rh/.test(code) && /Rhythmus/.test(code));
ok('die Alarmzahl des fremden Saals wird angezeigt', /s-alarm/.test(code) && /e\.al\s*>\s*0/.test(code));
/* Nur die ZAHL, nicht der Text: die Alarmtexte stecken im vollen Strom des gefuehrten Saals, und
 * der wird bewusst nicht fuer alle Saele geladen. Wer hier Texte zeigte, muesste sie laden — und
 * damit faellt die ganze Bandbreitenrechnung. */
ok('und zwar als Anzahl, nicht als Text (sonst muesste der volle Strom aller Saele geladen werden)',
  /Alarm'\+\(e\.al>1\?'e':''\)/.test(code.replace(/\s+/g, '')) || /'\s*Alarm'/.test(code));

/* ---------------------------------------------------------------------------
 * 11. DER BLOCK IST GUELTIGES JAVASCRIPT
 * new Function faengt genau die Klasse Fehler, die sonst erst im Browser des Tierarztes auffiele —
 * dort aber nicht als Fehlermeldung, sondern als leere Fern-Ansicht.
 * --------------------------------------------------------------------------- */
/* ==========================================================================================
 * 10b. KEIN BUCHWISSEN IM OEFFENTLICHEN KANAL (14.08.2026, Entscheidung des Nutzers)
 *
 * canis-vetpharm/ liegt oeffentlich auf GitHub Pages. ekg-literatur.js ist ein Auszug aus den
 * Fachbuechern der Praxis; deren Vorlagen sind ausdruecklich nur fuer den persoenlichen
 * Gebrauch lizenziert. Seit dem 14.08.2026 schreibt tools/web-app-bauen.js dort nur noch
 * einen Platzhalter hin.
 *
 * DIESE PRUEFUNG IST DER EIGENTLICHE RIEGEL. Ein Kommentar in der Kopierliste haelt nichts:
 * es genuegt, dass jemand die Zeile "der Vollstaendigkeit halber" wieder eintraegt - genau das
 * ist in diesem Projekt bei breed-genetics.js schon in die andere Richtung passiert. Sie
 * fragt deshalb die AUSGELIEFERTE Datei, nicht die Absicht: sie muss klein sein und darf
 * weder Buchtitel noch Seitenangaben noch die Eintragsliste enthalten.
 * ========================================================================================== */
console.log('\n== 10b. Buchwissen bleibt an der Station ==');
{
  /* Beide Dateien, dieselbe Lage: Auswertungen lizenzierter Fachbuecher, die nicht in den
   * oeffentlichen Kanal gehoeren. Was hier geprueft wird, ist die AUSGELIEFERTE Datei -
   * nicht die Absicht in der Kopierliste. Es genuegt, dass jemand eine Zeile "der
   * Vollstaendigkeit halber" wieder eintraegt; bei breed-genetics.js ist genau das in die
   * andere Richtung schon passiert. */
  const LOKAL = [
    { datei: 'ekg-literatur.js', war: 515, verbot: ['STELLEN', '"werk"', 'PDF-Seite'], merkmal: 'literaturNurLokal' },
    { datei: 'kardio-regeln.js', war: 1088, verbot: ['REGELN', '"abgleich"', '"kapitel"'], merkmal: 'kardioNurLokal' },
  ];
  LOKAL.forEach((L) => {
    const p = path.resolve(path.dirname(WEBAPP), '..', 'shared', L.datei);
    if (!fs.existsSync(p)) {
      ok(L.datei + ' im Kanal ist ein Platzhalter (oder fehlt ganz)', true, 'Datei nicht vorhanden');
      return;
    }
    const t = fs.readFileSync(p, 'utf8');
    const kb = Buffer.byteLength(t) / 1024;
    ok('die ausgelieferte ' + L.datei + ' ist klein (< 4 KB, war ' + L.war + ' KB)', kb < 4, kb.toFixed(2) + ' KB');
    const drin = L.verbot.filter((v) => t.indexOf(v) >= 0);
    ok(L.datei + ' traegt keine Buchdaten', drin.length === 0, drin.join(', ') || 'sauber');
    ok(L.datei + ' setzt das Merkmal fuer die Oberflaeche', t.indexOf(L.merkmal) >= 0);
  });
  /* Gegenprobe: die Oberflaeche muss den Unterschied auch AUSSPRECHEN. Ohne diesen Satz
   * meldet die Fern-App "nicht geladen" - und der Tierarzt sucht einen Fehler, den es nicht
   * gibt. Ein Merkmal, das niemand liest, ist so gut wie keins. */
  ok('die Web-App erklaert beide Faelle mit "nur an der Station"',
    html.indexOf('literaturNurLokal') >= 0 && html.indexOf('kardioNurLokal') >= 0 &&
    (html.match(/nur an der Station/g) || []).length >= 2);
}

console.log('\n== 11. Syntax ==');
let syntaxFehler = '';
try { new Function(block); } catch (e) { syntaxFehler = (e && e.message) || String(e); }
ok('der script-Block laesst sich uebersetzen (new Function)', syntaxFehler === '', syntaxFehler);

/* Gegenprobe zum Kommentar-Entferner: er darf keinen Code fressen, sonst waere jedes Verbot
 * oben nur scheinbar erfuellt. */
function zaehleFn(t) { return (String(t).match(/function\s/g) || []).length; }
ok('ohneKommentare() verliert keine einzige Funktion',
  zaehleFn(block) > 0 && zaehleFn(block) === zaehleFn(code),
  zaehleFn(block) + ' vs ' + zaehleFn(code));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
