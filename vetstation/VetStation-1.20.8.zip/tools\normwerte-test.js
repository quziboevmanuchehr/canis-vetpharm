'use strict';
/*
 * normwerte-test.js — Normwerte nach Tierart, Koerpergroesse und (nur wo belegt) Rasse.
 *
 * WORUM ES GEHT (Recherche 09.08.2026):
 * Fuer die ZEITEN (P, PQ, QRS, QT) gibt es KEINE rasseabhaengigen Normwerte, sondern art-
 * und KOERPERGROESSENabhaengige. Die kanonische Tabelle (Tilley) qualifiziert nach Groesse,
 * nie nach Rasseidentitaet. Rassewerte existieren veroeffentlicht nur fuer eine Handvoll
 * Rassen; fuer die uebrigen der 747 im Katalog waeren sie erfunden.
 *
 * ZWEI FEHLERKLASSEN, die dieser Test festhaelt:
 *
 *   1. ZU WENIG GEMELDET BEI KLEINEN HUNDEN. Bis zum 09.08.2026 galten fuer JEDEN Hund die
 *      Grenzen der GROSSEN Rassen (QRS bis 60 ms, R bis 3,0 mV). Ein 4-kg-Hund mit einem
 *      58-ms-Kammerkomplex galt damit als normal - Tilley setzt die Grenze fuer kleine
 *      Rassen bei 50 ms.
 *
 *   2. FALSCHMELDUNG BEI GESUNDEN TIEREN BESTIMMTER RASSEN. 39 % gesunder Dobermaenner
 *      haben eine linksverschobene Achse (bis -45 Grad), 30 % gesunder Franzoesischer
 *      Bulldoggen ebenso (bis -18 Grad), 62 % gesunder American Staffordshire Terrier eine
 *      P-Dauer ueber 40 ms und 66 % eine QRS-Dauer ueber 60 ms. Ohne Ausnahme bekommen
 *      diese Tiere kein "unauffaellig" - und wer das oft genug sieht, glaubt der Anzeige
 *      nicht mehr.
 *
 * UND EINE GRENZE, die genauso wichtig ist: fuer die uebrigen Rassen darf NICHTS angepasst
 * werden. Ein Test, der nur die vier Ausnahmen prueft, wuerde uebersehen, wenn jemand
 * spaeter Werte fuer weitere Rassen erfindet.
 *
 * Start: node tools/normwerte-test.js
 */
const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');
function holeBlock(anfang, ende) {
  const a = src.indexOf(anfang);
  if (a < 0) throw new Error('nicht gefunden: ' + anfang);
  const b = src.indexOf(ende, a);
  return src.slice(a, b + ende.length);
}
/* EKGNORM, die Rasseausnahmen und die drei Funktionen in eine Sandkiste holen. */
const umgebung = new Function(
  holeBlock('var EKGNORM={', '\n};') + '\n' +
  holeBlock('var RASSE_AUSNAHMEN=[', '\n];') + '\n' +
  holeBlock('function normKopie(N){', '\n}') + '\n' +
  holeBlock('function normFuer(sp, wtKg, rasse, rasseId){', '\n  return out;\n}') + '\n' +
  'return { EKGNORM:EKGNORM, RASSE_AUSNAHMEN:RASSE_AUSNAHMEN, normFuer:normFuer };')();
const { EKGNORM, RASSE_AUSNAHMEN, normFuer } = umgebung;

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Normwerte nach Art, Groesse und Rasse\n');

/* ================================================================================
 * 1. KOERPERGROESSE BEIM HUND (Tilley)
 * ============================================================================== */
block('1. Koerpergroesse');
{
  const klein = normFuer('hund', 4, '');
  pruef('4 kg: QRS bis 50 ms', klein.qrs[1] === 50, String(klein.qrs[1]));
  pruef('4 kg: R bis 2,5 mV', klein.rAmp[1] === 2.5, String(klein.rAmp[1]));
  pruef('4 kg: die Anpassung wird benannt', /bis 20 kg/.test(klein.angepasst.join(' ')),
    klein.angepasst.join(' | '));

  const gross = normFuer('hund', 28, '');
  pruef('28 kg: QRS bis 60 ms', gross.qrs[1] === 60, String(gross.qrs[1]));
  pruef('28 kg: R bis 3,0 mV', gross.rAmp[1] === 3.0, String(gross.rAmp[1]));

  const riese = normFuer('hund', 55, '');
  pruef('55 kg: P-Dauer bis 50 ms (Riesenrasse)', riese.pDauer[1] === 50, String(riese.pDauer[1]));
  /* DIE GEFAEHRLICHSTE LUECKE der ersten Fassung: sie deckelte JEDEN grossen Hund bei 60 ms.
   * Eine Deutsche Dogge mit 62 ms QRS waere damit "verbreitert" gewesen - Verdacht auf
   * ventrikulaeren Ursprung oder Schenkelblock - und ist nach der Gegenquelle normal. */
  pruef('55 kg: QRS bis 65 ms (dritte Stufe)', riese.qrs[1] === 65, String(riese.qrs[1]));
  pruef('eine Dogge mit 62 ms gilt jetzt als normal', 62 <= riese.qrs[1]);
  pruef('mit der alten Zweistufen-Tabelle waere sie verbreitert gewesen', 62 > 60);

  /* Die Grenze selbst: 15 kg zaehlt zur grossen Klasse. */
  /* Die Schwelle ist 20 kg - die einzige BELEGTE Zahl. Die 15 kg der ersten Fassung waren
   * frei gewaehlt. */
  pruef('genau 20 kg zaehlt zur mittleren Klasse', normFuer('hund', 20, '').qrs[1] === 60);
  pruef('19,9 kg zaehlt zur kleinen Klasse', normFuer('hund', 19.9, '').qrs[1] === 50);
  pruef('genau 40 kg zaehlt als Riesenrasse', normFuer('hund', 40, '').qrs[1] === 65);
  pruef('39,9 kg noch nicht', normFuer('hund', 39.9, '').qrs[1] === 60);
}

/* OHNE GEWICHT WIRD NICHT GERATEN — aber es wird gesagt. */
block('1b. fehlendes Gewicht');
[undefined, null, '', '   ', 'abc', 0, -3].forEach((w) => {
  const n = normFuer('hund', w, '');
  pruef('Gewicht "' + String(w) + '": es bleibt bei den weiteren Grenzen', n.qrs[1] === 60);
  pruef('Gewicht "' + String(w) + '": und das steht dabei',
    /kein Gewicht/.test(n.angepasst.join(' ')));
});

/* Bei Katze und Pferd gibt es KEINE belegte Gewichtsstaffelung - dort darf nichts passieren. */
block('1c. keine erfundene Staffelung bei anderen Arten');
['katze', 'pferd'].forEach((sp) => {
  const a = normFuer(sp, 2, ''), b = normFuer(sp, 9, ''), o = EKGNORM[sp];
  pruef(sp + ': QRS-Grenze haengt NICHT am Gewicht',
    a.qrs[1] === o.qrs[1] && b.qrs[1] === o.qrs[1]);
  pruef(sp + ': R-Amplitude haengt NICHT am Gewicht',
    JSON.stringify(a.rAmp) === JSON.stringify(o.rAmp));
  pruef(sp + ': keine Groessenanpassung gemeldet',
    !/Rasse \(/.test(a.angepasst.join(' ')) && !/kg\)/.test(a.angepasst.join(' ')));
});

/* ================================================================================
 * 2. DIE SECHS BELEGTEN RASSEAUSNAHMEN
 *
 * WAREN VIER, SIND SEIT DEM 15.08.2026 SECHS. Die feste Zahl steht hier mit Absicht: sie
 * zwingt jeden, der eine Ausnahme ergaenzt, sie auch zu begruenden - eine Rassegrenze ohne
 * Quelle waere eine erfundene Norm. Neu:
 *   brachy-pq    Mops, Bulldogge, Boston Terrier: PQ bis 150 ms (Santilli 2018, S.70).
 *                Beendet einen Fehlalarm bei genau den Rassen, die am haeufigsten zur
 *                Narkose kommen - bisher meldete die Station dort ab 130 ms AV-Block I.
 *   greyhound-p  OHNE Zahlenfeld, und das ist der Punkt: Santilli S.102 nennt P-Amplituden
 *                ueber 0,4 mV beim Greyhound als normal, aber KEINE Obergrenze. Der Eintrag
 *                haengt deshalb nur den Hinweis an und verschiebt keine Grenze.
 * ============================================================================== */
block('2. Rasseausnahmen (nur wo veroeffentlicht)');
pruef('es sind genau sechs', RASSE_AUSNAHMEN.length === 6, String(RASSE_AUSNAHMEN.length));
pruef('jede nennt Grund UND Quelle',
  RASSE_AUSNAHMEN.every((a) => a.grund && a.grund.length > 20 && a.quelle && a.quelle.length > 15));

{
  /* DER FALL, DER HEUTE FALSCH ANSCHLAEGT: gesunder Dobermann mit -30 Grad. */
  const d = normFuer('hund', 35, 'Dobermann');
  pruef('Dobermann: Achsenband beginnt bei -45 Grad', d.achse[0] === -45, JSON.stringify(d.achse));
  pruef('ein gesunder Dobermann mit -30 Grad liegt jetzt IM Band',
    -30 >= d.achse[0] && -30 <= d.achse[1]);
  pruef('mit der Artgrenze (+40 Grad) laege er ausserhalb — das war der Fehler',
    -30 < EKGNORM.hund.achse[0]);
  pruef('die Ausnahme wird benannt', d.rasseAusnahme && d.rasseAusnahme.id === 'dobermann');
  pruef('die Zahl aus der Studie steht in der Quelle', /39 %/.test(d.rasseAusnahme.quelle));
  /* Die Groessenstaffelung gilt trotzdem weiter. */
  pruef('Dobermann 35 kg: QRS weiterhin nach Groesse (60 ms)', d.qrs[1] === 60);
}
{
  const f = normFuer('hund', 12, 'Französische Bulldogge');
  pruef('Französische Bulldogge: Achse ab -20 Grad', f.achse[0] === -20, JSON.stringify(f.achse));
  pruef('-18 Grad liegt im Band', -18 >= f.achse[0]);
  pruef('12 kg: QRS trotzdem nach kleiner Rasse (50 ms)', f.qrs[1] === 50);
  pruef('auch die englische Schreibweise trifft', normFuer('hund', 12, 'French Bulldog').achse[0] === -20);
}
{
  const a = normFuer('hund', 25, 'American Staffordshire Terrier');
  pruef('AST: P-Dauer bis 55 ms', a.pDauer[1] === 55, String(a.pDauer[1]));
  pruef('AST: QRS bis 75 ms', a.qrs[1] === 75, String(a.qrs[1]));
  pruef('eine P-Dauer von 48 ms ist beim AST jetzt normal', 48 <= a.pDauer[1]);
  pruef('mit der Artgrenze (40 ms) waere sie "P mitrale" — das war der Fehler',
    48 > EKGNORM.hund.pDauer[1]);
  pruef('die Kurzform greift ebenfalls', normFuer('hund', 25, 'AmStaff').qrs[1] === 75);
}
{
  const w = normFuer('hund', 11, 'Whippet');
  pruef('Whippet: R bis 4,0 mV', w.rAmp[1] === 4.0, String(w.rAmp[1]));
  pruef('3,4 mV ist beim Whippet normal', 3.4 <= w.rAmp[1]);
}
/* ================================================================================
 * TREFFER UEBER DIE RASSE-KENNUNG (09.08.2026)
 *
 * Die Ausnahmen trafen bisher ueber ein Muster auf den RASSENAMEN. Das trifft zu viel und
 * zu wenig zugleich. Seit das Patientenblatt eine Kennung aus dem Rassekatalog liefert,
 * entscheidet sie - das Muster bleibt nur fuer eine getippte, nicht aufloesbare Rasse.
 * ============================================================================== */
{
  const w = normFuer('hund', 11, 'Whippet', 'whippet');
  pruef('ueber die Kennung: Whippet bekommt seine Ausnahme', w.rAmp[1] === 4.0, String(w.rAmp[1]));
  pruef('und sie wird als Rasseausnahme ausgewiesen', w.rasseAusnahme && w.rasseAusnahme.id === 'whippet');

  /* DER LANGHAAR-WHIPPET IST EINE ANDERE RASSE. Die Referenzintervalle (n = 105) wurden am
   * Whippet erhoben; sie auf ihn zu uebertragen waere eine Zahl ohne Messung. Das alte
   * Muster /whippet/i traf ihn mit. */
  const lang = normFuer('hund', 11, 'Langhaar-Whippet', 'whippet-lang');
  pruef('der Langhaar-Whippet bekommt sie NICHT', lang.rAmp[1] !== 4.0, String(lang.rAmp[1]));
  pruef('und wird nicht als Rasseausnahme gefuehrt', !lang.rasseAusnahme, JSON.stringify(lang.rasseAusnahme));

  const d = normFuer('hund', 35, 'Dobermann', 'dobermann');
  pruef('ueber die Kennung: Dobermann bekommt sein Achsenband', d.achse[0] === -45, String(d.achse));
  const zwerg = normFuer('hund', 5, 'Zwergpinscher', 'zwergpinscher');
  pruef('der Zwergpinscher bekommt es nicht', !zwerg.rasseAusnahme, JSON.stringify(zwerg.rasseAusnahme));

  /* Der Rueckfall muss weiter greifen: ohne Kennung entscheidet der Name. */
  pruef('ohne Kennung entscheidet weiter der Name',
    normFuer('hund', 35, 'Dobermann Pinscher').achse[0] === -45);
  pruef('und eine unbekannte Rasse bekommt keine Ausnahme',
    !normFuer('hund', 20, 'Mischling').rasseAusnahme);
}
/* ================================================================================
 * EINE HUNDEAUSNAHME DARF NIE AUF EINE ANDERE ART WIRKEN
 *
 * Schwerster Einzelbefund der Gegenpruefung vom 09.08.2026. Die Ausnahmen wurden ohne
 * jede Artpruefung angewandt; gemessen wurde:
 *     normFuer('katze', 4, 'Amstaff', '')  ->  qrs [null,75] statt [null,40]
 * Ein Kammerkomplex von 60 ms ist bei der Katze eindeutig verbreitert - mit der Hundegrenze
 * lief er durch die Regel qrs-breit hindurch und wurde GAR NICHT gemeldet. Auf dem Schirm
 * stand dabei "Bewertet nach: Katze - Rasse beruecksichtigt: Beim American Staffordshire
 * Terrier ...". Das ist ein weggeredeter Befund: die schlimmere der beiden Fehlerrichtungen.
 *
 * Erreichbar war es ueber den Freitext - VETBREED.search('Amstaff','katze') ist leer, die
 * Kennung bleibt deshalb leer, und genau dann greift der Musterzweig.
 * ============================================================================== */
{
  const katzeNorm = normFuer('katze', 4, '', '');
  ['Amstaff', 'American Staffordshire Terrier', 'Dobermann', 'Whippet', 'Französische Bulldogge']
    .forEach((r) => {
      const k = normFuer('katze', 4, r, '');
      pruef('Katze mit "' + r + '" behält die Katzengrenzen (QRS)',
        String(k.qrs) === String(katzeNorm.qrs), String(k.qrs) + ' statt ' + String(katzeNorm.qrs));
      pruef('Katze mit "' + r + '" bekommt KEINE Rasseausnahme',
        !k.rasseAusnahme, JSON.stringify(k.rasseAusnahme));
    });
  /* Auch nicht ueber die Kennung - eine Kennung kann durch einen Artwechsel stehenbleiben. */
  pruef('auch nicht über die Rassekennung',
    !normFuer('katze', 4, 'Dobermann', 'dobermann').rasseAusnahme);
  pruef('das Achsenband der Katze bleibt unangetastet',
    String(normFuer('katze', 4, 'Dobermann', 'dobermann').achse) === String(katzeNorm.achse));
  /* Gegenprobe: beim HUND greift dieselbe Ausnahme weiterhin. Ohne sie prueft der Test nichts. */
  pruef('beim Hund greift die Ausnahme unverändert',
    normFuer('hund', 30, 'Dobermann', 'dobermann').achse[0] === -45);
  pruef('und jeder Eintrag nennt seine Art', RASSE_AUSNAHMEN.every((a) => a.arten && a.arten.length),
    RASSE_AUSNAHMEN.filter((a) => !a.arten).map((a) => a.id).join(','));
  pruef('bei einem 11-kg-Hund ohne Rasse waere das eine Meldung',
    3.4 > normFuer('hund', 11, '').rAmp[1]);
}

/* ================================================================================
 * 3. DIE WICHTIGSTE GRENZE: ALLE ANDEREN RASSEN BEKOMMEN NICHTS
 * ============================================================================== */
block('3. keine erfundenen Rassewerte');
/* DER MOPS STAND BIS ZUM 15.08.2026 IN DIESER LISTE. Er ist herausgenommen, weil er seit
 * diesem Tag eine BELEGTE Ausnahme hat (brachy-pq, Santilli 2018 S.70) - nicht, weil die
 * Pruefung stoerte. Der Unterschied ist wichtig genug, um ihn hinzuschreiben: wer hier eine
 * Rasse streicht, muss ihre Quelle nennen koennen. Die Gegenpruefung dazu steht unten. */
['Labrador Retriever', 'Deutscher Schäferhund', 'Chihuahua', 'Beagle',
 'Golden Retriever', 'Boxer', 'Cavalier King Charles Spaniel', 'Mischling', 'Rottweiler']
  .forEach((r) => {
    const wt = 20;
    const mit = normFuer('hund', wt, r), ohne = normFuer('hund', wt, '');
    pruef(r + ': keine Rasseausnahme', mit.rasseAusnahme === null);
    pruef(r + ': Werte gleich wie ohne Rasseangabe',
      JSON.stringify(mit.achse) === JSON.stringify(ohne.achse) &&
      JSON.stringify(mit.qrs) === JSON.stringify(ohne.qrs) &&
      JSON.stringify(mit.pDauer) === JSON.stringify(ohne.pDauer) &&
      JSON.stringify(mit.rAmp) === JSON.stringify(ohne.rAmp));
  });

/* Und die Gegenrichtung fuer die zwei neuen Ausnahmen: sie muessen greifen, und sie duerfen
 * NUR das verschieben, wofuer es einen Beleg gibt. */
{
  const mops = normFuer('hund', 12, '', 'mops');
  pruef('Mops: die brachyzephale PQ-Ausnahme greift',
    mops.rasseAusnahme && mops.rasseAusnahme.id === 'brachy-pq' && mops.pq[1] === 150,
    JSON.stringify(mops.pq));
  pruef('Mops: sie verschiebt NUR das PQ',
    JSON.stringify(mops.qrs) === JSON.stringify(normFuer('hund', 12, '').qrs) &&
    JSON.stringify(mops.achse) === JSON.stringify(normFuer('hund', 12, '').achse));
  /* Die Franzoesische Bulldogge ist der Fall, an dem die Schleife stolpern koennte: sie
     bricht nach dem ERSTEN Treffer ab, und diese Rasse braucht BEIDE Ausnahmen. */
  const fb = normFuer('hund', 12, '', 'franz-bulldogge');
  pruef('Französische Bulldogge behält Achse UND bekommt das weitere PQ',
    fb.achse[0] === -20 && fb.pq[1] === 150,
    JSON.stringify(fb.achse) + ' / ' + JSON.stringify(fb.pq));
  /* Der Greyhound-Eintrag traegt bewusst KEINE Zahl - die Quelle nennt keine Obergrenze. */
  const gh = normFuer('hund', 30, '', 'greyhound');
  const ohne30 = normFuer('hund', 30, '');
  pruef('Greyhound: Hinweis ja, Grenzverschiebung nein',
    gh.rasseAusnahme && gh.rasseAusnahme.id === 'greyhound-p' &&
    JSON.stringify(gh.pAmp) === JSON.stringify(ohne30.pAmp) &&
    JSON.stringify(gh.pq) === JSON.stringify(ohne30.pq),
    JSON.stringify(gh.pAmp));
}

/* ================================================================================
 * 4. DIE URSPRUNGSTABELLE WIRD NICHT VERAENDERT
 * Ein Nebeneffekt auf EKGNORM wuerde bedeuten, dass der zweite Patient die Werte des
 * ersten erbt - der gefaehrlichste Fehler, den diese Funktion machen koennte.
 * ============================================================================== */
block('4. keine Nebenwirkung auf die Ursprungstabelle');
{
  const vorher = JSON.stringify(EKGNORM);
  normFuer('hund', 3, 'Dobermann');
  normFuer('hund', 60, 'American Staffordshire Terrier');
  normFuer('katze', 4, 'Maine Coon');
  pruef('EKGNORM ist unveraendert', JSON.stringify(EKGNORM) === vorher);
  /* Und zwei Aufrufe hintereinander duerfen sich nicht beeinflussen. */
  const d1 = normFuer('hund', 35, 'Dobermann');
  const l1 = normFuer('hund', 35, 'Labrador');
  pruef('nach einem Dobermann bekommt der Labrador wieder die Artgrenze',
    l1.achse[0] === EKGNORM.hund.achse[0], JSON.stringify(l1.achse));
  pruef('und der Dobermann behaelt seine', d1.achse[0] === -45);
}

/* ================================================================================
 * 4b. DIE KATZEN-HERZFREQUENZ — DIE UMSTRITTENSTE ZAHL
 *
 * Die Gegenpruefung am 09.08.2026 fand die Untergrenze 120 AUSSERHALB der Tilley-
 * Reproduktion nirgends. Andere Werke nennen 140-220, 140-240, 100-240; fuer die
 * NARKOTISIERTE Katze - den haeufigsten Fall dieser Station - sind 100-180 belegt.
 * Mit 120 haetten wir jede Katze zwischen 100 und 120 als bradykard gemeldet.
 * ============================================================================== */
block('4b. Katzen-Herzfrequenz');
{
  const k = normFuer('katze', 4, '');
  pruef('Untergrenze 100, nicht 120', k.hf[0] === 100, JSON.stringify(k.hf));
  pruef('Obergrenze 240 (die weiteste belegte)', k.hf[1] === 240);
  pruef('eine narkotisierte Katze mit 110/min gilt nicht mehr als bradykard',
    110 >= k.hf[0]);
  pruef('mit der alten Grenze 120 waere sie gemeldet worden', 110 < 120);
  pruef('eine wirklich bradykarde Katze (90/min) faellt weiterhin auf', 90 < k.hf[0]);
  pruef('der Streit steht im Datensatz', !!k.hfQuelle && /umstritten/.test(k.hfQuelle), String(k.hfQuelle));
}

/* ================================================================================
 * 5. UNBEKANNTE ART -> NICHTS BEHAUPTEN
 * ============================================================================== */
block('5. Arten ohne belegte Baender');
['kaninchen', 'frettchen', 'meerschweinchen', 'vogel', '', null].forEach((sp) => {
  pruef('"' + String(sp) + '" liefert keine Norm', normFuer(sp, 5, 'Irgendeine') === null);
});

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
