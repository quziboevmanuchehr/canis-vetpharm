'use strict';
/*
 * wsserver.js — Minimaler, abhaengigkeitsfreier WebSocket-Server (RFC 6455, Serverseite)
 * fuer VetStation. Bewusst OHNE npm-Abhaengigkeit (`ws`), damit der Kiosk-PC
 * ohne `npm install` und ohne Internet laeuft (Appliance-Prinzip).
 *
 * Unterstuetzt: HTTP-Upgrade-Handshake, Text-Frames (senden/empfangen),
 * fragmentierte Nachrichten (Continuation), Ping/Pong, Close, Masking.
 * Nachrichten sind kleine JSON-Strings -> keine Binaerlast noetig.
 *
 * API:
 *   const server = createWsServer(httpServer, { path: '/ws', onConnect, onMessage, onClose });
 *   server.broadcast(obj)        // JSON an alle Clients
 *   server.clients               // Set der offenen Sockets
 *   client.sendJSON(obj)         // an einen Client
 */

const crypto = require('crypto');
/* EINE Wahrheit fuer die Herkunftsfrage - siehe Kopf von herkunft.js. Bis zum 12.08.2026
 * stand istLokaleAdresse() hier UND in server.js, mit unterschiedlicher Wirkung. */
const { istLokaleAdresse, eigenerHostKopf } = require('./herkunft');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

function acceptKey(key) {
  return crypto.createHash('sha1').update(key + GUID).digest('base64');
}

function encodeFrame(payloadBuf, opcode) {
  // Serverseite: unmaskiert. opcode 0x1 = text, 0x8 = close, 0x9 = ping, 0xA = pong.
  const len = payloadBuf.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  header[0] = 0x80 | (opcode & 0x0f); // FIN + opcode
  return Buffer.concat([header, payloadBuf]);
}

/* Hoechstgroesse des Empfangspuffers je Verbindung. Ueber diesen Weg gehen kleine
 * JSON-Zeilen; 64 KB sind reichlich und begrenzen zugleich einen angekuendigten
 * Riesenrahmen. */
const MAX_PUFFER = 64 * 1024;


/* Der Origin muss zum eigenen Host passen. Verglichen wird nur Schema-los auf Host und
 * Port, weil die Oberflaeche mal ueber localhost und mal ueber 127.0.0.1 geoeffnet wird. */
function originPasst(origin, host) {
  if (!host) return false;
  let o;
  try { o = new URL(String(origin)); } catch (_) { return false; }
  const gleich = (x) => String(x).replace(/^localhost(?=:|$)/, '127.0.0.1');
  return gleich(o.host) === gleich(host);
}

function createWsServer(httpServer, opts = {}) {
  const path = opts.path || '/ws';
  const clients = new Set();
  const server = { clients, broadcast, close };

  httpServer.on('upgrade', (req, socket) => {
    try {
      const url = req.url || '/';
      if (!url.startsWith(path)) { socket.destroy(); return; }
      const key = req.headers['sec-websocket-key'];
      if (!key || (req.headers['upgrade'] || '').toLowerCase() !== 'websocket') {
        socket.destroy();
        return;
      }
      /* ================================================================================
       * ZWEI RIEGEL VOR DEM HANDSCHLAG (Befund der Sicherheitspruefung 08.08.2026).
       *
       * WAS WAR: geprueft wurden nur der Pfad und der Sec-WebSocket-Key. Ein Handschlag
       * mit fremdem Origin bekam nachweislich "HTTP/1.1 101 Switching Protocols".
       *
       * WARUM DAS SCHWERER WIEGT ALS EINE OFFENE HTTP-ROUTE: WebSockets unterliegen NICHT
       * der Same-Origin-Regel des Browsers. Jede beliebige Webseite, die auf dem Praxis-PC
       * offen ist, konnte damit eine Verbindung nach 127.0.0.1 aufbauen UND die Antworten
       * lesen - anders als bei einer HTTP-Anfrage, wo CORS wenigstens das Lesen verhindert.
       * Ueber diese Verbindung laufen Schreibbefehle (Narkoseprotokoll, Gewicht, Tierart).
       *
       * (1) Nur von der Maschine selbst. Die Station laeuft im Kiosk auf demselben PC;
       *     ein WebSocket aus dem Praxisnetz ist kein vorgesehener Betriebsfall.
       * (2) Wenn ein Origin-Kopf mitkommt, muss er zum eigenen Host passen. Ein Browser
       *     setzt ihn immer; eigene Werkzeuge ohne Origin bleiben moeglich (der Riegel (1)
       *     traegt dort). Ein Browser kann den Origin-Kopf nicht faelschen.
       * ============================================================================== */
      const fern = req.socket && req.socket.remoteAddress;
      if (!istLokaleAdresse(fern)) {
        try { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); } catch (_) {}
        socket.destroy();
        return;
      }
      /* (3) DER HOST-KOPF MUSS DIE EIGENE STATION MEINEN — und diese Pruefung muss VOR (2)
       *     stehen, weil (2) sie sonst aushebelt. originPasst() vergleicht Origin gegen den
       *     Host-Kopf DERSELBEN Anfrage; beim DNS-Rebinding sind beide der Name des
       *     Angreifers und damit gleich (Befund 12.08.2026, ausfuehrlich begruendet bei
       *     eigenerHostKopf in server.js). Ohne (3) stuende ueber diesen Weg der WebSocket
       *     offen - und darueber laufen die SCHREIBENDEN Befehle pair/setMeta/medGabe. */
      if (!eigenerHostKopf(req.headers['host'], req.socket && req.socket.localPort)) {
        try { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); } catch (_) {}
        socket.destroy();
        return;
      }
      const origin = req.headers['origin'];
      if (origin && !originPasst(origin, req.headers['host'])) {
        try { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); } catch (_) {}
        socket.destroy();
        return;
      }
      const headers = [
        'HTTP/1.1 101 Switching Protocols',
        'Upgrade: websocket',
        'Connection: Upgrade',
        'Sec-WebSocket-Accept: ' + acceptKey(key),
        '\r\n',
      ].join('\r\n');
      socket.write(headers);
      setupSocket(socket, req);
    } catch (e) {
      try { socket.destroy(); } catch (_) {}
    }
  });

  function setupSocket(socket, req) {
    socket.setNoDelay(true);
    let buffer = Buffer.alloc(0);
    let fragOpcode = null;
    let fragChunks = [];
    let alive = true;

    const client = {
      socket,
      ip: (req.socket && req.socket.remoteAddress) || '?',
      sendJSON(obj) { sendText(JSON.stringify(obj)); },
      sendText,
      close: closeSocket,
      meta: {},
    };
    clients.add(client);

    const pinger = setInterval(() => {
      if (!alive) return closeSocket();
      try { socket.write(encodeFrame(Buffer.alloc(0), 0x9)); } catch (_) {}
    }, 25000);

    if (typeof opts.onConnect === 'function') {
      try { opts.onConnect(client); } catch (e) { logErr(e); }
    }

    socket.on('data', (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      /* DECKEL VOR DEM ZERLEGEN (Befund 08.08.2026). parseFrames() kehrt bei einem
       * unvollstaendigen Rahmen mit return zurueck - ohne den Puffer je zu begrenzen. Wer
       * ein Textframe mit 64-Bit-Laengenfeld ankuendigt und danach weiterschiebt, laesst
       * den Puffer bis zum Speicherueberlauf wachsen, und die Station stirbt mitten in
       * einer Narkose. Ueber diese Verbindung laufen kleine JSON-Zeilen; 64 KB sind mehr
       * als das Zehnfache des groessten je gesehenen Rahmens. */
      if (buffer.length > MAX_PUFFER) {
        try { socket.destroy(); } catch (_) {}
        buffer = Buffer.alloc(0);
        return;
      }
      parseFrames();
    });
    socket.on('close', cleanup);
    socket.on('error', cleanup);

    function parseFrames() {
      while (buffer.length >= 2) {
        const b0 = buffer[0];
        const b1 = buffer[1];
        const fin = (b0 & 0x80) !== 0;
        const opcode = b0 & 0x0f;
        const masked = (b1 & 0x80) !== 0;
        let len = b1 & 0x7f;
        let offset = 2;
        if (len === 126) {
          if (buffer.length < 4) return;
          len = buffer.readUInt16BE(2);
          offset = 4;
        } else if (len === 127) {
          if (buffer.length < 10) return;
          const big = buffer.readBigUInt64BE(2);
          len = Number(big);
          offset = 10;
        }
        const maskLen = masked ? 4 : 0;
        if (buffer.length < offset + maskLen + len) return; // Frame noch nicht komplett
        let payload = buffer.slice(offset + maskLen, offset + maskLen + len);
        if (masked) {
          const mask = buffer.slice(offset, offset + 4);
          const out = Buffer.alloc(len);
          for (let i = 0; i < len; i++) out[i] = payload[i] ^ mask[i & 3];
          payload = out;
        }
        buffer = buffer.slice(offset + maskLen + len);

        if (opcode === 0x8) { closeSocket(); return; }          // close
        if (opcode === 0x9) {                                   // ping -> pong
          try { socket.write(encodeFrame(payload, 0xA)); } catch (_) {}
          continue;
        }
        if (opcode === 0xA) { alive = true; continue; }          // pong

        if (opcode === 0x0) {                                    // continuation
          fragChunks.push(payload);
          if (fin) { deliver(fragOpcode, Buffer.concat(fragChunks)); fragOpcode = null; fragChunks = []; }
        } else {                                                 // text/binary start
          if (!fin) { fragOpcode = opcode; fragChunks = [payload]; }
          else deliver(opcode, payload);
        }
      }
    }

    function deliver(opcode, payload) {
      alive = true;
      if (opcode !== 0x1) return; // nur Text (JSON) verarbeiten
      const text = payload.toString('utf8');
      if (typeof opts.onMessage === 'function') {
        try { opts.onMessage(client, text); } catch (e) { logErr(e); }
      }
    }

    function sendText(text) {
      if (socket.destroyed) return;
      try { socket.write(encodeFrame(Buffer.from(text, 'utf8'), 0x1)); } catch (_) {}
    }
    function closeSocket() {
      try { socket.write(encodeFrame(Buffer.alloc(0), 0x8)); } catch (_) {}
      try { socket.end(); } catch (_) {}
      cleanup();
    }
    function cleanup() {
      if (!clients.has(client)) return;
      clients.delete(client);
      clearInterval(pinger);
      if (typeof opts.onClose === 'function') {
        try { opts.onClose(client); } catch (e) { logErr(e); }
      }
    }
  }

  function broadcast(obj) {
    const text = JSON.stringify(obj);
    for (const c of clients) c.sendText(text);
  }
  function close() {
    for (const c of clients) c.close();
  }
  function logErr(e) {
    if (typeof opts.onError === 'function') opts.onError(e);
    else console.error('[wsserver]', e && e.message);
  }
  return server;
}

module.exports = { createWsServer };
