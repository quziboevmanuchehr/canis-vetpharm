# Sicherheit gegen künftige Quantenrechner — was geht, was nicht, und was wirklich dringt

Stand 13.08.2026. Anlass: die Frage, ob VetStation so abgesichert werden kann, dass „auch kein
zukünftiger Quantencomputer" das Projekt bricht.

Die kurze Antwort vorweg, damit sie nicht zwischen den Einzelheiten untergeht:

> **Die dringendste Lücke dieses Projekts ist keine Quantenlücke.** Der Update-Kanal ist heute
> **überhaupt nicht signiert** — er ist mit einem gewöhnlichen Rechner angreifbar, sobald jemand
> Zugriff auf das GitHub-Konto bekommt. Das ist ein Angriff für heute, nicht für 2040.
> Alles Quantenbezogene in diesem Papier ist demgegenüber nachrangig.

---

## 1. Was ein Quantenrechner überhaupt bedroht

Zwei Verfahren, zwei völlig verschiedene Größenordnungen — das wird oft vermengt:

| Verfahren | Wirkt gegen | Folge | Betrifft VetStation |
|---|---|---|---|
| **Shor** | RSA, ECDSA, ECDH, Ed25519 | vollständig gebrochen | TLS-Handschlag, Signaturen |
| **Grover** | symmetrische Verfahren, Hashes | Sicherheit **halbiert** | SHA-256 → 128 Bit |

**SHA-256 bleibt damit ausreichend.** 128 Bit sind keine erreichbare Angriffsgröße. Wer SHA-256
„post-quantum-sicher" ersetzen will, löst ein Problem, das es nicht gibt. MD5 und SHA-1 sind
dagegen schon heute gebrochen, ganz ohne Quantenrechner. Nachgezählt am 13.08.2026, alle
`createHash`-Aufrufe außerhalb von `dist/`:

* **fünfmal `sha256`** — Update-Prüfsumme, Stationskennung, Schlüsselfingerabdruck. Alles, was
  eine Sicherheitsaufgabe hat, läuft darüber.
* **einmal `sha1`**, in `bridge/src/wsserver.js:26`: der WebSocket-Handschlag. RFC 6455 schreibt
  es vor, der Wert wird weder geheim gehalten noch als Nachweis benutzt — hier ist SHA-1 keine
  Sicherheitsaussage, sondern ein Formatzwang. Austauschen ginge gar nicht, ohne den Standard
  zu verlassen.
* **MD5** kommt vor, aber nur **innerhalb von `jspdf.umd.min.js`** (PDF-interne Kennungen, nicht
  von VetStation aufgerufen). Kein Handlungsbedarf, aber es gehört genannt, statt „kommt nicht
  vor" zu behaupten.

## 2. Was dieses Projekt selbst ändern kann — und was nicht

Das ist die entscheidende Trennung, und sie fällt meist zuungunsten des Projekts aus:

| Stelle | Kryptografie | Wer bestimmt sie |
|---|---|---|
| TLS zu Firebase | X25519 / ECDSA | **Google und Node**, nicht VetStation |
| TLS zu GitHub Pages (Update-Kanal) | X25519 / ECDSA | **GitHub und Node** |
| Firebase-Anmeldung, Token | Google | **Google** |
| Update-Zip | *gar keine Signatur* | **VetStation** ← hier liegt der Hebel |
| Patientendaten auf der Platte | unverschlüsselt, NTFS-Rechte | **VetStation / Windows** |

Nachgemessen am ausgelieferten Node (13.08.2026):

```
Node v20.18.1, OpenSSL 3.0.15+quic
  ed25519      verfügbar
  ml-dsa-65    NICHT verfügbar     (Post-Quanten-Signatur)
  ml-kem-768   NICHT verfügbar     (Post-Quanten-Schlüsseltausch)
```

**Damit steht fest: echte Post-Quanten-Verfahren sind hier heute nicht erreichbar.** Die drei
denkbaren Wege und warum sie ausscheiden:

1. **Node anheben.** ML-KEM/ML-DSA kommen mit neuerem OpenSSL. Das ist der einzige saubere Weg —
   aber es ist ein Austausch der Laufzeit unter einer laufenden Narkosestation und gehört
   geplant, nicht nebenbei gemacht.
2. **Eine Bibliothek einbinden.** Verstößt gegen die Projektregel (kein npm auf dem Praxis-PC)
   und brächte fremden Kryptocode in ein Medizinumfeld.
3. **Selbst schreiben.** Nein. Handgeschriebene Kryptografie ist in einem Gerät, an dem ein
   narkotisiertes Tier hängt, keine vertretbare Option — hier gilt dieselbe Regel wie überall
   in diesem Projekt: *sie misst und schweigt im Zweifel.*

## 3. „Harvest now, decrypt later" — die einzige Bedrohung, die man nicht verschieben kann

Bei Signaturen kann man warten: eine Fälschung nützt erst, wenn der Quantenrechner existiert.
Bis dahin lässt sich das Verfahren wechseln. **Bei Vertraulichkeit geht das nicht** — wer den
Datenstrom heute mitschneidet, entschlüsselt ihn später.

Was von VetStation wäre in 15 Jahren noch schädlich?

* **Tiername, Besitzername, Telefonnummer, behandelnder Arzt** (Geräteakte, `/api/state`) — ja.
  Personenbezogene Daten von Tierhaltern altern langsam.
* **Praxisname, Anmelde-E-Mail, Stationskennung** — ja.
* **Vitalwerte, Kurven, Narkoseprotokoll** — kaum. Der Blutdruck eines Hundes von 2026 ist 2041
  ohne Belang.

Diese Daten gehen über TLS zu Firebase. **Und genau dort ist die Lage besser, als man denkt:**
Google hat den hybriden Schlüsseltausch X25519+ML-KEM auf seinen Endpunkten ausgerollt. Ob eine
*bestimmte* Verbindung ihn nutzt, hängt allerdings am Client — und Node 20.18 kann ML-KEM nicht
(siehe Messung oben), verhandelt also X25519. **Die Verbindung Station → Firebase ist damit
heute nicht quantensicher, und VetStation kann daran allein nichts ändern.**

Was das Projekt sehr wohl kann, und was mehr bringt als jedes Kryptoverfahren:

> **Weniger Daten senden.** Was nie übertragen wurde, kann niemand mitschneiden.
> `cfg.stammdaten = false` schaltet Tiername und Besitzerdaten aus der Cloud-Übertragung ab; die
> Vitalwerte laufen weiter. Für Praxen mit hohem Schutzbedarf ist das die wirksamste Maßnahme
> in diesem ganzen Papier — und sie wirkt sofort, nicht erst nach einem Laufzeitwechsel.

## 4. Die Lücke, die wirklich dringt: der Update-Kanal ist nicht signiert

`updater/updater.js` liest Manifest, `zipUrl` **und** `sha256` aus **einer** Quelle:
`https://quziboevmanuchehr.github.io/canis-vetpharm/vetstation-version.json`.

Die Prüfsumme beweist damit nur, dass die Zip **unterwegs** nicht beschädigt wurde. Sie beweist
**nicht**, dass sie von der richtigen Stelle stammt — wer das Manifest ändern kann, ändert die
Prüfsumme gleich mit. Und `canis-vetpharm` ist ein **öffentliches** Repo.

**Angriff, ohne jeden Quantenrechner:** Zugriff auf das GitHub-Konto → Manifest mit erhöhter
Versionsnummer, passende Zip, passende `sha256`. Jede Praxis zieht das Paket beim nächsten Start
und führt es aus. Der Updater vergleicht numerisch und bietet höhere Nummern von selbst an.

### Empfehlung, gestuft

**Stufe 1 — jetzt, klassisch (Ed25519).** Node kann es ohne jede Abhängigkeit.

* Zip signieren, nicht nur hashen: Feld `sigEd25519` im Manifest über `sha256(zip)`.
* Öffentlicher Schlüssel wird **einmal mit dem Setup** ausgeliefert (`updater/release-key.pub`)
  und ist **nicht über den Kanal nachladbar** — sonst tauscht ein Angreifer ihn einfach mit aus.
* Der private Schlüssel gehört **nicht** ins Repo.

Das schließt den Angriff von oben vollständig. Ed25519 ist nicht post-quanten-sicher — aber ein
Angreifer mit Quantenrechner ist ein Problem für später, ein Angreifer mit dem GitHub-Passwort
eines für heute.

**Stufe 2 — wenn Node angehoben wird: zusätzlich ML-DSA.** Beide Signaturen ins Manifest,
beide müssen stimmen. Solange eine der beiden hält, hält der Kanal. Das ist der übliche
Übergangsweg und lässt sich ohne Bruch nachrüsten, weil Stufe 1 das Feld schon vorsieht.

**Stufe 3 — unabhängig davon: Downgrade-Sperre.** Die eingespielte Version wird lokal vermerkt;
ein Manifest mit **kleinerer** Nummer wird abgelehnt, statt still ignoriert zu werden.

### Stufe 1 ist seit 1.16.0 gebaut (13.08.2026)

| | |
|---|---|
| Verfahren | Ed25519, Node-Bordmittel, keine Abhängigkeit |
| Vorschrift | `updater/signatur.js` — **eine** Stelle für Bilden und Prüfen |
| Signiert wird | `vetstation-update-v1\n<version>\n<sha256>` |
| Öffentlicher Schlüssel | `updater/release-key.pub`, **im Paket** ausgeliefert |
| Privater Schlüssel | `%USERPROFILE%\.vetstation-keys\`, außerhalb beider Repos, ACL nur Besitzer |
| Fingerabdruck | `4ab65c271b6b1a34` |
| Signieren | `node tools/paket-signieren.js` (setzt sha256 **und** Signatur selbst) |
| Prüfung | `tools/update-signatur-test.js`, 42 Prüfungen |

**Warum Version *und* Prüfsumme zusammen signiert werden.** Würde nur der sha256 signiert,
stünde die Versionsnummer unsigniert daneben. Ein Angreifer könnte dann ein **echtes, altes**
Paket unter einer hohen Nummer neu anbieten — Signatur gültig, Prüfsumme gültig. Jede Station
„aktualisiert" sich auf einen alten Stand mit längst behobenen Fehlern und bekäme die richtige
Fassung **nie wieder** angeboten, weil die Nummer bereits höher steht. Das Paar ist deshalb
unteilbar; `update-signatur-test.js` prüft genau diesen Fall.

**Warum der öffentliche Schlüssel nicht über den Kanal kommt.** Sonst tauscht ein Angreifer,
der den Kanal beherrscht, Schlüssel *und* Signatur aus, und die Prüfung geht auf. Ein Schlüssel,
den man vom Angreifer holt, prüft nichts.

**Mitgeschlossen:** `if (info.sha256)` ließ ein Manifest **ohne** Prüfsummenfeld völlig
ungeprüft durch — ein Riegel, den man durch Weglassen umgeht, ist keiner. Jetzt gilt: keine
Prüfsumme, kein Update.

**Was das kostet, und es ist kein Nebensatz:** Ohne den privaten Schlüssel lassen sich keine
Updates mehr freigeben. Es gibt keine Hintertür — das ist der Sinn. Geht er verloren, bleibt
der Weg über `VetStation-Setup.exe` (neues Schlüsselpaar, Stationen einmal neu einrichten).
Der Schlüssel gehört gesichert wie ein Praxisschlüssel.

**Übergang:** Fassungen vor 1.16.0 kennen die Prüfung nicht und holen sich 1.16.0 weiter allein
über die Prüfsumme — ihr Code ist ausgeliefert, daran lässt sich nichts mehr ändern. Ab 1.16.0
gilt der Riegel für jedes weitere Update.

## 5. Was am 13.08.2026 tatsächlich geändert wurde

Alles aus dieser Runde ist **klassische** Absicherung — sie wirkt gegen Angreifer von heute:

| Änderung | Datei |
|---|---|
| DNS-Rebinding geschlossen (Host-Kopf gegen Positivliste statt Selbstvergleich) | `bridge/src/herkunft.js`, `server.js`, `wsserver.js` |
| Vier zustandsändernde Routen bekamen den Herkunftsriegel | `bridge/src/server.js` |
| Update-Knopf reparierte sich selbst aus (403 durch fehlenden Content-Type) | `ui/views/admin.js` |
| `/api/netscan` gab die Netzaufklärung mit `Allow-Origin: *` heraus | `bridge/src/server.js` |
| Prototyp-Vergiftung über `setMeta('__proto__')` | `bridge/src/registry.js` |

Geprüft in `tools/sicherheit-test.js` (73 Prüfungen), ohne Netz und ohne laufenden Server.

## 6. Was bewusst NICHT gemacht wurde

* **Die Firebase-Regeln bleiben, wie sie sind.** Begründung unverändert in
  `vetstation-sicherheit` und `docs/FIREBASE-EINRICHTEN.md` — sie hier zu verschärfen würde die
  Fern-Ansicht brechen, ohne einen belegten Angriff zu schließen.
* **Kein Austausch von SHA-256.** Siehe Abschnitt 1: Grover halbiert es auf 128 Bit, das genügt.
* **Keine selbstgeschriebene Post-Quanten-Kryptografie.** Siehe Abschnitt 2.
