'use strict';
/*
 * anmeldung-test.js — die Anmeldung am Praxis-Konto darf zum Laden ihres eigenen Moduls
 * NICHT auf das Internet angewiesen sein.
 *
 * WARUM ES DIESE DATEI GIBT (Befund 19.08.2026, am Praxis-PC fotografiert):
 *
 *   Im Admin-Bereich stand unter dem Knopf "Anmelden" woertlich:
 *       Failed to fetch dynamically imported module:
 *       https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js
 *
 *   ui/views/admin.js holte das Firebase-SDK bei JEDER Anmeldung frisch von gstatic.com.
 *   Schlug das fehl, waren BEIDE Wege tot - auch der mit E-Mail und Passwort, der die
 *   Anbieterseiten von Google gar nicht braucht. Die Meldung war englisch, technisch und
 *   sagte nicht, was zu tun ist.
 *
 *   Das verstiess ausserdem gegen die erste Projektregel: Fremdcode wird MITGELIEFERT, nicht
 *   zur Laufzeit nachgeladen ("kein Bauschritt, kein Internet noetig"). Ein Praxis-PC, dessen
 *   Oberflaeche ein fremdes Rechenzentrum braucht, um bedienbar zu sein, ist kein
 *   Praxis-PC-taugliches Programm.
 *
 * ZWEI FALLEN, die dieser Test mitbewacht:
 *
 *   a) firebase-auth.js importiert firebase-app.js ueber eine ABSOLUTE gstatic-Adresse. Wer
 *      die Dateien nur kopiert und diese eine Zeile vergisst, holt die Haelfte doch wieder
 *      aus dem Netz - und merkt es nicht, weil die Anmeldung am Entwicklerrechner laeuft.
 *
 *   b) import() steht in einem KLASSISCHEN Skript und loest deshalb gegen die Adresse des
 *      DOKUMENTS auf, nicht gegen die von admin.js. Ein relativer Pfad waere davon abhaengig,
 *      welche Seite das Skript einbindet. Deshalb muss er absolut sein.
 *
 * Start: node tools/anmeldung-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

console.log('VetStation — die Anmeldung bringt ihr Modul selbst mit\n');

/* ---- 1) Die Dateien muessen im Baum liegen ---- */
console.log('1) Das SDK liegt im Paket:');
var DIR = path.join(WURZEL, 'ui/vendor/firebase');
var appJs = path.join(DIR, 'firebase-app.js');
var authJs = path.join(DIR, 'firebase-auth.js');
ok('ui/vendor/firebase/firebase-app.js vorhanden', fs.existsSync(appJs));
ok('ui/vendor/firebase/firebase-auth.js vorhanden', fs.existsSync(authJs));
ok('LIESMICH.txt erklaert Herkunft und Lizenz', fs.existsSync(path.join(DIR, 'LIESMICH.txt')));

if (fs.existsSync(appJs) && fs.existsSync(authJs)) {
  var a = fs.readFileSync(appJs, 'utf8');
  var b = fs.readFileSync(authJs, 'utf8');
  ok('firebase-app.js ist plausibel gross (' + Math.round(a.length / 1024) + ' KB)', a.length > 50000);
  ok('firebase-auth.js ist plausibel gross (' + Math.round(b.length / 1024) + ' KB)', b.length > 80000);

  /* Falle a): kein LADENDER gstatic-Verweis darf uebrig sein.
   *
   * Die erste Fassung dieser Pruefung suchte JEDES Vorkommen der Zeichenkette und wurde rot -
   * zu Unrecht. Zwei Stellen in firebase-app.js sind blosse Namensfelder des SDK:
   *     const name$p = "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js"
   *     new Logger('https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js')
   * Googles Bauweg setzt dort die Auslieferungsadresse anstelle des Paketnamens ein. Sie laden
   * nichts. Im Browser gemessen (19.08.2026): beim Laden beider Module ging KEIN einziger Ruf
   * an gstatic.com hinaus, nur zwei an /vendor/firebase/.
   *
   * Deshalb prueft diese Zeile jetzt genau das, worauf es ankommt: eine import- oder
   * from-Anweisung, die auf gstatic zeigt. Genau die stand in firebase-auth.js.
   */
  var ladend = (a + b).match(/(?:\bfrom|\bimport)\s*\(?\s*["'][^"']*gstatic\.com[^"']*["']/g) || [];
  ok('keine import-Anweisung zeigt mehr auf gstatic', ladend.length === 0, ladend.join(' | '));
  ok('firebase-auth.js importiert seinen Nachbarn relativ',
    /from\s*["']\.\/firebase-app\.js["']/.test(b));

  /* Die Funktionen, ohne die keiner der beiden Anmeldewege geht. */
  [['initializeApp', a, 'firebase-app.js'],
   ['getAuth', b, 'firebase-auth.js'],
   ['signInWithEmailAndPassword', b, 'firebase-auth.js'],
   ['signInWithRedirect', b, 'firebase-auth.js'],
   ['GoogleAuthProvider', b, 'firebase-auth.js'],
   ['OAuthProvider', b, 'firebase-auth.js']].forEach(function (t) {
    ok(t[0] + ' steckt in ' + t[2], t[1].indexOf(t[0]) >= 0);
  });
}

/* ---- 2) Und die Anmeldung muss sie auch von dort holen ---- */
console.log('\n2) admin.js laedt von dort, nicht aus dem Netz:');
var admin = fs.readFileSync(path.join(WURZEL, 'ui/views/admin.js'), 'utf8');
var adminCode = admin.replace(/\/\*[\s\S]*?\*\//g, ' ');

ok('der lokale Pfad ist gesetzt', /FBSDK_LOKAL\s*=\s*'\/vendor\/firebase\/'/.test(adminCode));
/* Falle b): ein relativer Pfad haenge an der Seite, die admin.js einbindet. */
ok('und er ist ABSOLUT (import() loest gegen das Dokument auf, nicht gegen admin.js)',
  !/FBSDK_LOKAL\s*=\s*'\.\.?\//.test(adminCode));
ok('ladeAuth() versucht zuerst die mitgelieferte Fassung',
  /ladeAuth\s*\(\)\s*\{[\s\S]{0,200}?ladeSdk\(FBSDK_LOKAL\)/.test(adminCode),
  'Sonst bleibt das Netz der erste Weg und der Fehler kommt zurueck');
ok('das Netz ist nur noch der Rueckfall (im catch)',
  /catch\s*\(function\s*\(e\)\s*\{[\s\S]{0,300}?ladeSdk\(FBSDK\)/.test(adminCode));
ok('und der Rueckfall wird nicht verschwiegen', /console\.warn\([^)]*Firebase-SDK/.test(adminCode));

/* ---- 3) Scheitert es doch, muss die Meldung auf Deutsch sagen was fehlt ---- */
console.log('\n3) Die Meldung, wenn es doch scheitert:');
ok('der Modulfehler wird eigens erkannt',
  /dynamically imported module\|Failed to fetch/.test(adminCode),
  'Er kommt OHNE Firebase-Code an - ein TypeError des Browsers - und fiel sonst als englischer Text durch');
ok('sie nennt den Weg zur Loesung (Aktualisieren)', /Admin ▸ Aktualisieren/.test(admin));
ok('sie nennt die beiden Namen, die erreichbar sein muessen',
  admin.indexOf('identitytoolkit.googleapis.com') > 0 && admin.indexOf('vet-station.firebaseapp.com') > 0);
ok('sie sagt, dass die Station selbst weiterlaeuft', /Station selbst läuft weiter/.test(admin));

/* ---- 4) Das Paket muss die Dateien wirklich mitnehmen ---- */
console.log('\n4) Der Bauweg nimmt sie mit:');
var mkdist = fs.readFileSync(path.join(WURZEL, 'installer/make-dist.ps1'), 'utf8');
var ausgeschlossen = /XD[^\n]*vendor/.test(mkdist);
ok('make-dist.ps1 schliesst ui/vendor NICHT aus', !ausgeschlossen,
  'Sonst faehrt die Station ohne ihr Anmeldemodul zum Kunden');

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
