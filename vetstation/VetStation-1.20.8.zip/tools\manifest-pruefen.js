'use strict';
/*
 * manifest-pruefen.js — haelt das VEROEFFENTLICHTE Update-Manifest gegen die Wirklichkeit.
 *
 * WARUM ES DIESES WERKZEUG GIBT (Befund der Freigabepruefung 08.08.2026):
 * Die Anleitung im README nannte das Update-Paket und liess dann die Pruefsumme der
 * SETUP-Zip bilden - zwei verschiedene Dateien in einem Atemzug. Wer dem folgt, traegt eine
 * Pruefsumme ein, die nicht zur verlinkten Datei gehoert. Der Fehler faellt beim Bauen NICHT
 * auf: alle Selbsttests bleiben gruen, das Paket ist in Ordnung, das Manifest sieht richtig
 * aus. Er faellt erst auf dem Praxis-PC auf, und zwar als Abbruch mit
 * "Pruefsumme (sha256) stimmt NICHT - Update abgebrochen (Sicherheit)" -
 * auf JEDER Station gleichzeitig.
 *
 * Im selben Zug wurde ein zweiter Fall gemessen, der genauso still ist: eine Zip, die im
 * Kanal liegt, aber aus einem AELTEREN Bau stammt als der Quellcode. Sie hat eine gueltige
 * Pruefsumme und wird anstandslos angenommen - sie liefert nur nicht das, was die
 * Freigabenotiz verspricht. Und weil die Versionsnummer danach nicht mehr steigt, bekommt
 * eine Station, die einmal darauf gegangen ist, die Korrektur nie angeboten.
 *
 * Geprueft wird deshalb:
 *   1. Das Manifest nennt dieselbe Version wie package.json.
 *   2. zipUrl zeigt auf VetStation-<version>.zip.
 *   3. Die Datei existiert im Kanal - und ihre Pruefsumme ist die eingetragene.
 *   4. Die Datei ist NICHT aelter als die Quelldateien, aus denen sie gebaut wurde.
 *   5. Sie enthaelt kein node/ und kein data/ (Groesse und Betriebsdaten des Kunden).
 *   6. Die Freigabenotiz nennt keine Befehle, die es am Praxis-PC nicht gibt.
 *
 * Das Web-Repo liegt NEBEN diesem: ../../canis-vetpharm. Fehlt es, wird nichts behauptet -
 * dann sagt das Werkzeug das und endet ohne Fehler (auf einem Praxis-PC gibt es das Repo nie).
 *
 * Start: node tools/manifest-pruefen.js
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const WEB = path.join(ROOT, '..', '..', 'canis-vetpharm');

let pass = 0; const fehler = [];
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fehler.push(n + (e ? '  -> ' + e : '')); console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

console.log('\nVetStation - Update-Manifest gegen die wirkliche Datei\n');

if (!fs.existsSync(WEB)) {
  console.log('  Das Web-/Kanal-Repo liegt nicht unter ' + WEB + '.');
  console.log('  Es gibt also nichts zu pruefen - das ist kein Fehler.\n');
  process.exit(0);
}

const manifestPfad = path.join(WEB, 'vetstation-version.json');
if (!fs.existsSync(manifestPfad)) {
  console.log('  Kein vetstation-version.json im Kanal - nichts zu pruefen.\n');
  process.exit(0);
}

const app = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
let m;
try { m = JSON.parse(fs.readFileSync(manifestPfad, 'utf8')); }
catch (e) { console.log('  Manifest ist kein gueltiges JSON: ' + e.message + '\n'); process.exit(1); }

console.log('  Quellbaum: ' + app + '        Manifest: ' + (m.app || '(fehlt)') + '\n');

ok('Manifest nennt dieselbe Version wie package.json', m.app === app, m.app);
ok('channel gesetzt', !!m.channel, m.channel);
ok('zipUrl gesetzt', !!m.zipUrl);
ok('sha256 gesetzt und plausibel', /^[0-9a-f]{64}$/.test(String(m.sha256 || '')), m.sha256);

const erwartet = 'VetStation-' + m.app + '.zip';
const genannt = String(m.zipUrl || '').split('/').pop();
ok('zipUrl zeigt auf ' + erwartet, genannt === erwartet, genannt);
/* Der eigentliche Fehler, den es hier zu fangen gilt. */
ok('zipUrl zeigt NICHT auf die Setup-Zip (die enthaelt node\\ und ist ~27 MB)',
  genannt !== 'VetStation-Setup.zip', genannt);

const zip = path.join(WEB, 'vetstation', erwartet);
if (!fs.existsSync(zip)) {
  ok('die Zip liegt im Kanal', false, zip + ' fehlt');
} else {
  ok('die Zip liegt im Kanal', true);
  const sha = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
  ok('sha256 im Manifest ist die der Datei', sha === String(m.sha256).toLowerCase(),
    'Datei ' + sha + ', Manifest ' + m.sha256);

  /* ------------------------------------------------------------------------------------
   * DIE SIGNATUR - hier faellt auf, wenn jemand das Signieren vergisst (13.08.2026).
   *
   * Ab 1.16.0 weist jede Station ein unsigniertes Paket ab. Ein vergessener Aufruf von
   * tools/paket-signieren.js waere also kein Schoenheitsfehler, sondern eine Freigabe, die
   * auf KEINER Station ankommt - und das merkt man sonst erst, wenn sich die erste Praxis
   * meldet. Geprueft wird mit genau dem oeffentlichen Schluessel, der im Paket liegt, und
   * mit derselben Vorschrift, die auch die Station benutzt (updater/signatur.js).
   * ---------------------------------------------------------------------------------- */
  {
    const signatur = require('../updater/signatur.js');
    const pubPfad = path.join(__dirname, '..', 'updater', 'release-key.pub');
    if (!fs.existsSync(pubPfad)) {
      ok('updater/release-key.pub ist vorhanden', false,
        'einmalig anlegen: node tools/schluessel-erzeugen.js');
    } else {
      const pub = fs.readFileSync(pubPfad, 'utf8');
      ok('das Manifest traegt eine Signatur (sigEd25519)', !!m.sigEd25519,
        'signieren mit: node tools/paket-signieren.js');
      const u = signatur.pruefe(m.app, sha, m.sigEd25519, pub);
      ok('die Signatur gilt fuer genau diese Version und diese Datei', u.ok, u.grund || '');
      console.log('  Schluessel-Fingerabdruck: ' + signatur.fingerabdruck(pub));
    }
  }

  const kb = Math.round(fs.statSync(zip).size / 1024);
  ok('Groesse passt zu einem Update-Paket (unter 8 MB, also ohne node\\)', kb < 8192, kb + ' KB');

  /* Aelter als die Quelle? Dann ist es ein Zwischenstand, auch wenn die Pruefsumme stimmt.
   *
   * NUR BEIM VEROEFFENTLICHEN EIN FEHLER, sonst ein Hinweis (Befund an mir selbst,
   * 08.08.2026): waehrend der normalen Arbeit gibt es fast immer Aenderungen, die noch
   * nicht im Kanal liegen - das ist der Regelfall und kein Mangel. Ein Test, der dabei
   * dauernd rot ist, wird nach kurzer Zeit weggesehen, und dann faellt er auch dann nicht
   * mehr auf, wenn es wirklich darauf ankommt. Mit "--freigabe" (so ruft die Freigabekette
   * ihn auf) ist dieselbe Abweichung ein harter Fehler. */
  const freigabe = process.argv.indexOf('--freigabe') >= 0;
  const zipZeit = fs.statSync(zip).mtimeMs;
  const quellen = [
    'ui/app/index.html', 'ui/shared/ekg-skala.js', 'ui/shared/ekg-analyse.js',
    'ui/shared/ekg-befunde.js', 'bridge/src/index.js', 'bridge/src/server.js',
    'bridge/src/wsserver.js', 'package.json',
    /* NACHGETRAGEN 15.08.2026. dosis-warnungen.js traegt die Richtigstellung zur tausendfach
     * zu hohen Dauertropfdosis und ist die einzige Datei, ueber die sie eine schon laufende
     * Station noch erreicht. Wer nur sie aendert und das Paket nicht neu baut, bekam bis
     * hierher auch mit --freigabe ein gruenes Ergebnis auf ein veraltetes Paket. */
    'ui/shared/dosis-warnungen.js', 'ui/shared/ekg-literatur.js',
  ].filter((r) => fs.existsSync(path.join(ROOT, r)));
  const juenger = quellen.filter((r) => fs.statSync(path.join(ROOT, r)).mtimeMs > zipZeit + 1000);
  if (freigabe) {
    ok('die Zip ist nicht aelter als die Quelldateien', juenger.length === 0,
      'neuer als das Paket: ' + juenger.join(', '));
  } else if (juenger.length) {
    console.log('  ! HINWEIS: seit dem Paketbau geaendert (noch nicht veroeffentlicht): ' +
      juenger.join(', '));
    console.log('    Vor einer Freigabe neu bauen und diesen Test mit --freigabe fahren.');
  } else {
    ok('die Zip ist nicht aelter als die Quelldateien', true);
  }
}

/* Die Notiz geht woertlich an den Tierarzt. */
const notes = String(m.notes || '');
ok('Freigabenotiz vorhanden', notes.length > 40, notes.length + ' Zeichen');
[['npm ', 'npm gibt es am Praxis-PC nicht'],
 ['node ', 'node liegt dort nicht im PATH'],
 ['cd ', 'ein Pfadwechsel hilft dort niemandem']]
  .forEach(([wort, warum]) => {
    ok('Freigabenotiz nennt kein "' + wort.trim() + '" (' + warum + ')',
      notes.indexOf(wort) < 0);
  });

console.log('\n' + (fehler.length
  ? fehler.length + ' von ' + (pass + fehler.length) + ' FEHLGESCHLAGEN - so darf NICHT veroeffentlicht werden.'
  : 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN'));
process.exit(fehler.length ? 1 : 0);
