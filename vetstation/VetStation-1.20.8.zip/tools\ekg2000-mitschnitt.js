'use strict';
/*
 * ekg2000-mitschnitt.js — das eingesteckte EKG 2000 selbst nach seinem Format fragen.
 *
 * WARUM ES DIESES WERKZEUG GIBT (13.08.2026):
 * Das serielle Datenformat des Eickemeyer/Grimed EKG 2000 ist nirgends veroeffentlicht.
 * Nachgesehen wurde: Produktblatt 321018, englisches Handbuch, zwei Internetrecherchen,
 * die mitgelieferten Treiberdateien. Die Programmdateien des Herstellers liegen in einem
 * verschluesselten Archiv - daran wird nicht gearbeitet, und es ist auch nicht noetig.
 *
 * Das Geraet selbst ist die belastbarste Quelle: es haengt am USB und sendet. Dieses
 * Werkzeug findet seinen Anschluss, probiert die ueblichen Baudraten durch, zeichnet auf,
 * was ankommt, und laesst bridge/src/ekg2000-format.js den Aufbau beurteilen.
 *
 * ES RAET NICHTS. Am Ende steht entweder eine belegte Formatbeschreibung oder ein
 * ehrliches "kein Muster erkennbar". Eine erfundene Rahmenlaenge waere schlimmer als gar
 * keine - sie ergaebe eine Kurve aus Rauschen, der niemand misstraut.
 *
 * STRIKT MITLESEN: es wird NICHTS an das Geraet gesendet. Der serielle Weg dieses Projekts
 * sendet ueberhaupt nur mit ausdruecklicher Erlaubnisliste (bridge/src/seriell.js); hier
 * wird sie gar nicht erst gesetzt.
 *
 * Start (mit angestecktem Geraet):
 *   node tools/ekg2000-mitschnitt.js
 *   node tools/ekg2000-mitschnitt.js --com COM5 --baud 115200 --sekunden 20
 *   node tools/ekg2000-mitschnitt.js --lesen data\ekg2000-115200.bin   (nur auswerten)
 */
const fs = require('fs');
const path = require('path');
const seriell = require('../bridge/src/seriell.js');
const format = require('../bridge/src/ekg2000-format.js');

const ROOT = path.join(__dirname, '..');
const AUS = path.join(ROOT, 'data');

function arg(n, s) { const i = process.argv.indexOf(n); return (i >= 0 && process.argv[i + 1]) ? process.argv[i + 1] : s; }
const nurLesen = arg('--lesen', null);
const comFest = arg('--com', null);
const baudFest = arg('--baud', null);
const sekunden = Number(arg('--sekunden', 8));

console.log('\nVetStation - EKG 2000: Datenformat ermitteln\n');

function bericht(buf, quelle) {
  const d = format.deute(buf);
  console.log('  ' + quelle);
  console.log('    ' + d.bytes + ' Byte, Entropie ' + d.entropie + ' Bit/Byte');
  console.log('    ' + d.urteil);
  if (d.felder) {
    const f = d.felder.filter((x) => x);
    console.log('    Felder im Satz:');
    f.forEach((x) => {
      const art = x.konstanz > 0.9 ? 'fest   0x' + x.wert.toString(16).padStart(2, '0')
        : x.zaehler ? 'Zaehler'
          : 'Wert   Spanne ' + x.spanne;
      console.log('      Byte ' + String(x.stelle).padStart(2) + '  ' + art
        + '   (gleich in ' + Math.round(x.konstanz * 100) + ' % der Saetze)');
    });
  }
  return d;
}

/* ---- Nur auswerten (aufgezeichnete Datei) ------------------------------------------- */
if (nurLesen) {
  const p = path.isAbsolute(nurLesen) ? nurLesen : path.join(ROOT, nurLesen);
  if (!fs.existsSync(p)) { console.log('  Datei nicht gefunden: ' + p + '\n'); process.exit(1); }
  bericht(fs.readFileSync(p), 'Aufzeichnung ' + path.basename(p));
  console.log('');
  process.exit(0);
}

/* ---- Am Geraet ---------------------------------------------------------------------- */
async function lauf() {
  let com = comFest;
  if (!com) {
    const u = await seriell.usbSerielleGeraete();
    if (!u.ok) { console.log('  ' + u.grund + '\n'); process.exit(1); }
    const ekg = u.liste.filter((g) => g.katalogId === 'eickemeyer-ekg-2000');
    if (!ekg.length) {
      console.log('  Kein EKG 2000 gefunden.');
      if (u.liste.length) {
        console.log('  Gefundene USB-Anschluesse:');
        u.liste.forEach((g) => console.log('    ' + g.port + '  ' + (g.name || 'unbekannt (' + g.vid + ':' + g.pid + ')')));
        console.log('  Mit --com COMx laesst sich einer davon von Hand waehlen.');
      } else {
        console.log('  ' + (u.grund || 'Es ist kein USB-Seriell-Geraet angesteckt.'));
        console.log('  Steckt das EKG 2000? Ist der Treiber da? -> installer\\set-ekg-treiber.ps1 -Erzwingen');
      }
      console.log('');
      process.exit(1);
    }
    com = ekg[0].port;
    console.log('  Gefunden: ' + ekg[0].name + ' an ' + com
      + (ekg[0].serie ? '  (Seriennummer ' + ekg[0].serie + ')' : ''));
  }

  const raten = baudFest ? [Number(baudFest)] : format.BAUDRATEN;
  fs.mkdirSync(AUS, { recursive: true });
  console.log('  Es wird NUR mitgelesen - an das Geraet geht nichts.\n');

  const treffer = [];
  for (const baud of raten) {
    const v = new seriell.SerielleVerbindung(
      { art: 'com', port: com, baud: baud },     /* keine erlaubteBefehle -> Senden gesperrt */
      { log: { info() {}, warn() {}, error() {} } });
    const stuecke = [];
    v.beiDaten((b) => stuecke.push(b));
    let offen = false;
    try { await v.oeffnen(); offen = true; } catch (e) {
      console.log('  ' + String(baud).padStart(7) + ' Baud: laesst sich nicht oeffnen (' + e.message + ')');
      continue;
    }
    await new Promise((r) => setTimeout(r, Math.max(1000, sekunden * 1000 / raten.length)));
    try { v.schliessen && v.schliessen(); } catch (_) {}
    const buf = Buffer.concat(stuecke);
    if (!buf.length) { console.log('  ' + String(baud).padStart(7) + ' Baud: nichts empfangen'); continue; }
    const d = format.deute(buf);
    console.log('  ' + String(baud).padStart(7) + ' Baud: ' + buf.length + ' Byte, Entropie '
      + d.entropie + (d.sinnvoll ? '  <== sieht nach Nutzdaten aus' : ''));
    const datei = path.join(AUS, 'ekg2000-' + baud + '.bin');
    fs.writeFileSync(datei, buf);
    if (d.sinnvoll) treffer.push({ baud, buf, datei, d });
  }

  console.log('');
  if (!treffer.length) {
    console.log('  KEIN BRAUCHBARER STROM. Moegliche Gruende, in dieser Reihenfolge pruefen:');
    console.log('   1. Das Geraet sendet erst, wenn es dazu aufgefordert wird. Dann hilft nur die');
    console.log('      Schnittstellenbeschreibung von Eickemeyer (Artikel 321018).');
    console.log('   2. Das Geraet spricht ueber die D2XX-Schnittstelle statt ueber den COM-Port.');
    console.log('   3. Elektroden nicht angeschlossen - manche Geraete senden dann nichts.');
    console.log('');
    process.exit(0);
  }

  treffer.sort((a, b) => a.d.entropie - b.d.entropie);
  const best = treffer[0];
  console.log('  === BESTER TREFFER: ' + best.baud + ' Baud ===');
  bericht(best.buf, path.basename(best.datei));
  console.log('');
  console.log('  Aufzeichnung liegt in: ' + best.datei);
  console.log('  Diese Datei bitte aufheben - aus ihr wird der Adapter parametriert.');
  console.log('');
}

lauf().catch((e) => { console.log('\n  Abbruch: ' + e.message + '\n'); process.exit(1); });
