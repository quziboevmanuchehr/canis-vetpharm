# Wie schnell kann die Fern-Ansicht wirklich sein?

**Gemessen am 19.08.2026, ohne angeschlossenes Gerät.** Das ist kein Mangel der Messung:
gefragt war die *Leitung*, nicht die Quelle. Was ein Gerät liefert, ändert an Laufzeit und
Datenmenge der Strecke nichts.

Anlass: die Bitte, die Werte eines echten Monitors sollten „in Millisekunden" im virtuellen
Gerät der Web-App erscheinen.

---

## Die Antwort in einem Satz

**Millisekunden ja — aber rund 150, nicht rund 1.** Und der größere Anteil liegt nicht im
Internet, sondern in der eigenen Software.

---

## Die beiden Hälften, einzeln gemessen

### 1. Die Softwarekette (`tools/fern-durchsatz-test.js`)

Gerätepaket → `registry.ingest` → `matching.mergePatients` → `cloud.publish` → Leitung.
Echte Software, nur HL7-Zerlegung und Internet ersetzt.

| | |
|---|---|
| Laufzeit bis auf die Leitung | schnellste **8 ms** · Mitte **118 ms** · langsamste **203 ms** |
| Übertragungen | 2 je Sekunde (Sendetakt 200 ms) |
| Paketgröße Mitte | 4136 Byte (kleinstes 210, größtes 5174) |
| reine Wertpakete | 672 Byte |
| Kurvendaten | 3,9 KB/s |
| gesamt während einer Narkose | 7,3 KB/s = 25,8 MB je Stunde |

### 2. Die Netzstrecke (`scratchpad/leitung-messen.js`)

Zur Datenbank `vet-station-default-rtdb.europe-west1.firebasedatabase.app`.

| | |
|---|---|
| DNS-Auflösung | 37 ms (einmalig) |
| TCP + TLS | 100 ms (einmalig je Verbindung) |
| Umlauf über eine **offene** Verbindung, 506-Byte-Rumpf | schnellste **28,4 ms** · Mitte **36,1 ms** · langsamste **108,6 ms** |
| daraus ein Weg | rund **18 ms** |

Die 18 ms decken sich mit dem, was die Fern-Ansicht selbst anzeigt (`Laufzeit 18 ms` im
Bildschirmfoto vom 19.08.2026). Zwei unabhängige Wege, dieselbe Zahl — das trägt.

---

## Was daraus folgt

```
Gerät → Software (118 ms) → Hinweg (18 ms) → Datenbank → Rückweg (18 ms) → Schirm
                                                            ≈ 154 ms im besten Fall
```

**Der Flaschenhals ist die eigene Software, nicht die Leitung.** 118 von 154 ms entstehen
vor dem ersten Byte auf der Leitung. Der größte Einzelposten darin ist der Sendetakt von
200 ms: ein Wert, der kurz nach einem Takt entsteht, wartet bis zum nächsten.

## Und die Datenmenge?

Eine durchgehende EKG-Kurve mit 250 Abtastwerten je Sekunde auf vier Bahnen sind
1000 Werte/s. Mit der vorhandenen Kodierung (`cloud.js encodeSamples`) und JSON-Rahmen
landet das in derselben Größenordnung wie die heute schon fließenden **3,9 KB/s** für
Kurvenstreifen.

Hochgerechnet bei 8 h Betrieb am Tag: **6 GB/Monat** — das Firebase-Freikontingent liegt bei
10 GB. Durchgehende Kurven sind also **bezahlbar**, solange es bei einem Saal bleibt.
Bei drei gleichzeitig laufenden Sälen wäre das Kontingent überschritten.

---

## Was ich damit **nicht** gemessen habe

- Die Schreibzeit **in** der Datenbank und die Zustellung an einen zweiten Zuhörer. Beides
  liegt oberhalb der 18 ms, nie darunter — als **Untergrenze** ist die Zahl belastbar, als
  Versprechen nicht.
- Das Verhalten bei schlechtem Praxis-WLAN. Die langsamste gemessene Runde lag bei 108,6 ms,
  also dreimal über der Mitte; das war ein Kabelanschluss.
- Ob die Kurve am anderen Ende **flüssig** aussieht. Dafür zählt nicht die Laufzeit, sondern
  die Gleichmäßigkeit der Pakete — das ist eine eigene Messung.

## Was sich lohnen würde, in dieser Reihenfolge

1. **Sendetakt für Kurven von 200 ms auf 40 ms.** Größter Gewinn, kleinster Eingriff:
   154 ms → rund 60 ms. Kostet Datenmenge, aber die Rechnung oben trägt sie.
2. **Die Verbindung offen halten.** Die 100 ms TLS-Handschlag dürfen nicht je Paket
   anfallen. (Der heutige Publisher hält sie bereits offen — nachzuprüfen, nicht anzunehmen.)
3. **Erst danach** über eine andere Übertragungsart nachdenken. Firebase RTDB ist mit 36 ms
   Umlauf nicht das Problem.

**Unter etwa 50 ms Ende zu Ende wird es ohne einen ganz anderen Weg nicht gehen** — und
50 ms sind für eine Fern-*Ansicht* mehr als genug: ein EKG mit 250 Hz zeigt in 50 ms
zwölf Abtastwerte, das Auge sieht keinen Unterschied. Für die Überwachung am Tisch bleibt
ohnehin der Monitor im OP zuständig; die Fern-Ansicht ist ausdrücklich „nur Ansicht".
