'use strict';
/*
 * cloud-test.js — Selbsttest des FERN-LIVE Publishers (bridge/src/cloud.js) OHNE Internet.
 * Ein lokaler HTTP-Server spielt Firebase (Anmeldung + securetoken-refresh + RTDB) nach.
 * Geprueft: Anmelde-Fluss, Snapshot-Schema, Brain-Enrichment (pri/top), Throttle,
 * Token-Refresh, Persistenz der Token-Datei.  Start: node tools/cloud-test.js
 *
 * ==========================================================================================
 * UMBAU 30.07.2026 — MEHRERE OP-SAELE (docs/PLAN-MEHRERE-SAELE.md)
 * ==========================================================================================
 * Der Publisher schreibt ab 1.1.0 in VIER getrennte Ziele statt in eines:
 *   Weg L  saele/<sid>/patients/<key>/<feld>   die Vitalwerte (Takt 500 ms)
 *   Weg T  tafel/<sid>/{meta,uebersicht,geraete}  Herzschlag + Kacheln (Takt 2 s)
 *   Weg S  meta/* + patients/s<sid6>__<key>/...   Spiegel fuer die alte Web-App 1.0.3
 *   Weg P  saele/<sid>/protokoll/<pid>/<ts>       das OP-Protokoll (eigener Vorgang)
 *
 * WAS SICH AN DIESER DATEI DADURCH ZWANGSLAEUFIG GEAENDERT HAT — vollstaendig aufgezaehlt, damit
 * niemand nachsehen muss, ob hier eine Pruefung stillschweigend weicher geworden ist:
 *   (1) Der Mock ist jetzt eine kleine ECHTE Datenbank (Baum + tiefe Pfade + null loescht +
 *       shallow). Ohne sie kann der Publisher nichts zurueckLESEN — und ohne Rueckleseweg bleibt
 *       er in F0 (kein Spiegel) und in der Anlaufsperre (keine Patientendaten).
 *   (2) Jeder Publisher bekommt eine EIGENE Stationskennung ueber eine eigene station-id.json im
 *       Temp-Verzeichnis. Sonst legte der Test eine Kennung im Projekt an (data/station-id.json),
 *       und alle Publisher schrieben in denselben Saalzweig.
 *   (3) Pfadausdruecke in den Bloecken 2, 5, 10, 11, 13, 13b, 13c und 13d zeigen auf den neuen
 *       Ort. Die AUSSAGE jeder dieser Pruefungen ist unveraendert; wo sie schaerfer werden
 *       konnte, ist sie schaerfer geworden (z. B. "kein Top-Level-patients im Koerper").
 *       Jede dieser Stellen ist mit "UMBAU-PFAD" gekennzeichnet.
 *   (4) Der Tafeltakt steht in den alten Bloecken auf 60 s. Sie zaehlen Schreibvorgaenge, und ein
 *       dazwischenfunkender Herzschlag machte die Zahlen von der Uhr abhaengig. Der Tafeltakt hat
 *       seinen eigenen Block (16) und wird dort scharf geprueft.
 */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { CloudPublisher, sanitizeKey } = require('../bridge/src/cloud');
const tafel = require('../bridge/src/tafel');
// Fuer die NAHT zum Saalnamen (N10): der Publisher muss den GESETZTEN Namen aus dieser einen
// Quelle holen, nicht cfg.station aus devices.json. Geprueft wird das mit einer echten Stationsid.
const stationsidModul = require('../bridge/src/stationsid');

let pass = 0, fail = 0;
function ok(name, cond, extra) { if (cond) { pass++; console.log('  ✓ ' + name); } else { fail++; console.log('  ✗ ' + name + (extra ? '  -> ' + extra : '')); } }
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }
/*
 * Warten, bis die Stationskennung steht.
 * Sie wird beim Anmelden (bzw. beim Start) aus einer Datei gelesen oder abgeleitet — das ist ein
 * Vorgang mit Datei- und ggf. Registryzugriff und damit nicht sofort fertig. OHNE Kennung schreibt
 * der Publisher absichtlich GAR NICHTS: jeder neue Pfad beginnt mit ihr, und eine geratene waere
 * ein Schreibvorgang in einen fremden Saal. Im Betrieb faellt das nicht auf (publish() laeuft
 * mehrmals je Sekunde), in einem Test mit genau EINEM publish() schon.
 */
async function bereit(p) {
  for (let i = 0; i < 300 && !p.status(true).sid; i++) await wait(10);
  return p.status(true).sid;
}
/*
 * Warmlaufen: EIN Takt ohne Patienten, danach steht die Antwort des Rueckleseweges.
 * Grund ist die Sperre aus Nachbesserung N1 — vor dem ersten Rueckleseweg ist eine doppelte
 * Stationskennung weder bewiesen noch ausgeschlossen, und dann gehen ausdruecklich KEINE
 * Patientendaten raus. In der Praxis dauert das einen Takt (publish laeuft mehrmals je Sekunde);
 * hier muss ein Test, der etwas anderes messen will, ihn ausdruecklich abwarten.
 */
async function warmlaufen(p) {
  await bereit(p);
  p.publish([], []);
  for (let i = 0; i < 200 && p.status(true).saal.sperre === 'unbekannt'; i++) await wait(10);
  // Und die Drosselung abwarten: publish() laesst hoechstens alle minIntervalMs (Untergrenze
  // 100 ms) einen Takt durch. Ohne diese Wartezeit verwirft der naechste Aufruf sich selbst, und
  // der Test wartete auf einen Schreibvorgang, den er verhindert hat.
  await wait(160);
  return p.status(true).saal.sperre;
}

/*
 * EIGENE STATIONSKENNUNG JE PUBLISHER.
 * Ohne eine vorgelegte Datei leitet stationsid.js die Kennung aus der Windows-Geraete-ID und dem
 * Rechnernamen ab — auf EINEM Rechner also fuer alle Publisher dieselbe. Der Test braucht aber
 * unterscheidbare Saele (und darf ausserdem nichts im Projektordner anlegen). Deshalb wird je
 * Publisher eine station-id.json im Temp-Verzeichnis hinterlegt; istBrauchbar() verlangt nur eine
 * formgueltige sid, alles andere zieht laden() selbst nach.
 */
const TMP = os.tmpdir();
const stationsDateien = [];
function stationsDatei(sid) {
  const p = path.join(TMP, 'vetstation-cloudtest-station-' + sid + '-' + process.pid + '.json');
  fs.writeFileSync(p, JSON.stringify({ sid: sid, quelle: 'test', erzeugt: null, instanzen: [] }), 'utf8');
  stationsDateien.push(p);
  return p;
}
function stationsDateienWeg() { stationsDateien.forEach((p) => { try { fs.unlinkSync(p); } catch (_) {} }); }

// Die Saele dieses Tests. Feste Kennungen, weil sie als Pfadsegment in jeder Erwartung vorkommen.
/*
 * DIE ERSTEN SECHS HEXZEICHEN MUESSEN SICH UNTERSCHEIDEN, nicht die letzten: aus ihnen entsteht der
 * Praefix des Kompatibilitaetsspiegels (s<sid6>__<key>). Zwei Saele mit gleichem sid6 schrieben
 * dort uebereinander — genau der Schaden, den der Praefix verhindern soll. Nachgemessen: mit
 * Kennungen, die sich erst am Ende unterscheiden, ueberschrieb dieser Test den Spiegel des
 * "fremden" Saals und meldete einen Fehler, den es im Code nicht gab.
 */
const SID = {
  haupt: 'sta1a1a1000001', kurven: 'sta2a2a2000002', stamm: 'sta3a3a3000003',
  archiv: 'sta4a4a4000004', neustart: 'sta5a5a5000005', saal: 'sta6a6a6000006',
  sperre: 'sta7a7a7000007', tafel: 'sta8a8a8000008', fehler: 'sta9a9a9000009',
  uhr: 'stb1b1b1000011', herz: 'stb2b2b2000012',
  // Nachbesserungsrunde 30.07.2026 (Befunde C1, C2, C3, C6 und die Naht zum Saalnamen).
  werte: 'stc1c1c1000021', wechsel: 'stc2c2c2000022', drossel: 'stc3c3c3000023',
  rest: 'stc4c4c4000024', name: 'stc5c5c5000025',
  /* 17.08.2026: eigene Kennung fuer die Karteileiche im TAFELZWEIG. Bewusst nicht SID.tafel —
   * die wird oben schon beschrieben, und ein geteilter Zweig liesse den Test aus dem falschen
   * Grund gruen oder rot werden. */
  tafelrest: 'stc6c6c6000026',
  fremd: 'stf0f0f0000099',
};
const SID6 = (sid) => sid.slice(2, 8);   // wie stationsid.sidKurz() fuer die Grundform

// ---- Mock-"Firebase" ----
// writes[] faengt PUT (Vollbild) UND PATCH (Delta) — seit 27.07.2026 schreibt der Publisher nach
// dem ersten Vollbild nur noch die geaenderten Pfade. puts[] bleibt PUT-only, damit die
// Vollbild-Pruefungen unveraendert aussagekraeftig sind.
const captured = { signups: 0, refreshes: 0, puts: [], writes: [], firestore: [], signins: [],
  shallowGets: [], abgelehnt: [], liest: [] };
// Schalter fuer die nachgebaute Unveraenderlichkeits-Regel (siehe PATCH-Zweig unten).
const regel = { streng: false, vorhanden: {} };
/*
 * Schalter fuer eine ABGEWIESENE TAFEL. Genau so verhaelt sich die echte Datenbank, wenn eine
 * Regel im Tafelzweig nicht passt: HTTP 401 "Permission denied". Ohne diesen Schalter liesse sich
 * die wichtigste Zusage des Umbaus nicht pruefen — dass ein Tafelfehler die Vitaluebertragung
 * NICHT abschaltet (frueher haetten drei davon genau das getan).
 *
 * UND DIE GEGENRICHTUNG (Befund C1, ergaenzt 30.07.2026): 'werte' weist den WERT-Zweig eines
 * bestimmten Saals ab (saele/<sid>/patients/...). Ohne diesen Schalter konnte kein Test der Datei
 * die schwerere Haelfte der Trennung ueberhaupt erzeugen — und genau die fehlte: ein Fehler auf dem
 * Wert-Weg nahm Tafel, Spiegel, Protokoll und Archiv mit, der laufende OP-Saal verschwand von jedem
 * anderen Bildschirm, und die Pruefungen blieben alle gruen.
 *   werteCode 401 = Regelablehnung (nicht selbstheilend -> zaehlt auf konfigFehler),
 *   werteCode 500 = Serverfehler   (selbstheilend    -> nur wachsende Wartezeit).
 * Beide Faelle waren gemessen gleich toedlich fuer den Herzschlag, also muessen beide geprueft sein.
 *
 * 'altbestand' laesst den einmaligen Blick auf die eigenen Reste fehlschlagen (Befund C6) — eine
 * kurze Leitungsstoerung genau beim Start. Er ist der Ersatz fuer die gestrichene persistente
 * Schluesselliste aus N7, und wenn er lautlos ausfaellt, bleibt die Karteileiche stehen, gegen die
 * er gebaut ist.
 */
const ablehnen = { tafel: false, werte: null, werteCode: 401, altbestand: null };
/*
 * EIN LANGSAMER WERT-SCHREIBVORGANG. Nicht jeder Ausfall ist eine Ablehnung: das haeufigere und
 * unauffaelligere ist eine Leitung, die haengt — cloud.js bricht erst nach 8 s ab. Wurde Weg L
 * abgewartet, hing der HERZSCHLAG genauso lange mit, ohne dass irgendwo ein Fehler stand.
 * Nachgebildet wird nur die ANTWORT verzoegert; geschrieben ist der Koerper sofort, denn genau so
 * verhaelt sich eine Datenbank hinter einer lahmen Leitung.
 */
const langsam = { werte: null, ms: 0 };
/*
 * EIN ZWILLING, der wirklich laeuft. Er schreibt seine eigene Instanz in denselben Kennungsknoten,
 * unmittelbar NACH jedem Schreibvorgang der Station. Ohne diese Nachbildung waere die Erkennung
 * nicht pruefbar: die Station ueberschreibt den Knoten in jedem Tafeltakt selbst und laese beim
 * naechsten Blick immer nur sich selbst zurueck — ein Zwilling, der einmal etwas hineinschreibt
 * und dann schweigt, ist kein Zwilling, sondern ein toter Vorgaenger.
 */
const zwilling = { sid: null, instanz: 'dead0000dead0001' };
/*
 * DIE UHR DER DATENBANK. Sie geht um versatzMs anders als die dieses PCs — genau der Fall, den
 * eine Praxis mit leerer CMOS-Batterie oder ohne Zeitserver hat. Die Datenbank setzt damit ihre
 * Date-Kopfzeile UND die aufgeloesten Serverplatzhalter; beides muss zusammenpassen, sonst misst
 * der Test eine Unstimmigkeit, die es in der echten Datenbank nicht gibt.
 */
const uhr = { versatzMs: 0 };
function serverJetzt() { return Date.now() + uhr.versatzMs; }

/* ==========================================================================================
 * EINE KLEINE ECHTE DATENBANK
 *
 * Der Publisher LIEST ab 1.1.0 zurueck: seinen eigenen Tafelkopf (steht dort ein Zwilling?), das
 * flache meta (schreibt hier eine 1.0.3?) und die Koepfe der Nachbarsaele. Ein Mock, der auf jedes
 * GET dasselbe antwortet, koennte davon nichts pruefen — und ein Mock, der gar nicht antwortet,
 * laesst den Publisher fuer immer in F0 stehen und macht jede Spiegelpruefung wertlos.
 * Nachgebildet ist deshalb genau das Verhalten, auf das sich cloud.js verlaesst:
 *   • ein PATCH-Schluessel ist ein PFAD ("a/b/c") und ersetzt genau diesen Teilbaum,
 *   • ein null LOESCHT den Schluessel (es gibt kein leeres Feld),
 *   • ?shallow=true liefert nur die Schluessel, nicht die Inhalte,
 *   • ein fehlender Knoten antwortet mit null, nicht mit 404.
 * ========================================================================================== */
const DB = {};
function dbSetze(baum, segs, wert) {
  if (!segs.length) return;
  let cur = baum;
  for (let i = 0; i < segs.length - 1; i++) {
    if (!cur[segs[i]] || typeof cur[segs[i]] !== 'object') cur[segs[i]] = {};
    cur = cur[segs[i]];
  }
  const letzt = segs[segs.length - 1];
  if (wert === null || wert === undefined) delete cur[letzt];
  else cur[letzt] = dbWert(wert);
}
/*
 * Was von einem JSON-Wert in der Datenbank wirklich ankommt: null-Kinder verschwinden, ein Objekt
 * ohne ueberlebende Kinder verschwindet mit — und der SERVERPLATZHALTER wird zur Serverzeit.
 *
 * Der Platzhalter {".sv":"timestamp"} ist kein Wert, sondern ein Auftrag: die Datenbank setzt beim
 * Schreiben IHRE Zeit ein. Wer ihn im Mock als Objekt liegen laesst, misst etwas anderes als das
 * Feld — nachgemessen: die Station las ihr eigenes qs-Kind als Objekt zurueck, hielt es fuer "nicht
 * frisch" und erklaerte sich selbst zur fremden Fassung 1.0.3 (F1). Der Kompatibilitaetsspiegel
 * blieb danach dauerhaft aus, und keine Pruefung dieser Datei haette den Grund nennen koennen.
 */
function dbWert(x) {
  if (x === null || x === undefined) return undefined;
  if (typeof x !== 'object') return x;
  if (!Array.isArray(x) && x['.sv'] === 'timestamp') return serverJetzt();
  const out = Array.isArray(x) ? [] : {};
  let n = 0;
  Object.keys(x).forEach((k) => { const v = dbWert(x[k]); if (v !== undefined) { out[k] = v; n++; } });
  if (Array.isArray(x)) return out;
  return n ? out : undefined;
}
function dbHole(baum, segs) {
  let cur = baum;
  for (const s of segs) {
    if (!cur || typeof cur !== 'object') return null;
    cur = cur[s];
  }
  return cur === undefined ? null : cur;
}
function dbPfad(url) {
  const ohneAbfrage = String(url).split('?')[0].replace(/\.json$/, '');
  return ohneAbfrage.split('/').filter((x) => x !== '');
}
// Die Unveraenderlichkeits-Regel trifft BEIDE Orte: saele/<sid>/protokoll/... und protokoll/...
// Verglichen wird deshalb an der logischen Form protokoll/<pid>/<ts>.
function protokollForm(pfad) {
  const m = /(?:^|\/)(protokoll\/[^/]+\/\d+)$/.exec(String(pfad));
  return m ? m[1] : null;
}
const srv = http.createServer((req, res) => {
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    if (req.url.startsWith('/identity')) {
      // Praxis-Anmeldung mit E-Mail + Passwort (accounts:signInWithPassword).
      let m = null; try { m = JSON.parse(body); } catch (_) {}
      captured.signins.push(m);
      if (!m || !m.email || !m.password) { res.writeHead(400); return res.end('{"error":{"message":"MISSING_PASSWORD"}}'); }
      if (m.password !== 'geheim123') { res.writeHead(400); return res.end('{"error":{"message":"INVALID_LOGIN_CREDENTIALS"}}'); }
      captured.signups++;
      return json(res, { idToken: 'IDTOKEN_1', refreshToken: 'REFRESH_1', localId: 'UIDPRAXIS1', email: m.email, expiresIn: '3600' });
    }
    if (req.url.startsWith('/token')) {
      captured.refreshes++;
      return json(res, { id_token: 'IDTOKEN_REFRESHED', refresh_token: 'REFRESH_1', user_id: 'UIDPRAXIS1', expires_in: '3600' });
    }
    if (req.url.indexOf('/projects/') >= 0 && req.url.indexOf('/documents/') >= 0) {
      let parsed = null; try { parsed = JSON.parse(body); } catch (_) {}
      captured.firestore.push({ url: req.url, body: parsed, auth: req.headers.authorization || null });
      return json(res, { name: 'doc/1' });
    }
    /*
     * FLACHER BLICK auf schon vorhandene Protokoll-Zeitpunkte (?shallow=true).
     * Die echte Datenbank liefert dabei nur die Schluessel. Der Publisher benutzt das, um nach
     * einer Ablehnung NACHZUSEHEN, statt zu raten, welche Zeilen schon dort liegen.
     * UMBAU-PFAD: nachgesehen wird jetzt im Saalzweig (saele/<sid>/protokoll/<pid>) — dort liegt
     * ab 1.1.0 das fuehrende Protokoll. Die Regel selbst ist dieselbe geblieben.
     */
    if (req.method === 'GET' && /\/protokoll\/[^/]+\.json/.test(req.url) && /shallow=true/.test(req.url)) {
      const m = /\/protokoll\/([^/.?]+)\.json/.exec(req.url);
      const out = {};
      if (m) {
        Object.keys(regel.vorhanden).forEach((k) => {
          const mm = new RegExp('^protokoll/' + m[1] + '/(\\d+)$').exec(k);
          if (mm) out[mm[1]] = true;
        });
      }
      captured.shallowGets.push(req.url);
      return json(res, Object.keys(out).length ? out : null);
    }
    /*
     * LESEN. Ohne diesen Zweig bliebe der Publisher dauerhaft in F0 (kein Spiegel) und in der
     * Anlaufsperre (keine Patientendaten) — beides waere ein Test, der die Neuerung gar nicht
     * erreicht.
     */
    if (req.method === 'GET' && req.url.indexOf('/live/') >= 0) {
      /*
       * Der einmalige Blick auf die eigenen Reste faellt aus (siehe 'ablehnen.altbestand').
       * Getroffen wird ausdruecklich NUR die eine der vier Abfragen: so wird geprueft, dass ein
       * teilweiser Fehlschlag den ganzen Blick als "nicht erledigt" gelten laesst — ein halb
       * gelesener Altbestand ist schlimmer als gar keiner, weil er sich fuer vollstaendig haelt.
       */
      if (ablehnen.altbestand && /shallow=true/.test(req.url)
          && req.url.indexOf('/saele/' + ablehnen.altbestand + '/patients') >= 0) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end('{"error":"Leitung weg"}');
      }
      const segs = dbPfad(req.url);
      const wert = dbHole(DB, segs);
      captured.liest.push(req.url);
      if (/shallow=true/.test(req.url)) {
        if (!wert || typeof wert !== 'object') return json(res, wert === undefined ? null : wert);
        const flach = {};
        Object.keys(wert).forEach((k) => { flach[k] = true; });
        return json(res, flach);
      }
      return json(res, wert);
    }
    /*
     * EINZELNE Protokollzeile: PUT auf .../protokoll/<Patient>/<Zeitpunkt>.json — der Pfad steht
     * in der Adresse, nicht im Koerper. Der Publisher wechselt darauf, sobald ein gebuendelter
     * Schreibvorgang an der Regel gescheitert ist; nur so ist jede Antwort einer Zeile zuordenbar.
     * Wird als Schreibvorgang mit EINEM Pfad im Koerper protokolliert, damit die Pruefungen
     * unveraendert auf body-Schluessel schauen koennen. Bewusst NICHT in captured.puts: dort
     * stuetzen sich die Vollbild-Pruefungen auf den grossen PUT auf die Wurzel.
     */
    const mEinzel = /\/live\/[^/]+\/((?:saele\/[^/]+\/)?protokoll\/[^/]+\/\d+)\.json/.exec(req.url);
    if (req.method === 'PUT' && mEinzel) {
      let parsed = null; try { parsed = JSON.parse(body); } catch (_) {}
      const pfad = mEinzel[1];
      const form = protokollForm(pfad);
      if (regel.streng && form && regel.vorhanden[form]) {
        captured.abgelehnt.push({ url: req.url, pfade: [pfad] });
        res.writeHead(401, { 'Content-Type': 'application/json' });
        return res.end('{"error":"Permission denied"}');
      }
      if (form) regel.vorhanden[form] = true;
      dbSetze(DB, dbPfad(req.url), parsed);
      const w = {}; w[pfad] = parsed;
      captured.writes.push({ method: 'PUT', url: req.url, body: w, einzeln: true });
      return json(res, parsed);
    }
    if ((req.method === 'PUT' || req.method === 'PATCH') && req.url.indexOf('/live/') >= 0) {
      let parsed = null; try { parsed = JSON.parse(body); } catch (_) {}
      /*
       * UNVERAENDERLICHKEITS-REGEL DER ECHTEN DATENBANK, nachgebaut.
       * ".validate": "!data.exists()" lehnt einen Protokollpfad ab, der schon existiert — auch bei
       * identischem Inhalt. Und weil ein Mehrpfad-PATCH ATOMAR ist, faellt damit der GANZE
       * Schreibvorgang durch, Vitalwerte inbegriffen. Genau diese Kombination hat am 29.07.2026
       * die Fern-Uebertragung nach jedem Neustart abgeschaltet; ohne die Regel im Mock kann kein
       * Test das je bemerken.
       */
      if (ablehnen.tafel && Object.keys(parsed || {}).some((k) => k.indexOf('tafel/') === 0)) {
        captured.abgelehnt.push({ url: req.url, pfade: Object.keys(parsed || {}), tafel: true });
        res.writeHead(401, { 'Content-Type': 'application/json' });
        return res.end('{"error":"Permission denied"}');
      }
      // Die Gegenrichtung: NUR der Wert-Zweig dieses einen Saals wird abgewiesen (Befund C1).
      if (ablehnen.werte && Object.keys(parsed || {})
        .some((k) => k.indexOf('saele/' + ablehnen.werte + '/patients/') === 0)) {
        captured.abgelehnt.push({ url: req.url, pfade: Object.keys(parsed || {}), werte: true });
        if (ablehnen.werteCode === 500) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          return res.end('{"error":"Serverfehler"}');
        }
        res.writeHead(401, { 'Content-Type': 'application/json' });
        return res.end('{"error":"Permission denied"}');
      }
      if (regel.streng) {
        const strittig = Object.keys(parsed || {}).filter((k) => {
          const f = protokollForm(k);
          return f && regel.vorhanden[f];
        });
        if (strittig.length) {
          captured.abgelehnt.push({ url: req.url, pfade: strittig });
          res.writeHead(401, { 'Content-Type': 'application/json' });
          return res.end('{"error":"Permission denied"}');
        }
      }
      Object.keys(parsed || {}).forEach((k) => { const f = protokollForm(k); if (f) regel.vorhanden[f] = true; });
      // Wie die echte Datenbank: der Schluessel eines PATCH ist ein PFAD.
      const wurzel = dbPfad(req.url);
      if (req.method === 'PUT') dbSetze(DB, wurzel, parsed);
      else Object.keys(parsed || {}).forEach((k) => dbSetze(DB, wurzel.concat(k.split('/').filter((x) => x !== '')), parsed[k]));
      // Der Zwilling schreibt unmittelbar danach seine eigene Instanz in denselben Knoten.
      if (zwilling.sid && Object.keys(parsed || {}).some((k) => k === 'tafel/' + zwilling.sid + '/meta')) {
        dbSetze(DB, ['live', 'UIDPRAXIS1', 'tafel', zwilling.sid, 'meta', 'instanz'], zwilling.instanz);
      }
      const w = { method: req.method, url: req.url, body: parsed };
      captured.writes.push(w);
      if (req.method === 'PUT') captured.puts.push(w);
      if (langsam.werte && Object.keys(parsed || {})
        .some((k) => k.indexOf('saele/' + langsam.werte + '/patients/') === 0)) {
        return setTimeout(() => json(res, parsed), langsam.ms);
      }
      return json(res, parsed);
    }
    res.writeHead(404); res.end('nope');
  });
});
// Jede Antwort traegt die Date-Kopfzeile der DATENBANK — daraus misst cloud.js den Uhrenversatz.
function json(res, o) {
  res.writeHead(200, { 'Content-Type': 'application/json', 'Date': new Date(serverJetzt()).toUTCString() });
  res.end(JSON.stringify(o));
}

// hr: erlaubt es, GEZIELT einen einzigen Wert zu aendern — damit laesst sich pruefen, dass das
// Delta wirklich nur den geaenderten Pfad schreibt und nicht wieder den ganzen Baum.
function samplePatients(hr, extra) {
  const p1 = { patientKey: 'sw:hund:22', patientId: 'Bello', species: 'hund', weightKg: 22, isoPct: 2.4,
    devices: [{ deviceId: 'd1', model: 'LifeVet 10C', role: 'combo' }],
    vitals: { hr: hr == null ? 38 : hr, spo2: 88, etco2: 62, af: 8, sys: 84, dia: 46, map: 59, temp: 37.1, ekgRhythm: 'sinusbrady', capnoShape: 'high', pleth: 'weak' },
    ts: 1753600000000 };
  if (extra) Object.assign(p1, extra);
  return [
    p1,
    { patientKey: 'sw:katze:4.2', patientId: 'Minka', species: 'katze', weightKg: 4.2, isoPct: 1.5,
      devices: [{ deviceId: 'd2', model: 'uMEC12 Vet', role: 'monitor' }],
      vitals: { hr: 150, spo2: 98, etco2: 40, af: 18, sys: 120, dia: 80, map: 93, temp: 38.4, ekgRhythm: 'sinus' }, ts: 1753600000000 },
  ];
}

async function run() {
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + srv.address().port;
  const authFile = path.join(os.tmpdir(), 'vetstation-cloudtest-' + Date.now() + '.json');

  console.log('FERN-LIVE Publisher-Selbsttest (Mock-Firebase auf ' + base + ')');

  const pub = new CloudPublisher({
    enabled: true, provider: 'firebase',
    apiKey: 'TEST_KEY', dbUrl: base, station: 'Test-OP',
    minIntervalMs: 800, authFile: authFile,
    identityUrl: base + '/identity', tokenUrl: base + '/token',
    // Siehe Kopf, Punkt (2) und (4): eigene Kennung, und der Herzschlag funkt beim Zaehlen nicht
    // dazwischen. Der Tafeltakt hat seinen eigenen Block.
    stationDatei: stationsDatei(SID.haupt), tafelTaktMs: 60000,
  }, { log: { info() {}, warn() {}, error() {} } });
  // Pfadhilfen: sie stehen EINMAL hier, damit nicht in dreissig Pruefungen dreissig Meinungen
  // darueber entstehen, wie ein Saalpfad geschrieben wird.
  const saalPfad = (sid, key, feld) => 'saele/' + sid + '/patients/' + key + (feld ? '/' + feld : '');
  const spiegelPfad = (sid, key, feld) => 'patients/s' + SID6(sid) + '__' + key + (feld ? '/' + feld : '');
  // Alle Koerper eines Abschnitts, die einen Pfad mit diesem Anfang tragen.
  const koerperMit = (ab, anfang) => captured.writes.slice(ab)
    .filter((w) => Object.keys(w.body || {}).some((k) => k.indexOf(anfang) === 0));

  /* --- 1) OHNE Anmeldung wird NICHTS uebertragen ---------------------------------------------
   * Das ist die wichtigste Zusicherung des Umbaus vom 27.07.2026: Patientendaten verlassen den
   * Praxis-PC erst, wenn sich die Praxis angemeldet hat. Vorher hing der Zugang an einem
   * Zugangscode im Link — jeder, der ihn hatte, konnte mitlesen und sogar Werte faelschen. */
  pub.start();
  ok('ohne Anmeldung startet die Uebertragung NICHT', pub.started === false);
  ok('ohne Anmeldung gilt "nicht angemeldet"', pub.angemeldet() === false);
  pub.publish(samplePatients());
  await wait(200);
  ok('ohne Anmeldung wird NICHTS geschrieben', captured.writes.length === 0, 'writes=' + captured.writes.length);
  ok('Fern-Link enthaelt KEINEN Zugangscode mehr',
    pub.shareUrl().indexOf('live=') < 0 && pub.shareUrl().indexOf('?') < 0, pub.shareUrl());

  // --- 1b) Falsches Passwort: klare Absage, keine halbe Anmeldung ---
  let fehlerText = null;
  try { await pub.anmelden('praxis@test.de', 'falsch'); } catch (e) { fehlerText = e.message; }
  ok('falsches Passwort wird abgelehnt', !!fehlerText, fehlerText);
  ok('nach Fehlversuch weiterhin nicht angemeldet', pub.angemeldet() === false);

  // --- 2) Anmeldung + erste Veroeffentlichung ---
  const st = await pub.anmelden('praxis@test.de', 'geheim123');
  const sidHaupt = await bereit(pub);
  ok('die Station kennt ihre eigene Kennung', sidHaupt === SID.haupt, String(sidHaupt));
  ok('Anmeldung liefert die Praxis-Kennung', st.uid === 'UIDPRAXIS1', st.uid);
  ok('Anmeldung erfolgte mit E-Mail und Passwort',
    captured.signins.some((s) => s && s.email === 'praxis@test.de' && s.password === 'geheim123' && s.returnSecureToken === true));
  ok('nach der Anmeldung laeuft die Uebertragung', pub.started === true && pub.angemeldet() === true);

  const keyHund = sanitizeKey('sw:hund:22');
  /*
   * DER ERSTE TAKT SCHREIBT NOCH KEINE PATIENTENDATEN — und das ist kein Mangel, sondern die
   * Sperre aus Nachbesserung N1: solange nicht ZURUECKGELESEN wurde, ist eine doppelte
   * Stationskennung weder bewiesen noch ausgeschlossen, und zwei geklonte Stationen wuerden zwei
   * Narkosen Feld fuer Feld mischen. Bis dahin geht nur der Kopf tafel/<sid>/meta raus. Der
   * Rueckleseweg wird in genau diesem Takt angestossen und antwortet binnen Millisekunden.
   */
  pub.publish(samplePatients());
  await waitForWrite(1);
  await wait(250);
  ok('vor dem ersten Rueckleseweg wird KEIN Patientendatum geschrieben (Sperre N1, fail-closed)',
    captured.writes.every((w) => Object.keys(w.body).every((k) => k === 'tafel/' + SID.haupt + '/meta')),
    captured.writes.map((w) => Object.keys(w.body).join(',')).join(' | '));
  ok('nach dem ersten Rueckleseweg ist die doppelte Kennung ausgeschlossen',
    pub.status(true).saal.sperre === 'ausgeschlossen', pub.status(true).saal.sperre);
  captured.writes.length = 0;      // ab hier zaehlt der Takt, der die Werte traegt
  await wait(800);
  pub.publish(samplePatients());
  await waitForWrite(1);
  await wait(200);   // die uebrigen Ziele desselben Taktes abwarten
  /*
   * UMBAU-PFAD. Frueher: "genau 1 Schreibvorgang" — es GAB nur einen. Jetzt schreibt der erste Takt
   * die Werte und den Herzschlag als ZWEI Koerper (der Spiegel folgt, sobald der Rueckleseweg
   * geantwortet hat). Die Aussage der Pruefung ist dieselbe geblieben und zusaetzlich um die
   * TRENNUNG erweitert — sie ist der Grund fuer den Umbau: ein abgelehntes Tafelfeld darf die
   * Vitalwerte nicht mitnehmen.
   */
  const werteKoerper = koerperMit(0, 'saele/');
  ok('genau 1 Schreibvorgang mit Vitalwerten', werteKoerper.length === 1,
    'werte=' + werteKoerper.length + ' von ' + captured.writes.length);
  ok('der Wert-Koerper traegt AUSSCHLIESSLICH Saalpfade (Trennung der Ziele)',
    werteKoerper.length === 1 && Object.keys(werteKoerper[0].body).every((k) => k.indexOf('saele/' + SID.haupt + '/') === 0),
    captured.writes.map((w) => Object.keys(w.body)[0]).join(' | '));

  const put = werteKoerper[0];
  /* Der Zielpfad ist die ANMELDE-KENNUNG, nicht mehr ein frei gewaehlter Code. Genau daran haengt
   * die Mandantentrennung: die Regel vergleicht das Pfadsegment mit auth.uid. */
  ok('Zielpfad = /live/<Anmelde-Kennung>', /\/live\/UIDPRAXIS1\.json\?auth=IDTOKEN_1/.test(put.url), put.url);
  ok('geschrieben wird als PATCH (PUT wuerde das Protokoll daneben loeschen)', put.method === 'PATCH', put.method);
  const snap = put.body || {};
  /*
   * UMBAU-PFAD: der Datensatz liegt jetzt unter saele/<sid>/patients/<key>/<feld> — tiefe Pfade
   * statt eines Knotens 'patients'. Die geprueften Felder sind dieselben.
   */
  ok('Patient (Hund) vorhanden unter sanitisiertem Key im EIGENEN Saalzweig',
    !!snap[saalPfad(SID.haupt, keyHund, 'vitals')], Object.keys(snap).slice(0, 4).join(', '));
  const ph = {
    vitals: snap[saalPfad(SID.haupt, keyHund, 'vitals')] || {},
    isoPct: snap[saalPfad(SID.haupt, keyHund, 'isoPct')],
    pri: snap[saalPfad(SID.haupt, keyHund, 'pri')],
    top: snap[saalPfad(SID.haupt, keyHund, 'top')],
  };
  ok('Vitalwerte uebertragen (hr=38, etco2=62)', ph.vitals.hr === 38 && ph.vitals.etco2 === 62);
  ok('MAP uebertragen (59)', ph.vitals.map === 59);
  ok('EKG-Rhythmus uebertragen (sinusbrady)', ph.vitals.ekgRhythm === 'sinusbrady');
  ok('isoPct uebertragen (2.4)', ph.isoPct === 2.4);

  // --- 3) Brain-Enrichment ---
  ok('Brain-Prioritaet vorhanden (pri > 0)', typeof ph.pri === 'number' && ph.pri > 0, ph.pri);
  ok('Top-Befund vorhanden', ph.top && typeof ph.top.title === 'string' && ph.top.title.length > 0, ph.top && ph.top.title);
  ok('Top-Befund hat Schweregrad (sev)', ph.top && ph.top.sev >= 1, ph.top && ph.top.sev);

  // --- 4) Throttle: sofortiger zweiter publish darf NICHT schreiben ---
  const before = captured.writes.length;
  pub.publish(samplePatients());
  await wait(150);
  ok('Throttle: kein zweiter Schreibvorgang innerhalb minInterval', captured.writes.length === before, 'writes=' + captured.writes.length);

  // --- 5) Nach Ablauf des Intervalls mit GEAENDERTEM Wert: PATCH nur des geaenderten Pfades ---
  // Kernzusage des Umbaus vom 27.07.2026: nach dem ersten Vollbild wird nur noch das Delta
  // geschrieben. Wuerde hier wieder der ganze Baum gehen, waere der schnelle Takt unbezahlbar.
  await wait(800);
  pub.publish(samplePatients(44));
  await waitForWrite(before + 1);
  const delta = koerperMit(before, 'saele/')[0] || { body: {} };
  ok('nach Intervall: weiterer Schreibvorgang mit Vitalwerten', !!delta.method, 'writes=' + captured.writes.length);
  ok('Delta wird als PATCH geschrieben (nicht PUT)', delta.method === 'PATCH', delta.method);
  const dKeys = Object.keys(delta.body || {});
  // UMBAU-PFAD: der Herzschlag steckt nicht mehr in diesem Koerper (er hat einen eigenen Takt und
  // ein eigenes Ziel), deshalb bleibt hier GENAU der eine geaenderte Pfad uebrig. Die Pruefung ist
  // dadurch schaerfer als vorher (frueher <= 3 Pfade).
  ok('Delta enthaelt nur den geaenderten Pfad (Vitalwerte)',
    dKeys.length === 1 && dKeys[0] === saalPfad(SID.haupt, keyHund, 'vitals'), dKeys.join(', '));
  ok('Delta enthaelt NICHT den unveraenderten zweiten Patienten',
    !dKeys.some((k) => k.indexOf(sanitizeKey('sw:katze:4.2')) >= 0), dKeys.join(', '));
  ok('Delta traegt den neuen Wert (hr=44)',
    delta.body[saalPfad(SID.haupt, keyHund, 'vitals')] && delta.body[saalPfad(SID.haupt, keyHund, 'vitals')].hr === 44);
  ok('keine erneute Anmeldung (Token gueltig)', captured.signups === 1, 'signups=' + captured.signups);

  // --- 5b) Unveraenderte Daten: gar kein Schreibvorgang (ausser dem Herzschlag alle 2 s) ---
  const vorRuhe = captured.writes.length;
  await wait(800);
  pub.publish(samplePatients(44));
  await wait(200);
  ok('unveraenderte Daten -> kein Schreibvorgang', captured.writes.length === vorRuhe, 'writes=' + captured.writes.length);

  // --- 6) Token-Erneuerung: Ablauf simulieren -> securetoken, KEINE Neuanmeldung ---
  pub.tokenExp = 0; // erzwingt Erneuerung
  await wait(800);
  pub.publish(samplePatients(46));
  await waitForWrite(vorRuhe + 1);
  ok('abgelaufener Token -> Erneuerung (securetoken)', captured.refreshes === 1, 'refreshes=' + captured.refreshes);
  ok('dabei wird das Passwort NICHT erneut gebraucht', captured.signups === 1, 'signups=' + captured.signups);
  const lastWrite = captured.writes[captured.writes.length - 1];
  ok('Schreibvorgang nutzt erneuerten Token', /auth=IDTOKEN_REFRESHED/.test(lastWrite.url), lastWrite.url);
  // Frueher legte der Rueckfall bei verworfenem Token ein NEUES anonymes Konto an - unter
  // uid-gebundenen Regeln waere die Station damit still in einen fremden, leeren Pfad gewandert.
  ok('die Praxis-Kennung bleibt nach der Erneuerung DIESELBE',
    /\/live\/UIDPRAXIS1\.json/.test(lastWrite.url), lastWrite.url);

  // --- 7) Persistenz: Erneuerungs-Token ja, Passwort NIEMALS ---
  let saved = null; try { saved = JSON.parse(fs.readFileSync(authFile, 'utf8')); } catch (_) {}
  ok('Erneuerungs-Token wird gespeichert (ueberdauert Neustarts)', saved && saved.refreshToken === 'REFRESH_1', saved && saved.refreshToken);
  ok('Praxis-Kennung wird gespeichert', saved && saved.localId === 'UIDPRAXIS1', saved && saved.localId);
  ok('das PASSWORT steht NIRGENDS in der Datei',
    JSON.stringify(saved || {}).indexOf('geheim123') < 0, JSON.stringify(saved));

  // --- 8) Status: oeffentlich vs. privat ---
  const stOeff = pub.status();
  const stPriv = pub.status(true);
  ok('Status meldet angemeldet', stOeff.angemeldet === true);
  /* /api/cloud antwortet mit "Access-Control-Allow-Origin: *" - jede fremde Webseite im
   * Praxis-Browser kann das lesen. Anmeldename und Kennung duerfen dort deshalb NICHT stehen. */
  ok('oeffentlicher Status enthaelt KEINE E-Mail', stOeff.email === undefined, JSON.stringify(stOeff.email));
  ok('oeffentlicher Status enthaelt KEINE Praxis-Kennung', stOeff.uid === undefined, JSON.stringify(stOeff.uid));
  ok('privater Status enthaelt beides', stPriv.email === 'praxis@test.de' && stPriv.uid === 'UIDPRAXIS1');

  // --- 9) Abmelden: Uebertragung endet und die gespeicherte Anmeldung ist weg ---
  const vorAbmeldung = captured.writes.length;
  pub.abmelden();
  ok('nach dem Abmelden: nicht mehr angemeldet', pub.angemeldet() === false);
  ok('nach dem Abmelden: Token-Datei geloescht', !fs.existsSync(authFile));
  await wait(900);
  pub.publish(samplePatients(99));
  await wait(200);
  ok('nach dem Abmelden wird NICHTS mehr uebertragen',
    captured.writes.length === vorAbmeldung, 'writes=' + captured.writes.length);

  // --- 10) ECHTE KURVEN: kodiert, und je Streifen nur EINMAL uebertragen ---
  // Ohne die "nur bei geaenderter Signatur"-Regel wuerde ein 512-Werte-EKG in JEDEM Takt neu
  // gesendet — bei 200 ms Takt waere das Freikontingent in wenigen Tagen aufgebraucht.
  const streifen = [{ code: 'ECG_I', name: 'EKG I', hz: 256, samples: Array.from({ length: 512 }, (_, i) => Math.sin(i / 8) * 900) }];
  const pubK = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'K', minIntervalMs: 1, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.k', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.kurven), tafelTaktMs: 60000 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubK.anmelden('kurven@test.de', 'geheim123');
  await warmlaufen(pubK);
  const w0 = captured.writes.length;
  pubK.publish(samplePatients(38, { kurvenDaten: streifen }));
  await waitForWrite(w0 + 1);
  // UMBAU-PFAD: Kurven liegen unter saele/<sid>/patients/<key>/kurven statt unter patients/<key>.
  const kPut = koerperMit(w0, 'saele/')[0] || { body: {} };
  const kRec = {
    kurvenSig: kPut.body[saalPfad(SID.kurven, keyHund, 'kurvenSig')],
    kurven: kPut.body[saalPfad(SID.kurven, keyHund, 'kurven')],
  };
  ok('Kurven-Signatur wird uebertragen', !!kRec.kurvenSig, kRec.kurvenSig);
  ok('Kurven-Abtastwerte werden uebertragen', !!(kRec.kurven && kRec.kurven.ECG_I), Object.keys(kRec.kurven || {}).join(','));
  const kanal = kRec.kurven && kRec.kurven.ECG_I;
  ok('Kurve ist Int16+Base64 kodiert (nicht als Zahlenliste)', !!(kanal && typeof kanal.b64 === 'string' && kanal.n === 512));
  ok('Kurve ist kompakter als die JSON-Zahlenliste',
    kanal && kanal.b64.length < JSON.stringify(streifen[0].samples).length,
    kanal && (kanal.b64.length + ' vs ' + JSON.stringify(streifen[0].samples).length));
  // Dekodieren und mit dem Original vergleichen — die Kurve muss klinisch unveraendert ankommen.
  const roh = Buffer.from(kanal.b64, 'base64');
  let maxAbw = 0;
  for (let i = 0; i < 512; i++) {
    const abw = Math.abs(roh.readInt16LE(i * 2) * kanal.skala - streifen[0].samples[i]);
    if (abw > maxAbw) maxAbw = abw;
  }
  ok('dekodierte Kurve weicht < 0,1 uV ab (verlustfrei genug)', maxAbw < 0.1, 'max ' + maxAbw.toFixed(4));

  const w1 = captured.writes.length;
  await wait(140);   // > minInterval (Untergrenze 100 ms), sonst greift die Drosselung
  pubK.publish(samplePatients(39, { kurvenDaten: streifen }));   // Puls geaendert, Streifen gleich
  await waitForWrite(w1 + 1);
  const kDelta = koerperMit(w1, 'saele/')[0] || { body: {} };
  ok('unveraenderter Streifen wird NICHT erneut uebertragen',
    !Object.keys(kDelta.body).some((k) => /\/kurven$/.test(k)), Object.keys(kDelta.body).join(', '));
  // Die Kurve ist der groesste Wert im ganzen Baum. Die gemeinsame Kappung (N9) darf sie deshalb
  // NICHT anfassen — 200 Zeichen wuerden sie nicht kuerzen, sondern zerstoeren.
  ok('die gemeinsame Kappung laesst die Abtastwerte unangetastet (kein 200-Zeichen-Schnitt)',
    kanal && kanal.b64.length > 1000 && kanal.n === 512, kanal && kanal.b64.length);

  /* --- 11) Stammdaten: jetzt standardmaessig AN, weil sie im EIGENEN Konto liegen ------------
   * Solange der Fern-Zugang an einem weiterleitbaren Link hing, waeren Tiername und Besitzerdaten
   * dort falsch aufgehoben gewesen. Seit die Daten ausschliesslich unter der Anmelde-Kennung der
   * eigenen Praxis liegen und nur diese Praxis sie lesen kann, gehoert der Tiername aufs
   * Protokoll — ein Narkoseprotokoll ohne Patientennamen waere als Dokument wertlos.
   * Abschaltbar bleibt es trotzdem, und das wird hier ausdruecklich geprueft. */
  ok('Stammdaten sind standardmaessig AN (eigenes Konto)', pubK.sendeStammdaten === true);
  const pubS = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'S', minIntervalMs: 1, stammdaten: false, archiv: { enabled: false },
    authFile: authFile + '.s', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.stamm), tafelTaktMs: 60000 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubS.anmelden('stamm@test.de', 'geheim123');
  await warmlaufen(pubS);
  const w2 = captured.writes.length;
  pubS.publish([Object.assign(samplePatients()[0], { patientName: 'Bello', akte: { besitzer: 'Muster' } })]);
  await waitForWrite(w2 + 1);
  // UMBAU-PFAD: die Felder sind jetzt einzelne Pfade unter dem eigenen Saal, kein Objekt mehr.
  const sBody = (koerperMit(w2, 'saele/')[0] || { body: {} }).body;
  ok('mit cloud.stammdaten=false bleibt der Tiername DRAUSSEN',
    !(saalPfad(SID.stamm, keyHund, 'patientName') in sBody), Object.keys(sBody).join(','));
  ok('mit cloud.stammdaten=false bleibt die Patientenakte DRAUSSEN',
    !(saalPfad(SID.stamm, keyHund, 'akte') in sBody));

  const w2b = captured.writes.length;
  await wait(140);
  pubK.publish([Object.assign(samplePatients()[0], { patientName: 'Bello', akte: { besitzer: 'Muster' } })]);
  await waitForWrite(w2b + 1);
  const kBody = (koerperMit(w2b, 'saele/')[0] || { body: {} }).body;
  const kName = kBody[saalPfad(SID.kurven, keyHund, 'patientName')];
  ok('mit der Voreinstellung wird der Tiername uebertragen', kName === 'Bello', String(kName));

  // --- 12) Firestore-Verlauf ---
  const fs0 = captured.firestore.length;
  const pubA = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'A', minIntervalMs: 1, firestoreUrl: base,
    authFile: authFile + '.a', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.archiv), tafelTaktMs: 60000,
    archiv: { enabled: true, intervalMs: 5000, projectId: 'vet-station' } }, { log: { info() {}, warn() {}, error() {} } });
  await pubA.anmelden('archiv@test.de', 'geheim123');
  await warmlaufen(pubA);
  pubA.publish(samplePatients());
  await new Promise((resolve, reject) => {
    const t0 = Date.now();
    (function poll() {
      if (captured.firestore.length > fs0) return resolve();
      if (Date.now() - t0 > 5000) return reject(new Error('Timeout: kein Firestore-Schreibvorgang'));
      setTimeout(poll, 20);
    })();
  });
  const fdoc = captured.firestore[fs0];
  ok('Firestore-Verlauf liegt unter praxen/<Anmelde-Kennung>/verlauf',
    /\/documents\/praxen\/UIDPRAXIS1\/verlauf/.test(fdoc.url), fdoc.url);
  // Frueher genuegte der oeffentliche API-Schluessel — der steht auch in der oeffentlichen
  // Web-App, also konnte jeder Fremde Dokumente anlegen und das Kontingent ALLER Praxen sprengen.
  ok('Firestore-Verlauf wird MIT Anmeldung geschrieben (Bearer-Kopfzeile)',
    fdoc.auth === 'Bearer IDTOKEN_1', String(fdoc.auth));
  ok('Firestore-Verlauf: Station + Patientenzahl als eigene Felder',
    fdoc.body.fields.station.stringValue === 'A' && fdoc.body.fields.patienten.integerValue === '2');
  ok('Firestore-Verlauf traegt KEINEN Zugangscode mehr', fdoc.body.fields.code === undefined);
  const archDaten = JSON.parse(fdoc.body.fields.daten.stringValue);
  ok('Firestore-Verlauf: Vitalwerte im Datensatz', archDaten.patients[keyHund].vitals.hr === 38);
  ok('Firestore-Verlauf: Kurven NICHT im Archiv (Dokumentgroesse)', !archDaten.patients[keyHund].kurven);

  // --- 13) OP-Protokoll: EINZELNE, unveraenderliche Pfade — und ein EIGENER Schreibvorgang ---
  const w3 = captured.writes.length;
  await wait(140);
  /* Der Zeitpunkt muss NACH dem Start dieses Publishers liegen, sonst gilt er als Altzeile
   * (Reparatur vom 30.07.2026, siehe cloud.js bei prozessStart). Bewusst aus Date.now() und NICHT
   * aus pub.prozessStart: dieses Feld gibt es in der alten Fassung nicht, und der Test soll dort
   * den ECHTEN Befund zeigen und nicht an einem NaN scheitern. */
  const tsNeu = Date.now();
  /*
   * UMBAU-PFAD fuer den ganzen Block 13: eine Protokollzeile liegt jetzt unter
   * saele/<sid>/protokoll/<pid>/<ts>. Die Aussagen sind Wort fuer Wort dieselben geblieben; nur
   * der Ort, an dem nachgesehen wird, ist der neue. Der Koerper wird ausserdem GESUCHT statt an
   * Position [1] erwartet — es koennen mehrere Ziele im selben Takt schreiben, und eine Pruefung,
   * die an einer Reihenfolge haengt, misst irgendwann die Uhr statt die Sache.
   */
  const protPfad = 'saele/' + SID.kurven + '/protokoll/Bello/' + tsNeu;
  const istProtokoll = (k) => /(?:^|\/)protokoll\//.test(k);
  pubK.publish(samplePatients(41), [], { 'Bello': [{ ts: tsNeu, hr: 41, finding: 'Bradykardie' }] });
  await warteAufWrite(w3 + 2, 1500);
  const neu13 = captured.writes.slice(w3);
  const vitalBody = (koerperMit(w3, 'saele/' + SID.kurven + '/patients/')[0] || { body: {} }).body;
  const protBody = (neu13.filter((w) => Object.keys(w.body || {}).some(istProtokoll))[0] || { body: {} }).body;
  /*
   * DIE WICHTIGSTE PRUEFUNG DIESES BLOCKS: Werte und Protokoll duerfen NICHT im selben
   * Schreibvorgang liegen. Bis 1.0.3 lagen sie es — und weil ein Mehrpfad-PATCH atomar ist, nahm
   * eine abgelehnte Protokollzeile alle Vitalwerte mit. Das Protokoll ist Dokumentation, die
   * Vitalwerte sind die Ueberwachung; die Dokumentation darf die Ueberwachung nie ausbremsen.
   */
  ok('Vitalwerte und Protokoll gehen in GETRENNTEN Schreibvorgaengen',
    neu13.length >= 2 && Object.keys(vitalBody).length > 0 && !Object.keys(vitalBody).some(istProtokoll),
    neu13.length + ' Schreibvorgang/-vorgaenge: ' + neu13.map((w) => Object.keys(w.body).join(',')).join(' | '));
  ok('Protokolleintrag geht als eigener Pfad protokoll/<Patient>/<Zeitpunkt>',
    !!protBody[protPfad], Object.keys(protBody).join(', '));
  ok('Protokolleintrag traegt die Werte',
    !!protBody[protPfad] && protBody[protPfad].hr === 41);
  ok('der Protokoll-Schreibvorgang enthaelt NUR Protokollpfade',
    Object.keys(protBody).length > 0 && Object.keys(protBody).every(istProtokoll), Object.keys(protBody).join(', '));
  // Ein zweites Mal derselbe Eintrag darf NICHT erneut uebertragen werden - sonst wuechse die
  // Datenmenge mit jedem Takt, und die Regel ".validate: !data.exists()" wuerde ihn ablehnen.
  const w4 = captured.writes.length;
  await wait(140);
  pubK.publish(samplePatients(42), [], { 'Bello': [{ ts: tsNeu, hr: 41, finding: 'Bradykardie' }] });
  await warteAufWrite(w4 + 1, 1500);
  ok('bereits gesendeter Protokolleintrag wird NICHT wiederholt',
    !captured.writes.slice(w4).some((w) => Object.keys(w.body).some(istProtokoll)),
    captured.writes.slice(w4).map((w) => Object.keys(w.body).join(',')).join(' | '));

  /* --- 13b) DER NEUSTART BEI LAUFENDER NARKOSE ---------------------------------------------
   *
   * Der Fehler, den dieser Block fuer immer festnagelt (bestaetigt am 30.07.2026):
   * registry laedt das Protokoll beim Start aus bridge\data\protokoll.json — die Datei ueberdauert
   * jeden Neustart. Die Merkliste im Publisher ueberdauerte ihn NICHT. Die Station bot deshalb nach
   * jedem Neustart alle alten Zeilen erneut an, die Unveraenderlichkeits-Regel lehnte ab, der
   * atomare PATCH nahm die Vitalwerte mit, HTTP 401 zaehlte als Konfigurationsfehler — und nach
   * drei Versuchen (rund 30 Sekunden) schaltete sich die Fern-Uebertragung dieser Station ab.
   * Ein Neustart half nicht: er stellte genau denselben Zustand wieder her.
   *
   * Die alte Fassung faellt hier mit "started" === false durch.
   */
  regel.streng = true;
  const alteZeilen = {
    'Bello': [
      { ts: 1753600001000, hr: 41, finding: 'Bradykardie' },   // lange vor jedem Prozessstart
      { ts: 1753600002000, hr: 42 },
      { ts: 1753600003000, hr: 43 },
    ],
  };
  // Diese Zeilen liegen bereits in der Datenbank — genau wie nach einer schon laufenden Narkose.
  Object.keys(alteZeilen.Bello).forEach((i) => {
    regel.vorhanden['protokoll/Bello/' + alteZeilen.Bello[i].ts] = true;
  });

  const pubR = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'R', minIntervalMs: 1, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.r', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.neustart), tafelTaktMs: 60000 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubR.anmelden('neustart@test.de', 'geheim123');
  await warmlaufen(pubR);
  const w5 = captured.writes.length;
  pubR.publish(samplePatients(55), [], alteZeilen);
  const kamAn = await warteAufWrite(w5 + 1, 2000);
  // UMBAU-PFAD: nachgesehen wird im Wert-Koerper dieses Saals.
  const rBody = (koerperMit(w5, 'saele/' + SID.neustart + '/patients/')[0] || { body: {} }).body;
  ok('nach dem Neustart kommt UEBERHAUPT ein Schreibvorgang durch', kamAn,
    'abgelehnt: ' + JSON.stringify(captured.abgelehnt.slice(0, 1)));
  ok('nach dem Neustart werden ALTE Protokollzeilen nicht erneut angeboten',
    !captured.writes.slice(w5).some((w) => Object.keys(w.body).some(istProtokoll)),
    captured.writes.slice(w5).map((w) => Object.keys(w.body).join(',')).join(' | '));
  ok('die Vitalwerte kommen nach dem Neustart durch',
    !!rBody[saalPfad(SID.neustart, keyHund, 'vitals')], Object.keys(rBody).join(', '));
  ok('die alten Zeilen sind als erledigt vermerkt', pubR._altzeilenUebersprungen === 3,
    String(pubR._altzeilenUebersprungen));

  // Drei weitere Takte: die alte Fassung haette hier bereits abgeschaltet.
  for (let i = 0; i < 3; i++) { await wait(160); pubR.publish(samplePatients(56 + i), [], alteZeilen); }
  await wait(300);
  ok('die Fern-Uebertragung schaltet sich NICHT ab', pubR.started === true && pubR.abgeschaltet === false,
    'started=' + pubR.started + ' abgeschaltet=' + pubR.abgeschaltet);
  ok('kein Konfigurationsfehler gezaehlt', pubR.konfigFehler === 0, String(pubR.konfigFehler));
  ok('die Anmeldung wird nicht faelschlich verworfen', pubR.idToken !== null);
  ok('die Datenbank hat keinen Schreibvorgang abgelehnt', captured.abgelehnt.length === 0,
    JSON.stringify(captured.abgelehnt.slice(0, 2)));

  // Eine NEUE Zeile aus dem laufenden Betrieb muss weiterhin durchgehen.
  const w6 = captured.writes.length;
  const tsFrisch = Date.now() + 1000;
  await wait(160);
  pubR.publish(samplePatients(60), [], {
    'Bello': alteZeilen.Bello.concat([{ ts: tsFrisch, hr: 60, finding: 'Hypotension' }]),
  });
  await warteAufWrite(w6 + 2, 2000);
  ok('eine NEUE Protokollzeile geht trotzdem raus',
    captured.writes.slice(w6).some((w) => !!w.body['saele/' + SID.neustart + '/protokoll/Bello/' + tsFrisch]),
    captured.writes.slice(w6).map((w) => Object.keys(w.body).join(',')).join(' | '));

  /* --- 13c) EIN STRITTIGER PROTOKOLLPFAD DARF DIE WERTE NICHT MITNEHMEN -----------------------
   * Fall: die Zeile ist angekommen, aber die Antwort ging verloren (Leitungsabbruch). Der Publisher
   * haelt sie fuer neu und schickt sie erneut; die Datenbank lehnt ab. Erwartet wird: die
   * Vitalwerte laufen weiter, es wird nachgesehen statt geraten, und nichts schaltet sich ab.
   */
  const tsStrittig = Date.now() + 2000;
  regel.vorhanden['protokoll/Bello/' + tsStrittig] = true;   // "schon da", der Publisher weiss es nicht
  const w7 = captured.writes.length;
  const g0 = captured.shallowGets.length;
  // 160 ms, nicht 60: publish() drosselt auf minInterval, und das hat eine Untergrenze von
  // 100 ms (cloud.js:169). Mit 60 ms wuerde der Takt verworfen und der Test wartete auf einen
  // Schreibvorgang, den er selbst verhindert hat.
  await wait(160);
  pubR.publish(samplePatients(61), [], {
    'Bello': [{ ts: tsStrittig, hr: 61, finding: 'Hypotension' }],
  });
  await warteAufWrite(w7 + 1, 2000);
  await wait(400);
  // UMBAU-PFAD: die Werte liegen im eigenen Saalzweig.
  ok('die Werte kommen an, obwohl der Protokollpfad abgelehnt wird',
    koerperMit(w7, 'saele/' + SID.neustart + '/patients/').length > 0,
    captured.writes.slice(w7).map((w) => Object.keys(w.body).join(',')).join(' | '));
  ok('die Ablehnung betraf NUR den Protokoll-Schreibvorgang',
    captured.abgelehnt.length >= 1 && captured.abgelehnt.every((a) => a.pfade.every(istProtokoll)),
    JSON.stringify(captured.abgelehnt.slice(0, 2)));
  ok('es wird NACHGESEHEN statt geraten (flache Abfrage)', captured.shallowGets.length > g0,
    String(captured.shallowGets.length - g0));
  ok('die Uebertragung laeuft weiter', pubR.started === true && pubR.abgeschaltet === false,
    'started=' + pubR.started + ' abgeschaltet=' + pubR.abgeschaltet);
  ok('der Protokollfehler zaehlt NICHT auf das Konto der Vitalwerte', pubR.konfigFehler === 0,
    String(pubR.konfigFehler));
  ok('der Zustand nennt das Protokoll getrennt', pubR.status(true).protokoll !== undefined
    && pubR.status(true).protokoll.aktiv === true);

  /* --- 13d) NACH DEM STREITFALL: ZEILE FUER ZEILE, DAMIT EINE STRITTIGE KEINE GESUNDE MITNIMMT ---
   * Die Datenbank sagt bei einem Mehrpfad-PATCH NICHT, welcher Pfad abgelehnt wurde. Eine einzige
   * strittige Zeile wuerde also alle anderen im selben Koerper blockieren, und niemand koennte
   * sagen, welche es war. Nach dem ersten Streitfall schreibt der Publisher deshalb einzeln.
   */
  ok('nach dem Streitfall ist der Einzelweg aktiv', pubR.protokollEinzeln === true);
  const w8 = captured.writes.length;
  const tsGesund = Date.now() + 3000;
  await wait(160);
  pubR.publish(samplePatients(62), [], {
    'Bello': [
      { ts: tsStrittig, hr: 61, finding: 'Hypotension' },   // strittig, liegt schon dort
      { ts: tsGesund, hr: 62, finding: 'Hypotension' },     // gesund, muss ankommen
    ],
  });
  await wait(700);
  const neu13d = captured.writes.slice(w8);
  ok('die gesunde Zeile kommt an, obwohl eine strittige daneben liegt',
    neu13d.some((w) => !!w.body['saele/' + SID.neustart + '/protokoll/Bello/' + tsGesund]),
    neu13d.map((w) => Object.keys(w.body).join(',')).join(' | '));
  ok('jede Zeile geht als EIGENER Schreibvorgang',
    neu13d.filter((w) => w.einzeln).every((w) => Object.keys(w.body).length === 1),
    neu13d.filter((w) => w.einzeln).map((w) => Object.keys(w.body).length).join(','));
  ok('die strittige Zeile wird als erledigt vermerkt und nicht endlos wiederholt',
    !!(pubR._protokollGesendet['Bello'] && pubR._protokollGesendet['Bello'][String(tsStrittig)]));
  ok('die Uebertragung laeuft auch danach', pubR.started === true && pubR.abgeschaltet === false);

  regel.streng = false;
  try { fs.unlinkSync(authFile + '.r'); } catch (_) {}

  // --- 14) Sicherheits-Vollbild ---
  ok('Vollbild-Intervall gesetzt (raeumt verlorene Deltas auf)', pub.vollbildMs >= 5000, String(pub.vollbildMs));

  /* ==========================================================================================
   * AB HIER: DER NEUE WEG — MEHRERE OP-SAELE IM SELBEN PRAXIS-KONTO
   * ========================================================================================== */

  /* --- 15) DER SAAL-ZWEIG UND DAS VERSCHWUNDENE 'patients' -----------------------------------
   *
   * Zwei Zusagen in einem Block, weil sie dieselbe Wurzel haben: alles Eigene liegt unter der
   * eigenen Stationskennung, und der Top-Level-Schluessel 'patients' kommt in KEINEM Koerper mehr
   * vor. Er ersetzte den ganzen Knoten — in einem Konto mit zwei Saelen haette EIN Vollbild die
   * Spiegelschluessel des anderen Saals geloescht, alle 30 s erneut, und keine Station haette es
   * bemerkt (ihr Delta-Gedaechtnis vergleicht nur gegen den eigenen letzten Stand).
   */
  console.log('\n--- Mehrere OP-Saele -------------------------------------------------------');
  // Ein FREMDER Saal liegt schon im Konto — hier wird gleich geprueft, dass ihm nichts passiert.
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'saele', SID.fremd, 'patients', 'sw_hund_9', 'vitals'], { hr: 77 });
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'patients', 's' + SID6(SID.fremd) + '__sw_hund_9', 'vitals'], { hr: 77 });
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'tafel', SID.fremd, 'meta'],
    { sid: SID.fremd, name: 'Nachbarsaal', instanz: 'beef0000beef0000', sv: Date.now(), v: 4 });

  const pubM = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'OP 2', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.m', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.saal), tafelTaktMs: 300, vollbildMs: 5000 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubM.anmelden('saal@test.de', 'geheim123');
  await warmlaufen(pubM);
  const w9 = captured.writes.length;
  // Mehrere Takte, damit der Rueckleseweg antworten kann: erst danach ist die Anlaufsperre
  // aufgehoben (Kollision ausgeschlossen) und der Kompatibilitaetsmodus entschieden.
  for (let i = 0; i < 8; i++) { pubM.publish(samplePatients(70 + i), []); await wait(150); }
  const neuM = captured.writes.slice(w9);

  ok('der eigene Saal-Zweig wird beschrieben (saele/<sid>/patients/<key>/<feld>)',
    neuM.some((w) => !!w.body[saalPfad(SID.saal, keyHund, 'vitals')]),
    neuM.map((w) => Object.keys(w.body)[0]).join(' | '));
  ok('die Tafel dieses Saals wird beschrieben (tafel/<sid>/meta + uebersicht)',
    neuM.some((w) => !!w.body['tafel/' + SID.saal + '/meta'])
    && neuM.some((w) => !!w.body['tafel/' + SID.saal + '/uebersicht/' + keyHund]),
    neuM.map((w) => Object.keys(w.body).join(',')).join(' | '));
  /*
   * DIE ZENTRALE SPERRE: kein einziger Koerper darf den Schluessel 'patients' oder 'meta' als
   * GANZEN Knoten tragen. Geprueft wird auf allen bisher aufgezeichneten Koerpern, nicht nur auf
   * denen dieses Blocks — auch das erste Vollbild und der Spiegel gehoeren dazu.
   */
  const ganzeKnoten = captured.writes.filter((w) => Object.keys(w.body || {})
    .some((k) => k === 'patients' || k === 'meta' || k === 'saele' || k === 'tafel'));
  ok('der Top-Level-Schluessel "patients" kommt in KEINEM Koerper vor (auch nicht im Vollbild)',
    ganzeKnoten.length === 0,
    ganzeKnoten.map((w) => Object.keys(w.body).join(',')).join(' | '));
  /*
   * Und jeder flache Patientenpfad traegt den EIGENEN Praefix. Das ist die zweite Haelfte
   * derselben Zusage: ein Schluessel ohne Praefix waere der einer 1.0.3 oder eines Nachbarsaals —
   * eine Loeschung dort haette dessen Patienten aus der alten Fern-Ansicht entfernt.
   */
  const fremdeSpiegelpfade = [];
  captured.writes.forEach((w) => Object.keys(w.body || {}).forEach((k) => {
    if (k.indexOf('patients/') === 0 && k.indexOf(spiegelPfad(SID.saal, '')) !== 0) fremdeSpiegelpfade.push(k);
  }));
  ok('der Spiegel fasst AUSSCHLIESSLICH eigene, praefixierte Schluessel an',
    fremdeSpiegelpfade.length === 0, fremdeSpiegelpfade.slice(0, 5).join(', '));

  /* --- 16) DAS VOLLBILD LOESCHT KEINEN FREMDEN ZWEIG ------------------------------------------
   * Der teuerste denkbare Fehler dieses Umbaus. Geprueft wird am Datenbestand des Mocks: nach
   * mehreren Takten samt Sicherheits-Vollbild muss der Nachbarsaal unveraendert dastehen.
   */
  await wait(120);
  ok('der Zweig des fremden Saals steht nach Vollbild und Deltas unveraendert da',
    dbHole(DB, ['live', 'UIDPRAXIS1', 'saele', SID.fremd, 'patients', 'sw_hund_9', 'vitals', 'hr']) === 77,
    JSON.stringify(dbHole(DB, ['live', 'UIDPRAXIS1', 'saele', SID.fremd])));
  ok('auch der Spiegelschluessel des fremden Saals steht unveraendert da',
    dbHole(DB, ['live', 'UIDPRAXIS1', 'patients', 's' + SID6(SID.fremd) + '__sw_hund_9', 'vitals', 'hr']) === 77,
    JSON.stringify(dbHole(DB, ['live', 'UIDPRAXIS1', 'patients'])));
  ok('und die Tafel des fremden Saals ebenfalls',
    (dbHole(DB, ['live', 'UIDPRAXIS1', 'tafel', SID.fremd, 'meta']) || {}).name === 'Nachbarsaal');

  /* --- 17) DER TAFELTAKT IST DER HERZSCHLAG (N6) ----------------------------------------------
   * Er muss laufen, auch wenn sich an den Werten NICHTS aendert. Genau daran haengt die Aussage
   * "dieser OP-Saal lebt": das LifeVet sendet ab Werk nur alle ~30 s, und ohne eigenen Takt stuende
   * meta.sv genauso lange still — jeder andere Bildschirm im Haus meldete den gesunden Saal nach
   * 60 s als offline und ersetzte seine Zahlen durch "Stand vor X min".
   */
  const w10 = captured.writes.length;
  const gleich = samplePatients(99);
  for (let i = 0; i < 6; i++) { pubM.publish(gleich, []); await wait(150); }
  const tafelKoerper17 = koerperMit(w10, 'tafel/' + SID.saal + '/meta');
  const werteKoerper17 = koerperMit(w10, 'saele/' + SID.saal + '/patients/');
  ok('die Tafel laeuft auch OHNE jede Wertaenderung weiter (Herzschlag)',
    tafelKoerper17.length >= 2, 'Tafelkoerper: ' + tafelKoerper17.length);
  ok('die unveraenderten Vitalwerte werden dabei NICHT erneut geschrieben (Delta bleibt sparsam)',
    werteKoerper17.length <= 1, 'Wertkoerper: ' + werteKoerper17.length);
  const kopf17 = tafelKoerper17[tafelKoerper17.length - 1].body['tafel/' + SID.saal + '/meta'];
  ok('der Tafelkopf traegt den Server-Zeitstempel-Platzhalter (ein toter Saal kann nicht frisch aussehen)',
    !!(kopf17.sv && kopf17.sv['.sv'] === 'timestamp'), JSON.stringify(kopf17.sv));
  ok('der Tafelkopf traegt sid, Instanz und Bauversion',
    kopf17.sid === SID.saal && /^[0-9a-f]{16}$/.test(String(kopf17.instanz)) && !!kopf17.bv,
    JSON.stringify({ sid: kopf17.sid, instanz: kopf17.instanz, bv: kopf17.bv }));
  ok('der Tafelkopf zaehlt die geschriebenen Kacheln (count)', kopf17.count === 2, String(kopf17.count));

  /* --- 18) DER SPIEGEL FUER DIE ALTE WEB-APP: OHNE pri UND top (N8) ---------------------------
   * Endet in OP 1 die Narkose, waehlt die ausgelieferte Web-App 1.0.3 den Patienten mit der
   * HOECHSTEN Prioritaet aus — ueber alle Saele hinweg — und uebernimmt nur nicht-leere Werte.
   * Hat der andere Saal keine Kapnografie, stehen dessen EtCO2, Temp, AF und NIBP unter dem Namen
   * des fremden Tieres, ausgewiesen als gemessene Istwerte, und gehen in Dosis- und
   * Beatmungsempfehlung ein. Ohne pri bleibt die Auswahl beim ersten Schluessel.
   */
  const spiegelKoerper = koerperMit(w9, 'meta/station');
  /*
   * ZUERST DER MODUS. Liefe diese Station in F0 oder F1, schriebe sie die flache Ebene gar nicht —
   * und jede Pruefung darunter waere gruen, ohne etwas geprueft zu haben. Genau das ist einmal
   * passiert, weil der nachgebaute Endpunkt den Serverplatzhalter nicht aufgeloest hat.
   */
  ok('der Spiegel laeuft ueberhaupt (Modus F2)', /^F2/.test(pubM.status().saal.modus),
    pubM.status().saal.modus + ' — ' + pubM.status().saal.grund);
  ok('der Kompatibilitaetsspiegel wird geschrieben (meta/station + tiefe Patientenpfade)',
    spiegelKoerper.length >= 1, 'Spiegelkoerper: ' + spiegelKoerper.length);
  const sp = spiegelKoerper[spiegelKoerper.length - 1].body;
  ok('der Spiegel traegt v3 fuer die FLACHE Ebene (die alte Web-App darf nichts merken, N11)',
    sp['meta/v'] === 3, String(sp['meta/v']));
  ok('der Spiegel traegt den Server-Zeitstempel-Platzhalter',
    !!(sp['meta/sv'] && sp['meta/sv']['.sv'] === 'timestamp'), JSON.stringify(sp['meta/sv']));
  ok('der Spiegel schreibt EIN eigenes qs-Kind (meta/qs/<sid>), nie den ganzen qs-Knoten',
    !!sp['meta/qs/' + SID.saal] && !Object.keys(sp).some((k) => k === 'meta/qs'), Object.keys(sp).filter((k) => k.indexOf('meta/qs') === 0).join(','));
  const alleSpiegelPfade = [];
  captured.writes.slice(w9).forEach((w) => Object.keys(w.body || {}).forEach((k) => {
    if (k.indexOf(spiegelPfad(SID.saal, '')) === 0) alleSpiegelPfade.push(k);
  }));
  ok('im Spiegel steht ueberhaupt ein Patient (sonst prueft die naechste Zeile nichts)',
    alleSpiegelPfade.length > 0, alleSpiegelPfade.slice(0, 3).join(', '));
  ok('im Spiegel kommen pri und top NIRGENDS vor (N8)',
    !alleSpiegelPfade.some((k) => /\/(pri|top)$/.test(k)),
    alleSpiegelPfade.filter((k) => /\/(pri|top)$/.test(k)).join(', '));
  ok('im SAAL-Zweig stehen pri und top dagegen weiterhin (die neue Ansicht braucht sie)',
    captured.writes.slice(w9).some((w) => !!w.body[saalPfad(SID.saal, keyHund, 'pri')]));

  /* --- 19) DER PATIENT VERSCHWINDET: AUSDRUECKLICHE LOESCHUNG STATT KARTEILEICHE (N7) ---------
   * Ohne diese Loeschung bleibt die Kachel eines abgehaengten Tieres stehen. Der Leser urteilt
   * ueber die Frische am SAAL (meta.sv), und altMs ist im alten Objekt eingefroren — die
   * Karteileiche erscheint dauerhaft als "1,2 s alt", mit plausiblen, unveraenderlichen
   * Vitalwerten, in der Tafel jeder Web-Ansicht und im Nachbarstreifen.
   */
  const keyKatze = sanitizeKey('sw:katze:4.2');
  const w13 = captured.writes.length;
  await wait(150);
  for (let i = 0; i < 4; i++) { pubM.publish([samplePatients(75)[0]], []); await wait(150); }
  const neuWeg = captured.writes.slice(w13);
  ok('der verschwundene Patient wird im Saalzweig ausdruecklich geloescht (null)',
    neuWeg.some((w) => w.body[saalPfad(SID.saal, keyKatze)] === null),
    neuWeg.map((w) => Object.keys(w.body).join(',')).join(' | ').slice(0, 200));
  ok('und im Spiegel ebenso',
    neuWeg.some((w) => w.body[spiegelPfad(SID.saal, keyKatze)] === null),
    neuWeg.map((w) => Object.keys(w.body).filter((k) => k.indexOf('patients/') === 0).join(',')).join(' | ').slice(0, 200));
  ok('geloescht wird der Patient als GANZES, nicht Feld fuer Feld (ein Pfad statt zwanzig)',
    !neuWeg.some((w) => Object.keys(w.body).some((k) => k.indexOf(saalPfad(SID.saal, keyKatze) + '/') === 0)),
    'es blieben Einzelfelder uebrig');
  ok('die Kachel des verschwundenen Patienten geht ebenfalls auf null',
    neuWeg.some((w) => w.body['tafel/' + SID.saal + '/uebersicht/' + keyKatze] === null),
    neuWeg.map((w) => Object.keys(w.body).filter((k) => k.indexOf('tafel/') === 0).join(',')).join(' | ').slice(0, 200));

  /* --- 20) EIN FEHLER IM TAFELZWEIG SCHALTET DIE VITALUEBERTRAGUNG NICHT AB -------------------
   * Die Kette, die am 29.07.2026 schon einmal zugeschlagen hat: HTTP 401 -> Konfigfehler -> nach
   * drei Treffern Selbstabschaltung. Sie darf ab jetzt nur noch vom ZIEL DER VITALWERTE ausgehen.
   * Ein abgewiesenes Tafelfeld (etwa nach einer verschaerften Regel) kostet die Tafel — nie die
   * Ueberwachung.
   *
   * DIE WERTE BLEIBEN IN DIESEM BLOCK ABSICHTLICH UNVERAENDERT. Ein erfolgreicher Wert-Koerper
   * setzt konfigFehler auf 0 zurueck (so war es immer schon) — er wuerde also verdecken, ob der
   * Tafelfehler dort ueberhaupt ankommt. Nachgemessen: mit wechselnden Werten bleibt der Zaehler
   * auch dann bei 0, wenn die Tafel ihn hochzaehlt, und die Pruefung waere wertlos. Mit
   * unveraenderten Werten schreibt Weg L nichts, und der Zaehler kann nur noch von der Tafel
   * kommen.
   */
  const pubF = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Fehlerfall', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.f', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.fehler), tafelTaktMs: 300, vollbildMs: 60000 },
    { log: { log: false, info() {}, warn() {}, error() {} } });
  await pubF.anmelden('fehler@test.de', 'geheim123');
  await warmlaufen(pubF);
  const gleichF = samplePatients(84);
  for (let i = 0; i < 3; i++) { pubF.publish(gleichF, []); await wait(150); }
  const w11 = captured.writes.length;
  ablehnen.tafel = true;
  for (let i = 0; i < 8; i++) { pubF.publish(gleichF, []); await wait(150); }
  await wait(300);
  ok('der Tafelzweig wurde tatsaechlich abgelehnt (sonst prueft dieser Block nichts)',
    captured.abgelehnt.some((a) => a.tafel), JSON.stringify(captured.abgelehnt.slice(-1)));
  ok('im Fehlerfenster ging KEIN Wert-Koerper raus (sonst haette er den Zaehler zurueckgesetzt)',
    koerperMit(w11, 'saele/' + SID.fehler + '/patients/').length === 0,
    captured.writes.slice(w11).map((w) => Object.keys(w.body)[0]).join(' | '));
  ok('ein Fehler im Tafelzweig schaltet die Vitaluebertragung NICHT ab',
    pubF.started === true && pubF.abgeschaltet === false,
    'started=' + pubF.started + ' abgeschaltet=' + pubF.abgeschaltet);
  ok('er zaehlt auch NICHT auf das Konto der Vitalwerte', pubF.konfigFehler === 0, String(pubF.konfigFehler));
  ok('das eigene Konto der Tafel zaehlt dagegen mit', pubF.tafelFehlerZahl >= 1, String(pubF.tafelFehlerZahl));
  ok('der Tafelfehler steht im Zustand — ein stiller Ausfall waere schlimmer als ein sichtbarer',
    !!pubF.status().tafel.lastError, JSON.stringify(pubF.status().tafel));
  /*
   * GEAENDERT AM 30.07.2026 (Befund C1/C4): hier stand 'tafel.aktiv === true'. Das Feld war hart
   * auf true verdrahtet, mit der Begruendung, die Tafel schalte sich nie ab — richtig, aber nicht
   * die Frage. Die Frage ist, ob der Herzschlag ANKOMMT. Kommt er nicht an, steht dieser OP-Saal
   * auf jedem anderen Bildschirm im Haus als "offline", und dann muss der Admin-Bereich das sagen
   * duerfen. Ein Feld, das in genau dieser Lage "in Ordnung" meldet, ist schlimmer als keines.
   */
  ok('und "aktiv" meldet den stehenden Herzschlag, statt ihn zu behaupten',
    pubF.status().tafel.aktiv === false, JSON.stringify(pubF.status().tafel));
  ok('und die Tafel gibt NICHT auf (sie wartet nur laenger)', pubF.tafelBackoffMs > 0 && pubF.tafelBackoffMs <= 60000,
    String(pubF.tafelBackoffMs));
  ablehnen.tafel = false;
  // Und die Gegenprobe: sobald die Datenbank die Tafel wieder annimmt, laeuft sie weiter.
  const w11b = captured.writes.length;
  await wait(2600);   // die Wartezeit nach dem Fehler abwarten (sie waechst auf 2 s)
  for (let i = 0; i < 4; i++) { pubF.publish(gleichF, []); await wait(150); }
  ok('nach dem Ende der Stoerung schreibt die Tafel von selbst wieder',
    koerperMit(w11b, 'tafel/' + SID.fehler + '/meta').length >= 1 && pubF.tafelFehler === null,
    'Tafelkoerper: ' + koerperMit(w11b, 'tafel/' + SID.fehler + '/meta').length + ', Fehler: ' + pubF.tafelFehler);
  ok('und "aktiv" meldet den Herzschlag wieder als schlagend', pubF.status().tafel.aktiv === true,
    JSON.stringify(pubF.status().tafel));

  /* --- 20) SPERRE BEI DOPPELTER STATIONSKENNUNG (N1) ------------------------------------------
   * Zwei geklonte PCs mit derselben Kennung wuerden unter saele/<sid>/patients/<key> zwei Narkosen
   * Feld fuer Feld mischen — bei zwei 22-kg-Hunden beide unter sw_hund_22. Solange das nicht
   * ausgeschlossen ist, geht NUR tafel/<sid>/meta raus.
   */
  const pubZ = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Zwilling', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.z', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.sperre), tafelTaktMs: 300 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubZ.anmelden('zwilling@test.de', 'geheim123');
  await warmlaufen(pubZ);
  /*
   * Erst ein paar Takte allein. Sie sind nicht Beiwerk: die Station muss ihre EIGENE Instanz
   * mindestens einmal aus dem Kennungsknoten zurueckgelesen haben. Danach — und nur danach — ist
   * ein FREMDER Wert dort der Beweis, dass jemand uns ueberschrieben hat, also lebt. Ohne diesen
   * Schritt braucht der Beweis den langsamen Weg (derselbe fremde Wert ueber 5 s), und genau diese
   * Unterscheidung ist die Reparatur in stationsid.js gegen das Aussperren einer Einzelstation
   * nach einem Neustart.
   */
  for (let i = 0; i < 6; i++) { pubZ.publish([], []); await wait(200); }
  ok('allein ist die Kennung ausgeschlossen (sonst prueft der Rest dieses Blocks nichts)',
    pubZ.status(true).saal.sperre === 'ausgeschlossen', pubZ.status(true).saal.sperre);
  // Ab jetzt laeuft ein ZWEITER Rechner mit derselben Kennung: er ueberschreibt den Kennungsknoten
  // nach jedem unserer Schreibvorgaenge mit SEINER Instanz.
  zwilling.sid = SID.sperre;
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'tafel', SID.sperre, 'meta', 'instanz'], zwilling.instanz);
  for (let i = 0; i < 60 && pubZ.status(true).saal.sperre !== 'bewiesen'; i++) {
    pubZ.publish(samplePatients(50), []); await wait(60);
  }
  // Erst AB HIER wird gezaehlt: der Weg in die Sperre gehoert nicht zur Aussage dieses Blocks.
  const w12 = captured.writes.length;
  for (let i = 0; i < 8; i++) { pubZ.publish(samplePatients(50 + i), []); await wait(120); }
  await wait(200);
  const neuZ = captured.writes.slice(w12);
  ok('die doppelte Kennung wird als BEWIESEN erkannt', pubZ.status(true).saal.sperre === 'bewiesen',
    pubZ.status(true).saal.sperre);
  ok('bei doppelter Kennung wird NUR tafel/<sid>/meta geschrieben — keine Patientendaten',
    neuZ.length > 0 && neuZ.every((w) => Object.keys(w.body).every((k) => k === 'tafel/' + SID.sperre + '/meta')),
    neuZ.map((w) => Object.keys(w.body).join(',')).join(' | '));
  ok('der Kopf meldet den Konflikt (dop) und sagt die Wahrheit ueber die Kacheln (count 0)',
    neuZ.some((w) => w.body['tafel/' + SID.sperre + '/meta']
      && w.body['tafel/' + SID.sperre + '/meta'].dop === 1
      && w.body['tafel/' + SID.sperre + '/meta'].count === 0),
    JSON.stringify(neuZ.length ? neuZ[neuZ.length - 1].body : {}));
  ok('kein Spiegel und kein Protokoll waehrend der Sperre',
    !neuZ.some((w) => Object.keys(w.body).some((k) => k.indexOf('meta/') === 0 || istProtokoll(k))),
    neuZ.map((w) => Object.keys(w.body).join(',')).join(' | '));

  /* --- 21) ZWEI UHREN, UND SIE DUERFEN SICH NICHT MISCHEN -------------------------------------
   *
   * Das Alter einer Kachel ist eine DAUER aus LOKALEN Zeitstempeln (der Zeitpunkt des
   * Geraetepakets kommt von diesem PC). Der Kompatibilitaetsspiegel und der Betriebsmodus rechnen
   * dagegen gegen die SERVERZEIT (sv setzt die Datenbank selbst, die qs-Kinder der Nachbarn
   * ebenso). Wer beides vertauscht, meldet einen gesunden Saal als "Stand vor 10 Minuten" —
   * oder haelt jeden Nachbarn fuer "aus der Zukunft" und sich selbst fuer allein im Konto.
   * Geprueft wird mit einer Datenbank, deren Uhr 10 Minuten vorgeht.
   */
  uhr.versatzMs = 600000;
  const pubU = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Uhrenpruefung', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.u', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.uhr), tafelTaktMs: 300 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubU.anmelden('uhr@test.de', 'geheim123');
  await warmlaufen(pubU);
  const w14 = captured.writes.length;
  for (let i = 0; i < 6; i++) { pubU.publish(samplePatients(72 + i, { ts: Date.now() }), []); await wait(150); }
  await wait(200);
  ok('der Uhrenversatz zur Datenbank wird ueberhaupt gemessen (Date-Kopfzeile)',
    pubU.status().saal.serverVersatzMs > 500000, String(pubU.status().saal.serverVersatzMs));
  const kachelU = (koerperMit(w14, 'tafel/' + SID.uhr + '/uebersicht/')
    .map((w) => w.body['tafel/' + SID.uhr + '/uebersicht/' + keyHund]).filter((x) => x))[0];
  ok('die Kachel rechnet ihr Alter in der LOKALEN Uhr (sonst waere ein frischer Wert 10 min alt)',
    !!kachelU && kachelU.altMs != null && kachelU.altMs < 30000, kachelU && String(kachelU.altMs));
  const spU = (koerperMit(w14, 'meta/ts').map((w) => w.body['meta/ts']).filter((x) => x))[0];
  ok('der Spiegel stempelt dagegen in der SERVERZEIT (die alte Web-App rechnet gegen sie)',
    !!spU && (spU - Date.now()) > 500000, String(spU ? spU - Date.now() : null));
  ok('und der Betriebsmodus bleibt trotz Uhrenversatz entscheidbar (kein F1 aus Versehen)',
    /^F2/.test(pubU.status().saal.modus), pubU.status().saal.modus);
  uhr.versatzMs = 0;

  /* --- 22) DIE TAKTE AUS DER ENTSCHEIDUNG DES NUTZERS ----------------------------------------- */
  const pubT = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'T', authFile: authFile + '.t', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.tafel) }, { log: { info() {}, warn() {}, error() {} } });
  ok('Vorgabe: Werte alle 500 ms', pubT.minInterval === 500, String(pubT.minInterval));
  ok('Vorgabe: Tafel alle 2000 ms', pubT.tafelTaktMs === 2000, String(pubT.tafelTaktMs));
  ok('Vorgabe: Ruhetakt 5000 ms (kein Patient im eigenen Saal, Sparregel N6)',
    pubT.ruheTaktMs === 5000, String(pubT.ruheTaktMs));
  ok('beide Takte sind aus der Konfiguration einstellbar',
    new CloudPublisher({ minIntervalMs: 250, tafelTaktMs: 1500, ruheTaktMs: 9000 }, {}).tafelTaktMs === 1500,
    'tafelTaktMs');
  /*
   * DER HERZSCHLAG DARF NICHT AN DER WERT-DROSSEL HAENGEN. Stellt eine Praxis die Werte langsamer
   * als die Tafel (schmale Leitung), muss der Herzschlag trotzdem seinen eigenen Takt behalten —
   * sonst meldet jeder andere Bildschirm im Haus diesen gesunden Saal nach 60 s als offline.
   */
  const pubH = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'H', minIntervalMs: 3000, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.h', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.herz), tafelTaktMs: 300 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubH.anmelden('herz@test.de', 'geheim123');
  await bereit(pubH);
  const w15 = captured.writes.length;
  for (let i = 0; i < 10; i++) { pubH.publish(samplePatients(90 + i), []); await wait(150); }
  ok('der Herzschlag laeuft auch dann in seinem Takt, wenn die WERTE langsamer gestellt sind',
    koerperMit(w15, 'tafel/' + SID.herz + '/meta').length >= 3,
    'Tafelkoerper: ' + koerperMit(w15, 'tafel/' + SID.herz + '/meta').length + ' in 1,5 s bei 3 s Wert-Takt');

  // Die Zusage aus dem Kopf von tafel.js: der Herzschlag entscheidet OHNE jeden Messwert.
  ok('der Tafeltakt haengt an der Uhr und der Patientenzahl — an keinem Messwert',
    tafel.herzschlagFaellig({ jetzt: 100000, letzter: 97000, patientenZahl: 1, tafelTaktMs: 2000 }) === true
    && tafel.herzschlagFaellig({ jetzt: 100000, letzter: 99000, patientenZahl: 1, tafelTaktMs: 2000 }) === false
    && tafel.herzschlagFaellig({ jetzt: 100000, letzter: 97000, patientenZahl: 0, tafelTaktMs: 2000, ruheTaktMs: 5000 }) === false);

  /* ==========================================================================================
   * NACHBESSERUNGSRUNDE 30.07.2026 — die Befunde C1, C2, C3, C6 und die Naht zum Saalnamen
   * ========================================================================================== */
  console.log('\n--- Die Trennung gilt in BEIDE Richtungen (C1) -----------------------------');
  /*
   * DIE FLACHE EBENE WIRD VOR DIESEN BLOECKEN GELEERT, und das ist kein Aufraeumen, sondern eine
   * Voraussetzung: in Block 21 geht die Uhr der Datenbank absichtlich zehn Minuten vor, und
   * meta/ts sowie die qs-Kinder bleiben danach mit einem Zeitstempel AUS DER ZUKUNFT stehen. Jede
   * spaeter angemeldete Station haelt das fuer eine laufende Fassung 1.0.3 (Modus F1) und spiegelt
   * dann ueberhaupt nichts — jede Spiegelpruefung darunter waere gruen, ohne etwas geprueft zu
   * haben. Nachgemessen: genau so ist es beim ersten Lauf dieser Bloecke passiert.
   */
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'meta'], null);

  /* --- 23) EIN FEHLER IM WERT-ZWEIG HAELT DEN HERZSCHLAG NICHT AN (Befund C1) -----------------
   *
   * Block 20 oben prueft die eine Richtung: ein Tafelfehler nimmt die Vitalwerte nicht mit.
   * DIESER BLOCK PRUEFT DIE ANDERE, und sie ist die schlimmere. Gemessen am 30.07.2026: wurde nur
   * der WERT-Zweig abgelehnt, kamen in 12 s NULL Herzschlaege, NULL Protokollkoerper und NULL
   * Spiegelkoerper — die Ablehnung fiel aus _publizieren heraus, und die Wartezeit (bis 60 s) und
   * die Selbstabschaltung (started = false) standen ganz oben in publish() und sperrten alles.
   * tafel.STUFE_OFFLINE_MS ist 60000: der laufende OP-Saal verschwand damit aus der Tafel jeder
   * anderen Station und aus jeder Fern-Ansicht, obwohl er narkotisiert weiterlief. Ein gestoerter
   * Saal war von einem ausgeschalteten nicht mehr zu unterscheiden — genau die Verwechslung,
   * gegen die dieser ganze Umbau gebaut ist.
   *
   * DER MOCK KONNTE DIESEN FALL BIS HEUTE GAR NICHT ERZEUGEN (er kannte nur 'ablehnen.tafel').
   * Deshalb waren alle Pruefungen dieser Datei gruen, waehrend der Fehler im Code stand.
   */
  const pubW = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Wertfehler', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.w', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.werte), tafelTaktMs: 250, vollbildMs: 60000 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubW.anmelden('wert@test.de', 'geheim123');
  await warmlaufen(pubW);
  for (let i = 0; i < 4; i++) { pubW.publish(samplePatients(40 + i), []); await wait(140); }
  await wait(200);
  ok('vor der Stoerung laeuft dieser Saal vollstaendig (sonst prueft der Block nichts)',
    pubW.sq >= 1 && pubW.tafelGeschrieben >= 1 && pubW.spiegelGeschrieben >= 1
    && pubW.status().tafel.aktiv === true,
    'sq=' + pubW.sq + ' tafel=' + pubW.tafelGeschrieben + ' spiegel=' + pubW.spiegelGeschrieben);

  /*
   * Phase 0: EINE LAHME LEITUNG, ohne jeden Fehler. Das ist der unauffaelligste Fall und der
   * haeufigste: der Wert-Schreibvorgang antwortet nicht, cloud.js bricht erst nach 8 s ab. Wurde
   * Weg L abgewartet, hing der Herzschlag genauso lange mit — und zwar OHNE dass irgendwo ein
   * Fehler stand, den jemand haette sehen koennen. Geprueft wird deshalb nicht "kommt eine
   * Fehlermeldung", sondern "schlaegt das Herz im eigenen Takt weiter".
   */
  const wL = captured.writes.length;
  langsam.werte = SID.werte; langsam.ms = 900;
  for (let i = 0; i < 14; i++) { pubW.publish(samplePatients(20 + i), []); await wait(150); }
  await wait(250);
  langsam.werte = null; langsam.ms = 0;
  const tafelL = koerperMit(wL, 'tafel/' + SID.werte + '/meta');
  ok('ein LANGSAMER Wert-Schreibvorgang bremst den Herzschlag nicht aus (Weg L wird nicht abgewartet)',
    tafelL.length >= 5, 'Tafelkoerper in 2,1 s bei 250 ms Takt und 900 ms lahmer Leitung: ' + tafelL.length);
  await wait(300);   // die letzte lahme Antwort noch abholen, bevor die naechste Phase misst

  /* Phase A: ein SELBSTHEILENDER Fehler (HTTP 500) auf dem Wert-Zweig. Er fuehrt zu keiner
   * Abschaltung, nur zu einer wachsenden Wartezeit — und genau die hat frueher den Herzschlag
   * mit angehalten. */
  const wA = captured.writes.length;
  const tsW = Date.now() + 500;
  ablehnen.werteCode = 500;
  ablehnen.werte = SID.werte;
  for (let i = 0; i < 14; i++) {
    pubW.publish(samplePatients(60 + i), [], { 'Bello': [{ ts: tsW + i, hr: 60 + i }] });
    await wait(150);
  }
  await wait(250);
  const tafelA = koerperMit(wA, 'tafel/' + SID.werte + '/meta');
  const werteA = koerperMit(wA, 'saele/' + SID.werte + '/patients/');
  ok('der WERT-Zweig wurde tatsaechlich abgelehnt (sonst misst dieser Block nichts)',
    captured.abgelehnt.some((a) => a.werte), JSON.stringify(captured.abgelehnt.slice(-1)));
  ok('und es kam wirklich kein Wert-Koerper durch', werteA.length === 0,
    'Wertkoerper: ' + werteA.length);
  ok('DER HERZSCHLAG LAEUFT TROTZDEM WEITER (C1)', tafelA.length >= 4,
    'Tafelkoerper in 2,1 s bei 250 ms Takt: ' + tafelA.length);
  ok('der Kompatibilitaetsspiegel laeuft ebenfalls weiter',
    koerperMit(wA, 'meta/ts').length >= 2, 'Spiegelkoerper: ' + koerperMit(wA, 'meta/ts').length);
  ok('und das OP-Protokoll ebenfalls (es haengt an einem eigenen Konto)',
    captured.writes.slice(wA).some((w) => Object.keys(w.body).some(
      (k) => k.indexOf('saele/' + SID.werte + '/protokoll/') === 0)),
    captured.writes.slice(wA).map((w) => Object.keys(w.body)[0]).join(' | ').slice(0, 200));
  ok('der Wert-Fehler steht im Zustand und hat seine eigene wachsende Wartezeit',
    !!pubW.status().lastError && pubW.backoffMs >= 2000, pubW.status().lastError + ' / ' + pubW.backoffMs);
  ok('ein selbstheilender Fehler zaehlt NICHT auf das Konfigurationskonto',
    pubW.konfigFehler === 0 && pubW.abgeschaltet === false, String(pubW.konfigFehler));
  ok('und der Saal bleibt fuer jeden anderen Bildschirm sichtbar',
    pubW.status().tafel.aktiv === true, JSON.stringify(pubW.status().tafel));

  /* Die Gegenprobe: sobald die Datenbank die Werte wieder annimmt, laeuft Weg L von selbst an.
   * Gewartet wird die WACHSENDE WARTEZEIT DES WERT-WEGES ab — sie ist hier die Sache. Feste
   * Sekundenzahlen haetten diese Zeile von der Uhr abhaengig gemacht statt von der Aussage. */
  ablehnen.werte = null;
  const wA2 = captured.writes.length;
  await wait(Math.max(300, pubW.naechsterVersuch - Date.now() + 250));
  for (let i = 0; i < 8; i++) { pubW.publish(samplePatients(100 + i), []); await wait(150); }
  ok('nach dem Ende der Stoerung schreibt der Wert-Zweig von selbst wieder',
    koerperMit(wA2, 'saele/' + SID.werte + '/patients/').length >= 1 && pubW.lastError === null,
    'Wertkoerper: ' + koerperMit(wA2, 'saele/' + SID.werte + '/patients/').length + ', Fehler: ' + pubW.lastError);

  /*
   * Phase B: DIE SELBSTABSCHALTUNG. Die drei Konfigurationsfehler werden hier direkt gezaehlt
   * statt ueber drei echte Ablehnungen — die wachsende Wartezeit dazwischen (2 s, 4 s) ist in
   * Block 20 und in tools/hl7-reconnect-test.js schon geprueft, und ein Test, der sie noch einmal
   * abwartet, misst die Uhr statt die Sache. Geprueft wird HIER, was danach passiert.
   */
  pubW._fehler(new Error('HTTP 401: Permission denied'));
  pubW._fehler(new Error('HTTP 401: Permission denied'));
  pubW._fehler(new Error('HTTP 401: Permission denied'));
  ok('drei Regelablehnungen schalten den WERTESTROM ab', pubW.abgeschaltet === true,
    'konfigFehler=' + pubW.konfigFehler);
  const wB = captured.writes.length;
  for (let i = 0; i < 10; i++) { pubW.publish(samplePatients(120 + i), []); await wait(150); }
  await wait(250);
  ok('nach der Abschaltung geht KEIN Wert-Koerper mehr raus',
    koerperMit(wB, 'saele/' + SID.werte + '/patients/').length === 0,
    captured.writes.slice(wB).map((w) => Object.keys(w.body)[0]).join(' | ').slice(0, 200));
  ok('DER HERZSCHLAG LAEUFT AUCH NACH DER ABSCHALTUNG WEITER — ein gestoerter Saal darf nicht '
    + 'aussehen wie ein ausgeschalteter', koerperMit(wB, 'tafel/' + SID.werte + '/meta').length >= 4,
    'Tafelkoerper: ' + koerperMit(wB, 'tafel/' + SID.werte + '/meta').length);
  ok('der Zustand sagt beides getrennt: Werte gestoppt, Herzschlag schlaegt',
    pubW.status().started === false && pubW.status().abgeschaltet === true
    && !!pubW.status().abschaltGrund && pubW.status().tafel.aktiv === true,
    JSON.stringify({ started: pubW.status().started, tafel: pubW.status().tafel.aktiv }));

  /* --- 24) MODUSWECHSEL F2-solo -> F2-multi: DER GESPIEGELTE STREIFEN WIRD GELOESCHT (C2) -----
   *
   * Gemessen am 30.07.2026: beim Wechsel blieb der zuletzt gespiegelte KURVENSTREIFEN dauerhaft in
   * der flachen Ebene stehen, waehrend kurvenSig und die Vitalwerte daneben weiterliefen. Die
   * ausgelieferte Web-App 1.0.3 zeichnete danach eine eingefrorene EKG-Kurve neben lebenden
   * Zahlen, ohne jedes Kennzeichen — und zwar genau in dem Moment, fuer den dieser Umbau gebaut
   * ist: die Praxis nimmt ihren zweiten Saal in Betrieb. Ein eingefrorener Wert, der aussieht wie
   * eine Messung, ist die gefaehrlichste Anzeige, die dieses Programm hervorbringen kann.
   *
   * Ursache: beim Moduswechsel wurde das Spiegelgedaechtnis GELEERT. Damit gab es nichts mehr,
   * woraus eine Loeschung haette entstehen koennen — das folgende Vollbild schrieb nur noch die
   * Felder, die es im neuen Modus GIBT.
   *
   * WARUM DIE NACHBARLISTE HIER VON HAND GESETZT WIRD: im Mock liegen inzwischen die Tafelkoepfe
   * aller frueheren Bloecke, dieser Saal waere also von der ersten Sekunde an in F2-multi. Der
   * Rueckleseweg der Nachbarn wird deshalb stillgelegt (fremdLeseTaktMs sehr gross) und die Liste
   * je Takt gesetzt — der WECHSEL ist die Sache, nicht das Lesen.
   */
  console.log('\n--- Der Moduswechsel und der eingefrorene Streifen (C2) --------------------');
  /*
   * Die flache Ebene noch einmal leeren, und zwar aus einem MESSTECHNISCHEN Grund, der auch im Feld
   * gilt: der Uhrenversatz wird aus der HTTP-Date-Kopfzeile geschaetzt, die 1 s Aufloesung hat und
   * abgeschnitten wird. Die eigene Schaetzung der Serverzeit liegt damit bis zu 999 ms ZURUECK. Ein
   * fremdes qs-Kind, das gerade eben geschrieben wurde, liegt fuer eine frisch gestartete Station
   * also scheinbar in der Zukunft und zaehlt nicht (tafel.qsFremdFrisch, Absicht) — sie haelt den
   * eben noch schreibenden Nachbarn fuer eine 1.0.3 und rastet fuer FREMD_STILLE_MS in F1 ein.
   * Genau das ist beim ersten Lauf passiert. Der Moduswechsel ist die Sache dieses Blocks, nicht
   * die Aufloesung einer HTTP-Kopfzeile.
   */
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'meta'], null);
  const streifenA = [{ code: 'ECG_I', name: 'EKG I', hz: 256, samples: Array.from({ length: 512 }, (_, i) => Math.sin(i / 7) * 800) }];
  const streifenB = [{ code: 'ECG_I', name: 'EKG I', hz: 256, samples: Array.from({ length: 512 }, (_, i) => Math.cos(i / 5) * 700) }];
  const pubC = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Wechselsaal', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.c', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.wechsel), tafelTaktMs: 200, vollbildMs: 60000,
    fremdLeseTaktMs: 600000 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubC.anmelden('wechsel@test.de', 'geheim123');
  await warmlaufen(pubC);
  const spiegelKey = 's' + SID6(SID.wechsel) + '__' + keyHund;
  const imSpiegel = (feld) => dbHole(DB, ['live', 'UIDPRAXIS1', 'patients', spiegelKey].concat(feld ? [feld] : []));
  // Phase 1: allein im Konto -> F2-solo, voller Spiegel MIT Kurven.
  for (let i = 0; i < 8; i++) {
    pubC._tafelEintraege = {};
    pubC.publish(samplePatients(70 + i, { kurvenDaten: streifenA }), []);
    await wait(140);
  }
  await wait(200);
  ok('Phase 1: dieser Saal ist allein im Konto (F2-solo)', pubC.status().saal.modus === 'F2-solo',
    pubC.status().saal.modus + ' — ' + pubC.status().saal.grund);
  const kurveVorher = imSpiegel('kurven');
  ok('Phase 1: der Kurvenstreifen liegt wirklich in der flachen Ebene',
    !!(kurveVorher && kurveVorher.ECG_I && kurveVorher.ECG_I.b64), JSON.stringify(Object.keys(kurveVorher || {})));
  const sigVorher = imSpiegel('kurvenSig');
  ok('Phase 1: und die Signatur daneben', typeof sigVorher === 'string' && sigVorher.length > 0, String(sigVorher));

  // Phase 2: ein zweiter Saal wird in Betrieb genommen -> F2-multi, Spiegel OHNE Kurven.
  const nachbarKopf = {};
  nachbarKopf[SID.fremd] = { sid: SID.fremd, name: 'Nachbarsaal', instanz: 'beef0000beef0000', sv: serverJetzt() };
  const wC2 = captured.writes.length;
  for (let i = 0; i < 10; i++) {
    pubC._tafelEintraege = nachbarKopf;
    pubC.publish(samplePatients(80 + i, { kurvenDaten: streifenB }), []);   // NEUER Streifen!
    await wait(140);
  }
  await wait(250);
  const neuC = captured.writes.slice(wC2);
  ok('Phase 2: der Modus wechselt auf F2-multi', pubC.status().saal.modus === 'F2-multi',
    pubC.status().saal.modus + ' — ' + pubC.status().saal.grund);
  ok('DER GESPIEGELTE STREIFEN WIRD BEIM WECHSEL AUSDRUECKLICH GELOESCHT (null)',
    neuC.some((w) => w.body[spiegelPfad(SID.wechsel, keyHund, 'kurven')] === null),
    neuC.map((w) => Object.keys(w.body).filter((k) => k.indexOf('patients/') === 0).join(',')).join(' | ').slice(0, 240));
  ok('und die Signatur daneben ebenso — ein Signaturwechsel ohne Streifen ist die eigentliche Luege',
    neuC.some((w) => w.body[spiegelPfad(SID.wechsel, keyHund, 'kurvenSig')] === null),
    neuC.map((w) => Object.keys(w.body).filter((k) => /kurvenSig$/.test(k)).join(',')).join(' | ').slice(0, 240));
  ok('am Datenbestand gemessen: in der flachen Ebene steht danach KEIN Streifen mehr',
    imSpiegel('kurven') === null, JSON.stringify(imSpiegel('kurven')));
  ok('und auch keine Signatur mehr', imSpiegel('kurvenSig') === null, String(imSpiegel('kurvenSig')));
  ok('die Vitalwerte daneben laufen unveraendert weiter (der Spiegel ist nicht abgestuerzt)',
    (imSpiegel('vitals') || {}).hr >= 80, JSON.stringify(imSpiegel('vitals')));
  ok('im eigenen Saalzweig bleibt der Streifen dagegen stehen — die neue Ansicht braucht ihn',
    !!dbHole(DB, ['live', 'UIDPRAXIS1', 'saele', SID.wechsel, 'patients', keyHund, 'kurven', 'ECG_I', 'b64']));

  /* --- 25) DIE WERT-DROSSEL IST DIE DROSSEL DER WERTE (Befund C3) ------------------------------
   * Gemessen: mit minIntervalMs 3000 gegen tafelTaktMs 500 gingen in 6 s zwoelf Wertkoerper raus
   * statt der eingestellten zwei — Faktor 6. Der Herzschlag oeffnete die Drossel nicht nur mit, er
   * nahm den ganzen Wert-Koerper mit raus. Eine Praxis mit schmaler Leitung bekam damit ein
   * Vielfaches der Datenmenge, die sie eingestellt hat, und bridge/config/devices.example.json
   * verspricht ausdruecklich "_minIntervalMs: Sendetakt der VITALWERTE".
   */
  console.log('\n--- Wert-Takt und Herzschlag sind zwei Takte (C3) --------------------------');
  const pubD = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Schmalband', minIntervalMs: 1200, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.d', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.drossel), tafelTaktMs: 250, vollbildMs: 60000 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubD.anmelden('drossel@test.de', 'geheim123');
  await warmlaufen(pubD);
  const wD = captured.writes.length;
  const dStart = Date.now();
  for (let i = 0; i < 25; i++) { pubD.publish(samplePatients(30 + i), []); await wait(100); }
  await wait(200);
  const dDauer = Date.now() - dStart;
  const werteD = koerperMit(wD, 'saele/' + SID.drossel + '/patients/').length;
  const tafelD = koerperMit(wD, 'tafel/' + SID.drossel + '/meta').length;
  const erwartetWerte = Math.ceil(dDauer / 1200) + 1;
  ok('die WERTE gehen im eingestellten Takt (1200 ms), nicht im Tafeltakt',
    werteD <= erwartetWerte, werteD + ' Wertkoerper in ' + dDauer + ' ms, hoechstens ' + erwartetWerte + ' erwartet');
  ok('der HERZSCHLAG geht dabei in SEINEM Takt (250 ms)', tafelD >= 6,
    tafelD + ' Tafelkoerper in ' + dDauer + ' ms');
  ok('und er ist deutlich haeufiger als die Werte — sonst haengt er doch an der Wert-Drossel',
    tafelD >= werteD * 3, 'Tafel ' + tafelD + ' gegen Werte ' + werteD);

  /* --- 26) DER BLICK AUF DEN EIGENEN ALTBESTAND FAELLT NICHT LAUTLOS AUS (Befund C6) -----------
   * Er ist der Ersatz fuer die gestrichene persistente Schluesselliste aus N7. Frueher wurde er
   * als erledigt vermerkt, BEVOR die Abfrage losging, und jeder Teilvorgang hatte ein stummes
   * .catch — ein kurzer Leitungsausfall genau beim Start liess ihn fuer die ganze Laufzeit
   * ausfallen, ohne eine Zeile im Log. Genau dann bleibt die Karteileiche stehen, gegen die er
   * gebaut ist: die Kachel eines abgehaengten Patienten mit eingefrorenem altMs.
   */
  console.log('\n--- Der Altbestand wird nachgeholt (C6) ------------------------------------');
  // Eine KARTEILEICHE aus einem frueheren Prozesslauf: dieser Patient wurde vor dem Neustart
  // abgehaengt, seine Zeile liegt aber noch in der Datenbank. Genau sie soll der Blick finden.
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'saele', SID.rest, 'patients', 'sw_hund_99', 'vitals'], { hr: 55 });
  ablehnen.altbestand = SID.rest;
  const pubAB = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Altbestand', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.ab', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.rest), tafelTaktMs: 250, ruheTaktMs: 250, leseTaktMs: 500 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubAB.anmelden('altbestand@test.de', 'geheim123');
  await warmlaufen(pubAB);
  await wait(300);
  ok('faellt der Blick auf den eigenen Altbestand aus, gilt er NICHT als erledigt',
    pubAB._altbestandGeholt === false && pubAB._saalAltbestand === null,
    'geholt=' + pubAB._altbestandGeholt + ' versuche=' + pubAB._altbestandVersuche);
  ok('er wurde ueberhaupt versucht (sonst prueft die Zeile darueber nichts)',
    pubAB._altbestandVersuche >= 1, String(pubAB._altbestandVersuche));
  ablehnen.altbestand = null;
  const wR = captured.writes.length;
  for (let i = 0; i < 8; i++) { pubAB.publish([], []); await wait(200); }
  await wait(200);
  ok('sobald die Leitung wieder steht, wird der Blick NACHGEHOLT',
    pubAB._altbestandGeholt === true,
    'geholt=' + pubAB._altbestandGeholt + ' versuche=' + pubAB._altbestandVersuche);
  ok('er gibt nach hoechstens drei Fehlversuchen auf, statt endlos abzufragen',
    pubAB._altbestandVersuche <= 3, String(pubAB._altbestandVersuche));
  /*
   * DAS IST DER GRUND FUER DEN GANZEN BLICK, und deshalb wird er am ERGEBNIS gemessen und nicht an
   * einem Merker: die Karteileiche muss verschwinden. Bliebe sie stehen, zeigte jede Fern-Ansicht
   * dauerhaft einen Patienten mit eingefrorenem Alter und plausiblen Vitalwerten, und niemand kann
   * ihm ansehen, dass er seit dem Neustart nicht mehr am Geraet haengt. Von 'sw_hund_99' weiss
   * dieser Prozess ausschliesslich aus dem nachgeholten Blick — kommt die Loeschung, hat er
   * stattgefunden.
   */
  ok('und die Karteileiche aus dem frueheren Lauf wird ausdruecklich geloescht (null)',
    captured.writes.slice(wR).some((w) => w.body['saele/' + SID.rest + '/patients/sw_hund_99'] === null),
    captured.writes.slice(wR).map((w) => Object.keys(w.body).join(',')).join(' | ').slice(0, 200));
  ok('am Datenbestand gemessen: sie ist wirklich weg',
    dbHole(DB, ['live', 'UIDPRAXIS1', 'saele', SID.rest, 'patients', 'sw_hund_99']) === null,
    JSON.stringify(dbHole(DB, ['live', 'UIDPRAXIS1', 'saele', SID.rest, 'patients', 'sw_hund_99'])));
  // Und der normale Betrieb laeuft danach unveraendert weiter.
  for (let i = 0; i < 4; i++) { pubAB.publish(samplePatients(45 + i), []); await wait(160); }
  await wait(200);
  ok('der Saal schreibt danach ganz normal weiter',
    !!dbHole(DB, ['live', 'UIDPRAXIS1', 'saele', SID.rest, 'patients', keyHund, 'vitals']));

  /*
   * DIESELBE KARTEILEICHE, ABER IM TAFELZWEIG (Befund 17.08.2026).
   *
   * Der Block darueber prueft Weg S (saele/<sid>/patients). Weg T (tafel/<sid>/uebersicht) hatte
   * KEINE Pruefung — und genau dort blieb die Kachel stehen. Der Unterschied liegt in der
   * Reihenfolge: _altbestandLesen() traegt seinen Fund in drei Gedaechtnisse ein, und der
   * Tafelstand wurde frueher nur uebernommen, WENN noch keiner dastand ("if (!this._tafelStand)").
   * Kam die Antwort NACH dem ersten erfolgreichen Tafel-Schreibvorgang — und genau das erzwingt
   * dieser Test mit ablehnen.altbestand —, wurden die alten Schluessel verworfen und die Kachel nie
   * geloescht. Sie stand dann in JEDER Fern-Ansicht und im Nachbarstreifen, mit eingefrorenen
   * Werten und frischem Alter, weil das Alter aus dem laufenden Herzschlag gerechnet wird.
   *
   * Seit dem 17.08.2026 wird VEREINIGT statt uebersprungen. Von 'sw_geist_77' weiss dieser Prozess
   * ausschliesslich aus dem nachgeholten Blick — kommt die Loeschung, hat die Vereinigung gewirkt.
   */
  console.log('\n--- Die Karteileiche im TAFELZWEIG (Weg T) --------------------------------');
  dbSetze(DB, ['live', 'UIDPRAXIS1', 'tafel', SID.tafelrest, 'uebersicht', 'sw_geist_77'],
    { n: 'Geist', hr: 77 });
  ablehnen.altbestand = SID.tafelrest;          // der Blick faellt zunaechst aus -> Tafel schreibt zuerst
  const pubTR = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    station: 'Tafelrest', minIntervalMs: 100, firestoreUrl: base, archiv: { enabled: false },
    authFile: authFile + '.t', identityUrl: base + '/identity', tokenUrl: base + '/token',
    stationDatei: stationsDatei(SID.tafelrest), tafelTaktMs: 200, ruheTaktMs: 250, leseTaktMs: 400 },
    { log: { info() {}, warn() {}, error() {} } });
  await pubTR.anmelden('tafelrest@test.de', 'geheim123');
  await warmlaufen(pubTR);
  // Erst schreiben lassen, SOLANGE der Altbestand noch nicht gelesen ist: so entsteht die
  // Reihenfolge, an der die alte Fassung scheiterte.
  for (let i = 0; i < 3; i++) { pubTR.publish(samplePatients(60 + i), []); await wait(220); }
  ok('die Tafel hat geschrieben, BEVOR der Altbestand gelesen war (sonst prueft der Rest nichts)',
    pubTR._tafelStand !== null && pubTR._altbestandGeholt === false,
    'stand=' + JSON.stringify(pubTR._tafelStand) + ' geholt=' + pubTR._altbestandGeholt);
  ablehnen.altbestand = null;               // ab jetzt gelingt der Blick — er kommt also ZU SPAET
  const wT = captured.writes.length;
  for (let i = 0; i < 8; i++) { pubTR.publish(samplePatients(70 + i), []); await wait(200); }
  await wait(250);
  ok('der nachgeholte Blick wird trotz bereits gesetztem Tafelstand uebernommen',
    pubTR._altbestandGeholt === true && (pubTR._tafelStand.u || []).length >= 1,
    'geholt=' + pubTR._altbestandGeholt + ' u=' + JSON.stringify(pubTR._tafelStand && pubTR._tafelStand.u));
  ok('die Geisterkachel im Tafelzweig wird ausdruecklich geloescht (null)',
    captured.writes.slice(wT).some((w) => w.body['tafel/' + SID.tafelrest + '/uebersicht/sw_geist_77'] === null),
    captured.writes.slice(wT).map((w) => Object.keys(w.body).filter((k) => /uebersicht/.test(k)).join(',')).join(' | ').slice(0, 220));
  ok('am Datenbestand gemessen: die Kachel ist wirklich weg',
    dbHole(DB, ['live', 'UIDPRAXIS1', 'tafel', SID.tafelrest, 'uebersicht', 'sw_geist_77']) === null,
    JSON.stringify(dbHole(DB, ['live', 'UIDPRAXIS1', 'tafel', SID.tafelrest, 'uebersicht', 'sw_geist_77'])));
  /*
   * UND DAS GEDAECHTNIS DARF NICHT WACHSEN. Die naheliegende zweite Aenderung waere gewesen, auch
   * nach dem Erfolg zu vereinigen (statt _tafelStand = tp.stand). Nachgemessen am 17.08.2026 ueber
   * 60 Takte mit 20 wechselnden Patienten: das Gedaechtnis waere von 1 auf 20 Schluessel gewachsen
   * und haette bis zu 19 Loeschpfade JE TAKT in denselben atomaren Koerper gelegt, der die
   * Vitalwerte traegt. Deshalb steht die Vereinigung nur an der einen Stelle.
   */
  ok('nach dem Aufraeumen bleibt das Tafelgedaechtnis klein (kein Anwachsen je Takt)',
    (pubTR._tafelStand.u || []).length <= 3,
    'u=' + JSON.stringify(pubTR._tafelStand && pubTR._tafelStand.u));
  try { pubTR.stop && pubTR.stop(); } catch (_) {}

  /* --- 27) DIE NAHT: DER GESETZTE SAALNAME VERLAESST DEN PC (N10) ------------------------------
   *
   * Der Fehler, den dieser Block fuer immer festnagelt: cloud.js rechnete seinen Saalnamen selbst
   * aus (this.station = cfg.station || 'VetStation') und war damit die ZWEITE Namensquelle neben
   * stationsid.stationsName(). Der Admin-Bereich speicherte den eingegebenen Namen, zeigte ihn an
   * und meldete Erfolg — in Tafel, Kompatibilitaetsspiegel und Firestore-Verlauf stand weiter der
   * Wert aus bridge/config/devices.json. Die Datei existiert im Auslieferstand gar nicht, ALLE
   * Saele aller Praxen hiessen also gleich. Die Oberflaeche behauptete das Gegenteil.
   *
   * UND DER NAME DARF NICHT EINGEFROREN SEIN: umbenannt wird im laufenden Betrieb (die Station
   * laeuft weiter, der Name aendert sich). Ein Feld, das nur beim Start gesetzt wird, haette den
   * alten Namen bis zum naechsten Programmstart weitergesendet.
   */
  console.log('\n--- Die Naht: der gesetzte Saalname verlaesst den PC (N10) -----------------');
  const namStation = new stationsidModul.Stationsid({
    log: { info() {}, warn() {}, error() {} }, datei: stationsDatei(SID.name),
  });
  await namStation.laden();
  const pubN = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
    // cfg.station ist ab jetzt reine VORBELEGUNG — und hier steht ausdruecklich der VORLAGEWERT
    // aus devices.example.json. Er darf nicht als Name durchgehen.
    station: 'Praxis OP 1', minIntervalMs: 100, firestoreUrl: base,
    authFile: authFile + '.n', identityUrl: base + '/identity', tokenUrl: base + '/token',
    tafelTaktMs: 250, vollbildMs: 60000,
    archiv: { enabled: true, intervalMs: 5000, projectId: 'vet-station' } },
    { log: { info() {}, warn() {}, error() {} }, stationsid: namStation });
  await pubN.anmelden('name@test.de', 'geheim123');
  await warmlaufen(pubN);
  ok('der Publisher benutzt die UEBERGEBENE Stationskennung (eine Instanz, ein Saal)',
    pubN.status(true).sid === SID.name, String(pubN.status(true).sid));
  ok('der Vorlagewert aus devices.example.json zaehlt NICHT als Saalname',
    pubN.station === null, JSON.stringify(pubN.station));
  ok('der Zustand nennt den Saal dann ausdruecklich unbenannt statt einen Namen zu erfinden',
    pubN.status().station === tafel.SPIEGEL_NAME_UNBENANNT, String(pubN.status().station));
  const wN0 = captured.writes.length;
  for (let i = 0; i < 3; i++) { pubN.publish(samplePatients(50 + i), []); await wait(140); }
  await wait(200);
  const kopfOhneNamen = (koerperMit(wN0, 'tafel/' + SID.name + '/meta')
    .map((w) => w.body['tafel/' + SID.name + '/meta']).filter((x) => x)).pop();
  ok('und der Tafelkopf traegt dann gar kein Namensfeld (statt eines erfundenen)',
    !!kopfOhneNamen && !('name' in kopfOhneNamen), JSON.stringify(kopfOhneNamen && kopfOhneNamen.name));
  ok('auch der Firestore-Verlauf nennt den Saal ehrlich unbenannt',
    captured.firestore.length > 0
    && captured.firestore[captured.firestore.length - 1].body.fields.station.stringValue
      === tafel.SPIEGEL_NAME_UNBENANNT,
    JSON.stringify(captured.firestore.length
      ? captured.firestore[captured.firestore.length - 1].body.fields.station : null));

  // Jetzt tippt ein Mensch im Admin-Bereich einen Namen ein — WAEHREND die Station laeuft.
  const fs0N = captured.firestore.length;
  ok('der gesetzte Name kommt ueberhaupt in der einen Quelle an',
    namStation.setzeName('OP 3 (Zahn)') === 'OP 3 (Zahn)' && pubN.station === 'OP 3 (Zahn)',
    String(pubN.station));
  // Den Ruhetakt des Archivs (Untergrenze 5 s) fuer diese eine Messung ueberspringen — DASS er
  // eingehalten wird, ist in Block 12 geprueft; hier geht es um den INHALT des Feldes.
  pubN.letztesArchiv = 0;
  const wN1 = captured.writes.length;
  for (let i = 0; i < 6; i++) { pubN.publish(samplePatients(60 + i), []); await wait(140); }
  await wait(250);
  const kopfMitNamen = (koerperMit(wN1, 'tafel/' + SID.name + '/meta')
    .map((w) => w.body['tafel/' + SID.name + '/meta']).filter((x) => x)).pop();
  ok('DER GESETZTE NAME STEHT IM TAFELKOPF — er verlaesst den PC',
    !!kopfMitNamen && kopfMitNamen.name === 'OP 3 (Zahn)', JSON.stringify(kopfMitNamen && kopfMitNamen.name));
  ok('und er steht auch im Firestore-Verlauf (dort liest ihn spaeter die Fallakte)',
    captured.firestore.length > fs0N
    && captured.firestore[captured.firestore.length - 1].body.fields.station.stringValue === 'OP 3 (Zahn)',
    JSON.stringify(captured.firestore.length > fs0N
      ? captured.firestore[captured.firestore.length - 1].body.fields.station : null));

  /*
   * Und noch einmal, mitten im Betrieb: der Name darf in KEINEM Feld eingefroren sein, das nur beim
   * Start gesetzt wird. Ein umbenannter Saal bleibt derselbe Saal — die Kennung aendert sich nicht.
   */
  namStation.setzeName('OP 4 (Roentgen)');
  const wN2 = captured.writes.length;
  for (let i = 0; i < 6; i++) { pubN.publish(samplePatients(70 + i), []); await wait(140); }
  await wait(250);
  const kopfNeu = (koerperMit(wN2, 'tafel/' + SID.name + '/meta')
    .map((w) => w.body['tafel/' + SID.name + '/meta']).filter((x) => x)).pop();
  ok('eine Umbenennung WAEHREND des Betriebs kommt sofort an (kein eingefrorenes Feld)',
    !!kopfNeu && kopfNeu.name === 'OP 4 (Roentgen)', JSON.stringify(kopfNeu && kopfNeu.name));
  ok('die Stationskennung aendert sich dabei NICHT — ein umbenannter Saal bleibt derselbe Saal',
    pubN.status(true).sid === SID.name, String(pubN.status(true).sid));
  ok('die Kappung auf 120 Zeichen bleibt (die Regel fuer meta/station laesst nicht mehr zu)',
    (namStation.setzeName('Z'.repeat(400)), pubN.station.length === 120), String(pubN.station.length));
  // Und eine echte Vorbelegung (kein Vorlagewert) wird weiterhin angenommen, solange nichts gesetzt ist.
  ok('eine echte Vorbelegung aus devices.json gilt weiter, solange kein Name gesetzt ist',
    pub.station === 'Test-OP', String(pub.station));

  /* --- 28) DER EINZELWEG DES PROTOKOLLS DARF KEINE ZEILE VERSCHLUCKEN -------------------------
   *
   * Der Fall (gefunden am 31.07.2026): schlaegt ein einzelner Protokoll-Schreibvorgang mit
   * "Permission denied" fehl, hat das ZWEI moegliche Ursachen — die Zeile liegt schon dort
   * (Unveraenderlichkeits-Regel, harmlos) ODER die Anmeldung gilt nicht mehr (ernst). Der Weg
   * vermerkte sie frueher pauschal als erledigt. Bei der zweiten Ursache fehlte sie damit fuer
   * immer im Narkoseprotokoll, denn Protokollzeilen sind unveraenderlich und werden nie wieder
   * angeboten. Lautlos.
   *
   * Geprueft wird deshalb der ernste Fall: Ablehnung UND die Datenbank kann NICHT bestaetigen,
   * dass die Zeile dort liegt. Dann darf sie nicht als gesendet gelten.
   * Geprueft wird ohne Netz, mit untergeschobenem Schreib- und Leseweg — so haengt die Pruefung
   * nicht an der Bauform des Mocks und bleibt auch nach dessen naechstem Umbau aussagekraeftig.
   */
  {
    const pubX = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
      station: 'X', minIntervalMs: 1, firestoreUrl: base, archiv: { enabled: false },
      authFile: authFile + '.x', identityUrl: base + '/identity', tokenUrl: base + '/token' },
      { log: { info() {}, warn() {}, error() {} } });
    await pubX.anmelden('einzelweg@test.de', 'geheim123');
    const SIDX = 'st0123456789ab';
    pubX.protokollEinzeln = true;
    pubX._letzterAbgleich = 0;
    // Jeder Schreibvorgang wird von der Regel abgelehnt; der flache Blick findet NICHTS.
    pubX._write = () => Promise.reject(new Error('HTTP 401: {"error":"Permission denied"}'));
    pubX._reqJson = () => Promise.resolve(null);

    const pfad = 'protokoll/Bello/1900000000000';
    const koerper = {}; koerper[pfad] = { ts: 1900000000000, hr: 44 };
    pubX._protokollEinzelweise(koerper, 'TOK', SIDX);
    await wait(400);
    ok('Einzelweg: eine NICHT bestaetigte Zeile gilt nicht als gesendet',
      !(pubX._protokollGesendet['Bello'] && pubX._protokollGesendet['Bello']['1900000000000']),
      JSON.stringify(pubX._protokollGesendet));
    ok('Einzelweg: der Fehler wird gezaehlt (sonst dreht er sich lautlos im Kreis)',
      pubX.protokollFehlerZahl >= 1, String(pubX.protokollFehlerZahl));

    // Zwei weitere Anlaeufe -> Protokolluebertragung schaltet sich ab und sagt es.
    for (let i = 0; i < 2; i++) { pubX.protokollInFlight = false; pubX._protokollEinzelweise(koerper, 'TOK', SIDX); await wait(300); }
    ok('Einzelweg: nach drei erfolglosen Anlaeufen wird die Protokolluebertragung abgeschaltet',
      pubX.protokollAus === true, 'Zahl: ' + pubX.protokollFehlerZahl);
    ok('Einzelweg: die Vitaluebertragung bleibt davon unberuehrt',
      pubX.konfigFehler === 0 && pubX.abgeschaltet === false,
      'konfigFehler=' + pubX.konfigFehler + ' abgeschaltet=' + pubX.abgeschaltet);

    // Gegenprobe: bestaetigt die Datenbank die Zeile, DARF sie als erledigt gelten.
    const pubY = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
      station: 'Y', minIntervalMs: 1, firestoreUrl: base, archiv: { enabled: false },
      authFile: authFile + '.y', identityUrl: base + '/identity', tokenUrl: base + '/token' },
      { log: { info() {}, warn() {}, error() {} } });
    await pubY.anmelden('einzelweg2@test.de', 'geheim123');
    pubY.protokollEinzeln = true; pubY._letzterAbgleich = 0;
    pubY._write = () => Promise.reject(new Error('HTTP 401: {"error":"Permission denied"}'));
    pubY._reqJson = () => Promise.resolve({ '1900000000000': true });
    pubY._protokollEinzelweise(koerper, 'TOK', SIDX);
    await wait(400);
    ok('Einzelweg: eine BESTAETIGTE Zeile gilt als erledigt und wird nicht wiederholt',
      !!(pubY._protokollGesendet['Bello'] && pubY._protokollGesendet['Bello']['1900000000000']),
      JSON.stringify(pubY._protokollGesendet));
  }

  /* --- 29) ZWEI ANGABEN AUS DEMSELBEN ZEITPUNKT -----------------------------------------------
   *
   * Der Fall (an zwei echten Stationen gemessen, 31.07.2026): modusAus() benutzt "wir haben ein
   * qs-Kind geschrieben, aber im gelesenen Stand fehlt es" als Beweis dafuer, dass hier eine
   * 1.0.3 schreibt. Der gelesene Stand hinkt dem Schreibvorgang aber um einen Lesetakt hinterher.
   * Beim ALLERERSTEN eigenen qs-Schreibvorgang meldete cloud.js deshalb beides gleichzeitig:
   * "geschrieben: ja" und "im Stand fehlt es" — und die Station erklaerte eine nagelneue
   * Nachbarstation zur 1.0.3. Folge: 5 Minuten lang nichts mehr auf der flachen Ebene, auch keine
   * Loeschung; die ausgelieferte Web-App zeigte ein Tier mit eingefrorenen Zahlen als LIVE.
   *
   * Geprueft wird die UEBERGABE, nicht das Ergebnis: modusAus() ist in tafel.js fuer sich geprueft
   * und richtig — der Fehler sass darin, WAS cloud.js ihm sagt. Genau solche Nahtstellen sind in
   * diesem Umbau dreimal teuer geworden.
   */
  {
    const tafelModul = require('../bridge/src/tafel');
    const echtesModusAus = tafelModul.modusAus;
    const gesehen = [];
    tafelModul.modusAus = function (args) { gesehen.push(args.qsGeschrieben); return echtesModusAus(args); };

    const pubZ = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
      station: 'Z', minIntervalMs: 1, firestoreUrl: base, archiv: { enabled: false },
      authFile: authFile + '.z2', identityUrl: base + '/identity', tokenUrl: base + '/token' },
      { log: { info() {}, warn() {}, error() {} } });
    await pubZ.anmelden('naht@test.de', 'geheim123');
    /* Eine schlanke Stationskennung genuegt: geprueft wird die UEBERGABE an modusAus(), nicht der
     * Schreibweg. Ohne sie wirft _spiegelSchreiben(), bevor es ueberhaupt dorthin kommt. */
    pubZ.stationsid = { instanz: '0123456789abcdef', name: () => 'Z', darfPatientendatenSchreiben: () => true };
    const jetzt = Date.now();
    const argZ = { jetzt: jetzt, now: jetzt, sid: 'st0123456789ab', darf: true, snapshot: null };

    // Lage genau nach dem ersten eigenen Schreibvorgang: geschrieben JA, Rueckleseweg noch aelter.
    pubZ._qsGeschrieben = true; pubZ._qsGeschriebenAm = jetzt; pubZ._flachGelesenAm = jetzt - 1000;
    gesehen.length = 0;
    try { pubZ._spiegelSchreiben(argZ); } catch (e) { /* der Schreibweg selbst ist hier egal */ }
    ok('Naht: ein Rueckleseweg, der AELTER ist als unser Schreibvorgang, gilt nicht als Beweis',
      gesehen.length > 0 && gesehen[gesehen.length - 1] === false, JSON.stringify(gesehen));

    // Sobald der Rueckleseweg nachgezogen hat, zaehlt die Aussage wieder — sonst waere der
    // zweite Beweisweg fuer eine ECHTE 1.0.3 dauerhaft ausgeschaltet, und dann ueberschriebe sie
    // ungehindert die flache Ebene.
    pubZ._qsGeschrieben = true; pubZ._qsGeschriebenAm = jetzt; pubZ._flachGelesenAm = jetzt + 1000;
    gesehen.length = 0;
    try { pubZ._spiegelSchreiben(argZ); } catch (e) {}
    ok('Naht: ein NEUERER Rueckleseweg zaehlt weiterhin als Beweis',
      gesehen.length > 0 && gesehen[gesehen.length - 1] === true, JSON.stringify(gesehen));

    tafelModul.modusAus = echtesModusAus;
  }

  try { fs.unlinkSync(authFile); } catch (_) {}
  ['.k', '.s', '.a', '.r', '.m', '.z', '.t', '.f', '.u', '.h',
    '.w', '.c', '.d', '.ab', '.n', '.x', '.y', '.z2'].forEach((e) => { try { fs.unlinkSync(authFile + e); } catch (_) {} });
  stationsDateienWeg();
  srv.close();
  console.log('\nErgebnis: ' + pass + ' OK, ' + fail + ' Fehler.');
  process.exit(fail ? 1 : 0);

  function waitForPut(n) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      (function poll() {
        if (captured.puts.length >= n) return resolve();
        if (Date.now() - t0 > 5000) return reject(new Error('Timeout: erwartet >=' + n + ' PUTs, hatte ' + captured.puts.length));
        setTimeout(poll, 20);
      })();
    });
  }
  function waitForWrite(n) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      (function poll() {
        if (captured.writes.length >= n) return resolve();
        if (Date.now() - t0 > 5000) return reject(new Error('Timeout: erwartet >=' + n + ' Schreibvorgaenge, hatte ' + captured.writes.length));
        setTimeout(poll, 20);
      })();
    });
  }
  /*
   * Wie waitForWrite, aber OHNE Abbruch — liefert nur true/false zurueck.
   *
   * Gebraucht fuer die Pruefungen des Protokoll-Fehlers (Bloecke 13, 13b, 13c): dort ist das
   * AUSBLEIBEN eines Schreibvorgangs genau der Befund. Mit dem abbrechenden waitForWrite haette die
   * alte, fehlerhafte Fassung den Test mit "Timeout" abgeschossen, statt die betroffenen Zeilen als
   * ✗ auszuweisen — und wer den Test dann liest, sieht einen Werkzeugfehler statt der Ursache.
   */
  function warteAufWrite(n, ms) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      (function poll() {
        if (captured.writes.length >= n) return resolve(true);
        if (Date.now() - t0 > (ms || 1200)) return resolve(false);
        setTimeout(poll, 20);
      })();
    });
  }
}

run().catch(e => { console.error('TESTFEHLER:', e); try { srv.close(); } catch (_) {} process.exit(1); });
