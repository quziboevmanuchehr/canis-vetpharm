'use strict';
/*
 * update-paket-test.js — prueft das AUSGELIEFERTE Update-Paket dist/VetStation-<version>.zip.
 *
 * WARUM (Befund 21.07.2026): Bei 0.6.0 gab es zuerst eine neue Setup.exe, aber KEIN Update-Paket.
 * Eine bereits laufende Praxis-Station haette also gar nicht nachziehen koennen — der einzige
 * Weg ohne USB-Stick war tot, ohne dass es jemandem aufgefallen waere.
 * Zweite Gefahr: geraet node\ mit hinein, wird aus 0,7 MB ein 27-MB-Download (die Praxis haengt
 * an einer normalen Leitung); geraet data\ hinein, ueberschreibt das Update die Betriebsdaten.
 *
 * Das Paket entsteht erst beim Bauen (SETUP-BAUEN.bat). Ist keins da, wird das ehrlich als
 * UEBERSPRUNGEN gemeldet — nicht als Fehler und erst recht nicht als "in Ordnung".
 *
 * Start: node tools/update-paket-test.js      (laeuft auch in `npm test`)
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0, skip = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function uebersprungen(n, grund) { skip++; console.log('  ○ ' + n + '  (uebersprungen: ' + grund + ')'); }

// Eintragsnamen direkt aus dem zentralen ZIP-Verzeichnis lesen (keine Fremdbibliothek noetig).
const SIG = Buffer.from([0x50, 0x4b, 0x01, 0x02]);
function zipEintraege(datei) {
  const b = fs.readFileSync(datei);
  const out = [];
  let i = 0;
  while ((i = b.indexOf(SIG, i)) >= 0) {
    const len = b.readUInt16LE(i + 28);
    // Windows-PowerShell schreibt Backslash-Pfade in die ZIP (nicht normgerecht, aber
    // Expand-Archive liest sie - so sind ALLE bisherigen Releases gebaut). Deshalb normalisieren.
    out.push(b.slice(i + 46, i + 46 + len).toString('utf8').split('\\').join('/'));
    i += 46 + len;
  }
  return out;
}

console.log('VetStation — ausgeliefertes Update-Paket\n');

const version = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const zipPfad = path.join(ROOT, 'dist', 'VetStation-' + version + '.zip');
console.log('  Erwartet: dist/VetStation-' + version + '.zip\n');

if (!fs.existsSync(zipPfad)) {
  uebersprungen('Update-Paket vorhanden', 'noch nicht gebaut — SETUP-BAUEN.bat doppelklicken');
  console.log('\n' + pass + ' bestanden, ' + fail + ' fehlgeschlagen, ' + skip + ' uebersprungen');
  process.exit(0);
}

const eintraege = zipEintraege(zipPfad);
const groesse = fs.statSync(zipPfad).size;
ok('Update-Paket ist vorhanden und nicht leer', eintraege.length > 50, eintraege.length + ' Eintraege');

// Die teuerste Verwechslung: node\ mit eingepackt -> 27 MB statt 0,7 MB.
console.log('\nGroesse und Ausschluesse:');
ok('node\\ ist NICHT enthalten (sonst 27 MB statt 0,7 MB)',
  eintraege.filter((x) => x.indexOf('node/') === 0).length === 0);
ok('data\\ ist NICHT enthalten (Betriebsdaten des Kunden)',
  eintraege.filter((x) => x.indexOf('data/') === 0).length === 0);
/*
 * ...UND AUCH NICHT TIEFER IM BAUM (Befund 27.07.2026).
 * Die Pruefung oben sah nur den obersten Ordner. bridge/data/ rutschte deshalb unbemerkt mit ins
 * Paket - und dort liegen patient-akte.json und protokoll.json, also PATIENTENDATEN. Das Paket
 * wird auf einer oeffentlichen Webseite veroeffentlicht; auf einem Rechner, der die echte Station
 * betrieben hat, waeren das echte Patientenakten gewesen. Deshalb jetzt: KEIN data-Ordner,
 * egal auf welcher Ebene.
 */
const datenReste = eintraege.filter((x) => /(^|\/)data\//.test(x));
ok('auch kein data-Ordner TIEFER im Baum (z. B. bridge/data mit Patientenakten)',
  datenReste.length === 0, datenReste.slice(0, 5).join(', '));
ok('keine Patientenakte im Paket', !eintraege.some((x) => /patient-akte\.json$/.test(x)));
ok('kein Protokoll im Paket', !eintraege.some((x) => /protokoll\.json$/.test(x)));
/*
 * KEINE .git-RESTE (Befund 27.07.2026, echter Ausfall beim Kunden-Update).
 * In einem Git-Arbeitsbaum ist ".git" eine DATEI mit einem Zeiger, kein Ordner — robocopy /XD
 * hat sie deshalb nicht ausgeschlossen. Auf der Station hielt der Updater die Installation
 * daraufhin fuer ein Git-Checkout und rief "git pull" auf; der Tierarzt sah nur
 * "fatal: not a git repository: (NULL)" und konnte gar nicht mehr aktualisieren.
 */
ok('kein .git-Rest im Paket (sonst versucht der Updater "git pull")',
  !eintraege.some((x) => /(^|\/)\.git($|\/)/.test(x)),
  eintraege.filter((x) => /(^|\/)\.git($|\/)/.test(x)).join(', '));
ok('.git\\ ist NICHT enthalten', eintraege.filter((x) => x.indexOf('.git/') === 0).length === 0);
/*
 * KEINE devices.json (ab 1.1.0). Bis 1.0.3 entstand sie nur von Hand und tauchte auf einem
 * Entwicklerrechner praktisch nie auf. Seit die Station gefundene Geraete SELBST eintraegt
 * (bridge/src/erstsuche.js), kann sie in jedem Arbeitsbaum liegen, in dem die Bridge einmal
 * gelaufen ist — mit den Geraeteadressen und dem Saalnamen einer echten Praxis, in einem Paket,
 * das oeffentlich abrufbar ist. Und ein Update wuerde damit die Konfiguration des Kunden
 * ueberschreiben. Die .example bleibt ausdruecklich drin: sie IST die Vorlage.
 */
ok('keine devices.json im Paket (Praxis-Konfiguration, seit 1.1.0 selbst geschrieben)',
  !eintraege.some((x) => /(^|\/)devices\.json$/.test(x)),
  eintraege.filter((x) => /devices\.json$/.test(x)).join(', '));
ok('devices.example.json ist dagegen enthalten (die Vorlage)',
  eintraege.some((x) => /devices\.example\.json$/.test(x)));
/*
 * KEIN BUCHWISSEN IM OEFFENTLICHEN PAKET (15.08.2026, Entscheidung des Nutzers).
 *
 * ui/shared/kardio-regeln.js (1113 KB, ein sechstes Fachbuch) und ui/shared/ekg-literatur.js
 * (516 KB, fuenf Werke) sind Auswertungen lizenzierter Vorlagen. Das Paket liegt oeffentlich
 * auf GitHub Pages; die Setup.exe geht dagegen per USB in die Praxis und traegt beide weiter.
 * Ausgeschlossen werden sie in installer/make-dist.ps1 unter $nichtInsUpdate - eine Liste, die
 * jemand pflegen muss. Diese Pruefung ist die Gegenprobe dazu.
 *
 * UND DIE ANDERE RICHTUNG GLEICH MIT: dosis-warnungen.js MUSS im Paket liegen. Sie traegt die
 * Richtigstellung zur tausendfach zu hohen Dauertropfdosis und ist genau deshalb aus der
 * grossen Datei herausgeloest worden - eine Station behaelt beim Update ihre alte
 * ekg-literatur.js (robocopy /E, ohne /MIR), und die kennt die Warnung nicht. Faellt die
 * kleine Datei aus dem Paket, ist die Warnung still wieder weg. Ein Riegel, der nur in eine
 * Richtung prueft, hat in diesem Projekt schon einmal den eigenen Update-Knopf ausgesperrt.
 */
const nurUeberSetup = ['ui/shared/kardio-regeln.js', 'ui/shared/ekg-literatur.js'];
nurUeberSetup.forEach((f) => {
  ok('kein Buchwissen im oeffentlichen Paket: ' + f + ' fehlt (kommt ueber die Setup.exe)',
    eintraege.indexOf(f) < 0);
});
ok('die Richtigstellungen fahren dagegen MIT (ui/shared/dosis-warnungen.js)',
  eintraege.indexOf('ui/shared/dosis-warnungen.js') >= 0,
  'ohne sie zeigt eine aktualisierte Station die 1000-fach zu hohe Dosis ungewarnt');
/*
 * GRENZE 5 -> 8 MB (07.08.2026), mit Begruendung statt aus Bequemlichkeit.
 * Seit dem Diagnostik-EKG traegt das Paket den WHQL-signierten USB-Treiber des EKG 2000
 * (treiber/ekg2000, komprimiert rund 1,6 MB). Das ist gewollt: der Nutzer soll nach der
 * Installation KEIN zweites Treiber-Setup mehr fahren muessen — und ein Update soll einen
 * neueren Treiber ebenso ausliefern koennen. Die Grenze bleibt aber eine Grenze: sie ist
 * bewusst nur so weit angehoben, dass EIN Treiberpaket hineinpasst und nicht mehr. Wer hier
 * das naechste Mal ansteht, soll nachsehen, was gewachsen ist, statt die Zahl weiterzuschieben.
 * (Erinnerung: dieser Test LAESST FEHLSCHLAGEN, er warnt nicht nur.)
 */
ok('Paket bleibt unter 8 MB (Praxis haengt an einer normalen Leitung)', groesse < 8 * 1024 * 1024,
  Math.round(groesse / 1024) + ' KB');
/*
 * Der Treiber MUSS wirklich im Paket liegen. Ohne diese Pruefung faellt genau der Fall durch,
 * den der Nutzer ausdruecklich ausgeschlossen haben wollte: eine Station aktualisiert sich,
 * meldet die neue Fassung — und das EKG bleibt am USB-Anschluss stumm, weil die .inf fehlt.
 */
/* DER FREIGABESCHLUESSEL MUSS IM PAKET LIEGEN (13.08.2026).
 *
 * Ohne updater/release-key.pub kann eine Station nicht entscheiden, ob ein Paket echt ist -
 * und sie lehnt seit 1.16.0 dann JEDES Update ab (updater/signatur.js, bewusst so: lieber
 * gar nicht aktualisieren als blind). Faellt die Datei bei einem kuenftigen Umbau aus dem
 * Paket, merkt das niemand beim Bauen, sondern erst der Tierarzt beim naechsten Update -
 * und dann auf allen Stationen gleichzeitig. Genau diese Sorte stillen Ausfalls hat dieses
 * Projekt schon zweimal getroffen (Kopierliste der Web-App, EKG-Treiber). */
const treiberPflicht = ['treiber/ekg2000/ftdibus.inf', 'treiber/ekg2000/ftdiport.inf',
  'treiber/ekg2000/ftdibus.cat', 'treiber/ekg2000/ftdiport.cat',
  'treiber/ekg2000/amd64/ftdibus.sys', 'treiber/ekg2000/amd64/ftser2k.sys',
  'installer/set-ekg-treiber.ps1',
  'updater/release-key.pub', 'updater/signatur.js'];
treiberPflicht.forEach((p) => {
  const gesucht = p.replace(/\//g, '\\');
  ok('EKG-2000-Treiber im Paket: ' + p,
    eintraege.some((x) => x.replace(/\//g, '\\').toLowerCase() === gesucht.toLowerCase()));
});

// Was drin sein MUSS, damit die aktualisierte Station auch wirklich die neue Fassung ist.
console.log('\nProgrammdateien im Paket:');
[
  'package.json',
  'bridge/src/index.js', 'bridge/src/server.js', 'bridge/src/logger.js',
  'bridge/src/netscan.js', 'bridge/src/diagnose.js', 'bridge/src/firewall.js', 'bridge/src/version.js',
  'bridge/src/adapters/hl7.js', 'bridge/src/adapters/probe.js',
  /*
   * Die Bausteine fuer MEHRERE OP-SAELE (ab 1.1.0). Sie stehen hier einzeln und nicht als
   * Sammelpruefung "bridge/src/*.js", weil ein FEHLENDER einzelner die schlimmste Sorte Fehler
   * ergibt: die Station startet, der eigene Saal laeuft, und nur die Nachbarn fehlen — mit einer
   * Meldung, die nach einem Netzproblem aussieht. Wer hier eine Datei ergaenzt, ergaenzt sie auch
   * in make-dist.ps1.
   */
  'bridge/src/stationsid.js', 'bridge/src/tafel.js', 'bridge/src/tafelabo.js',
  'bridge/src/fremdstore.js', 'bridge/src/nachbar.js',
  /* Die automatische Suche beim ersten Start — ohne sie findet eine frisch installierte Station
   * ihre Geraete erst, wenn jemand im Admin-Bereich auf "Suche starten" klickt. */
  'bridge/src/erstsuche.js',
  'ui/views/admin.js', 'ui/vetstation-live.js', 'ui/vetstation-nachbarn.js', 'ui/index.html',
  'updater/version.json', 'updater/updater.js',
  'kiosk/launch-kiosk.ps1', 'kiosk/stop-kiosk.ps1',
  /* Die Selbstheilung gegen eine EINGEFRORENE Station (1.2.1, siehe
   * docs/BEFUND-EINGEFROREN-2026-08-01.md). Fehlt watchdog-entscheidung.ps1 im Paket, bricht
   * watchdog.ps1 beim Dot-Sourcing ab — und zwar in einem versteckten Fenster, wo es niemand
   * sieht. Die Station liefe dann voellig unbewacht weiter: genau der Zustand, den 1.2.1
   * beseitigen soll, nur schlimmer, weil man ihn fuer behoben haelt. */
  'kiosk/watchdog.ps1', 'kiosk/watchdog-entscheidung.ps1', 'kiosk/watchdog-erkennung.ps1',
  'installer/set-firewall.ps1', 'installer/Install-VetStation.ps1',
  'tools/alle-tests.js', 'tools/geraete-check.js',
  'INSTALLIEREN.bat', 'NEUSTART.bat', 'FIREWALL-FREIGEBEN.bat', 'GERAETE-PRUEFEN.bat',
].forEach((f) => ok('enthaelt ' + f, eintraege.indexOf(f) >= 0));

// Die Version im Paket muss zu seinem Dateinamen passen — sonst meldet die Station nach dem
// Update eine andere Nummer als die, die geladen wurde (genau der Fehler aus Befund 2.4).
console.log('\nVersion im Paket:');
ok('der Dateiname nennt die Version aus der Wurzel-package.json', /VetStation-\d+\.\d+\.\d+\.zip$/.test(zipPfad));
ok('updater/version.json liegt bei (Station kennt danach ihre neue Nummer)',
  eintraege.indexOf('updater/version.json') >= 0);

console.log('\n' + (fail === 0
  ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' + (skip ? ' (' + skip + ' uebersprungen)' : '')
  : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
