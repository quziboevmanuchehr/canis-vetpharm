'use strict';
/*
 * webapp-saele-vollbild-test.js — zwei Aenderungen an der Fern-App vom 19.08.2026.
 *
 * 1) DIE OP-SAAL-KARTEN LASSEN SICH EINKLAPPEN. Auf dem Bildschirm des Praxis-PCs nehmen sie
 *    genau den Platz weg, auf dem die Werte des virtuellen Monitors stehen sollen (im
 *    Bildschirmfoto vom 19.08.2026 fuellen drei Karten das obere Drittel, waehrend darunter
 *    die Kurven angeschnitten sind).
 *
 * 2) VOLLBILD FUER MONITOR UND KAPNOGRAPH - dieselbe Mechanik wie in der Station.
 *
 * WARUM DIESER TEST DIE LOGIK RECHNET UND NICHT NUR QUELLTEXT LIEST:
 * tafelHtml() steckt im sechsten Skriptblock der Web-App (dem Fern-Modul) und ist von aussen
 * nicht aufrufbar. Ohne Verbindung gibt saalListe() eine leere Liste zurueck - im Browser
 * war der Knopf deshalb gar nicht im Baum, und ein reiner Sichttest haette "fehlt" gemeldet,
 * obwohl er richtig arbeitet. Deshalb wird die Funktion hier ausgeschnitten und mit
 * untergeschobenen Saelen gerechnet.
 *
 * Start: node tools/webapp-saele-vollbild-test.js
 */
var fs = require('fs');
var path = require('path');

var WA = path.join(__dirname, '..', '..', '..', 'canis-vetpharm', 'canis-anaesthesie', 'index.html');
var ST = path.join(__dirname, '..', 'ui', 'app', 'index.html');

var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

if (!fs.existsSync(WA)) {
  console.log('  ! HINWEIS: die Fern-App liegt nicht neben dem Quellbaum (' + WA + ').');
  console.log('    Auf einem Rechner ohne das zweite Repo ist das der Regelfall.');
  console.log('\n== Ergebnis: 0 OK, 0 FAIL (nichts zu pruefen) ==');
  process.exit(0);
}
var wa = fs.readFileSync(WA, 'utf8');
var st = fs.readFileSync(ST, 'utf8');
var waCode = wa.replace(/\/\*[\s\S]*?\*\//g, ' ');

console.log('VetStation — Fern-App: Saalleiste einklappen und Vollbild\n');

/* ---------------------------------------------------------------- 1) Saalleiste */
console.log('1) Die Saalleiste laesst sich einklappen:');
ok('es gibt den Umschaltknopf', /data-saele-tog/.test(wa));
ok('sein Zustand wird gemerkt (localStorage)', /vetlive_saele_zu/.test(waCode));
ok('… und ausgeklappt ist die Vorgabe',
  /var saeleZu = false;/.test(waCode),
  'Wer die Fern-Ansicht zum ersten Mal oeffnet, soll sehen, welche Saele es gibt');
ok('der Knopf hat einen Zuhoerer', /querySelectorAll\('\[data-saele-tog\]'\)/.test(waCode));
ok('und die Stilvorlage kennt ihn', /vetlive-saele-tog\{background/.test(wa));

/* Die Logik selbst rechnen. */
function schneide(q, kopf) {
  var a = q.indexOf(kopf);
  if (a < 0) return '';
  var t = q.indexOf('{', a), tiefe = 0, j = t;
  for (; j < q.length; j++) { if (q[j] === '{') tiefe++; else if (q[j] === '}') { tiefe--; if (!tiefe) break; } }
  return q.slice(a, j + 1);
}
var quelle = schneide(wa, 'function tafelHtml()');
ok('tafelHtml() liess sich ausschneiden (' + quelle.split('\n').length + ' Zeilen)', quelle.length > 200);

var bauen = null;
try {
  bauen = new Function('saalListe', 'DECKEL_SAELE', 'saalKarte', 'saeleZu',
    quelle + '\n; return tafelHtml;');
} catch (e) { console.log('  (nicht ausfuehrbar: ' + e.message + ')'); }

if (bauen) {
  var karten = function (s) { return '<div class="s-karte">' + s.name + '</div>'; };
  var drei = [{ name: 'A' }, { name: 'B' }, { name: 'C' }];

  var offen = bauen(function () { return drei; }, 8, karten, false)();
  var zu = bauen(function () { return drei; }, 8, karten, true)();
  var leer = bauen(function () { return []; }, 8, karten, false)();

  ok('ausgeklappt stehen alle drei Karten da',
    (offen.match(/s-karte/g) || []).length === 3, offen.slice(0, 90));
  ok('eingeklappt steht KEINE Karte mehr da',
    (zu.match(/s-karte/g) || []).length === 0, zu.slice(0, 90));
  ok('der Knopf bleibt aber in BEIDEN Zustaenden sichtbar',
    offen.indexOf('data-saele-tog') >= 0 && zu.indexOf('data-saele-tog') >= 0,
    'Sonst gaebe es eingeklappt keinen Weg zurueck');
  ok('eingeklappt nennt er die Zahl der Saele',
    /OP-Säle \(3\)/.test(zu), zu.slice(0, 120));
  ok('ohne Saal bleibt die Leiste ganz weg', leer === '', JSON.stringify(leer).slice(0, 80));

  /* Der Deckel darf durch die Aenderung nicht verlorengehen. */
  var viele = []; for (var i = 0; i < 12; i++) viele.push({ name: 'S' + i });
  var mitDeckel = bauen(function () { return viele; }, 8, karten, false)();
  ok('der Deckel fuer zu viele Saele wirkt weiter',
    (mitDeckel.match(/s-karte/g) || []).length === 8 && /4 weitere OP-Säle/.test(mitDeckel));
} else {
  ok('tafelHtml() liess sich rechnen', false, 'Ohne das prueft dieser Abschnitt nur Quelltext');
}

/* ---------------------------------------------------------------- 2) Vollbild */
console.log('\n2) Vollbild - dieselbe Mechanik wie in der Station:');
[['der Knopf', /id="dmVoll"/],
 ['die Vollbild-Schicht', /body\.mon-voll \.cockpit\{position:fixed/],
 ['der Schirm waechst (mit !important gegen die Inline-Hoehe)', /body\.mon-voll \.mon-screen\{height:calc\(100vh - 300px\)!important/],
 ['die Analyse bleibt schmal sichtbar', /body\.mon-voll \.ck-rechts\{height:calc\(100vh - 16px\);overflow-y:auto;font-size/],
 ['die Geraetespalte rollt statt abzuschneiden', /body\.mon-voll \.ck-links\{height:calc\(100vh - 16px\);overflow-y:auto/]
].forEach(function (t) { ok(t[0] + ' ist in der Fern-App vorhanden', t[1].test(wa)); });

ok('derselbe Knopf schaltet hin und zurueck',
  /b\.onclick=function\(\)\{ umschalten\(!document\.body\.classList\.contains\('mon-voll'\)\); \}/.test(waCode));
ok('Escape fuehrt ebenfalls zurueck', /e\.key==='Escape'[\s\S]{0,120}?umschalten\(false\)/.test(waCode));

/* Und beide Baeume muessen dieselbe Fassung tragen - sonst laufen Station und Fern-App
   auseinander, und genau davor warnt die Projektregel zur Web-App. */
console.log('\n3) Station und Fern-App tragen dieselbe Fassung:');
function block(q, von, bis) { var a = q.indexOf(von); if (a < 0) return null; var b = q.indexOf(bis, a); return b < 0 ? null : q.slice(a, b + bis.length); }
var vonCss = '/* ============================ VOLLBILD (19.08.2026) ============================';
var bisCss = 'body.mon-voll .ck-links{height:auto} body.mon-voll .ck-rechts{height:auto;max-height:38vh} }';
var cssSt = block(st, vonCss, bisCss), cssWa = block(wa, vonCss, bisCss);
ok('der Vollbild-Stil steht in beiden', !!cssSt && !!cssWa);
ok('… und ist zeichengleich', cssSt === cssWa,
  'Sonst verhaelt sich das Vollbild am Praxis-PC anders als von zu Hause');

ok('die Rhythmus-Chips laufen in der Fern-App weiter ueber $$ (alle)',
  /\$\$\('#rhythmChips \.chip'\)\.forEach/.test(waCode),
  'In String.replace ist "$$" im Ersatztext ein einzelnes "$" - genau daran ist die Zeile '
  + 'in der Station beim Einbau schon einmal zerbrochen');

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
