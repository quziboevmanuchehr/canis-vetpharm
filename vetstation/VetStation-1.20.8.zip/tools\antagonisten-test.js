'use strict';
/*
 * antagonisten-test.js — verbietet, dass die Station fuer dieselbe Arznei zwei verschiedene
 * Zahlen zeigt, und dass ein Knopf ohne Wirkung dasteht.
 *
 * WARUM ES DIESE DATEI GIBT (Befunde 18.08.2026, am geladenen Datenbestand gemessen):
 *
 *   Dieselbe Arznei steht an ZWEI Stellen: in ANAES.drugs[].species[art] (die Arzneikarte)
 *   und in ANAES.reversal[].sp[art] (die Antagonisten-Ansicht). Beide werden angezeigt, beide
 *   rechnen mit dem Gewicht, und keine sagt, dass es die andere gibt. Neun Paare wichen
 *   voneinander ab:
 *
 *     Flumazenil / Kaninchen    0,05-0,1   gegen  0,01-0,02   (fuenffach)
 *     Flumazenil / Frettchen    0,05       gegen  0,01-0,02
 *     Flumazenil / Hund+Katze   0,01-0,01  gegen  0,01-0,02
 *     Atipamezol / Meerschwein  0,1-1      gegen  0,5-1
 *     Atipamezol / Kaninchen    0,1-1      gegen  0,25-1
 *     Atipamezol / Hund         0,05-0,2   gegen  0,1-0,2
 *     Atipamezol / Katze        0,025-0,1  gegen  0,05-0,1
 *     Naloxon    / Kaninchen    0,01-0,1   gegen  0,01-0,04
 *
 *   URSACHE bei vieren davon: ui/shared/anaes-exotic-doses.js patcht in apply() nur
 *   ANAES.drugs und niemals ANAES.reversal. Die Arzneikarte bekam die Exotenzahl, die
 *   Antagonisten-Ansicht behielt die Hundezahl. Ein Test, der nur eine der beiden Tabellen
 *   liest, sieht davon nichts - deshalb vergleicht dieser Test sie GEGENEINANDER.
 *
 *   ZWEITER BEFUND: Yohimbin und Tolazolin stehen nur in ANAES.reversal und tragen dort
 *   einen Knopf "als am Tier verabreicht markieren". drugContext() beginnt aber mit
 *       var d=(A.drugs||[]).find(...); if(!d) return;
 *   Der frueh gesetzte return uebersprang fuer diese zwei IDs den ganzen Rumpf: kein Name in
 *   der Gabenliste, kein Wirkflag, keine Folge fuer ventAdvice(). Der Kommentar ueber dem
 *   Knopf behauptete ausdruecklich das Gegenteil.
 *
 * Start: node tools/antagonisten-test.js
 */
var fs = require('fs');
var path = require('path');
var vm = require('vm');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

/* Beide Datenquellen so laden, wie die Station es tut - MIT dem Exotenpatch. Ohne ihn
   waeren vier der neun Widersprueche unsichtbar, weil sie erst durch ihn entstehen. */
var sb = { self: {} };
sb.window = sb.self; sb.self.window = sb.self;
vm.createContext(sb);
vm.runInContext(fs.readFileSync(path.join(WURZEL, 'ui/app/anaes-data.js'), 'utf8'), sb);
vm.runInContext(fs.readFileSync(path.join(WURZEL, 'ui/shared/anaes-exotic-doses.js'), 'utf8'), sb);
var A = sb.self.ANAES;

console.log('VetStation — Arzneikarte und Antagonisten-Ansicht duerfen sich nicht widersprechen\n');

console.log('1) Der Exotenpatch ist wirklich aktiv (sonst prueft dieser Test die halbe Wahrheit):');
ok('anaes-exotic-doses.js hat gepatcht', !!sb.self.ANAES_EXOTIC_DOSES);
var flumKan = (A.drugs || []).filter(function (d) { return d.id === 'flumazenil'; })[0];
ok('Flumazenil/Kaninchen kommt aus dem Patch (0,05–0,1)',
  !!(flumKan && flumKan.species.kaninchen && flumKan.species.kaninchen.low === 0.05),
  'gefunden: ' + JSON.stringify(flumKan && flumKan.species.kaninchen && [flumKan.species.kaninchen.low, flumKan.species.kaninchen.high]));

console.log('\n2) Jedes Paar, das es in BEIDEN Tabellen gibt, muss dieselbe Zahl nennen:');
var karte = {};
(A.drugs || []).forEach(function (m) {
  Object.keys(m.species || {}).forEach(function (a) {
    var s = m.species[a];
    if (s && s.low != null) karte[m.id + '/' + a] = [s.low, s.high, s.unit];
  });
});
var streit = [], gleich = 0, nurRev = [];
(A.reversal || []).forEach(function (r) {
  Object.keys(r.sp || {}).forEach(function (a) {
    var v = r.sp[a];
    if (!Array.isArray(v)) return;
    var k = karte[r.id + '/' + a];
    if (!k) { nurRev.push(r.id + '/' + a); return; }
    if (k[0] === v[0] && k[1] === v[1]) { gleich++; return; }
    streit.push(r.id + '/' + a + ': Karte ' + k[0] + '-' + k[1] + ' gegen Ansicht ' + v[0] + '-' + v[1]);
  });
});
ok(gleich + ' gemeinsame Paare, davon 0 widerspruechlich', streit.length === 0, streit.join(' | '));
ok('es gibt ueberhaupt gemeinsame Paare (sonst prueft die Zeile darueber nichts)', gleich >= 20,
  'gefunden: ' + gleich);

console.log('\n3) Kein Knopf ohne Wirkung:');
var html = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
var i = html.indexOf('var DRUGFX={');
var drugfx = html.slice(i, html.indexOf('\n};', i) + 3);
ok('DRUGFX gefunden', i > 0 && drugfx.length > 200);
var ohneWirkung = [];
(A.reversal || []).forEach(function (r) {
  var hatKarte = (A.drugs || []).some(function (d) { return d.id === r.id; });
  var hatFx = new RegExp('(^|[{,\\s])' + r.id + '\\s*:').test(drugfx);
  if (!hatFx) ohneWirkung.push(r.id + ' (Arzneikarte: ' + (hatKarte ? 'ja' : 'nein') + ')');
});
ok('jeder Antagonist steht in DRUGFX', ohneWirkung.length === 0, ohneWirkung.join(', '));

var ohneKommentar = html.replace(/\/\*[\s\S]*?\*\//g, ' ');
ok('drugContext() faellt auf ANAES.reversal zurueck, wenn es keine Arzneikarte gibt',
  /if\(!d\)\s*d=\(A\.reversal\|\|\[\]\)\.find/.test(ohneKommentar),
  'Sonst ueberspringt der frueh gesetzte return den ganzen Rumpf');

console.log('\n4) Die vier Stellen, die der Exotenpatch nicht erreicht, im Einzelnen:');
[['flumazenil', 'kaninchen', 0.05, 0.1],
 ['flumazenil', 'frettchen', 0.05, 0.05],
 ['atipamezol', 'kaninchen', 0.1, 1],
 ['atipamezol', 'meerschwein', 0.1, 1]].forEach(function (t) {
  var r = (A.reversal || []).filter(function (x) { return x.id === t[0]; })[0];
  var v = r && r.sp && r.sp[t[1]];
  ok(t[0] + '/' + t[1] + ' in der Antagonisten-Ansicht: ' + t[2] + '–' + t[3],
    !!(v && v[0] === t[2] && v[1] === t[3]),
    'gefunden: ' + JSON.stringify(v));
});

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
