'use strict';
/*
 * ekg-skala-test.js — beschriftete Achsen des Diagnostik-EKG.
 *
 * WARUM ES DIESEN TEST GIBT (Befund 08.08.2026):
 * Die Skala wurde zuerst direkt in index.html gezeichnet und im laufenden Browser nachgemessen.
 * Das ging schief, und zwar nicht ein bisschen: der Bildtakt der Vorschau ist gedrosselt, die
 * Leinwand zeigte alte Bilder, und die Messung meldete sechs von zwoelf Einstellungen als
 * falsch. Der Code war richtig - die MESSUNG war es nicht. Vier requestAnimationFrame-Takte
 * kamen dort in 30 Sekunden nicht durch.
 *
 * Lehre daraus: Geometrie, die stimmen MUSS, gehoert in eine reine Funktion mit einem Test,
 * nicht in eine Zeichenroutine, die man nur am Bild kontrollieren kann.
 *
 * Was hier bewiesen wird:
 *   • Eine Sekunde ist GENAU so viele Millimeter breit wie der Vorschub sagt - bei 25, 50
 *     und 100 mm/s, und auch noch bei der hundertsten Marke (kein Gleitkomma-Drift).
 *   • Ein Millivolt ist GENAU so viele Millimeter hoch wie die Verstaerkung sagt.
 *   • Bildschirm (Bildpunkte je mm) und PDF (Punkte je mm) bekommen dieselbe Skala, nur
 *     anders skaliert - der Ausdruck kann nicht anders gemessen werden als der Schirm.
 *   • Die Skala passt zu der Rechnung, mit der die KURVE gezeichnet wird.
 *
 * Start:  node tools/ekg-skala-test.js
 */
const S = require('../ui/shared/ekg-skala.js');
const fs = require('fs');
const path = require('path');

/* Die Oberflaeche wird an mehreren Stellen im Quelltext geprueft. EINMAL einlesen, und
 * zusaetzlich eine Fassung OHNE Blockkommentare bereitstellen.
 *
 * Warum ohne Kommentare (gemessen 08.08.2026): eine Pruefung auf "der alte gedehnte Aufruf
 * kommt nicht mehr vor" schlug an - und zwar an dem Kommentar, der erklaert, warum es ihn
 * nicht mehr gibt. Eine Quellpruefung muss Code lesen, nicht die Begruendung daneben. */
const QUELLE = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');
const QUELLE_CODE = QUELLE.replace(/\/\*[\s\S]*?\*\//g, ' ');

let ok = 0;
const fehler = [];
function pruefe(was, bedingung, zusatz) {
  if (bedingung) { ok++; return; }
  fehler.push(was + (zusatz ? '  -> ' + zusatz : ''));
}
function gleich(was, ist, soll, toleranz) {
  const t = toleranz === undefined ? 1e-9 : toleranz;
  pruefe(was, Math.abs(ist - soll) <= t, 'ist ' + ist + ', soll ' + soll);
}
function block(titel) { console.log('\n--- ' + titel + ' ---'); }

const VORSCHUB = [25, 50, 100];       // mm/s
const VERSTAERKUNG = [5, 10, 20, 40]; // mm/mV

/* ================================================================================
 * 1. ZEITACHSE — eine Sekunde ist so breit wie der Vorschub sagt
 * ============================================================================== */
block('1. Zeitachse');
[1, 2, 2.8346].forEach((pmm) => {
  VORSCHUB.forEach((v) => {
    const breite = pmm * v * 6;              // genau 6 Sekunden Flaeche
    const m = S.zeitMarken(breite, pmm, v);
    pruefe('Marken vorhanden (' + v + ' mm/s, pmm ' + pmm + ')', m.length > 0);

    // Abstand zweier Marken = 0,2 s
    for (let i = 1; i < m.length; i++) {
      const d = m[i].x - m[i - 1].x;
      if (Math.abs(d - pmm * v * 0.2) > 1e-9) {
        fehler.push('Markenabstand bei ' + v + ' mm/s, pmm ' + pmm + ': ist ' + d);
        break;
      }
    }
    ok++;

    // Volle Sekunden: jede fuenfte Marke, und sie sitzt auf pmm*v je Sekunde
    const volle = m.filter((t) => t.voll);
    gleich('volle Sekunden gezaehlt (' + v + ', pmm ' + pmm + ')', volle.length, 7); // 0..6
    volle.forEach((t, i) => {
      gleich('Sekunde ' + i + ' bei ' + v + ' mm/s', t.x, i * pmm * v, 1e-9);
      gleich('Sekunde ' + i + ' Beschriftung', Math.round(t.sek), i);
    });

    // Kein Drift: die hundertste Marke muss exakt sitzen
    const lang = S.zeitMarken(pmm * v * 100, pmm, v);
    gleich('100. Marke ohne Drift (' + v + ' mm/s)', lang[100].x, 100 * pmm * v * 0.2, 1e-9);
    gleich('100. Marke traegt 20 s', lang[100].sek, 20, 1e-9);
  });
});

/* Die "voll"-Kennung darf nicht an einem Gleitkommarest haengen: 0,2*5 ergibt in JS
 * 1.0000000000000002, ein naiver Vergleich auf ganze Sekunden schluckt die Marke. */
{
  const m = S.zeitMarken(2 * 25 * 12, 2, 25);
  const volle = m.filter((t) => t.voll).map((t) => Math.round(t.sek));
  pruefe('volle Sekunden lueckenlos 0..12',
    volle.join(',') === '0,1,2,3,4,5,6,7,8,9,10,11,12', volle.join(','));
}

/* Rand: die Flaeche wird ausgefuellt, aber nichts weit dahinter gezeichnet. */
{
  const m = S.zeitMarken(101, 2, 25);       // 101 ist kein Vielfaches von 10
  const letzte = m[m.length - 1].x;
  pruefe('letzte Marke liegt in der Flaeche', letzte <= 101 + 0.5, 'x ' + letzte);
  pruefe('Flaeche wird bis zum Rand gefuellt', letzte > 101 - 10, 'x ' + letzte);
}

/* ================================================================================
 * 2. AMPLITUDENACHSE — ein Millivolt ist so hoch wie die Verstaerkung sagt
 * ============================================================================== */
block('2. Amplitudenachse');
[1, 2, 2.8346].forEach((pmm) => {
  VERSTAERKUNG.forEach((g) => {
    const hoehe = pmm * g * 9;               // Platz fuer +-4,5 mV
    const m = S.mvMarken(hoehe, pmm, g, { minAbstand: 0 });
    const mitte = hoehe / 2;

    m.forEach((a) => {
      gleich(a.mv + ' mV bei ' + g + ' mm/mV, pmm ' + pmm,
        a.y, mitte - a.mv * g * pmm, 1e-9);
    });

    // Symmetrie um die Grundlinie
    const plus = m.filter((a) => a.mv > 0).map((a) => a.mv).sort((x, y) => x - y);
    const minus = m.filter((a) => a.mv < 0).map((a) => -a.mv).sort((x, y) => x - y);
    pruefe('Skala symmetrisch (' + g + ' mm/mV)', plus.join(',') === minus.join(','),
      plus.join(',') + ' vs ' + minus.join(','));

    // Die Grundlinie selbst ist NICHT in der Liste - sie wird eigens gezeichnet
    pruefe('Grundlinie nicht doppelt', m.every((a) => a.mv !== 0));
  });
});

/* Schrittweite haengt am Mindestabstand, nicht an einer festen Zahl.
 * Diese Trennung ist der Grund, warum Schirm und Papier trotz verschieden grosser
 * "Millimeter" beide lesbar bleiben. */
block('2b. Schrittweite folgt dem Platz');
gleich('Schirm 10 mm/mV (2 px/mm, 14 px Schrift) -> 1 mV', S.mvSchritt(2, 10, 14), 1);
gleich('Schirm 20 mm/mV -> 0,5 mV', S.mvSchritt(2, 20, 14), 0.5);
gleich('Schirm 40 mm/mV -> 0,2 mV', S.mvSchritt(2, 40, 14), 0.2);
/* ACHTUNG, zwei Stufen: mvSchritt() kennt NUR den Platz fuer die Schrift. mvMarken() legt
 * darueber noch die Dichtegrenze (hoechstens MAX_PRO_SEITE Beschriftungen je Richtung) und
 * kommt deshalb auf einem hohen Feld zu einer groeberen Teilung. Beides ist gewollt - hier
 * wird belegt, dass die zweite Stufe wirklich greift und nicht bloss dieselbe Zahl liefert. */
{
  const feinAusLeiter = S.mvSchritt(2, 40, 14);
  const m = S.mvMarken(726, 2, 40, { oben: 12, unten: 14, minAbstand: 14 });
  const echterSchritt = Math.abs(m[1].mv - m[0].mv);
  pruefe('Dichtegrenze vergroebert gegenueber der reinen Leiter',
    echterSchritt > feinAusLeiter + 1e-9,
    'Leiter ' + feinAusLeiter + ', tatsaechlich ' + echterSchritt);
  gleich('und zwar auf 0,5 mV', Math.round(echterSchritt * 100) / 100, 0.5);
}
/* Bei 5 mm/mV liegt ein Millivolt nur 10 Bildpunkte hoch - da muss die Achse auf 2 mV
 * gehen, sonst kleben die Beschriftungen aneinander. */
gleich('Schirm 5 mm/mV -> 2 mV', S.mvSchritt(2, 5, 14), 2);
gleich('PDF 10 mm/mV (1 mm/mm, 3,2 mm Schrift) -> 0,5 mV', S.mvSchritt(1, 10, 3.2), 0.5);
gleich('PDF 5 mm/mV -> 1 mV', S.mvSchritt(1, 5, 3.2), 1);
{
  // Der versprochene Mindestabstand wird auch wirklich eingehalten
  [[2, 14], [1, 3.2]].forEach(([pmm, min]) => {
    VERSTAERKUNG.forEach((g) => {
      const s = S.mvSchritt(pmm, g, min);
      const abstand = s * pmm * g;
      pruefe('Beschriftungen halten ' + min + ' Abstand (pmm ' + pmm + ', ' + g + ' mm/mV)',
        abstand >= min - 1e-9, 'Abstand ' + abstand);
    });
  });
}

/* Rand: was unter die Legende oder in die Sekundenbeschriftung liefe, faellt weg. */
block('2c. Rand wird freigehalten');
{
  const hoehe = 726, m = S.mvMarken(hoehe, 2, 10, { oben: 12, unten: 14, minAbstand: 14 });
  pruefe('nichts oberhalb des Randes', m.every((a) => a.y >= 12), JSON.stringify(m.slice(0, 2)));
  pruefe('nichts unterhalb des Randes', m.every((a) => a.y <= hoehe - 14));
  pruefe('trotzdem Marken uebrig', m.length >= 6, 'n=' + m.length);
}

/* ================================================================================
 * 3. SCHIRM UND PAPIER MESSEN DASSELBE
 * Der eigentliche Zweck der gemeinsamen Datei. Dieselbe Sekunde, dieselbe Spannung -
 * nur ein anderer Massstab.
 * ============================================================================== */
block('3. Schirm und PDF decken sich');
VORSCHUB.forEach((v) => {
  const schirm = S.zeitMarken(2 * v * 5, 2, v);   // 2 Bildpunkte je mm
  const pdf = S.zeitMarken(1 * v * 5, 1, v);      // 1 Punkt je mm (jsPDF rechnet in mm)
  gleich('gleich viele Zeitmarken (' + v + ' mm/s)', schirm.length, pdf.length);
  for (let i = 0; i < pdf.length; i++) {
    gleich('Marke ' + i + ' deckt sich (' + v + ' mm/s)', schirm[i].x, pdf[i].x * 2, 1e-9);
    gleich('Marke ' + i + ' gleiche Sekunde', schirm[i].sek, pdf[i].sek, 1e-9);
  }
});
VERSTAERKUNG.forEach((g) => {
  const h = 400;
  const schirm = S.mvMarken(h * 2, 2, g, { minAbstand: 0 });
  const pdf = S.mvMarken(h, 1, g, { minAbstand: 0 });
  gleich('gleich viele mV-Marken (' + g + ' mm/mV)', schirm.length, pdf.length);
  for (let i = 0; i < pdf.length; i++) {
    gleich('mV-Marke ' + i + ' deckt sich (' + g + ')', schirm[i].y, pdf[i].y * 2, 1e-9);
    gleich('mV-Marke ' + i + ' gleiche Spannung (' + g + ')', schirm[i].mv, pdf[i].mv, 1e-9);
  }
});

/* ================================================================================
 * 4. DIE SKALA PASST ZUR KURVE
 * Eine Skala, die neben der Kurve gerechnet wird statt aus derselben Formel, waere
 * schlimmer als gar keine: sie sieht richtig aus und ist falsch.
 * ============================================================================== */
block('4. Skala und Kurve aus einer Formel');
VORSCHUB.forEach((v) => {
  [1, 2].forEach((pmm) => {
    const m = S.zeitMarken(pmm * v * 4, pmm, v);
    m.forEach((t) => {
      gleich('Zeitmarke = xVonSekunde (' + v + ')', t.x, S.xVonSekunde(t.sek, pmm, v), 1e-9);
    });
  });
});
VERSTAERKUNG.forEach((g) => {
  const h = 300;
  S.mvMarken(h, 2, g, { minAbstand: 0 }).forEach((a) => {
    gleich('mV-Marke = yVonMv (' + g + ')', a.y, S.yVonMv(a.mv, h, 2, g), 1e-9);
  });
});
/* Die sichtbare Dauer der Flaeche muss die sein, die die letzte Marke anzeigt.
 * zeichneZoom nimmt genau so viele Abtastwerte, wie bei diesem Vorschub in die Breite
 * passen: breiteMm/speed Sekunden. Die Skala muss dieselbe Zahl liefern. */
VORSCHUB.forEach((v) => {
  const breite = 1265, pmm = 2;
  const dauerLautKurve = (breite / pmm) / v;               // so rechnet zeichneZoom
  const m = S.zeitMarken(breite, pmm, v);
  const dauerLautSkala = m[m.length - 1].sek;
  pruefe('Flaechendauer stimmt (' + v + ' mm/s)',
    Math.abs(dauerLautKurve - dauerLautSkala) <= S.TAKT_S,
    'Kurve ' + dauerLautKurve.toFixed(3) + ' s, Skala ' + dauerLautSkala.toFixed(3) + ' s');
});

/* ================================================================================
 * 5. WAS EIN KAESTCHEN BEDEUTET
 * ============================================================================== */
block('5. Kaestchenwert');
gleich('25 mm/s -> 1 mm = 40 ms', S.kaestchen(25, 10).ms, 40);
gleich('50 mm/s -> 1 mm = 20 ms', S.kaestchen(50, 10).ms, 20);
gleich('100 mm/s -> 1 mm = 10 ms', S.kaestchen(100, 10).ms, 10);
gleich('5 mm/mV -> 1 mm = 0,2 mV', S.kaestchen(25, 5).mv, 0.2);
gleich('10 mm/mV -> 1 mm = 0,1 mV', S.kaestchen(25, 10).mv, 0.1);
gleich('20 mm/mV -> 1 mm = 0,05 mV', S.kaestchen(25, 20).mv, 0.05);
gleich('40 mm/mV -> 1 mm = 0,025 mV', S.kaestchen(25, 40).mv, 0.025);
pruefe('Klartext lesbar', S.kaestchenText(50, 10) === '1 mm = 20 ms · 0.1 mV',
  S.kaestchenText(50, 10));
/* Ein grosses Kaestchen (5 mm) bei 25 mm/s ist die bekannte 0,2 s - genau der Takt,
 * in dem die Marken stehen. */
gleich('grosses Kaestchen bei 25 mm/s = Markentakt', 5 * S.kaestchen(25, 10).ms / 1000, S.TAKT_S);

/* ================================================================================
 * 6. UNSINN FUEHRT ZU NICHTS, NICHT ZU FALSCHEM
 * Eine Skala, die bei fehlender Angabe irgendetwas zeichnet, ist gefaehrlicher als eine,
 * die schweigt - man wuerde an ihr messen.
 * ============================================================================== */
block('6. Unsinn erzeugt keine Skala');
[[0, 2, 25], [100, 0, 25], [100, 2, 0], [100, 2, -25], [NaN, 2, 25], [100, NaN, 25],
 [100, 2, NaN], [Infinity, 2, 25], [null, 2, 25], [undefined, 2, 25]]
  .forEach(([b, p, v]) => {
    const m = S.zeitMarken(b, p, v);
    pruefe('zeitMarken(' + b + ',' + p + ',' + v + ') leer', Array.isArray(m) && m.length === 0,
      'n=' + (m && m.length));
  });
[[0, 2, 10], [100, 0, 10], [100, 2, 0], [100, 2, -10], [NaN, 2, 10], [100, NaN, 10],
 [100, 2, NaN], [null, 2, 10]]
  .forEach(([h, p, g]) => {
    const m = S.mvMarken(h, p, g, { minAbstand: 0 });
    pruefe('mvMarken(' + h + ',' + p + ',' + g + ') leer', Array.isArray(m) && m.length === 0,
      'n=' + (m && m.length));
  });
pruefe('kaestchen(0,0) liefert nichts', S.kaestchen(0, 0) === null);
pruefe('kaestchenText ohne Angaben leer', S.kaestchenText(0, 10) === '');
/* Ohne opts darf es nicht abstuerzen - der Aufrufer vergisst so etwas. */
pruefe('mvMarken ohne opts laeuft', Array.isArray(S.mvMarken(400, 2, 20)));

/* ================================================================================
 * 7. KEINE ENDLOSSCHLEIFE
 * ============================================================================== */
block('7. Grenzen halten');
{
  const m = S.zeitMarken(1e6, 2, 25);
  pruefe('grosse Flaeche liefert endliche Liste', m.length > 0 && m.length < 200000,
    'n=' + m.length);
  const a = S.mvMarken(1e6, 2, 10, { minAbstand: 0 });
  pruefe('hohe Flaeche gibt hoechstens 2*MAX_SCHRITTE Marken',
    a.length <= 2 * S.MAX_SCHRITTE, 'n=' + a.length);
}

/* ================================================================================
 * 8. IM PDF MUSS DIE SKALA UEBER DER KURVE LIEGEN, NICHT NEBEN IHR
 *
 * WARUM DIESER TEST EXISTIERT (Befund beim Gegenlesen 08.08.2026):
 * Die Sekundenskala des Rhythmusstreifens war zuerst mit den Massen des RASTERS gezeichnet
 * (Mg, feldW), die Kurve aber mit Mg+9 und feldW-10 - eingerueckt, weil links der Eichzacken
 * steht. Die Null der Skala sass damit 9 mm vor dem Kurvenbeginn: bei 25 mm/s ein Fehler von
 * 360 ms auf JEDE abgelesene Zeit. Rechnerisch war die Skala tadellos, sie lag nur woanders.
 * Genau das faellt in einer Formelpruefung nicht auf - deshalb hier eine Quellpruefung.
 * ============================================================================== */
block('8. PDF: Skala deckt sich mit der Kurve');
{
  const quelle = QUELLE_CODE;

  /* Argumente eines Aufrufs holen, Leerzeichen entfernt. */
  function aufrufe(name) {
    const re = new RegExp(name + '\\(([^)]*)\\)', 'g');
    const aus = [];
    let m;
    while ((m = re.exec(quelle)) !== null) {
      const arg = m[1].split(',').map((s) => s.replace(/\s+/g, ''));
      // Der Funktionskopf selbst (Parameterliste x,y,w,h) ist kein Aufruf.
      if (arg.join(',') === 'x,y,w,h' || arg.join(',') === 'x,y,h') continue;
      aus.push(arg);
    }
    return aus;
  }

  const sek = aufrufe('sekundenmarken');
  const kur = aufrufe('kurve');
  pruefe('sekundenmarken wird im PDF benutzt', sek.length >= 1, 'n=' + sek.length);
  pruefe('kurve wird im PDF benutzt', kur.length >= 1, 'n=' + kur.length);

  /* kurve(buf, x, y, w, h) — x ist Argument 1, w ist Argument 3.
   * sekundenmarken(x, y, w, h) — x ist Argument 0, w ist Argument 2.
   *
   * Die Breite der Skala darf ENTWEDER dieselbe Angabe wie die der Kurve sein ODER der
   * Rueckgabewert genau dieses kurve()-Aufrufs. Das Zweite ist der Regelfall: kurve() liefert
   * die Breite, die sie WIRKLICH gebraucht hat - reicht der Puffer nicht ueber die ganze
   * Bahn, ist sie kleiner, und die Skala darf dann nicht weiterlaufen. */
  const zuweisungen = {};   // Variablenname -> Argumente des kurve()-Aufrufs
  let zm;
  /* Auch die BEDINGTE Zuweisung erkennen: `var bZ = (rest>1) ? kurve(...) : 0;`.
   * Die Fortsetzungszeilen des langen Streifens (10.08.2026) sind so geschrieben, weil eine
   * Zeile ohne Restsignal gar nicht erst gezeichnet wird. Der alte Ausdruck verlangte
   * `var x = kurve(` unmittelbar hintereinander und hielt die Zeile deshalb faelschlich fuer
   * eine Skala ohne zugehoerige Kurve. Geprueft werden soll die EIGENSCHAFT (die Skala nimmt
   * die wirklich gezeichnete Breite), nicht die Schreibweise. */
  const zre = /var\s+(\w+)\s*=\s*(?:[^;=]*\?\s*)?kurve\(([^)]*)\)/g;
  while ((zm = zre.exec(quelle)) !== null) {
    zuweisungen[zm[1]] = zm[2].split(',').map((s) => s.replace(/\s+/g, ''));
  }
  sek.forEach((a) => {
    const x = a[0], breite = a[2];
    const direkt = kur.some((k) => k[1] === x && k[3] === breite);
    const ausRueckgabe = zuweisungen[breite] && zuweisungen[breite][1] === x;
    pruefe('Sekundenskala bei ' + x + ' (Breite ' + breite + ') gehoert zu einer Kurve',
      direkt || ausRueckgabe,
      'Kurven: ' + kur.map((k) => k[1] + '|' + k[3]).join(' , ') +
      ' ; Rueckgaben: ' + Object.keys(zuweisungen).map((v) => v + '=kurve@' + zuweisungen[v][1]).join(' , '));
  });
  pruefe('mindestens eine Skala nimmt die WIRKLICH gezeichnete Breite',
    sek.some((a) => zuweisungen[a[2]]),
    'keine Skala haengt an einem kurve()-Rueckgabewert');

  /* Die sechs Ableitungen stehen NEBENEINANDER (3 Spalten). Eine Skala ueber den ganzen
   * Block hinweg behauptet einen durchgehenden Zeitverlauf, den es dort nicht gibt. */
  pruefe('keine durchgehende Skala unter dem 3x2-Ableitungsfeld',
    quelle.indexOf('sekundenmarken(Mg,top,feldW,feldH)') < 0,
    'die Skala laeuft ueber drei unabhaengige Spalten');

  /* Die Amplitudenskala haengt an der Bahnmitte, nicht am Kurvenbeginn - sie darf und muss
   * die Masse des Rasters tragen. Sie wird hier nur daraufhin geprueft, dass ihre Hoehe zu
   * der Bahn passt, in der die Kurve liegt. */
  const mvm = aufrufe('mvmarken');
  mvm.forEach((a) => {
    const hoehe = a[2];
    pruefe('mV-Skala benutzt dieselbe Bahnhoehe wie eine Kurve (' + hoehe + ')',
      kur.some((k) => k[4] === hoehe), 'Kurvenhoehen: ' + kur.map((k) => k[4]).join(','));
  });

  /* SPALTE FUER DIE AMPLITUDENBESCHRIFTUNG. Sie steht LINKS neben der KURVE. Der Grund ist
   * unveraendert (Befund der Freigabepruefung 08.08.2026): stuende sie am Blattrand, begaenne
   * sie 3,7 mm davon entfernt - uebliche Drucker lassen 4 bis 5 mm unbedruckt, und eine
   * angeschnittene "-160" liest sich als "160".
   *
   * GEPRUEFT WIRD DER ABSTAND, NICHT DIE LOESUNG (berichtigt 10.08.2026). Vorher verlangte
   * dieser Test woertlich "var sMg = Mg + >=5" - also genau den Weg, auf dem das Problem
   * damals geloest wurde. Als die Beschriftung am 10.08.2026 nach INNEN wanderte (zwischen
   * Eichzacke und Kurvenbeginn, siehe zellAufteilung), war der Abstand zum Blattrand
   * dreimal so gross wie gefordert - und der Test wurde trotzdem rot. Ein Test, der die
   * Bauweise festschreibt statt der Eigenschaft, verhindert Verbesserungen.
   * Jetzt wird gerechnet: wo landet die Beschriftung wirklich? */
  const MG_PDF = 10;                    // Seitenrand des Ausdrucks (Mg in buildPDF)
  const BREITE_PDF = 297 - 2 * MG_PDF;  // Rasterbreite A4 quer
  const LABEL_LUFT = 2.2;               // so weit vor der Marke endet die Beschriftung
  const LABEL_BREITE = 4.2;             // "-0.5" bei 6 pt
  [['Rhythmusstreifen', BREITE_PDF], ['Ableitungszelle', BREITE_PDF / 3]].forEach(([was, br]) => {
    const z = S.zellAufteilung(br, 1);
    const linkeKante = MG_PDF + z.kurveVon - LABEL_LUFT - LABEL_BREITE;
    pruefe(was + ': Amplitudenbeschriftung beginnt >= 5 mm vom Blattrand',
      z.achse && linkeKante >= 5, 'beginnt bei ' + Math.round(linkeKante * 10) / 10 + ' mm');
    /* Und sie darf nicht in den Eichzacken laufen - der ist 5 mm breit ab eichX. */
    pruefe(was + ': Amplitudenbeschriftung stoesst nicht in den Eichzacken',
      linkeKante - MG_PDF >= z.eichX + 5, 'Beschriftung ab ' + Math.round((linkeKante - MG_PDF) * 10) / 10 +
      ' mm, Eichzacke bis ' + (z.eichX + 5) + ' mm');
  });
  pruefe('die Amplitudenskala sitzt nicht am Rasterrand',
    mvm.every((a) => a[0] !== 'Mg' && a[0] !== 'sMg'),
    'Aufrufe: ' + mvm.map((a) => a[0]).join(','));
  pruefe('die Amplitudenskala haengt an derselben Aufteilung wie die Kurve',
    mvm.length > 0 && mvm.every((a) => /kurveVon$/.test(a[0])),
    'Aufrufe: ' + mvm.map((a) => a[0]).join(','));
}

/* ================================================================================
 * 11. JEDE ABLEITUNG TRAEGT IHRE EIGENE SKALA — UND KEINE ANSICHT DEHNT MEHR
 *
 * WARUM DIESER BLOCK EXISTIERT (zwei Befunde vom 10.08.2026):
 *
 * (a) NUTZERBEFUND, mit dem Stift auf einem Ausdruck markiert: das 3x2-Feld der sechs
 *     Extremitaetenableitungen trug nur blankes Millimeterraster. Gemessen werden konnte
 *     nur am Rhythmusstreifen. Jede Zelle bekommt jetzt ihre eigene, bei null beginnende
 *     Achse - eine durchgehende ueber alle drei Spalten waere falsch.
 *
 * (b) IM LAUFENDEN BROWSER NACHGEMESSEN: drei von vier Zeichenwegen stauchten die Kurve,
 *     weil sie die vorhandenen Werte ueber die ganze Flaeche verteilten (breite/(n-1))
 *     statt jedem Wert speed*pmm/hz zu geben:
 *         6-Kanal-Bild            25 mm/s eingestellt ->  80,5 mm/s gezeichnet
 *         Direktdruck 6 Kanaele   25 mm/s eingestellt -> 165,1 mm/s gezeichnet
 *         Direktdruck Rhythmus    25 mm/s eingestellt ->  49,6 mm/s gezeichnet
 *     Nur das PDF war richtig. Der alte Test deckte das nicht ab, weil er ausschliesslich
 *     die PDF-Aufrufe las.
 * ============================================================================== */
block('11. Zellskala und kein Dehnen mehr');
{
  const quelle = QUELLE_CODE;

  /* --- (a) Aufteilung der Zelle --- */
  [[297 - 20, 1], [(297 - 20) / 3, 1], [480, 3], [1936, 8], [1936 / 3, 8]].forEach(([br, pmm]) => {
    const z = S.zellAufteilung(br, pmm);
    pruefe('Aufteilung ' + br + '/' + pmm + ': Kurve behaelt mehr als die Haelfte',
      z.kurveBreite > br * 0.5, 'Kurve ' + z.kurveBreite + ' von ' + br);
    pruefe('Aufteilung ' + br + '/' + pmm + ': Kurve bleibt in der Zelle',
      z.kurveVon + z.kurveBreite <= br + 1e-9);
    pruefe('Aufteilung ' + br + '/' + pmm + ': Eichzacke vor der Kurve',
      z.eichX + 5 * pmm <= z.kurveVon + 1e-9);
  });
  {
    const schmal = S.zellAufteilung(20, 1);   // 20 mm Zelle: fuer eine Achse kein Platz
    pruefe('sehr schmale Zelle bekommt keine Achse, aber eine Kurve',
      schmal.achse === false && schmal.kurveBreite > 0,
      JSON.stringify(schmal));
  }
  [[0, 1], [100, 0], [NaN, 1], [null, 1], [7, 1]].forEach(([br, pmm]) => {
    const z = S.zellAufteilung(br, pmm);
    const grenze = (typeof br === 'number' && isFinite(br) && br > 0) ? br : 0;
    pruefe('Aufteilung(' + br + ',' + pmm + ') erfindet keine Flaeche',
      z.kurveBreite <= grenze, 'Kurve ' + z.kurveBreite + ' bei Grenze ' + grenze);
  });

  /* --- (b) kein Zeichenweg dehnt mehr --- */
  const ekgBlock = quelle.slice(quelle.indexOf('DIAGNOSTIK-EKG'));
  pruefe('kein Zeichenweg verteilt mehr ueber die ganze Flaeche (…/(N-1))',
    !/\/\s*\(\s*[nN]\w*\s*-\s*1\s*\)/.test(ekgBlock),
    'gefunden: ' + (ekgBlock.match(/[\w.]+\s*\/\s*\(\s*[nN]\w*\s*-\s*1\s*\)/g) || []).join(' , '));
  ['drawLeadCanvas', 'drawStripCanvas', 'renderSheet', 'buildPDF', 'zeichneZoom'].forEach((fn) => {
    const i = ekgBlock.indexOf('function ' + fn);
    pruefe(fn + ' gibt es noch', i >= 0);
    if (i < 0) return;
    const koerper = ekgBlock.slice(i, i + 6000);
    pruefe(fn + ' holt seinen Ausschnitt aus VS.skala',
      /kurvenAusschnitt|spurZeichnen/.test(koerper),
      'weder kurvenAusschnitt noch spurZeichnen im Koerper');
  });

  /* Die Abtastrate darf NICHT mehr am Vorschub haengen (Befund 10.08.2026: der Puffer lief
   * mit mmPx()*M.speed, also 50-100 Hz; 13 ms Schrittweite bei einer Katzen-QRS von 40 ms,
   * und die 50-Hz-Erkennung war unterhalb ihrer Nyquist-Grenze still tot). */
  pruefe('die Abtastrate haengt nicht mehr am Vorschub',
    !/M\.hz\s*=\s*[^;]*M\.speed/.test(ekgBlock) && /var\s+EKG_HZ\s*=\s*(\d+)/.test(ekgBlock),
    'M.hz wird noch aus M.speed gebildet');
  pruefe('die Abtastrate reicht fuer die 50-Hz-Erkennung (Nyquist, >= 100 Hz)',
    /var\s+EKG_HZ\s*=\s*(\d+)/.test(ekgBlock) && Number(RegExp.$1) >= 100,
    'EKG_HZ = ' + RegExp.$1);
  pruefe('die Abtastrate ist fein genug fuer eine Katzen-QRS (<= 5 ms Schrittweite)',
    /var\s+EKG_HZ\s*=\s*(\d+)/.test(ekgBlock) && 1000 / Number(RegExp.$1) <= 5,
    'Schrittweite ' + (1000 / Number(RegExp.$1)).toFixed(1) + ' ms');

  /* Und der Beweis in Zahlen: bei JEDER der drei Ansichten kommt genau der eingestellte
   * Vorschub heraus - das ist die Groesse, die vorher um Faktor 2 bis 6,6 danebenlag. */
  const HZ = 250;
  [[297 - 20, 1, 'PDF-Streifen'], [(297 - 20) / 3, 1, 'PDF-Zelle'],
   [480, 3, 'Schirm-Zelle'], [1936, 8, 'Blatt-Streifen'], [1936 / 3, 8, 'Blatt-Zelle']]
    .forEach(([br, pmm, was]) => {
      VORSCHUB.forEach((v) => {
        const z = S.zellAufteilung(br, pmm);
        const A = S.kurvenAusschnitt(z.kurveBreite, pmm, v, HZ, 20 * HZ);
        const effektiv = A.proWert * HZ / pmm;      // Einheiten/Wert * Werte/s / Einheiten/mm
        gleich(was + ' bei ' + v + ' mm/s zeichnet ' + v + ' mm/s', effektiv, v, 1e-9);
      });
    });
}

/* ================================================================================
 * 9. OHNE KALIBRIERUNG KEINE MILLIVOLT
 *
 * WARUM DIESER TEST EXISTIERT (Befund der Freigabepruefung 08.08.2026):
 * Die erste Fassung der Achse beschriftete IMMER in Millivolt - auch dann, wenn die
 * Verstaerkung des Geraets unbekannt ist und der Streifen nur auf eine ablesbare Hoehe
 * normiert wurde. Die Anwendung sagt an jeder anderen Stelle ausdruecklich das Gegenteil
 * ("Verstaerkung des Geraets ist unbekannt, deshalb keine Angabe in mV"), und die Fusszeile
 * des Ausdrucks schreibt im selben Lauf "Amplitude NICHT kalibriert". Die Achse haette dem
 * Blatt also widersprochen - auf dem Papier, das in der Akte landet.
 * ============================================================================== */
block('9. ohne Kalibrierung keine Millivolt');
{
  const hoehe = 726, pmm = 2;

  // Millimeterachse: haengt NICHT an der Verstaerkung - ein mm ist ein mm.
  const a10 = S.mmMarken(hoehe, pmm, { minAbstand: 14 });
  const mitte = hoehe / 2;
  a10.forEach((m) => gleich(m.mm + ' mm sitzt richtig', m.y, mitte - m.mm * pmm, 1e-9));
  pruefe('Millimeterachse traegt Millimeter, keine Millivolt',
    a10.every((m) => m.mm !== undefined && m.mv === undefined));
  pruefe('Millimeterachse ist symmetrisch',
    a10.filter((m) => m.mm > 0).length === a10.filter((m) => m.mm < 0).length);
  pruefe('Grundlinie nicht in der Liste', a10.every((m) => m.mm !== 0));

  // Stufenleiter
  gleich('Schirm (2/mm, 14 Schrift) -> 10 mm', S.mmSchritt(2, 14), 10);
  gleich('PDF (1/mm, 3,2 Schrift) -> 5 mm', S.mmSchritt(1, 3.2), 5);
  [[2, 14], [1, 3.2]].forEach(([p, min]) => {
    pruefe('mm-Beschriftungen halten ' + min + ' Abstand (pmm ' + p + ')',
      S.mmSchritt(p, min) * p >= min - 1e-9);
  });

  // Kaestchentext schweigt zur Hoehe
  const t = S.kaestchenText(50, 10, false);
  pruefe('Kaestchentext ohne Kalibrierung nennt KEIN Millivolt', t.indexOf('mV') < 0, t);
  pruefe('Kaestchentext ohne Kalibrierung nennt trotzdem die Zeit', /20 ms/.test(t), t);
  pruefe('Kaestchentext ohne Kalibrierung sagt es ausdruecklich',
    /nicht kalibriert/.test(t), t);
  pruefe('Kaestchentext MIT Kalibrierung nennt Millivolt',
    S.kaestchenText(50, 10, true).indexOf('mV') > 0);
  pruefe('Kaestchentext ohne Angabe verhaelt sich wie kalibriert (Rueckwaertsvertraeglichkeit)',
    S.kaestchenText(50, 10) === S.kaestchenText(50, 10, true));

  /* Die Achse muss das Feld auch WIRKLICH ausfuellen. Mit der alten Grenze von acht
   * Schritten endete sie bei 10 mm/mV schon 160 Punkte ueber der Grundlinie - die aeussere
   * Haelfte blieb unbeschriftet, und dort liegen die hohen R-Zacken. */
  /* Massstab der Forderung: die aeusserste Marke darf hoechstens EINE Schrittweite vom
   * nutzbaren Rand entfernt sein. Naeher geht nicht - die naechste Marke laege dann schon
   * im freigehaltenen Rand und muss wegfallen. */
  const nutzbar = mitte - 12;
  /* Die Schrittweite wird aus den Marken SELBST genommen, nicht noch einmal nachgerechnet.
   * Eine Nachrechnung im Test wuerde nur beweisen, dass ich zweimal dasselbe denke. */
  function schrittAus(marken) {
    const ys = marken.map((x) => x.y).sort((a, b) => a - b);
    return ys.length > 1 ? Math.min(...ys.slice(1).map((y, i) => y - ys[i])) : Infinity;
  }
  [...VERSTAERKUNG.map((g) => ['mV ' + g, S.mvMarken(hoehe, pmm, g, { oben: 12, unten: 14, minAbstand: 14 })]),
   ['mm', a10]].forEach(([was, m]) => {
    const hoechste = Math.max(...m.map((x) => Math.abs(mitte - x.y)));
    const schrittPx = schrittAus(m);
    pruefe(was + ': Achse reicht bis an den Rand',
      hoechste > nutzbar - schrittPx,
      'reicht ' + hoechste + ' von ' + nutzbar + ', Schritt ' + schrittPx);
    /* ... und ist trotzdem lesbar: nicht mehr als MAX_PRO_SEITE Beschriftungen je Richtung. */
    pruefe(was + ': Achse bleibt lesbar (hoechstens ' + S.MAX_PRO_SEITE + ' je Seite)',
      m.filter((x) => x.y < mitte).length <= S.MAX_PRO_SEITE,
      m.filter((x) => x.y < mitte).length + ' Marken oberhalb der Grundlinie');
    pruefe(was + ': Marken stehen weit genug auseinander',
      schrittPx >= 14 - 1e-9, 'Abstand ' + schrittPx);
  });
  /* Der Sinn der Dichtegrenze: bei JEDER Verstaerkung soll etwa derselbe Abstand
   * herauskommen, damit die Achse nicht mal leer und mal ueberfuellt wirkt. */
  {
    const abstaende = VERSTAERKUNG.map((g) =>
      schrittAus(S.mvMarken(hoehe, pmm, g, { oben: 12, unten: 14, minAbstand: 14 })));
    pruefe('Abstand aehnlich ueber alle Verstaerkungen',
      Math.max(...abstaende) / Math.min(...abstaende) <= 2,
      'Abstaende: ' + abstaende.join(', '));
  }

  // Unsinn erzeugt auch hier nichts
  [[0, 2], [100, 0], [NaN, 2], [100, NaN], [null, 2]].forEach(([h, p]) => {
    pruefe('mmMarken(' + h + ',' + p + ') leer', S.mmMarken(h, p, {}).length === 0);
  });
  pruefe('mmMarken ohne opts laeuft', Array.isArray(S.mmMarken(400, 2)));

  /* Quellpruefung: beide Zeichenstellen MUESSEN sich an M.kal binden. */
  const quelle = QUELLE_CODE;
  pruefe('Bildschirmachse fragt die Kalibrierung ab',
    /if\(M\.kal\)\{[\s\S]{0,400}?mvMarken[\s\S]{0,600}?mmMarken/.test(quelle));
  pruefe('PDF-Achse fragt die Kalibrierung ab',
    /kal\s*\?\s*S\.mvMarken[^:]*:\s*S\.mmMarken/.test(quelle));
  pruefe('Kaestchentext bekommt die Kalibrierung mit',
    /kaestchenText\(speed,gain,!!M\.kal\)/.test(quelle));
  pruefe('keine unbedingte mV-Beschriftung mehr an der Achse',
    quelle.indexOf("a.mv+' mV'") < 0 || /if\(M\.kal\)/.test(quelle));
}

/* ================================================================================
 * 10. NIE DEHNEN — EIN ABTASTWERT BEKOMMT IMMER SEINE EIGENE BREITE
 *
 * WARUM DIESER TEST EXISTIERT (Befund der Freigabepruefung 08.08.2026):
 * Zoomfenster und PDF verteilten die vorhandenen Werte ueber die GANZE Flaeche. Reichte der
 * Puffer nicht, war die Kurve gedehnt - im haeufigsten Fall um 17 %, bei Uebersicht 50 und
 * Zoom 25 um 134 %. Der Zeit-Messzirkel rechnet Bildpunkte ueber den Vorschub in
 * Millisekunden um und setzt einen echten Massstab voraus: aus 17 % Dehnung wurde eine um
 * 17 % zu lange QRS-Dauer. Der Fehler war aelter als die Skala - die Skala haette ihn nur
 * endlich sichtbar gemacht.
 * ============================================================================== */
block('10. nie dehnen');
{
  const K = S.kurvenAusschnitt;

  /* Die Kernzusicherung: die belegte Breite ist IMMER (n-1) mal der Wertabstand.
   * Ist sie es nicht, wurde gedehnt oder gestaucht. */
  [[1265, 2, 25, 50, 1081], [1265, 2, 25, 100, 1081], [1265, 2, 50, 100, 1081],
   [1265, 2, 100, 50, 1081], [277, 1, 25, 50, 1081], [277, 1, 50, 50, 400],
   [600, 2, 25, 50, 50], [600, 2, 25, 50, 100000]].forEach(([b, p, v, hz, vorh]) => {
    const a = K(b, p, v, hz, vorh);
    const bez = b + '/' + p + '/' + v + ' mm/s/' + hz + ' Hz/' + vorh + ' Werte';
    gleich('Wertabstand ist speed*pmm/hz (' + bez + ')', a.proWert, v * p / hz, 1e-12);
    pruefe('nie mehr Werte als vorhanden (' + bez + ')', a.n <= vorh, 'n=' + a.n);
    pruefe('nie breiter als die Flaeche (' + bez + ')', a.breite <= b + 1e-9,
      'breite=' + a.breite);
    if (a.n >= 2) {
      gleich('Breite = (n-1) * Wertabstand (' + bez + ')',
        a.breite, (a.n - 1) * a.proWert, 1e-9);
      /* Und daraus folgt das, worauf es klinisch ankommt: die angezeigte Dauer ist die
       * Dauer, die die Werte wirklich abdecken. */
      gleich('angezeigte Dauer = n-1 Abtastschritte (' + bez + ')',
        a.breite / (p * v), (a.n - 1) / hz, 1e-9);
    }
  });

  /* Genau der Fall, der den Fehler ausgeloest hat: Puffer kuerzer als die Flaeche. */
  {
    const a = K(1265, 2, 25, 50, 1081);
    pruefe('kurzer Puffer fuellt die Flaeche NICHT aus', a.breite < 1265 - 1,
      'breite=' + a.breite);
    gleich('er nimmt alle vorhandenen Werte', a.n, 1081);
    /* Die alte Fassung haette hier 1265 belegt - das waeren 5,06 s statt der echten 21,6 s
     * bei 25 mm/s ... nachgerechnet: 1080 Schritte bei 50 Hz sind 21,6 s, und die brauchen
     * bei 25 mm/s und 2 Punkten je mm genau 1080 Punkte. */
    gleich('belegte Breite entspricht der echten Dauer', a.breite, 1080, 1e-9);
    const dauerEcht = 1080 / 50;
    gleich('echte Dauer', a.breite / (2 * 25), dauerEcht, 1e-9);
    const dauerGedehnt = 1265 / (2 * 25);
    pruefe('die alte Dehnung waere ein Fehler von ueber 15 % gewesen',
      (dauerGedehnt - dauerEcht) / dauerEcht > 0.15,
      'Fehler ' + Math.round((dauerGedehnt / dauerEcht - 1) * 100) + ' %');
  }

  /* Reichlich Puffer: die Flaeche wird ausgefuellt, bis auf hoechstens einen Wertabstand. */
  [[25, 50], [50, 100], [100, 50]].forEach(([v, hz]) => {
    const a = K(1265, 2, v, hz, 1000000);
    pruefe('voller Puffer fuellt die Flaeche (' + v + ' mm/s)',
      1265 - a.breite <= a.proWert + 1e-9,
      'Rest ' + (1265 - a.breite) + ', ein Wert ist ' + a.proWert);
  });

  // Unsinn erzeugt nichts, nicht irgendetwas
  [[0, 2, 25, 50, 100], [1265, 0, 25, 50, 100], [1265, 2, 0, 50, 100],
   [1265, 2, 25, 0, 100], [1265, 2, 25, 50, 0], [1265, 2, 25, 50, -5],
   [NaN, 2, 25, 50, 100], [1265, 2, 25, NaN, 100]].forEach((arg) => {
    const a = K.apply(null, arg);
    pruefe('kurvenAusschnitt(' + arg.join(',') + ') liefert nichts',
      a.n === 0 && a.breite === 0, JSON.stringify(a));
  });
  {
    const a = K(1265, 2, 25, 50, 1);
    pruefe('ein einzelner Wert ergibt keine Strecke', a.breite === 0, JSON.stringify(a));
  }

  /* Quellpruefung: BEIDE Zeichenwege muessen die gemeinsame Funktion benutzen. Eine eigene
   * Rechnung an einer der beiden Stellen faellt sonst niemandem auf. */
  const q = QUELLE_CODE;
  const treffer = q.match(/kurvenAusschnitt\(/g) || [];
  pruefe('Zoomfenster und PDF benutzen kurvenAusschnitt()', treffer.length >= 2,
    treffer.length + ' Aufrufe gefunden');
  pruefe('keine Verteilung ueber die ganze Flaeche mehr (Zoom)',
    q.indexOf('dx=w/(n-1)') < 0 && q.indexOf('dx = w/(n-1)') < 0);
  pruefe('keine Verteilung ueber die ganze Flaeche mehr (PDF)',
    q.indexOf('dxmm=w/(n-1)') < 0 && q.indexOf('dxmm = w/(n-1)') < 0);
  pruefe('das Zoomfenster kennzeichnet fehlendes Signal',
    /kein Signal/.test(q));
}

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.slice(0, 40).forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
