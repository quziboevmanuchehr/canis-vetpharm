'use strict';
/*
 * geraeteriegel.js — beantwortet EINE Frage: ist das am anderen Ende ueberhaupt ein Geraet?
 *
 * WARUM ES DIESE DATEI GIBT (17.08.2026):
 * Die Datenports der Station (1550, 2528, 2575, 3502, 4601, 5000, 5510, 8830, 24105) sind rohe
 * TCP-Lauscher. Sie muessen es sein: ein Monitor traegt die PC-Adresse als "Serveradresse" ein
 * und schiebt dann seinen Strom, ohne Handschlag und ohne Kopfzeilen. Genau deshalb kennt keiner
 * dieser Ports die Riegel aus herkunft.js — es gibt dort keine Anfrage, deren Herkunft man
 * pruefen koennte, nur Bytes.
 *
 * DER OFFENE WEG, gemessen und nachgebaut: eine Seite, die im Browser des Praxis-PCs offen ist,
 * kann an 127.0.0.1 auf einen dieser Ports schreiben. Der Browser schickt dabei eine gewoehnliche
 * HTTP-Anfrage; ihr Rumpf darf beliebige Bytes tragen. Beide Leser der Station suchen den
 * MLLP-Rahmen aber mit indexOf ueber den GANZEN Puffer (hl7.js:_onClient und
 * probe.js:_onClient) — sie finden ihn deshalb auch dann, wenn Kopfzeilen davorstehen. Ergebnis
 * im Versuch: ein frei erfundener Patient mit gefaehrlich falschen Werten erschien als echtes
 * Geraet, ging in die Registry, in den Rundruf und ueber cloud.js in die Fern-Ansicht.
 *
 * DAS IST DAS ANGRIFFSBILD DIESES PROJEKTS (tools/sicherheit-test.js beschreibt es als
 * "eine beliebige Webseite, die im Browser des Praxis-PCs offen ist"). Derselbe Weg war dort
 * schon einmal Thema: der SPEICHERUEBERLAUF durch dieselbe Tuer wurde am 08.08.2026 geschlossen
 * (MAX_PROBE_PUFFER). Die EINSPEISUNG durch dieselbe Tuer blieb offen.
 *
 * WARUM NICHT EINFACH DIE RUECKSCHLEIFE SPERREN: naheliegend, aber falsch. Erstens laufen die
 * eigenen Selbsttests genau so — sie stellen ein Geraet dar, indem sie von 127.0.0.1 aus
 * verbinden; eine Sperre haette die halbe Testreihe erschlagen. Zweitens hilft eine
 * Firewallregel hier nicht: Windows filtert Rueckschleifenverkehr nicht, ein
 * "-RemoteAddress LocalSubnet" in set-firewall.ps1 laesst 127.0.0.1 unberuehrt.
 *
 * GEPRUEFT WIRD DESHALB, WAS GESPROCHEN WIRD, NICHT WOHER. Ein Medizingeraet spricht auf einem
 * Datenport kein HTTP. Wer es doch tut, ist kein Geraet — unabhaengig davon, von welcher Adresse
 * er kommt. Damit bleibt der Weg fuer echte Geraete und fuer die Tests unveraendert offen.
 *
 * KEINE ABHAENGIGKEITEN, keine Zustaende, nur eine reine Funktion — damit sie ohne Netz und ohne
 * laufenden Server geprueft werden kann.
 */

/*
 * Die Methoden, die ein Browser von sich aus auf die Leitung bringen kann. CONNECT und TRACE
 * kann er nicht, sie stehen hier trotzdem: der Riegel soll auch einen Portscanner erkennen, und
 * eine zusaetzliche Methode kann nichts kaputtmachen, was ein Geraet je sendet.
 */
const METHODEN = ['GET', 'POST', 'HEAD', 'PUT', 'DELETE', 'OPTIONS', 'PATCH', 'TRACE', 'CONNECT'];

/* Laengste Methode + Leerzeichen + kuerzester Pfad + " HTTP/1." — so viel muss da sein, bevor
 * man sicher entscheiden kann. Vorher lautet die Antwort ausdruecklich "noch unklar". */
const MINDESTENS = 16;

/*
 * istHttpAnfrage(buf) — spricht der Absender HTTP?
 *
 *   liefert einen STRING  (die Methode) -> ja, sicher. Der Aufrufer trennt die Verbindung.
 *   liefert null                        -> nein, oder noch nicht entscheidbar. Weiter zuhoeren.
 *
 * ES WIRD NUR DER ANFANG DER VERBINDUNG GEPRUEFT, und zwar bewusst streng: verlangt wird die
 * vollstaendige Anfragezeile "METHODE <pfad> HTTP/1." — nicht bloss die Methode. Ein Geraet, das
 * zufaellig mit den drei Buchstaben "GET" beginnt, faellt damit NICHT durch; ohne diese Haerte
 * waere der Riegel selbst eine Gefahr, denn er wuerde echte Geraete abweisen, und ein Monitor,
 * der nicht ankommt, ist im OP schlimmer als eine falsche Zahl im Nachschlagewerk.
 */
function istHttpAnfrage(buf) {
  if (!buf || buf.length < MINDESTENS) return null;
  /* Nur den Anfang ansehen. 256 Byte reichen fuer jede Anfragezeile, die ein Browser bildet,
   * und begrenzen die Arbeit bei einem Strom, der im Takt hereinkommt. */
  const kopf = buf.slice(0, 256).toString('latin1');
  for (let i = 0; i < METHODEN.length; i++) {
    const m = METHODEN[i];
    if (kopf.slice(0, m.length + 1) !== m + ' ') continue;
    /* " HTTP/1." muss NACH der Methode stehen und vor dem ersten Zeilenumbruch. Ohne diese
     * Bedingung wuerde ein Geraet, dessen Strom mit "PUT " beginnt, hier haengenbleiben. */
    const zeilenEnde = kopf.indexOf('\r\n');
    const zeile = zeilenEnde === -1 ? kopf : kopf.slice(0, zeilenEnde);
    if (zeile.indexOf(' HTTP/1.') > m.length) return m;
    /* Die Anfragezeile ist noch nicht vollstaendig da: noch nicht entscheiden. */
    if (zeilenEnde === -1) return null;
    return null;
  }
  return null;
}

module.exports = { istHttpAnfrage, METHODEN };
