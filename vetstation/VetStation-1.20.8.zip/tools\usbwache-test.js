'use strict';
/*
 * usbwache-test.js - nimmt die Station ein angestecktes EKG 2000 wirklich von selbst
 * in Betrieb, und laesst sie alles andere in Ruhe?
 *
 * WARUM ES DIESEN TEST GIBT (16.08.2026):
 * Der Wunsch lautete "das Geraet laeuft beim Anschliessen direkt, ohne irgendwas zu machen".
 * Genau das ist die Sorte Zusage, die still zerbricht: die Wache laeuft, findet nichts, und
 * niemand merkt es, weil "nichts gefunden" auch der Normalfall ist, wenn kein Geraet steckt.
 * Deshalb wird hier mit AUFGEZEICHNETEN Geraetelisten geprueft - ohne Geraet, ohne Registry.
 *
 * DIE ZWEITE HAELFTE IST DIE WICHTIGERE: ein fremder USB-Seriell-Wandler (FT232R, der
 * Allerweltschip) darf NICHT als EKG gestartet werden. Sonst haenge die Station an jedem
 * beliebigen Adapter einen EKG-Leser, und der Anwender misstraute der Erkennung danach
 * ueberall zu Recht.
 *
 * Start: node tools/usbwache-test.js
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const seriell = require('../bridge/src/seriell.js');
const { USBWache } = require('../bridge/src/usbwache.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - USB-Wache (angestecktes EKG laeuft von selbst an)\n');

/* Die Registry wird NICHT gefragt: beide Quellen werden ersetzt. Damit laeuft der Test auch
 * auf einem Rechner, an dem gar kein FTDI-Geraet steckt - und er misst die Wache, nicht
 * den Zufall des Pruefrechners. */
const echtSeriell = seriell.usbSerielleGeraete;
const echtRoh = seriell.usbRohGeraete;

function stelle(mitPort, roh) {
  seriell.usbSerielleGeraete = () => Promise.resolve({ ok: true, grund: null, liste: mitPort });
  seriell.usbRohGeraete = () => Promise.resolve({ ok: true, grund: null, liste: roh });
}

const tmpKonfig = path.join(os.tmpdir(), 'vetstation-usbwache-test-devices.json');
function neueWache(extra) {
  try { if (fs.existsSync(tmpKonfig)) fs.unlinkSync(tmpKonfig); } catch (_) {}
  const gestartet = [];
  const meldungen = [];
  const w = new USBWache(Object.assign({
    log: {
      info(_b, t) { meldungen.push(t); },
      warn(_b, t) { meldungen.push(t); },
      error(_b, t) { meldungen.push(t); },
    },
    registry: { adapters: [] },
    adapterStarten: (cfg) => { gestartet.push(cfg); return true; },
    konfigPfad: tmpKonfig,
  }, extra || {}));
  return { w: w, gestartet: gestartet, meldungen: meldungen };
}

(async function lauf() {
  block('1. ein angestecktes EKG 2000 wird gestartet');
  stelle([
    { port: 'COM5', vid: '0403', pid: '8ac8', serie: 'EK2K0017',
      name: 'EKG 2000', katalogId: 'eickemeyer-ekg-2000', erkannt: true, treiberMitgeliefert: true },
  ], []);
  let t = neueWache();
  let erg = await t.w.einmal();
  pruef('genau ein Adapter gestartet', t.gestartet.length === 1, String(t.gestartet.length));
  if (t.gestartet.length) {
    const c = t.gestartet[0];
    pruef('mit dem Adaptertyp ekg2000', c.type === 'ekg2000', String(c.type));
    pruef('am richtigen Anschluss COM5', c.port === 'COM5', String(c.port));
    pruef('mit einer wiedererkennbaren Kennung', c.id === 'ekg2000-com5', String(c.id));
    pruef('und mit vermerkter Herkunft', /usbwache/.test(c.herkunft || ''), String(c.herkunft));
  }
  pruef('der Eintrag wurde gesichert', fs.existsSync(tmpKonfig));
  if (fs.existsSync(tmpKonfig)) {
    const doc = JSON.parse(fs.readFileSync(tmpKonfig, 'utf8'));
    pruef('und steht wirklich in devices.json',
      doc.adapters && doc.adapters.some((a) => a.id === 'ekg2000-com5'), JSON.stringify(doc.adapters));
  }

  block('2. derselbe Durchgang zweimal startet nicht zweimal');
  /* Ein Adapter, der bei jedem Takt noch einmal gestartet wird, oeffnet denselben Anschluss
   * alle 12 s neu - das Fehlerbild waere "das EKG bricht staendig ab". */
  t.w.registry.adapters.push({ id: 'ekg2000-com5' });
  const vorher = t.gestartet.length;
  await t.w.einmal();
  pruef('kein zweiter Start', t.gestartet.length === vorher, String(t.gestartet.length));

  block('3. ein fremder USB-Seriell-Wandler wird NICHT gestartet');
  stelle([
    { port: 'COM9', vid: '0403', pid: '6001', serie: 'A50285BI',
      name: null, katalogId: null, erkannt: false, treiberMitgeliefert: null },
  ], []);
  t = neueWache();
  await t.w.einmal();
  pruef('kein Adapter fuer den FT232R', t.gestartet.length === 0, String(t.gestartet.length));
  pruef('und auch kein Eintrag in devices.json', !fs.existsSync(tmpKonfig));

  block('4. angesteckt, aber ohne Treiber: die Station sagt es - und zwar nur einmal');
  stelle([], [
    { vid: '0403', pid: '8ac8', serie: 'EK2K0099', name: 'EKG 2000',
      katalogId: 'eickemeyer-ekg-2000', treiberMitgeliefert: true, treiberLaeuft: false,
      hinweis: 'Nachholen: installer\\set-ekg-treiber.ps1 -Erzwingen (als Administrator).' },
  ]);
  t = neueWache();
  erg = await t.w.einmal();
  pruef('der Hinweis kommt', erg.hinweise.length === 1, String(erg.hinweise.length));
  pruef('kein Adapter wird gestartet (es gibt ja keinen Anschluss)', t.gestartet.length === 0);
  const nachErstem = t.meldungen.length;
  erg = await t.w.einmal();
  /* Eine Warnung, die alle 12 s wiederkommt, liest nach dem dritten Mal niemand mehr - und
   * sie verdraengt im Protokoll das, was wirklich neu ist. */
  pruef('beim zweiten Durchgang kommt er NICHT noch einmal', erg.hinweise.length === 0, String(erg.hinweise.length));
  pruef('und es steht auch keine neue Zeile im Protokoll', t.meldungen.length === nachErstem,
    t.meldungen.length + ' statt ' + nachErstem);

  block('5. abgeschaltet heisst abgeschaltet');
  stelle([
    { port: 'COM5', vid: '0403', pid: '8ac8', serie: 'X', name: 'EKG 2000',
      katalogId: 'eickemeyer-ekg-2000', erkannt: true, treiberMitgeliefert: true },
  ], []);
  t = neueWache({ enabled: false });
  await t.w.einmal();
  pruef('bei enabled:false wird nichts gestartet', t.gestartet.length === 0, String(t.gestartet.length));

  block('6. eine kaputte devices.json legt die Station nicht lahm');
  /* Der Adapter MUSS trotzdem starten. Ein Geraet nicht in Betrieb zu nehmen, weil eine
   * Konfigurationsdatei beschaedigt ist, waere die falsche Reihenfolge der Sorgen. */
  fs.writeFileSync(tmpKonfig, '{ das ist kein JSON', 'utf8');
  t = neueWache({});
  fs.writeFileSync(tmpKonfig, '{ das ist kein JSON', 'utf8');
  await t.w.einmal();
  pruef('der Adapter laeuft trotzdem an', t.gestartet.length === 1, String(t.gestartet.length));

  block('7. start() greift nicht sofort zu (Doppelstart-Falle)');
  /*
   * GEMESSEN AM LAUFENDEN START (16.08.2026): die Zeile der USB-Wache stand um 08:38:41.782
   * im Protokoll, der Doppelstart-Riegel schlug erst um 08:38:42.219 zu. Eine zum Abbruch
   * bestimmte Zweitinstanz haette in diesen 0,4 s den COM-Anschluss geoeffnet, an dem die
   * WIRKLICH laufende Station haengt - das EKG waere kurz abgerissen, und niemand haette das
   * einer Geraetesuche zugeschrieben. Deshalb wartet der erste Durchgang.
   */
  const W = require('../bridge/src/usbwache.js');
  pruef('der erste Durchgang wartet mindestens 3 s', W.ERSTER_LAUF_MS >= 3000, String(W.ERSTER_LAUF_MS));
  pruef('und der Doppelstart-Riegel (unter 1 s) kommt sicher vorher', W.ERSTER_LAUF_MS > 1000);
  stelle([
    { port: 'COM5', vid: '0403', pid: '8ac8', serie: 'X', name: 'EKG 2000',
      katalogId: 'eickemeyer-ekg-2000', erkannt: true, treiberMitgeliefert: true },
  ], []);
  t = neueWache();
  t.w.start();
  await new Promise((r) => setTimeout(r, 300));
  pruef('300 ms nach start() wurde noch nichts geoeffnet', t.gestartet.length === 0, String(t.gestartet.length));
  /* Und die Gegenprobe zum Beenden: stop() muss BEIDE Zeitgeber loeschen, sonst haengt ein
   * sofort wieder beendeter Prozess noch fuenf Sekunden. */
  t.w.stop();
  pruef('stop() loescht den Ersttimer', t.w._erstTimer === null);
  pruef('stop() loescht den Takttimer', t.w._timer === null);

  try { if (fs.existsSync(tmpKonfig)) fs.unlinkSync(tmpKonfig); } catch (_) {}
  seriell.usbSerielleGeraete = echtSeriell;
  seriell.usbRohGeraete = echtRoh;

  console.log('\n===============================================================');
  if (fehler.length) {
    console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
    fehler.forEach((f) => console.log('   ✗ ' + f));
    console.log('===============================================================\n');
    process.exit(1);
  }
  console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
  console.log('===============================================================\n');
})().catch((e) => { console.log('ABGEBROCHEN: ' + (e && e.stack)); process.exit(1); });
