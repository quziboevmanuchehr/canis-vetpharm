'use strict';
/*
 * ekg2000-protokoll.js - das Anmeldegespraech des Eickemeyer/Grimed EKG 2000, belegt aus
 * dem Herstellerprogramm.
 *
 * WARUM ES DIESE DATEI GIBT (16.08.2026):
 * Bis heute stand im Geraetekatalog "Datenformat unbekannt - VetStation liest dieses Geraet
 * NICHT". Der Grund war echt: das Protokoll ist nirgends veroeffentlicht. Am 16.08.2026 hat
 * der Nutzer das Installationsarchiv des Herstellers entschluesselt beigebracht. Damit liess
 * sich das Anmeldegespraech aus dem Maschinencode der Originalprogramme HERAUSLESEN - nicht
 * raten. Jede Zahl in dieser Datei hat unten eine Fundstelle.
 *
 * WAS HIER STEHT UND WAS AUSDRUECKLICH NICHT:
 *   STEHT:        Leitungsparameter, Kennungsabfrage, Bedeutung der Antwortbytes,
 *                 Bootlader-Handshake, Aufbau des Firmware-Uploads.
 *   STEHT NICHT:  der Aufbau des MESSDATENSTROMS (Rahmenlaenge, Kanalfolge, Bits je
 *                 Abtastwert, Abtastrate, Mikrovolt je Digit). Das war aus dem Code in der
 *                 verfuegbaren Zeit nicht zweifelsfrei zu belegen. Deshalb behauptet dieses
 *                 Modul dazu NICHTS. Die Regel des Projekts gilt gerade hier: eine erfundene
 *                 Rahmenlaenge erzeugt eine Kurve, die aussieht wie ein EKG und keine ist.
 *
 * FUNDSTELLEN (Dateien aus dem Archiv "PC-EKG.zip", Fassung 2.04.08, Grimed 1999-2024):
 *
 *   Leitungsparameter
 *     EKG_V.exe   VA 0x675489 und 0x67552C:  mov ecx, 19200   -> Open(..., BaudRate, ...)
 *     Monitor.exe VA 0x4E5118 und 0x4E51BB:  mov ecx, 19200   -> dieselbe Stelle
 *     EKG_V.exe   VA 0x66B8B8 und 0x66B8DE:  mov edx, 38400   -> SetupComPort(ABaudRate,...)
 *     Monitor.exe VA 0x4DA414 (SetupComPort) belegt die DCB:
 *         [DCB+18] = 8      ByteSize   (c6 45 f6 08)
 *         [DCB+20] = 0      StopBits = ONESTOPBIT (c6 45 f8 00)
 *         [DCB+8]  = 0x1001 fBinary=1, fRtsControl=RTS_CONTROL_ENABLE, sonst nichts
 *                           -> KEINE Flusssteuerung (kein CTS/DSR/XON)
 *         [DCB+4]  = Baudrate aus dem Parameter
 *     Paritaet: beide Aufrufer uebergeben 2 = EVENPARITY (6a 02 als erster Stapelparameter
 *               von Open; b9 02 00 00 00 als AParity von SetupComPort).
 *
 *   Kennungsabfrage - Monitor.exe VA 0x4DAA03, Methode VerzeCDS(Self, @Verze):
 *         FT_W32_PurgeComm(handle, 12)      Puffer leeren
 *         SendByte(0x10)                    Anfrage
 *         bis zu 50 Versuche: ReadByte; kam nichts, erneut 0x10 senden
 *         Antwort 0xAF  -> Geraet noch nicht bereit, weiter fragen
 *         Antwort 0x10  -> nur das eigene Echo, das gilt als FEHLER (setne bl)
 *         sonst         -> das gelesene Byte ist die Kennung
 *
 *   Bedeutung der Kennung - Monitor.exe VA 0x4E1B45 ff., EKG_V.exe VA 0x66B4D0 ff.:
 *         0x20        -> Bauart 1, Firmware MONITOR.BIN   bzw. EKG_V_C1.BIN
 *         0x21, 0x22  -> Bauart 2, Firmware MONITOR2.BIN  bzw. EKG_VC11.BIN
 *         alles andere-> das Programm bricht mit einer Fehlermeldung ab
 *
 *   Bootlader und Firmware - Monitor.exe VA 0x4DA8xx, Methode LoadPrgToCDS(SouborName):
 *         SendText(":F" + Chr(0x80), 3); WaitCommTxEmpty; Pause 7; ReadText(7)
 *         erwartete Antwort: "F_1.0.1"
 *         danach die Datei in Bloecken zu 16 Byte, Zieladresse beginnt bei 0x8000
 *         und waechst je Block um 16; der Rest am Ende in einem kuerzeren Block.
 *
 * Reine Funktionen, keine Ein-/Ausgabe - damit ohne Geraet pruefbar
 * (tools/ekg2000-protokoll-test.js).
 */

/* ------------------------------------------------------------------------------------------
 * Leitungsparameter.
 *
 * WARUM ZWEI SAETZE: das Geraet meldet sich bei 19200 an und wird fuer die Aufzeichnung auf
 * 38400 umgeschaltet. Wer nur mit 38400 aufmacht, bekommt beim Anmelden Buchstabensalat und
 * haelt das Geraet fuer defekt. Die Reihenfolge ist also Teil des Protokolls, keine Vorliebe.
 * ---------------------------------------------------------------------------------------- */
const LEITUNG_ANMELDUNG = { baud: 19200, datenbits: 8, paritaet: 'e', stopbits: 1 };
const LEITUNG_BETRIEB   = { baud: 38400, datenbits: 8, paritaet: 'e', stopbits: 1 };

/* Die Bytes, die den PC ueberhaupt verlassen duerfen. Diese Liste ist die Sicherheitszusage
 * dieses Adapters: seriell.js weist alles ab, was nicht darinsteht. Es sind ausschliesslich
 * AUSKUNFTS-Anfragen - nichts davon veraendert eine Einstellung am Geraet. Der Firmware-Upload
 * steht bewusst NICHT hier (siehe firmwareBloecke unten). */
const ANFRAGE_KENNUNG = 0x10;          /* "wer bist du" */
const ANTWORT_NICHT_BEREIT = 0xaf;     /* Geraet meldet: noch nicht so weit */
const VERSUCHE_MAX = 50;               /* wie im Original */

/* ------------------------------------------------------------------------------------------
 * deuteKennung - was bedeutet das Antwortbyte?
 *
 * Gibt IMMER ein Urteil mit Begruendung zurueck, nie nur einen Wahrheitswert: der haeufigste
 * Fall in der Praxis ist "es kommt etwas, aber nicht das Erwartete", und dann ist die Frage
 * des Anwenders "was denn nun" - nicht "ja oder nein".
 * ---------------------------------------------------------------------------------------- */
function deuteKennung(byte) {
  if (byte === null || byte === undefined) {
    return { bekannt: false, bereit: false, bauart: null, firmware: null,
      urteil: 'Es kam keine Antwort auf die Kennungsabfrage.' };
  }
  const b = byte & 0xff;
  if (b === ANTWORT_NICHT_BEREIT) {
    return { bekannt: true, bereit: false, bauart: null, firmware: null,
      urteil: 'Das Geraet meldet "noch nicht bereit" (0xAF). Das ist ein gueltiger Zustand - '
        + 'die Abfrage wird wiederholt.' };
  }
  if (b === ANFRAGE_KENNUNG) {
    /* Das Originalprogramm wertet genau diesen Fall als Fehler (setne bl nach cmp 0x10). */
    return { bekannt: true, bereit: false, bauart: null, firmware: null,
      urteil: 'Zurueck kam nur das eigene Anfragebyte (0x10). Das ist kein Geraet, das '
        + 'antwortet, sondern eine Leitung, die zurueckspiegelt - meist ein falscher Anschluss '
        + 'oder ein Adapter mit gebrueckten Sende- und Empfangsleitungen.' };
  }
  if (b === 0x20) {
    return { bekannt: true, bereit: true, bauart: 1,
      firmware: { monitor: 'MONITOR.BIN', ruhe: 'EKG_V_C1.BIN' },
      urteil: 'EKG 2000 der Bauart 1 (Kennung 0x20).' };
  }
  if (b === 0x21 || b === 0x22) {
    return { bekannt: true, bereit: true, bauart: 2,
      firmware: { monitor: 'MONITOR2.BIN', ruhe: 'EKG_VC11.BIN' },
      urteil: 'EKG 2000 der Bauart 2 (Kennung 0x' + b.toString(16).toUpperCase() + ').' };
  }
  /* WICHTIG: hier wird NICHT geraten. Das Originalprogramm bricht an dieser Stelle ab, und
   * genau das sagen wir auch - statt eine dritte Bauart zu erfinden. */
  return { bekannt: false, bereit: false, bauart: null, firmware: null,
    urteil: 'Antwort 0x' + b.toString(16).toUpperCase() + ' - diese Kennung kennt auch das '
      + 'Herstellerprogramm nicht (es bricht bei allem ausser 0x20/0x21/0x22 ab). '
      + 'Es haengt etwas anderes an diesem Anschluss.' };
}

/* ==========================================================================================
 * DER MESSDATENSTROM (16.08.2026 aus EKG_V.exe gelesen, Fundstellen unten).
 *
 * Aufbau eines Rahmens:
 *     Byte 0      0x80                Synchronbyte
 *     Byte 1..n   je Kanal EINE vorzeichenbehaftete 8-Bit-DIFFERENZ
 *
 * n ist 8 bei der erweiterten Ausfuehrung und 3 bei der Standardausfuehrung; bei 3 setzt das
 * Originalprogramm die restlichen fuenf Kanaele auf 0. Das deckt sich mit dem Handbuch
 * ("Standardausfuehrung 3 Extremitaetenkanaele, erweiterte Ausfuehrung ausserdem bis 6
 * Brustwandkanaele") - zwei unabhaengige Quellen, die dasselbe sagen.
 *
 * ES SIND DIFFERENZEN, KEINE ABSOLUTWERTE. Das ist die Stelle, an der man sich am
 * teuersten irren kann: wer die Bytes als Messwerte zeichnet, bekommt eine zappelnde Linie,
 * die wie ein verrauschtes EKG aussieht - und nicht wie ein Fehler. Der Messwert entsteht
 * erst durch Aufsummieren (Integration) je Kanal.
 *
 * FUNDSTELLEN (EKG_V.exe, ImageBase 0x400000):
 *     0x66C47A  80 7d f3 80              cmp byte [ebp-0Dh], 0x80     Synchronbyte
 *     0x66C4A6  b9 08 00 00 00           mov ecx, 8                   8 Nutzbytes
 *     0x66C4EC  b9 03 00 00 00           mov ecx, 3                   oder 3 Nutzbytes
 *     0x66C4CB  bb 05 00 00 00 / c6 07 00  die uebrigen 5 auf 0 setzen
 *     0x66C518  0f be 45 f3              movsx eax, byte              VORZEICHEN
 *     0x66C528  66 01 84 5a 76 32 00 00  add word [edx+ebx*2+3276h], ax   Aufsummieren
 *     0x66C55D  43 / 83 fb 09 / 75 af    Kanaele ebx = 1..8
 * Derselbe Parser steht in Monitor.exe ab 0x4E2570 (dort mit Basis 0x32F4).
 *
 * WAS HIER BEWUSST FEHLT - und warum das kein Versaeumnis ist:
 *   ABTASTRATE und MIKROVOLT JE DIGIT stehen weder im Handbuch (die "Technischen Daten"
 *   nennen nur Empfindlichkeit und Vorschub) noch als Konstante im Programm. Sie werden
 *   deshalb NICHT geraten, sondern GEMESSEN - siehe Ratenmesser unten und den Eichabgleich
 *   im Adapter. Eine geratene Rate verschiebt jede Zeitmessung (PQ, QRS, QT) linear mit,
 *   ohne dass die Kurve verdaechtig aussaehe; genau das darf hier nicht passieren.
 * ========================================================================================== */
const SYNC = 0x80;
const KANAELE_MAX = 8;

/*
 * rahmenLaenge(kanaele) — Synchronbyte plus je Kanal ein Differenzbyte.
 */
function rahmenLaenge(kanaele) { return 1 + kanaele; }

/*
 * Rahmenleser. Zustandsbehaftet, weil ein Datenstrom nun einmal mitten im Rahmen
 * ankommen kann - aber ohne Ein-/Ausgabe, damit er mit aufgezeichneten Stroemen
 * pruefbar ist.
 *
 * kanaele: 3 (Standardausfuehrung) oder 8 (erweiterte Ausfuehrung).
 */
function Rahmenleser(kanaele) {
  const n = kanaele === 3 ? 3 : KANAELE_MAX;
  this.kanaele = n;
  this.rest = Buffer.alloc(0);
  /*
   * Der laufende Summenwert je Kanal. 16 Bit mit Vorzeichen, wie im Original (add word).
   *
   * DIE KANAELE ZAEHLEN AB 1, INDEX 0 BLEIBT LEER — und das ist Absicht, keine Schlamperei:
   * das Originalprogramm zaehlt ebx von 1 bis 8 und legt bei [Basis + ebx*2] ab. Wer hier
   * auf 0-basiert umstellt, muss an JEDER Verbraucherstelle wieder +1 rechnen. Genau das
   * ist am 16.08.2026 passiert: der Rahmenleser lieferte 0-basiert, der Adapter las
   * 1-basiert - Kanal 1 fiel weg und Kanal 8 war undefined. Aufgefallen ist es nur, weil
   * der Test die Kanalnummern EINZELN prueft statt nur die Anzahl.
   */
  this.stand = new Array(KANAELE_MAX + 1).fill(0);
  this.rahmen = 0;
  this.verworfen = 0;      /* Bytes, die vor einem Synchronbyte lagen */
}

/*
 * schiebe(buf) — neue Bytes hineingeben, fertige Abtastwerte herausbekommen.
 * Rueckgabe: Array von Arrays; je Rahmen ein Array mit KANAELE_MAX Summenwerten.
 */
Rahmenleser.prototype.schiebe = function (buf) {
  let d = this.rest.length ? Buffer.concat([this.rest, buf]) : buf;
  const laenge = rahmenLaenge(this.kanaele);
  const aus = [];
  let i = 0;
  while (i + laenge <= d.length) {
    if (d[i] !== SYNC) {
      /* Kein Rahmenanfang: EIN Byte weiterruecken und neu suchen. Nicht den ganzen Rahmen
       * ueberspringen - sonst rastet ein einmal verschobener Strom nie wieder ein. */
      i++; this.verworfen++;
      continue;
    }
    for (let k = 1; k <= this.kanaele; k++) {
      /* Vorzeichenbehaftet lesen und aufsummieren, dann auf 16 Bit mit Vorzeichen
       * zurechtstutzen - genau das tut "add word" im Original. */
      const diff = d.readInt8(i + k);
      let s = (this.stand[k] + diff) & 0xffff;
      if (s > 0x7fff) s -= 0x10000;
      this.stand[k] = s;
    }
    aus.push(this.stand.slice());
    this.rahmen++;
    i += laenge;
  }
  this.rest = i < d.length ? d.slice(i) : Buffer.alloc(0);
  return aus;
};

/* ------------------------------------------------------------------------------------------
 * kanaeleErkennen — Standard- oder erweiterte Ausfuehrung? MESSEN, nicht einstellen lassen.
 *
 * WARUM DAS SEIN MUSS (16.08.2026): das Handbuch kennt zwei Ausfuehrungen, und sie senden
 * verschieden lange Rahmen - 4 Byte bei drei Extremitaetenkanaelen, 9 Byte bei acht. Wer die
 * falsche Laenge annimmt, findet das Synchronbyte NIE an der erwarteten Stelle und bekommt
 * entweder gar keine Kurve oder, schlimmer, eine aus versetzt zusammengesetzten Kanaelen.
 * Der Anwender kann das nicht wissen, und fragen waere das Gegenteil von "anstecken genuegt".
 *
 * WIE GEMESSEN WIRD, ohne etwas anzunehmen: bei der richtigen Rahmenlaenge liegt das
 * Synchronbyte 0x80 IMMER auf derselben Restklasse. Also fuer jede Kandidatenlaenge die beste
 * Phase suchen und zaehlen, wie oft dort wirklich 0x80 steht. Die richtige Laenge kommt nahe
 * an 1,0; die falsche bleibt bei etwa 1/L, weil die Synchronbytes sich dann gleichmaessig auf
 * alle Restklassen verteilen (4 und 9 sind teilerfremd). Der Abstand ist damit so gross, dass
 * er keine Ermessensfrage ist.
 *
 * Gibt null zurueck, wenn keine Laenge ueberzeugt - dann wird NICHTS behauptet.
 * ---------------------------------------------------------------------------------------- */
const KANDIDATEN = [3, 8];
const ERKENNUNG_MIN_ANTEIL = 0.9;   /* die richtige Laenge trifft praktisch immer */
const ERKENNUNG_VORSPRUNG = 2.0;    /* und mindestens doppelt so gut wie die andere */
const ERKENNUNG_MIN_BYTES = 200;

function kanaeleErkennen(buf) {
  if (!buf || buf.length < ERKENNUNG_MIN_BYTES) {
    return { kanaele: null, sicher: false,
      urteil: 'Zu wenig Daten (' + (buf ? buf.length : 0) + ' Byte) fuer eine Aussage.' };
  }
  const werte = KANDIDATEN.map((k) => {
    const L = rahmenLaenge(k);
    let besterAnteil = 0, bestePhase = 0;
    for (let p = 0; p < L; p++) {
      let treffer = 0, gesamt = 0;
      for (let i = p; i < buf.length; i += L) { gesamt++; if (buf[i] === SYNC) treffer++; }
      const anteil = gesamt ? treffer / gesamt : 0;
      if (anteil > besterAnteil) { besterAnteil = anteil; bestePhase = p; }
    }
    return { kanaele: k, laenge: L, anteil: besterAnteil, phase: bestePhase };
  });
  werte.sort((a, b) => b.anteil - a.anteil);
  const erst = werte[0], zweit = werte[1];
  const vorsprung = zweit.anteil > 0 ? erst.anteil / zweit.anteil : Infinity;
  const sicher = erst.anteil >= ERKENNUNG_MIN_ANTEIL && vorsprung >= ERKENNUNG_VORSPRUNG;
  return {
    kanaele: sicher ? erst.kanaele : null,
    sicher: sicher,
    anteil: erst.anteil,
    vorsprung: vorsprung === Infinity ? null : vorsprung,
    urteil: sicher
      ? ('Ausfuehrung mit ' + erst.kanaele + ' Kanaelen erkannt: das Synchronbyte 0x80 steht in '
        + Math.round(erst.anteil * 100) + ' % der Faelle an derselben Stelle eines '
        + erst.laenge + '-Byte-Rahmens (die andere Laenge kommt nur auf '
        + Math.round(zweit.anteil * 100) + ' %).')
      : ('Keine Rahmenlaenge ueberzeugt (bester Wert ' + Math.round(erst.anteil * 100)
        + ' % bei ' + erst.laenge + ' Byte). Es wird nichts angenommen - moeglich sind ein '
        + 'noch nicht gestarteter Strom, eine falsche Baudrate oder eine dritte Bauart.'),
  };
}

/* ------------------------------------------------------------------------------------------
 * Ratenmesser — die Abtastrate MESSEN statt annehmen.
 *
 * WARUM SO UND NICHT AUS EINER TABELLE: die Rate steht nirgends. Sie laesst sich aber ohne
 * jede Annahme bestimmen, weil das Geraet gleichmaessig sendet: Rahmen zaehlen, Uhrzeit
 * dazu, teilen. Nach ein paar Sekunden ist das genauer als jede Herstellerangabe es waere.
 *
 * Erst ab MINDEST_RAHMEN und MINDEST_MS wird ueberhaupt etwas behauptet; vorher gibt
 * hertz() null zurueck. Ein zu frueh genannter Wert waere schlimmer als keiner, weil jede
 * Zeitmessung linear daran haengt.
 * ---------------------------------------------------------------------------------------- */
const MINDEST_RAHMEN = 500;
const MINDEST_MS = 3000;

function Ratenmesser() { this.ersteMs = 0; this.rahmen = 0; this.letzteMs = 0; }

Ratenmesser.prototype.zaehle = function (anzahl, jetztMs) {
  if (!this.ersteMs) { this.ersteMs = jetztMs; return; }   /* der erste Block eicht die Uhr */
  this.rahmen += anzahl;
  this.letzteMs = jetztMs;
};

Ratenmesser.prototype.hertz = function () {
  const dauer = this.letzteMs - this.ersteMs;
  if (this.rahmen < MINDEST_RAHMEN || dauer < MINDEST_MS) return null;
  return this.rahmen / (dauer / 1000);
};

/*
 * gerundet() — auf eine uebliche Rate einrasten, ABER nur wenn die Messung nahe genug
 * liegt (2 %). Sonst wird der gemessene Wert selbst zurueckgegeben.
 *
 * Warum ueberhaupt einrasten: eine gemessene 249,6 Hz ist mit an Sicherheit grenzender
 * Wahrscheinlichkeit ein Quarz mit 250 Hz, und krumme Raten pflanzen sich in jede
 * Zeitangabe fort. Warum nur bei 2 %: bei groesserer Abweichung ist die Annahme "das ist
 * eigentlich 250" nicht mehr gedeckt - dann gilt, was gemessen wurde.
 */
const UEBLICHE_RATEN = [100, 125, 128, 200, 250, 256, 300, 333, 360, 400, 500, 512, 1000];

function gerundet(hz) {
  if (!hz) return null;
  let beste = null, abstand = Infinity;
  UEBLICHE_RATEN.forEach((r) => {
    const a = Math.abs(r - hz) / r;
    if (a < abstand) { abstand = a; beste = r; }
  });
  return abstand <= 0.02 ? { hz: beste, eingerastet: true, gemessen: hz }
    : { hz: hz, eingerastet: false, gemessen: hz };
}

/* ------------------------------------------------------------------------------------------
 * Bootlader.
 *
 * WARUM DAS HIER STEHT, OBWOHL VetStation ES (NOCH) NICHT BENUTZT:
 * Das EKG 2000 ist ohne Firmware stumm - es holt sein Programm bei jedem Start vom PC. Wer
 * spaeter Messdaten lesen will, kommt daran nicht vorbei. Die Bytes hier sind gemessen und
 * gehoeren dokumentiert, damit der Naechste sie nicht noch einmal suchen muss.
 * ---------------------------------------------------------------------------------------- */
const BOOTLADER_ANFRAGE = Buffer.from([0x3a, 0x46, 0x80]);   /* ":F" + 0x80 */
const BOOTLADER_ANTWORT = 'F_1.0.1';
const FIRMWARE_STARTADRESSE = 0x8000;
const FIRMWARE_BLOCK = 16;

/*
 * firmwareBloecke(laenge) - die Aufteilung, die das Originalprogramm vornimmt.
 * Reine Rechnung ohne Ein-/Ausgabe; sie belegt nur, wie der Upload AUSSAEHE. Ausgefuehrt wird
 * er hier nicht: die Firmwaredateien gehoeren dem Hersteller und liegen nicht im Paket.
 */
function firmwareBloecke(laenge) {
  const bloecke = [];
  let adresse = FIRMWARE_STARTADRESSE;
  let rest = laenge;
  let ab = 0;
  while (rest >= FIRMWARE_BLOCK) {
    bloecke.push({ adresse: adresse, ab: ab, laenge: FIRMWARE_BLOCK });
    adresse += FIRMWARE_BLOCK; ab += FIRMWARE_BLOCK; rest -= FIRMWARE_BLOCK;
  }
  /* Der Rest geht in einem kuerzeren Block - im Original der Zweig hinter "test esi,esi". */
  if (rest > 0) bloecke.push({ adresse: adresse, ab: ab, laenge: rest });
  return bloecke;
}

/* ------------------------------------------------------------------------------------------
 * Die Befehle des Messbetriebs (EKG_V.exe / Monitor.exe ab VA 0x4E1C40).
 *
 *   0x90  "melde dich"      -> das Geraet antwortet mit VIER Bytes
 *   0x88  "sende Messdaten" -> ab hier laeuft der Rahmenstrom
 *   0x80  "halt an"         -> beendet den Strom (an zwei Stellen als Abschluss gesendet)
 *
 * Fundstellen: b2 90 / b2 88 / b2 80 jeweils unmittelbar vor SendByte, dazwischen
 * WaitCommRx(4, 300) und ReadText(@buf, 4).
 * ---------------------------------------------------------------------------------------- */
const BEFEHL_MELDEN = 0x90;
const BEFEHL_START  = 0x88;
const BEFEHL_STOP   = 0x80;
const MELDEN_ANTWORT_BYTES = 4;
const MELDEN_FRIST_MS = 300;

/* Pause zwischen zwei Kennungsabfragen. Im Original Mezera(200) unmittelbar vor dem
 * erneuten SendByte(0x10) - VA 0x4D295F: ba c8 00 00 00. */
const ANFRAGE_ABSTAND_MS = 200;

module.exports = {
  LEITUNG_ANMELDUNG, LEITUNG_BETRIEB,
  ANFRAGE_KENNUNG, ANTWORT_NICHT_BEREIT, VERSUCHE_MAX, ANFRAGE_ABSTAND_MS,
  deuteKennung,
  BEFEHL_MELDEN, BEFEHL_START, BEFEHL_STOP, MELDEN_ANTWORT_BYTES, MELDEN_FRIST_MS,
  SYNC, KANAELE_MAX, rahmenLaenge, Rahmenleser, kanaeleErkennen, ERKENNUNG_MIN_BYTES,
  Ratenmesser, gerundet, UEBLICHE_RATEN, MINDEST_RAHMEN, MINDEST_MS,
  BOOTLADER_ANFRAGE, BOOTLADER_ANTWORT, FIRMWARE_STARTADRESSE, FIRMWARE_BLOCK, firmwareBloecke,
};
