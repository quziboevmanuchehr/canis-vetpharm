'use strict';
/*
 * alter-test.js — Alter aus Geburtsdatum oder Schaetzung.
 *
 * WARUM DAS EINEN EIGENEN TEST BRAUCHT (09.08.2026):
 * Altersrechnung sieht trivial aus und ist es nicht. Die drei Fallen, an denen sie in der
 * Praxis scheitert, sind hier ALLE als Pruefung festgehalten:
 *   1. new Date("2020-03-01") liest UTC-Mitternacht. In Mitteleuropa ergibt das den 29.02.
 *      Ein um einen Tag verschobenes Geburtsdatum faellt niemandem auf und verschiebt jede
 *      Altersgrenze - genau die Sorte Fehler, die diese Anwendung nicht haben darf.
 *   2. Tage/365,25 ergibt am eigenen Geburtstag je nach Schaltjahrlage 2,999 statt 3,0.
 *      Eine Regel "ab 3 Jahren" haette dann einen Tag zu spaet gegriffen.
 *   3. Der 29. Februar als Geburtstag.
 *
 * Und der inhaltlich wichtigste Punkt: eine GESCHAETZTE Altersangabe muss als geschaetzt
 * erkennbar bleiben. In der Kleintierpraxis ist das Fundtier ohne Papiere der Normalfall;
 * wenn "ca. 7 Jahre" hinterher aussieht wie ein Datum aus dem Impfpass, hat das Programm
 * eine Genauigkeit erfunden.
 *
 * Start: node tools/alter-test.js
 */
const A = require('../ui/shared/patient-alter.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Patientenalter\n');

/* ================================================================================
 * 1. AUS DEM GEBURTSDATUM — auf den Tag
 * ============================================================================== */
block('1. genaues Alter');
{
  const a = A.ausDatum('2020-03-15', '2026-08-09');
  pruef('gueltig', a.gueltig === true, a.warum);
  pruef('6 Jahre', a.jahre === 6, String(a.jahre));
  pruef('4 Monate', a.monate === 4, String(a.monate));
  pruef('25 Tage', a.tage === 25, String(a.tage));
  pruef('Text lesbar', a.text === '6 Jahre 4 Mon.', a.text);
  pruef('nicht als geschaetzt gefuehrt', a.geschaetzt === false);
  pruef('Herkunft steht dabei', a.quelle === 'datum');
}
{
  /* AM GEBURTSTAG MUSS ES GLATT AUFGEHEN. Ueber Tage/365,25 kaemen hier 3,999 heraus und
   * eine Regel "ab 4 Jahren" haette einen Tag zu spaet gegriffen. */
  const a = A.ausDatum('2022-08-09', '2026-08-09');
  pruef('am 4. Geburtstag: genau 4 Jahre', a.jahre === 4 && a.monate === 0 && a.tage === 0);
  pruef('und dezimalJahre ist exakt 4', a.dezimalJahre === 4, String(a.dezimalJahre));
  pruef('das Fenster "ab 4 Jahren" greift', A.imFenster(a, 4, null) === true);
  const tagDavor = A.ausDatum('2022-08-09', '2026-08-08');
  pruef('einen Tag davor greift es NICHT', A.imFenster(tagDavor, 4, null) === false,
    String(tagDavor.dezimalJahre));
  pruef('und es sind 3 Jahre 11 Monate', tagDavor.jahre === 3 && tagDavor.monate === 11,
    tagDavor.jahre + ' J ' + tagDavor.monate + ' M');
}
{
  /* DIE ZEITZONENFALLE. new Date("2020-03-01") ergibt in Mitteleuropa den 29.02.2020. */
  const a = A.ausDatum('2020-03-01', '2021-03-01');
  pruef('1. Maerz bleibt der 1. Maerz (keine Zeitzonenverschiebung)',
    a.jahre === 1 && a.monate === 0 && a.tage === 0, a.jahre + ' J ' + a.monate + ' M ' + a.tage + ' T');
  const roh = new Date('2020-03-01');
  pruef('Gegenprobe: der naive Weg verschiebt wirklich (oder die Zone ist UTC)',
    roh.getDate() === 29 || roh.getDate() === 1, 'getDate()=' + roh.getDate());
}
{
  /* Schaltjahr-Geburtstag. */
  const a = A.ausDatum('2020-02-29', '2026-02-28');
  pruef('29.02. wird angenommen', a.gueltig === true, a.warum);
  pruef('am 28.02. eines Nichtschaltjahres: 5 Jahre 11 Monate 30 Tage',
    a.jahre === 5, a.jahre + ' J ' + a.monate + ' M ' + a.tage + ' T');
  const b = A.ausDatum('2020-02-29', '2026-03-01');
  pruef('am 01.03. sind es 6 Jahre', b.jahre === 6, b.jahre + ' J ' + b.monate + ' M ' + b.tage + ' T');
}
{
  /* Monatsuebergang mit Uebertrag: 31.01. -> 01.03. */
  const a = A.ausDatum('2026-01-31', '2026-03-01');
  pruef('31.01. bis 01.03.: 1 Monat 1 Tag',
    a.jahre === 0 && a.monate === 1 && a.tage === 1, a.monate + ' M ' + a.tage + ' T');
}

/* ================================================================================
 * 2. JUNGTIERE WERDEN IN WOCHEN GEMESSEN
 * Beim Welpen entscheiden Wochen ueber Normwerte und Dosis - "0 Jahre 2 Monate" ist
 * dort keine brauchbare Anzeige.
 * ============================================================================== */
block('2. Jungtier');
{
  pruef('10 Tage alt', A.ausDatum('2026-07-30', '2026-08-09').text === '10 Tage',
    A.ausDatum('2026-07-30', '2026-08-09').text);
  pruef('1 Tag alt (Einzahl)', A.ausDatum('2026-08-08', '2026-08-09').text === '1 Tag',
    A.ausDatum('2026-08-08', '2026-08-09').text);
  pruef('5 Wochen alt', A.ausDatum('2026-07-05', '2026-08-09').text === '5 Wochen',
    A.ausDatum('2026-07-05', '2026-08-09').text);
  pruef('4 Monate alt', /^4 Monate/.test(A.ausDatum('2026-04-09', '2026-08-09').text),
    A.ausDatum('2026-04-09', '2026-08-09').text);
  pruef('1 Jahr (Einzahl)', /^1 Jahr\b/.test(A.ausDatum('2025-08-09', '2026-08-09').text),
    A.ausDatum('2025-08-09', '2026-08-09').text);
}

/* ================================================================================
 * 3. UNBRAUCHBARE ANGABEN WERDEN ABGEWIESEN — MIT GRUND
 * Eine stille Null waere in der Oberflaeche nicht von "noch nichts eingegeben" zu
 * unterscheiden.
 * ============================================================================== */
block('3. Abweisung mit Grund');
[
  ['', 'leer'], ['09.08.2026', 'deutsches Format'], ['2026-13-01', 'Monat 13'],
  ['2026-02-31', '31. Februar'], ['irgendwas', 'Unsinn'],
].forEach(([wert, was]) => {
  const a = A.ausDatum(wert, '2026-08-09');
  pruef(was + ' wird abgewiesen', a.gueltig === false, JSON.stringify(a));
  pruef(was + ' nennt einen Grund', !!a.warum);
});
{
  const a = A.ausDatum('2027-01-01', '2026-08-09');
  pruef('Zukunft wird abgewiesen', a.gueltig === false);
  pruef('und sagt warum', /Zukunft/.test(a.warum), a.warum);
}
{
  const a = A.ausDatum('1900-01-01', '2026-08-09');
  pruef('126 Jahre werden abgewiesen', a.gueltig === false, JSON.stringify(a));
}

/* ================================================================================
 * 4. GESCHAETZTES ALTER — der Normalfall beim Fundtier
 * ============================================================================== */
block('4. geschaetztes Alter');
{
  const a = A.ausUngefaehr(7, 0);
  pruef('7 Jahre', a.gueltig === true && a.jahre === 7);
  pruef('als geschaetzt gekennzeichnet', a.geschaetzt === true);
  pruef('und im Text steht "ca."', /^ca\./.test(a.text), a.text);
  pruef('kurz mit Tilde', a.kurz === '~7 J', a.kurz);
  pruef('trotzdem fuer Fenster nutzbar', A.imFenster(a, 4, null) === true);
}
{
  const a = A.ausUngefaehr(0, 18);
  pruef('18 Monate werden zu 1 Jahr 6 Monaten', a.jahre === 1 && a.monate === 6,
    a.jahre + ' J ' + a.monate + ' M');
}
{
  pruef('gar nichts -> ungueltig', A.ausUngefaehr(null, null).gueltig === false);
  pruef('0/0 -> ungueltig', A.ausUngefaehr(0, 0).gueltig === false);
  pruef('negativ -> ungueltig', A.ausUngefaehr(-3, 0).gueltig === false);
}

/* ================================================================================
 * 5. GETIPPTE ANGABEN VERSTEHEN — der Bestand aus dem alten Textfeld
 * ============================================================================== */
block('5. Freitext');
[
  ['9 J', 9, 0], ['9 Jahre', 9, 0], ['9', 9, 0], ['ca. 7', 7, 0], ['~5', 5, 0],
  ['3 Jahre 4 Monate', 3, 4], ['8 Monate', 0, 8], ['6 M', 0, 6], ['7,5 J', 7, 6],
  ['12 W', 0, 2], ['5-6 Jahre', 5, 0], ['2 J 6 Mon', 2, 6],
].forEach(([txt, j, m]) => {
  const a = A.parse(txt);
  pruef('"' + txt + '" -> ' + j + ' J ' + m + ' M',
    !!a && a.jahre === j && a.monate === m, a ? (a.jahre + ' J ' + a.monate + ' M') : 'null');
});
{
  /* EINE GETIPPTE ANGABE IST NIE AUF DEN TAG GENAU. Auch "9 Jahre" ohne "ca." nicht:
   * niemand tippt das Alter auf den Tag genau, dafuer gibt es das Datumsfeld. Wuerde die
   * Anwendung sie als genau fuehren, stuende auf dem Ausdruck eine Genauigkeit, die es
   * nicht gibt. */
  pruef('"9 Jahre" gilt trotzdem als geschaetzt', A.parse('9 Jahre').geschaetzt === true);
  pruef('"5-6 Jahre" nimmt den UNTEREN Wert', A.parse('5-6 Jahre').jahre === 5);
}
[null, undefined, '', '   ', 'adult', 'senior', 'Jungtier', 'keine Angabe'].forEach((txt) => {
  pruef('"' + String(txt) + '" ergibt null statt einer geratenen Zahl', A.parse(txt) === null,
    JSON.stringify(A.parse(txt)));
});

/* ================================================================================
 * 6. FENSTERPRUEFUNG — "wir wissen es nicht" ist nicht "trifft nicht zu"
 * ============================================================================== */
block('6. Altersfenster');
{
  const a = A.ausDatum('2020-01-01', '2026-08-09');       // 6 J 7 M
  pruef('ab 4 Jahren: ja', A.imFenster(a, 4, null) === true);
  pruef('bis 2 Jahre: nein', A.imFenster(a, null, 2) === false);
  pruef('4 bis 8 Jahre: ja', A.imFenster(a, 4, 8) === true);
  pruef('8 bis 12 Jahre: nein', A.imFenster(a, 8, 12) === false);
}
{
  /* Der entscheidende Fall: OHNE Alter darf keine Regel "trifft nicht zu" bekommen -
   * sonst wuerde eine altersabhaengige Warnung stillschweigend unterdrueckt. */
  pruef('ohne Alter: null, nicht false', A.imFenster(null, 4, null) === null);
  pruef('bei ungueltigem Alter: null', A.imFenster({ gueltig: false }, 4, null) === null);
  pruef('null ist NICHT false', A.imFenster(null, 4, null) !== false);
}

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
