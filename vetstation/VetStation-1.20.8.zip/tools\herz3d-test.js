/*
 * herz3d-test.js — rechnet die Behauptungen des Herzmodells nach.
 *
 * WARUM ES DIESEN TEST GIBT (13.08.2026):
 * Das Herzmodell macht zwei Sorten von Aussagen, und beide fallen im Browser NICHT auf,
 * wenn sie falsch sind:
 *
 *   1. ZEITEN. Laeuft die Erregung im Bild gegen die gezeichnete Kurve versetzt, sieht
 *      jede Haelfte fuer sich richtig aus. Genau dieser Fehler ist in diesem Projekt schon
 *      zweimal vorgekommen (Massstab des Diagnostik-EKG 1.12.0, P-Messung nach ihrem
 *      Verbraucher 1.12.0). Er wird nur durch Nachrechnen gefunden, nicht durch Hinsehen.
 *   2. ZUORDNUNGEN. Faellt ein Befund aus der Ort-Tabelle heraus, zeigt die Oberflaeche
 *      still gar nichts an - der Tierarzt sieht einen Hinweis ohne Ort und haelt das fuer
 *      normal. Deshalb dreht Block 6 die Beweislast um: JEDE Regel aus BEFUNDREGELN muss
 *      einen Eintrag haben, sonst wird der Test rot.
 *
 * Ausserdem gilt hier, was fuer das 3D-Tiermodell schon galt: Bild und Messung widerlegen
 * einander gegenseitig. Dieser Test misst. Das Bild muss man zusaetzlich ansehen.
 *
 * Start: dist/VetStation/node/node.exe tools/herz3d-test.js
 */
'use strict';
var fs = require('fs');
var pfad = require('path');
var WURZEL = pfad.join(__dirname, '..');

var H = require(pfad.join(WURZEL, 'ui/shared/herz3d.js'));
var M = require(pfad.join(WURZEL, 'ui/shared/ekg-modell.js'));

var fehler = 0, geprueft = 0;
function pruef(name, bedingung, zusatz) {
  geprueft++;
  if (bedingung) { console.log('  ok   ' + name); return; }
  fehler++;
  console.log('  FEHL ' + name + (zusatz ? '   -> ' + zusatz : ''));
}
function nah(a, b, tol) { return Math.abs(a - b) <= tol; }

var ARTEN = ['hund', 'katze'];
var SINUS = { p: 1, pq: 1, qrs: 1 };

/* ============================================================================
 * 1 — Geometrie: was das Lehrbuch ueber die Verhaeltnisse sagt, muss dastehen
 * ========================================================================= */
console.log('\n1  Geometrie und Verhaeltnisse (Killich, Kleintierkardiologie 2019, S. 26/30/32)');
ARTEN.forEach(function (art) {
  var B = H.bauFuer(art), m = H.netz(art);

  pruef(art + ': LV-Wand ist 2- bis 3-mal so dick wie die RV-Wand',
    B.wandLV / B.wandRV >= 2 && B.wandLV / B.wandRV <= 3,
    'Verhaeltnis ' + (B.wandLV / B.wandRV).toFixed(2));
  pruef(art + ': RV-Wand hoechstens 50 % der LV-Wand',
    B.wandRV <= B.wandLV * 0.5, 'RV ' + B.wandRV + ' vs LV ' + B.wandLV);
  pruef(art + ': Septum und LV-Wand verhalten sich 1:1 (beide im Hochdrucksystem)',
    nah(B.wandSeptum, B.wandLV, 1e-9));

  /* Die linke Kammer bildet die Herzspitze ALLEIN, die rechte erreicht sie nicht.
   *
   * GEPRUEFT WIRD DAS OHNE FESTE ZAHL (Befund 13.08.2026): hier stand zuerst "LV reicht
   * tiefer als -0,9". Beim Verbreitern des Herzens wurde die Kammer kuerzer, die Zahl passte
   * nicht mehr - und der Test wurde rot, obwohl die anatomische Aussage weiter stimmte.
   * Eine Pruefung, die bei jeder Massaenderung nachgezogen werden muss, prueft das Falsche.
   * Die Aussage lautet: KEINE andere Zone reicht so weit spitzenwaerts wie die linke Kammer. */
  var tiefste = {};
  m.faces.forEach(function (f) {
    var y = 0, i;
    for (i = 0; i < f.length; i++) y += m.pts[f[i]][1];
    y /= f.length;
    if (tiefste[f.zone] == null || y < tiefste[f.zone]) tiefste[f.zone] = y;
  });
  var tiefLV = tiefste.lv, tiefRV = tiefste.rv;
  pruef(art + ': die rechte Kammer erreicht die Herzspitze NICHT',
    tiefRV > tiefLV + 0.25, 'RV bis y=' + tiefRV.toFixed(2) + ', LV bis y=' + tiefLV.toFixed(2));
  var tieferAlsLV = [];
  for (var zk in tiefste) if (Object.prototype.hasOwnProperty.call(tiefste, zk)) {
    if (zk !== 'lv' && tiefste[zk] < tiefLV + 1e-9) tieferAlsLV.push(zk + '@' + tiefste[zk].toFixed(2));
  }
  pruef(art + ': die linke Kammer bildet die Herzspitze ALLEIN', tieferAlsLV.length === 0,
    tieferAlsLV.join(', '));

  /* Seitentreue: alles Rechte hat z<0, alles Linke z>0 - dieselbe Pruefung wie in tier3d. */
  function pkt(id) { var p = m.punkte, i; for (i = 0; i < p.length; i++) if (p[i].id === id) return p[i].p; return null; }
  pruef(art + ': Sinusknoten liegt RECHTS (z<0) und basisnah (y>0,6)',
    pkt('sinus')[2] < 0 && pkt('sinus')[1] > 0.6);
  pruef(art + ': AV-Knoten liegt auf der RECHTEN Septumseite (z<0)', pkt('avk')[2] < 0);
  pruef(art + ': das His-Buendel liegt UNTER dem AV-Knoten (kleineres y)',
    pkt('his')[1] < pkt('avk')[1]);
  /*
   * DIE SCHENKEL — und warum die erste Pruefung hier falsch war (13.08.2026).
   *
   * Zuerst stand hier "rechter Schenkel z<0, linker Schenkel z>0". Das ist rot geworden, und
   * der Test hatte unrecht: die Scheidewand liegt NICHT in der Mittelebene des Herzens. Die
   * linke Kammer ist die groessere, die rechte liegt ihr halbmondfoermig auf - also woelbt
   * sich die Scheidewand nach rechts, und BEIDE Schenkel haben ein negatives z. Ein absolutes
   * Vorzeichen ist hier schlicht die falsche Frage.
   *
   * Richtig gefragt ist: liegt der rechte Schenkel auf der Seite der RECHTEN Kammer und der
   * linke auf der Seite der LINKEN? Das heisst hier: weiter aussen bzw. weiter innen, gemessen
   * vom Mittelpunkt der linken Kammer.
   */
  var mLV = [0, H.LV_CZ];
  function abstandLV(p) { return Math.sqrt(p[0] * p[0] + (p[2] - mLV[1]) * (p[2] - mLV[1])); }
  var rSchenkel = abstandLV(pkt('crusD')), lSchenkel = abstandLV(pkt('crusS'));
  pruef(art + ': der rechte Schenkel liegt auf der Seite der RECHTEN Kammer (weiter aussen)',
    rSchenkel > lSchenkel, 'rechts ' + rSchenkel.toFixed(3) + ', links ' + lSchenkel.toFixed(3));
  /* Und beide muessen AUF der Wand liegen, nicht im Hohlraum: ihr Abstand zur Kammermitte
   * ist der Wandradius in ihrer Hoehe, um die Querverschiebung versetzt. Genau das war der
   * Fehler der ersten Fassung - die Punkte hingen frei im Lumen. */
  function wandRadiusBei(y) { return H.lvRadius(H.lvAnteil(y), B); }
  pruef(art + ': der rechte Schenkel liegt AUF der Wand (Wandradius + 0,045)',
    nah(rSchenkel, wandRadiusBei(pkt('crusD')[1]) + 0.045, 0.005),
    rSchenkel.toFixed(3) + ' vs ' + (wandRadiusBei(pkt('crusD')[1]) + 0.045).toFixed(3));
  pruef(art + ': der linke Schenkel liegt AUF der Wand (Wandradius - 0,045)',
    nah(lSchenkel, wandRadiusBei(pkt('crusS')[1]) - 0.045, 0.005));
  pruef(art + ': das His-Buendel liegt auf der RECHTEN Wandseite',
    nah(abstandLV(pkt('his')), wandRadiusBei(pkt('his')[1]) + 0.035, 0.005));
  /* Und der Weg muss von oben nach unten fuehren: His -> Schenkel -> Purkinje. */
  pruef(art + ': His liegt ueber den Schenkeln, die Purkinje-Fasern darunter',
    pkt('his')[1] > pkt('crusD')[1] && pkt('crusD')[1] > pkt('purkinje')[1]);

  /* Keine entarteten Flaechen: eine Flaeche mit doppeltem Eckpunkt hat keine Normale und
   * damit keine Seite - sie wird beim Zeichnen zufaellig sichtbar oder nicht. */
  var entartet = 0;
  m.faces.forEach(function (f) {
    var s = {}, i, doppelt = false;
    for (i = 0; i < f.length; i++) { if (s[f[i]]) doppelt = true; s[f[i]] = 1; }
    if (doppelt) entartet++;
  });
  pruef(art + ': keine entarteten Flaechen (doppelte Eckpunkte)', entartet === 0, entartet + ' gefunden');

  /* Jede Flaeche muss ihre Zone, ihre Tiefe und ihre Basisnaehe tragen - sonst kann
   * flaechenzustand() sie nicht einordnen und sie bliebe stumm dunkel. */
  var ohne = 0;
  m.faces.forEach(function (f) {
    if (!f.zone || f.tiefe == null || f.basisnah == null) ohne++;
    if (f.tiefe < 0 || f.tiefe > 1 || f.basisnah < 0 || f.basisnah > 1) ohne++;
  });
  pruef(art + ': jede Flaeche traegt Zone, Tiefe (0..1) und Basisnaehe (0..1)', ohne === 0, ohne + ' ohne');
});
pruef('Massenverhaeltnis LV:RV ist beim Hund 3:1 und bei der Katze 3,5:1',
  nah(H.bauFuer('hund').masseLV / H.bauFuer('hund').masseRV, 3.0, 1e-9) &&
  nah(H.bauFuer('katze').masseLV / H.bauFuer('katze').masseRV, 3.5, 1e-9));

/* ============================================================================
 * 2 — Der Zeitplan MUSS aus ekg-modell.js folgen. Das ist der Kern.
 * ========================================================================= */
console.log('\n2  Zeitplan gegen ekg-modell.js (hier entscheidet sich, ob Bild und Kurve zusammenlaufen)');
['hund', 'katze', 'pferd'].forEach(function (art) {
  var V = M.ekgVorgabe(art), Z = H.zeitplan(art), A = M.QRS_ANTEIL;
  pruef(art + ': P endet bei pMs', nah(Z.pEnde, V.pMs, 1e-9));
  pruef(art + ': QRS beginnt bei pqMs (das IST die PQ-Zeit)', nah(Z.qrsVon, V.pqMs, 1e-9));
  pruef(art + ': QRS endet bei pqMs + qrsMs', nah(Z.qrsBis, V.pqMs + V.qrsMs, 1e-9));
  pruef(art + ': ST endet bei pqMs + qrsMs + stMs', nah(Z.stBis, V.pqMs + V.qrsMs + V.stMs, 1e-9));
  pruef(art + ': T endet bei der QT-Zeit nach QRS-Beginn',
    nah(Z.tBis, V.pqMs + M.qtMs(art), 1e-9), 'tBis ' + Z.tBis + ' vs ' + (V.pqMs + M.qtMs(art)));
  /* Die drei Fenster des Kammerkomplexes muessen GENAU die aus QRS_ANTEIL sein. */
  pruef(art + ': Q-Fenster = QRS_ANTEIL.q', nah(Z.qBis - Z.qVon, V.qrsMs * A.q, 1e-9));
  pruef(art + ': R-Fenster = QRS_ANTEIL.r', nah(Z.rBis - Z.rVon, V.qrsMs * A.r, 1e-9));
  pruef(art + ': S-Fenster = QRS_ANTEIL.s', nah(Z.sBis - Z.sVon, V.qrsMs * A.s, 1e-9));
  pruef(art + ': Q, R und S schliessen luecken- und ueberlappungsfrei aneinander an',
    nah(Z.qBis, Z.rVon, 1e-9) && nah(Z.rBis, Z.sVon, 1e-9) && nah(Z.sBis, Z.qrsBis, 1e-9));
  /* Die Vorhofrepolarisation liegt im QRS und ist deshalb nicht zu sehen. */
  pruef(art + ': die Vorhofrepolarisation liegt im QRS (dort verborgen)',
    Z.taVon >= Z.qrsVon - 1e-9 && Z.taBis <= Z.qrsBis + 1e-9);
});

/* Die eigentliche Naht: der P-Beginn des Modells und der P-Beginn der KURVE. */
console.log('\n2b Naht zur gezeichneten Kurve (pBeginnSek gegen ekgMv)');
['hund', 'katze', 'pferd'].forEach(function (art) {
  var dt = 0.00005, erst = null, t;
  for (t = 0; t < 1.2; t += dt) { if (Math.abs(M.ekgMv(t, 0.8, SINUS, 0, art)) > 1e-9) { erst = t; break; } }
  pruef(art + ': pBeginnSek trifft den Punkt, an dem ekgMv die Nulllinie verlaesst',
    erst != null && nah(erst, M.pBeginnSek(art), 0.0002),
    'gemessen ' + (erst != null ? erst.toFixed(5) : '-') + ' s, angesagt ' + M.pBeginnSek(art).toFixed(5) + ' s');

  /* Und die Gegenprobe fuer den WICHTIGSTEN Augenblick: wenn das Modell die Kammer starten
   * laesst, muss die Kurve gerade den QRS beginnen. */
  var Z = H.zeitplan(art);
  var tQrs = M.pBeginnSek(art) + Z.qrsVon / 1000;
  var vor = Math.abs(M.ekgMv(tQrs - 0.004, 0.8, SINUS, 0, art));
  var nach = Math.abs(M.ekgMv(tQrs + 0.004, 0.8, SINUS, 0, art));
  pruef(art + ': am QRS-Beginn des Modells steigt auch die Kurve an', nach > vor,
    'vor ' + vor.toFixed(4) + ' mV, nach ' + nach.toFixed(4) + ' mV');
});

/* ============================================================================
 * 3 — Reihenfolge der Erregung. Was das Lehrbuch als Abfolge nennt, muss so laufen.
 * ========================================================================= */
console.log('\n3  Reihenfolge der Erregung');
(function () {
  var art = 'hund', Z = H.zeitplan(art), p0 = M.pBeginnSek(art);
  function bei(msSeitP, W, beat) { return H.zustand(p0 + msSeitP / 1000, 0.8, W || SINUS, beat || 0, art); }
  function ersterMoment(id, W, beat) {
    var ms;
    for (ms = 0; ms <= Z.zyklusEnde; ms += 0.5) { if (bei(ms, W, beat).erregt[id] > 0.02) return ms; }
    return null;
  }
  var tSinus = ersterMoment('sinus'), tRa = ersterMoment('ra'), tLa = ersterMoment('la');
  var tAv = ersterMoment('avk'), tHis = ersterMoment('his'), tCrus = ersterMoment('crusD');
  var tPap = ersterMoment('papD'), tSep = ersterMoment('septum'), tLv = ersterMoment('lv');

  pruef('Sinusknoten -> rechter Vorhof -> linker Vorhof',
    tSinus <= tRa && tRa < tLa, [tSinus, tRa, tLa].join(' / '));
  pruef('linker Vorhof vor AV-Knoten', tLa < tAv, tLa + ' / ' + tAv);
  pruef('AV-Knoten vor His-Buendel', tAv < tHis, tAv + ' / ' + tHis);
  pruef('His-Buendel vor den Tawara-Schenkeln', tHis < tCrus, tHis + ' / ' + tCrus);
  /* Killich S. 49: "Die Papillarmuskeln werden ... als ERSTE erreicht und kontrahieren
   * deshalb auch VOR der uebrigen Kammermuskulatur." */
  pruef('Papillarmuskeln VOR der uebrigen Kammerwand', tPap < tLv, tPap + ' / ' + tLv);
  pruef('Septum vor der freien Kammerwand (Q vor R)', tSep < tLv, tSep + ' / ' + tLv);

  /* Der AV-Knoten HAELT die Erregung: zwischen P-Ende und QRS-Beginn liegt eine Strecke,
   * in der etwas laeuft und die Kurve trotzdem flach ist. */
  var mitte = (Z.pEnde + Z.qrsVon) / 2;
  var zm = bei(mitte);
  pruef('waehrend der PQ-Strecke leitet der AV-Knoten', zm.leitet.avk === true || zm.erregt.avk > 0.1);
  pruef('waehrend der PQ-Strecke ist die Kammer noch unerregt', zm.erregt.lv < 0.02 && zm.erregt.septum < 0.02);
  pruef('waehrend der PQ-Strecke ist die Kurve flach',
    Math.abs(M.ekgMv(p0 + mitte / 1000, 0.8, SINUS, 0, art)) < 0.02,
    Math.abs(M.ekgMv(p0 + mitte / 1000, 0.8, SINUS, 0, art)).toFixed(4) + ' mV');

  /* In der ST-Strecke ist alles erregt und nichts repolarisiert - Vektor null. */
  var zst = bei((Z.stVon + Z.stBis) / 2);
  pruef('in der ST-Strecke ist die Kammer vollstaendig erregt',
    zst.erregt.lv > 0.98 && zst.repol.lv < 0.02);
  pruef('richtung() nennt die ST-Strecke ausdruecklich vektorfrei', H.richtung(zst).achse === 'keine');

  /* Rechte Kammerwand ist duenner - ihre Front ist frueher durch. */
  var zr = bei(Z.rBis);
  pruef('die duennere rechte Kammerwand ist frueher durcherregt als die linke',
    zr.erregt.rv > zr.erregt.lv, 'rv ' + zr.erregt.rv.toFixed(2) + ' lv ' + zr.erregt.lv.toFixed(2));
})();

/* ============================================================================
 * 4 — Richtungen INNERHALB der Kammerwand: innen->aussen und die T-Wellen-Konkordanz
 * ========================================================================= */
console.log('\n4  Innen nach aussen - und warum die T-Welle dasselbe Vorzeichen hat wie R');
(function () {
  var art = 'hund', m = H.netz(art), Z = H.zeitplan(art), p0 = M.pBeginnSek(art);
  /* Zwei Flaechen derselben Kammer: eine innen und apikal, eine aussen und basisnah. */
  var innen = { zone: 'lv', tiefe: 0, basisnah: 0 };
  var aussen = { zone: 'lv', tiefe: 1, basisnah: 1 };
  pruef('kammerU: innen+apikal ergibt 0, aussen+basisnah ergibt 1',
    nah(H.kammerU(innen), 0, 1e-9) && nah(H.kammerU(aussen), 1, 1e-9));

  function zust(ms) { return H.zustand(p0 + ms / 1000, 0.8, SINUS, 0, art); }
  /* Mitten in der R-Zacke muss die Innenschicht schon erregt und die Aussenschicht noch
   * nicht fertig sein - das IST "von den Innenschichten zu den Aussenschichten". */
  var zR = zust((Z.rVon + Z.rBis) / 2);
  var eIn = H.flaechenzustand(innen, zR).erregt, eAus = H.flaechenzustand(aussen, zR).erregt;
  pruef('waehrend der R-Zacke ist die Innenschicht weiter erregt als die Aussenschicht',
    eIn > eAus, 'innen ' + eIn.toFixed(2) + ', aussen ' + eAus.toFixed(2));

  /* Und die Umkehrung in der T-Welle: die zuletzt erregte Aussenschicht repolarisiert ZUERST.
   * Genau daraus folgt, dass T dasselbe Vorzeichen hat wie R. Das ist der eine Befund, den
   * dieses Modell erklaeren koennen muss - sonst ist es nur ein huebsches Bild. */
  var zT = zust((Z.tVon + Z.tBis) / 2);
  var rIn = H.flaechenzustand(innen, zT).repol, rAus = H.flaechenzustand(aussen, zT).repol;
  pruef('waehrend der T-Welle ist die Aussenschicht weiter repolarisiert als die Innenschicht',
    rAus > rIn, 'aussen ' + rAus.toFixed(2) + ', innen ' + rIn.toFixed(2));
  pruef('Erregung und Rueckbildung laufen damit GEGENLAEUFIG durch die Wand',
    (eIn > eAus) && (rAus > rIn));

  /* Am Zyklusende muss alles wieder ruhen - sonst waere der naechste Schlag auf einem
   * halb erregten Herz gezeichnet. */
  var zEnd = zust(Z.zyklusEnde + 5);
  pruef('am Zyklusende ist die Kammer wieder in Ruhe',
    H.aktiv(H.flaechenzustand(innen, zEnd)) < 0.02 && H.aktiv(H.flaechenzustand(aussen, zEnd)) < 0.02);
  pruef('aktiv() ist 0 bei ruhend und 1 bei voll erregt',
    nah(H.aktiv({ erregt: 0, repol: 0 }), 0, 1e-9) &&
    nah(H.aktiv({ erregt: 1, repol: 0 }), 1, 1e-9) &&
    nah(H.aktiv({ erregt: 1, repol: 1 }), 0, 1e-9));

  /* Die Ansicht muss ueberhaupt etwas hergeben. */
  var voll = H.ansicht(m, { breite: 500, hoehe: 400, gier: 25, nick: 10, zustand: zR });
  pruef('die Ansicht liefert Flaechen, Leitungspunkte und Klappen',
    voll.flaechen.length > 200 && voll.punkte.length === m.punkte.length && voll.klappen.length === 4);
  pruef('die Ansicht reicht die Richtungsaussage durch', !!voll.richtung && !!voll.richtung.text);

  /*
   * DER SCHNITT — und warum die naheliegende Pruefung hier falsch war (gemessen 13.08.2026).
   *
   * Zuerst stand hier "der Schnitt zeigt WENIGER Flaechen". Das ist rot geworden, und der
   * Test hatte unrecht, nicht der Code: die Schnittansicht laesst die Rueckseitenpruefung
   * absichtlich weg, weil man sonst in eine geoeffnete Kammer hineinsaehe und nichts saehe -
   * die Innenwand der Gegenseite zeigt von der Kamera weg. Sie zeigt also die kraniale
   * Haelfte NICHT MEHR und dafuer Rueckseiten, die vorher weggefallen waren. Die Zahl kann
   * dabei in beide Richtungen gehen.
   *
   * Geprueft gehoert stattdessen, was der Schnitt LEISTEN soll:
   *   (a) die kraniale Haelfte ist wirklich weg,
   *   (b) man sieht mehr Innenflaeche als vorher - sonst hat er seinen Zweck verfehlt.
   */
  var vollGerade = H.ansicht(m, { breite: 500, hoehe: 400, gier: 0, nick: 0, zustand: zR });
  var schnittGerade = H.ansicht(m, { breite: 500, hoehe: 400, gier: 0, nick: 0, zustand: zR, schnitt: true });
  /* Bei gier=0/nick=0 ist die Drehung die Einheit: groesseres Modell-x heisst groesseres
   * Bild-x. Alles Kraniale muss also rechts der Bildmitte liegen - und dort darf nichts sein. */
  var mitteX = 250, kranial = 0;
  schnittGerade.flaechen.forEach(function (f) {
    var mx = 0, i;
    for (i = 0; i < f.eck.length; i++) mx += f.eck[i].x;
    if (mx / f.eck.length > mitteX + 6) kranial++;
  });
  pruef('die Schnittansicht enthaelt keine Flaeche aus der kranialen Haelfte', kranial === 0,
    kranial + ' Flaechen jenseits der Schnittebene');

  /* ANGESEHEN WIRD DER SCHNITT AUS DER RICHTUNG, IN DIE SEINE FLAECHE ZEIGT.
   * Das war der zweite Irrtum dieses Blocks: geprueft wurde bei gier=0, also von der linken
   * Seite - da liegt die Schnittflaeche seitlich und man sieht weiter auf die linke Aussenwand.
   * herz3d.SCHNITT_GIER nennt die Richtung, aus der die Oberflaeche den Schnitt zeigt; genau
   * die gehoert geprueft, sonst prueft der Test ein Bild, das niemand zu sehen bekommt. */
  var schnitt = H.ansicht(m, { breite: 500, hoehe: 400, gier: H.SCHNITT_GIER, nick: 0, zustand: zR, schnitt: true });
  var vollSchnittBlick = H.ansicht(m, { breite: 500, hoehe: 400, gier: H.SCHNITT_GIER, nick: 0, zustand: zR });
  /*
   * ZWEITER ANLAUF, UND WIEDER HATTE DER TEST UNRECHT: "mehr Innenflaechen" zaehlte auch die
   * Innenwaende der Gegenseite, die in der geschlossenen Ansicht zwar in der Liste stehen,
   * aber von den Aussenwaenden ueberdeckt werden (Malerverfahren, nach Tiefe sortiert).
   * Gemessen: geschlossen 415, im Schnitt 364 - eine Zahl, die ueber Sichtbarkeit nichts sagt.
   *
   * Sichtbar ist, was ZULETZT gezeichnet wird. Geprueft wird deshalb das vordere Viertel der
   * Tiefensortierung: dort muss im Schnitt das Septum auftauchen und in der geschlossenen
   * Ansicht darf es das nicht.
   */
  function vorderste(a) {
    var ab = Math.floor(a.flaechen.length * 0.75), z = {}, i;
    for (i = ab; i < a.flaechen.length; i++) z[a.flaechen[i].zone] = (z[a.flaechen[i].zone] || 0) + 1;
    return z;
  }
  var vsSchnitt = vorderste(schnitt);
  pruef('im Schnitt liegt das Septum vorn - man sieht in das Herz hinein',
    (vsSchnitt.septum || 0) > 0, JSON.stringify(vsSchnitt));
  pruef('im Schnitt sind beide Kammern angeschnitten - die Vierkammeransicht',
    (vsSchnitt.lv || 0) + (vsSchnitt.septum || 0) > 0 && (vsSchnitt.rv || 0) > 0,
    JSON.stringify(vsSchnitt));

  /*
   * DASS DAS SEPTUM VON AUSSEN NICHT ZU SEHEN IST, wurde hier zuerst ueber den Tiefenrang
   * geprueft ("liegt es im vorderen Viertel?") - und war zweimal rot, obwohl der Code stimmte.
   * Der Tiefenrang sagt eben nicht, ob eine Flaeche SICHTBAR ist: sie kann weit vorn liegen
   * und trotzdem hinter einer naeheren stecken. Eine echte Verdeckungspruefung waere moeglich
   * (tier3d.js macht sie fuer seine Marken), aber sie beantwortet die falsche Frage.
   *
   * Die anatomische Aussage lautet: die Scheidewand ist die Wand ZWISCHEN den Kammern, die
   * rechte Kammer liegt ihr auf. Wenn das gilt, kann sie gar nicht aussen liegen. Genau das
   * wird hier geprueft - und diese Pruefung haelt auch dann, wenn jemand spaeter die Kamera,
   * die Sortierung oder die Beleuchtung anfasst.
   *
   * ZWEITER BEFUND AN DERSELBEN STELLE (14.08.2026): die Pruefung stand hier zwar richtig
   * begruendet, aber sie MASS DEN MITTELPUNKT der Flaeche - und genau nach dem Mittelpunkt
   * hatte netz() die Flaeche vorher als Septum gekennzeichnet. Damit fragte der Test den Code
   * nach dessen eigenem Kriterium und konnte gar nicht rot werden: 176 von 176 Flaechen
   * "bedeckt", waehrend am gerenderten Bild ein oranger Streifen aussen am Herzen stand.
   *
   * Eine Flaeche ist aber kein Punkt. Bei 24 Segmenten ist sie 0,262 rad breit; liegt ihre
   * Mitte 0,002 rad innerhalb der Fensterkante, ragt sie 0,129 rad DARUEBER HINAUS - dorthin,
   * wo keine rechte Kammer mehr liegt. Gemessen waren 20 solcher Flaechen.
   * Deshalb wird jetzt die GANZE Flaeche geprueft: ihr aeusserster Winkel nach beiden Seiten
   * und ihr tiefster Punkt, gegen das ENGSTE Fenster, das sie ueberstreicht. Was ein Punkt
   * nicht verraten kann, verraet die Ausdehnung.
   */
  var frei = 0, geprueftSept = 0, weitesteFrei = 0;
  var B2 = H.bauFuer('hund');
  m.faces.forEach(function (f) {
    if (f.zone !== 'septum') return;
    geprueftSept++;
    var wMin = 1e9, wMax = -1e9, yMin = 1e9, i;
    for (i = 0; i < f.length; i++) {
      var p = m.pts[f[i]];
      var wv = Math.atan2(p[2] - H.LV_CZ, p[0]);
      if (wv < wMin) wMin = wv;
      if (wv > wMax) wMax = wv;
      if (p[1] < yMin) yMin = p[1];
    }
    /* Das Fenster wird spitzenwaerts enger - massgebend ist der TIEFSTE Punkt der Flaeche. */
    var u = Math.max(0, Math.min(1, (0.60 - yMin) / (0.60 - B2.rvSpitze)));
    var eng = 0.34 * u;
    var ueber = Math.max((B2.rvVon + eng) - wMin, wMax - (B2.rvBis - eng));
    if (yMin < B2.rvSpitze - 1e-9 || ueber > 1e-6) {
      frei++;
      if (ueber > weitesteFrei) weitesteFrei = ueber;
    }
  });
  pruef('jede Septumflaeche ist GANZ von der rechten Kammer bedeckt - keine ragt hervor',
    frei === 0 && geprueftSept > 50,
    frei + ' ragen hervor von ' + geprueftSept + ' Septumflaechen, weiteste ' + weitesteFrei.toFixed(4) + ' rad');
  /*
   * UND DIE PROBE AUFS EXEMPEL: KEIN EINZIGER BILDPUNKT SEPTUM VON AUSSEN (14.08.2026).
   *
   * Die Pruefung oben fragt die GEOMETRIE - liegt jede Septumflaeche unter der rechten Kammer?
   * Nachdem sie auf die ganze Flaechenausdehnung umgestellt war, wurde sie gruen, WAEHREND
   * aussen am Herzen immer noch ein oranger Streifen stand (gemessen: 5,1 % der Bildflaeche
   * bei gier=90). Der Grund lag ausserhalb ihrer Reichweite: linke und rechte Kammer naehern
   * DIESELBE Flaeche mit verschieden feinen Vielecken an, und der Rasterer ohne Tiefenpuffer
   * entschied nach mittlerer Tiefe, welche oben liegt. Geometrisch war alles bedeckt -
   * GEZEICHNET war es das nicht. Zwei gruene Pruefungen, ein sichtbarer Fehler.
   *
   * Diese Pruefung fragt deshalb nicht die Geometrie, sondern das BILD: sie rastert die
   * geschlossene Ansicht rundum und zaehlt Septum-Bildpunkte. Anatomisch ist die Antwort
   * null - die Scheidewand liegt zwischen den Kammern und hat an der Herzoberflaeche nichts
   * zu suchen. Sie faellt bei JEDER Ursache rot aus (Kennzeichnung, Abtastung, Sortierung,
   * Kamera) und ist damit die einzige der beiden, die auch den naechsten Fehler findet,
   * den heute noch niemand kennt.
   */
  function septumBildpunkte(gier, nick) {
    var W = 200, Hh = 200;
    var a = H.ansicht(m, { breite: W, hoehe: Hh, gier: gier, nick: nick });
    var puffer = new Array(W * Hh), i;
    a.flaechen.forEach(function (fl) {                 /* schon nach Tiefe sortiert: hinten zuerst */
      var eck = fl.eck, xi = 1e9, xa = -1e9, yi = 1e9, ya = -1e9, q;
      for (q = 0; q < eck.length; q++) {
        if (eck[q].x < xi) xi = eck[q].x;
        if (eck[q].x > xa) xa = eck[q].x;
        if (eck[q].y < yi) yi = eck[q].y;
        if (eck[q].y > ya) ya = eck[q].y;
      }
      var x0 = Math.max(0, Math.floor(xi)), x1 = Math.min(W - 1, Math.ceil(xa));
      var y0 = Math.max(0, Math.floor(yi)), y1 = Math.min(Hh - 1, Math.ceil(ya));
      for (var py = y0; py <= y1; py++) {
        for (var px = x0; px <= x1; px++) {
          var drin = false, j, k;
          for (j = 0, k = eck.length - 1; j < eck.length; k = j++) {
            if (((eck[j].y > py) !== (eck[k].y > py)) &&
                (px < (eck[k].x - eck[j].x) * (py - eck[j].y) / (eck[k].y - eck[j].y) + eck[j].x)) drin = !drin;
          }
          if (drin) puffer[py * W + px] = fl;
        }
      }
    });
    var n = 0, aussen = 0;
    for (i = 0; i < puffer.length; i++) {
      if (puffer[i] && puffer[i].zone === 'septum') { n++; if (!puffer[i].innen) aussen++; }
    }
    return { n: n, aussen: aussen };
  }
  /*
   * ZWEI FRAGEN, WEIL ES ZWEI VERSCHIEDENE SIND (gemessen 14.08.2026).
   *
   * Von der Seite und von unten darf ueberhaupt kein Septum zu sehen sein - dort blickt man
   * auf die geschlossene Herzoberflaeche. Gemessen: 0 bei nick -16, -8 und 0.
   *
   * VON OBEN sieht man dagegen durch die OFFENE AV-Klappenoeffnung in die Kammer hinein; der
   * Deckel der linken Kammer ist ein Ring, kein Teller, und das ist Absicht (sonst gaebe es
   * keine Klappenoeffnung). Was dort erscheint, ist zu 100 % INNENhaut - gemessen 98 Punkte
   * bei nick 4, 397 bei nick 8, 876 bei nick 16, und kein einziger davon auf der Aussenhaut.
   * Das ist kein Fehler, sondern der Blick in ein offenes Herz.
   *
   * Die Aussenhaut dagegen darf aus KEINER Richtung Septum zeigen - auch nicht von oben.
   * Genau diese Trennung macht die Pruefung scharf statt tolerant: sie verlangt zweimal die
   * Null und nicht einmal einen Schwellwert, hinter dem sich ein neuer Fehler verstecken kann.
   */
  var septSeitlich = 0, septAussen = 0, schlimmG = -1, schlimmN = 0, schlimmZ = 0;
  [-16, -8, 0, 4, 8, 16].forEach(function (nk) {
    for (var gg = 0; gg < 360; gg += 30) {
      var r = septumBildpunkte(gg, nk);
      if (nk <= 0) septSeitlich += r.n;
      septAussen += r.aussen;
      if (r.n > schlimmZ) { schlimmZ = r.n; schlimmG = gg; schlimmN = nk; }
    }
  });
  pruef('seitlich und von unten ist rundum KEIN Bildpunkt Septum (36 Ansichten gerastert)',
    septSeitlich === 0,
    septSeitlich + ' Bildpunkte; groesster Einzelwert ' + schlimmZ + ' bei gier=' + schlimmG + ' nick=' + schlimmN);
  pruef('die AUSSENhaut zeigt aus KEINER Richtung Septum (72 Ansichten gerastert)',
    septAussen === 0, septAussen + ' Bildpunkte auf der Aussenhaut');

  var zonenImSchnitt = {};
  schnitt.flaechen.forEach(function (f) { zonenImSchnitt[f.zone] = 1; });
  pruef('der Schnitt zeigt Septum und beide Kammern', zonenImSchnitt.septum && zonenImSchnitt.lv && zonenImSchnitt.rv);
})();

/* ============================================================================
 * 5 — Rhythmen: WO bleibt die Erregung stehen? Das ist der klinische Kern.
 * ========================================================================= */
console.log('\n5  Rhythmusstoerungen und ihr Ort');
(function () {
  var art = 'hund', Z = H.zeitplan(art), p0 = M.pBeginnSek(art);
  function bei(ms, W, beat) { return H.zustand(p0 + ms / 1000, 0.8, W, beat, art); }

  /* Wenckebach (Mobitz I): der Halt sitzt IM AV-Knoten. */
  var wb = bei(Z.qrsVon + 20, { p: 1, drop: 'wenckebach', ratio: 4, pq: 'inc' }, 3);
  pruef('Wenckebach: der Halt sitzt im AV-KNOTEN', wb.halt === 'avk', 'halt=' + wb.halt);
  pruef('Wenckebach: die Kammer bleibt bei diesem Schlag unerregt', wb.erregt.lv < 0.02);

  /* Mobitz II: der Halt sitzt UNTERHALB des AV-Knotens. Genau dieser Unterschied entscheidet
   * ueber Atropinempfindlichkeit und Schrittmacherfrage - und er ist der Grund, warum das
   * Modell hier zwei verschiedene Stellen aufleuchten laesst. */
  var m2 = bei(Z.qrsVon + 20, { p: 1, drop: 'mobitz2', ratio: 3 }, 2);
  pruef('Mobitz II: der Halt sitzt im HIS-BUENDEL, nicht im AV-Knoten', m2.halt === 'his', 'halt=' + m2.halt);
  pruef('Mobitz II: der AV-Knoten hat den Impuls sehr wohl weitergegeben', m2.erregt.avk > 0.5);
  pruef('die beiden Bloecke zeigen auf VERSCHIEDENE Orte', wb.halt !== m2.halt);

  /*
   * KEIN SCHLAG, KEINE RICHTUNG (Befund 13.08.2026, im laufenden Browser gesehen).
   * richtung() entschied zuerst allein nach dem Zeitfenster und meldete bei einem
   * blockierten Schlag weiter "Richtung Herzspitze - R-Zacke", waehrend daneben die Kurve
   * flach lag und das Modell eine unerregte Kammer zeigte. Zwei Aussagen im selben Bild,
   * die einander widersprechen. Diese Pruefung haelt das fest.
   */
  pruef('Wenckebach: richtung() behauptet keine Kammerrichtung, wenn der Schlag ausfaellt',
    H.richtung(wb).achse === 'keine' && /nicht in der Kammer an/.test(H.richtung(wb).text),
    H.richtung(wb).text);
  pruef('Wenckebach: richtung() nennt den AV-Knoten als Ort des Halts',
    /AV-Knoten/.test(H.richtung(wb).warum));
  pruef('Mobitz II: richtung() nennt den Ort UNTERHALB des AV-Knotens',
    /His-Buendel/.test(H.richtung(m2).warum), H.richtung(m2).warum);
  /* Und die Gegenprobe: beim durchgeleiteten Schlag steht die normale Aussage wieder da. */
  var gut = bei(Z.rVon + 5, { p: 1, drop: 'wenckebach', ratio: 4, pq: 'inc' }, 0);
  pruef('derselbe Rhythmus, durchgeleiteter Schlag: die R-Richtung steht wieder da',
    H.richtung(gut).achse === 'spitze', H.richtung(gut).text);

  /* Und dieselbe Unterscheidung muss auch in der Ort-Tabelle stehen. */
  pruef('Ort-Tabelle: zunehmende PQ zeigt auf den AV-Knoten',
    H.ortFuer('pq-zunehmend').zonen.indexOf('avk') >= 0);
  pruef('Ort-Tabelle: Ausfall bei konstanter PQ zeigt UNTER den AV-Knoten',
    H.ortFuer('pq-konstant-ausfall').zonen.indexOf('his') >= 0 &&
    H.ortFuer('pq-konstant-ausfall').zonen.indexOf('avk') < 0);

  /* Ventrikulaere Extrasystole: Ursprung in der Kammer, ohne P, breit. */
  var ves = bei(Z.qrsVon + 40, { p: 1, ectopic: 'ves' }, 3);
  pruef('VES: der Ursprung liegt im Kammermyokard', ves.ursprung === 'kammer-ektop');
  pruef('VES: der Komplex ist breit (Weg durch die Arbeitsmuskulatur)', ves.breit === true);
  pruef('VES: das His-Buendel ist NICHT beteiligt', ves.erregt.his < 0.02);
  pruef('VES: die Schenkel sind NICHT beteiligt', ves.erregt.crusD < 0.02);
  pruef('VES: richtung() sagt, dass die Erregung NICHT den gewohnten Weg nimmt',
    H.richtung(ves).achse === 'ektop', H.richtung(ves).text);

  /* Totaler Block: Vorhoefe schlagen weiter, die Kammer aus einem Ersatzschrittmacher. */
  var dis = bei(Z.qrsVon + 40, { p: 1, pq: 'diss' }, 0);
  pruef('totaler Block: die Vorhoefe arbeiten weiter', dis.erregt.ra > 0.5);
  pruef('totaler Block: die Kammer laeuft aus einem Ersatzschrittmacher', dis.ursprung === 'ersatz-kammer');

  /* Asystolie und Kammerflimmern duerfen keinen geordneten Ablauf zeigen. */
  var asy = bei(Z.qrsVon, { flat: true }, 0);
  pruef('Asystolie: nichts ist erregt', asy.erregt.lv === 0 && asy.erregt.ra === 0);
  pruef('Asystolie: es gibt keinen Auswurf', asy.mech.abschnitt === 'kein Auswurf');
  var vf = bei(Z.qrsVon, { chaos: true }, 0);
  pruef('Kammerflimmern: das Kammermyokard ist ungeordnet erregt', vf.erregt.lv > 0.2);
  pruef('Kammerflimmern: es gibt keinen Auswurf', vf.mech.abschnitt === 'kein Auswurf');
  pruef('Kammerflimmern: richtung() sagt ausdruecklich, dass es keinen Vektor gibt',
    H.richtung(vf).achse === null);

  /* Die vulnerable Phase muss auf der T-Welle liegen - sie ist die Begruendung fuer R auf T. */
  pruef('die vulnerable Phase liegt auf der T-Welle',
    Z.vulnerabelVon >= Z.tVon && Z.vulnerabelBis <= Z.tBis);
  pruef('waehrend der T-Welle meldet das Modell die vulnerable Phase',
    bei((Z.vulnerabelVon + Z.vulnerabelBis) / 2, SINUS, 0).vulnerabel === true);
  pruef('waehrend der ST-Strecke meldet es sie NICHT',
    bei((Z.stVon + Z.stBis) / 2, SINUS, 0).vulnerabel === false);
})();

/* ============================================================================
 * 6 — Vollstaendigkeit: JEDE Regel der Hinweis-Maschine braucht einen Ort.
 *
 * DIESER BLOCK IST DIE EIGENTLICHE ABSICHERUNG. Er liest die Regel-Kennungen direkt aus
 * ui/app/index.html. Wer dort eine Regel ergaenzt und den Ort vergisst, bekommt hier eine
 * rote Zeile - statt einer Oberflaeche, die still nichts anzeigt.
 * ========================================================================= */
console.log('\n6  Jede Befundregel hat einen Ort (gelesen aus ui/app/index.html)');
(function () {
  var quelle = fs.readFileSync(pfad.join(WURZEL, 'ui/app/index.html'), 'utf8');
  /* Blockkommentare entfernen: eine Quellpruefung, die Kommentare mitliest, findet
   * Kennungen, die es gar nicht gibt (Befund 12.08.2026, siehe CLAUDE.md). */
  var rein = quelle.replace(/\/\*[\s\S]*?\*\//g, ' ');
  var von = rein.indexOf('var BEFUNDREGELN=');
  pruef('BEFUNDREGELN in index.html gefunden', von > 0);
  if (von < 0) return;
  var bis = rein.indexOf('function befundHinweise', von);
  var block = rein.slice(von, bis > 0 ? bis : von + 60000);
  var ids = [], re = /\bid:\s*'([a-zA-Z0-9_-]+)'/g, tr;
  while ((tr = re.exec(block))) if (ids.indexOf(tr[1]) < 0) ids.push(tr[1]);

  pruef('mindestens 40 Regeln gelesen', ids.length >= 40, ids.length + ' gelesen');
  var fehlend = ids.filter(function (id) { return !H.ortFuer(id); });
  pruef('jede Regel hat einen Eintrag in ORT', fehlend.length === 0,
    fehlend.length ? 'ohne Ort: ' + fehlend.join(', ') : '');

  /* Die Gegenrichtung: kein Eintrag ohne Regel - sonst wachsen hier Karteileichen. */
  var ueber = [];
  for (var k in H.ORT) if (Object.prototype.hasOwnProperty.call(H.ORT, k)) { if (ids.indexOf(k) < 0) ueber.push(k); }
  pruef('kein Ort ohne zugehoerige Regel', ueber.length === 0,
    ueber.length ? 'ohne Regel: ' + ueber.join(', ') : '');

  /* Jeder Eintrag muss vollstaendig sein und eine gueltige Art haben. */
  var arten = ['herz', 'umgebung', 'technik', 'artefakt'], schlecht = [];
  ids.forEach(function (id) {
    var o = H.ortFuer(id);
    if (!o) return;
    if (arten.indexOf(o.art) < 0) schlecht.push(id + ' (Art ' + o.art + ')');
    if (!o.was || !o.warum) schlecht.push(id + ' (Text fehlt)');
    if (!o.zonen) schlecht.push(id + ' (zonen fehlt)');
    /* Jede genannte Zone muss es auch geben - ein Tippfehler waere sonst eine Stelle,
     * die im Bild nie aufleuchtet und die niemand vermisst. */
    (o.zonen || []).forEach(function (zz) { if (!H.zone(zz)) schlecht.push(id + ' (unbekannte Zone ' + zz + ')'); });
  });
  pruef('jeder Eintrag ist vollstaendig und nennt nur bekannte Zonen', schlecht.length === 0, schlecht.join('; '));

  /* DIE WICHTIGSTE PRUEFUNG DIESES BLOCKS.
   * Ein Netzbrumm oder ein Filter darf KEINE Herzstelle aufleuchten lassen. Sonst malt die
   * Anwendung eine Krankheit an einen Ort, an dem nichts ist - der schaedlichste denkbare
   * Fehler dieses Merkmals. */
  var stoerung = ['guete-niedrig', 'netzeinstreuung', 'katze-vorschub', 'unkalibriert',
    'filter-amplitude', 'zaehlstrecke-kurz', 'lagerung', 'niedervoltage'];
  var malt = stoerung.filter(function (id) {
    var o = H.ortFuer(id);
    return o && o.art === 'herz';
  });
  pruef('Technik- und Artefaktbefunde zeigen auf KEINEN Herzort', malt.length === 0, malt.join(', '));
  var ohneZone = stoerung.filter(function (id) {
    var o = H.ortFuer(id);
    return o && o.art !== 'umgebung' && o.zonen.length > 0;
  });
  pruef('Technik- und Artefaktbefunde nennen gar keine Zone', ohneZone.length === 0, ohneZone.join(', '));
})();

/* ============================================================================
 * 7 — Mechanik und Blutfluss. Sie sind MODELL - und muessen sich auch so nennen.
 * ========================================================================= */
console.log('\n7  Herzzyklus, Klappen, Blutfluss (angehaengt an die Elektrik, NICHT gemessen)');
(function () {
  var art = 'hund', Z = H.zeitplan(art), p0 = M.pBeginnSek(art);
  function bei(ms, rr) { return H.zustand(p0 + ms / 1000, rr || 0.8, SINUS, 0, art); }

  pruef('das Modell kennzeichnet die Mechanik ausdruecklich als NICHT gemessen',
    bei(Z.qrsVon).mechanikGemessen === false);

  var anspann = bei(Z.qrsVon + H.MECH.emVerzugMs + 5);
  pruef('Anspannungsphase: BEIDE Klappenarten sind zu (isovolumisch)',
    anspann.mech.avOffen === false && anspann.mech.semiOffen === false,
    anspann.mech.abschnitt);
  var aus = bei(Z.qrsVon + H.MECH.emVerzugMs + H.MECH.anspannungMs + 20);
  pruef('Austreibungsphase: die Taschenklappen sind offen, die Segelklappen zu',
    aus.mech.semiOffen === true && aus.mech.avOffen === false, aus.mech.abschnitt);
  var fuell = bei(Z.tBis + H.MECH.entspannungMs + 20);
  pruef('Fuellungsphase: die Segelklappen sind offen, die Taschenklappen zu',
    fuell.mech.avOffen === true && fuell.mech.semiOffen === false, fuell.mech.abschnitt);

  /* Die Papillarmuskeln kontrahieren VOR der Wand und halten die Segel - deshalb darf zu
   * keinem Zeitpunkt gleichzeitig "Kammer kontrahiert" und "Segelklappe offen" gelten. */
  var schlimm = 0, ms;
  for (ms = 0; ms < Z.zyklusEnde; ms += 2) {
    var zz = bei(ms);
    if (zz.mech.kammerKontrahiert && zz.mech.avOffen) schlimm++;
  }
  pruef('nie gleichzeitig: Kammer kontrahiert UND Segelklappe offen', schlimm === 0, schlimm + ' Zeitpunkte');

  /* Koronarfluss NUR in der Diastole (Killich S. 33) - das ist die klinisch entscheidende
   * Aussage hinter jeder Tachykardie. */
  function hatKoronar(zz) {
    var f = zz.fluss, i;
    for (i = 0; i < f.length; i++) if (f[i].id === 'koronar') return true;
    return false;
  }
  pruef('Koronarfluss laeuft NICHT waehrend der Austreibung', !hatKoronar(aus));
  pruef('Koronarfluss laeuft in der Fuellungsphase', hatKoronar(fuell));

  /* Und die Folge daraus: je schneller das Herz, desto kuerzer die Diastole. */
  var d60 = H.diastoleDauer(Z, 1000), d200 = H.diastoleDauer(Z, 300);
  pruef('die Diastole wird bei steigender Frequenz kuerzer', d200 < d60,
    '60/min ' + d60.toFixed(0) + ' ms, 200/min ' + d200.toFixed(0) + ' ms');
  pruef('bei 200/min bleibt der Diastole weniger als die Haelfte der Zeit von 60/min',
    d200 < d60 * 0.5);

  /* ------------------------------------------------------------------------------------
   * DER BLUTFLUSS MUSS AUCH ANKOMMEN - nicht nur gerechnet werden (14.08.2026).
   *
   * Bis hierher wurde geprueft, WANN welche Bahn fuehrt. Bis zum 14.08.2026 stand der Fluss
   * aber nur als Satz im Seitenfeld; im Bild war er nicht zu sehen. Jetzt zeichnet ihn die
   * Oberflaeche zwischen zwei ANKERN - und damit entsteht genau die Sorte stiller Fehler,
   * die dieses Projekt schon zweimal getroffen hat (Positivliste = Loeschstelle, siehe
   * vetstation-ekg-submodul): fehlt zu einer Bahn der Anker, verschwindet sie WORTLOS aus
   * dem Bild, waehrend der Satz daneben weiter behauptet, dort fliesse Blut.
   *
   * Deshalb wird die Beweislast umgedreht: JEDE Bahn, die im ganzen Zyklus irgendwann fuehrt,
   * muss beide Anker haben, und die beiden muessen auseinanderliegen - ein Pfeil der Laenge
   * null ist auch kein Pfeil.
   * --------------------------------------------------------------------------------- */
  var alleBahnen = {}, ankerFehlt = [], zuNah = [], ohneBlut = [];
  var A0 = H.ansicht(H.netz('hund'), { breite: 400, hoehe: 400, gier: 0, nick: 10 });
  for (var tt = 0; tt <= 1000; tt += 5) {
    var zf = bei(tt);
    for (var q2 = 0; q2 < zf.fluss.length; q2++) {
      var bh = zf.fluss[q2];
      if (alleBahnen[bh.id]) continue;
      alleBahnen[bh.id] = bh;
      if (['venoes', 'arteriell'].indexOf(bh.blut) < 0) ohneBlut.push(bh.id);
      var av = A0.anker[bh.von], an = A0.anker[bh.nach];
      if (!av || !an) { ankerFehlt.push(bh.id + ' (' + bh.von + '->' + bh.nach + ')'); continue; }
      if (Math.abs(av.x - an.x) < 2 && Math.abs(av.y - an.y) < 2) zuNah.push(bh.id);
    }
  }
  var bahnZahl = 0, bk;
  for (bk in alleBahnen) if (Object.prototype.hasOwnProperty.call(alleBahnen, bk)) bahnZahl++;
  pruef('jede Flussbahn des Zyklus hat beide Anker im Bild', ankerFehlt.length === 0 && bahnZahl >= 5,
    bahnZahl + ' Bahnen, ohne Anker: ' + (ankerFehlt.join(', ') || 'keine'));
  pruef('kein Pfeil der Laenge null - Anfang und Ende liegen auseinander', zuNah.length === 0,
    zuNah.join(', ') || 'keine');
  pruef('jede Bahn sagt, ob sie venoeses oder arterielles Blut fuehrt', ohneBlut.length === 0,
    ohneBlut.join(', ') || 'keine');
  /* Der Merksatz, an dem sich Lernende verheddern - und den die Oberflaeche sonst falsch faerbt. */
  pruef('der Truncus pulmonalis fuehrt VENOESES Blut (Arterie mit venoesem Blut)',
    alleBahnen['auswurf-r'] && alleBahnen['auswurf-r'].blut === 'venoes');
  pruef('die Fuellung der linken Kammer fuehrt ARTERIELLES Blut (Vene mit arteriellem Blut)',
    alleBahnen['fuellung-l'] && alleBahnen['fuellung-l'].blut === 'arteriell');

  /*
   * Die Teilchen haengen an der ZYKLUSZEIT, nicht an der Uhr. Geprueft wird die Eigenschaft,
   * aus der das folgt: der Ort haengt allein vom Verhaeltnis tSek/rrSek ab. Waere das nicht so,
   * liefe das Bild bei einer anderen Herzfrequenz gegen die Kurve - und zwar unauffaellig.
   */
  var gleich = true, sp;
  for (sp = 0; sp < 20; sp++) {
    var frac = sp / 20;
    var a1 = H.flussPhase(frac * 0.4, 0.4, 0, 6);
    var a2 = H.flussPhase(frac * 1.2, 1.2, 0, 6);
    if (Math.abs(a1 - a2) > 1e-12) gleich = false;
  }
  pruef('die Teilchenphase haengt NUR am Bruchteil des Zyklus (60/min wie 150/min)', gleich);
  var imBereich = true, gleichAbstand = true;
  for (sp = 0; sp < 6; sp++) {
    var ph = H.flussPhase(0.137, 0.8, sp, 6);
    if (!(ph >= 0 && ph < 1)) imBereich = false;
    var soll = H.flussPhase(0.137, 0.8, 0, 6) + sp / 6;
    if (Math.abs(ph - (soll - Math.floor(soll))) > 1e-12) gleichAbstand = false;
  }
  pruef('jede Teilchenphase liegt in [0,1)', imBereich);
  pruef('die Teilchen stehen in gleichem Abstand auf der Bahn', gleichAbstand);
})();

/* ============================================================================
 * 8 — Reine ES5-Quelle, und die Datei muss in beide Baeume kopiert werden.
 * ========================================================================= */
console.log('\n8  Quelle und Einbindung');
(function () {
  var src = fs.readFileSync(pfad.join(WURZEL, 'ui/shared/herz3d.js'), 'utf8');
  var ohneKomm = src.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/(^|[^:])\/\/.*$/gm, '$1');
  pruef('herz3d.js ist reines ES5 (kein =>, class, const, let, Backtick)',
    !/=>|\bclass\s|\bconst\s|\blet\s|`/.test(ohneKomm));
  pruef('herz3d.js zieht keine fremde Abhaengigkeit herein',
    (ohneKomm.match(/require\(/g) || []).length === 1 &&
    ohneKomm.indexOf("require('./ekg-modell.js')") >= 0);

  var idx = fs.readFileSync(pfad.join(WURZEL, 'ui/app/index.html'), 'utf8');
  pruef('index.html laedt shared/herz3d.js', idx.indexOf('shared/herz3d.js') >= 0);
  pruef('herz3d.js wird NACH ekg-modell.js geladen (es braucht dessen Zeiten)',
    idx.indexOf('shared/herz3d.js') > idx.indexOf('shared/ekg-modell.js'));

  /* Die Kopierliste der Web-App. Ohne diesen Eintrag faellt das Merkmal in der Fern-App
   * STILL aus - der bekannteste Fallstrick dieses Projekts. */
  var bau = fs.readFileSync(pfad.join(WURZEL, 'tools/web-app-bauen.js'), 'utf8');
  pruef('herz3d.js steht in der Kopierliste von web-app-bauen.js',
    bau.indexOf("'shared/herz3d.js'") >= 0);

  var alle = fs.readFileSync(pfad.join(WURZEL, 'tools/alle-tests.js'), 'utf8');
  pruef('herz3d-test.js ist im Sammellauf eingetragen', alle.indexOf('herz3d-test.js') >= 0);
})();

console.log('\n' + (fehler ? 'FEHLGESCHLAGEN' : 'ALLE GRUEN') + ': ' + (geprueft - fehler) + ' von ' + geprueft + ' Pruefungen.');
process.exit(fehler ? 1 : 0);
