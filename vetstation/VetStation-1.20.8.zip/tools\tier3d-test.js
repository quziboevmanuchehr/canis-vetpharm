'use strict';
/*
 * tier3d-test.js — das drehbare 3D-Modell mit den Anlegepunkten.
 *
 * WAS HIER WIRKLICH BEWACHT WIRD, und es ist nur EINE Sache in drei Formen:
 * WELCHE SEITE IST DAS? Wer RA und LA vertauscht, bekommt eine Kurve, die tadellos
 * aussieht und in Ableitung I gespiegelt ist - der gefaehrlichste Bedienfehler am EKG.
 * Ein Modell, das man drehen kann, soll genau diese Verwechslung ausschliessen. Tut es das
 * nicht, ist es schlimmer als der alte flache Umriss, weil es Raeumlichkeit vortaeuscht.
 *
 * Und weil eine Marke NICHT aufgemalt, sondern das Gelenk selbst ist: sie muss mit dem
 * Kettenglied der Gliedmasse uebereinstimmen. Das kann gar nicht auseinanderlaufen -
 * dieser Test haelt fest, dass es so bleibt.
 *
 * ---------------------------------------------------------------------------------------
 * DREI PRUEFGRUPPEN KAMEN AM 12.08.2026 DAZU, und jede davon, weil ein Fehler durch die
 * alte Suite gruen hindurchgelaufen ist. Alle drei wurden erst am GERENDERTEN BILD
 * entdeckt (scratchpad-Rasterer, spaeter tools/tier3d-bild.js), nicht durch Rechnen:
 *
 *   9. DICHTHEIT.  Die alte Suite pruefte Punktzahl, Seiten, Rahmen und Sortierung; ein LOCH
 *      im Netz beruehrt nichts davon. Jetzt wird jeder Skelettpunkt, der im Inneren liegt,
 *      auf Bedeckung durch eine sichtbare Flaeche geprueft.
 *      EHRLICH DAZU: der Anlass war ein Fehlalarm - auf dem Bild sahen die Hinterbeine
 *      zerrissen aus, nachgemessen war es der Hintergrund zwischen ihnen. Die Pruefung ist
 *      geblieben, weil zwei absichtliche Beschaedigungen belegen, dass sie traegt (fehlender
 *      Flaechenring: 32 von 590 Punkten unbedeckt; verkuerzte Gliedmasse: 24 von 590).
 *      WAS SIE NICHT FINDET: ein verdrehtes Ringkreuz. Ein verdrehtes Band ist immer noch
 *      eine geschlossene Flaeche und bedeckt die inneren Punkte. Dagegen hilft nur der
 *      parallele Transport in loft() selbst, nicht eine Pruefung hinterher.
 *  10. BAUTEILE.  Der Kopf sass sichtbar NEBEN dem Hals: zwei getrennte Koerper mit einer
 *      Luecke dazwischen. Auch das ist rechnerisch unauffaellig. Jetzt wird die Zahl der
 *      zusammenhaengenden Teile gezaehlt - Kopf und Rumpf MUESSEN ein Teil sein.
 *      Absichtlich zerbrochen: Kopf wieder als eigener Loft -> 16 statt 15 Teile, rot.
 *  11. VERHAELTNISSE.  Hund und Katze sahen gleich aus. Wer zwei Arten anbietet und
 *      dasselbe Tier zeigt, hat eine Auswahl ohne Inhalt. Jetzt wird nachgerechnet, dass
 *      sich Schaedelform, Schnauzenanteil und Taille deutlich unterscheiden.
 *
 * Was diese Pruefungen NICHT koennen: sagen, ob ein Tier wie ein Tier AUSSIEHT. Dafuer
 * gibt es tools/tier3d-bild.js - ein Bild muss man ansehen.
 * ---------------------------------------------------------------------------------------
 *
 * Start: node tools/tier3d-test.js
 */
const T = require('../ui/shared/tier3d.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }
const ARTEN = T.arten();

console.log('\nVetStation - 3D-Modell und Anlegepunkte\n');

/* ================================================================================
 * 1. DIE SEITEN — Rohdaten
 * ============================================================================== */
block('1. links, rechts, vorn, hinten');
pruef('es gibt Modelle', ARTEN.length >= 3, ARTEN.join(','));
ARTEN.forEach((art) => {
  const m = T.netz(art);
  pruef(art + ': Netz gebaut', !!m && m.pts.length > 500 && m.faces.length > 400,
    m ? (m.pts.length + ' Punkte, ' + m.faces.length + ' Flaechen') : 'null');
  const M = {};
  m.marken.forEach((s) => { M[s.k] = s; });
  pruef(art + ': genau vier Anlegepunkte', m.marken.length === 4, String(m.marken.length));
  ['RA', 'LA', 'LL', 'RL'].forEach((k) => pruef(art + ': ' + k + ' vorhanden', !!M[k]));
  /* z < 0 ist RECHTS, z > 0 ist LINKS (siehe Dateikopf von tier3d.js). */
  pruef(art + ': RA liegt RECHTS', M.RA.p[2] < 0, String(M.RA.p[2]));
  pruef(art + ': RL liegt RECHTS', M.RL.p[2] < 0, String(M.RL.p[2]));
  pruef(art + ': LA liegt LINKS', M.LA.p[2] > 0, String(M.LA.p[2]));
  pruef(art + ': LL liegt LINKS', M.LL.p[2] > 0, String(M.LL.p[2]));
  /* x > 0 ist VORN (Nase), x < 0 ist HINTEN (Schwanz). */
  pruef(art + ': RA und LA sind VORN', M.RA.p[0] > 0 && M.LA.p[0] > 0, M.RA.p[0] + '/' + M.LA.p[0]);
  pruef(art + ': RL und LL sind HINTEN', M.RL.p[0] < 0 && M.LL.p[0] < 0, M.RL.p[0] + '/' + M.LL.p[0]);
  /* Und sie muessen einander spiegeln - eine Seite darf nicht weiter vorn sitzen. */
  pruef(art + ': RA und LA spiegeln einander',
    Math.abs(M.RA.p[0] - M.LA.p[0]) < 1e-9 && Math.abs(M.RA.p[2] + M.LA.p[2]) < 1e-9);
  pruef(art + ': RL und LL spiegeln einander',
    Math.abs(M.RL.p[0] - M.LL.p[0]) < 1e-9 && Math.abs(M.RL.p[2] + M.LL.p[2]) < 1e-9);
  pruef(art + ': vorn heisst Ellbogen, hinten Knie',
    M.RA.gelenk === 'Ellbogen' && M.LA.gelenk === 'Ellbogen' &&
    M.RL.gelenk === 'Knie' && M.LL.gelenk === 'Knie');
  pruef(art + ': RL ist als Neutral/Erde ausgewiesen', /Neutral|Erde/.test(M.RL.wo), M.RL.wo);
});

/* ================================================================================
 * 2. DIE MARKE IST DAS GELENK — nicht daneben gemalt
 * ============================================================================== */
block('2. die Marke sitzt auf dem Gelenk');
ARTEN.forEach((art) => {
  const b = T.BAU[art], m = T.netz(art);
  const M = {}; m.marken.forEach((s) => { M[s.k] = s; });
  /* Der Ellbogen des Bauplans, auf die linke Seite gespiegelt, MUSS der Punkt von LA sein.
   * Das Netz wird beim Bauen auf seine eigene Mitte geschoben - deshalb wird sie hier
   * wieder aufgeschlagen. Waere das eine Ausrede, wuerde die Pruefung nichts mehr bewachen;
   * sie ist es nicht: m.mitte ist EINE Verschiebung fuer alle Punkte, ein falsch gesetztes
   * Gelenk faellt darunter genauso auf wie vorher. */
  const mi = m.mitte, e = b.vorn.ellbogen, k = b.hinten.knie;
  const gl = (a, soll) => Math.abs(a - soll) < 1e-9;
  pruef(art + ': LA sitzt genau auf dem Ellbogen des Bauplans',
    gl(M.LA.p[0] + mi[0], e[0]) && gl(M.LA.p[1] + mi[1], e[1]) && gl(Math.abs(M.LA.p[2]), Math.abs(e[2])),
    JSON.stringify(M.LA.p) + ' + ' + JSON.stringify(mi) + ' vs ' + JSON.stringify(e));
  pruef(art + ': LL sitzt genau auf dem Knie des Bauplans',
    gl(M.LL.p[0] + mi[0], k[0]) && gl(M.LL.p[1] + mi[1], k[1]) && gl(Math.abs(M.LL.p[2]), Math.abs(k[2])),
    JSON.stringify(M.LL.p) + ' + ' + JSON.stringify(mi) + ' vs ' + JSON.stringify(k));
  /* Und das Modell muss wirklich zentriert sein - sonst steht es schief im Bild und dreht
   * sich um einen Punkt neben seinem Koerper. */
  {
    let lo = 1e9, hi = -1e9;
    m.pts.forEach((p) => { if (p[0] < lo) lo = p[0]; if (p[0] > hi) hi = p[0]; });
    pruef(art + ': das Netz ist waagerecht zentriert', Math.abs(lo + hi) < 1e-9, lo + ' / ' + hi);
  }
});

/* ================================================================================
 * 3. DIE GLIEDMASSE IST EINE KETTE MIT GELENKEN
 *
 * WARUM DAS GEPRUEFT WIRD: Die erste Fassung des Modells hatte KEIN SPRUNGGELENK - die
 * Hintergliedmasse lief in einer Geraden von der Huefte zur Pfote. Das ist nicht nur
 * haesslich, sondern fachlich schaedlich: im Anlegetext steht die Warnung "nicht am
 * Sprunggelenk klemmen", und das Modell zeigte gar keines. Wer den Unterschied zwischen
 * Knie und Sprunggelenk am Bild nicht sehen kann, kann ihn auch nicht einhalten.
 * ============================================================================== */
block('3. Gelenke der Gliedmasse');
ARTEN.forEach((art) => {
  const b = T.BAU[art], v = b.vorn, h = b.hinten;
  /* Von oben nach unten muss es bei jedem Glied ABWAERTS gehen. */
  pruef(art + ': Vordergliedmasse laeuft durchgehend abwaerts',
    v.schulter[1] > v.buggelenk[1] && v.buggelenk[1] > v.ellbogen[1] &&
    v.ellbogen[1] > v.carpus[1] && v.carpus[1] > v.pfote[1],
    [v.schulter[1], v.buggelenk[1], v.ellbogen[1], v.carpus[1], v.pfote[1]].join(' > '));
  pruef(art + ': Hintergliedmasse laeuft durchgehend abwaerts',
    h.huefte[1] > h.knie[1] && h.knie[1] > h.sprung[1] && h.sprung[1] > h.pfote[1],
    [h.huefte[1], h.knie[1], h.sprung[1], h.pfote[1]].join(' > '));
  /* DER ZICKZACK: das Knie liegt VOR der Huefte, das Sprunggelenk wieder dahinter. Genau
   * das ist der Unterschied, den man am Tier sehen und am Modell wiederfinden muss. */
  pruef(art + ': das Knie liegt VOR der Huefte', h.knie[0] > h.huefte[0],
    h.knie[0] + ' > ' + h.huefte[0]);
  pruef(art + ': das Sprunggelenk liegt HINTER dem Knie', h.sprung[0] < h.knie[0],
    h.sprung[0] + ' < ' + h.knie[0]);
  /* Und es liegt deutlich tiefer - sonst waeren beide auf einer Hoehe verwechselbar. */
  const spanne = h.huefte[1] - h.pfote[1];
  pruef(art + ': Knie und Sprunggelenk sind deutlich getrennt',
    (h.knie[1] - h.sprung[1]) > 0.20 * spanne,
    ((h.knie[1] - h.sprung[1]) / spanne).toFixed(2) + ' der Gliedmassenlaenge');
  /* Jedes Kettenglied braucht seinen Radius, sonst baut loft() Unsinn. */
  pruef(art + ': jedes Kettenglied hat einen Radius',
    v.r.length === 5 && h.r.length === 4, v.r.length + '/' + h.r.length);
});
{
  /* DER GRUND, WARUM JEDE ART EIN EIGENES MODELL HAT: beim Frettchen liegt der Ellbogen
   * viel dichter an der Unterlinie als beim Hund. Wer die Punkte des Hundes uebernimmt,
   * klemmt am Bauch. Diese Pruefung haelt den Unterschied fest. */
  const h = T.BAU.hund, f = T.BAU.frettchen;
  const anteil = (b) => (b.vorn.schulter[1] - b.vorn.ellbogen[1]) / (b.vorn.schulter[1] - b.vorn.pfote[1]);
  const relBein = (b) => (b.vorn.schulter[1] - b.vorn.pfote[1]) / b.laenge;
  console.log('    Beinlaenge/Rumpflaenge: Hund ' + relBein(h).toFixed(2) + ', Frettchen ' + relBein(f).toFixed(2));
  pruef('das Frettchen hat im Verhaeltnis viel kuerzere Beine als der Hund',
    relBein(f) < relBein(h) * 0.6, relBein(f).toFixed(2) + ' vs ' + relBein(h).toFixed(2));
  pruef('und der Ellbogen sitzt bei beiden auf gleicher relativer Beinhoehe',
    Math.abs(anteil(h) - anteil(f)) < 0.15, anteil(h).toFixed(2) + ' vs ' + anteil(f).toFixed(2));
  /* Das Kaninchen traegt die Kraft in der Hinterhand: sein Knie sitzt deutlich weiter VORN
   * (relativ zur Huefte) als beim Hund. */
  const kn = (b) => b.hinten.knie[0] - b.hinten.huefte[0];
  pruef('beim Kaninchen sitzt das Knie weiter vorn als beim Hund',
    kn(T.BAU.kaninchen) > kn(T.BAU.hund) + 0.05, kn(T.BAU.kaninchen).toFixed(2) + ' vs ' + kn(T.BAU.hund).toFixed(2));
}

/* ================================================================================
 * 4. DREHEN — die Geometrie muss stimmen, sonst verzerrt jedes Bild
 * ============================================================================== */
block('4. Drehung');
{
  const laenge = (p) => Math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]);
  const p = [1.3, -0.4, 0.7], L = laenge(p);
  [0, 37, 90, 180, 271, 359].forEach((g) => {
    [0, 20, -35].forEach((n) => {
      const q = T.drehe(p, g * Math.PI / 180, n * Math.PI / 180);
      pruef('Drehung ' + g + '/' + n + ' erhaelt die Laenge', Math.abs(laenge(q) - L) < 1e-9,
        laenge(q) + ' vs ' + L);
    });
  });
  const rund = T.drehe(p, 2 * Math.PI, 0);
  pruef('volle Umdrehung fuehrt zum Ausgangspunkt zurueck',
    Math.abs(rund[0] - p[0]) < 1e-9 && Math.abs(rund[2] - p[2]) < 1e-9);
  const halb = T.drehe(p, Math.PI, 0);
  pruef('halbe Umdrehung spiegelt x und z', Math.abs(halb[0] + p[0]) < 1e-9 && Math.abs(halb[2] + p[2]) < 1e-9);
  pruef('und laesst y in Ruhe (Drehung um die Hochachse)', Math.abs(halb[1] - p[1]) < 1e-9);
}

/* ================================================================================
 * 5. DAS BILD — bleibt links links?
 * ============================================================================== */
block('5. Seiten im gedrehten Bild');
{
  const m = T.netz('hund');
  /* Blick auf die LINKE Seite: die Kamera steht auf +z. Dann muessen LA und LL vorn
   * (sichtbar) sein und RA/RL hinten. */
  const a0 = T.ansicht(m, { gierGrad: 0, nickGrad: 0, breite: 420, hoehe: 300 });
  const V = {}; a0.marken.forEach((s) => { V[s.k] = s; });
  pruef('Blick von links: LA und LL sind sichtbar', V.LA.vorn === true && V.LL.vorn === true);
  pruef('Blick von links: RA und RL sind VERDECKT', V.RA.vorn === false && V.RL.vorn === false,
    'RA ' + V.RA.vorn + ', RL ' + V.RL.vorn);
  /* Und um 180 Grad gedreht kehrt sich das um - das ist der eigentliche Zweck des Modells. */
  const a180 = T.ansicht(m, { gierGrad: 180, nickGrad: 0, breite: 420, hoehe: 300 });
  const W = {}; a180.marken.forEach((s) => { W[s.k] = s; });
  pruef('um 180 Grad gedreht: RA und RL sind sichtbar', W.RA.vorn === true && W.RL.vorn === true);
  pruef('um 180 Grad gedreht: LA und LL sind verdeckt', W.LA.vorn === false && W.LL.vorn === false);
  /* Die Nase wechselt dabei die Bildseite - sonst dreht sich gar nichts. */
  const nase = (g) => {
    const v = T.ansicht(m, { gierGrad: g, nickGrad: 0, breite: 420, hoehe: 300 });
    return v.marken.filter((s) => s.k === 'LA')[0].x;
  };
  pruef('die Vordergliedmasse wechselt beim Drehen die Bildseite', (nase(0) - 210) * (nase(180) - 210) < 0,
    nase(0).toFixed(0) + ' -> ' + nase(180).toFixed(0));
}
{
  /* Ueber den ganzen Drehkreis: es duerfen NIE alle vier Marken gleichzeitig sichtbar sein.
   * Genau das waere die vorgetaeuschte Raeumlichkeit, vor der der Dateikopf warnt. */
  const m = T.netz('katze');
  let maxSichtbar = 0, minSichtbar = 9;
  for (let g = 0; g < 360; g += 5) {
    const v = T.ansicht(m, { gierGrad: g, nickGrad: 0, breite: 420, hoehe: 300 });
    const n = v.marken.filter((s) => s.vorn).length;
    if (n > maxSichtbar) maxSichtbar = n;
    if (n < minSichtbar) minSichtbar = n;
  }
  console.log('    sichtbare Marken ueber 72 Drehwinkel: ' + minSichtbar + ' bis ' + maxSichtbar);
  pruef('nie alle vier Marken gleichzeitig sichtbar', maxSichtbar < 4, String(maxSichtbar));
  pruef('aber auch nie weniger als zwei (sonst ist das Bild unbrauchbar)', minSichtbar >= 2, String(minSichtbar));
}

/* ================================================================================
 * 6. DAS BILD BLEIBT IM RAHMEN
 * ============================================================================== */
block('6. Rahmen');
ARTEN.forEach((art) => {
  const m = T.netz(art);
  let drin = true, groesster = 0;
  /* Ueber den GANZEN erlaubten Kippbereich, nicht nur ±30: der Massstab haengt seit dem
   * zweiten Fehlversuch vom Kippwinkel ab, und genau an den Raendern muss er tragen. */
  [[420, 300], [320, 220], [640, 420], [300, 300], [233, 144]].forEach(([B, H]) => {
    for (let g = 0; g < 360; g += 17) {
      for (const n of [-80, -55, -33, -12, 0, 7, 25, 44, 72, 80]) {
        const v = T.ansicht(m, { gierGrad: g, nickGrad: n, breite: B, hoehe: H });
        v.flaechen.forEach((f) => f.eck.forEach((e) => {
          if (e.x < -1 || e.x > B + 1 || e.y < -1 || e.y > H + 1) drin = false;
          groesster = Math.max(groesster, Math.abs(e.x - B / 2) / B, Math.abs(e.y - H / 2) / H);
        }));
      }
    }
  });
  pruef(art + ': ragt bei keiner Groesse und keinem Winkel aus der Flaeche', drin,
    'groesste relative Auslenkung ' + groesster.toFixed(2));
});

/* ================================================================================
 * 7. TIEFENSORTIERUNG UND RUECKSEITEN
 * ============================================================================== */
block('7. Zeichenreihenfolge');
{
  const m = T.netz('hund');
  const v = T.ansicht(m, { gierGrad: 35, nickGrad: 15, breite: 420, hoehe: 300 });
  let sortiert = true;
  for (let i = 1; i < v.flaechen.length; i++) if (v.flaechen[i].tiefe < v.flaechen[i - 1].tiefe) sortiert = false;
  pruef('Flaechen liegen hinten-zuerst (Maler-Verfahren)', sortiert);
  pruef('Rueckseiten werden weggelassen', v.flaechen.length < m.faces.length,
    v.flaechen.length + ' von ' + m.faces.length);
  /* Bei einem geschlossenen Koerper ist ungefaehr die HAELFTE sichtbar. Deutlich weniger
   * hiesse, dass die Umlaufrichtung irgendwo verdreht ist und der Koerper von innen
   * gezeichnet wird - ein Fehler, der im Bild nur "etwas komisch" aussieht. */
  const anteil = v.flaechen.length / m.faces.length;
  pruef('etwa die Haelfte der Flaechen zeigt zur Kamera', anteil > 0.35 && anteil < 0.62,
    (100 * anteil).toFixed(0) + ' %');
  let hellOk = true;
  v.flaechen.forEach((f) => { if (!(f.hell >= 0.28 && f.hell <= 1)) hellOk = false; });
  pruef('die Helligkeit bleibt im Band 0,28 bis 1', hellOk);
}

/* ================================================================================
 * 8. WO ES KEIN MODELL GIBT, WIRD KEINES BEHAUPTET
 * ============================================================================== */
block('8. Schweigen');
['vogel', 'reptil', 'pferd', 'hamster', '', null, 'unsinn'].forEach((art) => {
  pruef('"' + String(art) + '" hat kein Modell', T.hatModell(art) === false);
  pruef('"' + String(art) + '" liefert null statt einer Hundevorlage', T.netz(art) === null);
});

/* ================================================================================
 * 9. DICHTHEIT — hat das Netz irgendwo ein Loch?
 *
 * Jeder Skelettpunkt liegt INNERHALB des Koerpers (auf der Achse einer Gliedmasse oder auf
 * der Wirbelsaeule). Ein innerer Punkt eines geschlossenen Koerpers bildet sich bei jeder
 * Blickrichtung auf eine bedeckte Bildstelle ab. Tut er das nicht, klafft dort das Netz.
 *
 * Die Projektion wird hier ABSICHTLICH noch einmal ausgeschrieben statt aus tier3d.js
 * geholt: eine Pruefung, die dieselbe Funktion benutzt wie das Gepruefte, prueft nichts.
 * ============================================================================== */
block('9. Dichtheit des Netzes');
function imVieleck(x, y, eck) {
  let drin = false;
  for (let i = 0, j = eck.length - 1; i < eck.length; j = i++) {
    const yi = eck[i].y, yj = eck[j].y;
    if ((yi > y) === (yj > y)) continue;
    const xs = eck[i].x + (y - yi) / (yj - yi) * (eck[j].x - eck[i].x);
    if (xs > x) drin = !drin;
  }
  return drin;
}
ARTEN.forEach((art) => {
  const m = T.netz(art);
  const B = 640, H = 440;
  let loecher = 0, geprueft = 0, schlimmstes = '';
  [[0, 8], [45, 8], [90, 8], [135, 8], [180, 8], [225, 8], [270, 8], [315, 8], [30, 40], [30, -40]]
    .forEach(([g, n]) => {
      const v = T.ansicht(m, { gierGrad: g, nickGrad: n, breite: B, hoehe: H });
      const gr = g * Math.PI / 180, nr = n * Math.PI / 180;
      m.skelett.forEach((s) => {
        /* Nur ECHT innen liegende Punkte. Die Enden einer Kette sind die Mittelpunkte ihrer
         * Deckel und liegen damit AUF der Oberflaeche - von ihnen eine Flaeche davor zu
         * verlangen, waere eine Pruefung gegen die eigene Randbedingung, nicht gegen ein
         * Loch. Gemessen: dort hat die einzige Flaeche an der Bildstelle exakt dieselbe
         * Tiefe wie der Punkt. */
        if (!s.innen) return;
        const q = T.drehe(s.p, gr, nr);
        const f = T.KAMERA / (T.KAMERA - q[2]);
        const px = B / 2 + q[0] * v.skala * f, py = H / 2 - q[1] * v.skala * f;
        geprueft++;
        /* Bedeckt heisst: irgendeine sichtbare Flaeche liegt VOR dem Punkt an dieser Stelle. */
        const bedeckt = v.flaechen.some((fl) => fl.tiefe > q[2] && imVieleck(px, py, fl.eck));
        if (!bedeckt) { loecher++; if (!schlimmstes) schlimmstes = s.was + ' bei ' + g + '/' + n; }
      });
    });
  pruef(art + ': kein Skelettpunkt liegt in einem Loch', loecher === 0,
    loecher + ' von ' + geprueft + ' unbedeckt, zuerst: ' + schlimmstes);
});

/* ================================================================================
 * 10. BAUTEILE — sitzt der Kopf am Hals?
 *
 * Rumpf, Hals und Kopf sind EIN zusammenhaengendes Teil. Getrennt gebaut klaffte dazwischen
 * eine Luecke, und der Kopf sass sichtbar neben dem Hals. Gezaehlt wird ueber die geteilten
 * Eckpunkte: 1 Koerper + 1 Nasenspiegel + 1 Schwanz + 2 Augen + 2 Ohren + 4 Gliedmassen
 * + 4 Pfoten = 15.
 * ============================================================================== */
block('10. Bauteile');
ARTEN.forEach((art) => {
  const m = T.netz(art);
  const eltern = new Array(m.pts.length).fill(0).map((_, i) => i);
  const find = (x) => { while (eltern[x] !== x) { eltern[x] = eltern[eltern[x]]; x = eltern[x]; } return x; };
  m.faces.forEach((f) => {
    for (let j = 1; j < f.length; j++) { const a = find(f[0]), b = find(f[j]); if (a !== b) eltern[b] = a; }
  });
  const teile = new Set(); m.faces.forEach((f) => teile.add(find(f[0])));
  pruef(art + ': genau 15 Bauteile (Koerper mit Kopf ist EINES davon)', teile.size === 15, String(teile.size));
  /* Und das groesste Teil muss von der Schwanzwurzel bis zur Nasenspitze reichen. Waere der
   * Kopf wieder abgetrennt, endete es am Genick. */
  const zuTeil = new Map();
  m.faces.forEach((f) => {
    const w = find(f[0]);
    if (!zuTeil.has(w)) zuTeil.set(w, []);
    f.forEach((i) => zuTeil.get(w).push(i));
  });
  let groesstes = null;
  zuTeil.forEach((idx) => { if (!groesstes || idx.length > groesstes.length) groesstes = idx; });
  let xmax = -1e9;
  groesstes.forEach((i) => { const x = m.pts[i][0]; if (x > xmax) xmax = x; });
  /* Der Vergleich geht gegen die LETZTE KOPFSTATION, nicht gegen das aeusserste Modellteil.
   * Der Nasenspiegel ist absichtlich eine eigene Kugel und ragt darueber hinaus - wer gegen
   * ihn prueft, misst nicht, ob der Kopf am Hals sitzt, sondern nur, dass es eine Nase gibt.
   * (Erster Entwurf dieser Pruefung, 12.08.2026: sie schlug an allen vier Arten fehl,
   * obwohl alle vier Koerper vollstaendig zusammenhingen.) */
  const b = T.BAU[art];
  const kopfSpitze = b.kopf[b.kopf.length - 1][0] - m.mitte[0];
  pruef(art + ': der Koerper reicht durchgehend bis zur Kopfspitze', xmax > kopfSpitze - 0.02,
    'Koerper bis ' + xmax.toFixed(2) + ', Kopfspitze bei ' + kopfSpitze.toFixed(2));
});

/* ================================================================================
 * 11. VERHAELTNISSE — Hund und Katze duerfen nicht dasselbe Tier sein
 * ============================================================================== */
block('11. Hund und Katze sind unterscheidbar');
function masse(art) {
  const b = T.BAU[art];
  const kopfL = b.kopf[b.kopf.length - 1][0] - b.kopf[0][0];
  const kopfB = Math.max.apply(null, b.kopf.map((k) => k[3]));
  const brustB = Math.max.apply(null, b.rumpf.map((k) => k[3]));
  const brustT = Math.max.apply(null, b.rumpf.map((k) => k[1] - k[2]));
  /* Die Taille ist die schmalste Rumpfstelle ZWISCHEN den Gliedmassen - dort und nur dort
   * ist sie ein Artmerkmal; vor der Schulter und hinter der Huefte wird jedes Tier schmal. */
  const zwischen = b.rumpf.filter((k) => k[0] < b.vorn.ellbogen[0] && k[0] > b.hinten.knie[0]);
  const taille = Math.min.apply(null, zwischen.map((k) => k[3]));
  /* Schnauze: ab der Station, an der die Kopfbreite unter 60 % der groessten faellt. */
  let schnauzeAb = b.kopf[b.kopf.length - 1][0];
  for (let i = 0; i < b.kopf.length; i++) if (b.kopf[i][3] < 0.6 * kopfB) { schnauzeAb = b.kopf[i][0]; break; }
  return {
    kopfRund: (2 * kopfB) / kopfL,
    kopfZuBrust: kopfB / brustB,
    schnauze: (b.kopf[b.kopf.length - 1][0] - schnauzeAb) / kopfL,
    taille: taille / brustB,
    kopfHoch: Math.max.apply(null, b.kopf.map((k) => k[1] - k[2])) / brustT
  };
}
{
  const H = masse('hund'), K = masse('katze');
  const zeig = (n, a, b) => console.log('    ' + n.padEnd(24) + ' Hund ' + a.toFixed(2) + '   Katze ' + b.toFixed(2));
  zeig('Kopfbreite/Kopflaenge', H.kopfRund, K.kopfRund);
  zeig('Schnauzenanteil', H.schnauze, K.schnauze);
  zeig('Taille/Brustbreite', H.taille, K.taille);
  zeig('Kopfbreite/Brustbreite', H.kopfZuBrust, K.kopfZuBrust);
  zeig('Kopfhoehe/Brusttiefe', H.kopfHoch, K.kopfHoch);
  pruef('der Katzenschaedel ist deutlich runder als der Hundeschaedel',
    K.kopfRund > H.kopfRund * 1.35, K.kopfRund.toFixed(2) + ' vs ' + H.kopfRund.toFixed(2));
  pruef('die Katze hat eine deutlich kuerzere Schnauze',
    K.schnauze < H.schnauze * 0.7, K.schnauze.toFixed(2) + ' vs ' + H.schnauze.toFixed(2));
  pruef('die Katze ist in der Taille staerker aufgezogen',
    K.taille < H.taille * 0.95, K.taille.toFixed(2) + ' vs ' + H.taille.toFixed(2));
  pruef('der Katzenkopf ist im Verhaeltnis zum Rumpf groesser',
    K.kopfZuBrust > H.kopfZuBrust * 1.15, K.kopfZuBrust.toFixed(2) + ' vs ' + H.kopfZuBrust.toFixed(2));
  /* Und das Ohr: beim Hund liegt es an (Haengeohr), bei der Katze steht es weit ueber den
   * Schaedel hinaus. Gemessen als Ohrspitze ueber der hoechsten Kopfstelle. */
  const ueber = (art) => {
    const b = T.BAU[art];
    const kopfOben = Math.max.apply(null, b.kopf.map((k) => k[1]));
    return (Math.max.apply(null, b.ohr.map((o) => o[1])) - kopfOben) / (b.kopf[b.kopf.length - 1][0] - b.kopf[0][0]);
  };
  console.log('    Ohrspitze ueber dem Kopf   Hund ' + ueber('hund').toFixed(2) + '   Katze ' + ueber('katze').toFixed(2));
  pruef('das Katzenohr ragt weit ueber den Schaedel, das Hundeohr nicht',
    ueber('katze') > 0.4 && ueber('hund') < 0.1,
    'Katze ' + ueber('katze').toFixed(2) + ', Hund ' + ueber('hund').toFixed(2));
  pruef('das Kaninchen hat die laengsten Ohren von allen',
    ueber('kaninchen') > ueber('katze') * 1.2, ueber('kaninchen').toFixed(2));
}

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
