'use strict';
/*
 * schluessel-erzeugen.js — das Ed25519-Schluesselpaar fuer den Update-Kanal anlegen.
 *
 * WARUM ES DIESE DATEI GIBT (13.08.2026):
 * Der Update-Kanal war bis heute NICHT signiert. Manifest, zipUrl und sha256 kamen aus
 * DERSELBEN Datei auf GitHub Pages - die Pruefsumme belegte damit nur, dass die Zip
 * unterwegs nicht beschaedigt wurde, nicht dass sie von der richtigen Stelle stammt. Wer
 * das Konto uebernimmt, aendert Manifest und Pruefsumme in einem Zug, und jede Praxis holt
 * sich beim naechsten Klick fremden Code auf den Rechner, an dem ein narkotisiertes Tier
 * haengt. Das ist ein Angriff fuer heute, mit einem gewoehnlichen Rechner.
 *
 * DIE TRENNUNG, AUF DIE ALLES ANKOMMT:
 *   PRIVATER Schluessel  - bleibt beim Freigebenden, LOKAL, ausserhalb beider Git-Repos.
 *                          Er wird nie hochgeladen, nie eingecheckt, nie im Paket verteilt.
 *   OEFFENTLICHER Schl.  - wird MIT DEM PAKET ausgeliefert (updater/release-key.pub) und
 *                          ist damit schon auf dem Praxis-PC, bevor das erste Update kommt.
 *
 * WARUM DER OEFFENTLICHE SCHLUESSEL NICHT UEBER DEN KANAL NACHGELADEN WERDEN DARF:
 * Sonst tauscht ein Angreifer, der den Kanal beherrscht, einfach BEIDES aus - seinen
 * Schluessel und seine Signatur - und die Pruefung geht auf. Ein Schluessel, den man vom
 * Angreifer holt, prueft nichts. Deshalb liegt er im Paket und wird beim Update mitkopiert.
 *
 * Start:  node tools/schluessel-erzeugen.js
 *         node tools/schluessel-erzeugen.js --ziel "D:\\Schluessel\\vetstation.pem"
 *
 * Der private Schluessel landet standardmaessig unter
 *     %USERPROFILE%\.vetstation-keys\release-ed25519-priv.pem
 * also NICHT im Projektordner. Das ist Absicht: was im Projektordner liegt, wandert
 * frueher oder spaeter in ein Repo oder in ein Paket.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const OEFFENTLICH = path.join(__dirname, '..', 'updater', 'release-key.pub');
const STANDARD_PRIVAT = path.join(os.homedir(), '.vetstation-keys', 'release-ed25519-priv.pem');

function arg(name) {
  const i = process.argv.indexOf(name);
  return (i >= 0 && process.argv[i + 1]) ? process.argv[i + 1] : null;
}

const zielPrivat = arg('--ziel') || STANDARD_PRIVAT;
const erzwingen = process.argv.indexOf('--ueberschreiben') >= 0;

console.log('\nVetStation - Schluesselpaar fuer den Update-Kanal\n');

/* EIN VORHANDENES PAAR WIRD NICHT STILL ERSETZT. Wer den privaten Schluessel ueberschreibt,
 * sperrt damit JEDE Station aus, die den alten oeffentlichen Schluessel mitbekommen hat -
 * sie lehnt danach jedes Update ab, und zwar zu Recht. Das darf kein Versehen sein. */
if (fs.existsSync(zielPrivat) && !erzwingen) {
  console.log('  Es gibt bereits einen privaten Schluessel:');
  console.log('    ' + zielPrivat);
  console.log('');
  console.log('  Er wird NICHT ueberschrieben. Ein neues Paar sperrt jede Station aus, die den');
  console.log('  alten oeffentlichen Schluessel mitbekommen hat - sie lehnt danach jedes Update');
  console.log('  ab, bis sie ueber VetStation-Setup.exe neu eingerichtet wird.');
  console.log('');
  console.log('  Wirklich ein neues Paar:  node tools/schluessel-erzeugen.js --ueberschreiben');
  process.exit(1);
}

const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');

const privPem = privateKey.export({ type: 'pkcs8', format: 'pem' });
const pubPem = publicKey.export({ type: 'spki', format: 'pem' });

fs.mkdirSync(path.dirname(zielPrivat), { recursive: true });
fs.writeFileSync(zielPrivat, privPem, { mode: 0o600 });
fs.writeFileSync(OEFFENTLICH, pubPem);

/* Der Fingerabdruck macht die zwei Haelften vergleichbar, ohne den privaten Schluessel
 * anzufassen: derselbe Wert steht spaeter in der Signaturpruefung und im Freigabetest. */
const fp = crypto.createHash('sha256').update(pubPem).digest('hex').slice(0, 16);

console.log('  PRIVAT (bleibt bei Ihnen, niemals hochladen):');
console.log('    ' + zielPrivat);
console.log('');
console.log('  OEFFENTLICH (gehoert ins Repo und ins Paket):');
console.log('    ' + OEFFENTLICH);
console.log('');
console.log('  Fingerabdruck des oeffentlichen Schluessels: ' + fp);
console.log('');
console.log('  NAECHSTE SCHRITTE');
console.log('   1. updater/release-key.pub einchecken - er MUSS mit dem Paket ausgeliefert werden.');
console.log('   2. Den privaten Schluessel sichern (Passwortmanager, verschluesselter Stick).');
console.log('      OHNE IHN LASSEN SICH KEINE UPDATES MEHR FREIGEBEN. Es gibt keine Hintertuer -');
console.log('      genau das ist der Sinn der Sache.');
console.log('   3. Beim naechsten Bau signieren:  node tools/paket-signieren.js');
console.log('');
