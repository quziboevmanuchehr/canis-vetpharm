'use strict';
/*
 * mobil-test.js — nichts darf auf dem Handy ueber den Rahmen hinausragen.
 *
 * WARUM ES DIESEN TEST GIBT (gemessen 08.08.2026):
 * Auf einem 375 px breiten Schirm war die Seite mit geoeffnetem EKG 483 px breit. Man konnte
 * sie seitlich wegschieben, und Teile der Bedienung standen ausserhalb des Bildes. Vier
 * Ursachen, alle nach demselben Muster:
 *
 *   1. .ekg-body stand zweispaltig - die Messwertespalte hatte eine feste Grundbreite, die
 *      auf einem Handy nie aufgeht (273 + 210 = 483 px).
 *   2. Ein INLINE-Stil im Markup, style="flex:0 0 auto;min-width:auto", nagelte eine
 *      Knopfleiste auf 455 px fest. Ein Inline-Stil laesst sich von keiner Bildschirmregel
 *      mehr einholen, ohne !important zu schreiben.
 *   3. Ein Auswahlfeld mit flex:1, aber ohne min-width:0. Flex-Kinder haben von Haus aus
 *      min-width:auto und schrumpfen deshalb NIE unter ihre breiteste Option - hier
 *      "Routine (stabil, ASA I-II)" mit 313 px.
 *   4. .vp-tile hatte 94 px Mindestbreite, brauchte aber 118 - der rechte Stellerknopf stand
 *      15 px ausserhalb seiner eigenen Kachel.
 *
 * WAS DIESER TEST KANN UND WAS NICHT: Er prueft den QUELLTEXT auf genau diese vier
 * Fehlerklassen. Er kann KEIN Layout ausmessen - dafuer braucht es einen Browser. Die
 * Messung wurde von Hand ueber 13 Bildschirmbreiten (320 bis 1024 px) gefahren und war
 * ueberall sauber; dieser Test haelt fest, dass die Ursachen nicht zurueckkehren.
 *
 * Start: node tools/mobil-test.js
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const QUELLE = fs.readFileSync(path.join(ROOT, 'ui', 'app', 'index.html'), 'utf8');
/* Fuer Negativpruefungen den Code OHNE Kommentare nehmen - sonst schlaegt die Pruefung an
 * der Begruendung an, die danebensteht (in dieser Sitzung zweimal passiert). */
const CODE = QUELLE.replace(/<!--[\s\S]*?-->/g, ' ').replace(/\/\*[\s\S]*?\*\//g, ' ');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Handyansicht: nichts ragt aus dem Rahmen\n');

/* ================================================================================ */
block('1. EKG-Fenster wird auf schmalen Schirmen einspaltig');
const mq700 = /@media\(max-width:700px\)\{([\s\S]*?)\n\}/.exec(QUELLE);
pruef('es gibt eine Regel fuer bis 700 px', !!mq700);
if (mq700) {
  const r = mq700[1];
  pruef('.ekg-body steht darin untereinander', /\.ekg-body\{[^}]*flex-direction:\s*column/.test(r),
    'flex-direction:column fehlt');
  pruef('.ekg-side nimmt die volle Breite', /\.ekg-side\{[^}]*width:\s*100%/.test(r));
  pruef('.ekg-side hat keine feste Grundbreite mehr', /\.ekg-side\{[^}]*flex:\s*0 0 auto/.test(r));
  pruef('.ekg-main darf schrumpfen (min-width:0)', /\.ekg-main\{[^}]*min-width:\s*0/.test(r));
  /* Die Klammer: selbst wenn kuenftig etwas zu breit wird, darf es nicht aus dem Rahmen. */
  pruef('#ekgOverlay ist auf die Sichtbreite geklammert', /#ekgOverlay\{[^}]*max-width:\s*100vw/.test(r));
  pruef('#ekgOverlay schneidet Ueberstand ab statt ihn herausragen zu lassen',
    /#ekgOverlay\{[^}]*overflow-x:\s*clip/.test(r));
  /* clip und nicht hidden: hidden reisst die senkrechte Achse mit und macht aus der
   * Ueberlagerung ein zweites Rollfeld. */
  pruef('dafuer wird clip benutzt, nicht hidden', !/#ekgOverlay\{[^}]*overflow-x:\s*hidden/.test(r));
}

/* ================================================================================ */
block('2. keine festgenagelten Inline-Stile im Markup');
/* Das ist die gefaehrlichste Klasse: eine Bildschirmregel kann sie nicht einholen. */
const inline = CODE.match(/style="[^"]*(?:min-width:\s*auto|flex:\s*0 0 auto)[^"]*"/g) || [];
pruef('kein style="..." nagelt flex:0 0 auto oder min-width:auto fest',
  inline.length === 0, inline.slice(0, 3).join(' | '));
pruef('die Schalterzelle benutzt eine Klasse statt eines Inline-Stils',
  /class="gw gw-schalter"/.test(CODE));
pruef('und die Klasse hat eine Regel fuer schmale Schirme',
  /\.gwahl \.gw\.gw-schalter\{[^}]*flex:\s*1 1 100%/.test(QUELLE));

/* ================================================================================ */
block('3. Flex-Kinder duerfen unter ihre Inhaltsbreite schrumpfen');
pruef('.vr-pick select hat min-width:0', /\.vr-pick select\{[^}]*min-width:\s*0/.test(CODE),
  'ohne min-width:0 sperrt die breiteste Option das Schrumpfen');
pruef('.vr-pick bricht um', /\.vr-pick\{[^}]*flex-wrap:\s*wrap/.test(CODE));
pruef('.ck-schalter bricht um', /\.ck-schalter\{[^}]*flex-wrap:\s*wrap/.test(CODE));
pruef('.ck-schalter ist auf 100% geklammert', /\.ck-schalter\{[^}]*max-width:\s*100%/.test(CODE));

/* ================================================================================ */
block('4. Kacheln sind so breit wie ihr Inhalt');
const tile = /\.vp-tile\{[^}]*min-width:\s*(\d+)px/.exec(CODE);
pruef('.vp-tile hat eine Mindestbreite', !!tile);
if (tile) {
  /* 2 Stellerknoepfe je 30 px + 2 Abstaende je 4 px + 8 px Polster je Seite + 1 px Rahmen
   * je Seite = 108 px, plus Platz fuer den Wert dazwischen. */
  const noetig = 30 + 30 + 4 + 4 + 8 + 8 + 2;
  pruef('sie reicht fuer zwei Stellerknoepfe und den Wert (>= ' + noetig + ' px)',
    +tile[1] >= noetig, 'ist ' + tile[1] + ' px');
}

/* ================================================================================ */
block('5. sehr schmale Schirme (bis 480 px)');
const mq480 = /@media\(max-width:480px\)\{([\s\S]*?)\n\}/.exec(QUELLE);
pruef('es gibt eine Regel fuer bis 480 px', !!mq480);
if (mq480) {
  const r = mq480[1];
  pruef('die Kopfleiste bricht um', /\.actions\{[^}]*flex-wrap:\s*wrap/.test(r));
  pruef('.cockpit darf schrumpfen', /\.cockpit\{[^}]*min-width:\s*0/.test(r));
  pruef('.gwahl .gw darf schrumpfen', /\.gwahl \.gw\{[^}]*min-width:\s*0/.test(r));
}

/* ================================================================================ */
block('6. die Fern-Web-App traegt denselben Stand');
/* Sie wird aus derselben Datei gebaut. Laeuft der Bau nicht, hat das Handy die alte
 * Fassung - und genau dort wurde der Fehler gemeldet. */
const web = path.join(ROOT, '..', '..', 'canis-vetpharm', 'canis-anaesthesie', 'index.html');
if (!fs.existsSync(web)) {
  console.log('  (Web-Repo liegt nicht daneben - nichts zu vergleichen)');
} else {
  const w = fs.readFileSync(web, 'utf8');
  pruef('Web-App kennt die 700-px-Regel', /@media\(max-width:700px\)/.test(w));
  pruef('Web-App kennt die 480-px-Regel', /@media\(max-width:480px\)/.test(w));
  pruef('Web-App hat den Inline-Stil ebenfalls nicht mehr',
    (w.replace(/<!--[\s\S]*?-->/g, ' ').match(/style="[^"]*min-width:\s*auto[^"]*"/g) || []).length === 0);
  pruef('Web-App hat .vp-tile mit der groesseren Mindestbreite',
    /\.vp-tile\{[^}]*min-width:\s*118px/.test(w));
}

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
