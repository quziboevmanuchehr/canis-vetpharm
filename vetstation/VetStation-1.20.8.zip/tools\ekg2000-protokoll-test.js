'use strict';
/*
 * ekg2000-protokoll-test.js — haelt fest, was am 16.08.2026 aus dem Herstellerprogramm
 * GEMESSEN wurde, und was ausdruecklich NICHT bekannt ist.
 *
 * WARUM ES DIESEN TEST GIBT:
 * Die Zahlen in bridge/src/ekg2000-protokoll.js sehen aus wie Einstellungen, die man
 * "mal eben anpasst" — 19200, gerade Paritaet, Byte 0x10. Sie sind aber Fundstellen aus
 * einem fremden Maschinencode. Wer eine davon aendert, ohne die Fundstelle zu kennen,
 * bricht das Anmeldegespraech, und das Fehlerbild ist "Geraet antwortet nicht" — also
 * genau das, wonach niemand im Protokollmodul sucht. Dieser Test macht die Zahlen
 * unbeweglich und nennt bei jedem Fehlschlag die Fundstelle.
 *
 * DIE WICHTIGSTE PRUEFUNG STEHT AM ENDE (Block 6): dass der Adapter weiterhin KEINE
 * Messwerte behauptet. Solange der Aufbau des Datenstroms nicht belegt ist, waere eine
 * gemeldete Kurve Rauschen, dem niemand misstraut.
 *
 * Start: node tools/ekg2000-protokoll-test.js
 */
const P = require('../bridge/src/ekg2000-protokoll.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Anmeldegespraech des EKG 2000\n');

block('1. Leitungsparameter (EKG_V.exe VA 0x675489 / 0x66B8B8, Monitor.exe VA 0x4DA414)');
pruef('Anmeldung mit 19200 Baud', P.LEITUNG_ANMELDUNG.baud === 19200, String(P.LEITUNG_ANMELDUNG.baud));
pruef('Betrieb mit 38400 Baud', P.LEITUNG_BETRIEB.baud === 38400, String(P.LEITUNG_BETRIEB.baud));
[['Anmeldung', P.LEITUNG_ANMELDUNG], ['Betrieb', P.LEITUNG_BETRIEB]].forEach(([n, l]) => {
  pruef(n + ': 8 Datenbits (DCB+18 = 8)', l.datenbits === 8, String(l.datenbits));
  /* Das ist die Zahl, die am ehesten "korrigiert" wird: 8N1 ist ueberall die Vorgabe.
   * Hier ist es 8E1, und zwar weil beide Aufrufer die 2 (EVENPARITY) uebergeben. */
  pruef(n + ': GERADE Paritaet (Argument 2 = EVENPARITY)', l.paritaet === 'e', String(l.paritaet));
  pruef(n + ': 1 Stoppbit (DCB+20 = ONESTOPBIT)', l.stopbits === 1, String(l.stopbits));
});

block('2. Die Kennungsabfrage (Monitor.exe VA 0x4DAA03, Methode VerzeCDS)');
pruef('Anfragebyte ist 0x10', P.ANFRAGE_KENNUNG === 0x10, '0x' + P.ANFRAGE_KENNUNG.toString(16));
pruef('"noch nicht bereit" ist 0xAF', P.ANTWORT_NICHT_BEREIT === 0xaf, '0x' + P.ANTWORT_NICHT_BEREIT.toString(16));
pruef('50 Versuche wie im Original (mov ebp,50)', P.VERSUCHE_MAX === 50, String(P.VERSUCHE_MAX));

block('3. Die Antwortbytes werden richtig gedeutet');
const k20 = P.deuteKennung(0x20);
pruef('0x20 = Bauart 1', k20.bereit && k20.bauart === 1, JSON.stringify(k20.bauart));
pruef('0x20 waehlt EKG_V_C1.BIN / MONITOR.BIN',
  k20.firmware && k20.firmware.ruhe === 'EKG_V_C1.BIN' && k20.firmware.monitor === 'MONITOR.BIN',
  JSON.stringify(k20.firmware));
[0x21, 0x22].forEach((b) => {
  const k = P.deuteKennung(b);
  pruef('0x' + b.toString(16) + ' = Bauart 2', k.bereit && k.bauart === 2, JSON.stringify(k.bauart));
  pruef('0x' + b.toString(16) + ' waehlt EKG_VC11.BIN / MONITOR2.BIN',
    k.firmware && k.firmware.ruhe === 'EKG_VC11.BIN' && k.firmware.monitor === 'MONITOR2.BIN',
    JSON.stringify(k.firmware));
});

const kaf = P.deuteKennung(0xaf);
pruef('0xAF ist KEIN Fehler, sondern "noch nicht bereit"', kaf.bekannt === true && kaf.bereit === false, JSON.stringify(kaf));
/* Das Original wertet ein zurueckgespiegeltes 0x10 ausdruecklich als Misserfolg (setne bl
 * nach cmp byte [edi],0x10). Wer das als Erfolg deutet, meldet jede gebrueckte Leitung als
 * EKG - das waere die haesslichste Sorte Falschmeldung, weil sie ohne Geraet auftritt. */
const k10 = P.deuteKennung(0x10);
pruef('das eigene Echo 0x10 gilt NICHT als Geraet', k10.bereit === false, JSON.stringify(k10));
pruef('und die Meldung erklaert, was das heisst', /zurueckspiegelt|Echo|Anfragebyte/i.test(k10.urteil), k10.urteil);

block('4. Unbekanntes wird NICHT geraten');
[0x00, 0x23, 0x41, 0xff].forEach((b) => {
  const k = P.deuteKennung(b);
  pruef('0x' + b.toString(16).toUpperCase() + ' ergibt keine erfundene Bauart',
    k.bauart === null && k.bereit === false, JSON.stringify(k.bauart));
});
const kleer = P.deuteKennung(null);
pruef('gar keine Antwort ergibt ein ehrliches Urteil', kleer.bereit === false && /keine Antwort/i.test(kleer.urteil), kleer.urteil);

block('5. Firmware-Aufteilung (LoadPrgToCDS: 16-Byte-Bloecke ab 0x8000)');
pruef('Startadresse 0x8000', P.FIRMWARE_STARTADRESSE === 0x8000, '0x' + P.FIRMWARE_STARTADRESSE.toString(16));
pruef('Blockgroesse 16', P.FIRMWARE_BLOCK === 16, String(P.FIRMWARE_BLOCK));
pruef('Bootlader-Anfrage ist 3A 46 80', P.BOOTLADER_ANFRAGE.toString('hex') === '3a4680', P.BOOTLADER_ANFRAGE.toString('hex'));
pruef('erwartete Antwort "F_1.0.1" (7 Zeichen, wie ReadText 7)',
  P.BOOTLADER_ANTWORT === 'F_1.0.1' && P.BOOTLADER_ANTWORT.length === 7, P.BOOTLADER_ANTWORT);

/* 737 Byte ist die echte Groesse von MONITOR.BIN aus dem Archiv: 46 volle Bloecke und ein
 * Rest von einem einzigen Byte. Genau dieser Rest ist die Stelle, an der eine Schleife
 * "solange >= 16" gern etwas verliert. */
const b737 = P.firmwareBloecke(737);
pruef('737 Byte ergeben 47 Bloecke', b737.length === 47, String(b737.length));
pruef('der letzte Block ist 1 Byte lang', b737[b737.length - 1].laenge === 1, String(b737[b737.length - 1].laenge));
pruef('die Adressen laufen von 0x8000 lueckenlos hoch',
  b737[0].adresse === 0x8000 && b737[1].adresse === 0x8010
    && b737[46].adresse === 0x8000 + 46 * 16,
  b737.slice(0, 3).map((x) => '0x' + x.adresse.toString(16)).join(','));
pruef('die Bloecke decken die Datei vollstaendig ab',
  b737.reduce((s, x) => s + x.laenge, 0) === 737,
  String(b737.reduce((s, x) => s + x.laenge, 0)));
const b32 = P.firmwareBloecke(32);
pruef('eine glatt teilbare Laenge ergibt keinen leeren Restblock', b32.length === 2, String(b32.length));
pruef('Laenge 0 ergibt gar keinen Block', P.firmwareBloecke(0).length === 0);

block('6. Der Adapter behauptet weiterhin KEINE Messwerte');
/* DIE WICHTIGSTE PRUEFUNG DIESER DATEI. Der Aufbau des Datenstroms ist nicht belegt und das
 * Geraet braucht ausserdem die Firmware des Herstellers, die nicht im Paket liegt. Wer hier
 * "messwerte: true" eintraegt, ohne beides geloest zu haben, baut eine Kurve aus Rauschen. */
const { EKG2000Adapter } = require('../bridge/src/adapters/ekg2000.js');
const still = { info() {}, warn() {}, error() {} };
const a = new EKG2000Adapter({ id: 'test', port: 'COM9' }, { log: still, emit() {} });
const st = a.status();
pruef('ohne Eichung ist kalibriert false', st.kalibriert === false, String(st.kalibriert));
pruef('ohne Antwort gilt der Adapter nicht als verbunden', st.verbunden === false, String(st.verbunden));
pruef('und liefert noch keine Kurve', st.kurve === false, String(st.kurve));
pruef('der Adapter meldet sich als EKG, nicht als Monitor',
  a.describe().role === 'ekg', a.describe().role);
/* Und die Gegenprobe: der Adapter muss ueberhaupt Kennungen deuten koennen. Ein Test, der
 * nur "meldet nichts" prueft, waere auch dann gruen, wenn der Adapter gar nichts taete.
 * _anmeldeBytes statt _daten, weil _daten seit dem Messbetrieb nach Zustand verzweigt. */
a._anmeldeBytes(Buffer.from([P.ANTWORT_NICHT_BEREIT, 0x21]));
pruef('nach 0xAF und 0x21 ist die Bauart 2 erkannt', a.status().bauart === 2, String(a.status().bauart));
pruef('und die Kennung wird im Klartext gefuehrt', a.status().kennung === '0x21', String(a.status().kennung));
pruef('der Zustand geht auf "firmware" ueber', a.zustand === 'firmware', a.zustand);
a.dispose();

block('7. der Rahmenleser (Sync 0x80, vorzeichenbehaftete Differenzen, Aufsummieren)');
pruef('Synchronbyte ist 0x80', P.SYNC === 0x80, '0x' + P.SYNC.toString(16));
pruef('Rahmen mit 8 Kanaelen ist 9 Byte lang', P.rahmenLaenge(8) === 9, String(P.rahmenLaenge(8)));
pruef('Rahmen mit 3 Kanaelen ist 4 Byte lang', P.rahmenLaenge(3) === 4, String(P.rahmenLaenge(3)));

/* DIE PRUEFUNG, AUF DIE ES ANKOMMT. Die Bytes sind DIFFERENZEN. Wer sie als Messwerte
 * zeichnet, bekommt eine zappelnde Linie, die wie ein verrauschtes EKG aussieht und keins
 * ist. Hier steigt der Kanal um +10 je Rahmen: der Messwert muss also 10, 20, 30 lauten. */
let L = new P.Rahmenleser(3);
let r = L.schiebe(Buffer.from([0x80, 10, 0, 0, 0x80, 10, 0, 0, 0x80, 10, 0, 0]));
pruef('drei Rahmen gelesen', r.length === 3, String(r.length));
pruef('die Differenzen werden AUFSUMMIERT (10, 20, 30)',
  r[0][1] === 10 && r[1][1] === 20 && r[2][1] === 30,
  r.map((x) => x[1]).join(','));

/* Negative Differenzen: 0xF6 ist -10, nicht 246. Ein vorzeichenloses Lesen ergaebe eine
 * Kurve, die nur nach oben laeuft - und im Zweifel gar nicht auffiele. */
L = new P.Rahmenleser(3);
r = L.schiebe(Buffer.from([0x80, 0xf6, 0, 0, 0x80, 0xf6, 0, 0]));
pruef('0xF6 ist -10, nicht 246', r[0][1] === -10 && r[1][1] === -20, r.map((x) => x[1]).join(','));

/* Drei Kanaele: die uebrigen fuenf bleiben 0, wie im Original (c6 07 00 fuer 5 Bytes). */
L = new P.Rahmenleser(3);
r = L.schiebe(Buffer.from([0x80, 1, 2, 3]));
pruef('bei 3 Kanaelen bleiben die Kanaele 4..8 auf 0',
  r[0][4] === 0 && r[0][8] === 0, JSON.stringify(r[0]));
pruef('und die drei Extremitaetenkanaele stimmen',
  r[0][1] === 1 && r[0][2] === 2 && r[0][3] === 3, JSON.stringify(r[0].slice(1, 4)));

/* Einrasten: ein Strom, der mitten im Rahmen beginnt, muss sich wiederfinden. Wer bei einem
 * Fehltreffer einen GANZEN Rahmen ueberspringt, rastet nie wieder ein. */
L = new P.Rahmenleser(3);
r = L.schiebe(Buffer.from([0x11, 0x22, 0x80, 5, 5, 5, 0x80, 5, 5, 5]));
pruef('ein versetzt beginnender Strom rastet ein', r.length === 2, String(r.length));
pruef('und die Vorlaufbytes werden gezaehlt, nicht verschwiegen', L.verworfen === 2, String(L.verworfen));

/* Zerstueckelter Empfang: TCP und serielle Anschluesse liefern beliebige Haeppchen. */
L = new P.Rahmenleser(8);
let n = 0;
[[0x80, 1], [1, 1, 1], [1, 1, 1, 1, 0x80], [2, 2, 2, 2, 2, 2, 2, 2]].forEach((teil) => {
  n += L.schiebe(Buffer.from(teil)).length;
});
pruef('ueber vier Haeppchen verteilt kommen 2 Rahmen an', n === 2, String(n));
pruef('nach 8 Kanaelen steht Kanal 1 auf 3', L.stand[1] === 3, String(L.stand[1]));

block('7b. welche Ausfuehrung steckt da? — wird gemessen, nicht gefragt');
/*
 * Das Handbuch kennt zwei Ausfuehrungen mit VERSCHIEDEN LANGEN Rahmen (4 bzw. 9 Byte). Wer
 * die falsche annimmt, findet das Synchronbyte nie an der erwarteten Stelle - und im
 * schlimmsten Fall entsteht eine Kurve aus versetzt zusammengesetzten Kanaelen, die
 * plausibel aussieht. Deshalb wird die Laenge aus dem Strom selbst bestimmt.
 */
function strom(kanaele, rahmen, startwert) {
  const L = 1 + kanaele;
  const b = Buffer.alloc(L * rahmen);
  for (let f = 0; f < rahmen; f++) {
    b[f * L] = 0x80;
    for (let k = 1; k <= kanaele; k++) {
      /* Bewusst wechselnde Werte, damit die Erkennung nicht an einer Konstanten haengt. */
      b[f * L + k] = ((startwert + f * 3 + k * 7) % 251) - 125 & 0xff;
    }
  }
  return b;
}
let e = P.kanaeleErkennen(strom(8, 300, 0));
pruef('ein 8-Kanal-Strom wird als 8 erkannt', e.kanaele === 8 && e.sicher === true, JSON.stringify(e.kanaele));
e = P.kanaeleErkennen(strom(3, 500, 5));
pruef('ein 3-Kanal-Strom wird als 3 erkannt', e.kanaele === 3 && e.sicher === true, JSON.stringify(e.kanaele));
pruef('und das Urteil nennt die Zahlen', /%/.test(e.urteil), e.urteil.slice(0, 50));
/* Reines Rauschen darf KEINE Ausfuehrung ergeben. Ein Erkenner, der immer etwas sagt, ist
 * schlimmer als keiner: er stellt den Leser auf eine erfundene Rahmenlaenge ein. */
const rausch = Buffer.alloc(2000);
for (let i = 0; i < rausch.length; i++) rausch[i] = (i * 37 + 11) % 256;
e = P.kanaeleErkennen(rausch);
pruef('Rauschen ergibt KEINE Ausfuehrung', e.kanaele === null && e.sicher === false, JSON.stringify(e.kanaele));
pruef('und sagt ausdruecklich, dass nichts angenommen wird', /nichts angenommen/i.test(e.urteil));
e = P.kanaeleErkennen(Buffer.alloc(50));
pruef('zu wenig Daten ergeben keine Aussage', e.kanaele === null && /Zu wenig/i.test(e.urteil));
/* Und die Probe aufs Exempel: ein 3-Kanal-Strom darf NICHT als 8 durchgehen. Genau diese
 * Verwechslung erzeugt die plausibel aussehende Falschkurve. */
e = P.kanaeleErkennen(strom(3, 400, 9));
pruef('ein 3-Kanal-Strom wird NICHT faelschlich als 8 gelesen', e.kanaele !== 8, String(e.kanaele));
e = P.kanaeleErkennen(strom(8, 400, 9));
pruef('ein 8-Kanal-Strom wird NICHT faelschlich als 3 gelesen', e.kanaele !== 3, String(e.kanaele));

block('8. die Abtastrate wird GEMESSEN, nicht angenommen');
const RM = new P.Ratenmesser();
RM.zaehle(0, 1000);                       /* erster Block eicht nur die Uhr */
RM.zaehle(100, 1400);
pruef('nach 100 Rahmen wird noch NICHTS behauptet', RM.hertz() === null, String(RM.hertz()));
RM.zaehle(900, 5000);                     /* 1000 Rahmen in 4,0 s = 250 Hz */
const hz = RM.hertz();
pruef('nach genug Daten kommt eine Zahl', hz !== null && Math.abs(hz - 250) < 1, String(hz));
const g = P.gerundet(249.6);
pruef('249,6 Hz rastet auf 250 Hz ein', g.hz === 250 && g.eingerastet === true, JSON.stringify(g));
const g2 = P.gerundet(377.0);
/* 377 liegt von keiner ueblichen Rate naeher als 2 % entfernt - dann gilt der gemessene
 * Wert. Einzurasten waere hier eine Behauptung, die niemand belegen kann. */
pruef('377 Hz rastet NICHT ein, sondern bleibt 377', g2.hz === 377 && g2.eingerastet === false, JSON.stringify(g2));
pruef('ohne Messung gibt es keine Rate', P.gerundet(null) === null);

block('9. die Firmware wird geprueft, nicht blind geschrieben');
const FW = require('../bridge/src/ekg2000-firmware.js');
const os = require('os'), fs2 = require('fs'), path2 = require('path');
const tmp = path2.join(os.tmpdir(), 'vetstation-fw-test');
try { fs2.rmSync(tmp, { recursive: true, force: true }); } catch (_) {}
fs2.mkdirSync(path2.join(tmp, 'firmware', 'ekg2000'), { recursive: true });
const fwOrdner = path2.join(tmp, 'firmware', 'ekg2000');
/* Eine Datei mit richtiger Groesse, aber OHNE Herstellerkennung. Genau so saehe eine
 * verwechselte oder beschaedigte Datei aus - und die darf nicht in einen Mikrocontroller. */
fs2.writeFileSync(path2.join(fwOrdner, 'MONITOR.BIN'), Buffer.alloc(737, 0x42));
let p1 = FW.pruefe(path2.join(fwOrdner, 'MONITOR.BIN'));
pruef('richtige Groesse, aber fehlende Kennung wird abgelehnt', p1.ok === false, p1.grund);
pruef('und der Grund nennt die Kennung', /Kennung/i.test(p1.grund || ''), p1.grund);
/* Halb kopiert: richtige Kennung, falsche Groesse. */
fs2.writeFileSync(path2.join(fwOrdner, 'MONITOR.BIN'), Buffer.concat([Buffer.alloc(100), Buffer.from('GRIMED')]));
p1 = FW.pruefe(path2.join(fwOrdner, 'MONITOR.BIN'));
pruef('eine zu kurze Datei wird abgelehnt', p1.ok === false && /Groesse/i.test(p1.grund), p1.grund);
/* Und eine gueltige. */
const echt = Buffer.alloc(737, 0xff); Buffer.from('GRIMED').copy(echt, 700);
fs2.writeFileSync(path2.join(fwOrdner, 'MONITOR.BIN'), echt);
p1 = FW.pruefe(path2.join(fwOrdner, 'MONITOR.BIN'));
pruef('eine gueltige Datei wird angenommen', p1.ok === true, p1.grund || '');
const fund = FW.suche(tmp);
pruef('sie wird im Ordner gefunden', !!fund.gefunden['MONITOR.BIN']);
pruef('die vier anderen werden als fehlend gemeldet', fund.fehlend.length === 4, fund.fehlend.join(','));
/* DIE WICHTIGSTE PRUEFUNG DIESES BLOCKS: fehlt die Datei der passenden Bauart, wird NICHT
 * die einer anderen genommen. Eine Firmware der falschen Bauart ist der eine Vorgang, der
 * das Geraet wirklich beschaedigen koennte. */
pruef('Bauart 1 Monitor wird geliefert', (FW.fuerBauart(fund, 1, 'monitor') || {}).name === 'MONITOR.BIN');
pruef('Bauart 2 Monitor wird NICHT ersatzweise mit Bauart 1 bedient',
  FW.fuerBauart(fund, 2, 'monitor') === null, JSON.stringify(FW.fuerBauart(fund, 2, 'monitor')));
pruef('und Ruhe-EKG bekommt keine Monitorfirmware untergeschoben',
  FW.fuerBauart(fund, 1, 'ruhe') === null);
pruef('die Anleitung nennt den Zielordner', /firmware/i.test(FW.anleitung(fund)));
try { fs2.rmSync(tmp, { recursive: true, force: true }); } catch (_) {}

block('10. ohne Eichung werden KEINE Millivolt behauptet');
/* Die Umrechnung Digit -> Mikrovolt steht nirgends. Bis sie am Eichzacken gemessen ist,
 * muss die Kurve als ungeeicht gekennzeichnet bleiben - sonst rechnet die EKG-Auswertung
 * mit Digits, als waeren es Millivolt, und jede Amplitude ist falsch. */
const a2 = new EKG2000Adapter({ id: 't2', port: 'COM9' }, { log: still, emit() {} });
pruef('kalibriert ist ohne eichungUvProDigit false', a2.status().kalibriert === false);
const a3 = new EKG2000Adapter({ id: 't3', port: 'COM9', eichungUvProDigit: 5 }, { log: still, emit() {} });
pruef('mit gesetzter Eichung wird kalibriert true', a3.status().kalibriert === true);
let rahmenAus = null;
const a4 = new EKG2000Adapter({ id: 't4', port: 'COM9' },
  { log: still, emit(x) { rahmenAus = x; } });
a4.leser = new P.Rahmenleser(3); a4.zustand = 'messen';
a4.proben.push([0, 100, 0, 0, 0, 0, 0, 0, 0]);
a4._ausgeben();
pruef('der gemeldete Rahmen traegt kalibriert:false',
  rahmenAus && rahmenAus.kurven.ekg.kalibriert === false);
pruef('und die Einheit heisst "digit", nicht "mV"',
  rahmenAus && rahmenAus.kurven.ekg.einheit === 'digit', rahmenAus ? rahmenAus.kurven.ekg.einheit : '-');
pruef('vitals bleibt leer (keine abgeleiteten Messwerte)',
  rahmenAus && Object.keys(rahmenAus.vitals).length === 0);
[a2, a3, a4].forEach((x) => x.dispose());

console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
