'use strict';
/*
 * ekg-analyse-test.js — die EKG-Auswertung misst, statt zu raten, und SCHWEIGT im Zweifel.
 *
 * HINTERGRUND (22.07.2026): Das LifeVet 10C liefert die EKG-Kurve als Abtastblock mit 256 Hz.
 * Die Station hat sie nie ausgewertet - sie zeichnete aus der gemeldeten Herzfrequenz eine
 * Musterkurve nach. Jede Aussage ueber QRS-Form, Extrasystolen oder ST-Strecke war damit unmoeglich.
 *
 * Beim Bau dieser Auswertung sind DREI Fehler aufgetreten, die alle in dieselbe Richtung gingen -
 * sie haetten einen kranken Patienten gesund aussehen lassen oder einen gesunden krank:
 *   1. Die Schwellenschaetzung nahm den Median NUR der positiven Huellwerte, also der aktiven
 *      QRS-Abschnitte statt der Ruhephasen. Die geschaetzte Grundlinie lag dadurch fast so hoch
 *      wie ein QRS (14882 bei Spitzen von 40452) - die flachere ventrikulaere Extrasystole (17410)
 *      fiel durch. Aus "unregelmaessig mit Extrasystolen" wurde ein beruhigendes "regelmaessig".
 *   2. Die Schwankung wurde als MEDIAN der Abstandsunterschiede berechnet. Der Median ist
 *      unempfindlich gegen Ausreisser - eine einzelne Extrasystole IST aber der Ausreisser.
 *   3. Auf REINEM RAUSCHEN meldete die Auswertung "unregelmaessig mit vorzeitigen Schlaegen".
 *
 * Dieser Test haelt alle drei fest.
 *
 * Start: node tools/ekg-analyse-test.js      (laeuft auch in tools/alle-tests.js)
 */
const E = require('../ui/shared/ekg-analyse.js');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

const HZ = 256;

// --- Kunst-EKG bauen: Gauss-foermige QRS-Zacken auf ruhiger Grundlinie ----------------------
function qrs(s, r, breiteMs, amp) {
  const b = Math.round(breiteMs / 1000 * HZ);
  for (let k = -b; k <= b; k++) {
    const i = r + k;
    if (i < 0 || i >= s.length) continue;
    s[i] += Math.round(amp * Math.exp(-(k * k) / (2 * Math.pow(b / 3, 2))));
  }
}
/*
 * opt.ves: ein vorgezogener, BREITER Schlag mit kompensatorischer Pause danach - das vollstaendige
 * Muster einer ventrikulaeren Extrasystole (kurz, dann lang). Ohne die Pause waere es kein
 * belastbarer Befund, und der Test wuerde etwas verlangen, das klinisch nicht gilt.
 */
let __saat=1;
function __saatSetzen(s){__saat=s>>>0||1;}
function zufall(){__saat=(__saat*1103515245+12345)&0x7fffffff;return __saat/0x7fffffff;}
function bauEKG(opt) {
  opt = opt || {};
  const sek = opt.sek || 6;
  const n = Math.round(sek * HZ);
  const s = new Array(n).fill(0);
  if (opt.rauschen) for (let j = 0; j < n; j++) s[j] = Math.round((zufall() - 0.5) * opt.rauschen);
  const rrSek = 60 / (opt.hf || 100);
  const pos = [];
  let t = HZ * 0.4;
  for (let i = 0; i < 20 && t < n - HZ * 0.3; i++) {
    pos.push(Math.round(t));
    let d = rrSek;
    if (opt.ves && i === 3) d = rrSek * 0.66;   // vorgezogen
    if (opt.ves && i === 4) d = rrSek * 1.34;   // kompensatorische Pause
    t += d * HZ;
  }
  pos.forEach((r, i) => qrs(s, r, (opt.ves && i === 4) ? 90 : (opt.qrsMs || 50), 600));
  return s;
}

console.log('VetStation — EKG-Auswertung auf echten Abtastwerten\n');

/* ---------------- 1) Grundmessung ---------------- */
console.log('Messung (Hund, 120/min, 6 s):');
const hund = E.analysiere({ samples: bauEKG({ hf: 120 }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('der Streifen ist auswertbar', hund.brauchbar === true, hund.warum);
ok('die Herzfrequenz wird aus den RR-Abstaenden gemessen', Math.abs(hund.hf - 120) <= 3, String(hund.hf));
ok('die QRS-Breite wird gemessen', hund.qrsBreiteMs > 20 && hund.qrsBreiteMs < 120, String(hund.qrsBreiteMs));
ok('die RR-Abstaende werden ausgewiesen', hund.rr && hund.rr.mittelMs > 400 && hund.rr.mittelMs < 600, JSON.stringify(hund.rr));
ok('der Rhythmus wird als regelmaessig erkannt', hund.rhythmus.id === 'sinus', hund.rhythmus.name);
ok('jede Aussage traegt eine Begruendung', !!hund.rhythmus.begruendung);

console.log('\nKatze mit 210/min (Mensch-Grenzen wuerden hier versagen):');
const katze = E.analysiere({ samples: bauEKG({ hf: 210, qrsMs: 35 }), hz: HZ, skala: 1 }, { bandHr: [140, 220], einheit: 'uV' });
ok('auch 210/min werden korrekt gemessen', Math.abs(katze.hf - 210) <= 6, String(katze.hf));
ok('und gelten fuer die Katze NICHT als Tachykardie', katze.rhythmus.id === 'sinus', katze.rhythmus.name);

/* ---------------- 2) Fehler 1 + 2: die Extrasystole ---------------- */
console.log('\nVentrikulaere Extrasystole (breit, vorgezogen, mit Pause):');
let erkannt = 0;
for (let i = 0; i < 20; i++) {
  const r = E.analysiere({ samples: bauEKG({ ves: true }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
  if (r.rhythmus && /vorzeitig/.test(r.rhythmus.name)) erkannt++;
}
ok('sie wird zuverlaessig erkannt (20 Durchlaeufe)', erkannt === 20, erkannt + '/20');
const ves = E.analysiere({ samples: bauEKG({ ves: true }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('der BREITE Schlag wird ueberhaupt gefunden (Nachsuche in der Luecke)',
  ves.schlaege >= 8, ves.schlaege + ' Schlaege');
ok('der verkuerzte Abstand steht in der Begruendung', /kürzester Abstand/.test(ves.rhythmus.begruendung), ves.rhythmus.begruendung);
ok('sie wird als VERDACHT ausgewiesen, nicht als Diagnose', ves.rhythmus.sicherheit === 'Verdacht', ves.rhythmus.sicherheit);

/* ---------------- 3) Fehler 3: nichts aus Rauschen erfinden ---------------- */
console.log('\nSchweigeregeln:');
const rauschen = new Array(4 * HZ).fill(0).map(() => Math.round((zufall() - 0.5) * 40));
const rr = E.analysiere({ samples: rauschen, hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('reines Rauschen ergibt KEINE Rhythmusaussage', rr.brauchbar === false, rr.rhythmus && rr.rhythmus.name);
ok('und nennt den Grund im Klartext', /verrauscht/.test(rr.warum || ''), rr.warum);

let fehlalarm = 0;
const N_MESS = 200;   // feste Spuren, Begruendung unten
for (let i = 0; i < N_MESS; i++) { __saatSetzen(1000+i);
  const r = E.analysiere({ samples: bauEKG({ rauschen: 120 }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
  if (r.rhythmus && /vorzeitig/.test(r.rhythmus.name)) fehlalarm++;
}
/*
 * WARUM 200 FESTE SPUREN UND NICHT 20 ZUFAELLIGE (gemessen 30.07.2026).
 *
 * Die Schranke ist eine RATE: hoechstens 15 % Fehlalarme auf einem verrauschten, aber
 * regelmaessigen EKG. Vorher wurde sie an 20 ZUFAELLIGEN Spuren geprueft — bei einer wahren Rate
 * von 9 % erwartet man dort 1,8 Treffer, und die Streuung reicht muehelos bis 5 oder 6. Der Test
 * war deshalb in rund jedem fuenften Lauf rot, OHNE dass sich am Code etwas geaendert hatte
 * (nachgemessen: 7 von 40 Laeufen). Ein Tor, das grundlos flackert, bringt Menschen dazu, rote
 * Zeilen zu uebersehen — und dann faellt der echte Fehler auch nicht mehr auf.
 *
 * Die Schranke ist NICHT gelockert: 30 von 200 sind dieselben 15 % wie 3 von 20. Geaendert hat
 * sich nur, dass sie an genug Spuren gemessen wird, um eine Aussage zu sein. Die Spuren sind
 * gesaet und damit bei jedem Lauf dieselben; gemessen wurden 18 von 200 (9 %).
 */
ok('ein verrauschtes, aber regelmaessiges EKG ergibt kaum Fehlalarme (hoechstens 15 %)',
  fehlalarm <= 30, fehlalarm + '/' + N_MESS);

const kurz = E.analysiere({ samples: bauEKG({ sek: 1 }), hz: HZ, skala: 1 }, { bandHr: [60, 140] });
ok('ein zu kurzer Streifen ergibt keine Aussage', kurz.brauchbar === false);
ok('mit Begruendung', /zu kurz/.test(kurz.warum || ''), kurz.warum);

const abgefallen = E.analysiere({ samples: new Array(4 * HZ).fill(null), hz: HZ }, {});
ok('eine abgefallene Ableitung ergibt keine Aussage', abgefallen.brauchbar === false);
ok('und wird NICHT als Asystolie gemeldet', !/[Aa]systolie/.test(abgefallen.warum || '') || /Ableitung/.test(abgefallen.warum));

const ohneRate = E.analysiere({ samples: bauEKG({}), hz: 0 }, {});
ok('ohne Abtastrate wird nichts behauptet', ohneRate.brauchbar === false, ohneRate.warum);

/* ---------------- 4) ST-Strecke nur mit bekannter Verstaerkung ---------------- */
console.log('\nST-Strecke:');
const stOhne = E.analysiere({ samples: bauEKG({ hf: 120 }), hz: HZ, skala: null }, { bandHr: [60, 140], einheit: '' });
ok('ohne bekannte Verstaerkung gibt es KEINE Angabe in mV', stOhne.st && stOhne.st.messbar === false, JSON.stringify(stOhne.st));
ok('und der Grund wird genannt', /Verstärkung/.test((stOhne.st && stOhne.st.warum) || ''), stOhne.st && stOhne.st.warum);
const stMit = E.analysiere({ samples: bauEKG({ hf: 120 }), hz: HZ, skala: 1 }, { bandHr: [60, 140], einheit: 'uV' });
ok('mit Verstaerkung wird ein Wert in mV geliefert', stMit.st && stMit.st.messbar === true && typeof stMit.st.mv === 'number', JSON.stringify(stMit.st));

/* ---------------- 5) Die Kurve kommt wirklich aus dem Geraet ---------------- */
/* ================================================================================
 * DIE SCHNELLE GRUNDLINIE MUSS DIESELBE ZAHL LIEFERN — NICHT FAST DIESELBE
 *
 * WARUM DIESER TEST EXISTIERT (10.08.2026): grundlinieAbziehen() war mit 22 von 25 ms die
 * teuerste Stelle der ganzen Auswertung, und die laeuft 2,5-mal je Sekunde mitten in der
 * Zeichenschleife - das war das Ruckeln. Der erste Beschleunigungsversuch rechnete die
 * Grundlinie nur auf Stuetzstellen und verband sie geradlinig: achtmal schneller, aber bis
 * zu 82 uV daneben. Bei ST-Grenzen von 150 bis 200 uV ist das ein Zehntel des Befundes.
 * Die jetzige Fassung fuehrt das Fenster SORTIERT mit und rechnet mit derselben Wertemenge
 * wie vorher. "Gleich" heisst hier deshalb: Abweichung null. Genau das wird geprueft -
 * mit Luecken, ohne Luecken und mit dem breiten Pferdefenster.
 * ============================================================================== */
console.log('\nGrundlinie: schnell UND wertgleich:');
{
  function baueRoh(sek, mitLuecken) {
    const HZ = 250, n = Math.round(HZ * sek), s = new Array(n).fill(0);
    for (let i = 0; i < n; i++) s[i] = 180 * Math.sin(2 * Math.PI * i / HZ / 3.5) + ((i * 2654435761) % 1000 - 500) / 60;
    for (let t = 0.3; t < sek - 0.3; t += 0.6) {
      for (let i = Math.max(0, Math.round((t - 0.25) * HZ)); i < Math.min(n, Math.round((t + 0.30) * HZ)); i++) {
        const dt = i / HZ - t;
        const we = (x, t0, d) => (x < t0 || x > t0 + d) ? 0 : 0.5 * (1 - Math.cos(2 * Math.PI * (x - t0) / d));
        s[i] += 220 * we(dt, -0.110, 0.038) + 1000 * we(dt, -0.024, 0.048) - 220 * we(dt, 0.024, 0.038) + 220 * we(dt, 0.090, 0.120);
      }
    }
    if (mitLuecken) for (let q = 1000; q < 1200 && q < n; q++) s[q] = null;
    return s;
  }
  [[false, 0.2, 'Kleintier-Fenster 200 ms'], [true, 0.2, 'mit Sendeluecke'],
   [false, 0.6, 'Pferde-Fenster 600 ms']].forEach(([luecken, fenster, was]) => {
    const s = baueRoh(20, luecken);
    const genau = E.grundlinieAbziehenGenau(s, 250, fenster);
    const schnell = E.grundlinieAbziehen(s, 250, fenster);
    let max = 0, nullUnterschied = 0;
    for (let i = 0; i < s.length; i++) {
      if ((genau[i] == null) !== (schnell[i] == null)) { nullUnterschied++; continue; }
      if (genau[i] == null) continue;
      const d = Math.abs(genau[i] - schnell[i]);
      if (d > max) max = d;
    }
    ok(was + ': Abweichung null', max === 0, 'groesste Abweichung ' + max);
    ok(was + ': Luecken bleiben Luecken', nullUnterschied === 0, nullUnterschied + ' Stellen verschieden');
  });
  /* Und dass es wirklich schneller ist - sonst waere der Umbau umsonst gewesen. Die Grenze
   * ist bewusst grosszuegig (Faktor 3), damit der Test nicht auf einem langsamen Rechner
   * rot wird; gemessen wurde Faktor 17. */
  const s = baueRoh(20, false);
  E.grundlinieAbziehen(s, 250, 0.2); E.grundlinieAbziehenGenau(s, 250, 0.2);
  const t0 = Date.now(); for (let i = 0; i < 5; i++) E.grundlinieAbziehenGenau(s, 250, 0.2);
  const tGenau = Date.now() - t0;
  const t1 = Date.now(); for (let i = 0; i < 5; i++) E.grundlinieAbziehen(s, 250, 0.2);
  const tSchnell = Date.now() - t1;
  ok('die schnelle Fassung ist mindestens dreimal schneller',
    tSchnell * 3 <= tGenau || tSchnell <= 2, tGenau + ' ms gegen ' + tSchnell + ' ms');
  /* Und die ganze Auswertung muss unter einem Bild bleiben (30 ms bei 33 Bildern je
   * Sekunde) - sie laeuft mitten in der Zeichenschleife.
   *
   * GEMESSEN WIRD DAS MINIMUM, NICHT DER MITTELWERT (Berichtigung 17.08.2026).
   * Vorher stand hier (Date.now() - t2) / 5, also der Mittelwert aus fuenf Laeufen. Am
   * 17.08.2026 meldete der Sammellauf damit 31,8 ms und wurde rot, waehrend derselbe Test
   * allein gestartet dreimal hintereinander bestand: auf dem Entwicklerrechner (2 Kerne)
   * liefen gleichzeitig eigene Prozesse. Ein einziger verzoegerter Lauf zieht den Mittelwert
   * ueber die Grenze.
   *
   * Das Minimum ist die belastbare Schaetzung der ECHTEN Rechenzeit: Fremdlast, Umschaltungen
   * und Speicherbereinigung koennen einen Lauf nur LANGSAMER machen als den Code, niemals
   * schneller. Die Grenze von 30 ms bleibt unveraendert scharf — eine echte Verlangsamung des
   * Codes trifft alle Laeufe und damit auch das Minimum.
   *
   * WARUM DAS WICHTIG IST: ein Test, der ohne Codefehler rot wird, bringt den naechsten Leser
   * dazu, Rot zu ignorieren. Das ist teurer als die Millisekunden, um die es hier geht.
   * Der Mittelwert wird mitgemeldet, damit eine Verlangsamung sichtbar bleibt.
   */
  const laeufe = [];
  for (let i = 0; i < 7; i++) {
    const tA = Date.now();
    E.analysiere({ samples: s, hz: 250, skala: 1 }, { art: 'hund', einheit: 'uV', bandHr: [70, 160] });
    laeufe.push(Date.now() - tA);
  }
  const proLauf = Math.min.apply(null, laeufe);
  const mittel = laeufe.reduce(function (a, b) { return a + b; }, 0) / laeufe.length;
  ok('eine Auswertung von 20 s bleibt unter 30 ms (ein Bild)', proLauf < 30,
    'schnellster von ' + laeufe.length + ' Laeufen ' + proLauf.toFixed(1) + ' ms, Mittel '
    + mittel.toFixed(1) + ' ms, alle: ' + laeufe.join('/') + ' ms');
}

/* ================================================================================
 * ES DARF NUR EINE EKG-AUSWERTUNG IM BAUM GEBEN
 *
 * WARUM DIESER TEST EXISTIERT (Befund 10.08.2026, der schwerste der Sitzung):
 * ekg-analyse.js lag ZWEIMAL im Baum - unter ui/shared/ (99 KB, gepflegt) und unter
 * ui/engine/ (21 KB, Stand 22.07.2026). Die Oberflaeche lud die neue, aber
 * bridge/src/model.js und bridge/src/registry.js luden ueber require() die ALTE - und in
 * beiden stand im Kommentar woertlich "dieselbe Engine wie die Oberflaeche". Das war beim
 * Verschieben der Datei am 07.08.2026 unwahr geworden, ohne dass irgendetwas rot wurde:
 * die alte Datei lief ja weiter.
 *
 * Folge: Die BRIDGE - also der Teil, der auf dem Praxis-PC die echten Geraetedaten
 * auswertet, das Narkoseprotokoll schreibt und die Befunde in die Cloud schickt - hat
 * wochenlang mit einer Auswertung ohne P-Welle, ohne QT, ohne Formvergleich und mit einer
 * festen 80-ms-Breitengrenze gearbeitet. Station und Oberflaeche konnten fuer denselben
 * Streifen verschiedene Befunde melden.
 *
 * Auch dieser Test selbst lief seit dem 22.07.2026 gegen die tote Datei. Er war gruen und
 * hat nichts bewacht.
 * ============================================================================== */
console.log('\nEine Auswertung, nicht zwei:');
{
  const fs = require('fs');
  const path = require('path');
  const WURZEL = path.join(__dirname, '..');
  const gefunden = [];
  (function suche(dir, tiefe) {
    if (tiefe > 4) return;
    let eintraege = [];
    try { eintraege = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { return; }
    eintraege.forEach((e) => {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (/^(node_modules|dist|\.git)$/.test(e.name)) return;
        suche(p, tiefe + 1);
      } else if (e.name === 'ekg-analyse.js') gefunden.push(path.relative(WURZEL, p).replace(/\\/g, '/'));
    });
  }(WURZEL, 0));
  ok('ekg-analyse.js liegt genau EINMAL im Baum', gefunden.length === 1, gefunden.join(' , '));
  ok('und zwar in ui/shared/', gefunden[0] === 'ui/shared/ekg-analyse.js', gefunden.join(' , '));
  /* Und niemand darf mehr auf den alten Weg zeigen. */
  ['bridge/src/model.js', 'bridge/src/registry.js'].forEach((f) => {
    const s = fs.readFileSync(path.join(WURZEL, f), 'utf8');
    ok(f + ' laedt die gepflegte Auswertung',
      /require\('\.\.\/\.\.\/ui\/shared\/ekg-analyse\.js'\)/.test(s), 'zeigt woandershin');
    ok(f + ' zeigt NICHT mehr auf ui/engine', s.indexOf('ui/engine/ekg-analyse') < 0);
  });
  /* Gegenprobe an der SACHE, nicht am Pfad: die Bridge muss die neuen Groessen bekommen.
   * Waere sie noch an der alten Fassung, gaebe es weder p noch t noch muster. */
  const probe = E.analysiere({ samples: bauEKG({ hf: 120 }), hz: HZ, skala: 1 },
    { bandHr: [60, 140], einheit: 'uV', art: 'hund' });
  ['p', 't', 'form', 'muster', 'pausen', 'alternans'].forEach((feld) => {
    ok('die geladene Auswertung liefert "' + feld + '"', probe[feld] !== undefined, 'fehlt');
  });
}

console.log('\nAnbindung an die Geraetedaten:');
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const werte = bauEKG({ hf: 120, sek: 2 }).join('^');
const frame = parseHL7Message([
  'MSH|^~\\&|LifeVet 10C||||||ORU^R01|1|P|2.3.1',
  'OBX|1|NM|131330^MDC_ECG_ELEC_POTL_II||' + werte + '|uV|||||F',
  'OBX|2|NM|0^MDC_ATTR_SAMP_RATE||256|Hz|||||F',
  'OBX|3|NM|2327^MDC_ATTR_NU_MSMT_RES||1.000000||||||F',
].join('\r'), { deviceId: 't' }, function () {});
ok('der Kurvenblock des Geraets wird gelesen', (frame.kurvenDaten || []).length === 1);
ok('mit Abtastrate 256 Hz', frame.kurvenDaten[0].hz === 256);
const ausGeraet = E.analysiere(frame.kurvenDaten[0], { bandHr: [60, 140], einheit: 'uV' });
ok('und laesst sich direkt auswerten', ausGeraet.brauchbar === true, ausGeraet.warum);
ok('die gemessene Frequenz stimmt', Math.abs(ausGeraet.hf - 120) <= 6, String(ausGeraet.hf));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
