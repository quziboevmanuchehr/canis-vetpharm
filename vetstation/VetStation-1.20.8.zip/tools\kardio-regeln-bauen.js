'use strict';
/*
 * kardio-regeln-bauen.js — erzeugt ui/shared/kardio-regeln.js aus der Auswertung des
 * sechsten Fachbuchs (Killich, Kleintierkardiologie, Thieme 2019).
 *
 * WARUM ES DIESE DATEI GIBT (14.08.2026):
 * Das Buch liegt als 96 kapitelweise PDFs vor, 702 Seiten. Von Hand abzutippen waere eine
 * Fehlerquelle mit Zufallszuender - genau wie bei ekg-befunde.js und ekg-literatur.js. Die
 * Quelldaten bleiben deshalb im Repo (docs/kardio-quellen/), damit sich jede Zahl
 * zurueckverfolgen laesst und das Ergebnis jederzeit neu entsteht.
 *
 * WAS HIER ANDERS IST ALS BEIM NACHSCHLAGEWERK - und warum:
 * ekg-literatur.js traegt SAETZE aus Buechern. Diese Datei traegt ausdruecklich KEINE:
 * der Nutzer hat am 14.08.2026 entschieden, aus diesem Werk nur ZAHLEN, SCHWELLEN UND
 * ENTSCHEIDUNGSWEGE zu uebernehmen, in eigener Formulierung. Jede Regel ist auf 220 Zeichen
 * begrenzt und traegt Kapitel und Buchseite, damit sie nachschlagbar bleibt.
 *
 * DER STATUS IST DER EIGENTLICHE WERT. Jede Regel wurde gegen die fuenf bereits
 * ausgewerteten Werke und gegen den vorhandenen Code geprueft:
 *   bestaetigt     - eine andere Quelle sagt dasselbe (zweiter Beleg)
 *   neu            - in den vorhandenen Quellen nicht enthalten
 *   schon_verbaut  - die Anwendung benutzt den Wert bereits
 *   widerspruch    - eine vorhandene Quelle sagt etwas ANDERES
 *
 * WIDERSPRUECHE WERDEN NICHT GEGLAETTET. Sie behalten ihren vollstaendigen Abgleichtext mit
 * beiden Werten und beiden Quellen - die Merkblaetter dieses Projekts halten fest, dass genau
 * das der wertvollste Teil einer Buchauswertung ist. Bei allen anderen Status faellt der
 * Abgleichtext weg; er wuerde die Datei verdoppeln, ohne am Praxis-PC etwas zu beantworten.
 *
 * DIESE DATEI LOEST NICHTS AUS. Sie ist ein Nachschlagewerk wie ekg-literatur.js: die
 * Anwendung behauptet weiterhin nur, was sie selbst misst.
 *
 * Start: dist/VetStation/node/node.exe tools/kardio-regeln-bauen.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
/* Quelldaten unter docs/kardio-quellen/ - wie docs/ekg-quellen und docs/rassen-quellen aus
 * dem Paket ausgeschlossen (installer/make-dist.ps1). Sie gehoeren ins Repo, damit die
 * Herkunft jeder Zahl nachpruefbar bleibt, aber nicht ueber die Praxisleitung. */
const QUELLE = path.join(WURZEL, 'docs', 'kardio-quellen', 'killich-2019-regeln.json');
const ZIEL = path.join(WURZEL, 'ui', 'shared', 'kardio-regeln.js');

if (!fs.existsSync(QUELLE)) {
  console.error('Quelldatei fehlt: ' + QUELLE);
  process.exit(1);
}
const roh = JSON.parse(fs.readFileSync(QUELLE, 'utf8'));

const THEMEN = [
  ['narkose', 'Narkose am Herzpatienten'],
  ['arrhythmie', 'Arrhythmien'],
  ['dosis', 'Dosierungen'],
  ['notfall', 'Notfall'],
  ['normwert', 'Normwerte'],
  ['monitoring', 'Überwachung'],
  ['elektrolyt', 'Elektrolyte'],
  ['rasse', 'Rassen'],
  ['diagnostik', 'Diagnostik'],
];
const MODULE = ['narkose-risiko', 'ekg-befunde', 'ekg-analyse', 'dosis', 'monitor', 'rasse-herz', 'herz3d', 'notfall'];

function s(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }

/*
 * DUBLETTEN: derselbe Sachverhalt kann in zwei Kapiteln stehen (die Hyperkaliaemie etwa im
 * Elektrolyt- UND im Arrhythmiekapitel). Verglichen wird die Kennung; bei gleicher Kennung
 * gewinnt die Fassung mit dem hoeherwertigen Status - ein Widerspruch darf nicht von einer
 * "neu"-Fassung derselben Regel verdraengt werden, sonst verschwindet er still.
 */
const RANG = { widerspruch: 4, schon_verbaut: 3, bestaetigt: 2, neu: 1 };
const nachId = Object.create(null);
roh.forEach((r) => {
  const id = s(r.id);
  if (!id || !s(r.aussage)) return;
  const alt = nachId[id];
  if (alt && (RANG[alt.status] || 0) >= (RANG[r.status] || 0)) return;
  nachId[id] = r;
});

const sauber = [];
Object.keys(nachId).forEach((id) => {
  const r = nachId[id];
  const e = {
    id: id,
    thema: s(r.thema) || 'diagnostik',
    aussage: s(r.aussage).slice(0, 240),
    seite: Number(r.seite) || 0,
    kapitel: s(r.kapitel),
    status: s(r.status) || 'neu',
  };
  if (s(r.bedingung)) e.wenn = s(r.bedingung).slice(0, 240);
  if (s(r.folge)) e.dann = s(r.folge).slice(0, 240);
  if (r.tierart && r.tierart.length) e.art = r.tierart.map(s).filter(Boolean);
  if (s(r.passtZu) && s(r.passtZu) !== 'keins' && s(r.passtZu) !== '?') e.modul = s(r.passtZu);
  if (r.zahlen && r.zahlen.length) {
    e.zahlen = r.zahlen.map((z) => {
      const o = { was: s(z.groesse), wert: s(z.wert) };
      if (s(z.einheit)) o.einheit = s(z.einheit);
      if (s(z.art)) o.art = s(z.art);
      return o;
    }).filter((z) => z.was && z.wert);
    if (!e.zahlen.length) delete e.zahlen;
  }
  /* Nur beim Widerspruch: der volle Abgleich mit beiden Werten und beiden Quellen. */
  if (e.status === 'widerspruch' && s(r.abgleich)) e.abgleich = s(r.abgleich);
  sauber.push(e);
});

/* Sortierung: Widersprueche zuerst (sie brauchen eine Entscheidung), danach nach Thema. */
const tRang = Object.create(null);
THEMEN.forEach(([id], i) => { tRang[id] = i; });
sauber.sort((a, b) => {
  const wa = a.status === 'widerspruch' ? 0 : 1, wb = b.status === 'widerspruch' ? 0 : 1;
  if (wa !== wb) return wa - wb;
  const ra = tRang[a.thema] == null ? 99 : tRang[a.thema];
  const rb = tRang[b.thema] == null ? 99 : tRang[b.thema];
  if (ra !== rb) return ra - rb;
  return a.seite - b.seite;
});

const zaehlung = {};
sauber.forEach((e) => { zaehlung[e.status] = (zaehlung[e.status] || 0) + 1; });

const kopf = `/*
 * kardio-regeln.js — Zahlen, Schwellen und Entscheidungswege aus der Kleintierkardiologie.
 *
 * ERZEUGT von tools/kardio-regeln-bauen.js am ${new Date().toISOString().slice(0, 10)}.
 * NICHT von Hand aendern — die Quelldaten liegen in docs/kardio-quellen/.
 *
 * WOHER: Killich M. (Hrsg.), Kleintierkardiologie — Diagnose und Therapie von Herzerkrankungen
 * bei Hund, Katze und Heimtieren, Thieme 2019 (ISBN 978-3-13-219991-0), 593 ausgewertete
 * Buchseiten. Jede Regel traegt Kapitel und Seite.
 *
 * WAS SIE IST UND WAS NICHT: KEINE abgeschriebenen Buchsaetze. Uebernommen wurden
 * ausschliesslich Zahlen, Schwellen und Entscheidungswege, jeweils in eigener Formulierung.
 * Die Anwendung behauptet weiterhin nur, was sie selbst misst — diese Datei loest nichts aus.
 *
 * STATUS: jede Regel ist gegen die fuenf Werke in ekg-literatur.js und gegen den vorhandenen
 * Code geprueft. 'widerspruch' bedeutet, dass eine andere Quelle etwas ANDERES sagt; dort steht
 * der vollstaendige Abgleich mit beiden Werten dabei. Diese Faelle sind ABSICHTLICH nicht
 * geglaettet — wer eine Zahl uebernimmt, muss den Streit sehen.
 *
 * BLEIBT AN DER STATION: die Datei geht nicht in den oeffentlichen Kanal
 * (tools/web-app-bauen.js, NUR_LOKAL).
 *
 * Stand: ${sauber.length} Regeln — ${Object.keys(zaehlung).sort().map((k) => k + ' ' + zaehlung[k]).join(', ')}.
 *
 * Reines ES5, keine Abhaengigkeiten. Laeuft im Browser (window.VS.kardio) und in Node.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.VS = root.VS || {}; root.VS.kardio = factory(); }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var THEMEN = ${JSON.stringify(THEMEN, null, 2).split('\n').map((z, i) => (i ? '  ' + z : z)).join('\n')};

  var MODULE = ${JSON.stringify(MODULE)};

  var REGELN = ${JSON.stringify(sauber, null, 1).split('\n').map((z, i) => (i ? '  ' + z : z)).join('\n')};

  function themenName(id) {
    for (var i = 0; i < THEMEN.length; i++) if (THEMEN[i][0] === id) return THEMEN[i][1];
    return id;
  }

  /* Suchtext einer Regel — einmal gebaut und gemerkt, sonst kostet jede Tastatureingabe
   * einen vollstaendigen Durchlauf ueber alle Felder von ${sauber.length} Regeln. */
  function heuhaufen(e) {
    if (e.__h) return e.__h;
    var t = [e.id, e.aussage, e.wenn, e.dann, e.kapitel, e.thema, e.modul].join(' ');
    if (e.zahlen) for (var i = 0; i < e.zahlen.length; i++) {
      t += ' ' + e.zahlen[i].was + ' ' + e.zahlen[i].wert + ' ' + (e.zahlen[i].einheit || '');
    }
    if (e.abgleich) t += ' ' + e.abgleich;
    e.__h = t.toLowerCase();
    return e.__h;
  }

  function suche(text, thema, modul) {
    var w = String(text || '').toLowerCase().split(/\\s+/).filter(function (x) { return x.length > 1; });
    var out = [], i, j, e, passt;
    for (i = 0; i < REGELN.length; i++) {
      e = REGELN[i];
      if (thema && e.thema !== thema) continue;
      if (modul && e.modul !== modul) continue;
      passt = true;
      for (j = 0; j < w.length; j++) if (heuhaufen(e).indexOf(w[j]) < 0) { passt = false; break; }
      if (passt) out.push(e);
    }
    return out;
  }

  function themenMitTreffern(text) {
    var z = {}, i, tr = suche(text, null, null);
    for (i = 0; i < tr.length; i++) z[tr[i].thema] = (z[tr[i].thema] || 0) + 1;
    var out = [];
    for (i = 0; i < THEMEN.length; i++) {
      if (z[THEMEN[i][0]]) out.push({ id: THEMEN[i][0], name: THEMEN[i][1], n: z[THEMEN[i][0]] });
    }
    return out;
  }

  function fuerModul(m) { return suche('', null, m); }
  function widersprueche() {
    var out = [], i;
    for (i = 0; i < REGELN.length; i++) if (REGELN[i].status === 'widerspruch') out.push(REGELN[i]);
    return out;
  }

  return {
    REGELN: REGELN, THEMEN: THEMEN, MODULE: MODULE,
    suche: suche, themenMitTreffern: themenMitTreffern, themenName: themenName,
    fuerModul: fuerModul, widersprueche: widersprueche,
    anzahl: REGELN.length
  };
}));
`;

fs.writeFileSync(ZIEL, kopf, 'utf8');
console.log('geschrieben: ' + ZIEL);
console.log(sauber.length + ' Regeln aus ' + roh.length + ' Rohregeln (' + (roh.length - sauber.length) + ' Dubletten/leer entfernt)');
console.log('Status: ' + Object.keys(zaehlung).sort().map((k) => k + ' ' + zaehlung[k]).join(', '));
console.log('Groesse: ' + Math.round(fs.statSync(ZIEL).size / 1024) + ' KB');
