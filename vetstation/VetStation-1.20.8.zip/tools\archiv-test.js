'use strict';
/*
 * archiv-test.js — das Archiv speichert das SIGNAL, nicht ein Bild.
 *
 * WAS WAR, und es war gemessen (09.08.2026):
 * Ein gespeicherter Streifen war ein PNG des ganzen A4-Blattes. EIN Eintrag belegte 275 KB
 * (das Bild allein 277.330 Zeichen), sechzig Eintraege waeren 16,1 MB gewesen. Der uebliche
 * Speicher eines Browsers fasst 5 MB. Und weil archSave() den Fehler mit catch(e){}
 * verschluckte, haette der Tierarzt trotzdem "Streifen gespeichert" gelesen - ein stiller
 * Datenverlust.
 *
 * Schwerer wiegt das Zweite: ein BILD laesst sich nicht nachmessen. Genau dafuer archiviert
 * man ein EKG. Jetzt liegen die Abtastwerte als Int16 in base64 - rund 2,5 KB je Streifen.
 *
 * Dieser Test haelt vier Dinge fest:
 *   1. Die Rueckrechnung stimmt (sonst waere der archivierte Streifen ein anderer).
 *   2. Ein Streifen ist um Groessenordnungen kleiner als das alte Bild.
 *   3. Automatisch abgelegte Streifen verdraengen NIE einen von Hand gespeicherten.
 *   4. Ein misslungenes Speichern wird GEMELDET und nicht verschluckt.
 *
 * Start: node tools/archiv-test.js
 */
const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');
function holeBlock(anfang, ende) {
  const a = src.indexOf(anfang);
  if (a < 0) throw new Error('nicht gefunden: ' + anfang);
  const b = src.indexOf(ende, a);
  return src.slice(a, b + ende.length);
}

/* Node kennt weder localStorage noch btoa/atob im Browsersinn - beides nachbilden, damit
 * die ECHTEN Funktionen aus index.html geprueft werden und keine Nachbildung davon. */
function baueUmgebung(kapazitaet) {
  const speicher = {};
  let belegt = 0;
  const localStorage = {
    getItem(k) { return Object.prototype.hasOwnProperty.call(speicher, k) ? speicher[k] : null; },
    setItem(k, v) {
      const alt = speicher[k] ? speicher[k].length : 0;
      const neu = belegt - alt + String(v).length;
      if (neu > kapazitaet) { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; }
      speicher[k] = String(v); belegt = neu;
    },
    removeItem(k) { if (speicher[k]) { belegt -= speicher[k].length; delete speicher[k]; } },
  };
  const btoa = (s) => Buffer.from(s, 'latin1').toString('base64');
  const atob = (s) => Buffer.from(s, 'base64').toString('latin1');
  const fn = new Function('localStorage', 'btoa', 'atob', 'Uint8Array',
    holeBlock('var ARCH_KEY=', 'return { ok:false, fehler:\'Speicher voll\' };\n}') + '\n' +
    holeBlock('function samplesNachB64(samples){', '\n}') + '\n' +
    holeBlock('function b64NachSamples(b64, faktor){', '\n}') + '\n' +
    'return { archLoad:archLoad, archSave:archSave, archAufraeumen:archAufraeumen,' +
    ' samplesNachB64:samplesNachB64, b64NachSamples:b64NachSamples,' +
    ' ARCH_MAX:ARCH_MAX, ARCH_MAX_AUTO:ARCH_MAX_AUTO, ARCH_MAX_TAKT:ARCH_MAX_TAKT,' +
    ' _speicher:localStorage };');
  return fn(localStorage, btoa, atob, Uint8Array);
}

function baueRohpuffer() {
  const fn = new Function(
    holeBlock('var ROH={', 'sekunden:Math.round(n/ROH.hz*100)/100, angeschnitten:(n<will) };\n}') + '\n' +
    'return { ROH:ROH, ROH_MAX_SEK:ROH_MAX_SEK, rohLeeren:rohLeeren,' +
    ' rohUeberlappung:rohUeberlappung, rohAnhaengen:rohAnhaengen, rohStreifen:rohStreifen };');
  return fn();
}

/* EIN DURCHGEHENDES SIGNAL, aus dem die Lieferungen geschnitten werden.
 * Absichtlich NICHT rein periodisch: eine reine Sinuskurve waere fuer den
 * Ueberlappungsabgleich der guenstigste denkbare Fall - jede Lage passt irgendwo. Ein Signal
 * mit langsamer Drift und wiederkehrenden Zacken ist naeher am EKG und haerter zu treffen. */
function quelle(n) {
  const s = new Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / 256;
    s[i] = Math.sin(t * 2 * Math.PI * 1.2) * 0.2
      + Math.exp(-Math.pow((t % 0.8 - 0.2) / 0.01, 2))
      + Math.sin(i * 0.37) * 0.03;
  }
  return s;
}
/* Ein GLEITENDES FENSTER, wie /api/kurven es liefert: die letzten fensterS Sekunden des
 * Signals bis zur Stelle bisS. Genau diese Form hat der erste Entwurf verkannt. */
function fenster(sig, bisS, fensterS, hz) {
  const bis = Math.round(bisS * hz), von = Math.max(0, bis - Math.round(fensterS * hz));
  return { samples: sig.slice(von, bis), hz: hz };
}

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - EKG-Archiv\n');

/* ================================================================================
 * 1. DIE RUECKRECHNUNG MUSS STIMMEN
 * Ein archivierter Streifen, der anders aussieht als der aufgenommene, ist wertlos -
 * und faellt niemandem auf, weil er ja irgendein EKG zeigt.
 * ============================================================================== */
block('1. Signal geht verlustarm hin und zurueck');
{
  const U = baueUmgebung(5 * 1024 * 1024);
  /* Ein Streifen, wie er wirklich vorkommt: Zacken um die Grundlinie, Werte in mV. */
  const orig = [];
  for (let i = 0; i < 2500; i++) {
    const t = i / 250;
    orig.push(1.2 * Math.exp(-Math.pow((t % 0.5 - 0.1) / 0.012, 2)) - 0.15 * Math.sin(2 * Math.PI * t * 0.3));
  }
  const kod = U.samplesNachB64(orig);
  const zurueck = U.b64NachSamples(kod.b64, kod.faktor);

  pruef('gleiche Anzahl Werte', zurueck.length === orig.length, zurueck.length + ' statt ' + orig.length);
  let maxAbw = 0, spanne = 0;
  for (let i = 0; i < orig.length; i++) {
    maxAbw = Math.max(maxAbw, Math.abs(zurueck[i] - orig[i]));
    spanne = Math.max(spanne, Math.abs(orig[i]));
  }
  /* Int16 ueber die tatsaechliche Spanne: der Fehler muss weit unter dem liegen, was ein
   * Geraet selbst aufloest. 0,01 % der Spanne ist eine grosszuegige Obergrenze. */
  pruef('groesster Fehler unter 0,01 % der Spanne',
    maxAbw < spanne * 0.0001, 'Fehler ' + maxAbw.toExponential(2) + ', Spanne ' + spanne.toFixed(3));
  pruef('der Faktor wird mitgegeben', kod.faktor > 0 && isFinite(kod.faktor));

  /* Randfaelle, die im Betrieb vorkommen. */
  pruef('lauter Nullen ueberstehen es', U.b64NachSamples(U.samplesNachB64([0, 0, 0, 0]).b64, U.samplesNachB64([0, 0, 0, 0]).faktor).length === 4);
  const mitLuecken = [1, null, 0.5, undefined, -1];
  const kl = U.samplesNachB64(mitLuecken);
  pruef('Luecken (null) werden zu 0, nicht zu Unsinn',
    U.b64NachSamples(kl.b64, kl.faktor)[1] === 0);
  pruef('negative Werte bleiben negativ',
    U.b64NachSamples(kl.b64, kl.faktor)[4] < -0.9);
}

/* ================================================================================
 * 2. GROESSE — der eigentliche Grund des Umbaus
 * ============================================================================== */
block('2. Groesse');
{
  const U = baueUmgebung(5 * 1024 * 1024);
  const s = new Array(2500); for (let i = 0; i < 2500; i++) s[i] = Math.sin(i / 7);
  const kod = U.samplesNachB64(s);
  const kb = kod.b64.length / 1024;
  pruef('10 s bei 250 Hz passen in unter 10 KB', kb < 10, Math.round(kb * 10) / 10 + ' KB');
  /* Das alte Bild war gemessen 277.330 Zeichen. */
  pruef('mindestens 30-mal kleiner als das alte Blattbild (277.330 Zeichen)',
    kod.b64.length * 30 < 277330, kod.b64.length + ' Zeichen');
  pruef('60 Streifen bleiben unter 1 MB', kod.b64.length * 60 < 1024 * 1024,
    Math.round(kod.b64.length * 60 / 1024) + ' KB');
}

/* ================================================================================
 * 3. AUTOMATISCHE STREIFEN VERDRAENGEN NIE EINEN VON HAND GESPEICHERTEN
 * Von Hand speichern ist eine Entscheidung, automatisch ist Gelegenheit.
 * ============================================================================== */
block('3. Vorrang der von Hand gespeicherten Streifen');
{
  const U = baueUmgebung(5 * 1024 * 1024);
  const liste = [];
  for (let i = 0; i < 40; i++) liste.push({ id: 'h' + i, ts: 1000 + i, anlass: 'hand' });
  for (let i = 0; i < 40; i++) liste.push({ id: 'a' + i, ts: 5000 + i, anlass: 'auto' });
  const raus = U.archAufraeumen(liste);
  pruef('insgesamt hoechstens ' + U.ARCH_MAX, raus.length <= U.ARCH_MAX, String(raus.length));
  const hand = raus.filter((x) => x.anlass === 'hand').length;
  const auto = raus.filter((x) => x.anlass === 'auto').length;
  pruef('hoechstens ' + U.ARCH_MAX_AUTO + ' automatische', auto <= U.ARCH_MAX_AUTO, String(auto));
  pruef('alle 40 von Hand gespeicherten bleiben erhalten', hand === 40, String(hand));
  /* Die automatischen sind NEUER (ts 5000+) - eine reine Sortierung nach Zeit haette die
   * von Hand gespeicherten hinausgeworfen. Genau das darf nicht passieren. */
  pruef('obwohl die automatischen neuer sind', raus.filter((x) => x.anlass === 'hand').length === 40);
}

/* ================================================================================
 * 3b. EINE SALVE DARF DEN SELTENEN BEFUND NICHT LOESCHEN  (Recherche 09.08.2026)
 *
 * Ein reines "die 25 neuesten behalten" ist diagnostisch blind: fuenfundzwanzig
 * Extrasystolen-Meldungen hintereinander loeschen den EINZIGEN Streifen eines AV-Blocks,
 * der eine halbe Stunde vorher aufgezeichnet wurde. Der haeufigste Befund verdraengt den
 * seltenen - und der seltene ist meist der wichtigere.
 * ============================================================================== */
block('3b. je Verdachtsklasse bleibt einer stehen');
{
  const U = baueUmgebung(5 * 1024 * 1024);
  const liste = [];
  /* Eine Salve: 30 gleichartige Extrasystolen-Streifen, alle NEUER als der seltene Befund. */
  for (let i = 0; i < 30; i++) liste.push({ id: 'ves' + i, ts: 9000 + i, anlass: 'auto', ausloeser: ['extrasystolen'] });
  liste.push({ id: 'block', ts: 100, anlass: 'auto', ausloeser: ['pq-konstant-ausfall'] });
  liste.push({ id: 'vtach', ts: 90, anlass: 'auto', ausloeser: ['vtach-verdacht'] });
  const raus = U.archAufraeumen(liste);
  pruef('der AV-Block-Streifen ueberlebt die Salve',
    raus.some((x) => x.id === 'block'), raus.map((x) => x.id).slice(0, 6).join(','));
  pruef('der Kammertachykardie-Streifen ebenfalls', raus.some((x) => x.id === 'vtach'));
  pruef('trotzdem nicht mehr als der Deckel',
    raus.filter((x) => x.anlass === 'auto').length <= U.ARCH_MAX_AUTO);
  pruef('von der Salve bleibt mindestens einer',
    raus.filter((x) => x.ausloeser && x.ausloeser[0] === 'extrasystolen').length >= 1);
  /* Die Gegenprobe: eine reine Sortierung nach Zeit haette beide seltenen verloren. */
  const nurNeueste = liste.slice().sort((a, b) => b.ts - a.ts).slice(0, U.ARCH_MAX_AUTO);
  pruef('eine reine Sortierung nach Zeit haette beide seltenen verloren',
    !nurNeueste.some((x) => x.id === 'block') && !nurNeueste.some((x) => x.id === 'vtach'));
}

/* ================================================================================
 * 4. EIN MISSLUNGENES SPEICHERN WIRD GEMELDET
 * Das war der stille Datenverlust: catch(e){} und "gespeichert" in der Anzeige.
 * ============================================================================== */
block('4. Speicherfehler wird nicht verschluckt');
{
  /* Winziger Speicher: 4 KB. Ein Streifen mit Signal passt gerade so, zwei nicht. */
  const U = baueUmgebung(4096);
  const gross = 'x'.repeat(3000);
  const erg1 = U.archSave([{ id: 'a', ts: 1, anlass: 'hand', b64: gross }]);
  pruef('was passt, wird gespeichert und als ok gemeldet', erg1.ok === true, JSON.stringify(erg1));

  const zuViel = [];
  for (let i = 0; i < 5; i++) zuViel.push({ id: 'h' + i, ts: i, anlass: 'hand', b64: gross });
  const erg2 = U.archSave(zuViel);
  pruef('was NICHT passt, meldet ok=false statt still zu scheitern', erg2.ok === false, JSON.stringify(erg2));
  pruef('und nennt einen Grund', !!erg2.fehler, JSON.stringify(erg2));
}
{
  /* Und der Zwischenfall: es passt erst nach dem Verwerfen alter AUTOMATISCHER Streifen. */
  const U = baueUmgebung(9000);
  const gross = 'x'.repeat(2600);
  const liste = [
    { id: 'neu', ts: 99, anlass: 'hand', b64: gross },
    { id: 'a1', ts: 5, anlass: 'auto', b64: gross },
    { id: 'a2', ts: 4, anlass: 'auto', b64: gross },
    { id: 'a3', ts: 3, anlass: 'auto', b64: gross },
  ];
  const erg = U.archSave(liste);
  pruef('es wird Platz geschaffen statt aufzugeben', erg.ok === true, JSON.stringify(erg));
  pruef('und es wird gesagt, wie viel verworfen wurde', erg.verworfen > 0, String(erg.verworfen));
  const drin = U.archLoad();
  pruef('der neue Streifen von Hand ist drin', drin.some((x) => x.id === 'neu'));
  pruef('verworfen wurden AUTOMATISCHE', drin.filter((x) => x.anlass === 'auto').length < 3);
}

/* ================================================================================
 * 5. ROHPUFFER — DIE HOEHERE ABTASTRATE  (09.08.2026)
 *
 * Der Anzeigestreifen laeuft mit rund 75 Hz, also 13 ms Schrittweite. Ueber einen
 * Katzen-Kammerkomplex von 30 bis 50 ms sind das drei bis vier Punkte. Das Geraet selbst
 * tastet mit 256 Hz ab, sendet aber nur kurze Bloecke. Der Puffer haelt diese Bloecke vor.
 *
 * DIE GEFAEHRLICHE STELLE IST NICHT DIE RATE, SONDERN DAS ZUSAMMENKLEBEN: zwei Bloecke aus
 * verschiedenen Sendefenstern aneinandergesetzt ergeben eine Kurve, die tadellos aussieht
 * und in der Mitte Zeit verschluckt. Wer daran eine RR-Zeit abnimmt, misst Unsinn.
 * ============================================================================== */
block('5. Rohpuffer in Geraeteaufloesung');
{
  /* DER FEHLER, DEN DER ENTWURF GEMACHT HAT, UND ZWAR HIER FESTGENAGELT.
   *
   * Der erste Entwurf haengte jede Lieferung als eigenen Block an, in der Annahme, jede sei
   * ein neues Stueck Kurve. Sie ist es nicht: die Bridge fuehrt ein GLEITENDES 4-s-Fenster
   * (registry.js, rec.ekgBuf ... slice(-maxN)) und liefert es bei jeder Geraetenachricht neu.
   * Bei ~1 Nachricht je Sekunde ueberlappen zwei Lieferungen zu drei Vierteln. Aneinander-
   * gehaengt haette jeder Herzschlag rund viermal im Streifen gestanden - eine Kurve, die
   * gut aussieht und deren RR-Abstaende erfunden sind. */
  const sig = quelle(256 * 40);
  const R = baueRohpuffer();
  for (let s = 4; s <= 12; s++) R.rohAnhaengen(fenster(sig, s, 4, 256), 'pat1');
  const g = R.rohStreifen(30);
  pruef('neun sich ueberlappende 4-s-Fenster ergeben 12 s, nicht 36',
    Math.abs(g.sekunden - 12) < 0.01, g.sekunden + ' s');
  /* Und der eigentliche Beweis: der Puffer ist ZEICHENGLEICH mit dem Originalsignal. Eine
   * verdoppelte Stelle wuerde hier sofort auffallen, die Sekundenzahl allein nicht. */
  let gleich = true;
  for (let i = 0; i < g.werte.length; i++) if (g.werte[i] !== sig[i]) { gleich = false; break; }
  pruef('und sie sind zeichengleich mit dem Originalsignal (nichts verdoppelt)', gleich);
  pruef('die Geraeterate steht dabei', g.hz === 256, String(g.hz));
  /* Gegenprobe: die verworfene Fassung haette 36 s "Signal" gemeldet. */
  pruef('stumpfes Aneinanderhaengen haette 36 s ergeben (Gegenprobe)', 9 * 4 === 36 && g.sekunden < 13);
}
{
  /* DASSELBE FENSTER NOCH EINMAL - der Fall "nur Pleth hat sich geaendert".
   * kurvenSig ist EINE Zeichenkette ueber ALLE Kanaele (matching.js): aendert sich nur die
   * Pleth-Kurve, wird der unveraenderte EKG-Block trotzdem erneut geholt und uebergeben. */
  const sig = quelle(256 * 20);
  const R = baueRohpuffer();
  R.rohAnhaengen(fenster(sig, 4, 4, 256), 'p');
  const vorher = R.rohStreifen(30).sekunden;
  R.rohAnhaengen(fenster(sig, 4, 4, 256), 'p');
  R.rohAnhaengen(fenster(sig, 4, 4, 256), 'p');
  pruef('dieselbe Lieferung dreimal aendert nichts',
    R.rohStreifen(30).sekunden === vorher, R.rohStreifen(30).sekunden + ' statt ' + vorher);
}
{
  /* ABRISS: das Geraet war laenger still als das Fenster lang ist - die neue Lieferung hat
   * mit dem Puffer nichts mehr gemeinsam. Dann wird NEU BEGONNEN, nicht geklebt. */
  const sig = quelle(256 * 40);
  const R = baueRohpuffer();
  for (let s = 4; s <= 8; s++) R.rohAnhaengen(fenster(sig, s, 4, 256), 'p');
  pruef('vor dem Abriss liegen 8 s im Puffer', Math.abs(R.rohStreifen(30).sekunden - 8) < 0.01);
  R.rohAnhaengen(fenster(sig, 30, 4, 256), 'p');          // 22 s Stille dazwischen
  const s = R.rohStreifen(30);
  pruef('nach einem Abriss steht nur noch das neue Fenster da',
    Math.abs(s.sekunden - 4) < 0.01, s.sekunden + ' s - es wurde geklebt!');
  pruef('und es wird als angeschnitten ausgewiesen', s.angeschnitten === true);
  /* Haette der Puffer geklebt, waeren es 12 s "durchgehende" Kurve gewesen, in deren Mitte
   * 22 s fehlen - genau dort, wo man Rhythmus beurteilt. */
  pruef('geklebt waeren es 12 s mit einem Loch in der Mitte gewesen (Gegenprobe)', s.sekunden < 12);
}
{
  const sig = quelle(256 * 40);
  const R = baueRohpuffer();
  for (let s = 4; s <= 10; s++) R.rohAnhaengen(fenster(sig, s, 4, 256), 'pat1');
  pruef('vor dem Wechsel liegen 10 s im Puffer', Math.abs(R.rohStreifen(30).sekunden - 10) < 0.01);
  R.rohAnhaengen(fenster(sig, 11, 4, 256), 'pat2');       // ANDERES TIER
  const s = R.rohStreifen(30);
  /* Der schlimmste denkbare Fehler dieses Umbaus: Werte zweier Tiere in EINEM Streifen.
   * Er saehe tadellos aus und gehoerte niemandem. Besonders heimtueckisch ist, dass die
   * Ueberlappungspruefung ihn NICHT abfangen wuerde: die Fenster passen ja zusammen. */
  pruef('ein Patientenwechsel leert den Puffer vollstaendig',
    Math.abs(s.sekunden - 4) < 0.01, s.sekunden + ' s - es sind Werte des Vortiers drin!');
}
{
  const sig = quelle(256 * 20);
  const R = baueRohpuffer();
  for (let s = 4; s <= 8; s++) R.rohAnhaengen(fenster(sig, s, 4, 256), 'p');
  R.rohAnhaengen({ samples: quelle(500).slice(0, 500), hz: 500 }, 'p');
  const s = R.rohStreifen(30);
  /* Zwei Abtastraten in einem Streifen waeren zwei Zeitachsen in einer Kurve. */
  pruef('ein Ratenwechsel leert den Puffer', Math.abs(s.sekunden - 1) < 0.01, s.sekunden + ' s');
  pruef('und die neue Rate gilt', s.hz === 500, String(s.hz));
}
{
  const sig = quelle(256 * 120);
  const R = baueRohpuffer();
  /* Deckel: der Puffer darf nicht wachsen, solange niemand archiviert. 100 s Signal
   * gegen ROH_MAX_SEK. */
  for (let s = 4; s <= 100; s++) R.rohAnhaengen(fenster(sig, s, 4, 256), 'p');
  pruef('der Puffer laeuft nicht davon',
    R.ROH.werte.length <= R.ROH_MAX_SEK * 256, (R.ROH.werte.length / 256) + ' s bei Deckel ' + R.ROH_MAX_SEK);
  const s = R.rohStreifen(30);
  pruef('haelt aber genug fuer einen 30-s-Streifen', Math.abs(s.sekunden - 30) < 0.01, String(s.sekunden));
  pruef('der dann nicht als angeschnitten gilt', s.angeschnitten === false);
  /* Und er muss das ENDE zeigen, nicht den Anfang - archiviert wird, was gerade war. */
  pruef('und er endet auf dem juengsten Wert',
    s.werte[s.werte.length - 1] === R.ROH.werte[R.ROH.werte.length - 1]);
}
{
  const R = baueRohpuffer();
  pruef('leerer Puffer liefert null statt eines leeren Streifens', R.rohStreifen(30) === null);
  R.rohAnhaengen(null, 'p');
  R.rohAnhaengen({ samples: [], hz: 256 }, 'p');
  pruef('leere Lieferungen werden gar nicht erst aufgenommen', R.rohStreifen(30) === null);
}
{
  /* Die Ueberlappungssuche selbst, an kleinen Reihen von Hand nachvollziehbar. */
  const R = baueRohpuffer();
  pruef('volle Ueberlappung wird erkannt', R.rohUeberlappung([1, 2, 3], [1, 2, 3]) === 3);
  pruef('teilweise Ueberlappung wird erkannt', R.rohUeberlappung([1, 2, 3, 4], [3, 4, 5]) === 2);
  pruef('keine Ueberlappung ergibt 0', R.rohUeberlappung([1, 2, 3], [7, 8, 9]) === 0);
  /* Die LAENGSTE Lage gewinnt: bei [1,2,1,2] und [1,2,1,2,9] passt sowohl k=2 als auch k=4.
   * Wuerde die kurze gewinnen, kaemen zwei Werte doppelt in den Puffer. */
  pruef('bei mehreren moeglichen Lagen gewinnt die laengste',
    R.rohUeberlappung([1, 2, 1, 2], [1, 2, 1, 2, 9]) === 4);
  /* Luecken (null) sind Werte wie andere auch - sie duerfen die Suche nicht sprengen. */
  pruef('Luecken stoeren die Suche nicht', R.rohUeberlappung([1, null, 3], [null, 3, 4]) === 2);
}
{
  /* GROESSE — der Grund, warum NICHT durchgehend aufgezeichnet wird, und der Grund, warum
   * Taktstreifen kuerzer sind als Befundstreifen.
   *
   * DIESE ZAHLEN WAREN ERST GESCHAETZT UND DANN FALSCH: der Entwurf ging von 9 KB je
   * 30-Sekunden-Rohstreifen aus. Gemessen sind es 20 KB - 96 Taktstreifen waeren damit
   * 2,2 MB gewesen, in einem Speicher von ueblicherweise 5 MB. Deshalb stehen die Grenzen
   * hier als Messung und nicht als Annahme. */
  const U = baueUmgebung(5 * 1024 * 1024);
  const R = baueRohpuffer();
  const sig = quelle(256 * 60);
  for (let s = 4; s <= 45; s++) R.rohAnhaengen(fenster(sig, s, 4, 256), 'p');
  const kb = (sek) => U.samplesNachB64(R.rohStreifen(sek).werte).b64.length / 1024;
  const lang = kb(30), kurz = kb(10);
  pruef('30 s bei 256 Hz kosten rund 20 KB', lang > 19 && lang < 21, Math.round(lang * 10) / 10 + ' KB');
  pruef('10 s bei 256 Hz kosten rund 6,8 KB', kurz > 6 && kurz < 7.5, Math.round(kurz * 10) / 10 + ' KB');
  /* Ein Anzeigestreifen (9 s bei 75 Hz) kommt bei jedem Eintrag dazu: rund 1,8 KB. */
  const ANZEIGE_KB = 1.8;
  pruef('96 Taktstreifen (8 Stunden) bleiben unter 1 MB',
    (kurz + ANZEIGE_KB) * 96 < 1024, Math.round((kurz + ANZEIGE_KB) * 96) + ' KB');
  pruef('30 Befundstreifen bleiben unter 1 MB',
    (lang + ANZEIGE_KB) * 30 < 1024, Math.round((lang + ANZEIGE_KB) * 30) + ' KB');
  /* Und die Gegenprobe zur Entwurfsentscheidung: mit 30 s auch fuer Taktstreifen waere es
   * NICHT aufgegangen. Genau das hat diese Messung verhindert. */
  pruef('mit 30 s auch fuer Taktstreifen waere es ueber 2 MB gewesen (Gegenprobe)',
    (lang + ANZEIGE_KB) * 96 > 2048, Math.round((lang + ANZEIGE_KB) * 96) + ' KB');
}
{
  /* Und die Laenge muss vom Anlass abhaengen - sonst waere die Rechnung oben Makulatur. */
  const quellText = src.replace(/\/\*[\s\S]*?\*\//g, ' ');
  pruef('der Taktstreifen holt 10 s, alles andere 30 s',
    /streifen\(anlass==='takt'\?10:30\)/.test(quellText));
}

/* ================================================================================
 * 6. TAKTSTREIFEN HABEN EIN EIGENES KONTINGENT
 *
 * Eine dreistuendige Narkose legt im 5-Minuten-Takt 36 Streifen ab. Lagen die im selben
 * Topf wie die Befundstreifen, fraesse die Routine genau das auf, wofuer es das Archiv gibt.
 * ============================================================================== */
block('6. Taktstreifen verdraengen keine Befunde');
{
  const U = baueUmgebung(5 * 1024 * 1024);
  const liste = [];
  for (let i = 0; i < 20; i++) liste.push({ id: 'h' + i, ts: 1000 + i, anlass: 'hand' });
  for (let i = 0; i < 10; i++) liste.push({ id: 'a' + i, ts: 2000 + i, anlass: 'auto', ausloeser: ['ves' + i] });
  /* 200 Taktstreifen - weit mehr als der Deckel, und ALLE neuer als der Rest. */
  for (let i = 0; i < 200; i++) liste.push({ id: 't' + i, ts: 9000 + i, anlass: 'takt' });
  const raus = U.archAufraeumen(liste);
  pruef('alle 20 von Hand bleiben', raus.filter((x) => x.anlass === 'hand').length === 20,
    String(raus.filter((x) => x.anlass === 'hand').length));
  pruef('alle 10 Befundstreifen bleiben', raus.filter((x) => x.anlass === 'auto').length === 10,
    String(raus.filter((x) => x.anlass === 'auto').length));
  const takt = raus.filter((x) => x.anlass === 'takt').length;
  pruef('hoechstens ' + U.ARCH_MAX_TAKT + ' Taktstreifen', takt <= U.ARCH_MAX_TAKT, String(takt));
  pruef('und die Gesamtzahl bleibt unter dem Deckel', raus.length <= U.ARCH_MAX, String(raus.length));
  pruef('von den Taktstreifen bleiben die NEUESTEN',
    raus.some((x) => x.id === 't199') && !raus.some((x) => x.id === 't0'));
}
{
  /* DER FALL, DER DEN GESAMTDECKEL WIRKLICH ERREICHT.
   *
   * Der Fall darueber blieb mit 126 Eintraegen unter ARCH_MAX - eine absichtlich eingebaute
   * Fehlfassung (am Ende noch einmal nach Zeit auf ARCH_MAX abschneiden) blieb deshalb
   * unbemerkt. Erst wenn die Summe den Deckel UEBERSCHREITET, zeigt sich, ob der Platz nach
   * Rang oder nach Zeit vergeben wird. Hier sind alle Taktstreifen NEUER als jeder
   * Handstreifen: eine Sortierung nach Zeit wuerde saemtliche Handstreifen wegwerfen. */
  const U = baueUmgebung(5 * 1024 * 1024);
  const liste = [];
  for (let i = 0; i < 60; i++) liste.push({ id: 'h' + i, ts: 100 + i, anlass: 'hand' });
  for (let i = 0; i < 150; i++) liste.push({ id: 't' + i, ts: 90000 + i, anlass: 'takt' });
  const raus = U.archAufraeumen(liste);
  pruef('bei Ueberschreitung des Gesamtdeckels bleiben ALLE 60 Handstreifen',
    raus.filter((x) => x.anlass === 'hand').length === 60,
    String(raus.filter((x) => x.anlass === 'hand').length));
  pruef('und es wird der Deckel eingehalten', raus.length <= U.ARCH_MAX, String(raus.length));
  pruef('geopfert wurden Taktstreifen, obwohl sie die neueren sind',
    raus.filter((x) => x.anlass === 'takt').length === U.ARCH_MAX - 60,
    String(raus.filter((x) => x.anlass === 'takt').length));
}
{
  /* Bei Speicherdruck weicht zuerst die Routine - nicht der Befund. */
  const U = baueUmgebung(11000);
  const gross = 'x'.repeat(2400);
  const liste = [
    { id: 'neu', ts: 99, anlass: 'hand', b64: gross },
    { id: 'befund', ts: 10, anlass: 'auto', ausloeser: ['av-block'], b64: gross },
    { id: 'takt1', ts: 50, anlass: 'takt', b64: gross },
    { id: 'takt2', ts: 60, anlass: 'takt', b64: gross },
    { id: 'takt3', ts: 70, anlass: 'takt', b64: gross },
  ];
  const erg = U.archSave(liste);
  pruef('es wird Platz geschaffen', erg.ok === true, JSON.stringify(erg));
  const drin = U.archLoad();
  pruef('der Befundstreifen ueberlebt den Speicherdruck',
    drin.some((x) => x.id === 'befund'), drin.map((x) => x.id).join(','));
  pruef('der von Hand gespeicherte ebenfalls', drin.some((x) => x.id === 'neu'));
  pruef('geopfert wurden TAKTstreifen', drin.filter((x) => x.anlass === 'takt').length < 3);
}

/* ================================================================================
 * 7. DIE QUELLE SAGT, WAS SIE TUT
 * ============================================================================== */
block('7. Quellpruefung');
const code = src.replace(/\/\*[\s\S]*?\*\//g, ' ');
pruef('kein ganzes Blattbild mehr im Datensatz',
  !/png:\s*full/.test(code), 'png:full steht noch im Code');
pruef('das Signal wird abgelegt', /b64:kod\.b64/.test(code));
pruef('die Abtastrate wird mitgespeichert', /hz:hz/.test(code));
pruef('die Geraeterate ebenfalls (sie ist eine andere)', /hzGeraet:/.test(code));
pruef('die Patientendaten werden eingefroren', /patId:d\.patId/.test(code));
pruef('die Messwerte von damals kommen mit', /mess:B\?\{/.test(code));
pruef('automatisch wird nur bei ECHTEM Signal archiviert', /if\(!M\.echt\) return;/.test(code));
pruef('nicht bei unbrauchbarem Streifen', /guete<3\) return;/.test(code));
pruef('nicht oefter als der Mindestabstand', /AUTO_ABSTAND_MS/.test(code));
/* Die Sperre gilt JE VERDACHTSKLASSE. Global wuerde ein gerade gespeicherter
 * Extrasystolen-Streifen fuer 90 s auch eine danach einsetzende Bradykardie unterdruecken. */
pruef('die Sperre gilt je Verdachtsklasse, nicht global',
  /M\.autoTs\[id\]/.test(code) && !/if\(M\.letzteAutoTs/.test(code));
/* Nachlauf: kein untersuchtes Ereignissystem speichert nur bis zum Erkennungszeitpunkt. */
pruef('es gibt einen Nachlauf-Streifen', /NACHLAUF_MS/.test(code));
pruef('er ist als Verlauf gekennzeichnet', /rolle='verlauf'/.test(code));
pruef('und der erste als Beginn', /rolle='beginn'/.test(code));
pruef('der Nachlauf haengt am ersten Streifen', /gehoertZu\s*=\s*rec\.id/.test(code));
pruef('technische Hinweise loesen NICHTS aus', /if\(e\.technik\) continue;/.test(code));
pruef('das Vorschaubild wird gezeichnet, nicht gespeichert', /function archThumb/.test(code));
pruef('es gibt einen CSV-Ausgang der Abtastwerte', /data-csv/.test(code));
/* Rohpuffer und Taktstreifen (09.08.2026) */
pruef('der Rohpuffer wird beim Eintreffen echter Werte gefuellt',
  /rohAnhaengen\(out\.ekg/.test(code));
pruef('und beim Abmelden des Geraets geleert', /mon\.real=null;\s*rohLeeren\(\)/.test(code));
pruef('der Rohstreifen liegt im Datensatz', /roh:\(function\(\)/.test(code));
pruef('mit seiner eigenen Abtastrate', /hz:r\.hz,/.test(code));
pruef('und mit dem Vermerk, ob er angeschnitten ist', /angeschnitten:r\.angeschnitten/.test(code));
/* DIE STELLE, DIE OHNE MESSUNG TOT GEWESEN WAERE: archDatensatz() steht in einer ANDEREN
 * IIFE als der Rohpuffer. Ein direkter Aufruf von rohStreifen() waere dort ein
 * ReferenceError - und JEDES Speichern, auch das von Hand, waere fehlgeschlagen. */
pruef('der Puffer wird ueber window herausgereicht', /window\.__ekgRoh\s*=/.test(code));
pruef('und das EKG-Submodul greift auch darueber zu, nicht direkt',
  /R\.streifen\(anlass==='takt'\?10:30\)/.test(code));
pruef('rohStreifen wird NIRGENDS ueber die IIFE-Grenze direkt gerufen',
  (code.match(/[^.\w]rohStreifen\(/g) || []).length <= 1,
  'direkte Aufrufe: ' + (code.match(/[^.\w]rohStreifen\(/g) || []).length);
/* Die Kennung kommt von aussen, weil state.patientId im iframe nie gesetzt wird. */
pruef('die Patientenkennung kommt als Aufrufwert herein',
  /__setRealWave=function\(map, patKennung\)/.test(code));
pruef('und wird NICHT aus dem toten state.patientId gezogen',
  !/rohAnhaengen\([^)]*state\.patientId/.test(code));
pruef('die Ueberlappung wird abgeglichen statt stumpf angehaengt',
  /function rohUeberlappung/.test(code));
pruef('und ohne jede Uhrzeit (ein Zeitsprung darf keinen Bruch vortaeuschen)',
  !/Date\.now\(\)/.test(code.slice(code.indexOf('var ROH={'), code.indexOf('window.__ekgRoh'))));
pruef('es gibt Taktstreifen', /function taktArchiv/.test(code));
pruef('sie werden nach jedem Befund geprueft', /taktArchiv\(B\);/.test(code));
pruef('im 5-Minuten-Takt', /TAKT_ABSTAND_MS=300000/.test(code));
pruef('nur bei ECHTEM Signal (wie beim Ereignisspeicher)',
  /function taktArchiv\(B\)\{\s*if\(!M\.echt\) return;/.test(code.replace(/\n\s*/g, ' ').replace(/function taktArchiv\(B\) \{/, 'function taktArchiv(B){')));
pruef('der erste Befund stellt nur die Uhr, er speichert nicht',
  /if\(!M\.taktTs\)\{ M\.taktTs=t; return; \}/.test(code));
pruef('unmittelbar nach einem Befundstreifen schweigt der Takt',
  /TAKT_MINDESTABSTAND_MS/.test(code));
pruef('Taktstreifen haben ein eigenes Kontingent', /ARCH_MAX_TAKT/.test(code));
pruef('bei Speicherdruck weichen sie zuerst',
  /anlass==='takt'\)\{ idx=i; break; \}/.test(code));
pruef('die CSV gibt den feineren Streifen aus', /var nutzeRoh=/.test(code));

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
