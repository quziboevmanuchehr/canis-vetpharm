'use strict';
/*
 * ekg2000-format.js — aus einem rohen Bytestrom herauslesen, WIE das EKG 2000 spricht.
 *
 * WARUM ES DIESE DATEI GIBT (13.08.2026):
 * Das serielle Datenformat des Eickemeyer/Grimed EKG 2000 ist nirgends veroeffentlicht.
 * Nachgesehen wurde: das Produktblatt (321018), das englische Handbuch, zwei
 * Internetrecherchen und die mitgelieferten Treiberdateien. Die Programmdateien des
 * Herstellers liegen in einem VERSCHLUESSELTEN Archiv (EKG.cab ist eine ZIP mit gesetztem
 * Verschluesselungsflag) - daran wird nicht gearbeitet.
 *
 * Bleibt der ehrliche Weg: das Geraet SELBST fragen. Es haengt am USB, es sendet etwas,
 * und aus dem, was es sendet, laesst sich die Struktur ableiten - ohne eine einzige
 * Annahme ueber den Hersteller.
 *
 * DIE REGEL DIESES PROJEKTS GILT AUCH HIER: sie misst und schweigt im Zweifel. Dieses
 * Modul RAET NICHT. Es sagt entweder "so ist der Strom aufgebaut, mit dieser Begruendung"
 * oder "kein erkennbares Muster". Eine erfundene Rahmenlaenge waere schlimmer als gar
 * keine: sie ergaebe eine Kurve aus Rauschen, der niemand misstraut, weil sie aussieht
 * wie ein EKG.
 *
 * Reine Funktionen, keine Ein-/Ausgabe - damit sie ohne Geraet mit aufgezeichneten
 * Stroemen pruefbar sind (tools/ekg2000-format-test.js).
 */

/* Baudraten, die bei FTDI-basierten Medizingeraeten ueberhaupt vorkommen. Bewusst eine
 * kurze Liste: jede zusaetzliche Rate verlaengert die Suche am Geraet um Sekunden, und
 * exotische Raten sind bei einem Seriell-Wandler dieser Bauart nicht zu erwarten.
 *
 * REIHENFOLGE GEAENDERT AM 16.08.2026, UND ZWAR NICHT NACH GEFUEHL:
 * Aus dem Maschinencode des Herstellerprogramms sind die beiden echten Raten inzwischen
 * bekannt - 19200 fuer die Anmeldung, 38400 fuer den Betrieb (Fundstellen stehen in
 * ekg2000-protokoll.js). Sie stehen deshalb vorn. Vorher begann die Suche bei 115200 und
 * arbeitete sich abwaerts: die richtige Rate kam als vierte dran, und die drei falschen
 * davor liefern jeweils Sekunden voll Buchstabensalat. Die uebrigen bleiben in der Liste,
 * weil eine andere Geraetegeneration abweichen KANN - das ist nicht ausgeschlossen worden. */
const BAUDRATEN = [19200, 38400, 115200, 57600, 9600, 230400, 460800, 921600];

/* ------------------------------------------------------------------------------------------
 * istPlausibelEkg — sieht dieser Strom ueberhaupt nach Nutzdaten aus?
 *
 * Die erste Frage bei einer falschen Baudrate ist nicht "welches Format", sondern "ist das
 * ueberhaupt etwas". Bei falscher Rate liefert ein UART Muell mit typischen Merkmalen:
 * die Bytewerte verteilen sich nahezu gleichmaessig ueber 0..255, und es gibt keine
 * wiederkehrende Struktur. Echte Messdaten sind anders - sie haben einen Schwerpunkt.
 * ---------------------------------------------------------------------------------------- */
function byteVerteilung(buf) {
  const n = new Array(256).fill(0);
  for (let i = 0; i < buf.length; i++) n[buf[i]]++;
  return n;
}

/* Entropie in Bit je Byte. Gleichverteilter Muell liegt bei ~8,0; strukturierte Messdaten
 * deutlich darunter. Das ist kein Beweis, aber ein sehr guter Vorfilter. */
function entropie(buf) {
  if (!buf.length) return 0;
  const n = byteVerteilung(buf);
  let h = 0;
  for (let i = 0; i < 256; i++) {
    if (!n[i]) continue;
    const p = n[i] / buf.length;
    h -= p * Math.log2(p);
  }
  return h;
}

/* ------------------------------------------------------------------------------------------
 * satzlaenge — wiederholt sich der Strom in festen Abstaenden?
 *
 * Fast jedes Messgeraet sendet Saetze fester Laenge (Kopf + Kanaele + Pruefsumme). Findet
 * man diese Laenge, hat man die halbe Struktur. Gesucht wird sie ueber die AUTOKORRELATION
 * der Bytewerte: bei der richtigen Satzlaenge liegen gleichartige Felder (Kopfbyte,
 * Kanalnummer) uebereinander und die Uebereinstimmung springt hoch.
 *
 * Warum nicht einfach nach einem Startbyte suchen: ein Startbyte kann auch als Nutzwert
 * auftreten. Die Autokorrelation braucht gar keine Annahme darueber, WELCHES Byte der
 * Kopf ist - sie findet die Periode aus dem Strom selbst.
 * ---------------------------------------------------------------------------------------- */
function satzlaenge(buf, maxLaenge) {
  const max = Math.min(maxLaenge || 512, Math.floor(buf.length / 8));
  if (max < 2) return null;
  const werte = [];
  for (let L = 2; L <= max; L++) {
    let gleich = 0, gesamt = 0;
    for (let i = 0; i + L < buf.length; i++) {
      if (buf[i] === buf[i + L]) gleich++;
      gesamt++;
    }
    werte.push({ laenge: L, anteil: gesamt ? gleich / gesamt : 0 });
  }
  if (!werte.length) return null;
  /* Der Grundwert: wie oft stimmen zwei Bytes zufaellig ueberein? Alles, was diesen Wert
   * deutlich uebertrifft, ist Struktur und kein Zufall. */
  const mittel = werte.reduce((s, w) => s + w.anteil, 0) / werte.length;
  let beste = werte[0];
  werte.forEach((w) => { if (w.anteil > beste.anteil) beste = w; });
  /* ----------------------------------------------------------------------------------
   * VIELFACHE ZURUECKNEHMEN - aber NUR auf einen gleich guten TEILER.
   *
   * Wer bei Satzlaenge 8 auch bei 16, 24, 32 einen Ausschlag sieht, hat immer noch
   * Satzlaenge 8: eine echte kuerzere Periode erklaert den Strom mindestens ebenso gut.
   *
   * DER ERSTE ENTWURF NAHM "die kleinste Laenge oberhalb 60 % des Gipfels" - und das war
   * falsch, gemessen am nachgebildeten 12-Kanal-Strom (13.08.2026): bei 16-Bit-Werten um
   * 2048 ist das HIGH-BYTE fast immer 0x08. Jedes zweite Byte ist damit nahezu konstant,
   * und L=2 bekommt 0,41 - deutlich ueber der Schwelle, aber deutlich UNTER dem echten
   * Gipfel bei L=26 (0,484). Die Regel stieg also auf einen SCHLECHTEREN Teiler herab und
   * lieferte Satzlaenge 2. Ein Adapter haette den Strom danach in Zweibytehaeppchen
   * zerschnitten und zwoelf Kanaele zu einem Rauschen verruehrt.
   *
   * Richtig ist: nur ein TEILER des Gipfels kommt in Frage, und nur wenn er praktisch
   * genauso gut ist (>= 98 %). Ein echter kuerzerer Takt ist nie schlechter als sein
   * eigenes Vielfaches - ist er es doch, war er nie der Takt.
   * -------------------------------------------------------------------------------- */
  let kleinste = beste;
  werte.forEach((w) => {
    if (w.laenge >= kleinste.laenge) return;
    if (beste.laenge % w.laenge !== 0) return;              /* kein Teiler - kein Kandidat */
    if (w.anteil < beste.anteil * 0.98) return;             /* schlechter - also nicht der Takt */
    kleinste = w;
  });
  return {
    laenge: kleinste.laenge,
    staerke: kleinste.anteil,
    grundwert: mittel,
    /* Ein Verhaeltnis unter 2 heisst: kaum ueber dem Zufall. Dann wird NICHTS behauptet. */
    sicher: mittel > 0 && (kleinste.anteil / mittel) >= 2.0,
  };
}

/* ------------------------------------------------------------------------------------------
 * feldStabilitaet — welche Stellen im Satz sind fest, welche veraenderlich?
 *
 * Bei bekannter Satzlaenge verraet das die Rolle jedes Bytes:
 *   fast immer gleich   -> Kopf-/Startbyte oder Kennung
 *   staendig anders     -> Messwert
 *   langsam steigend    -> Zaehler
 * Genau diese Aufteilung braucht ein Adapter, um Messwerte von Verwaltung zu trennen.
 * ---------------------------------------------------------------------------------------- */
function feldStabilitaet(buf, laenge) {
  const felder = [];
  for (let f = 0; f < laenge; f++) {
    const werte = [];
    for (let i = f; i < buf.length; i += laenge) werte.push(buf[i]);
    if (werte.length < 4) { felder.push(null); continue; }
    const zaehl = {};
    werte.forEach((v) => { zaehl[v] = (zaehl[v] || 0) + 1; });
    let haeufigster = 0, haeufigkeit = 0;
    Object.keys(zaehl).forEach((k) => { if (zaehl[k] > haeufigkeit) { haeufigkeit = zaehl[k]; haeufigster = +k; } });
    /* Steigt der Wert ueberwiegend um 1? Dann ist es ein Zaehler - ein sehr sicheres Zeichen. */
    let schritte1 = 0;
    for (let i = 1; i < werte.length; i++) if (((werte[i] - werte[i - 1]) & 0xff) === 1) schritte1++;
    felder.push({
      stelle: f,
      konstanz: haeufigkeit / werte.length,
      wert: haeufigster,
      zaehler: werte.length > 8 && (schritte1 / (werte.length - 1)) > 0.8,
      spanne: Math.max.apply(null, werte) - Math.min.apply(null, werte),
    });
  }
  return felder;
}

/* ------------------------------------------------------------------------------------------
 * deute — alles zusammen zu einer Aussage, oder zu einem ehrlichen "weiss nicht".
 * ---------------------------------------------------------------------------------------- */
function deute(buf) {
  const e = entropie(buf);
  const aus = {
    bytes: buf.length,
    entropie: Math.round(e * 100) / 100,
    /* Ueber 7,5 Bit/Byte ist der Strom praktisch gleichverteilt - das ist das Bild einer
     * FALSCHEN Baudrate, nicht das von Messdaten. */
    sinnvoll: buf.length >= 256 && e < 7.5,
    satz: null,
    felder: null,
    urteil: '',
  };
  if (!buf.length) { aus.urteil = 'Es kam gar nichts an.'; return aus; }
  if (!aus.sinnvoll) {
    aus.urteil = buf.length < 256
      ? 'Zu wenig Daten (' + buf.length + ' Byte) fuer eine Aussage.'
      : 'Der Strom ist praktisch gleichverteilt (Entropie ' + aus.entropie + ' Bit/Byte). '
        + 'Das ist das Bild einer falschen Baudrate, nicht das von Messdaten.';
    return aus;
  }
  const s = satzlaenge(buf);
  aus.satz = s;
  if (!s || !s.sicher) {
    aus.urteil = 'Daten kommen an und sind nicht gleichverteilt, aber es ist KEINE feste '
      + 'Satzlaenge erkennbar. Moeglich sind ein textbasiertes Format oder variable Rahmen.';
    return aus;
  }
  aus.felder = feldStabilitaet(buf, s.laenge);
  const feste = aus.felder.filter((f) => f && f.konstanz > 0.9);
  const zaehler = aus.felder.filter((f) => f && f.zaehler);
  aus.urteil = 'Feste Satzlaenge ' + s.laenge + ' Byte (Uebereinstimmung '
    + Math.round(s.staerke * 100) + ' % gegen ' + Math.round(s.grundwert * 100) + ' % Zufall). '
    + feste.length + ' gleichbleibende Stelle(n)'
    + (feste.length ? ' bei Byte ' + feste.map((f) => f.stelle + '=0x' + f.wert.toString(16)).join(', ') : '')
    + (zaehler.length ? '; Zaehler bei Byte ' + zaehler.map((f) => f.stelle).join(', ') : '')
    + '.';
  return aus;
}

module.exports = { BAUDRATEN, entropie, byteVerteilung, satzlaenge, feldStabilitaet, deute };
