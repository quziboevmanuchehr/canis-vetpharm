'use strict';
/*
 * geraetekatalog.js — WELCHE Geraete gibt es, und WIE kommt man an ihre Daten?
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 01.08.2026, woertlich):
 * "Es muss auch Verbindung und Infrastruktur fuer die andere Narkosegeraete und auch die
 *  Monitorgeraete von Veterinaermedizin gebaut werden. [...] Je nach Narkosegeraet oder
 *  Monitorgeraet muss auch das App erkennen oder muss der Benutzer in Einstellung der Model das
 *  Geraet eingeben zu koennen, um zu Empfehlungen fuer Verbindung das App geben kann."
 *
 * Bis hierher kannte die Station GENAU EINE Geraetefamilie: Mindray/Eickemeyer ueber HL7. Alles
 * Wissen darueber — welcher Port, welcher Menuepfad, welches Passwort, was ein Geraet wirklich
 * sendet — lag verstreut in Kommentaren, in docs/*.md und im Kopf dessen, der dabei war. Ein
 * Tierarzt mit einem Draeger, einem Bionet oder einem WATO stand vor einer Station, die schwieg.
 *
 * DIESE DATEI IST DAS GEDAECHTNIS. Sie ist reine Daten plus ein paar Nachschlagefunktionen:
 *   - netscan.DATA_PORTS  (worauf gelauscht wird)          -> katalog.datenPorts()
 *   - geraetefund.MEDIZIN_OUI (welche MAC ist ein Geraet)  -> katalog.ouiListe()
 *   - die Modellauswahl im Admin-Bereich                   -> katalog.suche()
 *   - die automatische Erkennung (geraeteerkennung.js)     -> katalog.alle()
 *   - die Anleitung bei Fehlschlag (verbindungsberater.js) -> weg.schritte
 * Damit gibt es fuer jede dieser Fragen genau EINE Quelle. Genau daran ist am 31.07.2026 Port 5510
 * beinahe gescheitert: er musste an vier Stellen nachgetragen werden, und eine vergessene Stelle
 * heisst, dass ein Geraet sendet und niemand zuhoert — ohne jede Meldung, weil nie ein Byte ankommt.
 *
 * DIE WICHTIGSTE REGEL DIESER DATEI: `vertrauen` sagt die Wahrheit.
 *   'belegt'        = an einem echten Geraet gemessen ODER im Herstellerdokument nachgelesen.
 *   'wahrscheinlich'= gut begruendet (Baugleichheit, Herstellerfamilie), aber nicht nachgemessen.
 *   'unbestaetigt'  = Hinweis aus zweiter Hand. Wird dem Anwender AUCH SO angezeigt.
 * Ein Eintrag ohne Quelle ist ein Geruecht. Ein geratener Wert am narkotisierten Tier ist der
 * schlimmste Fehler, den dieses Programm machen kann — und ein geratener MENUEPFAD schickt einen
 * Tierarzt mitten im OP-Betrieb auf eine Suche, die nicht enden kann. Beides ist hier verboten.
 *
 * STRIKT READ-ONLY: dieser Katalog beschreibt ausschliesslich, wie man MITLIEST. Kein Eintrag
 * beschreibt je einen Weg, an einem Geraet etwas zu VERSTELLEN.
 */

/* ------------------------------------------------------------------ *
 * Wertebereiche. Bewusst klein gehalten — jede weitere Kategorie muss
 * die Oberflaeche und der Verbindungsberater auch bedienen koennen.
 * ------------------------------------------------------------------ */

/* Was ist das fuer ein Geraet? Bestimmt die Rolle beim Zusammenfuehren (matching.js). */
/* 'ekg' kam am 12.08.2026 dazu und ist bewusst KEIN 'monitor': ein Diagnostik-EKG haengt nicht
 * am narkotisierten Patienten und liefert keine Trendwerte, sondern einen Streifen zur
 * Befundung. Wer es unter 'monitor' fuehrt, bekommt es im Verbindungsberater neben Geraeten
 * angeboten, die den OP ueberwachen - und sucht dann an der falschen Stelle. */
const KATEGORIEN = ['monitor', 'narkose', 'beatmung', 'kapnograph', 'kombi', 'ekg'];

/* Wie kommt das Signal physisch zum PC? 'wlan' ist KEIN eigener Weg im Protokollsinn — es ist
 * 'lan' ueber eine Funkstrecke. Es steht trotzdem hier, weil ein Anwender danach sucht und weil
 * der Berater dafuer andere Schritte nennt (Client-Bridge statt Kabel). */
/* 'keiner' ist ein vollwertiger Wert und der wichtigste Eintrag ueberhaupt: sehr viele
 * Veterinaer-Narkosegeraete sind rein mechanisch-pneumatisch und haben schlicht keine Buchse.
 * Ein Katalog, der solche Geraete weglaesst, laesst den Tierarzt genau dort weitersuchen, wo es
 * nichts zu finden gibt — am Veta 5 hat das Tage gekostet. */
/* 'udp' ist seit 02.08.2026 ein eigener Wert und NICHT dasselbe wie 'lan'. Der Unterschied ist
 * kein Etikett: datenPorts() gibt nur 'lan'/'wlan' an die TCP-Lauschliste weiter. Ein UDP-Weg
 * (Philips Data Export, fest auf UDP 24105) gehoert dort nicht hinein — ein TCP-Lauscher empfaengt
 * dort nie ein Byte und meldet trotzdem "die Station hoert zu". */
const TRANSPORTE = ['lan', 'wlan', 'udp', 'seriell', 'usb', 'datei', 'keiner'];

/* Wer ruft wen an? Das entscheidet, ob die Station lauschen (Listener) oder anklopfen (Client) muss
 * — und es ist die Frage, an der die meiste Zeit verloren geht, weil beide Seiten "es sendet doch"
 * sagen und keiner die Richtung nennt. */
const RICHTUNGEN = ['geraet_sendet', 'pc_fragt_ab', 'beides', 'unbekannt'];

const VERTRAUEN = ['belegt', 'wahrscheinlich', 'unbestaetigt'];

/*
 * PORT-RANG — in welcher Reihenfolge wird gelauscht/geprueft?
 *
 * Der Rang steht AM WEG, nicht in einer zweiten Liste. Genau eine zweite Liste war das Problem,
 * das diese Datei aufloest. Kleiner Rang = zuerst. Ohne Angabe gilt RANG_NORMAL, danach wird
 * numerisch sortiert, damit die Reihenfolge bei gleichem Rang vorhersagbar bleibt.
 */
const RANG_ZUERST = 10;    // in der Praxis nachgewiesen und ab Werk eingetragen
const RANG_NORMAL = 50;
const RANG_SPAET = 90;     // Kandidat, nicht belegt

/* ------------------------------------------------------------------ *
 * DER KATALOG
 *
 * Aufbau eines Eintrags:
 *   id          eindeutig, kleingeschrieben, mit Bindestrichen (wird in devices.json gespeichert)
 *   hersteller  wie er auf dem Geraet steht
 *   modell      wie es auf dem Geraet steht
 *   aliase[]    Schreibweisen und Rebrands, unter denen jemand sucht
 *   kategorie   siehe KATEGORIEN
 *   einsatz     'vet' | 'human' | 'beides'
 *   oui[]       MAC-Praefixe (6 Hexzeichen, klein) — nur echte Hersteller-OUIs
 *   wege[]      Anbindungswege, BESTER ZUERST. Siehe unten.
 *   fallstricke Ein Satz, der die haeufigste Enttaeuschung vorwegnimmt.
 *   vertrauen   siehe VERTRAUEN — gilt fuer den Eintrag als Ganzes
 *   quellen[]   URLs/Dokumentnummern/eigene Messung mit Datum
 *
 * Aufbau eines Weges (wege[]):
 *   id          kurz, innerhalb des Geraets eindeutig
 *   name        was ein Mensch darunter versteht
 *   adapter     welcher Adapter aus bridge/src/adapters/ das kann ('hl7', 'probe', 'medibus', ...)
 *   transport   siehe TRANSPORTE
 *   richtung    siehe RICHTUNGEN
 *   port        TCP-Port (nur bei lan/wlan), sonst null
 *   rang        Reihenfolge beim Lauschen (siehe oben)
 *   vorlage     der fertige devices.json-Eintrag, den "Einrichten" schreibt (ohne id)
 *   liefert     WAS wirklich ankommt. Ehrlich, auch wenn es wenig ist.
 *   lizenz      'keine' | 'ja' | 'unklar' + Begruendung im Text
 *   schritte[]  was AM GERAET zu tun ist, in der Reihenfolge, in der man es tut
 *   vertrauen   siehe VERTRAUEN — gilt fuer DIESEN Weg
 *   keinAusgang true = auf diesem Weg kommt NIE etwas Lesbares. Der Verbindungsberater bricht
 *               die Fehlersuche dann ausdruecklich ab, statt den Anwender weitersuchen zu lassen.
 * ------------------------------------------------------------------ */

const KATALOG = [

  /* ================================================================
   * MINDRAY / EICKEMEYER — die Familie, die diese Station heute liest.
   * Alle Angaben hier sind an den Geraeten der Praxis GEMESSEN, nicht
   * abgeschrieben. Die Messungen stehen in docs/MINDRAY-HL7.md.
   * ================================================================ */

  {
    id: 'eickemeyer-lifevet-10c',
    hersteller: 'Eickemeyer',
    modell: 'LifeVet 10C',
    aliase: ['LifeVet 10', 'Eickemeyer 321920', 'Mindray ePM 10 Vet', 'ePM 10 Vet'],
    kategorie: 'kombi',
    einsatz: 'vet',
    /* NUR 000f14 — das ist die MAC, die am echten Geraet der Praxis gemessen wurde
     * (00:0f:14:2b:10:52, ARP-Tabelle 22.07.2026). 98:CC:E4 waere naheliegend, weil Mindray
     * dahintersteckt, ist an DIESEM Geraet aber nie gesehen worden. Naheliegend ist keine Quelle. */
    oui: ['000f14'],
    vertrauen: 'belegt',
    fallstricke: 'Das Geraet ist ein Mindray ePM 10 Vet mit Eickemeyer-Aufdruck. Im Handbuch stehen ' +
      'die Woerter "Mindray", "HL7" und "CMS" nicht — der Menuepfad existiert trotzdem.',
    quellen: [
      'eigene Messung Praxis-PC 2026-07 (docs/MINDRAY-HL7.md)',
      'https://www.eickemeyer.de/shop/321920-multiparameter-monitor-lifevet-10c-15534',
      'Mindray Patient Data Share Protocol Programmer\'s Guide v14, H-0010-20-43061',
    ],
    wege: [
      {
        id: 'hl7-push-8830',
        name: 'HL7: das Geraet sendet zum PC (Werkseinstellung)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 8830,
        rang: RANG_ZUERST,
        lizenz: 'keine',
        liefert: 'Zahlenwerte, Kurven und Alarme — dieses Geraet liefert nachweislich alles.',
        vertrauen: 'belegt',
        vorlage: null,   // der Verbindungs-Assistent lauscht ohnehin; kein eigener Eintrag noetig
        schritte: [
          'Am Monitor: Hauptmenue → Wartung → Benutzer-Wartung, Passwort 888888.',
          'Netzwerk → HL7-Konfiguration.',
          'Bei "Daten + Kurven" UND bei "Alarme" als Zieladresse die PC-Adresse eintragen (siehe oben in diesem Fenster).',
          'Den Port 8830 stehen lassen — die Station hoert dort ab Werk zu.',
          'Mit OK bestaetigen und das Fenster schliessen.',
        ],
      },
      {
        id: 'hl7-abfrage-4601',
        name: 'HL7: der PC fragt das Geraet ab (PDS-Realtime)',
        adapter: 'hl7',
        transport: 'lan',
        richtung: 'pc_fragt_ab',
        port: 4601,
        rang: RANG_NORMAL,
        lizenz: 'keine',
        liefert: 'Zahlenwerte und Alarme. Der Weg braucht keine Einstellung am Geraet, nur eine erreichbare Adresse.',
        vertrauen: 'belegt',
        vorlage: { type: 'hl7', mode: 'client', host: 'auto', port: 4601, role: 'combo', ack: true },
        schritte: [
          'Am Geraet ist nichts einzustellen — der PC klopft von sich aus an.',
          'Das Geraet muss im selben Netz erreichbar sein (Netzwerk-Suche im Reiter "Netzwerk & Geräte").',
          'Es kann immer nur EIN Programm gleichzeitig abfragen: ein parallel laufendes VSCapture blockiert diesen Weg.',
        ],
      },
    ],
  },

  {
    /*
     * KORREKTUR VOM 01.08.2026 — DIESES GERAET IST KEIN MINDRAY.
     *
     * Bis hierher lief das LifeVet M in diesem Projekt als "aeltere Eickemeyer-Baureihe" mit der
     * stillschweigenden Annahme, es gehoere wie das 10C zur Mindray-Familie. Die Recherche hat das
     * widerlegt: das Eickemeyer-Handbuch (Artikel 321870, Ausgabe April 2012) traegt im PDF-Titel
     * "iM8 VET Series Veterinary Monitor User Manual" und die EDAN-Dokumentnummer 01.54.455558.
     * Es ist eine EDAN-Plattform, und sie spricht mit "MFM-CMS" — EDANs eigener Zentralstation.
     *
     * WARUM DAS PRAKTISCH WICHTIG IST: der gesamte HL7-Code dieser Station hilft hier NICHT. Was
     * auf dem Server-Port ankommt, ist EDANs herstellereigener Binaerstrom, kein HL7. Die Monate
     * an Suche nach einem HL7-Menue an diesem Geraet waren deshalb aussichtslos — es gibt keines.
     * Die beiden Felder, die das Menue kennt (SERVER IP / SERVER PORT), zeigen auf die Zentrale
     * des Herstellers, nicht auf einen offenen Standard.
     */
    id: 'eickemeyer-lifevet-m',
    hersteller: 'Eickemeyer (Bauart: EDAN iM8 Vet)',
    modell: 'LifeVet M / LifeVet C',
    aliase: ['LifeVet-M', 'LifeVet M Monitor', 'LifeVet C', '321870', '321872', 'EDAN iM8 Vet'],
    kategorie: 'monitor',
    einsatz: 'vet',
    /* KEINE OUI eingetragen: die MAC-Praefixe von EDAN sind hier nicht belegt, und am Geraet der
     * Praxis wurde nie eine gesehen. Eine geratene OUI waere schlimmer als keine — sie wuerde einen
     * fremden Teilnehmer als Medizingeraet ausweisen. */
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'DIESES GERAET IST EIN EDAN, KEIN MINDRAY — der HL7-Weg der Station greift hier nicht. ' +
      'Sein Menue kennt nur SERVER IP und SERVER PORT; beide zeigen auf EDANs eigene Zentralstation ' +
      '(MFM-CMS), und was dort ankommt, ist ein herstellereigener Binaerstrom. Werkseinstellung der ' +
      'Server-IP ist 202.114.4.119 — eine Adresse, die in keiner Praxis existiert. Passwort der ' +
      'Benutzerwartung: ABC. Achtung beim Verkabeln: der Schwesternruf liegt auf Pin 7/8 DESSELBEN ' +
      'RJ45-Steckers wie das Netzwerk. Ohne CO2-Modul (C5 zeigt "-.-") gibt es kein EtCO2 — das ist ' +
      'Hardware, keine Einstellung.',
    quellen: [
      'LifeVet M User Manual, Eickemeyer Art. 321870, Release April 2012 (PDF-Titel "iM8 VET Series", EDAN-Dok. 01.54.455558)',
      'EDAN iM50/iM60/iM70/iM80/M50/M80 User Manual, P/N 01.54.457239',
      'eigene Messung Praxis-PC 31.07.2026 (Firmware 1.21(VET), Build 04.11.2013)',
    ],
    wege: [
      {
        id: 'mfm-cms-mitschnitt',
        name: 'EDAN-Zentralstationsstrom mitschneiden (kein HL7)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5510,
        rang: RANG_NORMAL,
        lizenz: 'ja — der vorgesehene Empfaenger ist EDANs kostenpflichtige Zentralstation MFM-CMS.',
        liefert: 'Kein HL7. Was ankommt, wird mitgeschrieben (data/probe-5510.log) und kann ausgewertet ' +
          'werden — gelesen wird es heute nicht, und geraten wird nichts.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Am Monitor: SYSTEM MENU → MAINTAIN → Passwort ABC → USER MAINTAIN.',
          'Feld "SERVER IP" auf die PC-Adresse setzen (ab Werk steht dort 202.114.4.119 — eine Adresse, ' +
            'die es hier nicht gibt; solange sie stehen bleibt, kann nichts ankommen).',
          'Feld "SERVER PORT" auf 5510 stehen lassen — dort hoert die Station zu.',
          'Zuerst am Geraet selbst pruefen: steht es in STANDBY oder ist ein Parameter rot durchgestrichen, ' +
            'misst es nichts und sendet nichts. Das ist kein Netzproblem.',
          'Danach im Reiter „Verbindung/Fehler" nachsehen, ob eine Verbindung ankommt. Der Mitschnitt ist ' +
            'die Grundlage, um bei Eickemeyer/EDAN gezielt nach einer offenen Schnittstelle zu fragen.',
        ],
      },
    ],
  },

  {
    id: 'mindray-umec12-vet',
    hersteller: 'Mindray',
    modell: 'uMEC12 Vet',
    aliase: ['uMEC 12 Vet', 'uMEC10 Vet', 'uMEC15 Vet', 'uMEC6 Vet', 'M2K302'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: ['98cce4'],
    vertrauen: 'belegt',
    fallstricke: 'An diesem Geraet (System-Software 01.13.00) wurde ueber Wochen nachgewiesen: es sendet ueber ' +
      'HL7 NUR Patientendaten, aperiodischen Blutdruck (NIBP) und Alarmtexte — KEINE laufenden Zahlenwerte ' +
      '(HF/SpO2/Temp/AF) und keine Kurven. Das ist keine Fehleinstellung und kein Fehler der Station: die ' +
      'Vet-Firmware hat den Menuepunkt "Send Data"/"HL7 Configuration" gar nicht, den die Humanmodelle haben. ' +
      'Freischaltung nur ueber Eickemeyer/Mindray oder eine echte eGateway-Box.',
    quellen: [
      'eigene Messungen 24.-26.07.2026, mehrere Mitschnitte (docs/MINDRAY-HL7.md)',
      'Fotos des vollstaendigen Netzwerk-Setup-Menues 26.07.2026',
      'uMEC Operator\'s Manual §23.16.8',
    ],
    wege: [
      {
        id: 'hl7-abfrage-4601',
        name: 'HL7: der PC fragt das Geraet ab (PDS-Realtime)',
        adapter: 'hl7',
        transport: 'lan',
        richtung: 'pc_fragt_ab',
        port: 4601,
        rang: RANG_ZUERST,
        lizenz: 'keine',
        liefert: 'Blutdruck (NIBP) und ALLE Alarme — nachgewiesen. Laufende Zahlenwerte kommen an diesem ' +
          'Geraet nicht, egal was eingestellt wird.',
        vertrauen: 'belegt',
        vorlage: { type: 'hl7', mode: 'client', host: 'auto', port: 4601, role: 'combo', ack: true },
        schritte: [
          'Am Monitor: Hauptmenue → Wartung → Benutzer-Wartung, Passwort 888888.',
          'Netzwerk-Setup → "HL7 Compatibility" auf EIN. Ohne diesen Schalter kommt gar nichts.',
          'Die IP des Monitors notieren (Monitornetzwerk-Setup) — oder in devices.json "host": "auto" lassen, ' +
            'dann folgt die Station dem Geraet von selbst.',
          'NICHT die "Gateway-Kommunikationseinst." auf den PC stellen: das ist der herstellereigene ' +
            'CMS-Weg (MD2), er braucht eine eGateway-Box und hat am 25.07.2026 den funktionierenden Weg zerstoert.',
        ],
      },
      {
        /*
         * DIESER WEG STEHT HIER, DAMIT NIEMAND IHN NOCH EINMAL VERSUCHT.
         * Er ist ab Werk im Geraet eingetragen (Ziel 192.168.0.99:3502) und sieht deshalb aus wie
         * DER vorgesehene Weg. Am 25.07.2026 wurde er ausprobiert: er lieferte nichts und legte
         * zusaetzlich den funktionierenden Abfrageweg lahm. Der Port bleibt trotzdem in der
         * Lauschliste — kommt dort etwas an, schreibt der Verbindungs-Assistent es mit, und dann
         * weiss man wenigstens, WAS das Geraet dorthin schickt.
         */
        id: 'gateway-md2-3502',
        name: 'Gateway-Kommunikation (MD2) — NICHT nutzbar ohne eGateway',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 3502,
        rang: RANG_ZUERST,
        lizenz: 'ja — braucht eine echte Mindray-eGateway-Box, nicht nur einen lauschenden PC.',
        liefert: 'Nichts Lesbares. Das ist Mindrays eigenes Binaerprotokoll (MD2), kein HL7.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Diesen Weg NICHT einrichten. Er ist hier nur aufgefuehrt, damit klar ist, warum die ' +
            'Werkseinstellung des Geraets ins Leere laeuft.',
          'Steht unter "Gateway-Kommunikationseinst." die PC-Adresse, wieder auf einen unbenutzten ' +
            'Wert zurueckstellen — sonst stoert dieser Weg die HL7-Abfrage.',
        ],
      },
    ],
  },

  {
    id: 'mindray-epm-n-serie',
    hersteller: 'Mindray',
    modell: 'ePM / BeneVision N-Serie (Humanmodelle)',
    aliase: ['ePM 10', 'ePM 12', 'ePM 15', 'BeneVision N1', 'N12', 'N15', 'N17', 'MINDRAY_N-SERIES'],
    kategorie: 'monitor',
    einsatz: 'human',
    oui: ['98cce4'],
    vertrauen: 'wahrscheinlich',
    fallstricke: 'Diese Firmware-Linie hat — anders als die Vet-Geraete — einen eigenen Reiter ' +
      '"HL7 Configuration" mit den Schaltern "Send Data" und "Send Waveforms". Genau dieser Reiter fehlt ' +
      'auf der uMEC-Vet-Firmware. Wer ein Humanmodell in der Tierklinik stehen hat, kommt damit an die ' +
      'laufenden Zahlenwerte.',
    quellen: [
      'Xchart ePM-Einrichtungsanleitung (xcharthelp.com/en/articles/9147202)',
      'Mindray VS-900 Operator\'s Manual S. 122',
    ],
    wege: [
      {
        id: 'hl7-push-5000',
        name: 'HL7: das Geraet sendet Daten und Kurven zum PC ("Send Data")',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5000,
        rang: RANG_NORMAL,
        lizenz: 'unklar — im Handbuch der N-Serie ist von einer Lizenz die Rede; auf mehreren Geraeten ist der Schalter ohne Lizenz da.',
        liefert: 'Laufende Zahlenwerte und wahlweise Kurven.',
        vertrauen: 'wahrscheinlich',
        vorlage: null,
        schritte: [
          'Am Monitor: Hauptmenue → Wartung (Maintenance) → Benutzer-Wartung, Passwort MIN888 (N-Serie) bzw. 888888.',
          'Netzwerk-Setup → mit ">>" bis zum Reiter "HL7 Configuration" blaettern.',
          'Server-Adresse = PC-Adresse, Port 5000 (die Station hoert auch auf 4601).',
          '"Send Data" = EIN, Datenintervall auf den kleinsten Wert, "Send Waveforms" nach Bedarf EIN.',
          'Schliessen (X) und den Monitor neu starten.',
          'Tipp aus der Anleitung: einen SpO2-Sensor angesteckt lassen, sonst geht der Monitor in den Ruhezustand und die Netzverbindung schlaeft mit ein.',
        ],
      },
      {
        id: 'hl7-abfrage-4601',
        name: 'HL7: der PC fragt das Geraet ab (PDS-Realtime)',
        adapter: 'hl7',
        transport: 'lan',
        richtung: 'pc_fragt_ab',
        port: 4601,
        rang: RANG_NORMAL,
        lizenz: 'keine',
        liefert: 'Zahlenwerte und Alarme, sofern die PDS-Realtime-Schnittstelle des Geraets frei ist.',
        vertrauen: 'wahrscheinlich',
        vorlage: { type: 'hl7', mode: 'client', host: 'auto', port: 4601, role: 'combo', ack: true },
        schritte: [
          'Am Geraet ist nichts einzustellen.',
          'Das Geraet muss im selben Netz erreichbar sein.',
        ],
      },
    ],
  },

  {
    id: 'mindray-veta-5',
    hersteller: 'Mindray Animal Care',
    modell: 'Veta 5 / Veta 5 Plus',
    aliase: ['Veta 5Plus', 'Veta5', 'Veta 5 Plus Narkosegeraet'],
    kategorie: 'narkose',
    einsatz: 'vet',
    oui: ['98cce4'],
    vertrauen: 'belegt',
    fallstricke: 'DIESES GERAET HAT KEINEN OFFENEN DATENAUSGANG. Sein Netzwerk-Menue kennt nur MD2 ' +
      '(herstellereigenes Binaerprotokoll) und die CentralStation — kein HL7, kein Datenexport. Auf Port ' +
      '4601 antwortet es zwar, sendet dort aber MD2 (Rahmen 0x02, Synchronwort A5 5A). VetStation liest das ' +
      'NICHT und raet es NICHT: ein geratener Beatmungswert am narkotisierten Tier waere gefaehrlich. ' +
      'Bis zu einer Freischaltung durch Mindray/Eickemeyer bleibt das virtuelle Narkosegeraet handbedient — ' +
      'der Beatmungs-Berater arbeitet dann mit den ECHTEN Monitorwerten weiter.',
    quellen: [
      'Fotos des System→Netzwerk-Menues 26.07.2026 (nur MD2 + CentralStation)',
      'eigener Mitschnitt probe-4601.log: 0x02 / A5 5A = MD2',
      'docs/VETA5-MITSCHNITT.md',
    ],
    wege: [
      {
        id: 'mitschnitt-pruefen',
        name: 'Erst beweisen, ob dieses Exemplar HL7 kann',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'beides',
        port: 4601,
        rang: RANG_SPAET,
        lizenz: 'unklar — im Menue dieses Geraets gibt es keinen HL7-Schalter. Ob Mindray/Eickemeyer einen ' +
          'freischalten kann, ist offen und nur beim Haendler zu erfahren.',
        liefert: 'Nichts Lesbares, solange nur MD2 kommt. Der Mitschnitt sagt, was wirklich anliegt.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Mitschnitt starten: node tools/veta5-mitschnitt.js --host <IP des Veta> --port 4601',
          'Zeigt der Mitschnitt ein MSH-Segment, spricht das Geraet HL7 — dann in devices.json den Eintrag "veta5" einschalten.',
          'Zeigt er 0x02 / A5 5A, ist es MD2. Dann hilft nur eine Freischaltung durch Eickemeyer/Mindray.',
          'Achtung auf Adresskonflikte: der Veta stand ab Werk auf derselben IP wie der Monitor.',
        ],
      },
    ],
  },

  {
    id: 'mindray-a-serie',
    hersteller: 'Mindray',
    modell: 'A-Serie Narkosegeraet (A7/A8/A9)',
    aliase: ['WATO A7', 'A8', 'A9', 'Mindray Anesthesia A-Series'],
    kategorie: 'narkose',
    einsatz: 'human',
    oui: ['98cce4'],
    vertrauen: 'wahrscheinlich',
    fallstricke: 'Die humane A-Serie hat — anders als der Veta — einen dokumentierten Datenausgang. ' +
      'Ob das konkrete Exemplar ihn freigeschaltet hat, sagt erst der Mitschnitt.',
    quellen: [
      'A-Series Com Protocol Interface Guide (SW V02.12.00–V02.13.00), Mindray',
    ],
    wege: [
      {
        id: 'hl7-push',
        name: 'HL7 v2.6 (IHE PCD) ueber Ethernet',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5000,
        rang: RANG_NORMAL,
        lizenz: 'unklar',
        liefert: 'Beatmungsparameter und Gaswerte als HL7-ORU.',
        vertrauen: 'wahrscheinlich',
        vorlage: null,
        schritte: [
          'Am Narkosegeraet im Service-/Netzwerkmenue die Zieladresse auf die PC-Adresse setzen.',
          'Den Port notieren, den das Geraet anbietet — die Station hoert auf mehreren; steht ein anderer da, ' +
            'kann er im Reiter "Geräte" nachgetragen werden.',
        ],
      },
    ],
  },

  {
    /*
     * DER WICHTIGSTE FUND DER RECHERCHE VOM 01.08.2026.
     *
     * Es gibt ein ECHTES Veterinaer-Narkosegeraet mit dokumentiertem, offenem Datenausgang — und
     * ausgerechnet dieses vertreibt Eickemeyer in Deutschland. Das Operator's Manual nennt auf der
     * Rueckseite unter "Communication Ports" woertlich drei Anschluesse, darunter:
     *   "B. Network port (Connect with the anesthesia information system through HL7 protocol)"
     * Damit ist der Satz "kein Vet-Narkosegeraet gibt Daten heraus", der in diesem Projekt lange
     * galt, widerlegt. Er stimmte fuer den Veta 5 — aber nicht fuer die WATO-Reihe.
     */
    id: 'mindray-wato-ex35-vet',
    hersteller: 'Mindray Animal Care',
    modell: 'WATO EX-35Vet',
    aliase: ['WATO EX-35 Vet', 'WATO EX35Vet', 'WATO EX-20Vet', 'WATO EX-20V', 'Eickemeyer WATO', 'WATO EX-35'],
    kategorie: 'narkose',
    einsatz: 'vet',
    oui: ['98cce4'],
    vertrauen: 'belegt',
    fallstricke: 'Anders als der Veta 5 hat dieses Geraet einen offenen Datenausgang — und zwar zwei: ' +
      'Netzwerk (HL7) und RS-232. Gute Nachricht fuer die Freischaltung: die Tabelle "Software Function ' +
      'Activation" im Handbuch listet alle per Code freischaltbaren Funktionen auf (P-mode, PCV, PSV, ' +
      'SIMV, Spirometrie-Schleifen, PCV-VG ...) — HL7 steht NICHT darunter, ist also keine kostenpflichtige ' +
      'Option. Die konkrete Portnummer steht nicht im Handbuch: sie wird am Geraet eingetragen. Deshalb ' +
      'einen Port waehlen, auf dem die Station ohnehin zuhoert (8830 oder 5000).',
    quellen: [
      'Mindray WATO EX-35Vet Operator\'s Manual, Rueckseite Punkt 3 "Communication Ports" und Kap. 4.4.2 "Software Function Activation"',
      'https://www.mindrayanimal.com/en/product/WATO_EX-35Vet',
    ],
    wege: [
      {
        id: 'hl7-netz',
        name: 'HL7 ueber Netzwerk (das Geraet sendet zum PC)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 8830,
        rang: RANG_NORMAL,
        lizenz: 'keine — HL7 steht NICHT in der Tabelle "Software Function Activation" des SERVICE Manuals ' +
          '(WATO EX-20/30/35 Service Manual, Kap. 4.4.2, S. 4-46: freischaltbar sind PCV, P-mode, PSV, ' +
          'SIMV, Spirometry loops, PCV-VG, SIMV-PRVC — HL7 nicht). Also keine Kaufoption. ' +
          '(Bis 1.2.3 stand hier faelschlich Kap. 4.4.2 des OPERATOR\'S Manual — dort geht es um die Wahl ' +
          'des Anaesthetikums.)',
        liefert: 'Beatmungs- und Frischgaswerte des Narkosegeraets als HL7. Was genau ankommt, zeigt der ' +
          'erste Mitschnitt — versprochen wird hier nichts, was nicht gemessen wurde.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Netzwerkkabel vom "Network port" an der Rueckseite in denselben Switch wie den PC stecken.',
          'Am Geraet: (Menue) -> Reiter [System] -> [Network]. Passwort fuer "Manage Configuration": 1234.',
          'DER SCHRITT, AN DEM DIE EINRICHTUNG SONST LAUTLOS SCHEITERT: "Network Protocol" -> Protocol ' +
            'steht AB WERK auf "MR-WATO", nicht auf HL7. MR-WATO ist Mindrays hauseigenes Format ' +
            '("for Mindray internal use only") — solange es eingestellt ist, kommt bei der Station nichts ' +
            'Lesbares an, egal wie richtig Ziel-IP und Port sind. Auf HL7 umstellen. ' +
            '(Auswahl: None, HL7, MR-WATO [Werkseinstellung], Philips.)',
          '"Destination IP" auf die PC-Adresse setzen. Ab Werk steht dort 192.168.23.200, die Geraete-IP ' +
            'ist ab Werk 192.168.23.250 — beides passt zu keinem Praxisnetz.',
          '"Port" steht ab Werk auf 1550. Entweder 1550 lassen (die Station lauscht dort seit 1.2.4) oder ' +
            'auf 8830 aendern — beides geht.',
          '"Interval" steht ab Werk auf 1 Minute. Fuer eine Narkoseueberwachung auf 10 Sekunden stellen.',
          'Im Reiter „Verbindung/Fehler" nachsehen, ob eine Verbindung ankommt und ob HL7 erkannt wird.',
        ],
      },
      {
        /* Werksport des Geraets. Er kostet nichts (ein Lauscher mehr) und erspart dem Anwender die
         * Umstellung am Geraet — und damit einen Schritt, an dem etwas schiefgehen kann. */
        id: 'hl7-netz-werksport',
        name: 'HL7 ueber Netzwerk auf dem WERKSPORT 1550 (nichts am Port umstellen)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 1550,
        rang: RANG_NORMAL,
        lizenz: 'keine (siehe oben).',
        liefert: 'Dasselbe wie der Weg darueber — nur ohne den Port am Geraet zu aendern.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Alles wie oben, aber "Port" auf der Werkseinstellung 1550 belassen.',
          'WICHTIG bleibt auch hier: "Network Protocol" -> Protocol von "MR-WATO" auf "HL7" umstellen.',
        ],
      },
      {
        id: 'rs232',
        name: 'RS-232 (serielle Schnittstelle an der Rueckseite)',
        adapter: 'probe',
        transport: 'seriell',
        richtung: 'geraet_sendet',
        port: null,
        seriell: '57600 Baud, 8 Datenbits, 1 Stoppbit, keine Paritaet — belegt im Handbuch, Abschnitt ' +
          '"Configure Serial" desselben Netzwerkmenues. (Bis 1.2.3 stand hier "nicht belegt, nicht raten"; ' +
          'die Angabe stand im selben Abschnitt, der nur nicht mit abgerufen worden war.) ' +
          'AUCH HIER GILT: "Network Protocol" -> Protocol muss von "MR-WATO" auf "HL7" stehen.',
        rang: RANG_SPAET,
        lizenz: 'keine',
        liefert: 'Vermutlich derselbe Datensatz wie ueber Netzwerk. Bei der verwandten A-Serie kommen ueber ' +
          'die serielle Schnittstelle ausdruecklich KEINE Kurven, nur Zahlenwerte und Alarme.',
        vertrauen: 'unbestaetigt',
        vorlage: null,
        schritte: [
          'Nur nehmen, wenn der Netzweg nicht geht — er ist der einfachere.',
          'Empfohlen: einen Geraeteserver (RS-232 auf LAN) dazwischenhaengen, dann laeuft es ueber den ' +
            'erprobten Netzweg der Station.',
          'Die seriellen Werte am Geraetemenue ablesen und hier eintragen.',
        ],
      },
    ],
  },

  {
    id: 'mindray-veta-3',
    hersteller: 'Mindray Animal Care',
    modell: 'Veta 3 / Veta 3X',
    aliase: ['Veta3', 'Veta 3X'],
    kategorie: 'narkose',
    einsatz: 'vet',
    oui: ['98cce4'],
    vertrauen: 'unbestaetigt',
    fallstricke: 'Die kleinere Schwester des Veta 5 (ohne Balg und Beatmungskreis — die Installationsanleitung ' +
      'markiert beides ausdruecklich mit "Veta 5 Only"). Ein Datenblatt mit Steckerliste war nicht zu ' +
      'beschaffen, das Handbuch ist verschluesselt. Solange nichts Gegenteiliges belegt ist, gilt hier ' +
      'dasselbe wie beim Veta 5: kein nutzbarer Datenausgang. Das ist eine begruendete Annahme, keine Messung.',
    quellen: ['Mindray Veta 3 Installationsanleitung (manualslib) — nennt keinen Datenanschluss'],
    wege: [
      {
        id: 'kein-ausgang',
        name: 'Kein belegter Datenausgang',
        adapter: 'keiner',
        transport: 'keiner',
        richtung: 'unbekannt',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'unklar',
        liefert: 'Nichts Belegtes.',
        keinAusgang: true,
        vertrauen: 'unbestaetigt',
        vorlage: null,
        schritte: [
          'Rueckseite des Geraets ansehen: gibt es dort ueberhaupt eine RJ45- oder DB9-Buchse?',
          'Wenn ja, im Menue nach einem Netzwerk- oder Kommunikationseintrag suchen und melden — der ' +
            'Katalog wird dann nachgefuehrt.',
          'Bis dahin: die Werte des Narkosegeraets im virtuellen Geraet von Hand fuehren.',
        ],
      },
    ],
  },

  {
    /*
     * MEHRERE MINDRAY-VET-MONITORE IN EINEM EINTRAG — mit Absicht.
     * Fuer ePM Vet, iPM Vet, iMEC Vet, PM-9000Vet und das Eickemeyer LifeVet 10M ist der Befund
     * identisch und wurde je Modell im Handbuch nachgeschlagen: die Vet-Firmware hat den
     * HL7-Reiter ueberhaupt nicht. Fuenf gleichlautende Eintraege wuerden die Auswahl aufblaehen,
     * ohne eine einzige zusaetzliche Auskunft zu geben; die Aliase machen jedes Modell auffindbar.
     */
    id: 'mindray-vet-monitore-ohne-hl7',
    hersteller: 'Mindray / Eickemeyer',
    modell: 'Vet-Monitore ohne HL7 (ePM Vet, iPM Vet, iMEC Vet, PM-9000Vet, LifeVet 10M)',
    aliase: ['ePM 10 Vet', 'ePM 12M Vet', 'iPM 12 Vet', 'iPM Vet', 'iMEC8 Vet', 'iMEC Vet', 'PM-9000Vet',
      'PM-900 Vet', 'LifeVet 10M', '321915', '321930', '321940'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: ['98cce4', '000f14'],
    vertrauen: 'belegt',
    fallstricke: 'Das ist der zentrale Unterschied zwischen Human- und Vet-Firmware bei Mindray: die ' +
      'Humanmodelle (ePM, BeneVision N) haben einen Reiter "HL7 Configuration" mit den Schaltern ' +
      '"Send Data" und "Send Waveforms" — in den Vet-Handbuechern kommt er ueberhaupt nicht vor. ' +
      'Vorhanden ist nur die herstellereigene CMS-Kopplung. Und die eGateway-Broschuere fuehrt in ihrer ' +
      'Kompatibilitaetsliste KEIN einziges Vet-Geraet auf — die verbreitete Auskunft "dann nimm halt ' +
      'ein eGateway" ist fuer diese Geraete also nicht belegt. Der BNC-Ausgang des PM-9000Vet ist analog ' +
      'und fuehrt auch das Schwesternruf-Signal; er ist als Datenquelle wertlos.',
    quellen: [
      'ePM 12M Vet Operator\'s Manual H-046-021061-00 Rev. 2.0 (2021-07), Kap. 22.11 Network Setup — kein HL7-Reiter',
      'iPM12 Vet Operator\'s Manual H-046-008141-00 Rev. 3.0; iMEC8 Vet H-046-008143-00 Rev. 3.0',
      'LifeVet 10M User Manual, Eickemeyer Art. 321915, Rev. 2.0 (2022-05), Kap. 19.5',
      'PM-9000Vet Operator\'s Manual Kap. 3.4.6; Mindray eGateway Broschuere (Kompatibilitaetsliste ohne Vet-Geraete)',
    ],
    wege: [
      {
        id: 'kein-hl7',
        name: 'Kein HL7 in dieser Firmware',
        adapter: 'keiner',
        transport: 'keiner',
        richtung: 'unbekannt',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'ja — der einzige belegte Weg ist Mindrays eigene Zentralstation (CMS), ein kostenpflichtiges Produkt.',
        liefert: 'Nichts, was ein Fremd-PC lesen koennte.',
        keinAusgang: true,
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Nicht in den Menues weitersuchen — der HL7-Reiter existiert in dieser Firmware nicht.',
          'Am Geraet unter Wartung → Monitorinformationen die Softwareversion ablesen und bei Eickemeyer/Mindray ' +
            'nach einer Firmware mit HL7-Ausgang fragen. Das ist die einzige Stelle, an der sich das aendern kann.',
          'Steht ein zweiter Monitor mit HL7 in der Praxis (z. B. LifeVet 10C), diesen als Wertequelle nehmen.',
        ],
      },
    ],
  },

  {
    id: 'mindray-vs900',
    hersteller: 'Mindray',
    modell: 'VS-900 / VS 8 / Accutorr 7 (Vitalwertmonitore)',
    aliase: ['VS-900', 'VS 8', 'VS 8A', 'Accutorr 7', 'Accutorr'],
    kategorie: 'monitor',
    einsatz: 'human',
    oui: ['98cce4'],
    vertrauen: 'belegt',
    fallstricke: 'DER FALLSTRICK STEHT IM WERKSZUSTAND: das Geraet kann seine Daten wahlweise per eGateway ' +
      'ODER per HL7 senden — und ab Werk steht es auf eGateway. Wer den HL7-Ausgang sucht, findet ihn ' +
      'nur, wenn er zuerst die "Data Send Method" umstellt; danach werden die Felder "Realtime Data Send ' +
      'Interval (for HL7 only)" ueberhaupt erst wirksam. Beim VS 8 / VS 8A kommt hinzu, dass das Handbuch ' +
      'ausdruecklich Lizenzen fuer das Senden von Echtzeitdaten, Kurven und Alarmen ueber HL7 nennt.',
    quellen: [
      'Mindray VS-900 Operator\'s Manual Rev. 15.0 (Mai 2019), Kap. 14.3 "Data Send Method", 14.3.5/14.3.6, Anhang C (Werksdefault eGateway)',
      'Mindray VS 8 / VS 8A Operator\'s Manual Kap. 16.15.10 und 3.9.6 (Lizenzen)',
    ],
    wege: [
      {
        id: 'hl7-push',
        name: 'HL7 (erst nach Umstellen der Sendemethode)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5000,
        rang: RANG_NORMAL,
        lizenz: 'unklar — beim VS 8/VS 8A nennt das Handbuch Lizenzen fuer Echtzeitdaten, Kurven und Alarme ueber HL7; beim VS-900 nicht.',
        liefert: 'Vitalwerte im eingestellten Takt.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Am Geraet: Wartung → Netzwerk → "Data Send Method" von eGateway auf HL7 umstellen. OHNE DIESEN ' +
            'SCHRITT bleibt jede weitere Einstellung wirkungslos.',
          'Zieladresse = PC-Adresse, Port 5000 (dort hoert die Station zu).',
          '"Realtime Data Send Interval" auf den kleinsten Wert stellen.',
        ],
      },
    ],
  },

  {
    id: 'mindray-egateway',
    hersteller: 'Mindray',
    modell: 'eGateway / BeneLink (Zusatzkaesten, keine Geraete)',
    aliase: ['eGateway', 'BeneLink', 'Integration Manager', 'PDS Gateway'],
    kategorie: 'kombi',
    einsatz: 'human',
    oui: ['98cce4'],
    vertrauen: 'belegt',
    fallstricke: 'Zwei Kaesten, die oft verwechselt werden, und beide zeigen in unterschiedliche Richtungen. ' +
      'eGateway sammelt bis zu 200 Mindray-MONITORE ein und gibt HL7 v2.6 nach aussen — der Weg RAUS, ' +
      'kostenpflichtig, und seine Kompatibilitaetsliste enthaelt KEIN Vet-Geraet. BeneLink ist das Gegenteil: ' +
      'ein Steckmodul mit vier RJ45-Buchsen, das FREMDE Narkose- und Beatmungsgeraete (Draeger Fabius/Primus/' +
      'Perseus/Apollo, GE Aespire/Aestiva/Aisys/Avance u. a.) IN einen Mindray-Monitor hineinholt — je Geraetetyp ' +
      'mit einem eigenen, passenden ID-Adapter. Fuer VetStation ist BeneLink also nur dann interessant, wenn der ' +
      'Monitor die Fremdwerte anschliessend selbst per HL7 weitergibt.',
    quellen: [
      'Mindray eGateway Broschuere P/N ENG-eGateway-210285X8PX20190131 (Data output protocol: "IHE standard HL7 v2.6")',
      'Mindray BeneLink Module Operator\'s Manual H-046-011948-00 Rev 5.0 (12/2021), Kompatibilitaets- und Adapterliste',
    ],
    wege: [
      {
        id: 'egateway-hl7',
        name: 'eGateway gibt HL7 an den PC (kostenpflichtiger Kasten)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5000,
        rang: RANG_SPAET,
        lizenz: 'ja — eigenstaendiges, kostenpflichtiges Mindray-Produkt.',
        liefert: 'HL7 v2.6 mit Stammdaten, Parametern, Alarmen und Kurvenverteilung aus allen angeschlossenen Monitoren.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Nur sinnvoll, wenn ohnehin ein eGateway in der Praxis steht — anschaffen lohnt sich fuer einen ' +
            'einzelnen OP-Saal nicht.',
          'Im eGateway die PC-Adresse als HL7-Ziel und einen Port eintragen, auf dem die Station hoert.',
          'Achtung: die Kompatibilitaetsliste des eGateway nennt keine Vet-Geraete — vor dem Kauf klaeren.',
        ],
      },
    ],
  },

  /* ================================================================
   * VETERINAER-MONITORE ANDERER HERSTELLER
   * Das sind die Geraete, die in deutschen Tierarztpraxen tatsaechlich
   * am haeufigsten stehen — Mindray/Eickemeyer ist nur ein Teil davon.
   * ================================================================ */

  {
    id: 'bionet-bm-vet-pro',
    hersteller: 'Bionet',
    modell: 'BM3Vet / BM5Vet / BM7Vet — Pro und Elite',
    aliase: ['BM3Vet Pro', 'BM5Vet Pro', 'BM7Vet Pro', 'BM3Vet Elite', 'BM5Vet Elite', 'BM7Vet Elite', 'BM Vet'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Die Pro- und die Elite-Reihe haben ein eigenes HL7-Menue (A-7) mit frei waehlbarer Ziel-IP ' +
      'UND frei waehlbarem Port — das macht sie zu den unkompliziertesten Fremdgeraeten im ganzen Katalog: ' +
      'einfach einen Port eintragen, auf dem die Station ohnehin hoert. ZWEI Einschraenkungen, beide wichtig: ' +
      '(1) Das kuerzeste Sendeintervall ist 10 Sekunden. Fuer eine Narkoseueberwachung ist das grob — ' +
      'zwischen zwei Werten liegt eine halbe Minute Ungewissheit. (2) Die AELTERE BM5Vet-Generation ' +
      '(Handbuch Rev. 2.x) hat KEIN HL7, sondern nur "CENTRAL / HOST IP" zur Bionet-Zentrale. Vor dem ' +
      'Einrichten also pruefen, ob im Menue ueberhaupt ein Punkt A-7 HL7 existiert. Der RS-232-Stecker der ' +
      'alten Generation ist NICHT als Datenausgang belegt.',
    quellen: [
      'Bionet BM7Vet Pro User\'s Manual Rev. 3.x (2020), Menuebaum A-5 bis A-7 und Kap. 3 "Network"',
      'Bionet BM Vet Elite Series Instructions for Use, Menue A-7 HL7',
      'Bionet BM5VET User\'s Manual Rev. 2.53 (2018) — dort KEIN HL7-Menuepunkt',
    ],
    wege: [
      {
        id: 'hl7',
        name: 'HL7 (Menue A-7, Ziel und Port frei waehlbar)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 8830,
        rang: RANG_NORMAL,
        lizenz: 'keine — HL7 steht im normalen Benutzerhandbuch und taucht in der Optionsliste nicht auf. ' +
          '(WLAN dagegen ist bei der Elite-Reihe eine kostenpflichtige Option.)',
        liefert: 'Zyklische Zahlenwerte, fruehestens alle 10 Sekunden. Keine Kurven, keine Schlag-fuer-Schlag-Daten.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Am Touchscreen das Zahnrad antippen → "A. SETUP" → "A-7. HL7".',
          'A-7-1 "HL7 Comm" auf ON.',
          'A-7-2 "HL7 IP" = die PC-Adresse.',
          'A-7-3 "Port" = 8830 (dort hoert die Station bereits zu; jeder andere Port geht auch, muss dann ' +
            'aber hier im Reiter „Geräte" ergaenzt werden).',
          'A-7-4 "HL7 Period" auf den kleinsten Wert: 10sec.',
          'Netzwerkadresse des Monitors selbst steht unter "A-5. Network information" (DHCP oder feste IP).',
          'Bei der Elite-Reihe kann ein "Setup password" gesetzt sein — ohne das kommt man nicht ins Menue.',
        ],
      },
    ],
  },

  {
    id: 'edan-im-serie',
    hersteller: 'EDAN Instruments',
    modell: 'iM50 / iM60 / iM70 / iM80 / M50 / M80 (inkl. Vet-Varianten)',
    aliase: ['iM50 Vet', 'iM60 Vet', 'iM80 Vet', 'iM50Vet', 'iM60Vet', 'iM80Vet', 'M50', 'M80', 'EDAN Vet'],
    kategorie: 'monitor',
    einsatz: 'beides',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'ACHTUNG, DER GROESSTE STOLPERSTEIN DIESES GERAETS: die HL7-Verschluesselung steht AB WERK ' +
      'auf TLS. Ein normaler Empfaenger sieht dann nur verschluesselte Bytes und meldet "unbekanntes ' +
      'Protokoll" — obwohl alles richtig eingestellt ist. Entweder am Geraet auf "Off" stellen (im ' +
      'isolierten Geraetenetz vertretbar) oder es geht gar nicht. Ausserdem: die HL7-Ausgabe ist NICHT auf ' +
      'allen Firmwarestaenden vorhanden (in einer aelteren Handbuchfassung fehlt sie ganz), der Monitor hat ' +
      'eine eigene Firewall mit Paketgrenze, und der Zielport ist im Benutzerhandbuch NICHT als einstellbar ' +
      'beschrieben — moeglicherweise ist er fest. Deshalb im Zweifel den Verbindungs-Assistenten auf allen ' +
      'Ports lauschen lassen und nachsehen, wo etwas ankommt.',
    quellen: [
      'EDAN iM50/iM60/iM70/iM80/M50/M80 Patient Monitor User Manual, P/N 01.54.457239, Release Juli 2020, Kap. 4.7 "HL7 Communication"',
      'ebenda Kap. 4.4/4.5 (MFM-CMS), Kap. 4.6 (GW1 Gateway), Anhang A.15.6 (RS232 nur iM80/M80)',
    ],
    wege: [
      {
        id: 'hl7',
        name: 'HL7 (Verschluesselung beachten!)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5000,
        rang: RANG_NORMAL,
        lizenz: 'unklar — im Benutzerhandbuch wird keine Freischaltung erwaehnt; HL7 erscheint als reiner Schalter.',
        liefert: 'Im Benutzerhandbuch nicht spezifiziert. Das eigentliche Protokolldokument gibt EDAN nur ' +
          'auf Anfrage heraus — was ankommt, zeigt der Mitschnitt.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Am Monitor: Menu → Maintenance → User Maintain → Passwort (Werk: ABC).',
          'Unter "Security": "HL7" auf On.',
          'IM SELBEN MENUE: "HL7 Encryption method" auf Off stellen — steht ab Werk auf TLS, und damit ' +
            'kann die Station nichts lesen.',
          'Unter "Network Maintain": die HL7-Ziel-IP auf die PC-Adresse setzen; Netzwerktyp LAN oder Wi-Fi waehlen.',
          'Danach im Reiter „Verbindung/Fehler" nachsehen, auf welchem Port etwas ankommt.',
        ],
      },
    ],
  },

  {
    id: 'surgivet-advisor',
    hersteller: 'Smiths Medical / SurgiVet',
    modell: 'Advisor Vital Signs Monitor V9200 / V9204',
    aliase: ['SurgiVet Advisor', 'V9200', 'V9203', 'V9204', 'Veterinary Advisor', 'Advisor'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'DER AM BESTEN DOKUMENTIERTE DATENAUSGANG ALLER VET-MONITORE — das Handbuch listet die ' +
      '25 Spalten der CSV-Zeile einzeln auf, ein Parser laesst sich sauber dagegen bauen. ' +
      'ABER EINE HARTE KABELWARNUNG: Pin 6 des DB9 fuehrt +5 Volt. Auf einem PC-COM-Anschluss liegt auf ' +
      'Pin 6 die Leitung DSR. Nur ein DREIADRIGES Kabel (Pins 2, 3, 5) verwenden — kein vollbelegtes ' +
      'Standardkabel und keinen Nullmodem-Adapter aus der Schublade. Die serielle Schnittstelle ist ' +
      'laut Handbuch eine Option; nicht jedes Geraet hat sie bestueckt.',
    quellen: [
      'Advisor Vital Signs Monitor Operation Manual — Veterinary Advisor, Kap. 14 "Serial and Analog Input/Output", S. 14-1 bis 14-7',
    ],
    wege: [
      {
        id: 'rs232-csv',
        name: 'RS-232: Klartext-CSV im Sekundentakt (REAL-TIME NUMERIC)',
        adapter: 'surgivet',
        transport: 'seriell',
        richtung: 'geraet_sendet',
        port: null,
        seriell: '115200 Baud, 8 Datenbits, keine Paritaet, 1 Stopbit, keine Flusskontrolle. ' +
          'NUR 3 Adern verwenden (Pin 2, 3, 5) — Pin 6 fuehrt +5 V!',
        rang: RANG_NORMAL,
        lizenz: 'unklar — die serielle Schnittstelle ist laut Handbuch eine Option; am Geraet pruefen, ob der DB9 vorhanden ist.',
        liefert: 'Eine kommaseparierte Klartextzeile mit 25 Spalten: HF (EKG), SpO2, Pulsfrequenz, ' +
          'IBP 1+2 (sys/dia/mittel), NIBP (sys/dia/mittel), Temperatur 1+2, EtCO2, inspiratorisches CO2, ' +
          'Atemfrequenz und Statusflags.',
        vertrauen: 'belegt',
        /* Vorbelegt auf den Geraeteserver-Weg, weil der der zuverlaessigere ist. Wer direkt an
         * einen COM-Anschluss geht, stellt beim Einrichten art auf 'com' und traegt den Anschluss
         * ein — welcher es ist, zeigt `node tools/seriell-pruefen.js`. */
        vorlage: { type: 'surgivet', art: 'tcp', host: '', tcpPort: 4001, baud: 115200, role: 'kombi' },
        felder: [
          { name: 'art', text: 'Anschlussart', werte: ['tcp', 'com'], vorgabe: 'tcp',
            hilfe: 'tcp = ueber einen Geraeteserver (empfohlen) · com = direkt am COM-Anschluss des PCs' },
          { name: 'host', text: 'Adresse des Geraeteservers', vorgabe: '', hilfe: 'nur bei "tcp" — z. B. 192.168.0.60' },
          { name: 'tcpPort', text: 'Port des Geraeteservers', vorgabe: 4001, hilfe: 'nur bei "tcp" — bei Moxa NPort ab Werk 4001' },
          { name: 'port', text: 'COM-Anschluss', vorgabe: 'COM1', hilfe: 'nur bei "com" — welcher es ist, zeigt: node tools/seriell-pruefen.js' },
          { name: 'baud', text: 'Baudrate', vorgabe: 115200, hilfe: 'Handbuchwert 115200 — nur aendern, wenn am Geraet etwas anderes eingestellt ist' },
        ],
        schritte: [
          'Mit dem Drehknopf: "SETUP" waehlen → "SERVICE MENU".',
          'Passwort Zeichen fuer Zeichen mit dem Drehknopf eingeben: ADVISOR → "ENTER".',
          '"MONITOR DEFAULTS" → "SERIAL OUTPUT MODE" → "REAL-TIME NUMERIC (CSV)".',
          'Kabel: NUR Pin 2, 3 und 5 durchverbinden. Pin 6 fuehrt +5 Volt und darf den PC nicht erreichen.',
          'Empfohlen statt Direktkabel: ein Geraeteserver (RS-232 auf LAN) — dann laeuft es ueber den ' +
            'erprobten Netzweg und der Monitor darf stehen bleiben, wo er steht.',
          'Pruefen mit: node tools/seriell-pruefen.js --com COM1 --baud 115200',
        ],
      },
    ],
  },

  {
    id: 'midmark-multiparameter',
    hersteller: 'Midmark',
    modell: 'Multiparameter Monitor (8019-0xx / 8020-00x)',
    aliase: ['Midmark 8019', 'Midmark 8020', 'Midmark Multiparameter Monitor', 'Midmark Vital Signs'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Der Monitor sendet an eine "Remote IP" auf dem Port 2528 (Werkseinstellung). Was er dort ' +
      'genau schickt, ist NICHT veroeffentlicht — der vorgesehene Empfaenger ist Midmarks kostenpflichtige ' +
      'Software "Anesthetic Record Interface" (Jahresabonnement, eine Lizenz je Praxis). VetStation kann ' +
      'auf 2528 zuhoeren und den Strom mitschneiden; ob er lesbar ist, zeigt erst der Mitschnitt. ' +
      'Auf keinen Fall Bytes raten. Zwei weitere Fallen: das Geraet kann KEIN DHCP (feste Adressen noetig), ' +
      'und ohne eingetragene Patientennummer am Monitor fliesst ueberhaupt nichts.',
    quellen: [
      'Midmark Multiparameter Monitor Veterinary Vital Signs Monitor User Guide, Dok. 003-10464-00 Rev. AA5 (03.07.2025), Netzwerk-Setup und Kap. 6.5',
    ],
    wege: [
      {
        id: 'push-2528',
        name: 'Push auf Remote-Port 2528 (Protokoll unbekannt — Mitschnitt)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 2528,
        rang: RANG_NORMAL,
        lizenz: 'ja fuer den Originalempfaenger (Midmark Anesthetic Record Interface, Jahresabonnement). ' +
          'Das Mitschneiden selbst kostet nichts.',
        liefert: 'Unbekannt. Die Station schreibt mit und erkennt HL7 selbst; ist es etwas anderes, steht ' +
          'es im Mitschnitt und kann ausgewertet werden.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Am Monitor: "Settings" → "Maintenance" → "User Maintenance" → Passwort 2013 → "Enter" → "OK".',
          '"Network Setup" → "Net Type" = LAN oder Wi-Fi.',
          '"Local IP" = eine feste Adresse im Netz des PCs (DHCP kann das Geraet NICHT).',
          '"Remote IP" = die PC-Adresse, "Remote Port" = 2528 stehen lassen.',
          'Am Monitor eine Patientennummer eintragen — ohne sie sendet das Geraet nichts.',
          'Danach im Reiter „Verbindung/Fehler" nachsehen, ob auf 2528 eine Verbindung ankommt.',
        ],
      },
      {
        id: 'usb-trend',
        name: 'Trenddaten auf USB-Stick (nachtraeglich, kein Livestrom)',
        adapter: 'keiner',
        transport: 'usb',
        richtung: 'geraet_sendet',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'keine',
        liefert: 'Eine Excel-Datei mit bis zu 20 Stunden Trenddaten. Nichts fuer die laufende Narkose.',
        keinAusgang: true,
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'USB-2.0-Stick (2-16 GB; USB 3.0 wird laut Handbuch nicht erkannt) anstecken.',
          'Im Menue "Export Trend and ECG Data" waehlen.',
        ],
      },
    ],
  },

  {
    id: 'midmark-cardell',
    hersteller: 'Midmark',
    modell: 'Cardell Touch / Cardell Insight / Cardell 9401-9402',
    aliase: ['Cardell Touch', 'Cardell Insight', 'Cardell 9401', 'Cardell 9402', '8013-001', '8013-003', 'CARDELL'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Drei Geraete, drei verschiedene Enttaeuschungen. Der Cardell INSIGHT hat zwar eine ' +
      'RJ45-Buchse, das Handbuch bezeichnet sie aber ausdruecklich als "Ethernet connection (future use)" — ' +
      'sie ist nicht in Betrieb. Beim Cardell TOUCH gibt es ein Menue "Network Settings"; welches Protokoll ' +
      'darueber laeuft, ist NICHT veroeffentlicht, und alle gespeicherten Daten werden geloescht, sobald der ' +
      'Monitor ausgeht — exportieren muss man VOR dem Abschalten. Der EKG-Export liefert nur Ableitung II ' +
      'und nur 12 Minuten. Beim 9401/9402 ist RS-232 eine kostenpflichtige Nachruestplatine, und das dort ' +
      'gesprochene "CAS Serial Protocol" ist nicht oeffentlich dokumentiert.',
    quellen: [
      'Midmark User Guide Cardell Insight, Dok. 003-2981-00 ("Ethernet Connection (Future)")',
      'Midmark Cardell Touch User\'s Guide 003-2647-00 Rev. J, Kap. 5.8',
      'CARDELL 9401 & 9402 Veterinary Monitor Service Manual, Midmark Dok. 21-02-0286 Rev. 02',
    ],
    wege: [
      {
        id: 'touch-netz',
        name: 'Cardell Touch: Netzwerk (Protokoll unveroeffentlicht — Mitschnitt)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5000,
        rang: RANG_SPAET,
        lizenz: 'unklar',
        liefert: 'Unbekannt. Nur ein Mitschnitt kann zeigen, ob dort etwas Lesbares kommt.',
        vertrauen: 'unbestaetigt',
        vorlage: null,
        schritte: [
          'Auf das Monitor-Symbol in der Statusleiste tippen → "Network Settings".',
          '"IP ADDRESS" = Adresse des Monitors, "GATEWAY" = Router (oder 0.0.0.0 im eigenen Switch).',
          'Gibt es ein Feld fuer eine Zieladresse, die PC-Adresse eintragen.',
          'Danach im Reiter „Verbindung/Fehler" nachsehen, ob und wo etwas ankommt.',
        ],
      },
      {
        id: 'insight-kein-netz',
        name: 'Cardell Insight: die Netzwerkbuchse ist NICHT in Betrieb',
        adapter: 'keiner',
        transport: 'keiner',
        richtung: 'unbekannt',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'keine',
        liefert: 'Nichts. Nur ein nachtraeglicher CSV-Export auf USB-Stick.',
        keinAusgang: true,
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Nicht weitersuchen: die RJ45-Buchse ist laut Herstellerhandbuch fuer eine kuenftige Funktion ' +
            'vorgesehen und heute ohne Funktion.',
          'Trenddaten koennen nur als CSV auf einen USB-Stick geschrieben werden (System Menu).',
        ],
      },
    ],
  },

  {
    id: 'contec-cms-vet',
    hersteller: 'Contec Medical',
    modell: 'CMS6000Vet / CMS8000Vet',
    aliase: ['CMS6000VET', 'CMS8000VET', 'CMS8000', 'CMS6000', 'CMS7000'],
    kategorie: 'monitor',
    einsatz: 'beides',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'SICHERHEITSHINWEIS, DER VOR DER TECHNIK KOMMT: Die US-Behoerde CISA hat im Januar 2025 im ' +
      'baugleichen Humanmodell CMS8000 eine Hintertuer gefunden — das Geraet baut nach dem Start von selbst ' +
      'eine Verbindung zu einer fest einprogrammierten fremden Adresse auf, streamt dorthin Patienten- und ' +
      'Sensordaten und kann darueber Code nachladen; die Netzwerkschnittstelle schaltet sich dabei selbst ' +
      'ein, auch wenn Netzwerk eigentlich aus ist (CVE-2025-0626, CVE-2025-0683). CISA hat ausdruecklich nur ' +
      'das Humangeraet untersucht; ob die Vet-Variante dieselbe Firmware hat, ist NICHT belegt — aber es ist ' +
      'auch nicht widerlegt. Empfehlung: ein solches Geraet gehoert in ein isoliertes Geraetenetz OHNE Weg ' +
      'ins Internet. Technisch gibt es ohnehin nur die herstellereigene Zentrale, kein HL7.',
    quellen: [
      'CISA Fact Sheet "Contec CMS8000 Contains a Backdoor", TLP:CLEAR, 30.01.2025',
      'CMS8000 Patient Monitor Service Manual (Contec, 2007), Abschnitt Netzwerkschnittstelle',
    ],
    wege: [
      {
        id: 'kein-offener-weg',
        name: 'Nur herstellereigene Zentrale — kein offener Datenweg',
        adapter: 'keiner',
        transport: 'keiner',
        richtung: 'unbekannt',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'ja — Contecs eigene Zentralsoftware.',
        liefert: 'Nichts, was ein Fremd-PC lesen koennte.',
        keinAusgang: true,
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Das Geraet in ein isoliertes Netz ohne Internetzugang haengen (siehe Sicherheitshinweis oben).',
          'Fuer die Narkoseueberwachung ein Geraet mit offener Schnittstelle als Wertequelle verwenden.',
        ],
      },
    ],
  },

  {
    id: 'comen-c50v',
    hersteller: 'Comen',
    modell: 'C50-V / C80-V / C86-V',
    aliase: ['Comen C50', 'C50 Vet', 'C80-V', 'C86-V', 'STAR8000'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Comen wirbt prominent mit "HL7-Compliant Connectivity" — das gilt aber fuer die ' +
      'ZENTRALSTATION STAR8800, nicht fuer den Monitor am OP-Tisch. Im Vet-Handbuch des C50-V kommt das ' +
      'Wort HL7 kein einziges Mal vor. Der einzige Datenweg ohne Zentrale ist ein nachtraeglicher ' +
      'Dateiexport (.bin/.txt/.xls) per USB oder FTP — und der verlangt anschliessend einen Geraeteneustart, ' +
      'was waehrend einer Narkose nicht in Frage kommt. Bei der STAR8000-Reihe kommt hinzu, dass ihr ' +
      'Netzwerk auf dem festen Schema 200.200.200.x laeuft und laut Handbuch ausschliesslich fuer die ' +
      'Herstellerzentrale freigegeben ist.',
    quellen: [
      'Instruction Manual C50-V / C80-V / C86-V Multi-parameter Veterinary Monitor (Shenzhen Comen), Kap. 4/5 und Kap. 7 Data Export',
      'Multi-parameter Patient Monitor STAR8000H User Manual (Comen)',
    ],
    wege: [
      {
        id: 'kein-hl7',
        name: 'Kein HL7 am Monitor — nur Zentrale oder Dateiexport',
        adapter: 'keiner',
        transport: 'keiner',
        richtung: 'unbekannt',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'ja — HL7 gibt es erst auf der kostenpflichtigen Zentralstation STAR8800.',
        liefert: 'Kein Livestrom fuer einen Fremd-PC.',
        keinAusgang: true,
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Nicht im Monitormenue nach HL7 suchen — es gibt dort keines.',
          'Steht eine STAR8800-Zentrale in der Praxis, dort nach dem HL7-Ausgang fragen.',
          'Der Dateiexport (Patientendateiverwaltung → Export) ist nur fuer die Nachbereitung brauchbar ' +
            'und erzwingt einen Neustart des Geraets.',
        ],
      },
    ],
  },

  {
    id: 'digicare-lifewindow',
    hersteller: 'Digicare Animal Health',
    modell: 'LifeWindow LW9xVet / LifeWindow Lite LW8',
    aliase: ['LifeWindow', 'LW9xVet', 'LW9x', 'LW8', 'LW6000', 'LW-One'],
    kategorie: 'monitor',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'wahrscheinlich',
    fallstricke: 'Das Geraet kann nachweislich live an einen PC senden (die kommerzielle Narkosebogen-Software ' +
      'IDEXX Smart Flow nutzt genau das) — aber weder Port noch Protokoll sind veroeffentlicht. Die ' +
      'Netzwerkeinstellungen sind zudem versteckt und werden ueber Pseudo-Patienten freigeschaltet ' +
      '(Patient "LW SMARTFLOW" mit ID 5139 aufnehmen, nach Neustart "LW CLOSE" mit ID 5967). Das steht in ' +
      'keiner Herstellerunterlage, sondern nur in der IDEXX-Anleitung. Fuer VetStation heisst das: zuhoeren ' +
      'und mitschneiden, nichts raten.',
    quellen: [
      'IDEXX SmartFlow Support-Artikel "How to set up Digicare (LifeWindow Lite LW8, LW9xVet) monitors?"',
      'https://www.digi-vet.com/LW-9x.html',
    ],
    wege: [
      {
        id: 'push-unbekannt',
        name: 'Push an einen PC (Protokoll unveroeffentlicht — Mitschnitt)',
        adapter: 'probe',
        transport: 'lan',
        richtung: 'geraet_sendet',
        port: 5000,
        rang: RANG_SPAET,
        lizenz: 'unklar',
        liefert: 'Unbekannt. Der Verbindungs-Assistent nimmt an, erkennt HL7 selbst und schreibt sonst mit.',
        vertrauen: 'unbestaetigt',
        vorlage: null,
        schritte: [
          'In den Netzwerkeinstellungen des Geraets die PC-Adresse als Ziel eintragen.',
          'Der Weg dorthin ist versteckt: System → Patient Management, Patient "LW SMARTFLOW" mit ID 5139 ' +
            'aufnehmen; nach einem Neustart Patient "LW CLOSE" mit ID 5967 aufnehmen.',
          'Danach im Reiter „Verbindung/Fehler" nachsehen, auf welchem Port etwas ankommt — und den Port ' +
            'hier ergaenzen, falls es ein anderer ist.',
        ],
      },
    ],
  },

  {
    id: 'mechanische-vet-narkose',
    hersteller: '(verschiedene)',
    modell: 'Rein mechanische Vet-Narkosegeraete (Matrx, Moduflex, Hallowell, Vetland, RWD, DRE, Supera)',
    aliase: ['Matrx VMS', 'Matrx VMS Plus', 'Midmark VMR', 'Moduflex Optimax', 'Moduflex Elite', 'Dispomed',
      'Hallowell 2000', 'Hallowell 2002', '2002PRO', 'Anesthesia WorkStation AWS', 'Vetland LAS-4000',
      'RWD R500', 'RWD R550', 'Supera M1000', 'DRE Integra SP II', 'NarkoVet', 'VetFlo', 'Vetamac'],
    kategorie: 'narkose',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'DAS IST DER NORMALFALL IN DER TIERMEDIZIN, und es ist keine schlechte Nachricht — es ist ' +
      'nur eine, die man kennen muss: die grosse Mehrheit der Veterinaer-Narkosegeraete ist rein ' +
      'mechanisch-pneumatisch. Schwebekoerperflowmeter, mechanisches Manometer, APL-Ventil, CO2-Absorber. ' +
      'Kein Netzanschluss, kein Display, keine Elektronik — folglich auch nichts auszulesen. ' +
      'Haeufigster Irrtum: "Digitalanzeige" heisst hier Ziffernanzeige, nicht digitale Schnittstelle ' +
      '(so bei der Hallowell-2002-Familie und den Midmark-2024-PRO-Ventilatoren). Fuer diese Geraete ist ' +
      'die richtige Loesung nicht eine Verbindung, sondern das virtuelle Narkosegeraet in der App: dort ' +
      'werden Modus, Frequenz und Drucke von Hand gefuehrt, und der Beatmungs-Berater rechnet mit den ' +
      'ECHTEN Monitorwerten weiter.',
    quellen: [
      'Midmark Matrx VMS Quick Reference Guide VA113301; Hallowell EMC 2002PRO Betriebshandbuch',
      'Dispomed Moduflex Handbuch; Vetland LAS-4000 Produktangaben; RWD R500 Series User Manual',
    ],
    wege: [
      {
        id: 'kein-ausgang',
        name: 'Kein Datenausgang — von Hand fuehren',
        adapter: 'keiner',
        transport: 'keiner',
        richtung: 'unbekannt',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'keine',
        liefert: 'Nichts. Diese Geraete haben keine Elektronik, die etwas senden koennte.',
        keinAusgang: true,
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Nicht nach einer Buchse suchen — es gibt keine.',
          'Im virtuellen Narkosegeraet der App Beatmungsmodus, Frequenz und Drucke von Hand eintragen.',
          'Der Beatmungs-Berater arbeitet mit den echten Monitorwerten (SpO2, EtCO2, Kapnokurve) weiter — ' +
            'die eigentliche Sicherheit kommt ohnehin vom Monitor, nicht vom Narkosegeraet.',
        ],
      },
    ],
  },

  {
    id: 'tafonius',
    hersteller: 'Vetronic / Hallowell EMC',
    modell: 'Tafonius / Tafonius Junior (Grosstier)',
    aliase: ['Tafonius', 'Tafonius Junior', 'T19', 'J2'],
    kategorie: 'kombi',
    einsatz: 'vet',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Der Tafonius ist innen ein Windows-PC mit Touchscreen und zeichnet die ganze Narkose auf — ' +
      'aber der einzige dokumentierte Weg, die Daten herauszubekommen, ist ein MANUELLER Export auf einen ' +
      'USB-Stick. Es ist keine Netzwerk-, keine serielle und keine Live-Schnittstelle dokumentiert.',
    quellen: ['"USING THE Tafonius SOFTWARE", DOC A4941B, S. 24 und 58 (Exporting Data)'],
    wege: [
      {
        id: 'usb-csv',
        name: 'CSV-Export auf USB-Stick (nachtraeglich)',
        adapter: 'keiner',
        transport: 'usb',
        richtung: 'geraet_sendet',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'keine',
        liefert: 'Slow Data als CSV und das Narkoseprotokoll als PDF — nachtraeglich, nicht live.',
        keinAusgang: true,
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'In der Tafonius Shell auf "Export Data" tippen.',
          'Die gewuenschte Aufzeichnung aus der nach Datum sortierten Liste waehlen und auf einen ' +
            'USB-Stick schreiben.',
          'Fuer die LAUFENDE Narkose ist das kein Weg — dafuer den angeschlossenen Monitor als Quelle nehmen.',
        ],
      },
    ],
  },

  /* ================================================================
   * HUMANGERAETE, DIE IN TIERKLINIKEN STEHEN
   * Meist gebraucht gekauft. Sie sind hier, weil sie die einzigen
   * Geraete mit wirklich offener, dokumentierter Schnittstelle sind.
   * ================================================================ */

  {
    id: 'draeger-medibus-narkose',
    hersteller: 'Dräger',
    modell: 'Fabius / Primus / Perseus / Zeus / Atlan (MEDIBUS)',
    aliase: ['Fabius Tiro', 'Fabius GS', 'Fabius plus', 'Primus', 'Primus IE', 'Perseus A500', 'Zeus IE',
      'Atlan A300', 'Atlan A350', 'Apollo', 'MEDIBUS', 'MEDIBUS.X'],
    kategorie: 'narkose',
    einsatz: 'beides',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'DIE GROESSTE FALLE DER FABIUS-FAMILIE: ab Werk steht das Protokoll auf VITALINK, NICHT auf ' +
      'MEDIBUS — und die Werksparitaet ist NONE statt EVEN. Dräger warnt im Servicehandbuch ausdruecklich, ' +
      'dass beide Protokolle einander aehneln und bei ungleicher Einstellung "inaccurate data" entstehen. ' +
      'Fuer eine Narkosestation heisst das: falsch eingestellt kommen PLAUSIBLE, aber FALSCHE Zahlen — der ' +
      'gefaehrlichste aller Faelle. Deshalb wird hier lieber gar nichts gelesen als etwas Ungeprueftes. ' +
      'Weiter: der Perseus A500 kann NUR MEDIBUS.X (klassisches MEDIBUS erzeugt einen COM-Fehler), beim ' +
      'Primus musste in einem dokumentierten Fall ein Dräger-Techniker den COM-Anschluss erst freischalten, ' +
      'und MEDIBUS laeuft NICHT ueber Netzwerk — dafuer verkauft Dräger einen eigenen Kasten (CC300). ' +
      'Ebenfalls wichtig: die alten Dräger-Narkosegeraete, die in Tierkliniken tatsaechlich am haeufigsten ' +
      'stehen (Sulla, Pallas, Trajan, Livius), haben KEIN MEDIBUS — sie stammen aus der Zeit davor.',
    quellen: [
      '"Protocol Definition Dräger RS 232 MEDIBUS Revision Level 6.00", Best.-Nr. 90 28 258, 10. Ausgabe Dez. 2007',
      '"MEDIBUS.X Profile Definition", Best.-Nr. 9052608, Edition 20, 2022-04',
      'Technical Service Manual Fabius Tiro, Dräger 6020.002 Rev. B, Abschnitt Serial Port',
      'Gebrauchsanweisung Perseus A500, Kap. "Anwenden des MEDIBUS-Protokolls"',
    ],
    wege: [
      {
        id: 'medibus-seriell',
        name: 'MEDIBUS ueber RS-232',
        adapter: 'medibus',
        transport: 'seriell',
        richtung: 'beides',
        port: null,
        seriell: 'Geraeteabhaengig. Fabius-Familie: waehlbar 1200-38400, in der Praxis 19200, 8 Datenbits, ' +
          'Paritaet EVEN, 1 Stopbit (Werkseinstellung ist aber NONE!). Stecker 9-polig Sub-D, ' +
          'Pin 2 = RXD, Pin 3 = TXD, Pin 5 = GND — das ist DTE-Belegung wie am PC, es wird also sehr ' +
          'wahrscheinlich ein Nullmodem-/Crossover-Kabel gebraucht.',
        rang: RANG_SPAET,
        lizenz: 'geraeteabhaengig: bei der Evita ist die Hardware-Option "EvitaLink" zwingend, beim Primus ' +
          'gibt es einen dokumentierten Fall, in dem ein Techniker den COM-Anschluss freischalten musste.',
        liefert: 'Beatmungs- und Gasmesswerte, Einstellungen, Alarmgrenzen, Alarme, Textmeldungen; ' +
          'optional Kurven ueber die Realtime-Erweiterung.',
        vertrauen: 'belegt',
        /* Der Leser baut die Verbindung auf und haelt sie stabil. Er meldet aber KEINEN Messwert,
         * solange keine Codetabelle hinterlegt ist — die Zuordnung Datencode → Wert steht in einem
         * geraetespezifischen Draeger-Dokument, das oeffentlich nicht zu bekommen war. Siehe den
         * Kopfkommentar von bridge/src/adapters/medibus.js. */
        vorlage: { type: 'medibus', art: 'tcp', host: '', tcpPort: 4001, baud: 19200, paritaet: 'e', profil: 'klassisch', role: 'anesthesia', codes: {} },
        felder: [
          { name: 'art', text: 'Anschlussart', werte: ['tcp', 'com'], vorgabe: 'tcp',
            hilfe: 'tcp = ueber einen Geraeteserver (empfohlen) · com = direkt am COM-Anschluss des PCs' },
          { name: 'host', text: 'Adresse des Geraeteservers', vorgabe: '', hilfe: 'nur bei "tcp"' },
          { name: 'tcpPort', text: 'Port des Geraeteservers', vorgabe: 4001, hilfe: 'nur bei "tcp"' },
          { name: 'port', text: 'COM-Anschluss', vorgabe: 'COM1', hilfe: 'nur bei "com"' },
          { name: 'baud', text: 'Baudrate', vorgabe: 19200, hilfe: 'AM GERAET ABLESEN. Fabius-Werkseinstellung ist 9600, nicht 19200' },
          { name: 'paritaet', text: 'Paritaet', werte: ['e', 'n', 'o'], vorgabe: 'e',
            hilfe: 'AM GERAET ABLESEN. Fabius-Werkseinstellung ist NONE (n), MEDIBUS braucht meist EVEN (e)' },
          { name: 'profil', text: 'Protokollfassung', werte: ['klassisch', 'x'], vorgabe: 'klassisch',
            hilfe: 'Perseus A500 und Atlan koennen NUR MEDIBUS.X ("x"). Fabius unter SW 3.35 und Primus unter SW 4.50 koennen nur "klassisch".' },
        ],
        schritte: [
          'ZUERST: das Protokoll am Geraet von VITALINK auf MEDIBUS umstellen. Bei der Fabius-Familie liegt ' +
            'das im Service-Bildschirm (Home + Standby gedrueckt halten, dann den Drehknopf druecken) unter ' +
            '"Serial Port" → "Parameters".',
          'Dort auch Baudrate (19200) und Paritaet (EVEN) einstellen — die Werkswerte sind andere.',
          'Kabel: 9-polig Sub-D, sehr wahrscheinlich Nullmodem (gekreuzt). Beide Varianten durchprobieren.',
          'Empfohlen: einen Geraeteserver (RS-232 auf LAN) dazwischenhaengen — dann laeuft es ueber den ' +
            'erprobten Netzweg der Station.',
          'Mitschneiden und pruefen: node tools/seriell-pruefen.js --com COM1 --baud 19200',
          'WICHTIG: MEDIBUS verlangt, dass der PC regelmaessig fragt (alle 2 s ein Lebenszeichen, Antwort ' +
            'binnen 10 s, Pause ueber 3 s bricht ab). VetStation liest heute nur mit und fragt NICHT — der ' +
            'Datenstrom kommt also erst, wenn der MEDIBUS-Leser fertig ist. Bis dahin dient dieser Weg dem ' +
            'Mitschnitt und dem Nachweis, dass die Leitung steht.',
        ],
      },
    ],
  },

  {
    id: 'datex-7900-smartvent',
    hersteller: 'Datex-Ohmeda / GE',
    modell: '7900 SmartVent (Aestiva/5, Aespire) — haeufiger Vet-Umbau',
    aliase: ['Aestiva', 'Aestiva/5', 'Aespire', '7900 SmartVent', 'Ohmeda 7900', 'Aestiva 3000'],
    kategorie: 'narkose',
    einsatz: 'beides',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Diese Maschinen werden haeufig gebraucht in Tierkliniken aufgestellt, und ihr serieller ' +
      'Ausgang ist durch eine begutachtete Veroeffentlichung samt offenem Quellcode (Projekt "DownVent") ' +
      'belegt — das ist die beste Beleglage aller Narkosegeraete hier. EIN PUNKT MUSS BEWUSST ENTSCHIEDEN ' +
      'WERDEN: um den Datenstrom zu starten, schickt der PC zwei Kommandos (Pruefsumme aus, Automatikmodus ' +
      'ein). Das stellt die DATENAUSGABE ein und greift nicht in die Beatmung ein — es ist aber formal ein ' +
      'Schreibvorgang. VetStation wuerde das nur ueber die ausdrueckliche Erlaubnisliste in seriell.js tun.',
    quellen: [
      '"Data acquisition from Datex-Ohmeda Aestiva/5 7900 ventilator using an open-source Python project", PMC10805220',
      'https://github.com/patnatha/DownVent',
      'Datex-Ohmeda COM 1.0 Serial Protocol, Version 1.5 (14.08.2001)',
    ],
    wege: [
      {
        id: 'com10-seriell',
        name: 'Datex-Ohmeda COM 1.0 ueber RS-232',
        adapter: 'probe',
        transport: 'seriell',
        richtung: 'beides',
        port: null,
        seriell: '19200 Baud, 7 Datenbits, Paritaet ODD, 1 Stopbit — im Quellcode von DownVent verifiziert. ' +
          'Achtung: die COM-Nummerierung ist zwischen Aestiva und Aespire NICHT einheitlich; entscheidend ' +
          'sind die Pins (6 = RX, 13 = TX, 5 = GND).',
        rang: RANG_SPAET,
        lizenz: 'keine — der Anschluss ist am Geraet vorhanden und galvanisch getrennt.',
        liefert: 'Zwei Nachrichten je Atemzug, jeweils am Ende der Ausatmung: Messwerte (Tidalvolumen, ' +
          'Minutenvolumen, Atemfrequenz, O2-Konzentration ...) und Einstellungen.',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Serielles Kabel an den Datenanschluss der Maschine (Pins 6/13/5).',
          'Am PC 19200 Baud, 7 Datenbits, Paritaet ODD, 1 Stopbit einstellen.',
          'Mitschneiden und pruefen: node tools/seriell-pruefen.js --com COM1 --baud 19200',
          'Empfohlen: Geraeteserver (RS-232 auf LAN) statt Direktkabel.',
          'Hinweis: das Geraet sendet erst nach zwei Startkommandos vom PC. Diese Kommandos stellen nur ' +
            'die Datenausgabe ein und veraendern die Beatmung nicht.',
        ],
      },
    ],
  },

  {
    id: 'philips-intellivue',
    hersteller: 'Philips',
    modell: 'IntelliVue (X2, MP2-MP90, MX400-MX800)',
    aliase: ['IntelliVue', 'MP5', 'MP20', 'MP50', 'MX450', 'MX500', 'X2', 'Data Export'],
    kategorie: 'monitor',
    einsatz: 'human',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Philips hat als einziger Hersteller hier eine frei verfuegbare, vollstaendige ' +
      'Schnittstellenspezifikation ("Data Export Interface Programming Guide", Dok. 4535 645 88011), und ' +
      'sie ist NICHT an eine Lizenz gebunden. Drei Einschraenkungen: (1) X2 und MP2 haben KEINEN ' +
      'RS-232-Anschluss — sie koennen Data Export nur ueber LAN, und dafuer muessen sie in einer ' +
      'Dockingstation bzw. an einem Monitor haengen. (2) Kurven kann immer nur EIN Client gleichzeitig ' +
      'anfordern; wer zweiter ist, bekommt sie nicht. (3) Ab Revision G.0 haben sich Bezeichnungen einiger ' +
      'Mess- und Kurvenkennungen geaendert — ein Parser muss die Geraeterevision kennen.',
    quellen: [
      'Philips IntelliVue Data Export Interface Programming Guide, Dok. 453564588011, Published in Germany 08/15',
    ],
    wege: [
      {
        id: 'data-export-lan',
        name: 'Data Export ueber LAN (UDP)',
        adapter: 'probe',
        /*
         * TRANSPORT 'udp' UND NICHT 'lan' — das war ein stiller Totalausfall (korrigiert 02.08.2026).
         *
         * Hier stand transport:'lan'. Damit wanderte 24105 ueber datenPorts() in
         * netscan.DATA_PORTS, und dort wird — wie bei jedem anderen Eintrag — auf einem TCP-Port
         * gelauscht. Philips sendet Data Export aber AUSSCHLIESSLICH ueber UDP (Data Export
         * Interface Programming Guide 4535 645 88011, Kap. 4 'UDP Port Number': "The current
         * Protocol version uses the fixed UDP port 24105"). Die Station haette auf TCP 24105 bis
         * in alle Ewigkeit nichts empfangen, der Verbindungs-Assistent haette "keine Verbindung"
         * gemeldet, und der Anwender haette am Monitor gesucht, an dem alles richtig eingestellt
         * ist. Genau die endlose Fehlersuche, die dieser Katalog verhindern soll.
         * Ein eigener Transportwert haelt den Port aus der TCP-Lauschliste heraus, ohne ihn zu
         * verschweigen — er steht weiterhin in der Anleitung.
         */
        transport: 'udp',
        /* Und die Richtung stimmte auch nicht: 'beides' liest sich als "das Geraet sendet von
         * selbst". Tut es nicht — der PC muss zuerst eine Association Request an UDP 24105
         * schicken. Unaufgefordert kommt nur die Erkennungsmeldung auf UDP 24005. */
        richtung: 'pc_fragt_ab',
        port: 24105,
        rang: RANG_NORMAL,
        lizenz: 'keine — in der Spezifikation ist Data Export durchgehend eine Konfigurationseinstellung, keine Kaufoption.',
        liefert: 'Zahlenwerte, Alarme und wahlweise Kurven nach ISO/IEEE-Nomenklatur. Kurven kann immer ' +
          'nur EINE Verbindung anfordern ("Only one connection is able to request wave data at a time").',
        vertrauen: 'belegt',
        vorlage: null,
        schritte: [
          'Am Monitor im KONFIGURATIONSMODUS: Main Setup -> Global Settings -> "LAN Data Export" auf ' +
            '"all" (oder "anonymous data") stellen.',
          'ZWEITER PFLICHTSCHRITT, ohne den nichts geht: Main Setup -> Network -> "Central Monitoring" ' +
            'auf "Optional" stellen. Steht dort etwas anderes, nimmt der Monitor keine Verbindung eines ' +
            'Computer-Clients an.',
          'Der Datenverkehr laeuft ueber UDP 24105, die Geraeteerkennung ueber UDP 24005 — NICHT ueber ' +
            'TCP. Ein TCP-Lauscher auf 24105 empfaengt hier nie etwas.',
          'Bei X2/MP2: die LAN-Schnittstelle gibt es nur mit dem externen Netzteil M8023A. Haengt das X2 ' +
            'an einem Hostmonitor, laeuft der Export ueber diesen.',
          'Der Leser fuer dieses Protokoll ist in VetStation noch nicht gebaut — der PC muesste die ' +
            'Association Request selbst senden. Belegt ist der Weg vollstaendig (Data Export Interface ' +
            'Programming Guide 4535 645 88011).',
        ],
      },
    ],
  },

  {
    id: 'ge-datex-s5',
    hersteller: 'GE Healthcare / Datex-Ohmeda',
    modell: 'S/5 Monitore und CARESCAPE',
    aliase: ['S/5', 'S5', 'AS/3', 'Cardiocap', 'CARESCAPE B450', 'B650', 'B850', 'Datex', 'S/5 Collect'],
    kategorie: 'monitor',
    einsatz: 'beides',
    oui: [],
    vertrauen: 'wahrscheinlich',
    fallstricke: 'Der Datenausgang der S/5-Familie ("Datex Record Interface", DRI) ist gut erforscht und wird ' +
      'von VSCapture unterstuetzt — das ist hier der schnellste Weg. Zwei Widersprueche, die man kennen ' +
      'muss: das Handbuch nennt 115,2 kBaud mit 8-N-1, die funktionierenden Implementierungen benutzen ' +
      'dagegen 19200 mit 8-E-1. Und der "DRI Level" (1999/2001/2003) muss am Monitor zum Leser passen; ' +
      'wird er geaendert, startet der Monitor neu. Sehr alte AS/3-Softwarestaende (vor 1995) sprechen ' +
      'gar nicht mit S/5 Collect.',
    quellen: [
      'Datex-Ohmeda S/5 Collect Programmer\'s Guide / DRI-Dokumentation',
      'VSCapture-Projekt (SourceForge), GE-Modul',
    ],
    wege: [
      {
        id: 'vscapture',
        name: 'Ueber VSCapture (empfohlen) — CSV mitlesen',
        adapter: 'vscapture',
        transport: 'datei',
        richtung: 'geraet_sendet',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'keine',
        liefert: 'Zahlenwerte, je nach Geraet auch Kurven — das, was VSCapture aus dem Monitor holt.',
        vertrauen: 'wahrscheinlich',
        vorlage: { type: 'vscapture', file: 'C:/VetStation/vscapture/GEDataExport.csv', role: 'monitor', pollMs: 1000 },
        schritte: [
          'VSCapture installieren und das GE-Modul waehlen.',
          'Serielles Kabel vom Monitor an den PC (oder ueber einen Geraeteserver).',
          'Am Monitor den "DRI Level" pruefen (Monitor Setup → Install/Service → Service → Frame → Network).',
          'Hier den Pfad der von VSCapture geschriebenen CSV eintragen.',
        ],
      },
    ],
  },

  /* ================================================================
   * RUECKFALLWEG FUER ALLE HERSTELLER: fremde Auslese-Software
   * schreibt eine CSV, die Station liest sie mit. Kostet Genauigkeit
   * in der Zeit, ist dafuer aber herstellerunabhaengig.
   * ================================================================ */

  {
    id: 'vscapture-csv',
    hersteller: '(herstellerunabhaengig)',
    modell: 'VSCapture (Rueckfallweg ueber CSV)',
    aliase: ['VSCapture', 'VSCaptureMRay', 'VSCaptureGE'],
    kategorie: 'kombi',
    einsatz: 'beides',
    oui: [],
    vertrauen: 'belegt',
    fallstricke: 'Kein eigener Geraeteweg, sondern eine Bruecke: VSCapture spricht das Geraeteprotokoll und ' +
      'schreibt eine CSV, die VetStation mitliest. Nachteil: eine zweite Software muss laufen, und sie belegt ' +
      'die Geraeteverbindung exklusiv — der eigene HL7-Abfrageweg der Station ist dann blockiert.',
    quellen: ['https://sourceforge.net/projects/vscapture/'],
    wege: [
      {
        id: 'csv',
        name: 'CSV von VSCapture mitlesen',
        adapter: 'vscapture',
        transport: 'datei',
        richtung: 'geraet_sendet',
        port: null,
        rang: RANG_SPAET,
        lizenz: 'keine',
        liefert: 'Das, was VSCapture aus dem Geraet holt — je nach Geraetefamilie Zahlenwerte, teils Kurven.',
        vertrauen: 'belegt',
        vorlage: { type: 'vscapture', file: 'C:/VetStation/vscapture/MRayDataExport.csv', role: 'combo', pollMs: 1000 },
        schritte: [
          'VSCapture einrichten: installer/setup-vscapture-fallback.ps1 als Administrator ausfuehren.',
          'start-vscapture.bat starten — es schreibt MRayDataExport.csv.',
          'Hier den Pfad zu dieser Datei eintragen.',
        ],
      },
    ],
  },

  /* ================================================================
   * DIAGNOSTIK-EKG AM USB
   *
   * WARUM DIESER EINTRAG UEBERHAUPT ANGELEGT WURDE, obwohl das Geraet noch nicht gelesen
   * werden kann (12.08.2026): Die Station bringt den USB-Treiber des EKG 2000 seit dem
   * 07.08.2026 MIT und installiert ihn still vor (installer/set-ekg-treiber.ps1, nachgeprueft:
   * ftdibus.inf/ftdiport.inf liegen im Windows-Treiberspeicher). Das Geraet meldet sich beim
   * Anstecken also brav als COM-Anschluss - und dann passiert nichts, weil niemand mitliest.
   * Ein halber Weg, der nirgends steht, ist schlimmer als kein Weg: der Anwender sucht den
   * Fehler bei sich, beim Kabel oder beim Treiber. Dieser Eintrag sagt ihm, wo er wirklich
   * steht, und was noch fehlt.
   * ================================================================ */
  {
    id: 'eickemeyer-ekg-2000',
    hersteller: 'Eickemeyer (Bauart: Grimed)',
    modell: 'EKG 2000 / PC-EKG',
    aliase: ['PC-EKG', 'Grimed EKG 2000', 'EKG2000', 'Eickemeyer 321018', 'VETNAR 2200', 'VETMON 2200'],
    kategorie: 'ekg',
    einsatz: 'vet',
    oui: [],                  /* USB-Geraet, keine MAC - der Netzscan findet es grundsaetzlich nicht */
    vertrauen: 'belegt',      /* belegt ist die HARDWARE-Kennung, NICHT das Datenformat (siehe wege) */
    fallstricke:
      'DAS FELD "Code:" IM INSTALLATIONSFENSTER DES EKG 2000 IST KEIN GERAETEPASSWORT. Es ist der ' +
      'Lizenzschluessel fuer das Windows-Programm von Grimed/Eickemeyer und schaltet nur DESSEN ' +
      'Installation frei. Das Geraet selbst ist nicht passwortgeschuetzt: es ist ein FTDI-USB-Wandler ' +
      '(VID_0403, PID_8AC8) und meldet sich beim Anstecken als virtueller COM-Anschluss, sobald der ' +
      'Treiber liegt. VetStation bringt genau diesen Treiber mit — fuer die Verbindung wird der Code ' +
      'also nicht gebraucht. Er wird nur gebraucht, wenn man ZUSAETZLICH das Originalprogramm ' +
      'installieren will.',
    quellen: [
      'Installationsarchiv "EKG_2000_V_2_04_08 Certified.zip" (Eickemeyer, 2025-07-10): ' +
        'INSTALL.EXE, EKG.cab, FTDI-Treiber 2.08.02 und WHQL_USB_driver — eigene Durchsicht 12.08.2026',
      'treiber/ekg2000/ftdibus.inf: USB\\VID_0403&PID_8AC8 = "EKG 2000", &PID_8AC9 = "VETNAR 2200"',
      'installer/set-ekg-treiber.ps1 (Vorinstallation in den Treiberspeicher, seit 07.08.2026)',
      'Handbuch 321018_PC-EKG_Prod_1_DE',
      /* Seit dem 16.08.2026 die belastbarste Quelle: das entschluesselte Herstellerarchiv
       * selbst. Jede Fundstelle steht mit virtueller Adresse in ekg2000-protokoll.js. */
      'Herstellerarchiv "PC-EKG.zip" (Eickemeyer, entschlüsselt 16.08.2026, Fassung 2.04.08): ' +
        'eigene Durchsicht des Maschinencodes von Basic_V.exe, EKG_V.exe, EKG_VL.exe und ' +
        'Monitor.exe — daraus Leitungsparameter, Anmeldegespräch, Firmware-Auswahl; ' +
        'siehe bridge/src/ekg2000-protokoll.js',
      'Handbuch 1_manual.pdf (deutsch) und 2_manual.pdf (englisch), Abschnitt "Technische ' +
        'Daten": 3 Extremitätenkanäle (erweitert bis 6 Brustwandkanäle), Ableitungen I, II, ' +
        'III, aVR, aVL, aVF, CX (erweitert V1–V6), Empfindlichkeit 5/10/20/40 mm/mV, Vorschub ' +
        '10/12,5/25/50/100 mm/s. Abtastrate und Auflösung nennt das Handbuch NICHT.',
    ],
    wege: [
      {
        id: 'usb-com-mitlesen',
        name: 'USB: Gerät meldet sich als COM-Anschluss — Datenformat noch offen',
        adapter: 'ekg2000',
        transport: 'usb',
        richtung: 'unbekannt',
        rang: RANG_SPAET,
        lizenz: 'keine',
        /* HIER STEHT BEWUSST, WAS NICHT GEHT. Die Regel dieses Projekts lautet: sie misst und
         * schweigt im Zweifel. Eine erfundene Baudrate waere schlimmer als keine - der Anwender
         * bekaeme eine Kurve aus Rauschen und haette keinen Anlass, ihr zu misstrauen. */
        liefert:
          'EINE KURVE — UNGEEICHT. Seit dem 16.08.2026 führt die Station die ganze Kette selbst: ' +
          'Gerät anstecken → USB-Wache findet es → Kennung abfragen (Byte 0x10) → passende ' +
          'Firmware aus firmware\\ekg2000 in das Gerät laden → auf 38400 Baud umschalten → ' +
          '0x90/0x88 → Rahmen lesen (0x80 + je Kanal eine vorzeichenbehaftete Differenz, ' +
          'aufsummiert). Die Abtastrate wird dabei GEMESSEN (Rahmen je Sekunde gegen die PC-Uhr), ' +
          'nicht angenommen. ' +
          'WAS WEITERHIN FEHLT: die Umrechnung Digit → Mikrovolt. Sie steht weder im Handbuch ' +
          'noch im Herstellerprogramm. Die Kurve wird deshalb ausdrücklich als kalibriert:false ' +
          'und in der Einheit "digit" gemeldet, und es werden KEINE Amplituden, Millivolt oder ' +
          'Befunde daraus abgeleitet — eine geratene Verstärkung verschöbe jede Amplitude linear ' +
          'mit, und das Ergebnis sähe aus wie ein befundetes EKG. Sobald der 1-mV-Eichzacken ' +
          'einmal aufgezeichnet ist, trägt man das Ergebnis als eichungUvProDigit ein, und die ' +
          'Kurve gilt als geeicht. ' +
          'NICHT AN ECHTER HARDWARE ERPROBT: hier hing kein Gerät. Alles unten Genannte ist aus ' +
          'dem Maschinencode des Herstellerprogramms belegt, aber am Gerät ungeprüft. ' +
          'Frühere Fassung dieses Feldes (bis 16.08.2026): ' +
          'Messwerte: NOCH NICHTS. Was am 16.08.2026 zuerst dazukam, war die BESTÄTIGUNG ' +
          'des Geräts: die Station steckt es selbst an (USB-Wache), öffnet den Anschluss mit den ' +
          'aus dem Herstellerprogramm gemessenen Parametern (19200 Baud, 8 Datenbits, gerade ' +
          'Parität, 1 Stoppbit) und führt dessen Anmeldegespräch — Anfragebyte 0x10, Antwort ' +
          '0x20/0x21/0x22 für die Bauart, 0xAF für "noch nicht bereit". Damit sagt sie belegt ' +
          '"hier hängt ein EKG 2000, Bauart 1 bzw. 2" statt nur "hier ist ein COM-Anschluss". ' +
          'Eine KURVE liefert sie weiterhin nicht, und zwar aus zwei nachprüfbaren Gründen: ' +
          '(1) der Aufbau des Messdatenstroms (Rahmenlänge, Kanalfolge, Bits je Abtastwert, ' +
          'Abtastrate, Mikrovolt je Digit) ist nach wie vor nicht belegt — auch das Handbuch ' +
          'nennt ihn nicht; (2) das Gerät ist ohne Firmware stumm: es holt sein Programm bei ' +
          'JEDEM Start vom PC (16-Byte-Blöcke ab Adresse 0x8000), und diese Firmware gehört dem ' +
          'Hersteller und liegt deshalb nicht im VetStation-Paket. Das Diagnostik-EKG arbeitet ' +
          'weiter mit der nachgebildeten Kurve, und der Ausdruck weist sie ausdrücklich als ' +
          'nachgebildet aus.',
        vertrauen: 'unbestaetigt',
        vorlage: null,
        schritte: [
          'Gerät einfach anstecken — mehr ist seit 16.08.2026 nicht zu tun. Die Station sieht ' +
            'alle 12 Sekunden nach (USB-Wache), trägt das Gerät selbst ein und nimmt es sofort ' +
            'in Betrieb; ein Neustart ist nicht nötig. Im Protokoll steht dann, welche Bauart ' +
            'geantwortet hat.',
          'Erscheint unter Geräte-Manager → Anschlüsse KEIN "EKG 2000 Serial Port (COMx)", ' +
            'fehlt der Treiber: installer\\set-ekg-treiber.ps1 -Erzwingen (als Administrator). ' +
            'Die Station sagt das von sich aus, sobald sie das Gerät ohne Treiber am USB sieht.',
          'AUSNAHME ÄLTERE BAUART: meldet Windows VID_0403 mit PID_6003 oder PID_6004, ist es ' +
            'ein EKG 2000 der ersten Generation. Dafür bringt VetStation KEINEN Treiber mit — ' +
            'das Herstellerpaket 2.08.02 hat keine Katalogdatei und lässt sich unter Windows 11 ' +
            'nicht vorinstallieren. Hier hilft nur das Original-Setup von Eickemeyer.',
          'Das Original-Setup von Eickemeyer wird für die aktuelle Bauart NICHT gebraucht und ' +
            'der "Code" nicht eingegeben.',
          'Damit VetStation eine KURVE zeigen kann, fehlen zwei Dinge: der Aufbau des ' +
            'Datenstroms (nirgends veröffentlicht; nachgesehen wurden Produktblatt 321018, ' +
            'deutsches und englisches Handbuch, zwei Internetrecherchen, die Treiberdateien und ' +
            'zuletzt der Maschinencode des Herstellerprogramms selbst) — und die Firmware, die ' +
            'das Gerät bei jedem Start vom PC holt und die dem Hersteller gehört.',
          'DAS GERÄT SELBST IST DIE BELASTBARSTE QUELLE. Mit angestecktem Gerät im Stationsordner ' +
            'EKG-PRUEFEN.bat doppelklicken: sie sucht den Anschluss, probiert die üblichen ' +
            'Übertragungsgeschwindigkeiten durch, zeichnet auf, was ankommt, und sagt, ob eine feste ' +
            'Satzlänge erkennbar ist. Sie sendet dabei NICHTS an das Gerät und rät nichts: am Ende ' +
            'steht entweder eine belegte Formatbeschreibung oder ausdrücklich "kein Muster erkennbar".',
          'Kommt dabei nichts an, sendet das Gerät vermutlich erst auf Aufforderung. Dann hilft nur ' +
            'die Schnittstellenbeschreibung von Eickemeyer/Grimed (Artikel 321018).',
          'Bis dahin bleibt die Kurve im Diagnostik-EKG nachgebildet — sie wird nirgends als Messung ausgegeben.',
        ],
      },
    ],
  },
];

/* ------------------------------------------------------------------ *
 * Nachschlagen. Alles reine Funktionen — deshalb ohne Netz und ohne
 * Geraet pruefbar (tools/geraetekatalog-test.js).
 * ------------------------------------------------------------------ */

function normText(s) {
  return String(s == null ? '' : s).toLowerCase().replace(/[\s._-]+/g, '');
}

function normMac(mac) {
  return String(mac || '').toLowerCase().replace(/[^0-9a-f]/g, '');
}

function alle() { return KATALOG; }

function nachId(id) {
  const k = String(id || '');
  return KATALOG.filter((g) => g.id === k)[0] || null;
}

function weg(geraetId, wegId) {
  const g = nachId(geraetId);
  if (!g) return null;
  return (g.wege || []).filter((w) => w.id === wegId)[0] || null;
}

/*
 * suche(text) — die Volltextsuche des Modellwaehlers.
 *
 * Sie sucht ueber Hersteller, Modell UND Aliase, weil ein Tierarzt "lifevet10c", "LifeVet 10 C" und
 * "ePM 10" schreibt und dasselbe Geraet meint. Leerzeichen, Punkte und Bindestriche werden dabei
 * ignoriert — sonst findet "uMEC 12" den Eintrag "uMEC12" nicht.
 */
function suche(text) {
  const q = normText(text);
  if (!q) return KATALOG.slice();
  return KATALOG.filter((g) => {
    const felder = [g.hersteller, g.modell].concat(g.aliase || []);
    return felder.some((f) => normText(f).indexOf(q) >= 0);
  });
}

/*
 * datenPorts() — die Portliste, auf der gelauscht wird. EINZIGE Quelle fuer netscan.DATA_PORTS.
 *
 * Sortiert nach Rang, bei gleichem Rang numerisch. Der Rang steht am jeweiligen Weg, damit die
 * Begruendung ("das ist die Werkseinstellung des uMEC") bei der Zahl bleibt und nicht in einer
 * separaten Liste verwaist.
 */
function datenPorts() {
  const rang = {};
  KATALOG.forEach((g) => {
    (g.wege || []).forEach((w) => {
      if (!w.port) return;
      if (w.transport !== 'lan' && w.transport !== 'wlan') return;
      const p = Number(w.port);
      if (!Number.isFinite(p) || p <= 0 || p > 65535) return;
      const r = Number.isFinite(w.rang) ? w.rang : RANG_NORMAL;
      if (!(p in rang) || r < rang[p]) rang[p] = r;
    });
  });
  return Object.keys(rang).map(Number).sort((a, b) => (rang[a] - rang[b]) || (a - b));
}

/* Welche Geraete koennten auf diesem Port sprechen? Fuer die Erkennung und fuer die Begruendung
 * einer Portfreigabe ("wozu ist 8830 da?"). */
function geraeteAufPort(port) {
  const p = Number(port);
  return KATALOG.filter((g) => (g.wege || []).some((w) => Number(w.port) === p));
}

/* Alle MAC-Praefixe. EINZIGE Quelle fuer geraetefund.MEDIZIN_OUI. */
function ouiListe() {
  const s = {};
  KATALOG.forEach((g) => (g.oui || []).forEach((o) => { const n = normMac(o); if (n.length === 6) s[n] = true; }));
  return Object.keys(s).sort();
}

/* Hersteller zu einer MAC — reiner HINWEIS, nie ein Ausschlusskriterium (siehe netscan.js). */
function herstellerVonMac(mac) {
  const m = normMac(mac);
  if (m.length < 6) return null;
  const p = m.slice(0, 6);
  const treffer = KATALOG.filter((g) => (g.oui || []).some((o) => normMac(o) === p));
  if (!treffer.length) return null;
  // Mehrere Modelle teilen sich eine OUI — dann nur den Herstellernamen nennen, nicht raten, welches.
  const namen = {};
  treffer.forEach((g) => { namen[g.hersteller] = true; });
  return Object.keys(namen).join(' / ');
}

function istMedizinMac(mac) {
  const m = normMac(mac);
  return m.length >= 6 && ouiListe().indexOf(m.slice(0, 6)) >= 0;
}

/* Geraete dieses Herstellers (nach MAC) — Grundlage der Modellvorschlaege. */
function geraeteMitOui(mac) {
  const m = normMac(mac);
  if (m.length < 6) return [];
  const p = m.slice(0, 6);
  return KATALOG.filter((g) => (g.oui || []).some((o) => normMac(o) === p));
}

/*
 * pruefe() — Selbstpruefung des Katalogs. Wird vom Test aufgerufen UND beim Start geladen, damit
 * ein Tippfehler in den Daten sofort auffaellt und nicht erst, wenn ein Tierarzt danach sucht.
 * Gibt eine Liste von Beanstandungen zurueck; leer = in Ordnung.
 */
function pruefe() {
  const fehler = [];
  const ids = {};
  KATALOG.forEach((g, i) => {
    const wo = 'Eintrag ' + i + ' (' + (g.id || 'ohne id') + ')';
    if (!g.id || !/^[a-z0-9-]+$/.test(g.id)) fehler.push(wo + ': id fehlt oder enthaelt unerlaubte Zeichen');
    if (ids[g.id]) fehler.push(wo + ': id doppelt vergeben');
    ids[g.id] = true;
    if (!g.hersteller) fehler.push(wo + ': hersteller fehlt');
    if (!g.modell) fehler.push(wo + ': modell fehlt');
    if (KATEGORIEN.indexOf(g.kategorie) < 0) fehler.push(wo + ': unbekannte kategorie "' + g.kategorie + '"');
    if (['vet', 'human', 'beides'].indexOf(g.einsatz) < 0) fehler.push(wo + ': unbekannter einsatz "' + g.einsatz + '"');
    if (VERTRAUEN.indexOf(g.vertrauen) < 0) fehler.push(wo + ': unbekanntes vertrauen "' + g.vertrauen + '"');
    if (!(g.quellen || []).length) fehler.push(wo + ': keine Quelle angegeben — ein Eintrag ohne Quelle ist ein Geruecht');
    (g.oui || []).forEach((o) => { if (normMac(o).length !== 6) fehler.push(wo + ': OUI "' + o + '" ist kein 6-stelliges MAC-Praefix'); });
    if (!(g.wege || []).length) fehler.push(wo + ': kein einziger Anbindungsweg');
    const wids = {};
    (g.wege || []).forEach((w, j) => {
      const ww = wo + ' Weg ' + j + ' (' + (w.id || 'ohne id') + ')';
      if (!w.id) fehler.push(ww + ': id fehlt');
      if (wids[w.id]) fehler.push(ww + ': Weg-id doppelt');
      wids[w.id] = true;
      if (!w.name) fehler.push(ww + ': name fehlt');
      if (!w.adapter) fehler.push(ww + ': adapter fehlt');
      if (TRANSPORTE.indexOf(w.transport) < 0) fehler.push(ww + ': unbekannter transport "' + w.transport + '"');
      if (RICHTUNGEN.indexOf(w.richtung) < 0) fehler.push(ww + ': unbekannte richtung "' + w.richtung + '"');
      if (VERTRAUEN.indexOf(w.vertrauen) < 0) fehler.push(ww + ': unbekanntes vertrauen "' + w.vertrauen + '"');
      if (!w.liefert) fehler.push(ww + ': "liefert" fehlt — der Anwender muss wissen, WAS ankommt');
      if (!(w.schritte || []).length) fehler.push(ww + ': keine Schritte — dann kann der Berater nichts sagen');
      if ((w.transport === 'lan' || w.transport === 'wlan') && !w.port) fehler.push(ww + ': Netzweg ohne Port');
      if (w.transport === 'seriell' && !w.seriell) fehler.push(ww + ': serieller Weg ohne Angabe der Schnittstellenparameter');
    });
  });
  return fehler;
}

module.exports = {
  KATALOG, KATEGORIEN, TRANSPORTE, RICHTUNGEN, VERTRAUEN,
  RANG_ZUERST, RANG_NORMAL, RANG_SPAET,
  alle, nachId, weg, suche,
  datenPorts, geraeteAufPort,
  ouiListe, herstellerVonMac, istMedizinMac, geraeteMitOui,
  normText, normMac, pruefe,
};
