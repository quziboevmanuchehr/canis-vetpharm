'use strict';
/*
 * virtuelles-geraet-test.js — ist die NACHBILDUNG geeicht?
 *
 * WARUM ES DIESEN TEST GIBT (Nutzerfrage 10.08.2026: "es muss das virtuelle Monitorgeraet
 * genau kalibriert werden, damit es genau medizinische Werte ausgibt"):
 *
 * Die nachgebildete EKG-Kurve wurde bis heute ueber die PHASE des Herzschlags gebaut. Die
 * Phase laeuft in jedem Schlag von 0 bis 1 - ihre Breite in Sekunden haengt damit an der
 * Herzfrequenz. Nachgemessen an der alten Fassung:
 *
 *      60/min -> QRS 23 ms     140/min -> QRS 10 ms
 *     100/min -> QRS 14 ms     200/min -> QRS  7 ms
 *
 * Ein Kammerkomplex ist aber eine Eigenschaft der Kammer, nicht der Frequenz. Auf einem
 * Trainingsblatt lernt man damit das Falsche, und der Messzirkel misst die Frequenz statt
 * das Herz.
 *
 * Dieser Test schliesst den Kreis: er baut die Kurve mit DERSELBEN Funktion, die die
 * Anwendung benutzt, laesst sie von DERSELBEN Auswertung vermessen und vergleicht das
 * Ergebnis mit der Vorgabe des Modells. Genau das zeigt die Oberflaeche als "Eichpruefung".
 *
 * BRAUCHT ES DAFUER EIN ANGESCHLOSSENES GERAET? Nein - und das ist der Punkt. Geeicht wird
 * gegen eine bekannte Vorgabe. Ein Geraet braucht man, um ein TIER zu messen.
 *
 * Aufruf:  node tools/virtuelles-geraet-test.js
 */
const fs = require('fs');
const path = require('path');
const VS = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-analyse.js'));

let gruen = 0, rot = 0;
function pruef(name, bed, zusatz) {
  if (bed) { gruen++; console.log('  ✓ ' + name); }
  else { rot++; console.log('  ✗ ' + name + (zusatz ? '   -> ' + zusatz : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

/* Die Bausteine aus index.html holen - NICHT nachbauen. Ein Test, der die Formel abschreibt,
 * prueft nur, dass ich zweimal dasselbe denke. */
const SRC = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');
function holeFunktion(name) {
  const start = SRC.indexOf('function ' + name + '(');
  if (start < 0) return null;
  const auf = SRC.indexOf('{', start);
  let tiefe = 0;
  for (let i = auf; i < SRC.length; i++) {
    if (SRC[i] === '{') tiefe++;
    else if (SRC[i] === '}') { tiefe--; if (!tiefe) return SRC.slice(start, i + 1); }
  }
  return null;
}
const MODELL_SRC = SRC.slice(SRC.indexOf('var MODELL={'), SRC.indexOf('\n};', SRC.indexOf('var MODELL={')) + 3);
const bau = new Function(MODELL_SRC + '\n' + holeFunktion('modellFuer') + '\n' +
  holeFunktion('mWelle') + '\n' + holeFunktion('ekgWaveMv') +
  '\nreturn { MODELL: MODELL, modellFuer: modellFuer, ekgWaveMv: ekgWaveMv };')();
const MODELL = bau.MODELL, ekgWaveMv = bau.ekgWaveMv;

const HZ = 250;                                   // EKG_HZ der Anwendung
/* Streifen bauen wie advance(): Phase mal Zyklusdauer = Zeit seit Zyklusbeginn. */
function streifen(hf, sek, sp, W) {
  const rr = 60 / hf, n = Math.round(HZ * sek), s = new Array(n);
  let ph = 0, beat = 0;
  for (let i = 0; i < n; i++) {
    const vor = ph;
    ph = (ph + (1 / HZ) / rr) % 1;
    if (ph < vor) beat++;
    s[i] = ekgWaveMv(ph * rr, rr, W || { p: true, pq: 1, qrs: 1 }, beat, sp);
  }
  return s;
}
function feinMax(sp) {
  /* Das Modell STETIG abtasten (20 kHz) - so ist die Vorgabe definiert, unabhaengig vom
   * 250-Hz-Raster der Anwendung. */
  const rr = 0.6, N = 12000; let max = -9;
  for (let i = 0; i < N; i++) { const v = ekgWaveMv(i / N * rr, rr, { p: true, pq: 1, qrs: 1 }, 0, sp); if (v > max) max = v; }
  return max;
}
function messe(hf, sp, sek) {
  return VS.analysiere({ samples: streifen(hf, sek || 20, sp), hz: HZ, skala: 1, einheit: 'mV' },
    { art: sp, einheit: 'mV', bandHr: [1, 999] });
}

// ===========================================================================
block('1. Die QRS-Breite haengt NICHT mehr an der Herzfrequenz');
{
  /* DER EIGENTLICHE BEFUND. Frueher: 23 ms bei 60/min gegen 7 ms bei 200/min - Faktor 3,3. */
  const breiten = [60, 90, 120, 160, 200].map((hf) => {
    const e = messe(hf, 'hund', 16);
    return { hf: hf, qrs: e.qrsBreiteMs, hfGemessen: e.hf };
  });
  breiten.forEach((b) => pruef('bei ' + b.hf + '/min wird eine QRS-Breite gemessen', b.qrs != null, JSON.stringify(b)));
  const werte = breiten.map((b) => b.qrs).filter((x) => x != null);
  const min = Math.min.apply(null, werte), max = Math.max.apply(null, werte);
  /* DIE ZAHL, AUF DIE ES ANKOMMT, IST DAS VERHAELTNIS. Alt: 23 ms bei 60/min gegen 7 ms bei
   * 200/min - Faktor 3,3, also eine Breite, die vor allem die Frequenz misst. Neu darf die
   * hoechste hoechstens das Anderthalbfache der niedrigsten sein; der Rest ist Abtastraster
   * (4 ms je Schritt) und die 12-ms-Haltezeit der Endebestimmung. */
  pruef('sie haengt nicht mehr an der Frequenz (hoechstens Faktor 1,5; frueher 3,3)',
    max <= min * 1.5, 'von ' + min + ' bis ' + max + ' ms bei ' + JSON.stringify(werte));
  pruef('die Spanne bleibt im Bereich des Abtastrasters (<= 14 ms)',
    (max - min) <= 14, 'Spanne ' + (max - min) + ' ms');
  pruef('und sie liegt im Band des Hundes (bis 60 ms)', max <= 60, max + ' ms');
}

// ===========================================================================
block('2. Die Vorgabe wird wiedergefunden — Hund');
{
  const Mm = MODELL.hund;
  const e = messe(100, 'hund', 20);
  pruef('der Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('Herzfrequenz: Vorgabe 100 -> gemessen ' + e.hf, Math.abs(e.hf - 100) <= 3);
  /* ==================================================================================
   * EINE SCHWELLENMESSUNG LIEST DAUERN SYSTEMATISCH ZU KURZ — UND ZWAR MESSBAR
   *
   * Anfang und Ende einer Welle werden ueber eine Schwelle bestimmt (8 % der Spitze bzw. das
   * 2,5-fache der Grundlinienunruhe). Eine Welle laeuft an ihren Enden flach aus; die
   * Schwelle wird deshalb INNERHALB der wahren Dauer erreicht. Gemessen gegen die Vorgabe:
   *     Hund  QRS 50 ms -> 40 ms (-20 %)      P 40 ms -> 24 ms (-40 %)
   *     Katze QRS 35 ms -> 20 ms (-43 %)
   * Je schmaler die Welle, desto groesser der Anteil - bei der Katze am staerksten.
   *
   * WARUM DAS TROTZDEM SO BLEIBT: jede Alternative war schlechter. Mit 5 % statt 8 % lief die
   * Messung auf ruhigen Streifen so weit aus, dass ein Sinuskomplex als verbreitert galt und
   * die Auswertung einen idioventrikulaeren Rhythmus MELDETE - ein erfundener Befund wiegt
   * schwerer als eine zu kurze Zahl. Die Richtung des Fehlers ist ausserdem die vorsichtige:
   * er meldet zu selten "verbreitert", nie zu oft.
   *
   * WAS DER TEST DESHALB PRUEFT: nicht "gleich", sondern "zu kurz, aber BEGRENZT und in der
   * richtigen Reihenfolge". Waere die Messung ploetzlich zu LANG, waere das ein neuer Fehler
   * in der gefaehrlichen Richtung - dagegen steht die obere Grenze.
   * ================================================================================== */
  pruef('QRS: Vorgabe ' + Mm.qrsMs + ' ms -> gemessen ' + e.qrsBreiteMs + ' ms (Schwellenmessung liest kurz)',
    e.qrsBreiteMs >= Mm.qrsMs * 0.55 && e.qrsBreiteMs <= Mm.qrsMs * 1.10,
    'Abweichung ' + Math.round((e.qrsBreiteMs - Mm.qrsMs) / Mm.qrsMs * 100) + ' %');
  pruef('die P-Welle wird gefunden', !!(e.p && e.p.vorhanden), (e.p && e.p.warum) || '');
  if (e.p && e.p.vorhanden) {
    /* Die PQ-ZEIT ist der Abstand zweier ANFAENGE und damit von der Schwelle fast unabhaengig -
     * sie trifft die Vorgabe auf zwei Prozent. Genau daran sieht man, dass die Zeitbasis
     * stimmt und nur die Dauermessung ihre bekannte Kuerze hat. */
    pruef('PQ: Vorgabe ' + Mm.pqMs + ' ms -> gemessen ' + e.p.pqMs + ' ms',
      Math.abs(e.p.pqMs - Mm.pqMs) <= Mm.pqMs * 0.20,
      'Abweichung ' + Math.round((e.p.pqMs - Mm.pqMs) / Mm.pqMs * 100) + ' %');
    pruef('P-Dauer: Vorgabe ' + Mm.pMs + ' ms -> gemessen ' + e.p.dauerMs + ' ms (ebenfalls kurz gelesen)',
      e.p.dauerMs >= Mm.pMs * 0.5 && e.p.dauerMs <= Mm.pMs * 1.2,
      'Abweichung ' + Math.round((e.p.dauerMs - Mm.pMs) / Mm.pMs * 100) + ' %');
  }
  const qtSoll = Mm.qrsMs + Mm.stMs + Mm.tMs;
  pruef('die T-Welle wird gefunden', !!(e.t && e.t.messbar), (e.t && e.t.warum) || '');
  if (e.t && e.t.messbar) {
    pruef('QT: Vorgabe ' + qtSoll + ' ms -> gemessen ' + e.t.qtMs + ' ms',
      Math.abs(e.t.qtMs - qtSoll) <= qtSoll * 0.20,
      'Abweichung ' + Math.round((e.t.qtMs - qtSoll) / qtSoll * 100) + ' %');
  }
  /* Und der Rhythmus muss das sein, was das Modell vorgibt: ein Sinusrhythmus mit P. */
  pruef('als Rhythmus kommt ein Sinusrhythmus heraus', e.rhythmus.id === 'sinus', e.rhythmus.name);
}

// ===========================================================================
block('3. Die Vorgabe wird wiedergefunden — Katze (andere Zahlen, andere Grenzen)');
{
  const Mm = MODELL.katze;
  const e = messe(180, 'katze', 20);
  pruef('der Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('Herzfrequenz: Vorgabe 180 -> gemessen ' + e.hf, Math.abs(e.hf - 180) <= 5);
  pruef('QRS: Vorgabe ' + Mm.qrsMs + ' ms -> gemessen ' + e.qrsBreiteMs + ' ms (Schwellenmessung liest kurz)',
    e.qrsBreiteMs >= Mm.qrsMs * 0.5 && e.qrsBreiteMs <= Mm.qrsMs * 1.1,
    'Abweichung ' + Math.round((e.qrsBreiteMs - Mm.qrsMs) / Mm.qrsMs * 100) + ' %');
  /* DER PUNKT, AN DEM DIE ART WIRKLICH ZAEHLT: der Katzenkomplex muss schmaler sein als der
   * des Hundes - sonst waere die Nachbildung ein Hund mit Katzenfrequenz. */
  const hund = messe(180, 'hund', 20);
  pruef('der Katzenkomplex ist schmaler als der des Hundes',
    e.qrsBreiteMs < hund.qrsBreiteMs, 'Katze ' + e.qrsBreiteMs + ' ms, Hund ' + hund.qrsBreiteMs + ' ms');
  pruef('und die Katze bleibt unter ihrer Artgrenze (bis 40 ms)', e.qrsBreiteMs <= 40, e.qrsBreiteMs + ' ms');
}

// ===========================================================================
block('4. Die Amplituden stimmen in MILLIVOLT');
{
  ['hund', 'katze'].forEach((sp) => {
    const Mm = MODELL[sp];
    const s = streifen(100, 12, sp);
    let max = -9; for (let i = 0; i < s.length; i++) if (s[i] > max) max = s[i];
    /* Der STETIGE Modellwert ist exakt - das ist die Vorgabe. Der ABGETASTETE Streifen
     * liest weniger, weil das 4-ms-Raster die Spitze einer schmalen R-Zacke nicht trifft:
     * beim Hund 3 %, bei der schmaleren Katzen-R bis 13 %. Das ist Physik der Abtastung und
     * gilt fuer jedes Geraet mit 250 Hz - deshalb wird es hier BEZIFFERT statt weggemittelt. */
    pruef(sp + ': die R-Zacke des Modells ist genau ' + Mm.rAmp + ' mV',
      Math.abs(feinMax(sp) - Mm.rAmp) < 0.001, 'stetig gemessen ' + Math.round(feinMax(sp) * 1000) / 1000);
    pruef(sp + ': abgetastet bleiben mindestens 85 % davon (' + Mm.rAmp + ' mV)',
      max >= Mm.rAmp * 0.85 && max <= Mm.rAmp * 1.001,
      'gemessen ' + Math.round(max * 1000) / 1000 + ' mV = ' + Math.round(max / Mm.rAmp * 100) + ' %');
    let min = 9; for (let i = 0; i < s.length; i++) if (s[i] < min) min = s[i];
    pruef(sp + ': die tiefste Auslenkung ist die S-Zacke (' + Mm.sAmp + ' mV)',
      Math.abs(Math.abs(min) - Mm.sAmp) < 0.02, 'gemessen ' + Math.round(min * 1000) / 1000 + ' mV');
  });
  /* Ein Modell ohne mV-Vorgabe waere wertlos - die Zahlen muessen zu den Normbaendern passen. */
  pruef('die Hunde-R liegt im Normband (1,0 bis 3,0 mV)', MODELL.hund.rAmp >= 1.0 && MODELL.hund.rAmp <= 3.0);
  pruef('die Katzen-R liegt im Normband (0,2 bis 0,9 mV)', MODELL.katze.rAmp >= 0.2 && MODELL.katze.rAmp <= 0.9);
  pruef('die Hunde-QT-Vorgabe liegt im Normband (150 bis 250 ms)',
    MODELL.hund.qrsMs + MODELL.hund.stMs + MODELL.hund.tMs >= 150 &&
    MODELL.hund.qrsMs + MODELL.hund.stMs + MODELL.hund.tMs <= 250);
  pruef('die Katzen-QT-Vorgabe liegt im Normband (120 bis 180 ms)',
    MODELL.katze.qrsMs + MODELL.katze.stMs + MODELL.katze.tMs >= 120 &&
    MODELL.katze.qrsMs + MODELL.katze.stMs + MODELL.katze.tMs <= 180);
  pruef('die Hunde-PQ-Vorgabe liegt im Normband (60 bis 130 ms)',
    MODELL.hund.pqMs >= 60 && MODELL.hund.pqMs <= 130);
  pruef('die Katzen-PQ-Vorgabe liegt im Normband (50 bis 90 ms)',
    MODELL.katze.pqMs >= 50 && MODELL.katze.pqMs <= 90);
}

// ===========================================================================
block('5. Die Eichpruefung in der Oberflaeche');
{
  const src = SRC.replace(/\/\*[\s\S]*?\*\//g, ' ');
  pruef('es gibt eine Eichpruefung', !!holeFunktion('eichPruefung'));
  const ep = holeFunktion('eichPruefung') || '';
  pruef('sie laeuft NUR ohne angeschlossenes Geraet', /if\(M\.echt\) return null/.test(ep),
    'am echten Signal gibt es keine Vorgabe');
  pruef('sie eicht nur am schlichten Sinusmodell',
    /W\.flat\|\|W\.chaos\|\|W\.drop\|\|W\.ectopic/.test(ep.replace(/\s+/g, '')),
    'ein Modell mit Ausfaellen hat keine EINE Vorgabe');
  pruef('sie benutzt DIESELBE Auswertung wie ein echter Streifen', /VS\.ekg\.analysiere/.test(ep));
  pruef('sie vergleicht Soll gegen Ist', /soll/.test(ep) && /ist:/.test(ep));
  pruef('das Ergebnis wird angezeigt', !!holeFunktion('renderEich') && /id="ekgEich"/.test(SRC));
  const re = holeFunktion('renderEich') || '';
  pruef('und ausdruecklich NICHT als Befund ueber ein Tier bezeichnet',
    /kein Befund über ein Tier/.test(re), 'der Satz fehlt');
  pruef('bei Abweichung wird auf das PROGRAMM gezeigt, nicht auf den Patienten',
    /Hinweis auf das PROGRAMM/.test(re));
  /* Und die Nachbildung darf weiterhin nicht "befundet" werden. */
  pruef('auf der Nachbildung laeuft weiterhin KEINE Befundregel',
    /zeigeHinweise\(null,f,normAktuell\(\),null\)/.test(src));
}

// ===========================================================================
block('6. Kein Rueckfall auf die phasenabhaengige Wellenform');
{
  const code = SRC.replace(/\/\*[\s\S]*?\*\//g, ' ');
  pruef('die alte, phasenabhaengige ekgWave() gibt es nicht mehr',
    !/function ekgWave\(/.test(code), 'sie ist zurueck');
  pruef('advance() rechnet die Phase in ZEIT um',
    /ekgWaveMv\(M\.phE\*rrJetzt,\s*rrJetzt/.test(code.replace(/\s+/g, ' ')));
  pruef('das Modell steht in EINER Tabelle', /var MODELL=\{/.test(code));
  ['hund', 'katze', 'pferd', 'standard'].forEach((sp) => {
    pruef('Modell fuer ' + sp + ' vorhanden', !!MODELL[sp]);
    if (MODELL[sp]) {
      ['rAmp', 'qrsMs', 'pqMs', 'tMs', 'stMs', 'pMs', 'pAmp'].forEach((f) => {
        pruef('  ' + sp + '.' + f + ' ist eine Zahl > 0', typeof MODELL[sp][f] === 'number' && MODELL[sp][f] > 0);
      });
    }
  });
}

console.log('\n' + (rot ? rot + ' FEHLGESCHLAGEN von ' + (gruen + rot)
  : 'ALLE ' + gruen + ' PRUEFUNGEN BESTANDEN'));
process.exit(rot ? 1 : 0);
