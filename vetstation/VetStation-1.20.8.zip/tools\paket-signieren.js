'use strict';
/*
 * paket-signieren.js — das Update-Paket signieren und das Manifest damit setzen.
 *
 * WARUM DIESES WERKZEUG DAS MANIFEST GLEICH MITSCHREIBT (13.08.2026):
 * Version, Pruefsumme und Signatur gehoeren zusammen - die Signatur gilt genau fuer DIESES
 * Paar (siehe updater/signatur.js). Wer sie von Hand in drei Felder eintraegt, hat drei
 * Gelegenheiten, sie auseinanderlaufen zu lassen; und die Freigabenotiz dieses Projekts
 * kennt bereits den Fall "die falsche Zip gehasht". Deshalb liest dieses Werkzeug die Zip
 * SELBST, rechnet die Pruefsumme SELBST und schreibt beide Felder zusammen mit der Signatur.
 * Von Hand bleibt nur die Freigabenotiz.
 *
 * Der private Schluessel wird NUR gelesen, nie ausgegeben und nie irgendwohin geschrieben.
 *
 * Start:
 *   node tools/paket-signieren.js
 *   node tools/paket-signieren.js --zip <pfad> --manifest <pfad> --schluessel <pfad>
 *   node tools/paket-signieren.js --nur-pruefen     (nichts schreiben, nur nachrechnen)
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const sig = require('../updater/signatur.js');

const ROOT = path.join(__dirname, '..');

function arg(name, standard) {
  const i = process.argv.indexOf(name);
  return (i >= 0 && process.argv[i + 1]) ? process.argv[i + 1] : standard;
}
const nurPruefen = process.argv.indexOf('--nur-pruefen') >= 0;

const version = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const zipPfad = arg('--zip', path.join(ROOT, 'dist', 'VetStation-' + version + '.zip'));
const manifestPfad = arg('--manifest', path.join(ROOT, '..', '..', 'canis-vetpharm', 'vetstation-version.json'));
const schluesselPfad = arg('--schluessel', path.join(os.homedir(), '.vetstation-keys', 'release-ed25519-priv.pem'));
const oeffentlichPfad = path.join(ROOT, 'updater', 'release-key.pub');

console.log('\nVetStation - Update-Paket signieren\n');

function abbruch(text) { console.log('  ABBRUCH: ' + text + '\n'); process.exit(1); }

if (!fs.existsSync(zipPfad)) {
  abbruch('Das Update-Paket fehlt:\n    ' + zipPfad
    + '\n  Erst bauen: powershell -ExecutionPolicy Bypass -File installer/make-dist.ps1');
}
if (!fs.existsSync(oeffentlichPfad)) {
  abbruch('updater/release-key.pub fehlt. Einmalig anlegen: node tools/schluessel-erzeugen.js');
}
if (!fs.existsSync(schluesselPfad)) {
  abbruch('Der private Schluessel fehlt:\n    ' + schluesselPfad
    + '\n  Er liegt bewusst ausserhalb des Repos. Einmalig anlegen: node tools/schluessel-erzeugen.js'
    + '\n  Auf einem anderen Rechner: aus der eigenen Sicherung zurueckspielen.');
}

/* DIE PRUEFSUMME WIRD HIER GERECHNET, NICHT UEBERNOMMEN. Ein uebergebener Wert waere genau
 * die Stelle, an der "die falsche Zip gehasht" wieder passieren kann. */
const zipBytes = fs.readFileSync(zipPfad);
const sha = crypto.createHash('sha256').update(zipBytes).digest('hex');

const privPem = fs.readFileSync(schluesselPfad, 'utf8');
const pubPem = fs.readFileSync(oeffentlichPfad, 'utf8');

let signatur;
try { signatur = sig.signiere(version, sha, privPem); }
catch (e) { abbruch('Signieren fehlgeschlagen: ' + e.message); }

/* SOFORT GEGENPRUEFEN, mit dem OEFFENTLICHEN Schluessel - also genau so, wie es die Station
 * spaeter tut. Passt der private Schluessel nicht zum ausgelieferten oeffentlichen, faellt
 * es hier auf und nicht auf zwanzig Praxis-PCs. */
const probe = sig.pruefe(version, sha, signatur, pubPem);
if (!probe.ok) {
  abbruch('Die eigene Gegenpruefung ist gescheitert: ' + probe.grund
    + '\n  Meist heisst das: der private Schluessel gehoert nicht zu updater/release-key.pub.');
}

console.log('  Paket:        ' + path.basename(zipPfad) + '  (' + Math.round(zipBytes.length / 1024) + ' KB)');
console.log('  Version:      ' + version);
console.log('  sha256:       ' + sha);
console.log('  Signatur:     ' + signatur);
console.log('  Schluessel:   Fingerabdruck ' + sig.fingerabdruck(pubPem));
console.log('  Gegenprobe:   Signatur gilt fuer genau diese Version und diese Pruefsumme');

if (nurPruefen) { console.log('\n  --nur-pruefen: es wurde nichts geschrieben.\n'); process.exit(0); }

if (!fs.existsSync(manifestPfad)) abbruch('Manifest nicht gefunden:\n    ' + manifestPfad);

const m = JSON.parse(fs.readFileSync(manifestPfad, 'utf8'));
if (m.app !== version) {
  abbruch('Das Manifest steht auf ' + m.app + ', das Paket ist ' + version + '.'
    + '\n  Erst das Manifest auf die neue Fassung setzen (app + notes), dann signieren.');
}
m.sha256 = sha;
m.sigEd25519 = signatur;
m.zipUrl = String(m.zipUrl || '').replace(/VetStation-\d+\.\d+\.\d+\.zip$/, 'VetStation-' + version + '.zip');
fs.writeFileSync(manifestPfad, JSON.stringify(m, null, 2) + '\n', 'utf8');

console.log('\n  Manifest gesetzt: ' + manifestPfad);
console.log('    app          ' + m.app);
console.log('    zipUrl       ' + m.zipUrl);
console.log('    sha256       ' + m.sha256);
console.log('    sigEd25519   ' + m.sigEd25519.slice(0, 24) + '...');
console.log('\n  Weiter: node tools/manifest-pruefen.js --freigabe\n');
