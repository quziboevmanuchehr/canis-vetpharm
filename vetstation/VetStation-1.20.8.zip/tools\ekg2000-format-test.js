'use strict';
/*
 * ekg2000-format-test.js — findet die Formaterkennung wirklich, was sie zu finden vorgibt?
 *
 * WARUM DIESER TEST VOR DEM GERAET KOMMT:
 * bridge/src/ekg2000-format.js soll aus einem unbekannten Bytestrom die Struktur ablesen.
 * Bei einem UNBEKANNTEN Strom kann niemand nachpruefen, ob die Antwort stimmt - das ist die
 * Lage am Praxis-PC. Also wird sie hier an Stroemen geprueft, deren Aufbau BEKANNT ist:
 * gebaute Rahmen mit gesetzter Satzlaenge, echtes Rauschen, zu wenig Daten, Text.
 *
 * Erst wenn sie die bekannten Faelle richtig beantwortet - und bei den unklaren ehrlich
 * schweigt -, darf man ihr bei einem echten Geraet glauben. Genau das ist die Regel dieses
 * Projekts: sie misst und schweigt im Zweifel.
 *
 * Start: node tools/ekg2000-format-test.js
 */
const F = require('../bridge/src/ekg2000-format.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

/* Ein Pseudozufall mit fester Saat: derselbe Test muss jedes Mal dasselbe pruefen.
 * Math.random() waere hier eine Fehlerquelle mit Zufallszuender. */
let saat = 12345;
function zufall() { saat = (saat * 1103515245 + 12345) & 0x7fffffff; return saat / 0x7fffffff; }

/*
 * Ein NACHGEBILDETER Geraetestrom: Startbyte, Zaehler, sechs Kanaele zu 16 Bit.
 * Die Kurvenform ist bewusst EKG-aehnlich (ruhige Grundlinie, schmale Spitze) - ein
 * Sinus haette eine Periodizitaet, die die Satzlaengensuche zusaetzlich stuetzen wuerde,
 * und das waere geschummelt.
 */
function baueStrom(saetze, satzlaenge, kanaele) {
  const buf = Buffer.alloc(saetze * satzlaenge);
  for (let s = 0; s < saetze; s++) {
    const o = s * satzlaenge;
    buf[o] = 0xa5;                      /* Startbyte, immer gleich */
    buf[o + 1] = s & 0xff;              /* Zaehler */
    for (let k = 0; k < kanaele; k++) {
      const phase = (s % 250) / 250;
      let v = 0;
      if (phase > 0.30 && phase < 0.34) v = 900 * Math.sin((phase - 0.30) / 0.04 * Math.PI);
      else v = 40 * Math.sin(phase * 6.283) + (zufall() - 0.5) * 25;
      const w = Math.max(0, Math.min(65535, Math.round(2048 + v + k * 7)));
      buf[o + 2 + k * 2] = w & 0xff;
      buf[o + 3 + k * 2] = (w >> 8) & 0xff;
    }
  }
  return buf;
}

console.log('\nVetStation - Formaterkennung EKG 2000\n');

/* ================================================================================
 * 1. Ein Strom mit BEKANNTER Satzlaenge muss wiedergefunden werden
 * ============================================================================== */
block('1. bekannte Satzlaenge wiederfinden');
[[14, 6], [10, 4], [26, 12], [8, 3]].forEach(([len, kan]) => {
  const buf = baueStrom(600, len, kan);
  const d = F.deute(buf);
  pruef('Satzlaenge ' + len + ' (' + kan + ' Kanaele) wird erkannt',
    d.satz && d.satz.sicher && d.satz.laenge === len,
    d.satz ? ('gefunden ' + d.satz.laenge + ', sicher=' + d.satz.sicher) : d.urteil);
});

/* DIE VIELFACHEN-FALLE. Bei Satzlaenge 8 schlaegt die Autokorrelation auch bei 16, 24, 32
 * aus - es ist derselbe Rhythmus. Wer das Vielfache nimmt, zerschneidet den Strom an der
 * falschen Stelle und bekommt zwei Kanaele in ein Feld. */
{
  const buf = baueStrom(800, 8, 3);
  const d = F.deute(buf);
  pruef('bei Vielfachen wird die KLEINSTE Periode genommen',
    d.satz && d.satz.laenge === 8, d.satz ? String(d.satz.laenge) : '-');
}

/* ================================================================================
 * 2. Wo NICHTS zu holen ist, wird auch nichts behauptet
 * ============================================================================== */
block('2. ehrliches Schweigen');
{
  /* Falsche Baudrate: ein UART liefert dann nahezu gleichverteilten Muell. */
  const muell = Buffer.alloc(4000);
  for (let i = 0; i < muell.length; i++) muell[i] = Math.floor(zufall() * 256);
  const d = F.deute(muell);
  pruef('gleichverteiltes Rauschen gilt NICHT als sinnvoll', d.sinnvoll === false,
    'Entropie ' + d.entropie);
  pruef('und die Begruendung nennt die Baudrate', /Baudrate/.test(d.urteil), d.urteil);
  pruef('es wird KEINE Satzlaenge behauptet', !d.satz || !d.satz.sicher);
}
{
  const d = F.deute(Buffer.alloc(0));
  pruef('leerer Strom: "es kam gar nichts an"', /gar nichts/.test(d.urteil), d.urteil);
}
{
  const d = F.deute(baueStrom(6, 14, 6));          /* 84 Byte - viel zu wenig */
  pruef('zu wenig Daten wird als solches gemeldet', /Zu wenig/.test(d.urteil), d.urteil);
  pruef('und es wird nichts behauptet', d.sinnvoll === false);
}
{
  /* Text (etwa ein Geraet, das Zeilen schickt): keine feste Satzlaenge, aber auch kein Muell. */
  let t = '';
  for (let i = 0; i < 400; i++) t += 'HR=' + (60 + (i % 40)) + ';SPO2=' + (95 + (i % 5)) + '\r\n';
  const d = F.deute(Buffer.from(t, 'latin1'));
  pruef('Textstrom gilt als sinnvoll (nicht als Muell)', d.sinnvoll === true, 'Entropie ' + d.entropie);
}

/* ================================================================================
 * 3. Die Felder im Satz richtig einordnen
 * ============================================================================== */
block('3. Kopf, Zaehler und Messwerte auseinanderhalten');
{
  const buf = baueStrom(700, 14, 6);
  const d = F.deute(buf);
  const f = d.felder || [];
  pruef('Byte 0 wird als gleichbleibend erkannt (Startbyte)',
    f[0] && f[0].konstanz > 0.95 && f[0].wert === 0xa5,
    f[0] ? ('Konstanz ' + f[0].konstanz.toFixed(2) + ', Wert 0x' + f[0].wert.toString(16)) : '-');
  pruef('Byte 1 wird als Zaehler erkannt', f[1] && f[1].zaehler === true);
  /* Die Messwertbytes duerfen NICHT als konstant durchgehen - sonst haelt der Adapter
   * einen Kanal fuer eine Kennung und zeichnet eine flache Linie. */
  const niedrig = f.slice(2).filter((x) => x && x.konstanz > 0.9).length;
  pruef('die Messwertbytes gelten nicht als konstant', niedrig <= 2, niedrig + ' von 12');
  console.log('    Urteil: ' + d.urteil.slice(0, 150));
}

/* ================================================================================
 * 4. Die Entropie trennt Nutzdaten von Muell zuverlaessig
 * ============================================================================== */
block('4. Entropie als Vorfilter');
{
  const echt = F.entropie(baueStrom(600, 14, 6));
  const muell = Buffer.alloc(4000);
  for (let i = 0; i < muell.length; i++) muell[i] = Math.floor(zufall() * 256);
  const rausch = F.entropie(muell);
  console.log('    Geraetestrom ' + echt.toFixed(2) + ' Bit/Byte, Rauschen ' + rausch.toFixed(2));
  pruef('Rauschen liegt nahe 8 Bit/Byte', rausch > 7.8, rausch.toFixed(2));
  pruef('ein Geraetestrom liegt deutlich darunter', echt < 7.5, echt.toFixed(2));
  pruef('der Abstand ist gross genug fuer eine Entscheidung', (rausch - echt) > 0.5,
    (rausch - echt).toFixed(2) + ' Bit');
}

/* ================================================================================
 * 5. Die Liste der Baudraten
 * ============================================================================== */
block('5. Baudraten');
pruef('die ueblichen Raten sind dabei',
  [9600, 19200, 38400, 57600, 115200].every((b) => F.BAUDRATEN.indexOf(b) >= 0));
pruef('die Liste bleibt kurz (jede Rate kostet Sekunden am Geraet)', F.BAUDRATEN.length <= 10,
  String(F.BAUDRATEN.length));

console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
