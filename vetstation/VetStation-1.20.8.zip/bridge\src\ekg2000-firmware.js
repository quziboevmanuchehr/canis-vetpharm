'use strict';
/*
 * ekg2000-firmware.js — die Geraetefirmware auf DIESEM PC finden, pruefen und bereitstellen.
 *
 * WARUM ES DIESE DATEI GIBT (16.08.2026):
 * Das EKG 2000 ist ohne Firmware stumm. Es holt sein Programm bei JEDEM Einschalten vom PC
 * (LoadPrgToCDS). Ohne diesen Schritt kommt kein einziger Messwert - egal wie gut das
 * Rahmenformat bekannt ist.
 *
 * WARUM DIE DATEIEN NICHT IM PAKET LIEGEN, obwohl das bequemer waere:
 * Es ist die Firmware von Grimed, nicht unsere. VetStation wird ueber GitHub Pages OEFFENTLICH
 * verteilt; die Dateien dort mitzuliefern hiesse, fremde Software zu verbreiten. Dieselbe
 * Grenze wurde am 15.08.2026 schon einmal gezogen, als die Buchauszuege aus dem Paket
 * genommen wurden. Der Nutzer hat die Dateien rechtmaessig - auf SEINEM Rechner duerfen sie
 * benutzt werden, und genau das tut dieses Modul.
 *
 * WO GESUCHT WIRD, in dieser Reihenfolge:
 *   1. <Station>\firmware\ekg2000\        (der vorgesehene Ort; INSTALLIEREN legt ihn an)
 *   2. die Installation des Originalprogramms (Registry-Pfad und die ueblichen Orte)
 *   3. ein in der Konfiguration angegebener Ordner (cfg.firmwareOrdner)
 * Gefunden wird nie geraten: eine Datei gilt nur dann als Firmware, wenn Groesse UND
 * Herstellerkennung stimmen (siehe pruefe()).
 */
const fs = require('fs');
const path = require('path');

/* Die fuenf Dateien aus dem Herstellerarchiv, mit ihrer echten Groesse. Die Groesse ist hier
 * kein Schoenheitspreis, sondern eine Pruefung: eine halb kopierte Datei wuerde sonst in das
 * Geraet geschrieben, und ein Mikrocontroller mit halbem Programm ist schwerer zu erkennen
 * als einer ohne. */
const BEKANNT = {
  'EKG_V.BIN':     { bytes: 569, zweck: 'Ruhe-EKG, aeltere Fassung' },
  'EKG_V_C1.BIN':  { bytes: 590, zweck: 'Ruhe-EKG, Bauart 1 (Kennung 0x20)' },
  'EKG_VC11.BIN':  { bytes: 666, zweck: 'Ruhe-EKG, Bauart 2 (Kennung 0x21/0x22)' },
  'MONITOR.BIN':   { bytes: 737, zweck: 'Monitorbetrieb, Bauart 1' },
  'MONITOR2.BIN':  { bytes: 737, zweck: 'Monitorbetrieb, Bauart 2' },
};

/* Jede Firmwaredatei traegt am Ende die Herstellerkennung. Sie ist der zweite, unabhaengige
 * Beleg dafuer, dass wirklich eine Firmware vorliegt und nicht irgendeine gleich grosse Datei. */
const KENNUNG = 'GRIMED';

function pruefe(datei) {
  const name = path.basename(datei).toUpperCase();
  const soll = BEKANNT[name];
  if (!soll) return { ok: false, grund: 'kein bekannter Firmwarename' };
  let b;
  try { b = fs.readFileSync(datei); } catch (e) { return { ok: false, grund: 'nicht lesbar: ' + e.message }; }
  if (b.length !== soll.bytes) {
    return { ok: false, grund: 'Groesse ' + b.length + ' statt ' + soll.bytes + ' Byte' };
  }
  if (b.toString('latin1').indexOf(KENNUNG) < 0) {
    return { ok: false, grund: 'die Herstellerkennung "' + KENNUNG + '" fehlt' };
  }
  return { ok: true, name: name, bytes: b, zweck: soll.zweck };
}

/* Die ueblichen Orte. Bewusst kurz: eine Suche ueber die ganze Platte dauert Minuten und
 * findet am Ende doch nur diese. */
function ortsliste(root, extra) {
  const l = [];
  if (extra) l.push(extra);
  if (root) l.push(path.join(root, 'firmware', 'ekg2000'));
  ['C:\\EKG_2000', 'C:\\Program Files (x86)\\EKG_2000', 'C:\\Program Files\\EKG_2000',
    'C:\\EKG2000', 'C:\\Grimed'].forEach((p) => l.push(p));
  return l;
}

/*
 * suche(root, extra) — was ist da, und was fehlt? Gibt IMMER beides zurueck.
 * Ein blosses "nicht gefunden" waere hier besonders unfreundlich: der Anwender hat die
 * Dateien ja, er weiss nur nicht, wohin damit.
 */
function suche(root, extra) {
  const gefunden = {};
  const orte = ortsliste(root, extra);
  const geprueft = [];
  orte.forEach((ort) => {
    let eintraege = [];
    try { eintraege = fs.readdirSync(ort); } catch (_) { return; }
    geprueft.push(ort);
    eintraege.forEach((e) => {
      const gross = e.toUpperCase();
      if (!BEKANNT[gross] || gefunden[gross]) return;
      const p = pruefe(path.join(ort, e));
      if (p.ok) gefunden[gross] = { pfad: path.join(ort, e), bytes: p.bytes, zweck: p.zweck };
    });
  });
  const fehlend = Object.keys(BEKANNT).filter((k) => !gefunden[k]);
  return {
    gefunden: gefunden,
    fehlend: fehlend,
    durchsucht: geprueft,
    ziel: root ? path.join(root, 'firmware', 'ekg2000') : null,
  };
}

/*
 * fuerBauart(fund, bauart, betrieb) — welche Datei gehoert zu diesem Geraet?
 * bauart 1 oder 2 (aus dem Antwortbyte 0x20 bzw. 0x21/0x22), betrieb 'ruhe' oder 'monitor'.
 * Gibt null zurueck, wenn die passende Datei fehlt - und NICHT etwa die andere: eine
 * Firmware der falschen Bauart in ein Geraet zu schreiben ist der eine Fehler, der es
 * wirklich beschaedigen koennte.
 */
function fuerBauart(fund, bauart, betrieb) {
  const tabelle = {
    '1-ruhe': 'EKG_V_C1.BIN', '2-ruhe': 'EKG_VC11.BIN',
    '1-monitor': 'MONITOR.BIN', '2-monitor': 'MONITOR2.BIN',
  };
  const name = tabelle[bauart + '-' + (betrieb === 'monitor' ? 'monitor' : 'ruhe')];
  if (!name) return null;
  const f = fund && fund.gefunden ? fund.gefunden[name] : null;
  return f ? { name: name, pfad: f.pfad, bytes: f.bytes, zweck: f.zweck } : null;
}

/* Der Text, der dem Anwender sagt, was zu tun ist. Steht hier und nicht im Adapter, damit
 * er an allen Stellen gleich lautet. */
function anleitung(fund) {
  return 'Die Firmware des EKG 2000 gehoert dem Hersteller und liegt deshalb NICHT im '
    + 'VetStation-Paket. Sie steckt in Ihrer PC-EKG-Installation bzw. im Installationsarchiv '
    + 'von Eickemeyer (EKG.cab). Kopieren Sie diese fuenf kleinen Dateien (zusammen unter '
    + '4 KB) nach: ' + (fund && fund.ziel ? fund.ziel : '<Station>\\firmware\\ekg2000') + '  —  '
    + Object.keys(BEKANNT).join(', ') + '. '
    + 'Danach laeuft das Geraet beim Anstecken ohne weiteres Zutun.';
}

module.exports = { BEKANNT, KENNUNG, pruefe, suche, fuerBauart, anleitung, ortsliste };
