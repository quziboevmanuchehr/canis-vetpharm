<#
  make-setup-exe.ps1 - Baut dist\VetStation-Setup.exe MIT BORDMITTELN (IExpress).

  WARUM DIESE DATEI EXISTIERT (Befund 2.10, 21.07.2026):
  Die Setup.exe liess sich NUR mit Inno Setup erzeugen. Inno ist auf dem Praxis-PC nicht
  installiert und ohne Internet auch nicht nachinstallierbar - die ausgelieferte Setup.exe war
  damit dauerhaft auf 0.5.2 eingefroren. IExpress (iexpress.exe) steckt in JEDEM Windows.
  Die Inno-Variante (vetstation-setup.iss) bleibt gepflegt und ist weiterhin die schoenere
  Oberflaeche - sie ist nur nicht mehr die einzige Moeglichkeit.

  AUFBAU DES ERGEBNISSES:
  IExpress kann keine Unterordner. Deshalb enthaelt die Setup.exe nur ZWEI Dateien -
  ein Zip des kompletten Pakets und einen Starter, der es entpackt und die Installation aufruft.

  Voraussetzung: vorher installer\make-dist.ps1 ausfuehren (erzeugt dist\VetStation inkl. Node).
  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\make-setup-exe.ps1
#>
param(
  [string]$OutDir = "$PSScriptRoot\..\dist"
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path $PSScriptRoot -Parent

$Stage = Join-Path $OutDir 'VetStation'
$Work = Join-Path $OutDir '_setupbau'
$Ziel = Join-Path $OutDir 'VetStation-Setup.exe'

Write-Host "== VetStation-Setup.exe bauen (IExpress, keine Fremdsoftware) =="

# --- 1) Voraussetzungen ehrlich pruefen --------------------------------------
if (-not (Test-Path $Stage)) {
  throw "ABBRUCH: $Stage fehlt. Bitte zuerst ausfuehren: powershell -ExecutionPolicy Bypass -File installer\make-dist.ps1"
}
if (-not (Test-Path (Join-Path $Stage 'node\node.exe'))) {
  throw "ABBRUCH: $Stage\node\node.exe fehlt. Ohne portables Node koennte der Ziel-PC VetStation nicht starten."
}
$iexpress = Join-Path $env:WINDIR 'System32\iexpress.exe'
if (-not (Test-Path $iexpress)) { $iexpress = Join-Path $env:WINDIR 'SysWOW64\iexpress.exe' }
if (-not (Test-Path $iexpress)) { throw "ABBRUCH: iexpress.exe nicht gefunden - ungewoehnlich, es gehoert zu Windows." }

# Version aus der EINEN Quelle der Wahrheit (Wurzel-package.json).
$pkg = Get-Content (Join-Path $Root 'package.json') -Raw | ConvertFrom-Json
$Version = $pkg.version
Write-Host "Version laut package.json: $Version"

# --- 2) Arbeitsordner: Zip + Starter -----------------------------------------
if (Test-Path $Work) { Remove-Item $Work -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Work | Out-Null

$zip = Join-Path $Work 'VetStation-Paket.zip'

<#
  BETRIEBS- UND SCHLUESSELDATEN DUERFEN NICHT IN DIE SETUP.EXE (Befund 17.08.2026).

  Bis hierher wurde $Stage UNGEFILTERT gepackt (Compress-Archive -Path $Stage). Auf dem
  Entwickler-PC ist dist\VetStation aber nicht nur das Bauergebnis, sondern AUCH die laufende
  Station: sie schreibt dorthin data\station-id.json, data\cloud-auth.json und data\diag.log.

  GEMESSEN AM 17.08.2026, damit der naechste Leser das nicht fuer Vorsicht haelt:
    dist\VetStation\data\station-id.json   495 Byte, Feld "priv" mit 64 Zeichen
                                           -> der PRIVATE Stationsschluessel
    dist\VetStation\data\diag.log         3641 Byte
  Das heutige dist\VetStation-Setup.zip (288 Eintraege) ist sauber - aber nur aus Zufall: es
  wurde 12:06 gebaut, die Station schrieb station-id.json 12:12. Sechs Minuten. Der naechste
  Setup-Bau nach einem Stationslauf haette den Schluessel verteilt.

  WARUM EINE GEFILTERTE KOPIE UND NICHT ETWAS BEQUEMERES:
    - NICHT data\ vor dem Zippen wegschieben und danach zurueck. Bricht der Bau dazwischen ab,
      hat die laufende Station ihre station-id.json verloren. Laut bridge/src/stationsid.js
      UEBERLEBT diese Datei bewusst jedes Update - sie IST die Kennung der Station. Eine
      Kopie ist billiger als dieses Risiko.
    - Der Zip-Prefix "VetStation\" ist TRAGEND: SETUP-START.cmd sucht
      %ZIEL%\VetStation\installer\Install-VetStation.ps1. Deshalb wird in einen Ordner
      _rein\VetStation kopiert und DIESER gepackt, nicht sein Inhalt.

  KOPIERT WIRD MIT ROBOCOPY UND ABSOLUTEN AUSSCHLUSSPFADEN - genau die Form, die
  make-dist.ps1 ein paar Zeilen weiter schon benutzt und dort als funktionierend belegt ist
  (/XD mit Join-Path, /XF mit Dateinamen). Die dort vermerkte Falle war /XD mit einem
  RELATIVEN Pfad: das schloss node\ nicht aus und fiel nur auf, weil zufaellig eine
  Groessenwarnung griff. Deshalb hier ausschliesslich Join-Path-Absolutpfade.
  'devices.json' schliesst NICHT devices.example.json aus - die Namen sind verschieden, und
  die Beispieldatei MUSS mit, sonst startet eine neue Installation ohne Konfiguration.

  UND DANACH WIRD GEGENGEPRUEFT, MIT throw. Eine Absicherung, die den Fehlerfall nur
  kommentiert, ist keine - dieselbe Bauform wie der Firmware-Ausschluss in make-dist.ps1.
#>
$Rein = Join-Path $Work '_rein'
$ReinStage = Join-Path $Rein 'VetStation'
New-Item -ItemType Directory -Force -Path $ReinStage | Out-Null
Write-Host "Kopiere $Stage ohne Betriebsdaten ..."
robocopy $Stage $ReinStage /E `
  /XD (Join-Path $Stage 'data') (Join-Path $Stage 'bridge\data') `
  /XF 'devices.json' '*.log' /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Kopieren fuer das Setup fehlgeschlagen (robocopy-Code $LASTEXITCODE)." }

Write-Host "Packe $ReinStage ..."
Compress-Archive -Path $ReinStage -DestinationPath $zip -CompressionLevel Optimal

# GEGENPROBE IM ERGEBNIS. Geprueft wird das ZIP, nicht der Ordner: nur das Zip wandert weiter.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$pruef = [IO.Compression.ZipFile]::OpenRead($zip)
try {
  $boese = @()
  foreach ($e in $pruef.Entries) {
    $n = $e.FullName.Replace('\', '/')
    if ($n -match '(^|/)data/' -or $n -match '/station-id\.json$' -or $n -match '/cloud-auth\.json$' `
        -or $n -match '/protokoll\.json$' -or $n -match '/patient-akte\.json$' `
        -or $n -match '/devices\.json$' -or $n -match '\.log$') { $boese += $n }
  }
  $anzahl = $pruef.Entries.Count
} finally { $pruef.Dispose() }
if ($boese.Count -gt 0) {
  throw ("ABBRUCH: im Setup-Paket liegen Betriebs- oder Schluesseldaten: " + ($boese -join ', ') +
    " - der Filter oben hat sie nicht erwischt. Die Setup.exe wurde NICHT gebaut.")
}
Write-Host "Gegenprobe: $anzahl Eintraege, keine Betriebs- oder Schluesseldaten."
Remove-Item -LiteralPath $Rein -Recurse -Force -ErrorAction SilentlyContinue

$mb = [math]::Round((Get-Item $zip).Length / 1MB, 1)
Write-Host "Paket: $mb MB"

# Der Starter laeuft IN der entpackten IExpress-Umgebung. Er entpackt das Zip an eine STABILE
# Stelle (ProgramData) - IExpress raeumt seinen eigenen Temp-Ordner sonst weg, waehrend die
# erhoehte Installation noch laeuft.
$starter = @"
@echo off
title VetStation $Version - Installation
echo.
echo   VetStation $Version wird installiert.
echo.
set ZIEL=%ProgramData%\VetStation-Install
if exist "%ZIEL%" rmdir /s /q "%ZIEL%"
echo   Entpacke Programmdateien ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%~dp0VetStation-Paket.zip' -DestinationPath '%ZIEL%' -Force"
if not exist "%ZIEL%\VetStation\installer\Install-VetStation.ps1" goto fehler
echo   Starte Einrichtung. Bitte die Nachfrage von Windows mit JA bestaetigen.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%ZIEL%\VetStation\installer\Install-VetStation.ps1"
echo.
echo   Fertig. Dieses Fenster kann geschlossen werden.
pause
exit /b 0
:fehler
echo.
echo   *** FEHLER: Die Programmdateien liessen sich nicht entpacken. ***
echo   Bitte pruefen, ob genug Platz auf Laufwerk C: frei ist.
echo.
pause
exit /b 1
"@
Set-Content -Encoding ASCII -Path (Join-Path $Work 'SETUP-START.cmd') -Value $starter

# --- 3) SED-Steuerdatei fuer IExpress ----------------------------------------
# TargetName MUSS ein vollstaendiger Pfad sein, sonst legt IExpress die Datei irgendwo ab.
$sedPath = Join-Path $Work 'vetstation.sed'
$workAbs = (Resolve-Path $Work).Path
$zielAbs = [System.IO.Path]::GetFullPath($Ziel)
$sed = @"
[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=1
HideExtractAnimation=1
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=%InstallPrompt%
DisplayLicense=%DisplayLicense%
FinishMessage=%FinishMessage%
TargetName=%TargetName%
FriendlyName=%FriendlyName%
AppLaunched=%AppLaunched%
PostInstallCmd=%PostInstallCmd%
AdminQuietInstCmd=%AdminQuietInstCmd%
UserQuietInstCmd=%UserQuietInstCmd%
SourceFiles=SourceFiles
[Strings]
InstallPrompt=
DisplayLicense=
FinishMessage=
TargetName=$zielAbs
FriendlyName=VetStation $Version - Setup
AppLaunched=cmd.exe /c SETUP-START.cmd
PostInstallCmd=<None>
AdminQuietInstCmd=
UserQuietInstCmd=
FILE0="VetStation-Paket.zip"
FILE1="SETUP-START.cmd"
[SourceFiles]
SourceFiles0=$workAbs\
[SourceFiles0]
%FILE0%=
%FILE1%=
"@
Set-Content -Encoding ASCII -Path $sedPath -Value $sed

# --- 4) Bauen ----------------------------------------------------------------
if (Test-Path $Ziel) { Remove-Item $Ziel -Force }
Write-Host "Rufe IExpress auf (das dauert je nach Paketgroesse ein bis zwei Minuten) ..."

# ZWEI STOLPERSTEINE, BEIDE AM 21.07.2026 GEMESSEN - bitte nichts davon "aufhuebschen":
#
#  1. KEIN "/Q".  Mit "/N /Q" bricht iexpress.exe wortlos mit Exitcode 1 ab und erzeugt gar
#     nichts. Mit "/N" allein laeuft derselbe Aufbau durch.
#  2. Den SED-Pfad NICHT in Anfuehrungszeichen setzen und den Ordner ueber -WorkingDirectory
#     vorgeben. Mit '"...\vetstation.sed"' erkennt IExpress den Pfad NICHT als Auftrag und
#     oeffnet stattdessen den INTERAKTIVEN Assistenten - der Prozess haengt dann ewig
#     (Merkmal: laeuft, aber 0 CPU-Sekunden; MainWindowTitle = "IExpress Wizard").
#     Ueber -WorkingDirectory genuegt der blosse Dateiname, damit sind auch Ordner mit
#     Leerzeichen kein Problem.
function Baue([string[]]$argListe) {
  $proc = Start-Process -FilePath $iexpress -ArgumentList $argListe -WorkingDirectory $workAbs -PassThru
  # Notbremse: haengt IExpress doch im Assistenten, wird hier abgeraeumt statt endlos zu warten.
  if (-not $proc.WaitForExit(15 * 60 * 1000)) {
    try { $proc.Kill() } catch { }
    Write-Warning "IExpress hat nach 15 Minuten nicht geantwortet und wurde beendet."
    return $null
  }
  return $proc.ExitCode
}

$code = Baue @('/N', 'vetstation.sed')
if (-not (Test-Path $Ziel)) {
  Write-Warning "IExpress lieferte nichts (Exitcode $code) - zweiter Versuch mit /N /Q ..."
  $code = Baue @('/N', '/Q', 'vetstation.sed')
}
if (-not (Test-Path $Ziel)) {
  throw "ABBRUCH: IExpress hat keine Setup.exe erzeugt (Exitcode $code). SED-Datei zum Nachsehen: $sedPath"
}

$setupMb = [math]::Round((Get-Item $Ziel).Length / 1MB, 1)
Write-Host ""
Write-Host "FERTIG:"
Write-Host "  $Ziel  ($setupMb MB, Version $Version)"
Write-Host "  Auf USB-Stick kopieren -> am Ziel-PC DOPPELKLICKEN. Mehr ist nicht noetig."
Write-Host ""
Write-Host "  Aufraeumen (optional):  Remove-Item '$Work' -Recurse -Force"
