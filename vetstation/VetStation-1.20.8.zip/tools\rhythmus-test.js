'use strict';
/*
 * rhythmus-test.js — Selbsttest der erweiterten Rhythmusdeutung (ui/shared/ekg-analyse.js).
 *
 * WARUM ES DIESEN TEST GIBT (10.08.2026):
 * Bis zu diesem Tag kannte rhythmus() fuenf Ergebnisse: regelmaessig, langsam, schnell,
 * vorzeitige Schlaege, ventrikulaere Tachykardie. Alles andere - Vorhofflimmern, AV-Block II,
 * Sinusarrest, Bigeminus, Salve - stand ausdruecklich als "nicht entscheidbar" im Text,
 * OBWOHL die dafuer noetige P-Wellen-Auswertung seit dem 08.08.2026 lief. Sie lief nur an der
 * falschen Stelle: rhythmus() wurde VOR ihr aufgerufen und bekam ihr Ergebnis nie zu sehen.
 *
 * Jede dieser Aussagen hat klinische Folgen. Ein erfundenes Vorhofflimmern fuehrt zu einer
 * Behandlung, ein uebersehener Mobitz II zu einer verpassten. Dieser Test prueft deshalb
 * BEIDE Richtungen: dass jedes Muster erkannt wird, wenn es da ist, UND dass ein sauberer
 * Sinusstreifen KEINES davon ausloest.
 *
 * Die Signale sind synthetisch, damit die Wahrheit bekannt ist. Kein Math.random - ein Test,
 * der bei jedem Lauf etwas anderes sagt, ist keiner.
 *
 * Aufruf:  node tools/rhythmus-test.js
 */
const path = require('path');
const VS = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-analyse.js'));

let gruen = 0, rot = 0;
function pruef(name, bed, zusatz) {
  if (bed) { gruen++; console.log('  ✓ ' + name); }
  else { rot++; console.log('  ✗ ' + name + (zusatz ? '   -> ' + zusatz : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

function rnd(seed) {
  let s = seed >>> 0;
  return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296 - 0.5; };
}
/* Erhoehter Kosinus mit EXAKTEM Traeger - im Gegensatz zur Gauss-Kurve hat er einen
 * definierten Anfang und ein definiertes Ende. Begruendung siehe p-welle-test.js. */
function welle(dt, t0, dauer) {
  if (dt < t0 || dt > t0 + dauer) return 0;
  return 0.5 * (1 - Math.cos(2 * Math.PI * (dt - t0) / dauer));
}

const HZ = 250;                 // die Rate, mit der das Modul heute aufzeichnet

/*
 * Baut einen Streifen aus einer LISTE VON SCHLAEGEN. Jeder Schlag sagt selbst, wie weit er
 * vom vorigen entfernt ist, ob er eine P-Welle hat, wie breit und wie hoch er ist.
 * Damit lassen sich alle Muster bauen, um die es geht - ohne fuer jedes einen eigenen
 * Generator zu schreiben.
 *
 *   schlaege: [{ rr, p (bool), breit (bool), amp (Faktor), tNeg (bool) }]
 *   pOhneQrs: [Zeitpunkte in Sekunden] - blockierte P-Wellen ohne folgenden Kammerkomplex
 *
 * Rueckgabe in Mikrovolt (skala 1, einheit uV) - so, wie ein Geraet liefert.
 */
function baueStreifen(o) {
  const zufall = rnd(o.seed == null ? 7 : o.seed);
  const rauschen = o.rauschen == null ? 6 : o.rauschen;      // uV
  const rAmp = 1000;                                         // 1 mV R-Zacke
  const pAmp = 220, pDauer = 0.038, pq = 0.110;
  const zeiten = [];
  let t = 0.8;
  for (const s of o.schlaege) { t += s.rr; zeiten.push(t); }
  const sek = t + 0.8;
  const n = Math.round(HZ * sek);
  const werte = new Array(n).fill(0);

  function trage(mitte, fn, von, bis) {
    const a = Math.max(0, Math.round((mitte + von) * HZ));
    const b = Math.min(n - 1, Math.round((mitte + bis) * HZ));
    for (let i = a; i <= b; i++) werte[i] += fn(i / HZ - mitte);
  }

  o.schlaege.forEach((s, k) => {
    const tR = zeiten[k];
    const amp = rAmp * (s.amp == null ? 1 : s.amp);
    const qb = s.breit ? 0.100 : 0.048;             // QRS-Dauer
    if (s.p !== false) {
      trage(tR, (dt) => pAmp * welle(dt, -pq, pDauer), -pq - 0.01, -pq + pDauer + 0.01);
    }
    trage(tR, (dt) => amp * welle(dt, -qb / 2, qb) - amp * 0.22 * welle(dt, qb / 2, qb * 0.8),
      -qb, qb * 1.5);
    const tVor = s.breit ? 0.075 : 0.090, tD = s.breit ? 0.140 : 0.120;
    const tAmp = (s.tNeg ? -1 : 1) * amp * 0.22;
    trage(tR, (dt) => tAmp * welle(dt, tVor, tD), tVor - 0.01, tVor + tD + 0.01);
  });
  // Blockierte P-Wellen: Vorhof schlaegt, Kammer folgt nicht.
  (o.pOhneQrs || []).forEach((tp) => {
    trage(tp, (dt) => pAmp * welle(dt, 0, pDauer), -0.01, pDauer + 0.01);
  });
  for (let i = 0; i < n; i++) werte[i] += zufall() * rauschen;
  return { samples: werte, hz: HZ, skala: 1, zeiten: zeiten };
}

function messe(streifen, art, band) {
  return VS.analysiere({ samples: streifen.samples, hz: streifen.hz, skala: 1 },
    { art: art || 'hund', einheit: 'uV', bandHr: band || [70, 160] });
}

/* Ein Muster von Schlaegen wiederholen. */
function mal(n, f) { const a = []; for (let i = 0; i < n; i++) a.push(f(i)); return a; }

// ===========================================================================
block('1. Sauberer Sinusstreifen — und was er NICHT ausloesen darf');
{
  const s = baueStreifen({ schlaege: mal(20, () => ({ rr: 0.60, p: true })) });
  const e = messe(s);
  pruef('Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('Frequenz stimmt (100/min)', Math.abs(e.hf - 100) <= 3, 'hf=' + e.hf);
  pruef('P-Welle wird gefunden', !!(e.p && e.p.vorhanden), JSON.stringify(e.p && e.p.warum));
  pruef('daraus wird ein SINUSRHYTHMUS (nicht nur "regelmaessig")',
    e.rhythmus.id === 'sinus' && /Sinusrhythmus/.test(e.rhythmus.name), e.rhythmus.name);
  ['vhf', 'avblock2', 'sinusarrest', 'bigeminus', 'trigeminus', 'couplet', 'vtach', 'aivr', 'pause']
    .forEach((id) => pruef('kein Fehlbefund "' + id + '"', e.rhythmus.id !== id, e.rhythmus.name));
  pruef('kein elektrischer Alternans im gleichmaessigen Streifen',
    !(e.alternans && e.alternans.vorhanden), JSON.stringify(e.alternans));
  pruef('keine formfremden Schlaege', !e.muster.messbar || e.muster.fremd === 0,
    JSON.stringify(e.muster));
}

// ===========================================================================
block('2. Bigeminus — jeder zweite Schlag ventrikulaer');
{
  /* Kopplungsintervall 40 % des Grundabstands, danach kompensatorische Pause. */
  const schlaege = [];
  for (let i = 0; i < 10; i++) {
    schlaege.push({ rr: 0.60, p: true });
    schlaege.push({ rr: 0.26, p: false, breit: true, amp: 1.35, tNeg: true });
  }
  const e = messe(baueStreifen({ schlaege: schlaege }));
  pruef('Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('die fremden Schlaege werden als solche erkannt',
    e.muster.messbar && e.muster.fremd >= 6, JSON.stringify(e.muster));
  pruef('ihr Muster ist der Zweiertakt', e.muster.bigeminusLaeufe >= 3,
    'bigeminusLaeufe=' + e.muster.bigeminusLaeufe);
  pruef('die fremden Schlaege sind BREIT gemessen',
    e.muster.qrsFremdMs != null && e.muster.qrsFremdMs > e.muster.qrsNormalMs,
    'fremd=' + e.muster.qrsFremdMs + ' normal=' + e.muster.qrsNormalMs);
  pruef('Befund: Bigeminus', e.rhythmus.id === 'bigeminus', e.rhythmus.id + ' / ' + e.rhythmus.name);
  pruef('der Text nennt den Puls am Tier', /Puls am Tier/.test(e.rhythmus.begruendung));
}

// ===========================================================================
block('3. Salve — vier breite Komplexe hintereinander (ventrikulaere Tachykardie)');
{
  const schlaege = mal(8, () => ({ rr: 0.60, p: true }));
  for (let i = 0; i < 5; i++) schlaege.push({ rr: 0.22, p: false, breit: true, amp: 1.3, tNeg: true });
  schlaege.push(...mal(8, () => ({ rr: 0.60, p: true })));
  const e = messe(baueStreifen({ schlaege: schlaege }));
  pruef('Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('der laengste Lauf fremder Schlaege ist >= 4',
    e.muster.messbar && e.muster.laengsterLauf >= 4, JSON.stringify(e.muster));
  pruef('Befund: ventrikulaere Tachykardie', e.rhythmus.id === 'vtach', e.rhythmus.id + ' / ' + e.rhythmus.name);
  pruef('der Text sagt, dass "anhaltend" NICHT entscheidbar ist',
    /ANHALTEND|anhaltend/.test(e.rhythmus.begruendung), e.rhythmus.begruendung);
  /* DIE ENTSCHEIDENDE GEGENPROBE: der Median der QRS-Breite ist in diesem Streifen SCHMAL
   * (5 breite gegen 16 schmale Schlaege). Wer die Salve am Median beurteilt, uebersieht sie. */
  pruef('der Median der QRS-Breite waere hier schmal gewesen (Gegenprobe)',
    e.qrsBreiteMs != null && e.qrsBreiteMs <= VS.R_ART.hund.qrsBreit,
    'Median ' + e.qrsBreiteMs + ' ms');
}

// ===========================================================================
block('4. Vorhofflimmern — unregelmaessig, keine P, schmaler Komplex');
{
  const z = rnd(99);
  const schlaege = mal(24, () => ({ rr: 0.30 + Math.abs(z()) * 0.75, p: false }));
  const e = messe(baueStreifen({ schlaege: schlaege, seed: 5 }));
  pruef('Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('keine P-Welle abgrenzbar', e.p.messbar === false && e.p.anteil < 40,
    JSON.stringify({ messbar: e.p.messbar, anteil: e.p.anteil }));
  pruef('Befund: Vorhofflimmern moeglich', e.rhythmus.id === 'vhf', e.rhythmus.id + ' / ' + e.rhythmus.name);
  pruef('der Text nennt alle drei Merkmale',
    /Abstand ein anderer|Spanne/.test(e.rhythmus.begruendung) && /P-Welle/.test(e.rhythmus.begruendung) &&
    /schmal/.test(e.rhythmus.begruendung), e.rhythmus.begruendung);
  pruef('und verlangt zur Sicherung mehr als diesen Streifen',
    /längeren Streifen|Auskultation|Pulsdefizit/.test(e.rhythmus.begruendung));
}
{
  /* GEGENPROBE 1: dieselbe Unregelmaessigkeit MIT P-Wellen ist KEIN Vorhofflimmern.
   * Genau das sagen die Werke ausdruecklich ("Sind P-Wellen zu erkennen, handelt es sich
   * nicht um Vorhofflimmern"). */
  const z = rnd(99);
  const schlaege = mal(24, () => ({ rr: 0.30 + Math.abs(z()) * 0.75, p: true }));
  const e = messe(baueStreifen({ schlaege: schlaege, seed: 5 }));
  pruef('mit erhaltenen P-Wellen KEIN Vorhofflimmern', e.rhythmus.id !== 'vhf',
    e.rhythmus.id + ' / ' + e.rhythmus.name);
}
{
  /* GEGENPROBE 2 — DIE WICHTIGSTE. Ein EINZELNER vorzeitiger Schlag mit kompensatorischer
   * Pause treibt die Spannweite der Abstaende ueber jede Schwelle. Der erste Entwurf machte
   * daraus ein "Vorhofflimmern moeglich"; gefunden hat das der Selbsttest der Extrasystole,
   * der seit dem 22.07.2026 unveraendert im Baum liegt. Deshalb steht die Probe jetzt auch
   * hier, wo die Regel wohnt: Unregelmaessigkeit heisst DURCHGEHEND, nicht einmal. */
  const schlaege = [];
  for (let i = 0; i < 14; i++) {
    if (i === 5) { schlaege.push({ rr: 0.40, p: false, breit: false }); schlaege.push({ rr: 0.80, p: true }); }
    else schlaege.push({ rr: 0.60, p: true });
  }
  const e = messe(baueStreifen({ schlaege: schlaege }));
  pruef('EIN vorzeitiger Schlag ist KEIN Vorhofflimmern', e.rhythmus.id !== 'vhf',
    e.rhythmus.id + ' / ' + e.rhythmus.name);
  pruef('er wird als vorzeitiger Schlag benannt', e.rhythmus.id === 'ves',
    e.rhythmus.id + ' / ' + e.rhythmus.name);
}

// ===========================================================================
block('5. AV-Block II — P-Welle ohne folgenden Kammerkomplex');
{
  /* Vorhof im 500-ms-Takt, jeder vierte Schlag wird nicht uebergeleitet.
   * Die blockierte P liegt dort, wo der ausgefallene QRS 110 ms spaeter gestanden haette. */
  const schlaege = [], pBlock = [];
  let t = 0.8;
  for (let i = 0; i < 16; i++) {
    const ausfall = (i % 4 === 3);
    if (ausfall) { schlaege.push({ rr: 1.00, p: true }); t += 1.00; pBlock.push(t - 0.50 - 0.110); }
    else { schlaege.push({ rr: 0.50, p: true }); t += 0.50; }
  }
  const e = messe(baueStreifen({ schlaege: schlaege, pOhneQrs: pBlock }));
  pruef('Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('die Pause ist etwa doppelt so lang', e.pausen.messbar && e.pausen.verhaeltnis >= 1.8,
    JSON.stringify(e.pausen));
  pruef('in der Pause wird eine P-Welle gefunden',
    e.pausenP.messbar && e.pausenP.pausenMitP > 0, JSON.stringify(e.pausenP));
  pruef('Befund: AV-Block II. Grades', e.rhythmus.id === 'avblock2', e.rhythmus.id + ' / ' + e.rhythmus.name);
  pruef('der Text nennt den PQ-Verlauf als Typunterscheidung',
    /Mobitz|PQ-Zeit/.test(e.rhythmus.begruendung), e.rhythmus.begruendung);
}

// ===========================================================================
block('6. Sinusarrest — Pause OHNE Vorhoftaetigkeit');
{
  const schlaege = [];
  for (let i = 0; i < 16; i++) schlaege.push({ rr: (i % 5 === 4) ? 1.30 : 0.50, p: true });
  const e = messe(baueStreifen({ schlaege: schlaege }));
  pruef('Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('in der Pause ist KEINE P-Welle nachweisbar',
    e.pausenP.messbar && e.pausenP.pausenMitP === 0, JSON.stringify(e.pausenP));
  pruef('Befund: Sinusarrest / SA-Block', e.rhythmus.id === 'sinusarrest',
    e.rhythmus.id + ' / ' + e.rhythmus.name);
  pruef('der Text sagt, dass "nicht nachweisbar" nicht "nicht vorhanden" heisst',
    /nicht nachweisbar.*nicht dasselbe|nicht dasselbe wie/.test(e.rhythmus.begruendung),
    e.rhythmus.begruendung);
}

// ===========================================================================
block('7. Elektrischer Alternans — gleicher Takt, wechselnde Hoehe');
{
  const schlaege = mal(20, (i) => ({ rr: 0.45, p: true, amp: i % 2 ? 0.62 : 1.0 }));
  const e = messe(baueStreifen({ schlaege: schlaege, band: [70, 160] }));
  pruef('Streifen ist auswertbar', e.brauchbar, e.warum || '');
  pruef('Alternans wird erkannt', e.alternans.messbar && e.alternans.vorhanden,
    JSON.stringify(e.alternans));
  pruef('der Hoehenunterschied wird beziffert', e.alternans.unterschied >= 15,
    'unterschied=' + e.alternans.unterschied + ' %');
}
{
  /* GEGENPROBE 1: gleiche Hoehe -> kein Alternans. */
  const e = messe(baueStreifen({ schlaege: mal(20, () => ({ rr: 0.45, p: true })) }));
  pruef('gleich hohe Schlaege ergeben KEINEN Alternans', !e.alternans.vorhanden,
    JSON.stringify(e.alternans));
}
{
  /* GEGENPROBE 2: wechselnde Hoehe bei UNREGELMAESSIGEM Rhythmus wird nicht als Alternans
   * gedeutet - dort schwankt die Hoehe schon wegen der unterschiedlichen Fuellung. */
  const z = rnd(3);
  const e = messe(baueStreifen({
    schlaege: mal(20, (i) => ({ rr: 0.35 + Math.abs(z()) * 0.5, p: true, amp: i % 2 ? 0.6 : 1.0 }))
  }));
  pruef('bei unregelmaessigem Rhythmus wird kein Alternans behauptet',
    !e.alternans.vorhanden, JSON.stringify(e.alternans));
}

// ===========================================================================
block('8. Artabhaengige Breitengrenze — der Katzenfall');
{
  /* Ein Kammerkomplex von 60 ms ist beim Hund normal und bei der KATZE deutlich zu breit.
   * Mit der frueheren festen Grenze von 80 ms galt er in beiden Faellen als schmal. */
  pruef('Hundegrenze liegt bei 70 ms', VS.R_ART.hund.qrsBreit === 70);
  pruef('Katzengrenze liegt darunter', VS.R_ART.katze.qrsBreit < VS.R_ART.hund.qrsBreit,
    'Katze ' + VS.R_ART.katze.qrsBreit);
  pruef('die alte feste Grenze 80 ms haette die Katze durchgehen lassen',
    VS.R_ART.katze.qrsBreit < 80);
  pruef('Pferdegrenze liegt deutlich hoeher (QRS 70-170 ms sind dort normal)',
    VS.R_ART.pferd.qrsBreit > 150, 'Pferd ' + VS.R_ART.pferd.qrsBreit);
  pruef('unbekannte Art faellt auf den Kleintierwert zurueck',
    VS.R_ART.standard.qrsBreit === VS.R_ART.hund.qrsBreit);
}

// ===========================================================================
block('8b. Ein zugeschalteter Filter darf kein Vorhofflimmern erzeugen');
{
  /* Die Fachliteratur ist an dieser Stelle eindeutig: Filter "verkleinern die
   * P-QRS-T-Ausschlaege, sodass kleine P-Wellen unterdrueckt und nicht mehr sichtbar sind".
   * Vorhofflimmern und der idioventrikulaere Rhythmus werden hier ueber das FEHLEN der
   * P-Welle begruendet - ohne Sperre koennte die Anwendung also einen Befund melden, den
   * ihr eigener Filter erzeugt hat. */
  const z = rnd(99);
  const schlaege = mal(24, () => ({ rr: 0.30 + Math.abs(z()) * 0.75, p: false }));
  const s = baueStreifen({ schlaege: schlaege, seed: 5 });
  const ohneFilter = VS.analysiere({ samples: s.samples, hz: s.hz, skala: 1 },
    { art: 'hund', einheit: 'uV', bandHr: [70, 160] });
  const mitFilter = VS.analysiere({ samples: s.samples, hz: s.hz, skala: 1 },
    { art: 'hund', einheit: 'uV', bandHr: [70, 160], filterAktiv: true });
  pruef('ohne Filter wird Vorhofflimmern erwogen', ohneFilter.rhythmus.id === 'vhf',
    ohneFilter.rhythmus.id);
  pruef('MIT Filter wird es NICHT behauptet', mitFilter.rhythmus.id !== 'vhf',
    mitFilter.rhythmus.id + ' / ' + mitFilter.rhythmus.name);
  pruef('die Messung selbst bleibt unveraendert (nur die Deutung schweigt)',
    mitFilter.p.messbar === ohneFilter.p.messbar && mitFilter.hf === ohneFilter.hf);
}

// ===========================================================================
block('8c. Abtastversatz erzeugt KEINE Ektopie');
{
  /* Herzzyklus und Abtasttakt gehen nicht auf: die R-Spitze liegt mal auf, mal zwischen zwei
   * Rasterpunkten. Auf einem schmalen Komplex (Katze) reicht das, um die Kreuzkorrelation
   * unter 0,95 zu druecken - gemessen 11.08.2026 an einem VOLLKOMMEN regelmaessigen
   * Katzenstreifen mit 180/min: 16 von 48 Schlaegen galten als formfremd, und die Auswertung
   * meldete einen TRIGEMINUS. Ein erfundener Rhythmusbefund aus reiner Abtastung.
   * Deshalb wird jeder Schlag vor dem Vergleich in Vierteln eines Abtastwerts ausgerichtet. */
  const schlaege = mal(30, () => ({ rr: 0.3333, p: true }));
  const e = messe(baueStreifen({ schlaege: schlaege, rauschen: 0 }), 'katze', [1, 999]);
  pruef('regelmaessiger Katzenstreifen bleibt regelmaessig', e.rhythmus.id === 'sinus',
    e.rhythmus.id + ' / ' + e.rhythmus.name);
  pruef('kein Schlag gilt als formfremd', !e.form.messbar || e.form.fremd === 0,
    JSON.stringify({ fremd: e.form.fremd, rMin: e.form.rMin }));
  /* Und die Ausrichtung darf eine WIRKLICH andere Form nicht wegbuegeln. */
  const mitVes = [];
  for (let i = 0; i < 30; i++) {
    mitVes.push({ rr: 0.3333, p: true });
    if (i === 10 || i === 20) mitVes.push({ rr: 0.16, p: false, breit: true, amp: 1.4, tNeg: true });
  }
  const e2 = messe(baueStreifen({ schlaege: mitVes }), 'katze', [1, 999]);
  pruef('ein ventrikulaerer Schlag wird trotz Ausrichtung erkannt',
    e2.form.messbar && e2.form.fremd >= 2, JSON.stringify({ fremd: e2.form.fremd }));
}

// ===========================================================================
block('9a. Aus Rauschen entsteht KEINE Ektopie');
{
  /* Der gefaehrlichste denkbare Fehlbefund: ein gestoerter Streifen, in dem kein Schlag dem
   * anderen gleicht, wuerde bei der neuen Klassenbildung eine "multiforme Ektopie" mit ueber
   * 90 % Anteil ergeben - jeder Schlag seine eigene Klasse, die groesste mit einem Mitglied.
   * Deshalb: ohne ueberwiegende Form gibt es keine Vorlage und keine Aussage. */
  const z = rnd(17);
  const schlaege = mal(16, (i) => ({ rr: 0.5, p: true, breit: i % 2 === 0, amp: 0.4 + Math.abs(z()) * 1.6 }));
  const e = messe(baueStreifen({ schlaege: schlaege, rauschen: 260, seed: 21 }));
  const behauptet = e.brauchbar && e.form && e.form.messbar && e.form.fremdAnteil > 60;
  pruef('bei zerfallenem Streifen wird KEINE Ektopie behauptet', !behauptet,
    JSON.stringify({ brauchbar: e.brauchbar, form: e.form && { m: e.form.messbar, anteil: e.form.fremdAnteil } }));
  if (e.form && e.form.messbar === false && e.form.warum) {
    pruef('und es steht dabei, WARUM nicht', /überwiegende Form|Elektrodensitz|zu wenige/.test(e.form.warum),
      e.form.warum);
  } else {
    pruef('und es steht dabei, WARUM nicht', true);   // Streifen war schon vorher unbrauchbar
  }
}

// ===========================================================================
block('9. Reihenfolge in analysiere(): die Deutung sieht die Messung');
{
  const fs = require('fs');
  const quelle = fs.readFileSync(path.join(__dirname, '..', 'ui', 'shared', 'ekg-analyse.js'), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, ' ');
  const iP = quelle.indexOf('ergebnis.p = pAuswertung');
  const iR = quelle.indexOf('ergebnis.rhythmus = rhythmus');
  pruef('pAuswertung laeuft VOR der Rhythmusdeutung', iP > 0 && iR > 0 && iP < iR,
    'p@' + iP + ' rhythmus@' + iR);
  pruef('die Rhythmusdeutung bekommt die P-Auswertung uebergeben',
    /rhythmus\([^)]*\{[\s\S]{0,200}?p:\s*ergebnis\.p/.test(quelle));
  pruef('sie bekommt auch Muster, Pausen und Pausen-P',
    /muster:\s*ergebnis\.muster/.test(quelle) && /pausen:\s*ergebnis\.pausen/.test(quelle) &&
    /pausenP:\s*ergebnis\.pausenP/.test(quelle));
  pruef('der alte Satz "die dieser Streifen nicht hergibt" kommt nicht mehr vor',
    quelle.indexOf('die dieser Streifen nicht hergibt') < 0);
}

console.log('\n' + (rot ? rot + ' FEHLGESCHLAGEN von ' + (gruen + rot)
  : 'ALLE ' + gruen + ' PRUEFUNGEN BESTANDEN'));
process.exit(rot ? 1 : 0);
