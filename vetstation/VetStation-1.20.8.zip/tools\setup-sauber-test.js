'use strict';
/*
 * setup-sauber-test.js — bewacht, dass KEIN Setup-Bauweg Betriebsdaten mitnimmt,
 * und dass ein Doppelklick auf das Setup eine LAUFENDE Station sauber ablöst.
 *
 * WARUM ES DIESE DATEI GIBT (Befund 18.08.2026, am eigenen Baum gemessen):
 *
 *   dist\VetStation ist auf dem Entwicklerrechner nicht nur das Bauergebnis. Es ist auch
 *   eine LAUFENDE Station: node.exe liegt dort, die Selbsttests laufen von dort, und der
 *   Vorschau-Server startet von dort. Sie legt dabei an:
 *       data\station-id.json   495 Byte, darin das Feld "priv" mit 64 Zeichen
 *       data\diag.log          Betriebsprotokoll mit Geraete- und Netzangaben
 *   "priv" ist der PRIVATE Schluessel dieser Station.
 *
 *   installer\vetstation-setup.iss packte "{#SrcDir}\*" ohne jeden Ausschluss. Jedes damit
 *   gebaute Setup haette diesen privaten Schluessel und diese Stationskennung auf jeden
 *   Praxis-PC getragen. Zwei Folgen, beide schlimm: derselbe geheime Schluessel auf
 *   mehreren Rechnern, und im Mehrsaal-Verbund melden sich zwei Saele als dieselbe Station
 *   (die Station hat dafuer eigens ein Feld "kollision").
 *
 *   installer\make-setup-exe.ps1 - der tatsaechlich benutzte Weg, weil Inno Setup auf diesem
 *   Rechner gar nicht installiert ist - war seit 17.08.2026 gefiltert. Genau daran zeigt sich
 *   der Wert dieses Tests: ES GIBT ZWEI BAUWEGE MIT DERSELBEN AUSGABEDATEI. Wer nur einen
 *   haertet, haelt das Problem fuer geloest.
 *
 *   Zweiter Befund: stop-kiosk.ps1 lief nur in [UninstallRun]. Wer das Setup zum
 *   AKTUALISIEREN doppelklickt - genau der Weg fuer einen zweiten PC - kopierte ueber eine
 *   laufende Station. node.exe haelt dabei Dateien offen; die betroffenen bleiben auf dem
 *   alten Stand, und das Setup meldet trotzdem Erfolg.
 *
 * Start: node tools/setup-sauber-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function lies(rel) { return fs.readFileSync(path.join(WURZEL, rel), 'utf8'); }

console.log('VetStation — kein Setup traegt Betriebsdaten mit sich\n');

/* ---- 1) Beide Bauwege muessen data\ ausschliessen ---- */
console.log('1) Die beiden Setup-Bauwege:');
var iss = lies('installer/vetstation-setup.iss');
var issOhneKommentar = iss.split('\n').filter(function (z) { return z.trim().indexOf(';') !== 0; }).join('\n');
ok('vetstation-setup.iss schliesst data\\ aus',
  /Excludes:\s*"[^"]*data\\\*/.test(issOhneKommentar),
  'Ohne Excludes wandert data\\station-id.json samt privatem Schluessel ins Setup');
ok('vetstation-setup.iss schliesst auch Protokolldateien aus',
  /Excludes:\s*"[^"]*\*\.log/.test(issOhneKommentar));

var exe = lies('installer/make-setup-exe.ps1');
ok('make-setup-exe.ps1 baut aus einer GEFILTERTEN Kopie, nicht aus dist direkt',
  /ReinStage|Rein\b/.test(exe),
  'Sonst packt IExpress dist\\VetStation samt data\\');
ok('make-setup-exe.ps1 nennt data ausdruecklich beim Filtern',
  /-ne\s*\x27data\x27|'data'/.test(exe));

/* ---- 2) Das Setup muss eine laufende Station abloesen koennen ---- */
console.log('\n2) Doppelklick auf ein Setup bei LAUFENDER Station:');
ok('vetstation-setup.iss haelt vor dem Kopieren an (PrepareToInstall)',
  /function\s+PrepareToInstall/.test(iss),
  'Sonst kopiert das Setup ueber offene Dateien und meldet trotzdem Erfolg');
ok('und ruft dafuer stop-kiosk.ps1',
  /PrepareToInstall[\s\S]{0,900}stop-kiosk\.ps1/.test(iss));
ok('stop-kiosk.ps1 gibt es auch wirklich',
  fs.existsSync(path.join(WURZEL, 'kiosk/stop-kiosk.ps1')));

/* ---- 3) Und die .iss bleibt ASCII ---- */
console.log('\n3) Zeichensatz:');
var nichtAscii = [];
for (var i = 0; i < iss.length; i++) if (iss.charCodeAt(i) > 126) nichtAscii.push(i);
ok('vetstation-setup.iss ist reines ASCII (' + iss.length + ' Zeichen)',
  nichtAscii.length === 0,
  nichtAscii.length ? 'erste Stelle: ' + JSON.stringify(iss.substr(nichtAscii[0] - 20, 40)) : '');

/* ---- 4) Und der Beweis am wirklichen Baum: was liegt heute in dist\VetStation\data? ---- */
console.log('\n4) Der Ordner, um den es geht:');
var dataDir = path.join(WURZEL, 'dist/VetStation/data');
if (!fs.existsSync(dataDir)) {
  ok('dist\\VetStation\\data existiert nicht (frischer Baum) - nichts zu schuetzen', true);
} else {
  var drin = fs.readdirSync(dataDir);
  console.log('   vorhanden: ' + drin.join(', '));
  var idPfad = path.join(dataDir, 'station-id.json');
  if (fs.existsSync(idPfad)) {
    var id = JSON.parse(fs.readFileSync(idPfad, 'utf8'));
    ok('station-id.json traegt tatsaechlich ein Geheimnis (Feld "priv")',
      typeof id.priv === 'string' && id.priv.length >= 32,
      'Ohne dieses Feld waere der Ausschluss weniger dringend - er bleibt trotzdem richtig');
    console.log('   (deshalb ist der Ausschluss keine Vorsichtsmassnahme, sondern noetig)');
  } else {
    ok('keine station-id.json im Baum - der Ausschluss bleibt trotzdem Pflicht', true);
  }
}

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
