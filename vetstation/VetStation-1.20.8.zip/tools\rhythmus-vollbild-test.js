'use strict';
/*
 * rhythmus-vollbild-test.js — zwei Befunde vom 19.08.2026.
 *
 * 1) DER SIMULIERTE RHYTHMUS BLIEB AN JEDEM FOLGENDEN PATIENTEN KLEBEN.
 *
 *    Im ausgedruckten Protokoll einer Katze standen 41 von 44 Befundzeilen auf
 *    "Ventrikulaere Extrasystolen", teils mit dem Zusatz "hypoxie-/hyperkapniegetrieben".
 *    Im Kopf DERSELBEN Seite stand gleichzeitig
 *        EKG-Rhythmus (zuletzt): -
 *    also gar kein vom Geraet gemeldeter Rhythmus. Die Herzfrequenz lag im Mittel bei
 *    125/min (Norm Katze 100-180), die Einzelwerte der VES-Zeilen bei 111-120/min. Ein Tier
 *    mit dieser Frequenz hat keine Dauer-Extrasystolie.
 *
 *    Die Meldung kam nicht aus einer Messung, sondern aus dem WAHLFELD des virtuellen
 *    Geraets: monResolve() nimmt im Ist-Modus "ekg:(state.rhythm||'sinus')". state.rhythm
 *    wurde an vier Stellen GESETZT und an keiner zurueckgesetzt - wer einmal einen Rhythmus
 *    antippte, um zu sehen wie er aussieht, vererbte ihn an jeden folgenden Patienten, ueber
 *    Tierartwechsel und neuen Fall hinweg. Genau das erklaert "kommt sehr haeufig raus".
 *
 * 2) ES FEHLTE EIN VOLLBILD FUER MONITOR UND KAPNOGRAPH.
 *    Waehrend der Narkose zaehlen Kurven und Zahlen; Kopfleiste, Reiter und Dosisrechner
 *    stehen dann im Weg. Verlangt war ein Knopf, der mit DEMSELBEN Druck wieder zurueckfuehrt,
 *    und eine Analyse, die klein weiterlaeuft statt zu verschwinden.
 *
 * Start: node tools/rhythmus-vollbild-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
var html = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
var code = html.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/<!--[\s\S]*?-->/g, ' ');

console.log('VetStation — simulierter Rhythmus und Vollbild\n');

/* ---------------------------------------------------------- 1) Rhythmus */
console.log('1) Der simulierte Rhythmus geht mit dem Patienten:');
ok('beim Tierartwechsel wird er auf Sinus zurueckgesetzt',
  /b\.dataset\.sp!==state\.sp\)\{\s*state\.rhythm='sinus'/.test(code),
  'Sonst erbt der naechste Patient das VES des vorigen');
ok('und beim Zuruecksetzen des Falls ebenso',
  /state\.rhythm='sinus';\s*\n?\s*state\.injInduction=null/.test(code));
/* Die Gegenprobe: es darf nicht bloss IRGENDWO stehen, sondern an beiden Stellen. */
var treffer = (code.match(/state\.rhythm='sinus'/g) || []).length;
ok('genau diese beiden Ruecksetzungen gibt es (gefunden: ' + treffer + ')', treffer >= 2);

console.log('\n2) Ein simuliertes VES gibt sich nicht als Messung aus:');
ok('monResolve() merkt sich, ob der Rhythmus simuliert ist',
  /simuliert:\(!!\(state\.mess&&Object\.keys\(state\.mess\)\.length\)/.test(code),
  'Nur dann, wenn ein ECHTES Geraet anliegt und trotzdem ein Rhythmus eingestellt ist');
ok('… und nur bei einem anderen Rhythmus als Sinus',
  /simuliert:[\s\S]{0,140}?!=='sinus'/.test(code),
  'Sinus ist die Vorgabe und keine Behauptung');
ok('die Befundkachel schreibt es dazu',
  /r\.simuliert\?' \(am virtuellen Gerät eingestellt — nicht gemessen\)'/.test(code));

/* ---------------------------------------------------------- 3) Vollbild */
console.log('\n3) Vollbild fuer Monitor und Kapnograph:');
ok('es gibt den Knopf', /id="dmVoll"/.test(html));
ok('derselbe Knopf schaltet hin und zurueck',
  /b\.onclick=function\(\)\{ umschalten\(!document\.body\.classList\.contains\('mon-voll'\)\); \}/.test(code),
  'Ein zweiter Knopf zum Verlassen waere im Vollbild genau der, den man nicht findet');
ok('Escape fuehrt ebenfalls zurueck',
  /e\.key==='Escape'[\s\S]{0,120}?umschalten\(false\)/.test(code));
ok('die Kopfleiste und die Reiter verschwinden',
  /body\.mon-voll header,body\.mon-voll #tabs/.test(html));
ok('die Analyse bleibt sichtbar, nur schmal',
  /body\.mon-voll \.ck-rechts\{height:calc\(100vh - 16px\);overflow-y:auto;font-size/.test(html),
  'Sie ganz auszublenden waere bequemer zu bauen und falsch');
ok('der Schirm bekommt den gewonnenen Platz - mit !important',
  /body\.mon-voll \.mon-screen\{height:calc\(100vh - 300px\)!important/.test(html),
  'cockpitHoehe() setzt die Hoehe INLINE; ohne !important blieb der Schirm bei 250 px');
ok('die Geraetespalte rollt, statt abzuschneiden',
  /body\.mon-voll \.ck-links\{height:calc\(100vh - 16px\);overflow-y:auto/.test(html),
  'Gemessen: 1858 px Inhalt in 720 px Fenster - mit overflow:hidden waeren die Regler des '
  + 'Narkosegeraets unerreichbar');
ok('nach dem Umschalten wird neu vermessen',
  /umschalten[\s\S]{0,600}?cockpitHoehe\(\); if\(mon\._resize\) mon\._resize\(\)/.test(code),
  'Sonst zeichnet die Leinwand in der alten Groesse weiter');
ok('und zwar auch ohne requestAnimationFrame',
  /setTimeout\(function\(\)\{ try\{ cockpitHoehe\(\); if\(mon\._resize\) mon\._resize\(\); \}catch\(e\)\{\} \}, 60\)/.test(code),
  'rAF feuert nicht, wenn das Fenster verborgen ist - dann bliebe die Leinwand alt');

/* ---------------------------------------------------------- 4) Selbstgemachte Falle */
console.log('\n4) Die Falle, die beim Einbau zugeschlagen hat:');
ok('die Rhythmus-Chips laufen weiter ueber $$ (alle), nicht ueber $ (eines)',
  /\$\$\('#rhythmChips \.chip'\)\.forEach/.test(code),
  'In String.replace(alt, neu) bedeutet "$$" im ERSATZTEXT ein einzelnes "$". Genau daran '
  + 'ist die Zeile beim Einbau zerbrochen: aus $$( wurde $(, und die Seite warf '
  + '"$(...).forEach is not a function"');

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
