'use strict';
/*
 * paket-gleich-test.js — vergleicht das veroeffentlichte Update-Paket BYTEWEISE mit dem
 * Quellbaum, Datei fuer Datei.
 *
 * WARUM ES DIESE DATEI GIBT (zweimal derselbe Fehler, 18. und 19.08.2026):
 *
 *   tools/manifest-pruefen.js prueft "die Zip ist nicht aelter als die Quelldateien" ueber die
 *   ZEITSTEMPEL. Das ist ein Indiz, kein Beweis, und es geht in beide Richtungen schief:
 *
 *   18.08.2026: das Paket 1.20.0 war aus einem Baum gebaut, in dem ein Teil der Dateien noch
 *   CRLF trug (core.autocrlf=true, keine .gitattributes). Nach der Vereinheitlichung wichen
 *   50 der 273 Eintraege ab - jeweils genau um die Zeilenzahl. Die Zeitstempel waren neuer,
 *   also meldete manifest-pruefen zwar etwas, aber die Ursache war daraus nicht zu erkennen.
 *
 *   19.08.2026: firebase-app.js kam mit CRLF aus dem Netz in den Baum. Git normalisierte es
 *   beim Einchecken auf LF - das Paket 1.20.4 trug 101721 Byte, der Baum 99357. Dieselbe
 *   Klasse, neuer Anlass. Ein Zeitstempelvergleich hat das nicht gezeigt.
 *
 *   Ein Paket, das nicht Datei fuer Datei dem Quellstand entspricht, ist nicht mehr
 *   nachvollziehbar: man kann nicht mehr sagen, welcher Code auf dem Praxis-PC laeuft.
 *   Genau das soll die Signaturkette leisten - sie signiert aber nur die Zip, nicht die
 *   Uebereinstimmung mit dem Baum.
 *
 * WAS ABSICHTLICH ABWEICHEN DARF: die .bat-Starter werden von installer/make-dist.ps1 beim
 * Bau selbst geschrieben (Set-Content) und liegen im Baum teils in einer aelteren Fassung -
 * sie werden nie kopiert. Sie sind namentlich ausgenommen; wer die Liste erweitert, muss
 * sagen warum.
 *
 * OHNE Paket zur aktuellen Version meldet dieser Test nur einen HINWEIS. Waehrend der Arbeit
 * ist der Kanalstand normalerweise hinter dem Baum, und das darf den Sammellauf nicht
 * rot faerben - dieselbe Regel wie bei manifest-pruefen.js ohne --freigabe.
 *
 * Start: node tools/paket-gleich-test.js
 */
var fs = require('fs');
var path = require('path');
var zlib = require('zlib');
var crypto = require('crypto');

var WURZEL = path.join(__dirname, '..');
var KANAL = path.join(WURZEL, '..', '..', 'canis-vetpharm', 'vetstation');

/*
 * Vom Bau ERZEUGT, nicht kopiert. Die Liste wird aus installer/make-dist.ps1 gelesen, nicht
 * von Hand gepflegt: eine handgeschriebene Ausnahmeliste war beim ersten Lauf schon falsch
 * (der Ausdruck /^[A-Z0-9-]+\.bat$/ traf "START-VetStation.bat" wegen der Kleinbuchstaben
 * nicht). Wer im Bauskript einen Starter ergaenzt, braucht hier nichts zu tun; wer einen
 * entfernt, bekommt ihn hier sofort als Abweichung gemeldet - und das ist richtig.
 */
function erzeugteDateien() {
  var ps = fs.readFileSync(path.join(WURZEL, 'installer/make-dist.ps1'), 'utf8');
  var re = /Join-Path\s+\$Stage\s+'([^']+\.bat)'/g, m, liste = {};
  while ((m = re.exec(ps))) liste[m[1]] = 1;
  return liste;
}

var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}

console.log('VetStation — Paket und Quellstand Datei fuer Datei\n');

var version = JSON.parse(fs.readFileSync(path.join(WURZEL, 'package.json'), 'utf8')).version;
var zip = path.join(KANAL, 'VetStation-' + version + '.zip');
console.log('  Quellbaum: ' + version);

if (!fs.existsSync(zip)) {
  console.log('  ! HINWEIS: im Kanal liegt kein Paket zu ' + version + '.');
  console.log('    Waehrend der Arbeit ist das der Regelfall. Vor einer Freigabe erst bauen,');
  console.log('    dann signieren, dann diesen Test fahren.');
  console.log('\n== Ergebnis: 0 OK, 0 FAIL (nichts zu vergleichen) ==');
  process.exit(0);
}

var b = fs.readFileSync(zip);
var eintraege = [];
var i = 0;
while ((i = b.indexOf(Buffer.from([0x50, 0x4b, 0x03, 0x04]), i)) >= 0) {
  var nlen = b.readUInt16LE(i + 26), elen = b.readUInt16LE(i + 28);
  var name = b.toString('utf8', i + 30, i + 30 + nlen);
  var meth = b.readUInt16LE(i + 8), csize = b.readUInt32LE(i + 18);
  var start = i + 30 + nlen + elen;
  eintraege.push({ name: name, meth: meth, start: start, csize: csize });
  i = start + csize;
}
ok('das Paket ist lesbar (' + eintraege.length + ' Eintraege)', eintraege.length > 100);

function sha(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }

var ERZEUGT = erzeugteDateien();
ok('die Liste der beim Bau erzeugten Starter kommt aus make-dist.ps1 (' +
  Object.keys(ERZEUGT).length + ' Dateien)', Object.keys(ERZEUGT).length >= 10,
  'gefunden: ' + Object.keys(ERZEUGT).join(', '));

var gleich = 0, anders = [], fehlt = [], erzeugt = 0, ordner = 0;
eintraege.forEach(function (e) {
  if (/[\\/]$/.test(e.name)) { ordner++; return; }
  var rel = e.name.replace(/\\/g, '/');
  if (ERZEUGT[rel]) { erzeugt++; return; }
  var p = path.join(WURZEL, rel);
  if (!fs.existsSync(p)) { fehlt.push(rel); return; }
  var roh;
  try { roh = e.meth === 8 ? zlib.inflateRawSync(b.slice(e.start, e.start + e.csize)) : b.slice(e.start, e.start + e.csize); }
  catch (x) { anders.push(rel + ' (nicht entpackbar: ' + x.message + ')'); return; }
  var imBaum = fs.readFileSync(p);
  if (sha(roh) === sha(imBaum)) { gleich++; return; }
  anders.push(rel + ' (Paket ' + roh.length + ' Byte, Baum ' + imBaum.length + ' Byte' +
    (roh.length - imBaum.length === (roh.toString('latin1').match(/\r\n/g) || []).length ? ', Unterschied = Zeilenzahl -> Zeilenenden' : '') + ')');
});

console.log('');
ok(gleich + ' Eintraege byteweise gleich, 0 abweichend', anders.length === 0, anders.slice(0, 10).join(' | '));
ok('keine Datei im Paket, die es im Baum nicht gibt (ausser den ' + erzeugt + ' erzeugten .bat)',
  fehlt.length === 0, fehlt.slice(0, 10).join(', '));
console.log('  (' + erzeugt + ' .bat vom Bau erzeugt, ' + ordner + ' Ordnereintrag/-eintraege uebersprungen)');

/* Und die Gegenprobe: der Vergleich muss ueberhaupt etwas anfassen. Ein Paket, dessen
   Eintragsnamen nicht auf den Baum passen, waere sonst "0 abweichend" - und damit gruen. */
ok('der Vergleich hat wirklich Dateien geoeffnet', gleich > 200, 'verglichen: ' + gleich);

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
