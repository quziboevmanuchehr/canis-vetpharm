'use strict';
/*
 * tier3d-bild.js — das 3D-Modell aus ui/shared/tier3d.js als PNG, ohne Browser.
 *
 * WARUM: Die Browser-Vorschau drosselt den Bildtakt; wer dort eine canvas ausliest, misst
 * alte Bilder (siehe vetstation-leinwand-messfalle.md). Um zu SEHEN, ob ein Tier wie ein
 * Tier aussieht, braucht es aber ein Bild. Dieser Rasterer zeichnet dieselbe ansicht()-
 * Ausgabe, die auch die Oberflaeche zeichnet - nur in einen Speicherpuffer statt auf eine
 * canvas. Damit ist das Bild reproduzierbar und nicht getaktet.
 *
 * PNG ohne Fremdbibliothek: zlib liegt in Node bei, CRC32 sind zehn Zeilen.
 *
 * Start: node tools/tier3d-bild.js <ziel.png> [art ...] [BREITExHOEHE]
 *        FLACH=1  ohne Schattierung auf hellem Grund - so sieht man Loecher im Netz
 *        SICHT="0,8;35,20"  eigene Blickwinkel (gier,nick), durch Semikolon getrennt
 */
const zlib = require('zlib');
const fs = require('fs');
const T = require('../ui/shared/tier3d.js');

/* ---- PNG ------------------------------------------------------------------------------ */
let CRC_TAB = null;
function crc32(buf) {
  if (!CRC_TAB) {
    CRC_TAB = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      CRC_TAB[n] = c;
    }
  }
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TAB[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}
function chunk(typ, daten) {
  const len = Buffer.alloc(4); len.writeUInt32BE(daten.length, 0);
  const kopf = Buffer.concat([Buffer.from(typ, 'ascii'), daten]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(kopf), 0);
  return Buffer.concat([len, kopf, crc]);
}
function png(breite, hoehe, rgb) {
  const roh = Buffer.alloc(hoehe * (1 + breite * 3));
  for (let y = 0; y < hoehe; y++) {
    roh[y * (1 + breite * 3)] = 0;                                   /* Filter 0 = keiner */
    rgb.copy(roh, y * (1 + breite * 3) + 1, y * breite * 3, (y + 1) * breite * 3);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(breite, 0); ihdr.writeUInt32BE(hoehe, 4);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;  /* 8 bit, Truecolor */
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(roh, { level: 9 })), chunk('IEND', Buffer.alloc(0))
  ]);
}

/* ---- Rasterer ------------------------------------------------------------------------- */
/* Vielecke werden durch Zerlegung in Dreiecke gefuellt (Faecher ab Ecke 0). Kein
 * Kantenglaetten: es geht um die FORM, und weiche Kanten wuerden nur verschleiern, wo eine
 * Flaeche wirklich endet. */
function bild(breite, hoehe, hg) {
  const b = Buffer.alloc(breite * hoehe * 3);
  for (let i = 0; i < breite * hoehe; i++) { b[i * 3] = hg[0]; b[i * 3 + 1] = hg[1]; b[i * 3 + 2] = hg[2]; }
  return b;
}
function dreieck(buf, breite, hoehe, a, b, c, farbe) {
  const x0 = Math.max(0, Math.floor(Math.min(a.x, b.x, c.x)));
  const x1 = Math.min(breite - 1, Math.ceil(Math.max(a.x, b.x, c.x)));
  const y0 = Math.max(0, Math.floor(Math.min(a.y, b.y, c.y)));
  const y1 = Math.min(hoehe - 1, Math.ceil(Math.max(a.y, b.y, c.y)));
  const d = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
  if (Math.abs(d) < 1e-9) return;
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const px = x + 0.5, py = y + 0.5;
      const w0 = ((b.y - c.y) * (px - c.x) + (c.x - b.x) * (py - c.y)) / d;
      const w1 = ((c.y - a.y) * (px - c.x) + (a.x - c.x) * (py - c.y)) / d;
      const w2 = 1 - w0 - w1;
      if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
      const o = (y * breite + x) * 3;
      buf[o] = farbe[0]; buf[o + 1] = farbe[1]; buf[o + 2] = farbe[2];
    }
  }
}
function kreis(buf, breite, hoehe, cx, cy, r, farbe, alpha) {
  for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(hoehe - 1, Math.ceil(cy + r)); y++) {
    for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(breite - 1, Math.ceil(cx + r)); x++) {
      const dx = x + 0.5 - cx, dy = y + 0.5 - cy;
      if (dx * dx + dy * dy > r * r) continue;
      const o = (y * breite + x) * 3;
      for (let k = 0; k < 3; k++) buf[o + k] = Math.round(buf[o + k] * (1 - alpha) + farbe[k] * alpha);
    }
  }
}
function hex(h, f) {
  return [Math.round(parseInt(h.slice(1, 3), 16) * f),
    Math.round(parseInt(h.slice(3, 5), 16) * f),
    Math.round(parseInt(h.slice(5, 7), 16) * f)];
}

const KLEMME = { RA: '#e33', LA: '#e5c100', LL: '#e33', RL: '#2ba84a' };

/* Ein Streifen mit mehreren Ansichten nebeneinander - so sieht man auf einen Blick, ob das
 * Tier aus JEDER Richtung ein Tier ist. Genau das war beim ersten Modell nicht der Fall. */
const FLACH = !!process.env.FLACH;                 /* ohne Schattierung: zeigt Loecher im Netz */
const HG = FLACH ? [235, 238, 242] : [14, 18, 26];

function streifen(art, ansichten, zellB, zellH) {
  const m = T.netz(art);
  const B = zellB * ansichten.length, H = zellH;
  const buf = bild(B, H, HG);
  ansichten.forEach((a, idx) => {
    const v = T.ansicht(m, { gierGrad: a[0], nickGrad: a[1], breite: zellB, hoehe: zellH });
    const ox = idx * zellB;
    v.flaechen.forEach((f) => {
      const c = FLACH ? hex(f.farbe, 1) : hex(f.farbe, f.hell);
      for (let j = 1; j < f.eck.length - 1; j++) {
        dreieck(buf, B, H,
          { x: f.eck[0].x + ox, y: f.eck[0].y }, { x: f.eck[j].x + ox, y: f.eck[j].y },
          { x: f.eck[j + 1].x + ox, y: f.eck[j + 1].y }, c);
      }
    });
    v.marken.forEach((s) => {
      kreis(buf, B, H, s.x + ox, s.y, 9, hex(KLEMME[s.k], 1), s.vorn ? 1 : 0.28);
    });
  });
  return { buf, B, H };
}

const ziel = process.argv[2] || 'modell.png';
const artArg = process.argv.slice(3).filter((a) => !/^\d/.test(a));
const arten = artArg.length ? artArg : T.arten();
const groesse = process.argv.slice(3).filter((a) => /^\d/.test(a))[0];
const ANSICHTEN = process.env.SICHT
  ? process.env.SICHT.split(';').map((s) => s.split(',').map(Number))
  : [[0, 12], [180, 12], [90, 12], [35, 45]];   /* links, rechts, vorn, schraeg oben */

const zellB = groesse ? +groesse.split('x')[0] : 300;
const zellH = groesse ? +groesse.split('x')[1] : 210;
const teile = arten.map((a) => streifen(a, ANSICHTEN, zellB, zellH));
const B = teile[0].B, H = teile.length * zellH;
const ganz = bild(B, H, HG);
teile.forEach((t, i) => t.buf.copy(ganz, i * zellH * B * 3));
fs.writeFileSync(ziel, png(B, H, ganz));
console.log('geschrieben: ' + ziel + '  (' + B + 'x' + H + ')  Arten: ' + arten.join(', '));
console.log('Ansichten je Zeile: links | rechts | von vorn | schraeg von oben');
