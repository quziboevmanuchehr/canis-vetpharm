'use strict';
/*
 * wechsel-test.js — spricht die Zackensuche abwechselnd auf P-Welle und R-Zacke an?
 *
 * WOHER DER FEHLERMODUS STAMMT (08.08.2026):
 * Zwei unabhaengige Dissertationen der LMU Muenchen (Schultheiss 2011, Penzl) beschreiben
 * denselben Ausfall an einem Ultraschallgeraet: die automatische EKG-Triggerung loeste
 * ABWECHSELND auf P-Welle und R-Zacke aus, bevorzugt bei Hunden mit hoher P-Welle, bei
 * normalem Sinusrhythmus und ausreichender QRS-Amplitude. Ein Dackel war deshalb gar nicht
 * auswertbar. Unsere Zackensuche arbeitet nach demselben Grundprinzip und kann denselben
 * Fehler machen.
 *
 * DAS EIGENTLICHE PROBLEM IST NICHT DIE ERKENNUNG, SONDERN DIE VERWECHSLUNG:
 * Ein Streifen mit abwechselnd kurzen und langen Abstaenden sieht genauso aus wie eine echte
 * ventrikulaere Bigeminie. Wer das eine fuer das andere haelt, befundet eine Rhythmusstoerung,
 * die es nicht gibt - oder uebersieht eine, die es gibt. Deshalb prueft dieser Test beide
 * Richtungen und ausdruecklich auch, dass ein GESUNDER Streifen NICHT anschlaegt.
 *
 * Start: node tools/wechsel-test.js
 */
const VS = require('../ui/shared/ekg-analyse.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

const HZ = 250;

/* Eine Zacke als angehobener Kosinus - sie hat einen definierten Anfang und ein definiertes
 * Ende, anders als eine Gauss-Glocke, die nie ganz auf null geht. */
function welle(werte, mitteS, dauerS, hoehe) {
  const von = Math.round((mitteS - dauerS / 2) * HZ);
  const bis = Math.round((mitteS + dauerS / 2) * HZ);
  for (let i = von; i <= bis; i++) {
    if (i < 0 || i >= werte.length) continue;
    const t = (i - von) / (bis - von);
    werte[i] += hoehe * 0.5 * (1 - Math.cos(2 * Math.PI * t));
  }
}

/* Streifen bauen: Schlaege an den angegebenen Zeitpunkten, jeder mit P und R.
 * pHoehe/rHoehe in denselben Einheiten wie die Kurve. */
function streifen(sekunden, schlaege, pHoehe, rHoehe, pqS) {
  const n = Math.round(sekunden * HZ);
  const w = new Array(n).fill(0);
  schlaege.forEach((t) => {
    if (pHoehe > 0) welle(w, t - pqS, 0.045, pHoehe);
    welle(w, t, 0.045, rHoehe);
  });
  return w;
}

function zackenAus(w) { return VS.findeQRS(w, HZ); }
function rrAus(z) {
  const rr = [];
  for (let i = 1; i < z.length; i++) rr.push((z[i] - z[i - 1]) / HZ * 1000);
  return rr;
}

/* ================================================================================
 * 1. GESUNDER STREIFEN — darf NICHT anschlagen
 * ============================================================================== */
block('1. regelmaessiger Sinusrhythmus');
{
  const t = [];
  for (let k = 0; k < 12; k++) t.push(0.6 + k * 0.6);          // 100/min, streng regelmaessig
  const w = streifen(9, t, 0.15, 1.0, 0.10);
  const z = zackenAus(w), rr = rrAus(z);
  pruef('Zacken gefunden', z.length >= 10, 'gefunden ' + z.length);
  pruef('kein Wechselverdacht bei regelmaessigem Rhythmus',
    VS.wechselVerdacht(w, z, rr) === null, JSON.stringify(VS.wechselVerdacht(w, z, rr)));
}

/* Auch eine kraeftige Atemarrhythmie darf nicht anschlagen - beim Hund ist sie normal, und
 * genau davor warnen die Quellen: eine Humanschwelle erzeugt hier Fehlalarme in Serie. */
block('1b. respiratorische Sinusarrhythmie (beim Hund normal)');
{
  const t = []; let s = 0.6;
  for (let k = 0; k < 14; k++) { t.push(s); s += 0.5 + 0.18 * Math.sin(k * 0.9); }
  const w = streifen(12, t, 0.15, 1.0, 0.10);
  const z = zackenAus(w), rr = rrAus(z);
  const v = VS.wechselVerdacht(w, z, rr);
  pruef('kein Wechselverdacht bei Atemarrhythmie', v === null, JSON.stringify(v));
}

/* ================================================================================
 * 2. P-WELLE WIRD MITGEZAEHLT — muss erkannt UND als solche gedeutet werden
 * ============================================================================== */
block('2. Erkennung zaehlt die P-Welle mit');
{
  /* So sieht es aus, wenn der Sucher auf P UND R anspricht: die Zacken liegen abwechselnd
   * bei t-PQ (klein) und t (gross). Wir bauen das direkt als Zackenliste nach, damit der
   * Test die DEUTUNG prueft und nicht die Empfindlichkeit der Zackensuche. */
  const w = new Array(Math.round(10 * HZ)).fill(0);
  const zack = [];
  let t = 0.6;
  for (let k = 0; k < 10; k++) {
    const pIdx = Math.round((t - 0.11) * HZ), rIdx = Math.round(t * HZ);
    w[pIdx] = 0.18;                    // P-Welle: klein
    w[rIdx] = 1.20;                    // R-Zacke: gross
    zack.push(pIdx, rIdx);
    t += 0.60;
  }
  const rr = rrAus(zack);
  const v = VS.wechselVerdacht(w, zack, rr);
  pruef('Wechsel wird erkannt', v !== null);
  if (v) {
    pruef('als mitgezaehlte P-Welle gedeutet', v.deutung === 'p-mitgezaehlt', v.deutung);
    pruef('kurzer Abstand entspricht der PQ-Zeit (~110 ms)', Math.abs(v.kurzMs - 110) <= 12, v.kurzMs + ' ms');
    pruef('langer Abstand ist der Rest des Schlages (~490 ms)', Math.abs(v.langMs - 490) <= 15, v.langMs + ' ms');
    pruef('Paarsumme ist der echte Herzschlag (~600 ms)', Math.abs(v.paarsummeMs - 600) <= 15, v.paarsummeMs + ' ms');
    pruef('Hoehenverhaeltnis deutlich ueber 2', v.hoehenverhaeltnis >= 2, String(v.hoehenverhaeltnis));
    pruef('der Hinweis nennt die P-Welle', /P-Welle/.test(v.hinweis));
    pruef('der Hinweis behauptet KEINE Bigeminie', !/ist eine Bigeminie/.test(v.hinweis));
    pruef('der Hinweis fordert den Blick auf den Streifen', /Streifen ansehen/.test(v.hinweis));
  }
}

/* ================================================================================
 * 3. ECHTE BIGEMINIE — Wechsel erkannt, aber NICHT als P-Welle gedeutet
 * ============================================================================== */
block('3. echte Bigeminie (beide Ausschlaege gleich hoch)');
{
  const w = new Array(Math.round(10 * HZ)).fill(0);
  const zack = [];
  let t = 0.6;
  for (let k = 0; k < 10; k++) {
    const vesIdx = Math.round((t + 0.24) * HZ), normIdx = Math.round(t * HZ);
    w[normIdx] = 1.10;
    w[vesIdx] = 1.25;                  // Extrasystole: aehnlich hoch, teils hoeher
    zack.push(normIdx, vesIdx);
    t += 0.60;
  }
  const rr = rrAus(zack);
  const v = VS.wechselVerdacht(w, zack, rr);
  pruef('Wechsel wird erkannt', v !== null);
  if (v) {
    pruef('NICHT als P-Welle gedeutet', v.deutung === 'offen', v.deutung);
    pruef('Hoehenverhaeltnis nahe 1', v.hoehenverhaeltnis < 2, String(v.hoehenverhaeltnis));
    pruef('der Hinweis nennt beide Deutungen',
      /Bigeminie/.test(v.hinweis) && /P-Welle/.test(v.hinweis), v.hinweis.slice(0, 80));
    pruef('der Hinweis behauptet nichts', /bevor ein Befund gestellt wird/.test(v.hinweis));
  }
}

/* ================================================================================
 * 4. GRENZEN — lieber schweigen als raten
 * ============================================================================== */
block('4. Grenzen');
pruef('zu wenige Schlaege -> kein Verdacht',
  VS.wechselVerdacht([0, 1, 0, 1], [0, 1, 2, 3], [100, 500, 100]) === null);
pruef('leere Eingabe -> kein Verdacht', VS.wechselVerdacht([], [], []) === null);
pruef('null -> kein Verdacht', VS.wechselVerdacht(null, null, null) === null);
{
  /* Wechsel ja, aber Paarsummen schwanken stark: dann ist es kein zerlegter Einzelschlag. */
  const w = new Array(2500).fill(0);
  const zack = []; let idx = 100;
  const folge = [30, 140, 30, 260, 30, 100, 30, 300, 30, 180, 30, 240];
  folge.forEach((d) => { zack.push(idx); w[idx] = 1.0; idx += d; });
  const rr = rrAus(zack);
  pruef('unregelmaessige Paarsummen -> kein Verdacht',
    VS.wechselVerdacht(w, zack, rr) === null);
}

/* ================================================================================
 * 5. DER BEFUND KOMMT AUCH BEI analysiere() AN
 * ============================================================================== */
block('5. Durchreichen bis zur Auswertung');
{
  const w = new Array(Math.round(10 * HZ)).fill(0);
  let t = 0.6;
  for (let k = 0; k < 12; k++) {
    welle(w, t - 0.11, 0.05, 0.9);     // absichtlich HOHE P-Welle
    welle(w, t, 0.05, 1.2);
    t += 0.60;
  }
  const erg = VS.analysiere({ samples: w, hz: HZ, skala: 1, einheit: 'mV' }, { art: 'hund' });
  pruef('analysiere() liefert das Feld wechsel', 'wechsel' in erg);
  /* Ob hier wirklich ein Verdacht entsteht, haengt an der Empfindlichkeit der Zackensuche -
   * das ist keine Zusicherung. Zugesichert ist nur: das Feld existiert und ist entweder
   * null oder ein vollstaendiger Befund. */
  if (erg.wechsel) {
    pruef('Befund ist vollstaendig',
      erg.wechsel.kurzMs > 0 && erg.wechsel.langMs > 0 && !!erg.wechsel.hinweis);
    console.log('    (Verdacht entstanden: ' + erg.wechsel.deutung + ', Verhaeltnis ' +
      erg.wechsel.hoehenverhaeltnis + ')');
  } else {
    console.log('    (kein Verdacht - die Zackensuche hat die hohe P-Welle nicht mitgezaehlt)');
    ok++;
  }
}

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
