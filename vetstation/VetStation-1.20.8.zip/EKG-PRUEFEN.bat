@echo off
title VetStation - EKG 2000 pruefen
REM Fragt das angesteckte EKG 2000 (PC-EKG) nach seinem Datenformat.
REM Es wird NUR mitgelesen - an das Geraet geht nichts.
REM Das Geraet muss angesteckt sein; Elektroden angeschlossen zu haben hilft.
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\ekg2000-mitschnitt.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\ekg2000-mitschnitt.js" %*
:ende
echo.
pause
