'use strict';
/*
 * herkunft.js — beantwortet EINE Frage: spricht diese Anfrage wirklich die eigene Station an?
 *
 * WARUM ES DIESE DATEI GIBT (12.08.2026):
 * Die Antwort wurde an ZWEI Stellen gebraucht - im HTTP-Server (server.js) und beim
 * WebSocket-Handschlag (wsserver.js) - und stand deshalb zweimal im Haus: istLokaleAdresse()
 * war in beiden Dateien Wort fuer Wort dasselbe. Bei einer Formatierungsfunktion waere das
 * laestig; bei einem SICHERHEITSRIEGEL ist es gefaehrlich. Wer eine der beiden Fassungen
 * verschaerft, haelt den Weg fuer geschlossen, waehrend die andere offen bleibt - und
 * ausgerechnet ueber den WebSocket laufen die schreibenden Befehle (pair, setMeta, medGabe).
 * server.js laedt wsserver.js, also kann wsserver.js nicht zurueckladen; eine gemeinsame
 * dritte Datei ist der einzige Weg zu EINER Wahrheit.
 *
 * KEINE ABHAENGIGKEITEN, keine Zustaende, nur reine Funktionen - damit sie ohne Netz und ohne
 * laufenden Server geprueft werden koennen (tools/sicherheit-test.js).
 */

/*
 * Kommt die VERBINDUNG von diesem Rechner? Das ist die Adresse der Gegenstelle - die kann ein
 * Browser nicht faelschen, anders als jeden Kopf, den er mitschickt.
 *
 * DIE BEIDEN ALTEN FASSUNGEN WAREN NICHT GLEICH, und das ist der beste Beleg dafuer, warum
 * diese Datei noetig war (nachgesehen 12.08.2026):
 *   server.js:    a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1'
 *   wsserver.js:  zusaetzlich der ganze Bereich 127.* und die Zeichenkette 'localhost'
 * Zwei Riegel mit demselben Namen und verschiedener Wirkung - genau die Lage, in der jemand
 * einen davon verschaerft und den anderen uebersieht.
 *
 * UEBERNOMMEN WIRD DIE ENGERE FASSUNG (die aus server.js). Der Weg dorthin ging ueber zwei
 * Irrtuemer, und beide stehen hier, weil sie naheliegen und der Naechste sie sonst wiederholt:
 *
 *   1. Zuerst wurde die WEITERE Fassung genommen, begruendet mit "127.0.0.0/8 ist vollstaendig
 *      Rueckschleife, also ist sie sachlich richtig". Der Satz stimmt fuer ADRESSEN - nur
 *      prueft /^127\./ keine Adresse, sondern einen ZEICHENANFANG. Damit galt auch
 *      "127.0.0.1.beispiel.invalid" als lokal, ein ganz gewoehnlicher Rechnername, den sich
 *      jeder eintragen kann.
 *   2. Danach wurde daraus ein sauberer Adressvergleich ueber den ganzen Bereich 127/8. Auch
 *      das war falsch, und zwar aus einem Grund, den man dem Code allein nicht ansieht:
 *      tools/saalname-test.js stellt einen FREMDEN Rechner dar, indem er von 127.0.0.2 aus
 *      anfragt ("Der Absender wird ueber die Quelladresse des Sockets gestellt (127.0.0.2).
 *      Fuer istLokal() ist das ein fremder Rechner; ein Netz oder eine zweite Karte braucht
 *      es dafuer nicht."). Dass NUR 127.0.0.1 als lokal gilt, ist in diesem Projekt also
 *      keine Nachlaessigkeit, sondern eine tragende Festlegung - ohne sie liesse sich die
 *      Sperre zwischen Praxisnetz und Saalnamen gar nicht mehr ohne zweite Netzkarte pruefen.
 *
 * Fuer den WebSocket ist das eine VERSCHAERFUNG (er nahm vorher 127.*). Sie ist gefahrlos:
 * Node meldet fuer eine Verbindung ueber die Rueckschleife 127.0.0.1 oder ::1, und ein
 * Browser auf demselben PC verbindet nicht von 127.0.0.2 aus.
 *
 * DIE LISTE IST ABSCHLIESSEND UND KEIN PRAEFIXVERGLEICH. Verglichen wird die Adresse des
 * SOCKETS; jede Angabe aus der Anfrage selbst (Host, X-Forwarded-For) kann der Absender frei
 * setzen und beweist nichts.
 */
function istLokaleAdresse(adr) {
  if (!adr) return false;
  const a = String(adr);
  return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
}

/*
 * eigenerHostKopf(hostKopf, localPort) — steht im Host-Kopf wirklich DIESE Station?
 *
 * DER FEHLER, DEN DAS SCHLIESST (Befund 12.08.2026, DNS-Rebinding):
 * Bis dahin wurde der Origin-Kopf gegen den HOST-Kopf DERSELBEN Anfrage verglichen. Begruendet
 * war das mit dem Satz "Ein Angreifer kann den Host-Kopf zwar mitsetzen, aber nicht den
 * Origin-Kopf: den setzt der Browser selbst." Der Satz stimmt - und beantwortet trotzdem die
 * falsche Frage. Beim DNS-Rebinding SETZT der Browser den Origin selbst, naemlich auf den Namen
 * des Angreifers; derselbe Name steht im Host-Kopf, weil der Browser die Seite unter diesem
 * Namen geladen hat. Der Vergleich war damit ein SELBSTVERGLEICH: zwei Werte aus derselben
 * Anfrage, beide vom Angreifer bestimmt, immer gleich.
 *
 * DER ABLAUF, konkret: eine Seite liegt unter http://boese.example:8770/. Der DNS-Eintrag hat
 * TTL 0 und wird nach dem ersten Laden auf 127.0.0.1 umgestellt. Ab da zeigt derselbe Name auf
 * die Station - fuer den Browser ist das dieselbe Herkunft. Also gibt es weder eine
 * CORS-Vorabfrage noch eine fremde Sec-Fetch-Site, und die Antwort ist LESBAR. Damit fielen
 * alle vier bisherigen Riegel gleichzeitig: istLokaleAdresse (die Verbindung kommt wirklich von
 * 127.0.0.1), Sec-Fetch-Site (meldet same-origin), der Content-Type-Zwang (bei gleicher Herkunft
 * frei setzbar) und der Origin-Vergleich (boese.example gegen boese.example).
 *
 * DER RIEGEL IST EINE POSITIVLISTE, kein Vergleich mit sich selbst. Eine Station spricht man
 * ueber 127.0.0.1, localhost oder ::1 an - unter jedem anderen Namen ist sie nicht gemeint.
 * Ein Angreifer kann den Namen im Host-Kopf zwar frei setzen; der Browser tut es aber NICHT
 * frei, sondern traegt dort die Adresse ein, unter der die Seite laeuft. Genau daran scheitert
 * das Rebinding: es braucht einen eigenen Namen, und ein eigener Name steht nicht auf der Liste.
 *
 * DER PORT KOMMT AUS DER VERBINDUNG (req.socket.localPort), NICHT AUS DER KONFIGURATION.
 * Genau daran war die alte Fassung gescheitert: bei port:0 vergibt das Betriebssystem den Port,
 * und so laufen die Selbsttests. Der Socket weiss immer, auf welchem Port er wirklich angenommen
 * hat; die Konfiguration weiss es nicht.
 *
 * FEHLT DER HOST-KOPF, wird NICHT abgelehnt: HTTP/1.0-Werkzeuge, curl -0 und eigene Skripte
 * senden ihn nicht. Der Weg, den dieser Riegel schliessen soll, fuehrt ueber einen Browser -
 * und ein Browser schickt den Host-Kopf immer.
 */
function eigenerHostKopf(hostKopf, localPort) {
  const h = String(hostKopf || '').trim().toLowerCase();
  if (!h) return true;                       /* kein Host-Kopf: kein Browser, siehe oben */
  /* IPv6 steht in eckigen Klammern: [::1]:8770 - deshalb zuerst diese Form probieren. */
  const m = h.match(/^\[([^\]]+)\](?::(\d+))?$/) || h.match(/^([^:]+)(?::(\d+))?$/);
  if (!m) return false;
  const name = m[1];
  if (name !== '127.0.0.1' && name !== 'localhost' && name !== '::1') return false;
  /* Ohne Portangabe meint ein Browser Port 80 - dann muss die Station auch dort horchen.
   * Ist der eigene Port unbekannt (kein Socket), bleibt es beim Namen. */
  const gemeint = m[2] ? Number(m[2]) : 80;
  return !localPort || gemeint === Number(localPort);
}

module.exports = { istLokaleAdresse, eigenerHostKopf };
