'use strict';
/*
 * hrv-test.js — Herzfrequenzvariabilitaet aus den RR-Abstaenden.
 *
 * WARUM ES DIESE MESSUNG GIBT (Recherche 09.08.2026):
 * Norav PC-ECG 1200 fuehrt HRV als lizenzpflichtige Zusatzoption, Televet 100 ebenso. Sie
 * braucht AUSSCHLIESSLICH die RR-Abstaende - anders als fast alles andere, was fremde
 * Geraete mehr koennen als wir, verlangt sie KEINE zweite Ableitung. Die Abstaende hat
 * unsere Zackensuche ohnehin schon.
 *
 * WAS HIER FESTGEHALTEN WIRD, IST VOR ALLEM DAS SCHWEIGEN:
 * Fuer Hund, Katze und die uebrigen Arten sind keine belastbaren HRV-Normbereiche belegt,
 * die diese Anwendung nennen duerfte - HRV haengt zusaetzlich an Narkosetiefe, Alter und
 * Rasse. Es wird deshalb GEMESSEN und NICHT BEWERTET. Ein Test, der nur die Arithmetik
 * prueft, wuerde den wichtigeren Teil uebersehen.
 *
 * Und eine harte Grenze: ein einziger vorzeitiger Schlag erzeugt einen kurzen UND einen
 * langen Abstand und hebt SDNN wie RMSSD deutlich an. Wo formfremde Schlaege im Streifen
 * sind, muss das an der Zahl stehen.
 *
 * Start: node tools/hrv-test.js
 */
const VS = require('../ui/shared/ekg-analyse.js');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function nah(was, ist, soll, tol) {
  pruef(was, Math.abs(ist - soll) <= tol, 'ist ' + ist + ', soll ' + soll + ' ±' + tol);
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Herzfrequenzvariabilitaet\n');

/* ================================================================================
 * 1. VOLLKOMMEN GLEICHMAESSIG -> alle Masse null
 * ============================================================================== */
block('1. streng regelmaessiger Rhythmus');
{
  const rr = new Array(40).fill(500);
  const h = VS.hrv(rr);
  pruef('messbar', h.messbar === true, h.warum);
  nah('mittlerer RR-Abstand', h.mittelRrMs, 500, 0);
  nah('SDNN ist null', h.sdnnMs, 0, 0.01);
  nah('RMSSD ist null', h.rmssdMs, 0, 0.01);
  nah('pNN50 ist null', h.pnn50, 0, 0.01);
  pruef('min und max sind gleich', h.minRrMs === 500 && h.maxRrMs === 500);
  pruef('nicht bewertet', h.bewertet === false);
  pruef('und es steht dabei, warum nicht', /keine belastbaren HRV-Normbereiche/.test(h.warum));
}

/* ================================================================================
 * 2. GEGEN EINE VON HAND GERECHNETE REIHE
 * Nicht "sieht plausibel aus", sondern die Zahlen nachgerechnet.
 * ============================================================================== */
block('2. nachgerechnete Reihe');
{
  /* 21 Abstaende, damit die Mindestzahl erreicht ist: abwechselnd 480 und 520 ms.
   * Mittel = (11*480 + 10*520)/21 = (5280+5200)/21 = 10480/21 = 499,0476...
   * SDNN: Abweichungen ±20 (fast), Stichprobenstandardabweichung ~20,49
   * Aufeinanderfolgende Unterschiede: alle ±40 -> RMSSD = 40
   * pNN50: alle 20 Unterschiede > 50 ms? NEIN, 40 < 50 -> pNN50 = 0 */
  const rr = [];
  for (let i = 0; i < 21; i++) rr.push(i % 2 === 0 ? 480 : 520);
  const h = VS.hrv(rr);
  nah('Mittel', h.mittelRrMs, 499, 1);
  nah('RMSSD ist genau der Wechsel (40 ms)', h.rmssdMs, 40, 0.2);
  nah('pNN50 ist 0, weil 40 ms unter der 50-ms-Schwelle liegt', h.pnn50, 0, 0.01);
  pruef('SDNN liegt zwischen 19 und 22 ms', h.sdnnMs > 19 && h.sdnnMs < 22, String(h.sdnnMs));
  pruef('min 480, max 520', h.minRrMs === 480 && h.maxRrMs === 520);
}
{
  /* Dieselbe Reihe, aber mit 60 ms Wechsel: jetzt MUSS pNN50 auf 100 % gehen. */
  const rr = [];
  for (let i = 0; i < 21; i++) rr.push(i % 2 === 0 ? 470 : 530);
  const h = VS.hrv(rr);
  nah('60-ms-Wechsel -> RMSSD 60', h.rmssdMs, 60, 0.2);
  nah('60-ms-Wechsel -> pNN50 100 %', h.pnn50, 100, 0.01);
}

/* ================================================================================
 * 3. ATEMARRHYTHMIE — beim Hund normal, und genau das misst RMSSD
 * ============================================================================== */
block('3. respiratorische Sinusarrhythmie');
{
  const rr = [];
  for (let i = 0; i < 40; i++) rr.push(500 + 90 * Math.sin(i * 0.55));
  const h = VS.hrv(rr);
  pruef('SDNN deutlich ueber null', h.sdnnMs > 40, String(h.sdnnMs));
  pruef('RMSSD deutlich ueber null', h.rmssdMs > 20, String(h.rmssdMs));
  pruef('trotzdem KEINE Bewertung', h.bewertet === false);
  /* Der springende Punkt: eine hohe Zahl ist beim Hund NICHT auffaellig. Wer hier eine
   * Ampel einbaut, erzeugt Fehlalarme in Serie. */
  pruef('es wird nicht als auffaellig gemeldet', !('auffaellig' in h) && !('stufe' in h));
}

/* ================================================================================
 * 4. ZU WENIG SCHLAEGE -> SCHWEIGEN
 * ============================================================================== */
block('4. zu kurzer Streifen');
[[], [500], new Array(5).fill(500), new Array(VS.HRV_MIN_RR - 1).fill(500)].forEach((rr) => {
  const h = VS.hrv(rr);
  pruef(rr.length + ' Abstaende -> nicht messbar', h.messbar === false);
  pruef(rr.length + ' Abstaende -> mit Begruendung', !!h.warum);
});
{
  const h = VS.hrv(new Array(VS.HRV_MIN_RR).fill(500));
  pruef(VS.HRV_MIN_RR + ' Abstaende -> messbar (die Grenze selbst zaehlt)', h.messbar === true);
}

/* ================================================================================
 * 5. EXTRASYSTOLEN VERFAELSCHEN JEDES MASS — das muss an der Zahl stehen
 * ============================================================================== */
block('5. Kennzeichnung bei formfremden Schlaegen');
{
  const rr = new Array(40).fill(500);
  pruef('ohne Ektopie: nicht gekennzeichnet', VS.hrv(rr, {}).durchEktopieVerfaelscht === false);
  pruef('mit Ektopie: gekennzeichnet', VS.hrv(rr, { ektopie: true }).durchEktopieVerfaelscht === true);
}
{
  /* Und der Beleg, WARUM: ein einziger vorzeitiger Schlag hebt die Masse deutlich. */
  const ruhig = new Array(40).fill(500);
  const mitVes = ruhig.slice();
  mitVes[20] = 300; mitVes[21] = 700;         // vorzeitig + kompensatorische Pause
  const a = VS.hrv(ruhig), b = VS.hrv(mitVes);
  pruef('ein einziger vorzeitiger Schlag hebt SDNN deutlich',
    b.sdnnMs > a.sdnnMs + 20, a.sdnnMs + ' -> ' + b.sdnnMs);
  pruef('und RMSSD noch staerker', b.rmssdMs > a.rmssdMs + 40, a.rmssdMs + ' -> ' + b.rmssdMs);
}

/* ================================================================================
 * 6. ANGEHAENGT AN analysiere()
 * ============================================================================== */
block('6. kommt bei analysiere() an');
{
  const HZ = 250, n = HZ * 20, w = new Array(n).fill(0);
  function zacke(mS, dS, h) {
    const a = Math.round((mS - dS / 2) * HZ), b = Math.round((mS + dS / 2) * HZ);
    for (let i = a; i <= b; i++) { if (i < 0 || i >= n) continue; const t = (i - a) / (b - a); w[i] += h * 0.5 * (1 - Math.cos(2 * Math.PI * t)); }
  }
  let t = 0.5;
  for (let k = 0; k < 38; k++) { zacke(t, 0.04, 1.0); t += 0.5; }
  const erg = VS.analysiere({ samples: w, hz: HZ, skala: 1, einheit: 'mV' }, { art: 'hund' });
  pruef('analysiere() liefert das Feld hrv', 'hrv' in erg);
  if (erg.hrv && erg.hrv.messbar) {
    nah('mittlerer RR passt zum gebauten Signal (500 ms)', erg.hrv.mittelRrMs, 500, 12);
    pruef('SDNN ist klein, das Signal ist regelmaessig', erg.hrv.sdnnMs < 15, String(erg.hrv.sdnnMs));
    pruef('nicht bewertet', erg.hrv.bewertet === false);
  } else {
    console.log('    (nicht messbar: ' + (erg.hrv && erg.hrv.warum) + ')');
    pruef('dann wenigstens mit Begruendung', !!(erg.hrv && erg.hrv.warum));
  }
}

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
