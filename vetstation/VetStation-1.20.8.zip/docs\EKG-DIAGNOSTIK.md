# Diagnostik-EKG — was gemessen wird, was gedruckt wird, was bewusst offen bleibt

Stand 10.08.2026. Gilt für das EKG-Submodul in `ui/app/index.html` (eigener Skriptblock am
Dateiende) und die gemeinsamen Dateien `ui/shared/ekg-analyse.js`, `ekg-skala.js`,
`ekg-befunde.js`, `ekg-literatur.js`.

---

## 1. Die Maßstabskette — und warum sie an einer Stelle stehen muss

Ein EKG-Ausdruck ist nur brauchbar, wenn „25 mm/s · 10 mm/mV" nicht Beschriftung ist,
sondern stimmt. Am 10.08.2026 wurde im laufenden Browser nachgemessen, was die vier
Zeichenwege wirklich taten:

| Ansicht | eingestellt | gezeichnet | Faktor |
|---|---|---|---|
| 6-Kanal-Bild am Schirm | 25 mm/s | 80,5 mm/s | 3,22× gestaucht |
| Direktdruck, 6 Ableitungen | 25 mm/s | 165,1 mm/s | 6,61× |
| Direktdruck, Rhythmusstreifen | 25 mm/s | 49,6 mm/s | 1,98× |
| PDF | 25 mm/s | 25 mm/s | richtig |

Ursache überall dieselbe: die vorhandenen Abtastwerte wurden über die ganze Fläche verteilt
(`breite/(n-1)`), statt jedem Wert die Breite zu geben, die ihm beim eingestellten Vorschub
zusteht. Nur das PDF benutzte `VS.skala.kurvenAusschnitt()`.

**Heute holen alle Zeichenwege ihre Geometrie aus `ui/shared/ekg-skala.js`.** Nachgemessen
nach der Berichtigung — injiziertes Gerätesignal mit exakt 100/min:

* PDF: Abtastabstand 0,1 mm, R-R 15,0 mm → 0,60 s → 100/min
* Direktdruck (gerendertes Blatt, Pixel ausgezählt): R-R 15,0 mm → 100/min
* alle sechs Zellen und der Rhythmusstreifen: effektiv exakt 25/50/100 mm/s

`tools/ekg-skala-test.js` rechnet das für fünf Flächen × drei Vorschübe nach und prüft
zusätzlich am Quelltext, dass die gedehnte Formel nirgends zurückkommt.

## 2. Abtastrate: fest, nicht an den Vorschub gekoppelt

`EKG_HZ = 250` (4 ms Schrittweite). Vorher lief der Puffer mit `mmPx() * M.speed`, also
50–100 Hz. Folgen, alle drei gemessen:

1. **13 ms Schrittweite** bei 75 Hz — eine Katzen-QRS-Dauer von 40 ms wurde auf drei Stufen
   gerundet.
2. **Die 50-Hz-Erkennung war still tot**: `netzStoerung()` verlangt ≥ 100 Hz (Nyquist) und
   gab darunter `null` zurück. Bei 25 mm/s wurde diese Grenze meist nicht erreicht.
3. **Umschalten verbog die Zeit**: wer während der Aufzeichnung 25 → 50 mm/s stellte,
   änderte die Rate der bereits liegenden Werte.

Der Puffer hält 20 s (`PUFFER_S`) und hängt **nicht mehr an der Leinwandbreite** — eine
Fenstergrößenänderung verwirft die Aufzeichnung nicht mehr. Gezeichnet und gemessen wird nur
der Teil, der wirklich aufgezeichnet ist (`vorhandeneWerte()`); der Rest heißt „kein Signal"
statt als flache Linie mitgemessen zu werden.

## 3. Skala in jeder Ableitung

Jede der sechs Zellen trägt eine **eigene, bei null beginnende** Zeitachse und eine
Amplitudenachse (mV bei bekannter Verstärkung, sonst mm Ausschlag). Eine durchgehende Achse
unter dem 3×2-Block wäre falsch — die drei Spalten sind drei unabhängige Zeitachsen.

Aufteilung einer Zelle aus `VS.skala.zellAufteilung()`, identisch für Schirm, PDF und
Direktdruck: `Eichzacke (1–6 mm) | Beschriftung | Kurve ab 14 mm`. Die Sekundenmarken der
Zellen zeigen **nach innen**, damit keine Beschriftung in die Zelle darunter fällt.
Auf jedem Blatt steht außerdem, was ein Kästchen trägt (`VS.skala.rasterText()`).

Vorschub 12,5 / 25 / 50 / 100 mm/s, Verstärkung 5 / 10 / 20 / 40 mm/mV — dieselbe Auswahl
wie am angeschlossenen Gerät.

## 4. Was die Auswertung benennt

`ui/shared/ekg-analyse.js` misst und schweigt im Zweifel. Seit dem 10.08.2026 läuft die
**P-Wellen-Auswertung vor der Rhythmusdeutung** — vorher lief sie danach, ihr Ergebnis
erreichte die Deutung nie, und dort stand deshalb wörtlich „für die Unterscheidung
(z. B. Vorhofflimmern) ist die P-Wellen-Beurteilung nötig, die dieser Streifen nicht hergibt".

Benannt werden jetzt zusätzlich:

| Befund | Bedingung (verkürzt) |
|---|---|
| Sinusrhythmus / Sinustachykardie / -bradykardie | regelmäßig **und** P vor jedem Komplex |
| Vorhofflimmern (Verdacht) | Schwankung > 30 %, keine P (< 40 % der Schläge), schmaler QRS |
| AV-Block II° | Pause ≥ 1,8× **und** P in der Pause; Typ über den PQ-Verlauf |
| Sinusarrest / SA-Block | Pause ≥ 1,8× **ohne** nachweisbare P |
| Bigeminus / Trigeminus | formfremde Schläge im Zweier-/Dreiertakt, ≥ 3 Perioden |
| Paare / Dreiergruppen | zwei bzw. drei formfremde Schläge in Folge |
| Salve / ventrikuläre Tachykardie | ≥ 4 formfremde Komplexe in Folge, **fremde** Breite über der Artgrenze |
| Idioventrikulärer Rhythmus | breit, regelmäßig, ohne P, unterhalb der Tachykardiegrenze |
| Elektrischer Alternans | regelmäßiger Rhythmus, Höhenwechsel ≥ 15 % in ≥ 80 % der Übergänge |
| Hyperkaliämie-Muster | T > 25 % der R **und** keine P **und** (langsam **oder** breiter QRS) |

Artabhängige Breitengrenze statt fester 80 ms: Hund 70, Katze 50, Pferd 180 ms. Mit der
alten festen Grenze wäre ein Katzen-QRS von 60 ms — anderthalbfach zu breit — als schmal
durchgegangen.

**Zwei Fallen, die der eigene Selbsttest gefunden hat:**

* Der Formvergleich nahm als Vorlage den Median **aller** Schläge. Bei einem Bigeminus liegt
  der genau zwischen beiden Formen; beide korrelierten über 0,95, und der häufigste Fall von
  Ektopie war der einzige, den der Vergleich nicht sehen konnte. Vorlage ist jetzt die größte
  Formklasse; bei zwei etwa gleich großen entscheidet die QRS-Breite.
* Beim Bigeminus fällt der **Median der RR-Abstände auf den kurzen Wert**. Die kompensatorische
  Pause steht damit rechnerisch bei 2,3× — der erste Entwurf meldete an einem sauberen
  Bigeminus einen **Sinusarrest**. `wechselVerdacht()` (kurz-lang mit gleichbleibender
  Paarsumme) hat deshalb ein Vetorecht über alle Pausenbefunde.

## 5. Der Ausdruck

Seite 1: sechs Ableitungen mit Skala, Rhythmusstreifen mit Skala, Rasterlegende,
Patientenkopf, Herkunft der Kurve (gemessen oder nachgebildet), Aufzeichnungsdauer.

Seite 2 (**nur bei echtem, brauchbarem Signal**): Messwerttabelle mit Normband und Urteil,
was **nicht** gemessen werden konnte und warum, Beurteilung, Auffälligkeiten mit Differenzial
und Quelle, „Nächster Schritt", und die Grenzen der Aussage. Auf einer nachgebildeten Kurve
gibt es diese Seite nicht — dort wäre jede Zahl die eigene Vorgabe.

## 6. „Nächster Schritt"

`NAECHSTE_SCHRITTE` verbindet Befunde mit der Untersuchung, die sie klärt (Echokardiografie,
Langzeit-EKG, Kalium, Atropintest, Mehrkanal-EKG, Aufnahme wiederholen). **Jeder Vorschlag
hängt an einem ausgelösten Befund** — eine Liste, die auf jedem Streifen gleich aussieht,
wird nach dem dritten Mal überblättert. Vorschläge, keine Anordnungen; Dringliches zuerst.

## 7. Nachschlagewerk

* `ui/shared/ekg-befunde.js` — 203 Befund**regeln** (Fachrecherche 08.08.2026).
* `ui/shared/ekg-literatur.js` — ausgewertete Einzelstellen aus den fünf Werken des Nutzers,
  je mit Buch und Seite, nach Thema gefiltert und durchsuchbar. Erzeugt von
  `tools/ekg-literatur-bauen.js`, Quelldaten in `docs/EKG-LITERATUR-2026-08.json`.
  **Löst nichts aus** — die Anwendung behauptet weiterhin nur, was sie selbst misst.
  **Steht nur an der Station** (seit 1.18.1): weder in der öffentlichen Web-App noch im
  Update-Paket, das über GitHub Pages geht. Sie kommt über die Setup.exe. Fehlt sie, sagt das
  Fenster das ausdrücklich, statt einen Fehler zu melden.
* `ui/shared/dosis-warnungen.js` — die Richtigstellungen zu Stellen, an denen die **Vorlage
  selbst** falsch ist (heute zwei: eine Dauertropfdosis, die im Buch tausendfach zu hoch
  gedruckt ist, und eine Bezugsgröße, die nur für die Katze gilt). Aus derselben Quelle
  erzeugt, aber **getrennt ausgeliefert** — und das ist der ganze Zweck: der Updater löscht
  nichts, eine laufende Station behält also ihre alte `ekg-literatur.js`, und die kennt die
  Warnungen nicht (gemessen: 1.12.0–1.17.0 tragen null davon). Zugeordnet wird über den
  exakten Schlüssel `werk|seite|zahlen`; `werk+seite` allein reicht nicht, dort sind 266
  Schlüssel mehrfach belegt. Enthält kein Buchwissen und darf deshalb überall hin.

## 8. Tests

| Datei | prüft |
|---|---|
| `tools/ekg-skala-test.js` | Achsen, Zellaufteilung, kein Dehnen, Abstand zum Blattrand |
| `tools/ekg-analyse-test.js` | QRS, Rhythmus, ST auf echten Gerätedaten |
| `tools/p-welle-test.js` | P und PQ — findet sie, wo sie ist, und schweigt, wo keine ist |
| `tools/rhythmus-test.js` | die neuen Rhythmusarten an synthetischen Streifen bekannter Wahrheit, mit Gegenproben |
| `tools/hrv-test.js` | Variabilität (gemessen, bewusst nicht bewertet) |
| `tools/ekg-modul-test.js` | Oberfläche, Regeln, Ausdruck, Befundbericht, „Nächster Schritt" |
