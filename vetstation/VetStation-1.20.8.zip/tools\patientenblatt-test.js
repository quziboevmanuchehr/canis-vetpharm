'use strict';
/*
 * patientenblatt-test.js — das Patientenblatt des EKG-Submoduls.
 *
 * WARUM ES DIESEN TEST GIBT (09.08.2026):
 * Das Patientenblatt ist die Stelle, an der Tierart, Rasse, Gewicht und Alter in das
 * Diagnostik-EKG kommen. Von diesen vier Angaben haengt danach ALLES ab: nach welcher
 * Tierart bewertet wird, welche Normgrenzen gelten, welche rassebedingten Herzhinweise
 * erscheinen und welches Altersfenster geprueft wird. Ein Fehler hier ist deshalb nie
 * lokal - er verschiebt jede spaetere Bewertung.
 *
 * DREI FEHLER, DIE HIER SCHON DRIN WAREN UND DIE DIESER TEST FESTHAELT:
 *
 *  1. ARTENKENNUNG. Das Blatt fuehrte "meerschweinchen", Katalog und Anwendung
 *     "meerschwein". Wer Meerschweinchen waehlte, bekam KEINE der 24 hinterlegten Rassen -
 *     die Liste war leer, ohne dass irgendetwas auf einen Fehler hindeutete. Degu und
 *     Rennmaus fehlten ganz.
 *
 *  2. IIFE-GRENZE. renderPatient() griff auf "A" (die Abkuerzung fuer window.ANAES) zu.
 *     Die gibt es nur in der Motor-IIFE; das EKG-Submodul ist ein eigener Skriptblock.
 *     Ergebnis war ein ReferenceError und ein leeres Patientenblatt - im Browser gemessen.
 *     Dieselbe Grenze hat am selben Tag schon den Rohpuffer des Archivs getroffen.
 *
 *  3. FREIES TEXTFELD FUER DIE RASSE. "Maine Coon", "mainecoon" und "MC" sind fuer ein
 *     Programm drei verschiedene Tiere. An einer Zeichenkette haengt keine Praedisposition.
 *
 * Start: node tools/patientenblatt-test.js
 */
const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');
/* Quellpruefungen lesen auch Kommentare - und in dieser Datei stehen lange Kommentare, die
 * genau die Begriffe nennen, nach denen gesucht wird. Ohne dieses Abstreifen wuerde der Test
 * seine eigenen Erklaerungen finden und immer gruen sein. Der Fehler ist hier zweimal
 * passiert; deshalb steht er im Kopf jeder betroffenen Datei. */
const code = src.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/<!--[\s\S]*?-->/g, ' ');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Patientenblatt des EKG-Submoduls\n');

/* ================================================================================
 * 1. ARTENKENNUNGEN
 * ============================================================================== */
block('1. Artenkennungen');
pruef('die Artenliste kommt aus der Anwendung, nicht aus einer zweiten Aufzaehlung',
  /arten\s*=\s*\(AD&&AD\.species\?AD\.species\.map/.test(code));
pruef('und ueber window.ANAES, nicht ueber die IIFE-Abkuerzung A',
  /var AD=window\.ANAES\|\|null;/.test(code));
{
  /* Die feste Liste, die frueher hier stand, darf nicht zurueckkommen. */
  const feste = /var arten=\['hund','katze','kaninchen','meerschweinchen'/.test(code);
  pruef('die alte feste Artenliste steht nicht mehr da', !feste);
}
pruef('Pferd und Vogel kommen dazu (die Narkoseabteilung fuehrt sie nicht)',
  /\['pferd','vogel'\]\.forEach/.test(code));
pruef('speciesName kennt die Katalogkennung meerschwein',
  /meerschwein:'Meerschweinchen'/.test(code));
pruef('speciesName kennt Degu und Rennmaus', /degu:'Degu'/.test(code) && /rennmaus:'Rennmaus'/.test(code));
pruef('die alte Schreibweise bleibt lesbar (gespeicherte Daten)',
  /meerschweinchen:'Meerschweinchen'/.test(code));
pruef('gespeicherte Altkennungen werden umgeschrieben',
  /SP_ALTLAST=\{ meerschweinchen:'meerschwein' \}/.test(code));
pruef('das Tierbild kennt die neue Kennung', /meerschwein:'nager'/.test(code));

/* ================================================================================
 * 2. RASSE: SUCHFELD MIT KENNUNG, NICHT FREITEXT
 * ============================================================================== */
block('2. Rassesuche');
pruef('gesucht wird mit derselben Funktion wie in der Narkoseabteilung',
  /VBl\.search\(txt, pBrArt\(\), 60\)/.test(code));
pruef('es entsteht eine Rasse-ID, nicht nur ein Text', /P\.rasseId=b\?b\.id:''/.test(code));
pruef('das alte reine Textfeld ist weg',
  !/<input id="pRas" value="'\+esc2\(P\.rasse\)\+'" placeholder="z\. B\. Maine Coon">/.test(code));
pruef('ein nicht auffindbarer Text bleibt trotzdem erhalten',
  /if\(b\)\{ P\.rasseId=b\.id; P\.rasse=b\.name; \} else \{ P\.rasseId=''; P\.rasse=txt; \}/.test(code));
{
  /* ARTWECHSEL MUSS DIE RASSE LOESCHEN. Eine Maine Coon ist keine Hunderasse; sie stehen
   * zu lassen hiesse, eine Praedisposition der falschen Art zu fuehren. */
  pruef('ein Artwechsel loescht die Rasse',
    /P\.sp=s\.value; P\.rasseId=''; P\.rasse='';/.test(code));
}
{
  /* Escape darf NUR die Trefferliste schliessen. Ohne stopPropagation faellt das ganze
   * EKG-Fenster zu, waehrend man eine Rasse sucht. */
  pruef('Escape schliesst nur die Liste, nicht das EKG-Fenster',
    /e\.key==='Escape'\)\{ if\(!\$\('#pRasPop'\)\.hidden\)\{ e\.stopPropagation\(\); pBrZu\(\); \}/.test(code));
}
pruef('das Rassefeld steht in BEIDEN Modi (am Geraet fehlt die Rasse oft)',
  /pRasseFeld\(d\)\+/.test(code) &&
  !/P\.modus==='hand'\s*\?\s*[^]{0,200}pRasseFeld/.test(code));
pruef('eine hier gewaehlte Rasse wird NICHT in die Anwendung zurueckgeschrieben',
  !/state\.breed\s*=\s*P\.rasse/.test(code));

/* ================================================================================
 * 3. ALTER: GEBURTSDATUM ODER SCHAETZUNG
 * ============================================================================== */
block('3. Alter');
pruef('es gibt beide Eingabewege', /P\.altModus==='datum'/.test(code) && /ausUngefaehr\(P\.altJahre, P\.altMonate\)/.test(code));
pruef('das Geburtsdatum hat Vorrang vor der Schaetzung',
  code.indexOf("P.altModus==='datum' && P.gebDatum") < code.indexOf("P.altJahre!=='' || P.altMonate!==''"));
pruef('das Datumsfeld laesst kein Datum in der Zukunft zu', /type="date"[^>]*max="/.test(code));
pruef('das alte Freitextfeld wird noch gelesen (Bestand geht nicht verloren)',
  /if\(P\.alter\) return VA\.parse\(P\.alter\);/.test(code));
pruef('gespeicherter Freitext wird beim Laden in Zahlen ueberfuehrt',
  /function pAltlast/.test(code) && /VS\.alter\.parse\(p\.alter\)/.test(code));
pruef('patDaten liefert das Alter als OBJEKT, nicht nur als Text', /alterObj:\(A2&&A2\.gueltig\)\?A2:null/.test(code));

/* ================================================================================
 * DIE DREI SCHWEREN BEFUNDE DER GEGENPRUEFUNG VOM 09.08.2026
 * Sie waren alle drei still: nichts wurde rot, nichts fiel aus - es stand nur das
 * Falsche da. Deshalb stehen sie hier namentlich.
 * ============================================================================== */
{
  /* (1) Eine Rasse gilt nur fuer ihre Art. Gemessen: gespeicherte Rasse "dobermann",
   * danach auf Katze gewechselt -> Kopfzeile "Katze · Dobermann", Befundblock mit der DCM
   * des Dobermanns, und ueber normFuer das Achsenband des Dobermanns auf der Katze. */
  pruef('patRasse bekommt die Tierart uebergeben', /function patRasse\(f, sp\)/.test(code));
  pruef('und verwirft eine Rasse fremder Art', /if\(b && sp && b\.sp && b\.sp!==sp\) b=null;/.test(code));
  pruef('das Verwerfen wird dem Untersucher gesagt, nicht verschwiegen',
    /rasseArtFremd/.test(code) && /gehört zu einer anderen Tierart/.test(code));
  pruef('der Aufruf reicht die Art wirklich weiter', /patRasse\(f, sp\)/.test(code));
}
{
  /* (2) Der Handmodus uebernimmt Tierart und Gewicht, wenn nichts eingetragen ist.
   * Vorher blieb sp='' , obwohl das Feld sichtbar "Hund" zeigte - bewertungsArt() fiel
   * dann still auf die Art des Feeds zurueck, und der Ausdruck druckte "Patient". */
  pruef('der Handmodus faellt auf die Art des Feeds zurueck', /var hSp=P\.sp\|\|f\.sp\|\|'';/.test(code));
  pruef('und auf dessen Gewicht', /var hWt=\(P\.wt!==''/.test(code));
  pruef('sp wird aus hSp gefuellt, nicht aus P.sp allein', /sp:hSp,/.test(code));
  pruef('wt ebenso', /wt:hWt,/.test(code));
  /* Ein Gewicht von 0 ist eine Angabe, kein Fehlen - deshalb darf hier kein || stehen. */
  pruef('ein Gewicht von 0 wird nicht als fehlend behandelt', /wt:\(f\.wt!=null\?f\.wt:''\)/.test(code));
}
{
  /* (3) Der Vorgabewert von 10 kg darf nicht als Messung durchgehen. */
  pruef('das Gewicht wird nur weitergereicht, wenn es gesetzt wurde',
    /wt:\(state\.wtGesetzt\?state\.wt:null\)/.test(code));
  pruef('und die Marke wird beim Eintragen gesetzt', /state\.wtGesetzt=true;/.test(code));
  const seam = fs.readFileSync(path.join(__dirname, 'web-fern-seam.js'), 'utf8');
  pruef('auch im Fern-Seam', /state\.wtGesetzt=!!\(p&&p\.weightKg>0\)/.test(seam));
}
{
  /* (4) Der Patientenwechsel leert die Handeintraege - sonst schlaegt eine Eingabe von
   * gestern den heutigen Patienten. */
  pruef('ein Patientenwechsel wird erkannt', /function patWechselPruefen/.test(code));
  pruef('und im Messtakt geprueft', /patWechselPruefen\(M\.feed\)/.test(code));
  pruef('die Angaben zur UNTERSUCHUNG bleiben dabei stehen',
    !/P\.lagerung=''/.test(code) && !/P\.kabelnorm=''/.test(code) && !/P\.untersucher=''/.test(code));
  pruef('und der Nutzer erfaehrt davon', /die von Hand eingetragenen Angaben wurden geleert/.test(code));
}
pruef('und den Jahreswert in den Regelkontext', /alterJahre:\(d0&&d0\.alterObj\)\?d0\.alterObj\.dezimalJahre:null/.test(code));
{
  /* Die gerechnete Zeile MUSS immer existieren, auch leer - sonst schweigt das Feld beim
   * Tippen, bis das Blatt neu gezeichnet wird. Im Browser gemessen. */
  pruef('die Ausgabezeile ist ein festes Element', /id="pAltOut"/.test(code) && /id="pAltHint"/.test(code));
  pruef('sie wird beim Zeichnen gefuellt', /\n\s*pAlterZeile\(\);\s*\n\}/.test(code));
}

/* ================================================================================
 * 4. RASSEHINWEISE IM BEFUND
 * ============================================================================== */
block('4. Rassehinweise');
pruef('der Block wird gebaut', /function rasseHerzBlock/.test(code));
{
  /* ER MUSS IN BEIDE ZWEIGE. Der zweite ist der Kardio-Termin: kein Geraet, kein Streifen,
   * alles von Hand eingetragen. Wer dort Rasse und Alter eingibt und nichts sieht, haelt
   * die Eingabe zu Recht fuer wirkungslos. */
  /* Die DEFINITION zaehlt nicht mit: "function rasseHerzBlock(){" enthaelt ebenfalls
   * "rasseHerzBlock()". Ohne dieses Abziehen war die Pruefung gruen, obwohl einer der
   * beiden Aufrufe entfernt war - beim absichtlichen Zerbrechen aufgefallen. */
  const treffer = (code.match(/rasseHerzBlock\(\)/g) || []).length
    - (code.match(/function rasseHerzBlock\(\)/g) || []).length;
  pruef('er erscheint an ZWEI Stellen (mit und ohne auswertbaren Streifen)', treffer >= 2,
    treffer + ' Aufrufe');
  pruef('auch im Zweig ohne brauchbaren Streifen',
    /host\.innerHTML=htmlT\+rasseHerzBlock\(\)/.test(code));
}
pruef('er zaehlt NICHT in die Befundzahl mit',
  !/verdacht\.push\([^)]*rasse/i.test(code) && /var kritisch=verdacht\.filter/.test(code));
pruef('die Ueberschrift sagt, dass es kein Befund an diesem Tier ist',
  /kein Befund an diesem Tier/.test(code));
pruef('ohne Alter wird der Hinweis NICHT unterdrueckt, sondern gekennzeichnet',
  /ohne Altersangabe nicht prüfbar/.test(code));
pruef('ein Hinweis ausserhalb des Altersfensters bleibt sichtbar',
  /Der Hinweis bleibt stehen, damit er nicht übersehen wird/.test(code));
pruef('der Ausdruck traegt den Rassehinweis mit', /function rasseHerzZeile/.test(code) && /rhTxt=rasseHerzZeile\(pd\)/.test(code));
pruef('und er ist auf zwei Zeilen gedeckelt (Platz vor dem Haftungshinweis)',
  /doc\.text\(rhZ\.slice\(0,2\)/.test(code));

/* ================================================================================
 * 5. RASSEGRUPPE STATT NAMENSMUSTER
 * ============================================================================== */
block('5. Rassegruppe im Regelkontext');
pruef('die Gruppenzugehoerigkeit kommt aus dem Katalog', /function patGruppe/.test(code));
pruef('mit dem Namensmuster nur als Rueckfall',
  /if\(d\.breed && d\.breed\.groups\) return d\.breed\.groups\.indexOf\(gruppe\)>=0;/.test(code));
pruef('windhund wird darueber bestimmt', /windhund:patGruppe\('sighthound'/.test(code));
{
  /* Das alte, allein namensbasierte Muster darf nicht mehr die Entscheidung treffen. */
  pruef('nicht mehr allein ueber den Rassenamen',
    !/windhund:\(function\(\)\{ var b=String/.test(code));
}

/* ================================================================================
 * 6. LADEREIHENFOLGE
 * Beide Module schlagen zur Laufzeit im Katalog nach. Stuenden sie davor, waere das kein
 * Ladefehler - die Hinweise blieben nur immer leer.
 * ============================================================================== */
block('6. Ladereihenfolge');
{
  const iKat = src.indexOf('shared/breed-katalog.js');
  const iAlt = src.indexOf('shared/patient-alter.js');
  const iRh = src.indexOf('shared/rasse-herz.js');
  pruef('breed-katalog.js wird geladen', iKat > 0);
  pruef('patient-alter.js wird geladen', iAlt > 0);
  pruef('rasse-herz.js wird geladen', iRh > 0);
  pruef('rasse-herz.js steht NACH breed-katalog.js', iRh > iKat, iRh + ' vs ' + iKat);
}
{
  /* Und der Bau der Web-App muss sie mitkopieren - sonst laedt die Fern-App zwei Dateien,
   * die es dort nicht gibt, und beide Merkmale fallen still aus. */
  const bau = fs.readFileSync(path.join(__dirname, 'web-app-bauen.js'), 'utf8');
  pruef('der Web-App-Bau kopiert patient-alter.js mit', /shared\/patient-alter\.js/.test(bau));
  pruef('der Web-App-Bau kopiert rasse-herz.js mit', /shared\/rasse-herz\.js/.test(bau));
  pruef('und prueft die Ladereihenfolge nach dem Bau', /Rasse-Herz nach dem Katalog geladen/.test(bau));
}

/* ================================================================================
 * 7. HANDYANSICHT — die neuen Felder duerfen nicht aus dem Rahmen
 * Vier Fehlerklassen dieses Projekts hatten dieselbe Ursache: min-width:auto.
 * ============================================================================== */
block('7. Handyansicht');
pruef('die Zweierzeile der Alterseingabe kann schrumpfen',
  /\.ekg-patbox \.zwei>input\{flex:1 1 0;min-width:0\}/.test(src));
pruef('die Rassetrefferliste sprengt die Spalte nicht',
  /\.ekg-patbox \.breed-pop\{min-width:0;width:100%;max-width:100%/.test(src));
/* GEMESSEN, NICHT VERMUTET (09.08.2026, 375 px Fensterbreite): ohne diese drei Zeilen
 * reichten die Trefferzeilen bis 650 px, weil .bp-n und .bp-m beide white-space:nowrap
 * tragen und ein Flex-Kind von Haus aus min-width:auto hat. Die Seite lief nicht ueber -
 * die Liste rollte seitwaerts, und der Rassename war nur durch Scrollen zu lesen. */
pruef('die Trefferzeile selbst kann schrumpfen (Name)',
  /\.ekg-patbox \.breed-pop \.bp-n\{flex:1 1 auto;min-width:0\}/.test(src));
pruef('die Trefferzeile selbst kann schrumpfen (Zusatz)',
  /\.ekg-patbox \.breed-pop \.bp-m\{flex:0 1 auto;min-width:0;overflow:hidden/.test(src));
pruef('und die Zeile hat kein min-width:auto mehr',
  /\.ekg-patbox \.breed-pop \.bp-i\{min-width:0\}/.test(src));

/* ================================================================================
 * 8. DAS DREHBARE 3D-MODELL
 * ============================================================================== */
block('8. 3D-Modell');
pruef('das Modul wird geladen', /shared\/tier3d\.js/.test(src));
{
  const iKat = src.indexOf('shared/breed-katalog.js'), i3d = src.indexOf('shared/tier3d.js');
  pruef('tier3d.js steht bei den uebrigen gemeinsamen Modulen', i3d > 0 && i3d > iKat);
}
pruef('der Web-App-Bau kopiert es mit',
  /shared\/tier3d\.js/.test(fs.readFileSync(path.join(__dirname, 'web-app-bauen.js'), 'utf8')));
pruef('es gibt einen Block dafuer', /function modell3dBlock/.test(code));
pruef('und er wird in der Anlegeseite eingesetzt', /modell3dBlock\(sp\)\)\+/.test(code));
pruef('das Modell wird nach jedem Neuzeichnen neu gebunden', /m3dBinde\(d\.sp\|\|''\)/.test(code));
{
  /* WO ES KEIN MODELL GIBT, DARF KEINES ERSCHEINEN. Eine Hundevorlage fuer einen Vogel
   * waere eine Anleitung zu einer Ableitung, die so niemand macht. */
  pruef('ohne Modell fuer diese Art bleibt der Block leer',
    /if\(!T\|\|!T\.hatModell\(sp\)\) return '';/.test(code));
}
{
  /* touch-action:none ist PFLICHT, nicht Kosmetik: ohne sie scrollt das Handy die Seite,
   * sobald man auf der Leinwand zieht - das Modell laesst sich dann gar nicht drehen.
   * Im Browser bei 375 px nachgemessen (09.08.2026). */
  pruef('die Leinwand nimmt Ziehgesten an, statt die Seite zu scrollen',
    /\.m3d-cv\{[^}]*touch-action:none/.test(src));
  pruef('sie kann nicht breiter werden als die Spalte',
    /\.m3d-cv\{display:block;width:100%;max-width:100%/.test(src));
  pruef('die Kopfzeile darf umbrechen (sonst haelt sie die Spalte auf)',
    /\.m3d-kopf\{[^}]*flex-wrap:wrap;min-width:0/.test(src));
}
pruef('der Nickwinkel ist begrenzt (sonst kippt das Modell weg)',
  /Math\.max\(-80,Math\.min\(80,/.test(code));
pruef('es wird gesagt, dass verdeckte Klemmen ausgegraut sind',
  /Verdeckte Klemmen sind/.test(code));
pruef('und dass das Modell stilisiert ist, kein Abbild',
  /stilisiertes<\/b> anatomisches/.test(code) || /stilisiertes\b/.test(code));

/* ================================================================================ */
console.log('\n===============================================================');
if (fehler.length) {
  console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
  fehler.forEach((f) => console.log('   ✗ ' + f));
  console.log('===============================================================\n');
  process.exit(1);
}
console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
console.log('===============================================================\n');
