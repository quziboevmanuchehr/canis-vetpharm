'use strict';
/*
 * update-signatur-test.js — der Riegel, der den Update-Kanal an die eigene Freigabe bindet.
 *
 * WAS HIER BEWACHT WIRD, in einem Satz:
 * Ein Praxis-PC laedt aus dem Netz ein Paket und FUEHRT ES AUS - neben einem narkotisierten
 * Tier. Bis zum 13.08.2026 belegte nur eine Pruefsumme, dass die Zip unterwegs nicht
 * beschaedigt wurde; sie stand in DERSELBEN oeffentlichen Datei wie die Zip selbst. Wer das
 * GitHub-Konto uebernimmt, aendert beide in einem Zug. Die Signatur beantwortet die andere
 * Frage: stammt das Paket von dem, der dieses Programm ausliefert?
 *
 * JEDER PRUEFPUNKT HIER IST EIN ANGRIFFSWEG, kein Formalismus. Wer einen davon rot macht,
 * hat den Kanal wieder geoeffnet.
 *
 * Start: node tools/update-signatur-test.js
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const sig = require('../updater/signatur.js');

const ROOT = path.join(__dirname, '..');
let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Signatur des Update-Kanals\n');

/* Ein Wegwerf-Paar fuer die Pruefungen. Der ECHTE private Schluessel wird hier nie
 * angefasst - ein Test, der ihn braucht, waere ein Test, der ihn irgendwann ausgibt. */
const A = crypto.generateKeyPairSync('ed25519');
const privA = A.privateKey.export({ type: 'pkcs8', format: 'pem' });
const pubA = A.publicKey.export({ type: 'spki', format: 'pem' });
const B = crypto.generateKeyPairSync('ed25519');
const privB = B.privateKey.export({ type: 'pkcs8', format: 'pem' });

const V = '1.16.0';
const SHA = crypto.createHash('sha256').update('irgendein Paketinhalt').digest('hex');

/* ================================================================================
 * 1. Der gute Fall
 * ============================================================================== */
block('1. eine echte Signatur wird angenommen');
const echt = sig.signiere(V, SHA, privA);
pruef('die eigene Signatur wird anerkannt', sig.pruefe(V, SHA, echt, pubA).ok === true);
pruef('sie ist 64 Byte lang (Ed25519)', Buffer.from(echt, 'base64').length === 64);
pruef('zweimal signieren ergibt dasselbe (Ed25519 ist deterministisch)',
  sig.signiere(V, SHA, privA) === echt);

/* ================================================================================
 * 2. DIE ANGRIFFSWEGE — jeder einzeln
 * ============================================================================== */
block('2. was abgewiesen werden MUSS');

/* (a) Fremder Schluessel: der Angreifer signiert mit seinem eigenen. */
const fremd = sig.signiere(V, SHA, privB);
pruef('eine Signatur mit FREMDEM Schluessel wird abgewiesen',
  sig.pruefe(V, SHA, fremd, pubA).ok === false);

/* (b) Anderer Inhalt bei gleicher Nummer: die Zip wurde ausgetauscht. */
const andereZip = crypto.createHash('sha256').update('BOESER Paketinhalt').digest('hex');
pruef('dieselbe Signatur gilt NICHT fuer eine andere Zip',
  sig.pruefe(V, andereZip, echt, pubA).ok === false);

/* (c) DER WICHTIGSTE FALL - und der Grund, warum die Version mitsigniert wird:
 * ein ALTES, echt signiertes Paket unter einer HOEHEREN Nummer neu anbieten. Wuerde nur
 * der sha256 signiert, ginge das durch: Signatur gueltig, Pruefsumme gueltig - und jede
 * Station "aktualisiert" sich auf einen alten Stand mit laengst behobenen Fehlern. Weil
 * die Nummer danach hoeher steht, bekaeme sie die echte Fassung nie wieder angeboten. */
pruef('ein echtes Paket unter FALSCHER Versionsnummer wird abgewiesen',
  sig.pruefe('9.9.9', SHA, echt, pubA).ok === false,
  'sonst liesse sich ein alter Stand als neuer unterschieben');

/* (d) Weglassen. Ein Riegel, den man durch Weglassen umgeht, ist keiner. */
pruef('eine FEHLENDE Signatur wird abgewiesen', sig.pruefe(V, SHA, null, pubA).ok === false);
pruef('eine leere Signatur wird abgewiesen', sig.pruefe(V, SHA, '', pubA).ok === false);
pruef('ein fehlender Schluessel wird abgewiesen', sig.pruefe(V, SHA, echt, null).ok === false);

/* (e) Unfug statt Signatur. */
['Hallo', 'AAAA', '!!!nicht base64!!!', Buffer.alloc(64).toString('base64')].forEach((s) => {
  pruef('Unfug als Signatur wird abgewiesen: "' + String(s).slice(0, 14) + '"',
    sig.pruefe(V, SHA, s, pubA).ok === false);
});
pruef('ein unlesbarer Schluessel wird abgewiesen',
  sig.pruefe(V, SHA, echt, 'kein PEM').ok === false);

/* (f) Kaputte Eingaben duerfen nicht werfen - der Updater laeuft auf dem Praxis-PC. */
[[null, SHA], [V, null], ['', ''], ['1.2', SHA], [V, 'zu kurz'], ['1.2.3.4', SHA]].forEach(([v, h]) => {
  let warf = false, r = null;
  try { r = sig.pruefe(v, h, echt, pubA); } catch (_) { warf = true; }
  pruef('pruefe(' + JSON.stringify(v) + ', ' + JSON.stringify(String(h).slice(0, 10)) + ') wirft nicht',
    !warf && r && r.ok === false);
});

/* ================================================================================
 * 3. Die Aussage bindet Version UND Inhalt
 * ============================================================================== */
block('3. was genau signiert wird');
const a1 = sig.aussage('1.16.0', SHA).toString('utf8');
pruef('die Aussage traegt das Zweck-Praefix', a1.indexOf('vetstation-update-v1') === 0,
  'ohne Praefix koennte eine Signatur fuer einen anderen Zweck durchgehen');
pruef('sie enthaelt die Version', a1.indexOf('1.16.0') > 0);
pruef('sie enthaelt die Pruefsumme', a1.indexOf(SHA) > 0);
pruef('Gross- und Kleinschreibung der Pruefsumme spielt keine Rolle',
  sig.aussage(V, SHA.toUpperCase()).equals(sig.aussage(V, SHA)),
  'sonst scheitert die Freigabe an Get-FileHash, das GROSS schreibt');

/* ================================================================================
 * 4. Der Updater benutzt das auch wirklich
 * ============================================================================== */
block('4. der Updater prueft wirklich');
{
  const q = fs.readFileSync(path.join(ROOT, 'updater/updater.js'), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, ' ');       /* Kommentare raus - sonst prueft man Prosa */
  pruef('updater.js laedt die Signaturvorschrift', /require\('\.\/signatur\.js'\)/.test(q));
  pruef('updater.js prueft die Signatur vor dem Stagen', /signaturPruefung\(/.test(q));
  /* DIE PRUEFSUMME DARF NICHT MEHR OPTIONAL SEIN. Bis 1.15.0 stand dort `if (info.sha256)` -
   * ein Manifest ohne das Feld lief voellig ungeprueft durch. */
  pruef('ein Manifest OHNE Pruefsumme wird abgewiesen', /if \(!info\.sha256\)/.test(q),
    'frueher: if (info.sha256) - Weglassen umging die Pruefung');
  pruef('bei ungueltiger Signatur wird NICHT gestaged',
    /if \(!su\.ok\)[\s\S]{0,200}return \{ ok: false/.test(q));
  /* REIHENFOLGE NUR INNERHALB VON apply() MESSEN. Der erste Entwurf dieser Pruefung suchte
   * das erste Vorkommen von 'update-pending.json' in der GANZEN Datei - und traf damit das
   * LESEN in pendingUpdate() (Zeile 113), nicht das Schreiben (Zeile 186). Sie schlug fehl,
   * obwohl die Reihenfolge im Code stimmte. Ein Test, der die falsche Stelle misst, meldet
   * einen Fehler, den es nicht gibt - und kostet genauso viel Zeit wie ein echter. */
  const aStart = q.indexOf('async function apply(');
  const inApply = q.slice(aStart);
  const iSig = inApply.indexOf('signaturPruefung(');
  const iStage = inApply.indexOf("'update-pending.json'");
  pruef('in apply() steht die Pruefung VOR dem Schreiben des Markers',
    aStart > 0 && iSig > 0 && iStage > 0 && iSig < iStage,
    'sonst gilt ein abgelehntes Paket trotzdem als bereitgestellt');
}

/* ================================================================================
 * 4b. DER EIGENTLICHE BEWEIS: ein gefaelschter Kanal wird wirklich abgewiesen
 *
 * Die Pruefungen oben lesen Quelltext. Das findet eine umgestellte Zeile, aber es beweist
 * nicht, dass ein gefaelschtes Paket am Ende auch WIRKLICH nicht eingespielt wird - genau
 * das ist aber die Zusage. Deshalb hier ein echter Durchlauf: ein eigener kleiner Webserver
 * spielt den Kanal, eine Kopie des Updaters spielt die Station, und dann wird nachgesehen,
 * ob ein Marker entstanden ist. Kein Netz, keine echte Freigabe, kein echter Schluessel.
 * ============================================================================== */
block('4b. gefaelschter Kanal, echter Updater');
{
  const http = require('http');
  const os = require('os');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vetstation-sig-'));
  const zipInhalt = Buffer.from('ein Paket, das es nicht sein darf');
  const zipSha = crypto.createHash('sha256').update(zipInhalt).digest('hex');

  /* Eine Station aufbauen: updater/ kopieren, aber mit UNSEREM Wegwerf-Schluessel. */
  fs.mkdirSync(path.join(tmp, 'updater'), { recursive: true });
  fs.mkdirSync(path.join(tmp, 'data'), { recursive: true });
  ['updater.js', 'signatur.js'].forEach((f) =>
    fs.copyFileSync(path.join(ROOT, 'updater', f), path.join(tmp, 'updater', f)));
  fs.writeFileSync(path.join(tmp, 'updater', 'release-key.pub'), pubA);

  const faelle = [
    { n: 'gueltige Signatur', sig: sig.signiere('9.9.9', zipSha, privA), sha: zipSha, soll: true },
    { n: 'FREMD signiert', sig: sig.signiere('9.9.9', zipSha, privB), sha: zipSha, soll: false },
    { n: 'gar keine Signatur', sig: null, sha: zipSha, soll: false },
    { n: 'gar keine Pruefsumme', sig: sig.signiere('9.9.9', zipSha, privA), sha: null, soll: false },
    { n: 'Signatur einer ANDEREN Version', sig: sig.signiere('1.0.0', zipSha, privA), sha: zipSha, soll: false },
  ];

  let i = 0;
  const server = http.createServer((req, res) => {
    const f = faelle[i];
    if (req.url === '/zip') { res.writeHead(200); return res.end(zipInhalt); }
    const m = { app: '9.9.9', zipUrl: 'http://127.0.0.1:' + server.address().port + '/zip', notes: 'Test' };
    if (f.sha) m.sha256 = f.sha;
    if (f.sig) m.sigEd25519 = f.sig;
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(m));
  });

  const fertig = new Promise((resolve) => {
    server.listen(0, '127.0.0.1', async () => {
      const port = server.address().port;
      for (i = 0; i < faelle.length; i++) {
        const f = faelle[i];
        /* version.json je Fall neu schreiben und den Updater frisch laden - er liest sie beim Aufruf. */
        fs.writeFileSync(path.join(tmp, 'updater', 'version.json'), JSON.stringify({
          app: '1.0.0', channel: 'stable', manifestUrl: 'http://127.0.0.1:' + port + '/manifest',
        }));
        const marker = path.join(tmp, 'data', 'update-pending.json');
        try { fs.unlinkSync(marker); } catch (_) {}
        delete require.cache[require.resolve(path.join(tmp, 'updater', 'updater.js'))];
        delete require.cache[require.resolve(path.join(tmp, 'updater', 'signatur.js'))];
        const u = require(path.join(tmp, 'updater', 'updater.js'));
        let r = null;
        try { r = await u.apply(); } catch (e) { r = { ok: false, msg: 'Ausnahme: ' + e.message }; }
        const gestaged = fs.existsSync(marker);
        if (f.soll) {
          pruef('"' + f.n + '" wird angenommen und gestaged', r && r.ok === true && gestaged,
            r ? String(r.msg).slice(0, 80) : 'kein Ergebnis');
        } else {
          pruef('"' + f.n + '" wird ABGEWIESEN', r && r.ok === false,
            r ? String(r.msg).slice(0, 80) : 'kein Ergebnis');
          pruef('   und es entsteht KEIN Marker', !gestaged,
            'ein abgelehntes Paket darf nicht als bereitgestellt gelten');
        }
      }
      server.close(() => resolve());
    });
  });
  /* Der Test ist synchron aufgebaut; dieser eine Abschnitt wartet ausdruecklich. */
  module.exports = fertig.then(() => {
    fs.rmSync(tmp, { recursive: true, force: true });
    abschluss();
  });
}

/* ================================================================================
 * 5. Der oeffentliche Schluessel ist da - der private NICHT
 * ============================================================================== */
block('5. Schluessel am richtigen Ort');
{
  const pubPfad = path.join(ROOT, 'updater/release-key.pub');
  pruef('updater/release-key.pub liegt im Repo', fs.existsSync(pubPfad));
  if (fs.existsSync(pubPfad)) {
    const pem = fs.readFileSync(pubPfad, 'utf8');
    pruef('er ist ein lesbarer oeffentlicher Ed25519-Schluessel',
      crypto.createPublicKey(pem).asymmetricKeyType === 'ed25519');
    pruef('er enthaelt KEINEN privaten Teil', !/PRIVATE KEY/.test(pem),
      'ein privater Schluessel im Paket waere das Ende der ganzen Absicherung');
    console.log('    Fingerabdruck: ' + sig.fingerabdruck(pem));
  }
  /* Kein privater Schluessel im Baum - weder eingecheckt noch herumliegend. */
  const verdaechtig = [];
  (function suche(d, tiefe) {
    if (tiefe > 3) return;
    let e = []; try { e = fs.readdirSync(d, { withFileTypes: true }); } catch (_) { return; }
    e.forEach((x) => {
      if (x.name === 'node_modules' || x.name === '.git' || x.name === 'dist') return;
      const p = path.join(d, x.name);
      if (x.isDirectory()) return suche(p, tiefe + 1);
      if (!/\.(pem|key)$/i.test(x.name)) return;
      let t = ''; try { t = fs.readFileSync(p, 'utf8'); } catch (_) { return; }
      if (/PRIVATE KEY/.test(t)) verdaechtig.push(path.relative(ROOT, p));
    });
  })(ROOT, 0);
  pruef('kein privater Schluessel liegt im Projektbaum', verdaechtig.length === 0,
    verdaechtig.join(', '));
}

/* ================================================================================
 * Der Abschluss laeuft ERST, wenn der Durchlauf aus 4b fertig ist - sonst zaehlte er die
 * Pruefungen des gefaelschten Kanals gar nicht mit und die Datei waere gruen, bevor der
 * wichtigste Teil ueberhaupt gelaufen ist.
 * ============================================================================== */
function abschluss() {
  console.log('\n===============================================================');
  if (fehler.length) {
    console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
    fehler.forEach((f) => console.log('   ✗ ' + f));
    console.log('===============================================================\n');
    process.exit(1);
  }
  console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
  console.log('===============================================================\n');
}
