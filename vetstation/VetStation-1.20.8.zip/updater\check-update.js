'use strict';
/*
 * check-update.js — CLI-Hülle um updater/updater.js (§13).
 *   node updater/check-update.js            -> prüft, ob eine neuere App-Version vorliegt (nur melden)
 *   node updater/check-update.js --apply    -> wendet an (git pull) bzw. stagt eine geprüfte Zip
 * In der Station geschieht dasselbe komfortabel über Admin ▸ 🔄 Aktualisieren.
 */
const updater = require('./updater');

(async function () {
  const info = await updater.check();
  console.log('VetStation Update-Check — lokale App-Version:', info.current, '(' + info.channel + ')');
  /* Hier stand "Klinische Daten: aktualisieren sich zur Laufzeit automatisch vom Live-Site".
   * Falsch (Befund 17.08.2026): der Lader dafuer wird von keiner Seite geladen. Dosen aendern
   * sich nur mit einem Update. Die Adresse bleibt in der Ausgabe, weil sie in version.json
   * steht und sonst niemand merkt, dass dort ein unbenutztes Feld liegt. */
  console.log('Klinische Daten: stecken IM PAKET und aendern sich nur mit einem Update.');
  console.log('  (unbenutztes Feld clinicalDataLive in version.json:', info.clinicalDataLive, ')');
  if (info.pending) console.log('Hinweis: Update', info.pending.version, 'ist bereits geladen und wird beim nächsten Start angewendet.');
  if (!info.manifestUrl) { console.log(info.msg || 'Kein App-Shell-Manifest konfiguriert.'); return; }
  if (!info.reachable) { console.log(info.msg || 'Manifest nicht erreichbar -> App-Shell bleibt.'); return; }
  if (!info.updateAvailable) { console.log('App-Shell ist aktuell (', info.latest, ').'); return; }

  console.log('NEUE App-Version verfügbar:', info.latest, '(lokal', info.current + ')');
  if (info.notes) console.log('Änderungen:', info.notes);
  if (process.argv.includes('--apply')) {
    const res = await updater.apply();
    console.log(res.ok ? '✓ ' + res.msg : '✗ ' + res.msg);
    if (res.log) console.log(res.log);
  } else {
    console.log('Zum Anwenden:  node updater/check-update.js --apply   (oder Admin ▸ Aktualisieren)');
  }
})();
