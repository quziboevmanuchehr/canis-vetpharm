'use strict';
/*
 * ekg-literatur-bauen.js — erzeugt ui/shared/ekg-literatur.js aus der Auswertung der
 * Fachbuecher, die der Nutzer am 10.08.2026 bereitgestellt hat.
 *
 * WARUM ERZEUGT UND NICHT VON HAND GESCHRIEBEN:
 * Es sind rund tausend Einzelaussagen aus fuenf Werken mit jeweils Seitenzahl. Sie von Hand
 * abzutippen waere eine Fehlerquelle mit Zufallszuender — genau wie schon bei
 * ui/shared/ekg-befunde.js. Die Quelldaten liegen als JSON unter
 * docs/EKG-LITERATUR-2026-08.json und bleiben im Repo, damit sich das Ergebnis jederzeit
 * nachbauen und nachpruefen laesst.
 *
 * WAS DIESE DATEI NICHT TUT: Sie erzeugt keine REGELN. Die Auswertung behauptet weiterhin
 * nur, was sie selbst misst (BEFUNDREGELN in ui/app/index.html). Hier entsteht ein
 * NACHSCHLAGEWERK: durchsuchbare, belegte Saetze mit Buch und Seite, die der Untersucher
 * im EKG-Fenster aufschlagen kann, ohne das Buch zu holen.
 *
 * Aufruf:  node tools/ekg-literatur-bauen.js
 *          node tools/ekg-literatur-bauen.js --aus <journal.jsonl>   (Quelldaten neu ziehen)
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
/* Die Quelldaten liegen unter docs/ekg-quellen/ und NICHT unter docs/ - genau wie
 * docs/rassen-quellen. Grund (gemessen 10.08.2026): make-dist.ps1 packt docs/ mit ins
 * Update-Paket, und 820 KB Rohdaten haetten es ueber die Grenze getrieben, die
 * tools/paket-test.js bewacht. Die Station liest nur die fertige Datei
 * ui/shared/ekg-literatur.js; die Rohdaten gehoeren ins Repo, damit das Ergebnis
 * reproduzierbar bleibt, aber nicht auf den Praxis-PC. */
const QUELLE = path.join(WURZEL, 'docs', 'ekg-quellen', 'literatur-2026-08.json');
const ZIEL = path.join(WURZEL, 'ui', 'shared', 'ekg-literatur.js');
/* Zweites Ziel seit 15.08.2026 — Begruendung im Kopf der erzeugten Datei weiter unten.
 * Kurz: ZIEL wird nicht mehr oeffentlich ausgeliefert, die Warnungen darin muessen es aber. */
const ZIEL_WARN = path.join(WURZEL, 'ui', 'shared', 'dosis-warnungen.js');

/* Themen in der Reihenfolge, in der ein Untersucher sie sucht: erst wie man aufnimmt,
 * dann was man misst, dann was daraus folgt. */
const THEMEN = [
  ['aufnahmetechnik', 'Aufnahme und Technik'],
  ['lagerung', 'Lagerung und Elektroden'],
  ['kalibrierung', 'Eichung und Verstärkung'],
  ['papier-raster', 'Papier, Raster, Vorschub'],
  ['filter', 'Filter'],
  ['artefakte', 'Artefakte erkennen'],
  ['messgroessen', 'Messgrößen und Vorgehen'],
  ['normwerte', 'Normwerte'],
  ['formel', 'Formeln'],
  ['achse', 'Elektrische Herzachse'],
  ['p-welle', 'P-Welle'],
  ['qrs', 'Kammerkomplex'],
  ['st-t', 'ST-Strecke und T-Welle'],
  ['qt', 'QT-Zeit'],
  ['rhythmus-sinus', 'Sinusrhythmus und -arrhythmie'],
  ['rhythmus-supraventrikulaer', 'Supraventrikuläre Rhythmusstörungen'],
  ['rhythmus-ventrikulaer', 'Ventrikuläre Rhythmusstörungen'],
  ['block-av', 'AV-Blockierungen'],
  ['block-sa', 'SA-Block und Sinusarrest'],
  ['schenkelblock', 'Schenkelblöcke'],
  ['praeexzitation', 'Präexzitation'],
  ['schrittmacher', 'Schrittmacher'],
  ['holter-24h', '24-Stunden-EKG'],
  ['kammergroesse', 'Vergrößerung von Vorhof und Kammer'],
  ['elektrolyt', 'Elektrolyte'],
  ['medikament', 'Medikamente und Antiarrhythmika'],
  ['perikard', 'Perikard'],
  ['echo', 'Echokardiografie'],
  ['befundaufbau', 'Aufbau eines Befundes'],
  /* Diese beiden Kennungen stammen aus dem Feld "umsetzbar" der Auswertung und sind bei
   * einzelnen Abschnitten im Themenfeld gelandet. Sie bekommen einen lesbaren Namen, statt
   * unter ihrer Rohkennung im Fenster zu stehen. */
  ['bedienung', 'Bedienung'],
  ['darstellung-druck', 'Darstellung und Ausdruck'],
  ['sonstiges', 'Sonstiges'],
];

function ausJournal(datei) {
  const zeilen = fs.readFileSync(datei, 'utf8').trim().split('\n');
  const alle = [];
  zeilen.forEach((z) => {
    let r; try { r = JSON.parse(z); } catch (e) { return; }
    if (!r || r.type !== 'result' || !r.result || !Array.isArray(r.result.fakten)) return;
    const quelle = String(r.result.quelle || '').replace(/\s+/g, ' ').trim();
    r.result.fakten.forEach((f) => {
      /* Einzelne Auswerter haben Schreibvarianten geliefert ("sonstige" statt "sonstiges").
       * Ohne diese Zuordnung stuende die Rohkennung als Themenname im Fenster. */
      let thema = String(f.thema || 'sonstiges').trim().toLowerCase();
      if (thema === 'sonstige' || thema === 'allgemein' || !thema) thema = 'sonstiges';
      alle.push({
        thema: thema,
        text: String(f.aussage || '').replace(/\s+/g, ' ').trim(),
        zahlen: String(f.zahlen || '').replace(/\s+/g, ' ').trim(),
        seite: String(f.seite || '').replace(/\s+/g, ' ').trim(),
        art: String(f.umsetzbar || '').trim(),
        werk: quelle,
      });
    });
  });
  return alle;
}

/*
 * ==========================================================================================
 * DAS WERK FOLGT AUS DER BUCHSEITE, NICHT AUS DER QUELLENANGABE (berichtigt 15.08.2026)
 *
 * BEFUND: die Etiketten waren grossflaechig falsch. "Praxis der Kardiologie: 24-Stunden-EKG"
 * trug 101 Stellen ueber die Buchseiten 19 bis 448 - nur 10 davon lagen im wirklichen Bereich
 * dieses Kapitels (179-202), 65 stammten aus dem Antiarrhythmika-Kapitel (429-436).
 * "Referenzwerte Katze" streute ueber 95-467.
 *
 * URSACHE: ein Auswerter bearbeitete MEHRERE Kapiteldateien und meldete dafuer EINE
 * Quellenangabe - eine davon sagt woertlich "Vier Dateien: 95 Echokardiografie ...".
 * kurzWerk() klebte daraus per Regex ein einziges Werk. Die SEITENZAHLEN waren die ganze Zeit
 * richtig; nur der Name daneben war es nicht.
 *
 * WAS DAS ANGERICHTET HAT: jede Quellenangabe im Literaturfenster fuehrte an diesen Stellen
 * in ein falsches Kapitel. Und es hat mich am 15.08.2026 zu dem Fehlschluss verleitet, das
 * Antiarrhythmika-Kapitel sei noch gar nicht ausgewertet - ich hatte nach dem WERK gesucht
 * statt nach den Seiten und haette es beinahe ein zweites Mal geerntet.
 *
 * DIE BERICHTIGUNG ist deterministisch: "Praxis der Kardiologie Hund und Katze" ist EIN Buch,
 * seine Kapitel liegen auf bekannten Seitenbereichen. Aus der Buchseite folgt das Kapitel
 * eindeutig. Fuer die anderen Werke bleibt die Quellenangabe massgeblich - sie sind je ein
 * eigenes Buch und haben keine Kapitelbereiche in dieser Zaehlung.
 * ========================================================================================== */
const PK_KAPITEL = [
  [42, 138, 'Untersuchung und Bildgebung'],
  [139, 178, 'Anfertigung des EKGs'],
  [179, 202, '24-Stunden-EKG'],
  [203, 252, 'Erworbene Erkrankungen des Myokards'],
  [253, 332, 'Angeborene Erkrankungen'],
  [333, 346, 'Herzrhythmusstoerungen'],
  [347, 358, 'Parasitaere und endokrine Herzerkrankungen'],
  [359, 391, 'Herzerkrankungen der Katze'],
  [392, 419, 'Erworbene Erkrankungen von Klappen und Perikard'],
  [420, 441, 'Therapie und Wirkstoffgruppen'],
  [442, 447, 'Abkuerzungen und Formeln'],
  [448, 460, 'Referenzwerte Hund'],
  [461, 467, 'Referenzwerte Katze'],
];
function pkKapitel(seite) {
  for (let i = 0; i < PK_KAPITEL.length; i++) {
    if (seite >= PK_KAPITEL[i][0] && seite <= PK_KAPITEL[i][1]) return PK_KAPITEL[i][2];
  }
  return '';
}
/* Die Buchseite steht in mehreren Schreibweisen im Feld seite ("PDF 44 (Buch 232)",
 * "PDF-Seite 2 (Buchseite 430)", "Buchseite 433", "433"). */
function buchseiteAus(s) {
  const t = String(s || '');
  let m = t.match(/Buch(?:seite)?\s*(\d{2,3})/i);
  if (m) return +m[1];
  m = t.match(/(\d{2,3})\s*$/);
  if (m) return +m[1];
  m = t.match(/(\d{2,3})/);
  return m ? +m[1] : 0;
}

function kurzWerk(q, seite) {
  /* Aus der langen Quellenangabe des Auswerters einen kurzen, wiedererkennbaren Namen. */
  if (/EKG-Interpretation/i.test(q)) return 'EKG-Interpretation in der Kleintierpraxis';
  if (/kompakt/i.test(q)) return 'Kompakt Kleintierkardiologie';
  /* Alles Uebrige stammt aus "Praxis der Kardiologie Hund und Katze" - dort entscheidet die
   * Seite, nicht der Dateiname, unter dem der Auswerter mehrere Kapitel zusammengefasst hat. */
  const kap = pkKapitel(buchseiteAus(seite));
  if (kap) return 'Praxis der Kardiologie: ' + kap;
  if (/Anfertigung/i.test(q)) return 'Praxis der Kardiologie: Anfertigung des EKGs';
  if (/24-Stunden|Holter/i.test(q)) return 'Praxis der Kardiologie: 24-Stunden-EKG';
  if (/Antiarrhythmika/i.test(q)) return 'Praxis der Kardiologie: Antiarrhythmika';
  if (/Formeln/i.test(q)) return 'Praxis der Kardiologie: Formeln';
  if (/Referenzwerte.*Katze/i.test(q)) return 'Praxis der Kardiologie: Referenzwerte Katze';
  if (/Referenzwerte/i.test(q)) return 'Praxis der Kardiologie: Referenzwerte Hund';
  if (/Echokardiografie|2D/i.test(q)) return 'Praxis der Kardiologie: Echokardiografie';
  return q.slice(0, 60);
}

let fakten;
const argAus = process.argv.indexOf('--aus');
if (argAus > 0 && process.argv[argAus + 1]) {
  fakten = ausJournal(process.argv[argAus + 1]);
  fs.mkdirSync(path.dirname(QUELLE), { recursive: true });
  fs.writeFileSync(QUELLE, JSON.stringify(fakten, null, 1), 'utf8');
  console.log('Quelldaten geschrieben: ' + QUELLE + ' (' + fakten.length + ' Aussagen)');
} else {
  if (!fs.existsSync(QUELLE)) {
    console.error('Quelldatei fehlt: ' + QUELLE + '\nEinmalig mit --aus <journal.jsonl> erzeugen.');
    process.exit(1);
  }
  fakten = JSON.parse(fs.readFileSync(QUELLE, 'utf8'));
}

/* Dubletten heraus: zwei Auswerter derselben Seitenspanne finden dieselbe Aussage.
 * Verglichen wird der auf Kleinschreibung und Buchstaben reduzierte Text - Zeichensetzung
 * und Umbrueche unterscheiden sich sonst gerade genug, um jede Dublette durchzulassen. */
const gesehen = Object.create(null);
const sauber = [];
fakten.forEach((f) => {
  if (!f.text || f.text.length < 25) return;
  const schluessel = f.text.toLowerCase().replace(/[^a-zäöüß0-9]/g, '').slice(0, 110);
  if (gesehen[schluessel]) return;
  gesehen[schluessel] = true;
  const s = {
    thema: f.thema, text: f.text, zahlen: f.zahlen, seite: f.seite,
    werk: kurzWerk(f.werk, f.seite),
  };
  /*
   * WARNUNG — nur gesetzt, wo die VORLAGE SELBST falsch ist (14.08.2026).
   *
   * Am 14.08.2026 fiel beim Abgleich mit einem sechsten Werk auf, dass eine Stelle
   * Dopamin, Dobutamin und Nitroprussid mit "5 mg/kg/min" fuehrt. Das ist die gedruckte
   * Einheit des Buches und um den FAKTOR 1000 zu hoch (CliniPharm: 1-3 / 3-10 / ueber 10
   * ug/kg/min). Der Auswerter hatte das treu uebernommen und sogar vermerkt - richtig
   * zitiert und trotzdem gefaehrlich, denn hier schlaegt jemand am Patienten nach.
   *
   * Das Zitat wird NICHT stillschweigend umgeschrieben: dieses Nachschlagewerk lebt davon,
   * dass jede Aussage steht, wie sie im Buch steht. Stattdessen faehrt die Warnung mit und
   * die Oberflaeche zeigt sie ueber dem Satz. So sieht der Tierarzt beides - was das Buch
   * sagt und warum er ihm hier nicht folgen darf.
   */
  if (f.warnung) s.warnung = String(f.warnung).replace(/\s+/g, ' ').trim();
  sauber.push(s);
});

/* Nach Themenreihenfolge sortieren; unbekannte Themen hinten. */
const rang = Object.create(null);
THEMEN.forEach((t, i) => { rang[t[0]] = i; });
sauber.sort((a, b) => {
  const ra = rang[a.thema] == null ? 99 : rang[a.thema];
  const rb = rang[b.thema] == null ? 99 : rang[b.thema];
  if (ra !== rb) return ra - rb;
  return a.werk < b.werk ? -1 : (a.werk > b.werk ? 1 : 0);
});

const jetzt = new Date().toISOString().slice(0, 10);
const kopf = `/*
 * ekg-literatur.js — durchsuchbares Nachschlagewerk aus den Fachbuechern des Nutzers.
 *
 * ERZEUGT von tools/ekg-literatur-bauen.js am ${jetzt}. NICHT von Hand aendern —
 * die Quelldaten liegen in docs/EKG-LITERATUR-2026-08.json.
 *
 * WOHER: systematische Auswertung von fuenf Werken der Kleintierkardiologie
 * (EKG-Interpretation in der Kleintierpraxis Bd. 1-3; Kompakt Kleintierkardiologie;
 * Praxis der Kardiologie Hund und Katze — Anfertigung des EKGs, 24-Stunden-EKG,
 * Antiarrhythmika, Formeln, Referenzwerte, Echokardiografie). Jede Aussage traegt Buch
 * und Seite.
 *
 * WAS SIE IST UND WAS NICHT: ein NACHSCHLAGEWERK. Die Anwendung behauptet weiterhin nur,
 * was sie selbst misst (BEFUNDREGELN in ui/app/index.html, ekg-analyse.js). Was hier steht,
 * schlaegt der Untersucher nach — es loest nichts aus.
 *
 * Reines ES5, keine Abhaengigkeiten. Laeuft im Browser (window.VS.literatur) und in Node.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.VS = root.VS || {}; root.VS.literatur = factory(); }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var THEMEN = ${JSON.stringify(THEMEN, null, 2).replace(/\n/g, '\n  ')};

  /* EINE ZEILE JE STELLE. Nicht aus Schoenheit: mit der eingerueckten Schreibweise
   * (ein Feld je Zeile) war diese Datei 571 KB gross und trieb das Update-Paket ueber die
   * Grenze von 4096 KB, die tools/paket-test.js bewacht - das Paket geht ueber die
   * Praxisleitung. Eine Zeile je Eintrag bleibt im Git-Vergleich trotzdem lesbar. */
  var STELLEN = [
${sauber.map((s) => '    ' + JSON.stringify(s)).join(',\n')}
  ];

  function themenName(t) {
    for (var i = 0; i < THEMEN.length; i++) if (THEMEN[i][0] === t) return THEMEN[i][1];
    return t;
  }
  /* Suche ueber Text, Zahlen, Thema und Werk. Ohne Suchwort kommt alles. */
  function suche(wort, thema) {
    var w = String(wort || '').trim().toLowerCase();
    var aus = [], i;
    for (i = 0; i < STELLEN.length; i++) {
      var s = STELLEN[i];
      if (thema && s.thema !== thema) continue;
      if (w) {
        var heu = (s.text + ' ' + s.zahlen + ' ' + s.thema + ' ' + themenName(s.thema) + ' ' + s.werk).toLowerCase();
        if (heu.indexOf(w) < 0) continue;
      }
      aus.push(s);
    }
    return aus;
  }
  function themenMitTreffern(wort) {
    var zaehler = {}, i;
    var treffer = suche(wort, null);
    for (i = 0; i < treffer.length; i++) zaehler[treffer[i].thema] = (zaehler[treffer[i].thema] || 0) + 1;
    var aus = [];
    for (i = 0; i < THEMEN.length; i++) {
      if (zaehler[THEMEN[i][0]]) aus.push({ id: THEMEN[i][0], name: THEMEN[i][1], n: zaehler[THEMEN[i][0]] });
    }
    return aus;
  }

  return {
    STELLEN: STELLEN, THEMEN: THEMEN,
    suche: suche, themenMitTreffern: themenMitTreffern, themenName: themenName,
    anzahl: STELLEN.length,
  };
}));
`;

fs.writeFileSync(ZIEL, kopf, 'utf8');

/* ==========================================================================================
 * ZWEITE DATEI: die Warnungen allein (15.08.2026)
 *
 * WARUM SIE GETRENNT SEIN MUSS: ekg-literatur.js wird seit 1.18.1 NICHT mehr im oeffentlichen
 * Update-Paket ausgeliefert (Auszug aus lizenzierten Fachbuechern, canis-vetpharm ist
 * oeffentlich). Der Updater loescht nichts - kiosk\launch-kiosk.ps1 spielt mit "robocopy /E"
 * ein, ohne /MIR und ohne /PURGE. Eine schon laufende Station behaelt also ihre ALTE
 * ekg-literatur.js, und die kennt die Warnungen nicht: gemessen am 15.08.2026 tragen die
 * ausgelieferten Fassungen 1.12.0 bis 1.17.0 NULL Warnungen, erst 1.18.0 hat zwei.
 *
 * Ohne diese Datei saehe eine ueber den Kanal aktualisierte Station die tausendfach zu hohe
 * Dauertropfdosis wieder ungewarnt - der Ausschluss haette also eine Sicherheitswarnung
 * zurueckgenommen, ohne dass es jemandem auffaellt. Genau die Sorte stiller Rueckschritt,
 * gegen die dieses Projekt gebaut ist.
 *
 * SIE DARF OEFFENTLICH SEIN: hier steht kein Buchsatz, sondern nur die eigene Richtigstellung
 * mit oeffentlichen Gegenquellen (CliniPharm/vetpharm.uzh.ch, ACVIM-Konsensus, Killich 2019).
 * Wenige KB statt 516.
 * ========================================================================================== */
/*
 * DER SCHLUESSEL WIRD GEHASHT, NICHT AUSGESCHRIEBEN (15.08.2026).
 *
 * Erste Fassung trug werk|seite|zahlen im Klartext. Das waere ein Widerspruch in sich gewesen:
 * diese Datei geht ins OEFFENTLICHE Paket, und "zahlen" ist die abgeschriebene Dosiszeile der
 * Buchseite - genau die Sorte Inhalt, wegen der ekg-literatur.js gerade herausgenommen wurde.
 * Der Hash leistet dasselbe (er trifft dieselbe eine Stelle), gibt aber nichts preis.
 *
 * werk und seite bleiben im Klartext stehen: eine Buchtitel- und Seitenangabe ist eine
 * QUELLENANGABE, kein Auszug - und die Belegpflicht dieses Projekts verlangt sie.
 */
function kennungVon(werk, seite, zahlen) {
  const s = String(werk || '') + '|' + String(seite || '') + '|' + String(zahlen || '');
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return ('0000000' + h.toString(16)).slice(-8);
}
const warnStellen = sauber.filter((s) => s.warnung).map((s) => ({
  werk: s.werk, seite: s.seite, kennung: kennungVon(s.werk, s.seite, s.zahlen), warnung: s.warnung,
}));
const kopfWarn = `/*
 * dosis-warnungen.js — Richtigstellungen zu Stellen des Nachschlagewerks, an denen die
 * VORLAGE SELBST falsch ist.
 *
 * ERZEUGT von tools/ekg-literatur-bauen.js am ${jetzt}. NICHT von Hand aendern —
 * die Quelldaten liegen in docs/ekg-quellen/literatur-2026-08.json (Feld "warnung").
 *
 * WARUM ES DIESE DATEI GETRENNT VON ekg-literatur.js GIBT (15.08.2026):
 * Das Nachschlagewerk ist ein Auszug aus lizenzierten Fachbuechern und geht seit 1.18.1 nicht
 * mehr ins oeffentliche Update-Paket. Der Updater loescht nichts (robocopy /E, ohne /MIR),
 * eine laufende Station behaelt also ihre ALTE Fassung — und die kennt die Warnungen nicht:
 * 1.12.0 bis 1.17.0 tragen nachgemessen NULL, erst 1.18.0 zwei. Die Warnung muss die Station
 * deshalb auf einem anderen Weg erreichen als die Daten, die sie kommentiert.
 *
 * ZUORDNUNG UEBER EINEN EXAKTEN SCHLUESSEL aus werk|seite|zahlen — keine Teilzeichenkette,
 * damit nie eine fremde Stelle mitmarkiert wird. Gemessen am 15.08.2026 an allen sechs
 * veroeffentlichten Fassungen (1.12.0-1.18.0): beide Schluessel treffen dort je GENAU EINE
 * Stelle. werk+seite allein reicht nicht — 266 Schluessel sind dort mehrfach belegt.
 *
 * DER SCHLUESSEL STEHT ALS HASH DA, NICHT IM KLARTEXT: "zahlen" ist die abgeschriebene
 * Dosiszeile der Buchseite, und diese Datei geht ins oeffentliche Paket. Der Hash trifft
 * dieselbe Stelle, ohne den Satz mitzuliefern. werk und seite bleiben lesbar — eine
 * Quellenangabe ist kein Auszug, und die Belegpflicht des Projekts verlangt sie.
 *
 * Diese Datei enthaelt KEIN Buchwissen, nur eigene Richtigstellungen mit oeffentlichen
 * Gegenquellen. Reines ES5, keine Abhaengigkeiten.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.VS = root.VS || {}; root.VS.dosisWarnungen = factory(); }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var WARNUNGEN = [
${warnStellen.map((s) => '    ' + JSON.stringify(s)).join(',\n')}
  ];

  /* FNV-1a ueber die UTF-16-Einheiten. Kein Sicherheitsverfahren - er soll nur eindeutig
   * zuordnen, und tools/ekg-modul-test.js erzwingt, dass jeder Wert genau eine Stelle trifft.
   * Eine Kollision faerbt diese Pruefung also rot, statt still zu warnen. */
  function schluessel(s) {
    var t = String((s && s.werk) || '') + '|' + String((s && s.seite) || '') + '|' + String((s && s.zahlen) || '');
    var h = 0x811c9dc5, i;
    for (i = 0; i < t.length; i++) {
      h ^= t.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return ('0000000' + h.toString(16)).slice(-8);
  }
  var KARTE = {};
  for (var i = 0; i < WARNUNGEN.length; i++) KARTE[WARNUNGEN[i].kennung] = WARNUNGEN[i].warnung;

  /* Der Rueckfall auf stelle.warnung ist Absicht: eine NEUERE Fassung des Nachschlagewerks
   * darf eine Warnung mitbringen, die diese Datei noch nicht kennt. Die Reihenfolge sagt,
   * wer im Streitfall gewinnt — die eigene Karte, weil sie ueberall ankommt. */
  function fuer(stelle) {
    if (!stelle) return '';
    return KARTE[schluessel(stelle)] || String(stelle.warnung || '');
  }

  return {
    WARNUNGEN: WARNUNGEN, fuer: fuer, schluessel: schluessel, anzahl: WARNUNGEN.length,
  };
}));
`;
fs.writeFileSync(ZIEL_WARN, kopfWarn, 'utf8');

const nachThema = {};
sauber.forEach((s) => { nachThema[s.thema] = (nachThema[s.thema] || 0) + 1; });
console.log('geschrieben: ' + ZIEL);
console.log('geschrieben: ' + ZIEL_WARN + ' (' + warnStellen.length + ' Richtigstellung(en), ' +
  Math.round(kopfWarn.length / 1024) + ' KB)');
console.log(sauber.length + ' Stellen aus ' + fakten.length + ' Rohaussagen (' +
  (fakten.length - sauber.length) + ' Dubletten/zu kurz entfernt)');
console.log('Themen: ' + Object.keys(nachThema).sort().map((t) => t + ' ' + nachThema[t]).join(', '));
