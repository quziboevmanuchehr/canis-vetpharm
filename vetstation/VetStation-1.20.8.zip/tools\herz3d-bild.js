'use strict';
/*
 * herz3d-bild.js — das Herzmodell aus ui/shared/herz3d.js als PNG, ohne Browser.
 *
 * WARUM ES DIESES WERKZEUG GIBT (13.08.2026):
 * Aus demselben Grund wie tier3d-bild.js. Die Browser-Vorschau drosselt den Bildtakt; wer
 * dort eine canvas ausliest, misst alte Bilder (vetstation-leinwand-messfalle.md). Und die
 * Erfahrung dieses Projekts ist eindeutig: BILD UND MESSUNG WIDERLEGEN EINANDER GEGENSEITIG.
 * Beim 3D-Tiermodell waren am 12.08.2026 alle 152 Pruefungen gruen, waehrend Kopf und Hals
 * sichtbar getrennt waren - Punktzahl und Sortierung beruehren ein Loch nun einmal nicht.
 *
 * Genau derselbe Fall ist hier schon eingetreten: der Test war lange gruen, waehrend die
 * Kammerscheidewand als flaches Blatt MITTEN IM HOHLRAUM der linken Kammer steckte. Gefunden
 * hat das erst eine Pruefung, die nach der Sichtbarkeit fragte. Ein Bild haette es sofort
 * gezeigt.
 *
 * Der Rasterer ist derselbe wie in tier3d-bild.js (Dreiecksfaecher, kein Kantenglaetten) -
 * bewusst, damit beide Werkzeuge dieselbe Sorte Bild liefern und vergleichbar bleiben.
 *
 * Start: node tools/herz3d-bild.js <ziel.png> [art ...] [BREITExHOEHE]
 *        SCHNITT=1        die kraniale Haelfte wegschneiden (Vierkammerblick)
 *        MS=<zahl>        Zeitpunkt in ms nach P-Beginn - faerbt die Erregung ein
 *        SICHT="0,12;90,12"   eigene Blickwinkel (gier,nick), durch Semikolon getrennt
 *        FLACH=1          ohne Schattierung auf hellem Grund: so sieht man Loecher im Netz
 */
const zlib = require('zlib');
const fs = require('fs');
const H = require('../ui/shared/herz3d.js');
const MOD = require('../ui/shared/ekg-modell.js');

/* ---- PNG (zlib liegt in Node bei, CRC32 sind zehn Zeilen) ------------------------------ */
let CRC_TAB = null;
function crc32(buf) {
  if (!CRC_TAB) {
    CRC_TAB = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      CRC_TAB[n] = c;
    }
  }
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TAB[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}
function chunk(typ, daten) {
  const len = Buffer.alloc(4); len.writeUInt32BE(daten.length, 0);
  const kopf = Buffer.concat([Buffer.from(typ, 'ascii'), daten]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(kopf), 0);
  return Buffer.concat([len, kopf, crc]);
}
function png(breite, hoehe, rgb) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(breite, 0); ihdr.writeUInt32BE(hoehe, 4);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const roh = Buffer.alloc(hoehe * (breite * 3 + 1));
  for (let y = 0; y < hoehe; y++) {
    roh[y * (breite * 3 + 1)] = 0;
    rgb.copy(roh, y * (breite * 3 + 1) + 1, y * breite * 3, (y + 1) * breite * 3);
  }
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(roh, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

/* ---- Rasterer -------------------------------------------------------------------------- */
function bild(breite, hoehe, hg) {
  const b = Buffer.alloc(breite * hoehe * 3);
  for (let i = 0; i < breite * hoehe; i++) { b[i * 3] = hg[0]; b[i * 3 + 1] = hg[1]; b[i * 3 + 2] = hg[2]; }
  return b;
}
function dreieck(buf, breite, hoehe, a, b, c, farbe) {
  const x0 = Math.max(0, Math.floor(Math.min(a.x, b.x, c.x)));
  const x1 = Math.min(breite - 1, Math.ceil(Math.max(a.x, b.x, c.x)));
  const y0 = Math.max(0, Math.floor(Math.min(a.y, b.y, c.y)));
  const y1 = Math.min(hoehe - 1, Math.ceil(Math.max(a.y, b.y, c.y)));
  const d = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
  if (Math.abs(d) < 1e-9) return;
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const px = x + 0.5, py = y + 0.5;
      const w0 = ((b.y - c.y) * (px - c.x) + (c.x - b.x) * (py - c.y)) / d;
      const w1 = ((c.y - a.y) * (px - c.x) + (a.x - c.x) * (py - c.y)) / d;
      const w2 = 1 - w0 - w1;
      if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
      const o = (y * breite + x) * 3;
      buf[o] = farbe[0]; buf[o + 1] = farbe[1]; buf[o + 2] = farbe[2];
    }
  }
}
function kreis(buf, breite, hoehe, cx, cy, r, farbe, alpha) {
  for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(hoehe - 1, Math.ceil(cy + r)); y++) {
    for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(breite - 1, Math.ceil(cx + r)); x++) {
      const dx = x + 0.5 - cx, dy = y + 0.5 - cy;
      if (dx * dx + dy * dy > r * r) continue;
      const o = (y * breite + x) * 3;
      for (let k = 0; k < 3; k++) buf[o + k] = Math.round(buf[o + k] * (1 - alpha) + farbe[k] * alpha);
    }
  }
}
function hex(h, f) {
  return [Math.min(255, Math.round(parseInt(h.slice(1, 3), 16) * f)),
    Math.min(255, Math.round(parseInt(h.slice(3, 5), 16) * f)),
    Math.min(255, Math.round(parseInt(h.slice(5, 7), 16) * f))];
}
function misch(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t].map(Math.round); }

const FLACH = !!process.env.FLACH;
const SCHNITT = !!process.env.SCHNITT;
const HG = FLACH ? [235, 238, 242] : [12, 15, 22];
/* Erregtes Gewebe wird hell - dieselbe Aussage wie in der Oberflaeche: was leuchtet, ist
 * gerade depolarisiert. */
const ERREGT = [255, 214, 92];

function streifen(art, ansichten, zellB, zellH, ms) {
  const m = H.netz(art);
  const z = ms == null ? null : H.zustand(MOD.pBeginnSek(art) + ms / 1000, 0.8, { p: 1, pq: 1, qrs: 1 }, 0, art);
  const B = zellB * ansichten.length, HH = zellH;
  const buf = bild(B, HH, HG);
  ansichten.forEach((a, idx) => {
    const v = H.ansicht(m, { gier: a[0], nick: a[1], breite: zellB, hoehe: zellH, zustand: z, schnitt: SCHNITT });
    const ox = idx * zellB;
    v.flaechen.forEach((f) => {
      let c = FLACH ? hex(f.farbe, 1) : hex(f.farbe, f.hell);
      if (z) c = misch(c, ERREGT, H.aktiv(f) * 0.75);
      for (let j = 1; j < f.eck.length - 1; j++) {
        dreieck(buf, B, HH,
          { x: f.eck[0].x + ox, y: f.eck[0].y }, { x: f.eck[j].x + ox, y: f.eck[j].y },
          { x: f.eck[j + 1].x + ox, y: f.eck[j + 1].y }, c);
      }
    });
    /* Die Leitungspunkte: gruen wenn ruhend, hell wenn erregt, rot wenn die Erregung dort
     * stehen bleibt. Genau das ist die Aussage, um die es dem Merkmal geht. */
    v.punkte.forEach((s) => {
      const farbe = s.halt ? [255, 70, 70] : (s.erregt > 0.15 ? ERREGT : [80, 220, 140]);
      kreis(buf, B, HH, s.x + ox, s.y, 7, farbe, 1);
      kreis(buf, B, HH, s.x + ox, s.y, 10, farbe, 0.30);
    });
    v.klappen.forEach((k) => {
      kreis(buf, B, HH, k.x + ox, k.y, Math.max(4, k.r), k.offen ? [120, 210, 255] : [255, 255, 255], k.offen ? 0.20 : 0.42);
    });
  });
  return { buf, B, H: HH };
}

const ziel = process.argv[2] || 'herz.png';
const argRest = process.argv.slice(3);
const artArg = argRest.filter((a) => !/^\d/.test(a));
const arten = artArg.length ? artArg : H.arten();
const groesse = argRest.filter((a) => /^\d/.test(a))[0];
const MS = process.env.MS != null ? Number(process.env.MS) : null;
/* Vorgabeblicke: von links, von rechts, von kranial (das ist der Blick auf den Schnitt),
 * und schraeg oben. Der Schnittblick steht in herz3d.SCHNITT_GIER, damit Werkzeug,
 * Oberflaeche und Test dieselbe Richtung meinen. */
const ANSICHTEN = process.env.SICHT
  ? process.env.SICHT.split(';').map((s) => s.split(',').map(Number))
  : (SCHNITT ? [[H.SCHNITT_GIER, 0], [H.SCHNITT_GIER, 18], [H.SCHNITT_GIER + 25, 10]]
    : [[0, 10], [180, 10], [H.SCHNITT_GIER, 10], [40, 30]]);

const zellB = groesse ? +groesse.split('x')[0] : 320;
const zellH = groesse ? +groesse.split('x')[1] : 330;
const teile = arten.map((a) => streifen(a, ANSICHTEN, zellB, zellH, MS));

const gesB = Math.max(...teile.map((t) => t.B));
const gesH = teile.reduce((s, t) => s + t.H, 0);
const alles = bild(gesB, gesH, HG);
let y0 = 0;
teile.forEach((t) => {
  for (let y = 0; y < t.H; y++) t.buf.copy(alles, ((y0 + y) * gesB) * 3, y * t.B * 3, (y + 1) * t.B * 3);
  y0 += t.H;
});
fs.writeFileSync(ziel, png(gesB, gesH, alles));
console.log('geschrieben: ' + ziel + '  (' + gesB + 'x' + gesH + ', Arten: ' + arten.join(', ') +
  (MS != null ? ', t = ' + MS + ' ms nach P-Beginn' : '') + (SCHNITT ? ', Schnitt' : '') + ')');
