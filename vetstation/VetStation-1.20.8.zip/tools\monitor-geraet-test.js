'use strict';
/*
 * monitor-geraet-test.js — ist das VIRTUELLE MONITORGERAET im Geraetemenue geeicht?
 *
 * NICHT das EKG-Submodul (das prueft tools/virtuelles-geraet-test.js), sondern die Kurven,
 * die das Monitorbild im Geraetemenue zeichnet: wEkg, wPleth, wCapno und der Puffer dahinter.
 *
 * WARUM ES DIESEN TEST GIBT (Nutzerbefund 11.08.2026):
 * Beide Kurven wurden ueber die PHASE des Herzschlags gebaut. Die Phase laeuft in jedem
 * Schlag von 0 bis 1 - ihre Breite in Sekunden haengt also an der Frequenz. Am laufenden
 * Programm nachgemessen:
 *
 *      EKG, Halbwertsbreite des Kammerkomplexes
 *       60/min -> 23 ms      140/min -> 10 ms
 *      100/min -> 14 ms      240/min ->  6 ms      (Faktor 3,8)
 *
 *      Pleth, systolischer Anstieg bis zum Gipfel
 *       60/min -> 100 ms     120/min -> 50 ms      200/min -> 30 ms
 *
 * Ein Kammerkomplex ist eine Eigenschaft der Kammer, nicht der Frequenz; und der systolische
 * Anstieg bleibt bei steigender Frequenz nahezu gleich lang - kuerzer wird die Diastole.
 *
 * Aufruf:  node tools/monitor-geraet-test.js
 */
const fs = require('fs');
const path = require('path');
const M = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-modell.js'));
const VS = require(path.join(__dirname, '..', 'ui', 'shared', 'ekg-analyse.js'));

let gruen = 0, rot = 0;
function pruef(name, bed, zusatz) {
  if (bed) { gruen++; console.log('  ✓ ' + name); }
  else { rot++; console.log('  ✗ ' + name + (zusatz ? '   -> ' + zusatz : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

const SRC = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');
function holeFunktion(name) {
  const start = SRC.indexOf('function ' + name + '(');
  if (start < 0) return null;
  const auf = SRC.indexOf('{', start);
  let tiefe = 0;
  for (let i = auf; i < SRC.length; i++) {
    if (SRC[i] === '{') tiefe++;
    else if (SRC[i] === '}') { tiefe--; if (!tiefe) return SRC.slice(start, i + 1); }
  }
  return null;
}
/* Die Zeichenfunktionen des Monitors mit ihren echten Abhaengigkeiten bauen - nicht nachbauen. */
const MON_HZ = Number((SRC.match(/var MON_HZ\s*=\s*(\d+)/) || [])[1]);
const bahnAnteil = Number((SRC.match(/var EKG_BAHN_MV_PRO_HOEHE\s*=\s*([\d.]+)/) || [])[1]);
const umgebung = {
  mon: { beatN: 0 },
  state: { species: 'hund' },
  window: { VS: { modell: M } },
  ekgDef: (t) => ({ w: (t === 'normal' || !t) ? { p: true, pq: 1, qrs: 1 } : { p: true, pq: 1, qrs: 1 } }),
};
const bau = new Function('mon', 'state', 'window', 'ekgDef',
  'var EKG_BAHN_MV_PRO_HOEHE=' + bahnAnteil + ';\n' +
  holeFunktion('monArt') + '\n' + holeFunktion('wEkg') + '\n' +
  holeFunktion('ekgBahnY') + '\n' + holeFunktion('wPleth') + '\n' +
  'return { wEkg: wEkg, wPleth: wPleth, ekgBahnY: ekgBahnY, monArt: monArt };')(
  umgebung.mon, umgebung.state, umgebung.window, umgebung.ekgDef);

// ===========================================================================
block('1. Die Kurve haengt nicht mehr an der Frequenz');
{
  function halbwert(hf) {
    const rr = 60 / hf, N = 8000, y = [];
    for (let i = 0; i < N; i++) y.push(bau.wEkg(i / N, 'normal', rr));
    let max = -9, imax = 0; for (let i = 0; i < N; i++) if (y[i] > max) { max = y[i]; imax = i; }
    const basis = 0.5, halb = basis + (max - basis) / 2;
    let a = imax; while (a > 0 && y[a] > halb) a--;
    let b = imax; while (b < N - 1 && y[b] > halb) b++;
    return Math.round((b - a) / N * rr * 1000);
  }
  const w = [60, 100, 140, 200, 240].map(halbwert);
  const min = Math.min.apply(null, w), max = Math.max.apply(null, w);
  pruef('QRS-Halbwertsbreite ueber alle Frequenzen gleich (frueher Faktor 3,8)',
    max <= min + 2, 'von ' + min + ' bis ' + max + ' ms bei ' + JSON.stringify(w));

  function plethAnstieg(hf) {
    const rr = 60 / hf, N = 8000, y = [];
    for (let i = 0; i < N; i++) y.push(bau.wPleth(i / N, 'normal', rr));
    let max2 = -9, imax2 = 0; for (let i = 0; i < N; i++) if (y[i] > max2) { max2 = y[i]; imax2 = i; }
    return Math.round(imax2 / N * rr * 1000);
  }
  /* Der systolische Anstieg bleibt gleich lang; nur wenn der Zyklus so kurz wird, dass er
   * nicht mehr hineinpasst, wird er begrenzt (bei 240/min ist ein Zyklus 250 ms). */
  const p = [60, 100, 140, 200].map(plethAnstieg);
  pruef('Pleth: der systolische Anstieg bleibt bei ~100 ms (frueher 100 -> 30)',
    p.every((x) => Math.abs(x - M.PLETH.anstiegMs) <= 12), JSON.stringify(p));
  pruef('bei sehr hoher Frequenz wird er begrenzt statt den Zyklus zu sprengen',
    plethAnstieg(240) <= 250 * 0.5, plethAnstieg(240) + ' ms bei 250 ms Zyklus');
}

// ===========================================================================
block('2. Die EKG-Bahn hat einen Massstab');
{
  pruef('EKG_BAHN_MV_PRO_HOEHE ist festgelegt', bahnAnteil > 0, String(bahnAnteil));
  /* Der Eichbalken und die Kurve MUESSEN aus derselben Umrechnung kommen - sonst zeigt der
   * Balken eine andere Hoehe an, als die Kurve benutzt. */
  const nullLinie = bau.ekgBahnY(0), einMv = bau.ekgBahnY(1);
  pruef('0 mV liegt auf der Bahnmitte', Math.abs(nullLinie - 0.5) < 1e-9, String(nullLinie));
  pruef('1 mV ist genau EKG_BAHN_MV_PRO_HOEHE der halben Bahn',
    Math.abs((einMv - nullLinie) - bahnAnteil * 0.5) < 1e-9, String(einMv - nullLinie));
  /* Gegenprobe an der KURVE: eine 1-mV-R-Zacke muss den Balken genau ausfuellen. */
  const rr = 0.6, N = 6000; let max = -9;
  for (let i = 0; i < N; i++) { const v = bau.wEkg(i / N, 'normal', rr); if (v > max) max = v; }
  pruef('eine 1-mV-R-Zacke erreicht genau die Hoehe des Eichbalkens',
    Math.abs(max - einMv) < 0.002, 'Kurve ' + max.toFixed(4) + ', Balken ' + einMv.toFixed(4));
  /* Und die groesste zu erwartende Zacke (3 mV, oberes Hundeband) darf die Bahn nicht sprengen. */
  pruef('3 mV bleiben innerhalb der Bahn', bau.ekgBahnY(3) <= 1.0 && bau.ekgBahnY(-3) >= 0,
    'oben ' + bau.ekgBahnY(3).toFixed(3) + ', unten ' + bau.ekgBahnY(-3).toFixed(3));
  pruef('der Eichbalken wird gezeichnet', /1 mV/.test(SRC) && /ekgBahnY\(1\)/.test(SRC));
  pruef('das Pleth wird als relativ gekennzeichnet', /' · rel\.'/.test(SRC));
  pruef('Zeitmassstab und Abtastrate stehen im Bild', /sweep\+' s · '\+MON_HZ\+' Hz'/.test(SRC));
}

// ===========================================================================
block('3. Die Abtastrate haengt nicht mehr an der Fensterbreite');
{
  pruef('MON_HZ ist festgelegt', MON_HZ > 0, String(MON_HZ));
  pruef('MON_HZ ergibt hoechstens 5 ms Schrittweite (Katzen-QRS 35 ms)',
    1000 / MON_HZ <= 5, (1000 / MON_HZ).toFixed(1) + ' ms');
  const src = SRC.replace(/\/\*[\s\S]*?\*\//g, ' ');
  pruef('die Rate kommt NICHT mehr aus der Spaltenzahl',
    !/pxPerSec\s*=\s*cols\s*\/\s*sweep/.test(src), 'cols/sweep steht noch im Code');
  pruef('der Puffer haengt an der Rate, nicht an der Leinwandbreite',
    /pufN\s*=\s*Math\.round\(MON_HZ\s*\*\s*6\.0\)/.test(src));
  pruef('und wird bei einer Groessenaenderung NICHT mehr verworfen',
    !/mon\.buf\.__cols/.test(src), '__cols wird noch verglichen');
  pruef('der Vorschub von 6 s bleibt', /var sweep\s*=\s*6\.0/.test(src));
}

// ===========================================================================
block('4. Die Vorgabe wird von der Auswertung wiedergefunden');
{
  /* DER EIGENTLICHE EICHSCHRITT: die Kurve des virtuellen Geraets durch dieselbe Auswertung
   * schicken, die auch echte Geraetestreifen misst. */
  ['hund', 'katze'].forEach((sp) => {
    const V = M.ekgVorgabe(sp), hf = sp === 'katze' ? 180 : 100;
    const rr = 60 / hf, n = Math.round(MON_HZ * 16), s = new Array(n);
    let ph = 0, beat = 0;
    for (let i = 0; i < n; i++) {
      const vor = ph; ph = (ph + (1 / MON_HZ) / rr) % 1; if (ph < vor) beat++;
      s[i] = M.ekgMv(ph * rr, rr, { p: true, pq: 1, qrs: 1 }, beat, sp);
    }
    const e = VS.analysiere({ samples: s, hz: MON_HZ, skala: 1, einheit: 'mV' },
      { art: sp, einheit: 'mV', bandHr: [1, 999] });
    pruef(sp + ': der Streifen ist auswertbar', e.brauchbar, e.warum || '');
    pruef(sp + ': Frequenz ' + hf + ' -> gemessen ' + e.hf, Math.abs(e.hf - hf) <= 4);
    pruef(sp + ': eine P-Welle wird gefunden', !!(e.p && e.p.vorhanden), (e.p && e.p.warum) || '');
    if (e.p && e.p.vorhanden) {
      pruef(sp + ': PQ ' + V.pqMs + ' -> gemessen ' + e.p.pqMs + ' ms',
        Math.abs(e.p.pqMs - V.pqMs) <= V.pqMs * 0.2);
    }
    /* Die Schwellenmessung liest Dauern systematisch zu kurz (siehe ekg-analyse.js) - geprueft
     * wird deshalb "kurz, aber begrenzt", nicht "gleich". */
    pruef(sp + ': QRS ' + V.qrsMs + ' -> gemessen ' + e.qrsBreiteMs + ' ms',
      e.qrsBreiteMs >= V.qrsMs * 0.5 && e.qrsBreiteMs <= V.qrsMs * 1.15);
    pruef(sp + ': der Rhythmus kommt als Sinusrhythmus heraus', e.rhythmus.id === 'sinus', e.rhythmus.name);
  });
}

// ===========================================================================
block('5. Die Vorgaben passen zu den Normbaendern der Art');
{
  const baender = {
    hund: { rAmp: [1.0, 3.0], qrs: [null, 60], pq: [60, 130], qt: [150, 250], p: [null, 40] },
    katze: { rAmp: [0.2, 0.9], qrs: [null, 40], pq: [50, 90], qt: [120, 180], p: [null, 40] },
  };
  Object.keys(baender).forEach((sp) => {
    const V = M.ekgVorgabe(sp), B = baender[sp];
    function drin(wert, band) { return (band[0] == null || wert >= band[0]) && (band[1] == null || wert <= band[1]); }
    pruef(sp + ': R-Amplitude ' + V.rAmp + ' mV liegt im Band', drin(V.rAmp, B.rAmp));
    pruef(sp + ': QRS ' + V.qrsMs + ' ms liegt im Band', drin(V.qrsMs, B.qrs));
    pruef(sp + ': PQ ' + V.pqMs + ' ms liegt im Band', drin(V.pqMs, B.pq));
    pruef(sp + ': P-Dauer ' + V.pMs + ' ms liegt im Band', drin(V.pMs, B.p));
    pruef(sp + ': QT ' + M.qtMs(sp) + ' ms liegt im Band', drin(M.qtMs(sp), B.qt));
  });
  pruef('die Katze hat den schmaleren Komplex als der Hund',
    M.ekgVorgabe('katze').qrsMs < M.ekgVorgabe('hund').qrsMs);
  pruef('das Pferd den breitesten', M.ekgVorgabe('pferd').qrsMs > M.ekgVorgabe('hund').qrsMs);
}

// ===========================================================================
block('6. Es gibt nur EINE Vorgabe — Monitor und EKG-Fenster duerfen nicht auseinanderlaufen');
{
  /* Das EKG-Submodul fuehrt seine eigene Tabelle MODELL (es wurde auf Wunsch nicht angefasst).
   * Solange es zwei Tabellen gibt, muss ein Test sie Wert fuer Wert vergleichen - sonst
   * zeigt der Monitor eine andere Katze als der Ausdruck. Genau diese Sorte stiller
   * Doppelung hat am 10.08.2026 die Bridge wochenlang auf einer toten Kopie laufen lassen. */
  const modellSrc = SRC.slice(SRC.indexOf('var MODELL={'), SRC.indexOf('\n};', SRC.indexOf('var MODELL={')) + 3);
  pruef('die Tabelle des EKG-Fensters ist auffindbar', modellSrc.length > 50);
  const MODELL = new Function(modellSrc + '\nreturn MODELL;')();
  Object.keys(M.EKG).forEach((sp) => {
    pruef('Art "' + sp + '" gibt es in beiden Tabellen', !!MODELL[sp]);
    if (!MODELL[sp]) return;
    Object.keys(M.EKG[sp]).forEach((feld) => {
      pruef('  ' + sp + '.' + feld + ' stimmt ueberein (' + M.EKG[sp][feld] + ')',
        MODELL[sp][feld] === M.EKG[sp][feld],
        'Monitor ' + M.EKG[sp][feld] + ' gegen EKG-Fenster ' + MODELL[sp][feld]);
    });
  });
  pruef('die gemeinsame Datei wird in index.html geladen', /shared\/ekg-modell\.js/.test(SRC));
  pruef('und in die Web-App kopiert',
    /shared\/ekg-modell\.js/.test(fs.readFileSync(path.join(__dirname, 'web-app-bauen.js'), 'utf8')));
}

// ===========================================================================
block('7. Ohne Modell wird NICHTS erfunden');
{
  const ohne = new Function('mon', 'state', 'window', 'ekgDef',
    'var EKG_BAHN_MV_PRO_HOEHE=' + bahnAnteil + ';\n' +
    holeFunktion('monArt') + '\n' + holeFunktion('wEkg') + '\n' + holeFunktion('wPleth') + '\n' +
    'return { wEkg: wEkg, wPleth: wPleth };')({ beatN: 0 }, { species: 'hund' }, { VS: {} }, umgebung.ekgDef);
  pruef('fehlt die Modelldatei, liefert das EKG die Nulllinie statt einer erfundenen Kurve',
    ohne.wEkg(0.3, 'normal', 0.6) === 0.5);
  pruef('dasselbe beim Pleth', ohne.wPleth(0.3, 'normal', 0.6) === 0.5);
}

console.log('\n' + (rot ? rot + ' FEHLGESCHLAGEN von ' + (gruen + rot)
  : 'ALLE ' + gruen + ' PRUEFUNGEN BESTANDEN'));
process.exit(rot ? 1 : 0);
