'use strict';
/*
 * usbwache.js — ein am USB angestecktes Diagnostik-EKG von selbst in Betrieb nehmen.
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 16.08.2026: "damit das Geraet beim Anschliessen in das
 * PC direkt laeuft, ohne irgendwas zu machen"):
 * Die automatische Geraetesuche (erstsuche.js) sucht ausschliesslich im NETZ. Sie klopft
 * IP-Adressen und Datenports ab. Ein USB-Geraet hat keine Adresse und keinen Port — es kam
 * in der Suche also ueberhaupt nicht vor. Nachgesehen am 16.08.2026: usbSerielleGeraete()
 * wurde im ganzen Programm nur von zwei Werkzeugen aufgerufen, von KEINEM Dienst. Das EKG
 * konnte deshalb angesteckt sein, erkannt sein — und wurde trotzdem nie gestartet.
 *
 * WARUM ALS EIGENE DATEI UND NICHT IN erstsuche.js:
 * Die Erstsuche traegt die Narkose-Sperre (darfSuchen), den Bewaehrungsmechanismus, die
 * Nachbarsaal-Erkennung und den langsamen Wachtakt. Nichts davon gilt hier: das Nachsehen,
 * ob ein USB-Geraet steckt, ist ein Registry-Lesevorgang von wenigen Millisekunden, der
 * weder das Netz noch den Empfang beruehrt. Er darf deshalb auch waehrend einer Narkose
 * laufen — und genau dann wird er gebraucht, denn das EKG wird am Patienten angesteckt.
 * In erstsuche.js eingebaut haette er sich all deren Sperren eingefangen.
 *
 * WAS SIE NICHT TUT: sie startet nichts, was sie nicht benennen kann. Ein fremder
 * FTDI-Wandler (der Allerweltschip FT232R steckt in unzaehligen Adaptern) bekommt KEINEN
 * Adapter — sonst haenge die Station an jedem beliebigen USB-Seriell-Stecker einen
 * EKG-Leser, und der Anwender misstraute der Erkennung danach zu Recht ueberall.
 */
const fs = require('fs');
const path = require('path');
const seriell = require('./seriell');

/* Alle 12 s nachsehen. Das ist ein Registry-Lesevorgang, kein Netzverkehr — der Takt darf
 * kurz sein. Kuerzer lohnt nicht: bis Windows einen frisch angesteckten USB-Wandler
 * eingerichtet und ihm einen Anschluss zugeteilt hat, vergehen ohnehin einige Sekunden. */
const TAKT_MS = 12 * 1000;

/*
 * WARUM DER ERSTE DURCHGANG WARTET (gemessen am laufenden Start, 16.08.2026):
 * Im Protokoll eines zweiten Starts steht die Zeile der USB-Wache um 08:38:41.782 - und
 * erst um 08:38:42.219 greift der Doppelstart-Riegel und beendet diese Instanz wieder.
 * In diesen 0,4 Sekunden haette die Wache den COM-Anschluss geoeffnet, den die WIRKLICH
 * laufende Station gerade benutzt. Das Fehlerbild waere ein EKG, das beim Doppelklick auf
 * eine Verknuepfung kurz abreisst - und niemand kaeme auf die Idee, das einer Geraetesuche
 * zuzuschreiben. Fuenf Sekunden reichen sicher: der Riegel schlaegt nach weniger als einer zu.
 * Verloren geht dadurch nichts, denn danach laeuft die Wache ohnehin dauernd.
 */
const ERSTER_LAUF_MS = 5 * 1000;

class USBWache {
  /*
   * opts = {
   *   log, registry,
   *   adapterStarten(cfg) -> bool   Rueckruf aus index.js: macht aus einem Eintrag einen
   *                                 laufenden Adapter. Fehlt er, wird nur eingetragen.
   *   konfigPfad                    bridge/config/devices.json
   *   enabled                       false schaltet die Wache ab
   * }
   */
  constructor(opts) {
    const o = opts || {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    this.registry = o.registry || null;
    this.adapterStarten = o.adapterStarten || null;
    this.konfigPfad = o.konfigPfad || path.join(__dirname, '..', 'config', 'devices.json');
    this.aus = o.enabled === false;
    this._timer = null;
    this._erstTimer = null;
    this._gemeldet = {};      /* Kennung -> schon einmal gemeldet (damit der Log nicht zulaeuft) */
    this.gestartet = [];      /* was diese Wache in Betrieb genommen hat */
  }

  start() {
    if (this.aus) { this.log.info('usbwache', 'USB-Wache ist abgeschaltet.'); return; }
    if (process.platform !== 'win32') return;
    /* Kurz warten, DANN nachsehen (Grund oben bei ERSTER_LAUF_MS): das Geraet kann beim
     * Start schon stecken, aber eine zum Abbruch bestimmte Zweitinstanz darf den Anschluss
     * der laufenden Station nicht anfassen. */
    this._erstTimer = setTimeout(() => {
      this._erstTimer = null;
      this.einmal().catch(() => {});
      this._timer = setInterval(() => { this.einmal().catch(() => {}); }, TAKT_MS);
      if (this._timer.unref) this._timer.unref();
    }, ERSTER_LAUF_MS);
    if (this._erstTimer.unref) this._erstTimer.unref();
    this.log.info('usbwache', 'USB-Wache laeuft: ein angestecktes EKG 2000 wird binnen '
      + Math.round(TAKT_MS / 1000) + ' s von selbst in Betrieb genommen — ohne Neustart und '
      + 'ohne Zutun.');
  }

  /* BEIDE Zeitgeber loeschen. Bliebe der Ersttimer stehen, haenge ein sofort wieder
   * beendeter Prozess noch fuenf Sekunden - genau der Fall, den doppelstart-test.js misst. */
  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
    if (this._erstTimer) { clearTimeout(this._erstTimer); this._erstTimer = null; }
  }

  /*
   * einmal() — ein Durchgang. Wirft nie: eine Station darf nicht an einer Geraetesuche
   * scheitern.
   */
  async einmal() {
    if (this.aus) return { gestartet: [], hinweise: [] };
    const hinweise = [];
    const gestartet = [];

    /* 1) Geraete MIT Anschluss — die koennen sofort in Betrieb gehen. */
    let mitPort = { liste: [] };
    try { mitPort = await seriell.usbSerielleGeraete(); } catch (_) {}
    for (const g of (mitPort.liste || [])) {
      if (!g.erkannt || g.katalogId !== 'eickemeyer-ekg-2000') continue;
      const id = 'ekg2000-' + g.port.toLowerCase();
      if (this.registry && this.registry.adapters
          && this.registry.adapters.some((a) => a && a.id === id)) continue;   /* laeuft schon */
      const cfg = {
        type: 'ekg2000', id: id, port: g.port,
        model: g.name || 'Eickemeyer EKG 2000', role: 'ekg',
        /* Herkunft mitschreiben: sonst weiss beim naechsten Start niemand, warum dieser
         * Eintrag in devices.json steht. */
        herkunft: 'usbwache ' + new Date().toISOString().slice(0, 10),
      };
      this._eintragen(cfg);
      let lief = false;
      if (this.adapterStarten) {
        try { lief = !!this.adapterStarten(cfg); } catch (e) {
          this.log.warn('usbwache', 'Adapter ' + id + ' liess sich nicht starten: ' + (e && e.message));
        }
      }
      gestartet.push(id);
      this.gestartet.push(id);
      this.log.info('usbwache', g.name + ' an ' + g.port + ' gefunden und '
        + (lief ? 'sofort in Betrieb genommen' : 'eingetragen (wirksam beim naechsten Start)')
        + '. Seriennummer ' + (g.serie || 'unbekannt') + '.');
    }

    /* 2) Geraete OHNE Anschluss — die koennen NICHT laufen, und genau das muss gesagt werden.
     *    Einmal je Kennung, nicht bei jedem Durchgang: eine Meldung, die alle 12 s wiederkommt,
     *    liest nach dem dritten Mal niemand mehr. */
    let roh = { liste: [] };
    try { roh = await seriell.usbRohGeraete(); } catch (_) {}
    const haben = {};
    (mitPort.liste || []).forEach((g) => { haben[g.vid + ':' + g.pid + '+' + (g.serie || '')] = true; });
    for (const g of (roh.liste || [])) {
      if (g.treiberLaeuft) continue;
      const schluessel = g.vid + ':' + g.pid + '+' + (g.serie || '');
      if (this._gemeldet[schluessel]) continue;
      this._gemeldet[schluessel] = true;
      hinweise.push(g.hinweis);
      this.log.warn('usbwache', g.name + ' steckt am USB, laeuft aber nicht: ' + g.hinweis);
    }

    return { gestartet: gestartet, hinweise: hinweise };
  }

  /*
   * _eintragen(cfg) — den Adapter in devices.json ablegen, damit er den Neustart ueberlebt.
   *
   * Scheitert das Schreiben, ist das KEIN Grund, den Adapter nicht zu starten: die Station
   * laeuft dann eben bis zum naechsten Neustart mit einem Eintrag, den nur der Speicher
   * kennt. Das ist deutlich besser als gar kein EKG.
   */
  _eintragen(cfg) {
    try {
      let doc = { adapters: [] };
      if (fs.existsSync(this.konfigPfad)) {
        doc = JSON.parse(fs.readFileSync(this.konfigPfad, 'utf8')) || {};
      }
      if (!Array.isArray(doc.adapters)) doc.adapters = [];
      if (doc.adapters.some((a) => a && a.id === cfg.id)) return true;
      doc.adapters.push(cfg);
      const ordner = path.dirname(this.konfigPfad);
      if (!fs.existsSync(ordner)) fs.mkdirSync(ordner, { recursive: true });
      /* Erst daneben schreiben, dann umbenennen: ein abgebrochener Schreibvorgang darf keine
       * halbe devices.json hinterlassen — die Station startet sonst beim naechsten Mal ohne
       * ihre Geraete. */
      const tmp = this.konfigPfad + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(doc, null, 2), 'utf8');
      fs.renameSync(tmp, this.konfigPfad);
      return true;
    } catch (e) {
      this.log.warn('usbwache', 'Der Eintrag liess sich nicht sichern (' + (e && e.message)
        + '). Der Adapter laeuft trotzdem — bis zum naechsten Neustart.');
      return false;
    }
  }
}

module.exports = { USBWache, TAKT_MS, ERSTER_LAUF_MS };
