'use strict';
/*
 * protokoll-blatt-test.js — vier Befunde vom 19.08.2026, am AUSGEDRUCKTEN Narkoseprotokoll
 * und an der Oberflaeche des Praxis-PCs festgestellt.
 *
 * 1) DAS GEWICHT LIESS SICH NICHT VON HAND EINTRAGEN. Drei Ursachen zusammen:
 *      a) drive() laeuft im 500-ms-Rundruf und schrieb das Feld #wt aus p.weightKg zurueck,
 *         sobald der getippte Wert abwich - die Zahl sprang beim Tippen zurueck.
 *      b) Der Zuhoerer hing nur an 'change'. Bei einem Zahlenfeld feuert das erst beim
 *         Verlassen des Feldes; wer tippte und weiterarbeitete, hatte nichts uebernommen.
 *      c) sendMetaForWindow() verwarf die Eingabe STILL, wenn kein Geraet anlag:
 *         "var ids = (p.devices||[]).map(...); if (!ids.length) return;" - kein Ziel, keine
 *         Meldung, kein Speichern.
 *
 * 2) EINE SOFORT ZURUECKGENOMMENE FEHLEINGABE STAND ZWEIMAL AUF DEM BLATT:
 *      10:34:53  [GEGEBEN] Atipamezol      10:34:58  [zurueckgenommen] Atipamezol
 *    Fuenf Sekunden - ein Vertipper, kein klinisches Ereignis.
 *
 * 3) JEDE GABE STAND ZUSAETZLICH IM VERLAUFSPROTOKOLL, also viermal dasselbe je Gabe auf
 *    einer Seite - oben mit Dosis und Weg, unten ohne beides.
 *
 * 4) DIE TABELLE "AKTUELLE NARKOSE-PARAMETER" WAR FAST LEER: HF, SpO2, EtCO2, AF und MAP
 *    alle "-", obwohl die Zeilen darunter ueber zehn Minuten saubere Werte zeigen (HF 96-99,
 *    SpO2 97). Gedruckt wurde der ZULETZT gemeldete Wert, und zum Zeitpunkt des Ausdrucks
 *    hatte das Geraet nichts mehr geliefert.
 *
 * Start: node tools/protokoll-blatt-test.js
 */
var fs = require('fs');
var path = require('path');

var WURZEL = path.join(__dirname, '..');
var pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function lies(rel) { return fs.readFileSync(path.join(WURZEL, rel), 'utf8'); }
function ohneKommentar(s) { return s.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/\/\/[^\n]*/g, ' '); }

var live = lies('ui/vetstation-live.js');
var liveCode = ohneKommentar(live);

console.log('VetStation — das ausgedruckte Narkoseprotokoll\n');

/* ---------------------------------------------------------------- 1) Gewicht */
console.log('1) Gewicht von Hand eintragen:');
ok('drive() erkennt, dass jemand tippt (Fokus oder frische Handeingabe)',
  /doc\.activeElement\s*===\s*wt/.test(liveCode) &&
  /__vsHandEingabe/.test(liveCode) && /<\s*8000/.test(liveCode),
  'Sonst springt die Zahl beim Tippen zurueck');
/*
 * UND DIE ERKENNUNG MUSS AUCH GREIFEN. Die erste Fassung dieser Pruefung suchte nur, ob
 * "doc.activeElement === wt" IRGENDWO steht. Beim Zerbrechen fiel auf: entfernt man das
 * "&& !tippt" aus der Schreibbedingung, bleibt die Erkennung stehen, wirkt aber nicht mehr -
 * und der Test blieb gruen. Ein abgesicherter Fehler ist schlimmer als gar keine Pruefung.
 */
ok('und die Schreibbedingung fragt sie auch ab',
  /if \(wt && p\.weightKg != null && !tippt\)/.test(liveCode),
  'Die Erkennung allein genuegt nicht - sie muss das Schreiben verhindern');
ok('das Gewicht wird schon beim Tippen uebernommen (input, entprellt)',
  /addEventListener\('input'[\s\S]{0,400}?t\.id\s*!==\s*'wt'/.test(liveCode),
  "Nur 'change' feuert erst beim Verlassen des Feldes");
ok('und weiterhin sofort bei Enter/Verlassen (change bleibt)',
  /addEventListener\('change'[\s\S]{0,300}?t\.id\s*!==\s*'wt'/.test(liveCode));
/*
 * Die Pruefung muss auf sendMetaForWindow BEGRENZT sein: dieselbe Zeile steht voellig zu
 * Recht in mergeSelected() ("keine Auswahl, nichts zu koppeln"). Die erste Fassung suchte
 * sie in der ganzen Datei und wurde dadurch zu Unrecht rot - der Test war falsch, nicht
 * der Code.
 */
var iSMW = liveCode.indexOf('function sendMetaForWindow');
var rumpfSMW = iSMW >= 0 ? liveCode.slice(iSMW, liveCode.indexOf('\n  }', iSMW)) : '';
ok('sendMetaForWindow gefunden', rumpfSMW.length > 200);
ok('ohne Geraet wird die Eingabe NICHT mehr still verworfen',
  rumpfSMW.indexOf('if (!ids.length) return;') < 0,
  'Genau diese Zeile war die Ursache');
ok('sie geht dann ueber die Patienten-ID in die Krankenakte',
  /type:\s*'setAkte'/.test(liveCode));
ok('und der Anwender erfaehrt, WOHIN sie ging',
  /noch kein Gerät angeschlossen/.test(live) && /kein Gerät und keine Patienten-ID/.test(live));

console.log('\n   Die Gegenstelle in der Bruecke:');
var reg = lies('bridge/src/registry.js');
ok('registry.setAkte() gibt es', /\bsetAkte\s*\(patientId,\s*meta\)\s*\{/.test(reg));
ok('sie hat denselben Schluessel-Riegel wie setMeta',
  /setAkte[\s\S]{0,700}?pid === '__proto__'/.test(reg),
  "Ein Eintrag unter '__proto__' wuerde jeden Datensatz ohne eigenes Gewicht veraendern");
ok('sie nimmt nur ein plausibles Gewicht an (endlich und > 0)',
  /setAkte[\s\S]{0,900}?Number\.isFinite\(g\)\s*&&\s*g\s*>\s*0/.test(reg));
ok('sie schreibt in dieselbe Ablage wie setMeta (akteStore + Datei)',
  /setAkte[\s\S]{0,900}?this\.akteStore\[pid\][\s\S]{0,200}?_akteSpeichern\(\)/.test(reg));
ok('die Nachricht ist im Modell erklaert', /SET_AKTE:\s*'setAkte'/.test(lies('bridge/src/model.js')));
ok('und der Server bedient sie', /case MSG\.SET_AKTE:/.test(lies('bridge/src/server.js')));

/* ---------------------------------------------------------------- 2) Storno */
console.log('\n2) Sofort zurueckgenommene Fehleingabe steht nicht mehr auf dem Blatt:');
ok('es gibt eine Korrekturfrist', /var KORRFRIST\s*=\s*(\d+)/.test(liveCode));
var frist = (liveCode.match(/var KORRFRIST\s*=\s*(\d+)/) || [])[1];
ok('sie ist kurz genug, um nur Vertipper zu treffen (' + (frist / 1000) + ' s)',
  Number(frist) > 0 && Number(frist) <= 300000, 'gefunden: ' + frist + ' ms');
ok('Gabe UND Ruecknahme fallen zusammen weg (beide markiert)',
  /weg\[i\]\s*=\s*1;\s*weg\[j\]\s*=\s*1/.test(liveCode));
ok('nur dieselbe Arznei wird zusammengefuehrt',
  /f\.med\.name\s*!==\s*e\.med\.name/.test(liveCode),
  'Sonst loescht eine Ruecknahme die Gabe eines ANDEREN Mittels');
ok('eine spaetere Ruecknahme bleibt sichtbar (Frist bricht die Suche ab)',
  />\s*KORRFRIST\)\s*break/.test(liveCode));
ok('wie viele Zeilen entfernt wurden, steht unter der Tabelle',
  /zurückgenommene Fehleingabe/.test(live),
  'Stilles Verschwinden waere genau der Fehler, den dieses Projekt vermeidet');
ok('und dass die vollstaendige Aufzeichnung erhalten bleibt',
  /vollständige Aufzeichnung bleibt in der Station gespeichert/.test(live));

/* ---------------------------------------------------------------- 3) Doppelfuehrung */
console.log('\n3) Gaben stehen nur noch EINMAL auf dem Blatt:');
ok('sie werden nicht mehr ins Verlaufsprotokoll gemischt',
  liveCode.indexOf('zeilen.concat(meds)') < 0);
ok('der Abschnitt heisst jetzt "Verlaufsprotokoll — Messwerte"',
  /Verlaufsprotokoll — Messwerte/.test(live));
ok('und die Tabelle "Verabreichte Medikamente" gibt es weiterhin',
  /Verabreichte Medikamente \/ Narkosemittel/.test(live));

/* ---------------------------------------------------------------- 4) Mittelwerte */
console.log('\n4) Oben stehen Mittelwerte statt des letzten Werts:');
ok('es gibt eine Mittelungsfunktion', /function mittel\(feld\)/.test(liveCode));
ok('sie ueberspringt Gaben-Zeilen', /function mittel[\s\S]{0,400}?e\.art === 'med'\) continue/.test(liveCode));
ok('sie zaehlt nur echte Zahlen', /function mittel[\s\S]{0,600}?isFinite\(x\)/.test(liveCode));
ok('ohne Messung bleibt der Strich - es wird nichts geraten',
  /if \(!m\.n\) return '—'/.test(liveCode));
ok('die Anzahl der Messungen steht in einer eigenen Spalte',
  /'Parameter', 'Mittelwert', 'Messungen', 'Narkose-Norm'/.test(liveCode));
ok('Rhythmus, Isofluran und Beatmung sind als "zuletzt" gekennzeichnet',
  /EKG-Rhythmus \(zuletzt\)/.test(live) && /Isofluran \(zuletzt\)/.test(live),
  'Sie lassen sich nicht mitteln - das muss dastehen');
ok('unter der Tabelle steht, worauf der Mittelwert beruht',
  /ab der ersten\s*'\s*\+\s*'Messung dieses Parameters|ab der ersten .{0,40}Messung dieses Parameters/.test(live));

/* --- Und die Rechnung selbst, an Zahlen statt an Quelltext ------------------------------- */
console.log('\n5) Die Mittelung rechnet richtig:');
/*
 * Beide Funktionen per KLAMMERZAEHLUNG ausschneiden. Ein Schnitt auf "\n      }" traf beim
 * ersten Versuch die falsche Zeile, und der Abschnitt meldete dann nur, dass er nichts
 * pruefen kann - das ist die stille Zustimmung, die dieses Projekt vermeiden will.
 */
function schneide(q, kopf) {
  var a = q.indexOf(kopf);
  if (a < 0) return '';
  var t = q.indexOf('{', a), tiefe = 0, j = t;
  for (; j < q.length; j++) { if (q[j] === '{') tiefe++; else if (q[j] === '}') { tiefe--; if (!tiefe) break; } }
  return q.slice(a, j + 1);
}
var quelle = schneide(live, 'function mittel(feld)') + '\n' + schneide(live, 'function zeig(m, stellen)');
var L = [
  { ts: 1, art: 'vital', hr: 100, spo2: 97 },
  { ts: 2, art: 'med', med: { name: 'Propofol' } },     /* muss uebersprungen werden */
  { ts: 3, art: 'vital', hr: 90, spo2: null },
  { ts: 4, art: 'vital', hr: null, spo2: 99 },
  { ts: 5, art: 'vital', hr: 110, spo2: '—' }           /* Zeichenkette zaehlt nicht */
];
/*
 * NICHT eval(): diese Datei laeuft unter 'use strict', und dort bekommt eval einen eigenen
 * Gueltigkeitsbereich - die Funktionsdeklarationen kamen nie heraus, und der Abschnitt
 * meldete nur, dass er nichts pruefen kann. new Function() gibt sie ausdruecklich zurueck.
 */
var mittel = null, zeig = null;
try {
  var paar = (new Function('L', quelle + '\n; return { mittel: mittel, zeig: zeig };'))(L);
  mittel = paar.mittel; zeig = paar.zeig;
} catch (e) { console.log('  (Funktionen nicht ausschneidbar: ' + e.message + ')'); }
if (typeof mittel === 'function') {
  var mh = mittel('hr'), ms = mittel('spo2'), mx = mittel('etco2');
  ok('HF: Mittel aus 100, 90, 110 = 100 bei n=3', mh.n === 3 && Math.round(mh.wert) === 100,
    JSON.stringify(mh));
  ok('SpO₂: null und "—" zaehlen nicht, 97 und 99 = 98 bei n=2', ms.n === 2 && Math.round(ms.wert) === 98,
    JSON.stringify(ms));
  ok('EtCO₂ ohne eine einzige Messung: n=0 und kein Wert', mx.n === 0 && mx.wert === null);
  ok('die Anzeige rundet und schweigt bei n=0',
    zeig(mh, 0) === '100' && zeig(mx, 0) === '—');
} else {
  ok('die Mittelungsfunktion liess sich zum Rechnen ausschneiden', false,
    'Ohne sie prueft dieser Abschnitt nur Quelltext');
}

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
