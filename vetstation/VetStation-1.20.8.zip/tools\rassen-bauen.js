'use strict';
/*
 * rassen-bauen.js — macht aus den Recherche-JSONs die Datei quellcode/ui/shared/breed-katalog.js.
 *
 * Warum generiert und nicht von Hand: es sind mehrere hundert Rassen aus dreizehn Quelldateien,
 * die einander ueberschneiden (der Mops steht in der Brachy- UND in der FCI-Liste). Von Hand
 * zusammengefuehrt entstuende genau das, was man in so einer Datei nicht will: zwei Eintraege
 * fuer dasselbe Tier, von denen einer die Warnung hat und der andere nicht.
 *
 * Die MEDIZIN steht nicht hier, sondern in ui/shared/narkose-risiko.js (handgepflegt). Dieses
 * Skript erzeugt nur den Rassekatalog und die Erkrankungen, die die Recherche zusaetzlich
 * geliefert hat, und verknuepft beides ueber Schluessel.
 *
 * Aufruf:  node tools/rassen-bauen.js  [--quelle <ordner>]
 */
const fs = require('fs');
const path = require('path');

/* Quellordner: standardmaessig die im Repo archivierten Rechercheauszuege.
 * Anderer Ordner: node tools/rassen-bauen.js --quelle <pfad> */
const iQ = process.argv.indexOf('--quelle');
const DIR = iQ > 0 && process.argv[iQ + 1] ? path.resolve(process.argv[iQ + 1]) : path.join(__dirname, '..', 'docs', 'rassen-quellen');
const QUELL = path.join(__dirname, '..');
const OUT = path.join(QUELL, 'ui/shared/breed-katalog.js');

const VB = require(path.join(QUELL, 'ui/shared/breed-genetics.js'));
require(path.join(QUELL, 'ui/shared/narkose-risiko.js'));

/* ------------------------------------------------------------------ Werkzeug */
function norm(s) {
  return String(s == null ? '' : s).toLowerCase()
    .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
    .replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
}
function slug(s) { return norm(s).replace(/ /g, '-').slice(0, 48) || 'x'; }
function kurz(s, n) {
  s = String(s == null ? '' : s).trim().replace(/\s+/g, ' ');
  if (s.length <= n) return s;
  const schnitt = s.slice(0, n);
  const p = Math.max(schnitt.lastIndexOf('. '), schnitt.lastIndexOf('; '));
  return (p > n * 0.6 ? schnitt.slice(0, p + 1) : schnitt.trim() + ' …');
}
/* Freitext einer Stabilisierungsanweisung in Schritte zerlegen. Nummerierte Listen und
 * Aufzaehlungen kommen aus der Recherche in ganz unterschiedlicher Form. */
function schritte(text) {
  const s = String(text || '').trim().replace(/\s+/g, ' ');
  if (!s) return [];
  let teile = s.split(/(?:^|\s)(?:\d{1,2}[.)]\s+|[•▪–—-]\s+)/).map((x) => x.trim()).filter(Boolean);
  if (teile.length < 2) teile = s.split(/(?<=[.!?])\s+(?=[A-ZÄÖÜ])/).map((x) => x.trim()).filter(Boolean);
  if (teile.length < 2) teile = [s];
  return teile.map((x) => kurz(x, 420)).slice(0, 12);
}
function liste(x) {
  if (!x) return [];
  if (Array.isArray(x)) return x.map((s) => String(s).trim()).filter(Boolean);
  return String(x).split(/[,;]/).map((s) => s.trim()).filter(Boolean);
}

/* ----------------------------------------------- Schluessel-Gleichsetzungen
 * Die Recherche vergibt eigene Schluessel. Wo sie dasselbe meint wie ein bereits
 * gepflegter Eintrag, wird darauf gezeigt statt ein zweiter Eintrag angelegt —
 * sonst haette dieselbe Katze „HCM" zweimal, einmal mit und einmal ohne Protokoll. */
const GLEICH = {
  'mdr1-abcb1-defekt': 'mdr1', 'mdr1': 'mdr1', 'abcb1': 'mdr1', 'mdr1-defekt': 'mdr1',
  'abcb1-defekt': 'mdr1', 'mdr1-abcb1': 'mdr1', 'p-glykoprotein-defekt': 'mdr1',
  'abcb1-katze': 'mdr1-cat', 'mdr1-katze': 'mdr1-cat', 'abcb1-defekt-katze': 'mdr1-cat',
  'windhund-pharmakologie': 'sighthound', 'sighthound': 'sighthound', 'cyp2b11': 'sighthound',
  'windhund-phaenotyp': 'sighthound',
  'boas': 'boas', 'brachyzephales-syndrom': 'boas', 'brachyzephales-obstruktives-atemwegssyndrom': 'boas',
  'maligne-hyperthermie': 'malignant-hyperthermia', 'mh': 'malignant-hyperthermia',
  'ryr1': 'malignant-hyperthermia',
  'hcm': 'hcm-cat', 'hcm-katze': 'hcm-cat', 'hypertrophe-kardiomyopathie': 'hcm-cat',
  'hcm-mybpc3': 'hcm-cat', 'feline-hcm': 'hcm-cat',
  'pkd': 'pkd-cat', 'pkd1': 'pkd-cat', 'polyzystische-nierenerkrankung': 'pkd-cat',
  'polyzystische-niere': 'pkd-cat',
  'von-willebrand': 'vwd', 'vwd': 'vwd', 'von-willebrand-erkrankung': 'vwd', 'vwd-typ-1': 'vwd',
  'dcm': 'dcm-doberman', 'dilatative-kardiomyopathie': 'dcm-doberman',
  'mmvd': 'mmvd-cavalier', 'myxomatoese-mitralklappenerkrankung': 'mmvd-cavalier',
  'mitralklappenendokardiose': 'mmvd-cavalier',
  'pk-mangel': 'pk-deficiency', 'pyruvatkinase-mangel': 'pk-deficiency', 'pkdef': 'pk-deficiency',
  'pfk-mangel': 'pfk-deficiency', 'phosphofruktokinase-mangel': 'pfk-deficiency',
  'hyperurikosurie': 'hyperuricosuria',
  'acepromazin-ueberempfindlichkeit': 'boxer-ace',
  'atropinesterase': 'atropinesterase', 'atropinesterase-kaninchen': 'atropinesterase',
  'insulinom': 'insulinom-frettchen', 'frettchen-insulinom': 'insulinom-frettchen',
  'degu-diabetes': 'degu-diabetes', 'diabetes-mellitus-degu': 'degu-diabetes',
  'satin-syndrom': 'satin-osteodystrophie', 'satin-osteodystrophie': 'satin-osteodystrophie',
  'fur-slip': 'fellrutschen', 'fellrutschen': 'fellrutschen',
  'wobble-syndrom': 'morph-neuro', 'spider-wobble': 'morph-neuro', 'enigma-syndrom': 'morph-neuro',
  'jaguar-syndrom': 'morph-neuro',
  'malokklusion': 'malokklusion', 'zahnfehlstellung': 'malokklusion',
  'kongenitale-taubheit': 'taubheit', 'taubheit': 'taubheit', 'waardenburg': 'taubheit',
  'merle': 'merle', 'doppel-merle': 'merle',
  /* Stoffwechsel-/Neuro-Recherche: auf die bereits gepflegten Protokolle zeigen lassen. */
  /* maligne-hyperthermie steht schon oben bei ryr1 - hier waere sie ein zweites Mal
     im selben Objekt und damit wirkungslos (Befund 18.08.2026). */
  'portosystemischer-shunt': 'pss', 'cddy-ivdd': 'chondro-ivdd',
  'juvenile-hypoglykaemie': 'toy-hypoglykaemie',
  'hypoadrenokortizismus': 'addison', 'diabetes-mellitus': 'diabetes',
  'idiopathische-epilepsie': 'epilepsie',
};
/* Recherche-Schluessel, die in Wahrheit RETTUNGSWEGE sind und keine Erkrankung —
 * sie tauchen bei manchen Rassen in „krankheiten" auf. Dort weggelassen. */
const IST_RETTUNG = new Set([
  'opioid-ueberhang', 'makrozyklische-lakton-toxikose', 'ivermectin-toxikose',
  'alpha2-ueberdosierung', 'acepromazin-hypotension', 'last', 'lokalanaesthetika-intoxikation',
  'anaphylaxie', 'hypothermie', 'hypoglykaemie', 'hyperkaliaemie', 'regurgitation-aspiration',
  'herzstillstand', 'reanimation', 'nsaid-ueberdosierung', 'nicht-aufwachender-patient',
]);
const RETTUNG_ZIEL = {
  'opioid-ueberhang': 'opioid-ueberhang',
  'makrozyklische-lakton-toxikose': 'ivermectin-mdr1', 'ivermectin-toxikose': 'ivermectin-mdr1',
  'alpha2-ueberdosierung': 'alpha2-ueberdosis', 'acepromazin-hypotension': 'ace-hypotension',
  'last': 'last', 'lokalanaesthetika-intoxikation': 'last', 'anaphylaxie': 'anaphylaxie',
  'hypothermie': 'hypothermie', 'hypoglykaemie': 'hypoglykaemie', 'hyperkaliaemie': 'hyperkaliaemie',
  'regurgitation-aspiration': 'regurgitation', 'herzstillstand': 'cpr', 'reanimation': 'cpr',
  'nsaid-ueberdosierung': 'nsaid-ueberdosis', 'nicht-aufwachender-patient': 'nicht-aufwachen',
};

/* -------------------------------------------------- Gruppen aus dem Freitext */
function gruppenAus(text, sp, condKeys) {
  const t = norm(text) + ' ' + condKeys.join(' ');
  const g = new Set();
  /* „brachy" traegt das BOAS-Protokoll (Hund/Katze). Ein kurzkoepfiges Zwergkaninchen ist zwar
   * auch brachyzephal, aber ihm mit einem Hundeprotokoll zu kommen waere schlicht falsch —
   * seine Hinweise stehen in kanin-zwerg. */
  if (/brachyzephal|boas|kurzkoepfig/.test(t) && (sp === 'hund' || sp === 'katze')) g.add('brachy');
  if (/windhund|sighthound|greyhound|whippet|galgo|saluki|barsoi|afghan|deerhound|wolfshund/.test(t)) g.add('sighthound');
  if (/mdr1|abcb1/.test(t)) g.add('mdr1');
  if (/chondrodystroph|cddy|ivdd/.test(t)) g.add('chondro');
  if (/merle|taubheit|waardenburg/.test(t)) { /* keine eigene Gruppe */ }
  if (sp === 'hund') {
    if (/riesenrasse|molosser|giant/.test(t)) g.add('giant');
    /* NICHT ueber die FCI-Gruppe 9 ("Gesellschafts- und Begleithunde") — da stehen Mops,
     * Bulldogge und Pudel drin, und keiner davon ist eine Zwergrasse unter 5 kg. */
    if (/zwerg|toy|miniature|teacup|kleinst/.test(t)) g.add('toy');
  }
  if (sp === 'hamster') {
    if (/zwerghamster|phodopus|campbell|dsungar|roborowski|chinesisch/.test(t)) g.add('zwerghamster');
    if (/langhaar|teddy|angora/.test(t)) g.add('langhaar');
  }
  if (sp === 'kaninchen') {
    /* Getrennt halten: ein Deutscher Widder wiegt 5 kg und ist kein Zwerg. Ein Zwergwidder ist
     * beides und bekommt dann auch beide Hinweise. */
    if (/riese|gross|flaemisch|giant/.test(t)) g.add('riesenkanin');
    if (/zwerg|dwarf|hermelin|mini|loewen|netherland|polish/.test(t)) g.add('zwergkanin');
    if (/widder|lop/.test(t)) g.add('widderkanin');
  }
  if (/nackt|haarlos|skinny|baldwin|sphynx|scaleless|silkback/.test(t)) g.add('nackt');
  if (/angora|langhaar|woll|peruaner|sheltie|texel|coronet|merino|alpaka|lunkarya/.test(t)) g.add('langhaar');
  if (/morph|spider|jaguar|enigma|lemon frost|letalfaktor/.test(t)) g.add('morph');
  return Array.from(g);
}

/* Artweite Zusatzrisiken: was fuer JEDES Tier dieser Art gilt und im OP zaehlt.
 * Sie haengen an der Rasse, weil der Narkoseplan an der Rasse haengt. */
const ART_BASIS = {
  kaninchen: ['atropinesterase', 'nager-dysbiose'],
  meerschwein: ['nager-dysbiose'],
  /* Ratte und Maus vertragen deutlich mehr Antibiotika als Hasenartige und Hystricomorpha —
   * ihnen die Dysbiose-Warnung anzuhaengen waere falsch. Hamster dagegen reagiert wie das
   * Meerschweinchen. Siehe docs/rassen-quellen/nager-neue-arten.json. */
  hamster: ['nager-dysbiose'],
  chinchilla: ['nager-dysbiose', 'fellrutschen', 'hitzeempfindlich'],
  degu: ['nager-dysbiose', 'degu-diabetes'],
  frettchen: ['insulinom-frettchen', 'kardiomyopathie-frettchen'],
  reptil: ['reptil-basis'],
};
const ART_PROTOKOLL = {
  hund: 'hund', katze: 'katze',
  kaninchen: 'kaninchen', meerschwein: 'meerschwein', chinchilla: 'chinchilla',
  degu: 'degu', ratte: 'ratte', maus: 'maus', hamster: 'hamster', rennmaus: 'rennmaus',
  frettchen: 'frettchen', reptil: 'reptil',
};

/* ------------------------------------------------------------------- Einlesen */
/* Die Rechercheagenten liefern nicht immer die vereinbarte Huelle: manche schreiben eine reine
 * Liste, manche ein Objekt mit Zahlenschluesseln (serialisiertes Array), manche legen Teilstuecke
 * in einen Unterordner. Statt daran zu scheitern, wird die Form hier erkannt — der Inhalt ist in
 * allen Faellen derselbe. */
function normForm(j) {
  if (Array.isArray(j)) return { rassen: j, krankheiten: [] };
  if (j && typeof j === 'object') {
    if (Array.isArray(j.rassen) || Array.isArray(j.krankheiten)) {
      return { rassen: j.rassen || [], krankheiten: j.krankheiten || [] };
    }
    const werte = Object.values(j).filter((v) => v && typeof v === 'object');
    const rassen = [], krank = [];
    werte.forEach((v) => {
      if (Array.isArray(v)) { v.forEach((x) => { if (x && x.name && x.sp) rassen.push(x); else if (x && x.key) krank.push(x); }); }
      else if (v.name && v.sp) rassen.push(v);
      else if (v.key && v.name) krank.push(v);
    });
    return { rassen: rassen, krankheiten: krank };
  }
  return { rassen: [], krankheiten: [] };
}
function sammleDateien(dir) {
  const out = [];
  fs.readdirSync(dir, { withFileTypes: true }).forEach((e) => {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...sammleDateien(p));
    else if (e.name.endsWith('.json')) out.push(p);
  });
  return out;
}
const dateien = sammleDateien(DIR);
if (!dateien.length) { console.error('Keine Recherchedateien in ' + DIR); process.exit(1); }

const rohRassen = [];
const rohKrank = [];
for (const p of dateien) {
  const f = path.relative(DIR, p).replace(/\\/g, '/');
  let j;
  try { j = normForm(JSON.parse(fs.readFileSync(p, 'utf8'))); }
  catch (e) { console.error('  ! ' + f + ' unlesbar: ' + e.message.slice(0, 70)); continue; }
  (j.rassen || []).forEach((r) => { if (r && r.name && r.sp) rohRassen.push(Object.assign({ __q: f }, r)); });
  (j.krankheiten || []).forEach((k) => { if (k && k.key && k.name) rohKrank.push(Object.assign({ __q: f }, k)); });
  console.log('  ' + f.padEnd(42) + (j.rassen || []).length + ' Rassen, ' + (j.krankheiten || []).length + ' Krankheiten');
}
console.log('  ------------------------------------------------------------');
console.log('  roh: ' + rohRassen.length + ' Rassen, ' + rohKrank.length + ' Krankheiten\n');

/* ------------------------------------------------- Krankheiten zusammenfuehren */
function zielKey(k) {
  const s = slug(k);
  if (GLEICH[s]) return GLEICH[s];
  if (VB.CONDITIONS[s]) return s;
  return s;
}
const CONDS = {};          /* neue Erkrankungen, die es noch nicht gibt */
const RESC = {};           /* Rettungswege, die aus „stabilisieren" entstehen */
const ERG = {};            /* Nachtraege zu bereits gepflegten Erkrankungen */
const kondNamen = {};      /* normalisierter Name -> key, gegen Doppelungen */

rohKrank.forEach((k) => {
  const key = zielKey(k.key);
  if (IST_RETTUNG.has(slug(k.key))) return;         /* ist ein Rettungsweg, keine Erkrankung */
  const nk = norm(k.name).slice(0, 60);
  if (VB.CONDITIONS[key]) {                         /* schon gepflegt: nur Erstwahl/Rettung ergaenzen */
    ergaenzeVorhandene(key, k);
    kondNamen[nk] = key;
    return;
  }
  if (kondNamen[nk] && kondNamen[nk] !== key) return;   /* gleicher Name, anderer Schluessel */
  kondNamen[nk] = key;
  const alt = CONDS[key];
  if (alt) { verschmelzeKond(alt, k); return; }
  CONDS[key] = neueKond(key, k);
});

function ikon(kat) {
  const t = norm(kat);
  if (/herz|kreislauf/.test(t)) return '💗';
  if (/atemweg|lunge/.test(t)) return '👃';
  if (/pharmakogenetik/.test(t)) return '🧬';
  if (/gerinnung|blut/.test(t)) return '🩸';
  if (/niere/.test(t)) return '🫘';
  if (/stoffwechsel/.test(t)) return '⚗️';
  if (/neuro|nerv/.test(t)) return '🧠';
  if (/muskel/.test(t)) return '💪';
  if (/skelett|knochen/.test(t)) return '🦴';
  if (/auge/.test(t)) return '👁️';
  if (/haut/.test(t)) return '🧴';
  if (/temperatur/.test(t)) return '🌡️';
  return '⚠️';
}
function risikoAus(k) {
  const t = norm((k.narkoseRisiko || '') + ' ' + (k.kurz || ''));
  if (/toed|letal|lebensbedroh|herzstillstand|ploetzlich|reanimation|kontraindiziert|fatal/.test(t)) return 'hoch';
  if (/schwer|erheblich|deutlich|hochgradig|dekompens|krise/.test(t)) return 'mittel';
  return 'niedrig';
}
function neueKond(key, k) {
  const c = {
    name: kurz(k.name, 110),
    gene: kurz(k.gen, 160) || undefined,
    cat: kurz(k.kategorie, 24) || 'Sonstiges',
    icon: ikon(k.kategorie),
    risk: risikoAus(k),
    short: kurz(k.kurz, 420),
    anesth: kurz(k.narkoseRisiko, 700),
    sources: liste(k.quellen).map((s) => kurz(s, 140)).slice(0, 4),
  };
  /* Manche Rechercheeintraege sind in Wahrheit Notfallablaeufe („Rettungsalgorithmus",
   * „Ivermectin-Toxikose"). Ihr Text gehoert unter „stabilisieren" und nicht unter
   * „Narkose erste Wahl" — sonst steht ein Notfallplan da, wo ein Narkoseplan hingehoert. */
  if (/rettungs?algorithmus|notfallalgorithmus|ueberdosier|intoxikation|toxikose|-krise|krise\b|reanimation/i.test(k.name)) c.rescueOnly = true;
  if (k.erstwahl) c.first = kurz(k.erstwahl, 800);
  const meiden = liste(k.meiden).map((s) => kurz(s, 90)).slice(0, 10);
  if (meiden.length) c.avoid = meiden;
  if (k.stabilisieren) {
    const rk = 'r-' + key;
    RESC[rk] = {
      name: 'Stabilisieren: ' + kurz(k.name, 80),
      zeichen: kurz(k.narkoseRisiko, 300) || undefined,
      schritte: schritte(k.stabilisieren),
      sources: c.sources,
    };
    c.rescue = [rk];
  }
  if (k.konfidenz === 'niedrig') c.unsicher = true;
  /* Traegt die neue Erkrankung denselben Schluessel wie ein handgepflegtes Protokoll
   * (z. B. 'pss', 'addison', 'epilepsie'), wird es verknuepft — sonst stuende die gepruefte
   * Anleitung ungenutzt daneben, waehrend die Karte nur den Recherchetext zeigt. */
  if (VB.PROTOCOLS[key]) c.protocol = [key];
  return c;
}
function verschmelzeKond(alt, k) {
  if (!alt.first && k.erstwahl) alt.first = kurz(k.erstwahl, 800);
  const m = liste(k.meiden).map((s) => kurz(s, 90));
  if (m.length) { alt.avoid = Array.from(new Set((alt.avoid || []).concat(m))).slice(0, 12); }
  if (!alt.short && k.kurz) alt.short = kurz(k.kurz, 420);
  if (alt.anesth && k.narkoseRisiko && alt.anesth.length < 200) alt.anesth = kurz(k.narkoseRisiko, 700);
  const q = liste(k.quellen).map((s) => kurz(s, 140));
  alt.sources = Array.from(new Set((alt.sources || []).concat(q))).slice(0, 5);
}
/* Vorhandene, handgepflegte Erkrankung: NUR ergaenzen, was fehlt. */
function ergaenzeVorhandene(key, k) {
  const c = VB.CONDITIONS[key];
  const e = ERG[key] || (ERG[key] = {});
  if (!c.first && !e.first && k.erstwahl) e.first = kurz(k.erstwahl, 800);
  const m = liste(k.meiden).map((s) => kurz(s, 90));
  if (m.length && !(c.avoid || []).length) e.avoid = Array.from(new Set((e.avoid || []).concat(m))).slice(0, 12);
  if (k.stabilisieren && !(c.rescue || []).length && !e.rescue) {
    const rk = 'r-' + key;
    RESC[rk] = { name: 'Stabilisieren: ' + kurz(k.name, 80), schritte: schritte(k.stabilisieren),
      sources: liste(k.quellen).map((s) => kurz(s, 140)).slice(0, 4) };
    e.rescue = [rk];
  }
}

/* --------------------------------------------------- Rassen zusammenfuehren */
const BREEDS = [];
const nachName = {};      /* sp + '|' + normalisierter Name -> Eintrag */
const nachAlias = {};     /* sp + '|' + normalisierter Alias -> Eintrag (nur eindeutige) */
const idsVergeben = {};

function bekannteRasse(name, sp) {
  const tr = VB.search(name, sp, 3);
  return (tr.length && tr[0].score === 100) ? tr[0].breed : null;
}
function freieId(basis, sp) {
  let id = basis;
  if (idsVergeben[id] || VB.byId(id)) id = basis + '-' + sp;
  let n = 2;
  while (idsVergeben[id]) { id = basis + '-' + sp + '-' + n; n++; }
  idsVergeben[id] = true;
  return id;
}

rohRassen.forEach((r) => {
  const sp = String(r.sp).trim();
  const nn = norm(r.name);
  if (!nn) return;
  const schl = sp + '|' + nn;
  let e = nachName[schl] || nachAlias[schl];

  const condKeys = liste(r.krankheiten)
    .map((k) => slug(k))
    .filter((k) => !IST_RETTUNG.has(k))
    .map((k) => zielKey(k))
    .filter((k) => VB.CONDITIONS[k] || CONDS[k]);
  const rettKeys = liste(r.krankheiten).map((k) => slug(k))
    .filter((k) => IST_RETTUNG.has(k)).map((k) => RETTUNG_ZIEL[k]).filter(Boolean);

  if (!e) {
    const vorhanden = bekannteRasse(r.name, sp);
    const id = vorhanden ? vorhanden.id : freieId(slug(r.name), sp);
    if (vorhanden) idsVergeben[id] = true;
    e = { id: id, name: String(r.name).trim().slice(0, 70), sp: sp,
      aliases: [], groups: [], conditions: [], rescue: [], freq: '', note: '', __gruppe: '' };
    BREEDS.push(e);
    nachName[schl] = e;
  }
  liste(r.aliase).forEach((a) => {
    const na = norm(a);
    if (!na || na === nn) return;
    if (e.aliases.indexOf(a) < 0 && e.aliases.length < 8) e.aliases.push(String(a).trim().slice(0, 48));
    const ak = sp + '|' + na;
    if (!nachName[ak]) { if (nachAlias[ak] && nachAlias[ak] !== e) nachAlias[ak] = null; else nachAlias[ak] = e; }
  });
  condKeys.forEach((k) => { if (e.conditions.indexOf(k) < 0) e.conditions.push(k); });
  rettKeys.forEach((k) => { if (e.rescue.indexOf(k) < 0) e.rescue.push(k); });
  e.__gruppe += ' ' + (r.gruppe || '');
  if (r.haeufigkeit && r.haeufigkeit.length > (e.freq || '').length) e.freq = kurz(r.haeufigkeit, 120);
  if (r.hinweis && r.hinweis.length > (e.note || '').length) e.note = kurz(r.hinweis, 260);
});

/* Gruppen + artweite Grundrisiken nachtragen */
BREEDS.forEach((e) => {
  e.groups = gruppenAus(e.__gruppe + ' ' + e.name, e.sp, e.conditions);
  (ART_BASIS[e.sp] || []).forEach((k) => { if (e.conditions.indexOf(k) < 0) e.conditions.push(k); });
  delete e.__gruppe;
  if (!e.freq) delete e.freq;
  if (!e.note) delete e.note;
  if (!e.rescue.length) delete e.rescue;
  if (!e.aliases.length) delete e.aliases;
});

/* ------------------------------------------------- Beinahe-Doppelte zusammenlegen
 * „Collie Kurzhaar" und „Kurzhaarcollie" sind dasselbe Tier; die eine Fassung kommt aus der
 * Recherche, die andere ist handgepflegt. Zwei Eintraege sind hier schlimmer als einer zu wenig:
 * der Tierarzt waehlt den einen, und die Warnung haengt am anderen. Zusammengelegt wird, wenn der
 * NAME der einen Rasse ein ALIAS der anderen ist (gleiche Tierart). Der handgepflegte Eintrag
 * gewinnt, sonst der zuerst eingelesene. */
(function zusammenlegen() {
  const nachAlias2 = {};
  BREEDS.forEach((b) => {
    (b.aliases || []).forEach((a) => {
      const k = b.sp + '|' + norm(a);
      if (nachAlias2[k] === undefined) nachAlias2[k] = b; else if (nachAlias2[k] !== b) nachAlias2[k] = null;
    });
  });
  const weg = new Set();
  BREEDS.forEach((b) => {
    if (weg.has(b.id)) return;
    const ziel = nachAlias2[b.sp + '|' + norm(b.name)];
    if (!ziel || ziel === b || weg.has(ziel.id)) return;
    /* Wer ueberlebt: der handgepflegte Eintrag aus breed-genetics.js. */
    const bHand = !!VB.byId(b.id) && !b.__neu, zHand = !!VB.byId(ziel.id) && !ziel.__neu;
    const bleibt = (zHand && !bHand) ? ziel : (bHand && !zHand) ? b : ziel;
    const geht = bleibt === b ? ziel : b;
    ['conditions', 'groups', 'rescue'].forEach((f) => {
      const m = (bleibt[f] || []).slice();
      (geht[f] || []).forEach((x) => { if (m.indexOf(x) < 0) m.push(x); });
      if (m.length) bleibt[f] = m;
    });
    const al = (bleibt.aliases || []).slice();
    [geht.name].concat(geht.aliases || []).forEach((a) => {
      if (a && norm(a) !== norm(bleibt.name) && al.map(norm).indexOf(norm(a)) < 0 && al.length < 10) al.push(a);
    });
    if (al.length) bleibt.aliases = al;
    if (!bleibt.freq && geht.freq) bleibt.freq = geht.freq;
    if ((geht.note || '').length > (bleibt.note || '').length) bleibt.note = geht.note;
    weg.add(geht.id);
  });
  for (let i = BREEDS.length - 1; i >= 0; i--) if (weg.has(BREEDS[i].id)) BREEDS.splice(i, 1);
  if (weg.size) console.log('  zusammengelegt: ' + weg.size + ' Beinahe-Doppelte (' + [...weg].slice(0, 6).join(', ') + ')');
})();

/* Was sich NICHT zusammenlegen laesst, muss wenigstens dasselbe wissen.
 * „Malinois" ist Alias von „Belgischer Schaeferhund" UND von „Belgischer Schaeferhund Malinois" —
 * bei mehreren Anwaertern greift die Zusammenlegung oben bewusst nicht (Zwergpudel und Toypudel
 * sind zwei FCI-Varietaeten und duerfen NICHT verschmelzen). Gefaehrlich ist aber nicht der
 * doppelte Eintrag, sondern der Unterschied: der Tierarzt waehlt die eine Fassung, und die
 * Warnung haengt an der anderen. Also werden die Erkrankungen vereinigt, die Eintraege bleiben. */
(function warnungenAngleichen() {
  let angeglichen = 0;
  for (let runde = 0; runde < 2; runde++) {
    const aliasIx = {};
    BREEDS.forEach((b) => { (b.aliases || []).forEach((a) => {
      const k = b.sp + '|' + norm(a); (aliasIx[k] = aliasIx[k] || []).push(b);
    }); });
    BREEDS.forEach((b) => {
      (aliasIx[b.sp + '|' + norm(b.name)] || []).forEach((z) => {
        if (z === b) return;
        [[b, z], [z, b]].forEach(([von, nach]) => {
          (von.conditions || []).forEach((c) => {
            if ((nach.conditions || []).indexOf(c) < 0) { nach.conditions = (nach.conditions || []).concat([c]); angeglichen++; }
          });
        });
      });
    });
  }
  if (angeglichen) console.log('  Warnungen angeglichen: ' + angeglichen + ' Zuordnungen bei Beinahe-Doppelten');
})();

/* -------------------------------------------------------- Artprotokolle binden
 * Damit auch eine Rasse ohne einzelne Erbkrankheit einen Plan hat, bekommt jede Art
 * eine Grundgruppe mit ihrem Protokoll. */
const ART_NAME = { hund: 'Hund', katze: 'Katze', kaninchen: 'Kaninchen', meerschwein: 'Meerschweinchen',
  ratte: 'Ratte', maus: 'Maus', hamster: 'Hamster', rennmaus: 'Rennmaus',
  chinchilla: 'Chinchilla', degu: 'Degu', frettchen: 'Frettchen', reptil: 'Reptil' };
const ART_GRUPPEN = {};
Object.keys(ART_PROTOKOLL).forEach((sp) => {
  const g = 'art-' + sp;
  ART_GRUPPEN[g] = { name: 'Grundsätze ' + (ART_NAME[sp] || sp), icon: '🐾', color: '#16a06a',
    desc: 'Narkosegrundsätze dieser Tierart – gelten unabhängig von der Rasse.',
    protocol: [ART_PROTOKOLL[sp]] };
  BREEDS.forEach((e) => { if (e.sp === sp && e.groups.indexOf(g) < 0) e.groups.push(g); });
});
/* Die von Hand gepflegten Rassen aus breed-genetics.js stehen nicht zwangslaeufig in der
 * Recherche. Ohne diesen Nachtrag haetten ausgerechnet sie keinen Artplan — als Stummel
 * eintragen, register() vereinigt die Gruppen an der vorhandenen Rasse. */
const schonDa = {}; BREEDS.forEach((b) => { schonDa[b.id] = 1; });
VB.BREEDS.forEach((b) => {
  const g = 'art-' + b.sp;
  if (schonDa[b.id] || !ART_GRUPPEN[g]) return;
  BREEDS.push({ id: b.id, name: b.name, sp: b.sp, groups: [g], conditions: (ART_BASIS[b.sp] || []).slice() });
});

/* ----------------------------------------------------------------- Ausgabe */
function js(v) { return JSON.stringify(v); }
function objZeile(o) {
  return '{' + Object.keys(o).map((k) => (/^[a-z][a-zA-Z0-9]*$/.test(k) ? k : js(k)) + ':' + js(o[k])).join(',') + '}';
}

const kopf = `/* ============================================================================
   shared/breed-katalog.js  ·  Canis VET-PHARM / VetStation
   RASSEKATALOG aller Tierarten des Moduls + die dazugehoerigen Erbkrankheiten.
   Haengt sich ueber VETBREED.register() an shared/breed-genetics.js an und setzt
   die Erstwahl-Protokolle aus shared/narkose-risiko.js voraus.
   ----------------------------------------------------------------------------
   ERZEUGT, NICHT VON HAND GESCHRIEBEN (tools/rassen-bauen.js aus den geprueften
   Rechercheauszuegen). Aenderungen an einzelnen Rassen gehoeren in die Quelle,
   sonst sind sie beim naechsten Bau weg. Handgepflegte Eintraege in
   breed-genetics.js/narkose-risiko.js werden NIE ueberschrieben — register()
   ergaenzt dort nur fehlende Felder.

   Quellen der Rassedaten: FCI/VDH, FIFe/WCF/TICA/GCCF, ZDRK/BRC/ARBA,
   CliniPharm/CliniTox (vetpharm.uzh.ch), Vetidata, WSU-VCPL, OMIA,
   UC Davis VGL, PennGen, WSAVA/ACVAA/AAHA, BSAVA, Carpenter Exotic Animal
   Formulary, RVC VetCompass, peer-reviewte Fachjournale.
   ALLES Referenz-/Lernhilfe – kein Ersatz fuer klinisches Urteil.
   ============================================================================ */
(function (root) {
  'use strict';
  var VB = root.VETBREED;
  if (!VB || !VB.register) return;
`;

const zeilen = [];
zeilen.push('  var GROUPS = {');
zeilen.push(Object.keys(ART_GRUPPEN).map((k) => '    ' + js(k) + ': ' + objZeile(ART_GRUPPEN[k])).join(',\n'));
zeilen.push('  };');
zeilen.push('');
zeilen.push('  /* Erkrankungen, die in breed-genetics.js noch nicht stehen. */');
zeilen.push('  var CONDITIONS = {');
zeilen.push(Object.keys(CONDS).sort().map((k) => '    ' + js(k) + ': ' + objZeile(CONDS[k])).join(',\n'));
zeilen.push('  };');
zeilen.push('');
zeilen.push('  /* Nachtrag zu bereits gepflegten Erkrankungen: nur fehlende Felder. */');
zeilen.push('  var NACHTRAG = {');
zeilen.push(Object.keys(ERG).filter((k) => Object.keys(ERG[k]).length).sort()
  .map((k) => '    ' + js(k) + ': ' + objZeile(ERG[k])).join(',\n'));
zeilen.push('  };');
zeilen.push('');
zeilen.push('  /* Rettungswege aus den Recherchetexten (Handgepflegtes hat Vorrang). */');
zeilen.push('  var RESCUE = {');
zeilen.push(Object.keys(RESC).sort().map((k) => '    ' + js(k) + ': ' + objZeile(RESC[k])).join(',\n'));
zeilen.push('  };');
zeilen.push('');
zeilen.push('  var BREEDS = [');
zeilen.push(BREEDS.sort((a, z) => (a.sp === z.sp ? (a.name < z.name ? -1 : 1) : (a.sp < z.sp ? -1 : 1)))
  .map((b) => '    ' + objZeile(b)).join(',\n'));
zeilen.push('  ];');
zeilen.push('');
zeilen.push('  Object.keys(NACHTRAG).forEach(function (k) { if (!CONDITIONS[k]) CONDITIONS[k] = NACHTRAG[k]; });');
zeilen.push('  VB.register({ groups: GROUPS, conditions: CONDITIONS, rescue: RESCUE, breeds: BREEDS });');
zeilen.push("})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));");

fs.writeFileSync(OUT, kopf + zeilen.join('\n') + '\n', 'utf8');

const proArt = {};
BREEDS.forEach((b) => { proArt[b.sp] = (proArt[b.sp] || 0) + 1; });
console.log('geschrieben: ' + OUT);
console.log('  Rassen gesamt: ' + BREEDS.length);
Object.keys(proArt).sort().forEach((s) => console.log('    ' + s.padEnd(14) + proArt[s]));
console.log('  neue Erkrankungen: ' + Object.keys(CONDS).length);
console.log('  Nachtraege zu vorhandenen: ' + Object.keys(ERG).filter((k) => Object.keys(ERG[k]).length).length);
console.log('  Rettungswege: ' + Object.keys(RESC).length);
console.log('  Dateigroesse: ' + Math.round(fs.statSync(OUT).size / 1024) + ' KB');
