# Exoten-Notfalldosen — PROVISORISCH, zur tierärztlichen Freigabe

Ermittelt per quellenbelegtem, **adversarial 2-fach verifiziertem** Recherche-Workflow (Carpenter Exotic Animal Formulary 5th ed., BSAVA Exotic, Plumb's, CliniPharm); füllt die bisher **fehlenden** Notfall-Artdosen. In der App als **provisorisch** markiert (Quelle + Konfidenz + Warnung), additiv über `ui/shared/anaes-exotic-doses.js` — **geprüfte Bestandsdosen werden nie überschrieben**.

> ⚠️ **Vor klinischem Einsatz gegenprüfen.** Konfidenz: **high** = direkt belegt · **medium** = Formulary-Konsens/nahe Art · **low** = Extrapolation von verwandten Arten (konservativ, nach Wirkung titrieren).

| Wirkstoff | Tierart | Dosis | Konz. | Konfidenz | Quelle |
|---|---|---|---|---|---|
| Adrenalin | chinchilla | 0.01–0.1 mg/kg | 1 mg/mL (1:1000) | medium | Carpenter Exotic Animal Formulary 5th ed. (Emergency/CPR-Dosen Kleinsaeuger) + RECOVER-Konsens; keine chinchil |
| Adrenalin | degu | 0.01–0.1 mg/kg | 1 mg/mL (1:1000) | low | Extrapolation (kein Degu-Datensatz); abgeleitet von Chinchilla/Meerschwein/Ratte + RECOVER-Konsens |
| Atipamezol | chinchilla | 0.1–1 mg/kg | 5 mg/mL | medium | Carpenter Exotic Animal Formulary 5th ed. (2018) / Formulary-Konsens (Rodentia) |
| Atipamezol | degu | 0.5–1 mg/kg | 5 mg/mL | low | Extrapolation von Meerschwein/Chinchilla (Carpenter Exotic Animal Formulary 5th ed.); keine art-spezifische Pu |
| Atipamezol | frettchen | 0.5–1 mg/kg | 5 mg/mL | high | Carpenter Exotic Animal Formulary 5th ed. (2018) / BSAVA Manual of Ferrets |
| Atipamezol | meerschwein | 0.1–1 mg/kg | 5 mg/mL | high | Carpenter Exotic Animal Formulary 5th ed. (2018); Antisedan/Rodent-Formulary-Konsens |
| Atipamezol | reptil | 0.25–0.5 mg/kg | 5 mg/mL | low | Carpenter Exotic Animal Formulary 5th ed. (2018), Reptilien-Abschnitt (Regel: 4-5x Medetomidin-Dosis) |
| Atropin | chinchilla | 0.05–0.2 mg/kg | 0.5 mg/mL | high | Morrisey & Carpenter, Exotic Animal Formulary (Morrisey 2004; Fehr 2005); Schweigart 1995 – zusammengefasst in |
| Atropin | degu | 0.05–0.1 mg/kg | 0.5 mg/mL | low | Keine Degu-spezifische Quelle vorhanden; Extrapolation von nahverwandten Hystricomorpha (Chinchilla/Meerschwei |
| Atropin | frettchen | 0.04–0.05 mg/kg | 0.5 mg/mL | high | Morrisey & Carpenter, Exotic Animal Formulary (Morrisey 2004: 0,04 mg/kg; Morrisey 1996: 0,05 mg/kg); vetpharm |
| Ephedrin | chinchilla | 0.05–0.2 mg/kg | 50 mg/mL | low | Keine artspezifische Quelle; kein Ephedrin-Eintrag in Carpenter/BSAVA fuer Chinchilla. Extrapolation der Hund/ |
| Ephedrin | degu | 0.05–0.2 mg/kg | 50 mg/mL | low | Keine belastbare artspezifische Quelle; Degu in keinem Formulary mit Ephedrin gelistet. Extrapolation der Hund |
| Ephedrin | frettchen | 0.05–0.2 mg/kg | 50 mg/mL | low | Keine ferret-spezifische Ephedrin-Vasopressor-Dosis publiziert; Frettchen-Anaesthesie extrapoliert ueblicherwe |
| Ephedrin | kaninchen | 0.05–0.2 mg/kg | 50 mg/mL | low | Keine im Formulary verankerte Ephedrin-Dosis; Extrapolation Hund/Katze (0,05-0,2 mg/kg IV). Kaninchen-Anaesthe |
| Ephedrin | meerschwein | 0.05–0.2 mg/kg | 50 mg/mL | low | Keine artspezifische Quelle; Carpenter's Exotic Animal Formulary (5th/6th ed.) fuehrt kein Ephedrin fuer Nager |
| Ephedrin | reptil | — | 50 mg/mL | none | keine belastbare Dosis → Hund-Referenz bleibt |
| Flumazenil | chinchilla | 0.05–0.1 mg/kg | 0.1 mg/mL | medium | Carpenter Exotic Animal Formulary 5th ed. (Kleinsaeuger-Konsens); Extrapolation, keine chinchilla-spezifische  |
| Flumazenil | degu | 0.05–0.1 mg/kg | 0.1 mg/mL | low | Extrapolation vom Meerschwein/Kleinsaeuger-Konsens (Carpenter Exotic Animal Formulary 5th ed.); keine degu-spe |
| Flumazenil | frettchen | 0.05 mg/kg | 0.1 mg/mL | high | BSAVA Manual/Formulary of Exotic Pets (Part B, Exotic Pets); Carpenter Exotic Animal Formulary 5th ed. |
| Flumazenil | kaninchen | 0.05–0.1 mg/kg | 0.1 mg/mL | high | PK/PD-Studie IV Midazolam+Flumazenil beim Kaninchen, Comp Med (PMC8145127, 2021); Carpenter Exotic Animal Form |
| Flumazenil | meerschwein | 0.05–0.1 mg/kg | 0.1 mg/mL | medium | Carpenter Exotic Animal Formulary 5th ed. (Kleinsaeuger-/Nager-Konsens); keine meerschwein-spezifische PK-Stud |
| Flumazenil | reptil | 0.05 mg/kg | 0.1 mg/mL | medium | Carpenter Exotic Animal Formulary 5th ed.; ARAV Reptile Sedation/Anesthesia Proceedings 2015; Midazolam/Flumaz |
| Glycopyrrolat | chinchilla | 0.01–0.02 mg/kg | 0.2 mg/mL | medium | Carpenter Exotic Animal Formulary 5th ed. (Rodents/Chinchilla-Konsens) / BSAVA Manual of Rodents & Ferrets |
| Glycopyrrolat | degu | 0.01–0.02 mg/kg | 0.2 mg/mL | low | Extrapolation von Hystricomorpha (Chinchilla/Meerschwein), Carpenter Exotic Animal Formulary 5th ed. Rodent-Ko |
| Glycopyrrolat | frettchen | 0.01–0.02 mg/kg | 0.2 mg/mL | high | Carpenter Exotic Animal Formulary 5th ed. (Ferret section) / Vetlexicon Exotis Ferrets (Glycopyrrolate) |
| Lidocain i.v. | chinchilla | — | 20 mg/mL (2%) | none | keine belastbare Dosis → Hund-Referenz bleibt |
| Lidocain i.v. | degu | — | 20 mg/mL (2%) | none | keine belastbare Dosis → Hund-Referenz bleibt |
| Lidocain i.v. | frettchen | 0.25–1 mg/kg | 20 mg/mL (2%) | low | Ferret Cardiology, Vet Clin North Am Exot Anim Pract 2022; Carpenter Exotic Animal Formulary 5th ed. |
| Lidocain i.v. | kaninchen | 1–2 mg/kg | 20 mg/mL (2%) | low | Carpenter Exotic Animal Formulary 5th ed.; rabbit lidocaine literature (Bolus 1-2 mg/kg + CRI ~50 ug/kg/min) |
| Lidocain i.v. | meerschwein | — | 20 mg/mL (2%) | none | keine belastbare Dosis → Hund-Referenz bleibt |
| Lidocain i.v. | reptil | — | 20 mg/mL (2%) | none | keine belastbare Dosis → Hund-Referenz bleibt |
| Naloxon | chinchilla | 0.01–0.04 mg/kg | 0.4 mg/mL | low | Carpenter Exotic Animal Formulary (5th ed., 2018) / Plumb's — Kleinsaeuger-Konsens |
| Naloxon | degu | 0.01–0.04 mg/kg | 0.4 mg/mL | low | Extrapolation vom Meerschwein/Nager-Konsens (Carpenter Exotic Animal Formulary 5th ed.); keine degu-spezifisch |
| Naloxon | frettchen | 0.01–0.04 mg/kg | 0.4 mg/mL | medium | Carpenter Exotic Animal Formulary (5th ed., 2018) / Plumb's Veterinary Drug Handbook |
| Naloxon | meerschwein | 0.01–0.04 mg/kg | 0.4 mg/mL | low | Carpenter Exotic Animal Formulary (5th ed., 2018) / Plumb's Veterinary Drug Handbook — Kleinsaeuger-Konsens |
| Naloxon | reptil | 0.04–0.2 mg/kg | 0.4 mg/mL | low | ARAV / ExoticsCon Reptile Sedation, Anesthesia & Analgesia Proceedings (Sladky/Mans); reptile-spezifische Reve |

**„keine belastbare Dosis"** (Konfidenz none): hier bleibt bewusst die gekennzeichnete Hund-Referenz-Warnung — KEINE erfundene Dosis (u.a. Ephedrin Reptil; Lidocain i.v. bei Meerschwein/Chinchilla/Degu/Reptil, bei diesen Arten ohnehin nicht empfohlen).
