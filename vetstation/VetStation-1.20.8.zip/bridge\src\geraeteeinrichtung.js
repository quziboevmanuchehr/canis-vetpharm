'use strict';
/*
 * geraeteeinrichtung.js — ein Modell aus dem Katalog in Betrieb nehmen, mit EINEM Klick.
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 01.08.2026):
 * Der Anwender soll sein Geraet in den Einstellungen AUSWAEHLEN koennen. Danach muss die Station
 * alles Weitere selbst tun — sonst hat man die Frage nur verschoben: von "welche IP trage ich ein"
 * zu "welchen JSON-Block trage ich ein".
 *
 * WAS SIE TUT:
 *   1. Den passenden Eintrag in bridge/config/devices.json schreiben (aus katalog.weg.vorlage).
 *   2. Den Port, ueber den dieses Geraet spricht, in die Lauschliste des Verbindungs-Assistenten
 *      aufnehmen — UND ZWAR SOFORT, ohne Neustart (probe.ergaenzePort).
 *   3. Den Adapter sofort starten (derselbe Rueckruf, den die automatische Erstsuche benutzt).
 *   4. Ehrlich melden, was danach noch fehlt (Firewall-Freigabe, Einstellung am Geraet).
 *
 * DIE WICHTIGSTE ZUSAGE — BESTEHENDES BLEIBT UNANGETASTET (ausdrueckliche Auflage des Nutzers:
 * "Du musst die Infrastruktur und Verbindungen von bisherigen eingestellten und verbundenen
 * Geraeten nicht schaedigen"). Deshalb gilt hier ausnahmslos:
 *   - Es wird NIE ein vorhandener Adapter geloescht oder umgeschrieben. Nur angefuegt.
 *   - Die Portliste des Assistenten wird NUR ERWEITERT, nie gekuerzt oder umsortiert.
 *   - Wird ein Modell zweimal eingerichtet, entsteht kein zweiter Eintrag (die Adapterkennung
 *     leitet sich aus Modell und Weg ab) — sonst erschiene dasselbe Geraet doppelt in der
 *     Patientenliste, der Fehler von 22.07.2026 an Port 8830.
 *   - Geschrieben wird ueber eine Nebendatei mit anschliessendem Umbenennen. Ein abgebrochener
 *     Schreibvorgang darf keine halbe devices.json hinterlassen — die Station startet danach im
 *     Simulator-Rueckfall, und im OP faellt das erst auf, wenn keine Werte kommen.
 *
 * STRIKT READ-ONLY gegenueber allen Geraeten: hier wird ausschliesslich die eigene Konfiguration
 * geschrieben. An kein Geraet geht ein Byte.
 */
const fs = require('fs');
const path = require('path');

const katalog = require('./geraetekatalog');

/* Die Adapterkennung wird ABGELEITET, nicht gewuerfelt. Nur so ist zweimaliges Einrichten
 * folgenlos statt doppelt. */
function adapterId(geraetId, wegId) { return 'katalog-' + geraetId + '-' + wegId; }

/*
 * WELCHE FELDER DIE OBERFLAECHE UEBERHAUPT SETZEN DARF.
 *
 * Ohne diese Liste koennte ein Aufrufer jedes Feld des Adaptereintrags ueberschreiben — auch
 * `type` (welcher Adapter laeuft) oder `codes` (welcher Datencode als welcher Vitalwert gilt).
 * Gerade `codes` ist sicherheitsrelevant: eine ueber die Oberflaeche gesetzte Zuordnung waere
 * genau die geratene Abbildung, die medibus.js ausdruecklich verweigert. Die Liste enthaelt
 * deshalb NUR das, was beschreibt, WO das Geraet haengt und WIE die Leitung eingestellt ist.
 */
const ERLAUBTE_FELDER = {
  art: (v) => (v === 'com' || v === 'tcp') ? v : null,
  host: (v) => /^[0-9a-zA-Z.\-]{0,64}$/.test(String(v)) ? String(v) : null,
  tcpPort: (v) => { const n = Number(v); return (Number.isInteger(n) && n > 0 && n < 65536) ? n : null; },
  port: (v) => /^(COM\d+|\d{1,5})$/i.test(String(v)) ? (/^COM/i.test(String(v)) ? String(v).toUpperCase() : Number(v)) : null,
  baud: (v) => { const n = Number(v); return [1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200].indexOf(n) >= 0 ? n : null; },
  paritaet: (v) => (['n', 'e', 'o'].indexOf(String(v).toLowerCase()) >= 0) ? String(v).toLowerCase() : null,
  stopbits: (v) => (Number(v) === 1 || Number(v) === 2) ? Number(v) : null,
  profil: (v) => (v === 'klassisch' || v === 'x') ? v : null,
  role: (v) => (['monitor', 'anesthesia', 'capno', 'combo', 'kombi'].indexOf(String(v)) >= 0) ? String(v) : null,
};

/*
 * felderPruefen(roh) -> { werte, abgelehnt[] }
 * Pure Funktion. Ein abgelehntes Feld wird GEMELDET, nicht stillschweigend verschluckt — sonst
 * traegt jemand eine Baudrate ein, sie wird verworfen, und er sucht den Fehler am Kabel.
 */
function felderPruefen(roh) {
  const werte = {}; const abgelehnt = [];
  Object.keys(roh || {}).forEach((k) => {
    const pruef = ERLAUBTE_FELDER[k];
    if (!pruef) { abgelehnt.push(k + ': dieses Feld darf hier nicht gesetzt werden'); return; }
    if (roh[k] === '' || roh[k] == null) return;             // leer = Vorgabe behalten
    const w = pruef(roh[k]);
    if (w === null) { abgelehnt.push(k + ' = "' + roh[k] + '" ist kein gueltiger Wert'); return; }
    werte[k] = w;
  });
  return { werte: werte, abgelehnt: abgelehnt };
}

class Geraeteeinrichtung {
  constructor(opts) {
    const o = opts || {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    this.registry = o.registry || null;
    this.adapterStarten = o.adapterStarten || null;
    this.konfigPfad = o.konfigPfad || path.join(__dirname, '..', 'config', 'devices.json');
    this.beispielPfad = o.beispielPfad || path.join(__dirname, '..', 'config', 'devices.example.json');
  }

  /* ---------------- Konfiguration ---------------- */

  _lesen() {
    for (const p of [this.konfigPfad, this.beispielPfad]) {
      try {
        const j = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (j && typeof j === 'object') { j.adapters = j.adapters || []; return j; }
      } catch (_) {}
    }
    return { port: 8770, host: '127.0.0.1', adapters: [] };
  }

  _schreiben(cfg) {
    try {
      fs.mkdirSync(path.dirname(this.konfigPfad), { recursive: true });
      const tmp = this.konfigPfad + '.neu';
      fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2), 'utf8');
      fs.renameSync(tmp, this.konfigPfad);
      return true;
    } catch (e) {
      this.log.warn('geraete', 'bridge/config/devices.json nicht schreibbar: ' + (e && e.message));
      return false;
    }
  }

  /* ---------------- Der laufende Verbindungs-Assistent ---------------- */

  _probe() {
    return ((this.registry && this.registry.adapters) || []).filter((a) => a && typeof a.ergaenzePort === 'function')[0] || null;
  }

  /* Auf welchen Ports hoert die Station GERADE? Nicht "welche stehen in der Datei" — was zaehlt,
   * ist der laufende Zustand. */
  lauschPorts() {
    const p = this._probe();
    if (p && p.ports) return p.ports.slice();
    const cfg = this._lesen();
    const eintrag = (cfg.adapters || []).filter((a) => a && a.type === 'probe')[0];
    return (eintrag && eintrag.ports) ? eintrag.ports.slice() : katalog.datenPorts();
  }

  /*
   * _portSichern(port) — der Port MUSS in der Lauschliste stehen, sonst sendet das Geraet und
   * niemand hoert zu. Das ist der Fehler, der am 31.07.2026 nicht einmal eine Logzeile erzeugt hat.
   * Rueckgabe: 'schon-da' | 'ergaenzt' | 'ergaenzt-neustart' | 'fehlgeschlagen'
   */
  _portSichern(port) {
    const p = Number(port);
    if (!Number.isFinite(p) || p <= 0) return 'schon-da';

    // 1) In die Datei, damit es den naechsten Start ueberlebt. Nur ANFUEGEN.
    const cfg = this._lesen();
    let eintrag = (cfg.adapters || []).filter((a) => a && a.type === 'probe')[0];
    if (!eintrag) {
      eintrag = { type: 'probe', id: 'assistent', enabled: true, ports: katalog.datenPorts().slice(), arpScan: true, species: null };
      cfg.adapters = cfg.adapters || [];
      cfg.adapters.unshift(eintrag);
    }
    eintrag.ports = eintrag.ports && eintrag.ports.length ? eintrag.ports : katalog.datenPorts().slice();
    const warSchonInDatei = eintrag.ports.indexOf(p) >= 0;
    if (!warSchonInDatei) eintrag.ports.push(p);
    const geschrieben = warSchonInDatei ? true : this._schreiben(cfg);

    // 2) In den LAUFENDEN Assistenten, damit es sofort wirkt.
    const probe = this._probe();
    if (!probe) return warSchonInDatei ? 'schon-da' : (geschrieben ? 'ergaenzt-neustart' : 'fehlgeschlagen');
    if ((probe.ports || []).indexOf(p) >= 0) return warSchonInDatei ? 'schon-da' : 'ergaenzt';
    const ok = probe.ergaenzePort(p);
    if (!ok) return 'ergaenzt-neustart';
    return 'ergaenzt';
  }

  /* ---------------- Einrichten ---------------- */

  /*
   * einrichten({ geraetId, wegId, host }) -> Bericht
   *
   * `host` ist optional und ueberschreibt die Adresse aus der Vorlage — dafuer gibt es genau einen
   * Grund: ein Geraet, dessen Adresse der Anwender am Geraet abgelesen hat. Ohne Angabe bleibt es
   * bei "auto", und die Station folgt dem Geraet selbst (geraetefund.js).
   */
  einrichten(wunsch) {
    const w = wunsch || {};
    const g = katalog.nachId(w.geraetId);
    if (!g) return { ok: false, fehler: 'Dieses Modell steht nicht im Katalog.' };
    const weg = (g.wege || []).filter((x) => x.id === w.wegId)[0] || (g.wege || [])[0];
    if (!weg) return { ok: false, fehler: 'Fuer dieses Modell ist kein Anbindungsweg hinterlegt.' };

    /*
     * KEIN AUSGANG HEISST: HIER GIBT ES NICHTS EINZURICHTEN (02.08.2026, Befund Schwere 4).
     *
     * Das Feld weg.keinAusgang kam in dieser Datei ueberhaupt nicht vor. Fuer jeden Weg ohne
     * Vorlage lief der else-Zweig ganz unten und meldete: "Fuer diesen Weg ist kein eigener
     * Eintrag noetig — der Verbindungs-Assistent nimmt das Geraet entgegen, sobald es sendet."
     * Nachgestellt: einrichten({geraetId:'tafonius'}) lieferte {ok:true, ...} — ebenso fuer die
     * rein mechanischen Narkosegeraete und den Veta 3. Also gruenes Licht fuer Geraete, die
     * nachweislich nie ein Byte schicken, weil sie ueberhaupt keine Buchse haben. Der Anwender
     * wartet danach auf einen Datenstrom, den es physisch nicht gibt.
     *
     * Diese Pruefung ist zugleich die Rueckfallsicherung, wenn die Sperre in der Oberflaeche
     * ausfaellt oder der Aufruf direkt ueber POST /api/geraete/einrichten kommt. Sie liest
     * dieselbe Quelle wie der Verbindungsberater — den Katalog.
     */
    if (weg.keinAusgang === true) {
      return {
        ok: false,
        fehler: g.hersteller + ' ' + g.modell + ': dieser Weg gibt keine lesbaren Daten heraus. '
          + 'Es gibt hier nichts einzurichten — an diesem Geraet liegt es weder am Netz noch an '
          + 'der Station.',
        geraet: g.hersteller + ' ' + g.modell,
        weg: weg.name,
        naechsteSchritte: (weg.schritte || []).slice(),
      };
    }

    const bericht = {
      ok: true,
      geraet: g.hersteller + ' ' + g.modell,
      weg: weg.name,
      adapterId: null,
      portZustand: null,
      port: weg.port || null,
      neustartNoetig: false,
      naechsteSchritte: [],
      meldung: '',
    };

    /* 1) Der Port. Immer zuerst — ein Adapter ohne offenen Weg ist wertlos. */
    if (weg.port && (weg.richtung === 'geraet_sendet' || weg.richtung === 'beides')) {
      bericht.portZustand = this._portSichern(weg.port);
      if (bericht.portZustand === 'ergaenzt-neustart') bericht.neustartNoetig = true;
      if (bericht.portZustand === 'fehlgeschlagen') {
        bericht.naechsteSchritte.push('Port ' + weg.port + ' konnte nicht dauerhaft gespeichert werden ' +
          '(Schreibrecht auf bridge/config/devices.json?). Bis zum naechsten Start wird trotzdem gelauscht.');
      }
    }

    /* 2) Der Adapter — nur, wenn dieser Weg ueberhaupt einen braucht. Ein Geraet, das VON SICH AUS
     *    sendet, wird vom Verbindungs-Assistenten entgegengenommen; ein zusaetzlicher Adapter waere
     *    hier schaedlich (dasselbe Geraet erschiene zweimal). */
    if (weg.vorlage) {
      const id = adapterId(g.id, weg.id);
      bericht.adapterId = id;
      const cfg = this._lesen();
      cfg.adapters = cfg.adapters || [];
      const vorhanden = cfg.adapters.filter((a) => a && a.id === id)[0];
      /* Die vom Menschen eingetragenen Felder kommen NACH der Vorlage und werden vorher geprueft.
       * Was nicht durchkommt, steht im Bericht — verschluckt wird nichts. */
      const gep = felderPruefen(Object.assign({}, w.felder || {}, w.host ? { host: w.host } : {}));
      gep.abgelehnt.forEach((t) => bericht.naechsteSchritte.push('Nicht uebernommen: ' + t));

      const eintrag = Object.assign({ id: id, enabled: true }, weg.vorlage, gep.werte, {
        model: g.hersteller + ' ' + g.modell,
        _katalog: g.id + '/' + weg.id,
        _hinweis: 'Von der Station eingetragen (Reiter „Geräte“, ' + new Date().toISOString().slice(0, 10) + '). ' +
          'Weg: ' + weg.name + '. Liefert: ' + weg.liefert,
      });

      if (vorhanden) {
        /* Schon da. NICHT ueberschreiben: vielleicht hat jemand die Adresse von Hand angepasst,
         * und ein Klick auf "Einrichten" darf diese Handarbeit nicht wegwerfen. Nur wieder
         * einschalten, falls jemand ihn abgeschaltet hatte. */
        if (vorhanden.enabled === false) { vorhanden.enabled = true; this._schreiben(cfg); }
        bericht.meldung = 'Dieses Modell war bereits eingerichtet (' + id + ').';
      } else {
        cfg.adapters.push(eintrag);
        if (!this._schreiben(cfg)) {
          bericht.naechsteSchritte.push('Der Eintrag konnte nicht gespeichert werden — er laeuft bis zum naechsten Start trotzdem.');
        }
        if (this.adapterStarten) {
          try {
            const gestartet = this.adapterStarten(eintrag);
            if (gestartet === false) { bericht.neustartNoetig = true; }
          } catch (e) {
            bericht.neustartNoetig = true;
            this.log.warn('geraete', 'Adapter ' + id + ' liess sich nicht sofort starten: ' + (e && e.message));
          }
        } else {
          bericht.neustartNoetig = true;
        }
        bericht.meldung = 'Eingerichtet: ' + bericht.geraet + ' ueber „' + weg.name + '“.';
      }
    } else {
      bericht.meldung = 'Fuer diesen Weg ist kein eigener Eintrag noetig — der Verbindungs-Assistent ' +
        'nimmt das Geraet entgegen, sobald es sendet.';
    }

    /* 3) Was der Mensch jetzt noch tun muss. Ehrlich und vollstaendig. */
    if (weg.port) {
      bericht.naechsteSchritte.push('Einmalig: FIREWALL-FREIGEBEN.bat doppelklicken, damit Windows Port ' +
        weg.port + ' nicht lautlos verwirft.');
    }
    (weg.schritte || []).forEach((s) => bericht.naechsteSchritte.push(s));
    if (bericht.neustartNoetig) {
      bericht.naechsteSchritte.push('Danach NEUSTART.bat doppelklicken — dieser Teil wird erst mit dem naechsten Start wirksam.');
    }

    this.log.info('geraete', bericht.meldung + (bericht.port ? ' Port ' + bericht.port + ': ' + bericht.portZustand + '.' : ''));
    return bericht;
  }

  /*
   * entfernen(id) — einen selbst eingerichteten Eintrag wieder abschalten.
   * ABSCHALTEN, nicht loeschen: eine von Hand angepasste Adresse soll nicht verloren gehen, und
   * ein versehentlicher Klick soll umkehrbar sein. Ports bleiben in der Lauschliste — sie kosten
   * nichts und ihr Entfernen koennte ein ANDERES Geraet stillegen.
   */
  entfernen(id) {
    const cfg = this._lesen();
    const a = (cfg.adapters || []).filter((x) => x && x.id === id)[0];
    if (!a) return { ok: false, fehler: 'Diesen Eintrag gibt es nicht.' };
    if (String(id).indexOf('katalog-') !== 0) {
      return { ok: false, fehler: 'Nur selbst eingerichtete Geraete koennen hier abgeschaltet werden. ' +
        'Alles Uebrige wurde von Hand oder bei der Installation eingetragen und bleibt unangetastet.' };
    }
    a.enabled = false;
    this._schreiben(cfg);
    ((this.registry && this.registry.adapters) || []).forEach((x) => {
      if (x && x.id === id && typeof x.dispose === 'function') { try { x.dispose(); } catch (_) {} }
    });
    this.log.info('geraete', 'Geraeteeintrag ' + id + ' abgeschaltet (nicht geloescht).');
    return { ok: true, meldung: 'Abgeschaltet. Der Eintrag bleibt in devices.json stehen und kann jederzeit wieder eingeschaltet werden.' };
  }

  /*
   * liste() — was ist eingerichtet, und liefert es etwas?
   * Fuehrt die Konfiguration mit dem LAUFENDEN Zustand zusammen. Ein Eintrag, der in der Datei
   * steht, aber nicht laeuft, ist die Sorte stiller Zustand, die dieses Programm nicht haben will.
   */
  liste() {
    const cfg = this._lesen();
    const devs = (this.registry ? this.registry.getDevices() : []) || [];
    return (cfg.adapters || []).filter((a) => a && a.type !== 'simulator').map((a) => {
      const lauft = ((this.registry && this.registry.adapters) || []).some((x) => x && x.id === a.id && x.connected);
      const dev = devs.filter((d) => d.deviceId === a.id || String(d.deviceId || '').indexOf(a.id) === 0)[0] || null;
      const kat = a._katalog ? String(a._katalog).split('/') : null;
      return {
        id: a.id,
        type: a.type,
        model: a.model || null,
        enabled: a.enabled !== false,
        host: a.host || null,
        port: a.port || a.listenPort || null,
        laeuft: lauft,
        ausKatalog: kat ? { geraetId: kat[0], wegId: kat[1] } : null,
        status: dev ? dev.status : null,
        letzteDatenVorMs: dev && dev.lastTs ? (Date.now() - dev.lastTs) : null,
      };
    });
  }
}

module.exports = { Geraeteeinrichtung, adapterId, felderPruefen, ERLAUBTE_FELDER };
