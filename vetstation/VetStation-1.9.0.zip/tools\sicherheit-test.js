'use strict';
/*
 * sicherheit-test.js — die Riegel, die eine fremde Webseite aussperren.
 *
 * WOHER DIE PRUEFPUNKTE STAMMEN (Sicherheitspruefung 08.08.2026):
 * Die Station laeuft auf einem Praxis-PC, im selben Browser wie alles andere, was dort
 * jemand oeffnet. Daraus folgt das Angriffsbild, um das es hier geht: NICHT ein Fremder aus
 * dem Internet, sondern eine beliebige Webseite, die im Browser des Praxis-PCs offen ist.
 * Sie kann Anfragen an 127.0.0.1 stellen. Gefunden und behoben wurden vier Wege:
 *
 *   1. WEBSOCKET /ws ohne Herkunftspruefung. Der Handschlag pruefte nur Pfad und Key und
 *      antwortete auch fremder Herkunft mit "101 Switching Protocols". WebSockets
 *      unterliegen NICHT der Same-Origin-Regel - die fremde Seite konnte also nicht nur
 *      senden, sondern auch MITLESEN. Ueber diesen Weg laufen Schreibbefehle
 *      (Narkoseprotokoll, Gewicht, Tierart).
 *   2. PATIENTENDATEN mit "Access-Control-Allow-Origin: *". /api/state gibt die
 *      vollstaendige Geraeteakte heraus (Besitzer, Arzt, Bett, Alter, Rasse, Telefon).
 *      Mit dieser Kopfzeile darf jede fremde Seite die Antwort LESEN.
 *   3. /api/update/apply per GET. Ein <img src="http://127.0.0.1:8770/api/update/apply">
 *      genuegte, um ein Update anzustossen - ohne CORS-Vorabfrage.
 *   4. EMPFANGSPUFFER ohne Deckel (Verbindungs-Assistent und WebSocket-Zerleger). Wer
 *      "MSH|" sendet und dann ohne Pause weiterschreibt, treibt die Station in den
 *      Speicherueberlauf - waehrend einer Narkose.
 *
 * Der WebSocket-Riegel wird FUNKTIONAL geprueft (echter Handschlag gegen einen echten
 * Server), die uebrigen am Quelltext. Ein Kommentar ist keine Schranke - genau das war
 * bei Punkt 2 und 3 der Fehler: die Absicht stand da, der Code nicht.
 *
 * Start: node tools/sicherheit-test.js
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const net = require('net');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const lies = (rel) => fs.readFileSync(path.join(ROOT, rel), 'utf8');
/* Quellpruefungen lesen KEINE Kommentare - sonst prueft man die Begruendung statt den Code. */
const ohneKommentar = (s) => s.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/^\s*\/\/.*$/gm, ' ');

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  ✓ ' + was); }
  else { fehler.push(was + (zusatz ? '  -> ' + zusatz : '')); console.log('  ✗ ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}
function block(t) { console.log('\n--- ' + t + ' ---'); }

console.log('\nVetStation - Riegel gegen eine fremde Webseite im Browser des Praxis-PCs\n');

/* ================================================================================
 * 1. WEBSOCKET — FUNKTIONAL: echter Handschlag gegen einen echten Server
 * ============================================================================== */
function handschlag(port, kopfzeilen) {
  return new Promise((resolve) => {
    const s = net.connect(port, '127.0.0.1', () => {
      const key = crypto.randomBytes(16).toString('base64');
      s.write('GET /ws HTTP/1.1\r\nHost: 127.0.0.1:' + port + '\r\n' +
        'Upgrade: websocket\r\nConnection: Upgrade\r\n' +
        'Sec-WebSocket-Key: ' + key + '\r\nSec-WebSocket-Version: 13\r\n' +
        kopfzeilen + '\r\n');
    });
    let antwort = '';
    const fertig = (w) => { try { s.destroy(); } catch (_) {} resolve(w); };
    s.on('data', (c) => { antwort += c.toString('latin1'); if (antwort.indexOf('\r\n\r\n') >= 0) fertig(antwort.split('\r\n')[0]); });
    s.on('close', () => fertig(antwort ? antwort.split('\r\n')[0] : '(geschlossen ohne Antwort)'));
    s.on('error', () => fertig('(Fehler)'));
    setTimeout(() => fertig('(Zeitueberschreitung)'), 3000);
  });
}

(async function () {
  block('1. WebSocket-Handschlag');
  let srv = null;
  try {
    const { createWsServer } = require('../bridge/src/wsserver.js');
    srv = http.createServer((q, r) => { r.writeHead(200); r.end('ok'); });
    await new Promise((res) => srv.listen(0, '127.0.0.1', res));
    const port = srv.address().port;
    createWsServer(srv, { path: '/ws' });

    const eigen = await handschlag(port, 'Origin: http://127.0.0.1:' + port + '\r\n');
    pruef('eigene Herkunft wird angenommen', /101/.test(eigen), eigen);

    const fremd = await handschlag(port, 'Origin: https://boese.example\r\n');
    pruef('FREMDE Herkunft wird abgewiesen (kein 101)', !/101/.test(fremd), fremd);

    const ohne = await handschlag(port, '');
    pruef('ohne Origin-Kopf weiter moeglich (eigene Werkzeuge)', /101/.test(ohne), ohne);

    const localhost = await handschlag(port, 'Origin: http://localhost:' + port + '\r\n');
    pruef('localhost gilt als dieselbe Herkunft wie 127.0.0.1', /101/.test(localhost), localhost);
  } catch (e) {
    pruef('WebSocket-Server laesst sich pruefen', false, e.message);
  } finally {
    if (srv) try { srv.close(); } catch (_) {}
  }

  /* ================================================================================
   * 2. PATIENTENDATEN NUR LOKAL UND OHNE CORS-FREIGABE
   * ============================================================================== */
  block('2. Patientendaten (Quelltext)');
  const server = ohneKommentar(lies('bridge/src/server.js'));
  [
    ['/api/state', 'Geraete und Patienten samt Akte'],
    ['/api/kurven', 'Abtastwerte eines Patienten'],
    ['/api/geraet', 'Rohwerte eines Geraets'],
    ['/api/rohnachrichten', 'unveraenderte HL7-Nachrichten'],
    ['/api/diag', 'Diagnoseprotokoll'],
    ['/api/protokoll', 'Narkoseprotokoll'],
  ].forEach(([route, was]) => {
    /* Der Abschnitt einer Route: vom Routennamen bis zur naechsten Route. */
    const i = server.indexOf("'" + route + "'");
    const rest = i >= 0 ? server.slice(i, i + 700) : '';
    pruef(route + ' verlangt istLokal (' + was + ')', /istLokal\(req\)/.test(rest),
      i < 0 ? 'Route nicht gefunden' : 'kein istLokal im Abschnitt');
    pruef(route + ' antwortet ueber jsonPrivat (ohne CORS-Freigabe)',
      /jsonPrivat\(/.test(rest), 'benutzt noch json()');
  });
  /* json() mit ACAO:* darf es weiter geben - aber nur fuer Dinge ohne Patientenbezug. */
  pruef('json() setzt weiterhin die CORS-Kopfzeile (fuer /api/version, /healthz)',
    /function json\(res, obj\)[\s\S]{0,220}Access-Control-Allow-Origin/.test(server));
  pruef('jsonPrivat() setzt sie NICHT',
    !/function jsonPrivat\(res, obj\)[\s\S]{0,220}Access-Control-Allow-Origin/.test(server));

  /* ================================================================================
   * 3. UPDATE-ROUTEN
   * ============================================================================== */
  block('3. In-App-Update');
  const upd = server.slice(server.indexOf("'/api/update/check'"), server.indexOf("'/api/version'"));
  pruef('/api/update/check verlangt istLokal', /check[\s\S]{0,200}istLokal\(req\)/.test(upd) || /istLokal\(req\)/.test(upd));
  pruef('/api/update/apply verlangt POST', /req\.method !== 'POST'/.test(upd),
    'ein GET waere per <img src> ausloesbar');
  pruef('/api/update/apply prueft fremde Browserherkunft', /fremderBrowserzugriff\(req\)/.test(upd));
  const admin = ohneKommentar(lies('ui/views/admin.js'));
  pruef('die Oberflaeche ruft apply auch wirklich per POST',
    /update\/apply'[^)]*method:\s*'POST'/.test(admin),
    'sonst haette der Riegel die Update-Funktion abgeschaltet');

  /* ================================================================================
   * 3b. WEITERE HANDLUNGEN, DIE KEIN GET SEIN DUERFEN
   * ============================================================================== */
  block('3b. Handlungen statt Abrufe');
  {
    const i = server.indexOf("'/api/netscan/start'");
    const rest = i >= 0 ? server.slice(i, i + 500) : '';
    pruef('/api/netscan/start verlangt istLokal', /istLokal\(req\)/.test(rest));
    pruef('/api/netscan/start verlangt POST', /req\.method !== 'POST'/.test(rest),
      'ein Netzsuchlauf ist eine Handlung, kein Abruf');
    pruef('die Oberflaeche startet den Suchlauf per POST',
      !/fetch\('\/api\/netscan\/start'\)/.test(admin));
  }

  /* Genaue Route vor Praefix-Route - sonst ist die genaue unerreichbar. */
  block('3c. Reihenfolge der Routen');
  {
    const genau = server.indexOf("pathname === '/api/nachbarn/schluessel/bestaetigen'");
    const praefix = server.indexOf("pathname.indexOf('/api/nachbarn/') === 0");
    pruef('beide Routen existieren', genau > 0 && praefix > 0);
    pruef('die GENAUE Route steht vor der Praefix-Route', genau > 0 && praefix > 0 && genau < praefix,
      'sonst verschattet der Praefix den einzigen Schreibweg des Verbunds');
    pruef('die Praefix-Route schliesst den Schluesselpfad zusaetzlich aus',
      /indexOf\('\/api\/nachbarn\/schluessel\/'\) !== 0/.test(server));
    pruef('die Route kommt nur EINMAL vor',
      (server.match(/pathname === '\/api\/nachbarn\/schluessel\/bestaetigen'/g) || []).length === 1);
  }

  /* Pfadsperre der statischen Auslieferung. */
  block('3d. statische Auslieferung');
  pruef('der Pfadvergleich schliesst das Trennzeichen ein',
    /startsWith\(UI_DIR \+ path\.sep\)/.test(server),
    'ohne Trennzeichen passt auch ein Geschwisterordner mit gleichem Namensanfang');
  pruef('ein blosses startsWith(UI_DIR) steht nicht mehr allein da',
    !/if \(!filePath\.startsWith\(UI_DIR\)\)/.test(server));

  /* ================================================================================
   * 4. EMPFANGSPUFFER
   * ============================================================================== */
  block('4. Empfangspuffer haben einen Deckel');
  const probe = ohneKommentar(lies('bridge/src/adapters/probe.js'));
  pruef('probe.js hat eine Hoechstgroesse', /MAX_PROBE_PUFFER/.test(probe));
  {
    /* Der Deckel MUSS vor dem MSH-Zweig stehen - dahinter wird er nie erreicht, weil der
     * Zweig mit return aussteigt. Genau das war der Fehler. */
    const iData = probe.indexOf('buf = Buffer.concat([buf, chunk])');
    const iDeckel = probe.indexOf('MAX_PROBE_PUFFER', iData);
    const iMsh = probe.indexOf("indexOf('MSH|')", iData);
    pruef('der Deckel steht VOR dem MSH-Zweig',
      iDeckel > 0 && iMsh > 0 && iDeckel < iMsh,
      'Deckel bei ' + iDeckel + ', MSH-Zweig bei ' + iMsh);
    pruef('bei Ueberschreitung wird die Verbindung getrennt',
      /MAX_PROBE_PUFFER[\s\S]{0,400}socket\.destroy\(\)/.test(probe));
  }
  const ws = ohneKommentar(lies('bridge/src/wsserver.js'));
  pruef('wsserver.js hat eine Hoechstgroesse', /MAX_PUFFER/.test(ws));
  {
    const iData = ws.indexOf('buffer = Buffer.concat([buffer, chunk])');
    const iDeckel = ws.indexOf('MAX_PUFFER', iData);
    const iParse = ws.indexOf('parseFrames()', iData);
    pruef('der Deckel steht VOR dem Zerlegen',
      iDeckel > 0 && iParse > 0 && iDeckel < iParse,
      'Deckel bei ' + iDeckel + ', parseFrames bei ' + iParse);
  }

  /* ================================================================================
   * 5. NICHTS BETRIEBLICHES AUF DEN USB-STICK
   * ============================================================================== */
  block('5. Auf USB kopieren');
  const usb = lies('installer/auf-usb-kopieren.ps1');
  pruef('bridge\\data ist ausgeschlossen', /bridge\\\\data|bridge\\data/.test(usb),
    'dort liegen protokoll.json und patient-akte.json');
  pruef('devices.json ist ausgeschlossen', /devices\.json/.test(usb),
    'sie traegt Geraeteadressen und den Saalnamen der Praxis');
  pruef('nach dem Kopieren wird gegengeprueft', /ABBRUCH: Betriebs- oder Patientendaten/.test(usb),
    'ein stiller Datenabfluss faellt sonst niemandem auf');
  {
    const b = fs.readFileSync(path.join(ROOT, 'installer/auf-usb-kopieren.ps1'));
    let hoch = 0;
    for (let i = 0; i < b.length; i++) if (b[i] > 127) hoch++;
    pruef('die Datei ist reines ASCII (Projektregel)', hoch === 0, hoch + ' Bytes ueber 127');
  }

  /* ============================================================================== */
  console.log('\n===============================================================');
  if (fehler.length) {
    console.log('  FEHLGESCHLAGEN: ' + fehler.length + ' von ' + (ok + fehler.length));
    fehler.forEach((f) => console.log('   ✗ ' + f));
    console.log('===============================================================\n');
    process.exit(1);
  }
  console.log('  ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
  console.log('===============================================================\n');
})();
