<#
  make-dist.ps1 - Baut auf DIESEM (Entwickler-)PC ein fertiges, kopierbares Paket
  `dist\VetStation\`, das **portables Node** enthaelt, sodass auf dem Ziel-PC NICHTS extra
  installiert werden muss. Das Paket auf USB-Stick/Netz kopieren und dort `Install-VetStation.ps1`
  ausfuehren (oder `START-VetStation.bat` doppelklicken).

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\make-dist.ps1
  Optional: -NodeVersion 20.18.1   -OutDir <pfad>
#>
param(
  [string]$NodeVersion = '20.18.1',
  [string]$OutDir = "$PSScriptRoot\..\dist"
)
$ErrorActionPreference = 'Stop'
$Root  = Split-Path $PSScriptRoot -Parent

# Nur aus dem echten Quellbaum bauen (Befund 19.08.2026).
#
# $Root kommt aus dem ORT dieses Skripts. Es gibt eine zweite Kopie der
# Einrichtungsskripte neben dem Repo; von dort aus zeigt derselbe Ausdruck auf den
# Arbeitsordner statt auf quellcode\. Genau das ist passiert, weil das
# Arbeitsverzeichnis zurueckgesetzt war: 2,9 GB Bauausgabe, darunter eine 644 MB grosse
# VetStation-Setup.zip, gepackt aus dem gesamten Arbeitsordner samt Quellcode.
#
# Der Bau brach danach zwar ab (die Liste nichtInsUpdate fand eine Datei nicht) - aber
# erst NACH dem Packen. Diese Pruefung steht deshalb vor dem ersten Schreibvorgang.
#
# Drei Merkmale zusammen, nicht eines: ein einzelnes koennte zufaellig danebenliegen.
$merkmale = @('ui\app\index.html', 'tools\alle-tests.js', 'bridge\src\server.js')
$fehlend = @($merkmale | Where-Object { -not (Test-Path (Join-Path $Root $_)) })
if ($fehlend.Count -gt 0) {
  Write-Host ''
  Write-Host 'ABBRUCH: hier liegt kein VetStation-Quellbaum.' -ForegroundColor Red
  Write-Host ("  angenommene Wurzel: " + $Root)
  Write-Host ("  es fehlen:          " + ($fehlend -join ', '))
  Write-Host ''
  Write-Host 'Dieses Skript nimmt den Ordner UEBER sich als Quellbaum. Wird die Kopie'
  Write-Host 'neben dem Repo gestartet, ist das der falsche Ordner - und gepackt wuerde'
  Write-Host 'der gesamte Arbeitsordner. Richtig ist:'
  Write-Host '    quellcode\installer\make-dist.ps1'
  Write-Host ''
  throw 'Bau abgebrochen: falscher Quellbaum.'
}

$Stage = Join-Path $OutDir 'VetStation'

Write-Host "== VetStation-Paket bauen =="

# Bereits heruntergeladenes portables Node retten, BEVOR der Stage-Ordner geloescht wird.
# Sonst steht das Paket ohne node.exe da, wenn der Download spaeter fehlschlaegt (offline).
$savedNode = $null
$oldNode = Join-Path $Stage 'node\node.exe'
if (Test-Path $oldNode) {
  $savedNode = Join-Path $env:TEMP 'vetstation-node-cache.exe'
  Copy-Item $oldNode $savedNode -Force
  Write-Host "Vorhandenes node.exe zwischengespeichert (Fallback bei Offline-Build)."
}

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Stage | Out-Null

# 1) App-Dateien kopieren (ohne .git, node_modules, data, dist)
Write-Host "Kopiere App-Dateien ..."
# bridge\data MUSS ausgeschlossen bleiben (Befund 27.07.2026): dort liegen patient-akte.json und
# protokoll.json, also PATIENTENDATEN. Bis hierher wurden sie mitkopiert und landeten damit im
# Update-Paket, das auf einer oeffentlichen Webseite veroeffentlicht wird. Aufgefallen ist es nur,
# weil die Paketpruefung erweitert wurde; im Ernstfall waeren es echte Patientenakten gewesen.
# Ausserdem wuerde ein Update sonst die Betriebsdaten des Kunden ueberschreiben.
# /XF '.git' zusaetzlich zu /XD (Befund 27.07.2026): /XD schliesst nur ORDNER aus. In einem
# Git-Arbeitsbaum ist ".git" aber eine DATEI mit einem Zeiger. Genau so eine Datei landete auf der
# Praxis-Station, und der Updater hielt die Installation daraufhin fuer ein Git-Checkout und rief
# "git pull" auf -> "fatal: not a git repository: (NULL)". Das Update war damit unmoeglich.
# devices.json (NICHT die .example): NEU AUSGESCHLOSSEN am 31.07.2026, und zwar vorsorglich.
# Bisher entstand diese Datei nur, wenn ein Mensch sie anlegte, auf einem Entwicklerrechner also
# praktisch nie. Seit 1.1.0 schreibt die Station sie SELBST (bridge/src/erstsuche.js traegt
# gefundene Geraete ein). Damit kann sie ab jetzt in JEDEM Arbeitsbaum auftauchen, in dem die
# Bridge einmal gelaufen ist, und sie enthaelt die Geraeteadressen und den Saalnamen einer
# konkreten Praxis. Beides gehoert nicht in ein Paket, das oeffentlich auf GitHub Pages liegt,
# und ein Update wuerde damit ausserdem die Konfiguration des Kunden ueberschreiben.
# Dieselbe Sorte Fehler wie bridge/data (siehe oben); diesmal vor dem Ernstfall geschlossen.
# docs\rassen-quellen: die Rechercheauszuege, aus denen ui\shared\breed-katalog.js erzeugt wird
# (1,2 MB JSON). Sie gehoeren ins Git-Repo, damit der Katalog reproduzierbar bleibt - aber nicht
# in das Paket, das ueber die Praxisleitung geht: die Station liest nur die fertige Katalogdatei.
# docs\ekg-quellen: dasselbe fuer ui\shared\ekg-literatur.js (820 KB Rohdaten aus der
# Buchauswertung vom 10.08.2026). Gemessen: mit ihnen lag das Update-Paket bei 4348 KB und
# damit ueber der Grenze in tools\paket-test.js; ohne sie darunter.
# docs\kardio-quellen: dasselbe fuer ui\shared\kardio-regeln.js (1265 KB, Auswertung des
# sechsten Werks am 14.08.2026). ZWEI Gruende, nicht nur die Paketgroesse: die Rohdaten
# enthalten zu jeder Regel den vollstaendigen Quellenabgleich, und die Vorlage ist
# ausdruecklich nur fuer den persoenlichen Gebrauch lizenziert. Die Station liest die
# fertige Regeldatei, nicht die Rohdaten.
# CLAUDE.md: NEU AUSGESCHLOSSEN am 27.08.2026. Die Datei enthaelt die Arbeitsregeln fuer die
# Entwicklung - Testwege, Freigabekette, Verzeichnis der Notizen. Auf einem Praxis-PC hat sie
# nichts zu suchen und wurde dort auch nie gelesen; sie lag nur mit, weil robocopy alles nimmt.
# Sie ist ausserdem der deutlichste Hinweis darauf, womit entwickelt wurde - und das gehoert
# nicht auf die Rechner der Kundschaft. Dieselbe Trennung wie bei docs\rassen-quellen: gehoert
# ins Repo, nicht ins Paket. Der Verweis darauf ist am selben Tag aus allen zwoelf Kommentaren
# verschwunden; tools\keine-regeldatei-test.js haelt beides fest.
robocopy $Root $Stage /E /XD (Join-Path $Root '.git') (Join-Path $Root 'node_modules') (Join-Path $Root 'data') (Join-Path $Root 'bridge\data') (Join-Path $Root 'dist') (Join-Path $Root 'docs\rassen-quellen') (Join-Path $Root 'docs\ekg-quellen') (Join-Path $Root 'docs\kardio-quellen') /XF '*.log' '.git' 'devices.json' 'CLAUDE.md' /NFL /NDL /NJH /NJS /NP | Out-Null
# DIE GERAETEFIRMWARE DES EKG 2000 KOMMT HIER MIT - UND FAELLT ERST BEIM UPDATE-PAKET RAUS.
#
# WARUM DIESE UNTERSCHEIDUNG (16.08.2026, praezisiert auf Wunsch des Nutzers):
# Es sind ZWEI verschiedene Wege mit zwei verschiedenen Empfaengern.
#   dist\VetStation und die daraus gebaute Setup.exe gehen auf die Praxis-PCs DES LIZENZ-
#     INHABERS. Er hat die Firmware rechtmaessig erworben; sie auf seine eigenen Rechner zu
#     bringen, ist genau der Zweck. Ohne sie ist das Geraet beim Anstecken stumm, und das
#     Versprechen "anstecken genuegt" waere gebrochen.
#   Das Update-Zip liegt OEFFENTLICH auf GitHub Pages. Dorthin darf sie nicht - das waere
#     Verbreitung fremder Software an beliebige Dritte.
# Der Ausschluss steht deshalb weiter unten bei $nichtInsUpdate, nicht hier. Wer ihn hierher
# zurueckverlegt, nimmt dem Setup die Firmware wieder weg, ohne dass ein Test rot wird -
# deshalb steht die Begruendung an beiden Stellen.

# 2) Portables Node holen und als node\node.exe ablegen
$nodeDir = Join-Path $Stage 'node'
New-Item -ItemType Directory -Force -Path $nodeDir | Out-Null
$zipName = "node-v$NodeVersion-win-x64"
$zipUrl  = "https://nodejs.org/dist/v$NodeVersion/$zipName.zip"
$zipPath = Join-Path $env:TEMP "$zipName.zip"
Write-Host "Lade portables Node $NodeVersion ..."
try {
  Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing
  $tmp = Join-Path $env:TEMP "vetstation-node"
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive -Path $zipPath -DestinationPath $tmp -Force
  Copy-Item (Join-Path $tmp "$zipName\node.exe") (Join-Path $nodeDir 'node.exe') -Force
  Write-Host "node.exe eingebettet."
} catch {
  Write-Warning "Node-Download fehlgeschlagen ($($_.Exception.Message))."
  if ($savedNode -and (Test-Path $savedNode)) {
    Copy-Item $savedNode (Join-Path $nodeDir 'node.exe') -Force
    Write-Host "Zwischengespeichertes node.exe wiederhergestellt - Paket bleibt lauffaehig."
  } else {
    Write-Warning "Kein Fallback vorhanden. Bitte node.exe manuell nach $nodeDir kopieren."
  }
}
if (-not (Test-Path (Join-Path $nodeDir 'node.exe'))) {
  throw "ABBRUCH: node\node.exe fehlt im Paket - der Ziel-PC koennte VetStation nicht starten."
}

# 3) Doppelklick-Starter + Installer-Starter ins Paket
@"
@echo off
title VetStation
REM VetStation starten (ECHTE Geraete). Fuer Dauerbetrieb: Install-VetStation.ps1 ausfuehren.
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
REM Nur im FEHLERFALL anhalten. Sonst schliesst sich das Fenster in derselben Sekunde und der
REM Tierarzt sieht Meldungen wie "Node.js nicht gefunden" oder "Bridge nicht erreichbar" nie.
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo     Netzwerk/Geraete pruefen: GERAETE-PRUEFEN.bat doppelklicken.
  echo.
  pause
)
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-VetStation.bat')

@"
@echo off
REM DEMO/TEST OHNE Geraete: schaltet den Simulator zu (zwei Demo-Patienten Hund+Katze).
set VETSTATION_SIM=1
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-TESTMODUS.bat')

@"
@echo off
title VetStation - installieren / aktualisieren
REM EIN Doppelklick fuer BEIDES: Neuinstallation UND Update eines vorhandenen PCs.
REM Der Installer holt sich die Adminrechte selbst (UAC-Abfrage bestaetigen).
REM
REM Er beendet zuerst die laufende Station (sonst bliebe nach dem Update der ALTE Code im
REM Speicher - genau das ist am 21.07.2026 passiert), kopiert, startet neu und PRUEFT NACH,
REM ob wirklich der neue Stand laeuft. Die Konfiguration bridge\config\devices.json bleibt erhalten.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\Install-VetStation.ps1"
if errorlevel 1 (
  echo.
  echo *** Die Installation ist nicht sauber durchgelaufen - Meldung oben lesen. ***
  echo.
)
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'INSTALLIEREN.bat')

# NEUSTART: es gab bisher KEINEN vorgesehenen Weg, die Station neu zu starten. Weil der Prozess
# erhoeht laeuft, liess er sich nicht einmal im Task-Manager beenden (Befund 2.9).
@"
@echo off
title VetStation - neu starten
REM Beendet die laufende Station (auch wenn sie mit erhoehten Rechten laeuft) und startet sie neu.
REM Noetig nach einem Update, nach Aenderungen an bridge\config\devices.json und wenn ein
REM Datenport von einer zweiten Instanz belegt ist.
echo Beende VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\stop-kiosk.ps1"
REM ZWEITE SICHERUNG (02.08.2026): erst weiter, wenn Port 8770 wirklich frei ist.
REM stop-kiosk.ps1 wartet seit 1.2.4 selbst auf seinen erhoehten Lauf (-Wait). Diese Zeile ist
REM der Guertel zum Hosentraeger: solange die alte Bridge noch horcht, wuerde das Update ueber
REM laufende Dateien geschrieben, und der neue Start saehe die alte Station und taete nichts.
REM Hoechstens 15 Sekunden - danach laeuft es trotzdem weiter und meldet sich unten.
powershell -NoProfile -ExecutionPolicy Bypass -Command "for(`$i=0; `$i -lt 30; `$i++){ `$b=@(Get-NetTCPConnection -LocalPort 8770 -State Listen -ErrorAction SilentlyContinue); if(-not `$b){ break }; Start-Sleep -Milliseconds 500 }"
echo Starte VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo.
  pause
)
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'NEUSTART.bat')

# BEFUND EXPORTIEREN: schreibt EINE Textdatei mit allem, was zur Ferndiagnose noetig ist.
# Ohne sie muss man den Zustand eines fremden PCs muehsam zusammenfragen.
@"
@echo off
title VetStation - Befund exportieren
REM Schreibt eine Textdatei mit Version, IP, Firewall, Geraetesuche, Empfang und Urteil.
REM Diese Datei kann man weitergeben - oder am anderen PC von Claude einlesen lassen.
REM Patienten-Kennungen werden dabei unkenntlich gemacht, Vitalwerte sind NICHT enthalten.
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\befund-export.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\befund-export.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'BEFUND-EXPORTIEREN.bat')

# AUF USB KOPIEREN: ganzes Projekt (Setup + Quellcode + Git) auf einen anderen Datentraeger.
@"
@echo off
title VetStation - auf externe Platte / USB kopieren
REM Legt Setup, Update-Paket UND den vollstaendigen Quellcode inkl. Git-Historie auf einen
REM anderen Datentraeger, damit an einem ANDEREN PC weitergearbeitet werden kann.
REM Ziel aendern:  AUF-USB-KOPIEREN.bat E:\VetStation
cd /d "%~dp0"
set ZIEL=%~1
if "%ZIEL%"=="" set ZIEL=G:\Manu\VetStation
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\auf-usb-kopieren.ps1" -Ziel "%ZIEL%"
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'AUF-USB-KOPIEREN.bat')

# FIREWALL: fehlt eine Freigabe, verwirft Windows die Vitaldaten LAUTLOS (Befund 2.6).
@"
@echo off
title VetStation - Firewall freigeben
REM Gibt die Geraete-Datenports frei und raeumt doppelte Altregeln frueherer Installationen auf.
REM Mehrfaches Ausfuehren schadet nicht - das Ergebnis ist immer genau eine Regel je Port.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-firewall.ps1"
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'FIREWALL-FREIGEBEN.bat')

# 3b) Netzwerk + Geraetepruefung als DOPPELKLICK-Dateien.
#     Grund: In PowerShell startet der Nutzer in C:\Windows\System32 - ein RELATIVER Pfad
#     ("-File installer\set-static-ip.ps1") schlaegt dort fehl. Diese .bat benutzen IMMER
#     ihren eigenen Ordner (%~dp0) und sind damit vom Startverzeichnis unabhaengig.
@"
@echo off
title VetStation - Netzwerk einrichten
REM Setzt die feste IP 192.168.0.99 fuer das isolierte Geraete-Netz (Ziel im Monitor).
REM Einfach DOPPELKLICKEN. Adminrechte holt sich das Skript selbst (UAC bestaetigen).
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-static-ip.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'NETZWERK-EINRICHTEN.bat')

# INTERNET EINRICHTEN: Gegenstueck zu NETZWERK-EINRICHTEN.bat. Die feste IP wird bewusst OHNE
# Gateway gesetzt (isoliertes Geraetenetz). Haengt der PC aber ueber einen Verstaerker am
# Praxis-/Hausnetz, sind damit Update, Fern-Live und die klinischen Daten still tot, waehrend die
# Geraetedaten voellig normal laufen (Befund 22.07.2026). Diese Datei traegt Gateway + DNS nach,
# ohne die IP anzufassen.
@"
@echo off
title VetStation - Internet einrichten (Update + Fern-Live)
REM Traegt Standardgateway und DNS nach, OHNE die feste Geraete-IP zu aendern.
REM Noetig, wenn der PC ueber einen Verstaerker/Switch am Praxis- oder Hausnetz haengt:
REM dann laufen die Geraetedaten zwar, aber Update, Fern-Live und die klinischen Daten
REM kommen nicht ins Internet - ohne dass irgendwo ein Fehler erscheint.
REM Im ISOLIERTEN Geraetenetz (eigener Switch, kein Router) wird diese Datei NICHT gebraucht.
REM Einfach DOPPELKLICKEN. Adminrechte holt sich das Skript selbst (UAC bestaetigen).
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-internet.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'INTERNET-EINRICHTEN.bat')

@"
@echo off
title VetStation - Geraete pruefen
REM Prueft, ob Monitor/Kapnograf Daten senden. Benutzt das mitgelieferte portable Node -
REM auf dem Praxis-PC gibt es KEIN npm, deshalb NICHT "npm run check" verwenden.
REM Optional laesst sich eine Geraete-IP mitgeben:  GERAETE-PRUEFEN.bat 192.168.0.50
REM Ohne Parameter sucht das Programm die Geraete selbst (MAC-Suche + Lauschphase).
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\geraete-check.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\geraete-check.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'GERAETE-PRUEFEN.bat')

# EKG 2000 am USB - EIGENE Startdatei, nicht in GERAETE-PRUEFEN.bat mit hinein.
# Grund: GERAETE-PRUEFEN.bat sucht Geraete im NETZ (MAC-Suche, Lauschports). Das EKG haengt
# am USB und hat weder IP noch MAC. Beides in eine Datei zu legen hiesse, dem Anwender bei
# jedem Suchlauf die jeweils andere Haelfte als Fehlermeldung vorzusetzen.
@"
@echo off
title VetStation - EKG 2000 pruefen
REM Fragt das angesteckte EKG 2000 (PC-EKG) nach seinem Datenformat.
REM Es wird NUR mitgelesen - an das Geraet geht nichts.
REM Das Geraet muss angesteckt sein; Elektroden angeschlossen zu haben hilft.
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\ekg2000-mitschnitt.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\ekg2000-mitschnitt.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'EKG-PRUEFEN.bat')

# Geschwindigkeit der Fern-Uebertragung messen (beantwortet "kommt das wirklich schnell an?").
@"
@echo off
title VetStation - Geschwindigkeit der Fern-Uebertragung messen
REM Misst, wie lange ein Wertepaket vom Praxis-PC bis zur Cloud-Datenbank braucht.
REM Die zweite Haelfte der Strecke (Datenbank -> Zuhause) steht in der Web-App unter
REM "Fern-Live" -> "Verbindung & Geschwindigkeit".
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\fern-messen.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\fern-messen.js" %*
:ende
echo.
pause
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'GESCHWINDIGKEIT-MESSEN.bat')

# 4) Volles Paket zippen (Ordner-Kopie fuer USB-Stick / Netzlaufwerk)
$zipOut = Join-Path $OutDir 'VetStation-Setup.zip'
if (Test-Path $zipOut) { Remove-Item $zipOut -Force }
Compress-Archive -Path $Stage -DestinationPath $zipOut

# 4b) UPDATE-PAKET fuer den In-App-Updater (Admin -> Aktualisieren).
#     WARUM HIER UND NICHT VON HAND: dieser Schritt war bisher ein reiner Handgriff und wurde
#     deshalb bei 0.6.0 prompt vergessen - es gab eine neue Setup.exe, aber kein Update-Paket,
#     mit dem eine bereits laufende Station haette nachziehen koennen.
#     node\ und data\ MUESSEN draussen bleiben: mit node\ waeren es 27 MB statt gut 0,7 MB,
#     und data\ enthaelt die Betriebsdaten des Kunden.
#
#     NICHT INS OEFFENTLICHE UPDATE-PAKET (15.08.2026, Entscheidung des Nutzers).
#
#     Das Update-Paket wird ueber canis-vetpharm ausgeliefert, und dieses Repo ist OEFFENTLICH
#     (per GitHub-API geprueft: visibility=public). Die Setup.exe dagegen geht per USB an die
#     Praxis. Was hier ausgeschlossen wird, fehlt also NUR im oeffentlichen Weg - ueber die
#     Setup.exe bekommt die Station es weiterhin vollstaendig.
#
#     GEFAHRLOS, WEIL DER UPDATER NICHTS LOESCHT: kiosk\launch-kiosk.ps1 spielt mit
#     "robocopy $src $Root /E" ein - ohne /MIR und ohne /PURGE. Eine Datei, die im Paket fehlt,
#     bleibt auf der Station unangetastet. Nachgesehen, nicht angenommen.
#
#     ekg-literatur.js KAM AM 15.08.2026 DAZU (Entscheidung des Nutzers, 1.18.1).
#
#     Bis dahin stand hier die Gegenbegruendung: die Datei liege ohnehin schon in den
#     veroeffentlichten Paketen 1.12.0 bis 1.18.0 (nachgezaehlt: sieben Stueck, je 516 KB),
#     ein Ausschluss schuetze also nichts mehr. Das bleibt richtig fuer das Vergangene und
#     falsch fuer das Kuenftige - jedes weitere Paket haette die Auszuege erneut ins offene
#     Netz gelegt. Was schon draussen ist, ist eine getrennte Frage (siehe Freigabenotiz).
#
#     DER HAKEN, DER DABEI FAST UEBERSEHEN WURDE: der Updater loescht nichts, also behaelt eine
#     laufende Station ihre ALTE ekg-literatur.js - und die kennt die Einheitenwarnung zur
#     tausendfach zu hohen Dauertropfdosis nicht (gemessen: 1.12.0-1.17.0 tragen null
#     Warnungen, erst 1.18.0 zwei). Der Ausschluss allein haette eine Sicherheitswarnung
#     stillschweigend zurueckgenommen. Deshalb liegen die Warnungen seit 1.18.1 in einer
#     eigenen, ueberall ausgelieferten Datei: ui\shared\dosis-warnungen.js (4 KB, kein
#     Buchwissen). Sie ordnet sich ueber werk|seite|zahlen zu und wirkt damit auch auf einer
#     alten Datendatei - nachgemessen an allen sechs ausgelieferten Fassungen.
$nichtInsUpdate = @(
  'ui\shared\kardio-regeln.js',   # 1113 KB Auswertung eines lizenzierten Fachbuchs, nie veroeffentlicht
  'ui\shared\ekg-literatur.js',   # 516 KB Auszuege aus fuenf Fachbuechern; Warnungen daraus siehe oben
  # Die vier Netzskripte beschreiben die Netztopologie DIESER Praxis (fester PC 192.168.0.5,
  # Gateway .1, Geraetesuche auf .242 in drei Subnetzen). Alles RFC1918 und damit nicht aus dem
  # Internet erreichbar - aber es gehoert niemandem sonst und nuetzt auch niemandem sonst: eine
  # fremde Praxis hat andere Adressen. Das Update-Paket wird ueber das OEFFENTLICHE Repo
  # canis-vetpharm ausgeliefert; ueber die Setup-Datei erreichen die Skripte den Praxis-PC
  # weiterhin. Dieselbe Trennung wie bei den beiden Buchdateien darueber. (19.08.2026)
  'installer\monitor-netzsuche.ps1',
  'installer\monitor-andere-netze.ps1',
  'installer\netz-reparieren.ps1',
  'installer\netzsuche-scan.js',
  # 160 KB QUELLE DER FERN-ANSICHT - eine BAUvorlage, die die Station nie liest (21.08.2026).
  #
  # Sie kam am 21.08.2026 dazu, als das Fern-Modul endlich eine Quelle im Repo bekam (vorher
  # reichte tools\web-app-bauen.js es aus seinem eigenen Bauergebnis weiter, es war also die
  # einzige Datei des Projekts ohne Quelle). Gebraucht wird sie ausschliesslich hier beim Bauen
  # der oeffentlichen Web-App - auf dem Praxis-PC laeuft sie nie, wird von nichts geladen und
  # von keinem Test gelesen.
  #
  # Sie hat das Paket von 4508 auf 4668 KB getrieben und damit die Grenze in tools\paket-test.js
  # gerissen. Der Kommentar dort sagt, was dann zu tun ist: "eine gerissene Groessengrenze ist
  # zuerst eine Frage nach dem INHALT, nicht nach der Zahl." Das ist hier woertlich der Fall -
  # 160 KB Bauvorlage ueber die Praxisleitung zu schicken, damit sie dort ungenutzt liegt, waere
  # die bequeme Antwort gewesen. Ueber die Setup.exe kommt sie weiterhin mit.
  'tools\web-fern-modul.html'
)
$ver = (Get-Content (Join-Path $Root 'package.json') -Raw | ConvertFrom-Json).version
$updZip = Join-Path $OutDir ("VetStation-$ver.zip")
if (Test-Path $updZip) { Remove-Item $updZip -Force }
$updStage = Join-Path $OutDir '_updatebau'
if (Test-Path $updStage) { Remove-Item $updStage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $updStage | Out-Null
#     DERSELBE FILTER WIE BISHER, nur in ein Zwischenverzeichnis statt direkt ins Zip.
#     Ein erster Versuch mit "robocopy /XD <vollpfad node> <vollpfad data>" schloss node\ NICHT
#     aus - das Paket wurde 30875 statt 4400 KB. Aufgefallen ist es nur, weil der Selbstschutz
#     ein paar Zeilen weiter unten bei ueber 5 MB warnt. Deshalb hier der Filter, der sich seit
#     0.6.0 bewaehrt hat, statt eines zweiten Ausschlussverfahrens daneben.
Get-ChildItem -LiteralPath $Stage -Force |
  Where-Object { $_.Name -ne 'node' -and $_.Name -ne 'data' } |
  ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $updStage -Recurse -Force }
#     ABBRECHEN STATT WARNEN (15.08.2026). Vorher stand hier nur ein Write-Warning: ein
#     Tippfehler im Pfad haette also eine Zeile unter dreissig erzeugt, der Bau waere
#     weitergelaufen - und die Buchdatei waere im oeffentlichen Paket gelandet. Genau der
#     Fall, gegen den diese Liste ueberhaupt gebaut ist. Eine Absicherung, die den
#     Fehlerfall nur kommentiert, ist keine.
foreach ($rel in $nichtInsUpdate) {
  $weg = Join-Path $updStage $rel
  if (Test-Path $weg) { Remove-Item $weg -Force; Write-Host "  nicht ins Update-Paket: $rel" }
  else { throw "nichtInsUpdate nennt '$rel', aber die Datei liegt nicht unter $updStage. Entweder ist der Pfad falsch geschrieben oder die Liste ist veraltet - beides wuerde die Datei ausliefern. Bau abgebrochen." }
}
#     DIE GERAETEFIRMWARE DES EKG 2000 - hier und NUR hier faellt sie raus.
#     Sie gehoert Grimed. Im Setup (dist\VetStation) bleibt sie: das geht auf die eigenen
#     Rechner des Lizenzinhabers. Das Update-Zip liegt oeffentlich auf GitHub Pages, dort
#     waere sie Verbreitung fremder Software.
#     KEIN throw wie oben bei $nichtInsUpdate: dass gar keine Firmware daliegt, ist ein voellig
#     gueltiger Zustand (ein Entwicklungsrechner ohne EKG hat sie nicht). Gezaehlt und gemeldet
#     wird trotzdem - ein stilles "0 entfernt" waere genau die Zeile, die niemand liest, wenn
#     der Filter eines Tages ins Leere greift.
$fwWeg = Join-Path $updStage 'firmware\ekg2000'
$fwZahl = 0
if (Test-Path $fwWeg) {
  Get-ChildItem -LiteralPath $fwWeg -Filter '*.BIN' -File -ErrorAction SilentlyContinue |
    ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force; $fwZahl++ }
}
Write-Host "  nicht ins Update-Paket: $fwZahl Firmwaredatei(en) des EKG 2000 (bleiben im Setup)"
#     GEGENPROBE STATT VERTRAUEN: nach dem Entfernen wird nachgesehen. Ein Filter, der sich
#     selbst bestaetigt, hat in diesem Projekt schon einmal nichts gefangen.
$rest = @(Get-ChildItem -LiteralPath $updStage -Recurse -File -Filter '*.BIN' -ErrorAction SilentlyContinue)
if ($rest.Count -gt 0) {
  throw ("Im Update-Paket liegen noch " + $rest.Count + " .BIN-Datei(en): " +
         (($rest | ForEach-Object { $_.Name }) -join ', ') + ". Bau abgebrochen.")
}
$inhalt = Get-ChildItem -LiteralPath $updStage -Force
Compress-Archive -Path $inhalt.FullName -DestinationPath $updZip
Remove-Item $updStage -Recurse -Force
$sha = (Get-FileHash -LiteralPath $updZip -Algorithm SHA256).Hash.ToLower()
$updKb = [math]::Round((Get-Item $updZip).Length / 1KB, 0)
if ((Get-Item $updZip).Length -gt 5MB) {
  Write-Warning "Update-Paket ist $updKb KB gross - vermutlich ist node\ mit hineingeraten. Bitte pruefen."
}

# 5) SELBSTSCHUTZ: Beobachtet am 21.07.2026 - nach einem Lauf war die QUELLE
#    installer\make-dist.ps1 verschwunden (die Kopie im Stage blieb intakt, kein
#    Virenscanner-Fund). Ursache noch nicht abschliessend geklaert; da die Datei beim
#    Kopieren nach $Stage noch vorhanden war, laesst sich der Verlust hier sicher heilen.
#    Ohne diesen Block landet die Loeschung beim naechsten `git add -A` unbemerkt im Commit
#    (genau das ist in 0.5.1 passiert).
#
#    STAND DER UNTERSUCHUNG (0.6.0): einzeln nachgestellt wurden robocopy, Compress-Archive und
#    Remove-Item auf einer Kopie - KEINER dieser Schritte loescht die Quelle. Im Paket gibt es
#    auch keine Verknuepfungspunkte (Junctions), denen Remove-Item -Recurse folgen koennte.
#    Der Verlust tritt also nur im Zusammenspiel auf und bleibt vorerst unerklaert.
#    WICHTIG UND BEWUSST SO: wiederhergestellt wird aus $Stage, und dorthin wurde die Datei in
#    GENAU DIESEM Lauf kopiert. Die Heilung kann deshalb nie einen alten Stand zurueckspielen -
#    sie stellt immer exakt den Inhalt wieder her, mit dem der Lauf begonnen hat.
$selbst  = $PSCommandPath
$imStage = Join-Path $Stage 'installer\make-dist.ps1'
if ($selbst -and -not (Test-Path -LiteralPath $selbst) -and (Test-Path -LiteralPath $imStage)) {
  Copy-Item -LiteralPath $imStage -Destination $selbst -Force
  Write-Warning "make-dist.ps1 war nach dem Lauf verschwunden und wurde aus dem Paket wiederhergestellt."
}

Write-Host ""
Write-Host "FERTIG (Version $ver):"
Write-Host "  Ordner:        $Stage"
Write-Host "  Volles Zip:    $zipOut"
Write-Host "  Update-Paket:  $updZip  ($updKb KB)"
Write-Host "  sha256:        $sha"
Write-Host ""
Write-Host "Auf den Ziel-PC kopieren -> INSTALLIEREN.bat (als Admin) oder START-VetStation.bat (Test)."
Write-Host "Fuer den In-App-Update-Kanal: Update-Paket + sha256 im Manifest vetstation-version.json"
Write-Host "veroeffentlichen (siehe README, Abschnitt 'neues Release veroeffentlichen')."
