'use strict';
/*
 * alle-tests.js — faehrt ALLE Selbsttests der Reihe nach und fasst sie zusammen.
 *
 * Warum als eigenes Programm statt einer langen npm-Zeile:
 *   • Auf dem PRAXIS-PC gibt es KEIN npm — nur node\node.exe. `npm test` ist dort nicht
 *     ausfuehrbar, dieses Programm schon:  node\node.exe tools\alle-tests.js
 *   • Mehrere Tests belegen TCP-Ports. Sie muessen NACHEINANDER laufen, sonst behindern sie
 *     sich gegenseitig und melden Fehler, die keine sind.
 *   • Am Ende steht EINE Zeile, die man ohne Suchen lesen kann.
 *
 * Start: node tools/alle-tests.js      (oder npm test)
 */
const path = require('path');
const { spawnSync } = require('child_process');

const TESTS = [
  ['smoke-test.js', 'Grundfunktionen'],
  ['species-test.js', 'Tierarten/Dosen'],
  /* 17.08.2026 aufgenommen. Bewacht drei Luecken, die alle 81 anderen Dateien gruen passierten:
   * keine Einheitenpruefung (mEq wurde als mg gerechnet, Faktor 125), eine dritte Datenkopie,
   * die die Stationsschale wirklich lud, und ein Herzfrequenzband, das nie ankam. */
  ['dosis-einheiten-test.js', 'Dosiseinheiten, Datenkopien, Herzfrequenzband'],
  ['doppelschluessel-test.js', 'doppelte Schluessel (stiller Datenverlust)'],
  ['setup-sauber-test.js', 'kein Setup traegt Betriebsdaten mit sich'],
  /* 27.08.2026 aufgenommen. Die Regeldatei der Entwicklung lag in JEDEM Paket und damit auf
   * jedem Praxis-PC - sie war nie ausgeschlossen worden, weil robocopy den ganzen Baum nimmt.
   * Ihr Name stand ausserdem in zwoelf Kommentaren, vier davon in ui/app/index.html und damit
   * in der oeffentlich ausgelieferten Web-App. Der Waechter prueft beides: den Namen im ganzen
   * Baum, und dass Bau und Paket die Datei wirklich draussen lassen. */
  ['keine-regeldatei-test.js', 'Regeldatei der Entwicklung bleibt im Repo (nicht im Paket, nicht im Netz)'],
  ['antagonisten-test.js', 'Arzneikarte und Antagonisten-Ansicht widerspruchsfrei'],
  ['anmeldung-test.js', 'Anmeldung bringt ihr Modul selbst mit'],
  ['paket-gleich-test.js', 'Paket und Quellstand Datei fuer Datei gleich'],
  ['protokoll-blatt-test.js', 'Narkoseprotokoll: Gewicht, Storno, Mittelwerte'],
  ['rhythmus-vollbild-test.js', 'simulierter Rhythmus geht mit dem Patienten; Vollbild'],
  ['webapp-saele-vollbild-test.js', 'Fern-App: Saalleiste einklappen, Vollbild'],
  ['abmelden-erklaerung-test.js', 'Abmelden entsperrt, Sendetakt 40 ms, Werterklaerungen'],
  ['temperatursonde-test.js', 'abgefallene Temperatursonde wird erkannt'],
  /* 21.08.2026 aufgenommen. Der Medikamenten-Reiter zeigt seither die Mittel der ersten Wahl
   * zum erkannten Problem, mit der Menge fuer das eingetragene Gewicht. Der Test FAEHRT die
   * Auswahl und die vier Arznei-Sperren, statt nach Woertern zu suchen - eine
   * Behandlungsempfehlung darf nicht davon abhaengen, ob in der Datei die richtigen Woerter
   * stehen. Er haelt ausserdem fest, dass in den Rangfolgen KEINE Dosis steht: sonst stuende
   * dieselbe Zahl ein drittes Mal im Baum, und tools/dosis-abgleich.js liest index.html nicht.
   * Gegenprobe von Hand gefahren (eine Dosis in einen erst-Block geschrieben -> rot). */
  ['erstwahl-test.js', 'Erstwahl-Medikamente zum erkannten Problem'],
  /* 21.08.2026 aufgenommen. Es gab im ganzen Baum keine einzige Stelle, die Kontrast rechnet
   * (weder 0.2126 noch "luminan" noch "contrastRatio" kamen vor) — und der HELLMODUS ist die
   * Vorgabe der Anwendung. Beim ersten Lauf: 53 unlesbare Stellen, darunter das Warnfenster,
   * das sich beim Verabreichen aufdraengt (Kontrast 1,21) und die Alarmtexte der Fern-Ansicht
   * (1,37). Der Test bringt seine eigene Gegenprobe mit: 17 Proben mit bekanntem Ergebnis, und
   * er wurde fuenfmal absichtlich zerbrochen, um zu sehen, dass sie das merkt.
   * Er vergleicht ausserdem die BEIDEN glass.css — der Bau kopiert sie nicht, und bis dahin
   * verglich sie nichts. Gegenprobe von Hand gefahren (eine Zeile angehaengt -> rot). */
  ['kontrast-test.js', 'Hellmodus: jede Schrift lesbar, ein Themenblatt'],
  /* 21.08.2026 aufgenommen. Die Kette "am Praxis-PC Protokoll erzeugt -> vollstaendig in der
   * Fern-Ansicht" hat sechs Glieder in vier Dateien, und eines davon ist eine Zeichenkette, die
   * zweimal geschrieben steht (der Browser kann bridge/src/model.js nicht laden). Reisst sie,
   * faellt kein Test um: die Bridge landet im default-Zweig und tut nichts, waehrend der Knopf
   * unveraendert funktionsfaehig aussieht. Der Test faehrt einen echten CloudPublisher. */
  ['protokoll-fern-test.js', 'erzeugtes Protokoll geht vollstaendig fern'],
  /* 19.08.2026 aufgenommen. Anlass: Noradrenalin stand in der Arzneikarte mit einer
   * Obergrenze, die das Vierfache dessen war, was dieselbe Anwendung an 28 anderen Stellen
   * schrieb - gefunden von Hand beim Nachschlagen eines einzelnen Stoffes. Der Waechter
   * macht daraus eine Messung. Gegenprobe von Hand: tools/dosis-abgleich-gegenprobe.js */
  ['dosis-abgleich-test.js', 'keine Arzneikarte laesst mehr zu als die App vertritt'],
  /* 19.08.2026 aufgenommen. Zwei Rettungswege sagten, wieviel Milliliter der VERDUENNTEN
   * Loesung zu geben sind; gemeint war das Volumen der 50-prozentigen Stammloesung. Faktor 4
   * zu wenig, ausgerechnet im Rettungsweg bei Hypoglykaemie. Der Test RECHNET (Volumen x
   * Konzentration gegen die genannte g/kg-Menge) - nach Woertern zu suchen haette nichts
   * gefunden, die Woerter waren alle da. */
  ['glukose-bezug-test.js', 'Volumen einer Prozentloesung: Stamm oder Verduennung'],
  /* 19.08.2026 aufgenommen. Esmolol nannte nur die Einzeldosis 0,05-0,5 mg/kg; vetpharm
   * (selbst gelesen, Fox 1999b) sagt "als Bolus alle 5 Minuten, BIS MAXIMAL 0,5 mg/kg".
   * Wer nachdosiert, ueberschritt eine Grenze, die die Station nicht erwaehnte. */
  ['kumulative-grenze-test.js', 'Summengrenze bei wiederholbaren Boli'],
  /* 20.08.2026 aufgenommen. Der Baum behauptete an zwei Stellen, die QRS-Breitenmessung lese
   * "rund 20 % zu kurz, bei der Katze 43 %". Beide Zahlen stammten aus dem Vergleich mit einem
   * Generator, dessen gezeichnete Breite das Doppelte seiner Vorgabe ist - gemessen wurde der
   * Massstab. Gegen eine eindeutige Referenz ist der Fehler viermal kleiner. Haette jemand die
   * alten Zahlen als Korrekturfaktor angebracht, meldete die Station verbreiterte
   * Kammerkomplexe, wo keine sind. */
  ['qrs-breite-test.js', 'QRS-Breite gegen eine eindeutige Referenz'],
  /* 20.08.2026 aufgenommen. Bewegungsartefakte ergaben 100 von 100 einen Herzbefund, ueberwiegend
   * "ventrikulaere Tachykardie" - bei einer Guete von 71, also weit im Bereich "sauber". Die Guete
   * kann das bauartbedingt nicht sehen: Stoerzacken landen in ihrem eigenen Zaehler, und sie ist
   * ein Median ueber den ganzen Streifen. Jetzt wird fensterweise die Ruhe ZWISCHEN den Zacken
   * gemessen. Nach dem Einbau: Bewegung 10 %, Diathermie 0 %, Grundlinie 0 %. */
  ['artefakt-test.js', 'gestoerte Abschnitte statt erfundener Rhythmusbefunde'],
  ['matching-test.js', 'Geraete->Patient zusammenfuehren'],
  ['priority-test.js', 'Prioritaet/Befunde'],
  ['version-test.js', 'EINE Quelle der Wahrheit fuer die Version'],
  ['netscan-test.js', 'Geraetesuche + Einstufung'],
  ['stationsid-test.js', 'Stationskennung (mehrere OP-Saele)'],
  ['doppelstart-test.js', 'zweiter Start derselben Station'],
  ['watchdog-test.js', 'Selbstheilung bei EINGEFRORENER Station'],
  ['routen-test.js', 'jede Auskunftsroute wirklich aufrufen (Station darf nicht sterben)'],
  ['bremse-test.js', 'Lastbremse: Nachbarsaele haengen nicht an einem Ausrutscher'],
  ['diagnose-test.js', 'Klartext-Diagnose "wo liegt das Problem"'],
  ['geraetefund-test.js', 'Station folgt dem Geraet (statt toter IP)'],
  ['geraetekatalog-test.js', 'Geraetekatalog (Ports, MAC, Menuepfade)'],
  ['geraete-profil-test.js', 'universelles virtuelles Geraet (Kanaele, Kurven, MAC, Fern-Gleichstand)'],
  ['geraeteerkennung-test.js', 'Modellerkennung (schlaegt vor, raet nie)'],
  ['verbindungsberater-test.js', 'Verbindungsberater (Anleitung + Empfehlung)'],
  ['geraeteeinrichtung-test.js', 'Geraet einrichten, ohne Bestehendes zu schaedigen'],
  ['seriell-test.js', 'serieller Weg (RS-232/Geraeteserver, Sendesperre)'],
  ['ekg2000-format-test.js', 'EKG-2000-Format aus dem Bytestrom lesen (und schweigen, wo nichts ist)'],
  ['ekg2000-protokoll-test.js', 'EKG-2000-Anmeldegespraech (19200 8E1, Byte 0x10) - und weiterhin KEINE Messwerte'],
  ['usb-geraete-test.js', 'USB-Diagnostik-EKG erkennen (EKG 2000, kein Fremdwandler)'],
  ['usbwache-test.js', 'angestecktes EKG laeuft von selbst an (und ein Fremdwandler nicht)'],
  ['surgivet-test.js', 'SurgiVet Advisor CSV (25 Spalten, Skalierung gemessen)'],
  ['medibus-test.js', 'Draeger MEDIBUS (Rahmen, Zeitregeln, Sendesperre)'],
  ['erstsuche-test.js', 'findet Geraete + Nachbar-PCs von selbst'],
  ['vollauslesung-test.js', 'Station liest ALLES vom Geraet'],
  ['ekg-analyse-test.js', 'EKG-Analyse (QRS, Rhythmus, ST)'],
  /* Diese beiden fehlten bis 08.08.2026 in der Liste — sie liefen nur, wenn jemand sie von
   * Hand startete. Ein Test, der nicht im Sammellauf steht, bewacht nichts: er faellt beim
   * naechsten Umbau still aus, und niemand merkt es. */
  ['p-welle-test.js', 'P-Welle und PQ-Zeit (findet sie, wo sie ist — und schweigt, wo keine ist)'],
  ['rhythmus-test.js', 'Rhythmusdeutung (Vorhofflimmern, AV-Block II, Sinusarrest, Bigeminus, Salve)'],
  ['virtuelles-geraet-test.js', 'Virtuelles Geraet geeicht (Vorgabe in mV/ms wird wiedergefunden)'],
  ['monitor-geraet-test.js', 'Virtuelles MONITORGERAET im Geraetemenue (EKG/Pleth geeicht, Massstab an der Bahn)'],
  ['ekg-modul-test.js', 'Diagnostik-EKG-Submodul (Messzirkel, Normwerte, Hinweis-Maschine)'],
  ['ekg-skala-test.js', 'beschriftete EKG-Achsen (Schirm und Ausdruck messen dasselbe)'],
  /* 26.08.2026 aufgenommen. Anlass war eine fremde Analyse-Ernte, die auf eine Zeile in
   * model.js zeigte: dort stand fest { einheit: 'uV' }, obwohl die Positivliste zwanzig Zeilen
   * darueber die Einheit seit dem 07.08.2026 mitfuehrt UND ihr Kommentar verspricht, ein Geraet
   * koenne die Annahme "ueberschreiben, statt still falsch gerechnet zu werden". Nachgeprueft:
   * es konnte nicht. hl7.js las die Einheit gar nicht ein, registry.js hatte dieselbe feste
   * Zeile und verlor sie ausserdem in seinem Puffer. Drei tote Glieder in einer Kette, an der
   * der FAKTOR 1000 fuer ST, P und T haengt.
   * Der Test faehrt den echten Parser und die echte Auswertung und weist den Faktor 1000
   * nach — eine Quelltextpruefung allein haette die vierte Falle nicht gesehen: MDC_DIM_
   * MILLI_VOLT enthaelt weder "uv" noch "mv", die Zeichenkette unuebersetzt weiterzureichen
   * haette JEDEN HL7-Monitor auf "unkalibriert" gestellt und die ST-Strecke stillgelegt.
   * Gegenprobe gefahren: alle sechs Zerbrechproben wurden erkannt. */
  ['ekg-einheit-test.js', 'Einheit ueberlebt Geraet -> Puffer -> Auswertung (Faktor 1000)'],
  /* 26.08.2026 aufgenommen. Die Zackensuche war NOCH NIE an echten Tiersignalen gemessen —
   * alle bisherigen Belege sind synthetisch und stammen aus diesem Projekt selbst. Seit heute
   * liegen 17 oeffentliche Hundeaufzeichnungen mit 10.860 menschlich korrigierten R-Zacken
   * daneben (ausserhalb des Repos, also nicht im Update-Paket; fehlen sie, endet der Test mit
   * einem Hinweis statt mit einem Fehler).
   * Die erste Messung ist unbequem und steht deshalb im Kopf der Datei: 11 Aufnahmen 100 %,
   * sechs fallen durch, ueber alles 66,7 %. Der Test AENDERT nichts an der Schwelle — er
   * haelt den Stand fest und macht die Zahl sichtbar. */
  ['qrs-referenz-test.js', 'Zackensuche gegen 10.860 echte, menschlich korrigierte Schlaege'],
  ['mobil-test.js', 'Handyansicht: nichts ragt aus dem Rahmen'],
  /* 26.08.2026 aufgenommen. Anlass aus der Praxis: "beim Runterscrollen rutscht die Leiste
   * runter, manchmal zittert die ganze Web-App". Nachgemessen in echtem Chrome: bei JEDER
   * Radraste stand die Reiterleiste 57 px zu tief, weil data-kopf sofort wirkt und die
   * Haftpunkte erst ein Bild spaeter nachgezogen wurden. Und in der Web-App lag der ganze
   * Kopf samt CPR-Knopf unsichtbar unter der festen Fern-Leiste, weil position:sticky vom
   * FENSTERRAND misst und nicht vom Elternelement.
   * Beides faerbte KEINEN der 101 vorhandenen Tests rot - es gab im ganzen Baum keine Zeile,
   * die den Kopfbereich prueft. Der Waechter bewacht die drei Haftpunkte, das synchrone
   * Nachziehen, die Notuhr, den Groessenwaechter und - die eigentliche Falle - dass
   * Polsterung und Ueberbau im Fern-Modul nicht auseinanderlaufen.
   * Gegenprobe gefahren: alle zwoelf Zerbrechproben wurden erkannt. */
  ['kopfbereich-test.js', 'klebender Kopfbereich: Haftpunkte, Ueberbau, Nachziehen'],
  ['wechsel-test.js', 'P-Welle mitgezaehlt oder echte Bigeminie? (belegter Fehlermodus)'],
  ['hrv-test.js', 'Herzfrequenzvariabilitaet (gemessen, bewusst nicht bewertet)'],
  ['normwerte-test.js', 'Normwerte nach Art, Koerpergroesse und (nur wo belegt) Rasse'],
  ['alter-test.js', 'Alter aus Geburtsdatum oder Schaetzung (Kalenderfallen)'],
  ['rasse-herz-test.js', 'Rasse -> Herz -> was das EKG davon zeigen kann'],
  ['patientenblatt-test.js', 'Patientenblatt: Art, Rasse, Gewicht, Alter (davon haengt alles ab)'],
  ['tier3d-test.js', 'drehbares 3D-Modell: welche Seite ist das? (RA/LA-Verwechslung)'],
  ['herz3d-test.js', 'Herzmodell: Erregung synchron zur Kurve, jeder Befund mit seinem Ort'],
  ['monitor-eingabe-test.js', 'Werteeingabe am Monitor: Ziffernfolge, Zeichenfilter, Kachelbreite, Schirmhoehe'],
  ['archiv-test.js', 'Archiv speichert das SIGNAL, nicht ein Bild'],
  ['sicherheit-test.js', 'Riegel gegen eine fremde Webseite im Browser des Praxis-PCs'],
  /* Prueft das VEROEFFENTLICHTE Manifest gegen die Datei im Kanal. Liegt das Web-Repo nicht
   * daneben (Praxis-PC), sagt es das und endet ohne Fehler. */
  ['manifest-pruefen.js', 'Update-Manifest zeigt auf die richtige Datei'],
  ['hl7-test.js', 'HL7 lesen'],
  /* 17.08.2026 aufgenommen. Diese Datei war die EINZIGE der 81 Testdateien, die nicht im
   * Sammellauf stand — sie lief nur, wenn jemand sie von Hand startete, und bewachte damit
   * nichts. Sie prueft die echte MLLP-Rahmung ueber TCP, also keinen Nebenweg. Sie bindet
   * Port 5099; der gehoert zu keinem Geraeteport der Station (die liegen bei 1550, 2528, 2575,
   * 3502, 4601, 5000, 5510, 8830 und 24105) und kollidiert deshalb auch mit einer laufenden
   * Station nicht. Derselbe Fall wie am 08.08.2026 bei p-welle- und rhythmus-test.js. */
  ['hl7-live-test.js', 'HL7 live ueber echtes TCP (MLLP-Rahmung)'],
  ['temp-co2-test.js', 'Temperatur + CO2 (Kabel angeschlossen)'],
  ['umec12-nibp-test.js', 'uMEC12 Zahlen (HL7 Compatibility Ein)'],
  ['hl7-client-test.js', 'HL7-Client'],
  ['hl7-reconnect-test.js', 'kein Log-Fluten bei abwesendem Geraet'],
  ['probe-test.js', 'Verbindungs-Assistent'],
  ['check-haengt-nicht-test.js', 'Verbindungs-Check haengt nie'],
  ['ui-flacker-test.js', 'Oberflaeche flackert nicht'],
  ['port3502-test.js', 'Gateway-Port 3502'],
  ['vscapture-test.js', 'VSCapture-Fallback'],
  ['drei-geraete-test.js', 'drei Geraete gleichzeitig'],
  ['paket-test.js', 'Bedienbarkeit am Praxis-PC'],
  ['update-signatur-test.js', 'Update-Kanal ist signiert (Ed25519, gefaelschter Kanal wird abgewiesen)'],
  ['update-paket-test.js', 'ausgeliefertes Update-Paket'],
  ['cloud-test.js', 'Fern-Live'],
  ['cloud-integration-test.js', 'Fern-Live Ende zu Ende'],
  ['tafel-test.js', 'Saal-Tafel (Kacheln, Alterung, Modus)'],
  ['tafelabo-test.js', 'Tafel lesen (Nachbarsaele)'],
  ['fremdstore-test.js', 'Nachbarsaele zusammenfuehren (Alter, Quelle)'],
  ['nachbar-test.js', 'Nachbar-Port 8771 (Handschlag, Deckel)'],
  ['nachbarn-test.js', 'Kiosk-Band der Nachbarsaele'],
  ['saalname-test.js', 'Saalname + Stationskennung von Hand'],
  ['regeln-test.js', 'Sicherheitsregeln der Datenbank'],
  ['regeln-vertrag-test.js', 'Regeln gegen ECHTE Daten (Vertrag)'],
  ['firebase-regeln-test.js', 'Firebase-Datenbankregeln (Form + was die Station schreibt)'],
  // Laeuft hier mit der kurzen Vorgabe (8 s), damit die Suite zuegig bleibt; fuer eine
  // aussagekraeftige Messung von Hand mit "--sekunden 30" starten.
  // Schuetzt vor allem die Zusicherung "kein Kurvenstreifen geht doppelt ueber die Leitung".
  ['fern-durchsatz-test.js', 'Fern-Durchsatz (Werte + Kurven)'],
  ['veta5-mirror-test.js', 'Veta 5 Beatmungsmodus/-werte live spiegeln'],
  ['af-quelle-test.js', 'AF-Quelle: Kapnograph vor Monitor'],
  ['drug-context-test.js', 'Medikamenten-bewusste Beatmungsanalyse'],
  ['gaben-protokoll-test.js', 'NUR bestaetigte Gaben ins Protokoll + Rueckweg'],
  /* Lauter ZUSATZfelder: faellt eines weg, sieht nichts anders aus und kein anderer Test wird
   * rot. Gegenprobe von Hand: tools/gaben-herkunft-gegenprobe.js (17 Schaeden, alle erkannt). */
  ['gaben-herkunft-test.js', 'Herkunft der Gabe + Fallkennung + Geraet'],
  /* Rauschmass -> Bridge -> Protokollzeile -> Beleg-Paket. Jede Stufe faellt still aus:
   * fehlt eine, sieht nichts anders aus und kein anderer Test wird rot. */
  ['beleg-kette-test.js', 'Rauschmass, Urteil und Beleg-Paket'],
  /* Der Befundbericht versprach "Kennungen unkenntlich" und hing die Diagnosemeldungen ROH an -
   * mit Aktennummer, Wirkstoff und Dosis. Drei Ausgaenge, alle still. Gegenprobe von Hand:
   * tools/kennung-im-log-gegenprobe.js (8 Rueckfaelle, alle erkannt). */
  ['kennung-im-log-test.js', 'Aktennummer verlaesst den Praxis-PC nicht'],
  ['protokoll-kopf-test.js', 'Spaltenkopf auf JEDER Protokollseite (400 Zeilen gerechnet)'],
  ['rassen-test.js', 'Rassekatalog, Erstwahl-Narkose, Rettungswege'],
  ['webapp-fern-test.js', 'Fern-Ansicht auf mehrere OP-Saele'],
  ['logumbruch-test.js', 'Diagnose-Log laeuft nicht voll'],
  ['dauerwache-test.js', 'Dauerwache: spaeter angestecktes Geraet wird gefunden'],
];

const nurEins = process.argv[2];
const liste = nurEins ? TESTS.filter((t) => t[0].indexOf(nurEins) >= 0) : TESTS;

console.log('\n===============================================================');
console.log('  VetStation - Selbsttests (' + liste.length + ' Dateien)');
console.log('===============================================================\n');

const gut = [], schlecht = [];
for (const [datei, was] of liste) {
  const p = path.join(__dirname, datei);
  process.stdout.write(('  ' + was).padEnd(52, '.') + ' ');
  const r = spawnSync(process.execPath, [p], { encoding: 'utf8' });
  const text = String(r.stdout || '') + String(r.stderr || '');
  if (r.status === 0) {
    const m = text.match(/ALLE (\d+) PRUEFUNGEN BESTANDEN/) || text.match(/(\d+) OK/);
    console.log('OK' + (m ? '  (' + m[1] + ')' : ''));
    gut.push(datei);
  } else {
    console.log('FEHLGESCHLAGEN');
    schlecht.push([datei, text]);
  }
}

if (schlecht.length) {
  console.log('\n---------------------------------------------------------------');
  console.log('  FEHLGESCHLAGEN - Ausgabe im Einzelnen:');
  console.log('---------------------------------------------------------------');
  schlecht.forEach(([datei, text]) => {
    console.log('\n### ' + datei + ' ###');
    // Nur die Fehlerzeilen und das Fazit zeigen - der Rest ist Rauschen.
    const zeilen = text.split('\n').filter((l) => /✗|FEHLGESCHLAGEN|FAIL|Error|Testfehler/.test(l));
    console.log(zeilen.length ? zeilen.join('\n') : text.slice(-1500));
  });
}

console.log('\n===============================================================');
if (schlecht.length) {
  console.log('  ERGEBNIS: ' + schlecht.length + ' von ' + liste.length + ' Testdateien FEHLGESCHLAGEN');
  console.log('  Es sollte KEIN Setup gebaut werden, solange das so ist.');
} else {
  console.log('  ERGEBNIS: alle ' + gut.length + ' Testdateien bestanden.');
}
console.log('===============================================================\n');
process.exit(schlecht.length ? 1 : 0);
