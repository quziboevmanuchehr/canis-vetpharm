'use strict';
/*
 * cloud.js — FERN-LIVE Publisher (Schicht 1/3 -> Internet).
 *
 * Aufgabe: die bereits pro Patient zusammengefuehrten Live-Daten (registry.getPatients())
 * plus die "Brain"-Bewertung (brain.assess -> Prioritaet + Top-Befund) ~1x/Sekunde in ein
 * Cloud-Relay schreiben, damit die oeffentliche Web-App (GitHub Pages,
 * quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie) sie FERN anzeigen kann.
 *
 * Relay = Firebase Realtime Database (Projekt vetpharma-f9d98). Der Praxis-PC schreibt per
 * REST (anonyme Firebase-Anmeldung -> idToken), die Zuschauer LESEN mit dem Zugangscode.
 *
 * STRIKT READ-ONLY gegenueber den Geraeten. NULL npm-Dependencies (nur Node-Bordmittel: https).
 * Datenschutz: es werden ausschliesslich Vitalwerte + Tierart/Gewicht/Befund uebertragen,
 * KEINE Klarnamen/Personendaten. Zugriff nur mit dem unratbaren Code (Teil des Links).
 */
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ---- klinische Engine (fuer die Fern-Prioritaet/Top-Befund je Patient) ----
// UMD-Module laufen auch in Node (siehe ui/engine/*.js). Faellt sauber aus, wenn nicht ladbar.
let brain = null, anaes = null, ANAES = null;
try {
  brain = require('../../ui/engine/brain.js');
  anaes = require('./anaes.js');
  ANAES = anaes.loadAnaes();
} catch (_) { /* Enrichment optional — ohne Engine werden Rohwerte ohne pri/top gesendet */ }

const IDENTITY = 'https://identitytoolkit.googleapis.com/v1/accounts:signUp';
const SECURETOKEN = 'https://securetoken.googleapis.com/v1/token';

function sanitizeKey(s) {
  // RTDB-Schluessel + URL-Parameter: nur unbedenkliche Zeichen zulassen (Rest -> _).
  return String(s == null ? '' : s).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 200) || '_';
}
function nowSec() { return Math.floor(Date.now() / 1000); }

class CloudPublisher {
  /*
   * cfg = {
   *   enabled, provider:'firebase',
   *   apiKey,            // Firebase Web-API-Key (oeffentlich)
   *   dbUrl,             // z.B. https://vetpharma-f9d98-default-rtdb.europe-west1.firebasedatabase.app
   *   code,              // Zugangscode (= Teil des Fern-Links). Unratbar waehlen.
   *   station,           // Anzeigename der Station ("Praxis OP 1")
   *   minIntervalMs,     // Mindestabstand zweier Schreibvorgaenge (Default 1000)
   *   authFile           // Pfad zur persistenten Token-Datei (Default data/cloud-auth.json)
   * }
   */
  constructor(cfg, { log } = {}) {
    this.cfg = cfg || {};
    this.log = log || { info() {}, warn() {}, error() {} };
    this.provider = this.cfg.provider || 'firebase';
    this.identityUrl = this.cfg.identityUrl || IDENTITY;   // fuer Tests ueberschreibbar
    this.tokenUrl = this.cfg.tokenUrl || SECURETOKEN;
    this.code = sanitizeKey(this.cfg.code || 'vetstation');
    this.station = this.cfg.station || 'VetStation';
    // Standard: OHNE Anmeldung schreiben (Regeln sind code-basiert). Nur wenn useAuth:true -> anonyme Firebase-Anmeldung.
    this.useAuth = this.cfg.useAuth === true;
    this.minInterval = Math.max(250, Number(this.cfg.minIntervalMs) || 500);
    this.authFile = this.cfg.authFile || path.join(__dirname, '..', '..', 'data', 'cloud-auth.json');

    this.idToken = null;
    this.refreshToken = null;
    this.localId = null;
    this.tokenExp = 0;          // Unix-Sekunden
    this.lastPublish = 0;       // ms
    this.inFlight = false;
    this.authFailAt = 0;        // Backoff nach Auth-Fehlern
    this.started = false;
    this.lastError = null;
  }

  shareUrl(base) {
    var b = base || 'https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/';
    return b + (b.indexOf('?') >= 0 ? '&' : '?') + 'live=' + encodeURIComponent(this.code);
  }

  start() {
    if (this.started) return;
    if (!this.cfg.enabled) { this.log.info('cloud', 'Fern-Live deaktiviert (cloud.enabled=false).'); return; }
    if (this.provider !== 'firebase') { this.log.warn('cloud', 'Unbekannter Provider "' + this.provider + '" — nur "firebase" unterstuetzt.'); return; }
    if (!this.cfg.apiKey || !this.cfg.dbUrl) {
      this.log.warn('cloud', 'Fern-Live: apiKey/dbUrl fehlen in der Konfiguration (cloud-Block). Uebertragung aus.');
      return;
    }
    this.started = true;
    if (this.useAuth) this._loadAuth();
    this.log.info('cloud', 'Fern-Live AKTIV (' + (this.useAuth ? 'mit Anmeldung' : 'ohne Anmeldung, code-basiert') + ') → ' + this.shareUrl());
    this.log.info('cloud', 'Zuschauer-Zugang (Code): ' + this.code);
  }

  status() {
    return {
      enabled: !!this.cfg.enabled, provider: this.provider, started: this.started,
      code: this.code, station: this.station, url: this.shareUrl(),
      mode: this.useAuth ? 'auth' : 'code',
      authed: this.useAuth ? (!!this.idToken && this.tokenExp > nowSec()) : this.started,
      lastPublish: this.lastPublish, lastError: this.lastError,
    };
  }

  // Wird aus dem Broadcast-Takt der Bridge aufgerufen (registry.getPatients()).
  publish(patients) {
    if (!this.started) return;
    const now = Date.now();
    if (this.inFlight) return;
    if (now - this.lastPublish < this.minInterval) return;
    if (this.authFailAt && now - this.authFailAt < 15000) return; // Backoff
    this.lastPublish = now;
    this.inFlight = true;
    const snapshot = this._buildSnapshot(patients || []);
    const write = this.useAuth
      ? this._ensureAuth().then((tok) => this._put('/live/' + this.code + '.json?auth=' + encodeURIComponent(tok), snapshot))
      : this._put('/live/' + this.code + '.json', snapshot);   // ohne Anmeldung (Regeln code-basiert)
    write
      .then(() => { this.lastError = null; })
      .catch((e) => {
        this.lastError = e && e.message ? e.message : String(e);
        this.log.warn('cloud', 'Fern-Live Schreibfehler: ' + this.lastError);
        if (this.useAuth && /401|403|token|auth|credential/i.test(this.lastError)) { this.idToken = null; this.tokenExp = 0; this.authFailAt = Date.now(); }
      })
      .then(() => { this.inFlight = false; });
  }

  // ---------- Snapshot ----------
  _buildSnapshot(patients) {
    const out = {};
    let count = 0;
    for (const p of patients) {
      const key = sanitizeKey(p.patientKey || ('dev:' + (p.devices && p.devices[0] && p.devices[0].deviceId)));
      const v = p.vitals || {};
      const rec = {
        patientId: p.patientId || null,
        species: p.species || null,
        weightKg: p.weightKg != null ? p.weightKg : null,
        isoPct: p.isoPct != null ? p.isoPct : null,
        ventMode: p.ventMode || null,
        ts: p.ts || Date.now(),
        vitals: {
          hr: nn(v.hr), spo2: nn(v.spo2), etco2: nn(v.etco2), fico2: nn(v.fico2), af: nn(v.af),
          sys: nn(v.sys), dia: nn(v.dia), map: nn(v.map), temp: nn(v.temp), paw: nn(v.paw),
          ekgRhythm: v.ekgRhythm || null, capnoShape: v.capnoShape || null, pleth: v.pleth || null,
        },
        alarms: Array.isArray(p.alarms) ? p.alarms.slice(0, 12) : [],
        devices: (p.devices || []).map((d) => ({ model: d.model || '?', role: d.role || 'monitor', status: d.status || null })),
      };
      const res = this._assess(p);
      if (res) { rec.pri = res.pri; rec.top = res.top; }
      out[key] = rec;
      count++;
    }
    return {
      meta: { code: this.code, station: this.station, v: 1, ts: Date.now(), count: count },
      patients: out,
    };
  }

  // Brain-Bewertung -> kompakte Fern-Zusammenfassung (Prioritaet + Top-Befund).
  _assess(p) {
    if (!brain || !ANAES) return null;
    try {
      const flat = Object.assign({ species: p.species || 'hund', weightKg: p.weightKg || 10, isoPct: p.isoPct }, p.vitals || {});
      const r = brain.assess(ANAES, flat, { iso: p.isoPct });
      const top = r.top ? { sev: r.top.sev || 0, title: r.top.title || '', tag: r.top.tag || '', fix: r.top.fix || '', incident: r.top.incident || null } : null;
      return { pri: Math.round((r.priority || 0) * 10) / 10, top: top };
    } catch (_) { return null; }
  }

  // ---------- Firebase Auth (anonym) ----------
  _loadAuth() {
    try {
      const j = JSON.parse(fs.readFileSync(this.authFile, 'utf8'));
      if (j && j.refreshToken) { this.refreshToken = j.refreshToken; this.localId = j.localId || null; }
    } catch (_) { /* erste Nutzung */ }
  }
  _saveAuth() {
    try {
      fs.mkdirSync(path.dirname(this.authFile), { recursive: true });
      fs.writeFileSync(this.authFile, JSON.stringify({ refreshToken: this.refreshToken, localId: this.localId }), 'utf8');
    } catch (e) { this.log.warn('cloud', 'Token-Datei nicht speicherbar: ' + e.message); }
  }

  async _ensureAuth() {
    if (this.idToken && this.tokenExp > nowSec() + 60) return this.idToken;
    if (this.refreshToken) {
      try { return await this._refresh(); }
      catch (_) { this.refreshToken = null; /* faellt auf Neuanmeldung */ }
    }
    return await this._signUp();
  }

  async _signUp() {
    const url = this.identityUrl + '?key=' + encodeURIComponent(this.cfg.apiKey);
    const res = await this._reqJson('POST', url, JSON.stringify({ returnSecureToken: true }), { 'Content-Type': 'application/json' });
    if (!res.idToken) throw new Error('signUp ohne idToken: ' + JSON.stringify(res).slice(0, 160));
    this.idToken = res.idToken;
    this.refreshToken = res.refreshToken;
    this.localId = res.localId;
    this.tokenExp = nowSec() + (parseInt(res.expiresIn, 10) || 3600);
    this._saveAuth();
    this.log.info('cloud', 'Fern-Live: anonym bei Firebase angemeldet (uid ' + String(this.localId).slice(0, 8) + '…).');
    return this.idToken;
  }

  async _refresh() {
    const url = this.tokenUrl + '?key=' + encodeURIComponent(this.cfg.apiKey);
    const body = 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(this.refreshToken);
    const res = await this._reqJson('POST', url, body, { 'Content-Type': 'application/x-www-form-urlencoded' });
    if (!res.id_token) throw new Error('refresh ohne id_token: ' + JSON.stringify(res).slice(0, 160));
    this.idToken = res.id_token;
    this.refreshToken = res.refresh_token || this.refreshToken;
    this.localId = res.user_id || this.localId;
    this.tokenExp = nowSec() + (parseInt(res.expires_in, 10) || 3600);
    this._saveAuth();
    return this.idToken;
  }

  // ---------- RTDB REST ----------
  _put(pathAndQuery, obj) {
    const url = this.cfg.dbUrl.replace(/\/+$/, '') + pathAndQuery;
    return this._reqJson('PUT', url, JSON.stringify(obj), { 'Content-Type': 'application/json' });
  }

  _reqJson(method, urlString, body, headers) {
    return new Promise((resolve, reject) => {
      let u;
      try { u = new URL(urlString); } catch (e) { return reject(new Error('URL ungueltig: ' + e.message)); }
      const isHttp = u.protocol === 'http:';
      const lib = isHttp ? http : https;
      const opts = {
        method: method,
        hostname: u.hostname,
        port: u.port || (isHttp ? 80 : 443),
        path: u.pathname + u.search,
        headers: Object.assign({ 'Accept': 'application/json' }, headers || {}),
        timeout: 8000,
      };
      if (body != null) opts.headers['Content-Length'] = Buffer.byteLength(body);
      const req = lib.request(opts, (res) => {
        let data = '';
        res.on('data', (c) => { data += c; });
        res.on('end', () => {
          const code = res.statusCode || 0;
          if (code < 200 || code >= 300) return reject(new Error('HTTP ' + code + ': ' + String(data).slice(0, 200)));
          if (!data) return resolve({});
          try { resolve(JSON.parse(data)); } catch (_) { resolve({ raw: data }); }
        });
      });
      req.on('error', (e) => reject(e));
      req.on('timeout', () => { req.destroy(new Error('Zeitueberschreitung')); });
      if (body != null) req.write(body);
      req.end();
    });
  }

  stop() { this.started = false; }
}

function nn(x) { return (x == null || Number.isNaN(x)) ? null : x; }

module.exports = { CloudPublisher, sanitizeKey };
