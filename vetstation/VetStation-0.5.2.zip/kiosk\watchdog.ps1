<#
  watchdog.ps1 - Selbstheilung (Par.8): prueft periodisch, ob Bridge+UI erreichbar sind und der
  Kiosk-Browser laeuft; startet bei Absturz automatisch neu. Read-only.

  Aufruf:  powershell -ExecutionPolicy Bypass -File kiosk\watchdog.ps1 -Port 8770
#>
param([int]$Port = 8770, [int]$IntervalSec = 10)

$Root = Split-Path $PSScriptRoot -Parent
$Url = "http://127.0.0.1:$Port"
Write-Host "VetStation-Watchdog aktiv (Port $Port, Intervall ${IntervalSec}s). Strg+C zum Beenden."

function Test-BridgeUp { try { return (Invoke-WebRequest "$Url/healthz" -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200 } catch { return $false } }
function Test-EdgeUp { return [bool](Get-Process msedge -ErrorAction SilentlyContinue) }

while ($true) {
  if (-not (Test-BridgeUp)) {
    Write-Warning "$(Get-Date -Format T) Bridge nicht erreichbar -> Neustart."
    & (Join-Path $PSScriptRoot 'launch-kiosk.ps1') -Port $Port -NoKiosk
  }
  if (-not (Test-EdgeUp)) {
    Write-Warning "$(Get-Date -Format T) Kiosk-Browser weg -> Neustart."
    & (Join-Path $PSScriptRoot 'launch-kiosk.ps1') -Port $Port | Out-Null
  }
  Start-Sleep -Seconds $IntervalSec
}
