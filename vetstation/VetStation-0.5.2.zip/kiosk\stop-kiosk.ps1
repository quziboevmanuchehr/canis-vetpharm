<#
  stop-kiosk.ps1 - Kiosk sauber beenden (Wartung). Stoppt den Kiosk-Edge und die Bridge.
  Hinweis: Der PIN-Schutz liegt IN der App (Admin-Bereich). Dieses Skript ist fuer die
  Wartung am dedizierten PC gedacht (z. B. nach Anmeldung als Admin).

  ADMINRECHTE: Der Autostart-Kiosk wird von install-autostart.ps1 als geplante Aufgabe mit
  -RunLevel Highest registriert - Bridge (node) und Edge laufen dadurch ERHOEHT. Aus einer
  normalen PowerShell scheitert Stop-Process dann mit "Zugriff verweigert". Frueher steckten
  die Aufrufe in try{}catch{}: es erschien trotzdem "VetStation gestoppt.", obwohl nichts
  gestoppt wurde. Deshalb ab 0.5.1: Rechte selbst anfordern und ehrlich berichten.

  Aufruf:  powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\stop-kiosk.ps1"
#>
param([int]$Port = 8770)

# --- Adminrechte sicherstellen -------------------------------------------------
$__id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
  try {
    Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass',
      '-File', ('"' + $PSCommandPath + '"'), '-Port', $Port)
  } catch {
    Write-Warning "Adminrechte noetig. Bitte PowerShell rechtsklicken -> 'Als Administrator ausfuehren'."
    Start-Sleep 6
  }
  exit
}

$edge = 0; $bridge = 0; $fehler = @()

# Kiosk-Edge (nur die VetStation-Instanz mit eigenem Profil) beenden
Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -match 'VetStation\\EdgeProfile' } |
  ForEach-Object {
    try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $edge++ }
    catch { $fehler += "Edge (PID $($_.ProcessId)): $($_.Exception.Message)" }
  }

# Bridge (Node auf dem Port) beenden
$c = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($c) {
  $c.OwningProcess | Select-Object -Unique | ForEach-Object {
    $pidNr = $_
    try { Stop-Process -Id $pidNr -Force -ErrorAction Stop; $bridge++ }
    catch { $fehler += "Bridge (PID $pidNr): $($_.Exception.Message)" }
  }
}

# Ehrliche Rueckmeldung statt pauschalem "gestoppt."
if ($fehler.Count -gt 0) {
  Write-Warning "NICHT alles konnte beendet werden:"
  $fehler | ForEach-Object { Write-Warning "  - $_" }
  Write-Host "Der Kiosk laeuft moeglicherweise WEITER."
} elseif ($edge -eq 0 -and $bridge -eq 0) {
  Write-Host "Es lief nichts: weder Kiosk-Edge noch Bridge auf Port $Port gefunden."
} else {
  Write-Host "VetStation gestoppt (Edge-Fenster: $edge, Bridge-Prozesse: $bridge)."
}
