<#
  set-static-ip.ps1 - Richtet die statische IP fuer das ISOLIERTE Geraete-Netz ein (Par. LAN-Setup).
  Interaktiv: zeigt die Netzwerkkarten, du waehlst die Karte, die am Geraete-Switch haengt.
  Setzt standardmaessig 192.168.0.99/24 OHNE Gateway (isoliert, kein Router).

  WARUM 192.168.0.99? Im uMEC12 Vet steht unter "Gateway-Kommunikationseinst." bereits
  Ziel 192.168.0.99 Port 3502. Wenn der PC GENAU diese IP bekommt, muss am Geraet nichts
  umgestellt werden ausser der eigenen Geraete-IP (DHCP schlaegt ohne Router fehl!).

  WICHTIG: Nur die Karte auswaehlen, die zum Geraete-Switch geht - NICHT die Karte mit
  Internet/Praxisnetz. Als Administrator ausfuehren.

  EINFACHSTER WEG (nichts tippen):  im Ordner C:\VetStation die Datei
  NETZWERK-EINRICHTEN.bat DOPPELKLICKEN.

  Aufruf von Hand (VOLLSTAENDIGER Pfad - ein relativer Pfad schlaegt fehl, wenn PowerShell
  in C:\Windows\System32 startet!):
      powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-static-ip.ps1"
  Nicht-interaktiv:  -Adapter "Ethernet 2" -IP 192.168.0.99 -Prefix 24
#>
param(
  [string]$Adapter,
  [string]$IP = '192.168.0.99',
  [int]$Prefix = 24
)

# --- Adminrechte sicherstellen -------------------------------------------------
# New-NetIPAddress/Remove-NetIPAddress brauchen Adminrechte. Ohne diesen Guard laeuft das
# Skript bis zum Ende durch und scheitert erst beim Setzen der IP ("Zugriff verweigert").
$__id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
  $__args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'),
              '-IP', $IP, '-Prefix', $Prefix)
  if ($Adapter) { $__args += @('-Adapter', ('"' + $Adapter + '"')) }
  try {
    Start-Process powershell.exe -Verb RunAs -ArgumentList $__args
  } catch {
    Write-Warning "Adminrechte noetig. Bitte 'NETZWERK-EINRICHTEN.bat' rechtsklicken -> Als Administrator ausfuehren."
    Start-Sleep 6
  }
  exit
}

Write-Host "== Statische IP fuer das isolierte Geraete-Netz =="
Write-Host "Im Monitor steht als Ziel bereits:  192.168.0.99  Port 3502  (Gateway-Kommunikationseinst.)"
Write-Host "-> Der PC bekommt deshalb GENAU diese IP: $IP /$Prefix (kein Gateway, isoliert)."
Write-Host "   Dann musst du am Geraet nur noch die EIGENE Geraete-IP fest eintragen."
Write-Host ""
Write-Host "ACHTUNG - haeufigste Ursache 'verbindet nicht':"
Write-Host "   Der Monitor stand auf DHCP und hat KEINE IP bekommen (0.0.0.0,"
Write-Host "   Meldung 'Abrufen der Netzwerkadr. fehlgeschlagen') - ohne Router gibt es keinen DHCP."
Write-Host "   Loesung: am Monitor Adresstyp auf 'Manuell/Statisch' stellen (siehe Schritte unten)."
Write-Host ""

# Virtuelle Karten (VPN, Hyper-V, Bluetooth, Loopback) gehoeren NIE ans Geraete-Netz und
# wuerden die Auswahl nur unuebersichtlich machen -> ausblenden.
$VIRTUELL = 'VPN|Virtual|Hyper-V|VMware|VirtualBox|Loopback|Bluetooth|TAP-|Radmin|Tailscale|WireGuard|WAN Miniport'
$nics = @(Get-NetAdapter | Where-Object {
    $_.Status -in @('Up', 'Disconnected') -and
    $_.InterfaceDescription -notmatch $VIRTUELL -and $_.Name -notmatch $VIRTUELL
  } | Sort-Object Name)

if (-not $Adapter) {
  if ($nics.Count -eq 0) {
    Write-Warning "Keine Netzwerkkarte gefunden. Steckt das LAN-Kabel im PC?"
    Read-Host "Zum Schliessen die EINGABETASTE druecken"
    exit 1
  }
  # Nur EINE Karte, ODER genau eine Karte mit eingestecktem Kabel ('Up') -> gar nicht erst fragen.
  # (Frueher wurde hier immer nach einer Nummer gefragt; Nutzer tippten die IP oder eine
  #  Zufallszahl ein und bekamen nur "Ungueltige Auswahl" + sofortigen Abbruch.)
  elseif ($nics.Count -eq 1 -or @($nics | Where-Object Status -eq 'Up').Count -eq 1) {
    $wahl = if ($nics.Count -eq 1) { $nics[0] } else { @($nics | Where-Object Status -eq 'Up')[0] }
    $Adapter = $wahl.Name
    Write-Host ("Netzwerkkarte automatisch gewaehlt: {0}  ({1}, {2})" -f $wahl.Name, $wahl.InterfaceDescription, $wahl.Status)
    if ($wahl.Status -eq 'Disconnected') {
      Write-Host ""
      Write-Warning "In dieser Karte steckt gerade KEIN Kabel ('Disconnected')."
      Write-Host "  Die IP wird trotzdem gesetzt - aber Daten kommen erst, wenn das LAN-Kabel"
      Write-Host "  zwischen PC, Switch und Monitor steckt."
    }
  }
  else {
    Write-Host "Es gibt mehrere Netzwerkkarten. Welche haengt am GERAETE-Switch (Monitor)?"
    Write-Host ""
    for ($i = 0; $i -lt $nics.Count; $i++) {
      Write-Host ("   [{0}]  {1}   ({2}, {3})" -f $i, $nics[$i].Name, $nics[$i].InterfaceDescription, $nics[$i].Status)
    }
    Write-Host ""
    Write-Host "Bitte NUR die Zahl aus der eckigen Klammer eingeben - also 0" -ForegroundColor Yellow
    Write-Host "(keine IP-Adresse, keinen Namen, nur die Zahl 0 bis $($nics.Count - 1))."
    $versuch = 0
    while (-not $Adapter) {
      $versuch++
      $sel = (Read-Host "Zahl eingeben").Trim()
      if ($sel -match '^\d+$' -and [int]$sel -lt $nics.Count) {
        $Adapter = $nics[[int]$sel].Name
      }
      elseif ($nics.Name -contains $sel) {
        $Adapter = $sel   # der Nutzer hat den Kartennamen getippt - auch das akzeptieren
      }
      else {
        Write-Warning "'$sel' ist keine gueltige Auswahl. Erwartet wird eine Zahl von 0 bis $($nics.Count - 1)."
        if ($versuch -ge 3) {
          Write-Warning "Abbruch nach 3 Versuchen. Bitte das Skript erneut starten."
          Read-Host "Zum Schliessen die EINGABETASTE druecken"
          exit 1
        }
      }
    }
  }
}

Write-Host ""
Write-Host "Setze auf Karte '$Adapter':  IP $IP /$Prefix, kein Gateway (isoliert)."
$ok = Read-Host "Fortfahren? j = ja, n = nein  (Standard: ja)"
if ($ok -ne '' -and $ok -notmatch '^(j|y)') { Write-Host "Abgebrochen."; Read-Host "EINGABETASTE"; exit 0 }

try {
  # Vorhandene statische IPs/Routen dieser Karte entfernen, dann setzen
  Get-NetIPAddress -InterfaceAlias $Adapter -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object PrefixOrigin -eq 'Manual' | Remove-NetIPAddress -Confirm:$false -ErrorAction SilentlyContinue
  New-NetIPAddress -InterfaceAlias $Adapter -IPAddress $IP -PrefixLength $Prefix -ErrorAction Stop | Out-Null
  # DNS leeren (isoliert)
  Set-DnsClientServerAddress -InterfaceAlias $Adapter -ResetServerAddresses -ErrorAction SilentlyContinue

  # Nachpruefen statt nur behaupten: steht die IP wirklich auf der Karte?
  Start-Sleep -Milliseconds 800
  $ist = Get-NetIPAddress -InterfaceAlias $Adapter -AddressFamily IPv4 -ErrorAction SilentlyContinue |
           Where-Object IPAddress -eq $IP
  if ($ist) {
    Write-Host ""
    Write-Host "ERFOLG: '$Adapter' hat jetzt $IP/$Prefix." -ForegroundColor Green
  } else {
    Write-Warning "Die IP $IP konnte nicht bestaetigt werden. Bitte pruefen mit:  ipconfig"
  }
  Write-Host ""
  Write-Host "NAECHSTE SCHRITTE AM MONITOR (uMEC12 Vet) - genau in dieser Reihenfolge:"
  Write-Host "  1) Hauptmenue -> Wartung -> Benutzer-Wartung  (Passwort 888888)"
  Write-Host "  2) Netzwerk -> Monitornetzwerk-Setup:"
  Write-Host "       Netzwerktyp : LAN"
  Write-Host "       Adresstyp   : Manuell / Statisch   <-- NICHT DHCP (sonst 0.0.0.0!)"
  Write-Host "       IP-Adresse  : 192.168.0.50"
  Write-Host "       Subn.maske  : 255.255.255.0"
  Write-Host "       Gateway     : 192.168.0.1   (oder 0.0.0.0, wenn kein Router)"
  Write-Host "     -> OK. Die IP darf danach NICHT mehr 0.0.0.0 sein."
  Write-Host "  3) Netzwerk -> Gateway-Kommunikationseinst.:  IP $IP   Port 3502   -> OK"
  Write-Host "  4) Zweites Geraet (LifeVet) analog: IP 192.168.0.51, gleiches Ziel $IP."
  Write-Host "  5) Am PC pruefen: Datei GERAETE-PRUEFEN.bat DOPPELKLICKEN (zeigt, ob Daten ankommen)."
  Write-Host "  - Details: docs\LAN-SETUP.md"
} catch {
  Write-Warning "Fehler: $($_.Exception.Message)"
  Write-Host "Alternativ manuell: Systemsteuerung -> Netzwerkadapter -> IPv4 -> feste IP $IP, Maske 255.255.255.0, kein Gateway."
}

Write-Host ""
Read-Host "Fertig. Zum Schliessen die EINGABETASTE druecken"
