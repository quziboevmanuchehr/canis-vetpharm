'use strict';
/*
 * probe.js — Verbindungs-Assistent / Auto-Erkennung (fuer die Erst-Inbetriebnahme am echten Geraet).
 *
 * Zweck: Du steckst das LAN-Kabel ein und traegst am Geraet als Serveradresse die PC-IP ein.
 * Der Probe lauscht auf MEHREREN Kandidaten-Ports, ERKENNT HL7 automatisch (und parst es dann
 * sofort -> Patient erscheint), und protokolliert alles Unbekannte als Rohdaten (Hex) fuer die
 * Analyse. Zusaetzlich sucht er per ARP nach Mindray-Geraeten (MAC-Prefix 98:CC:E4).
 *
 * STRIKT READ-ONLY: nur lauschen/aufzeichnen, nie senden.
 *
 * Konfig: { id, ports:[3502,4601,5000,24105,2575], species?, arpScan?:true }
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { Adapter } = require('./base');
const { parseHL7Message } = require('./hl7');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
// Mindray-MAC-Praefixe (aus den Fotos): 98:CC:E4 (uMEC12 Vet / Veta 5 Plus), 00:0F:14 (LifeVet 10C).
const MINDRAY_OUI = ['98cce4', '000f14'];

class ProbeAdapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    // 3502 = Mindray "Gateway-Kommunikation" (am uMEC12 Vet im Netzwerk-Menue ab Werk eingetragen,
    //        Foto der Praxis: Ziel 192.168.0.99:3502) -> ZUERST lauschen.
    // 4601 = VSCapture-/Mindray-HL7-Standardport (aus dem VSCapture-Binary bestaetigt); 5000/24105/2575 weitere Kandidaten.
    this.ports = cfg.ports && cfg.ports.length ? cfg.ports : [3502, 4601, 5000, 24105, 2575];
    this.servers = [];
    this.detected = {};       // port -> 'hl7' | 'unbekannt'
    this.unmapped = new Set();
    this.arpTimer = null;
  }

  describe() { return { id: this.id, model: 'Verbindungs-Assistent', role: 'monitor' }; }

  async connect() {
    this.ports.forEach((port) => this._listen(port));
    this.connected = true;
    this.ctx.log.info('probe', 'Verbindungs-Assistent aktiv. Lauscht auf Ports ' + this.ports.join(', ') +
      '. Am Geraet Serveradresse = PC-IP eintragen. Erkanntes HL7 wird automatisch verarbeitet.');
    if (this.cfg.arpScan !== false) { this._arpScan(); this.arpTimer = setInterval(() => this._arpScan(), 30000); }
  }

  _listen(port) {
    const server = net.createServer((socket) => this._onClient(socket, port));
    server.on('error', (e) => {
      if (e.code === 'EADDRINUSE') this.ctx.log.warn('probe', 'Port ' + port + ' bereits belegt (anderer Adapter?) — uebersprungen.');
      else this.ctx.log.warn('probe', 'Port ' + port + ' Fehler: ' + e.message);
    });
    server.listen(port, () => this.ctx.log.info('probe', 'bereit auf Port ' + port));
    this.servers.push(server);
  }

  _onClient(socket, port) {
    const ip = socket.remoteAddress;
    this.ctx.log.info('probe', 'VERBINDUNG auf Port ' + port + ' von ' + ip + ' — analysiere Datenstrom...');
    let buf = Buffer.alloc(0);
    let idle = null;

    socket.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      // 1) HL7 mit MLLP-Rahmen?
      let start;
      let handled = false;
      while ((start = buf.indexOf(VT)) !== -1) {
        const end = buf.indexOf(FS, start + 1);
        if (end === -1) break;
        const payload = buf.slice(start + 1, end).toString('latin1');
        buf = buf.slice(end + 2);
        this._onHL7(payload, port, ip); handled = true;
      }
      if (handled) return;
      // 2) HL7 ohne MLLP? (rohes "MSH|") — nach kurzer Ruhe parsen
      if (buf.indexOf('MSH|') !== -1) {
        clearTimeout(idle);
        idle = setTimeout(() => {
          const text = buf.toString('latin1'); buf = Buffer.alloc(0);
          if (text.indexOf('MSH|') !== -1) this._onHL7(text, port, ip);
        }, 400);
        return;
      }
      // 3) Unbekanntes (proprietaeres?) Protokoll -> Rohdaten sichern
      if (this.detected[port] !== 'unbekannt') {
        this.detected[port] = 'unbekannt';
        this.ctx.log.warn('probe', 'Port ' + port + ': KEIN HL7 erkannt (evtl. proprietaerer CentralStation-Link). ' +
          'Erste Bytes: ' + buf.slice(0, 24).toString('hex') + ' — Rohdaten -> data/probe-' + port + '.log');
      }
      this._rawDump(port, chunk);
      if (buf.length > 1 << 20) buf = Buffer.alloc(0);
    });
    socket.on('error', () => {});
    socket.on('close', () => this.ctx.log.info('probe', 'Verbindung Port ' + port + ' (' + ip + ') geschlossen.'));
  }

  _onHL7(text, port, ip) {
    if (this.detected[port] !== 'hl7') {
      this.detected[port] = 'hl7';
      this.ctx.log.info('probe', '✓ HL7 ERKANNT auf Port ' + port + ' von ' + ip + ' — Werte werden jetzt automatisch gelesen!');
    }
    let frame;
    try {
      frame = parseHL7Message(text, { deviceId: this.id + '-' + port, model: 'Mindray (HL7 auto)', role: 'combo', species: this.cfg.species },
        (u) => { if (!this.unmapped.has(u)) { this.unmapped.add(u); this.ctx.log.warn('probe', 'Unbekannter OBX-Code: ' + u + ' (in hl7.js CODE_MAP ergaenzen)'); } });
    } catch (e) { this.ctx.log.warn('probe', 'HL7-Parsefehler: ' + e.message); return; }
    if (frame) this.emit(frame);
  }

  _rawDump(port, chunk) {
    try { const dir = path.join(__dirname, '..', '..', 'data'); fs.mkdirSync(dir, { recursive: true }); fs.appendFileSync(path.join(dir, 'probe-' + port + '.log'), chunk); } catch (_) {}
  }

  // ARP-Scan: findet Mindray-Geraete im Netz (MAC 98:CC:E4...) -> bestaetigt die physische Verbindung.
  _arpScan() {
    execFile('arp', ['-a'], { timeout: 5000 }, (err, stdout) => {
      if (err || !stdout) return;
      const lines = stdout.split(/\r?\n/);
      const found = [];
      lines.forEach((l) => {
        const m = l.match(/(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2})/);
        if (!m) return;
        const mac = m[2].toLowerCase().replace(/[:-]/g, '');
        if (MINDRAY_OUI.some((o) => mac.startsWith(o))) found.push({ ip: m[1], mac: m[2].toLowerCase() });
      });
      if (found.length) this.ctx.log.info('probe', 'Mindray-Geraet(e) im Netz gefunden: ' + found.map((f) => f.ip + ' (' + f.mac + ')').join(', '));
    });
  }

  dispose() {
    if (this.arpTimer) clearInterval(this.arpTimer);
    this.servers.forEach((s) => { try { s.close(); } catch (_) {} });
    this.servers = []; this.connected = false;
  }
}

module.exports = { ProbeAdapter };
