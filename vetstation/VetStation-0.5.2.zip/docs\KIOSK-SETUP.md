# Kiosk-Setup (Kurzüberblick)

Die vollständige Anleitung steht in **[../kiosk/assigned-access.md](../kiosk/assigned-access.md)**.

## Sofort lauffähig (heute, ohne Rust)

### Doppelklick — nichts tippen (Praxis-PC, Installation liegt in `C:\VetStation`)

| Doppelklick auf … | bewirkt … |
|---|---|
| `C:\VetStation\START-VetStation.bat` | Bridge + Edge-Vollbild-Kiosk starten (einmalig, ohne Autostart) |
| `C:\VetStation\INSTALLIEREN.bat` | Autostart beim Anmelden + Watchdog einrichten — holt die Adminrechte selbst, UAC-Abfrage mit **Ja** bestätigen |

`NETZWERK-EINRICHTEN.bat` (feste IP **192.168.0.99**) und `GERAETE-PRUEFEN.bat` liegen ebenfalls in
`C:\VetStation` und zusätzlich im Startmenü unter **„VetStation"**.

### Nur falls doch getippt werden muss (vollständiger Pfad, in Anführungszeichen)

PowerShell startet in `C:\Windows\System32`. Ein relativer Pfad wie `kiosk\launch-kiosk.ps1` wird dort
**nicht** gefunden („Das Argument … für den -File-Parameter ist nicht vorhanden").

```powershell
# Bridge + Edge-Vollbild-Kiosk  (ohne Adminrechte)
powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\launch-kiosk.ps1"

# Autostart beim Anmelden + Watchdog  -->  BRAUCHT ADMINRECHTE
powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\install-autostart.ps1"
```

> **Adminrechte:** Der zweite Befehl registriert eine geplante Aufgabe
> (`Register-ScheduledTask -RunLevel Highest`). PowerShell dafür per **Rechtsklick →
> „Als Administrator ausführen"** öffnen. Das Skript versucht sich auch selbst hochzustufen —
> die UAC-Abfrage dann mit **Ja** bestätigen. Einfacher ist der Doppelklick auf `INSTALLIEREN.bat`.

- Nutzt die bereits installierte **Edge/WebView2-Runtime** (kein Extra-Install).
- **Watchdog** (`C:\VetStation\kiosk\watchdog.ps1`) startet Bridge/Kiosk bei Absturz automatisch neu (§8).
- **Autologin** + **Assigned Access** (Weg A) oder **Shell Launcher** (Weg B) → siehe assigned-access.md.
- **Beenden/Wartung:** Admin-PIN in der App (Standard `1234`); Kiosk-Wartung über ein separates
  Admin-Windows-Konto und diesen Befehl. **PowerShell per Rechtsklick → „Als Administrator
  ausführen" öffnen** — der Kiosk läuft mit erhöhten Rechten (Autostart-Aufgabe mit
  `-RunLevel Highest`), sonst schlägt das Beenden fehl. Ab 0.5.1 fordert das Skript die Rechte
  selbst an (UAC) und meldet ehrlich, wenn nichts beendet werden konnte:

  ```powershell
  powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\stop-kiosk.ps1"
  ```

## Produktions-Packaging (später, mit Rust)
**Tauri-MSI + signiertes Auto-Update** → **[../tauri-shell/README.md](../tauri-shell/README.md)**.

## Windows 10 & 11
Beide unterstützt; WebView2 ist Evergreen (identisches Verhalten, auch künftige Versionen). Layout
responsiv/DPI-fähig, Maus **und** Touch.

## Nur Entwickler-PC (D:\VetStation)
Auf dem Entwickler-PC liegt die Quelle unter `D:\VetStation` (nicht `C:\VetStation`). Dieselben
Skripte werden dort mit dem D:-Pfad aufgerufen:

```powershell
powershell -ExecutionPolicy Bypass -File "D:\VetStation\kiosk\launch-kiosk.ps1"
powershell -ExecutionPolicy Bypass -File "D:\VetStation\kiosk\install-autostart.ps1"   # Adminrechte
powershell -ExecutionPolicy Bypass -File "D:\VetStation\kiosk\stop-kiosk.ps1"
```
