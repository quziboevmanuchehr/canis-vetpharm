<#
  Install-VetStation.ps1 - Installiert VetStation auf dem Ziel-PC (Windows 10/11 Pro) als
  Autostart-Kiosk. Kopiert die App nach C:\VetStation, richtet Autostart + Watchdog ein und
  bietet optional die statische IP fuer das isolierte Geraete-Netz an.

  AUSFUEHREN ALS ADMINISTRATOR (Rechtsklick INSTALLIEREN.bat -> Als Administrator ausfuehren,
  oder: powershell -ExecutionPolicy Bypass -File installer\Install-VetStation.ps1).
#>
param(
  [string]$Dest = "C:\VetStation",
  [int]$Port = 8770,
  [switch]$NoStaticIP,
  [switch]$NoAutostart
)
$ErrorActionPreference = 'Stop'

function Ensure-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Starte Installer mit Administratorrechten neu (bitte UAC-Abfrage bestaetigen)..."
    try {
      Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'))
    } catch { Write-Warning "Adminrechte noetig. Bitte 'INSTALLIEREN.bat' rechtsklicken -> Als Administrator ausfuehren." ; Start-Sleep 4 }
    exit
  }
}
Ensure-Admin

# Windows 10 UND Windows 11 werden gleichermassen unterstuetzt (WebView2 Evergreen, PowerShell, Scheduled Task).
$os = try { (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { 'Windows' }
Write-Host "Windows erkannt: $os  - Win10 und Win11 werden unterstuetzt."

$Src = Split-Path $PSScriptRoot -Parent   # Wurzel des Bundles (dieser Ordner)
Write-Host "== VetStation Installation =="
Write-Host "Quelle: $Src"
Write-Host "Ziel:   $Dest"

# 1) Kopieren nach $Dest (falls nicht bereits dort ausgefuehrt)
if ((Resolve-Path $Src).Path -ne (Resolve-Path -LiteralPath $Dest -ErrorAction SilentlyContinue).Path) {
  New-Item -ItemType Directory -Force -Path $Dest | Out-Null
  Write-Host "Kopiere App nach $Dest ..."
  robocopy $Src $Dest /E /XD (Join-Path $Src '.git') (Join-Path $Src 'dist') /XF '*.log' /NFL /NDL /NJH /NJS /NP | Out-Null
}

# 2) Node pruefen (bundled bevorzugt)
$node = $null
foreach ($p in @("$Dest\node\node.exe", "$env:ProgramFiles\nodejs\node.exe")) { if (Test-Path $p) { $node = $p; break } }
if (-not $node) { $c = Get-Command node -ErrorAction SilentlyContinue; if ($c) { $node = $c.Source } }
if (-not $node) {
  Write-Warning "Kein Node gefunden. Das Paket sollte 'node\node.exe' enthalten (make-dist.ps1). Sonst Node 18+ installieren."
} else {
  Write-Host "Node: $node"
}

# 3) Autostart-Kiosk registrieren (nutzt kiosk\install-autostart.ps1 im Ziel)
if (-not $NoAutostart) {
  Write-Host "Richte Autostart (Kiosk + Watchdog) ein ..."
  & (Join-Path $Dest 'kiosk\install-autostart.ps1') -Port $Port
}

# 4) Windows-Firewall: eingehende Geraete-Ports freigeben
#    OHNE diese Regeln blockiert Windows die Vitaldaten LAUTLOS (Geraet sendet, PC verwirft).
#    3502 = Mindray Gateway-Kommunikation (uMEC12 Vet Standard-Ziel), 4601 = HL7/VSCapture,
#    5000/24105/2575 = weitere HL7-Kandidatenports.
Write-Host ""
Write-Host "Gebe die Windows-Firewall fuer die Geraete-Ports frei (eingehend TCP) ..."
$fwPorts = @(3502, 4601, 5000, 24105, 2575)
foreach ($p in $fwPorts) {
  $ruleName = "VetStation Geraetedaten TCP $p"
  $ok = $false
  try {
    Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP `
      -LocalPort $p -Profile Any -Description "VetStation: Vitaldaten von Narkose-/Patientenmonitoren (nur lesend)" -ErrorAction Stop | Out-Null
    $ok = $true
  } catch {
    # Fallback fuer Systeme ohne NetSecurity-Modul
    try {
      netsh advfirewall firewall delete rule name="$ruleName" | Out-Null
      netsh advfirewall firewall add rule name="$ruleName" dir=in action=allow protocol=TCP localport=$p | Out-Null
      $ok = $true
    } catch {}
  }
  if ($ok) { Write-Host ("  + TCP {0} freigegeben" -f $p) } else { Write-Host ("  ! TCP {0} konnte nicht freigegeben werden (bitte manuell)" -f $p) }
}

# 5) Optional: statische IP fuer das isolierte Geraete-Netz
if (-not $NoStaticIP) {
  Write-Host ""
  $ans = Read-Host "Jetzt die statische IP fuer das isolierte Geraete-Netz einrichten? (j/N)"
  if ($ans -match '^(j|y)') { & (Join-Path $Dest 'installer\set-static-ip.ps1') }
  else { Write-Host "Uebersprungen. Spaeter: installer\set-static-ip.ps1 (siehe docs\LAN-SETUP.md)." }
}

Write-Host ""
Write-Host "== Installation abgeschlossen =="
Write-Host "Sofort testen:   powershell -ExecutionPolicy Bypass -File `"$Dest\kiosk\launch-kiosk.ps1`""
Write-Host "Beim naechsten Anmelden startet VetStation automatisch im Vollbild-Kiosk."
Write-Host "LAN-Aufbau (Switch, IPs, Serveradresse=PC-IP):  $Dest\docs\LAN-SETUP.md"
Write-Host "Geraete-Adapter aktivieren:  $Dest\bridge\config\devices.json  (siehe docs\DEVICE-ADAPTERS.md)"
