# Geräte-Protokolle — Quellen & Links (verifiziert 2026-07-18)

Alle Links geprüft (erreichbar) + der jeweils entscheidende Fakt fürs Live-Auslesen an den PC.

## Mindray-Protokolle (das Herzstück)
| Quelle | Erreichbar | Kernfakt fürs Auslesen |
|---|---|---|
| **PDS Protocol Guide (HL7)** — [PDF](https://www.mindray.com/content/dam/xpace/en_us/service-and-support/training-and-education/resource--library/technical--documents/operators-manuals-1/H-0010-20-43061-2-Mindray-Patient-Data-Share-Protocol-Programmers-Guide-v14_2-03-2020.pdf) | ✅ | **HL7 + MLLP + `ORU^R01` über TCP**, Daten **RAUS** an den PC (Bedside/CMS/PDS-Gateway → Client). OBX-Codes (101=HF, 160=SpO₂, 170/171/172=NIBP, 220=CO₂, 222=AWRR, 200=Temp). **Das ist die Schnittstelle, die VetStation bedient.** |
| **BeneLink** — [Seite](https://www.mindray.com/en/products/it-products/benelink) · Manual H-046-011948-00 | ✅ | **Falsche Richtung für uns:** holt Fremdgeräte (Beatmung/Narkose) **IN** den Monitor. Kein Export an den PC. |
| **eGateway** — [Seite](https://www.mindray.com/en/products/it-products/egateway) | ✅ | Der **RAUS**-Weg: bündelt bis 200 Monitore → **HL7** an EMR/PC. (Kostenpflichtig, für Mehrbett-/EMR-Setups.) |
| **A-Serie Anesthesia Protocol Guide** — [PDF](https://www.mindray.com/content/dam/xpace/en_us/service-and-support/training-and-education/resource--library/technical--documents/operators-manuals-2/A-Series-Com-Protocol-Interface-Guide-(SW-V02.12.00-to-V02.13.00).pdf) | ✅ | Narkosegerät sendet **RAUS** via Ethernet/RS-232, **HL7 v2.6 (IHE PCD DEC), MLLP, ORU**, Port am Gerät konfigurierbar. (Humane A-Serie, nicht der Veta.) |

## Gerätehandbücher
| Gerät | Erreichbar | Kernfakt |
|---|---|---|
| **uMEC10/12/15 Operator's Manual** — [PDF](http://mindray.sy/wp-content/uploads/2019/09/uMEC-Operator%E2%80%99s-Manual.pdf) | ✅ | RJ45-LAN + CMS; **Gateway-Comm-Setup (IP/Port) + ADT-Query**; proprietäres CMS/Multicast, **kein explizites HL7-Menü** (HL7 via Gateway). Service-Passwort 888888. |
| **uMEC12 Vet** — [Seite](https://www.mindrayanimal.com/en/product/uMEC12_Vet) | ✅ | Marketing; kein offenes Interface auf der Seite (Details im Operator's Manual). |
| **Veta 5 Plus** — [Seite](https://www.mindrayanimal.com/en/product/Veta_5Plus) | ✅ | „Anesthesia Super Hub" = Gerät-zu-Gerät (liest EtCO₂ **vom** Monitor); **kein LAN/CMS/HL7-Datenausgang**. (`Veta_5_/_Veta_3` = 404.) |

## LifeVet 10C (Eickemeyer)
| Quelle | Erreichbar | Kernfakt |
|---|---|---|
| **Produktseite** — [Eickemeyer 321920](https://www.eickemeyer.de/shop/321920-multiparameter-monitor-lifevet-10c-15534) | ✅ | Eickemeyer-Rebadge (Distributor), 10″, bis 8 Kurven, ~2.495 €. |
| **User Manual EN** — [PDF](https://scandivet.se/wp-content/uploads/2024/08/4108131-manual.pdf) | ✅ | **Strukturell ein Mindray-Monitor-Handbuch** (Remote View, Alarm Watch, LLDP/CDP-Bettnummer, GB1-Font). LAN/WLAN, Netzwerk-Monitoring. Branding entfernt (keine Worte „Mindray/HL7/CMS"). |
| **Kurzanleitung DE** — [manualslib](https://www.manualslib.de/manual/990378/Eickemeyer-Lifevet-10C.html) | ⚠️ 403 für Bots | Blockiert automatisierte Abrufe; im normalen Browser erreichbar. |
| Kontakt | — | info@eickemeyer.de |

## Auslese-Software
| Tool | Erreichbar | Kernfakt |
|---|---|---|
| **VSCapture** — [SourceForge](https://sourceforge.net/projects/vscapture/) | ✅ | Listet **„Mindray HL7"**; HL7-Listener (Port **4601**, aus dem Binary bestätigt). **Der reale PC-Weg.** Einrichten: siehe Kasten „VSCapture einrichten" direkt unter dieser Tabelle. |
| **VitalRecorder** — [vitaldb.net](https://vitaldb.net/vital-recorder/) | ✅ | Listet GE/Philips/Dräger/Nihon Kohden/Maquet — **Mindray NICHT** dokumentiert. → nicht als Mindray-Weg annehmen. |

### VSCapture einrichten (Praxis-PC, Installation liegt in `C:\VetStation`)

1. **PowerShell per Rechtsklick → „Als Administrator ausführen"** öffnen. Adminrechte sind nötig, weil das Skript herunterlädt und nach `C:\VetStation\vscapture` schreibt.
2. Diese **eine Zeile vollständig** hineinkopieren (voller Pfad in Anführungszeichen — PowerShell startet in `C:\WINDOWS\system32`, ein Aufruf mit `installer\...` schlägt dort immer fehl):

   ```
   powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\setup-vscapture-fallback.ps1"
   ```

3. Danach `C:\VetStation\vscapture\start-vscapture.bat` **doppelklicken** — sie schreibt `MRayDataExport.csv` in denselben Ordner.
4. Am Monitor eintragen: **Serveradresse = 192.168.0.99, Port 4601**
   (Menüweg: Hauptmenü → Wartung → Benutzer-Wartung, Passwort **888888** → Netzwerk).
   Achtung: **4601 gilt nur für diesen VSCapture-Fallback.** Im Normalbetrieb hört VetStation selbst auf **192.168.0.99 : 3502** — dann dort auch 3502 eintragen.

## Fazit für VetStation
- **Alle drei Geräte gehören zur Mindray-Familie** (LifeVet bestätigt Mindray-Technik). Der Datenweg **raus zum PC** ist überall **PDS-HL7 (MLLP/ORU über TCP)** bzw. eGateway/CMS — **BeneLink ist nur rein**.
- VetStation deckt beide Richtungen ab: **Listener** (Gerät → PC, im Monitor „Serveradresse = PC-IP **192.168.0.99**, Port **3502**") **und** **PDS-Realtime-Client** (PC → Gerät `192.168.0.50` bzw. `192.168.0.51`, Port 4601, `QRY^R02`). Der **Verbindungs-Assistent** erkennt automatisch. Die feste PC-IP setzt am Praxis-PC ein Doppelklick auf **`C:\VetStation\NETZWERK-EINRICHTEN.bat`** (holt Adminrechte selbst; liegt auch im Startmenü unter „VetStation"), prüfen lässt sich der Datenempfang per Doppelklick auf **`C:\VetStation\GERAETE-PRUEFEN.bat`**.
- **Offen (nur vom Händler):** Freischaltung/Lizenz, „Kurven ja/nein", und der **genaue TCP-Port deiner Vet-Firmware** (4601 ist die Konvention, in keiner Vet-Doku fest gedruckt). → E-Mail an Eickemeyer/Mindray.
- **Read-only:** VetStation liest/fragt nur Daten (QRY/ACK sind Protokoll, keine Gerätesteuerung); es verstellt nie Verdampfer/Beatmung.
