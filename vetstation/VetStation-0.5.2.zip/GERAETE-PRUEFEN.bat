@echo off
title VetStation - Geraete pruefen
REM Prueft, ob Monitor/Kapnograf Daten senden. Benutzt das mitgelieferte portable Node -
REM auf dem Praxis-PC gibt es KEIN npm, deshalb NICHT "npm run check" verwenden.
REM Optional laesst sich eine Geraete-IP mitgeben:  GERAETE-PRUEFEN.bat 192.168.0.50
REM Ohne Parameter sucht das Programm die Geraete selbst (MAC-Suche + Lauschphase).
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\geraete-check.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\geraete-check.js" %*
:ende
echo.
pause
