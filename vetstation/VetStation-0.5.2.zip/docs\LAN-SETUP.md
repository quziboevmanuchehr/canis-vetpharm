# LAN-Aufbau — PC + Monitor + Kapnograf verbinden

> ## ⭐ ZUERST LESEN: die 3 Gründe, warum „es verbindet nicht"
> Am 21.07.2026 direkt an den Praxis-Fotos des uMEC12 Vet festgestellt:
>
> **1. Der Monitor hatte KEINE IP-Adresse.** Im Menü *Monitornetzwerk-Setup* stand
> `Adresstyp: DHCP` und `IP-Adresse 0.0.0.0`, dazu die Meldung
> **„Abrufen der Netzwerkadr. fehlgeschlagen"**. Ohne Router gibt es keinen DHCP-Server,
> der Adressen vergibt → das Gerät bleibt auf `0.0.0.0` und kann **nichts** senden.
> **Lösung:** Adresstyp auf **Manuell/Statisch** stellen (Werte unten).
>
> **2. Der Monitor sendet an Port 3502 — dort lauschte VetStation nicht.** Unter
> *Gateway-Kommunikationseinst.* steht das Ziel **`192.168.0.99 : 3502`**. VetStation
> hörte bis 0.4.0 nur auf 4601/5000/24105/2575. **Ab 0.5.0 wird 3502 zuerst gelauscht.**
>
> **3. Die Windows-Firewall blockierte eingehende Verbindungen.** Ohne Freigabe verwirft
> Windows die Gerätedaten lautlos. **Der Installer legt die Regeln jetzt automatisch an**
> (TCP 3502/4601/5000/24105/2575).
>
> ### Einstellungen, die zusammenpassen müssen
> | Wo | Einstellung | Wert |
> |---|---|---|
> | **PC** | feste IP (isoliert) | **192.168.0.99** / 255.255.255.0 |
> | **Monitor** → Monitornetzwerk-Setup | Adresstyp | **Manuell** (nicht DHCP!) |
> | **Monitor** → Monitornetzwerk-Setup | IP-Adresse | **192.168.0.50** / 255.255.255.0 |
> | **Monitor** → Gateway-Kommunikationseinst. | Ziel-IP / Port | **192.168.0.99** / **3502** |
> | 2. Gerät (LifeVet) | IP-Adresse | 192.168.0.51 (gleiches Ziel) |
>
> ### Ablauf — NICHTS tippen, nur doppelklicken
> Im Ordner **`C:\VetStation`** (bzw. über *Startmenü → VetStation*) liegen zwei Dateien:
>
> | Schritt | Datei zum **Doppelklicken** | was sie tut |
> |---|---|---|
> | 1 | **`NETZWERK-EINRICHTEN.bat`** | setzt den PC auf die feste IP `192.168.0.99` (holt sich die Adminrechte selbst — UAC mit **Ja** bestätigen) |
> | 2 | *(am Monitor die 4 Werte eintragen — Tabelle oben)* | |
> | 3 | **`GERAETE-PRUEFEN.bat`** | zeigt im Klartext, ob Daten ankommen |
>
> Menüweg am Gerät: *Hauptmenü → Wartung → Benutzer-Wartung (Passwort **888888**) → Netzwerk*.
>
> > ⚠️ **Nicht von Hand mit relativem Pfad starten.** PowerShell öffnet sich in
> > `C:\Windows\System32`; `-File installer\set-static-ip.ps1` findet die Datei dort **nicht**
> > („Das Argument … ist nicht vorhanden"). Wenn es doch getippt sein muss, dann mit
> > **vollständigem** Pfad:
> > `powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-static-ip.ps1"`
> > Dieses Skript **braucht Adminrechte**: PowerShell dafür per Rechtsklick
> > **„Als Administrator ausführen"** öffnen. (Beim Doppelklick auf `NETZWERK-EINRICHTEN.bat`
> > entfällt das — die Datei holt sich die Rechte selbst.)
> >
> > ⚠️ **`npm` gibt es auf dem Praxis-PC nicht** (nur portables `node.exe`). `npm run check`
> > funktioniert **nur** auf dem Entwickler-PC — auf der Station stattdessen
> > `GERAETE-PRUEFEN.bat` doppelklicken.

Dein PC hat **nur einen LAN-Anschluss** — deshalb ist ein **kleiner LAN-Switch/Hub Pflicht**, um
3–5 Geräte zusammenzubinden. Aufbau:

```
   [uMEC12 Vet Monitor] --LAN(CS)--\
   [Veta 5 Plus]         --LAN(CS)-- >--[ kleiner Gigabit-Switch ]--LAN--[ Windows-PC: VetStation ]
   (weitere Geräte)      ----------/
```

## Was du brauchst (günstig)
- **1 kleiner Gigabit-Switch** (5–8 Ports, ~15–25 €) — ein **eigenes, isoliertes** Geräte-Netz.
- **LAN-Kabel** für jedes Gerät + den PC.
- Der **Windows-10-Pro-PC** (i3/8 GB genügt).

## Netzwerk (feste IPs — verbindliche Werte)
PC **und alle Geräte** müssen im **selben Subnetz `192.168.0.x`** stehen. Die folgenden Werte sind
verbindlich und entsprechen der ausgelieferten Software. Ältere Notizen mit `192.168.23.x` oder
`192.168.2.x` sind **veraltet** — nicht mehr verwenden.

| Gerät | IP | Maske |
|---|---|---|
| **PC (VetStation)** | `192.168.0.99` | `255.255.255.0` (/24), **kein Gateway** |
| **uMEC12 Vet Monitor** | `192.168.0.50` | /24, Adresstyp **Manuell** (nicht DHCP!) |
| **LifeVet / 2. Gerät** | `192.168.0.51` | /24 |
| Ziel im Gerät (*Gateway-Kommunikationseinst.*) | `192.168.0.99` : **3502** | — |

- **PC-IP setzen — nichts tippen:** in **`C:\VetStation`** die Datei **`NETZWERK-EINRICHTEN.bat`**
  doppelklicken (liegt auch im *Startmenü → VetStation*). Sie setzt `192.168.0.99` und holt sich die
  Adminrechte selbst — die UAC-Abfrage mit **Ja** bestätigen.
- Geräte-IP ablesen/ändern am Gerät: *Hauptmenü → Wartung → Benutzer-Wartung (Passwort **888888**)
  → Netzwerk* — „IP automatisch beziehen"/DHCP **AUS**, Adresstyp **Manuell**.

> **Wichtig — alle Geräte in EIN Netz:** Zeigt ein Gerät noch eine Adresse aus einem anderen Subnetz
> (z. B. `192.168.23.x` oder `192.168.2.x`), muss sie umgestellt werden: uMEC12 Vet auf
> **`192.168.0.50`**, LifeVet 10C auf **`192.168.0.51`** (am LifeVet: *Wartung → … → Netzwerk*),
> der PC bleibt **`192.168.0.99`**.
> Der Verbindungs-Assistent erkennt beide Mindray-Typen automatisch (MAC-Präfixe 98:CC:E4 und 00:0F:14).
- **Kein Gateway/Internet nötig** — isoliertes Netz. (Ohne Internet nutzt VetStation die **lokal
  mitgelieferte** Klinik-Datenbasis; das ist voll funktionsfähig. Updates ziehen sich nur, wenn der PC
  zusätzlich Internet hat, z. B. über WLAN.)

## Verbinden & einstellen (der eigentliche Knackpunkt)
**Ehrliche Lage:** Der **LifeVet 10C** (Mindray-Monitor) hat einen **dokumentierten HL7-Menüpunkt** — er ist
der beste Weg. Der **uMEC12 Vet** sendet evtl. nur proprietäres MD2; das zeigt der **Verbindungs-Assistent**.
Vorgehen:

1. Alles verkabeln (ein Switch, ein Subnetz), PC-IP `192.168.0.99` setzen →
   **`NETZWERK-EINRICHTEN.bat` doppelklicken** (UAC mit **Ja** bestätigen).
2. **VetStation starten** — **`START-VetStation.bat` doppelklicken**. Der Verbindungs-Assistent läuft
   automatisch und lauscht **zuerst auf 3502**, zusätzlich auf 4601/5000/24105/2575.
3. **Am LifeVet 10C zuerst**: `Wartung → Benutzer-Wartung (Passwort 888888) → Netzwerk → EMR-Kommunikation`
   → **Server-IP = 192.168.0.99, Protokoll = HL7, „Real Data Send" = EIN, Port = 3502**
   (bietet das Gerät 3502 nicht an, ist **Port 4601** die Alternative — VetStation lauscht auf beiden).
   **Am uMEC12 Vet**: `… → Netzwerk → Gateway-Comm-Setup` → **Ziel-IP = 192.168.0.99, Port = 3502**. Details: [MINDRAY-HL7.md](MINDRAY-HL7.md).
4. **VetStation-Admin → „Verbindung/Fehler"** ansehen:
   - „✓ HL7 ERKANNT auf Port 3502" (bzw. 4601) → läuft, Patient erscheint. **Fertig.**
   - „KEIN HL7 erkannt" → Gerät sendet proprietär → Fallback (VSCapture/eGateway), siehe MINDRAY-HL7.md.
   - Kommt gar nichts an: **`GERAETE-PRUEFEN.bat` doppelklicken** — es zeigt im Klartext, ob Daten eintreffen.

`ping 192.168.0.50` vom PC muss klappen → physisches Netz steht.
(Eingabeaufforderung oder PowerShell öffnen, `ping 192.168.0.50` eintippen — **keine** Adminrechte nötig.)

## Sicherheit (§10)
- **Nur lesen** — VetStation sendet **nie** etwas an die Geräte (kein Verstellen von Verdampfer/Beatmung).
- **Isoliertes Geräte-Netz** (eigener Switch). Patientendaten bleiben **lokal** auf dem PC.

## Mit dem Händler klären
1. Sendet der uMEC **HL7 über LAN (Port 3502, ersatzweise 4601)** oder nur **MD2** an die BeneVision CMS Vet? Menüpfad/Port? **Freigeschaltet/Lizenz?**
2. Gibt es einen **offenen Datenausgang (HL7/eGateway)** für Monitor und/oder Veta — und was kostet die Freischaltung?
