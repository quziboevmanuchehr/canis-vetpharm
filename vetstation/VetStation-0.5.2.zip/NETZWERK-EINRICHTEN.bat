@echo off
title VetStation - Netzwerk einrichten
REM Setzt die feste IP 192.168.0.99 fuer das isolierte Geraete-Netz (Ziel im Monitor).
REM Einfach DOPPELKLICKEN. Adminrechte holt sich das Skript selbst (UAC bestaetigen).
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-static-ip.ps1"
