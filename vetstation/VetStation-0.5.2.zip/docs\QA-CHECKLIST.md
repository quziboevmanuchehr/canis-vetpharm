# Qualitätssicherung (§12)

## Automatischer Klinik-Selbsttest (Praxis-PC: C:\VetStation)
Prüft die wiederverwendete Brain-Logik headless. **Aktueller Stand: 17/17 OK.**

Für diesen Selbsttest gibt es **keine** Doppelklick-Datei. Er muss getippt werden – deshalb
PowerShell öffnen (normal, **keine** Adminrechte nötig) und den Befehl **mit vollständigem Pfad
in Anführungszeichen** eingeben:

```powershell
& "C:\VetStation\node\node.exe" "C:\VetStation\tools\smoke-test.js"
```

- Der Befehl funktioniert aus **jedem** Startverzeichnis (PowerShell startet in `C:\WINDOWS\system32`).
- **Kein `npm`, kein `node` ohne Pfad** – auf dem Praxis-PC gibt es nur `C:\VetStation\node\node.exe`.

Ob die **Geräte** Daten senden, prüft dagegen die vorhandene Doppelklick-Datei
**GERAETE-PRUEFEN.bat** in `C:\VetStation` (auch im Startmenü unter „VetStation") – nichts tippen.

| Test (aus §12) | Erwartung | Status |
|---|---|---|
| Datenbasis lädt | `window.ANAES` in Node, 8 Arten, 43 Medis | ✅ |
| Normal (Hund) | keine kritische Kreuz-Analyse | ✅ |
| MAP 50 bei hohem Iso | „Iso senken" / Hypotonie | ✅ |
| Bradykardie + tief | „Bradykardie bei zu tiefer Narkose → Iso zuerst senken" | ✅ |
| VES + SpO₂↓ | **erst O₂/Beatmung** (nicht antiarrhythmisch zuerst) | ✅ |
| VES isoliert | Lidocain (Hund) nach Sicherung | ✅ |
| Apnoe | Inzident Apnoe (AF/EtCO₂ = 0) → IPPV | ✅ |
| Hypoventilation | Inzident Hypoventilation (EtCO₂ hoch) | ✅ |
| Bronchospasmus (Katze) | Kapno-Haifischflosse → Atemweg (R6 live) | ✅ |
| Kammerflimmern | **CPR + DEFIBRILLIEREN** (sev 5) | ✅ |
| Asystolie (Katze) | CPR (sev 5) | ✅ |
| Hyperthermie / Hypothermie | Inzident Temp hoch/niedrig (mehrere Arten) | ✅ |
| AV-Block III (Reptil 0.4 kg) | Brain läuft artspezifisch, kein Crash | ✅ |
| Injektion mL | Asystolie/Katze: Adrenalin liefert mL; Bradykardie/Hund: Atropin | ✅ |
| Artspezifische Dosis | Atropin Hund ≠ Kaninchen (mg/kg) | ✅ |

## Live-Verifikation (Browser, gegen die laufende Bridge)
Bereits geprüft (Simulator):
- **Auto-Discovery:** 4 Geräte erkannt (2× Monitor, 2× Kapno), Status „active".
- **Matching:** Monitor+Kapno gleicher ID → 1 Patient; zwei Patienten (Hund + Katze) getrennt.
- **Split-View-Priorität:** VFlimmern-Hund (sev 5) steht über Hypotonie-Katze (sev 3).
- **Brain live:** VF → „Kammerflimmern → CPR/DEFIB" + mL (Adrenalin 0.22, Vasopressin 0.88 …);
  Hypotonie → „Verdampfer senken" + **Iso-Soll [OFF]** (3.6 vs 1.5–2.5).
- **Alarme:** Kacheln färben sich rot bei Grenzwertverletzung.
- **Waveforms:** EKG/Pleth/Kapno zeichnen (Canvas 423×234, Herzschlag läuft).
- **Live-Datenpull:** UI zeigt „📚 Live-Daten" (Pull vom canis-vetpharm erfolgreich).
- **Admin (PIN 1234):** 4 Reiter, Geräte-/Fehlerliste, Feedback, Export.

## Manuell zu prüfen (mit echten Geräten / vor Praxiseinsatz)
- [ ] Jedes der 3 Geräte im Standby wird erkannt, richtig benannt, Werte = Gerätewerte
      (erst nach Einbau der Protokoll-Parser, siehe DEVICE-ADAPTERS.md).
      Voraussetzung – verbindliche Adressen: PC (VetStation) **192.168.0.99**,
      uMEC12 Vet Monitor **192.168.0.50** (Adresstyp MANUELL, nicht DHCP),
      LifeVet / 2. Gerät **192.168.0.51**, jeweils Maske 255.255.255.0 **ohne** Gateway;
      Ziel im Monitor (Gateway-Kommunikationseinstellung) **192.168.0.99 : 3502**.
      Die feste IP am PC setzt die Doppelklick-Datei **NETZWERK-EINRICHTEN.bat** in `C:\VetStation`
      (auch im Startmenü unter „VetStation") – sie holt sich die Adminrechte selbst, UAC bestätigen.
      Geräte-Menüweg: Hauptmenü → Wartung → Benutzer-Wartung (Passwort 888888) → Netzwerk.
- [ ] Matching-Test mit echten Patienten-IDs (gleich → zusammengeführt; unterschiedlich → getrennt).
- [ ] Performance auf i3/8 GB: 3 Streams + 2 Fenster flüssig, RAM stabil (mehrere Stunden).
- [ ] Kiosk: bootet direkt in die App, kein Desktop, Watchdog startet nach Absturz neu.
- [ ] Win10 **und** Win11: identisches Verhalten (Kiosk, WebView2, DPI-Skalierung, Touch).
- [ ] DPI/Touchscreen: Layout responsiv, große Zahlen lesbar, Maus **und** Touch bedienbar.

---

## Nur Entwickler-PC (D:\VetStation)
Die folgenden Befehle gelten **ausschließlich** auf dem Entwickler-PC, wo das Projekt unter
`D:\VetStation` liegt und `npm`/`node` im PATH stehen. **Nicht** auf dem Praxis-PC eintippen –
dort gibt es kein npm; dafür gilt der Abschnitt „Automatischer Klinik-Selbsttest" oben.

```powershell
cd D:\VetStation
node tools/smoke-test.js     # Klinik-Selbsttest, 17 Prüfungen (identisch zu: npm run smoke)
npm test                     # alle Testskripte nacheinander
```

### Hinweis zu Screenshots im Test (Entwickler-PC)
Die UI läuft dauerhaft mit `requestAnimationFrame` (Monitor-Kurven). Automatische Screenshots können
dabei hängen; **DOM/JS-Inspektion** (read_page / console) ist verlässlicher. In einem **sichtbaren**
Vollbildfenster laufen die Kurven normal (rAF wird nur bei versteckten Tabs pausiert).
