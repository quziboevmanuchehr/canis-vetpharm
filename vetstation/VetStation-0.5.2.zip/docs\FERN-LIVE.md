# Fern-Live — Werte & Monitor über das Internet ansehen

Der Praxis-PC (VetStation) liest die Geräte, berechnet die Empfehlungen **und** schreibt
die Live-Werte ~1×/Sekunde in ein Cloud-Relay (Firebase). Die öffentliche Web-App
`quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/` liest sie und zeigt
denselben Monitor + dieselben Empfehlungen **fern** an — z. B. von zu Hause.

- **Read-only:** Fern-Zuschauer können die Geräte niemals steuern.
- **Datensparsam:** Es werden nur Vitalwerte, Tierart, Gewicht, Iso % und der Befundtext
  übertragen — **keine Klarnamen/Personendaten**.
- **Zugriff nur mit Code:** Der Code ist Teil des Links. Wer den Link nicht hat, sieht nichts.

```
Praxis-PC (VetStation-Bridge)            Firebase Realtime DB            Web-App (GitHub Pages)
  liest Geräte  ─►  Brain/Empfehlung ─►  /live/<code>  ◄─ abonniert ─►  Fern-Ansicht (?live=<code>)
                    schreibt ~1×/s                                       Monitor + Empfehlungen live
```

---

## Einmalige Einrichtung (~10 Minuten)

### 1) Realtime Database aktivieren
[console.firebase.google.com](https://console.firebase.google.com) → Projekt **vet-station**
→ **Build → Realtime Database → Datenbank erstellen** → Region **europe-west1** (Frankfurt)
→ **im gesperrten Modus** starten.
Notiere die **Datenbank-URL** oben, z. B.
`https://vet-station-default-rtdb.europe-west1.firebasedatabase.app`.

### 2) (entfällt) — keine Anmeldung nötig
Der Praxis-PC schreibt **ohne Anmeldung** (Zugriff wird über den unratbaren Code + die Regeln
geschützt). Du musst in Authentication **nichts** einrichten.

### 3) Sicherheitsregeln setzen
**Realtime Database → Regeln** → den kompletten Inhalt der Regel-Datei einfügen → **Veröffentlichen**.

Die Regel-Datei liegt auf dem Praxis-PC unter
**`C:\VetStation\installer\firebase-rtdb-rules.json`**
(auf dem Entwickler-PC: [`installer/firebase-rtdb-rules.json`](../installer/firebase-rtdb-rules.json)).

> **So öffnet man eine `.json`-Datei:** **Rechtsklick auf die Datei → „Öffnen mit" → „Editor"**
> (Notepad). Ein einfacher Doppelklick startet unter Windows kein sinnvolles Programm.
> Im Editor **Strg+A** (alles markieren) und **Strg+C** (kopieren) → im Firebase-Regelfenster
> **Strg+A**, dann **Strg+V** (einfügen). Nichts an der Datei selbst ändern.

(Lesen: jeder mit dem Code. Schreiben: nur der angemeldete Praxis-PC, und nur unter dem eigenen Code.)

### 4) Web-API-Key holen
**Projekteinstellungen (Zahnrad) → Allgemein → Deine Apps → Web-App → SDK-Konfiguration.**
Kopiere `apiKey` und `databaseURL`.
(Falls noch keine Web-App existiert: **App hinzufügen → Web**, Namen z. B. „canis-anaesthesie", registrieren.)

### 5) Praxis-PC konfigurieren (VetStation)
Zu bearbeiten ist die Datei **`C:\VetStation\bridge\config\devices.json`**.

1. **Ordner öffnen:** Explorer starten (**Windows-Taste + E**) und in die Adresszeile oben
   `C:\VetStation\bridge\config` eintippen + Enter — oder klicken:
   *Dieser PC → C: → VetStation → bridge → config*.
2. Liegt dort **keine** `devices.json`, sondern nur `devices.example.json`:
   Rechtsklick auf **`devices.example.json` → Kopieren**, dann Rechtsklick auf die freie Fläche
   → **Einfügen**, und die Kopie per Rechtsklick → **Umbenennen** in **`devices.json`**
   umbenennen (der Name muss genau `devices.json` lauten).
3. **`devices.json` öffnen: Rechtsklick → „Öffnen mit" → „Editor"** (Notepad).
   Doppelklick genügt nicht — für `.json` startet Windows kein sinnvolles Programm.
4. Den `cloud`-Block ausfüllen:

```json
"cloud": {
  "enabled": true,
  "provider": "firebase",
  "apiKey": "<dein Web-API-Key>",
  "dbUrl": "https://vet-station-default-rtdb.europe-west1.firebasedatabase.app",
  "code": "praxis-op1-Xy7k3",
  "station": "Praxis OP 1",
  "minIntervalMs": 1000
}
```
- Danach im Editor speichern: **Strg+S**, Fenster schließen.
- **`code`** unratbar wählen (Buchstaben/Ziffern/Bindestrich). Er ist der Zugangs-Link.
- VetStation **neu starten**: laufendes Fenster schließen, dann
  **`C:\VetStation\START-VetStation.bat`** doppelklicken.
  Im Log erscheint: `cloud: Fern-Live AKTIV → https://…?live=<code>`.
- Der fertige Link steht auch im **Admin → 📡 Fern-Live → „Kopieren"**.

### 6) Web-App einmalig konfigurieren — **nur Entwickler-PC** (Repo `canis-vetpharm`)
> Auf dem Praxis-PC ist hier **nichts** zu tun.

Im Repo `canis-vetpharm` in der Datei `canis-anaesthesie\index.html` das Objekt
**`window.VETLIVE_CFG`** mit `apiKey` und `databaseURL` füllen (identisch zu Schritt 4/5).
`authDomain`/`projectId` sind bereits gesetzt.
Danach die Web-App wie üblich zu GitHub Pages deployen.

> Hinweis: `apiKey` und `databaseURL` sind **öffentliche** Firebase-Web-Werte (kein Geheimnis) —
> sie stehen bei jeder Firebase-Web-App im Browser. Die Sicherheit kommt aus den Regeln + dem Code.

### 7) Fern schauen
Zuhause im Browser öffnen:
```
https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/?live=<code>
```
Oben erscheint die Leiste **📡 FERN-ANSICHT** mit Verbindungsstatus und — bei mehreren
Patienten — einem Umschalter. Der Monitor (EKG/Kapno/Werte) und die Empfehlungen laufen live.

---

## Testen ohne Geräte / ohne Firebase (Praxis-PC)
- **Web-Viewer offline** (synthetische Werte, kein Firebase) — nur im Browser öffnen:
  `https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/?livedemo=1`
- **Prüfen, ob überhaupt Gerätedaten am PC ankommen:** **`GERAETE-PRUEFEN.bat`** in
  `C:\VetStation` (oder *Startmenü → VetStation*) doppelklicken.
- Die beiden Cloud-Selbsttests sind Entwickler-Werkzeuge → Abschnitt
  **„Nur Entwickler-PC (D:\VetStation)"** ganz unten.

## Sicherheit & Abschalten
- Teile den Link nur mit befugten Personen. Wer den Code hat, kann mitlesen (nicht steuern).
- **Abschalten:** in **`C:\VetStation\bridge\config\devices.json`**
  (Rechtsklick → „Öffnen mit" → „Editor") `cloud.enabled = false` setzen, speichern (Strg+S),
  dann VetStation neu starten (**`C:\VetStation\START-VetStation.bat`** doppelklicken).
  Oder den `code` ändern → alle alten Links sind sofort tot.
- Der Refresh-Token des Praxis-PCs liegt lokal in **`C:\VetStation\data\cloud-auth.json`**
  (ist git-ignoriert).

## Fehlersuche
| Symptom (Web-App-Leiste) | Ursache / Lösung |
|---|---|
| „Firebase nicht konfiguriert" | `window.VETLIVE_CFG` in `canis-anaesthesie\index.html` noch mit Platzhalter → Schritt 6 (Entwickler-PC). |
| „Verbindungsfehler" | `databaseURL` falsch/Region stimmt nicht, oder Regeln nicht veröffentlicht. |
| „keine neuen Daten (Xs)" | Praxis-PC sendet nicht: VetStation läuft nicht (→ `C:\VetStation\START-VetStation.bat` doppelklicken) oder `cloud.enabled` steht in `C:\VetStation\bridge\config\devices.json` auf `false`. Log prüfen. |
| Log: `Schreibfehler … 401/403` | Anonyme Anmeldung nicht aktiviert (Schritt 2) oder Regeln (Schritt 3). |
| Fern-Leiste bleibt leer | Es sind (noch) keine Geräte/Patienten am Praxis-PC aktiv. |

---

## Nur Entwickler-PC (D:\VetStation)
Diese Befehle gehören **nicht** auf den Praxis-PC — dort gibt es kein `npm` und kein `node`
im PATH. PowerShell startet außerdem in `C:\Windows\System32`, deshalb hier immer
**vollständige Pfade**:

```powershell
node D:\VetStation\tools\cloud-test.js              # Publisher-Selbsttest (Mock-Firebase, 26 Prüfungen)
node D:\VetStation\tools\cloud-integration-test.js  # Ende-zu-Ende: echte Bridge + Simulator
```

Muss ein Selbsttest ausnahmsweise doch auf dem **Praxis-PC** laufen (z. B. auf Bitten des
Supports), dann in PowerShell mit dem mitgelieferten portablen Node und vollständigen Pfaden:

```powershell
& "C:\VetStation\node\node.exe" "C:\VetStation\tools\cloud-test.js"
```
