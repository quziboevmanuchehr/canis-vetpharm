'use strict';
/*
 * cloud-integration-test.js — Ende-zu-Ende: ECHTE Bridge (Simulator) -> Cloud-Publisher -> Mock-Firebase.
 * Beweist, dass server.js die zusammengefuehrten Patienten (registry.getPatients) tatsaechlich
 * ~1x/s an die Cloud sendet, inkl. Brain-Enrichment. Legt temporaer eine devices.json an
 * (Simulator + cloud.enabled) und raeumt sie am Ende wieder weg.  Start: node tools/cloud-integration-test.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CFG = path.join(__dirname, '..', 'bridge', 'config', 'devices.json');
const AUTH_FILE = path.join(require('os').tmpdir(), 'vetstation-integ-auth-' + process.pid + '.json');
let pass = 0, fail = 0, child = null, hadCfgBefore = fs.existsSync(CFG);
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? ' -> ' + e : '')); } }

const captured = { puts: [], signups: 0, refreshes: 0 };
const mock = http.createServer((req, res) => {
  let body = ''; req.on('data', c => body += c); req.on('end', () => {
    if (req.url.startsWith('/identity')) { captured.signups++; return j(res, { idToken: 'ID', refreshToken: 'RT', localId: 'u1', expiresIn: '3600' }); }
    if (req.url.startsWith('/token')) { captured.refreshes++; return j(res, { id_token: 'ID', refresh_token: 'RT', user_id: 'u1', expires_in: '3600' }); }
    if (req.method === 'PUT' && req.url.indexOf('/live/') >= 0) { let p = null; try { p = JSON.parse(body); } catch (_) {} captured.puts.push(p); return j(res, p); }
    res.writeHead(404); res.end();
  });
});
function j(res, o) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); }

function cleanup() {
  try { if (child) child.kill(); } catch (_) {}
  try { if (!hadCfgBefore) fs.unlinkSync(CFG); } catch (_) {}
  try { fs.unlinkSync(AUTH_FILE); } catch (_) {}
  try { mock.close(); } catch (_) {}
}

async function run() {
  if (hadCfgBefore) { console.log('devices.json existiert bereits — Test uebersprungen (nicht ueberschreiben).'); process.exit(0); }
  await new Promise(r => mock.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + mock.address().port;
  console.log('Integrationstest: Bridge -> Cloud -> Mock (' + base + ')');

  fs.writeFileSync(CFG, JSON.stringify({
    port: 8779, host: '127.0.0.1',
    cloud: { enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base, code: 'integ-test',
      station: 'Integ-OP', minIntervalMs: 600, identityUrl: base + '/identity', tokenUrl: base + '/token',
      authFile: AUTH_FILE },
    adapters: [{ type: 'simulator', id: 'sim', enabled: true, rateMs: 500 }],
  }, null, 2));

  child = spawn(process.execPath, [path.join(__dirname, '..', 'bridge', 'src', 'index.js')], { stdio: 'ignore' });

  // bis zu 6s auf >=2 PUTs warten
  const t0 = Date.now();
  while (captured.puts.length < 2 && Date.now() - t0 < 6000) await wait(150);

  ok('No-Auth-Standard: keine Firebase-Anmeldung noetig', captured.signups + captured.refreshes === 0, 'signups=' + captured.signups + ' refreshes=' + captured.refreshes);
  ok('mindestens 2 Snapshots gesendet', captured.puts.length >= 2, 'puts=' + captured.puts.length);

  const snap = captured.puts[captured.puts.length - 1] || {};
  ok('Snapshot hat meta+patients', !!snap.meta && !!snap.patients);
  ok('meta.station = Integ-OP', snap.meta && snap.meta.station === 'Integ-OP');
  const keys = snap.patients ? Object.keys(snap.patients) : [];
  ok('mehrere zusammengefuehrte Patienten (Simulator-Standard = 4)', keys.length === 4, 'keys=' + keys.length);
  const specs = keys.map(k => snap.patients[k].species);
  ok('Art-Vielfalt end-to-end (Kaninchen + Reptil in der Cloud)', specs.indexOf('kaninchen') >= 0 && specs.indexOf('reptil') >= 0, specs.join(','));

  const anyVitals = keys.some(k => snap.patients[k].vitals && snap.patients[k].vitals.hr != null);
  ok('echte Vitalwerte enthalten (hr)', anyVitals);
  const anyEnriched = keys.some(k => typeof snap.patients[k].pri === 'number');
  ok('Brain-Enrichment vorhanden (pri)', anyEnriched);
  const anySpecies = keys.every(k => !!snap.patients[k].species);
  ok('jede Spezies gesetzt', anySpecies);

  cleanup();
  console.log('\nErgebnis: ' + pass + ' OK, ' + fail + ' Fehler.');
  process.exit(fail ? 1 : 0);
}
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }
process.on('uncaughtException', e => { console.error('FEHLER', e); cleanup(); process.exit(1); });
run().catch(e => { console.error('TESTFEHLER', e); cleanup(); process.exit(1); });
