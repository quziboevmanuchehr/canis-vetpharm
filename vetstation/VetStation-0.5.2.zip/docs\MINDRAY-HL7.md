# Mindray/Eickemeyer-Geräte anbinden — ehrlicher Stand & Vorgehen

Ergebnis einer gründlichen Recherche in den **Original-Handbüchern** (uMEC Operator's/Service Manual,
Veta 5 Operator's Manual, LifeVet 10C Manual) und Mindray-Produktdoku. Kurz und ehrlich vorweg:

> **Keines der Geräte hat einen öffentlich dokumentierten, offenen (HL7-)Datenausgang am Gerät.**
> Mindray-Geräte reden ihr **proprietäres „MD2"-Protokoll** mit der **BeneVision CMS Vet**
> (kostenpflichtige PC-Zentrale) bzw. einem **eGateway** — und erst der eGateway erzeugt HL7.

Das relativiert das „einfach Kabel dran und lesen" des Händlers: das **Kabel ist nötig, reicht aber
nicht** — es kommt darauf an, **was** das Gerät über das Kabel sendet (offenes HL7 vs. proprietäres MD2).

## ⭐ Bester Weg: der LifeVet 10C (hat einen DOKUMENTIERTEN HL7-Menüpunkt)
Der **LifeVet 10C** ist ein modularer **Mindray-Monitor** (BeneView-/ePM-/BeneVision-Klasse, System-SW
09.02). Diese Klasse hat HL7 **eingebaut** (kein eGateway für Numerik nötig). Dokumentierter Menüpfad:

`Hauptmenü → Wartung → Benutzer-Wartung` — **Passwort `888888`** → `Netzwerk` → **`EMR-Kommunikation`**
→ **Server-IP = PC-IP** (`192.168.0.99`), **Protokoll = HL7**, **„Real Data Send" = EIN**, **Port = 4601**.
(Die IP des LifeVet selbst ist `192.168.0.51`.)

VetStation braucht **nur die Zahlen** (Kurven zeichnet es selbst) — perfekt, denn Numerik ist bei dieser
Monitor-Klasse der zuverlässige Teil. **→ Zuerst den LifeVet so verbinden; das ist der beste Kandidat.**

**BeneLink-Bonus:** Der LifeVet kann über sein **BeneLink**-Modul externe Narkose-/Beatmungsgeräte
(Dräger, Hamilton, GE …) **einbinden** — deren Daten erscheinen am Monitor und gehen dann per HL7 **mit
raus**. So könnte ein Narkosegerät (über BeneLink + ID-Adapter + passendes Plugin) EtCO₂/Beatmung
beisteuern. (Ob es ein Plugin für den Veta gibt, mit Eickemeyer klären.)

## Zweiter Weg: der uMEC12 Vet — testen mit dem Assistenten
Beim **uMEC12 Vet** zeigt das öffentliche Handbuch **keinen** HL7-Menüpunkt (proprietäres MD2). Er *könnte*
per HL7 senden (VSCapture-Beleg) — das zeigt der **Verbindungs-Assistent** am echten Gerät
(lauscht auf 3502/4601/5000/24105/2575, erkennt HL7 automatisch, protokolliert Unbekanntes, ARP-Scan).

### Schritt-für-Schritt-Test (am echten Gerät)
1. **LAN** verkabeln (ein Switch, PC + Geräte — siehe [LAN-SETUP.md](LAN-SETUP.md)). Dann in `C:\VetStation`
   **`NETZWERK-EINRICHTEN.bat`** **doppelklicken** (liegt auch im *Startmenü → VetStation*, holt sich die
   Adminrechte selbst — UAC mit **Ja** bestätigen). Sie setzt den PC auf **`192.168.0.99`** / 255.255.255.0,
   **kein Gateway**. Geräte: uMEC12 Vet = `192.168.0.50`, LifeVet = `192.168.0.51`.
2. **VetStation starten**: in `C:\VetStation` **`START-VetStation.bat`** **doppelklicken**
   (der Verbindungs-Assistent läuft standardmäßig mit).
3. **Am uMEC12 Vet** (Touch): `Hauptmenü → Wartung/Maintenance → Benutzer-Wartung` — **Passwort `888888`**
   (Werks-/Factory-Wartung: `332888`, Demo: `2088`) → `Netzwerk` / `Netzwerk-Setup` →
   - **`Gateway-Kommunikationseinst.` (Gateway-Comm-Setup)**: `IP-Adresse` = **PC-IP** (`192.168.0.99`),
     `Port` = **`3502`** (Standardziel des uMEC12 — VetStation lauscht dort zuerst; `4601` wird ebenfalls
     mitgelauscht), ggf. `ADT Query` EIN.
   - Beim Gerät selbst muss der **Adresstyp „Manuell"** stehen (nicht DHCP).
   - (Alternativ/zusätzlich, falls vorhanden, ein „HL7"- oder „Export"-Untermenü im Werks-Modus `332888`.)
4. **Prüfen, ob Daten ankommen** — am einfachsten in `C:\VetStation` **`GERAETE-PRUEFEN.bat`**
   **doppelklicken** (liegt auch im *Startmenü → VetStation*). Dasselbe steht im
   **VetStation-Admin → „Verbindung/Fehler"** im Log:
   - **„✓ HL7 ERKANNT auf Port 3502"** (oder `4601`) → **es funktioniert**, die Werte laufen automatisch in
     VetStation. Fertig.
   - **„KEIN HL7 erkannt (evtl. proprietärer CentralStation-Link)"** → das Gerät sendet **MD2 (proprietär)**.
     Dann VetStation nicht direkt nutzbar → siehe **Fallbacks**.
     (Die Rohdaten liegen in `C:\VetStation\bridge\data\probe-3502.log` — Dateiname = der jeweilige Port.)

## Fallbacks, falls kein direktes HL7
### 1. VSCapture als Empfänger (kostenlos, bewährt) — schlüsselfertig
VSCapture „spricht" das Mindray-HL7 und schreibt eine CSV; VetStation liest sie live.
- **Einmalig einrichten** (einmal getippt, danach nur noch Doppelklick): PowerShell per **Rechtsklick →
  „Als Administrator ausführen"** öffnen — das Skript lädt aus dem Internet herunter und legt Ordner an —
  und dort diese Zeile mit **vollständigem Pfad in Anführungszeichen** eingeben:
  ```
  powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\setup-vscapture-fallback.ps1"
  ```
  Es lädt `VSCaptureCLIv1.008Binary.zip` und entpackt nach `C:\VetStation\vscapture`; dort legt es
  auch **`start-vscapture.bat`** an.

  > ⚠️ **Das Skript installiert .NET 8 NICHT — es prüft nur.** Fehlt die **.NET 8 Runtime**, gibt es
  > nur eine Warnung. Dann einmalig von https://dotnet.microsoft.com/download/dotnet/8.0
  > (*.NET Runtime 8.0*) installieren und das Skript **erneut** ausführen. Ohne .NET 8 scheitert der
  > nächste Schritt mit „dotnet … wird nicht als Name eines Cmdlets erkannt".

  (Manuell: Download von https://github.com/xeonfusion/VSCaptureCLI ; .NET 8 von https://dotnet.microsoft.com/download.)
- **Starten**: **`C:\VetStation\vscapture\start-vscapture.bat` doppelklicken** — mehr ist nicht nötig
  (**setzt installiertes .NET 8 voraus**; die `.bat` ruft ebenfalls `dotnet` auf).
  Nur falls doch getippt werden muss (PowerShell, vollständige Pfade, erst in den Ordner wechseln):
  ```
  cd "C:\VetStation\vscapture"
  dotnet VSCaptureMRay.dll -mode 2 -serverport 4601 -interval 1 -export 1
  ```
  Meldet PowerShell „`dotnet` wird nicht als Name eines Cmdlets erkannt", fehlt .NET 8 (siehe oben)
  oder es steht nicht im PATH — dann mit vollem Pfad: `& "C:\Program Files\dotnet\dotnet.exe" VSCaptureMRay.dll …`
  (interaktiv, ebenfalls nach dem `cd`: `dotnet VSCaptureMRay.dll` → `2` = TCP Listener → Port `4601`
  → Intervall `1` = 5 s.)
  Es schreibt **`MRayDataExport.csv`** in dieses Verzeichnis (Spalte 1 `Time`, dann dynamische Parameter-Spalten).
  **Wichtig:** VSCapture lauscht auf **4601** — das Gerät muss dann auf Port `4601` senden (statt `3502`).
- **VetStation** liest die CSV. Dazu im Ordner `C:\VetStation\bridge\config\`:
  1. Liegt dort noch **keine** `devices.json`? Dann `devices.example.json` **kopieren** und die Kopie
     in **`devices.json`** umbenennen. *(Ausgeliefert wird nur die `example`-Datei. Und nur
     `devices.json` überlebt Updates — beim Einspielen wird ausdrücklich nur sie geschützt.)*
  2. `devices.json` mit **Editor/Notepad** öffnen (Rechtsklick → Öffnen mit → Editor).
  3. Beim Adapter `vscapture` setzen: `"enabled": true` und
     `"file": "C:/VetStation/vscapture/MRayDataExport.csv"`.

  Der Adapter ordnet die Spalten über die Kopfzeile zu.
2. **Mindray eGateway** (kostenpflichtig): der dokumentierte Weg zu **echtem HL7** aus dem Mindray-Netz →
   VetStations `hl7`-Adapter liest es. Preise/Freischaltung über Eickemeyer/Mindray.
3. **BeneVision CMS Vet** (kostenpflichtige PC-Zentrale): sammelt die Daten; HL7-Export nur mit eGateway.

## Veta 5 Plus — der CS-Port liefert KEINE Daten (nur Firmware-Update)
Definitiv (Veta-5-Handbuch, Primärquelle): Der **CS-Port des Veta ist laut Hersteller ausschließlich
„Verbindung zum PC für Software-Update"** — **kein** Datenstrom, kein HL7, kein MD2. Der Veta↔Monitor-Link
fließt **hinein**: der Veta **liest EtCO₂ vom Monitor** (für die VS+-Beatmung), er sendet nichts nach außen.
Ein „Anesthesia-Plugin" für BeneLink ist nur für die **humane A-Serie** dokumentiert, nicht für den Veta.

→ **Konsequenz für die Verkabelung:** Das gelbe Kabel im Veta-CS-Port bringt VetStation **nichts**. Die
**Datenquelle ist der Monitor** (uMEC12 Vet **oder** LifeVet 10C). Dessen **Kapno-Modul liefert EtCO₂/FiCO₂/AF**
(OBX 220/221/222) — also ist alles im HL7-Strom des Monitors enthalten. **Es genügt, EINEN Monitor per HL7
anzubinden.** (Für Beatmungs-Detaildaten des Veta gäbe es nur den kostenpflichtigen Mindray-Weg Monitor→CMS.)

## Welche Werte VetStation aus HL7 liest (OBX-Codes, Mindray-PDS-Spezifikation)
`101=HF, 160=SpO₂, 170/171/172=NIBP Sys/Dia/Mean, 220=EtCO₂, 221=FiCO₂, 222=AWRR→AF, 200=T1/213=TB=Temp,
51=Gewicht, 102=PVCs`. Unbekannte Codes landen **automatisch im Diagnose-Log** — in der Praxis ist dafür
nichts zu tun; sie können später in der Software ergänzt werden (siehe Abschnitt „Nur Entwickler-PC").

## Nur Entwickler-PC (D:\VetStation)
*Diese Befehle sind **nicht** für den Praxis-PC gedacht — sie laufen nur auf dem Entwickler-PC mit
Node/npm im Projektordner `D:\VetStation`.*
- Code-Zuordnung der OBX-Codes: `bridge/src/adapters/hl7.js` → `CODE_MAP` (dort neue Codes ergänzen).
- Parser-Tests: `node tools/hl7-test.js` (15/15), `node tools/hl7-live-test.js` (7/7).

## Zwei klare Fragen an Eickemeyer/Mindray
1. **„Sendet der uMEC12 Vet Live-Daten per HL7 über LAN (Port 3502 bzw. 4601), oder nur das proprietäre MD2 an die
   BeneVision CMS Vet? Falls HL7: welcher Menüpfad/Port, und ist es freigeschaltet (Lizenz)?"**
2. **„Gibt es für uns einen offenen Datenausgang (HL7/eGateway) für Monitor UND/ODER Veta — und was kostet die
   Freischaltung?"**

## Quellen (Primär)
- uMEC Operator's/Service Manual (kein HL7-Menü; MD2; Passwörter 888888/332888; Gateway-Comm-Setup).
- Mindray Patient Data Share Programmer's Guide (HL7 v2.3.1, MLLP, ORU^R01, OBX-Codes).
- VSCapture v1.008 (Port 4601, PC=Listener; uMEC numerik-orientiert) — sourceforge.net/projects/vscapture.
- Veta 5 / LifeVet 10C Operator's Manuals (CS=proprietär, kein offener Export).
- Mindray BeneVision CMS Vet / eGateway (proprietäres MD2 bzw. HL7 nur am Gateway).
