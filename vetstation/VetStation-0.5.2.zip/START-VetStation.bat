@echo off
title VetStation
REM VetStation starten (ECHTE Geraete). Fuer Dauerbetrieb: Install-VetStation.ps1 ausfuehren.
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
REM Nur im FEHLERFALL anhalten. Sonst schliesst sich das Fenster in derselben Sekunde und der
REM Tierarzt sieht Meldungen wie "Node.js nicht gefunden" oder "Bridge nicht erreichbar" nie.
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo     Netzwerk/Geraete pruefen: GERAETE-PRUEFEN.bat doppelklicken.
  echo.
  pause
)
