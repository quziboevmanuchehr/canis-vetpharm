'use strict';
/*
 * cloud-test.js — Selbsttest des FERN-LIVE Publishers (bridge/src/cloud.js) OHNE Internet.
 * Ein lokaler HTTP-Server spielt Firebase (signUp + securetoken-refresh + RTDB-PUT) nach.
 * Geprueft: Anmelde-Fluss, Snapshot-Schema, Brain-Enrichment (pri/top), Throttle,
 * Token-Refresh, Persistenz der Token-Datei.  Start: node tools/cloud-test.js
 */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { CloudPublisher, sanitizeKey } = require('../bridge/src/cloud');

let pass = 0, fail = 0;
function ok(name, cond, extra) { if (cond) { pass++; console.log('  ✓ ' + name); } else { fail++; console.log('  ✗ ' + name + (extra ? '  -> ' + extra : '')); } }
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

// ---- Mock-"Firebase" ----
const captured = { signups: 0, refreshes: 0, puts: [] };
const srv = http.createServer((req, res) => {
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    if (req.url.startsWith('/identity')) {
      captured.signups++;
      return json(res, { idToken: 'IDTOKEN_1', refreshToken: 'REFRESH_1', localId: 'anonuid123', expiresIn: '3600' });
    }
    if (req.url.startsWith('/token')) {
      captured.refreshes++;
      return json(res, { id_token: 'IDTOKEN_REFRESHED', refresh_token: 'REFRESH_1', user_id: 'anonuid123', expires_in: '3600' });
    }
    if (req.method === 'PUT' && req.url.indexOf('/live/') >= 0) {
      let parsed = null; try { parsed = JSON.parse(body); } catch (_) {}
      captured.puts.push({ url: req.url, body: parsed });
      return json(res, parsed);
    }
    res.writeHead(404); res.end('nope');
  });
});
function json(res, o) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); }

function samplePatients() {
  return [
    { patientKey: 'sw:hund:22', patientId: 'Bello', species: 'hund', weightKg: 22, isoPct: 2.4,
      devices: [{ deviceId: 'd1', model: 'LifeVet 10C', role: 'combo' }],
      vitals: { hr: 38, spo2: 88, etco2: 62, af: 8, sys: 84, dia: 46, map: 59, temp: 37.1, ekgRhythm: 'sinusbrady', capnoShape: 'high', pleth: 'weak' }, ts: Date.now() },
    { patientKey: 'sw:katze:4.2', patientId: 'Minka', species: 'katze', weightKg: 4.2, isoPct: 1.5,
      devices: [{ deviceId: 'd2', model: 'uMEC12 Vet', role: 'monitor' }],
      vitals: { hr: 150, spo2: 98, etco2: 40, af: 18, sys: 120, dia: 80, map: 93, temp: 38.4, ekgRhythm: 'sinus' }, ts: Date.now() },
  ];
}

async function run() {
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + srv.address().port;
  const authFile = path.join(os.tmpdir(), 'vetstation-cloudtest-' + Date.now() + '.json');

  console.log('FERN-LIVE Publisher-Selbsttest (Mock-Firebase auf ' + base + ')');

  const pub = new CloudPublisher({
    enabled: true, provider: 'firebase',
    apiKey: 'TEST_KEY', dbUrl: base, code: 'praxis test/1', station: 'Test-OP',
    minIntervalMs: 800, authFile: authFile, useAuth: true,
    identityUrl: base + '/identity', tokenUrl: base + '/token',
  }, { log: { info() {}, warn() {}, error() {} } });

  // --- 1) Start + Share-Link ---
  pub.start();
  ok('startet (started=true)', pub.started === true);
  ok('Code wird sanitisiert (kein Slash/Space)', pub.code === 'praxis_test_1', pub.code);
  ok('Share-URL enthaelt ?live=<code>', pub.shareUrl().indexOf('?live=praxis_test_1') >= 0, pub.shareUrl());

  // --- 2) Erste Veroeffentlichung -> signUp + PUT ---
  pub.publish(samplePatients());
  await waitForPut(1);
  ok('anonyme Anmeldung genau 1x', captured.signups === 1, 'signups=' + captured.signups);
  ok('genau 1 PUT geschrieben', captured.puts.length === 1, 'puts=' + captured.puts.length);

  const put = captured.puts[0];
  ok('PUT-Pfad = /live/<code>.json?auth=IDTOKEN_1', /\/live\/praxis_test_1\.json\?auth=IDTOKEN_1/.test(put.url), put.url);
  const snap = put.body || {};
  ok('Snapshot hat meta + patients', !!snap.meta && !!snap.patients);
  ok('meta.count = 2', snap.meta && snap.meta.count === 2, snap.meta && snap.meta.count);
  ok('meta.station korrekt', snap.meta && snap.meta.station === 'Test-OP');

  const keyHund = sanitizeKey('sw:hund:22');
  const ph = snap.patients[keyHund];
  ok('Patient (Hund) vorhanden unter sanitisiertem Key', !!ph, keyHund);
  ok('Vitalwerte uebertragen (hr=38, etco2=62)', ph && ph.vitals.hr === 38 && ph.vitals.etco2 === 62);
  ok('MAP uebertragen (59)', ph && ph.vitals.map === 59);
  ok('EKG-Rhythmus uebertragen (sinusbrady)', ph && ph.vitals.ekgRhythm === 'sinusbrady');
  ok('isoPct uebertragen (2.4)', ph && ph.isoPct === 2.4);

  // --- 3) Brain-Enrichment ---
  ok('Brain-Prioritaet vorhanden (pri > 0)', ph && typeof ph.pri === 'number' && ph.pri > 0, ph && ph.pri);
  ok('Top-Befund vorhanden', ph && ph.top && typeof ph.top.title === 'string' && ph.top.title.length > 0, ph && ph.top && ph.top.title);
  ok('Top-Befund hat Schweregrad (sev)', ph && ph.top && ph.top.sev >= 1, ph && ph.top && ph.top.sev);

  // --- 4) Throttle: sofortiger zweiter publish darf NICHT schreiben ---
  const before = captured.puts.length;
  pub.publish(samplePatients());
  await wait(150);
  ok('Throttle: kein zweiter PUT innerhalb minInterval', captured.puts.length === before, 'puts=' + captured.puts.length);

  // --- 5) Nach Ablauf des Intervalls: neuer PUT, aber KEINE neue Anmeldung (Token gecacht) ---
  await wait(800);
  pub.publish(samplePatients());
  await waitForPut(before + 1);
  ok('nach Intervall: weiterer PUT', captured.puts.length === before + 1, 'puts=' + captured.puts.length);
  ok('keine erneute Anmeldung (Token gueltig)', captured.signups === 1, 'signups=' + captured.signups);

  // --- 6) Token-Refresh: Ablauf simulieren -> securetoken statt signUp ---
  pub.tokenExp = 0; // erzwingt Erneuerung
  await wait(800);
  pub.publish(samplePatients());
  await waitForPut(before + 2);
  ok('abgelaufener Token -> Refresh (securetoken)', captured.refreshes === 1, 'refreshes=' + captured.refreshes);
  ok('immer noch nur 1 signUp', captured.signups === 1, 'signups=' + captured.signups);
  const lastPut = captured.puts[captured.puts.length - 1];
  ok('PUT nutzt erneuerten Token', /auth=IDTOKEN_REFRESHED/.test(lastPut.url), lastPut.url);

  // --- 7) Persistenz der Token-Datei ---
  let saved = null; try { saved = JSON.parse(fs.readFileSync(authFile, 'utf8')); } catch (_) {}
  ok('Token-Datei persistiert (refreshToken)', saved && saved.refreshToken === 'REFRESH_1', saved && saved.refreshToken);

  // --- 8) Status-API ---
  const st = pub.status();
  ok('status.authed = true', st.authed === true);
  ok('status.url = Share-Link', st.url.indexOf('live=praxis_test_1') >= 0);

  // --- 9) No-Auth-Modus (Standard): schreibt OHNE Anmeldung, code-basiert ---
  const sign0 = captured.signups, puts0 = captured.puts.length;
  const pub2 = new CloudPublisher({ enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base, code: 'noauth1',
    station: 'NA', minIntervalMs: 1, identityUrl: base + '/identity', tokenUrl: base + '/token' },
    { log: { info() {}, warn() {}, error() {} } });
  pub2.start();
  ok('No-Auth ist Standard (useAuth=false)', pub2.useAuth === false);
  pub2.publish(samplePatients());
  await waitForPut(puts0 + 1);
  const naPut = captured.puts.slice(puts0).find((p) => p.url.indexOf('/live/noauth1.json') >= 0);
  ok('No-Auth: PUT geschrieben', !!naPut, naPut && naPut.url);
  ok('No-Auth: PUT OHNE ?auth-Parameter', naPut && naPut.url.indexOf('auth=') < 0, naPut && naPut.url);
  ok('No-Auth: KEINE Firebase-Anmeldung ausgeloest', captured.signups === sign0, 'signups delta=' + (captured.signups - sign0));

  try { fs.unlinkSync(authFile); } catch (_) {}
  srv.close();
  console.log('\nErgebnis: ' + pass + ' OK, ' + fail + ' Fehler.');
  process.exit(fail ? 1 : 0);

  function waitForPut(n) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      (function poll() {
        if (captured.puts.length >= n) return resolve();
        if (Date.now() - t0 > 5000) return reject(new Error('Timeout: erwartet >=' + n + ' PUTs, hatte ' + captured.puts.length));
        setTimeout(poll, 20);
      })();
    });
  }
}

run().catch(e => { console.error('TESTFEHLER:', e); try { srv.close(); } catch (_) {} process.exit(1); });
