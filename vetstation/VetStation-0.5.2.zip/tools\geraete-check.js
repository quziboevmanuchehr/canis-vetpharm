'use strict';
/*
 * geraete-check.js — VERBINDUNGS-CHECK fuer die Praxis (an den ECHTEN Geraeten).
 *
 * Beantwortet die Frage: "Verbinden sich uMEC12 Vet / Veta 5 Plus / LifeVet 10C mit dem PC?"
 * Der Check macht in EINEM Durchlauf:
 *   1. Netzwerkkarten + PC-IP anzeigen  (das ist die "Serveradresse", die am Geraet eingetragen wird)
 *   2. ARP-Suche nach Mindray-Geraeten (MAC 98:CC:E4 / 00:0F:14) im Netz
 *   3. Erreichbarkeit (Ping) je gefundenem/angegebenem Geraet
 *   4. Port-Test auf den Datenports (4601/5000/24105/2575)
 *   5. HL7-Handshake: sendet QRY^R02 und prueft, ob echte Messwerte zurueckkommen
 *   6. Lauschphase: faengt Geraete, die von sich aus zum PC senden ("Send HL7")
 *   7. Klartext-Urteil je Geraet + konkrete naechste Schritte
 *
 * STRIKT READ-ONLY: es werden nur Datenabfragen gesendet, nie Geraete-Einstellungen.
 *
 * Start am PRAXIS-PC:  GERAETE-PRUEFEN.bat doppelklicken (Ordner C:\VetStation oder Startmenue).
 *                      Mit IP:  GERAETE-PRUEFEN.bat 192.168.0.50 192.168.0.51
 *                      Dort gibt es kein npm und kein node in PATH - nur node\node.exe.
 * Start am Entwickler-PC (D:\VetStation):  node tools/geraete-check.js [IP ...]
 */
const os = require('os');
const net = require('net');
const { execFile } = require('child_process');
const { parseHL7Message } = require('../bridge/src/adapters/hl7');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
// 3502 = Mindray "Gateway-Kommunikation" (Standard-Ziel im uMEC12-Vet-Netzwerkmenue) — zuerst pruefen.
const PORTS = [3502, 4601, 5000, 24105, 2575];
// Ziel, das im Monitor unter "Gateway-Kommunikationseinst." eingetragen ist (Praxis-Foto): 192.168.0.99 : 3502
const ZIEL_IP = '192.168.0.99';
const ZIEL_NETZ = '192.168.0.';
const ZIEL_PORT = 3502;
const MINDRAY_OUI = { '98cce4': 'Mindray (uMEC12 Vet / Veta 5 Plus)', '000f14': 'Mindray/Eickemeyer (LifeVet 10C)' };
const LISTEN_SECONDS = 20;

function line(c) { console.log((c || '─').repeat(72)); }
function h(t) { console.log('\n' + t); line(); }
function mllp(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }
function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

// Virtuelle/VPN-Adapter erkennen — deren IP darf NICHT als "Serveradresse" empfohlen werden.
const VIRTUELL = /vpn|virtual|hyper-?v|vmware|virtualbox|radmin|tailscale|zerotier|tap|tun|wsl|bluetooth|docker|loopback/i;
function istPrivat(ip) { return /^192\.168\./.test(ip) || /^10\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip); }

function localIPs() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const name in ifs) for (const a of ifs[name]) {
    if (a.family === 'IPv4' && !a.internal) out.push({ name, address: a.address, netmask: a.netmask, mac: a.mac });
  }
  // Ranking: echte LAN-Karte im privaten Netz zuerst, virtuelle/VPN ganz nach hinten.
  out.forEach((i) => {
    let s = 0;
    if (!VIRTUELL.test(i.name)) s += 10;
    if (istPrivat(i.address)) s += 5;
    if (/^192\.168\./.test(i.address)) s += 2;      // typisches Praxis-Netz
    if (/ethernet|lan/i.test(i.name)) s += 3;
    i.virtuell = VIRTUELL.test(i.name);
    i.score = s;
  });
  out.sort((a, b) => b.score - a.score);
  return out;
}

function arpTable() {
  return new Promise((resolve) => {
    execFile('arp', ['-a'], { timeout: 8000 }, (err, stdout) => {
      if (err || !stdout) return resolve([]);
      const found = [];
      String(stdout).split(/\r?\n/).forEach((ln) => {
        const m = ln.match(/(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F-:]{11,})/);
        if (!m) return;
        const ip = m[1], mac = m[2].replace(/[-:]/g, '').toLowerCase();
        const oui = mac.slice(0, 6);
        if (MINDRAY_OUI[oui]) found.push({ ip: ip, mac: mac, hersteller: MINDRAY_OUI[oui] });
      });
      resolve(found);
    });
  });
}

function ping(host) {
  return new Promise((resolve) => {
    execFile('ping', ['-n', '1', '-w', '900', host], { timeout: 5000 }, (err, stdout) => {
      resolve(!err && /TTL=|ttl=/.test(String(stdout)));
    });
  });
}

function tcpOpen(host, port, timeout) {
  return new Promise((resolve) => {
    const s = new net.Socket(); let done = false;
    const fin = (v) => { if (done) return; done = true; try { s.destroy(); } catch (_) {} resolve(v); };
    s.setTimeout(timeout || 1200);
    s.once('connect', () => fin(true));
    s.once('timeout', () => fin(false));
    s.once('error', () => fin(false));
    s.connect(port, host);
  });
}

// Sendet QRY^R02 (reine DATEN-ABFRAGE, keine Steuerung) und prueft die Antwort.
function pdsHandshake(host, port, ms) {
  return new Promise((resolve) => {
    const s = new net.Socket(); let buf = Buffer.alloc(0); let done = false;
    const fin = (r) => { if (done) return; done = true; try { s.destroy(); } catch (_) {} resolve(r); };
    s.setTimeout(ms || 6000);
    s.once('error', () => fin({ ok: false, grund: 'Verbindung abgelehnt' }));
    s.once('timeout', () => fin({ ok: false, grund: 'keine Antwort (Zeitueberschreitung)' }));
    s.connect(port, host, () => {
      s.write(mllp('MSH|^~\\&|VetStation|||||' + new Date().toISOString().replace(/\D/g, '').slice(0, 14) + '||QRY^R02|1|P|2.3.1'));
    });
    s.on('data', (c) => {
      buf = Buffer.concat([buf, c]);
      const txt = buf.toString('latin1');
      if (txt.indexOf('MSH') < 0) return;
      const start = buf.indexOf(VT), end = buf.indexOf(FS);
      const payload = (start >= 0 && end > start) ? buf.slice(start + 1, end).toString('latin1') : txt;
      let frame = null; try { frame = parseHL7Message(payload, { deviceId: 'check', model: host }); } catch (_) {}
      const v = frame && frame.vitals || {};
      const werte = ['hr', 'spo2', 'etco2', 'af', 'temp'].filter((k) => v[k] != null)
        .map((k) => k.toUpperCase() + '=' + v[k]);
      if (v.nibp && v.nibp.sys != null) werte.push('NIBP=' + v.nibp.sys + '/' + v.nibp.dia);
      fin({ ok: true, hl7: true, werte: werte, roh: payload.slice(0, 90) });
    });
  });
}

// Lauscht auf allen Kandidaten-Ports: faengt Geraete, die VON SICH AUS senden.
function listenPhase(seconds) {
  return new Promise((resolve) => {
    const hits = []; const servers = []; const belegt = [];
    PORTS.forEach((port) => {
      const srv = net.createServer((sock) => {
        const ip = (sock.remoteAddress || '').replace('::ffff:', '');
        let buf = Buffer.alloc(0);
        sock.on('error', () => {});
        sock.on('data', (c) => {
          buf = Buffer.concat([buf, c]);
          const txt = buf.toString('latin1');
          if (txt.indexOf('MSH') >= 0 && !hits.some((x) => x.ip === ip && x.port === port)) {
            const start = buf.indexOf(VT), end = buf.indexOf(FS);
            const payload = (start >= 0 && end > start) ? buf.slice(start + 1, end).toString('latin1') : txt;
            let frame = null; try { frame = parseHL7Message(payload, { deviceId: 'x', model: ip }); } catch (_) {}
            const v = (frame && frame.vitals) || {};
            hits.push({ ip: ip, port: port, hl7: true, werte: ['hr', 'spo2', 'etco2', 'af'].filter((k) => v[k] != null).map((k) => k.toUpperCase() + '=' + v[k]) });
          } else if (buf.length > 8 && !hits.some((x) => x.ip === ip && x.port === port)) {
            hits.push({ ip: ip, port: port, hl7: false, roh: buf.slice(0, 16).toString('hex') });
          }
        });
      });
      srv.on('error', (e) => { if (e.code === 'EADDRINUSE') belegt.push(port); });
      try { srv.listen(port); servers.push(srv); } catch (_) {}
    });
    setTimeout(() => { servers.forEach((s) => { try { s.close(); } catch (_) {} }); resolve({ hits, belegt }); }, seconds * 1000);
  });
}

async function run() {
  const argHosts = process.argv.slice(2).filter((a) => /^\d+\.\d+\.\d+\.\d+$/.test(a));
  console.log('\n╔══════════════════════════════════════════════════════════════════╗');
  console.log('║  VetStation — VERBINDUNGS-CHECK  (uMEC12 Vet · Veta 5 Plus ·     ║');
  console.log('║  LifeVet 10C)   — nur lesen, es wird nichts am Geraet verstellt   ║');
  console.log('╚══════════════════════════════════════════════════════════════════╝');

  // 1) PC-Netzwerk
  h('1) Dieser PC im Netzwerk');
  const ips = localIPs();
  if (!ips.length) console.log('  ⚠ KEINE Netzwerkverbindung gefunden. LAN-Kabel/Switch pruefen!');
  ips.forEach((i) => console.log('  • ' + i.name + ': IP ' + i.address + '  (Maske ' + i.netmask + ', MAC ' + i.mac + ')'
    + (i.virtuell ? '   ⟵ virtuell/VPN, NICHT verwenden' : '')));
  const empfohlen = ips.find((i) => !i.virtuell) || ips[0];
  console.log('\n  → DIESE IP traegst du am Geraet als "Serveradresse"/"Server IP" ein:  '
    + (empfohlen ? empfohlen.address : '(keine IP!)') + (empfohlen && empfohlen.virtuell ? '  ⚠ (nur VPN gefunden — LAN-Kabel pruefen!)' : ''));

  // 1b) Abgleich mit dem Ziel, das im Monitor unter "Gateway-Kommunikationseinst." steht
  const hatZiel = ips.some((i) => i.address === ZIEL_IP);
  const imZielnetz = ips.some((i) => !i.virtuell && i.address.indexOf(ZIEL_NETZ) === 0);
  console.log('');
  if (hatZiel) {
    console.log('  ✓ Dieser PC hat GENAU ' + ZIEL_IP + ' — also die IP, die im Monitor als Ziel eingetragen ist. Passt.');
  } else if (imZielnetz) {
    console.log('  ⚠ PC ist zwar im Netz ' + ZIEL_NETZ + 'x, hat aber NICHT ' + ZIEL_IP + '.');
    console.log('    → Entweder PC auf ' + ZIEL_IP + ' setzen: NETZWERK-EINRICHTEN.bat doppelklicken,');
    console.log('      ODER am Monitor unter "Gateway-Kommunikationseinst." die oben gezeigte PC-IP eintragen.');
  } else {
    console.log('  ⚠ PC ist NICHT im Netz ' + ZIEL_NETZ + 'x — der Monitor sendet aber an ' + ZIEL_IP + ':' + ZIEL_PORT + '.');
    console.log('    → PC auf ' + ZIEL_IP + '/24 setzen: im Ordner C:\\VetStation die Datei');
    console.log('      NETZWERK-EINRICHTEN.bat DOPPELKLICKEN (holt sich die Adminrechte selbst).');
  }

  // 2) ARP-Suche
  h('2) Mindray-Geraete im Netz (MAC-Suche)');
  const arp = await arpTable();
  if (arp.length) arp.forEach((d) => console.log('  ✓ ' + d.ip + '  (' + d.hersteller + ')'));
  else console.log('  – keine Mindray-MAC gefunden. (Geraet aus? anderes Subnetz? noch nie Daten getauscht?)\n' +
    '    Tipp: Geraet anpingen oder IP direkt angeben — GERAETE-PRUEFEN.bat 192.168.0.50');

  // Kandidaten = ARP-Funde + manuell angegebene
  const hosts = [];
  arp.forEach((d) => { if (!hosts.includes(d.ip)) hosts.push(d.ip); });
  argHosts.forEach((a) => { if (!hosts.includes(a)) hosts.push(a); });

  // 3-5) je Geraet: Ping, Ports, HL7-Handshake
  const ergebnisse = [];
  if (hosts.length) {
    h('3) Test je Geraet (Ping → offene Ports → HL7-Abfrage)');
    for (const host of hosts) {
      console.log('\n  ▸ Geraet ' + host);
      const erreichbar = await ping(host);
      console.log('    Ping: ' + (erreichbar ? '✓ erreichbar' : '✗ NICHT erreichbar'));
      const offen = [];
      for (const p of PORTS) { if (await tcpOpen(host, p)) offen.push(p); }
      console.log('    Offene Datenports: ' + (offen.length ? offen.join(', ') : '– keiner von ' + PORTS.join('/')));
      let hl7 = null;
      for (const p of offen) {
        process.stdout.write('    HL7-Abfrage auf Port ' + p + ' ... ');
        const r = await pdsHandshake(host, p);
        if (r.ok && r.hl7) { console.log('✓ HL7 ERKANNT' + (r.werte.length ? '  [' + r.werte.join(' ') + ']' : ' (Nachricht ohne Messwerte)')); hl7 = { port: p, werte: r.werte }; break; }
        console.log('✗ ' + (r.grund || 'kein HL7'));
      }
      ergebnisse.push({ host, erreichbar, offen, hl7 });
    }
  }

  // 6) Lauschphase
  h('6) Lauschphase (' + LISTEN_SECONDS + ' s) — Geraete, die von sich aus senden');
  console.log('  Jetzt am Geraet die Datenuebertragung starten/einschalten');
  console.log('  (Serveradresse = ' + (empfohlen ? empfohlen.address : 'PC-IP') + ', Port 4601). Bitte warten ...');
  const { hits, belegt } = await listenPhase(LISTEN_SECONDS);
  if (belegt.length) console.log('  ⚠ Ports belegt (laeuft VetStation gerade?): ' + belegt.join(', ') + ' — dann diese hier nicht pruefbar.');
  if (hits.length) hits.forEach((x) => console.log('  ✓ ' + x.ip + ' sendet auf Port ' + x.port + (x.hl7 ? '  → HL7 ERKANNT [' + x.werte.join(' ') + ']' : '  → unbekanntes Format (hex ' + x.roh + ')')));
  else console.log('  – kein Geraet hat von sich aus gesendet.');

  // 7) Urteil
  h('7) ERGEBNIS & naechste Schritte');
  const okDevices = ergebnisse.filter((e) => e.hl7).map((e) => e.host).concat(hits.filter((x) => x.hl7).map((x) => x.ip));
  if (okDevices.length) {
    console.log('  ✅ DATENVERBINDUNG STEHT fuer: ' + [...new Set(okDevices)].join(', '));
    console.log('     → In bridge/config/devices.json eintragen (host + port), enabled:true, VetStation neu starten.');
  } else {
    console.log('  ❌ Noch KEINE Datenverbindung. Wahrscheinlichste Ursachen, der Reihe nach:\n');
    console.log('     0. ⭐ HAT DER MONITOR UEBERHAUPT EINE IP?  (haeufigste Ursache!)');
    console.log('        Am Monitor: Wartung → Benutzer-Wartung (888888) → Netzwerk → Monitornetzwerk-Setup.');
    console.log('        Steht dort IP-Adresse 0.0.0.0 bzw. "Abrufen der Netzwerkadr. fehlgeschlagen",');
    console.log('        dann hat DHCP keine Adresse bekommen (ohne Router gibt es keinen DHCP-Server!).');
    console.log('        → Adresstyp auf MANUELL/STATISCH stellen und eintragen:');
    console.log('             IP-Adresse 192.168.0.50 · Subn.maske 255.255.255.0 · Gateway 192.168.0.1');
    console.log('          (PC steht dann auf ' + ZIEL_IP + ' — siehe installer\\set-static-ip.ps1)');
    console.log('        Solange dort 0.0.0.0 steht, kann NICHTS ankommen.\n');
    const unreachable = ergebnisse.filter((e) => !e.erreichbar);
    if (!hosts.length) {
      console.log('     1. Geraet nicht im selben Netz. Beide (PC + Geraet) an DENSELBEN Switch,');
      console.log('        gleicher IP-Bereich (PC ' + ZIEL_IP + ', Monitor 192.168.0.50).');
    } else if (unreachable.length) {
      console.log('     1. Nicht erreichbar (' + unreachable.map((e) => e.host).join(', ') + '): Kabel/Switch/IP-Bereich pruefen.');
    } else {
      console.log('     1. Geraet erreichbar, aber sendet keine Daten → am GERAET die Ausgabe aktivieren:');
    }
    console.log('        • uMEC12 Vet / LifeVet 10C:  Hauptmenue → Wartung → Benutzer-Wartung');
    console.log('          (Passwort 888888) → Netzwerk → Gateway-Kommunikationseinst. / EMR-Kommunikation:');
    console.log('          Server-IP = ' + (empfohlen ? empfohlen.address : 'PC-IP') + ' , Port ' + ZIEL_PORT + ' (bzw. 4601 bei HL7/EMR),');
    console.log('          Protokoll HL7 , "Real Data Send" EIN');
    console.log('     1b. WINDOWS-FIREWALL: eingehende Ports muessen offen sein (' + PORTS.join('/') + ').');
    console.log('         Der Installer macht das; sonst als Admin:');
    console.log('         netsh advfirewall firewall add rule name="VetStation TCP ' + ZIEL_PORT + '" dir=in action=allow protocol=TCP localport=' + ZIEL_PORT);
    console.log('        • Veta 5 Plus: hat laut Handbuch KEINEN offenen Datenausgang (CS-Port = nur');
    console.log('          Firmware-Update). Kapno-Werte deshalb ueber den MONITOR holen (der misst CO2)');
    console.log('          oder Veta per BeneLink an den Monitor koppeln → geht dann im HL7-Strom mit.');
    console.log('     2. Falls das Geraet HL7 nicht anbietet (Firmware/Lizenz): Fallback VSCapture');
    console.log('        einrichten. Dazu PowerShell ALS ADMINISTRATOR oeffnen und eingeben:');
    console.log('        powershell -ExecutionPolicy Bypass -File "C:\\VetStation\\installer\\setup-vscapture-fallback.ps1"');
    console.log('        (Anleitung: C:\\VetStation\\docs\\MINDRAY-HL7.md)');
    console.log('     3. Beim Haendler (Eickemeyer) erfragen: Freischaltung/Lizenz fuer Datenausgabe +');
    console.log('        exakter Port. Vorlage: docs/geraete-protokolle-quellen-links.md');
  }
  console.log('\n  Rohdaten-Mitschnitt fuer die Analyse: in devices.json beim Adapter "rawLog": true');
  console.log('  → schreibt data/hl7-raw.log. Details: docs/MINDRAY-HL7.md\n');
}

run().catch((e) => { console.error('Fehler im Check:', e.message); process.exit(1); });
