'use strict';
/*
 * paket-test.js — Regressionstest fuer die BEDIENBARKEIT auf dem Praxis-PC.
 *
 * HINTERGRUND (21.07.2026): Der Nutzer hat auf dem frisch installierten Praxis-PC
 *   powershell -ExecutionPolicy Bypass -File installer\set-static-ip.ps1
 * eingegeben und bekam: "Das Argument ... fuer den -File-Parameter ist nicht vorhanden".
 * Grund: PowerShell startet in C:\Windows\System32 — ein RELATIVER Pfad zeigt dort ins Leere.
 * Zweiter Fehler derselben Klasse: die Anleitung empfahl `npm run check`, aber auf dem
 * Ziel-PC gibt es KEIN npm (nur das portable node\node.exe).
 *
 * Dieser Test stellt sicher, dass der Tierarzt NIEMALS einen Pfad tippen muss:
 * es gibt Doppelklick-Dateien, sie benutzen %~dp0 (eigener Ordner) und liegen im Startmenue.
 *
 * Start: node tools/paket-test.js      (laeuft auch in `npm test`)
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function read(rel) { try { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); } catch (_) { return ''; } }

console.log('VetStation — Paket/Bedienbarkeit auf dem Praxis-PC\n');

const mk = read('installer/make-dist.ps1');
const iss = read('installer/vetstation-setup.iss');
const ip = read('installer/set-static-ip.ps1');
const lan = read('docs/LAN-SETUP.md');

// 1) Die beiden Doppelklick-Dateien werden ins Paket geschrieben
console.log('Doppelklick statt Tippen:');
ok('make-dist erzeugt NETZWERK-EINRICHTEN.bat', mk.indexOf('NETZWERK-EINRICHTEN.bat') >= 0);
ok('make-dist erzeugt GERAETE-PRUEFEN.bat', mk.indexOf('GERAETE-PRUEFEN.bat') >= 0);

// 2) Sie duerfen NICHT vom Startverzeichnis abhaengen -> immer %~dp0 (Ordner der .bat)
const netzBlock = mk.slice(mk.indexOf('title VetStation'), mk.indexOf("'NETZWERK-EINRICHTEN.bat'"));
ok('NETZWERK-EINRICHTEN.bat benutzt %~dp0 (kein relativer Pfad)',
  /%~dp0installer\\set-static-ip\.ps1/.test(netzBlock), 'Block: ' + netzBlock.slice(0, 120));
const pruefIdx = mk.indexOf('Geraete pruefen');
const pruefBlock = pruefIdx >= 0 ? mk.slice(pruefIdx, mk.indexOf("'GERAETE-PRUEFEN.bat'")) : '';
ok('GERAETE-PRUEFEN.bat benutzt %~dp0 (kein relativer Pfad)',
  /%~dp0tools\\geraete-check\.js/.test(pruefBlock));

// 3) Auf dem Ziel-PC gibt es kein npm -> nur portables node.exe verwenden
ok('GERAETE-PRUEFEN.bat startet node\\node.exe (nicht npm)',
  /%~dp0node\\node\.exe/.test(pruefBlock));
ok('GERAETE-PRUEFEN.bat ruft NICHT "npm run" auf',
  !/npm\s+run\s+check/.test(pruefBlock.replace(/^REM.*$/gm, '')));
ok('das aufgerufene Skript existiert wirklich', fs.existsSync(path.join(ROOT, 'tools', 'geraete-check.js')));
ok('GERAETE-PRUEFEN.bat haelt das Fenster offen (pause)', /\npause/.test(pruefBlock));

// 4) Startmenue-/Desktop-Verknuepfungen im Installer
console.log('\nVerknuepfungen im Installer:');
ok('Setup legt Startmenue-Eintrag "Netzwerk einrichten" an',
  /\[Icons\][\s\S]*NETZWERK-EINRICHTEN\.bat/.test(iss));
ok('Setup legt Startmenue-Eintrag "Geraete pruefen" an',
  /\[Icons\][\s\S]*GERAETE-PRUEFEN\.bat/.test(iss));

// 5) set-static-ip.ps1 muss sich die Adminrechte selbst holen und lesbar bleiben
console.log('\nset-static-ip.ps1:');
ok('holt sich Adminrechte selbst (RunAs-Guard)',
  ip.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && ip.indexOf('-Verb RunAs') >= 0);
ok('nennt den VOLLSTAENDIGEN Pfad als Handaufruf',
  ip.indexOf('C:\\VetStation\\installer\\set-static-ip.ps1') >= 0);
ok('empfiehlt NICHT mehr "npm run check"', !/npm run check/.test(ip));
ok('verweist auf GERAETE-PRUEFEN.bat', ip.indexOf('GERAETE-PRUEFEN.bat') >= 0);
ok('Fenster bleibt am Ende offen (Read-Host)', /Read-Host[^\n]*EINGABETASTE/.test(ip));
// Der Nutzer tippte auf die Frage "Nummer der Karte" eine IP bzw. "1231" und bekam nur
// "Ungueltige Auswahl" + sofortigen Abbruch. Deshalb: bei einer Karte gar nicht fragen.
ok('waehlt die Netzwerkkarte automatisch, wenn es nur eine (verbundene) gibt',
  /Netzwerkkarte automatisch gewaehlt/.test(ip) && /Where-Object Status -eq 'Up'\)\.Count -eq 1/.test(ip));
ok('blendet VPN-/virtuelle Adapter aus', /\$VIRTUELL\s*=/.test(ip) && ip.indexOf('Radmin') >= 0);
ok('bricht bei Fehleingabe nicht sofort ab (mehrere Versuche)', /versuch -ge 3/.test(ip));
ok('sagt klar, dass nur die Zahl aus der Klammer erwartet wird',
  ip.indexOf('NUR die Zahl aus der eckigen Klammer') >= 0);
ok('prueft nach, ob die IP wirklich gesetzt wurde', /ERFOLG/.test(ip) && /Get-NetIPAddress[^\n]*\n?[^\n]*IPAddress -eq \$IP/.test(ip));

// 6) ANSI-Falle: Windows PowerShell 5.1 liest .ps1 ohne BOM als ANSI. Ein UTF-8-Gedankenstrich
//    zerfaellt dabei in U+201D — und das ist fuer PowerShell ein STRING-ANFANG. Ergebnis:
//    "Die schliessende } fehlt". Deshalb muessen die Skripte ASCII-rein bleiben.
console.log('\nASCII-Reinheit der PowerShell-Skripte (PowerShell-5.1-ANSI-Falle):');
['installer', 'kiosk'].forEach((dir) => {
  const psDir = path.join(ROOT, dir);
  fs.readdirSync(psDir).filter((f) => f.endsWith('.ps1')).forEach((f) => {
    const buf = fs.readFileSync(path.join(psDir, f));
    let bad = -1;
    for (let i = 0; i < buf.length; i++) { if (buf[i] > 0x7f) { bad = i; break; } }
    ok(dir + '/' + f + ' ist rein ASCII', bad === -1, bad >= 0 ? ('Byte 0x' + buf[bad].toString(16) + ' an Position ' + bad) : '');
  });
});

// 6b) Adminrechte: Skripte, die geplante Aufgaben registrieren, muessen sich selbst erhoehen —
//     sonst brechen sie mit "Zugriff verweigert" ab (beim Entfernen frueher sogar lautlos).
console.log('\nAdminrechte holen sich die Skripte selbst:');
const autostart = read('kiosk/install-autostart.ps1');
ok('install-autostart.ps1 hat RunAs-Guard',
  autostart.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && autostart.indexOf('-Verb RunAs') >= 0);
ok('install-autostart.ps1 meldet ehrlich, wenn nichts zu entfernen war',
  autostart.indexOf('war nicht registriert') >= 0);
ok('install-autostart.ps1 nennt den vollstaendigen Pfad',
  autostart.indexOf('C:\\VetStation\\kiosk\\install-autostart.ps1') >= 0);

// 6c) Der Starter darf im Fehlerfall nicht kommentarlos verschwinden.
console.log('\nStarter zeigt Fehler an:');
const startBlock = mk.slice(mk.indexOf('title VetStation\n'), mk.indexOf("'START-VetStation.bat'"));
ok('START-VetStation.bat haelt bei Fehler an (errorlevel + pause)',
  /if errorlevel 1/.test(startBlock) && /pause/.test(startBlock));
ok('GERAETE-PRUEFEN.bat reicht eine Geraete-IP durch (%*)', /geraete-check\.js" %\*/.test(pruefBlock));

// 7) Konsolen-Hinweise der Pruef-App: sie haben dem Nutzer genau den Befehl vorgeschlagen,
//    der heute fehlgeschlagen ist. Sie duerfen keine relativen Pfade mehr nennen.
console.log('\nHinweistexte in tools/geraete-check.js:');
const check = read('tools/geraete-check.js');
ok('schlaegt KEINEN relativen -File-Pfad mehr vor', !/-File installer\\\\set-static-ip/.test(check));
// Nur die BILDSCHIRMAUSGABE zaehlt: im Kopfkommentar darf der Entwickler-Aufruf stehen bleiben.
const ausgaben = check.split('\n').filter((l) => l.indexOf('console.log') >= 0).join('\n');
ok('keine Bildschirmausgabe schlaegt "node tools/..." vor', !/node tools\//.test(ausgaben));
ok('keine Bildschirmausgabe nennt einen relativen installer/-Pfad',
  !/[^\\:]installer[\\/]set-static-ip|[^\\:]installer[\\/]setup-vscapture/.test(ausgaben));
ok('verweist auf NETZWERK-EINRICHTEN.bat', check.indexOf('NETZWERK-EINRICHTEN.bat') >= 0);
ok('nennt setup-vscapture mit vollem Pfad', check.indexOf('C:\\\\VetStation\\\\installer\\\\setup-vscapture-fallback.ps1') >= 0);

// 8) Oberflaeche: keine Pfade nennen, die es auf dem Praxis-PC nicht gibt.
console.log('\nOberflaeche (ui):');
const adm = read('ui/views/admin.js');
ok('Fern-Live nennt den vollstaendigen Konfigurationspfad',
  adm.indexOf('C:\\\\VetStation\\\\bridge\\\\config\\\\') >= 0);
ok('Fern-Live erklaert devices.example.json -> devices.json', adm.indexOf('devices.example.json') >= 0);
ok('Update wendet nicht mehr per location.reload() an (tat nichts)',
  !/restart[\s\S]{0,200}location\.reload\(\)/.test(adm));
ok('Update sagt, dass es beim naechsten Start angewendet wird',
  adm.indexOf('nächsten Start von VetStation') >= 0);
const live = read('ui/vetstation-live.js');
ok('Kiosk macht tote Modul-Links unklickbar', /a\[href\^="\.\.\/"\]\{pointer-events:none/.test(live));
ok('Kiosk blendet den toten "Start"-Link aus', live.indexOf('header a[href="../"]') >= 0);

// 7) Paket ohne node.exe waere unbrauchbar -> make-dist muss abbrechen
console.log('\nPaketbau:');
ok('make-dist bricht ab, wenn node.exe fehlt', /throw "ABBRUCH: node\\node\.exe fehlt/.test(mk));
ok('make-dist rettet vorhandenes node.exe (Offline-Build)', mk.indexOf('vetstation-node-cache.exe') >= 0);

// 8) Die Anleitung darf den Fehler nicht wiederholen
console.log('\nAnleitung docs/LAN-SETUP.md:');
ok('warnt vor dem relativen Pfad', lan.indexOf('C:\\Windows\\System32') >= 0);
ok('nennt NETZWERK-EINRICHTEN.bat zum Doppelklicken', lan.indexOf('NETZWERK-EINRICHTEN.bat') >= 0);
ok('nennt GERAETE-PRUEFEN.bat statt npm', lan.indexOf('GERAETE-PRUEFEN.bat') >= 0);
ok('erklaert, dass es auf dem Praxis-PC kein npm gibt', /npm[^\n]*gibt es auf dem Praxis-PC nicht/.test(lan));

// 9) Lautlose Fehlschlaege: Skripte duerfen nicht "erledigt" melden, wenn nichts passiert ist.
console.log('\nKeine lautlosen Fehlschlaege:');
const stop = read('kiosk/stop-kiosk.ps1');
ok('stop-kiosk.ps1 holt sich Adminrechte (Kiosk laeuft erhoeht)',
  stop.indexOf('WindowsBuiltInRole]::Administrator') >= 0 && stop.indexOf('-Verb RunAs') >= 0);
// Kommentare ausblenden: der Kopfkommentar BESCHREIBT das alte "try{}catch{}" und darf das auch.
const stopCode = stop.replace(/<#[\s\S]*?#>/g, '').split('\n').filter((l) => !/^\s*#/.test(l)).join('\n');
ok('stop-kiosk.ps1 verschluckt Fehler nicht mehr (kein leeres catch)', !/catch\s*\{\s*\}/.test(stopCode));
ok('stop-kiosk.ps1 warnt, wenn der Kiosk weiterlaeuft', stop.indexOf('laeuft moeglicherweise WEITER') >= 0);
const kiosk = read('docs/KIOSK-SETUP.md');
ok('KIOSK-SETUP.md behauptet nicht mehr "keine Adminrechte noetig"',
  kiosk.indexOf('keine Adminrechte nötig') < 0);

// 10) Sachlich falsche Zusagen in der Doku
console.log('\nDoku sagt die Wahrheit:');
const mray = read('docs/MINDRAY-HL7.md');
ok('MINDRAY-HL7.md behauptet nicht mehr, .NET 8 werde installiert',
  mray.indexOf('prüft/installiert **.NET 8') < 0 && /installiert \.NET 8 NICHT/.test(mray));
ok('MINDRAY-HL7.md erklaert devices.example.json -> devices.json', mray.indexOf('devices.example.json') >= 0);
const aa = read('kiosk/assigned-access.md');
ok('assigned-access.md warnt: Shell Launcher gibt es nicht in Windows Pro',
  /Pro gibt es Shell Launcher\s*\n?>?\s*nicht|nicht in Pro/.test(aa));
ok('assigned-access.md erklaert, dass die PIN im Kiosk nicht aenderbar ist',
  aa.indexOf('nur vom Techniker ändern') >= 0);

// 11) Veraltete Netzwerkangaben duerfen in keiner Anleitung mehr stehen - sie widersprechen
//     der ausgelieferten Software (PC .99 / Monitor .50 / Port 3502).
console.log('\nKeine veralteten IPs in den Anleitungen:');
['README.md', 'docs/LAN-SETUP.md', 'docs/KIOSK-SETUP.md', 'docs/MINDRAY-HL7.md',
 'docs/FERN-LIVE.md', 'installer/README.md', 'kiosk/assigned-access.md'].forEach((f) => {
  const t = read(f);
  const alt = (t.match(/192\.168\.(?:23|2)\.\d+/g) || []).filter((ip) => ip.indexOf('192.168.2.') !== 0 || true);
  // 192.168.23.x und 192.168.2.x sind beide veraltet; erlaubt ist nur eine ausdrueckliche
  // "veraltet"-Warnung, die den Wert nennt.
  const nurWarnung = alt.length > 0 && /veraltet/i.test(t);
  ok(f + ' ohne veraltete IP', alt.length === 0 || nurWarnung,
    alt.length ? ('gefunden: ' + alt.slice(0, 4).join(', ')) : '');
});

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
