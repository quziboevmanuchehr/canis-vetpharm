# VetStation auf dem Praxis-PC installieren (Windows 10/11 Pro)

Ziel: **einfach installieren, danach läuft es automatisch** (Vollbild-Kiosk beim Hochfahren).

> Alles Wichtige geht per **Doppelklick** — es muss nichts getippt werden.
> Auf dem Praxis-PC liegt die Installation immer unter **`C:\VetStation`**.

## A) Installieren (auf dem Praxis-PC)
Voraussetzung: `VetStation-Setup.exe` bzw. der Ordner `VetStation` liegt bereits auf dem PC
(per USB-Stick oder Netzwerk kopiert).

Zwei Wege — beide ohne Tippen:

- **`VetStation-Setup.exe`** doppelklicken (eine Datei, ~19 MB, empfohlen) → UAC-Abfrage mit **Ja**
  bestätigen. Installiert nach `C:\VetStation`, legt Start-Menü-Einträge an und richtet den Autostart
  ein. Deinstallation später über „Apps & Features". Läuft auf Windows 10 **und** 11.
- Oder im kopierten Ordner **`INSTALLIEREN.bat`** doppelklicken. Die Datei holt sich die Adminrechte
  selbst (UAC-Abfrage mit **Ja** bestätigen); falls das nicht klappt: Rechtsklick →
  **„Als Administrator ausführen"**.
  Das kopiert die App nach `C:\VetStation`, richtet **Autostart + Watchdog** ein, gibt die
  Geräte-Ports in der Windows-Firewall frei und fragt optional die **statische IP** fürs Geräte-Netz ab.

Nur testen (ohne Autostart): **`C:\VetStation\START-VetStation.bat`** doppelklicken.

Danach startet VetStation beim nächsten Anmelden automatisch im Vollbild. Für den „echten" Appliance-
Modus (kein Desktop sichtbar) zusätzlich **Assigned Access / Autologin** einrichten →
`C:\VetStation\kiosk\assigned-access.md` ([assigned-access.md](../kiosk/assigned-access.md)).

## B) Netzwerk einrichten (feste IP für das Geräte-Netz)
**`NETZWERK-EINRICHTEN.bat`** doppelklicken — liegt in `C:\VetStation` und im **Startmenü unter
„VetStation"**. Adminrechte holt sich die Datei selbst, die UAC-Abfrage bitte mit **Ja** bestätigen.

Verbindliche Adressen (das Skript setzt die PC-Adresse, die Geräte werden am Gerät selbst eingestellt):

| Gerät | Adresse |
|---|---|
| PC (VetStation) | `192.168.0.99` / `255.255.255.0`, **kein** Gateway |
| uMEC12 Vet Monitor | `192.168.0.50` / `255.255.255.0`, Adresstyp **MANUELL** (nicht DHCP) |
| LifeVet / 2. Gerät | `192.168.0.51` |
| Ziel im Monitor (Gateway-Kommunikationseinstellung) | `192.168.0.99` : `3502` |

Menüweg im Monitor: **Hauptmenü → Wartung → Benutzer-Wartung (Passwort `888888`) → Netzwerk**.

## C) Geräte anschließen und prüfen
- Physischer LAN-Aufbau (Switch, IPs, Serveradresse = PC-IP) → `C:\VetStation\docs\LAN-SETUP.md`
  ([LAN-SETUP.md](../docs/LAN-SETUP.md))
- Geräte-Adapter aktivieren → `C:\VetStation\docs\DEVICE-ADAPTERS.md`
  ([DEVICE-ADAPTERS.md](../docs/DEVICE-ADAPTERS.md))
- Kommen wirklich Daten an? **`GERAETE-PRUEFEN.bat`** doppelklicken (liegt in `C:\VetStation` und im
  Startmenü unter „VetStation"). Das Fenster zeigt, ob der Monitor sendet.

## D) Deinstallieren
Am einfachsten über **Einstellungen → Apps & Features → VetStation → Deinstallieren**
(wenn mit `VetStation-Setup.exe` installiert wurde).

Wurde ohne Setup installiert, muss der Autostart einmal von Hand entfernt werden. Dafür PowerShell
per **Rechtsklick → „Als Administrator ausführen"** öffnen (ohne Adminrechte schlägt das Entfernen
der geplanten Aufgabe fehl) und diese Zeile mit **vollständigem Pfad** eingeben:
```powershell
powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\install-autostart.ps1" -Remove
```
Danach den Ordner `C:\VetStation` löschen.

---

## Nur Entwickler-PC (D:\VetStation)
Die folgenden Befehle gehören **nicht** auf den Praxis-PC. Sie laufen nur auf dem Entwickler-PC, auf
dem das Projekt unter `D:\VetStation` liegt. Alle Pfade vollständig und in Anführungszeichen, weil
PowerShell in `C:\Windows\System32` startet und relative Pfade dort fehlschlagen.

**1) Paket bauen**
```powershell
powershell -ExecutionPolicy Bypass -File "D:\VetStation\installer\make-dist.ps1"
```
Erzeugt `D:\VetStation\dist\VetStation\` (**inkl. portablem Node** — auf dem Ziel-PC muss nichts extra
installiert werden) und `D:\VetStation\dist\VetStation-Setup.zip`.

**2) Setup-EXE bauen** (nach jeder Änderung erst `make-dist.ps1`, dann):
```powershell
& "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe" "D:\VetStation\installer\vetstation-setup.iss"
```
Ergebnis: `D:\VetStation\dist\VetStation-Setup.exe` (~19 MB).
Inno Setup ist kostenlos: `winget install JRSoftware.InnoSetup`.
Skript: `D:\VetStation\installer\vetstation-setup.iss`.

**3) Auf den Praxis-PC bringen**
`D:\VetStation\dist\VetStation-Setup.exe` (oder den Ordner `D:\VetStation\dist\VetStation` bzw. das
entpackte Zip) per **USB-Stick** oder Netzwerk auf den Ziel-PC kopieren → dort weiter bei Abschnitt **A)**.
