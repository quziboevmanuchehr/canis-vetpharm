# Kiosk-/Appliance-Modus einrichten (Windows 10 & 11)

Ziel (§8): VetStation startet beim Hochfahren **automatisch im Vollbild**, ohne sichtbaren
Windows-Desktop/Taskleiste — wie ein IDEXX-Laborgerät. Zwei bewährte Wege; beide funktionieren
unter **Windows 10 Pro 22H2** und **Windows 11**.

## Voraussetzung: Autostart + Autologin
1. **Autostart** einrichten — **ohne Tippen**: im Ordner **C:\VetStation** die Datei
   **INSTALLIEREN.bat** **doppelklicken**. Sie holt sich die Adminrechte selbst
   (UAC-Abfrage mit **Ja** bestätigen) und registriert dabei die geplante Aufgabe
   „VetStation-Kiosk" bei Anmeldung, inkl. Watchdog/Selbstheilung.

   *Nur falls der Autostart einzeln nachgeholt oder repariert werden muss* — vollständiger Pfad
   in Anführungszeichen, weil PowerShell in `C:\WINDOWS\system32` startet und ein relativer Pfad
   dort immer fehlschlägt:
   ```
   powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\install-autostart.ps1"
   ```
   Dieser Befehl braucht **Adminrechte** (`Register-ScheduledTask`): PowerShell per Rechtsklick
   **„Als Administrator ausführen"** öffnen. Das Skript fragt die Rechte sonst selbst per UAC nach —
   die Abfrage muss dann mit **Ja** bestätigt werden.
   Wieder entfernen: derselbe Befehl mit ` -Remove` am Ende.
2. **Autologin** für den dedizierten PC:
   - `netplwiz` → Haken „Benutzer müssen … Kennwort eingeben" **entfernen** → Konto + Passwort bestätigen, **oder**
   - Registry `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon`: `AutoAdminLogon=1`, `DefaultUserName`, `DefaultPassword`.

## Weg A — Assigned Access (Zugewiesener Zugriff) — einfachster Kiosk
Startet **Microsoft Edge im Kioskmodus** automatisch. Ideal, da VetStation ohnehin über Edge/WebView2 läuft.
- Windows-Einstellungen → **Konten → Andere Benutzer → Kiosk einrichten** (bzw. „Assigned Access").
- Kiosk-Konto wählen → **Microsoft Edge** → **als Vollbild-/digital-signage/Kiosk** → URL `http://127.0.0.1:8770`.
- Wichtig: Die **Bridge muss vorher laufen** → Autostart (oben) startet sie. Der Assigned-Access-Edge zeigt dann die UI.
- Per PowerShell automatisierbar über `Set-AssignedAccess`/`Set-CimInstance MDM_AssignedAccess` (Provisioning-Paket mit dem **Windows Configuration Designer**).
  Diese Befehle brauchen **Adminrechte**: PowerShell per Rechtsklick **„Als Administrator ausführen"** öffnen.

## Weg B — Shell Launcher — App ersetzt explorer.exe (härtester Kiosk)
Ersetzt die Windows-Shell komplett durch VetStation; **kein Desktop/keine Taskleiste**.

> ⚠️ **Nur Windows Enterprise / Education / IoT.** Auf **Windows 10/11 Pro gibt es Shell Launcher
> nicht** — der Befehl unten scheitert dort mit „Feature name Client-EmbeddedShellLauncher is
> unknown" (0x800f080c). **Auf einem Pro-PC bitte Weg A benutzen** (Assigned Access, oben).

- Feature aktivieren — braucht **Adminrechte**: PowerShell per Rechtsklick **„Als Administrator ausführen"** öffnen, dann:
  ```
  Enable-WindowsOptionalFeature -Online -FeatureName Client-EmbeddedShellLauncher
  ```
- Als „custom shell" den **vollständigen Pfad in Anführungszeichen** setzen:
  ```
  powershell.exe -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\launch-kiosk.ps1" -Watchdog
  ```
  (via WMI `WESL_UserSetting` / Configuration Designer — ebenfalls **als Administrator**).
  `launch-kiosk.ps1` startet Bridge **und** Edge-Kiosk und hält sich mit dem Watchdog selbst am Leben.
- Rückkehr zur Wartung: als **Admin-Konto** anmelden (dort normale Shell) — siehe unten.

## Beenden/Wartung nur mit PIN (§8)
- **In der App:** Der Admin-Bereich ist **PIN-geschützt** (Standard `1234`). Dort liegen
  Selbstdiagnose/Feedback/Export.
  > ⚠️ **Die PIN lässt sich derzeit nur vom Techniker ändern** (Schlüssel `vetstation.pin` im
  > localStorage). **Im Edge-Kioskmodus geht das nicht** — dort gibt es keine Entwicklertools, und
  > im Admin-Bereich existiert noch kein Feld dafür. Die PIN deshalb **vor** dem Kiosk-Betrieb
  > setzen: VetStation einmal in einem normalen Browserfenster öffnen (`http://127.0.0.1:8770`),
  > F12 → Konsole → `localStorage.setItem('vetstation.pin','…')`. Der Standard `1234` sollte in
  > der Praxis nicht stehen bleiben.
- **Kiosk verlassen (Technik):** separates **Admin-Windows-Konto** ohne Kiosk anlegen; über den Anmeldebildschirm
  (Assigned Access) bzw. Shell-Launcher-Ausnahme dorthin wechseln, dann — PowerShell per Rechtsklick
  **„Als Administrator ausführen"** öffnen (der Kiosk läuft mit erhöhten Rechten) und mit vollständigem
  Pfad in Anführungszeichen aufrufen:
  ```
  powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\stop-kiosk.ps1"
  ```
  Danach lässt sich VetStation normal per Doppelklick auf **C:\VetStation\START-VetStation.bat** wieder starten.
- Der reine Edge-Kioskmodus lässt sich nicht per Tastenkürzel schließen (gewollt); Wartung immer über das Admin-Konto.

## Windows 11 Hinweise
- **Assigned Access** (Weg A) gibt es unter Windows 10/11 in **Pro, Enterprise und Education**.
  **Shell Launcher** (Weg B) dagegen **nur in Enterprise/Education/IoT — nicht in Pro**.
- WebView2 ist Evergreen (Microsoft aktualisiert automatisch) → identisches Verhalten Win10/Win11.
- DPI/Skalierung: die UI ist responsiv (relative Einheiten); bei Touchscreens funktioniert Maus **und** Touch.

## Empfehlung für diesen Aufbau
Jetzt sofort lauffähig: **Autostart + Assigned Access (Weg A)** mit dem Edge-WebView2-Kiosk.
In der Praxis heißt das: **INSTALLIEREN.bat doppelklicken** (Autostart), dann Assigned Access wie unter Weg A klicken.

## Nur Entwickler-PC (D:\VetStation)
Diese Punkte gelten **nicht** für den Praxis-PC und sind dort nicht nötig:
- Später, mit Rust-Toolchain: **Tauri-MSI** (`D:\VetStation\tauri-shell\`) als 1-Klick-Appliance
  mit signiertem Auto-Update.
