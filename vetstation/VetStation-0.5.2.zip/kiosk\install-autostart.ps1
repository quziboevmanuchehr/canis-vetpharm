<#
  install-autostart.ps1 - Autostart einrichten (Par.8): registriert eine geplante Aufgabe, die
  VetStation beim Anmelden automatisch im Kiosk startet (mit Watchdog). Fuer den dedizierten
  Praxis-PC zusaetzlich Autologin einrichten (siehe assigned-access.md).

  Aufruf (VOLLSTAENDIGER Pfad - ein relativer Pfad schlaegt fehl, weil PowerShell in
  C:\Windows\System32 startet):
      powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\install-autostart.ps1"
  Entfernen:
      powershell -ExecutionPolicy Bypass -File "C:\VetStation\kiosk\install-autostart.ps1" -Remove
  Adminrechte holt sich das Skript ab 0.5.1 selbst (UAC-Abfrage bestaetigen).
#>
param([switch]$Remove, [int]$Port = 8770)

# --- Adminrechte sicherstellen -------------------------------------------------
# Register-/Unregister-ScheduledTask mit -RunLevel Highest braucht Adminrechte. Ohne diesen
# Guard brach das Skript mit "Zugriff verweigert" (0x80070005) ab - beim Entfernen sogar
# lautlos, weil dort -ErrorAction SilentlyContinue steht.
$__id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
  $__args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'), '-Port', $Port)
  if ($Remove) { $__args += '-Remove' }
  try {
    Start-Process powershell.exe -Verb RunAs -ArgumentList $__args
  } catch {
    Write-Warning "Adminrechte noetig. Bitte PowerShell rechtsklicken -> 'Als Administrator ausfuehren'."
    Start-Sleep 6
  }
  exit
}

$TaskName = 'VetStation-Kiosk'
$Root = Split-Path $PSScriptRoot -Parent
$Launch = Join-Path $PSScriptRoot 'launch-kiosk.ps1'

if ($Remove) {
  # Ehrliche Rueckmeldung statt lautlosem Schlucken: sagen, ob wirklich etwas entfernt wurde.
  $vorhanden = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  if (-not $vorhanden) {
    Write-Host "Autostart '$TaskName' war nicht registriert - nichts zu entfernen."
    return
  }
  try {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop
    Write-Host "Autostart '$TaskName' entfernt."
  } catch {
    Write-Warning "Autostart '$TaskName' konnte NICHT entfernt werden: $($_.Exception.Message)"
  }
  return
}

$action  = New-ScheduledTaskAction -Execute 'powershell.exe' `
  -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Launch`" -Port $Port -Watchdog"
$trigger = New-ScheduledTaskTrigger -AtLogOn
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Hours 0)
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Write-Host "Autostart '$TaskName' registriert (startet beim Anmelden, mit Watchdog)."
Write-Host "Fuer echten Appliance-Betrieb zusaetzlich Autologin + Assigned Access einrichten -> kiosk\assigned-access.md"
