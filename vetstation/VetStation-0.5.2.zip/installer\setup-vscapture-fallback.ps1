<#
  setup-vscapture-fallback.ps1 - Richtet den VSCapture-Fallback ein (falls VetStations HL7-Listener
  am Geraet nicht direkt greift). VSCapture (Open Source) empfaengt den Mindray-HL7-Strom und schreibt
  eine CSV, die VetStation live liest.

  Was es tut (transparent):
   1) prueft, ob .NET 8 Runtime vorhanden ist (sonst Hinweis + Link),
   2) laedt VSCaptureCLIv1.008Binary.zip (~1 MB) von GitHub und entpackt nach <Root>\vscapture,
   3) legt start-vscapture.bat an (startet den HL7-Listener auf Port 4601),
   4) erinnert daran, den 'vscapture'-Adapter in bridge\config\devices.json zu aktivieren.

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\setup-vscapture-fallback.ps1
#>
param(
  [string]$Root = (Split-Path $PSScriptRoot -Parent),
  [int]$Port = 4601
)
$ErrorActionPreference = 'Stop'
$dir = Join-Path $Root 'vscapture'
$zipUrl = 'https://github.com/xeonfusion/VSCaptureCLI/raw/main/VSCaptureCLIv1.008Binary.zip'

Write-Host "== VSCapture-Fallback einrichten =="

# 1) .NET 8 pruefen
$hasNet8 = $false
try {
  $rts = & dotnet --list-runtimes 2>$null
  if ($rts -and ($rts | Select-String 'Microsoft.NETCore.App 8\.')) { $hasNet8 = $true }
} catch {}
if ($hasNet8) { Write-Host ".NET 8 Runtime: vorhanden." }
else {
  Write-Warning ".NET 8 Runtime NICHT gefunden. Bitte installieren: https://dotnet.microsoft.com/download/dotnet/8.0  (.NET Runtime 8.0)"
  Write-Host "Danach dieses Skript erneut ausfuehren."
}

# 2) VSCapture laden + entpacken
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$zip = Join-Path $env:TEMP 'VSCaptureCLIv1.008Binary.zip'
Write-Host "Lade VSCapture (VSCaptureCLIv1.008Binary.zip, ~1 MB) von GitHub ..."
try {
  Invoke-WebRequest -Uri $zipUrl -OutFile $zip -UseBasicParsing
  Expand-Archive -Path $zip -DestinationPath $dir -Force
  Write-Host "VSCapture entpackt nach: $dir"
} catch {
  Write-Warning "Download/Entpacken fehlgeschlagen ($($_.Exception.Message))."
  Write-Host "Manuell: $zipUrl herunterladen und nach $dir entpacken."
}

# 3) Start-Klick anlegen (CSV landet im Arbeitsverzeichnis -> hierher wechseln)
$bat = @"
@echo off
cd /d "%~dp0"
REM Mindray-HL7-Listener auf Port $Port -> schreibt MRayDataExport.csv in diesen Ordner.
dotnet VSCaptureMRay.dll -mode 2 -serverport $Port -interval 1 -export 1
pause
"@
Set-Content -Encoding ASCII (Join-Path $dir 'start-vscapture.bat') -Value $bat

Write-Host ""
Write-Host "FERTIG. Naechste Schritte:"
Write-Host "  1) Am Monitor 'Send HL7 / EMR' -> Serveradresse = PC-IP, Port $Port (siehe docs\MINDRAY-HL7.md)."
Write-Host "  2) In $dir die Datei 'start-vscapture.bat' doppelklicken (schreibt MRayDataExport.csv)."
Write-Host "  3) In bridge\config\devices.json den 'vscapture'-Adapter auf \"enabled\": true setzen"
Write-Host "     (file = $dir\MRayDataExport.csv) und VetStation/Watchdog neu starten."
