'use strict';
/*
 * monitor-eingabe-test.js — die Werteeingabe am virtuellen Monitor (Befund 21.08.2026).
 *
 * WARUM ES DIESE DATEI GIBT:
 * Aus der Praxis gemeldet: "wenn ich 87 eingeben moechte nimmt erstmal 7 und danach 8".
 * Nachgestellt im Browser, Ziffern EINZELN mit Pause getippt:
 *
 *     getippt 8 ... 7   ->   im Feld steht 7      (die 8 war weg)
 *
 * Schnell hintereinander getippt faellt es NICHT auf - deshalb war der Schnelltest vom
 * Vortag gruen. Das ist die eigentliche Lehre dieses Befunds: eine Eingabepruefung, die
 * schneller tippt als ein Mensch, prueft einen Fall, den es nicht gibt.
 *
 * ZWEI SCHICHTEN URSACHE:
 *   1. renderMonValues() baut #monTiles bei jedem Tastendruck ueber innerHTML neu auf.
 *      Dagegen gibt es fokusMerken()/fokusZurueck(). Deren Kommentar behauptet seit jeher,
 *      die Schreibmarke werde gemerkt und zurueckgesetzt - sie wurde es NIE: bei
 *      type="number" liefert selectionStart laut HTML-Norm null (gemessen: es wirft nicht
 *      einmal, es gibt null zurueck), und setSelectionRange wirft. Die Absicherung war von
 *      Anfang an wirkungslos, nur unsichtbar.
 *   2. Sichtbar wurde sie durch das Antippen-waehlt-aus vom 21.08.2026: fokusZurueck() ruft
 *      focus() auf dem NEUEN Knoten, das loest focusin aus, und das select() darin markierte
 *      den ganzen Wert - der naechste Anschlag ersetzte ihn.
 *
 * WAS DIESER TEST KANN UND WAS NICHT:
 * Eine Schreibmarke hat nur ein echter Browser. Geprueft wird deshalb (a) das Verhalten von
 * nurZahl() wirklich ausgefuehrt und (b) an der Quelle, dass die drei Bauteile stehen, ohne
 * die der Fehler zurueckkommt. Die Messung am laufenden Browser steht im Freigabetext.
 */

var fs = require('fs');
var pfad = require('path');
var WURZEL = pfad.join(__dirname, '..');

var geprueft = 0, fehler = 0;
function pruef(name, bedingung, hinweis) {
  geprueft++;
  if (bedingung) { console.log('  ok   ' + name); return; }
  fehler++;
  console.log('  FEHL ' + name + (hinweis ? '  -> ' + hinweis : ''));
}

var HTML = fs.readFileSync(pfad.join(WURZEL, 'ui/app/index.html'), 'utf8');
/* Quellpruefungen lesen sonst die Kommentare mit - in diesem Baum schon zweimal die
 * Ursache eines Tests, der das Gegenteil dessen meldete, was er meinte. */
var CODE = HTML.replace(new RegExp('/\\*[\\s\\S]*?\\*/', 'g'), ' ');

console.log('\n1  nurZahl() - was der Browser am Zahlenfeld erledigt hat');
(function () {
  var von = HTML.indexOf('function nurZahl(roh){');
  pruef('nurZahl() gibt es', von >= 0);
  if (von < 0) return;
  var bis = HTML.indexOf('\n}', von);
  var quelle = HTML.slice(von, bis + 2);
  /* Die Deklaration ausfuehren und DANN zurueckgeben - in Klammern gesetzt waere sie ein
   * Ausdruck und der Name nirgends gebunden. */
  var nurZahl = new Function(quelle + '; return nurZahl;')();

  [
    ['87', '87', 'die gewoehnliche Eingabe bleibt unangetastet'],
    ['abc', '', 'Buchstaben - type=text faengt sie nicht mehr ab, also muss es hier passieren'],
    ['12a3', '123', 'Buchstabe mittendrin'],
    ['1,37', '1.37', 'Komma der deutschen Zehnertastatur; type=number hat es VERWORFEN'],
    ['2..5', '2.5', 'nur EIN Dezimalpunkt'],
    ['1,2,3', '1.23', 'zweites Komma faellt weg, die Ziffer bleibt'],
    ['-5', '5', 'Minus: es gibt keinen negativen Blutdruck und keine negative Frequenz'],
    ['', '', 'leer bleibt leer - das ist "kein Wert", nicht "null"'],
    ['0.5', '0.5', 'fuehrende Null bleibt'],
    ['200', '200', 'dreistellig']
  ].forEach(function (f) {
    pruef('nurZahl("' + f[0] + '") = "' + f[1] + '" (' + f[2] + ')',
      nurZahl(f[0]) === f[1], 'bekommen: "' + nurZahl(f[0]) + '"');
  });
})();

console.log('\n2  Die drei Bauteile, ohne die der Ziffern-Dreher zurueckkommt');
(function () {
  /*
   * (a) type="number" ist der Grund, warum die Schreibmarke nicht lesbar war. Steht es
   *     wieder an einem Wertefeld, ist die ganze Kette wieder blind.
   */
  /*
   * Geprueft werden die ZWEI Bauer der sichtbaren Wertefelder, nicht alle Zahlenfelder der
   * Anwendung. Das Gewichtsfeld und die verborgenen Spiegel unter #monInputs (display:none,
   * gemessen 0x0) duerfen type="number" bleiben: in die tippt niemand waehrend eines
   * Neuaufbaus, und dort ist die Browser-Pruefung ein Gewinn statt eines Hindernisses.
   */
  ['function wertFeld(p, wert, klasse){', 'function wertFeldPaar(iv){'].forEach(function (kopf) {
    var von = CODE.indexOf(kopf);
    var quelle = von >= 0 ? CODE.slice(von, CODE.indexOf('\n}', von)) : '';
    pruef(kopf.split('(')[0].replace('function ', '') + ' baut KEIN type="number" mehr',
      von >= 0 && quelle.indexOf('type="number"') < 0,
      'bei type=number gibt selectionStart null zurueck - fokusMerken() ist dann wirkungslos');
  });
  pruef('die Wertefelder sind type="text" mit inputmode="decimal"',
    CODE.indexOf('type="text" inputmode="decimal"') >= 0,
    'inputmode haelt das Zahlenfeld am Telefon und am Touchschirm');

  /* (b) Die Fahne, die echten Fokus von wiederhergestelltem unterscheidet. */
  pruef('fokusStelltZurueck gibt es', CODE.indexOf('var fokusStelltZurueck') >= 0);
  pruef('fokusZurueck() setzt die Fahne',
    CODE.indexOf('fokusStelltZurueck=true') >= 0 && CODE.indexOf('fokusStelltZurueck=false') >= 0);
  pruef('fokusZurueck() nimmt die Fahne auch bei einem Fehler zurueck (finally)',
    CODE.indexOf('finally { fokusStelltZurueck=false; }') >= 0,
    'ohne finally bliebe sie nach einer Ausnahme stehen und das Antippen waehlte nie wieder aus');
  pruef('der focusin-Zweig fragt die Fahne AB',
    CODE.indexOf('if(fokusStelltZurueck) return;') >= 0,
    'ohne diese Zeile markiert jeder Tastendruck den bisherigen Wert neu');

  /* (c) Ohne Position ans ENDE, nie an den Anfang - sonst wandert jede Ziffer nach vorn. */
  pruef('ohne gemerkte Position wird ans Ende gesetzt, nicht an den Anfang',
    CODE.indexOf('String(n.value||\'\').length') >= 0,
    'an Position 0 landet die zweite Ziffer VOR der ersten - genau der gemeldete Befund');

  /* (d) Der Eingabezweig muss nurZahl() wirklich benutzen. */
  pruef('der input-Zweig raeumt mit nurZahl() auf',
    CODE.indexOf('roh=nurZahl(inp.value)') >= 0);
})();

console.log('\n3  Die Kachel waechst mit der Stellenzahl');
(function () {
  var von = HTML.indexOf('function feldBreite(v){');
  pruef('feldBreite() gibt es', von >= 0);
  if (von < 0) return;
  var quelle = HTML.slice(von, HTML.indexOf('\n}', von) + 2);
  var feldBreite = new Function(quelle + '; return feldBreite;')();
  pruef('leer bekommt die Mindestbreite', feldBreite('') === 2.2);
  pruef('dreistellig ist breiter als zweistellig', feldBreite(140) > feldBreite(87));
  pruef('vierstellig ist breiter als dreistellig', feldBreite(1000) > feldBreite(140));
  pruef('200 passt in seine Breite', feldBreite(200) >= 3.4,
    'drei Ziffern plus Luft fuer die Schreibmarke');
  /* Die breite Kachel fuer viele Stellen - der Blutdruck 200/140 war der Anlass. */
  pruef('es gibt die breite Kachel (mt-breit) ab sieben Zeichen',
    CODE.indexOf('mt-breit') >= 0 && CODE.indexOf('zeichen>=7') >= 0,
    '200/140 sind sieben Zeichen; davor war die Haelfte der Zahl abgeschnitten');
})();

console.log('\n4  Cockpit-Hoehe: die Kurvenflaeche wird gemessen, nicht geraten');
(function () {
  /*
   * Befund 21.08.2026: "beim gross und klein machen sieht danach alles komisch klein aus".
   * Gemessen bei 1920x1080 nach einmal Vollbild ein und aus: 250 px vorher, 224 px nachher.
   * Die Pruefung "passt die Spalte noch?" ueber scrollHeight ist baulich blind, weil die
   * Bloecke IN der Spalte eigene Rollwege haben - sie melden "passt", auch zusammengequetscht.
   */
  pruef('cockpitHoehe() misst die Hoehe von .mon-screen',
    CODE.indexOf("el.querySelector('.mon-screen')") >= 0);
  pruef('und vergleicht sie mit den 250 px, die ck-eng fest zusagt',
    CODE.indexOf('getBoundingClientRect().height < 250') >= 0,
    'die Betriebsart FUER kleine Fenster darf nie mehr Kurve zeigen als die fuer grosse');
  pruef('im Vollbild wird nicht geprueft',
    CODE.indexOf("if(document.body.classList.contains('mon-voll')) return;") >= 0,
    'dort soll der Schirm gross sein - ck-eng wuerde ihm die gewonnene Hoehe nehmen');

  var ckEng = CODE.indexOf('.ck-eng .ck-schirm .mon-screen');
  pruef('ck-eng sagt dem Schirm wirklich 250 px zu',
    ckEng >= 0 && CODE.slice(ckEng, ckEng + 160).indexOf('250px') >= 0,
    'stimmt die Zahl im Stylesheet nicht mehr mit der Schwelle ueberein, schwingt es');

  /* Reihenfolge: erst der billige Test, dann der teure - und die Messung ganz zuletzt,
   * damit sie an einem fertig gesetzten Layout misst. */
  var links = CODE.indexOf('links.scrollHeight>links.clientHeight+8');
  var schirm = CODE.indexOf("el.querySelector('.mon-screen')");
  pruef('die Schirmmessung steht NACH der Spaltenmessung', links >= 0 && schirm > links,
    'davor gemessen haette sie ein Layout gesehen, das noch gar nicht gesetzt ist');
})();

console.log('\n5  Das Herzmodell ist aus dem EKG-Untermenue heraus (21.08.2026)');
(function () {
  /* Abbestellt vom Praxisinhaber. Hier steht nur die Naht zur Oberflaeche; die Geometrie
   * und ihr Verbleib sind in tools/herz3d-test.js Block 8 begruendet. */
  ['ekgHerzBtn', 'id="ekgHerz"', 'herzOeffnen', 'herzZeichne', 'shared/herz3d.js'].forEach(function (w) {
    pruef('index.html kennt "' + w + '" nicht mehr', HTML.indexOf(w) < 0);
  });
  /* Und das, was NICHT mitgehen durfte: das 3D-Tiermodell fuer die Elektrodenlage. */
  pruef('das 3D-TIERmodell (Elektroden anlegen) ist unangetastet',
    HTML.indexOf('shared/tier3d.js') >= 0 && HTML.indexOf('ekgAnlegenBtn') >= 0,
    'es ist ein anderes Modell und war nicht gemeint');
})();

console.log('\n' + (fehler ? 'FEHLGESCHLAGEN' : 'ALLE GRUEN') + ': ' +
  (geprueft - fehler) + ' von ' + geprueft + ' Pruefungen.');
process.exit(fehler ? 1 : 0);
