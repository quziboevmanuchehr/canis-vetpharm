'use strict';
/*
 * regeln-test.js — prueft die beiden REGELDATEIEN, die die Mandantentrennung tragen
 * (installer/firebase-rtdb-rules.json und installer/firestore-rules.txt).
 *
 * WARUM ES DIESEN TEST GIBT
 * Bis heute prueft KEIN anderer Test im Projekt eine Regeldatei. Sie ist aber die einzige Stelle, an
 * der die Trennung zwischen zwei Praxen tatsaechlich stattfindet: der Quellcode kann sie nicht
 * herstellen und nicht ersetzen. Und sie ist die einzige Datei, deren Aenderung SOFORT und ohne
 * Update auf jede bereits ausgelieferte Station wirkt. Ein Tippfehler hier ist entweder ein
 * offener Datenbestand aller Praxen oder ein Totalausfall aller Praxen — dazwischen liegt wenig.
 *
 * WAS SICH AM 30.07.2026 GEAENDERT HAT — UND WARUM
 * Die erste Fassung dieses Tests hat die Regeln nur als Struktur angesehen: "steht hier irgendeine
 * Zahl?", "ist der Bestandsblock wortgleich?". Damit hat sie den schwersten Fehler der Regeldatei
 * NICHT gesehen: zwei Felder (herkunft, top) trugen im echten Datensatz OBJEKTE, standen aber unter
 * einer Regel, die nur Text, Zahl oder Wahrheitswert erlaubte. Weil der Mehrpfad-PATCH atomar ist,
 * haette JEDER 5-Hz-Schreibvorgang der neuen Station abgelehnt — samt aller Vitalwerte, in allen
 * Praxen, binnen einer Minute. Eine Pruefung, die nur die Regeln liest, kann das nicht finden.
 *
 * DESHALB PRUEFT DIESER TEST JETZT GEGEN DIE ECHTEN DATEN:
 *   • er BAUT mit CloudPublisher._buildSnapshot (bridge/src/cloud.js) den echten Saal-Datensatz,
 *   • er BAUT mit tafel.js die echte Tafel-Kopfzeile, Kachel und Geraetezeile — auch in ihrer
 *     kargsten Form (kein Saalname, kein Alter, kein Zeitstempel). tafel.js laesst ein leeres Feld
 *     entweder gar nicht erst entstehen oder schreibt null hinein; beides endet in der Realtime
 *     Database beim FEHLENDEN Schluessel, und darauf ein Pflichtfeld zu setzen ist die Ablehnung
 *     des ganzen atomaren Koerpers,
 *   • und haelt JEDES Feld gegen die Regel, die es treffen wird: Typ, Laenge, Pflichtfelder.
 *   • Die Kappungen im Code werden nicht abgelesen, sondern GEMESSEN (tafel.kappe/text/schluessel
 *     werden mit 5000 Zeichen aufgerufen). Eine Regelgrenze UNTER einer Kappung ist keine Sperre,
 *     sondern eine Falle: der Code schreibt dann etwas, das die Datenbank ablehnt.
 *
 * WAS DIESER TEST NICHT KANN, ausdruecklich benannt:
 *   • Er beweist nicht, WIE Firebase eine Regel auswertet. Ob ein $-Platzhalter auch fuer
 *     namentlich genannte Geschwister gilt und ob das ".validate" eines Vorfahren bei einem tiefen
 *     Schreibvorgang mitspricht, ist ungemessen (dafuer ist tools/regel-messung.js gegen ein
 *     Wegwerf-Konto gedacht).
 *     UND DER TEST RECHNET NICHT UEBERALL GLEICH — das stand hier bis 30.07.2026 falsch drin
 *     ("der Test rechnet mit der SCHLECHTEREN Annahme", pauschal). Richtig ist:
 *       - Struktur-, Kollisions- und Bandpruefungen (Abschnitte 7 bis 11) rechnen mit der
 *         SCHLECHTEREN Annahme: sie halten jede Auffangkette gegen jeden namentlichen Zweig
 *         derselben Tiefe, als gaelten beide gleichzeitig.
 *       - Der FORMPRUEFER (regelKind, pruefeForm, wirksameRegel, Abschnitt 12) rechnet mit der
 *         BESSEREN: er nimmt fuer ein namentlich genanntes Kind NUR dessen Regel. Anders geht es
 *         nicht, ohne jede Meldung zu verdoppeln — aber es heisst, dass er eine namentliche
 *         Grenze, die ENGER ist als die Auffangkette daneben, nicht meldet. Aufgefangen wird
 *         dieser Fall heute allein von der unteren Bandgrenze in Abschnitt 7.
 *     Zum Vergleich: tools/regeln-vertrag-test.js wertet BEIDE Regeln aus und sagt das in seiner
 *     NICHT-GEPRUEFT-Liste. Wer diese Luecke schliessen will, prueft dort nach, nicht hier.
 *   • Sein Formpruefer versteht nur die drei Muster, die in dieser Regeldatei vorkommen:
 *     "newData.isString() ? <Grenze> : <Rest>", eine reine Typpruefung und hasChildren([...]).
 *     Er ist kein Auswerter fuer die Regelsprache und behauptet das nicht.
 *   • Ein ".validate", das gar nicht da ist, gilt in Firebase als ERLAUBT. Eine fehlende Regel kann
 *     also Bytes kosten, niemals die Ueberwachung — der Test zaehlt sie deshalb als Lueckenhinweis
 *     und nicht als Ablehnungsrisiko.
 *
 * OHNE NETZ, auch mit cloud.js. Der Publisher wird nur GEBAUT und _buildSnapshot aufgerufen;
 * start() laeuft nie, es wird kein Token geholt und nichts geschrieben. Die Anmeldedatei ist auf
 * einen Namen im Temp-Verzeichnis gesetzt, den niemand liest oder anlegt.
 *
 * JEDE PRUEFUNG SAGT IM FEHLERFALL, WELCHE GEFAHR SIE ABWENDET. Das ist Absicht: wer diese Datei
 * spaeter rot macht, soll nicht nach dem Grund suchen muessen.
 *
 * Start: node tools/regeln-test.js      (laeuft auch in `node tools/alle-tests.js`)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const RTDB_DATEI = path.join(__dirname, '..', 'installer', 'firebase-rtdb-rules.json');
const FS_DATEI = path.join(__dirname, '..', 'installer', 'firestore-rules.txt');

const AUTH = 'auth != null && auth.uid === $praxis';
const FENSTER = 'newData.val() <= now && newData.val() > now - 60000';
const NEUE_ZWEIGE = ['tafel', 'saele', 'verbund'];

/*
 * WELCHE ETAPPE WIRD GEPRUEFT.
 * Etappe 1: das ".write" steht auf /live/$praxis und kaskadiert nach unten. Das MUSS so sein —
 *   sein Entzug ist eine Verscharfung, die eine ausgelieferte 1.0.3 zuerst ueberleben muss.
 * Etappe 2: das ".write" verschwindet dort und steht je Teilbaum. Erst dann wird die
 *   Unveraenderlichkeit des Narkoseprotokolls echt (heute ist sie eine Absichtserklaerung).
 * Wer Etappe 2 baut, setzt diese Zahl auf 2 — dann kehren sich die beiden Pruefungen um, statt dass
 * eine richtige Aenderung an einem Test scheitert, dessen Fehlertext ihr Patientengefahr vorwirft.
 */
const ETAPPE = 1;

/*
 * ERWARTETE KINDMENGE UNTER /live/$praxis. Jeder zusaetzliche Schluessel — insbesondere jeder
 * $-Platzhalter — wirkt auf die FLACHE Ebene und damit auf jede ausgelieferte 1.0.3.
 */
const PRAXIS_KINDER = ['meta', 'patients', 'protokoll', 'saele', 'tafel', 'verbund'];

/*
 * WO EINE REGEL ETWAS ABWEISEN DARF statt nur zu begrenzen: drei ARTEN an FUENF Stellen (sid und
 * sv kommen in tafel und in verbund je einmal vor).
 * Jede andere Wertregel in den neuen Zweigen MUSS Struktur durchlassen (": true"), sonst ist sie
 * im schlechten Fall der Totalausfall der neuen Station — genau daran hing der toedliche Befund.
 * Wer hier einen Pfad ergaenzt, schuldet die Begruendung als Text UND einen Beleg am echten
 * Datensatz (Abschnitt 12), sonst ist der Eintrag nur eine Ausrede.
 */
const STRENG_ERLAUBT = {
  'saele/$station/patients/$key/vitals/$feld':
    'cloud.js:_buildSnapshot() laesst hier nachweislich nur Zahl, Text oder Wahrheitswert durch (nibp ist in '
    + 'mergePatients schon flachgezogen). Die Formpruefung unten haelt das am echten Snapshot nach.',
  'tafel/$station/meta/sid':
    'Der Wert MUSS gleich dem Pfadsegment sein — ein Objekt kann das nie sein.',
  'verbund/lan/$station/sid':
    'Der Wert MUSS gleich dem Pfadsegment sein — ein Objekt kann das nie sein.',
  'tafel/$station/meta/sv':
    'Serverplatzhalter. Genau das Abweisen einer selbst gewaehlten Zahl ist der Zweck dieser Regel: '
    + 'sonst sieht ein abgestuerzter OP-Saal fuer immer "vor 0 s" aus.',
  'verbund/lan/$station/sv':
    'Serverplatzhalter, siehe tafel/$station/meta/sv.',
};

/*
 * ZULAESSIGES BAND JE ZWEIG (untere/obere Grenze fuer jede Wertlaenge).
 * Untere Grenze: keine Regel darf enger sein als die im Code GEMESSENE Kappung — sonst schreibt der
 *   Code etwas, das die Datenbank ablehnt, und nimmt den ganzen atomaren Koerper mit.
 * Obere Grenze: ein einziger sehr langer Text zieht das projektweite Kontingent ALLER Praxen leer.
 * saele darf mehr als tafel, weil dort die Kurven liegen und weil cloud.js die gemeinsame Kappung
 * noch nicht anwendet; tafel bleibt eng, weil jede offene Web-Ansicht sie dauerhaft abonniert.
 */
const BAND = {
  tafel: { min: null, max: 400 },      // min wird unten auf die gemessene Kappung gesetzt
  verbund: { min: null, max: 400 },
  saele: { min: 2000, max: 12000 },
};

let pass = 0, fail = 0;
/*
 * gefahr = der Satz, der im Fehlerfall dasteht. Nicht "Bedingung verletzt", sondern was in einer
 * Praxis passiert, wenn die Regel so ausgeliefert wird.
 */
function ok(n, c, gefahr, extra) {
  if (c) { pass++; console.log('  ✓ ' + n); return; }
  fail++;
  console.log('  ✗ ' + n);
  console.log('      GEFAHR: ' + gefahr);
  if (extra) console.log('      gefunden: ' + extra);
}

/*
 * Die Firebase-Konsole nimmt Kommentare in den Regeln an, JSON.parse nicht. Der Entferner muss
 * zeichenkettenbewusst sein: in den Regelausdruecken stehen Schraegstriche (.matches(/^[0-3]$/)),
 * und ein naiver Entferner wuerde daraus einen Zeilenkommentar machen.
 */
function ohneKommentare(text) {
  let out = '', i = 0, inStr = false;
  while (i < text.length) {
    const c = text[i], d = text[i + 1];
    if (inStr) {
      if (c === '\\') { out += c + (d === undefined ? '' : d); i += 2; continue; }
      if (c === '"') inStr = false;
      out += c; i++; continue;
    }
    if (c === '"') { inStr = true; out += c; i++; continue; }
    if (c === '/' && d === '/') { while (i < text.length && text[i] !== '\n') i++; continue; }
    if (c === '/' && d === '*') {
      i += 2;
      while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++;
      i += 2; continue;
    }
    out += c; i++;
  }
  return out;
}

// Kinder eines Regelknotens = alle Schluessel, die keine Regel (".read"/".write"/".validate") sind.
function kinder(node) {
  if (!node || typeof node !== 'object') return [];
  return Object.keys(node).filter((k) => k[0] !== '.');
}
function istBlatt(node) { return kinder(node).length === 0; }
/*
 * Jeder Zugriff auf einen Regelausdruck geht durch txt(): ein fehlender Knoten oder ein fehlendes
 * ".validate" muss ein BEFUND mit Gefahrentext sein, nie ein Absturz. Vorher starb dieser Test bei
 * einem fehlenden ".validate" an "Cannot read properties of undefined" — die 35 folgenden
 * Pruefungen liefen dann nie, und der Leser bekam einen Stapelabzug statt der Erklaerung.
 */
function txt(x) { return typeof x === 'string' ? x : ''; }

/*
 * grenzeIn(ausdruck) — die groesste Laengengrenze fuer den WERT, oder null.
 *
 * ABSICHTLICH NUR "newData.val().length <= N". Eine Grenze auf einem SCHLUESSEL ("$key.length <=
 * 200") begrenzt den Wert nicht um ein Byte; die fruehere Fassung zaehlte sie mit und hielt damit
 * ein Blatt fuer gedeckelt, dessen Wert unbegrenzt war.
 */
function grenzeIn(ausdruck) {
  const s = txt(ausdruck);
  const re = /newData\.val\(\)\.length\s*<=\s*(\d+)/g;
  let m, max = null;
  while ((m = re.exec(s)) !== null) { const n = Number(m[1]); if (max === null || n > max) max = n; }
  return max;
}
// Grenze auf dem SCHLUESSEL ($key/$station/$geraet/$kanal), getrennt gefuehrt.
function schluesselGrenzeIn(ausdruck) {
  const m = /\$\w+\.length\s*<=\s*(\d+)/.exec(txt(ausdruck));
  return m ? Number(m[1]) : null;
}
// Jeden Knoten mit seinem Pfad besuchen.
function begehen(node, pfad, fn) {
  fn(node, pfad);
  kinder(node).forEach((k) => {
    const kind = node[k];
    if (kind && typeof kind === 'object') begehen(kind, pfad.concat([k]), fn);
  });
}
function knotenAn(wurzel, segmente) {
  let n = wurzel;
  for (const s of segmente) { if (!n || typeof n !== 'object') return null; n = n[s]; }
  return n;
}
/*
 * stabil(x) — Vergleichstext, bei dem die REIHENFOLGE der Schluessel keine Rolle spielt.
 * Grund: die Wortgleichheits-Pruefung des Bestands trug den schaerfsten Fehlertext dieser Datei
 * ("Selbstabschaltung aller Praxen"). Eine reine Umsortierung ist inhaltlich nichts — sie darf
 * diesen Text nicht ausloesen, sonst bringt der erste Falschalarm die Pruefung in Verruf, die
 * spaeter wirklich zaehlt.
 */
function stabil(x) {
  if (x === null || typeof x !== 'object') return JSON.stringify(x);
  if (Array.isArray(x)) return '[' + x.map(stabil).join(',') + ']';
  return '{' + Object.keys(x).sort().map((k) => JSON.stringify(k) + ':' + stabil(x[k])).join(',') + '}';
}

/* ----------------------------------------------------------------------------
 * Der Formpruefer: was macht diese Regel mit DIESEM Wert?
 * -------------------------------------------------------------------------- */

/*
 * Wie Firebase ein Kind aufloest: namentlich genannt hat Vorrang, sonst der $-Platzhalter.
 * DAS IST DIE BESSERE (= guenstigere) DER BEIDEN UNGEMESSENEN ANNAHMEN, und der Kopf dieser Datei
 * benennt sie als solche. Wer sie umdreht, muss hier BEIDE Regeln auswerten und die engere gewinnen
 * lassen — dann meldet der Formpruefer allerdings jede Auffangkette doppelt.
 */
function regelKind(regel, schluessel) {
  if (!regel || typeof regel !== 'object') return null;
  if (schluessel[0] !== '.' && Object.prototype.hasOwnProperty.call(regel, schluessel)) return regel[schluessel];
  const p = kinder(regel).filter((k) => k[0] === '$');
  return p.length ? regel[p[0]] : null;
}
// Der Sonst-Zweig von "newData.isString() ? A : B", oder null wenn es kein solches Muster ist.
function sonstZweig(ausdruck) {
  const m = /^\s*newData\.isString\(\)\s*\?\s*([^?]*?)\s*:\s*(.*?)\s*$/.exec(txt(ausdruck));
  return m ? m[2] : null;
}
// "!newData.isString()" ist das GEGENTEIL einer Einzelwert-Forderung und darf nicht mitgezaehlt werden.
function ohneNegation(ausdruck) { return txt(ausdruck).replace(/!\s*newData\.isString\(\)/g, 'true'); }
function fordertEinzelwert(ausdruck) {
  return /newData\.is(String|Number|Boolean)\s*\(\s*\)/.test(ohneNegation(ausdruck));
}
// Pflichtfelder aus hasChildren([...]) — nur wenn sie mit UND verknuepft sind (kein "||" im Ausdruck).
function pflichtfelder(ausdruck) {
  const s = txt(ausdruck);
  if (!s || s.indexOf('||') >= 0) return [];
  const out = [];
  const re = /hasChildren\(\[([^\]]*)\]\)/g;
  let m;
  while ((m = re.exec(s)) !== null) {
    m[1].split(',').forEach((t) => { const v = t.trim().replace(/^['"]|['"]$/g, ''); if (v) out.push(v); });
  }
  return out;
}
/*
 * passt(wert, ausdruck) — null wenn der Wert durchgeht, sonst der Grund der Ablehnung.
 * Kein Auswerter der Regelsprache: nur Typ und Laenge, und nur die Muster, die hier vorkommen.
 */
function passt(wert, ausdruck) {
  // Der Wahrheitswert false ist KEINE fehlende Regel, sondern die schaerfste: er weist alles ab.
  if (ausdruck === false) return 'die Regel ist der Wahrheitswert false und weist ALLES ab';
  if (typeof ausdruck !== 'string') return null;          // keine Regel (bzw. true) = erlaubt
  if (/^\s*false\s*$/.test(ausdruck)) return 'die Regel steht auf "false" und weist ALLES ab';
  const sonst = sonstZweig(ausdruck);
  const struktur = (wert !== null && typeof wert === 'object');
  if (struktur) {
    if (sonst !== null) {
      return sonst === 'true' ? null
        : 'die Regel weist Objekte und Listen ab (Sonst-Zweig "' + sonst + '")';
    }
    if (fordertEinzelwert(ausdruck)) return 'die Regel verlangt einen Einzelwert, der Wert ist eine Struktur';
    return null;
  }
  if (typeof wert === 'string') {
    if (sonst === null && fordertEinzelwert(ausdruck) && !/newData\.isString\s*\(\s*\)/.test(ohneNegation(ausdruck))) {
      return 'die Regel verlangt Zahl oder Wahrheitswert, der Wert ist eine Zeichenkette';
    }
    const g = grenzeIn(ausdruck);
    if (g !== null && wert.length > g) return 'die Zeichenkette ist ' + wert.length + ' Zeichen lang, die Grenze ist ' + g;
    return null;
  }
  if (typeof wert === 'number' || typeof wert === 'boolean') {
    if (sonst === null && /newData\.isString\s*\(\s*\)/.test(ohneNegation(ausdruck))
      && !/newData\.isNumber\s*\(\s*\)/.test(ausdruck) && !/newData\.isBoolean\s*\(\s*\)/.test(ausdruck)) {
      return 'die Regel verlangt eine Zeichenkette, der Wert ist eine Zahl bzw. ein Wahrheitswert';
    }
    return null;
  }
  return null;
}
/*
 * pruefeForm(wert, regel, pfad, befunde, ohneRegel) — laeuft den ECHTEN Datensatz und den Regelbaum
 * gleichzeitig ab.
 *
 * null und undefined werden uebersprungen: ein null-Wert loescht in der Realtime Database den
 * Schluessel, und ".validate" wird bei Loeschungen nicht ausgewertet. Genau deshalb ist ein
 * Pflichtfeld auf einem Feld, das leer sein kann, eine Ablehnung des ganzen Koerpers.
 */
function pruefeForm(wert, regel, pfad, befunde, ohneRegel) {
  if (wert === null || wert === undefined) return;
  let w = wert;
  let anmerkung = '';
  /*
   * Der Serverplatzhalter {".sv":"timestamp"} wird von der Datenbank VOR der Validierung zu einer
   * Zahl aufgeloest (Belegstelle im Kopf der Regeldatei: die Bestandsregel "sv": isNumber() geht
   * durch). Hier wird er deshalb als Zahl behandelt. Der Wert selbst — das 60-s-Fenster — ist mit
   * einem gefaelschten Zeitstempel nicht ohne Netz pruefbar; darum kuemmert sich Abschnitt 6.
   */
  if (w && typeof w === 'object' && !Array.isArray(w)
    && Object.keys(w).length === 1 && Object.keys(w)[0] === '.sv') {
    w = 0;
    anmerkung = ' (Serverplatzhalter, als Zahl behandelt)';
  }
  if (!regel || typeof regel !== 'object') {
    ohneRegel.push(pfad);
  } else {
    const v = regel['.validate'];
    const grund = passt(w, v);
    if (grund) befunde.push(pfad + anmerkung + ': ' + grund + '  [Regel: ' + JSON.stringify(v) + ']');
    pflichtfelder(v).forEach((p) => {
      const da = w && typeof w === 'object' && w[p] !== undefined && w[p] !== null;
      if (!da) {
        befunde.push(pfad + ': die Regel verlangt das Pflichtfeld "' + p
          + '", der ECHTE Datensatz hat es nicht  [Regel: ' + JSON.stringify(v) + ']');
      }
    });
  }
  if (w && typeof w === 'object') {
    Object.keys(w).forEach((k) => {
      if (k[0] === '.') return;
      pruefeForm(w[k], regelKind(regel, k), pfad + '/' + k, befunde, ohneRegel);
    });
  }
}

console.log('VetStation — Sicherheitsregeln (Realtime Database + Firestore)\n');

/* ============================================================================
 * 0) Die Datei muss ueberhaupt lesbar sein
 * ========================================================================== */
const rohText = fs.readFileSync(RTDB_DATEI, 'utf8');
const sauber = ohneKommentare(rohText);
let doc = null, parseFehler = null;
try { doc = JSON.parse(sauber); } catch (e) { parseFehler = e.message; }

console.log('Die Regeldatei ist gueltiges JSON:');
ok('firebase-rtdb-rules.json laesst sich nach Entfernen der Kommentare lesen', doc !== null,
  'Die Firebase-Konsole nimmt eine kaputte Regeldatei nicht an. Die Praxen laufen dann weiter mit '
  + 'dem ALTEN Regelsatz, waehrend alle glauben, die neuen Regeln seien in Kraft — die neuen '
  + 'Teilbaeume waeren damit vollstaendig unvalidiert.', parseFehler);
if (!doc) {
  console.log('\n1 von 1 FEHLGESCHLAGEN');
  process.exit(1);
}
const R = doc.rules || {};
ok('es gibt einen "rules"-Block', !!doc.rules && typeof doc.rules === 'object',
  'Ohne "rules" ist die Datei kein Regelsatz und die Konsole weist sie ab.');

/* ============================================================================
 * 0b) Die Kappungen im Code MESSEN, nicht ablesen
 * ========================================================================== */
console.log('\nDie Kappungen im Code sind messbar (gegen sie werden die Grenzen unten gesetzt):');
let tafelMod = null, tafelFehler = null;
try { tafelMod = require(path.join(__dirname, '..', 'bridge', 'src', 'tafel.js')); } catch (e) { tafelFehler = e.message; }
ok('bridge/src/tafel.js ist ladbar und liefert die gemeinsamen Kappungen',
  !!(tafelMod && typeof tafelMod.kappe === 'function' && typeof tafelMod.schluessel === 'function'
    && typeof tafelMod.text === 'function'),
  'Ohne die Kappungsfunktionen laesst sich nicht pruefen, ob eine Regelgrenze UNTER der Kappung im '
  + 'Code liegt. Genau das ist die Falle, an der ein einziges langes Geraetefeld (MSH-3 aus dem '
  + 'Gast-WLAN) den ganzen atomaren Koerper eines OP-Saals abweist — mit der Regel, die davor '
  + 'schuetzen sollte.', tafelFehler);

/*
 * cloud.js wird HIER geladen und nicht erst in Abschnitt 12: Abschnitt 3c braucht den Publisher,
 * um die Kappung des Saalnamens zu MESSEN, und das muss vor den Bestandspruefungen stehen.
 */
let cloudMod = null, cloudFehler = null;
try { cloudMod = require(path.join(__dirname, '..', 'bridge', 'src', 'cloud.js')); } catch (e) { cloudFehler = e.message; }

const LANG = 'x'.repeat(5000);
const KAPP_WERT = tafelMod ? String(tafelMod.kappe(LANG)).length : 200;
const KAPP_SCHLUESSEL = tafelMod ? String(tafelMod.schluessel(LANG)).length : 200;
const KAPP_TEXT = tafelMod ? String(tafelMod.text(LANG)).length : 40;
const KAPPUNG = Math.max(KAPP_WERT, KAPP_SCHLUESSEL);
BAND.tafel.min = KAPPUNG;
BAND.verbund.min = KAPPUNG;
console.log('    gemessen: kappe() ' + KAPP_WERT + ', schluessel() ' + KAPP_SCHLUESSEL
  + ', text() ' + KAPP_TEXT + '  ->  keine Grenze darf unter ' + KAPPUNG + ' liegen');
ok('die gemessenen Kappungen sind plausible Zahlen', KAPP_WERT > 0 && KAPP_SCHLUESSEL > 0 && KAPP_TEXT > 0
  && KAPP_WERT < 5000 && KAPP_SCHLUESSEL < 5000,
  'Kappt der Code gar nicht (5000 Zeichen kommen unveraendert zurueck), dann ist jede Grenze in '
  + 'dieser Regeldatei die EINZIGE Sperre — und jede Grenze darunter weist im Betrieb echte Daten '
  + 'ab. Dann darf hier keine Grenze klein sein.',
  'kappe=' + KAPP_WERT + ' schluessel=' + KAPP_SCHLUESSEL + ' text=' + KAPP_TEXT);

/* ============================================================================
 * 1) Die Wurzel ist zu — fail-closed
 * ========================================================================== */
console.log('\nDie Wurzel bleibt fail-closed:');
ok('Wurzel ".read" ist false (der Wahrheitswert, nicht der Text "false")', R['.read'] === false,
  'Steht die Wurzel offen, ist JEDER Pfad lesbar, den eine spaetere Aenderung anlegt — auch die '
  + 'Liste aller Praxen. Ein Fremder koennte GET /.json aufrufen und den ganzen Bestand '
  + 'herunterladen.', JSON.stringify(R['.read']));
ok('Wurzel ".write" ist false', R['.write'] === false,
  'Ein offenes Schreibrecht an der Wurzel heisst: jeder darf Vitalwerte einer laufenden Narkose '
  + 'faelschen und jedes Narkoseprotokoll ueberschreiben.', JSON.stringify(R['.write']));
ok('auf /live selbst gibt es kein Leserecht', !!R.live && R.live['.read'] === undefined,
  'Mit einem Leserecht auf /live laesst sich per ?shallow=true die Liste ALLER Praxen abfragen — '
  + 'die komplette Kundenliste, und danach jeder einzelne Knoten.');
/*
 * B3: der Knoten "live" darf ausser dem $praxis-Kind NICHTS haben. Eine Regel dort steht eine Ebene
 * UEBER dem Mandanten und wirkt damit auf JEDE Praxis gleichzeitig.
 */
const liveKinder = R.live ? Object.keys(R.live) : [];
ok('der Knoten live traegt ausser "$praxis" nichts — keine Regel, kein weiteres Kind',
  liveKinder.length === 1 && liveKinder[0] === '$praxis',
  'Ein ".validate" auf /live wirkt eine Ebene UEBER dem Mandanten: es entscheidet fuer JEDE Praxis '
  + 'gleichzeitig. Ein einziges hasChildren([...]) dort weist — unter der Annahme, auf die diese '
  + 'Datei gebaut ist — jeden Schreibvorgang jeder Praxis ab, und das binnen einer Minute und '
  + 'gleichzeitig. Ein ".read" dort gibt die Kundenliste heraus. Diese Ebene bleibt leer.',
  liveKinder.join(', '));

/* ============================================================================
 * 2) Die Mandantentrennung ist genau ein Stringvergleich
 * ========================================================================== */
console.log('\nDie Mandantentrennung steht auf /live/$praxis und nirgends sonst:');
const praxis = (R.live && R.live.$praxis) || {};
ok('es gibt den Knoten live/$praxis', !!(R.live && R.live.$praxis),
  'Ohne diesen Knoten gibt es keinen Ort, an dem die Praxis-Kennung mit auth.uid verglichen wird.');
ok('live/$praxis ".read" ist genau "' + AUTH + '"', praxis['.read'] === AUTH,
  'Jede andere Fassung ist eine andere Trennung. Eine Kennung, die aus einem Datenfeld, einem '
  + 'Zugangscode oder einer Zeichenlaenge abgeleitet wird, kann ein Fremder setzen — auth.uid '
  + 'nicht.', JSON.stringify(praxis['.read']));
if (ETAPPE === 1) {
  ok('live/$praxis ".write" ist genau "' + AUTH + '" (Etappe 1)', praxis['.write'] === AUTH,
    'IN ETAPPE 1 MUSS DIESES ".write" HIER STEHEN. Es zu entfernen und je Teilbaum zu verteilen ist '
    + 'die richtige Aenderung — aber sie ist eine VERSCHARFUNG, und jede ausgelieferte Station '
    + '1.0.3 schreibt Pfade, die dann kein Schreibrecht mehr haetten. Drei Ablehnungen spaeter hat '
    + 'jede Praxis die Fern-Uebertragung dauerhaft verloren. TODO ETAPPE 2: hier oben entfaellt das '
    + '".write", je Teilbaum kommt eines dazu, und diese Pruefung wird durch die Etappe-2-Fassung '
    + 'ersetzt (ETAPPE = 2 setzen). Erst dann wird die Unveraenderlichkeit des Narkoseprotokolls '
    + 'echt; heute ist sie eine Absichtserklaerung.', JSON.stringify(praxis['.write']));
} else {
  ok('live/$praxis hat KEIN ".write" mehr (Etappe 2)', praxis['.write'] === undefined,
    'Solange das ".write" hier oben steht, kaskadiert es nach unten und ist tiefer NICHT entziehbar. '
    + 'Das Narkoseprotokoll bleibt damit loeschbar, obwohl unten eine Regel steht, die das verbietet '
    + '— eine Zusage, die der Code nicht haelt.', JSON.stringify(praxis['.write']));
  /*
   * NICHT "jeder Teilbaum braucht ein eigenes '.write'" — das war die fruehere Fassung, und sie war
   * FALSCH und gefaehrlich zugleich. Sie verlangte ein ".write" auch auf live/$praxis/protokoll und
   * auf live/$praxis/saele. Ein ".write" auf einem dieser beiden kaskadiert nach unten und macht
   * das Blatt-".write" der Protokollzeile ("!data.exists() && newData.exists()") wieder wirkungslos
   * — es zerstoert also genau das, wofuer Etappe 2 ueberhaupt gebaut wird. Zusaetzlich zeigte sie
   * auf die falsche Ebene: bei tafel, saele und verbund steht das ".write" schon eine Stufe tiefer
   * auf <zweig>/$station, und das ist die ENGERE und richtige Stelle — ein ".write" auf "saele"
   * erlaubt einer Station auch das Ueberschreiben und Loeschen der Saele ihrer NACHBARN im selben
   * Konto. Ein roter Test, dessen Fehlertext zur falschen Aenderung draengt, ist schlimmer als
   * keiner.
   *
   * Geprueft wird deshalb, was wirklich zaehlt, und je Richtung getrennt:
   *   (a) fuer jeden Pfad, den die Station BESCHREIBT: irgendwo auf dem Weg dorthin steht ein
   *       ".write" — sonst verliert sie die Fern-Uebertragung;
   *   (b) fuer jede Protokollzeile: das ".write" steht AM BLATT und NIRGENDWO DARUEBER — sonst ist
   *       die Unveraenderlichkeit wieder nur eine Absichtserklaerung.
   */
  const SCHREIBZIELE = [
    ['meta', 'ts'],
    ['patients', '$key'],
    ['tafel', '$station', 'meta'],
    ['saele', '$station', 'patients', '$key'],
    ['verbund', 'lan', '$station'],
  ];
  const PROTOKOLL_ZIELE = [
    ['protokoll', '$patient', '$zeitpunkt'],
    ['saele', '$station', 'protokoll', '$patient', '$zeitpunkt'],
  ];
  // Alle ".write" von /live/$praxis abwaerts bis einschliesslich zum Ziel, mit ihrer Ebene.
  const schreibrechteAuf = (segmente) => {
    const out = [];
    if (typeof praxis['.write'] === 'string') out.push({ pfad: 'live/$praxis', wert: praxis['.write'] });
    let n = praxis;
    for (let i = 0; i < segmente.length; i++) {
      n = regelKind(n, segmente[i]);
      if (!n || typeof n !== 'object') break;   // tiefer gibt es keinen Regelknoten und also kein ".write"
      if (typeof n['.write'] === 'string') {
        out.push({ pfad: segmente.slice(0, i + 1).join('/'), wert: n['.write'] });
      }
    }
    return out;
  };
  SCHREIBZIELE.forEach((ziel) => {
    const w = schreibrechteAuf(ziel);
    ok('auf dem Weg zu ' + ziel.join('/') + ' steht mindestens ein ".write" (Etappe 2)', w.length > 0,
      'Diesen Pfad beschreibt die Station im Betrieb. Nach dem Entzug des kaskadierenden ".write" '
      + 'auf /live/$praxis ist er ohne ein eigenes Schreibrecht irgendwo darueber nicht mehr '
      + 'beschreibbar — die Station verliert die Fern-Uebertragung vollstaendig. WOHIN das ".write" '
      + 'gehoert: so TIEF wie moeglich (bei tafel/saele/verbund auf <zweig>/$station, nicht auf den '
      + 'Zweig selbst — sonst darf eine Station die Saele ihrer Nachbarn im selben Konto '
      + 'ueberschreiben und loeschen), aber NIE oberhalb einer Protokollzeile.',
      w.map((e) => e.pfad).join(', ') || '(kein einziges ".write" auf dem ganzen Weg)');
  });
  PROTOKOLL_ZIELE.forEach((ziel) => {
    const p = ziel.join('/');
    const w = schreibrechteAuf(ziel);
    const amBlatt = w.filter((e) => e.pfad === p);
    const darueber = w.filter((e) => e.pfad !== p);
    ok(p + ' hat sein ".write" AM BLATT, und es weist das DELETE ab (Etappe 2)',
      amBlatt.length === 1 && amBlatt[0].wert.indexOf('!data.exists()') >= 0
        && amBlatt[0].wert.indexOf('newData.exists()') >= 0,
      'Nur hier kann die Unveraenderlichkeit einer Narkoseprotokollzeile entstehen. Das ".validate" '
      + 'wird bei Loeschungen nicht ausgewertet — ohne "!data.exists() && newData.exists()" im '
      + '".write" bleibt eine geschriebene Zeile per DELETE entfernbar und danach neu schreibbar, '
      + 'also faelschbar.', amBlatt.map((e) => e.wert).join(' | ') || '(kein ".write" am Blatt)');
    ok('ueber ' + p + ' steht KEIN kaskadierendes ".write" (Etappe 2)', darueber.length === 0,
      'Ein ".write" auf einem Vorfahren kaskadiert nach unten und ist tiefer NICHT entziehbar — die '
      + 'Regeldatei sagt das im Kopf selbst. Es macht das Blatt-".write" wirkungslos und damit die '
      + 'ganze Unveraenderlichkeit zur Absichtserklaerung. ABHILFE IST NICHT, hier ein ".write" zu '
      + 'ergaenzen, sondern das gefundene TIEFER ZU LEGEN: bei saele gehoert es auf '
      + 'saele/$station/patients (und auf jeden weiteren Nicht-Protokoll-Teilbaum eines Saals), '
      + 'nicht auf saele/$station.',
      darueber.map((e) => e.pfad).join(', '));
  });
}

// Kein literal true, nirgends — und jedes .read/.write nennt den Kontovergleich.
const rechte = [];
begehen(R, [], (node, pfad) => {
  ['.read', '.write'].forEach((r) => {
    if (Object.prototype.hasOwnProperty.call(node, r)) rechte.push({ pfad: pfad.join('/') || '(Wurzel)', regel: r, wert: node[r] });
  });
});
const offen = rechte.filter((e) => e.wert === true || e.wert === 'true');
ok('nirgends steht ".read": true oder ".write": true', offen.length === 0,
  'Genau so war es bis 0.9.0: /live/<code> war fuer jeden lesbar. Leserechte kaskadieren in '
  + 'Firebase nach UNTEN — ein einziges "true" oeffnet Vitalwerte, Kurven, Alarme und das '
  + 'Narkoseprotokoll gleichermassen, und zwar ohne Anmeldung.',
  offen.map((e) => e.pfad + ' ' + e.regel).join(', '));
const fremdeRechte = rechte.filter((e) => e.wert !== false && String(e.wert).indexOf('auth.uid === $praxis') < 0);
ok('jedes Schreib-/Leserecht nennt den Vergleich auth.uid === $praxis', fremdeRechte.length === 0,
  'Ein Recht ohne diesen Vergleich haengt an etwas anderem als der Anmeldung. Damit waere die '
  + 'Trennung zwischen zwei Praxen nicht mehr unverhandelbar, sondern von einem Datenfeld '
  + 'abhaengig, das jemand setzen kann.',
  fremdeRechte.map((e) => e.pfad + ' ' + e.regel + '=' + JSON.stringify(e.wert)).join(', '));

/* ============================================================================
 * 3) NUR ADDITIV — der Bestand darf sich nicht bewegt haben
 * ========================================================================== */
console.log('\nEtappe 1 ist rein additiv (sonst verliert JEDE ausgelieferte Praxis die Fern-Uebertragung):');
ok('der Kopfkommentar haelt die Additiv-Regel fest', /NUR ADDITIV/.test(rohText),
  'Diese Datei wirkt in der Sekunde des Veroeffentlichens auf jede 1.0.3-Station. Wer das beim '
  + 'naechsten Mal nicht im Kopf der Datei liest, verscharft eine Zeile an meta oder protokoll — '
  + 'und drei Ablehnungen spaeter hat jede Praxis die Fern-Uebertragung dauerhaft verloren, '
  + 'zurueckholbar nur durch einen Neustart vor Ort.');

/*
 * DIE DREI WORTGLEICHHEITS-PRUEFUNGEN GELTEN NUR FUER ETAPPE 1. In Etappe 2 sollen meta, patients
 * und protokoll ausdruecklich strenger werden — dann waeren sie eine Pruefung, die eine RICHTIGE
 * Aenderung rot macht und ihr im Fehlertext Patientengefahr vorwirft. Genau das darf ein Test
 * nicht. Deshalb haengen sie am Schalter ETAPPE oben.
 */
const metaSoll = {
  '.validate': "newData.hasChildren(['station','ts'])",
  station: { '.validate': 'newData.isString() && newData.val().length <= 120' },
  ts: { '.validate': 'newData.isNumber()' },
  sv: { '.validate': 'newData.isNumber()' },
};
if (ETAPPE !== 1) {
  console.log('  · Etappe ' + ETAPPE + ': die Wortgleichheits- und "noch nicht verscharft"-Pruefungen');
  console.log('    sind uebersprungen. Sie sichern die Additiv-Zusage der Etappe 1 und wuerden hier');
  console.log('    genau die Verscharfungen rot machen, die Etappe 2 einbauen SOLL.');
}
if (ETAPPE === 1) {
ok('der flache meta-Block ist inhaltlich unveraendert (Reihenfolge zaehlt NICHT)',
  stabil(praxis.meta) === stabil(metaSoll),
  'Eine 1.0.3-Station schreibt meta in JEDEM Takt. Jedes zusaetzliche Pflichtfeld, jede neue '
  + 'Auffangregel und jede zusaetzliche Typpruefung hier ist eine Ablehnung pro Takt — also die '
  + 'Selbstabschaltung aller Praxen binnen einer Minute. Verscharfungen an meta gehoeren in '
  + 'Etappe 2, NACH der Messung und NACH dem Update der Stationen.', stabil(praxis.meta));
ok('der flache patients-Block ist inhaltlich unveraendert (".validate": true)',
  stabil(praxis.patients) === stabil({ '.validate': true }),
  'Die flache Ebene ist der Kompatibilitaetsspiegel fuer die ausgelieferte Web-App. Eine '
  + 'Laengengrenze hier trifft zuerst die 1.0.3-Stationen, die ihren ganzen Patientenknoten in '
  + 'einem Stueck schreiben.', stabil(praxis.patients));
ok('das flache Protokoll ist inhaltlich unveraendert',
  stabil(knotenAn(praxis, ['protokoll', '$patient', '$zeitpunkt']))
    === stabil({ '.validate': "!data.exists() && newData.hasChildren(['ts'])" }),
  'Ein zusaetzliches ".write" hier wirkt heute nicht (das ".write" auf $praxis kaskadiert und ist '
  + 'tiefer nicht entziehbar), ein zusaetzliches Pflichtfeld dagegen sofort — und dann verliert '
  + 'eine Praxis Protokollzeilen ENDGUELTIG, weil die Zeilen unveraenderlich sind und nicht '
  + 'nachgeliefert werden koennen.',
  stabil(knotenAn(praxis, ['protokoll', '$patient', '$zeitpunkt'])));
}
/*
 * B3: die Kindmenge unter $praxis muss GENAU die sechs bekannten Namen sein. Ein zusaetzlicher
 * Schluessel — vor allem ein $-Platzhalter — wirkt auf die FLACHE Ebene. Gilt in JEDER Etappe:
 * ein neuer Teilbaum ist eine bewusste Entscheidung, kein stiller Zuwachs.
 */
const praxisKinder = kinder(praxis).slice().sort();
ok('unter $praxis stehen genau die sechs bekannten Teilbaeume und kein $-Platzhalter',
  stabil(praxisKinder) === stabil(PRAXIS_KINDER),
  'Ein zusaetzlicher Schluessel hier liegt auf DERSELBEN Ebene wie meta, patients und protokoll. '
  + 'Ein "$sonst" mit einer Typ- oder Laengenregel weist damit — sobald ein $-Platzhalter auch '
  + 'neben namentlichen Geschwistern gilt, die ungemessene Annahme dieser Datei — den ganzen '
  + 'Patientenknoten einer 1.0.3 ab. Ergebnis: jede Praxis verliert binnen einer Minute die '
  + 'Fern-Uebertragung, zurueck nur durch einen Neustart VOR ORT. Ein neuer Teilbaum gehoert in '
  + 'diese Liste UND in eine bewusste Entscheidung, nicht in einen stillen Zuwachs.',
  praxisKinder.join(', '));
ok('das ".validate" auf $praxis laesst einen Koerper mit nur meta weiter durch',
  txt(praxis['.validate']).indexOf("newData.hasChildren(['meta'])") >= 0,
  'Der 1.0.3-Koerper enthaelt meta. Faellt diese Bedingung weg oder wird sie zu einem UND '
  + 'verknuepft, weist die Datenbank jeden Schreibvorgang jeder ausgelieferten Station ab.',
  JSON.stringify(praxis['.validate']));
/*
 * Alle drei neuen Zweige — auch verbund. Die fruehere Fassung dieser Schleife hatte fuer verbund
 * ein festverdrahtetes Bestehen ("z === 'verbund' || ...") und druckte damit eine gruene Zeile fuer
 * eine FALSCHE Aussage. Sachlich richtig ist: die erste LAN-Anmeldung einer Station in einem frisch
 * angelegten Praxiskonto traegt ausschliesslich verbund-Pfade, und wenn unter /live/<uid> noch
 * keines der anderen Kinder liegt, weist ein ".validate" ohne verbund sie ab — ohne dass irgendeine
 * Meldung den Grund verraet. Also steht verbund jetzt in der Regel, und die Ausnahme ist weg.
 */
NEUE_ZWEIGE.forEach((z) => {
  ok('das ".validate" auf $praxis erlaubt zusaetzlich "' + z + '"',
    txt(praxis['.validate']).indexOf("newData.hasChildren(['" + z + "'])") >= 0,
    'Wird das ".validate" eines Vorfahren bei einem tiefen Schreibvorgang ausgewertet — ungemessen, '
    + 'deshalb vorsichtshalber angenommen —, dann weist es jeden Koerper ab, der nur ' + z
    + '-Pfade enthaelt. Bei saele ist das der 200-ms-Takt der neuen Station, also der Vitalstrom '
    + 'selbst; bei verbund die LAN-Anmeldung beim Start; bei tafel der Herzschlag des Saals.',
    JSON.stringify(praxis['.validate']));
});

/* ============================================================================
 * 3b) Die drei Dinge, die in Etappe 1 NOCH DURCHGEHEN MUESSEN
 *     (nur Etappe 1: in Etappe 2 sind genau das die gewollten Verscharfungen)
 * ========================================================================== */
if (ETAPPE === 1) {
console.log('\nDie Verscharfungen der Etappe 2 sind noch NICHT eingebaut (sonst stirbt jede 1.0.3):');
ok('flaches meta/sv steht unveraendert auf "newData.isNumber()" (eine feste Zahl geht durch)',
  txt(knotenAn(praxis, ['meta', 'sv', '.validate'])) === 'newData.isNumber()',
  'Das 60-s-Frischefenster auf der FLACHEN Ebene ist eine Verscharfung: eine 1.0.3 schreibt dort '
  + 'meta/sv als Serverplatzhalter, aber ihr Koerper enthaelt auch Faelle, in denen das Feld gar '
  + 'nicht neu gesetzt wird. Wer die Handpruefliste aus dem Plan (Etappe 2) hier anwendet, haelt '
  + 'das fuer einen Fehler und "repariert" es — und nimmt damit jeder Praxis die Fern-Uebertragung.',
  JSON.stringify(knotenAn(praxis, ['meta', 'sv', '.validate'])));
ok('der flache meta-Block verlangt KEIN newData.exists() ({"meta":null} geht durch)',
  txt(knotenAn(praxis, ['meta', '.validate'])).indexOf('exists()') < 0,
  'Ein Pflichtfeld in meta ist eine Verscharfung fuer jede ausgelieferte Station. Es gehoert nach '
  + 'Etappe 2. Steht es heute hier, ist es die Selbstabschaltung aller Praxen.',
  JSON.stringify(knotenAn(praxis, ['meta', '.validate'])));
const schreibMitExists = rechte.filter((e) => String(e.wert).indexOf('newData.exists()') >= 0);
ok('kein ".write" auf dem BESTAND verlangt newData.exists() (Loeschungen gehen in Etappe 1 durch)',
  schreibMitExists.every((e) => e.pfad.indexOf('saele') >= 0),
  'Das ".validate" wird bei Loeschungen nicht ausgewertet, ein ".write" schon. Ein '
  + '"newData.exists()" auf dem Bestand macht aus jedem legitimen Loeschvorgang einer 1.0.3 '
  + '(verschwundener Patient, weggefallenes Feld — cloud.js:_delta() schreibt dafuer ausdruecklich '
  + 'null) eine Ablehnung des ganzen atomaren Koerpers.',
  schreibMitExists.map((e) => e.pfad).join(', '));
ok('die Handpruefliste fuer ETAPPE 1 steht im Kopf der Regeldatei',
  /HANDPRUEFLISTE FUER ETAPPE 1/.test(rohText) && /GEHT IN ETAPPE 1 NOCH DURCH/.test(rohText),
  'Die Pruefliste des Plans gehoert zu Etappe 2. Wer nach ihr im Regel-Simulator prueft, sieht drei '
  + 'Erwartungen verletzt ({"saele":null} abgewiesen, {"meta":null} abgewiesen, feste sv-Zahl '
  + 'abgewiesen), haelt die Veroeffentlichung fuer misslungen und verscharft meta oder entzieht das '
  + '".write" — genau die Handlung, die binnen einer Minute JEDER Praxis die Fern-Uebertragung '
  + 'nimmt. Ohne die richtige Liste IM Kopf der Datei passiert das wieder.');
}

/* ============================================================================
 * 3c) meta/station — die NIEDRIGSTE Grenze der Datei, GEBUNDEN an die Kappung im Code
 * ========================================================================== */
/*
 * WARUM DIESER ABSCHNITT EIGENS EXISTIERT (Befund vom 30.07.2026).
 * meta/station laesst 120 Zeichen zu — weniger als jede andere Regel dieser Datei, und das auf dem
 * BESTAND, also auf der Zeile, die jede ausgelieferte 1.0.3 in jedem Takt beschreibt. cloud.js hat
 * den Saalnamen aus bridge/config/devices.json lange UNGEKAPPT dorthin geschrieben. Ein Saalname
 * mit 121 Zeichen (Tippfehler, eingefuegter Text, kuenftig POST /api/station/name aus N10) genuegte
 * damit, um den ganzen atomaren Koerper samt aller Vitalwerte abweisen zu lassen und die
 * Fern-Uebertragung dieser Praxis nach drei Takten dauerhaft abzuschalten.
 *
 * Inzwischen kappt cloud.js im Konstruktor auf genau 120. Damit ist der Fall behoben — aber er
 * bleibt genau so lange behoben, wie die BEIDEN ZAHLEN gleich bleiben. Nebeneinander dokumentiert
 * waren sie vorher auch (tafel.js fuehrt GRENZEN.spiegelStation = 120 mit genau diesem Kommentar,
 * und cloud.js hat tafel.js nie geladen). Genau dieses stille Auseinanderlaufen war der Befund.
 * Deshalb steht hier eine Pruefung und keine dritte Notiz.
 *
 * GEMESSEN, NICHT ABGELESEN: der Test baut einen Publisher mit einem 5000-Zeichen-Saalnamen und
 * liest pub.station.length. Eine Pruefung, die die Zahl 120 aus dem Quelltext von cloud.js
 * herausregnet, bestuende auch dann, wenn die Kappung dort gar nicht mehr angewendet wird — das
 * waere eine leere Pruefung.
 */
console.log('\nDie Grenze fuer meta/station ist an die Kappung in cloud.js gebunden:');
const STATION_REGEL = grenzeIn(knotenAn(praxis, ['meta', 'station', '.validate']));
let STATION_KAPP = null, stationFehler = null;
if (cloudMod && cloudMod.CloudPublisher) {
  try {
    const pub = new cloudMod.CloudPublisher({
      enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: 'http://127.0.0.1:1/',
      station: LANG,
      authFile: path.join(os.tmpdir(), 'vetstation-regeln-test-nie-geschrieben.json'),
    }, { log: { info() {}, warn() {}, error() {} } });
    STATION_KAPP = String(pub.station == null ? '' : pub.station).length;
  } catch (e) { stationFehler = e.message; }
} else {
  stationFehler = 'bridge/src/cloud.js nicht ladbar: ' + cloudFehler;
}
console.log('    gemessen: cloud.js macht aus einem 5000-Zeichen-Saalnamen '
  + (STATION_KAPP === null ? '(nicht messbar)' : STATION_KAPP + ' Zeichen')
  + '  ->  Regelgrenze ' + (STATION_REGEL === null ? '(keine)' : STATION_REGEL));

ok('die Regel fuer meta/station traegt ueberhaupt eine Laengengrenze', STATION_REGEL !== null,
  'Ohne Grenze auf meta/station ist das Feld, das in JEDEM Takt jeder ausgelieferten 1.0.3 mitgeht, '
  + 'unbegrenzt — und diese Pruefung haette nichts, woran sie die Kappung im Code binden koennte. '
  + 'Sie waere dann gruen, weil sie nichts gefunden hat.',
  JSON.stringify(knotenAn(praxis, ['meta', 'station', '.validate'])));
ok('cloud.js kappt den Saalnamen ueberhaupt (5000 Zeichen kommen nicht durch)',
  STATION_KAPP !== null && STATION_KAPP < 5000,
  'Ohne Kappung im Code ist die Regelgrenze die einzige Sperre — und dann ist sie keine Sperre, '
  + 'sondern eine Falle: der Saalname kommt aus bridge/config/devices.json, also aus einer von Hand '
  + 'getippten Datei. Ein zu langer Name laesst den ganzen atomaren Koerper samt Vitalwerten '
  + 'abweisen (PERMISSION_DENIED), cloud.js zaehlt das als Konfigfehler und schaltet nach DREI '
  + 'Takten die Fern-Uebertragung dieser Praxis dauerhaft ab. Zurueck kommt sie nur durch einen '
  + 'Neustart VOR ORT. Zu beheben in bridge/src/cloud.js, nicht hier.',
  stationFehler || ('gemessen: ' + STATION_KAPP + ' Zeichen'));
ok('die GEMESSENE Kappung des Saalnamens liegt NICHT ueber der Regelgrenze fuer meta/station',
  STATION_KAPP !== null && STATION_REGEL !== null && STATION_KAPP <= STATION_REGEL,
  'DAS IST DIE GEFAEHRLICHE RICHTUNG. Kappt cloud.js auf mehr Zeichen, als die Regel zulaesst, '
  + 'weist die Datenbank meta/station ab — und weil cloud.js:_delta() einen atomaren '
  + 'Mehrpfad-PATCH schickt, faellt der GANZE Koerper mit allen Vitalwerten. Drei Takte spaeter ist '
  + 'die Fern-Uebertragung dieser Praxis dauerhaft aus, zurueck nur durch einen Neustart VOR ORT, '
  + 'moeglicherweise mitten in einer Narkose. Das trifft NICHT nur die neue Station: meta/station '
  + 'liegt auf der Kompatibilitaetsschicht und wird von JEDER ausgelieferten 1.0.3 geschrieben. '
  + 'Abhilfe: die Kappung in cloud.js senken. Die Regelgrenze anzuheben ist zwar eine reine '
  + 'Lockerung und erlaubt — aber sie wirkt erst nach dem Veroeffentlichen in der Firebase-Konsole, '
  + 'waehrend die Kappung mit dem naechsten Programmstart wirkt.',
  'Kappung ' + STATION_KAPP + ' gegen Regelgrenze ' + STATION_REGEL + (stationFehler ? ' — ' + stationFehler : ''));
/*
 * Die dritte Zahl: der Kommentar an der Regelzeile. Er ist die einzige Stelle, an der ein Leser die
 * Verbindung ueberhaupt erfaehrt — also muss auch er mitwandern, sonst steht dort bald wieder eine
 * Behauptung, die der Code widerlegt.
 */
const BINDUNG = /BINDUNG meta\/station: Regelgrenze (\d+) = Kappung cloud\.js _kurz\(cfg\.station, (\d+)\)/
  .exec(rohText);
ok('der Kommentar an der Regelzeile nennt die Bindung, und alle drei Zahlen stimmen ueberein',
  !!BINDUNG && STATION_REGEL !== null && STATION_KAPP !== null
    && Number(BINDUNG[1]) === STATION_REGEL && Number(BINDUNG[2]) === STATION_KAPP,
  'Ein Kommentar, der etwas anderes behauptet als der Code tut, ist schlimmer als kein Kommentar: '
  + 'der naechste Baumeister glaubt ihm und prueft die Zahl nicht nach. Genau so ist der Befund '
  + 'entstanden — tafel.js fuehrte GRENZEN.spiegelStation = 120 samt Verweis auf diese Regel, und '
  + 'cloud.js hat tafel.js nie geladen. WENN DIESE ZEILE ROT IST, IST MEIST NICHTS KAPUTT: kappt '
  + 'cloud.js absichtlich ENGER als die Regel, ist das voellig in Ordnung, und es gehoert nur die '
  + 'Zahl im Kommentar an der Regelzeile (Suchwort "BINDUNG meta/station") nachgezogen. Kappt '
  + 'cloud.js WEITER als die Regel, ist die Zeile darueber ebenfalls rot — dann ist es ernst.',
  BINDUNG ? ('Kommentar: Regel ' + BINDUNG[1] + ' / Kappung ' + BINDUNG[2]
    + ' | tatsaechlich: Regel ' + STATION_REGEL + ' / Kappung ' + STATION_KAPP)
    : '(die BINDUNG-Zeile fehlt im Kopf der Regelzeile)');

/* ============================================================================
 * 4) Die neuen Teilbaeume sind ueberhaupt da
 * ========================================================================== */
console.log('\nDie neuen Teilbaeume sind beschrieben:');
ok('tafel/$station existiert', !!knotenAn(praxis, ['tafel', '$station']),
  'Ohne Regelblock ist der Zweig, den JEDE Web-Ansicht per Dauerabonnement laedt, vollstaendig '
  + 'unvalidiert — dort koennte ein einziger 5-MB-String das Kontingent aller Praxen leerziehen.');
ok('tafel/$station/geraete existiert', !!knotenAn(praxis, ['tafel', '$station', 'geraete']),
  'Ohne die Geraetezeile kann der Tierarzt in Saal 1 nicht unterscheiden zwischen "in Saal 2 '
  + 'haengt kein Kapnograph" und "in Saal 2 ist der Kapnograph abgerissen" — und ohne Regelblock '
  + 'traegt dieser Zweig unbegrenzte Texte aus dem Praxisnetz.');
ok('saele/$station/patients existiert', !!knotenAn(praxis, ['saele', '$station', 'patients']),
  'Das ist der Zweig mit der groessten Datenmenge. Unvalidiert ist er der bequemste Ort fuer '
  + 'einen sehr langen Text, den danach jede Ansicht und jede andere Station bei jedem Delta '
  + 'erneut laedt.');
ok('verbund/lan/$station existiert', !!knotenAn(praxis, ['verbund', 'lan', '$station']),
  'Im LAN-Verzeichnis liegen oeffentlicher Schluessel, Fingerabdruck und Adressen. Ohne Regeln '
  + 'kann dort jede Laenge und jede Portnummer stehen.');

/* ============================================================================
 * 5) Unveraenderlichkeit des Narkoseprotokolls — an JEDER Protokollstelle
 * ========================================================================== */
console.log('\nDie Unveraenderlichkeit des Narkoseprotokolls steht an JEDER Protokollstelle:');
const protokollStellen = [];
begehen(praxis, ['live', '$praxis'], (node, pfad) => {
  if (pfad[pfad.length - 1] !== 'protokoll') return;
  protokollStellen.push({
    pfad: pfad.join('/'),
    // "neu" = das Protokoll liegt in einem der neuen Zweige (heute: saele/<sid>/protokoll). Dort
    // darf und MUSS ein eigenes ".write" stehen; auf dem flachen Bestand waere es eine
    // Verscharfung fuer jede ausgelieferte 1.0.3 (Abschnitt 3b haelt das getrennt fest).
    neu: pfad.some((s) => NEUE_ZWEIGE.indexOf(s) >= 0),
    blatt: knotenAn(node, ['$patient', '$zeitpunkt']),
  });
});
ok('es gibt mindestens zwei Protokollstellen (flach und je Saal)', protokollStellen.length >= 2,
  'Der Umbau legt ein zweites Protokoll unter saele/<sid>/protokoll an. Fehlt es, gibt es fuer '
  + 'den Mehr-Saal-Betrieb ueberhaupt kein fernes Narkoseprotokoll — und diese Pruefung waere '
  + 'nur deshalb gruen, weil sie nichts zu pruefen hatte.',
  protokollStellen.map((s) => s.pfad).join(', '));
protokollStellen.forEach((s) => {
  const val = txt(s.blatt && s.blatt['.validate']);
  const wr = txt(s.blatt && s.blatt['.write']);
  /*
   * GETRENNT geprueft, nicht als ein Text zusammengeklebt. Solange das ".write" auf $praxis steht,
   * ist ein tieferes ".write" wirkungslos (die Datei sagt das an drei Stellen selbst) — die
   * Bedingung MUSS also im ".validate" stehen. Die alte Fassung hat beide Ausdruecke aneinander
   * gehaengt und konnte deshalb nicht unterscheiden, ob sie an der heute WIRKSAMEN Stelle steht:
   * ein Entfernen aus dem ".validate" blieb gruen.
   */
  ok(s.pfad + '/$patient/$zeitpunkt hat "!data.exists()" im ".validate" (die heute wirksame Stelle)',
    val.indexOf('!data.exists()') >= 0,
    'Solange das ".write" auf /live/$praxis steht, kaskadiert es nach unten und ist tiefer NICHT '
    + 'entziehbar — ein "!data.exists()" im ".write" ist heute eine Absichtserklaerung ohne '
    + 'Wirkung. Fehlt die Bedingung im ".validate", laesst sich eine bereits geschriebene '
    + 'Protokollzeile UEBERSCHREIBEN. Ein Narkoseprotokoll, das man nachtraeglich umschreiben kann, '
    + 'ist als Dokumentation wertlos — und im Streitfall ist es das einzige, was noch da ist.',
    val || '(kein Blatt $patient/$zeitpunkt)');
  ok(s.pfad + '/$patient/$zeitpunkt verlangt einen Zeitstempel',
    val.indexOf("hasChildren(['ts'])") >= 0,
    'Eine Protokollzeile ohne ts laesst sich zeitlich nicht einordnen. Sie ist unveraenderlich, '
    + 'also bleibt der Fehler fuer immer im Dokument stehen.', val || '(kein Blatt)');
  /*
   * ANWESENHEIT UND INHALT GETRENNT — und die Anwesenheit VERLANGT, nicht nur beim Vorfinden
   * geprueft. Die fruehere Fassung hatte nur das "if (wr) { ... }" unten. Wer die ".write"-Zeile
   * ersatzlos loescht, loescht damit die Pruefung mit: gemessen meldete der Test danach "ALLE
   * PRUEFUNGEN BESTANDEN" mit einer Pruefung WENIGER, und keine einzige Zeile wurde rot. Eine
   * Pruefung, die mit ihrem Gegenstand verschwindet, ist keine.
   */
  if (s.neu) {
    ok(s.pfad + '/$patient/$zeitpunkt hat ueberhaupt ein ".write"', !!wr,
      'Heute wirkt dieses ".write" nicht — das ".write" auf /live/$praxis kaskadiert nach unten und '
      + 'ist tiefer nicht entziehbar. Ab Etappe 2 ist es die EINZIGE Stelle, an der die '
      + 'Unveraenderlichkeit einer Narkoseprotokollzeile ueberhaupt entstehen kann: ".validate" '
      + 'wird bei Loeschungen nicht ausgewertet (die Regeldatei sagt das an drei Stellen selbst), '
      + 'ein DELETE geht also daran vorbei. Fehlt die Zeile, ist eine bereits geschriebene '
      + 'Protokollzeile per DELETE entfernbar und danach neu schreibbar — also faelschbar, und zwar '
      + 'genau dann, wenn im Streitfall nur noch dieses Dokument da ist. Sie muss JETZT stehen, '
      + 'nicht erst in Etappe 2: wer Etappe 2 baut, entzieht oben das ".write" und merkt nicht, '
      + 'dass unten nie eines stand.',
      '(kein ".write" an ' + s.pfad + '/$patient/$zeitpunkt)');
  }
  if (wr) {
    ok(s.pfad + '/$patient/$zeitpunkt: das zusaetzliche ".write" weist auch das DELETE ab',
      wr.indexOf('!data.exists()') >= 0 && wr.indexOf('newData.exists()') >= 0,
      'Das ".validate" wird bei Loeschungen NICHT ausgewertet: eine Protokollzeile ist per DELETE '
      + 'entfernbar und danach neu schreibbar. Nur ein ".write" mit "!data.exists() && '
      + 'newData.exists()" schliesst das — ab Etappe 2, wenn das kaskadierende ".write" oben weg '
      + 'ist. Steht es hier unvollstaendig, ist die Luecke nach Etappe 2 immer noch offen.', wr);
  }
});

/* ============================================================================
 * 6) Frische eines Saales — TOLERANTES FENSTER, keine Gleichheit auf now
 * ========================================================================== */
console.log('\nJede Frische-Bedingung ist die tolerante Fassung:');
const nowRegeln = [];
begehen(R, [], (node, pfad) => {
  ['.validate', '.read', '.write'].forEach((r) => {
    const v = node[r];
    if (typeof v === 'string' && /\bnow\b/.test(v)) nowRegeln.push({ pfad: pfad.join('/'), regel: r, ausdruck: v });
  });
});
ok('es gibt ueberhaupt Frische-Bedingungen (tafel und verbund)', nowRegeln.length >= 2,
  'Ohne serverseitigen Zeitstempel genuegt EIN Schreibvorgang mit einer selbst gewaehlten Zahl, '
  + 'und die letzten Vitalwerte eines abgestuerzten PCs stehen auf jedem anderen Bildschirm im '
  + 'Haus fuer immer als "vor 0 s". Ein toter OP-Saal sieht dann gesund aus.',
  nowRegeln.map((e) => e.pfad).join(', '));
nowRegeln.forEach((e) => {
  ok(e.pfad + ' benutzt das 60-s-Fenster', e.ausdruck.indexOf(FENSTER) >= 0,
    'Die Gleichheitspruefung "=== now" ist eine WETTE: der Serverplatzhalter {".sv":"timestamp"} '
    + 'kommt in einem Mehrpfad-Schreibvorgang mehrfach vor, und dass alle Vorkommen auf genau den '
    + 'Wert aufgeloest werden, den das "now" der Regelauswertung sieht, ist NICHT belegt. Waere '
    + 'es nicht so, lehnte die Datenbank ab dem Moment der Veroeffentlichung JEDEN Schreibvorgang '
    + 'JEDER Praxis ab. Das Fenster leistet dasselbe, ohne zu wetten.', e.ausdruck);
  ok(e.pfad + ' prueft now NICHT auf Gleichheit', !/[=!]==?\s*now\b/.test(e.ausdruck),
    'Siehe oben: eine Gleichheitspruefung auf now ist der Totalausfall aller Praxen, wenn die '
    + 'Annahme ueber den Serverplatzhalter nicht stimmt — und der Regel-Simulator der Konsole kann '
    + 'sie nicht pruefen, weil er den Platzhalter gar nicht aufloest.', e.ausdruck);
});

/* ============================================================================
 * 7) Groessengrenzen: JEDES Blatt gedeckelt, und zwar IM BAND
 * ========================================================================== */
console.log('\nJedes Blatt der neuen Zweige hat eine Grenze, und jede Grenze liegt im erlaubten Band:');
const ohneGrenze = [];
const zuEng = [];
const zuWeit = [];
const schluesselZuEng = [];
let blaetterGeprueft = 0;
let wertgrenzen = 0;
NEUE_ZWEIGE.forEach((z) => {
  const wurzel = praxis[z];
  if (!wurzel) return;
  const band = BAND[z];
  begehen(wurzel, [z], (node, pfad) => {
    const v = node['.validate'];
    const g = grenzeIn(v);
    if (g !== null) {
      wertgrenzen++;
      if (g < band.min) zuEng.push(pfad.join('/') + ' -> ' + g + ' (Kappung/Zweig-Minimum ' + band.min + ')');
      if (g > band.max) zuWeit.push(pfad.join('/') + ' -> ' + g + ' (Zweig-Maximum ' + band.max + ')');
    }
    const sg = schluesselGrenzeIn(v);
    /*
     * Schluesselgrenzen getrennt: $station traegt eine Stationskennung (tafel.pruefeSid erlaubt
     * hoechstens 24 Zeichen), jeder andere Schluessel kommt aus tafel.schluessel/sanitizeKey und
     * darf so lang werden, wie die dort gemessene Kappung erlaubt.
     */
    if (sg !== null && pfad[pfad.length - 1] !== '$station' && sg < KAPP_SCHLUESSEL) {
      schluesselZuEng.push(pfad.join('/') + ' -> ' + sg + ' (Kappung ' + KAPP_SCHLUESSEL + ')');
    }
    if (!istBlatt(node)) return;
    blaetterGeprueft++;
    if (typeof v !== 'string') { ohneGrenze.push(pfad.join('/') + ' -> ' + JSON.stringify(v)); return; }
    const nurZahl = /newData\.isNumber\s*\(\s*\)/.test(v) && !/newData\.isString\s*\(\s*\)/.test(v);
    const anPfadGebunden = v.indexOf('=== $station') >= 0;   // Wert = Pfadsegment, das selbst begrenzt ist
    if (g === null && !nurZahl && !anPfadGebunden) ohneGrenze.push(pfad.join('/') + ' -> ' + v);
  });
});
ok('es wurden ueberhaupt Blaetter und Grenzen gefunden', blaetterGeprueft >= 20 && wertgrenzen >= 20,
  'Diese Pruefung waere sonst gruen, weil sie nichts gefunden hat. Genau so entsteht ein Test, '
  + 'der eine leere Regeldatei durchlaesst.', 'Blaetter: ' + blaetterGeprueft + ', Wertgrenzen: ' + wertgrenzen);
ok('kein Blatt ohne Laengengrenze und ohne Zahlpruefung', ohneGrenze.length === 0,
  'Die Geraeteports werden ohne Host-Argument gebunden und ihre Firewallregeln stehen auf '
  + '"-Profile Any": ein Notebook im Gast-WLAN kann Werte einspeisen, die fern gehen. Ein '
  + 'einziger 5-MB-String in einem unbegrenzten Blatt zieht das projektweite Kontingent ALLER '
  + 'Praxen leer (1 GB Speicher, 10 GB/Monat) und wird von jeder Ansicht bei jedem Delta erneut '
  + 'geladen.', ohneGrenze.join(' | '));
/*
 * DIE UNTERE GRENZE IST DIE WICHTIGERE. Eine Grenze UNTER der Kappung im Code ist keine Sperre,
 * sondern eine Falle: der Code schreibt dann etwas, das die Datenbank ablehnt.
 */
ok('keine Grenze liegt unter der gemessenen Kappung bzw. unter dem Zweig-Minimum', zuEng.length === 0,
  'Eine Regelgrenze unter der Kappung im Code weist ECHTE Daten ab. Weil der Mehrpfad-PATCH atomar '
  + 'ist, faellt dabei der GANZE Koerper mit allen Vitalwerten. Konkret: hl7.js:parseHL7Message() nimmt fuer das '
  + 'Geraetemodell MSH-3 unveraendert aus dem Netz und kappt es NICHT — ein Geraet oder ein '
  + 'Notebook im Gast-WLAN, das 121 Zeichen sendet, schaltet damit genau einen OP-Saal fern ab. '
  + 'Aus einer Kontingent-Verschwendung wird ein gezielter Fern-Blackout, mit der Regel, die vor '
  + 'genau diesem Notebook schuetzen sollte. Entweder die Grenze anheben oder die Kappung im Code '
  + 'senken — aber niemals die Grenze unter der Kappung stehen lassen.', zuEng.join(' | '));
ok('keine Grenze liegt ueber dem Zweig-Maximum', zuWeit.length === 0,
  'Eine Grenze ist nur eine Sperre, solange die Zahl klein ist. Mit 5000000 steht dieselbe Regel '
  + 'da und schuetzt nichts: ein einziger 5-MB-String zieht das projektweite Kontingent ALLER '
  + 'Praxen leer (1 GB Speicher, 10 GB/Monat) und wird von jeder offenen Ansicht bei jedem Delta '
  + 'erneut geladen. Die Tafel ist am engsten (jede Ansicht abonniert sie dauerhaft), der '
  + 'Kurvenstreifen ist der einzige absichtlich grosse Wert.', zuWeit.join(' | '));
ok('keine Schluesselgrenze liegt unter der gemessenen Schluessel-Kappung', schluesselZuEng.length === 0,
  'tafel.schluessel und cloud.sanitizeKey erzeugen Datenbankschluessel bis zur gemessenen Laenge. '
  + 'Eine kuerzere Grenze im Regelsatz weist genau die Schluessel ab, die der Code selbst baut — '
  + 'und damit den ganzen atomaren Koerper: eine lange Geraete-ID (patientKey, Kanalcode) genuegt.',
  schluesselZuEng.join(' | '));

// '".validate": true' ist in den neuen Zweigen nirgends erlaubt — auch nicht auf Zwischenebenen.
const offeneValidate = [];
NEUE_ZWEIGE.forEach((z) => {
  if (!praxis[z]) return;
  begehen(praxis[z], [z], (node, pfad) => {
    if (node['.validate'] === true) offeneValidate.push(pfad.join('/'));
  });
});
ok('kein ".validate": true in den neuen Zweigen', offeneValidate.length === 0,
  'Ein ".validate": true erlaubt an dieser Stelle jeden Wert jeder Groesse — es ist genau die '
  + 'Luecke, die auf der flachen Ebene aus Kompatibilitaetsgruenden noch offen bleiben MUSS und '
  + 'die in den neuen Zweigen niemals entstehen darf.', offeneValidate.join(', '));

/*
 * B14: ein Sammelknoten OHNE eigene Wertgrenze kann selbst als Zeichenkette beschrieben werden und
 * ist dann ein Blatt, das der Regelbaum gar nicht als Blatt zeigt. PUT /live/<uid>/tafel.json mit
 * einem 5-MB-String waere sonst erlaubt.
 */
const stringDurchlass = [];
NEUE_ZWEIGE.forEach((z) => {
  if (!praxis[z]) return;
  begehen(praxis[z], [z], (node, pfad) => {
    if (istBlatt(node)) return;
    const v = txt(node['.validate']);
    if (grenzeIn(v) !== null) return;                 // traegt selbst eine Wertgrenze: darf ein Text sein
    if (/!\s*newData\.isString\s*\(\s*\)/.test(v)) return;
    if (v.indexOf('hasChildren(') >= 0) return;       // eine Zeichenkette hat keine Kinder
    stringDurchlass.push(pfad.join('/') + ' -> ' + JSON.stringify(node['.validate']));
  });
});
ok('jeder Sammelknoten der neuen Zweige weist eine reine Zeichenkette ab', stringDurchlass.length === 0,
  'Ein PUT auf einen Sammelknoten (tafel, tafel/<sid>, saele/<sid>, patients, uebersicht, geraete, '
  + 'kurven) mit einer 5-MB-Zeichenkette macht den Knoten zum BLATT: die Regeln fuer seine Kinder '
  + 'werden dann gar nicht ausgewertet, und die Zusage "jedes Blatt hat eine Grenze" ist gebrochen. '
  + 'Schreibberechtigt ist jede Sitzung des Praxiskontos, also auch das Tablet am Empfang, und das '
  + 'Kontingent gilt projektweit fuer ALLE Praxen. "!newData.isString()" ist rein additiv: kein '
  + 'Schreibweg dieser Station beschreibt einen Sammelknoten je als Text.', stringDurchlass.join(' | '));

/* ============================================================================
 * 8) Auffangregel fuer unbekannte Schluessel
 * ========================================================================== */
console.log('\nJede Ebene mit namentlich genannten Feldern hat eine Auffangregel:');
const brauchtAuffang = [
  ['tafel', '$station', 'meta'],
  ['tafel', '$station', 'uebersicht', '$key'],
  ['tafel', '$station', 'geraete', '$geraet'],
  ['saele', '$station', 'patients', '$key'],
  ['saele', '$station', 'patients', '$key', 'kurven', '$kanal'],
  ['verbund', 'lan', '$station'],
];
brauchtAuffang.forEach((p) => {
  const node = knotenAn(praxis, p);
  const platzhalter = node ? kinder(node).filter((k) => k[0] === '$') : [];
  const mitRegel = platzhalter.filter((k) => typeof node[k]['.validate'] === 'string');
  ok(p.join('/') + ' hat einen Platzhalter mit Grenze', mitRegel.length > 0,
    'Ohne Auffangregel ist jedes Feld unbegrenzt, das hier kuenftig hinzukommt — und neue Felder '
    + 'kommen schneller als neue Regeln. Die Feldnamen im Geraetestrom sind ohnehin nicht '
    + 'abschliessend aufzaehlbar.', node ? kinder(node).join(', ') : '(Knoten fehlt)');
});

/* ============================================================================
 * 9) Die Falle: eine Auffangkette, die enger ist als ein namentlicher Zweig
 * ========================================================================== */
console.log('\nKeine Auffangkette ist auf irgendeiner Stufe enger als der namentliche Zweig daneben:');
/*
 * NACH TIEFE, NICHT NUR NACH GESCHWISTERN. Die Falle hat zwei Gestalten, und die zweite liegt
 * ueber Zweiggrenzen hinweg: eine Auffangkette, die als Geschwister eines namentlichen Zweigs
 * beginnt, reicht so tief wie dieser. Die alte Fassung verglich nur die DIREKTEN Kinder eines
 * Knotens ("$sonst" gegen "kurvenSig") und konnte deshalb nie "$sonst/$a/$b" gegen
 * "kurven/$kanal/b64" halten — genau die Stufe, an der ein gesenkter Wert den Kurvenstreifen
 * abweist und die Vitalwerte im selben atomaren Koerper mitnimmt.
 */
function grenzenJeTiefe(node, tiefe, aus, minimieren) {
  const g = grenzeIn(node && node['.validate']);
  if (g !== null && tiefe >= 1) {
    if (minimieren) aus[tiefe] = (aus[tiefe] === undefined) ? g : Math.min(aus[tiefe], g);
    else aus[tiefe] = (aus[tiefe] === undefined) ? g : Math.max(aus[tiefe], g);
  }
  kinder(node).forEach((k) => {
    const kind = node[k];
    if (kind && typeof kind === 'object') grenzenJeTiefe(kind, tiefe + 1, aus, minimieren);
  });
}
const kollisionen = [];
NEUE_ZWEIGE.forEach((z) => {
  if (!praxis[z]) return;
  begehen(praxis[z], [z], (node, pfad) => {
    const platz = kinder(node).filter((k) => k[0] === '$');
    const namentlich = kinder(node).filter((k) => k[0] !== '$');
    if (!platz.length || !namentlich.length) return;
    const kette = {};
    platz.forEach((k) => grenzenJeTiefe(node[k], 1, kette, true));
    const zweig = {};
    namentlich.forEach((k) => grenzenJeTiefe(node[k], 1, zweig, false));
    Object.keys(zweig).forEach((t) => {
      if (kette[t] === undefined) return;              // die Kette reicht nicht so tief: kein Konflikt
      if (kette[t] < zweig[t]) {
        kollisionen.push(pfad.join('/') + ' Stufe ' + t + ': Auffangkette ' + kette[t]
          + ' < namentlicher Zweig ' + zweig[t]);
      }
    });
  });
});
ok('jede Auffangstufe ist >= der groessten namentlichen Grenze derselben Tiefe', kollisionen.length === 0,
  'Firebase gibt einem namentlich genannten Kind Vorrang vor dem $-Platzhalter — das ist eine '
  + 'ANNAHME und in dieser Datenbank nicht nachgemessen. Traefe sie nicht zu, gaelte zusaetzlich '
  + 'die Auffanggrenze, und die kleinere gewaenne. Erste Gestalt: die Ed25519-Signatur (base64, 88 '
  + 'Zeichen) zerbricht an einer Auffanggrenze von 64 und nimmt die Vitalwerte im selben atomaren '
  + '1-Hz-Koerper mit. Zweite Gestalt: die Auffangkette unter patients/<key> reicht bis auf die '
  + 'Tiefe von kurven/<kanal>/b64 — steht ihre dritte Stufe auf 200, ist der Kurvenstreifen '
  + 'abgewiesen und der ganze 5-Hz-Koerper mit ihm.', kollisionen.join(' | '));

/*
 * Die zwei Felder, an denen genau das schiefgeht, ueber die WIRKSAME Grenze pruefen — nicht ueber
 * "ist es namentlich genannt". Ob eine Grenze aus einer namentlichen Regel oder aus der
 * Auffangkette kommt, ist der Datenbank gleich; wichtig ist, was am Ende gilt.
 */
function wirksameRegel(segmente) {
  let n = praxis;
  for (const s of segmente) {
    n = regelKind(n, s);
    if (!n) return null;
  }
  return n['.validate'];
}
const sigRegel = wirksameRegel(['tafel', '$station', 'meta', 'sig']);
ok('auf tafel/$station/meta/sig gilt eine Grenze von mindestens 88 Zeichen',
  grenzeIn(sigRegel) !== null && grenzeIn(sigRegel) >= 88,
  'Die Ed25519-Signatur ist base64 ueber 64 Byte, also 88 Zeichen. Greift dort eine engere Grenze '
  + '(der Entwurf hatte 64), faellt sie durch — und weil sie im SELBEN atomaren 1-Hz-Koerper liegt '
  + 'wie die Vitalwerte, nimmt sie die Vitalwerte mit.', JSON.stringify(sigRegel));
const b64Regel = wirksameRegel(['saele', '$station', 'patients', '$key', 'kurven', '$kanal', 'b64']);
ok('auf saele/.../kurven/$kanal/b64 gilt eine Grenze von mindestens 12000 Zeichen',
  grenzeIn(b64Regel) !== null && grenzeIn(b64Regel) >= 12000,
  'Der Kurvenstreifen ist der einzige absichtlich grosse Wert im Baum. Eine zu enge Grenze macht '
  + 'die EKG-Kurve fern unsichtbar und weist den ganzen 5-Hz-Koerper ab; gar keine Grenze macht '
  + 'diesen Zweig zum bequemsten Ort fuer einen 5-MB-String.', JSON.stringify(b64Regel));

/* ============================================================================
 * 10) Die Stationskennung im Pfad bleibt kurz und an den Datensatz gebunden
 * ========================================================================== */
console.log('\nDie Stationskennung im Pfad ist begrenzt und an den Datensatz gebunden:');
/*
 * Die Grenze 24 darf NICHT unter der laengsten Kennung liegen, die stationsid.js/tafel.js
 * ueberhaupt fuer gueltig halten. Deshalb gemessen statt geglaubt: die laengste formgueltige
 * Kennung ist "st" + 12 Hexzeichen + "-" + 4 Hexzeichen.
 */
const SID_LANG = 'st' + 'ab'.repeat(6) + '-' + 'cdef';
ok('die laengste formgueltige Stationskennung wird von tafel.pruefeSid akzeptiert',
  !tafelMod || tafelMod.pruefeSid(SID_LANG) === true,
  'Ohne diesen Bezugswert ist die Grenze auf $station geraten. Liegt sie unter der laengsten '
  + 'gueltigen Kennung, weist die Datenbank genau die Saele ab, die der Code selbst anlegt.',
  SID_LANG + ' (' + SID_LANG.length + ' Zeichen)');
[['tafel', '$station'], ['saele', '$station'], ['verbund', 'lan', '$station']].forEach((p) => {
  const node = knotenAn(praxis, p);
  const v = txt(node && node['.validate']);
  const g = schluesselGrenzeIn(v);
  ok(p.join('/') + ' begrenzt $station und laesst die laengste gueltige Kennung durch',
    g !== null && g >= SID_LANG.length,
    'Ein Pfadsegment aus dem Praxisnetz ohne Laengengrenze legt beliebig viele und beliebig lange '
    + 'Saalknoten an; die Tafel, die jede Ansicht dauerhaft abonniert, waechst dann unbegrenzt. '
    + 'Eine Grenze UNTER der laengsten gueltigen Kennung ist umgekehrt die Ablehnung eines '
    + 'legitimen Saals samt seiner Vitalwerte.',
    JSON.stringify(node && node['.validate']));
});
[['tafel', '$station', 'meta'], ['verbund', 'lan', '$station']].forEach((p) => {
  const node = knotenAn(praxis, p);
  const v = txt(node && node['.validate']);
  ok(p.join('/') + ' verlangt sid === $station',
    v.indexOf("newData.child('sid').val() === $station") >= 0,
    'Die Bindung des Datensatzes an seinen Pfad faengt Versehen, kopierte Konfiguration und '
    + 'Tippfehler: ein Saal kann sich nicht als ein anderer ausgeben, ohne auch dessen Pfad zu '
    + 'benutzen. Sie ist die einzige Sperre, die innerhalb EINES Praxiskontos ueberhaupt moeglich '
    + 'ist.', JSON.stringify(node && node['.validate']));
});

/* ============================================================================
 * 11) Struktur muss durch — nur die begruendeten Ausnahmen weisen ab
 *     (drei Arten an fuenf Stellen, siehe STRENG_ERLAUBT oben)
 * ========================================================================== */
console.log('\nKeine Regel der neuen Zweige weist Objekte ab (ausser den begruendeten Ausnahmen):');
const strengOhneGrund = [];
const falsche = [];
NEUE_ZWEIGE.forEach((z) => {
  if (!praxis[z]) return;
  begehen(praxis[z], [z], (node, pfad) => {
    const p = pfad.join('/');
    const v = node['.validate'];
    if (v === false || /^\s*false\s*$/.test(txt(v))) { falsche.push(p); return; }
    if (typeof v !== 'string') return;
    const sonst = sonstZweig(v);
    const weistAb = (sonst !== null) ? (sonst !== 'true')
      : (fordertEinzelwert(v) && v.indexOf('hasChildren(') < 0);
    if (weistAb && !Object.prototype.hasOwnProperty.call(STRENG_ERLAUBT, p)) {
      strengOhneGrund.push(p + ' -> ' + JSON.stringify(v));
    }
  });
});
ok('nirgends in den neuen Zweigen steht ".validate": false', falsche.length === 0,
  'Ein "false" in einer Auffangkette weist JEDES verschachtelte Objekt ab. Neben den Platzhaltern '
  + 'stehen Objekte: uebersicht/dv, verbund/ips, vitals, ventParams, ekgAnalyse, akte, roh, '
  + 'devices, alarms, kurven, herkunft und top SIND Objekte. Sobald ein $-Platzhalter auch neben '
  + 'namentlichen Geschwistern gilt (die ungemessene Annahme dieser Datei), ist das der '
  + 'Totalausfall der neuen Station: kein einziger Vitalwert wird mehr fern uebertragen.',
  falsche.join(', '));
ok('jede Wertregel laesst Struktur durch (": true"), ausser den namentlich begruendeten Ausnahmen',
  strengOhneGrund.length === 0,
  'GENAU HIER SASS DER TOEDLICHE BEFUND. herkunft ist ein OBJEKT { species, weightKg } '
  + '(hl7.js:parseHL7Message(), model.js:normalizeFrame()) und top ist ein OBJEKT { sev, title, tag, fix, incident } '
  + '(cloud.js:_assess()) — beide standen unter einer Regel "nur Text, Zahl oder Wahrheitswert". Weil '
  + 'cloud.js je Patient genau eine Ebene abflacht, ist jedes dieser Felder ein eigener Pfad im '
  + 'SELBEN atomaren Mehrpfad-PATCH wie die Vitalwerte: ein einziges false darauf weist den ganzen '
  + 'Koerper ab (PERMISSION_DENIED), cloud.js zaehlt das als Konfigfehler und schaltet nach drei '
  + 'Treffern die Fern-Uebertragung ab. Die schuetzende Eigenschaft ist die LAENGENGRENZE fuer '
  + 'Texte, nicht das Abweisen von Objekten. Wer hier streng werden will, traegt den Pfad mit '
  + 'Begruendung in STRENG_ERLAUBT ein — und belegt die Begruendung am echten Datensatz.',
  strengOhneGrund.join(' | '));

/* ============================================================================
 * 12) DIE ECHTEN DATEN: was der Code schreibt, muss durch die Regeln passen
 * ========================================================================== */
console.log('\nDie ECHTEN Datensaetze aus cloud.js und tafel.js gehen durch die Regeln:');

// --- 12a) Saal-Datensatz aus dem echten Publisher --------------------------
ok('bridge/src/cloud.js ist ladbar (fuer den echten Snapshot)', !!(cloudMod && cloudMod.CloudPublisher),
  'Ohne den echten Snapshot kann dieser Test nur die Regeln unter sich vergleichen. Genau so ist '
  + 'der toedliche Befund entstanden: zwei Felder trugen Objekte, die Regel erlaubte nur '
  + 'Einzelwerte, und keine Pruefung hat die beiden je zusammengebracht.', cloudFehler);

/*
 * musterPatient(fuellText, laenge) — ein Patient, wie ihn registry.getPatients()/mergePatients
 * liefert. Mit fuellText=true traegt JEDES Textfeld laenge Zeichen (Vorgabe 2000): das ist die
 * Gegenprobe zur unteren Bandgrenze. Ohne sie faellt eine zu kleine Grenze erst in einer Praxis
 * auf, und dann nimmt sie den ganzen atomaren Koerper mit.
 * Der zweite Parameter dient dem OFFEN-Block am Ende: mit 5000 Zeichen laesst sich MESSEN, welche
 * Felder cloud.js heute noch ungekappt durchreicht, statt es zu behaupten.
 */
function musterPatient(fuellText, laenge) {
  const L = laenge || 2000;
  const p = {
    patientKey: 'id_12345', patientId: fuellText ? 'y'.repeat(L) : '12345',
    patientName: fuellText ? 'y'.repeat(L) : 'Bello',
    species: fuellText ? 'y'.repeat(L) : 'hund',
    weightKg: 22, isoPct: 2.4, o2Flow: 1.2,
    ventMode: fuellText ? 'y'.repeat(L) : 'IPPV',
    // herkunft ist ein OBJEKT — hl7.js:parseHL7Message() baut es bei JEDEM Rahmen, model.js:normalizeFrame() reicht es durch.
    herkunft: { species: 'geraet', weightKg: 'konfig' },
    gebDatum: '2019-05-01', geschlecht: 'm', manual: false,
    akte: { owner: fuellText ? 'y'.repeat(L) : 'Frau Meier', doctor: 'Dr. Klein', breed: 'Labrador' },
    ekgAnalyse: { qrsMs: 62, rhythmus: 'sinus', st: 0.02 },
    ventParams: { peep: 4, vt: 250, ie: '1:2' },
    afSource: 'kapnograf',
    alarms: [{ text: fuellText ? 'y'.repeat(L) : 'EKG-Ableitung ab', quelle: 'geraet' }],
    roh: [{ code: '2301', label: 'HR', wert: 38, einheit: 'bpm',
      von: fuellText ? 'y'.repeat(L) : 'LifeVet', modell: fuellText ? 'y'.repeat(L) : 'LifeVet 10C' }],
    kurven: ['EKG II', 'CO2'],
    kurvenDaten: [],
    devices: [{ deviceId: 'd1', model: fuellText ? 'y'.repeat(L) : 'LifeVet 10C',
      role: 'combo', ip: '192.168.0.9', port: 3500 }],
    vitals: {
      hr: 38, spo2: 88, etco2: 62, af: 8, sys: 84, dia: 46, map: 59, temp: 37.1,
      ekgRhythm: fuellText ? 'y'.repeat(L) : 'sinusbrady', capnoShape: 'high', pleth: 'weak',
    },
    ts: Date.now(),
  };
  /*
   * Vier echte Kurven mit LANGEN Codes: kurvenSig ist EIN Text fuer ALLE Kanaele
   * (cloud.js:_buildSnapshot()) und waechst mit der Codelaenge. Genau daran zerbricht eine Grenze, die nur
   * nach der Laenge EINES Codes bemessen ist.
   */
  for (let i = 0; i < 4; i++) {
    const code = fuellText ? ('MDC_' + 'Z'.repeat(L - 10) + i) : ('MDC_ECG_ELEC_POTL_' + i);
    p.kurvenDaten.push({ name: 'Kanal ' + i, code: code, hz: 256, skala: 1,
      samples: new Array(512).fill(0).map((_, j) => Math.sin(j / 8) * 100) });
  }
  return p;
}

const keyRegel = knotenAn(praxis, ['saele', '$station', 'patients', '$key']);
[false, true].forEach((fuellText) => {
  const wie = fuellText ? 'mit 2000 Zeichen in jedem Textfeld' : 'aus einem gewoehnlichen LifeVet-Rahmen';
  if (!cloudMod || !cloudMod.CloudPublisher) return;
  let rec = null, baufehler = null;
  try {
    const pub = new cloudMod.CloudPublisher({
      enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: 'http://127.0.0.1:1/',
      station: 'OP 1', stammdaten: true, rohwerte: true, kurven: true,
      authFile: path.join(os.tmpdir(), 'vetstation-regeln-test-nie-geschrieben.json'),
    }, { log: { info() {}, warn() {}, error() {} } });
    const snap = pub._buildSnapshot([musterPatient(fuellText)],
      [{ deviceId: 'd1', status: 'live', transport: 'tcp', taktMs: 1000, sekundenSeitDaten: 2 }]);
    rec = snap.patients[Object.keys(snap.patients)[0]];
  } catch (e) { baufehler = e.message; }
  ok('der echte Saal-Datensatz ' + wie + ' laesst sich bauen', !!rec,
    'Ohne Datensatz prueft dieser Abschnitt nichts und ist nur deshalb gruen.', baufehler);
  if (!rec) return;

  /*
   * Die beiden Felder, an denen der toedliche Befund hing, MUESSEN in der Probe stecken. Ohne
   * geladene Bewertungsengine entsteht kein "top" — dann waere dieser Abschnitt gruen, ohne das
   * Entscheidende geprueft zu haben. In diesem Fall wird die im Code belegte Form eingesetzt
   * (cloud.js:_assess()) und das ausdruecklich gesagt.
   */
  if (!rec.top || typeof rec.top !== 'object') {
    rec.top = { sev: 2, title: 'Ersatzform nach cloud.js:_assess()', tag: 'SpO2',
      fix: 'Bewertungsengine war nicht ladbar — Form aus dem Quelltext eingesetzt.', incident: 'hypoxaemie' };
    console.log('    Hinweis: brain/anaes nicht ladbar, "top" wurde in der im Code belegten Form eingesetzt.');
  }
  ok('die Probe ' + wie + ' enthaelt herkunft UND top als OBJEKT', typeof rec.herkunft === 'object'
    && rec.herkunft !== null && typeof rec.top === 'object' && rec.top !== null,
    'Ohne diese beiden Felder deckt die Formpruefung genau die Klasse nicht ab, an der der '
    + 'toedliche Befund hing — und waere gruen, weil sie nichts zu pruefen hatte.',
    'herkunft=' + typeof rec.herkunft + ' top=' + typeof rec.top);

  const befunde = [], ohneRegel = [];
  pruefeForm(rec, keyRegel, 'saele/$station/patients/$key', befunde, ohneRegel);
  ok('jedes Feld des echten Saal-Datensatzes ' + wie + ' geht durch seine Regel', befunde.length === 0,
    'Jedes Feld hier ist ein eigener Pfad im SELBEN atomaren Mehrpfad-PATCH wie die Vitalwerte '
    + '(cloud.js:_pfade() flacht je Patient genau eine Ebene ab). Ein ".validate", das auf EINEM '
    + 'dieser Pfade false ergibt, weist den GANZEN Koerper ab: die Datenbank antwortet '
    + 'PERMISSION_DENIED, cloud.js erkennt darin einen Konfigfehler und schaltet nach DREI Treffern '
    + 'die Fern-Uebertragung dauerhaft ab. Drei Takte sind weniger als eine Minute, und das gilt '
    + 'fuer JEDE Praxis gleichzeitig. Der Mehr-Saal-Betrieb uebertraegt dann nie einen einzigen '
    + 'Vitalwert, und der Fehler faellt erst gegen ein echtes Firebase-Projekt auf.',
    befunde.join('\n                '));
  ok('kein Feld des echten Saal-Datensatzes ' + wie + ' faellt aus dem Regelbaum heraus',
    ohneRegel.length === 0,
    'Ein Feld ohne Regel wird von Firebase ERLAUBT — es kann also nichts abweisen, aber es ist auch '
    + 'nicht gedeckelt. Genau dort landet der 5-MB-String, den jede offene Ansicht bei jedem Delta '
    + 'erneut laedt. Entweder das Feld namentlich aufnehmen oder die Auffangkette eine Stufe tiefer '
    + 'fuehren.', ohneRegel.join(' | '));
});

/*
 * Die Formtabelle darf nicht hinter cloud.js zuruecklaufen: JEDES Feld, das _buildSnapshot in den
 * Patientendatensatz schreibt, muss in der Probe vorkommen. Sonst pruefen wir kuenftig ein Feld
 * weniger, ohne dass es auffaellt.
 */
(function pruefeFeldabdeckung() {
  const quelle = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'cloud.js'), 'utf8');
  const start = quelle.indexOf('const rec = {');
  const felder = new Set();
  if (start >= 0) {
    let i = quelle.indexOf('{', start), tiefe = 0, ende = -1;
    for (; i < quelle.length; i++) {
      if (quelle[i] === '{') tiefe++;
      else if (quelle[i] === '}') { tiefe--; if (tiefe === 0) { ende = i; break; } }
    }
    const block = quelle.slice(start, ende + 1);
    // Nur die oberste Ebene des Literals: Einrueckung genau wie beim ersten Feld.
    const re = /^(\s+)([A-Za-z_]\w*)\s*:/gm;
    let m, tiefste = null;
    while ((m = re.exec(block)) !== null) {
      if (tiefste === null) tiefste = m[1].length;
      if (m[1].length === tiefste) felder.add(m[2]);
    }
  }
  const re2 = /\brec\.([A-Za-z_]\w*)\s*=/g;
  let m2;
  while ((m2 = re2.exec(quelle)) !== null) felder.add(m2[1]);
  const liste = Array.from(felder).sort();
  ok('die Felder von _buildSnapshot liessen sich aus cloud.js ablesen', liste.length >= 20,
    'Ohne diese Liste kann niemand merken, dass cloud.js ein neues Snapshotfeld bekommen hat. Der '
    + 'toedliche Befund war genau das: ein Feld, dessen Form niemand gegen die Regel gehalten hat.',
    liste.length + ' Felder: ' + liste.join(', '));
  const probe = (cloudMod && cloudMod.CloudPublisher) ? (function () {
    try {
      const pub = new cloudMod.CloudPublisher({
        enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: 'http://127.0.0.1:1/',
        station: 'OP 1', stammdaten: true, rohwerte: true, kurven: true,
        authFile: path.join(os.tmpdir(), 'vetstation-regeln-test-nie-geschrieben.json'),
      }, { log: { info() {}, warn() {}, error() {} } });
      const s = pub._buildSnapshot([musterPatient(false)], [{ deviceId: 'd1', status: 'live' }]);
      return s.patients[Object.keys(s.patients)[0]] || {};
    } catch (_) { return {}; }
  })() : {};
  const fehlend = liste.filter((f) => !(f in probe));
  ok('die Musterdaten dieses Tests deckeln JEDES Feld ab, das cloud.js wirklich schreibt',
    fehlend.length === 0,
    'Ein Feld, das cloud.js schreibt und dieser Test nicht baut, wird gegen keine Regel gehalten. '
    + 'Wird daraus je ein Objekt, ist es der naechste toedliche Befund — nur diesmal ohne '
    + 'Gegenpruefung. Musterpatient in musterPatient() ergaenzen, bis das Feld entsteht, und die '
    + 'Formtabelle im Kopf der Regeldatei nachziehen.', fehlend.join(', '));
  /*
   * DER SCHLUESSEL ALLEIN GENUEGT NICHT. Die Pruefung darueber fragte nur "steht der Name im
   * Snapshot?". Ein Feld, das cloud.js ausdruecklich als null materialisiert (rec.akte = ... : null
   * und die uebrigen Ersatz-null), galt damit als abgedeckt — obwohl pruefeForm null ueberspringt
   * (ein null loescht in der Realtime Database den Schluessel, und ".validate" wird bei Loeschungen
   * nicht ausgewertet). Die zugehoerigen Regeln wurden dann von keiner einzigen Zeile beruehrt, und
   * der Fehlertext versprach trotzdem vollstaendige Abdeckung. Gemessen: "akte" aus musterPatient()
   * entfernen liess den Test gruen — die Regeln fuer akte und akte/$feld pruefte danach nichts mehr.
   * Ein leeres Objekt und eine leere Liste sind derselbe Fall: pruefeForm steigt hinein und findet
   * nichts, was es gegen die Kindregel halten koennte.
   */
  const leer = liste.filter((f) => {
    if (!(f in probe)) return false;                 // schon oben gemeldet
    const v = probe[f];
    if (v === null || v === undefined) return true;
    if (typeof v === 'object' && Object.keys(v).length === 0) return true;
    return false;
  });
  ok('jedes dieser Felder traegt in den Musterdaten auch INHALT (null und leer pruefen nichts)',
    leer.length === 0,
    'Ein Feld, das in der Probe null oder leer ist, beruehrt keine einzige Regel: pruefeForm '
    + 'ueberspringt null, und in ein leeres Objekt bzw. eine leere Liste steigt es zwar hinein, '
    + 'findet dort aber nichts, was es gegen die Kindregel halten koennte. Die Regeln fuer dieses '
    + 'Feld und alles darunter sind damit UNGEPRUEFT, waehrend die Pruefung darueber vollstaendige '
    + 'Abdeckung meldet — genau die Sorte Test, die eine falsche Regeldatei bestehen laesst. '
    + 'Abhilfe: musterPatient() so ergaenzen, dass cloud.js das Feld mit Inhalt fuellt.',
    leer.join(', '));
})();

// --- 12b) Tafel: Kopfzeile, Kachel und Geraetezeile, auch in der kargsten Form ---
if (tafelMod) {
  const jetzt = Date.now();
  const sid = 'st0123456789ab';
  const platzhalter = { '.sv': 'timestamp' };
  const vollKachel = tafelMod.uebersichtSatz(musterPatient(false), { pri: 3.2, top: { title: 'SpO2 zu niedrig' } }, jetzt);
  const vollZeile = tafelMod.geraeteSatz({ deviceId: 'd1', model: 'LifeVet 10C', role: 'combo',
    status: 'live', ip: '192.168.0.9', port: 3500, transport: 'tcp', taktMs: 1000,
    werteAnzahl: 14, lastTs: jetzt - 500, patientKey: 'id_12345' }, jetzt, null);
  const faelle = [
    ['tafel/$station/meta (voll)', ['tafel', '$station', 'meta'],
      tafelMod.tafelSatz({ sid: sid, name: 'OP 1', jetzt: jetzt, sv: platzhalter, bv: '1.1.0',
        instanz: 'a1b2c3d4', taktMs: 1000, kurven: true, sq: 2,
        uebersicht: { id_12345: vollKachel }, geraete: { d1: vollZeile } })],
    /*
     * DER KARGE FALL IST DER WICHTIGE. Ein Saal ohne konfigurierten Namen schreibt meta OHNE
     * "name" (tafel.js:tafelSatz() setzt leere Felder gar nicht), und ohne Geraetezeile ist altMs null.
     * Ein hasChildren(['sid','name','ts']) haette damit den 1-Hz-Herzschlag abgewiesen — und jeder
     * andere Bildschirm im Haus meldet einen GESUNDEN Saal nach 12 s gelb und nach 60 s offline.
     */
    ['tafel/$station/meta (ohne Saalname, ohne altMs)', ['tafel', '$station', 'meta'],
      tafelMod.tafelSatz({ sid: sid, jetzt: jetzt, sv: platzhalter })],
    ['tafel/$station/uebersicht/$key (voll)', ['tafel', '$station', 'uebersicht', '$key'], vollKachel],
    /*
     * Ein gekoppeltes Geraet, das noch KEIN Datenpaket geliefert hat: registry.js:getDevices() liefert
     * seitMs = null, tafel.js macht daraus "Alter unbekannt" (N16 verlangt das ausdruecklich) und
     * laesst das Feld weg. Dazu fehlt ohne ts auch der Zeitstempel.
     */
    ['tafel/$station/uebersicht/$key (ohne ts, ohne altMs)', ['tafel', '$station', 'uebersicht', '$key'],
      tafelMod.uebersichtSatz({}, null, jetzt)],
    ['tafel/$station/geraete/$geraet (voll)', ['tafel', '$station', 'geraete', '$geraet'], vollZeile],
    ['tafel/$station/geraete/$geraet (noch kein Paket geliefert)', ['tafel', '$station', 'geraete', '$geraet'],
      tafelMod.geraeteSatz({ deviceId: 'd1', model: 'uMEC12 Vet', seitMs: null, lastTs: null }, jetzt, null)],
  ];
  faelle.forEach(([name, segmente, wert]) => {
    const befunde = [], ohneRegel = [];
    pruefeForm(wert, knotenAn(praxis, segmente), segmente.join('/'), befunde, ohneRegel);
    ok(name + ' geht durch seine Regel', befunde.length === 0,
      'Der Tafelkoerper geht als EIN atomarer 1-Hz-Schreibvorgang raus (Kopfzeile, alle Kacheln und '
      + 'alle Geraetezeilen zusammen, und in Stufe 2 zusaetzlich verbund/lan/<sid>). Eine einzige '
      + 'abgewiesene Zeile nimmt den ganzen Koerper mit: tafel/<sid>/meta.sv bleibt dann stehen, '
      + 'und jeder andere Bildschirm im Haus meldet nach 12 s gelb und nach 60 s "offline" fuer '
      + 'einen GESUNDEN Saal — bei laufender Narkose. LEERE FELDER FEHLEN GANZ (die Hilfsfunktion '
      + '"setzt" in tafel.js:uebersichtSatz(), tafel.js:geraeteSatz() und tafel.js:tafelSatz()), '
      + 'ein Pflichtfeld darauf ist deshalb kein Schutz, sondern diese Ablehnung.',
      befunde.join('\n                '));
    ok(name + ': kein Feld faellt aus dem Regelbaum heraus', ohneRegel.length === 0,
      'Ein Feld ohne Regel ist erlaubt, aber ungedeckelt — und die Tafel laedt JEDE offene '
      + 'Web-Ansicht im Dauerabonnement.', ohneRegel.join(' | '));
  });
}

// --- 12c) verbund/lan: Entwurfsform, weil noch kein Code sie baut -----------
{
  /*
   * EHRLICH BENANNT: diesen Knoten schreibt heute kein Code. Die Form stammt aus dem Plan
   * (Stufe 2). Geprueft wird deshalb vor allem der KARGE Fall — die Regel darf nicht mehr
   * verlangen, als der erste Schreibvorgang einer Station sicher liefern kann.
   */
  const seg = ['verbund', 'lan', '$station'];
  const sid = 'st0123456789ab';
  const faelle = [
    ['verbund/lan/$station (voll)', { sid: sid, pub: 'A'.repeat(44), fp: 'ab12cd34', port: 3599,
      ips: ['192.168.0.9', '10.0.0.5'], sv: { '.sv': 'timestamp' } }],
    ['verbund/lan/$station (erste Anmeldung, nur sid und sv)', { sid: sid, sv: { '.sv': 'timestamp' } }],
  ];
  faelle.forEach(([name, wert]) => {
    const befunde = [], ohneRegel = [];
    pruefeForm(wert, knotenAn(praxis, seg), seg.join('/'), befunde, ohneRegel);
    ok(name + ' geht durch seine Regel', befunde.length === 0,
      'In Stufe 2 liegt verbund/lan/<sid>.sv im SELBEN atomaren 1-Hz-Koerper wie die Vitalwerte. '
      + 'Ein Pflichtfeld, das der erste Schreibvorgang noch nicht liefern kann (der LAN-Dienst '
      + 'lauscht beim Anmelden vielleicht noch nicht), weist damit nicht nur die LAN-Anmeldung ab, '
      + 'sondern den Herzschlag des Saals — und ohne dass eine Meldung den Grund verraet.',
      befunde.join('\n                '));
    ok(name + ': kein Feld faellt aus dem Regelbaum heraus', ohneRegel.length === 0,
      'Siehe oben: erlaubt, aber ungedeckelt.', ohneRegel.join(' | '));
  });
}

// --- 12d) Der 1.0.3-Koerper auf der flachen Ebene --------------------------
if (cloudMod && cloudMod.CloudPublisher) {
  let flach = null;
  try {
    const pub = new cloudMod.CloudPublisher({
      enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: 'http://127.0.0.1:1/', station: 'OP 1',
      authFile: path.join(os.tmpdir(), 'vetstation-regeln-test-nie-geschrieben.json'),
    }, { log: { info() {}, warn() {}, error() {} } });
    flach = pub._buildSnapshot([musterPatient(false)], []).meta;
  } catch (_) { flach = null; }
  const pf = pflichtfelder(knotenAn(praxis, ['meta', '.validate']));
  ok('das echte flache meta erfuellt die Pflichtfelder des Bestandsblocks',
    !!flach && pf.length > 0 && pf.every((f) => flach[f] !== undefined && flach[f] !== null),
    'Der flache meta-Block gilt fuer JEDE ausgelieferte 1.0.3 und wird in JEDEM Takt geschrieben. '
    + 'Verlangt er ein Feld, das cloud.js nicht immer setzt, ist das eine Ablehnung pro Takt — die '
    + 'Selbstabschaltung aller Praxen binnen einer Minute.',
    'verlangt: ' + pf.join(', ') + ' | vorhanden: ' + (flach ? Object.keys(flach).join(', ') : '(kein meta)'));
}

/* ============================================================================
 * 12e) BELEGSTELLEN — jeder Verweis auf fremden Code muss ihn auch treffen
 * ========================================================================== */
/*
 * WARUM DAS EINE PRUEFUNG WERT IST.
 * Beide Dateien begruenden fast jede Lockerung mit einer Stelle im Code ("nur 'sid' ist Pflicht,
 * weil tafel.js leere Felder weglaesst"). Am 30.07.2026 nachgemessen: SAEMTLICHE tafel.js-Angaben
 * zeigten auf fremden Code — die Zeilen waren um rund 250 verrutscht, weil Funktionen dazukamen.
 * Der wahrscheinliche Ausgang ist nicht, dass jemand die Zahl korrigiert: er oeffnet die genannte
 * Zeile, findet dort etwas voellig anderes, haelt die Begruendung fuer erfunden und baut die
 * Verscharfung wieder ein, gegen die sie geschrieben wurde (also hasChildren(['sid','name','ts'])
 * — und damit die Ablehnung des atomaren 1-Hz-Koerpers, sobald ein Saal keinen Namen traegt).
 *
 * DESHALB: Belegstellen nennen ab jetzt die FUNKTION — Dateiname, Doppelpunkt, Funktionsname mit
 * Klammern —, nie eine Zeilennummer.
 * Ein Funktionsname wandert mit seinem Code mit und ist nachpruefbar — genau das tut diese
 * Pruefung. Eine Zeilennummer ist beim naechsten Einfuegen falsch, und niemand merkt es.
 */
console.log('\nJede Belegstelle zeigt auf Code, den es in der genannten Datei wirklich gibt:');
const eigenerText = fs.readFileSync(__filename, 'utf8');
const BELEG_DATEIEN = [
  ['installer/firebase-rtdb-rules.json', rohText],
  ['tools/regeln-test.js', eigenerText],
];
// Wo eine genannte Quelldatei liegen kann. Mehr Orte kosten nichts; ein fehlender Ort macht eine
// richtige Belegstelle faelschlich rot, und ein Falschalarm bringt die Pruefung in Verruf.
const QUELLORTE = [
  path.join(__dirname, '..', 'bridge', 'src'),
  path.join(__dirname, '..', 'bridge', 'src', 'adapters'),
  __dirname,
];
const quellCache = {};
function quelleLesen(name) {
  if (Object.prototype.hasOwnProperty.call(quellCache, name)) return quellCache[name];
  let inhalt = null;
  for (const ort of QUELLORTE) {
    try { inhalt = fs.readFileSync(path.join(ort, name), 'utf8'); break; } catch (_) { /* weiter */ }
  }
  quellCache[name] = inhalt;
  return inhalt;
}
/*
 * Eine DEFINITION suchen, nicht bloss das Vorkommen des Namens. Erlaubt sind die drei Formen, die
 * in diesem Projekt vorkommen: "function name(", die Methode einer Klasse ("  name(" bzw.
 * "  static name(") und "const name =". Ein blosser Aufruf zaehlt NICHT — sonst bestuende die
 * Pruefung auch fuer eine Funktion, die es nirgends mehr gibt.
 */
function definiert(quelle, name) {
  const n = name.replace(/[$]/g, '\\$');
  return new RegExp('(^|\\n)\\s*(static\\s+)?(async\\s+)?(function\\s+)?' + n + '\\s*\\(').test(quelle)
    || new RegExp('(^|\\n)\\s*(const|let|var)\\s+' + n + '\\s*=').test(quelle);
}
const belegFehler = [];
const zeilenVerweise = [];
let belegeGeprueft = 0;
BELEG_DATEIEN.forEach(([wo, inhalt]) => {
  // Belegstelle mit Funktionsnamen (Dateiname, Doppelpunkt, Name, Klammerpaar).
  const re = /\b([a-z][\w-]*\.js):([A-Za-z_$][\w$]*)\(\)/g;
  let m;
  while ((m = re.exec(inhalt)) !== null) {
    belegeGeprueft++;
    const quelle = quelleLesen(m[1]);
    if (quelle === null) { belegFehler.push(wo + ': Datei "' + m[1] + '" nicht gefunden'); continue; }
    if (!definiert(quelle, m[2])) belegFehler.push(wo + ': ' + m[1] + ' hat kein "' + m[2] + '"');
  }
  // Und keine Zeilennummer mehr, in keiner der beiden Dateien.
  const re2 = /\b([a-z][\w-]*\.js):(\d+)/g;
  let m2;
  while ((m2 = re2.exec(inhalt)) !== null) zeilenVerweise.push(wo + ': ' + m2[0]);
});
ok('es wurden ueberhaupt Belegstellen gefunden', belegeGeprueft >= 15,
  'Diese Pruefung waere sonst gruen, weil sie nichts zu pruefen hatte — und die naechste Aenderung '
  + 'duerfte wieder auf beliebigen Code zeigen.', 'gefunden: ' + belegeGeprueft);
ok('jede genannte Funktion gibt es in der genannten Datei', belegFehler.length === 0,
  'Eine Belegstelle, die ins Leere zeigt, ist schlimmer als keine: der naechste Baumeister haelt '
  + 'die Begruendung fuer erfunden und baut die Verscharfung wieder ein, gegen die sie geschrieben '
  + 'wurde. Bei tafel/<sid>/meta ist das hasChildren([\'sid\',\'name\',\'ts\']) — und damit die '
  + 'Ablehnung des atomaren 1-Hz-Koerpers samt Vitalwerten, sobald ein Saal keinen konfigurierten '
  + 'Namen traegt.', belegFehler.join(' | '));
ok('keine Belegstelle nennt eine Zeilennummer', zeilenVerweise.length === 0,
  'Zeilennummern sind beim naechsten Einfuegen falsch, und niemand merkt es: gemessen waren am '
  + '30.07.2026 alle tafel.js-Angaben um rund 250 Zeilen verrutscht. Ein Kommentar, der etwas '
  + 'anderes behauptet als der Code tut, ist schlimmer als kein Kommentar. Stattdessen die FUNKTION '
  + 'nennen (datei.js gefolgt von Doppelpunkt und Funktionsname mit Klammern) — das prueft die '
  + 'Zeile darueber nach.', zeilenVerweise.join(' | '));

/* ============================================================================
 * 13) Firestore: "allow list" bleibt getrennt und geschlossen
 * ========================================================================== */
console.log('\nFirestore laesst die Praxen weiterhin nicht auflisten:');
const fsText = fs.readFileSync(FS_DATEI, 'utf8');
ok('firestore-rules.txt enthaelt "allow list" mit false',
  /allow\s+list\s*:\s*if\s+false\s*;/.test(fsText),
  'In Firestore umfasst "allow read" BEIDES: get und list. Ohne ein eigenes, geschlossenes '
  + '"allow list" liefert ein anonymer ListDocuments-Aufruf mit showMissing=true die '
  + 'Dokument-Kennungen ALLER Praxen — also die komplette Kundenliste, und danach den Vollzugriff '
  + 'auf jeden Verlauf. Das war ein echtes Leck, nicht ein theoretisches.');
ok('der Verlauf bleibt unveraenderlich (update, delete: if false)',
  /allow\s+update,\s*delete\s*:\s*if\s+false\s*;/.test(fsText),
  'Der Firestore-Verlauf ist das loeschfeste Archiv. Laesst er sich aendern, gibt es kein '
  + 'Dokument mehr, das im Streitfall traegt.');
ok('der Auffangblock am Ende bleibt geschlossen',
  /match\s*\/\{document=\*\*\}\s*\{[\s\S]*?allow\s+read,\s*write\s*:\s*if\s+false\s*;/.test(fsText),
  'Ohne diesen Block waeren die frueheren Pfade unter /stationen und jeder kuenftige Pfad offen. '
  + 'Fail-closed muss auch in Firestore die letzte Zeile sein.');

/* ============================================================================
 * OFFEN — was dieser Test bewusst NICHT rot macht
 * ========================================================================== */
console.log('\nOFFEN (gehoert nicht in diese Dateien, aber hierher in Sichtweite):');
/*
 * DIESER BLOCK WAR SELBST EINE FALSCHE BUCHFUEHRUNG (Stand bis 30.07.2026). Er verengte die Luecke
 * auf den saele-Zweig ("bis dahin sind die Grenzen im saele-Zweig die EINZIGE Sperre") — wer das
 * las, hielt meta/station fuer gedeckt. meta/station war aber genau die niedrigste Grenze der
 * ganzen Datei und der einzige Fall, der HEUTE SCHON scharf war. Er ist inzwischen behoben (cloud.js
 * kappt den Saalnamen im Konstruktor) UND gebunden (Abschnitt 3c misst die Kappung gegen die
 * Regelgrenze). Damit dieser Block nicht ein zweites Mal hinter dem Code herlaeuft, zaehlt er die
 * Restluecke nicht mehr aus dem Gedaechtnis auf, sondern MISST sie: ein Musterpatient mit 5000
 * Zeichen in jedem Textfeld geht durch _buildSnapshot, und was danach noch 5000 Zeichen lang ist,
 * hat cloud.js ungekappt durchgereicht.
 */
console.log('  · N9 ist in bridge/src/cloud.js weiterhin nur ZUR HAELFTE umgesetzt: cloud.js kappt');
console.log('    inzwischen selbst (CloudPublisher._kurz/_kurzObjekt), benutzt aber NICHT die');
console.log('    gemeinsame Kappung aus tafel.js (tafel.kappe, gemessen ' + KAPP_WERT + ' Zeichen) — cloud.js');
console.log('    laedt tafel.js nach wie vor gar nicht. Zwei Kappungen fuer dieselbe Sache koennen');
console.log('    auseinanderlaufen; fuer meta/station ist genau das der behobene Befund gewesen.');
if (cloudMod && cloudMod.CloudPublisher) {
  let ungekappt = [];
  try {
    const pub = new cloudMod.CloudPublisher({
      enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: 'http://127.0.0.1:1/',
      station: 'OP 1', stammdaten: true, rohwerte: true, kurven: true,
      authFile: path.join(os.tmpdir(), 'vetstation-regeln-test-nie-geschrieben.json'),
    }, { log: { info() {}, warn() {}, error() {} } });
    const snap = pub._buildSnapshot([musterPatient(true, 5000)], [{ deviceId: 'd1', status: 'live' }]);
    const rec = snap.patients[Object.keys(snap.patients)[0]] || {};
    const sammle = (wert, pfad) => {
      if (typeof wert === 'string') { if (wert.length >= 5000) ungekappt.push(pfad); return; }
      if (wert && typeof wert === 'object') {
        Object.keys(wert).forEach((k) => sammle(wert[k], pfad + '/' + (/^\d+$/.test(k) ? '<i>' : k)));
      }
    };
    Object.keys(rec).forEach((k) => sammle(rec[k], k));
  } catch (e) { ungekappt = ['(nicht messbar: ' + e.message + ')']; }
  console.log('    GEMESSEN mit 5000 Zeichen in jedem Textfeld — ungekappt kommen heute durch:');
  console.log('      ' + (ungekappt.length ? ungekappt.join(', ') : '(nichts)'));
  console.log('    kurvenSig ist darin ABSICHTLICH ungekappt — ebenso kurven/<kanal>/b64, das in');
  console.log('    dieser Messung nur deshalb fehlt, weil die Musterkurven kurz sind. Beides sind');
  console.log('    Abtastwerte, keine Texte: eine Kappung zerstoerte die Kurve, und die Regeln');
  console.log('    lassen dort deshalb ' + BAND.saele.max + ' zu. Alles Uebrige ist der offene Rest von N9.');
}
console.log('    Solange dieser Rest offen ist, sind die Grenzen im saele-Zweig fuer ihn die EINZIGE');
console.log('    Sperre; deshalb stehen sie dort auf ' + BAND.saele.min + ' und nicht auf ' + KAPP_WERT + '.');
console.log('    Dieser Test macht das nicht rot, weil cloud.js ein anderer Baustein ist und ein');
console.log('    roter Test hier den Bau des Setups blockieren wuerde (alle-tests.js). Die eine');
console.log('    Stelle, die HEUTE SCHON scharf war — meta/station —, ist dagegen nicht mehr offen,');
console.log('    sondern in Abschnitt 3c gebunden und wird rot, sobald die Zahlen auseinanderlaufen.');

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
