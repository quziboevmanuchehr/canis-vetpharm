'use strict';
/*
 * vollauslesung-test.js — "Die App muss ALLES lesen, was das Geraet schickt."
 *
 * BEFUND 22.07.2026 (Praxis-PC, Eickemeyer LifeVet 10C auf 192.168.0.51):
 * Der Monitor war per HL7 verbunden und sendete. Am Bildschirm stand trotzdem nichts Brauchbares:
 * "? / ? kg", Zustand "stabil" in Gruen, daneben "warte auf Geraete...". Der Tierarzt schloss
 * daraus: "Die App liest ueberhaupt keine Daten."
 *
 * Tatsaechlich lasen wir NUR Zahlen, deren Code zufaellig in einer festen Tabelle stand:
 *   • hl7.js verwarf JEDEN Textwert stillschweigend (`if (!Number.isFinite(val)) continue`).
 *     Damit fielen Tierart ("Hund"), die Klartext-Alarme ("EKG-Ableitung ab", "Keine
 *     CO2-Wasserfalle") und alle Geraetemeldungen ersatzlos weg - ohne eine einzige Logzeile.
 *   • Das Gewicht (15,0 kg) erreichte die Dosisrechnung nie.
 *   • normalizeFrame() war eine Positivliste: was dort nicht stand, existierte danach nicht mehr.
 *   • brain.js rechnete bei fehlender Tierart still mit "Hund", bei fehlendem Gewicht mit 10 kg -
 *     und die Oberflaeche zeigte die daraus folgenden mL-Mengen, als waeren sie belegt.
 *   • Ein Patient OHNE einen einzigen Messwert wurde gruen als "stabil" ausgewiesen.
 *
 * Dieser Test haelt jede dieser Stellen fest. Er prueft die Kette
 *   HL7-Text -> parseHL7Message -> normalizeFrame -> mergePatients
 * und zusaetzlich statisch die Oberflaeche.
 *
 * Start: node tools/vollauslesung-test.js      (laeuft auch in tools/alle-tests.js)
 */
const fs = require('fs');
const path = require('path');
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const { normalizeFrame } = require('../bridge/src/model');
const { mergePatients } = require('../bridge/src/matching');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function read(rel) { try { return fs.readFileSync(path.join(__dirname, '..', rel), 'utf8').replace(/\r\n/g, '\n'); } catch (_) { return ''; } }
function hl7(zeilen, cfg, unmapped) { return parseHL7Message(zeilen.join('\r'), cfg || { deviceId: 't' }, unmapped || function () {}); }

console.log('VetStation — die Station liest ALLES, was das Geraet schickt\n');

/* ---------------- 1) Die Nachricht des Praxisgeraets ---------------- */
// Nachgebaut nach dem, was am 22.07.2026 tatsaechlich auf Port 8830 ankam, ergaenzt um die
// Stammdaten, die am Monitor unter "Patientenverwaltung" stehen (ID 1234, Hund, 15,0 kg).
const PRAXIS = [
  'MSH|^~\\&|LifeVet||VetStation||20260722194700||ORU^R01|1|P|2.3.1',
  'PID|1||1234||Quziboev^Manuchehr||20170101|M',
  'OBR|1||||||20260722194700',
  'OBX|1|ST|68481^MDC_ATTR_PT_TYPE||Hund||||||F',
  'OBX|2|NM|188736^MDC_ATTR_PT_WEIGHT||15.0|kg|||||F',
  'OBX|3|ST|262196^MDC_EVT_INOP||EKG-Ableitung ab||||||F',
  'OBX|4|ST|196616^MDC_EVT_ALARM||Keine CO2-Wasserfalle||||||F',
  'OBX|5|NM|131330^MDC_ECG_ELEC_POTL_II||0.12|uV|||||F',
];

console.log('Stammdaten vom Geraet (vorher komplett verloren):');
const unbekannt = [];
const roh1 = hl7(PRAXIS, { deviceId: 'assistent-8830', model: 'LifeVet 10C', role: 'combo', deviceIp: '192.168.0.51', devicePort: 8830, transport: 'HL7/MLLP' }, function (u) { unbekannt.push(u); });
ok('Patienten-ID wird gelesen', roh1.patientId === '1234', roh1.patientId);
ok('Patientenname wird gelesen', /Manuchehr/.test(roh1.patientName || ''), roh1.patientName);
ok('TIERART kommt vom Geraet an ("Hund" -> hund)', roh1.species === 'hund', String(roh1.species));
ok('GEWICHT kommt vom Geraet an (15,0 kg)', roh1.weightKg === 15, String(roh1.weightKg));
ok('die Herkunft ist nachvollziehbar (Geraet, nicht geraten)',
  roh1.herkunft && roh1.herkunft.species === 'geraet' && roh1.herkunft.weightKg === 'geraet',
  JSON.stringify(roh1.herkunft));
ok('Geschlecht wird gelesen', roh1.geschlecht === 'M', String(roh1.geschlecht));
ok('Adresse und Port des Geraets stehen im Frame',
  roh1.deviceIp === '192.168.0.51' && roh1.devicePort === 8830, roh1.deviceIp + ':' + roh1.devicePort);

console.log('\nKlartextmeldungen des Geraets (erklaeren, WARUM ein Wert fehlt):');
const texte = (roh1.alarms || []).map(function (a) { return a.text; });
ok('"EKG-Ableitung ab" kommt an', texte.indexOf('EKG-Ableitung ab') >= 0, texte.join(' / '));
ok('"Keine CO2-Wasserfalle" kommt an', texte.indexOf('Keine CO2-Wasserfalle') >= 0, texte.join(' / '));
ok('die Meldungen sind Klartext, keine Codes', texte.every(function (t) { return !/^MDC_|^\d+\^/.test(t); }));

console.log('\nNichts wird mehr stillschweigend verworfen:');
ok('JEDER OBX-Eintrag steht in den Rohwerten', roh1._meta.roh.length === 5, String(roh1._meta.roh.length));
ok('auch der Textwert "Hund" ist darunter',
  roh1._meta.roh.some(function (x) { return x.wert === 'Hund'; }));
ok('Einheiten werden mitgefuehrt',
  roh1._meta.roh.some(function (x) { return x.einheit === 'kg'; }));
ok('Kurvenpunkte gelten NICHT als fehlende Zuordnung', unbekannt.length === 0, unbekannt.join(', '));

/* ---------------- 2) Bis zum Patienten durchgereicht ---------------- */
console.log('\nDie Angaben ueberleben normalizeFrame und die Zusammenfuehrung:');
const n1 = normalizeFrame(roh1).frame;
ok('normalizeFrame behaelt die Tierart', n1.species === 'hund');
ok('normalizeFrame behaelt das Gewicht', n1.weightKg === 15);
ok('normalizeFrame behaelt die Rohwerte', (n1.roh || []).length === 5);
ok('normalizeFrame behaelt die Geraeteadresse', n1.deviceIp === '192.168.0.51');
const pats = mergePatients([{ deviceId: 'assistent-8830', model: 'LifeVet 10C', role: 'combo', frame: n1 }], {});
const P = pats[0];
ok('der Patient traegt Tierart und Gewicht', P.species === 'hund' && P.weightKg === 15);
ok('der Patient traegt die Geraetemeldungen', (P.alarms || []).length >= 2);
ok('der Patient traegt die Rohwerte, mit Angabe des liefernden Geraets',
  (P.roh || []).length === 5 && P.roh[0].von === 'assistent-8830');

/* ---------------- 3) Einheiten: umrechnen oder ehrlich weglassen ---------------- */
console.log('\nEinheiten werden geprueft, nicht angenommen (sicherheitskritisch):');
const kpa = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|220^EtCO2||5.3|kPa|||||F']);
ok('EtCO2 in kPa wird nach mmHg umgerechnet (5,3 kPa ~ 40 mmHg)',
  kpa.vitals.etco2 > 38 && kpa.vitals.etco2 < 42, String(kpa.vitals.etco2));
ok('die Umrechnung wird protokolliert', (kpa._meta.umrechnungen || []).length === 1, JSON.stringify(kpa._meta.umrechnungen));
const fahr = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|200^Temp||98.6|[degF]|||||F']);
ok('Temperatur in Fahrenheit wird nach Celsius umgerechnet (98,6 F = 37,0 C)',
  fahr.vitals.temp === 37, String(fahr.vitals.temp));
const fremd = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|220^EtCO2||42|xyz|||||F']);
ok('unbekannte Einheit: der Wert wird NICHT als Messwert uebernommen',
  fremd.vitals.etco2 == null, String(fremd.vitals.etco2));
ok('stattdessen gibt es eine Klartextmeldung',
  (fremd.alarms || []).some(function (a) { return /unbekannten? Einheit/.test(a.text); }),
  JSON.stringify(fremd.alarms));
ok('und der Wert bleibt als Rohwert sichtbar', (fremd._meta.roh || []).length === 1);

/* ---------------- 4) Alarmstufe des Geraets ---------------- */
console.log('\nDas Geraet markiert einen Wert selbst als kritisch (OBX-8):');
const hoch = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|101^HR||210|bpm||HH||F']);
ok('Flag HH erzeugt eine Meldung', (hoch.alarms || []).length === 1, JSON.stringify(hoch.alarms));
ok('die Meldung ist in Alltagssprache, ohne Kuerzel',
  /Herzfrequenz zu hoch/.test(hoch.alarms[0].text) && !/HH|OBX/.test(hoch.alarms[0].text),
  hoch.alarms[0] && hoch.alarms[0].text);
ok('der Messwert selbst bleibt erhalten', hoch.vitals.hr === 210);
const normal = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|101^HR||88|bpm||N||F']);
ok('Flag N erzeugt KEINE Meldung', (normal.alarms || []).length === 0);

/* ---------------- 5) Gewicht: streng, weil daraus mL werden ---------------- */
console.log('\nGewicht wird nur uebernommen, wenn es belegt ist:');
const lb = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|188736^MDC_ATTR_PT_WEIGHT||33.1|lb|||||F']);
ok('Pfund wird nach kg umgerechnet (33,1 lb = 15,0 kg)',
  Math.abs(lb.weightKg - 15) < 0.1, String(lb.weightKg));
const unsinn = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|188736^MDC_ATTR_PT_WEIGHT||900|kg|||||F']);
ok('ein unplausibles Gewicht wird NICHT uebernommen (lieber keins als ein falsches)',
  unsinn.weightKg == null, String(unsinn.weightKg));
const freitext = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|ST|99^Bemerkung||Der Hund ist ruhig||||||F']);
ok('Tierart wird NICHT aus beliebigem Freitext geraten', freitext.species == null, String(freitext.species));

/* ---------------- 6) Ehrlichkeit der Bewertung ---------------- */
console.log('\nDie Bewertung sagt, was sie NICHT weiss:');
const brainSrc = read('ui/engine/brain.js');
ok('assess meldet, wenn gar kein Messwert vorliegt (keineDaten)', /keineDaten/.test(brainSrc));
ok('assess legt die Ersatzwerte offen (annahmen)', /annahmen/.test(brainSrc));
ok('assess benennt die fehlenden Parameter (fehlt)', /fehlt: fehlt/.test(brainSrc));
ok('die Ersatzwerte "hund"/10 kg sind weiterhin dokumentiert, aber gekennzeichnet',
  /ersatz/.test(brainSrc) && /patient\.species \|\| 'hund'/.test(brainSrc));

const live = read('ui/vetstation-live.js');
ok('die Oberflaeche kennt den Zustand "KEINE WERTE"', /KEINE WERTE/.test(live));
ok('und benutzt ihn statt "stabil", wenn keine Daten vorliegen',
  /res\.keineDaten \? 'KEINE WERTE'/.test(live) || /keineDaten \? 'KEINE WERTE'/.test(live));
ok('fehlende Tierart/Gewicht werden als fehlend gezeigt, nicht ersetzt',
  /Tierart \?/.test(live) && /Gewicht \?/.test(live));

/* ---------------- 7) Geraete-Menue beantwortet "was haengt dran?" ---------------- */
console.log('\nGeraete-Menue zeigt das tatsaechlich verbundene Geraet:');
ok('es zeigt Adresse und Port', /d\.ip/.test(live) && /d\.port/.test(live));
ok('es zeigt, wie viele Messwerte anliegen', /d\.werteAnzahl/.test(live));
ok('es zeigt die Klartextmeldungen des Geraets', /d\.alarms/.test(live));
ok('es gibt eine Ansicht "Alle Werte vom Geraet"', /Alle Werte vom Ger/.test(live));
ok('diese Ansicht holt die Daten auf Abruf ueber /api/geraet', /api\/geraet/.test(live));
ok('die wandernden Zeitangaben stehen NICHT in der Neuaufbau-Signatur (Tippschutz)',
  /aktualisierePairingZeiten/.test(live) && !/d\.seitMs,/.test(live) && !/d\.taktMs,/.test(live));
ok('sie werden per textContent nachgefuehrt (kein innerHTML im Takt)',
  /el\.textContent !== t/.test(live));
ok('der Leerzustand widerspricht sich nicht mehr selbst',
  /es kommen noch keine Messwerte/.test(live));
ok('der Wortlaut "warte auf Geraete" bleibt fuer den Fall OHNE Geraet erhalten',
  /warte auf Ger/.test(live));

const server = read('bridge/src/server.js');
ok('der Server liefert die Rohwerte eines Geraets', /'\/api\/geraet'/.test(server));
ok('und tut das NUR auf Abruf, nicht im Rundruf', !/roh:/.test(read('bridge/src/server.js').split('broadcast')[1] || ''));

const reg = read('bridge/src/registry.js');
ok('die Registry liefert Adresse, Port und Sendetakt', /taktMs/.test(reg) && /ip: f\.deviceIp/.test(reg));
ok('sie unterscheidet "verbunden" von "verbunden UND misst"', /werteAnzahl/.test(reg) && /zaehleWerte/.test(reg));
ok('ein Geraet mit 30-s-Takt faellt nicht mehr faelschlich auf offline',
  /STANDBY_MS = 90000/.test(reg));

/* ---------------- 7b) Empfehlungen AUCH ohne Narkosegeraet ----------------
 * Die Kreuzregeln R4/R5 setzen die Verdampfer-Einstellung voraus - die liefert ein Monitor nicht.
 * Haengt nur der Monitor an der Station (der Normalfall), feuerte deshalb KEINE Regel, und der
 * Einzelwert-Befund trug ein leeres "fix": der Tierarzt sah "Blutdruck zu niedrig" und sonst nichts.
 */
console.log('\nZwischenfall erkannt -> konkrete Empfehlung (auch ohne Narkosegeraet):');
const { loadAnaes } = require('../bridge/src/anaes');
const brain = require('../ui/engine/brain');
const dosis = require('../ui/engine/dose');
const AN = loadAnaes();

const brady = brain.assess(AN, { species: 'hund', weightKg: 15, hr: 38, spo2: 96, etco2: 35, map: 70, af: 10, temp: 37 });
ok('Bradykardie wird erkannt', !!brady.top && /Herzfrequenz/.test(brady.top.title), brady.top && brady.top.title);
ok('es gibt eine Sofortmassnahme (vorher leer)', !!brady.top.fix, brady.top.fix);
ok('es gibt eine Geraete-Korrektur', /Isofluran/.test(brady.top.geraet || ''), brady.top.geraet);
ok('es gibt eine geordnete Schrittfolge', (brady.top.schritte || []).length >= 3, String((brady.top.schritte || []).length));
const injH = dosis.injectionsFor(AN, brady.top.incident, 'hund', 15).filter(function (x) { return x.available; });
ok('und eine fertige mL-Menge fuer 15 kg Hund', injH.length > 0 && injH[0].mlLo > 0,
  injH[0] && (injH[0].name + ' ' + injH[0].mlLo + '-' + injH[0].mlHi + ' mL'));

const injK = dosis.injectionsFor(AN, brady.top.incident, 'katze', 4.2).filter(function (x) { return x.available; });
ok('die Menge ist artspezifisch (Katze 4,2 kg ergibt eine andere Menge als Hund 15 kg)',
  injK.length > 0 && injK[0].mlLo !== injH[0].mlLo, (injK[0] && injK[0].mlLo) + ' vs ' + injH[0].mlLo);

const hypo = brain.assess(AN, { species: 'hund', weightKg: 15, hr: 80, spo2: 96, etco2: 35, map: 48, af: 10, temp: 37 });
ok('Hypotonie wird erkannt und benannt', /Blutdruck/.test(hypo.top.title), hypo.top.title);
ok('mit Sofortmassnahme statt nur einer Feststellung', /Isofluran/.test(hypo.top.fix || ''), hypo.top.fix);

const app = read('ui/app.js');
ok('das Patientenfenster zeigt die Geraete-Korrektur', /f\.geraet/.test(app));
ok('und die Schrittfolge', /f\.schritte/.test(app));
ok('OHNE Gewicht wird KEINE mL-Menge angezeigt (kein stiller 10-kg-Ersatzwert)',
  /p\.weightKg == null/.test(app) && !/injectionsFor\(A\(\), f\.incident, p\.species \|\| 'hund', p\.weightKg \|\| 10\)/.test(app));
ok('stattdessen wird zum Eintragen des Gewichts aufgefordert', /Gewicht fehlt/.test(app));

/* ---------------- 7c) Echte Kurven des Geraets ----------------
 * Am Praxisgeraet gemessen (22.07.2026): das LifeVet packt Abtastwerte einer Kurve in EIN
 * OBX-Feld, getrennt durch "^", und beschreibt sie mit MDC_ATTR_SAMP_RATE (256 Hz fuer EKG,
 * 40 Hz fuer CO2). Der Parser machte daraus per parseFloat die ERSTE Zahl - also einen
 * erfundenen Einzelmesswert. Ausserdem steht 32767 fuer "kein Wert" (Ableitung ab).
 */
console.log('\nEchte Kurven und Ungueltig-Marker:');
const ekgWerte = Array.from({ length: 20 }, function (_, i) { return Math.round(Math.sin(i / 3) * 100); }).join('^');
const mitKurve = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1',
  'OBX|1|NM|131330^MDC_ECG_ELEC_POTL_II||' + ekgWerte + '|uV|||||F',
  'OBX|2|NM|0^MDC_ATTR_SAMP_RATE||256|Hz|||||F',
  'OBX|3|NM|2327^MDC_ATTR_NU_MSMT_RES||1.000000||||||F',
  'OBX|4|NM|101^MDC_ECG_HEART_RATE||88|bpm|||||F']);
ok('ein Kurvenblock wird als Kurve erkannt', (mitKurve.kurvenDaten || []).length === 1, String((mitKurve.kurvenDaten || []).length));
ok('mit Abtastrate', mitKurve.kurvenDaten[0].hz === 256, String(mitKurve.kurvenDaten[0].hz));
ok('und allen Abtastwerten', mitKurve.kurvenDaten[0].samples.length === 20);
ok('er wird NICHT als Einzelmesswert missdeutet (frueher: erste Zahl des Blocks)',
  mitKurve.vitals.spo2 == null && mitKurve.vitals.etco2 == null);
ok('ein danach folgender echter Messwert wird weiterhin gelesen', mitKurve.vitals.hr === 88, String(mitKurve.vitals.hr));

const marker = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|101^MDC_ECG_HEART_RATE||32767|bpm|||||F']);
ok('DER GEFAEHRLICHE FALL: 32767 ("Ableitung ab") wird NICHT zur Herzfrequenz',
  marker.vitals.hr == null, String(marker.vitals.hr));
const nurMarker = hl7(['MSH|^~\\&|L||||||ORU^R01|1|P|2.3.1',
  'OBX|1|NM|151780^MDC_IMPED_TTHOR||32767^32767^32767^32767^32767|uV|||||F',
  'OBX|2|NM|0^MDC_ATTR_SAMP_RATE||256|Hz|||||F']);
ok('eine Kurve aus lauter Ungueltig-Werten wird nicht als darstellbar ausgegeben',
  (nurMarker.kurvenDaten || []).length === 0, 'keine leere Linie vortaeuschen');

/* ---------------- 7d) Bandbreite des Rundrufs ----------------
 * Der Rundruf geht 2x pro Sekunde an JEDES offene Fenster. Rohwerte und Kurven gehoeren dort
 * nicht hinein: die Oberflaeche liest sie im Rundruf nie (Rohwerte auf Klick ueber /api/geraet).
 */
console.log('\nDer 500-ms-Rundruf bleibt schlank:');
const { mergePatients: mp, fuerRundruf } = require('../bridge/src/matching');
const { normalizeFrame: nf } = require('../bridge/src/model');
const vieleRoh = Array.from({ length: 60 }, function (_, i) {
  return { code: '' + i, bezeichnung: 'MDC_TEST_' + i, wert: '123.4', einheit: 'mmHg', flag: null };
});
const langeKurve = Array.from({ length: 512 }, function (_, i) { return i % 100; });
const gross = nf({
  deviceId: 'd1', deviceModel: 'LifeVet 10C', vitals: { hr: 88, spo2: 97 },
  kurvenDaten: [{ name: 'EKG', code: 'ECG', hz: 256, skala: 1, samples: langeKurve }],
  _meta: { roh: vieleRoh, kurven: ['EKG-Kurve'] },
}).frame;
const patVoll = mp([{ deviceId: 'd1', model: 'x', role: 'combo', frame: gross }], {});
const patSchlank = fuerRundruf(patVoll);
const kbVoll = JSON.stringify(patVoll).length / 1024;
const kbSchlank = JSON.stringify(patSchlank).length / 1024;
ok('Rohwerte sind aus dem Rundruf entfernt', !/"roh"/.test(JSON.stringify(patSchlank)));
ok('Kurven-Abtastwerte ebenfalls', !/"kurvenDaten"/.test(JSON.stringify(patSchlank)));
ok('der Rundruf bleibt unter 2 KB je Patient', kbSchlank < 2, kbSchlank.toFixed(2) + ' KB');
ok('und ist deutlich kleiner als vorher', kbSchlank < kbVoll / 5,
  kbVoll.toFixed(1) + ' KB -> ' + kbSchlank.toFixed(2) + ' KB');
ok('die Vitalwerte bleiben vollstaendig erhalten', patSchlank[0].vitals.hr === 88 && patSchlank[0].vitals.spo2 === 97);
ok('die Kurven-NAMEN bleiben (fuers Geraete-Menue, wenige Bytes)', (patSchlank[0].kurven || []).length === 1);
ok('der Server benutzt den schlanken Rundruf', /fuerRundruf\(patients\)/.test(read('bridge/src/server.js')));

/* ---------------- 7e) Keine vorbelegten Normwerte als Messung ausgeben ---------------- */
console.log('\nNicht gemessene Werte bleiben leer (statt auf Normwerten stehenzubleiben):');
ok('ein nicht geliefertes Feld wird im Fenster GELEERT',
  /if \(val == null\)[\s\S]{0,120}inp\.value = ''/.test(live));
ok('und der Grund steht als Begruendung im Quelltext',
  /NORMWERTEN der Tierart vor/.test(live));
ok('das virtuelle Narkosegeraet wird live gefuehrt (Verdampfer/Fluss/Beatmung/Parameter)',
  /d\.iso = p\.isoPct/.test(live) && /d\.mode = id/.test(live) && /p\.ventParams/.test(live) && /renderMachine/.test(live));
ok('aber NUR, wenn ein Geraet den Wert wirklich liefert UND er sich aendert (Handeingabe bleibt stehen)',
  /p\.isoPct != null/.test(live) && /p\.isoPct !== d\.__last\.iso/.test(live));

/* ---------------- 7f) Geraetename: OBR-4 ist NICHT der Geraetename ----------------
 * Am Praxis-PC stand im Geraete-Menue "CONTINUOUS WAVEFORM" als Modell. Das ist OBR-4
 * (Universal Service ID) - also WAS gemessen wird, nicht WER misst. Der Name des sendenden
 * Geraets steht in MSH-3.
 */
console.log('\nGeraetename kommt aus MSH-3, nicht aus OBR-4:');
const mitNamen = hl7(['MSH|^~\\&|LifeVet 10C||VetStation||20260722||ORU^R01|1|P|2.3.1',
  'OBR|1|||CONTINUOUS WAVEFORM|||20260722',
  'OBX|1|NM|101^MDC_ECG_HEART_RATE||88|bpm|||||F'], { deviceId: 't', devicePort: 8830 });
ok('das Modell heisst wie das Geraet', mitNamen.deviceModel === 'LifeVet 10C', mitNamen.deviceModel);
ok('und NICHT "CONTINUOUS WAVEFORM"', !/CONTINUOUS/i.test(mitNamen.deviceModel), mitNamen.deviceModel);
const ohneNamen = hl7(['MSH|^~\\&|||||||ORU^R01|1|P|2.3.1', 'OBR|1|||CONTINUOUS WAVEFORM',
  'OBX|1|NM|101^HR||70|bpm|||||F'], { deviceId: 't', devicePort: 8830 });
ok('ohne Absendername gibt es einen neutralen Ersatz mit Port',
  /Port 8830/.test(ohneNamen.deviceModel), ohneNamen.deviceModel);

console.log('\nHandeintrag des Tierarztes bleibt als solcher erkennbar:');
const reg2 = read('bridge/src/registry.js');
ok('ein manuell gesetztes Gewicht wird als "manuell" gekennzeichnet',
  /herkunft\.weightKg = 'manuell'/.test(reg2));
ok('ebenso die Tierart', /herkunft\.species = 'manuell'/.test(reg2));

/* ---------------- 7g) Stammdaten ueberleben karge Folgenachrichten ----------------
 * DER FEHLER, DER "erkennt keine Patientendaten" AUSLOESTE (23.07.2026):
 * Das LifeVet sendet Name+ID (PID) in JEDER Nachricht, Tierart+Gewicht aber nur EINMAL beim
 * Bestaetigen des Patientendialogs. Die naechste Nachricht (nur MDC_EVT_INOP) trug sie nicht mehr,
 * und die Registry behielt immer nur die LETZTE Nachricht - nach einer Sekunde waren Tierart und
 * Gewicht wieder leer. Der Name blieb (steht in jedem PID), Tierart/Gewicht verschwanden.
 */
console.log('\nStammdaten bleiben erhalten, wenn Folgenachrichten sie nicht wiederholen:');
const { Registry } = require('../bridge/src/registry');
const stumm = { info() {}, warn() {}, error() {} };
const regT = new Registry({ log: stumm });
const DEV = 'assistent-8830-192.168.0.51';
function ingMsg(zeilen) {
  regT.ingest(Object.assign({ deviceId: DEV }, hl7(zeilen, { deviceId: DEV, model: null, deviceIp: '192.168.0.51', devicePort: 8830 })));
}
ingMsg(['MSH|^~\\&|LifeVet||||20260723||ORU^R01|1|P|2.3.1', 'PID|1||1234||Quziboev^Manuchehr||20170101|M',
  'OBX|1|ST|1^MDC_ATTR_PT_TYPE||Hund||||||F', 'OBX|2|NM|2^MDC_ATTR_PT_WEIGHT||15.0|kg|||||F',
  'OBX|3|NM|3^MDC_ATTR_PT_HEIGHT||62|cm|||||F']);
for (let i = 0; i < 5; i++) {
  ingMsg(['MSH|^~\\&|LifeVet||||20260723||ORU^R01|' + (i + 2) + '|P|2.3.1', 'PID|1||1234||Quziboev^Manuchehr||20170101|M',
    'OBX|1|NM|9^MDC_EVT_INOP||32767||||||F']);
}
const dev1 = regT.getDevices()[0];
ok('der Name bleibt (steht in jedem PID)', dev1.patientName === 'Manuchehr Quziboev', dev1.patientName);
ok('die TIERART bleibt erhalten (vorher nach 1 s weg)', dev1.species === 'hund', String(dev1.species));
ok('das GEWICHT bleibt erhalten', dev1.weightKg === 15, String(dev1.weightKg));
ok('die Groesse aus der Akte bleibt erhalten', dev1.akte && dev1.akte.groesseCm === 62, JSON.stringify(dev1.akte));

// Gegenprobe: neuer Patient (andere ID) darf die alten Daten NICHT erben.
ingMsg(['MSH|^~\\&|LifeVet||||20260723||ORU^R01|9|P|2.3.1', 'PID|1||9999||Neu^Katze||20200101|W',
  'OBX|1|NM|9^MDC_EVT_INOP||32767||||||F']);
const dev2 = regT.getDevices()[0];
ok('bei neuer Patienten-ID wird der Name gewechselt', /Katze/.test(dev2.patientName || ''), dev2.patientName);
ok('und die Tierart des ALTEN Patienten NICHT uebernommen', dev2.species == null, String(dev2.species));
ok('und das Gewicht des alten Patienten NICHT uebernommen', dev2.weightKg == null, String(dev2.weightKg));

/* ---------------- 7h) Handeintrag bleibt an den Patienten gebunden erhalten ----------------
 * Der echte Datenstrom des LifeVet ist belegt (23.07.2026): das Geraet sendet ueber HL7 nur ID,
 * Name und Geschlecht - NICHT Tierart, Gewicht, Groesse. Die traegt der Tierarzt von Hand ein.
 * Damit er das nicht bei jeder Narkose neu tun muss, wird der Eintrag an die Patienten-ID gebunden
 * gespeichert und ueberlebt Neustarts - ein ANDERER Patient (andere ID) erbt ihn aber nie.
 */
console.log('\nHandeintrag (Tierart/Gewicht) bleibt an die Patienten-ID gebunden erhalten:');
const _os = require('os');
const _fs = require('fs');
const _pt = require('path');
const akteDatei = _pt.join(_os.tmpdir(), 'vs-akte-test-' + process.pid + '.json');
try { _fs.unlinkSync(akteDatei); } catch (_) {}
const DEV2 = 'assistent-8830-192.168.0.51';
const echtPID = ['MSH|^~\\&|MINDRAY_N-SERIES^X^EUI-64||||20260723||ORU^R01|1|P|2.3.1',
  'PID|||1234^^^Hospital^PI||Quziboev^Manuchehr^^^^^L|||M||Unknown', 'OBX|1|NM|262196^MDC_EVT_INOP||32767||||||F'];
function ingPID(reg, zeilen) {
  reg.ingest(Object.assign({ deviceId: DEV2 }, hl7(zeilen || echtPID, { deviceId: DEV2, model: null, deviceIp: '192.168.0.51', devicePort: 8830 })));
}
const rA = new Registry({ log: stumm }); rA.akteDatei = akteDatei; rA.akteStore = {};
ingPID(rA);
ok('das Geraet liefert Tierart/Gewicht NICHT (nur ID/Name/Geschlecht)',
  rA.getDevices()[0].species == null && rA.getDevices()[0].weightKg == null);
ok('aber ID, Name und Geschlecht kommen an',
  rA.getDevices()[0].patientId === '1234' && /Manuchehr/.test(rA.getDevices()[0].patientName) && rA.getDevices()[0].geschlecht === 'M');
rA.setMeta(DEV2, { species: 'hund', weightKg: 15 });
ingPID(rA);
ok('nach Handeintrag stehen Tierart und Gewicht', rA.getDevices()[0].species === 'hund' && rA.getDevices()[0].weightKg === 15);
ok('der Eintrag wurde auf die Platte geschrieben (an die ID gebunden)',
  _fs.existsSync(akteDatei) && /"1234"/.test(_fs.readFileSync(akteDatei, 'utf8')));
// Neustart simulieren: neue Registry laedt die Datei.
const rB = new Registry({ log: stumm }); rB.akteDatei = akteDatei;
rB.akteStore = JSON.parse(_fs.readFileSync(akteDatei, 'utf8'));
ingPID(rB);
ok('nach einem Neustart wird der Eintrag automatisch wiederhergestellt',
  rB.getDevices()[0].species === 'hund' && rB.getDevices()[0].weightKg === 15);
ok('und ist als "manuell" gekennzeichnet (keine Geraetemessung)',
  rB.getDevices()[0].herkunft && rB.getDevices()[0].herkunft.weightKg === 'manuell');
// Sicherheit: anderer Patient erbt den Eintrag NICHT.
ingPID(rB, ['MSH|^~\\&|X||||20260723||ORU^R01|9|P|2.3.1', 'PID|||9999^^^Hospital^PI||Neu^Katze^^^^^L|||W||Unknown', 'OBX|1|NM|262196^MDC_EVT_INOP||32767||||||F']);
ok('ein ANDERER Patient (ID 9999) erbt Tierart/Gewicht NICHT',
  rB.getDevices()[0].species == null && rB.getDevices()[0].weightKg == null, 'Sicherheit');
try { _fs.unlinkSync(akteDatei); } catch (_) {}

/* ---------------- 7i) "Patient Information Change"-Nachricht (Mindray PDS v14.2) ----------------
 * Belegt aus dem offiziellen Mindray Patient Data Share Protocol Programmer's Guide v14.2
 * (recherchiert 23.07.2026): Gewicht/Groesse kommen NICHT im PID und NICHT als MDC-Code, sondern
 * als OBX mit Mindray-Eigencode 51^Weight (kg) / 52^Height (cm), in einer SEPARATEN Nachricht, die
 * nur beim Verbindungsaufbau gesendet wird. Ein Gewicht 0.0 heisst "kein Patient eingetragen".
 */
console.log('\n"Patient Information Change"-Nachricht (Mindray-Eigencodes 51/52/2301/2302/2303):');
const infoMsg = ['MSH|^~\\&|MINDRAY_N-SERIES^X^EUI-64||||20260723||ORU^R01|1|P|2.3.1',
  'PID|||1234^^^Hospital^PI||Quziboev^Manuchehr^^^^^L|||M', 'PV1||I', 'OBR|1||||Patient Info',
  'OBX|1|NM|52^Height||62.0||||||F', 'OBX|2|NM|51^Weight||15.0||||||F',
  'OBX|3|ST|2301^MRN||A-2024-1234||||||F', 'OBX|4|CE|2302^BloodType||1^A||||||F',
  'OBX|5|CE|2303^PACE_Switch||0^Off||||||F'];
const info = hl7(infoMsg, { deviceId: 't' });
ok('Gewicht kommt aus Mindray-Code 51 (kg)', info.weightKg === 15, String(info.weightKg));
ok('Groesse kommt aus Mindray-Code 52 (cm)', info.akte && info.akte.groesseCm === 62, JSON.stringify(info.akte));
ok('echte Fallnummer (Code 2301) wird der PID-Nummer vorgezogen', info.patientId === 'A-2024-1234', info.patientId);
ok('Blutgruppe (Code 2302) wird gelesen', info.akte && info.akte.blutgruppe === 'A', info.akte && info.akte.blutgruppe);
ok('Schrittmacher (Code 2303 "PACE_Switch") wird gelesen', info.akte && info.akte.pacer === false, String(info.akte && info.akte.pacer));
const leerGewicht = hl7(['MSH|^~\\&|X||||||ORU^R01|1|P|2.3.1', 'OBX|1|NM|51^Weight||0.0||||||F'], { deviceId: 't' });
ok('ein Gewicht von 0.0 (kein Patient eingetragen) wird NICHT uebernommen', leerGewicht.weightKg == null, String(leerGewicht.weightKg));

console.log('\nMDC-Dialekt (das LifeVet nutzt diesen) - Nummern loesen auch ohne Label auf:');
const mdcNum = hl7(['MSH|^~\\&|X||||||ORU^R01|1|P|2.3.1',
  'OBX|1|NM|147842^^MDC||88|bpm|||||F', 'OBX|2|NM|150456^^MDC||97|%|||||F',
  'OBX|3|NM|151728^^MDC||38|mmHg|||||F', 'OBX|4|NM|151570^^MDC||14|rpm|||||F'], { deviceId: 't' });
ok('MDC-Nummer 147842 -> HF (auch ohne Label)', mdcNum.vitals.hr === 88, String(mdcNum.vitals.hr));
ok('MDC-Nummer 150456 -> SpO2', mdcNum.vitals.spo2 === 97, String(mdcNum.vitals.spo2));
ok('MDC-Nummer 151728 -> EtCO2', mdcNum.vitals.etco2 === 38, String(mdcNum.vitals.etco2));
ok('MDC-Nummer 151570 (MDC_AWAY_RESP_RATE, war Luecke) -> Atemfrequenz', mdcNum.vitals.af === 14, String(mdcNum.vitals.af));

/* ---------------- 8) Datenschutz: der Name bleibt auf dem PC ---------------- */
/*
 * Bis 27.07.2026 stand hier schlicht "das Wort patientName darf in cloud.js nicht vorkommen".
 * Seit der Nutzer die Stammdaten fern sehen WOLLTE, gibt es dafuer einen ausdruecklichen Schalter
 * (cloud.stammdaten). Die Zusage aus §10 bleibt aber dieselbe und wird jetzt SCHAERFER geprueft:
 * der Name darf nirgends unbedingt uebertragen werden, sondern ausschliesslich innerhalb des
 * Opt-in-Blocks — und der Standard muss AUS sein. Ein versehentliches
 * "rec.patientName = ..." an anderer Stelle faellt damit weiterhin sofort auf.
 */
console.log('\nDer Patientenname geht ausschliesslich ins EIGENE Praxis-Konto (§10):');
const cloud = read('bridge/src/cloud.js');
ok('Fern-Live baut eine ausdrueckliche Positivliste', /patientId: p\.patientId/.test(cloud));

/*
 * WAS SICH AM 27.07.2026 GEAENDERT HAT — und warum die Zusage trotzdem haelt.
 * Bis dahin hing der Fern-Zugang an einem Zugangscode im Link. Wer den Link hatte, sah alles;
 * Tiername und Besitzerdaten durften deshalb NICHT mitgehen. Seit der Umstellung auf Praxis-Konten
 * liegen die Daten unter der Anmelde-Kennung der Praxis, und die Regel laesst ausschliesslich
 * dieses eine Konto lesen. Es sind damit die EIGENEN Daten im EIGENEN Konto — und ein
 * Narkoseprotokoll ohne Patientennamen waere als Dokument wertlos.
 * Geprueft wird deshalb jetzt das, was die Zusage traegt: dass der Zielpfad an die Anmeldung
 * gebunden ist, dass ohne Anmeldung gar nichts hinausgeht, und dass es weiterhin einen
 * Abschalter gibt.
 */
ok('der Zielpfad ist an die Anmelde-Kennung gebunden',
  /'\/live\/' \+ this\.localId/.test(cloud));
ok('ohne Anmeldung wird nichts uebertragen',
  /if \(!this\.angemeldet\(\)\) return;/.test(cloud));
ok('es gibt keinen code-basierten Pfad mehr', !/\/live\/' \+ this\.code/.test(cloud));
const stammBlock = /if \(this\.sendeStammdaten\) \{([\s\S]*?)\n      \}/.exec(cloud);
ok('es gibt einen Stammdaten-Block', !!stammBlock);
ok('Stammdaten lassen sich weiterhin abschalten (stammdaten:false)',
  /this\.sendeStammdaten = this\.cfg\.stammdaten !== false/.test(cloud));
ok('Tiername wird NUR in diesem Block gesetzt',
  (cloud.match(/rec\.patientName/g) || []).length === 1 && !!stammBlock && /rec\.patientName/.test(stammBlock[1]));
ok('Patientenakte (Besitzer/Arzt/Telefon) wird NUR in diesem Block gesetzt',
  (cloud.match(/rec\.akte/g) || []).length === 1 && !!stammBlock && /rec\.akte/.test(stammBlock[1]));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
