'use strict';
/*
 * hl7-test.js — Verifiziert den Mindray-HL7/PDS-Parser gegen eine realistische ORU^R01-Nachricht
 * (Segmente/Codes exakt nach Mindray PDS Programmer's Guide). Prueft zusaetzlich MLLP-Rahmen-
 * extraktion und den Durchlauf bis ins "Brain".
 *   node tools/hl7-test.js
 */
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const { normalizeFrame } = require('../bridge/src/model');
const { mergePatients } = require('../bridge/src/matching');
const { loadAnaes } = require('../bridge/src/anaes');
const brain = require('../ui/engine/brain');

let fails = 0, passes = 0;
function ok(c, d, x) { if (c) { passes++; console.log('  ✓ ' + d); } else { fails++; console.log('  ✗ FAIL: ' + d + (x ? '  [' + x + ']' : '')); } }

// Realistische uMEC12-Vet-Nachricht (Hund 22 kg, stabil), Codes wie in der PDS-Spezifikation.
const MSG = [
  'MSH|^~\\&|Mindray|Gateway|||||ORU^R01|42|P|2.3.1|',
  'PID|||A-102||Bella^||20200101|M|||^^^^|||',
  'PV1||I|^^OP&Bed1&3232241659&0&0|||||||||||||||A||||||||||||||||||||||||||20260706172815',
  'OBR||||Mindray Monitor|||20260706172815|',
  'OBX||NM|101^HR|2101|99||||||F',
  'OBX||NM|160^SpO2|2103|98||||||F',
  'OBX||NM|170^Sys|2105|123||||||F',
  'OBX||NM|171^Dia|2105|78||||||F',
  'OBX||NM|172^Mean|2105|93||||||F',
  'OBX||NM|220^CO2|2109|42||||||F',
  'OBX||NM|222^AWRR|2109|14||||||F',
  'OBX||NM|200^T1|2104|38.0||||||F',
  'OBX||NM|102^PVCs|2101|0||||||F',
  'OBX||NM|51^Weight||22.0||||||F',
  'OBX||NM|999^UnbekannterParam|2101|5||||||F',
].join('\r');

console.log('== VetStation HL7/PDS-Parser-Test ==');

// 1) Reiner Parser
let unmapped = [];
const frame = parseHL7Message(MSG, { deviceId: 'umec12', model: 'uMEC12 Vet', species: 'hund' }, (u) => unmapped.push(u));
ok(!!frame, 'ORU^R01 wird geparst');
ok(frame.vitals.hr === 99, 'HR = 99', frame.vitals.hr);
ok(frame.vitals.spo2 === 98, 'SpO2 = 98', frame.vitals.spo2);
ok(frame.vitals.nibp.sys === 123 && frame.vitals.nibp.dia === 78 && frame.vitals.nibp.map === 93, 'NIBP 123/78 (93)', JSON.stringify(frame.vitals.nibp));
ok(frame.vitals.etco2 === 42, 'EtCO2 = 42 (Code 220^CO2)', frame.vitals.etco2);
ok(frame.vitals.af === 14, 'AF = 14 (Code 222^AWRR)', frame.vitals.af);
ok(frame.vitals.temp === 38, 'Temp = 38 (Code 200^T1)', frame.vitals.temp);
ok(frame.weightKg === 22, 'Gewicht = 22 kg (Code 51^Weight)', frame.weightKg);
ok(frame.patientId === 'A-102', 'PatientId = A-102 (PID-3)', frame.patientId);
ok(frame.deviceRole === 'combo', 'Rolle = combo (EtCO2 vorhanden)', frame.deviceRole);
ok(unmapped.length === 1 && /999/.test(unmapped[0]), 'Unbekannter OBX-Code wird gemeldet (999)', unmapped.join(','));

// 1b) Label-Fallback / IEEE-11073-MDC-Nomenklatur (BeneView/BeneVision): unbekannte Nummerncodes, MDC-Labels
const MDC = [
  'MSH|^~\\&|Mindray|Gateway|||||ORU^R01|9|P|2.3.1|',
  'OBX||NM|150456^MDC_ECG_HEART_RATE^MDC|0|72||||||F',
  'OBX||NM|150316^MDC_PULS_OXIM_SAT_O2^MDC|0|96||||||F',
  'OBX||NM|151708^MDC_CO2_ET^MDC|0|38||||||F',
].join('\r');
const fm = parseHL7Message(MDC, {});
ok(fm && fm.vitals.hr === 72 && fm.vitals.spo2 === 96 && fm.vitals.etco2 === 38,
  'MDC-Label-Fallback (BeneView): HR/SpO2/EtCO2 via MDC_* erkannt', fm ? JSON.stringify(fm.vitals) : 'null');

// 2) MLLP-Rahmenextraktion (VT ... FS CR), auch bei zwei Nachrichten in einem Chunk
const VT = 0x0b, FS = 0x1c, CR = 0x0d;
function frameMLLP(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }
let buf = Buffer.concat([frameMLLP(MSG), frameMLLP(MSG)]);
let count = 0, start;
while ((start = buf.indexOf(VT)) !== -1) { const end = buf.indexOf(FS, start + 1); if (end === -1) break; const p = buf.slice(start + 1, end).toString('latin1'); if (parseHL7Message(p, {})) count++; buf = buf.slice(end + 2); }
ok(count === 2, 'MLLP: zwei gerahmte Nachrichten aus einem Chunk extrahiert', count);

// 3) Durchlauf bis ins Brain (normalize -> merge -> assess)
const ANAES = loadAnaes();
const norm = normalizeFrame(frame).frame;
const patients = mergePatients([{ deviceId: 'umec12', model: 'uMEC12 Vet', role: 'combo', frame: norm }], {});
ok(patients.length === 1, 'Ein Patient nach Matching', patients.length);
const p = patients[0];
const pat = Object.assign({ species: p.species || 'hund', weightKg: p.weightKg, isoPct: null }, p.vitals);
const res = brain.assess(ANAES, pat);
ok(Array.isArray(res.cross) && res.top !== undefined, 'Brain bewertet den HL7-Patienten ohne Fehler', 'cross=' + res.cross.length);
ok(p.weightKg === 22 && p.vitals.hr === 99 && p.vitals.etco2 === 42, 'Merged Patient hat HL7-Werte', JSON.stringify({ w: p.weightKg, hr: p.vitals.hr, etco2: p.vitals.etco2 }));

/* 4) ECHTE Codes des Praxisgeraets (LifeVet 10C, 22.07.2026, Port 8830).
 *    Es sendete ausschliesslich Kurven + technische Meldungen und KEINEN Zahlenwert, weil kein
 *    Patient angeschlossen war. Die Station hat daraus im Sekundentakt "Unbekannter OBX-Code ...
 *    (in hl7.js CODE_MAP ergaenzen)" gemacht - das liest sich wie ein Programmfehler und wie
 *    "hier gehen Messwerte verloren". Beides war falsch. */
const NUR_KURVEN = [
  'MSH|^~\\&|LifeVet||||20260722174706||ORU^R01|9|P|2.3.1',
  'PID|||T-1||Test',
  'OBR|1||||||20260722174706',
  'OBX|1|NM|131330^MDC_ECG_ELEC_POTL_II||0.12|uV',
  'OBX|2|NM|151700^MDC_CONC_AWAY_CO2||3.4|mmHg',
  'OBX|3|NM|151780^MDC_IMPED_TTHOR||1.8|Ohm',
  'OBX|4|NM|0^MDC_ATTR_SAMP_RATE||250|Hz',
  'OBX|5|NM|196616^MDC_EVT_ALARM||1|',
  'OBX|6|NM|262196^MDC_EVT_INOP||1|',
].join('\r');
const unbekannt = [];
const nurKurven = parseHL7Message(NUR_KURVEN, {}, (u) => unbekannt.push(u));
ok(!!nurKurven, 'Nachricht mit ausschliesslich Kurven wird trotzdem gelesen');
ok(unbekannt.length === 0, 'Kurven/Attribute/Alarme werden NICHT als fehlende Zuordnung gemeldet', unbekannt.join(', '));
ok((nurKurven._meta.kurven || []).length >= 3, 'sie werden aber getrennt gezaehlt', JSON.stringify(nurKurven._meta.kurven));
ok((nurKurven._meta.kurven || []).indexOf('EKG-Kurve (Ableitung II)') >= 0,
  'und im Klartext benannt (nicht als MDC-Nummer)', JSON.stringify(nurKurven._meta.kurven));
ok((nurKurven._meta.kurven || []).every((k) => !/^mdc_/i.test(k)),
  'kein roher MDC-Bezeichner rutscht in die Anzeige (Abtastrate/Aufloesung sagen dem Tierarzt nichts)',
  JSON.stringify(nurKurven._meta.kurven));
ok(nurKurven.vitals.hr == null && nurKurven.vitals.spo2 == null && nurKurven.vitals.etco2 == null,
  'aus Kurvenpunkten werden KEINE Vitalwerte erfunden');

/* Ein WIRKLICH unbekannter Messwert muss weiterhin gemeldet werden - nur der gehoert in CODE_MAP. */
const echtUnbekannt = [];
parseHL7Message([
  'MSH|^~\\&|LifeVet||||20260722174706||ORU^R01|10|P|2.3.1',
  'OBX|1|NM|987654^MDC_IRGENDWAS_NEUES||42|mmHg',
].join('\r'), {}, (u) => echtUnbekannt.push(u));
ok(echtUnbekannt.length === 1, 'ein echter unbekannter Messwert wird weiterhin gemeldet', echtUnbekannt.join(', '));

/* Und die MDC-Namen der echten Vitalwerte muessen ankommen (Label-Zuordnung, ohne Nummerncode). */
const mdc = parseHL7Message([
  'MSH|^~\\&|LifeVet||||20260722174706||ORU^R01|11|P|2.3.1',
  'OBX|1|NM|147842^MDC_ECG_HEART_RATE||88|bpm',
  'OBX|2|NM|150456^MDC_PULS_OXIM_SAT_O2||97|%',
  'OBX|3|NM|151708^MDC_AWAY_CO2_ET||38|mmHg',
  'OBX|4|NM|151594^MDC_CO2_RESP_RATE||14|rpm',
  'OBX|5|NM|150017^MDC_PRESS_BLD_NONINV_SYS||118|mmHg',
  'OBX|6|NM|150018^MDC_PRESS_BLD_NONINV_DIA||72|mmHg',
  'OBX|7|NM|150019^MDC_PRESS_BLD_NONINV_MEAN||87|mmHg',
  'OBX|8|NM|188424^MDC_TEMP||37.8|Cel',
].join('\r'), {});
ok(mdc.vitals.hr === 88 && mdc.vitals.spo2 === 97, 'MDC-Nomenklatur: HF und SpO2 werden gelesen',
  JSON.stringify({ hr: mdc.vitals.hr, spo2: mdc.vitals.spo2 }));
ok(mdc.vitals.etco2 === 38 && mdc.vitals.af === 14, 'MDC-Nomenklatur: EtCO2 und Atemfrequenz werden gelesen',
  JSON.stringify({ etco2: mdc.vitals.etco2, af: mdc.vitals.af }));
ok(mdc.vitals.nibp.sys === 118 && mdc.vitals.nibp.dia === 72 && mdc.vitals.nibp.map === 87,
  'MDC-Nomenklatur: Blutdruck wird gelesen', JSON.stringify(mdc.vitals.nibp));
ok(mdc.vitals.temp === 37.8, 'MDC-Nomenklatur: Temperatur wird gelesen', mdc.vitals.temp);

console.log('\n== Ergebnis: ' + passes + ' OK, ' + fails + ' FAIL ==');
process.exit(fails ? 1 : 0);
