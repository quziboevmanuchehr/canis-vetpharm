'use strict';
/*
 * surgivet.js — Smiths Medical / SurgiVet "Advisor Vital Signs Monitor" (V9200 / V9204).
 *
 * WARUM DIESER ADAPTER ZUERST GEBAUT WURDE (Recherche 01.08.2026):
 * Von allen Veterinaer-Monitoren hat dieser den mit ABSTAND am besten dokumentierten Datenausgang.
 * Das Betriebshandbuch (Kap. 14 "Serial and Analog Input/Output") listet die 25 Spalten der
 * CSV-Zeile EINZELN auf, dazu die Ungueltig-Kennungen und die Bitbelegung des Flags-Feldes. Damit
 * laesst sich ein Leser Zeile fuer Zeile gegen das Handbuch bauen, statt ihn zu erraten — genau
 * das, was dieses Projekt verlangt.
 *
 * DER DATENSTROM (Handbuch Kap. 14, "REAL-TIME NUMERIC (CSV)"):
 *   115200 Baud, 8 Datenbits, keine Paritaet, 1 Stopbit, keine Flusskontrolle.
 *   Eine Zeile je Messtakt, 25 kommagetrennte Felder in fester Reihenfolge:
 *     0  Flags (bitcodiert)      1  ECG HR          2  SpO2 %        3  Ox Strength
 *     4  Ox Pulse                5  IBP1 SYS        6  IBP1 DIA      7  IBP1 MN
 *     8  IBP1 HR                 9  IBP2 SYS       10  IBP2 DIA     11  IBP2 MN
 *    12  IBP2 HR                13  Temp1 °C       14  Temp1 °F     15  Temp2 °C
 *    16  Temp2 °F               17  NIBP SYS       18  NIBP DIA     19  NIBP MAP
 *    20  NIBP HR                21  EtCO2          22  InCO2        23  Umgebungsdruck mmHg
 *    24  CO2 RESP (Atemzuege/min)
 *   Ungueltige Werte kommen als -32764, -32765, -32766 oder -32767.
 *   Flags: Bit 0-6 Ableitungsfehler (aVF, aVL, aVR, V, III, II, I),
 *          Bit 7-9 Herzfrequenzquelle (1 = EKG, 2 = Oximetrie, 3 = IBP),
 *          Bit 10/11 IBP1/IBP2 "Nullabgleich noetig".
 *
 * ZWEI DINGE, DIE DAS HANDBUCH NICHT SAGT — und wie dieser Leser damit umgeht, OHNE zu raten:
 *
 *  (1) DIE SKALIERUNG DER TEMPERATUR. Das Handbuch nennt weder Nachkommastellen noch Faktor.
 *      Statt zu raten, wird sie AUS DEN DATEN SELBST BESTIMMT: das Geraet sendet dieselbe
 *      Temperatur zweimal, einmal in °C und einmal in °F. Zwischen beiden gilt fest F = C*1,8+32.
 *      Der Leser probiert die Faktoren 1, 10 und 100 durch und nimmt den, bei dem diese Gleichung
 *      aufgeht UND das Ergebnis in einem lebensmoeglichen Bereich liegt. Geht keiner auf, wird
 *      KEINE Temperatur gemeldet und der Grund einmal ins Log geschrieben.
 *      Das ist keine Vermutung, sondern eine Messung mit eingebauter Gegenprobe.
 *
 *  (2) DIE SENDEFREQUENZ. Ebenfalls nicht dokumentiert. Sie wird gemessen und im Status
 *      ausgewiesen, statt angenommen zu werden.
 *
 * PLAUSIBILITAETSGRENZEN — die Lehre aus dem Draeger-Primus-Fall (Recherche 01.08.2026): dort
 * bekam ein Anwender ueber eine falsch gebaute Verbindung Zahlen, die PLAUSIBEL AUSSAHEN und
 * trotzdem falsch waren (Tidalvolumen 17165 mL statt 300 mL). Ein Wert, der ausserhalb des
 * physiologisch Moeglichen liegt, wird hier deshalb VERWORFEN und gemeldet — nicht angezeigt.
 * Lieber ein leeres Feld als eine falsche Zahl am narkotisierten Tier.
 *
 * STRIKT READ-ONLY: dieser Adapter sendet NICHTS. Der Advisor gibt seinen CSV-Strom von selbst
 * heraus, sobald am Geraet "SERIAL OUTPUT MODE = REAL-TIME NUMERIC (CSV)" eingestellt ist.
 * Es wird deshalb auch keine Erlaubnisliste zum Senden gesetzt.
 *
 * KABELWARNUNG (steht auch in der Anleitung im Reiter "Geräte"): Pin 6 des DB9 fuehrt +5 Volt,
 * auf einem PC-COM-Anschluss liegt dort DSR. NUR ein dreiadriges Kabel (Pin 2, 3, 5) verwenden.
 */
const { Adapter } = require('./base');
const { SerielleVerbindung } = require('../seriell');

/* Ungueltig-Kennungen laut Handbuch. Bewusst als Liste und nicht als "alles unter -32000":
 * eine offene Untergrenze wuerde auch einen echten, nur falsch skalierten Wert verschlucken. */
const UNGUELTIG = [-32764, -32765, -32766, -32767];

/* Spaltennummern. Sie stehen hier EINMAL und mit Namen — eine Zahl mitten im Code waere die
 * Sorte Fehler, die niemand beim Lesen findet. */
const S = {
  flags: 0, hrEkg: 1, spo2: 2, oxStaerke: 3, hrOx: 4,
  ibp1sys: 5, ibp1dia: 6, ibp1map: 7, ibp1hr: 8,
  ibp2sys: 9, ibp2dia: 10, ibp2map: 11, ibp2hr: 12,
  temp1c: 13, temp1f: 14, temp2c: 15, temp2f: 16,
  nibpSys: 17, nibpDia: 18, nibpMap: 19, nibpHr: 20,
  etco2: 21, fico2: 22, umgebungsdruck: 23, af: 24,
};
const SPALTEN = 25;

/*
 * Plausibilitaetsgrenzen. Absichtlich WEIT gefasst: sie sollen Uebertragungsfehler abfangen, nicht
 * medizinisch urteilen. Ein Frettchen hat eine Herzfrequenz von 300, eine Dogge 60 — beides ist
 * echt. Was hier herausfaellt, ist kein ungewoehnlicher Patient, sondern eine kaputte Zahl.
 */
const GRENZEN = {
  hr: [10, 400], spo2: [1, 100], etco2: [0, 150], fico2: [0, 60], af: [0, 120],
  temp: [10, 50], sys: [10, 300], dia: [5, 250], map: [5, 260],
};

function zahl(feld) {
  const t = String(feld == null ? '' : feld).trim();
  if (!t || t === '---' || t === '--.-') return null;
  const n = Number(t);
  if (!Number.isFinite(n)) return null;
  if (UNGUELTIG.indexOf(n) >= 0) return null;
  return n;
}

function imBereich(wert, name) {
  if (wert == null) return null;
  const g = GRENZEN[name];
  if (!g) return wert;
  return (wert >= g[0] && wert <= g[1]) ? wert : undefined;   // undefined = ausserhalb, wird gemeldet
}

/*
 * temperaturSkala(cRoh, fRoh) — bestimmt den Teiler AUS DEN DATEN.
 *
 * Das Geraet sendet dieselbe Temperatur in °C und in °F. F = C*1,8+32 gilt immer. Damit ist der
 * Teiler messbar statt ratbar: er ist derjenige, bei dem die Gleichung aufgeht.
 * Rueckgabe: { teiler, celsius } oder null, wenn sich keiner bestaetigen laesst.
 *
 * Pure Funktion -> ohne Geraet pruefbar (tools/surgivet-test.js).
 */
function temperaturSkala(cRoh, fRoh) {
  if (cRoh == null || fRoh == null) return null;
  const kandidaten = [1, 10, 100];
  for (const t of kandidaten) {
    const c = cRoh / t;
    const f = fRoh / t;
    if (c < GRENZEN.temp[0] || c > GRENZEN.temp[1]) continue;
    /* 0,6 °F Spielraum: beide Werte sind gerundet, und bei Teiler 1 kann eine ganze Zahl
     * gegenueber der Umrechnung um bis zu einem halben Grad abweichen. */
    if (Math.abs(f - (c * 1.8 + 32)) <= 0.6) return { teiler: t, celsius: Math.round(c * 10) / 10 };
  }
  return null;
}

/* Herzfrequenzquelle aus dem Flags-Feld (Bits 7-9). */
const HR_QUELLE = { 1: 'EKG', 2: 'Oximetrie', 3: 'Blutdruck' };
function hrQuelle(flags) {
  if (flags == null) return null;
  return HR_QUELLE[(Number(flags) >> 7) & 0x07] || null;
}

/* Welche EKG-Ableitungen melden einen Kabelfehler? (Bits 0-6) */
const ABLEITUNG = ['aVF', 'aVL', 'aVR', 'V', 'III', 'II', 'I'];
function ableitungsFehler(flags) {
  if (flags == null) return [];
  const f = Number(flags);
  return ABLEITUNG.filter((_, i) => (f >> i) & 1);
}

/*
 * parseZeile(zeile) -> { vitals, alarms, hinweise, quelle } | null
 *
 * PURE FUNKTION. Kein Netz, keine Uhr, kein Zustand — genau deshalb laesst sich der Leser gegen
 * die Handbuchtabelle pruefen, ohne dass ein Geraet angeschlossen ist.
 * `hinweise` sammelt alles, was auffiel (verworfene Werte, unbestimmbare Skalierung).
 */
function parseZeile(zeile) {
  const roh = String(zeile || '').trim();
  if (!roh) return null;
  const f = roh.split(',');
  /* Die Zeile MUSS 25 Felder haben. Eine kuerzere Zeile ist ein abgeschnittener Empfang — sie
   * spaltenweise auszuwerten hiesse, EtCO2 an der Stelle von NIBP zu lesen. */
  if (f.length !== SPALTEN) return null;
  /* Sicherheitsnetz gegen Textzeilen (Menuenamen, Trend-Kopfzeilen): das erste Feld muss eine
   * Zahl sein, sonst ist es keine Messzeile. */
  if (!/^-?\d+$/.test(String(f[S.flags]).trim())) return null;

  const hinweise = [];
  const nimm = (spalte, name) => {
    const w = imBereich(zahl(f[spalte]), name);
    if (w === undefined) { hinweise.push(name + '=' + String(f[spalte]).trim() + ' liegt ausserhalb des Moeglichen und wurde verworfen'); return null; }
    return w;
  };

  const flags = zahl(f[S.flags]);
  const vitals = {};

  /* Herzfrequenz: das Geraet sagt selbst, woher sie kommt. Steht dort Oximetrie, wird der
   * Oximetriewert genommen — sonst zeigte die Station eine EKG-Frequenz an, die gar keine ist. */
  const q = hrQuelle(flags);
  const hrEkg = nimm(S.hrEkg, 'hr');
  const hrOx = nimm(S.hrOx, 'hr');
  const hrIbp = nimm(S.ibp1hr, 'hr');
  vitals.hr = (q === 'Oximetrie' ? hrOx : (q === 'Blutdruck' ? hrIbp : hrEkg));
  if (vitals.hr == null) vitals.hr = hrEkg != null ? hrEkg : (hrOx != null ? hrOx : hrIbp);

  vitals.spo2 = nimm(S.spo2, 'spo2');
  vitals.etco2 = nimm(S.etco2, 'etco2');
  vitals.fico2 = nimm(S.fico2, 'fico2');
  vitals.af = nimm(S.af, 'af');

  const sys = nimm(S.nibpSys, 'sys'), dia = nimm(S.nibpDia, 'dia'), map = nimm(S.nibpMap, 'map');
  if (sys != null || dia != null || map != null) vitals.nibp = { sys: sys, dia: dia, map: map };

  const t1 = temperaturSkala(zahl(f[S.temp1c]), zahl(f[S.temp1f]));
  if (t1) vitals.temp = t1.celsius;
  else if (zahl(f[S.temp1c]) != null) {
    hinweise.push('Temperatur nicht uebernommen: aus den Spalten °C=' + String(f[S.temp1c]).trim() +
      ' und °F=' + String(f[S.temp1f]).trim() + ' laesst sich keine gueltige Skalierung bestimmen ' +
      '(F = C*1,8+32 geht bei keinem Teiler auf). Lieber kein Wert als ein falscher.');
  }

  /* Ableitungsfehler sind echte technische Alarme — der Tierarzt sieht sonst eine leere
   * Herzfrequenz und weiss nicht, dass nur eine Elektrode ab ist. */
  const alarms = [];
  const abl = ableitungsFehler(flags);
  if (abl.length && abl.length < ABLEITUNG.length) alarms.push('EKG-Ableitung ohne Kontakt: ' + abl.join(', '));
  else if (abl.length === ABLEITUNG.length) alarms.push('EKG: alle Ableitungen ohne Kontakt');
  if (flags != null && ((Number(flags) >> 10) & 1)) alarms.push('IBP1: Nullabgleich noetig');
  if (flags != null && ((Number(flags) >> 11) & 1)) alarms.push('IBP2: Nullabgleich noetig');

  return { vitals: vitals, alarms: alarms, hinweise: hinweise, quelle: q, teiler: t1 ? t1.teiler : null };
}

class SurgiVetAdapter extends Adapter {
  /*
   * cfg = {
   *   id, model, role, species,
   *   art: 'com' | 'tcp'      'com' = direkt am PC, 'tcp' = ueber einen Geraeteserver (empfohlen)
   *   port: 'COM3'            (bei art 'com')
   *   host, tcpPort           (bei art 'tcp')
   *   baud: 115200            Handbuchwert; nur aendern, wenn am Geraet etwas anderes eingestellt ist
   * }
   */
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.verbindung = null;
    this.puffer = '';
    this.zeilen = 0;
    this.verworfen = 0;
    this.letzteTs = 0;
    this.taktMs = null;         // GEMESSEN, nicht angenommen
    this.gemeldet = {};         // damit derselbe Hinweis nicht im Sekundentakt im Log steht
    this.teiler = null;
  }

  describe() {
    return { id: this.id, model: this.cfg.model || 'SurgiVet Advisor', role: this.cfg.role || 'kombi' };
  }

  async connect() {
    const cfg = {
      art: this.cfg.art === 'com' ? 'com' : 'tcp',
      port: this.cfg.port,
      host: this.cfg.host,
      tcpPort: this.cfg.tcpPort,
      baud: this.cfg.baud || 115200,
      datenbits: 8, paritaet: 'n', stopbits: 1,
      /* KEINE Erlaubnisliste: dieser Adapter sendet nie etwas. */
    };
    this.verbindung = new SerielleVerbindung(cfg, this.ctx);
    this.verbindung.beiDaten((d) => this._daten(d));
    this.verbindung.beiEnde(() => {
      this.connected = false;
      this.ctx.log.warn('surgivet', 'Verbindung zum Advisor beendet.');
    });
    await this.verbindung.oeffnen();
    this.connected = true;
    this.ctx.log.info('surgivet', 'Advisor verbunden (' + (cfg.art === 'com' ? cfg.port : cfg.host + ':' + cfg.tcpPort) +
      ', ' + cfg.baud + ' Baud). Am Geraet muss "SERIAL OUTPUT MODE = REAL-TIME NUMERIC (CSV)" ' +
      'eingestellt sein (SETUP → SERVICE MENU → Passwort ADVISOR → MONITOR DEFAULTS).');
  }

  _daten(chunk) {
    this.puffer += chunk.toString('latin1');
    if (this.puffer.length > 64 * 1024) this.puffer = this.puffer.slice(-8192);   // Notbremse
    let i;
    while ((i = this.puffer.search(/\r\n|\n|\r/)) >= 0) {
      const zeile = this.puffer.slice(0, i);
      this.puffer = this.puffer.slice(i + (this.puffer.substr(i, 2) === '\r\n' ? 2 : 1));
      this._zeile(zeile);
    }
  }

  _zeile(zeile) {
    const erg = parseZeile(zeile);
    if (!erg) {
      if (String(zeile).trim()) this.verworfen++;
      /* Eine einzelne unlesbare Zeile ist normal (Einschaltmoment, Menuewechsel). Erst wenn NUR
       * unlesbare Zeilen kommen, ist etwas faul — dann meldet es sich, und zwar genau einmal. */
      if (this.verworfen === 20 && this.zeilen === 0) {
        this.ctx.log.warn('surgivet', 'Es kommen Daten an, aber keine einzige Zeile hat das erwartete ' +
          'Format (25 Felder, kommagetrennt). Steht am Geraet wirklich "REAL-TIME NUMERIC (CSV)" und ' +
          'nicht "TREND RETRIEVAL"? Stimmt die Baudrate (Handbuch: 115200)?');
      }
      return;
    }

    const jetzt = Date.now();
    if (this.letzteTs) {
      const d = jetzt - this.letzteTs;
      /* Gleitender Mittelwert statt Einzelmessung — ein verzoegertes Paket soll den Takt nicht
       * verfaelschen. Der Wert wird ausgewiesen, weil das Handbuch ihn NICHT nennt. */
      this.taktMs = this.taktMs ? Math.round(this.taktMs * 0.8 + d * 0.2) : d;
    }
    this.letzteTs = jetzt;
    this.zeilen++;
    if (erg.teiler && this.teiler !== erg.teiler) {
      this.teiler = erg.teiler;
      this.ctx.log.info('surgivet', 'Temperaturskalierung aus den Daten bestimmt: Teiler ' + erg.teiler +
        ' (gegengeprueft ueber die mitgesendete °F-Spalte).');
    }
    erg.hinweise.forEach((h) => {
      if (this.gemeldet[h]) return;
      this.gemeldet[h] = true;
      this.ctx.log.warn('surgivet', h);
    });
    if (this.zeilen === 1) {
      this.ctx.log.info('surgivet', 'Erste gueltige Messzeile gelesen — die Kette Geraet → Station steht.' +
        (erg.quelle ? ' Herzfrequenzquelle laut Geraet: ' + erg.quelle + '.' : ''));
    }

    this.emit({
      deviceId: this.id,
      deviceModel: this.cfg.model || 'SurgiVet Advisor',
      deviceRole: this.cfg.role || 'kombi',
      species: this.cfg.species || null,
      ts: jetzt,
      vitals: erg.vitals,
      alarms: erg.alarms,
      _meta: { hrQuelle: erg.quelle, taktMs: this.taktMs, transport: 'RS-232 CSV' },
    });
  }

  status() {
    return {
      verbunden: this.connected, zeilen: this.zeilen, verworfen: this.verworfen,
      taktMs: this.taktMs, temperaturTeiler: this.teiler,
    };
  }

  dispose() {
    if (this.verbindung) { try { this.verbindung.schliessen(); } catch (_) {} }
    this.verbindung = null;
    this.connected = false;
  }
}

module.exports = {
  SurgiVetAdapter,
  parseZeile, temperaturSkala, hrQuelle, ableitungsFehler, zahl, imBereich,
  S, SPALTEN, UNGUELTIG, GRENZEN,
};
