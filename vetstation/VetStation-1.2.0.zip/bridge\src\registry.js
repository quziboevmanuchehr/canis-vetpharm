'use strict';
/*
 * registry.js — Geraete-Registry + Auto-Discovery (§6.1). Geraete "erscheinen", sobald sie
 * Frames senden (wie eine IDEXX-Station). Verwaltet Status (active/standby/offline),
 * manuelles Koppeln, Meta-Overrides und leitet die Patienten-Zusammenfuehrung an.
 */
const { normalizeFrame } = require('./model');
const { mergePatients } = require('./matching');
// EKG-Analyse (QRS/Rhythmus/ST) — dieselbe Engine wie die Oberflaeche. Wird hier auf den
// AUFGESAMMELTEN EKG-Streifen angewandt (das Geraet sendet nur 1-s-Haeppchen; die Engine braucht >=2 s).
let ekgEngine = null;
try { ekgEngine = require('../../ui/engine/ekg-analyse'); } catch (_) { ekgEngine = null; }

const ACTIVE_MS = 5000;
// STANDBY grosszuegig: das LifeVet 10C sendet ab Werk nur alle ~30 s. Mit dem alten Wert fiel ein
// voellig gesundes Geraet zwischen zwei Paketen auf "offline" und verschwand aus der Anzeige.
const STANDBY_MS = 90000;

// Wie viele echte Messwerte liegen an? Unterscheidet "verbunden" von "verbunden UND misst" -
// genau die Frage, an der die Fehlersuche am 22.07.2026 haengen blieb.
function zaehleWerte(v) {
  if (!v) return 0;
  let n = 0;
  ['hr', 'spo2', 'etco2', 'fico2', 'af', 'temp'].forEach((k) => { if (v[k] != null) n++; });
  if (v.nibp) ['sys', 'dia', 'map'].forEach((k) => { if (v.nibp[k] != null) n++; });
  return n;
}

const fs = require('fs');
const path = require('path');

class Registry {
  constructor({ log }) {
    this.devices = new Map(); // deviceId -> { deviceId, model, role, frame, lastTs }
    this.manual = {};         // deviceId -> patientKey (manuelles Koppeln, §6.3)
    this.meta = {};           // deviceId -> { species, weightKg, patientId } Overrides (§6.3)
    this.log = log;
    this.adapters = [];

    /*
     * DAUERHAFTE HANDEINTRAEGE, an die PATIENTEN-ID gebunden (Befund 23.07.2026).
     *
     * Der echte Datenstrom des LifeVet ist belegt: das Geraet sendet ueber HL7 nur ID, Name und
     * Geschlecht - NICHT Tierart, Gewicht, Groesse oder Besitzer. Die muss der Tierarzt also von
     * Hand eintragen. Bisher lag dieser Eintrag nur im Speicher (this.meta) und war nach jedem
     * Neustart weg - der Tierarzt haette ihn bei jeder Narkose neu tippen muessen.
     *
     * Deshalb: Handeintraege werden an die Patienten-ID gebunden auf die Platte geschrieben. Kommt
     * DERSELBE Patient (gleiche ID vom Geraet) wieder, werden Tierart und Gewicht automatisch
     * wiederhergestellt. Ein ANDERER Patient (andere ID) bekommt sie NICHT - das waere gefaehrlich.
     * Die Datei enthaelt nur Tierart/Gewicht/ID, keine Vitalwerte.
     */
    this.akteDatei = path.join(__dirname, '..', 'data', 'patient-akte.json');
    this.akteStore = {};      // patientId -> { species, weightKg, ts }
    try {
      if (fs.existsSync(this.akteDatei)) this.akteStore = JSON.parse(fs.readFileSync(this.akteDatei, 'utf8')) || {};
    } catch (e) { this.log && this.log.warn && this.log.warn('registry', 'patient-akte.json nicht lesbar: ' + e.message); }

    /*
     * OP-PROTOKOLL IN DER BRIDGE (neu 27.07.2026).
     *
     * WARUM ES HIERHER GEHOERT: Das Narkoseprotokoll wurde bisher ausschliesslich im Browser des
     * Kiosk gefuehrt (ui/vetstation-live.js, Variable "log") — als reine Closure-Variable, ohne
     * jede Speicherung. Ein F5, ein Browser-Absturz, ein Kiosk-Neustart mitten in der Narkose: das
     * komplette Protokoll war restlos weg, ohne Warnung und ohne Wiederherstellung. Fuer ein
     * Dokument, das eine Narkose belegen soll, ist das nicht haltbar. Ausserdem konnte es so
     * niemals fern uebertragen werden.
     *
     * Die Schwellenlogik ist bewusst IDENTISCH zur bisherigen im Browser (ui/vetstation-live.js):
     * ein neuer Eintrag entsteht beim ersten Mal, nach 12 s, oder sobald sich der Top-Befund
     * aendert. So bleibt das gedruckte Protokoll inhaltlich dasselbe wie bisher.
     *
     * Gebunden wird an die PATIENTEN-ID, nicht an den patientKey: der Schluessel wechselt, sobald
     * das Geraet Tierart/Gewicht nachliefert, und genau daran zerfiel das Protokoll im Browser
     * bisher in zwei Haelften.
     */
    this.protokollDatei = path.join(__dirname, '..', 'data', 'protokoll.json');
    this.protokoll = {};          // patientId -> [ {ts, hr, spo2, ...} ]
    this.protokollKopf = {};      // patientId -> Stammdaten zum Zeitpunkt des ersten Eintrags
    this._protokollSchmutzig = false;
    /*
     * BEIM LADEN AUFRAEUMEN (30.07.2026).
     *
     * Vorher wuchs protokoll.json unbegrenzt: es gab keinen Altersfilter und kein Verwerfen alter
     * Patienten. Auf diesem Rechner standen nach drei Tagen 6 Patienten mit 153 Zeilen darin — und
     * jede davon wurde nach jedem Neustart erneut in die Cloud angeboten, was dort die
     * Unveraenderlichkeits-Regel ablehnte und die Fern-Uebertragung abschaltete (Ursache ist in
     * bridge/src/cloud.js bei prozessStart beschrieben und dort behoben). Die wachsende Datei war
     * der Verstaerker: je laenger die Praxis laeuft, desto groesser der abgelehnte Schreibvorgang.
     *
     * Behalten wird ein Monat. Das ist bewusst reichlich: ein Narkoseprotokoll wird manchmal Tage
     * spaeter noch gebraucht, und die Datei ist der lokale Ausdruck-Bestand — geloescht wird also
     * nur, was auch im Firestore-Verlauf steht. Der Massstab ist der ZULETZT geschriebene Eintrag
     * eines Patienten, nicht der erste: eine lange Narkose darf nicht mitten hindurch abgeschnitten
     * werden.
     */
    try {
      if (fs.existsSync(this.protokollDatei)) {
        const j = JSON.parse(fs.readFileSync(this.protokollDatei, 'utf8')) || {};
        const geladen = j.protokoll || {};
        const kopf = j.kopf || {};
        const grenze = Date.now() - 30 * 24 * 60 * 60 * 1000;
        let weg = 0;
        for (const pid in geladen) {
          const liste = geladen[pid] || [];
          const letzte = liste.length ? Number(liste[liste.length - 1].ts) : 0;
          if (Number.isFinite(letzte) && letzte >= grenze) {
            this.protokoll[pid] = liste;
            if (kopf[pid]) this.protokollKopf[pid] = kopf[pid];
          } else { weg++; }
        }
        if (weg) {
          this._protokollSchmutzig = true;   // aufgeraeumte Fassung beim naechsten Takt speichern
          this.log && this.log.info && this.log.info('registry',
            weg + ' Narkoseprotokoll(e) aelter als 30 Tage aus protokoll.json entfernt.');
        }
      }
    } catch (e) { this.log && this.log.warn && this.log.warn('registry', 'protokoll.json nicht lesbar: ' + e.message); }
    // Gebuendelt speichern statt bei jedem Eintrag: bei flatterndem Befund koennten sonst alle
    // 350 ms mehrere hundert Kilobyte synchron auf die Platte geschrieben werden.
    this._protokollTimer = setInterval(() => this._protokollSpeichern(), 5000);
    if (this._protokollTimer.unref) this._protokollTimer.unref();
  }

  _akteSpeichern() {
    try {
      fs.mkdirSync(path.dirname(this.akteDatei), { recursive: true });
      fs.writeFileSync(this.akteDatei, JSON.stringify(this.akteStore, null, 2));
    } catch (e) { this.log && this.log.warn && this.log.warn('registry', 'patient-akte.json nicht schreibbar: ' + e.message); }
  }

  _protokollSpeichern() {
    if (!this._protokollSchmutzig) return;
    this._protokollSchmutzig = false;
    try {
      fs.mkdirSync(path.dirname(this.protokollDatei), { recursive: true });
      fs.writeFileSync(this.protokollDatei,
        JSON.stringify({ protokoll: this.protokoll, kopf: this.protokollKopf }));
    } catch (e) { this.log && this.log.warn && this.log.warn('registry', 'protokoll.json nicht schreibbar: ' + e.message); }
  }

  /*
   * protokollSchritt(patients, bewerten) — genau EINMAL pro Runde aufrufen.
   *
   * bewerten(p) liefert den Titel des Top-Befunds (dieselbe Brain-Bewertung, die auch die
   * Fern-Ansicht benutzt) oder null. Ohne Bewertung wird trotzdem protokolliert, dann eben
   * ohne Befundtext.
   *
   * NICHT in getPatients() einbauen: die Methode laeuft pro Runde mehrfach (Rundruf-Zeitgeber
   * UND eigener Cloud-Zeitgeber), das Protokoll wuerde doppelt zaehlen.
   */
  protokollSchritt(patients, bewerten) {
    const now = Date.now();
    for (const p of patients || []) {
      const pid = p.patientId || p.patientKey;
      if (!pid) continue;
      const v = p.vitals || {};
      // Ohne einen einzigen Messwert entsteht kein Eintrag — sonst fuellt eine leere,
      // nur angeschlossene Station das Protokoll mit Nullzeilen.
      if (v.hr == null && v.spo2 == null && v.etco2 == null && v.map == null && v.temp == null) continue;

      let befund = null;
      if (typeof bewerten === 'function') { try { befund = bewerten(p); } catch (_) { befund = null; } }

      const L = this.protokoll[pid] || (this.protokoll[pid] = []);
      const letzter = L[L.length - 1];
      const neu = !letzter || (now - letzter.ts > 12000) || ((letzter.finding || '') !== (befund || ''));
      if (!neu) continue;

      /*
       * DER ZEITPUNKT IST DER SCHLUESSEL — er muss eindeutig sein.
       *
       * In der Cloud liegt jede Zeile unter protokoll/<Patient>/<Zeitpunkt>, und die Regel macht
       * sie unveraenderlich (".validate": "!data.exists()"). Ein doppelter Zeitpunkt ist deshalb
       * nicht nur haesslich, er ist eine dauerhafte Ablehnung: die zweite Zeile kaeme nie an.
       * Doppelt werden kann er, wenn die Uhr des PCs zurueckspringt — beim Hochfahren mit leerer
       * CMOS-Batterie stellt Windows die Zeit erst per NTP, und das kann Minuten spaeter passieren.
       * Ein belegter Zeitpunkt wird deshalb um eine Millisekunde weitergeschoben. Fuer ein
       * Narkoseprotokoll ist das ohne Bedeutung, fuer den Schluessel entscheidend.
       */
      let ts = now;
      if (letzter && ts <= letzter.ts) ts = letzter.ts + 1;

      L.push({
        ts: ts,
        hr: v.hr != null ? v.hr : null, spo2: v.spo2 != null ? v.spo2 : null,
        etco2: v.etco2 != null ? v.etco2 : null, af: v.af != null ? v.af : null,
        map: v.map != null ? v.map : null, sys: v.sys != null ? v.sys : null,
        dia: v.dia != null ? v.dia : null, temp: v.temp != null ? v.temp : null,
        rhythm: v.ekgRhythm || null, iso: p.isoPct != null ? p.isoPct : null,
        ventMode: p.ventMode || null,
        finding: befund || null,
      });
      if (L.length > 2000) L.shift();

      // Stammdaten beim ERSTEN Eintrag festhalten und danach nur ergaenzen. Im Browser wurden sie
      // bei jedem Takt ueberschrieben — ein spaeter exportierter Patient hatte deshalb keine mehr.
      const k = this.protokollKopf[pid] || (this.protokollKopf[pid] = { beginn: now });
      ['patientId', 'patientName', 'species', 'weightKg', 'gebDatum', 'geschlecht'].forEach((f) => {
        if (k[f] == null && p[f] != null) k[f] = p[f];
      });
      if (p.akte && typeof p.akte === 'object') {
        k.akte = Object.assign({}, p.akte, k.akte || {});
      }
      k.zuletzt = now;
      this._protokollSchmutzig = true;
    }
  }

  // Was die Cloud uebertragen soll: je Patient die letzten Eintraege. Der Publisher merkt sich
  // selbst, welche Zeitpunkte er schon geschickt hat, und sendet nur die neuen.
  protokollFuerCloud(maxJePatient) {
    const n = maxJePatient || 400;
    const out = {};
    for (const pid in this.protokoll) {
      const L = this.protokoll[pid];
      if (L && L.length) out[pid] = L.slice(-n);
    }
    return out;
  }

  // Fuer den PDF-Export und die Fern-Ansicht: Protokoll + Kopfdaten eines Patienten.
  protokollVon(pid) {
    return { kopf: this.protokollKopf[pid] || null, eintraege: this.protokoll[pid] || [] };
  }

  // Uebersicht fuer den Auswahldialog des Exports.
  protokollListe() {
    return Object.keys(this.protokoll).map((pid) => ({
      patientId: pid,
      anzahl: (this.protokoll[pid] || []).length,
      kopf: this.protokollKopf[pid] || null,
    })).sort((a, b) => ((b.kopf && b.kopf.zuletzt) || 0) - ((a.kopf && a.kopf.zuletzt) || 0));
  }

  addAdapter(adapter) { this.adapters.push(adapter); }

  async start() {
    for (const a of this.adapters) {
      try { await a.connect(); }
      catch (e) { this.log.error('registry', 'Adapter ' + a.id + ' connect fehlgeschlagen: ' + (e && e.message)); }
    }
  }

  // Roh-Frame eines Adapters aufnehmen -> normalisieren -> Geraet aktualisieren.
  ingest(raw) {
    /*
     * GERAET GEWINNT BEIM GEWICHT (Wunsch 23.07.2026: "Gewicht automatisch vom Monitor, wie
     * eingegeben"). Liefert das Geraet einen echten Gewichtswert (Code 51, beim OK-Druecken im
     * Patientendialog), wird ER die Quelle: der Handeintrag fuers Gewicht weicht, und der Wert wird
     * an die Patienten-ID persistiert. So bleibt der Monitor-Wert auch fuer die VIELEN Folge-
     * nachrichten OHNE Gewicht erhalten (kein Zurueckspringen auf den alten Handeintrag).
     */
    if (raw.weightKg != null && Number.isFinite(raw.weightKg)) {
      if (this.meta[raw.deviceId] && this.meta[raw.deviceId].weightKg != null) delete this.meta[raw.deviceId].weightKg;
      const pidW = String((raw.patientId != null ? raw.patientId : (this.meta[raw.deviceId] && this.meta[raw.deviceId].patientId)) || '').trim();
      if (pidW) { this.akteStore[pidW] = Object.assign({}, this.akteStore[pidW], { weightKg: raw.weightKg, ts: Date.now() }); this._akteSpeichern(); }
    }

    /*
     * GERAET GEWINNT AUCH BEI DER PATIENTENKATEGORIE/TIERART (Befund 24.07.2026: "Kategorie am
     * Monitor geaendert und OK gedrueckt — die App uebernimmt es nicht, Live aendert sich nicht").
     *
     * Sendet das Geraet eine Tierart/Patientenkategorie mit (manche Mindray-/ePM-Vet-Konfigurationen
     * fuehren sie in PID/PV1/OBX), wird SIE die Quelle — symmetrisch zum Gewicht oben. Bisher fehlte
     * genau diese Symmetrie: ein einmal von Hand gesetzter Tierart-Eintrag (this.meta / akteStore)
     * wurde NIE zurueckgenommen. Der am Monitor geaenderte Wert gewann nur fuer den EINEN Frame, der
     * die Kategorie trug; jeder Folge-Frame (ohne Kategorie) drehte ihn ueber den Handeintrag sofort
     * wieder auf den alten Wert zurueck -> "aendert sich in Live nicht". Jetzt weicht der Handeintrag,
     * und der neue Wert wird an die Patienten-ID persistiert (nur bei echter Aenderung geschrieben,
     * damit eine in JEDER Nachricht mitgesendete Kategorie nicht die Platte im Takt beschreibt).
     */
    if (raw.species) {
      const md = this.meta[raw.deviceId];
      if (md && md.species && md.species !== raw.species) delete md.species;
      const pidS = String((raw.patientId != null ? raw.patientId : (md && md.patientId)) || '').trim();
      if (pidS && (!this.akteStore[pidS] || this.akteStore[pidS].species !== raw.species)) {
        this.akteStore[pidS] = Object.assign({}, this.akteStore[pidS], { species: raw.species, ts: Date.now() });
        this._akteSpeichern();
      }
    }

    const ov = this.meta[raw.deviceId];
    if (ov) {
      /*
       * GERAET GEWINNT, Handeintrag fuellt nur LUECKEN (Wunsch 23.07.2026: "Gewicht automatisch vom
       * Monitor uebernehmen, wie eingegeben"). Frueher schlug der Handeintrag das Geraet - dann kam
       * das beim OK-Druecken gesendete Geraete-Gewicht (Code 51) nie durch. Jetzt gilt: liefert das
       * Geraet einen Wert, zaehlt DER; der Handeintrag greift nur, solange das Geraet keinen liefert.
       * Die Tierart sendet das Geraet nie ueber HL7 -> dafuer greift der Handeintrag praktisch immer.
       * Herkunft bleibt erkennbar (manuell vs. geraet) - wichtig fuer die mL-Dosisbegruendung.
       */
      raw.herkunft = Object.assign({}, raw.herkunft);
      if (ov.species && !raw.species) { raw.species = ov.species; raw.herkunft.species = 'manuell'; }
      if (ov.weightKg != null && ov.weightKg !== '' && raw.weightKg == null) { raw.weightKg = ov.weightKg; raw.herkunft.weightKg = 'manuell'; }
      if (ov.patientId && !raw.patientId) raw.patientId = ov.patientId;
    }

    /*
     * DAUERHAFTEN HANDEINTRAG ZUR PATIENTEN-ID ANWENDEN.
     * Nur wenn das Geraet KEINE eigene Angabe liefert (es sendet Tierart/Gewicht ohnehin nie) und
     * die gespeicherte ID zur aktuell gemeldeten passt. So folgt der Eintrag dem Patienten, nicht
     * dem Geraet - und ein anderer Patient erbt ihn niemals.
     */
    const pid = raw.patientId != null ? String(raw.patientId) : null;
    if (pid && this.akteStore[pid]) {
      const g = this.akteStore[pid];
      raw.herkunft = Object.assign({}, raw.herkunft);
      if (!raw.species && g.species) { raw.species = g.species; raw.herkunft.species = 'manuell'; }
      if (raw.weightKg == null && g.weightKg != null) { raw.weightKg = g.weightKg; raw.herkunft.weightKg = 'manuell'; }
    }
    const { frame, warnings } = normalizeFrame(raw);
    let rec = this.devices.get(frame.deviceId);
    const isNew = !rec;
    if (isNew) rec = { deviceId: frame.deviceId };

    /*
     * STAMMDATEN UEBER DIE ZEIT FESTHALTEN (Kernfehler, gefunden 23.07.2026).
     *
     * Das LifeVet sendet Name und ID (PID-Segment) in JEDER Nachricht - deshalb waren sie sichtbar.
     * Tierart, Gewicht, Groesse, Besitzer usw. schickt es aber nur EINMAL, beim Bestaetigen des
     * Patientendialogs (als OBX bzw. GT1/PV1). Schon die naechste Nachricht (z. B. nur
     * MDC_EVT_INOP) trug diese Felder nicht mehr - und weil die Registry immer nur die LETZTE
     * Nachricht behielt, waren Tierart und Gewicht nach einer Sekunde wieder leer. Genau das sah
     * der Tierarzt als "erkennt keine Patientendaten".
     *
     * Deshalb: die stabilen Patientenangaben aus dem vorigen Frame UEBERNEHMEN, wenn die neue
     * Nachricht sie nicht enthaelt - solange es derselbe Patient ist (gleiche ID). Wechselt die
     * Patienten-ID, wird NICHTS uebernommen (neuer Patient, alte Daten waeren gefaehrlich).
     */
    const alt = rec.frame;
    const gleicherPatient = alt && (
      (frame.patientId && alt.patientId && frame.patientId === alt.patientId) ||
      (!frame.patientId && !this.meta[frame.deviceId])   // keine ID: solange nicht manuell umgesetzt
    );
    if (alt && gleicherPatient) {
      if (!frame.species && alt.species) { frame.species = alt.species; frame.herkunft = frame.herkunft || alt.herkunft; }
      if (frame.weightKg == null && alt.weightKg != null) { frame.weightKg = alt.weightKg; frame.herkunft = frame.herkunft || alt.herkunft; }
      if (!frame.patientName && alt.patientName) frame.patientName = alt.patientName;
      if (!frame.geschlecht && alt.geschlecht) frame.geschlecht = alt.geschlecht;
      if (!frame.gebDatum && alt.gebDatum) frame.gebDatum = alt.gebDatum;
      if (!frame.patientId && alt.patientId) frame.patientId = alt.patientId;
      // Akte feldweise fortschreiben - nie ein bereits bekanntes Feld mit leer ueberschreiben.
      if (alt.akte) {
        frame.akte = Object.assign({}, alt.akte, frame.akte || {});
      }
      // EKG-Auswertung halten, bis ein neuer Streifen eine neue liefert (sonst blinkt sie zwischen
      // zwei ~30-s-Kurvennachrichten weg). Nur uebernehmen, wenn sie nicht zu alt ist (< 90 s).
      if (!frame.ekgAnalyse && alt.ekgAnalyse && (frame.ts - (alt.ekgAnalyse.ts || 0)) < 90000) {
        frame.ekgAnalyse = alt.ekgAnalyse;
      }
      if (!frame.herkunft && alt.herkunft) frame.herkunft = alt.herkunft;
    }

    /*
     * VITALWERTE UEBER KURZE LUECKEN HALTEN (Befund 23.07.2026, echtes LifeVet/N-Series).
     * Das Geraet sendet ZAHLEN (HF/SpO2/AF/Temp) und KURVEN in GETRENNTEN HL7-Nachrichten - und die
     * Kurven-Nachrichten (EKG 500 Hz) sind VIEL haeufiger. Die Registry behaelt aber nur den letzten
     * Frame: jede Kurvennachricht "leert" die eben gelesenen Vitalwerte sofort wieder. Folge: im Bild
     * flackern SpO2/HF weg oder erscheinen gar nicht (gemessen: 0 % sichtbar, obwohl SpO2 99 ankam).
     * Deshalb: den letzten gemessenen Wert je Parameter kurz festhalten. Der TTL sorgt dafuer, dass
     * ein ABGEZOGENER Sensor NICHT ewig einen alten Wert vortaeuscht - kommt 20 s kein neuer, leert es.
     */
    if (!gleicherPatient) rec.vitalHold = {};   // Patientenwechsel -> alte Vitalwerte verwerfen
    rec.vitalHold = rec.vitalHold || {};
    const VITAL_TTL = 20000, vhTs = frame.ts;
    const halte = (k, val) => {
      if (val != null && Number.isFinite(val)) { rec.vitalHold[k] = { v: val, ts: vhTs }; return val; }
      const h = rec.vitalHold[k];
      if (h && (vhTs - h.ts) < VITAL_TTL) return h.v;    // frisch genug -> weiterreichen
      if (h) delete rec.vitalHold[k];
      return val;
    };
    const fv = frame.vitals;
    fv.hr = halte('hr', fv.hr); fv.spo2 = halte('spo2', fv.spo2);
    fv.etco2 = halte('etco2', fv.etco2); fv.fico2 = halte('fico2', fv.fico2);
    fv.af = halte('af', fv.af); fv.temp = halte('temp', fv.temp);
    if (fv.nibp) { fv.nibp.sys = halte('sys', fv.nibp.sys); fv.nibp.dia = halte('dia', fv.nibp.dia); fv.nibp.map = halte('map', fv.nibp.map); }
    if (fv.ekgRhythm != null) rec.vitalHold.__r = { v: fv.ekgRhythm, ts: vhTs };
    else { const h = rec.vitalHold.__r; if (h && (vhTs - h.ts) < VITAL_TTL) fv.ekgRhythm = h.v; else if (h) delete rec.vitalHold.__r; }

    /*
     * ALLE ALARME AUFSAMMELN + KURZ HALTEN (26.07.2026, Wunsch "alle Alarme in der App anzeigen").
     * Der uMEC sendet physiologische Alarme (**T1/**RESP/**SpO2/**HF …) und technische Alarme
     * (EKG-Rauschen, Kabel Aus, CO2-Modulfehler …) in GETRENNTEN Nachrichten, ~1 s auseinander. Die
     * Registry behaelt aber nur den LETZTEN Frame - deshalb war immer nur EINE Sorte Alarme sichtbar,
     * die im Sekundentakt hin- und hersprang. Loesung: alle aktiven Alarme je Geraet mit TTL
     * aufsammeln, damit ALLE gleichzeitig und stabil im Bild stehen. Ein Alarm verschwindet erst,
     * wenn er ~15 s nicht mehr gesendet wurde (= am Geraet quittiert/behoben).
     */
    if (!gleicherPatient) rec.alarmHold = {};   // Patientenwechsel -> alte Alarme verwerfen
    rec.alarmHold = rec.alarmHold || {};
    const ALARM_TTL = 15000;
    (frame.alarms || []).forEach((a) => {
      const t = a && a.text ? a.text : (a != null ? String(a) : '');
      if (t) rec.alarmHold[t] = { text: t, quelle: (a && a.quelle) || 'geraet', ts: frame.ts };
    });
    Object.keys(rec.alarmHold).forEach((t) => { if (frame.ts - rec.alarmHold[t].ts > ALARM_TTL) delete rec.alarmHold[t]; });
    frame.alarms = Object.values(rec.alarmHold)
      .sort((a, b) => b.ts - a.ts)                       // frischester Alarm zuerst
      .slice(0, 30)
      .map((a) => ({ text: a.text, quelle: a.quelle }));

    /*
     * EKG-KURVE AUFSAMMELN + ANALYSIEREN (Befund 23.07.2026, echtes LifeVet/N-Series).
     * Das Geraet sendet den EKG-Streifen nur in ~1-s-Haeppchen und in SEPARATEN Nachrichten (mal
     * EKG, mal Pleth, mal CO2). Fuer eine belastbare QRS-/Rhythmus-/ST-Analyse braucht die Engine
     * >=2 s zusammenhaengende Kurve - deshalb verwarf sie bisher jeden Streifen als "zu kurz".
     * Loesung: die EKG-Samples ueber mehrere Nachrichten zu einem gleitenden 5-s-Fenster
     * zusammensetzen und die Analyse DARAUF rechnen. Zusaetzlich ALLE Kurvenkanaele kurz halten,
     * damit die Zeichnung nicht zwischen EKG/Pleth/CO2 hin- und herflackert.
     */
    const _istEkg = (k) => /ECG|EKG|ELEC_POTL/i.test((k.code || '') + (k.name || ''));
    const ekgNeu = (frame.kurvenDaten || []).find((k) => _istEkg(k) && k.hz && (k.samples || []).some((s) => s != null));
    const KURVE_TTL = 8000;
    if (ekgNeu) {
      const hz = ekgNeu.hz || 500;
      if (!rec.ekgBuf || rec.ekgBuf.hz !== hz || (frame.ts - (rec.ekgBufTs || 0)) > KURVE_TTL) {
        rec.ekgBuf = { samples: [], hz: hz, code: ekgNeu.code, name: ekgNeu.name, skala: ekgNeu.skala };
      }
      rec.ekgBuf.samples = rec.ekgBuf.samples.concat(ekgNeu.samples);
      if (ekgNeu.skala) rec.ekgBuf.skala = ekgNeu.skala;
      const maxN = Math.round(hz * 4);                       // gleitendes 4-s-Fenster (reaktionsschneller)
      if (rec.ekgBuf.samples.length > maxN) rec.ekgBuf.samples = rec.ekgBuf.samples.slice(-maxN);
      rec.ekgBufTs = frame.ts;
    } else if (rec.ekgBuf && (frame.ts - (rec.ekgBufTs || 0)) > KURVE_TTL) {
      rec.ekgBuf = null;                                     // laenger kein EKG -> verwerfen
    }
    // alle Kurvenkanaele kurz halten (stabile Zeichnung statt Flackern)
    rec.kurvenHold = rec.kurvenHold || {};
    (frame.kurvenDaten || []).forEach((k) => { rec.kurvenHold[k.code || k.name] = { k: k, ts: frame.ts }; });
    Object.keys(rec.kurvenHold).forEach((c) => { if (frame.ts - rec.kurvenHold[c].ts > KURVE_TTL) delete rec.kurvenHold[c]; });
    frame.kurvenDaten = Object.values(rec.kurvenHold).map((x) => x.k);
    // EKG-Kanal durch den laengeren Puffer ersetzen (fuer Analyse UND fluessigere Zeichnung)
    if (rec.ekgBuf && rec.ekgBuf.samples.length) {
      const voll = { name: rec.ekgBuf.name, code: rec.ekgBuf.code, hz: rec.ekgBuf.hz, skala: rec.ekgBuf.skala, samples: rec.ekgBuf.samples };
      const i = frame.kurvenDaten.findIndex(_istEkg);
      if (i >= 0) frame.kurvenDaten[i] = voll; else frame.kurvenDaten.push(voll);
      /*
       * QRS/Rhythmus/ST auf dem aufgesammelten Streifen (nur ab ~1,8 s belastbar) — GEDROSSELT auf
       * hoechstens ~1,4x/s. Ein 4-s-Fenster oefter durchzurechnen bringt kein neues Ergebnis, kostet
       * aber viel CPU auf dem Kiosk-i3 - und CPU-Last ist genau das, was die Live-Anzeige LANGSAM
       * macht. Zwischen den Rechnungen wird das letzte Ergebnis gehalten (bleibt "live" im Bild).
       */
      const genug = rec.ekgBuf.samples.filter((s) => s != null).length > rec.ekgBuf.hz * 1.8;
      if (ekgEngine && genug && (!rec.ekgAnaTs || (frame.ts - rec.ekgAnaTs) >= 700)) {
        try {
          const a = ekgEngine.analysiere(voll, { einheit: 'uV' });
          rec.ekgAna = {
            brauchbar: !!a.brauchbar, warum: a.warum || null,
            hf: a.hf != null ? a.hf : null, qrsBreiteMs: a.qrsBreiteMs != null ? a.qrsBreiteMs : null,
            rhythmus: a.rhythmus || null, st: a.st || null, guete: a.guete != null ? a.guete : null,
            sekunden: a.sekunden || null, ts: frame.ts,
          };
          rec.ekgAnaTs = frame.ts;
        } catch (_) { /* eine Analyse darf die Datenaufnahme nie stoppen */ }
      }
      if (rec.ekgAna && (frame.ts - (rec.ekgAnaTs || 0)) < 90000) frame.ekgAnalyse = rec.ekgAna;
    }

    /*
     * LIVE-HF AUS DER KURVE (Befund 23.07.2026): Das Geraet sendet die HF-ZAHL nur im Data Interval
     * (beim Anwender 10 s!) - die EKG-KURVE aber ~jede Sekunde. Ist die Kurvenanalyse belastbar, wird
     * IHRE HF (aus den RR-Abstaenden) als Live-HF genommen: die HF aktualisiert dann im Sekundentakt
     * statt alle 10 s. So sind HF + Herzanalyse "schnell live", auch wenn die Geraete-Zahl traege ist.
     * Nur bei belastbarer Analyse; sonst bleibt die (gehaltene) Geraete-HF unveraendert.
     */
    /*
     * HF = GENAU die HF DES MONITORS (Wunsch 23.07.2026: keine zwei verschiedenen Werte).
     * Die aus der Kurve gerechnete HF wird NICHT als Anzeige-HF genommen - sie wich vom Monitor ab
     * (App 80 vs. Monitor 95). Es zaehlt nur die HF-Zahl des Monitors (ueber die Zeit gehalten).
     * Damit auch im EKG-Analyse-Block dieselbe HF steht, wird die Analyse-HF an die Monitor-HF
     * angeglichen (eine einzige HF ueberall). QRS/Rhythmus/ST bleiben aus der Kurve.
     */
    if (frame.ekgAnalyse && frame.vitals.hr != null) {
      frame.ekgAnalyse = Object.assign({}, frame.ekgAnalyse, { hf: frame.vitals.hr });
    }

    rec.model = frame.deviceModel;
    rec.role = frame.deviceRole;
    rec.frame = frame;
    rec.lastTs = frame.ts;
    // Sendezeitpunkte fuer die Takt-Anzeige (nur die letzten 8, das genuegt fuer einen Median).
    rec.takte = (rec.takte || []).concat(frame.ts).slice(-8);
    this.devices.set(frame.deviceId, rec);
    if (isNew) this.log.info('discovery', 'Neues Geraet erkannt: ' + frame.deviceModel + ' [' + frame.deviceId + ', ' + frame.deviceRole + ']');
    if (warnings.length) warnings.forEach(w => this.log.warn('data', frame.deviceId + ': ' + w));
    return frame;
  }

  _status(rec, now) {
    const age = now - (rec.lastTs || 0);
    if (age < ACTIVE_MS) return 'active';
    if (age < STANDBY_MS) return 'standby';
    return 'offline';
  }

  /*
   * getDevices() — was im Geraete-Menue steht.
   *
   * WARUM SO AUSFUEHRLICH (Befund 22.07.2026): Der Tierarzt fragte, welches Geraet gerade
   * verbunden ist - und die Station konnte es nicht beantworten. Sie kannte nur einen internen
   * Namen ("assistent-8830"). Jetzt steht hier alles, was die Frage "haengt mein Monitor dran und
   * kommen Daten?" beantwortet: Modell, Adresse, Port, Uebertragungsweg, Sekunden seit dem letzten
   * Datenpaket, gemessener Sendetakt und die Klartextmeldungen des Geraets.
   */
  getDevices() {
    const now = Date.now();
    return [...this.devices.values()].map(r => {
      const f = r.frame || {};
      const takte = r.takte || [];
      // Sendetakt aus den letzten Abstaenden - sagt, ob ein Geraet zuegig oder traege liefert
      // (das LifeVet sendete ab Werk nur alle ~30 s; fuer eine Narkose ist das zu traege).
      let taktMs = null;
      if (takte.length >= 2) {
        const d = [];
        for (let i = 1; i < takte.length; i++) d.push(takte[i] - takte[i - 1]);
        d.sort((a, b) => a - b);
        taktMs = d[Math.floor(d.length / 2)];   // Median: unempfindlich gegen einen Ausreisser
      }
      return {
        deviceId: r.deviceId, model: r.model, role: r.role,
        status: this._status(r, now),
        patientId: f.patientId || null,
        patientName: f.patientName || null,
        species: f.species || null,
        weightKg: f.weightKg != null ? f.weightKg : null,
        herkunft: f.herkunft || null,
        // Vollstaendige Patientenakte des Geraets fuer die Anzeige im Geraete-Menue.
        geschlecht: f.geschlecht || null,
        gebDatum: f.gebDatum || null,
        akte: f.akte || null,
        ekgAnalyse: f.ekgAnalyse || null,
        ip: f.deviceIp || null,
        port: f.devicePort || null,
        transport: f.transport || null,
        alarms: f.alarms || [],
        kurven: f.kurven || [],
        rohAnzahl: (f.roh || []).length,
        werteAnzahl: zaehleWerte(f.vitals),
        seitMs: r.lastTs ? (now - r.lastTs) : null,
        taktMs: taktMs,
        manualKey: this.manual[r.deviceId] || null,   // manuelle Kopplung (fuer die Koppel-UI)
        meta: this.meta[r.deviceId] || null,           // Tierart/Gewicht/ID-Override
        lastTs: r.lastTs,
      };
    });
  }

  // Alle Rohwerte eines Geraets (Ansicht "Alle Werte vom Geraet").
  getRoh(deviceId) {
    const r = this.devices.get(deviceId);
    return (r && r.frame && r.frame.roh) || [];
  }

  // Die letzten unveraenderten HL7-Nachrichten aus dem Speicher-Ringpuffer der Probe-Adapter.
  // Zweck: belegen, in welchem HL7-Feld das Geraet die Stammdaten schickt (statt zu raten).
  getRohNachrichten() {
    const out = [];
    (this.adapters || []).forEach((a) => { (a && a.letzteRoh ? a.letzteRoh : []).forEach((r) => out.push(r)); });
    return out.sort((x, y) => (y.ts || 0) - (x.ts || 0));
  }

  getPatients() {
    const now = Date.now();
    const recs = [...this.devices.values()]
      .filter(r => this._status(r, now) !== 'offline')
      .map(r => ({ deviceId: r.deviceId, model: r.model, role: r.role, frame: r.frame }));
    return mergePatients(recs, this.manual);
  }

  // ---- Steuerung (veraendert nur Bridge/Zuordnung, NIE die Geraete) ----
  pair(deviceIds, patientKey) { (deviceIds || []).forEach(id => { this.manual[id] = patientKey; }); }
  unpair(patientKey) { for (const id in this.manual) if (this.manual[id] === patientKey) delete this.manual[id]; }
  setMeta(deviceId, meta) {
    this.meta[deviceId] = Object.assign(this.meta[deviceId] || {}, meta || {});
    const rec = this.devices.get(deviceId);
    /*
     * SOFORT WIRKSAM (Befund 23.07.2026): Der Handeintrag wurde bisher erst beim NAECHSTEN
     * Geraetepaket angewandt (ingest). Das LifeVet sendet aber nur alle ~30 s - der Tierarzt waehlte
     * also "Katze", und bis zu 30 s lang drehte die Anzeige es auf den alten Wert zurueck ("laesst
     * sich nicht aendern"). Deshalb wird der Eintrag hier direkt auf den aktuellen Frame gelegt, damit
     * ihn der naechste 500-ms-Rundruf sofort zeigt.
     */
    if (rec && rec.frame) {
      rec.frame.herkunft = Object.assign({}, rec.frame.herkunft);
      if (meta && meta.species) { rec.frame.species = meta.species; rec.frame.herkunft.species = 'manuell'; }
      if (meta && meta.weightKg != null && meta.weightKg !== '') { rec.frame.weightKg = Number(meta.weightKg); rec.frame.herkunft.weightKg = 'manuell'; }
      if (meta && meta.patientId) rec.frame.patientId = String(meta.patientId);
    }
    /*
     * Handeintrag DAUERHAFT an die Patienten-ID binden. So ueberlebt das einmal eingetragene
     * Gewicht/die Tierart jeden Neustart - solange derselbe Patient (gleiche ID) anliegt.
     * Bezugs-ID: die ausdruecklich mitgegebene, sonst die aktuell vom Geraet gemeldete.
     */
    const pid = String((meta && meta.patientId) || (rec && rec.frame && rec.frame.patientId) || '').trim();
    if (pid) {
      const eintrag = this.akteStore[pid] || {};
      if (meta && meta.species) eintrag.species = meta.species;
      if (meta && meta.weightKg != null && meta.weightKg !== '') eintrag.weightKg = Number(meta.weightKg);
      eintrag.ts = Date.now();
      this.akteStore[pid] = eintrag;
      this._akteSpeichern();
    }
  }

  setScenario(patientId, scenarioId) {
    let ok = false;
    for (const a of this.adapters) if (typeof a.setScenario === 'function') ok = a.setScenario(patientId, scenarioId) || ok;
    return ok;
  }

  dispose() {
    // Beim Beenden das Protokoll noch sichern — sonst gingen bis zu 5 s Narkoseverlauf verloren.
    if (this._protokollTimer) clearInterval(this._protokollTimer);
    this._protokollSpeichern();
    this.adapters.forEach(a => a.dispose && a.dispose());
  }
}

module.exports = { Registry };
