'use strict';
/*
 * drug-context-test.js — sichert die medikamenten-bewusste Beatmungsanalyse (Browser-App, daher
 * Quell-Check). Regel (Nutzer 25.07.2026): verabreichte Medikamente (Injektionsnarkose + einzeln
 * als „gegeben" markierte Notfall-/Weitere Medikamente) samt EKG/Monitor/Kapnograph gehen in die
 * Beatmungsmodus-Empfehlung ein; die App analysiert die FOLGEN der Wirkstoffe.
 * Start: node tools/drug-context-test.js
 */
const fs = require('fs');
const path = require('path');
const app = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

console.log('Medikamenten-bewusste Beatmungsanalyse — Selbsttest\n');

// 1) Zustand + Markieren „als gegeben" für JEDES Medikament (wie Injektionsnarkose)
ok('state.givenDrugs vorhanden', /givenDrugs\s*:\s*\[\]/.test(app));
ok('Medikamenten-Tab hat „als gegeben"-Umschalter', /data-give-drug=/.test(app) && /gegeben/.test(app));
ok('Umschalter füllt state.givenDrugs', /state\.givenDrugs\.(push|splice)/.test(app));

// 2) Pharmakologie-Klassifikator + Folgen
ok('DRUGFX-Wirkungskarte vorhanden', /var\s+DRUGFX\s*=/.test(app));
['methadon', 'propofol', 'dexmedetomidin', 'atropin', 'adrenalin', 'lidocain_iv', 'naloxon', 'atipamezol'].forEach((id) => {
  ok('DRUGFX kennt ' + id, new RegExp('\\b' + id + '\\s*:\\s*\\[').test(app));
});
ok('drugContext() vereint Injektion + gegebene Medikamente', /function\s+drugContext\s*\(/.test(app));
ok('Folgen-Flags: Atemdepression/Antagonist/Anticholinergikum', /respDep/.test(app) && /antagResp/.test(app) && /anticholinergic/.test(app));

// 3) Verknüpfung mit dem Beatmungsmodus-Berater + Coach (EKG/Monitor/Kapnograph + Medikamente)
ok('ventAdvice nutzt drugContext (nicht nur injContext)', /var\s+ctx\s*=\s*drugContext\(\)/.test(app));
ok('Atemdepression → kontrolliert (VCV/PCV) bereithalten', /Atemdepression[\s\S]{0,80}kontrolliert/.test(app) && /up\('vcv',2/.test(app));
ok('Antagonist an Bord → Spontanatmung/PSV begleiten', /antagResp[\s\S]{0,120}(psv|Atemantrieb kehrt zurück)/i.test(app));
ok('Anticholinergikum → Tachykardie erwartet (nicht als „zu flach" fehldeuten)', /Anticholinergikum[\s\S]{0,80}Tachykardie/.test(app));
ok('Reset löscht auch givenDrugs', /state\.givenDrugs\s*=\s*\[\]/.test(app));

// 4) Evidenzbasierte Verfeinerungen (Welt-Leitlinien: ACVAA/AAHA/WSAVA/Clinician's Brief)
ok('α2-Bradykardie = REFLEX → KEIN Atropin/Glyco (bradyReflex)', /bradyReflex/.test(app) && /α2-Bradykardie[\s\S]{0,90}KEIN Atropin/.test(app));
ok('Opioid-Bradykardie = vagal → Anticholinergikum angemessen (bradyVagal)', /bradyVagal/.test(app) && /Opioid-Bradykardie[\s\S]{0,80}(vagal|angemessen)/.test(app));
ok('Warnung: Anticholinergikum + α2 zusammen (Hypertonie/VES)', /anticholPlusAlpha2/.test(app) && /Hypertonie[\s\S]{0,40}(ventrikulär|VES)/i.test(app));
ok('Ketamin bei HCM-Katze vorsichtig', /Ketamin bei HCM-Katze/.test(app));
ok('Acepromazin-Folgen (Hypotonie, kein Antidot)', /phenothiazine/.test(app) && /Acepromazin[\s\S]{0,60}(Hypotonie|Vasodilatation)/.test(app));
ok('lungenschonende Beatmung 8–12 ml/kg (statt 10–15)', /lungenschonend 8–12 m[lL]\/kg/.test(app));
ok('Driving Pressure (Pplat−PEEP) im Ziel', /Driving Pressure/.test(app));

console.log('\n' + (fail ? ('FEHLER: ' + fail + ' Test(s) fehlgeschlagen, ' + pass + ' ok') : ('ALLE ' + pass + ' Tests bestanden')));
process.exit(fail ? 1 : 0);
