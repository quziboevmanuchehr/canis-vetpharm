# Veta 5 (Narkosegerät) live auslesen — Mitschnitt & virtuelles Gerät

> Stand 24.07.2026. Betrifft **nur das Narkosegerät Veta 5 Plus** (192.168.0.52).
> Der Monitor (LifeVet / uMEC12) ist davon unberührt — der liefert die Vitalwerte wie gehabt.

## Kurzfassung

- Das **virtuelle Narkosegerät** in der App (Tab **Gerät** und Tab **Einstellungen → Beatmungs-Modi**)
  zeigt **alle Beatmungsmodi** (VS, VS+, PSV, CPAP/PEEP, VCV, PCV, SIMV, Manuell), den **Kapnografen**
  (CO₂/EtCO₂) und **für jeden Fall** die passenden Einstellungen. Die **leuchtenden roten/grünen Buttons**
  empfehlen live — aus den **echten Monitorwerten** (SpO₂, EtCO₂, MAP, Rhythmus) + Zwischenfall + Rasse +
  gegebenen Medikamenten. Das funktioniert **ohne** Datenverbindung zum Narkosegerät.
- Sobald das Narkosegerät seine Einstellungen **lesbar** ins Netz gibt, **spiegelt** das virtuelle Gerät
  den **exakt eingestellten Modus + die Werte** („übernehmen und genau so zeigen"). Bis dahin ist der
  virtuelle Verdampfer/Modus **handbedient**.

## Warum es (noch) nicht von selbst live ist

Der Veta 5 sendet auf Port 4601 **MD2** — Mindrays proprietären Binärstrom (Rahmen `0x02`/STX + Sync-Wort
`A5 5A`). Den versteht **nur die kostenpflichtige BeneVision CMS Vet**. VetStation **liest ihn nicht und
rät ihn nicht** — ein geratener Beatmungswert am narkotisierten Patienten wäre gefährlich.

Beim **uMEC12** war es genauso, bis im Gerätemenü **`HL7 Compatibility: Ein`** gefunden wurde — dann kamen
echte HL7-Zahlen. **Für den Veta 5 ist dieser Schritt offen.** Deshalb: erst mitschneiden, dann entscheiden.

## Schritt 1 — Mitschneiden, was der Veta 5 sendet

```bash
node tools/veta5-mitschnitt.js --host 192.168.0.52 --port 4601 --seconds 60
```

Sendet das Gerät von sich aus zum PC (am Gerät **Serveradresse = PC-IP 192.168.0.99** setzen), stattdessen
zuhören:

```bash
node tools/veta5-mitschnitt.js --listen --port 4601 --seconds 120
```

Am Ende sagt das Werkzeug ehrlich:

- **`Protokoll: HL7 ✓ LESBAR`** → weiter mit Schritt 2.
- **`Protokoll: MD2 ✗ nicht direkt lesbar`** → am Gerät nach einem **HL7-/EMR-/Datenexport-Schalter**
  suchen (Analogie uMEC12 „HL7 Compatibility"); gibt es keinen, beim Händler (Eickemeyer) die
  **HL7-Freischaltung** erfragen. Ohne HL7 bleibt das virtuelle Gerät handbedient (der Berater läuft
  trotzdem aus den Monitorwerten).

Struktur eines Mitschnitts ansehen (ordnet **nie** Bytes zu Messwerten zu):

```bash
node tools/binaer-analyse.js bridge/data/veta5-4601.log
```

## Schritt 2 — Adapter einschalten (nur wenn HL7 bestätigt)

In `bridge/config/devices.json` den Adapter **`veta5`** auf `"enabled": true` setzen (Host `192.168.0.52`,
Port `4601`, `role: "anesthesia"`) und **`NEUSTART.bat`**. Danach übernimmt das virtuelle Gerät den am
Veta 5 eingestellten **Modus + Vt/AF/PEEP/Pinsp/…** automatisch und zeigt oben das Abzeichen
**🔗 live vom Veta 5 gespiegelt**. Dreht der Tierarzt am virtuellen Gerät, gilt seine Handeinstellung, bis
sich am echten Gerät wieder etwas ändert.

## Wie die Spiegelung technisch läuft

`Adapter (veta5) → hl7-Parser → registry.ingest → matching.mergePatients` reicht `ventMode`, `o2Flow`,
`isoPct` und `ventParams` (Vt/AF/I:E/PEEP/Pinsp/Tinsp/ΔPsupp/Trigger) zum Patienten durch. Die Shell
(`ui/vetstation-live.js drive()`) spiegelt sie **flankengetrieben** ins virtuelle Gerät (`state.dev`):
Modusname → App-Modus-ID, Werte → `state.dev.vp`. Kommt nichts (MD2), bleibt alles handbedient.
Im **Testmodus** (`START-TESTMODUS.bat`) liefert der Simulator diese Felder — so lässt sich die Spiegelung
ohne echtes Gerät ansehen.
