'use strict';
/*
 * umec12-nibp-test.js — verifiziert den uMEC12-Vet-HL7-Strom mit "HL7 Compatibility: Ein"
 * gegen ECHTE Mitschnitte (24.07.2026, Port 4601). Der uMEC12 sendet numerische OBX (NM),
 * darunter NIBP-Messungen (170/171/172) und dazwischen Alarm-Grenzen/-Einstellungen, die KEINE
 * Messwerte sind. Dieser Test sichert: echte NIBP wird gelesen, Platzhalter -100 verworfen,
 * Alarm-Konfig-Codes weder als Vitalwert noch als "unbekannter Code" gemeldet.
 *   node tools/umec12-nibp-test.js
 */
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
let fails = 0, passes = 0;
function ok(c, d, x) { if (c) { passes++; console.log('  ✓ ' + d); } else { fails++; console.log('  ✗ FAIL: ' + d + (x !== undefined ? '  [' + x + ']' : '')); } }
function msg(lines) { return lines.join('\r'); }

console.log('== uMEC12 (HL7 Compatibility: Ein) — echte NM-Mitschnitte ==');

/* A) ECHTE NIBP-Messung (Mitschnitt 15:28:09) → wird gelesen */
const A = parseHL7Message(msg([
  'MSH|^~\\&|||||||ORU^R01|503|P|2.3.1|',
  'OBX||NM|171^Dia|2105|66||||||F||APERIODIC|20260724152809',
  'OBX||NM|172^Mean|2105|82||||||F||APERIODIC|20260724152809',
  'OBX||NM|170^Sys|2105|98||||||F||APERIODIC|20260724152809',
]), {});
ok(A.vitals.nibp.sys === 98 && A.vitals.nibp.dia === 66 && A.vitals.nibp.map === 82,
  'echte NIBP 98/66 (MAP 82) wird gelesen (Codes 170/171/172)', JSON.stringify(A.vitals.nibp));

/* A2) weitere echte Messung 146/80 */
const A2 = parseHL7Message(msg([
  'MSH|^~\\&|||||||ORU^R01|503|P|2.3.1|',
  'OBX||NM|171^Dia|2105|80||||||F||APERIODIC|20260724153752',
  'OBX||NM|172^Mean|2105|123||||||F||APERIODIC|20260724153752',
  'OBX||NM|170^Sys|2105|146||||||F||APERIODIC|20260724153752',
]), {});
ok(A2.vitals.nibp.sys === 146 && A2.vitals.nibp.dia === 80, 'zweite echte NIBP 146/80 wird gelesen', JSON.stringify(A2.vitals.nibp));

/* B) PLATZHALTER -100 (zwischen den Messungen) → NICHT uebernehmen */
const B = parseHL7Message(msg([
  'MSH|^~\\&|||||||ORU^R01|503|P|2.3.1|',
  'OBX||NM|171^Dia|2105|-100||||||F||APERIODIC|00000000000000',
  'OBX||NM|172^Mean|2105|-100||||||F||APERIODIC|00000000000000',
  'OBX||NM|170^Sys|2105|-100||||||F||APERIODIC|00000000000000',
]), {});
ok(B.vitals.nibp.sys == null && B.vitals.nibp.dia == null && B.vitals.nibp.map == null,
  'Platzhalter -100 wird NICHT als Blutdruck uebernommen', JSON.stringify(B.vitals.nibp));

/* C) ALARM-GRENZEN (2002/2003 mit Sub-ID) → keine Vitals, KEIN unbekannter-Code-Alarm */
const unmappedC = [];
const C = parseHL7Message(msg([
  'MSH|^~\\&|||||||ORU^R01|51|P|2.3.1|',
  'OBX||NM|2002^|170|160||||||F',
  'OBX||NM|2003^|170|80||||||F',
  'OBX||NM|2002^|172|100||||||F',
  'OBX||NM|2003^|172|65||||||F',
]), {}, (u) => unmappedC.push(u));
ok(C.vitals.nibp.sys == null && C.vitals.hr == null, 'Alarm-Grenzen (2002/2003) werden NICHT zu Vitals', JSON.stringify(C.vitals.nibp));
ok(unmappedC.length === 0, 'Alarm-Grenzen fluten NICHT das "unbekannter Code"-Log', unmappedC.join(','));

/* D) ALARM-EINSTELLUNGEN (2013/2014/2016/2027/2028/2040/2041/2042) → still ignoriert */
const unmappedD = [];
const D = parseHL7Message(msg([
  'MSH|^~\\&|||||||ORU^R01|53|P|2.3.1|',
  'OBX||NM|2013^Alarmlautst.||1||||||F',
  'OBX||NM|2014^Alarm Mute||0||||||F',
  'OBX||NM|2028^Alm Sound Pause||0||||||F',
  'OBX||NM|2016^Alarm Pause||0||||||F',
  'OBX||NM|2042^||0||||||F',
]), {}, (u) => unmappedD.push(u));
ok(unmappedD.length === 0, 'Alarm-Einstellungen (2013/2014/2016/2028/2042) werden still ignoriert', unmappedD.join(','));

/* E) Alarm-Texte des uMEC kommen weiterhin an (Regression) */
const E = parseHL7Message(msg([
  'MSH|^~\\&|||||||ORU^R01|56|P|2.3.1|',
  'OBX||CE|3||205^SpO2-Sensor Aus||||||F|',
  'OBX||CE|4||5^EKG Kabel Aus||||||F|',
]), {});
ok((E.alarms || []).some((a) => /SpO2-Sensor Aus/.test(a.text)) && (E.alarms || []).some((a) => /EKG Kabel Aus/.test(a.text)),
  'Alarm-Texte (SpO2-Sensor Aus / EKG Kabel Aus) kommen weiterhin an', JSON.stringify((E.alarms || []).map((a) => a.text)));

console.log('\n== Ergebnis: ' + passes + ' OK, ' + fails + ' FAIL ==');
process.exit(fails ? 1 : 0);
