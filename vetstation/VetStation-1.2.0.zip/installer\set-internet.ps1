<#
  set-internet.ps1 - Traegt Standardgateway + DNS nach, OHNE die feste Geraete-IP zu aendern.

  WOFUER? (Befund 22.07.2026, Praxis-PC)
  NETZWERK-EINRICHTEN.bat setzt 192.168.0.99/24 OHNE Gateway - genau richtig fuer ein ISOLIERTES
  Geraetenetz mit eigenem Switch. Haengt der PC aber ueber einen Verstaerker (z. B. TP-Link) am
  Praxis-/Hausnetz, in dem ein Router steht, dann gilt:
      - Die GERAETEDATEN laufen weiter - Monitor und PC liegen im selben Netz.
      - Aber Update (Admin -> Aktualisieren), Fern-Live und die klinischen Daten sind STILL tot,
        weil der PC keinen Weg nach draussen kennt. Nichts davon meldet einen Fehler.
  Dieses Skript schliesst genau diese Luecke: gleiche IP, gleiche Maske, nur Gateway + DNS dazu.

  STRIKT READ-ONLY GEGENUEBER GERAETEN: es wird nur die Windows-Netzwerkkarte konfiguriert.

  EINFACHSTER WEG (nichts tippen): im Ordner C:\VetStation die Datei
  INTERNET-EINRICHTEN.bat DOPPELKLICKEN.

  Aufruf von Hand (VOLLSTAENDIGER Pfad in Anfuehrungszeichen):
      powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-internet.ps1"
  Rueckgaengig (zurueck ins isolierte Netz ohne Gateway):
      powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-internet.ps1" -Entfernen
#>
param(
  [string]$Adapter,
  [string]$Gateway,
  [string[]]$DNS,
  [switch]$Entfernen
)

# --- Adminrechte sicherstellen (sonst scheitert es erst ganz am Ende) ---------------
$__id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
  $__args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'))
  if ($Adapter)  { $__args += @('-Adapter', ('"' + $Adapter + '"')) }
  if ($Gateway)  { $__args += @('-Gateway', $Gateway) }
  if ($Entfernen) { $__args += '-Entfernen' }
  try { Start-Process powershell.exe -Verb RunAs -ArgumentList $__args }
  catch {
    Write-Warning "Adminrechte noetig. Bitte 'INTERNET-EINRICHTEN.bat' rechtsklicken -> Als Administrator ausfuehren."
    Start-Sleep 6
  }
  exit
}

Write-Host "== Internetzugang fuer diesen PC (Update + Fern-Live) =="
Write-Host ""

# --- Netzwerkkarte bestimmen -------------------------------------------------------
$VIRTUELL = 'VPN|Virtual|Hyper-V|VMware|VirtualBox|Loopback|Bluetooth|TAP-|Radmin|Tailscale|WireGuard|WAN Miniport'
if (-not $Adapter) {
  $nics = @(Get-NetAdapter | Where-Object {
      $_.Status -eq 'Up' -and $_.InterfaceDescription -notmatch $VIRTUELL -and $_.Name -notmatch $VIRTUELL
    } | Sort-Object Name)
  if ($nics.Count -eq 0) {
    Write-Warning "Keine aktive Netzwerkkarte gefunden. Steckt das LAN-Kabel?"
    Read-Host "Zum Schliessen die EINGABETASTE druecken"; exit 1
  }
  $Adapter = $nics[0].Name
  Write-Host ("Netzwerkkarte: {0}  ({1})" -f $nics[0].Name, $nics[0].InterfaceDescription)
}

$ipObj = Get-NetIPAddress -InterfaceAlias $Adapter -AddressFamily IPv4 -ErrorAction SilentlyContinue |
           Where-Object { $_.IPAddress -notlike '169.254.*' } | Select-Object -First 1
if (-not $ipObj) {
  Write-Warning "Die Karte '$Adapter' hat keine IPv4-Adresse. Erst NETZWERK-EINRICHTEN.bat ausfuehren."
  Read-Host "Zum Schliessen die EINGABETASTE druecken"; exit 1
}
$meineIp = $ipObj.IPAddress
$prefix  = $ipObj.PrefixLength
Write-Host ("Feste Adresse dieses PCs: {0}/{1}  - sie bleibt UNVERAENDERT." -f $meineIp, $prefix)

# --- Rueckbau: zurueck ins isolierte Netz ------------------------------------------
if ($Entfernen) {
  Write-Host ""
  Write-Host "Entferne Standardgateway und DNS (zurueck zum isolierten Geraetenetz)..."
  Get-NetRoute -InterfaceAlias $Adapter -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue |
    Remove-NetRoute -Confirm:$false -ErrorAction SilentlyContinue
  Set-DnsClientServerAddress -InterfaceAlias $Adapter -ResetServerAddresses -ErrorAction SilentlyContinue
  Write-Host "Fertig. Die Geraeteverbindung ist davon nicht betroffen." -ForegroundColor Green
  Read-Host "Zum Schliessen die EINGABETASTE druecken"; exit 0
}

# --- Router suchen: ueblicherweise .1 im eigenen Netz --------------------------------
function Antwortet($ip) {
  if (Test-Connection -ComputerName $ip -Count 1 -Quiet -ErrorAction SilentlyContinue) { return $true }
  foreach ($p in 80, 53, 443) {
    $c = New-Object System.Net.Sockets.TcpClient
    try { $r = $c.BeginConnect($ip, $p, $null, $null); if ($r.AsyncWaitHandle.WaitOne(700) -and $c.Connected) { $c.Close(); return $true } } catch {}
    $c.Close()
  }
  return $false
}

if (-not $Gateway) {
  $basis = ($meineIp -split '\.')[0..2] -join '.'
  Write-Host ""
  Write-Host "Suche den Router im Netz $basis.x ..."
  foreach ($kandidat in @("$basis.1", "$basis.254", "$basis.138")) {
    if (Antwortet $kandidat) { $Gateway = $kandidat; break }
  }
}

if (-not $Gateway) {
  Write-Host ""
  Write-Warning "In diesem Netz antwortet kein Router (.1/.254 wurden geprueft)."
  Write-Host "Das ist KEIN Fehler, wenn PC und Monitor allein an einem eigenen Switch haengen -"
  Write-Host "dann ist der PC absichtlich vom Internet getrennt und die Geraetedaten laufen trotzdem."
  Write-Host "Soll der PC ins Internet, muss er ans Praxisnetz (Router/Verstaerker) angeschlossen sein."
  Read-Host "Zum Schliessen die EINGABETASTE druecken"; exit 0
}

Write-Host ("Router gefunden: {0}" -f $Gateway) -ForegroundColor Green
if (-not $DNS -or $DNS.Count -eq 0) { $DNS = @($Gateway, '1.1.1.1') }

Write-Host ""
Write-Host "Es wird eingetragen:"
Write-Host ("   Standardgateway : {0}" -f $Gateway)
Write-Host ("   DNS-Server      : {0}" -f ($DNS -join ', '))
Write-Host ("   IP-Adresse      : {0}/{1}   (unveraendert - die Geraeteverbindung bleibt wie sie ist)" -f $meineIp, $prefix)
$ok = Read-Host "Fortfahren? j = ja, n = nein  (Standard: ja)"
if ($ok -ne '' -and $ok -notmatch '^(j|y)') { Write-Host "Abgebrochen."; Read-Host "EINGABETASTE"; exit 0 }

try {
  # Alte Standardroute dieser Karte entfernen (sonst zwei widerspruechliche Eintraege).
  Get-NetRoute -InterfaceAlias $Adapter -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue |
    Remove-NetRoute -Confirm:$false -ErrorAction SilentlyContinue

  # In BEIDE Speicher schreiben: ActiveStore wirkt sofort, PersistentStore ueberlebt den Neustart.
  # Fehlt der PersistentStore, ist das Internet nach dem naechsten Hochfahren still wieder weg -
  # genau die Sorte Fehler, die niemand mehr mit diesem Skript in Verbindung bringt.
  New-NetRoute -InterfaceAlias $Adapter -DestinationPrefix '0.0.0.0/0' -NextHop $Gateway `
               -PolicyStore ActiveStore -Confirm:$false -ErrorAction Stop | Out-Null
  New-NetRoute -InterfaceAlias $Adapter -DestinationPrefix '0.0.0.0/0' -NextHop $Gateway `
               -PolicyStore PersistentStore -Confirm:$false -ErrorAction SilentlyContinue | Out-Null

  Set-DnsClientServerAddress -InterfaceAlias $Adapter -ServerAddresses $DNS -ErrorAction Stop

  # --- Nachpruefen statt behaupten ---------------------------------------------------
  Start-Sleep -Seconds 2
  Clear-DnsClientCache -ErrorAction SilentlyContinue
  $pingOk = Test-Connection -ComputerName 1.1.1.1 -Count 2 -Quiet -ErrorAction SilentlyContinue
  $dnsOk = $false
  try { $null = Resolve-DnsName -Name 'github.com' -Type A -ErrorAction Stop; $dnsOk = $true } catch {}

  Write-Host ""
  if ($pingOk -and $dnsOk) {
    Write-Host "ERFOLG: Der PC kommt jetzt ins Internet (Ping + Namensaufloesung geprueft)." -ForegroundColor Green
    Write-Host "  -> Admin -> Aktualisieren, Fern-Live und die klinischen Daten funktionieren wieder."
  } elseif ($pingOk) {
    Write-Warning "Internet erreichbar, aber die Namensaufloesung (DNS) klappt noch nicht."
    Write-Host "  Meist braucht der Router einen Moment. Sonst hier einen anderen DNS setzen:"
    Write-Host "  powershell -ExecutionPolicy Bypass -File `"$PSCommandPath`" -DNS 1.1.1.1"
  } else {
    Write-Warning "Gateway eingetragen, es kommt aber noch keine Verbindung nach draussen zustande."
    Write-Host "  Pruefen: Hat der Verstaerker/Router selbst Internet? Antwortet $Gateway im Browser?"
    Write-Host "  Die GERAETEVERBINDUNG ist davon unabhaengig und laeuft weiter."
  }
  Write-Host ""
  Write-Host "Die feste Adresse $meineIp wurde NICHT veraendert - der Monitor sendet weiter dorthin."
} catch {
  Write-Warning "Fehler: $($_.Exception.Message)"
  Write-Host "Alternativ manuell: Systemsteuerung -> Netzwerkadapter -> IPv4-Eigenschaften ->"
  Write-Host "  Standardgateway $Gateway, bevorzugter DNS-Server $Gateway."
}

Write-Host ""
Read-Host "Fertig. Zum Schliessen die EINGABETASTE druecken"
