'use strict';
/*
 * version-test.js — EINE Quelle der Wahrheit fuer die Versionsnummer (Befund 2.4, 21.07.2026).
 *
 * Was war: /api/version meldete hartnaeckig 0.1.0, weil die Bridge bridge/package.json einlas
 * statt der Wurzel-package.json. In updater/version.json stand eine DRITTE Nummer.
 * Folge: nach einem Update war nicht feststellbar, ob es angekommen ist — und die
 * Update-Pruefung verglich gegen die falsche Zahl.
 *
 * Start: node tools/version-test.js      (laeuft auch in `npm test`)
 */
const fs = require('fs');
const path = require('path');
const version = require('../bridge/src/version');

const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function read(rel) { try { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); } catch (_) { return ''; } }
function json(rel) { try { return JSON.parse(read(rel)); } catch (_) { return null; } }

console.log('VetStation — eine Quelle der Wahrheit fuer die Version\n');

const app = version.appVersion();
console.log('  Massgebliche Version (Wurzel-package.json): ' + app + '\n');

ok('Wurzel-package.json hat eine gueltige Version', /^\d+\.\d+\.\d+$/.test(app), app);
ok('die Version ist nicht mehr 0.1.0 (der alte Fehlwert)', app !== '0.1.0');

const bridge = json('bridge/package.json');
ok('bridge/package.json stimmt mit der Wurzel ueberein', bridge && bridge.version === app,
  bridge ? bridge.version : '(nicht lesbar)');

const upd = json('updater/version.json');
ok('updater/version.json stimmt mit der Wurzel ueberein', upd && upd.app === app,
  upd ? upd.app : '(nicht lesbar)');

const iss = read('installer/vetstation-setup.iss');
const m = iss.match(/#define\s+AppVersion\s+"([^"]+)"/);
ok('Inno-Setup AppVersion stimmt mit der Wurzel ueberein', m && m[1] === app, m ? m[1] : '(nicht gefunden)');

// Der eigentliche Fehler: die Bridge las die FALSCHE Datei ein.
const idx = read('bridge/src/index.js');
ok('bridge liest NICHT mehr bridge/package.json fuer die Version',
  !/require\(\s*['"]\.\.\/package\.json['"]\s*\)/.test(idx));
ok('bridge benutzt das gemeinsame Versionsmodul', /require\(\s*['"]\.\/version['"]\s*\)/.test(idx));
ok('der Server bekommt appVersion() uebergeben', /version:\s*appVersion\(\)/.test(idx));

// Das Modul selbst muss die Abweichung auch melden koennen.
const p = version.pruefe();
ok('version.pruefe() meldet "stimmig"', p.stimmig === true,
  p.abweichungen.map((a) => a.datei + '=' + a.wert).join(', '));
ok('version.pruefe() nennt dieselbe Version', p.version === app);

// Die Station warnt beim Start, wenn doch einmal etwas auseinanderlaeuft.
ok('die Station warnt bei abweichenden Versionsnummern', /Versionsnummern weichen ab/.test(idx));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
