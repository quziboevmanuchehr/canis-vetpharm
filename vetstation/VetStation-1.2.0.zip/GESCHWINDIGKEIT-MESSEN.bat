@echo off
title VetStation - Geschwindigkeit der Fern-Uebertragung messen
REM Misst, wie lange ein Wertepaket vom Praxis-PC bis zur Cloud-Datenbank braucht.
REM Die zweite Haelfte der Strecke (Datenbank -> Zuhause) steht in der Web-App unter
REM "Fern-Live" -> "Verbindung & Geschwindigkeit".
cd /d "%~dp0"
if exist "%~dp0node\node.exe" goto portabel
node "%~dp0tools\fern-messen.js" %*
goto ende
:portabel
"%~dp0node\node.exe" "%~dp0tools\fern-messen.js" %*
:ende
echo.
pause
