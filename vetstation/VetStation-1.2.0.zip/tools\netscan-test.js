'use strict';
/*
 * netscan-test.js — sichert die GERAETESUCHE ab (Befund 2.1 / 2.13, 21.07.2026).
 *
 * Was hier NIE wieder passieren darf:
 *   • Ein Geraet mit unbekanntem MAC-Praefix wird stillschweigend verworfen
 *     (Hersteller darf HINWEIS sein, niemals FILTER).
 *   • Ein Buero-PC, ein Drucker oder der Router wird als "moegliches Geraet" ausgegeben —
 *     nach der Suche blieben so sieben Kandidaten uebrig, KEINER davon ein Medizingeraet.
 *   • Ein Fund ohne Begruendung: jede Einstufung muss sagen, WARUM.
 *
 * Start: node tools/netscan-test.js      (laeuft auch in `npm test`)
 */
const ns = require('../bridge/src/netscan');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function stufe(h) { return ns.classifyHost(h).stufe; }
function gruende(h) { return ns.classifyHost(h).gruende.join(' | '); }

console.log('VetStation — Geraetesuche (aktive Suche + Einstufung)\n');

/* ---------------- 1) Datenport schlaegt ALLES ---------------- */
console.log('Ein offener Datenport macht den Fund sicher:');
ns.DATA_PORTS.forEach((p) => {
  ok('Port ' + p + ' offen -> sicher', stufe({ ip: '192.168.0.50', offenePorts: [p] }) === 'sicher',
    stufe({ ip: '192.168.0.50', offenePorts: [p] }));
});
ok('Begruendung nennt den Datenport',
  /Datenport 3502/.test(gruende({ ip: '192.168.0.50', offenePorts: [3502] })));

/* ---------------- 2) Hersteller ist HINWEIS, kein FILTER ---------------- */
console.log('\nHersteller ist Hinweis, kein Filter (Kernfehler der alten Suche):');
ok('unbekannte MAC + Datenport = trotzdem sicher',
  stufe({ ip: '192.168.0.60', mac: 'aabbccddeeff', offenePorts: [3502] }) === 'sicher');
ok('gar keine MAC + Datenport = trotzdem sicher',
  stufe({ ip: '192.168.0.61', mac: null, offenePorts: [4601] }) === 'sicher');
ok('Mindray-MAC ohne Datenport = sicher (Datenausgabe nur aus)',
  stufe({ ip: '192.168.0.50', mac: '98cce4112233', offenePorts: [] }) === 'sicher');
ok('zweites Mindray-Praefix (LifeVet) wird erkannt',
  stufe({ ip: '192.168.0.51', mac: '000f14aabbcc', offenePorts: [] }) === 'sicher');
// Diese Pruefung hiess frueher: "Begruendung nennt 'Datenausgabe am Geraet vermutlich aus'".
// Genau dieser Satz war FALSCH GESCHLOSSEN und wurde am 22.07.2026 entfernt - ein sendendes
// Geraet oeffnet gar keinen Port. Die genauen Anforderungen an den neuen Text stehen unten
// in Abschnitt "Ein sendendes Geraet ohne offenen Port wird richtig erklaert".
ok('bei Mindray-MAC ohne Port wird die Lage erklaert statt geraten',
  /NORMAL/.test(gruende({ ip: '192.168.0.50', mac: '98cce4112233', offenePorts: [] })));

/* ---------------- 3) Fremdgeraete herabstufen — MIT Begruendung ---------------- */
console.log('\nBuero-PCs, Drucker und Router werden herabgestuft (Befund 2.13):');
ok('Windows-Dateifreigabe (445) -> unwahrscheinlich',
  stufe({ ip: '192.168.0.233', offenePorts: [445, 139] }) === 'unwahrscheinlich');
ok('Remotedesktop (3389) -> unwahrscheinlich',
  stufe({ ip: '192.168.0.233', offenePorts: [3389] }) === 'unwahrscheinlich');
ok('Drucker (9100) -> unwahrscheinlich',
  stufe({ ip: '192.168.0.104', offenePorts: [9100] }) === 'unwahrscheinlich');
ok('Drucker (631/IPP) -> unwahrscheinlich',
  stufe({ ip: '192.168.0.104', offenePorts: [631] }) === 'unwahrscheinlich');
ok('Router (Gateway) -> unwahrscheinlich',
  stufe({ ip: '192.168.0.1', istGateway: true, offenePorts: [53, 80] }) === 'unwahrscheinlich');
ok('Zufalls-MAC (Handy) -> unwahrscheinlich',
  stufe({ ip: '192.168.0.77', mac: '3aBB33445566'.toLowerCase(), offenePorts: [] }) === 'unwahrscheinlich');
ok('Herabstufung wird BEGRUENDET, nicht verschwiegen',
  /Dateifreigabe/.test(gruende({ ip: '192.168.0.233', offenePorts: [445] })));
ok('Router-Begruendung nennt den Grund',
  /Gateway|Router/.test(gruende({ ip: '192.168.0.1', istGateway: true, offenePorts: [] })));

/* ---------------- 3b) Ein zweiter PC mit VetStation ist kein Geraet ---------------- */
// Beobachtet am 22.07.2026: 192.168.0.233 wurde als "sicher ein Geraet" gemeldet, weil es auf
// 2575, 3502, 4601, 5000, 8830 UND 24105 antwortete - das ist der Verbindungs-Assistent von
// VetStation selbst. Ein echter Monitor oeffnet hoechstens EINEN Datenport.
console.log('\nEin zweiter PC mit VetStation wird nicht fuer ein Geraet gehalten:');
const alleP = ns.DATA_PORTS.slice();
ok('antwortet auf ALLE Datenports -> unwahrscheinlich',
  stufe({ ip: '192.168.0.233', mac: '88aedd8aafaa', offenePorts: alleP }) === 'unwahrscheinlich',
  stufe({ ip: '192.168.0.233', mac: '88aedd8aafaa', offenePorts: alleP }));
ok('die Begruendung nennt den Grund im Klartext',
  /PC mit laufender VetStation/.test(gruende({ ip: '192.168.0.233', offenePorts: alleP })));
ok('sie erklaert auch, woran man es erkennt (ein Monitor oeffnet nur einen Port)',
  /hoechstens einen Port/.test(gruende({ ip: '192.168.0.233', offenePorts: alleP })));
ok('der Fund wird als zweite Station markiert',
  ns.classifyHost({ ip: '192.168.0.233', offenePorts: alleP }).zweiteStation === true);
ok('EIN offener Datenport bleibt ein sicheres Geraet',
  stufe({ ip: '192.168.0.50', offenePorts: [3502] }) === 'sicher');
ok('auch zwei offene Datenports noch',
  stufe({ ip: '192.168.0.50', offenePorts: [3502, 4601] }) === 'sicher');
ok('aber eine Medizin-MAC schlaegt die Regel IMMER (Monitor bleibt Monitor)',
  stufe({ ip: '192.168.0.51', mac: '000f142b1052', offenePorts: alleP }) === 'sicher');

/* ---------------- 3c) Sendendes Geraet ohne offenen Port ---------------- */
// KORREKTUR: "kein offener Datenport" hiess frueher "Datenausgabe vermutlich aus". Falsch -
// ein Geraet, das seine Werte SENDET, lauscht ueberhaupt nicht.
console.log('\nEin sendendes Geraet ohne offenen Port wird richtig erklaert:');
const lifevet = { ip: '192.168.0.51', mac: '000f142b1052', offenePorts: [] };
ok('bleibt "sicher ein Geraet"', stufe(lifevet) === 'sicher');
ok('behauptet NICHT mehr "Datenausgabe vermutlich aus"',
  !/Datenausgabe am Geraet vermutlich aus/.test(gruende(lifevet)), gruende(lifevet));
ok('erklaert, dass ein sendendes Geraet nicht lauscht', /lauscht nicht|ruft den PC an/.test(gruende(lifevet)));
ok('nennt "das ist NORMAL"', /NORMAL/.test(gruende(lifevet)));
ok('verweist darauf, dass erst der Empfang die Frage beantwortet', /Lauschphase|Patientenanzeige/.test(gruende(lifevet)));
ok('markiert den Fund als vermutlich sendend', ns.classifyHost(lifevet).sendetVermutlich === true);

/* ---------------- 4) Ein Monitor bleibt ein Monitor ---------------- */
console.log('\nDatenport/Medizin-MAC schlagen die Fremdgeraete-Erkennung IMMER:');
ok('Datenport + SMB -> trotzdem sicher',
  stufe({ ip: '192.168.0.50', offenePorts: [3502, 445] }) === 'sicher');
ok('Mindray-MAC + Druckerport -> trotzdem sicher',
  stufe({ ip: '192.168.0.50', mac: '98cce4000001', offenePorts: [9100] }) === 'sicher');
ok('Datenport + Gateway-Adresse -> trotzdem sicher',
  stufe({ ip: '192.168.0.1', istGateway: true, offenePorts: [3502] }) === 'sicher');

/* ---------------- 5) Unbestimmte ehrlich als "moeglich" ---------------- */
console.log('\nUnbestimmte Funde werden ehrlich als "moeglich" gemeldet:');
ok('antwortet, aber nichts spricht dafuer/dagegen -> moeglich',
  stufe({ ip: '192.168.0.90', mac: '001122334455', offenePorts: [] }) === 'moeglich');
ok('80/443 offen ist KEIN Fremd-Merkmal (Monitore haben Web-Konfig)',
  stufe({ ip: '192.168.0.90', mac: '001122334455', offenePorts: [80, 443] }) === 'moeglich');
ok('"moeglich" nennt den Grund',
  /kein Datenport offen/.test(gruende({ ip: '192.168.0.90', offenePorts: [] })));
ok('fehlende MAC wird als solche benannt',
  /keine MAC ermittelbar/.test(gruende({ ip: '192.168.0.90', mac: null, offenePorts: [] })));
ok('eigener PC wird als solcher erkannt',
  stufe({ ip: '192.168.0.99', selbst: true, offenePorts: [3502] }) === 'selbst');

/* ---------------- 6) ARP-Auswertung ---------------- */
console.log('\nARP-Tabelle lesen:');
const arpAusgabe = [
  'Schnittstelle: 192.168.0.99 --- 0xd',
  '  Internetadresse       Physische Adresse     Typ',
  '  192.168.0.1           a4-2b-b0-11-22-33     dynamisch',
  '  192.168.0.50          98-cc-e4-aa-bb-cc     dynamisch',
  '  192.168.0.255         ff-ff-ff-ff-ff-ff     statisch',
  '  224.0.0.22            01-00-5e-00-00-16     statisch',
].join('\r\n');
const map = ns.parseArpTable(arpAusgabe);
ok('Router-MAC gelesen', map['192.168.0.1'] === 'a42bb0112233', JSON.stringify(map));
ok('Monitor-MAC gelesen', map['192.168.0.50'] === '98cce4aabbcc');
ok('Broadcast wird ignoriert', map['192.168.0.255'] === undefined);
ok('Multicast wird ignoriert', map['224.0.0.22'] === undefined);
ok('leere Ausgabe stuerzt nicht ab', Object.keys(ns.parseArpTable('')).length === 0);
ok('Hersteller aus MAC', ns.herstellerVon('98cce4aabbcc') && /Mindray/.test(ns.herstellerVon('98cce4aabbcc')));
ok('Medizin-MAC erkannt', ns.istMedizinMac('000f14aabbcc') === true);
ok('fremde MAC ist keine Medizin-MAC', ns.istMedizinMac('a42bb0112233') === false);
ok('Zufalls-MAC erkannt (lokal verwaltetes Bit)', ns.istZufallsMac('3a1122334455') === true);
ok('feste MAC ist keine Zufalls-MAC', ns.istZufallsMac('98cce4aabbcc') === false);

/* ---------------- 6b) Nachtrag aus der ARP-Tabelle ---------------- */
console.log('\nStill verwerfende Geraete werden aus der MAC-Tabelle nachgetragen:');
const gefunden = [{ ip: '192.168.0.1', offenePorts: [53] }];
const arpMap2 = {
  '192.168.0.1': 'a42bb0112233',
  '192.168.0.50': '98cce4aabbcc',   // hat auf TCP NICHT geantwortet, steht aber im ARP
  '192.168.0.99': '001122334455',   // das ist der PC selbst
  '10.9.9.9': 'aabbccddeeff',       // fremdes Netz
  '192.168.0.255': 'ffffffffffff',  // Broadcastadresse
};
const ergaenzt = ns.ergaenzeAusArp(gefunden, arpMap2, '192.168.0.', '192.168.0.99');
const ips = ergaenzt.map((h) => h.ip);
ok('das stille Geraet wird nachgetragen', ips.indexOf('192.168.0.50') >= 0, ips.join(', '));
ok('der eigene PC wird nicht doppelt aufgenommen', ips.indexOf('192.168.0.99') < 0);
ok('fremde Netze bleiben aussen vor', ips.indexOf('10.9.9.9') < 0);
ok('die Broadcastadresse wird ausgelassen', ips.indexOf('192.168.0.255') < 0);
ok('bereits gefundene Teilnehmer bleiben unveraendert', ergaenzt[0].offenePorts.indexOf(53) >= 0);
ok('Nachtraege sind als solche gekennzeichnet',
  ergaenzt.find((h) => h.ip === '192.168.0.50').nurArp === true);
ok('ohne ARP-Tabelle passiert nichts Schlimmes',
  ns.ergaenzeAusArp(gefunden, null, '192.168.0.', '192.168.0.99').length === 1);

/* ---------------- 7) Netzbereich ---------------- */
console.log('\nNetzbereich bestimmen:');
const s24 = ns.subnetOf({ address: '192.168.0.99', netmask: '255.255.255.0' });
ok('/24 -> Basis 192.168.0.', s24 && s24.base === '192.168.0.', JSON.stringify(s24));
ok('/24 wird nicht begrenzt', s24 && s24.begrenzt === false);
const s16 = ns.subnetOf({ address: '10.1.2.3', netmask: '255.255.0.0' });
ok('/16 wird auf das /24 des PCs begrenzt (sonst Stunden Laufzeit)', s16 && s16.begrenzt === true && s16.base === '10.1.2.');
ok('Gateway wird als .1 angenommen', ns.gatewayIp('192.168.0.') === '192.168.0.1');
ok('unsinnige Adresse gibt null statt Absturz', ns.subnetOf({ address: 'keine', netmask: 'x' }) === null);

/* ---------------- 8) Fremdport-Tabelle vollstaendig beschrieben ---------------- */
console.log('\nJeder Fremdport hat einen Klartext-Namen:');
ok('alle Fremdports sind benannt',
  Object.keys(ns.FREMD_PORTS).every((p) => typeof ns.FREMD_PORTS[p] === 'string' && ns.FREMD_PORTS[p].length > 3));
ok('3502 gilt als Datenport und NICHT als Fremdport',
  ns.DATA_PORTS.indexOf(3502) >= 0 && !ns.FREMD_PORTS[3502]);
ok('3502 wird zuerst geprueft (Praxis-Standard)', ns.DATA_PORTS[0] === 3502);

/* ---------------- 9) Gleichzeitigkeitspool ---------------- */
console.log('\nSuchlauf-Technik:');
(async () => {
  let gleichzeitig = 0, hoechstens = 0;
  const items = Array.from({ length: 50 }, (_, i) => i);
  const res = await ns.pool(items, async (x) => {
    gleichzeitig++; hoechstens = Math.max(hoechstens, gleichzeitig);
    await new Promise((r) => setTimeout(r, 3));
    gleichzeitig--;
    return x * 2;
  }, 8);
  ok('Pool haelt die Gleichzeitigkeit ein (max 8)', hoechstens <= 8, 'gemessen: ' + hoechstens);
  ok('Pool liefert alle Ergebnisse in der richtigen Reihenfolge',
    res.length === 50 && res[7] === 14 && res[49] === 98);

  const r = await ns.knock('192.0.2.1', 3502, 120);   // TEST-NET-1: antwortet garantiert nie
  ok('Anklopfen an eine tote Adresse meldet "lebt nicht"', r.lebt === false && r.offen === false, JSON.stringify(r));

  /* ------------------------------------------------------------------ *
   * ALTE GERAETE UND DIE GANZE VERKABELUNG (31.07.2026)
   * ------------------------------------------------------------------ */
  console.log('\nAeltere Geraete und mehrere Netzwerkkarten:');

  /* Port 5510 steht auf dem Geraet selbst: Eickemeyer LifeVet M, Benutzerwartung, Feld
   * "Server-Port". Fehlt er in DATA_PORTS, sendet das Geraet sauber und niemand hoert zu — und
   * zwar OHNE Meldung, weil nie ein Byte ankommt. Genau diese Sorte Fehler ist unsichtbar. */
  ok('Port 5510 ist ein Datenport (Server-Port des LifeVet M)', ns.DATA_PORTS.indexOf(5510) >= 0);
  ok('8830 ist weiterhin dabei (LifeVet 10C)', ns.DATA_PORTS.indexOf(8830) >= 0);
  ok('3502 wird weiterhin zuerst geklopft (uMEC12-Standard)', ns.DATA_PORTS[0] === 3502);
  ok('5510 ist KEIN Fremdgeraete-Port', !ns.FREMD_PORTS[5510]);

  /*
   * Die Auswahl der Netzwerkkarten. Bis 31.07.2026 wurde nur echte[0] abgesucht — am Praxis-PC
   * mit Geraetenetz UND Hausnetz also die Haelfte, und welche Haelfte, entschied Windows.
   */
  const K = (adr, virt, netmask) => ({ address: adr, virtuell: !!virt, netmask: netmask || '255.255.255.0', family: 'IPv4' });
  let w = ns.welcheNetze([K('192.168.0.5'), K('192.168.7.10')]);
  ok('zwei echte Netze werden BEIDE abgesucht', w.karten.length === 2,
    w.karten.map((x) => x.address).join(','));
  w = ns.welcheNetze([K('192.168.0.5'), K('192.168.0.6')]);
  ok('zwei Karten im SELBEN Netz werden nur einmal abgesucht', w.karten.length === 1,
    w.karten.map((x) => x.address).join(','));
  w = ns.welcheNetze([K('192.168.0.5'), K('10.8.0.2', true), K('172.20.5.1', true)]);
  ok('virtuelle Karten (VPN/Hyper-V) werden nicht abgesucht', w.karten.length === 1
    && w.karten[0].address === '192.168.0.5', w.karten.map((x) => x.address).join(','));
  w = ns.welcheNetze([K('192.168.0.5'), K('93.184.216.34')]);
  ok('oeffentliche Adressen werden nicht abgesucht', w.karten.length === 1
    && w.karten[0].address === '192.168.0.5', w.karten.map((x) => x.address).join(','));
  w = ns.welcheNetze([K('192.168.1.1'), K('192.168.2.1'), K('192.168.3.1'), K('192.168.4.1')]);
  ok('mehr als ' + ns.NETZE_MAX + ' Netze werden gedeckelt', w.karten.length === ns.NETZE_MAX);
  ok('und die uebrigen werden GEMELDET, nicht verschwiegen', w.weitere.length === 1
    && w.weitere[0].address === '192.168.4.1', JSON.stringify(w.weitere.map((x) => x.address)));
  w = ns.welcheNetze([K('93.184.216.34')]);
  ok('ohne private Karte wird trotzdem gesucht statt aufzugeben', w.karten.length === 1);
  w = ns.welcheNetze([]);
  ok('ganz ohne Netzwerkkarte gibt es nichts zu suchen', w.karten.length === 0);

  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
})();
