'use strict';
/*
 * tafelabo.js — DER LESEWEG. Der Tafel-Strom aller OP-Saele dieses Praxis-Kontos.
 *
 * Diese Datei liest, sie schreibt nichts. Sie haelt eine Dauerverbindung auf
 * /live/<uid>/tafel.json und traegt aus den Ereignissen der Datenbank einen Stand je Saal
 * zusammen: Name, Alter, Kacheln, Geraetezeilen. Wer den Nachbarstreifen auf dem Kiosk oder die
 * Saalliste in der Oberflaeche fuellt, holt sie hier ab (saele()).
 *
 * ------------------------------------------------------------------------------------------
 * DIE WICHTIGSTE AUSSAGE DIESER DATEI: SIE DARF DEN SCHREIBWEG NICHT ANFASSEN.
 * ------------------------------------------------------------------------------------------
 * cloud.js zaehlt Schreibfehler in konfigFehler, und drei davon schalten die Fern-Uebertragung
 * dieser Praxis ab (cloud.js: konfigFehler >= 3 -> _selbstAbschalten). Ein ausgefallener NACHBAR
 * darf die eigene Uebertragung niemals anfassen — deshalb hat dieser Leser
 *   • ein EIGENES Fehlerkonto (_fehlerAnzahl) und einen EIGENEN Backoff (2 s .. 60 s),
 *   • EIGENE HTTP-Agenten (cloud.js haelt maxSockets 4 fuer den Schreibweg; ein dauerhaft
 *     offener Strom haette dort eine der vier Verbindungen fuer immer belegt und den eigenen
 *     Saal langsamer gemacht — genau das verbietet Randbedingung 5),
 *   • KEINE Kenntnis vom Schreibweg: es gibt in dieser Datei kein Feld, ueber das man ihn
 *     erreichen koennte, und der Konstruktor merkt sich keine unbekannten Optionen.
 * Was ein Lesefehler bewirkt, ist genau eins: die Saalliste veraltet und stand() sagt es.
 *
 * ------------------------------------------------------------------------------------------
 * WARUM EIN STROM (SSE) UND KEIN ABRUF IM TAKT
 * ------------------------------------------------------------------------------------------
 * Ein Abruf im 2-s-Takt zahlt JEDES MAL den vollen Zweig; der Strom zahlt das Vollbild einmal
 * und danach nur noch die Aenderung. Bei acht Saelen mit Kacheln und Geraetezeilen ist das der
 * Unterschied zwischen "passt ins Freikontingent" und "passt nicht" (offene Frage 1 im Plan).
 * Der Plantext nennt als Ausweichweg einen Abruf im 2-s-Takt (Konfigschluessel nachbarn.leseart).
 * DEN GIBT ES HIER BEWUSST NICHT: cloud.js liest die Koepfe der Nachbarsaele in seinem eigenen
 * Rueckleseweg ohnehin schon im Takt (cloud.js _nachbarnLesen, fremdLeseTaktMs). Ein zweiter
 * Abrufweg an dieser Stelle waere eine zweite Quelle fuer dieselbe Aussage — und zwei Quellen,
 * die sich widersprechen koennen, sind schlimmer als eine, die ausfaellt.
 *
 * Kein Firebase-SDK: nur http/https aus dem Node-Bestand, wie der Rest der Bridge. Der Strom ist
 * ein gewoehnlicher GET mit "Accept: text/event-stream", die Antwort ein Zeilenformat mit
 * "event:" und "data:" je Rahmen. Behandelt werden put, patch, keep-alive, auth_revoked, cancel.
 *
 * ZWEI WEITERE ABWEICHUNGEN VOM PLANTEXT, BEIDE MIT GRUND:
 *  (a) Kein Budgetwaechter, der "auf 5-s-Takt geht". Ein Strom HAT keinen Takt, den man
 *      verlangsamen koennte — man kann ihn nur trennen. Was dieser Leser dem Waechter schuldet,
 *      ist die Messgroesse, und die liefert er: stand().bytes. Wer das Monatsvolumen kennt (das
 *      weiss cloud.js, nicht diese Datei), ruft stop() und spaeter wieder start(). Eine zweite
 *      Stelle, die dasselbe Volumen schaetzt, waere eine zweite Wahrheit ueber dieselbe Zahl.
 *
 *      WAS stand().bytes GENAU ZAEHLT (Befund C7 — der Satz stand hier einmal groesser, als der
 *      Code ihn halten konnte): den entschluesselten Rumpf der laufenden Stroeme UND den Aufschlag
 *      JEDER Verbindung — die Antwortkopfzeilen (aus res.rawHeaders gerechnet) sowie die Rumpfe
 *      der Umleitungs- und Fehlerantworten. Genau die machen den Verbrauch aus, wenn der Leser
 *      wegen einer stoerenden Zwischenstelle im Sekundentakt neu verbindet — also in der Lage, in
 *      der ein zu niedrig geschaetzter Verbrauch am teuersten ist (der Kontingentdeckel des
 *      gemeinsamen Firebase-Projekts trifft ALLE Praxen). NICHT gezaehlt wird, was unterhalb von
 *      Node nicht sichtbar ist: TCP/TLS-Handschlag, Sendekopfzeilen, HTTP/2-Rahmen. Die Zahl ist
 *      damit eine Untergrenze, keine Abrechnung — wer einen Monatsdeckel darauf stuetzt, muss
 *      diesen Aufschlag einplanen.
 *  (b) Kein Rueckruf nach aussen. Wer die Saele braucht, HOLT sie (saele()). Ein Rueckruf aus dem
 *      Lesestrom heraus koppelte fremde Daten in den Takt des eigenen Saals ein — der eigene
 *      Rundruf bekommt seinen eigenen Zeitgeber (Plan-Schritt 17), und Randbedingung 5 verlangt,
 *      dass die Anzeige des EIGENEN Saals durch nichts langsamer wird.
 *
 * ------------------------------------------------------------------------------------------
 * DIE UMLEITUNG (307) IST PFLICHT, NICHT KUER
 * ------------------------------------------------------------------------------------------
 * Die Realtime Database beantwortet einen Stromanfang regelmaessig mit 307 auf einen
 * namensraum-eigenen Server (s-euw1b-nss-N.europe-west1.firebasedatabase.app). Wer ihr nicht
 * folgt, bekommt nie ein Ereignis. Gefolgt wird hoechstens UMLEITUNGEN_MAX mal und NUR auf einen
 * Rechnernamen unter derselben Domaene (letzte zwei Namensteile) — der Zugangsschluessel steht in
 * der Adresse, und einer fremden Domaene darf man ihn nicht hinterhertragen.
 *
 * ------------------------------------------------------------------------------------------
 * ALTER IMMER UEBER DIE SERVERZEIT
 * ------------------------------------------------------------------------------------------
 * Das Alter eines fremden Saals wird NIE gegen die fremde Uhr gerechnet, sondern gegen die Zeit
 * der Datenbank: meta.sv setzt der Server selbst, und der Versatz zwischen dieser Uhr und der
 * PC-Uhr wird aus der HTTP-Date-Kopfzeile JEDER Antwort gemessen (Median der letzten
 * VERSATZ_PROBEN Messungen, wie im Plan). Ohne das haelt ein OP-PC mit falscher Uhr jeden
 * Nachbarn fuer "aus der Zukunft" oder einen toten Saal fuer brandaktuell.
 * Die Date-Kopfzeile hat 1 s Aufloesung — Vergleiche unter einer Sekunde traegt sie nicht, und
 * genau darauf sind die Schwellen von tafel.js (12 s / 60 s / 12 h) ausgelegt.
 *
 * ------------------------------------------------------------------------------------------
 * DER DECKEL (Nachbesserung N17): LAUT, NIE STILL
 * ------------------------------------------------------------------------------------------
 * Gefuehrt werden hoechstens GRENZEN.saele (8) Saele, stabil sortiert nach Saalname und bei
 * gleichem Namen nach Stationskennung. Was darueber liegt, wird gezaehlt, in stand() namentlich
 * genannt und im Log gemeldet — ein lautlos verschwundener OP-Saal ist genau die
 * Verwechslungsgefahr, gegen die dieser Umbau gebaut wird. Dasselbe gilt fuer die Kacheln (12)
 * und die Geraetezeilen (16) je Saal.
 *
 * ------------------------------------------------------------------------------------------
 * DIE ERNEUERUNGSSPERRE HAENGT AN DER UHR, NICHT AN "ES KAM ETWAS DAZWISCHEN" (Befund C1)
 * ------------------------------------------------------------------------------------------
 * Ein abgelaufener Zugang (auth_revoked) darf GENAU EINMAL ein frisches Token holen; danach gehoert
 * er in den gewoehnlichen Backoff. Hier stand dafuer einmal ein Merker, den jedes gelieferte
 * Ereignis zurueckgesetzt hat. Gegen die ECHTE Datenbank griff er deshalb NIE: die RTDB schickt
 * beim Abonnieren IMMER zuerst ein put mit dem Vollbild und danach Lebenszeichen im Sekundentakt —
 * beide setzten den Merker zurueck, bevor das naechste auth_revoked eintraf.
 *
 * NACHGEMESSEN mit einem Nachbau, der sich wie die RTDB verhaelt (erst put, dann auth_revoked):
 * 177 Verbindungsaufbauten und 177 Tokenerneuerungen in 3001 ms — rund 59 je Sekunde, waehrend der
 * Leser sich selbst als kerngesund meldete (backoffMs 0, fehlerAnzahl 0, keine Fehlerzeile). Jede
 * dieser Erneuerungen ist eine echte Anfrage an DENSELBEN Anmeldeweg, an dem der SCHREIBWEG von
 * cloud.js fuer die Vitalwerte haengt; 59 je Sekunde laufen in die Mengenbegrenzung des Anbieters
 * (HTTP 429), und ab da bekommt auch der Schreibweg kein Token mehr. Damit war die Zusage ganz oben
 * ("ein ausgefallener Nachbar darf die eigene Uebertragung niemals anfassen") auf einem Weg
 * gebrochen, den kein Ereigniszaehler sichtbar machen konnte.
 *
 * DESHALB EIN ZEITSTEMPEL: _letzteErneuerungAm. Eine zweite Erneuerung innerhalb von
 * erneuernSperreMs (Werk 60 s) wird abgelehnt und geht in den gewoehnlichen Backoff. Diese Bremse
 * kann kein Lebenszeichen loesen, weil sie gar nicht danach fragt — sie fragt die Uhr. Damit ist
 * die Anmeldelast dieses Lesers nach oben gedeckelt (hoechstens EINE Tokenanfrage je Sperrfenster),
 * und ein Token, das nach Stunden regulaer ablaeuft, wird trotzdem erneuert: die Sperre ist eine
 * Drossel, kein Verbot. Beides steht als Pruefung in tools/tafelabo-test.js, Block 4 — und der
 * Nachbau dort schickt die Lebenszeichen MIT, genau die haben die alte Fassung unwirksam gemacht.
 *
 * ------------------------------------------------------------------------------------------
 * JEDER SAALSATZ SAGT, OB WIR SELBST BLIND SIND (Befund C3)
 * ------------------------------------------------------------------------------------------
 * Das Alter eines Saals wird aus seinem sv gerechnet — es altert also auch dann weiter, wenn nicht
 * der Saal steht, sondern UNSER Lesestrom abgerissen ist. Ein Nachbarstreifen, der nur saele()
 * rendert, meldete dann "OP 2 offline seit 3 Minuten", waehrend OP 2 einwandfrei laeuft und nur
 * unser WLAN weg ist. Das ist derselbe Schaden wie ein lautlos verschwundener Saal, nur mit
 * umgekehrtem Vorzeichen. Deshalb traegt JEDER Satz aus saele()/nachbarn() zwei zusaetzliche
 * Felder: blind (der eigene Strom steht gerade nicht) und lesestandMs (wie lange der letzte
 * gelieferte Rahmen her ist, null = seit dem Start keiner). Wer eine Stufe 'alt'/'offline' anzeigt,
 * MUSS blind mitlesen — sonst schreibt er einem laufenden OP-Saal einen Ausfall zu, den unser
 * eigener PC hat.
 *
 * ------------------------------------------------------------------------------------------
 * DOPPELTE EIGENE KENNUNG: NUR MELDEN, NIE ENTSCHEIDEN
 * ------------------------------------------------------------------------------------------
 * Liefert der Strom fuer den EIGENEN Tafelknoten eine fremde instanz, geht dieser Wert
 * unveraendert an stationsid.kollisionGemeldet(). Dort und nur dort faellt die Entscheidung, ob
 * das ein Beweis ist (Form, Herkunft, Ausdauer). Hier wird nichts gezaehlt und nichts geglaubt.
 * ENTWARNT WIRD NIE: ein fehlender Wert ist eine Entwarnung, und eine Entwarnung oeffnet die
 * Sperre fuer Patientendaten (stationsid.darfPatientendatenSchreiben). Diese Entscheidung gehoert
 * an den Rueckleseweg von cloud.js, der unmittelbar nach dem EIGENEN Schreibvorgang liest; der
 * Strom liefert einen zwischengespeicherten Stand und koennte die Sperre auf alter Kenntnis
 * oeffnen. Der Leseweg kann die Sperre also nur zuziehen, nie oeffnen — die sichere Richtung.
 *
 * KEIN ZUGRIFF auf registry, matching oder einen Adapter: fremde Daten duerfen den eigenen
 * Messweg nicht erreichen. tools/tafelabo-test.js prueft das an der Quelldatei.
 */
const http = require('http');
const https = require('https');
const tafel = require('./tafel');

/*
 * EIGENE VERBINDUNGSVERWALTUNG (im Plan: AGENT_LESEN). keepAlive ist AUS: ein Stromende ist hier
 * der Normalfall (Umleitung, Tokenwechsel, Abriss), und eine im Vorrat gehaltene tote Verbindung
 * kostet beim naechsten Versuch eine Zeitueberschreitung statt einer sauberen Neuverbindung.
 * maxSockets 2 statt 1, damit ein noch nicht abgeraeumter Vorgaenger den Nachfolger nicht
 * blockiert.
 */
const AGENT_LESEN_HTTPS = new https.Agent({ keepAlive: false, maxSockets: 2 });
const AGENT_LESEN_HTTP = new http.Agent({ keepAlive: false, maxSockets: 2 });

const BACKOFF_START_MS = 2000;      // erste Wartezeit nach einem Lesefehler
const BACKOFF_MAX_MS = 60000;       // Obergrenze; darueber wird nicht mehr verdoppelt
const ANLAUF_MS = 2000;             // "noch nicht angemeldet" ist kein Fehler, nur zu frueh
const VERBINDUNGS_FRIST_MS = 15000; // bis die Antwortkopfzeilen da sein muessen
const STILLE_MAX_MS = 90000;        // ohne jedes Ereignis (auch ohne keep-alive) gilt der Strom als tot
const RAHMEN_MAX = 1024 * 1024;     // ein einzelner SSE-Rahmen; darueber wird die Verbindung verworfen
const UMLEITUNGEN_MAX = 3;
const VERSATZ_PROBEN = 10;          // Fenster fuer den Median des Uhrenversatzes
const MELDE_TAKT_MS = 60000;        // hoechstens eine gleichartige Logzeile je Minute
const ROH_SAELE_MAX = 64;           // Speichergrenze fuer den Rohbaum (der Deckel der ANZEIGE ist 8)
const KINDER_MAX = 200;             // Speichergrenze fuer die Kinder EINES Knotens im Rohbaum
const VERDRAENGT_LISTE_MAX = 8;     // so viele verdraengte Kennungen werden NAMENTLICH gefuehrt

/*
 * Fruehestens so spaet darf ein zweites Mal ein frisches Token geholt werden (Befund C1).
 *
 * 60 s liegen weit unter jeder regulaeren Tokenlaufzeit (Google gibt eine Stunde), eine ECHTE
 * Erneuerung wird also nie verhindert. Nach oben deckelt der Wert die Anmeldelast dieses Lesers auf
 * hoechstens eine Tokenanfrage je Minute — auch dann, wenn die Gegenseite den Zugang im Sekundentakt
 * entzieht. Die Begruendung in voller Laenge steht im Kopfkommentar.
 */
const ERNEUERN_SPERRE_MS = 60000;

/*
 * Segmentnamen, die niemals in einen Objektpfad geschrieben werden duerfen.
 *
 * Datenbankschluessel duerfen '__proto__' heissen. Ein cur['__proto__'] ist aber kein Kind,
 * sondern der PROTOTYP: das Absteigen auf diesen Namen landet bei Object.prototype, und der
 * naechste Schreibvorgang haengt das Feld an JEDES Objekt dieses Prozesses. Nachgemessen in
 * tools/tafelabo-test.js — mit einem Ereignis auf '/<sid>/__proto__/kaputt' trug danach jedes
 * frische {} ein Feld 'kaputt'.
 *
 * ALS LISTE, NICHT ALS OBJEKT: in einem Objektliteral ist '__proto__: 1' kein Feld, sondern eine
 * Zuweisung an den Prototyp — die Sperre haette genau den Namen nicht enthalten, gegen den sie
 * gebaut ist. Auch das stand hier schon einmal falsch und ist nur durch den Test aufgefallen.
 */
const VERBOTENE_SEGMENTE = ['__proto__', 'constructor', 'prototype'];

// ---------------------------------------------------------------- reine Bausteine

/*
 * pfadTeile('/st.../meta') -> ['st...','meta'];  pfadTeile('/') -> [].
 * Leere Teile fallen weg, damit '//a' und '/a' dasselbe bedeuten (die Datenbank schickt beides
 * nicht, aber ein Zwischenspeicher oder ein Test darf uns damit nicht in ein '' -Kind schreiben).
 */
function pfadTeile(pfad) {
  return String(pfad == null ? '' : pfad).split('/').filter((s) => s !== '');
}

/*
 * mittlererVersatz(liste) — Median, NICHT Mittelwert.
 *
 * Jede Antwort liefert eine Messung; eine einzelne davon kann durch eine langsame Zwischenstelle
 * um Sekunden danebenliegen. Ein Mittelwert traegt so einen Ausreisser dauerhaft mit, der Median
 * wirft ihn weg. Bei gerader Anzahl wird zwischen den beiden mittleren Werten gerundet.
 */
function mittlererVersatz(liste) {
  const l = (liste || []).filter((x) => Number.isFinite(x)).sort((a, b) => a - b);
  if (!l.length) return 0;
  const m = Math.floor(l.length / 2);
  return l.length % 2 ? l[m] : Math.round((l[m - 1] + l[m]) / 2);
}

/*
 * saeubere(wert) — was aus einem FREMDEN Saal auf den eigenen Bildschirm darf.
 *
 * Unterschied zu tafel.kappe(): dort wird nur begrenzt, hier wird auch GEFILTERT. tafel.kappe()
 * behandelt die EIGENEN Daten — ein Alarmtext des eigenen Geraets ist ein Dokument, aus dem man
 * keine Zeichen entfernt. Hier kommen die Daten von einem anderen Rechner; wer ein Geraet ins
 * Gast-WLAN haengt, kann einen Patientennamen frei setzen, und der landet ueber den
 * Nachbarstreifen auf einem Bildschirm neben einer laufenden Narkose. tafel.text() nimmt
 * < > & " ' \ ` und alle Steuerzeichen heraus und kuerzt auf 40 Zeichen.
 *
 * TYPEN WERDEN NICHT UMGEWANDELT. Der Plantext sagt "Zahlen durch Number()"; das ist hier bereits
 * erfuellt, weil JSON.parse Zahlen als Zahlen liefert und JSON weder NaN noch Unendlich kennt.
 * Eine Zeichenkette "96" zusaetzlich in eine Zahl zu verwandeln waere das Gegenteil einer
 * Kappung: sie behauptete einen Messwert, wo nur ein Text steht.
 *
 * ------------------------------------------------------------------------------------------
 * EIN SAUBERER NAME DARF NIE EINEN FREMDEN WERT TRAGEN (Befund C2)
 * ------------------------------------------------------------------------------------------
 * tafel.text() entfernt < > & " ' \ ` und alle Steuerzeichen und faltet Leerraum — ZWEI
 * verschiedene Datenbankschluessel koennen danach denselben Namen tragen ('hr<' und 'hr' werden
 * beide zu 'hr'). Weil die Namen vorher sortiert werden, kam der verstuemmelte Schluessel ZULETZT
 * und ueberschrieb den sauberen: NACHGEMESSEN ergab saeubere({'hr<':250, hr:96}) genau {"hr":250}.
 * Auf eine Kachel uebertragen heisst das ein Wert am falschen Platz — der Nachbarstreifen zeigte
 * fuer das Tier im anderen Saal eine Herzfrequenz von 250 statt 96, ohne jede Kennzeichnung. Und
 * ausgerechnet saeubere() ist die Abwehr, die fremde Daten harmlos machen soll.
 * DESHALB: der erste (sortierte) Name gewinnt, jede Kollision wird GEZAEHLT und gemeldet. Ein
 * zweiter Schreiber im Praxiskonto (Privathandy, Tablet am Empfang, kopierte data/cloud-auth.json —
 * alle drei sind im Plan als getragene Restrisiken benannt) kann damit einen Messwert nicht mehr
 * unter den Namen eines anderen schieben.
 *
 * VERBOTENE NAMEN FALLEN GANZ HERAUS (Befund C4). '__proto__' ist ein erlaubter Datenbank-
 * schluessel; ein out['__proto__'] = ... ist aber keine Zuweisung, sondern ein Prototypenwechsel.
 * NACHGEMESSEN: das Ergebnis sah fuer JSON.stringify und Object.keys aus wie {"n":"Bello"}, trug
 * aber ein Feld, das nur ueber den Prototyp sichtbar war — Bildschirm und Fehlerbericht
 * widersprachen sich, und genau so ein Widerspruch kostet waehrend einer Narkose Zeit. Object.
 * create(null) haette das Feld nur sichtbar gemacht und die Falle an den naechsten Object.assign()
 * weitergereicht; deshalb wird der Name verworfen und gezaehlt, wie es _setze() fuer Pfadsegmente
 * schon tut. GEPRUEFT WIRD DER GESAEUBERTE NAME, nicht der rohe: '__proto__<' faellt sonst durch
 * tafel.text() hindurch und heisst danach wieder '__proto__'.
 *
 * zaehler ist ein OPTIONALER Zaehlerbeutel {namensKollision, verbotenerName}. Die Funktion bleibt
 * rein — sie meldet nichts und wirft nichts; wer die Zahlen braucht, reicht das Objekt herein und
 * liest es danach (Tafelabo.saele() tut das und meldet sie ins Log).
 */
function saeubere(wert, tiefe, zaehler) {
  const t = tiefe == null ? 0 : tiefe;
  if (wert === null || wert === undefined) return null;
  const typ = typeof wert;
  if (typ === 'number') return Number.isFinite(wert) ? wert : null;
  if (typ === 'boolean') return wert;
  if (typ === 'string') return tafel.text(wert, tafel.GRENZEN.tafelText);
  if (typ !== 'object') return null;                    // Funktionen kommen aus JSON nie, aber sicher ist sicher
  if (t >= tafel.GRENZEN.tiefe) return null;
  if (Array.isArray(wert)) {
    const out = [];
    for (let i = 0; i < wert.length && out.length < tafel.GRENZEN.liste; i++) out.push(saeubere(wert[i], t + 1, zaehler));
    return out;
  }
  const out = {};
  const namen = Object.keys(wert).sort();               // sortiert: bei einem gekappten Objekt darf nicht
  for (let i = 0; i < namen.length && i < tafel.GRENZEN.felder; i++) {   // die Reihenfolge der Datenbank entscheiden,
    const n = tafel.text(namen[i], tafel.GRENZEN.tafelText);             // WELCHE 40 Felder ueberleben
    if (!n) continue;
    if (VERBOTENE_SEGMENTE.indexOf(n) >= 0) { zaehle(zaehler, 'verbotenerName'); continue; }
    if (Object.prototype.hasOwnProperty.call(out, n)) { zaehle(zaehler, 'namensKollision'); continue; }
    out[n] = saeubere(wert[namen[i]], t + 1, zaehler);
  }
  return out;
}

/* Ein Zaehlerbeutel ist freiwillig: fehlt er, wird nur nicht gezaehlt. Nie werfen — saeubere()
 * laeuft auf FREMDEN Daten, und eine Ausnahme dort riesse den ganzen Nachbarstreifen mit. */
function zaehle(beutel, feld) {
  if (beutel && typeof beutel === 'object') beutel[feld] = (Number(beutel[feld]) || 0) + 1;
}

/*
 * kopfAus/svAus — WORTGLEICH zu den gleichnamigen Hilfen in tafel.js.
 *
 * Sie stehen dort absichtlich nicht im Export (sie sind Innenleben der Tafel). Nachgebaut statt
 * ausgeliehen wird hier nur diese eine Zeile Bedeutung: "der Kopf liegt unter meta, oder der
 * Eintrag IST der Kopf" und "die Serverzeit sv gilt, ts ist nur Rueckfall". Damit die beiden
 * Fassungen nicht auseinanderlaufen koennen, haelt tools/tafelabo-test.js die Saalliste dieser
 * Datei gegen tafel.frischeSaele() — Reihenfolge, Namen und Alter muessen uebereinstimmen.
 */
function kopfAus(eintrag) {
  const e = eintrag || {};
  return (e.meta && typeof e.meta === 'object' && !Array.isArray(e.meta)) ? e.meta : e;
}
function svAus(kopf) {
  if (kopf.sv != null && typeof kopf.sv !== 'object') return kopf.sv;
  return kopf.ts != null ? kopf.ts : null;
}

/*
 * sortiereSaele — dieselbe Regel wie in tafel.js: erst Name, dann Kennung.
 *
 * tafel.js warnt ausdruecklich davor, eine zweite Sortierregel an einer zweiten Stelle zu fuehren.
 * Sie steht hier trotzdem, weil tafel.frischeSaele() nur FRISCHE Saele liefert (unter 60 s) —
 * ein Leser, der einen Saal nach 60 s Stille aus der Liste wirft, laesst einen ausgefallenen
 * OP-Saal lautlos verschwinden, statt ihn als "offline" zu zeigen. Gegen das Auseinanderlaufen
 * steht der Vertragstest in tools/tafelabo-test.js.
 */
function sortiereSaele(liste) {
  return liste.sort((a, b) => {
    const an = a.name || '', bn = b.name || '';
    if (an < bn) return -1;
    if (an > bn) return 1;
    if (a.sid < b.sid) return -1;
    if (a.sid > b.sid) return 1;
    return 0;
  });
}

/*
 * Rahmenleser — der Zeilenleser fuer den Ereignisstrom.
 *
 * Ein SSE-Rahmen ist eine Folge von Zeilen "feld: wert" und endet an einer LEEREN Zeile. Ein
 * Chunk aus dem Netz enthaelt beliebige Bruchstuecke davon — ein halber Rahmen, drei Rahmen, ein
 * halbes Zeichen. Deshalb ein Puffer, der nur an '\n' schneidet.
 *
 * DER PUFFER IST GEDECKELT (RAHMEN_MAX). Eine Gegenstelle, die ein Byte je Sekunde ohne Zeilenende
 * schickt, waere sonst ein langsam wachsender Speicherfresser auf dem OP-PC. Bei Ueberlauf wird
 * nicht geraten, sondern die Verbindung verworfen und neu aufgebaut.
 */
class Rahmenleser {
  constructor(aufRahmen, max) {
    this._aufRahmen = aufRahmen;
    this._max = max || RAHMEN_MAX;
    this._puffer = '';
    this._event = null;
    this._daten = [];
    this.ueberlauf = false;
  }
  schub(text) {
    if (this.ueberlauf) return;
    this._puffer += text;
    if (this._puffer.length > this._max) { this.ueberlauf = true; this._puffer = ''; this._daten = []; return; }
    let i;
    while ((i = this._puffer.indexOf('\n')) >= 0) {
      const zeile = this._puffer.slice(0, i).replace(/\r$/, '');
      this._puffer = this._puffer.slice(i + 1);
      this._zeile(zeile);
      if (this.ueberlauf) return;
    }
  }
  _zeile(z) {
    if (z === '') {                                  // leere Zeile = Rahmenende
      if (this._event === null && !this._daten.length) return;
      const ev = this._event, daten = this._daten.join('\n');
      this._event = null; this._daten = [];
      this._aufRahmen(ev, daten);
      return;
    }
    const p = z.indexOf(':');
    const feld = p < 0 ? z : z.slice(0, p);
    let wert = p < 0 ? '' : z.slice(p + 1);
    if (wert.charAt(0) === ' ') wert = wert.slice(1);   // genau EIN fuehrendes Leerzeichen gehoert zum Format
    if (feld === 'event') this._event = wert;
    else if (feld === 'data') this._daten.push(wert);
    // 'id', 'retry' und Kommentarzeilen (':...' -> feld '') braucht dieser Strom nicht
  }
}

// ---------------------------------------------------------------- der Leser

class Tafelabo {
  /*
   * Optionen — alles, was von aussen kommt, kommt als Naht herein, damit der Test ohne Netz,
   * ohne Anmeldung und ohne Warten laufen kann:
   *   dbUrl      Wurzel der Datenbank (wie cloud.cfg.dbUrl)
   *   uid        Kontokennung, Wert ODER Funktion (sie steht erst nach der Anmeldung fest)
   *   sid        eigene Stationskennung, Wert ODER Funktion; ohne Angabe aus stationsid.sid()
   *   token      async (erneuern) => idToken. Bei erneuern === true MUSS ein frischer geholt werden.
   *   stationsid Objekt mit kollisionGemeldet(); NUR diese eine Funktion wird benutzt.
   *   log        info/warn/error
   *   jetzt      lokale Uhr (Vorgabe Date.now)
   *   versatzMs  Funktion, die einen anderswo gemessenen Uhrenversatz liefert (Rueckfall)
   */
  constructor(opts) {
    const o = opts || {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    this.dbUrl = String(o.dbUrl || '').replace(/\/+$/, '');
    this._uidQuelle = o.uid;
    this._sidQuelle = o.sid;
    this.stationsid = o.stationsid || null;
    this._token = typeof o.token === 'function' ? o.token : null;
    this._uhr = typeof o.jetzt === 'function' ? o.jetzt : Date.now;
    this._versatzAussen = typeof o.versatzMs === 'function' ? o.versatzMs : null;

    // Takte und Deckel sind einstellbar, damit der Test nicht 60 s auf einen Backoff wartet.
    this.deckel = Math.max(1, Number(o.deckel) || tafel.GRENZEN.saele);
    this.backoffStartMs = Math.max(1, Number(o.backoffStartMs) || BACKOFF_START_MS);
    this.backoffMaxMs = Math.max(this.backoffStartMs, Number(o.backoffMaxMs) || BACKOFF_MAX_MS);
    this.stilleMaxMs = Math.max(100, Number(o.stilleMaxMs) || STILLE_MAX_MS);
    this.verbindungsFristMs = Math.max(100, Number(o.verbindungsFristMs) || VERBINDUNGS_FRIST_MS);
    this.rahmenMax = Math.max(1024, Number(o.rahmenMax) || RAHMEN_MAX);
    /* Auch die Erneuerungssperre ist einstellbar — nicht der Bequemlichkeit wegen: ein Test, der
     * 60 s auf ein Sperrfenster wartet, wird irgendwann herausgenommen, und dann prueft NIEMAND
     * mehr die eine Zahl, die die Anmeldelast dieses Lesers deckelt (Befund C1). */
    this.erneuernSperreMs = Math.max(1, Number(o.erneuernSperreMs) || ERNEUERN_SPERRE_MS);

    this._roh = {};                 // sid -> Saalknoten, wie die Datenbank ihn liefert
    this._gestoppt = true;
    this._req = null;
    this._res = null;
    this._leser = null;
    this._timer = null;
    this._stilleTimer = null;
    this._verbunden = false;
    this._verbundenSeit = 0;
    this._backoffMs = 0;
    this._naechsterVersuch = 0;
    /* Zeitpunkt der letzten Tokenerneuerung auf der PC-UHR (0 = noch keine). Absichtlich KEIN
     * Merker "schon erneuert": ein Merker muss irgendwann zurueckgesetzt werden, und jede Stelle,
     * die das tut, ist eine Stelle, an der ein Lebenszeichen die Bremse loesen kann — genau daran
     * ist die alte Fassung gescheitert (Befund C1). Ein Zeitstempel braucht kein Zuruecksetzen. */
    this._letzteErneuerungAm = 0;
    this._letzterRahmenAm = 0;      // wann kam zuletzt IRGENDEIN Rahmen? (auch keep-alive) — Befund C3
    this._versaetze = [];
    this._fehler = null;
    this._fehlerAnzahl = 0;
    this._gemeldet = Object.create(null);   // Schluesselwort -> {text, am} fuer die Drossel (Befund C6)
    this._deckelGemeldet = { anzahl: -1, am: 0 };
    this._zaehler = {
      verbindungen: 0, umleitungen: 0, put: 0, patch: 0, keepAlive: 0,
      authRevoked: 0, cancel: 0, unbekannt: 0, bytes: 0, instanzMeldungen: 0,
      tokenErneuert: 0, erneuernAbgelehnt: 0,
    };
    this._verworfen = {
      fremdeSchluessel: 0, zuVieleSaele: 0, zuTief: 0, zuVieleKinder: 0,
      verboteneSegmente: 0, ueberlauf: 0, ohneInstanz: 0, zuAlt: 0, ueberDeckel: 0,
      verdraengt: 0, namensKollision: 0, verbotenerName: 0,
    };
    this._weitere = [];             // Saele oberhalb des Deckels: {sid,name} — gezaehlt, nie still
    this._verdraengt = [];          // aus dem ROHBAUM gewichene Saele: {sid,name} — ebenfalls nie still
  }

  // ------------------------------------------------------------ Ein und Aus
  start() {
    if (!this._gestoppt) return;
    this._gestoppt = false;
    this._verbinde(false);
  }

  /* stop() muss jeden Zeitgeber und die Verbindung wirklich loswerden — sonst haelt ein Leser den
   * Prozess am Leben, den index.js gerade ordentlich beenden will. */
  stop() {
    this._gestoppt = true;
    this._timerWeg();
    this._verbindungWeg();
  }

  laeuft() { return !this._gestoppt; }

  // ------------------------------------------------------------ Zeit
  /* Die Serverzeit: PC-Uhr plus gemessener Versatz. JEDE Altersrechnung geht hier durch. */
  jetzt() { return this._uhr() + this.versatzMs(); }

  versatzMs() {
    if (this._versaetze.length) return mittlererVersatz(this._versaetze);
    if (this._versatzAussen) {
      try { const v = Number(this._versatzAussen()); if (Number.isFinite(v)) return v; } catch (_) { /* fremde Quelle darf nie werfen */ }
    }
    return 0;
  }

  zeitQuelle() {
    if (this._versaetze.length) return 'gemessen';
    if (this._versatzAussen) return 'uebernommen';
    return 'lokal';
  }

  _versatzMerken(dateKopf) {
    if (!dateKopf) return;
    const t = Date.parse(dateKopf);
    if (!Number.isFinite(t)) return;
    const versatz = t - this._uhr();
    /* Mehr als 12 h sind kein Gangunterschied, sondern eine kaputte Kopfzeile oder eine
     * Zwischenstelle mit eigener Uhr. Dann lieber die eigene Uhr behalten — dieselbe Grenze wie
     * in cloud.js, damit nicht zwei Stellen dasselbe verschieden entscheiden. */
    if (Math.abs(versatz) > tafel.UHR_TOLERANZ_MS) {
      this._melde('warn', 'uhr', 'Die Date-Kopfzeile der Datenbank weicht um mehr als 12 Stunden '
        + 'von der Uhr dieses PCs ab. Der Wert wird NICHT uebernommen — bitte die Uhrzeit des '
        + 'Praxis-PCs richtig stellen, sonst ist das Alter fremder OP-Saele nicht berechenbar.');
      return;
    }
    this._versaetze.push(versatz);
    if (this._versaetze.length > VERSATZ_PROBEN) this._versaetze.shift();
  }

  // ------------------------------------------------------------ Verbindung
  _uid() {
    const q = this._uidQuelle;
    const v = typeof q === 'function' ? q() : q;
    return v ? String(v) : null;
  }

  _sid() {
    const q = this._sidQuelle;
    let v = typeof q === 'function' ? q() : q;
    if (!v && this.stationsid && typeof this.stationsid.sid === 'function') v = this.stationsid.sid();
    return v ? String(v) : null;
  }

  async _verbinde(erneuern) {
    if (this._gestoppt || this._req) return;
    const uid = this._uid();
    if (!uid) return this._spaeter('Fern-Live ist noch nicht angemeldet — der Tafel-Strom wartet.');
    if (!this.dbUrl) return this._spaeter('Fern-Live: dbUrl fehlt — der Tafel-Strom wartet.');
    if (!this._token) return this._spaeter('Kein Weg zu einem Zugangstoken — der Tafel-Strom wartet.');

    let tok;
    try {
      tok = await this._token(!!erneuern);
    } catch (e) {
      return this._leseFehler('Zugangstoken nicht zu bekommen: ' + fehlertext(e));
    }
    if (this._gestoppt || this._req) return;
    if (!tok) return this._spaeter('Noch kein Zugangstoken — der Tafel-Strom wartet.');

    const url = this.dbUrl + '/live/' + encodeURIComponent(uid) + '/tafel.json?auth='
      + encodeURIComponent(tok);
    this._anfrage(url, 0);
  }

  _anfrage(urlText, hops) {
    let u;
    try { u = new URL(urlText); } catch (e) { return this._leseFehler('Adresse ungueltig: ' + fehlertext(e)); }
    const istHttp = u.protocol === 'http:';
    if (!istHttp && u.protocol !== 'https:') return this._leseFehler('Adresse ohne http/https: ' + u.protocol);
    const lib = istHttp ? http : https;

    const req = lib.request({
      method: 'GET',
      hostname: u.hostname,
      port: u.port || (istHttp ? 80 : 443),
      path: u.pathname + u.search,
      headers: { Accept: 'text/event-stream', 'Cache-Control': 'no-cache' },
      agent: istHttp ? AGENT_LESEN_HTTP : AGENT_LESEN_HTTPS,
    }, (res) => {
      // Ab hier gilt die Stille-Ueberwachung, nicht mehr die Frist fuer den Verbindungsaufbau:
      // ein Strom DARF beliebig lange offen stehen, er muss nur Lebenszeichen senden.
      try { req.setTimeout(0); } catch (_) { /* aeltere Node-Fassungen */ }
      /* Der Aufschlag JEDER Verbindung, noch VOR der Verzweigung nach dem Statuscode (Befund C7):
       * so zaehlen auch die 307 und die Fehlerantworten mit — und genau die sind der Verbrauch,
       * wenn eine stoerende Zwischenstelle den Leser im Sekundentakt neu verbinden laesst. */
      this._zaehler.bytes += kopfBytes(res);
      this._versatzMerken(res.headers && res.headers.date);
      const code = res.statusCode || 0;

      if (code === 301 || code === 302 || code === 303 || code === 307 || code === 308) {
        res.on('data', (c) => { this._zaehler.bytes += stueckBytes(c); });
        res.resume();
        this._req = null;
        const ziel = res.headers && res.headers.location;
        if (!ziel) return this._leseFehler('Umleitung ohne Ziel (HTTP ' + code + ')');
        if (hops >= UMLEITUNGEN_MAX) return this._leseFehler('Zu viele Umleitungen (' + hops + ')');
        let neu;
        try { neu = new URL(ziel, urlText); } catch (e) { return this._leseFehler('Umleitungsziel ungueltig: ' + fehlertext(e)); }
        if (!gleicheDomaene(u.hostname, neu.hostname)) {
          return this._leseFehler('Umleitung auf eine fremde Domaene abgelehnt: ' + neu.hostname
            + ' (der Zugangsschluessel steht in der Adresse und bleibt bei ' + u.hostname + ')');
        }
        this._zaehler.umleitungen++;
        return this._anfrage(neu.toString(), hops + 1);
      }

      if (code < 200 || code >= 300) {
        let rumpf = '';
        res.on('data', (c) => { this._zaehler.bytes += stueckBytes(c); if (rumpf.length < 400) rumpf += c; });
        res.on('end', () => {
          this._req = null;
          this._leseFehler('HTTP ' + code + ': ' + String(rumpf).slice(0, 200));
        });
        res.on('error', () => { this._req = null; this._leseFehler('HTTP ' + code); });
        return undefined;
      }

      this._res = res;
      this._verbunden = true;
      this._verbundenSeit = this._uhr();
      this._zaehler.verbindungen++;
      this._leser = new Rahmenleser((ev, daten) => this._rahmen(ev, daten), this.rahmenMax);
      this._stilleNeu();
      res.setEncoding('utf8');
      res.on('data', (c) => {
        /* Der Leser wird waehrend dieses Rueckrufs abgeraeumt, wenn ein Rahmen darin die
         * Verbindung beendet (auth_revoked, cancel, Ueberlauf). Deshalb wird er hier EINMAL
         * festgehalten und danach geprueft, ob er noch der aktuelle ist — sonst greift der
         * naechste Chunk auf ein null zu, und der ganze Leser stirbt an genau dem Ereignis, das
         * er behandeln soll. */
        const leser = this._leser;
        if (!leser) return;
        this._zaehler.bytes += Buffer.byteLength(c, 'utf8');
        this._stilleNeu();
        leser.schub(c);
        if (leser.ueberlauf && this._leser === leser) {
          this._verworfen.ueberlauf++;
          this._abbruch('Ein einzelner Rahmen war groesser als ' + this.rahmenMax + ' Byte');
        }
      });
      res.on('end', () => this._abbruch('Der Strom wurde von der Gegenseite beendet'));
      res.on('close', () => this._abbruch('Die Verbindung wurde geschlossen'));
      res.on('error', (e) => this._abbruch('Fehler im Strom: ' + fehlertext(e)));
      return undefined;
    });

    this._req = req;
    req.setTimeout(this.verbindungsFristMs, () => {
      req.destroy(new Error('Zeitueberschreitung beim Verbindungsaufbau'));
    });
    req.on('error', (e) => {
      if (this._res) return;                     // der Strom lief schon: das behandelt _abbruch
      this._req = null;
      this._leseFehler('Verbindung fehlgeschlagen: ' + fehlertext(e));
    });
    req.end();
  }

  /* Ein Abriss ist kein Sonderfall, sondern der Normalfall eines Dauerstroms (Router, WLAN,
   * Serverwechsel). Er wird EINMAL behandelt, egal ob 'end', 'close' oder 'error' zuerst kommt. */
  _abbruch(grund) {
    if (!this._verbunden && !this._res) return;
    this._verbindungWeg();
    if (this._gestoppt) return;
    this._leseFehler(grund);
  }

  _verbindungWeg() {
    this._verbunden = false;
    if (this._stilleTimer) { clearTimeout(this._stilleTimer); this._stilleTimer = null; }
    const res = this._res, req = this._req;
    this._res = null; this._req = null; this._leser = null;
    if (res) { try { res.removeAllListeners(); res.destroy(); } catch (_) { /* schon zu */ } }
    if (req) { try { req.destroy(); } catch (_) { /* schon zu */ } }
  }

  _stilleNeu() {
    if (this._stilleTimer) clearTimeout(this._stilleTimer);
    this._stilleTimer = setTimeout(() => {
      this._abbruch('Seit ' + Math.round(this.stilleMaxMs / 1000) + ' s kam kein Lebenszeichen');
    }, this.stilleMaxMs);
    if (this._stilleTimer.unref) this._stilleTimer.unref();
  }

  _timerWeg() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (this._stilleTimer) { clearTimeout(this._stilleTimer); this._stilleTimer = null; }
  }

  _planen(ms, erneuern) {
    if (this._gestoppt) return;
    if (this._timer) clearTimeout(this._timer);
    this._timer = setTimeout(() => { this._timer = null; this._verbinde(!!erneuern); }, ms);
    if (this._timer.unref) this._timer.unref();
  }

  /*
   * DER EIGENE FEHLERWEG. Er zaehlt in _fehlerAnzahl, verdoppelt _backoffMs bis BACKOFF_MAX_MS und
   * endet in einem neuen Versuch. Was er NICHT tut: irgendetwas am Schreibweg anfassen. Es gibt
   * hier keinen Zugriff darauf, und es darf auch nie einer entstehen — ein ausgefallener Nachbar
   * ist kein Grund, die eigene Ueberwachung abzuschalten.
   */
  _leseFehler(grund) {
    this._fehler = grund;
    this._fehlerAnzahl++;
    this._backoffMs = this._backoffMs ? Math.min(this._backoffMs * 2, this.backoffMaxMs) : this.backoffStartMs;
    this._naechsterVersuch = this._uhr() + this._backoffMs;
    this._melde('warn', 'fehler', 'Der Tafel-Strom der Nachbarsaele ist unterbrochen: ' + grund
      + ' — neuer Versuch in ' + Math.round(this._backoffMs / 1000) + ' s. Die eigene '
      + 'Uebertragung ist davon nicht betroffen.');
    this._planen(this._backoffMs, false);
  }

  /* "Noch nicht angemeldet" ist KEIN Fehler: es wird nichts gezaehlt und nichts verdoppelt,
   * sonst stuende der Leser nach ein paar Minuten Anmeldezeit auf 60 s Wartezeit. */
  _spaeter(grund) {
    this._melde('info', 'wartet', grund);
    this._planen(ANLAUF_MS, false);
  }

  /*
   * Erfolg: der Strom hat wirklich geliefert. ERST HIER wird der Backoff zurueckgesetzt — nicht
   * schon beim Verbindungsaufbau. Eine Gegenstelle, die annimmt und sofort auflegt, ergaebe sonst
   * eine Schleife ohne jede Wartezeit.
   *
   * WAS HIER AUSDRUECKLICH NICHT MEHR PASSIERT (Befund C1): die Erneuerungssperre fuer das Token
   * wird NICHT angefasst. Sie stand frueher hier als Merker — und weil die Datenbank beim
   * Abonnieren zuerst ein Vollbild und danach im Sekundentakt Lebenszeichen schickt, lief diese
   * Zeile vor JEDEM auth_revoked, das im Feld eintreffen kann. Die Bremse war damit gegen die echte
   * Gegenstelle wirkungslos (gemessen: 59 Tokenerneuerungen je Sekunde). Wer sie hier wieder
   * einbaut, baut genau diesen Fehler wieder ein; die Sperre haengt jetzt allein an der Uhr.
   */
  _lebenszeichen() {
    if (this._backoffMs) {
      this.log.info('nachbarn', 'Der Tafel-Strom der Nachbarsaele laeuft wieder.');
    }
    this._backoffMs = 0;
    this._naechsterVersuch = 0;
    this._fehler = null;
  }

  // ------------------------------------------------------------ Ereignisse
  _rahmen(event, daten) {
    /* Ein Netzpaket kann mehrere Rahmen tragen. Hat einer davon die Verbindung beendet (Entzug,
     * Absage), sind die folgenden Rahmen derselben Lieferung nicht mehr zustaendig — sonst wuerde
     * ein zweiter Entzug im selben Paket die Tokenerneuerung ein zweites Mal anstossen. */
    if (!this._verbunden) return;
    /* Der Lesestand (Befund C3): JEDER Rahmen zaehlt, auch ein keep-alive — er ist der Beweis, dass
     * der Strom noch steht. Aus diesem Zeitpunkt entsteht das Feld, mit dem ein Nachbarstreifen
     * unseren eigenen Ausfall von dem des Nachbarn unterscheiden kann. */
    this._letzterRahmenAm = this._uhr();
    if (event === 'keep-alive') { this._zaehler.keepAlive++; this._lebenszeichen(); return; }

    if (event === 'auth_revoked') {
      this._zaehler.authRevoked++;
      /*
       * EINMAL erneuern, dann in den gewoehnlichen Backoff — und "einmal" heisst: einmal je
       * erneuernSperreMs, gemessen an der UHR. Nicht "einmal, bis irgendein Ereignis dazwischenkam":
       * die Datenbank schickt beim Abonnieren zuerst ein Vollbild und danach Lebenszeichen im
       * Sekundentakt, ein solcher Merker stuende also bei jedem echten auth_revoked schon wieder
       * offen (Befund C1, gemessen: 59 Erneuerungen je Sekunde). Die Anmeldelast trifft DENSELBEN
       * Weg, an dem der Schreibweg von cloud.js fuer die Vitalwerte haengt — ein ausgefallener
       * Nachbar darf die eigene Uebertragung nicht anfassen, auch nicht ueber die Anmeldung.
       */
      /* Gemessen wird an der ROHEN PC-Uhr (_uhr), nicht an der serverkorrigierten jetzt(): hier
       * geht es um eine oertliche Dauer zwischen zwei eigenen Handlungen. Der Uhrenversatz ist ein
       * gleitender Median, der sich mit jeder Antwort verschiebt — er gehoert in die Altersrechnung
       * fremder Saele und nicht in eine Sperrfrist, die dadurch springen wuerde. */
      const jetzt = this._uhr();
      const seit = jetzt - this._letzteErneuerungAm;
      if (this._letzteErneuerungAm && seit < this.erneuernSperreMs) {
        /* Springt die PC-Uhr rueckwaerts (NTP korrigiert eine falsch gestellte Uhr), waere die
         * Sperre sonst stundenlang zu und der Nachbarstreifen so lange leer. Deshalb wandert der
         * Anker in diesem Fall auf JETZT: gesperrt bleibt hoechstens ein Fenster. */
        if (seit < 0) this._letzteErneuerungAm = jetzt;
        this._zaehler.erneuernAbgelehnt++;
        this._verbindungWeg();
        return this._leseFehler('Der Zugang wurde erneut entzogen, obwohl das Token vor '
          + Math.max(0, Math.round(seit / 1000)) + ' s erneuert wurde — es wird fruehestens in '
          + Math.round(this.erneuernSperreMs / 1000) + ' s wieder eines geholt. Bitte im '
          + 'Admin-Bereich unter "Fern-Live" die Anmeldung pruefen.');
      }
      this._letzteErneuerungAm = jetzt;
      this._zaehler.tokenErneuert++;
      this._verbindungWeg();
      this.log.info('nachbarn', 'Der Zugang zum Tafel-Strom ist abgelaufen — das Token wird einmal '
        + 'erneuert und die Verbindung neu aufgebaut.');
      this._planen(0, true);
      return;
    }

    if (event === 'cancel') {
      /* Die Datenbank hat den Strom abgesagt — das ist ein RECHTEproblem und heilt nicht in zwei
       * Sekunden. Deshalb sofort die lange Wartezeit, statt im Sekundentakt nach einer Absage zu
       * fragen. Auch das bleibt ausschliesslich der Leseweg. */
      this._zaehler.cancel++;
      this._verbindungWeg();
      this._backoffMs = this.backoffMaxMs;
      this._fehler = 'Die Datenbank hat den Tafel-Strom abgesagt (cancel)';
      this._fehlerAnzahl++;
      this._naechsterVersuch = this._uhr() + this._backoffMs;
      this._melde('warn', 'cancel', 'Die Datenbank hat den Tafel-Strom abgesagt — die Nachbarsaele '
        + 'bleiben leer. Meist fehlt das Leserecht auf /live/<Konto>/tafel in den '
        + 'Sicherheitsregeln. Die eigene Uebertragung ist davon nicht betroffen.');
      this._planen(this._backoffMs, false);
      return;
    }

    if (event !== 'put' && event !== 'patch') {
      this._zaehler.unbekannt++;
      this._lebenszeichen();
      return;
    }

    let j;
    try { j = JSON.parse(daten); } catch (e) {
      this._zaehler.unbekannt++;
      this._melde('warn', 'json', 'Ein Ereignis des Tafel-Stroms war kein gueltiges JSON und wurde '
        + 'uebergangen: ' + fehlertext(e));
      return;
    }
    this._lebenszeichen();
    if (!j || typeof j !== 'object') return;
    const pfad = pfadTeile(j.path);
    if (event === 'put') {
      this._zaehler.put++;
      this._setze(pfad, j.data === undefined ? null : j.data);
      return;
    }
    this._zaehler.patch++;
    const d = j.data;
    if (!d || typeof d !== 'object' || Array.isArray(d)) return;
    // Ein patch-Ereignis traegt RELATIVE Pfade als Schluessel — sie koennen selbst mehrstufig sein
    // ("st.../meta"). Jeder davon ist ein eigener put auf pfad + schluessel.
    for (const k of Object.keys(d)) this._setze(pfad.concat(pfadTeile(k)), d[k] === undefined ? null : d[k]);
  }

  /*
   * _setze — ein Ereignis in den Rohbaum eintragen.
   *
   * Zwei Dinge passieren hier, und sie sind absichtlich in dieser Reihenfolge:
   *   1. Die Meldung an stationsid, wenn das Ereignis einen Wert fuer den EIGENEN
   *      meta.instanz-Knoten TRAEGT. Gemeldet wird nur, was das Ereignis wirklich geliefert hat —
   *      niemals der zwischengespeicherte Stand. Sonst zaehlte eine Kachelaenderung als weitere
   *      Sichtung desselben Zwillings, und aus EINER Sichtung wuerde ueber die Ausdauerregel von
   *      stationsid.js ein Beweis, den es nicht gibt. Ein falscher Beweis sperrt die
   *      Patientendaten dieser Station — der Preis eines Fehlers ist hier hoch.
   *   2. Das Eintragen selbst, mit allen Speichergrenzen.
   */
  _setze(segs, wert) {
    const eigen = this._instanzAusEreignis(segs, wert);
    if (eigen.trifft) this._instanzMelden(eigen.wert);

    if (!segs.length) {
      const neu = {};
      if (wert && typeof wert === 'object' && !Array.isArray(wert)) {
        /*
         * Beim Vollbild wird NICHT nach Lieferreihenfolge abgeschnitten, sondern nach ALTER: die
         * juengsten ROH_SAELE_MAX Saele gewinnen (Befund C8). Grund: ausgemusterte Praxis-PCs
         * hinterlassen ihren Tafelknoten in der Datenbank (aufgeraeumt wird laut Plan nur per
         * Admin-Knopf). Wer nach Lieferreihenfolge abschneidet, laesst 64 solche Leichen einen NEU
         * aufgestellten OP-Saal verdraengen — der taucht dann nie in der Tafel auf, lautlos bis auf
         * einen Zaehler ohne Namen. Bei gleichem Zeitstempel entscheidet die Kennung, damit die
         * Auswahl von Lauf zu Lauf dieselbe ist.
         */
        const kand = [];
        for (const k of Object.keys(wert)) {
          if (!tafel.pruefeSid(k)) { this._verworfen.fremdeSchluessel++; continue; }
          const v = wert[k];
          const knoten = (v && typeof v === 'object' && !Array.isArray(v)) ? v : {};
          const sv = Number(svAus(kopfAus(knoten)));
          kand.push({ sid: k, knoten: knoten, sv: Number.isFinite(sv) ? sv : -Infinity });
        }
        kand.sort((a, b) => {
          if (a.sv !== b.sv) return b.sv - a.sv;        // juengster zuerst
          return a.sid < b.sid ? -1 : (a.sid > b.sid ? 1 : 0);
        });
        for (let i = 0; i < kand.length; i++) {
          if (i < ROH_SAELE_MAX) { neu[kand[i].sid] = kand[i].knoten; continue; }
          this._verworfen.zuVieleSaele++;
          this._saalVerdraengt(kand[i].sid, kand[i].knoten);
        }
      }
      this._roh = neu;
      this._grenzenMelden();
      return;
    }

    if (segs.length > tafel.GRENZEN.tiefe) { this._verworfen.zuTief++; this._grenzenMelden(); return; }
    const sid = segs[0];
    if (!tafel.pruefeSid(sid)) { this._verworfen.fremdeSchluessel++; this._grenzenMelden(); return; }
    for (let i = 1; i < segs.length; i++) {
      if (VERBOTENE_SEGMENTE.indexOf(segs[i]) >= 0) {
        this._verworfen.verboteneSegmente++; this._grenzenMelden(); return;
      }
    }
    const neuerSaal = !Object.prototype.hasOwnProperty.call(this._roh, sid);
    /* Eine Loeschung fuer einen Saal, den wir gar nicht fuehren, ist in JEDEM Fall folgenlos — sie
     * darf deshalb weder Platz beanspruchen noch (weiter unten) einen anderen Saal verdraengen. */
    if (neuerSaal && wert === null) { this._grenzenMelden(); return; }
    if (neuerSaal && Object.keys(this._roh).length >= ROH_SAELE_MAX) {
      /* Der Rohbaum ist voll. Nicht den NEUEN abweisen, sondern den aeltesten weichen lassen: der
       * neue schreibt gerade, ist also mit Sicherheit ein laufender Saal, waehrend der aelteste
       * ebensogut der Knoten eines ausgemusterten PCs sein kann. Die Anzeige laesst Saele ab 12 h
       * ohnehin fallen — nur der Rohbaum tat es bisher nie (Befund C8). */
      if (!this._aeltestenVerdraengen()) {
        this._verworfen.zuVieleSaele++; this._saalVerdraengt(sid, null); this._grenzenMelden(); return;
      }
    }

    if (segs.length === 1) {
      if (wert === null) delete this._roh[sid];
      else this._roh[sid] = (typeof wert === 'object' && !Array.isArray(wert)) ? wert : {};
      this._grenzenMelden();
      return;
    }

    if (!this._roh[sid] || typeof this._roh[sid] !== 'object') this._roh[sid] = {};
    let cur = this._roh[sid];
    for (let i = 1; i < segs.length - 1; i++) {
      const s = segs[i];
      if (!cur[s] || typeof cur[s] !== 'object' || Array.isArray(cur[s])) {
        if (!Object.prototype.hasOwnProperty.call(cur, s) && Object.keys(cur).length >= KINDER_MAX) {
          this._verworfen.zuVieleKinder++; this._grenzenMelden(); return;
        }
        cur[s] = {};
      }
      cur = cur[s];
    }
    const letzt = segs[segs.length - 1];
    if (wert === null) { delete cur[letzt]; this._grenzenMelden(); return; }
    if (!Object.prototype.hasOwnProperty.call(cur, letzt) && Object.keys(cur).length >= KINDER_MAX) {
      this._verworfen.zuVieleKinder++; this._grenzenMelden(); return;
    }
    cur[letzt] = wert;
    this._grenzenMelden();
  }

  /*
   * _aeltestenVerdraengen — den Saal mit dem AELTESTEN Zeitstempel aus dem Rohbaum werfen.
   *
   * Ein Knoten ohne brauchbaren Zeitstempel gilt als der aelteste ueberhaupt: er kann keine
   * Altersaussage tragen und ist damit der einzige Kandidat, dessen Verlust nichts kostet. Bei
   * gleichem Alter entscheidet die Kennung, damit zwei Laeufe dieselbe Wahl treffen.
   * Rueckgabe: true, wenn wirklich einer gewichen ist.
   */
  _aeltestenVerdraengen() {
    const sids = Object.keys(this._roh);
    if (!sids.length) return false;
    let opfer = null;
    let aeltest = Infinity;
    for (const s of sids) {
      const sv = Number(svAus(kopfAus(this._roh[s])));
      const wert = Number.isFinite(sv) ? sv : -Infinity;
      if (wert < aeltest || (wert === aeltest && opfer !== null && s < opfer)) { aeltest = wert; opfer = s; }
    }
    if (opfer === null) return false;
    const knoten = this._roh[opfer];
    delete this._roh[opfer];
    this._verworfen.verdraengt++;
    this._saalVerdraengt(opfer, knoten);
    return true;
  }

  /*
   * Ein Saal, der den Rohbaum verlaesst oder gar nicht hineinkommt, wird NAMENTLICH gefuehrt und
   * gemeldet — dieselbe Regel wie beim Anzeigedeckel (N17). Ein Zaehler ohne Namen beantwortet die
   * einzige Frage nicht, die der Tierarzt dann hat: WELCHER Saal fehlt?
   */
  _saalVerdraengt(sid, knoten) {
    const name = knoten ? tafel.text(kopfAus(knoten).name, tafel.GRENZEN.spiegelStation) : null;
    this._verdraengt.push({ sid: sid, name: name || null });
    while (this._verdraengt.length > VERDRAENGT_LISTE_MAX) this._verdraengt.shift();
    this._melde('warn', 'verdraengt', 'Der Rohbaum fasst hoechstens ' + ROH_SAELE_MAX
      + ' OP-Saele; zuletzt wichen: ' + this._verdraengt.map((s) => (s.name || s.sid)).join(', ')
      + '. Ausgemusterte Praxis-PCs hinterlassen ihren Tafelknoten in der Datenbank — bitte im '
      + 'Admin-Bereich aufraeumen.', true);
  }

  /*
   * _instanzAusEreignis — TRAEGT dieses Ereignis einen Wert fuer <eigene sid>/meta/instanz?
   *
   * Vier Wege liefern ihn, und nur diese vier:
   *   put '/'                     -> data[sid].meta.instanz
   *   put '/<sid>'                -> data.meta.instanz
   *   put '/<sid>/meta'           -> data.instanz
   *   put '/<sid>/meta/instanz'   -> data
   * Alles andere (eine Kachel, eine Geraetezeile, ein anderer Saal) traegt ihn NICHT. Genau das
   * unterscheidet "ich habe gerade hingesehen" von "ich erinnere mich".
   */
  _instanzAusEreignis(segs, wert) {
    const nein = { trifft: false, wert: null };
    const sid = this._sid();
    if (!sid) return nein;
    const feld = (o, n) => ((o && typeof o === 'object' && !Array.isArray(o)) ? o[n] : undefined);
    if (!segs.length) {
      if (wert === null) return nein;              // der ganze Zweig ist weg — eine Abwesenheit, keine Meldung
      return { trifft: true, wert: feld(feld(feld(wert, sid), 'meta'), 'instanz') };
    }
    if (segs[0] !== sid) return nein;
    if (segs.length === 1) return { trifft: true, wert: feld(feld(wert, 'meta'), 'instanz') };
    if (segs[1] !== 'meta') return nein;
    if (segs.length === 2) return { trifft: true, wert: feld(wert, 'instanz') };
    if (segs.length === 3 && segs[2] === 'instanz') return { trifft: true, wert: wert };
    return nein;
  }

  /*
   * Der Wert geht UNVERAENDERT an stationsid.kollisionGemeldet(). Kein Saeubern, kein Kuerzen,
   * kein Vergleich mit der eigenen Instanz: Form, Herkunft und Ausdauer entscheidet stationsid.js,
   * und ein Aufrufer, der vorsortiert, erwischt die halbe Logik.
   * Nicht gemeldet wird ausschliesslich die ABWESENHEIT (kein Wert): sie waere eine Entwarnung,
   * und Entwarnen ist nicht Sache des Lesewegs — siehe Kopfkommentar.
   */
  _instanzMelden(wert) {
    if (wert === null || wert === undefined || wert === '') return;
    if (!this.stationsid || typeof this.stationsid.kollisionGemeldet !== 'function') return;
    this._zaehler.instanzMeldungen++;
    try { this.stationsid.kollisionGemeldet(wert); } catch (e) {
      this._melde('warn', 'kollision', 'Die Meldung einer fremden Instanz ist fehlgeschlagen: ' + fehlertext(e));
    }
  }

  // ------------------------------------------------------------ Ausgabe
  /*
   * saele() — was weitergegeben wird. Gedeckelt, gesaeubert, stabil sortiert.
   *
   * Enthalten sind auch AUSGEFALLENE Saele (Stufe 'alt'/'offline') — ein Saal, der nach 60 s
   * Stille aus der Liste faellt, verschwindet lautlos, und genau das soll dieser Umbau beenden.
   * Nicht mehr enthalten sind:
   *   • Knoten ohne instanz (Rest oder Fremdschreibvorgang, dieselbe Regel wie tafel.istZeigbar)
   *     -> stand().verworfen.ohneInstanz
   *   • Knoten aelter als 12 h UND Knoten, deren Zeitstempel mehr als 12 h in der Zukunft liegt
   *     -> beide in stand().verworfen.zuAlt. Ein gemeinsamer Zaehler, weil beides dasselbe
   *     bedeutet: dieser Zeitstempel taugt nicht mehr fuer eine Altersaussage.
   *
   * JEDER SATZ TRAEGT ZUSAETZLICH blind UND lesestandMs (Befund C3). altMs und stufe altern aus dem
   * sv des Nachbarn — sie altern deshalb auch dann weiter, wenn nicht der Nachbar steht, sondern
   * UNSER Strom abgerissen ist. Ohne diese beiden Felder meldet ein Nachbarstreifen einem
   * kerngesunden OP-Saal einen Ausfall, den der eigene PC hat, und der Tierarzt laeuft hinueber
   * oder verlaesst sich nicht mehr auf die Fernansicht. Die Stufe wird deswegen NICHT beschoenigt:
   * die Zahlen sind wirklich alt. Nur ihr Grund steht jetzt daneben.
   */
  saele() {
    const jetzt = this.jetzt();
    const eigen = this._sid();
    const alle = [];
    let ohneInstanz = 0, zuAlt = 0;
    for (const sid of Object.keys(this._roh)) {
      const eintrag = this._roh[sid];
      if (!eintrag || typeof eintrag !== 'object') continue;
      const kopf = kopfAus(eintrag);
      if (!kopf.instanz) { ohneInstanz++; continue; }
      const sv = svAus(kopf);
      const alt = tafel.alterMs(sv, jetzt);
      if (alt != null && alt >= tafel.STUFE_WEG_MS) { zuAlt++; continue; }
      if (alt == null) {
        // Alter unbekannt: der Zeitstempel liegt vor unserer Uhr. Innerhalb der Uhrentoleranz
        // bleibt der Saal sichtbar (mit Stufe 'unbekannt'), darueber hinaus ist es kein Gangfehler
        // mehr, sondern Unsinn — dieselbe Grenze wie tafel.istFrisch().
        const vor = Number(sv) - jetzt;
        if (!Number.isFinite(vor) || vor < 0 || vor > tafel.UHR_TOLERANZ_MS) { zuAlt++; continue; }
      }
      alle.push({
        sid: sid,
        name: tafel.text(kopf.name, tafel.GRENZEN.spiegelStation),
        eigen: sid === eigen,
        altMs: alt,
        stufe: tafel.altersStufe(alt),
        kopf: kopf,
        eintrag: eintrag,
      });
    }
    this._verworfen.ohneInstanz = ohneInstanz;
    this._verworfen.zuAlt = zuAlt;

    sortiereSaele(alle);
    const gefuehrt = alle.slice(0, this.deckel);
    this._weitere = alle.slice(this.deckel).map((s) => ({ sid: s.sid, name: s.name }));
    this._verworfen.ueberDeckel = this._weitere.length;
    this._deckelMelden();

    /* Die Lage des EIGENEN Lesers, EINMAL gerechnet und in jeden Satz gelegt: acht Saele duerfen
     * nicht acht verschiedene Antworten auf dieselbe Frage tragen. */
    const lage = { blind: !this._verbunden, lesestandMs: this.lesestandMs() };
    /* Ein frischer Zaehlerbeutel je Aufruf, nicht aufsummiert: saele() rechnet jedes Mal aus
     * DEMSELBEN Rohbaum: eine Summe ueber alle Aufrufe waere keine Aussage ueber die Daten,
     * sondern ueber die Anzahl der Bildschirmaktualisierungen (genau wie ohneInstanz und zuAlt). */
    const zaehler = { namensKollision: 0, verbotenerName: 0 };
    const saetze = gefuehrt.map((s) => this._satz(s, lage, zaehler));
    this._verworfen.namensKollision = zaehler.namensKollision;
    this._verworfen.verbotenerName = zaehler.verbotenerName;
    this._saeuberMelden(zaehler);
    return saetze;
  }

  /* Nur die Nachbarn — der eigene Saal kommt auf dem eigenen Bildschirm aus der Registry und
   * nicht aus der Cloud. Er nimmt an Sortierung und Deckel trotzdem teil: die Tafel zeigt acht
   * SAELE, nicht acht Nachbarn. */
  nachbarn() { return this.saele().filter((s) => !s.eigen); }

  /* Wie lange ist der letzte gelieferte Rahmen her? null = seit dem Start kam keiner. Ein
   * keep-alive zaehlt mit — er ist genau der Rahmen, mit dem der Strom seine Gesundheit zeigt. */
  lesestandMs() {
    if (!this._letzterRahmenAm) return null;
    const d = this._uhr() - this._letzterRahmenAm;
    return d < 0 ? 0 : d;                 // eine rueckwaerts gesprungene Uhr macht kein Alter negativ
  }

  /*
   * _satz — der Saalsatz nach aussen. 'name' wird hier NICHT ein zweites Mal ausgeliefert:
   * ohneZweige() trennt ihn zusammen mit uebersicht und geraete heraus (Befund C5). Vorher trug ein
   * Saal in EINER Antwort zwei Namen — satz.name auf 120 Zeichen, satz.meta.name auf 40 — und wer
   * im Nachbarstreifen den einen und in der Saalkarte den anderen nahm, schrieb fuer DENSELBEN
   * OP-Saal zwei verschiedene Namen auf zwei Bildschirme. Genau davor warnt N10.
   */
  _satz(s, lage, zaehler) {
    const kacheln = this._kinder(s.eintrag.uebersicht, tafel.GRENZEN.kacheln, zaehler);
    const geraete = this._kinder(s.eintrag.geraete, tafel.GRENZEN.geraete, zaehler);
    return {
      sid: s.sid,
      name: s.name,
      eigen: s.eigen,
      altMs: s.altMs,
      stufe: s.stufe,
      blind: !!(lage && lage.blind),
      lesestandMs: lage ? lage.lesestandMs : null,
      meta: saeubere(ohneZweige(s.kopf), 0, zaehler),
      kacheln: kacheln.liste,
      weitereKacheln: kacheln.weitere,
      geraete: geraete.liste,
      weitereGeraete: geraete.weitere,
    };
  }

  /*
   * Kacheln und Geraetezeilen: stabil nach Schluessel sortiert, gedeckelt, gesaeubert — und der
   * Rest wird GEZAEHLT. "12 Kacheln" ist derselbe Deckel wie beim Schreiben (tafel.GRENZEN).
   *
   * DERSELBE KOLLISIONSFALL WIE IN saeubere() (Befund C2), nur eine Ebene hoeher: tafel.schluessel()
   * ersetzt jedes Zeichen ausser A-Z a-z 0-9 _ - durch '_', zwei verschiedene Datenbankschluessel
   * ('sw/hund' und 'sw:hund') werden danach zu EINEM. Zwei Kacheln mit demselben Schluessel sind
   * fuer jede Anzeige, die danach ordnet, dieselbe Kachel — und welche der beiden sie zeigt, haengt
   * dann von ihrer eigenen Bauart ab. Deshalb gewinnt auch hier der erste sortierte Schluessel, und
   * der zweite wird gezaehlt statt mitgeliefert. Er zaehlt NICHT als 'weitere': 'weitere' bedeutet
   * "wegen des Deckels nicht dabei", und das waere hier eine falsche Auskunft.
   */
  _kinder(knoten, deckel, zaehler) {
    if (!knoten || typeof knoten !== 'object' || Array.isArray(knoten)) return { liste: [], weitere: 0 };
    const namen = Object.keys(knoten).sort();
    const liste = [];
    const gesehen = Object.create(null);
    let doppelt = 0;
    for (let i = 0; i < namen.length && liste.length < deckel; i++) {
      const k = tafel.schluessel(namen[i]);
      if (gesehen[k]) { doppelt++; zaehle(zaehler, 'namensKollision'); continue; }
      gesehen[k] = true;
      liste.push({ schluessel: k, werte: saeubere(knoten[namen[i]], 0, zaehler) });
    }
    return { liste: liste, weitere: Math.max(0, namen.length - liste.length - doppelt) };
  }

  /*
   * stand() — alles, was ein Mensch oder eine Diagnoseseite ueber diesen Leser wissen muss.
   * Hier stehen ausdruecklich auch die VERWORFENEN Dinge: ein Deckel, der nur wirkt und nichts
   * meldet, ist ein stiller Datenverlust.
   */
  stand() {
    const gefuehrt = this.saele();
    return {
      laeuft: !this._gestoppt,
      verbunden: this._verbunden,
      seit: this._verbundenSeit || null,
      verbindungen: this._zaehler.verbindungen,
      umleitungen: this._zaehler.umleitungen,
      ereignisse: {
        put: this._zaehler.put, patch: this._zaehler.patch, keepAlive: this._zaehler.keepAlive,
        authRevoked: this._zaehler.authRevoked, cancel: this._zaehler.cancel,
        unbekannt: this._zaehler.unbekannt,
      },
      bytes: this._zaehler.bytes,
      fehler: this._fehler,
      fehlerAnzahl: this._fehlerAnzahl,
      backoffMs: this._backoffMs,
      naechsterVersuch: this._naechsterVersuch || null,
      /* Der Lesestand steht auch HIER, nicht nur im Saalsatz: eine Diagnoseseite, die keinen
       * einzigen Saal hat (Strom tot seit dem Start), muss trotzdem sagen koennen, seit wann.
       * blind ist bewusst dasselbe wie !verbunden — zwei Woerter fuer eine Aussage, weil der
       * Saalsatz das Wort 'blind' traegt und ein Leser beides nebeneinander wiederfinden soll. */
      blind: !this._verbunden,
      lesestandMs: this.lesestandMs(),
      /* Die Anmeldelast dieses Lesers, offen ausgewiesen (Befund C1): erneuert zaehlt die wirklich
       * geholten Token, abgelehnt die von der Sperre abgewiesenen Versuche. Steigt 'abgelehnt'
       * dauerhaft, liegt es an der Anmeldung — nicht am Netz. */
      token: {
        erneuert: this._zaehler.tokenErneuert,
        abgelehnt: this._zaehler.erneuernAbgelehnt,
        letzteAm: this._letzteErneuerungAm || null,
        sperreMs: this.erneuernSperreMs,
      },
      zeit: { quelle: this.zeitQuelle(), versatzMs: this.versatzMs(), proben: this._versaetze.length },
      saele: gefuehrt.length,
      grenze: this.deckel,
      weitere: this._weitere.length,
      weitereListe: this._weitere.slice(),
      verdraengteListe: this._verdraengt.slice(),
      verworfen: Object.assign({}, this._verworfen),
      instanzMeldungen: this._zaehler.instanzMeldungen,
    };
  }

  // ------------------------------------------------------------ Meldungen
  /*
   * Der Deckel wird gemeldet, sobald er greift — und erneut, wenn sich die Zahl aendert oder eine
   * Minute vergangen ist. Der Wortlaut ist der aus Nachbesserung N17, damit Log, Kiosk-Streifen
   * und Web-App dasselbe sagen.
   */
  _deckelMelden() {
    const n = this._weitere.length;
    if (!n) { this._deckelGemeldet.anzahl = 0; return; }
    const jetzt = this._uhr();
    if (this._deckelGemeldet.anzahl === n && (jetzt - this._deckelGemeldet.am) < MELDE_TAKT_MS) return;
    this._deckelGemeldet = { anzahl: n, am: jetzt };
    this.log.warn('nachbarn', n + ' weitere OP-Saele werden nicht angezeigt — Deckel erreicht ('
      + this.deckel + '): ' + this._weitere.map((s) => (s.name || s.sid)).join(', '));
  }

  /*
   * Die Speichergrenzen des Rohbaums: gezaehlt und WIRKLICH nur einmal je Minute gesagt.
   *
   * Der Text traegt die laufenden Zaehler — steigt einer, ist der Text NEU. Eine Drossel, die auf
   * den Text schluesselt, greift damit genau dann nicht, wenn sie gebraucht wird: 20 abgewiesene
   * Ereignisse in unter einer Sekunde ergaben 20 Warnzeilen, und der Kommentar an dieser Stelle
   * behauptete trotzdem "einmal je Minute" (Befund C6). Deshalb wird hier auf das SCHLUESSELWORT
   * gedrosselt (letztes Argument true) und nicht auf den Text. Was das kostet, gehoert dazu: eine
   * Minute lang sieht man den Anstieg der Zaehler nicht im Log. Man sieht ihn in stand().verworfen,
   * und eine Warnzeile je Sekunde in genau dem Log, in dem waehrend einer Narkose die klinischen
   * Warnungen stehen, ist der schwerere Schaden.
   */
  _grenzenMelden() {
    const v = this._verworfen;
    const n = v.fremdeSchluessel + v.zuVieleSaele + v.zuTief + v.zuVieleKinder + v.verboteneSegmente;
    if (!n) return;
    this._melde('warn', 'grenzen', 'Aus dem Tafel-Strom wurden ' + n + ' Eintraege abgewiesen '
      + '(fremde Schluessel ' + v.fremdeSchluessel + ', zu viele Saele ' + v.zuVieleSaele
      + ', zu tief ' + v.zuTief + ', zu viele Kinder ' + v.zuVieleKinder
      + ', verbotene Namen ' + v.verboteneSegmente + '). Sie stehen in der Datenbank, werden hier '
      + 'aber nicht gefuehrt.', true);
  }

  /*
   * Namenskollisionen und verbotene Feldnamen beim Saeubern (Befunde C2 und C4).
   *
   * Auch das ist eine Grenze, die wirkt — also darf sie nicht still wirken. Gedrosselt wird auf das
   * Schluesselwort, weil saele() bei JEDER Bildschirmaktualisierung laeuft und die Zahlen dabei
   * schwanken; ohne diese Drossel stuende hier eine Zeile je Bildaufbau.
   */
  _saeuberMelden(z) {
    const n = (z.namensKollision || 0) + (z.verbotenerName || 0);
    if (!n) return;
    this._melde('warn', 'saeubern', 'In den Daten der Nachbarsaele wurden ' + n + ' Felder nicht '
      + 'uebernommen (Namenskollision ' + (z.namensKollision || 0) + ', verbotener Name '
      + (z.verbotenerName || 0) + '). Zwei verschiedene Datenbankschluessel ergeben nach dem '
      + 'Saeubern denselben Namen; es gilt der erste. So kann kein Messwert unter dem Namen eines '
      + 'anderen Feldes auf einem Bildschirm landen.');
  }

  /*
   * Die Drossel fuer wiederkehrende Meldungen — und ihre Grenze, ausdruecklich benannt.
   *
   * JE SCHLUESSELWORT EIN EIGENES GEDAECHTNIS. Frueher gab es genau EINEN Platz fuer alle: zwei
   * abwechselnde Schluesselwoerter loeschten sich gegenseitig aus, und die Drossel griff bei
   * keinem von beiden.
   *
   * SIE BREMST: denselben Text unter demselben Schluesselwort hoechstens einmal je MELDE_TAKT_MS.
   * Ohne das schreibt ein klemmender Strom im Sekundentakt in genau das Log, in dem waehrend einer
   * Narkose die klinischen Warnungen stehen (Befund A3 in stationsid.js, dort dasselbe Muster).
   *
   * SIE BREMST NICHT: zwei ABWECHSELNDE Texte unter demselben Schluesselwort. Das ist fuer
   * 'fehler' gewollt — die eigentliche Bremse ist dort der Backoff selbst, ein Lesefehler kann
   * fruehestens nach _backoffMs wiederkommen, und der Text nennt genau diese wachsende Wartezeit;
   * solange sie waechst, soll JEDE Zeile im Log stehen. Steht sie auf ihrem Hoechstwert, ist der
   * Text gleich und die Drossel greift.
   *
   * WER DAS NICHT WILL, SETZT nurSchluessel: dann entscheidet allein das Schluesselwort, und der
   * Text darf sich aendern, ohne die Drossel zu loesen. Das brauchen alle Meldungen, deren Text
   * laufende Zaehler traegt ('grenzen', 'saeubern', 'verdraengt') — bei ihnen ist ein neuer Text
   * der Normalfall und kein neues Ereignis (Befund C6).
   */
  _melde(stufe, schluesselWort, text, nurSchluessel) {
    const jetzt = this._uhr();
    const alt = this._gemeldet[schluesselWort];
    if (alt && (nurSchluessel || alt.text === text) && (jetzt - alt.am) < MELDE_TAKT_MS) return;
    this._gemeldet[schluesselWort] = { text: text, am: jetzt };
    const fn = this.log[stufe] || this.log.info;
    try { fn.call(this.log, 'nachbarn', text); } catch (_) { /* ein Log darf nie den Leser stoppen */ }
  }
}

// ---------------------------------------------------------------- kleine Hilfen

function fehlertext(e) { return (e && e.message) ? e.message : String(e); }

/*
 * Der Saalkopf OHNE die Felder, die der Satz bereits an einer besseren Stelle fuehrt.
 *
 * uebersicht und geraete werden getrennt gefuehrt (gedeckelt und gesaeubert) — ohne dieses
 * Abtrennen stuenden sie doppelt im Ergebnis, einmal ungedeckelt.
 * 'name' faellt aus demselben Grund heraus, aber mit einer schaerferen Folge (Befund C5): er stand
 * in satz.name auf 120 Zeichen und in satz.meta.name auf 40 — ZWEI Namen fuer EINEN OP-Saal in
 * EINER Antwort. Der Nachbarstreifen nahm den einen, die Saalkarte den anderen, und derselbe Saal
 * hiess auf zwei Bildschirmen verschieden. Es gibt jetzt genau einen Namen, und er steht in
 * satz.name.
 */
const KOPF_OHNE = ['uebersicht', 'geraete', 'name'];

function ohneZweige(kopf) {
  const out = {};
  for (const k of Object.keys(kopf || {})) {
    if (KOPF_OHNE.indexOf(k) >= 0) continue;
    out[k] = kopf[k];
  }
  return out;
}

/*
 * kopfBytes/stueckBytes — der Aufschlag, den stand().bytes mitzaehlt (Befund C7).
 *
 * res.rawHeaders ist die flache Liste [Name, Wert, Name, Wert, ...], wie sie auf der Leitung stand.
 * Dazu je Zeile ': ' und CRLF, ein CRLF fuer das Kopfende und rund 15 Byte fuer die Statuszeile
 * ('HTTP/1.1 200 OK'). Das ist eine RECHNUNG, keine Messung am Socket — auf ein Byte genau kaeme
 * man nur unterhalb von Node heran, und eine Zahl, die niemand nachpruefen kann, waere schlechter
 * als eine, deren Bauart hier steht.
 */
const STATUSZEILE_BYTES = 15 + 2;     // 'HTTP/1.1 200 OK' + CRLF
const KOPFZEILE_ZUSATZ = 4;           // ': ' zwischen Name und Wert, CRLF am Zeilenende

function kopfBytes(res) {
  const roh = (res && Array.isArray(res.rawHeaders)) ? res.rawHeaders : [];
  let n = STATUSZEILE_BYTES + 2;      // + das leere CRLF, das den Kopf beendet
  for (let i = 0; i < roh.length; i += 2) {
    n += Buffer.byteLength(String(roh[i]), 'utf8')
      + Buffer.byteLength(String(roh[i + 1] == null ? '' : roh[i + 1]), 'utf8')
      + KOPFZEILE_ZUSATZ;
  }
  return n;
}

function stueckBytes(c) {
  if (c == null) return 0;
  if (Buffer.isBuffer(c)) return c.length;
  return Buffer.byteLength(String(c), 'utf8');
}

/* Gleiche Domaene = gleiche letzte zwei Namensteile (oder derselbe Rechner). Reicht fuer den
 * einzigen Fall, den es gibt: die Umleitung der Datenbank auf ihren Namensraumserver
 * (...-default-rtdb.europe-west1.firebasedatabase.app -> s-euw1b-nss-2.europe-west1.firebasedatabase.app).
 * Eine Adresse ohne Punkt (localhost, 127.0.0.1) muss exakt gleich sein. */
function gleicheDomaene(a, b) {
  const x = String(a || '').toLowerCase(), y = String(b || '').toLowerCase();
  if (x === y) return true;
  const xs = x.split('.'), ys = y.split('.');
  if (xs.length < 3 || ys.length < 3) return false;
  return xs.slice(-2).join('.') === ys.slice(-2).join('.');
}

module.exports = {
  Tafelabo,
  Rahmenleser,
  pfadTeile,
  saeubere,
  mittlererVersatz,
  sortiereSaele,
  gleicheDomaene,
  BACKOFF_START_MS,
  BACKOFF_MAX_MS,
  STILLE_MAX_MS,
  RAHMEN_MAX,
  ROH_SAELE_MAX,
  KINDER_MAX,
  VERSATZ_PROBEN,
  UMLEITUNGEN_MAX,
  MELDE_TAKT_MS,
  ANLAUF_MS,
  ERNEUERN_SPERRE_MS,
  VERDRAENGT_LISTE_MAX,
};
