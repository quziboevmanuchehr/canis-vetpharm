@echo off
title VetStation - neu starten
REM Beendet die laufende Station (auch wenn sie mit erhoehten Rechten laeuft) und startet sie neu.
REM Noetig nach einem Update, nach Aenderungen an bridge\config\devices.json und wenn ein
REM Datenport von einer zweiten Instanz belegt ist.
echo Beende VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\stop-kiosk.ps1"
echo Starte VetStation ...
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
if errorlevel 1 (
  echo.
  echo *** VetStation konnte nicht gestartet werden - Meldung oben lesen. ***
  echo.
  pause
)
