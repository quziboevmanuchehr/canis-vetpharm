'use strict';
/*
 * fremdstore.js — das Gedaechtnis fuer FREMDE OP-Saele (Stufe 1, ab 1.1.0).
 *
 * WOZU DIESE DATEI DA IST: Was der Leseweg (tafelabo.js) aus der Cloud holt und was spaeter der
 * LAN-Weg (nachbar.js, Stufe 2) liefert, sind ZWEI Beschreibungen DESSELBEN Nachbarsaals. Hier
 * werden sie zu EINER Sicht je Saal zusammengefuehrt: eine Quelle, ein Alter, eine Alterungsstufe,
 * eine Liste Patienten, eine Liste Geraete. Wer den Nachbarstreifen auf dem Kiosk fuellt
 * (MSG.FREMD) oder /api/nachbarn beantwortet, holt sie hier ab.
 *
 * ------------------------------------------------------------------------------------------
 * DIE WICHTIGSTE AUSSAGE DIESER DATEI: FREMDE DATEN ERREICHEN DEN EIGENEN MESSWEG NIE.
 * ------------------------------------------------------------------------------------------
 * Es gibt hier kein require auf registry, matching, cloud, model, server oder einen Adapter — und
 * zwar nicht aus Ordnungsliebe: an registry.ingest() haengt die halbe Fehlerliste des Plans
 * (kollidierende deviceIds, vergiftete manual/meta-Tabellen, bridge/data/patient-akte.json, der
 * Halte-Puffer mit fremden Uhren). Ein Patient aus OP 2 darf im eigenen Saal weder in einer
 * Dosisrechnung noch in einem Narkoseprotokoll noch im Koppel-Dialog auftauchen. Geladen wird
 * ausschliesslich ./tafel — und das ist eine Datei ohne jedes require, ohne fs, ohne Netz.
 * tools/fremdstore-test.js erzwingt das am Quelltext UND zur Laufzeit ueber require.cache.
 *
 * ------------------------------------------------------------------------------------------
 * KEINE EIGENE UHR, NIRGENDS
 * ------------------------------------------------------------------------------------------
 * Wie in tafel.js ist die Zeit immer ein Argument. Das ist die Voraussetzung dafuer, dass die drei
 * Alterungsschwellen (12 s / 60 s / 12 h) und ein negatives Alter ohne zwei PCs, ein Firebase-Konto
 * und stundenlanges Warten pruefbar sind (Nachbesserung N16). Deshalb hat auch status() keinen
 * Uhr-Parameter und rechnet KEIN Alter: sie zeigt, was beim letzten saele()/rundruf() entschieden
 * wurde, und die rohen Zeitstempel. Eine zweite Uhr an dieser Stelle waere eine zweite Wahrheit
 * ueber dasselbe Alter.
 *
 * WELCHE UHR DER AUFRUFER UEBERGEBEN MUSS: dieselbe wie bei tafel.js — die SERVERZEIT, also die
 * PC-Uhr plus den Versatz aus der HTTP-Date-Kopfzeile (tafelabo.jetzt() liefert genau das). Die
 * Cloud-Zeitstempel sind Serverzeit; wer hier die unkorrigierte PC-Uhr uebergibt, vergleicht zwei
 * Zeitrechnungen.
 *
 * ------------------------------------------------------------------------------------------
 * LAN DARF DIE LAUFZEIT UEBERHOLEN, NIE DIE WAHRHEIT (Plan, Abschnitt lanWeg, QUELLENWAHL)
 * ------------------------------------------------------------------------------------------
 * Je Saal genau EINE Quelle. LAN wird bevorzugt, weil es schneller ist und kein Kontingent kostet.
 * ABER: bei Widerspruch gewinnt IMMER die Cloud, und der Saal traegt dann das Feld
 * widerspruchText = 'Quellen widersprechen sich'. Begruendung: der Cloud-Weg ist der einzige, bei
 * dem der Absender durch eine Anmeldung am Praxis-Konto gedeckt ist und die Datenbankregel
 * sid === $station den Datensatz an seinen Pfad bindet. Der LAN-Weg ist der neue, der erstmals
 * einen Port im Praxisnetz oeffnet. Wo beide dasselbe sagen, ist LAN der schnellere; wo sie sich
 * unterscheiden, ist die Cloud die belastbarere Aussage.
 *
 * ------------------------------------------------------------------------------------------
 * DIE DECKEL SIND SICHTBAR, NIE STILL (Nachbesserung N17)
 * ------------------------------------------------------------------------------------------
 * Acht Saele, zwoelf Kacheln je Saal — was darueber liegt, steht ALS ZAHL im Ergebnis (mehr) und
 * als fertiger Klartext in hinweise[]. Ein lautlos verschwundener OP-Saal ist genau die
 * Verwechslungsgefahr, gegen die dieser Umbau gebaut wird.
 *
 * ------------------------------------------------------------------------------------------
 * WAS HIER ABSICHTLICH NICHT WEITERGEGEBEN WIRD
 * ------------------------------------------------------------------------------------------
 * Das Kachelfeld dv (hoechstens zwei '<deviceId>@<ip>') wird NICHT durchgereicht. Die
 * Doppelempfangserkennung laeuft ausdruecklich ueber die vollstaendige Geraeteliste (N13), und dv
 * presst zwei Werte in eine gekuerzte Zeichenkette — zwei verschiedene Geraete koennen darin zu
 * einem verschmelzen (Befund B7 in tafel.js). Waere dv hier verfuegbar, baute frueher oder spaeter
 * jemand die Erkennung darauf. Aus demselben Grund fehlen fi und dev: sie stehen nicht im
 * Feldsatz des Plan-Abschnitts oberflaechen und werden im Nachbarstreifen nicht gezeigt.
 */
const tafel = require('./tafel');

/*
 * ALTERUNG: es gibt genau EINE Regel, und sie steht in tafel.js.
 *
 * altersStufe wird hier WEITERGEREICHT, nicht nachgebaut. Ein zweiter Satz Schwellen waere der
 * sichere Weg dahin, dass ein Saal auf dem Kiosk 'live' und in der Web-App 'offline' heisst — und
 * genau das schliesst der Kommentar bei tafel.STUFE_LIVE_MS aus. tools/fremdstore-test.js prueft
 * die Gleichheit der beiden Funktionen als Identitaet (===), nicht nur als gleiches Ergebnis.
 */
const altersStufe = tafel.altersStufe;

/*
 * DER SICHERUNGSSCHALTER FUER DEN LAN-WEG.
 *
 * 3 Fehlversuche ODER 3 s Stille -> zurueck auf Cloud (Plan, QUELLENWAHL). Beides ist noetig: ein
 * Nachbar-PC, der auf halber Strecke haengt, antwortet nicht mit einem Fehler, sondern gar nicht —
 * ein reiner Fehlerzaehler zaehlte dann nie und die Anzeige stuende still. Umgekehrt kann eine
 * Gegenstelle jede Anfrage im Millisekundentakt mit 500 beantworten; dann gibt es keine Stille,
 * aber auch keine Daten.
 */
const LAN_FEHLER_MAX = 3;
const LAN_STILLE_MS = 3000;

/*
 * WIE DER LAN-WEG WIEDER ZURUECKKOMMT (Zusatz zum Plantext, der dazu schweigt).
 *
 * Ohne Rueckkehrregel genuegt EIN geglueckter Rahmen, um die Quelle wieder auf LAN zu stellen —
 * bei einer wackligen Leitung wechselt die Anzeige dann im Sekundentakt zwischen 'ueber LAN' und
 * 'ueber Cloud', und der Tierarzt liest daraus einen Fehler, den es nicht gibt. Deshalb muss LAN
 * nach dem Ausloesen LAN_ERHOLUNG_ANZAHL Saetze in Folge liefern, bevor er wieder gilt.
 * Das ist dieselbe Bauform wie tafel.FREMD_STILLE_MS (dort: F1 ist sofort betretbar, zurueck nach
 * F2 erst nach Stille) — eine Hysterese, kein Verbot.
 */
const LAN_ERHOLUNG_ANZAHL = 3;

/*
 * WANN WIDERSPRECHEN SICH ZWEI QUELLEN? (Plan: "weichen in HF/SpO2/EtCO2 oder altMs deutlich ab")
 *
 * Verglichen werden nur Kacheln mit DEMSELBEN Schluessel, und zwar vier Groessen. Die Schwellen
 * sind so gewaehlt, dass sie ueber dem liegen, was die beiden Wege an Laufzeit unterscheiden kann:
 *  hr    10 /min — ein Monitor mittelt die Herzfrequenz ueber mehrere Schlaege und zeigt sie rund
 *                  1x/s neu. Zwei Ablesungen im Abstand einer Sekunde unterscheiden sich darunter,
 *                  ohne dass eine der beiden falsch waere.
 *  sp     3 %    — die Messunsicherheit der Pulsoximetrie liegt nach Geraetespezifikation bei
 *                  etwa 2 %; 3 laesst einen Schritt Luft.
 *  et     5 mmHg — EtCO2 schwankt von Atemzug zu Atemzug legitim um einige mmHg. 5 liegt ueber der
 *                  Schwankung eines einzelnen Atemzugs bei ruhiger Beatmung.
 *  altMs  5000 ms — verglichen wird das WIRKSAME Alter (Alter in der Kachel + Uebertragungsalter),
 *                  also die Frage "wie alt ist diese Messung JETZT". Der Cloud-Weg schreibt
 *                  hoechstens 1x/s, der LAN-Weg alle 250 ms, dazu die Aufloesung der Date-Kopfzeile
 *                  von 1 s — zwei bis drei Sekunden Unterschied sind also normal, fuenf nicht mehr.
 *
 * EHRLICH BENANNT: 5000 ms schliessen NICHT aus, dass die beiden Werte trotzdem in verschiedenen
 * Alterungsstufen liegen (9 s und 13,9 s). Dagegen hilft keine einzelne Zahl. Deshalb entscheidet
 * ein Widerspruch nur die QUELLE und steht im Band — er veraendert keinen einzigen Messwert.
 */
const GRENZWERTE = { hr: 10, sp: 3, et: 5, altMs: 5000 };

// Der Wortlaut, den das Band und das Log tragen. Jede dieser Zeichenketten steht GENAU EINMAL im
// Projekt — zwei Fassungen desselben Satzes sind zwei Aussagen ueber dieselbe Lage.
const TEXT_WIDERSPRUCH = 'Quellen widersprechen sich';
const TEXT_UNBEKANNT = 'Alter unbekannt';

// Speichergrenze fuer die Kinder EINES Saalknotens, bevor ueberhaupt gedeckelt wird. Der Deckel der
// ANZEIGE ist 12 (Kacheln) bzw. 16 (Geraete); diese Zahl schuetzt nur den Arbeitsspeicher des
// OP-PCs gegen einen Nachbarn, der 50000 Kacheln schickt. Dieselbe Groesse wie tafelabo.KINDER_MAX.
const KINDER_MAX = 200;

// Hoechstens eine gleichartige Logzeile je Minute (dieselbe Drossel wie in tafelabo.js).
const MELDE_TAKT_MS = 60000;

// ---------------------------------------------------------------- kleine Bausteine

/*
 * kopfAus/svAus — WORTGLEICH zu den gleichnamigen Hilfen in tafel.js und tafelabo.js.
 *
 * tafel.js haelt sie absichtlich aus dem Export heraus (sie sind Innenleben der Tafel). Nachgebaut
 * wird hier nur diese eine Zeile Bedeutung: "der Kopf liegt unter meta, oder der Eintrag IST der
 * Kopf" und "die Serverzeit sv gilt, ts ist nur Rueckfall". Ein Auseinanderlaufen faellt in
 * tools/fremdstore-test.js auf, der dieselbe Eingabe durch tafel.frischeSaele() schickt.
 */
function kopfAus(eintrag) {
  const e = eintrag || {};
  return (e.meta && typeof e.meta === 'object' && !Array.isArray(e.meta)) ? e.meta : e;
}

function svAus(kopf) {
  const m = kopf || {};
  if (m.sv != null && typeof m.sv !== 'object') return m.sv;
  return m.ts != null ? m.ts : null;
}

// Eine Zahl oder null — nie NaN, nie Unendlich. Kuerzel fuer tafel.zahl(x, 0) an den Stellen, an
// denen eine Dauer in Millisekunden gemeint ist.
function ms(x) { return tafel.zahl(x, 0); }

/*
 * ersatzText(uebertragungMs) — was ANSTELLE der Zahlen steht, sobald ein Saal offline ist.
 *
 * Der Plan verlangt woertlich, dass die Zahlen ab 60 s ERSETZT werden, nicht nur eingefaerbt: ein
 * Blutdruck von 112/64 neben einer laufenden Narkose ist eine Aussage ueber JETZT, und wenn er
 * zwei Minuten alt ist, ist diese Aussage falsch. Deshalb liefert diese Funktion den Text, der an
 * ihre Stelle tritt.
 *
 * Aufgerundet auf ganze Minuten, mindestens 1: '61 s alt' und 'Stand vor 0 min' waeren beide
 * irrefuehrend, weil sie Genauigkeit behaupten, die die Uhrenschaetzung nicht hat.
 */
function ersatzText(uebertragungMs) {
  const m = ms(uebertragungMs);
  if (m == null || m < 0) return TEXT_UNBEKANNT;
  const min = Math.max(1, Math.round(m / 60000));
  return 'Stand vor ' + min + ' min';
}

/*
 * hinweisText(stufe, uebertragungMs) — der Klartext zu einer Alterungsstufe.
 *
 * Wortlaut aus dem Plan-Abschnitt oberflaechen, damit Nachbarstreifen, Web-App und Log fuer
 * denselben Zustand denselben Satz zeigen.
 */
function hinweisText(stufe, uebertragungMs) {
  if (stufe === 'unbekannt') return TEXT_UNBEKANNT;
  const m = ms(uebertragungMs);
  if (stufe === 'alt') return 'keine neuen Daten (' + Math.round((m == null ? 0 : m) / 1000) + 's)';
  if (stufe === 'offline') return 'offline seit ' + Math.max(1, Math.round((m == null ? 0 : m) / 60000)) + ' min';
  /*
   * 'weg' BRAUCHT EINEN SATZ — die Annahme "wird nie gezeigt" war falsch (Gegenpruefung 31.07.2026).
   *
   * _istWeg verwirft einen Saal nur, wenn das JUENGSTE seiner beiden Quellenalter ueber 12 h liegt.
   * Die Stufe rechnet dagegen aus dem Alter der GEWAEHLTEN Quelle. Ist die Cloud-Sicht 13 Stunden
   * alt und der LAN-Weg frisch, bleibt der Saal also stehen und traegt trotzdem stufe='weg'.
   * Ohne Satz und ohne Ersetzen stand damit ein 13 Stunden alter Blutdruck als blanke Zahl neben
   * einer laufenden Narkose — genau das, was der Plan mit "die Zahlen werden ERSETZT" ausschliesst.
   */
  if (stufe === 'weg') return 'seit ueber 12 Stunden nichts empfangen';
  return null;                                    // 'live' braucht keinen Satz
}

/*
 * empfaengt(zeile) — nimmt dieses Geraet gerade wirklich Daten entgegen?
 *
 * NUR FUER DIE DOPPELEMPFANGSERKENNUNG. Ein Geraet, das aus OP 1 nach OP 2 gerollt wurde, steht in
 * der Geraeteliste von OP 1 noch bis zu 90 s als 'standby' und danach als 'offline' (registry.js:
 * ACTIVE_MS 5 s, STANDBY_MS 90 s) — genau das ist der Sinn der vollstaendigen Geraeteliste aus
 * N13. Wer diese Zeilen mitzaehlt, meldet nach JEDEM Umstellen eines Monitors einen Fehlbetrieb,
 * den es nicht gibt, und die Meldung wird danach nicht mehr gelesen.
 *
 * status kommt UNVERAENDERT aus der fremden Registry und wird hier nicht neu gerechnet (dieselbe
 * Regel wie in tafel.geraeteSatz). Fehlt er, entscheidet das Alter: unter der Live-Schwelle
 * (12 s) sendet das Geraet, darueber nicht.
 */
function empfaengt(zeile) {
  const z = zeile;
  if (!z || typeof z !== 'object') return false;
  const st = z.status == null ? null : String(z.status);
  if (st === 'offline' || st === 'standby') return false;
  if (st === 'active') return true;
  const a = ms(z.altMs);
  return a != null && a >= 0 && a < tafel.STUFE_LIVE_MS;
}

/*
 * paare(knoten) — Kacheln oder Geraetezeilen aus BEIDEN Lieferformen.
 *
 * Der Leseweg liefert zwei Formen desselben Zweigs, und beide muessen hier ankommen duerfen:
 *   • der ROHE Datenbankknoten   {"<key>": {...}, "<key2>": {...}}   (tafel/<sid>, LAN-Weg)
 *   • der fertige Satz aus tafelabo.saele()   [{schluessel, werte}, ...]
 * Eine dritte Stelle, die zwischen beiden umformt, waere genau die Stelle, an der irgendwann eine
 * Kachel unter dem Schluessel einer anderen landet.
 *
 * ZUERST SORTIEREN, DANN FALTEN — dieselbe Ueberlegung wie in tafel.auswahl() und tafelabo._kinder():
 * tafel.schluessel() ersetzt jedes Zeichen ausser A-Z a-z 0-9 _ - durch '_', zwei verschiedene
 * Datenbankschluessel ('sw/hund' und 'sw:hund') werden danach zu EINEM. Gewinnt nicht immer
 * derselbe, wechselt die Kachel im Sekundentakt ihren Inhalt.
 */
function paare(knoten) {
  const roh = [];
  if (Array.isArray(knoten)) {
    knoten.forEach((e) => {
      if (!e || typeof e !== 'object') return;
      const k = e.schluessel != null ? e.schluessel : e.key;
      const w = e.werte !== undefined ? e.werte : (e.w !== undefined ? e.w : null);
      if (k != null) roh.push([String(k), w]);
    });
  } else if (knoten && typeof knoten === 'object') {
    Object.keys(knoten).forEach((n) => roh.push([n, knoten[n]]));
  }
  roh.sort((a, b) => (a[0] < b[0] ? -1 : (a[0] > b[0] ? 1 : 0)));
  const liste = [];
  const gesehen = Object.create(null);
  let mehr = 0;
  let doppelt = 0;
  for (let i = 0; i < roh.length; i++) {
    const k = tafel.schluessel(roh[i][0]);
    if (gesehen[k]) { doppelt++; continue; }
    gesehen[k] = true;
    if (liste.length >= KINDER_MAX) { mehr++; continue; }
    liste.push({ k: k, w: roh[i][1] });
  }
  return { liste: liste, mehr: mehr, doppelt: doppelt };
}

/*
 * kopfSatz(meta) — der Saalkopf, Feld fuer Feld benannt.
 *
 * NUR BENANNTE FELDER, kein Durchreichen. Der Kopf kommt von einem fremden Rechner und landet auf
 * einem Bildschirm, der neben einer laufenden Narkose steht; ein unbekanntes Feld hat dort nichts
 * verloren. Die naheliegende Alternative — alles durchlassen und nur kappen, wie tafelabo.saeubere()
 * es tut — hat den Vorteil, dass ein neues Feld in tafel.js hier automatisch ankommt, und den
 * Nachteil, dass ein zweiter Schreiber im Praxiskonto (Privathandy, Tablet am Empfang, kopierte
 * data/cloud-auth.json — alle drei sind im Plan als getragene Restrisiken benannt) beliebige Felder
 * auf den Kiosk legen kann. Gegen das Veralten dieser Liste steht ein Vertragstest: er baut einen
 * Kopf mit tafel.tafelSatz() und prueft, dass jedes Feld daraus hier ueberlebt.
 *
 * sv wird nur als ZAHL uebernommen. Der Serverplatzhalter {".sv":"timestamp"} ist kein Zeitpunkt,
 * sondern eine Anweisung an die Datenbank; ueber den LAN-Weg kann er unaufgeloest ankommen, und
 * ein Objekt an dieser Stelle wuerde jede Altersrechnung still verderben.
 */
function kopfSatz(meta) {
  const m = (meta && typeof meta === 'object' && !Array.isArray(meta)) ? meta : {};
  const satz = {};
  const setzt = (feld, wert) => { if (wert != null) satz[feld] = wert; };
  setzt('sid', tafel.text(m.sid, tafel.GRENZEN.sid));
  setzt('name', tafel.text(m.name, tafel.GRENZEN.spiegelStation));
  setzt('v', tafel.zahl(m.v, 0));
  setzt('bv', tafel.text(m.bv, 24));
  setzt('instanz', tafel.text(m.instanz, 32));
  setzt('ts', tafel.zahl(m.ts, 0));
  if (typeof m.sv === 'number' && Number.isFinite(m.sv)) satz.sv = m.sv;
  setzt('count', tafel.ganz(m.count));
  setzt('ueber', tafel.ganz(m.ueber));
  setzt('ueberG', tafel.ganz(m.ueberG));
  setzt('pri', tafel.zahl(m.pri, 1));
  setzt('al', tafel.ganz(m.al));
  setzt('altMs', tafel.zahl(m.altMs, 0));
  setzt('taktMs', tafel.ganz(m.taktMs));
  if (m.kurven != null) satz.kurven = !!m.kurven;
  setzt('sq', tafel.ganz(m.sq));
  if (m.dop) satz.dop = 1;
  setzt('aus', tafel.zahl(m.aus, 0));
  return satz;
}

/*
 * normalisiere(satz) — aus einer Lieferung wird eine Quellsicht.
 *
 * Rueckgabe {name, meta, kacheln, geraete, mehrK, mehrG, sv, blind, lesestandMs} oder null.
 * 'sv' bleibt hier ROH (Zahl oder null) — ob daraus ein Alter wird, entscheidet erst der Aufrufer
 * mit seiner Uhr.
 *
 * mehrK/mehrG tragen den Deckel der VORSTUFE mit: tafelabo.saele() hat bereits bei 12 Kacheln
 * gekappt und meldet den Rest in weitereKacheln. Ohne diese Uebernahme verschwaende genau diese
 * Zahl auf dem Weg zum Bildschirm — und N17 verlangt, dass der Deckel sichtbar ist, nicht dass er
 * wirkt.
 */
function normalisiere(satz) {
  if (!satz || typeof satz !== 'object' || Array.isArray(satz)) return null;
  const meta = kopfAus(satz);
  if (!meta || typeof meta !== 'object' || Array.isArray(meta)) return null;
  const k = paare(satz.kacheln !== undefined ? satz.kacheln : satz.uebersicht);
  const g = paare(satz.geraete);
  const vorK = tafel.ganz(satz.weitereKacheln) || 0;
  const vorG = tafel.ganz(satz.weitereGeraete) || 0;
  return {
    name: tafel.text(satz.name != null ? satz.name : meta.name, tafel.GRENZEN.spiegelStation),
    meta: kopfSatz(meta),
    kacheln: k.liste,
    geraete: g.liste,
    mehrK: k.mehr + vorK,
    mehrG: g.mehr + vorG,
    sv: svAus(meta),
    // blind/lesestandMs beschreiben den EIGENEN Leser, nicht den Nachbarn (tafelabo, Befund C3).
    // Sie werden durchgereicht, weil ein Nachbarstreifen sonst einem kerngesunden OP-Saal einen
    // Ausfall zuschreibt, den der eigene PC hat.
    blind: satz.blind === true,
    lesestandMs: ms(satz.lesestandMs),
  };
}

/*
 * patientSatz(key, werte, uebertragungMs, ersetzt) — EINE Kachel fuer den Rundruf.
 *
 * Feldsatz wortgenau nach dem Plan-Abschnitt oberflaechen:
 *   key, pid, n, a, g, hr, sp, et, af, sys, dia, map, t, rh, pri, top, al, altMs
 *
 * altMs IST DIE SUMME aus dem Alter in der Kachel (Dauer, an der Quelle gemessen) und dem
 * Uebertragungsalter — genau die Rechnung "altMs + (Serverzeit - sv)" aus dem Plan. Nur so steht
 * dort, wie alt die Messung JETZT ist, und nicht, wie alt sie beim Absenden war.
 *
 * ERSETZT STATT GEZEIGT (Plan, oberflaechen): ab der Stufe 'offline' fallen ALLE Messwerte weg und
 * an ihre Stelle tritt ersatz='Stand vor X min'. Stehen bleiben Schluessel, pid, Name, Tierart und
 * Gewicht — das ist die Identitaet des Tiers und veraltet nicht in der gefaehrlichen Richtung.
 * Auch pri und al fallen weg: beide sind aus Messwerten abgeleitet, und eine zwei Minuten alte
 * Prioritaetsfarbe neben einer laufenden Narkose ist dieselbe Luege wie ein zwei Minuten alter
 * Blutdruck. Weggelassen wird, nicht auf null gesetzt — dieselbe Regel wie in tafel.uebersichtSatz.
 */
function patientSatz(key, werte, uebertragungMs, ersetzt) {
  const w = (werte && typeof werte === 'object' && !Array.isArray(werte)) ? werte : {};
  const satz = { key: tafel.schluessel(key) };
  const setzt = (feld, wert) => { if (wert != null) satz[feld] = wert; };

  setzt('pid', tafel.text(w.pid, tafel.GRENZEN.tafelText));
  setzt('n', tafel.text(w.n, tafel.GRENZEN.tafelText));
  setzt('a', tafel.text(w.a, 24));
  setzt('g', tafel.zahl(w.g, 1));

  const roh = ms(w.altMs);
  const ueb = ms(uebertragungMs);
  const alt = (roh != null && roh >= 0 && ueb != null && ueb >= 0) ? roh + ueb : null;

  if (ersetzt) {
    satz.ersetzt = true;
    satz.ersatz = ersatzText(ueb);
    setzt('altMs', alt);
    return satz;
  }

  setzt('hr', tafel.zahl(w.hr, 0));
  setzt('sp', tafel.zahl(w.sp, 0));
  setzt('et', tafel.zahl(w.et, 1));
  setzt('af', tafel.zahl(w.af, 0));
  setzt('sys', tafel.zahl(w.sys, 0));
  setzt('dia', tafel.zahl(w.dia, 0));
  setzt('map', tafel.zahl(w.map, 0));
  setzt('t', tafel.zahl(w.t, 1));
  setzt('rh', tafel.text(w.rh, 24));
  setzt('pri', tafel.zahl(w.pri, 1));
  setzt('top', tafel.text(w.top, tafel.GRENZEN.tafelText));
  setzt('al', tafel.ganz(w.al));
  setzt('altMs', alt);
  return satz;
}

/*
 * geraeteZeile(id, werte, uebertragungMs) — EINE Geraetezeile (N13).
 *
 * Feldnamen wortgenau wie in tafel.geraeteSatz() und damit wie im Koppel-Dialog vor Ort: fern soll
 * dasselbe stehen wie lokal, eine zweite Namenswelt waere nur eine weitere Fehlerquelle.
 * altMs ist auch hier die Summe aus Alter an der Quelle und Uebertragungsalter.
 */
function geraeteZeile(id, werte, uebertragungMs) {
  const w = (werte && typeof werte === 'object' && !Array.isArray(werte)) ? werte : {};
  const satz = { id: tafel.schluessel(id) };
  const setzt = (feld, wert) => { if (wert != null) satz[feld] = wert; };
  setzt('model', tafel.text(w.model, tafel.GRENZEN.tafelText));
  setzt('role', tafel.text(w.role, 24));
  setzt('status', tafel.text(w.status, 16));
  setzt('ip', tafel.text(w.ip, tafel.GRENZEN.adresse));
  setzt('port', tafel.ganz(w.port));
  setzt('transport', tafel.text(w.transport, 24));
  setzt('taktMs', tafel.ganz(w.taktMs));
  setzt('werteAnzahl', tafel.ganz(w.werteAnzahl));
  if (w.patientKey != null) satz.patientKey = tafel.schluessel(w.patientKey);
  const roh = ms(w.altMs);
  const ueb = ms(uebertragungMs);
  setzt('altMs', (roh != null && roh >= 0 && ueb != null && ueb >= 0) ? roh + ueb : null);
  return satz;
}

// ---------------------------------------------------------------- reine Entscheidungen

/*
 * sortiereSaele(liste) — stabile Reihenfolge: erst Saalname, dann Stationskennung.
 *
 * Dieselbe Regel wie in tafel.js und tafelabo.js. Sie steht hier zum dritten Mal, weil diese Datei
 * an KEINEM anderen Projektmodul haengen darf (siehe Kopfkommentar) und tafel.frischeSaele() eine
 * andere Liste liefert: dort fallen Saele nach 60 s Stille heraus, hier muessen sie als 'offline'
 * stehen bleiben. Gegen das Auseinanderlaufen steht ein Vertragstest, der dieselbe Eingabe durch
 * tafelabo.sortiereSaele() schickt und die Reihenfolge vergleicht.
 *
 * KOPIERT STATT GEAENDERT: die uebergebene Liste gehoert dem Aufrufer (dieselbe Ueberlegung wie in
 * tafel.tafelPfade beim Saalkopf). tafelabo.sortiereSaele sortiert an Ort und Stelle — wer beide
 * nebeneinander benutzt, soll sich auf die harmlosere Fassung verlassen koennen.
 */
function sortiereSaele(liste) {
  const l = Array.isArray(liste) ? liste.filter((x) => x && typeof x === 'object') : [];
  return l.slice().sort((a, b) => {
    const an = a.name || '', bn = b.name || '';
    if (an < bn) return -1;
    if (an > bn) return 1;
    const as = String(a.sid == null ? '' : a.sid), bs = String(b.sid == null ? '' : b.sid);
    if (as < bs) return -1;
    if (as > bs) return 1;
    return 0;
  });
}

/*
 * kappeSaele(liste, max) — der Saal-Deckel, sichtbar (N17).
 *
 * Rueckgabe {saele, mehr, weitereListe, hinweis}. 'mehr' ist eine ZAHL, damit Band, Log und
 * /api/nachbarn sie ausgeben koennen, ohne einen Text zu zerlegen; 'weitereListe' nennt die
 * verdraengten Saele NAMENTLICH, weil "einer fehlt" ohne "welcher" keine brauchbare Auskunft ist.
 * Gekappt wird erst NACH dem Sortieren — sonst haengt es an der Reihenfolge der Datenbank, welcher
 * OP-Saal verschwindet.
 */
function kappeSaele(liste, max) {
  const l = Array.isArray(liste) ? liste.filter((x) => x && typeof x === 'object') : [];
  const m = Math.max(1, Math.floor(Number(max) || tafel.GRENZEN.saele));
  const genommen = l.slice(0, m);
  const rest = l.slice(m);
  return {
    saele: genommen,
    mehr: rest.length,
    weitereListe: rest.map((s) => ({ sid: String(s.sid == null ? '' : s.sid), name: s.name || null })),
    hinweis: rest.length
      ? (rest.length + ' weitere OP-Saele werden nicht angezeigt — Deckel erreicht')
      : null,
  };
}

/*
 * quellenwahl(lage) — welche der beiden Quellen gilt fuer DIESEN Saal?
 *
 * lage = {lanDa, lanStilleMs, lanFehler, lanGesperrt, cloudDa, widerspruch, fehlerMax, stilleMaxMs}
 * Rueckgabe {quelle:'lan'|'cloud'|'aus', grund, widerspruch}
 *
 * DIE REIHENFOLGE DER REGELN IST DIE AUSSAGE:
 *  1. Widerspruch -> Cloud. Ohne Ausnahme, solange es eine Cloud-Sicht gibt. LAN darf die Laufzeit
 *     ueberholen, nie die Wahrheit.
 *  2. LAN, wenn er frisch ist: kein ausgeloester Sicherungsschalter, weniger als fehlerMax
 *     Fehlversuche, und die letzte Lieferung liegt hoechstens stilleMaxMs zurueck.
 *  3. sonst Cloud, mit dem Grund im Klartext — 'wir sind auf Cloud' ohne 'warum' ist im Admin-
 *     Bereich nutzlos.
 *  4. Gibt es GAR KEINE Cloud-Sicht, gilt weiter LAN, auch wenn er alt ist. Eine alte Zahl mit
 *     ehrlichem Alter ist besser als eine leere Karte; wie alt sie ist, sagt die Alterungsstufe.
 *  5. sonst 'aus'.
 *
 * Ein unbekanntes lanStilleMs (null) zaehlt wie Stille: wer nicht sagen kann, wann zuletzt etwas
 * kam, hat keinen frischen Weg.
 */
function quellenwahl(lage) {
  const l = lage || {};
  const fehlerMax = Math.max(1, Math.floor(Number(l.fehlerMax) || LAN_FEHLER_MAX));
  const stilleMax = Math.max(1, Math.floor(Number(l.stilleMaxMs) || LAN_STILLE_MS));
  const lanDa = !!l.lanDa;
  const cloudDa = !!l.cloudDa;
  const widerspruch = !!l.widerspruch;
  const fehler = Math.max(0, Math.floor(Number(l.lanFehler) || 0));
  const stille = ms(l.lanStilleMs);

  if (widerspruch && cloudDa) return { quelle: 'cloud', grund: 'widerspruch', widerspruch: true };

  const lanFrisch = lanDa && !l.lanGesperrt && fehler < fehlerMax
    && stille != null && stille >= 0 && stille <= stilleMax;
  if (lanFrisch) return { quelle: 'lan', grund: 'lan-frisch', widerspruch: widerspruch };

  if (cloudDa) {
    // Reihenfolge der Gruende: der FRISCHE Befund zuerst. Direkt nach dem Ausloesen stehen die
    // Fehlversuche noch da ('lan-fehlversuche'); erst wenn wieder Saetze ankommen und nur noch die
    // Sperre offen ist, heisst es 'lan-erholt-sich'. Umgekehrt gelesen waere im Admin-Bereich der
    // Grund fuer das Umschalten nie zu sehen.
    let grund = 'nur-cloud';
    if (lanDa && fehler >= fehlerMax) grund = 'lan-fehlversuche';
    else if (lanDa && l.lanGesperrt) grund = 'lan-erholt-sich';
    else if (lanDa) grund = 'lan-stille';
    return { quelle: 'cloud', grund: grund, widerspruch: widerspruch };
  }

  if (lanDa) return { quelle: 'lan', grund: 'nur-lan', widerspruch: widerspruch };
  return { quelle: 'aus', grund: 'keine-quelle', widerspruch: false };
}

/*
 * widerspruchAus(lanSicht, cloudSicht, grenzen) — sagen die beiden Quellen dasselbe?
 *
 * Jede Sicht ist {kacheln:[{k,w}], uebertragungMs}. Verglichen werden nur Kacheln mit DEMSELBEN
 * Schluessel; die Schwellen und ihre Begruendung stehen bei GRENZWERTE.
 *
 * EIN SCHLUESSEL, DEN NUR EINE SEITE FUEHRT, IST KEIN WIDERSPRUCH — er wird als 'unvergleichbar'
 * gezaehlt. Grund: der LAN-Weg laeuft mit 250 ms, der Cloud-Weg mit 1000 ms; ein Patient, der
 * gerade angemeldet oder beendet wurde, steht darum regelmaessig einen Takt lang nur auf einer
 * Seite. Wer das als Widerspruch meldet, meldet ihn bei JEDEM Patientenwechsel — und eine Warnung,
 * die bei einem normalen Vorgang erscheint, wird nach zwei Wochen nicht mehr gelesen.
 *
 * ZWEI VOLLSTAENDIG DISJUNKTE LISTEN SIND TROTZDEM EINER. Ein Wettlauf betrifft einen Patienten,
 * nicht die ganze Liste: fuehren beide Seiten Kacheln und ist keine einzige gemeinsam, beschreiben
 * sie zwei verschiedene Saele. Das ist der Fall, den der Plan mit "gelieferte sid == erwartete sid"
 * meint — nur dass er hier auch dann auffaellt, wenn die sid stimmt und der Inhalt nicht.
 */
function widerspruchAus(lanSicht, cloudSicht, grenzen) {
  const g = Object.assign({}, GRENZWERTE, grenzen || {});
  const nein = { widerspruch: false, gruende: [], verglichen: 0, unvergleichbar: 0 };
  const L = lanSicht, C = cloudSicht;
  if (!L || !C || !Array.isArray(L.kacheln) || !Array.isArray(C.kacheln)) return nein;

  const abbL = Object.create(null);
  const abbC = Object.create(null);
  L.kacheln.forEach((e) => { if (e && abbL[e.k] === undefined) abbL[e.k] = e.w || {}; });
  C.kacheln.forEach((e) => { if (e && abbC[e.k] === undefined) abbC[e.k] = e.w || {}; });

  const gruende = [];
  let verglichen = 0, unvergleichbar = 0;
  const uebL = ms(L.uebertragungMs);
  const uebC = ms(C.uebertragungMs);

  Object.keys(abbL).sort().forEach((k) => {
    if (abbC[k] === undefined) { unvergleichbar++; return; }
    verglichen++;
    const a = abbL[k], b = abbC[k];
    [['hr', 'HF', 0], ['sp', 'SpO2', 0], ['et', 'EtCO2', 1]].forEach((f) => {
      const va = tafel.zahl(a[f[0]], f[2]);
      const vb = tafel.zahl(b[f[0]], f[2]);
      if (va == null || vb == null) return;
      if (Math.abs(va - vb) > g[f[0]]) {
        gruende.push(k + ': ' + f[1] + ' LAN ' + va + ', Cloud ' + vb);
      }
    });
    /*
     * DER ALTERSVERGLEICH GILT NUR, WENN BEIDE WEGE FRISCH SIND — und das ist keine Feinheit,
     * sondern die Reparatur eines schweren Befundes (Gegenpruefung 31.07.2026).
     *
     * Vorher wurde jederzeit verglichen. Faellt das Internet aus — der HAEUFIGSTE Stoerfall und
     * genau der, fuer den Stufe 2 gebaut ist —, friert die letzte Cloud-Momentaufnahme ein, der
     * LAN-Weg liefert weiter live. Der Altersunterschied ist dann garantiert groesser als die
     * Schwelle, also ist der Widerspruch garantiert, also gewinnt "bei Widerspruch gewinnt die
     * Cloud" ohne Ausnahme. Ergebnis: der Nachbarsaal wird als "offline seit 30 min" mit
     * ersetzten Zahlen gemeldet, waehrend nebenan eine HF von 150 live vorliegt. Der LAN-Weg
     * waere damit genau dann wirkungslos, wenn er gebraucht wird.
     *
     * Die Regel "bei Widerspruch gewinnt die Cloud" war gegen abweichende MESSWERTE gedacht: zwei
     * Wege, die verschiedene Zahlen fuer dasselbe Tier nennen. Ein Altersunterschied ist keine
     * abweichende Messung, sondern der normale Laufzeitunterschied — und wenn eine Quelle
     * stillsteht, ist er kein Widerspruch, sondern ihr Ausfall. Deshalb: Alter nur vergleichen,
     * solange BEIDE Wege innerhalb der Live-Schwelle liefern. Ist einer davon alt, entscheidet
     * die Alterung (der Saal steht mit seiner ehrlichen Stufe da), nicht der Widerspruch.
     */
    const altA = ms(a.altMs), altB = ms(b.altMs);
    const beideFrisch = uebL != null && uebC != null
      && uebL < tafel.STUFE_LIVE_MS && uebC < tafel.STUFE_LIVE_MS;
    if (beideFrisch && altA != null && altB != null) {
      const wa = altA + uebL, wb = altB + uebC;
      if (Math.abs(wa - wb) > g.altMs) {
        gruende.push(k + ': Alter LAN ' + wa + ' ms, Cloud ' + wb + ' ms');
      }
    }
  });
  Object.keys(abbC).forEach((k) => { if (abbL[k] === undefined) unvergleichbar++; });

  const lZahl = Object.keys(abbL).length, cZahl = Object.keys(abbC).length;
  if (verglichen === 0 && lZahl > 0 && cZahl > 0) {
    gruende.push('kein gemeinsamer Patient: LAN fuehrt ' + lZahl + ', die Cloud ' + cZahl);
  }
  /*
   * EINE LEERE LISTE GEGEN EINE GEFUELLTE IST EBENFALLS EIN WIDERSPRUCH (Gegenpruefung 31.07.2026).
   *
   * Vorher wurde der Fall nur gemeldet, wenn BEIDE Seiten Kacheln fuehrten. Fuehrte der LAN-Weg
   * null Kacheln, gab es weder Widerspruch noch Hinweis, und der frische LAN-Weg gewann die
   * Quellenwahl: ein OP-Saal mit zwei narkotisierten Patienten stand als LEER im Nachbarstreifen.
   * Ausloesbar durch einen gerade neu gestarteten Nachbarn oder eine abgeschnittene Antwort.
   *
   * Warum das anders liegt als der Wettlauf um EINEN Patienten (der bewusst nicht gemeldet wird):
   * ein Wettlauf betrifft einen Schluessel, nicht die ganze Liste. "Diese Quelle kennt ueberhaupt
   * keinen Patienten, die andere zwei" ist keine Taktverschiebung, sondern eine Aussage darueber,
   * dass eine der beiden Quellen gerade nichts weiss.
   */
  if (lZahl === 0 && cZahl > 0) {
    gruende.push('der LAN-Weg fuehrt keinen Patienten, die Cloud ' + cZahl);
  }
  if (cZahl === 0 && lZahl > 0) {
    gruende.push('die Cloud fuehrt keinen Patienten, der LAN-Weg ' + lZahl);
  }

  return {
    widerspruch: gruende.length > 0,
    gruende: gruende,
    verglichen: verglichen,
    unvergleichbar: unvergleichbar,
  };
}

/*
 * verlegungenAus(saele) — derselbe Patient in zwei OP-Saelen.
 *
 * AUSSCHLIESSLICH UEBER GLEICHE, NICHT LEERE pid. Eine leere pid darf NIE zwei Patienten
 * verschmelzen: der patientKey ist bei zwei 22-kg-Hunden in beiden Saelen 'sw_hund_22' (die
 * Schluesselwahl bleibt laut Plan unveraendert), und ohne eingetragene Patienten-ID ist pid leer
 * oder gleicht dem Ersatzschluessel. Wer hier eine leere pid mitzaehlt, erklaert zwei fremde Tiere
 * zu einem — das ist der Weg, den der Plan als toedlich beschreibt (Messwerte des Tiers aus Saal 1
 * unter dem Namen des Tiers in Saal 2).
 *
 * NICHT NORMALISIERT ausser fuehrenden/folgenden Leerzeichen: zwei Schreibweisen sind zwei
 * Patienten. Wer hier Gross- und Kleinschreibung angleicht oder Trennzeichen entfernt, verschmilzt
 * Tiere, deren Kennungen sich nur darin unterscheiden.
 *
 * ZWEI EINTRAEGE BLEIBEN ZWEI EINTRAEGE. Zusammengefuehrt wird nichts — das Ergebnis nennt nur, in
 * welchen Saelen dieselbe pid gefuehrt wird. Zusammengelegt wird laut Plan ausschliesslich Papier.
 */
function verlegungenAus(saele) {
  const proPid = Object.create(null);
  (Array.isArray(saele) ? saele : []).forEach((s) => {
    if (!s || typeof s !== 'object') return;
    const sid = String(s.sid == null ? '' : s.sid);
    if (!sid) return;
    const schonHier = Object.create(null);        // dieselbe pid zweimal im SELBEN Saal ist keine Verlegung
    (Array.isArray(s.patients) ? s.patients : []).forEach((p) => {
      if (!p || typeof p !== 'object') return;
      const pid = String(p.pid == null ? '' : p.pid).trim();
      if (!pid) return;
      if (schonHier[pid]) return;
      schonHier[pid] = true;
      if (!proPid[pid]) proPid[pid] = [];
      proPid[pid].push({ sid: sid, name: s.name || null });
    });
  });
  const raus = [];
  Object.keys(proPid).sort().forEach((pid) => {
    const orte = proPid[pid];
    if (orte.length < 2) return;
    raus.push({
      pid: pid,
      saele: orte.map((o) => o.sid),
      namen: orte.map((o) => o.name),
    });
  });
  return raus;
}

/*
 * doppelempfang(saele) — dasselbe Geraet sendet an ZWEI Stationen.
 *
 * UEBER DIE VOLLSTAENDIGE GERAETELISTE (N13), nicht ueber das Kachelfeld dv. dv presst
 * '<deviceId>@<ip>' in eine gekuerzte Zeichenkette; zwei verschiedene IPv6-Adressen ergaben damit
 * denselben Eintrag und die Erkennung meldete einen Aufbaufehler, den es nicht gab (Befund B7 in
 * tafel.js). Die Geraeteliste traegt die deviceId als eigenen Schluessel — sie ist die Identitaet.
 *
 * DAS IST EIN ECHTER FEHLBETRIEB und wird im Klartext gemeldet: ein Monitor kann seine Daten nicht
 * an zwei Stationen gleichzeitig schicken, ohne dass eine der beiden ein unvollstaendiges Bild
 * bekommt — und beide zeigen es als vollstaendig. diagnose.js bekommt dafuer laut Plan-Schritt 20
 * einen eigenen Befund; der Text hier ist die Vorlage dafuer.
 *
 * Gezaehlt wird nur, was gerade WIRKLICH empfaengt (siehe empfaengt()): sonst meldet jedes
 * Umstellen eines Geraets von OP 1 nach OP 2 fuer anderthalb Minuten einen Fehlbetrieb.
 */
function doppelempfang(saele) {
  const proId = Object.create(null);
  (Array.isArray(saele) ? saele : []).forEach((s) => {
    if (!s || typeof s !== 'object') return;
    const sid = String(s.sid == null ? '' : s.sid);
    if (!sid) return;
    const schonHier = Object.create(null);
    (Array.isArray(s.geraete) ? s.geraete : []).forEach((z) => {
      if (!z || typeof z !== 'object') return;
      const id = String(z.id == null ? '' : z.id);
      if (!id || !empfaengt(z)) return;
      if (schonHier[id]) return;
      schonHier[id] = true;
      if (!proId[id]) proId[id] = [];
      proId[id].push({ sid: sid, name: s.name || null, model: z.model || null });
    });
  });
  const raus = [];
  Object.keys(proId).sort().forEach((id) => {
    const orte = proId[id];
    if (orte.length < 2) return;
    const wo = orte.map((o) => o.name || o.sid).join(', ');
    const modell = orte[0].model ? (' (' + orte[0].model + ')') : '';
    raus.push({
      id: id,
      saele: orte.map((o) => o.sid),
      namen: orte.map((o) => o.name),
      text: 'Das Geraet ' + id + modell + ' sendet gleichzeitig an mehrere Stationen: ' + wo
        + ' — ein Geraet darf nur an EINER Station haengen, sonst hat jede von beiden ein '
        + 'unvollstaendiges Bild und zeigt es als vollstaendig.',
    });
  });
  return raus;
}

// ---------------------------------------------------------------- der Speicher

class Fremdstore {
  /*
   * eigeneSid und eigeneInstanz duerfen WERTE ODER FUNKTIONEN sein (dasselbe Muster wie
   * tafelabo.js bei uid/sid). Grund: beim ersten Takt steht die eigene Kennung noch nicht fest —
   * sie entsteht in stationsid.js und die Instanz erst beim Prozessstart. Waere nur ein Wert
   * erlaubt, muesste der Aufrufer den Speicher spaeter noch einmal anfassen, und bis dahin haette
   * die Station sich selbst als Nachbarsaal gefuehrt.
   */
  constructor(opts) {
    const o = opts || {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    this._eigeneSid = o.eigeneSid;
    this._eigeneInstanz = o.eigeneInstanz;
    this.saeleMax = Math.max(1, Math.floor(Number(o.saeleMax) || tafel.GRENZEN.saele));
    this.kachelnMax = Math.max(1, Math.floor(Number(o.kachelnMax) || tafel.GRENZEN.kacheln));
    this.geraeteMax = Math.max(1, Math.floor(Number(o.geraeteMax) || tafel.GRENZEN.geraete));
    // Auch der Sicherungsschalter ist einstellbar — nicht der Bequemlichkeit wegen: ein Test, der
    // drei echte Sekunden wartet, wird irgendwann herausgenommen, und dann prueft niemand mehr die
    // Zahl, an der die Quellenwahl haengt (dieselbe Ueberlegung wie tafelabo.erneuernSperreMs).
    this.lanFehlerMax = Math.max(1, Math.floor(Number(o.lanFehlerMax) || LAN_FEHLER_MAX));
    this.lanStilleMs = Math.max(1, Math.floor(Number(o.lanStilleMs) || LAN_STILLE_MS));
    this.lanErholungAnzahl = Math.max(1, Math.floor(Number(o.lanErholungAnzahl) || LAN_ERHOLUNG_ANZAHL));
    this.grenzwerte = Object.assign({}, GRENZWERTE, o.grenzwerte || {});

    this._saele = new Map();          // sid -> Eintrag (siehe _eintrag)
    this._gemeldet = Object.create(null);
    this._zaehler = { cloud: 0, lan: 0, lanFehler: 0, entfernt: 0, gealtert: 0 };
    this._verworfen = { sid: 0, eigen: 0, leer: 0, unbekannteSid: 0 };
    this._letzteWahl = Object.create(null);   // sid -> {quelle, grund, widerspruch} vom letzten Blick
  }

  // ---------------------------------------------------------------- eigene Kennung
  eigeneSid() {
    const q = this._eigeneSid;
    const v = typeof q === 'function' ? q() : q;
    return v ? String(v) : null;
  }

  eigeneInstanz() {
    const q = this._eigeneInstanz;
    const v = typeof q === 'function' ? q() : q;
    return v ? String(v) : null;
  }

  /*
   * istEigen(sid, meta) — bin ich das selbst?
   *
   * ZWEI MERKMALE, weil eines nicht reicht (Plan, QUELLENWAHL, Befund A2-8, dort als toedlich
   * gefuehrt): docs/LAN-SETUP.md schreibt JEDEM Praxis-PC die Adresse 192.168.0.99 vor, ein
   * LAN-Weg kann also auf den eigenen Rechner zurueckzeigen. Gleiche sid ist der eine Beweis,
   * gleiche instanz der andere — instanz ist bei jedem Prozessstart neu und damit auch dann
   * eindeutig, wenn zwei Rechner dieselbe Kennung tragen (geklonte Platte). Ohne diese Pruefung
   * spricht die Station mit sich selbst und beschriftet es als Nachbarsaal.
   */
  istEigen(sid, meta) {
    const e = this.eigeneSid();
    if (e && String(sid) === e) return true;
    const i = this.eigeneInstanz();
    if (!i) return false;
    const m = kopfAus(meta || {});
    return !!(m && m.instanz != null && String(m.instanz) === i);
  }

  // ---------------------------------------------------------------- Eingang
  /*
   * ausCloud/ausLan — EINE Lieferung fuer EINEN Saal.
   *
   * 'jetzt' wird mitgeschrieben und ist der Empfangszeitpunkt. Er ist fuer den LAN-Weg die einzige
   * brauchbare Alterszeit (siehe _uebertragung) und fuer beide Wege die Grundlage der
   * Stille-Erkennung. Rueckgabe true/false, damit der Aufrufer und der Test sehen, ob die
   * Lieferung angenommen wurde — ein stilles Verwerfen waere hier dasselbe wie ein lautlos
   * verschwundener OP-Saal.
   */
  ausCloud(sid, satz, jetzt) { return this._aufnehmen('cloud', sid, satz, jetzt); }
  ausLan(sid, satz, jetzt) { return this._aufnehmen('lan', sid, satz, jetzt); }

  _aufnehmen(quelle, sid, satz, jetzt) {
    const s = String(sid == null ? '' : sid);
    if (!tafel.pruefeSid(s)) {
      // Eine unbrauchbare Kennung kommt hier nie in einen Pfad (dieser Speicher schreibt nichts),
      // aber sie kaeme in eine Anzeige und in /api/nachbarn/<sid>. Ein Saal, den man nicht wieder
      // aufrufen kann, ist keine Auskunft.
      this._verworfen.sid++;
      return false;
    }
    const sicht = normalisiere(satz);
    if (!sicht) { this._verworfen.leer++; return false; }
    if (this.istEigen(s, sicht.meta)) { this._verworfen.eigen++; return false; }

    const e = this._eintrag(s);
    const j = ms(jetzt);
    sicht.empfangen = j;
    if (quelle === 'lan') {
      e.lan = sicht;
      e.lanEmpfangen = j;
      this._zaehler.lan++;
      /*
       * Ein geglueckter Satz setzt den Fehlerzaehler zurueck — aber die SPERRE loest er erst nach
       * lanErholungAnzahl Saetzen in Folge. Warum, steht bei LAN_ERHOLUNG_ANZAHL.
       */
      e.lanFehlerZahl = 0;
      if (e.lanGesperrt) {
        e.lanErholung++;
        if (e.lanErholung >= this.lanErholungAnzahl) { e.lanGesperrt = false; e.lanErholung = 0; }
      }
    } else {
      e.cloud = sicht;
      e.cloudEmpfangen = j;
      this._zaehler.cloud++;
    }
    return true;
  }

  /*
   * lanFehler(sid, grund) — ein Fehlversuch auf dem LAN-Weg.
   *
   * Zaehlt auf den Sicherungsschalter ein. Ab lanFehlerMax gilt er als ausgeloest, und dann bleibt
   * er es, bis der LAN-Weg sich erholt hat (siehe _aufnehmen). Der Grund wird im Klartext behalten
   * und in status() gezeigt: 'wir sind auf Cloud' ohne 'warum' ist im Admin-Bereich nutzlos.
   *
   * Ein Fehler fuer eine noch unbekannte Kennung legt KEINEN Saal an. Sonst stuende nach einem
   * fehlgeschlagenen Anklopfen ein leerer Saal in der Tafel, den es nie gab.
   */
  lanFehler(sid, grund) {
    const s = String(sid == null ? '' : sid);
    const e = this._saele.get(s);
    if (!e) { this._verworfen.unbekannteSid++; return false; }
    e.lanFehlerZahl++;
    e.lanFehlerGrund = tafel.text(grund, tafel.GRENZEN.wert);
    /*
     * DIE ERHOLUNG MUSS "IN FOLGE" SEIN — sonst ist die Hysterese keine (Gegenpruefung 31.07.2026).
     *
     * Ohne diese Zeile sammelt eine wacklige Leitung, die abwechselnd einen Satz liefert und einen
     * Fehlversuch produziert, die drei Erholungsschritte trotzdem ein und schaltet zurueck auf LAN.
     * Damit flattert die Quellenangabe im Sekundentakt zwischen "direkt im Haus" und
     * "Praxis-Konto" — genau das, wogegen LAN_ERHOLUNG_ANZAHL gebaut wurde. Ein Fehlversuch setzt
     * die Zaehlung deshalb auf null, nicht nur die Sperre.
     */
    e.lanErholung = 0;
    this._zaehler.lanFehler++;
    if (e.lanFehlerZahl >= this.lanFehlerMax && !e.lanGesperrt) {
      e.lanGesperrt = true;
      e.lanErholung = 0;
      this.log.warn('nachbarn', 'Der LAN-Weg zu ' + s + ' hat ' + e.lanFehlerZahl
        + ' Fehlversuche — dieser OP-Saal wird bis auf weiteres ueber die Cloud gelesen.'
        + (e.lanFehlerGrund ? ' Zuletzt: ' + e.lanFehlerGrund : ''));
    }
    return true;
  }

  entferne(sid) {
    const s = String(sid == null ? '' : sid);
    const weg = this._saele.delete(s);
    if (weg) { this._zaehler.entfernt++; delete this._letzteWahl[s]; }
    return weg;
  }

  _eintrag(sid) {
    let e = this._saele.get(sid);
    if (!e) {
      e = {
        sid: sid,
        cloud: null, lan: null,
        cloudEmpfangen: null, lanEmpfangen: null,
        lanFehlerZahl: 0, lanFehlerGrund: null, lanGesperrt: false, lanErholung: 0,
      };
      this._saele.set(sid, e);
    }
    return e;
  }

  // ---------------------------------------------------------------- Ausgabe
  /*
   * saele(jetzt) — die fertige Sicht: sortiert, gedeckelt, mit Alterungsstufe.
   * rundruf(jetzt) und verlegungen(jetzt) gehen ueber DIESELBE Rechnung (_sicht). Zwei Wege zu
   * derselben Aussage waeren zwei Aussagen — das ist der Fehler, den tafel.js mit saalListe()
   * ausdruecklich beseitigt hat (Befund A3).
   */
  saele(jetzt) { return this._sicht(jetzt).saele; }

  rundruf(jetzt) {
    const s = this._sicht(jetzt);
    return { ts: s.jetzt, saele: s.saele, mehr: s.mehr, hinweise: s.hinweise };
  }

  verlegungen(jetzt) { return this._sicht(jetzt).verlegungen; }

  /*
   * _uebertragung(sicht, quelle, jetzt) — wie alt ist diese Lieferung?
   *
   * CLOUD: gegen die SERVERZEIT sv. Sie setzt die Datenbank selbst, sie haengt an keiner
   * Schreibleitung und ueberlebt jeden Uhrenversatz zwischen zwei Praxis-PCs (deshalb wurde die
   * Rechnung "eigenes sv minus fremdes sv" im Plan verworfen). Fehlt sv, gilt ts als Rueckfall —
   * und der ist eine Zahl, die der Schreiber frei waehlt; genau deshalb steht die 12-h-Grenze
   * daneben.
   *
   * LAN: gegen den EIGENEN Empfangszeitpunkt, ausdruecklich NICHT gegen den mitgelieferten
   * Zeitstempel. Der Nachbar liefert ueber LAN seine eigene Tafelfassung; ihr sv ist entweder der
   * unaufgeloeste Serverplatzhalter oder seine eigene PC-Uhr. Beides ist schlechter als die
   * Frage "wann hat unser Rechner diesen Satz zuletzt bekommen?" — die haengt an genau EINER Uhr,
   * unserer, und die verwendet der Aufrufer ohnehin fuer alles andere auch.
   *
   * Ein negatives Alter ergibt NIE 0, sondern null = 'Alter unbekannt' (N16). Das ist die
   * Kernzusage: ein Saal, dessen Uhr vorgeht, waere sonst dauerhaft brandaktuell — 0 ms alt,
   * gruen, mit seinen letzten Vitalwerten.
   */
  _uebertragung(sicht, quelle, jetzt) {
    if (!sicht) return null;
    if (quelle === 'lan') return tafel.alterMs(sicht.empfangen, jetzt);
    return tafel.alterMs(sicht.sv, jetzt);
  }

  /*
   * _sicht(jetzt) — die eine Rechnung.
   *
   * Reihenfolge: altern (und ueber 12 h ersatzlos entfernen) -> Quelle je Saal waehlen -> Saetze
   * bauen -> sortieren -> deckeln -> Verlegungen und Doppelempfang ueber die SICHTBAREN Saele ->
   * Hinweise als Klartext.
   *
   * VERLEGUNG UND DOPPELEMPFANG WERDEN ERST NACH DEM DECKEL GERECHNET. Ein Hinweis "auch in OP 9"
   * auf einen Saal, den der Deckel gerade weggeschnitten hat, waere ein Verweis ins Leere. Dass
   * der Deckel damit auch eine Erkennung verdecken kann, ist der Preis — er steht als Zahl und als
   * Klartext im selben Ergebnis, sodass es niemandem entgeht.
   */
  _sicht(jetzt) {
    const j = ms(jetzt);
    const roh = [];

    for (const sid of Array.from(this._saele.keys())) {
      const e = this._saele.get(sid);
      if (!e) continue;

      // Die eigene Kennung kann erst nach dem ersten Takt feststehen (siehe Konstruktor): was
      // beim Eingang noch nicht als eigen erkennbar war, faellt spaetestens hier heraus.
      if (this.istEigen(sid, (e.cloud && e.cloud.meta) || (e.lan && e.lan.meta))) {
        this._verworfen.eigen++;
        this._saele.delete(sid);
        delete this._letzteWahl[sid];
        continue;
      }

      const uebC = this._uebertragung(e.cloud, 'cloud', j);
      const uebL = this._uebertragung(e.lan, 'lan', j);

      if (this._istWeg(e, uebC, uebL, j)) {
        // NACH 12 H ERSATZLOS RAUS. Kein Zeitgeber raeumt hier auf, weil diese Datei keine Uhr
        // hat — aufgeraeumt wird, wenn jemand mit einer Uhr hinsieht. Das genuegt: gelesen wird
        // im Sekundentakt, und ohne Leser schadet ein Eintrag im Speicher niemandem.
        this._zaehler.gealtert++;
        this._saele.delete(sid);
        delete this._letzteWahl[sid];
        continue;
      }

      const wid = widerspruchAus(
        e.lan ? { kacheln: e.lan.kacheln, uebertragungMs: uebL } : null,
        e.cloud ? { kacheln: e.cloud.kacheln, uebertragungMs: uebC } : null,
        this.grenzwerte);

      const stille = e.lanEmpfangen == null ? null : tafel.alterMs(e.lanEmpfangen, j);
      const wahl = quellenwahl({
        lanDa: !!e.lan, cloudDa: !!e.cloud,
        lanStilleMs: stille, lanFehler: e.lanFehlerZahl, lanGesperrt: e.lanGesperrt,
        widerspruch: wid.widerspruch,
        fehlerMax: this.lanFehlerMax, stilleMaxMs: this.lanStilleMs,
      });
      this._letzteWahl[sid] = { quelle: wahl.quelle, grund: wahl.grund, widerspruch: wahl.widerspruch };

      const sicht = wahl.quelle === 'lan' ? e.lan : (wahl.quelle === 'cloud' ? e.cloud : null);
      const ueb = wahl.quelle === 'lan' ? uebL : (wahl.quelle === 'cloud' ? uebC : null);
      roh.push(this._saalSatz(e, sicht, wahl, ueb, uebL, uebC, wid, stille));
    }

    const sortiert = sortiereSaele(roh);
    const gekappt = kappeSaele(sortiert, this.saeleMax);
    const verlegungen = verlegungenAus(gekappt.saele);
    const doppel = doppelempfang(gekappt.saele);
    this._markiereVerlegungen(gekappt.saele, verlegungen);

    const hinweise = this._hinweise(gekappt, verlegungen, doppel, j);
    return {
      jetzt: j,
      saele: gekappt.saele,
      mehr: gekappt.mehr,
      weitereListe: gekappt.weitereListe,
      verlegungen: verlegungen,
      doppelempfang: doppel,
      hinweise: hinweise,
    };
  }

  /*
   * _istWeg — faellt dieser Saal ersatzlos heraus?
   *
   * Zwei Faelle, beide mit derselben Bedeutung "dieser Zeitstempel taugt nicht mehr fuer eine
   * Altersaussage" (dieselbe Regel wie tafelabo.saele()):
   *   1. Das juengste bekannte Alter liegt ueber 12 h.
   *   2. Der Zeitstempel liegt mehr als 12 h in der ZUKUNFT. Innerhalb dieser Toleranz bleibt der
   *      Saal mit der Stufe 'unbekannt' sichtbar (unsere Uhr geht nach, nicht sein Saal ist tot);
   *      darueber hinaus ist es kein Gangfehler mehr, sondern Unsinn.
   * Ein Saal, von dem gar nichts mehr da ist (beide Quellen leer), faellt ebenfalls heraus.
   */
  _istWeg(e, uebC, uebL, jetzt) {
    if (!e.cloud && !e.lan) return true;
    const bekannt = [uebC, uebL].filter((x) => x != null);
    if (bekannt.length) return Math.min.apply(null, bekannt) >= tafel.STUFE_WEG_MS;
    // OHNE UHR WIRD NICHTS WEGGEWORFEN. Das steht vor allem anderen: 'jetzt' ist hier bereits
    // durch ms() gegangen und damit null, wenn der Aufrufer keine Uhr uebergeben hat — Number(null)
    // waere 0, und gegen die Uhr 0 liegt JEDER Zeitstempel mehr als 12 h in der Zukunft. Ein
    // einziger Aufruf saele() ohne Uhr haette so den ganzen Speicher geleert.
    if (jetzt == null) return false;
    const zeiten = [];
    if (e.cloud) zeiten.push(Number(e.cloud.sv));
    if (e.lan) zeiten.push(Number(e.lan.empfangen));
    const j = Number(jetzt);
    if (!Number.isFinite(j)) return false;
    for (let i = 0; i < zeiten.length; i++) {
      const vor = zeiten[i] - j;
      if (Number.isFinite(vor) && vor >= 0 && vor <= tafel.UHR_TOLERANZ_MS) return false;
    }
    return true;
  }

  /* Ein fertiger Saalsatz. Die Feldnamen sind die aus der Schnittstelle (sid, name, quelle,
   * uebertragungMs, meta, patients, geraete) plus alles, was Band, Log und Admin-Bereich sonst
   * nicht selbst ausrechnen koennten, ohne eine zweite Rechnung aufzumachen. */
  _saalSatz(e, sicht, wahl, ueb, uebL, uebC, wid, stille) {
    const stufe = altersStufe(ueb);
    /* 'weg' MUSS mit ersetzen — siehe die Begruendung bei hinweisText. Ein Saal in dieser Stufe
     * kann sichtbar bleiben (wenn nur EINE seiner beiden Quellen ueber 12 h alt ist), und dann
     * waeren seine Zahlen die aeltesten im ganzen Band und die einzigen ohne Warnung. */
    const ersetzt = stufe === 'offline' || stufe === 'weg';
    const kacheln = sicht ? sicht.kacheln : [];
    const zeilen = sicht ? sicht.geraete : [];
    const gezeigteK = kacheln.slice(0, this.kachelnMax);
    const gezeigteG = zeilen.slice(0, this.geraeteMax);

    return {
      sid: e.sid,
      name: (sicht && sicht.name) || null,
      quelle: wahl.quelle,
      grund: wahl.grund,
      uebertragungMs: ueb,
      stufe: stufe,
      hinweis: hinweisText(stufe, ueb),
      // ab 'offline' stehen keine Zahlen mehr in den Kacheln, sondern der Ersatztext. Das Feld
      // sagt es dem Band ausdruecklich, damit es nicht am Fehlen einzelner Felder raten muss.
      ersetzt: ersetzt,
      ersatz: ersetzt ? ersatzText(ueb) : null,
      widerspruch: !!wid.widerspruch,
      widerspruchText: wid.widerspruch ? TEXT_WIDERSPRUCH : null,
      widerspruchGruende: wid.gruende.slice(0, 8),
      meta: sicht ? sicht.meta : {},
      patients: gezeigteK.map((x) => patientSatz(x.k, x.w, ueb, ersetzt)),
      geraete: gezeigteG.map((x) => geraeteZeile(x.k, x.w, ueb)),
      // Die Deckel ALS ZAHL (N17) — der Rest der Vorstufe ist in mehrK/mehrG schon enthalten.
      mehr: Math.max(0, kacheln.length - gezeigteK.length) + (sicht ? sicht.mehrK : 0),
      mehrGeraete: Math.max(0, zeilen.length - gezeigteG.length) + (sicht ? sicht.mehrG : 0),
      count: gezeigteK.length,
      // Der eigene Leser, durchgereicht (Befund C3 in tafelabo): wer 'offline' anzeigt, MUSS
      // wissen, ob nicht der Nachbar steht, sondern der eigene Strom abgerissen ist.
      blind: sicht ? !!sicht.blind : true,
      lesestandMs: sicht ? sicht.lesestandMs : null,
      lan: { da: !!e.lan, uebertragungMs: uebL, stilleMs: stille, fehler: e.lanFehlerZahl, gesperrt: !!e.lanGesperrt },
      cloud: { da: !!e.cloud, uebertragungMs: uebC },
    };
  }

  /*
   * _markiereVerlegungen — die Marke 'auch in OP 2' an der Kachel.
   *
   * Sie steht ZUSAETZLICH zu den zwei Eintraegen, nicht an ihrer Stelle: der Patient bleibt in
   * beiden Saelen einzeln gefuehrt, weil in beiden Saelen wirklich Geraete an ihm haengen koennen
   * (Verlegung waehrend der Narkose) und weil die Protokolle je PC lokal bleiben.
   */
  _markiereVerlegungen(saele, verlegungen) {
    if (!verlegungen.length) return;
    const proPid = Object.create(null);
    verlegungen.forEach((v) => { proPid[v.pid] = v; });
    saele.forEach((s) => {
      (s.patients || []).forEach((p) => {
        const pid = String(p.pid == null ? '' : p.pid).trim();
        if (!pid) return;
        const v = proPid[pid];
        if (!v) return;
        const andere = [];
        for (let i = 0; i < v.saele.length; i++) {
          if (v.saele[i] === s.sid) continue;
          andere.push(v.namen[i] || v.saele[i]);
        }
        if (andere.length) p.auch = andere;
      });
    });
  }

  /*
   * _hinweise — der Klartext fuer Band und Log, fertig formuliert.
   *
   * Warum hier und nicht in der Oberflaeche: den Wortlaut aus N17 gibt es genau einmal, sonst
   * sagen Kiosk-Streifen, Web-App und Log fuer dieselbe Lage drei verschiedene Saetze. Die
   * Oberflaeche darf entscheiden, ob sie eine Zeile zeigt — nicht, wie sie heisst.
   */
  _hinweise(gekappt, verlegungen, doppel, jetzt) {
    const raus = [];
    if (gekappt.hinweis) {
      raus.push(gekappt.hinweis);
      this._melde('warn', 'deckel', gekappt.hinweis + ' ('
        + gekappt.weitereListe.map((w) => (w.name || w.sid)).join(', ') + ')', jetzt);
    }
    gekappt.saele.forEach((s) => {
      const wer = s.name || s.sid;
      if (s.mehr > 0) {
        raus.push(wer + ': ' + s.mehr + ' weitere Patienten werden nicht angezeigt — Deckel erreicht');
      }
      if (s.widerspruch) {
        const zeile = wer + ': ' + TEXT_WIDERSPRUCH + ' — es gilt die Cloud.';
        raus.push(zeile);
        this._melde('warn', 'widerspruch-' + s.sid,
          zeile + ' ' + s.widerspruchGruende.join('; '), jetzt);
      }
      if (s.stufe === 'offline') raus.push(wer + ' ' + hinweisText('offline', s.uebertragungMs));
      else if (s.stufe === 'unbekannt') raus.push(wer + ': ' + TEXT_UNBEKANNT);
    });
    verlegungen.forEach((v) => {
      raus.push('Patient ' + v.pid + ' ist in mehreren OP-Saelen gefuehrt: '
        + v.namen.map((n, i) => (n || v.saele[i])).join(', '));
    });
    doppel.forEach((d) => {
      raus.push(d.text);
      this._melde('error', 'doppelempfang-' + d.id, d.text, jetzt);
    });
    return raus;
  }

  /*
   * _melde — dieselbe Drossel wie in tafelabo.js: hoechstens eine gleichartige Zeile je Minute.
   * Ohne uebergebene Uhr wird jede Art GENAU EINMAL gemeldet — eine ungedrosselte Zeile im
   * Sekundentakt macht das Log unbrauchbar, und eine eigene Uhr gibt es hier nicht.
   */
  _melde(art, schluessel, text, jetzt) {
    const alt = this._gemeldet[schluessel];
    const j = ms(jetzt);
    if (alt) {
      if (j == null || alt.am == null) return;
      if (alt.text === text && (j - alt.am) < MELDE_TAKT_MS) return;
    }
    this._gemeldet[schluessel] = { text: text, am: j };
    const fn = this.log[art] || this.log.info;
    if (typeof fn === 'function') fn.call(this.log, 'nachbarn', text);
  }

  /*
   * status() — der kurze Zustand fuer GET /api/nachbarn und den Admin-Bereich.
   *
   * OHNE UHR, mit Absicht (siehe Kopfkommentar): hier stehen die rohen Zeitstempel und die beim
   * letzten saele()/rundruf() getroffene Quellenwahl. Wer Alterszahlen braucht, ruft saele(jetzt)
   * — dieselbe Zahl an zwei Stellen aus zwei Uhren waere zwei Zahlen.
   */
  status() {
    const quellen = [];
    for (const sid of Array.from(this._saele.keys()).sort()) {
      const e = this._saele.get(sid);
      const w = this._letzteWahl[sid] || null;
      quellen.push({
        sid: sid,
        name: (e.cloud && e.cloud.name) || (e.lan && e.lan.name) || null,
        quelle: w ? w.quelle : null,
        grund: w ? w.grund : null,
        widerspruch: w ? !!w.widerspruch : false,
        cloudDa: !!e.cloud, cloudEmpfangen: e.cloudEmpfangen,
        lanDa: !!e.lan, lanEmpfangen: e.lanEmpfangen,
        lanFehler: e.lanFehlerZahl, lanGesperrt: !!e.lanGesperrt, lanFehlerGrund: e.lanFehlerGrund,
      });
    }
    return {
      saele: this._saele.size,
      saeleMax: this.saeleMax,
      kachelnMax: this.kachelnMax,
      geraeteMax: this.geraeteMax,
      eigeneSid: this.eigeneSid(),
      lanFehlerMax: this.lanFehlerMax,
      lanStilleMs: this.lanStilleMs,
      lanErholungAnzahl: this.lanErholungAnzahl,
      grenzwerte: Object.assign({}, this.grenzwerte),
      quellen: quellen,
      zaehler: Object.assign({}, this._zaehler),
      verworfen: Object.assign({}, this._verworfen),
    };
  }
}

module.exports = {
  Fremdstore,
  // reine Funktionen — jede einzeln pruefbar, keine haelt einen Zustand und keine fragt eine Uhr
  altersStufe,
  quellenwahl,
  sortiereSaele,
  kappeSaele,
  verlegungenAus,
  doppelempfang,
  widerspruchAus,
  normalisiere,
  patientSatz,
  geraeteZeile,
  kopfSatz,
  paare,
  empfaengt,
  ersatzText,
  hinweisText,
  // Konstanten, damit Test und Aufrufer dieselben Zahlen benutzen und keine eigenen erfinden
  LAN_FEHLER_MAX,
  LAN_STILLE_MS,
  LAN_ERHOLUNG_ANZAHL,
  GRENZWERTE,
  KINDER_MAX,
  MELDE_TAKT_MS,
  TEXT_WIDERSPRUCH,
  TEXT_UNBEKANNT,
};
