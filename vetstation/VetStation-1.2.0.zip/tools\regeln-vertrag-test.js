'use strict';
/*
 * regeln-vertrag-test.js — der MECHANISCHE Vertrag zwischen Sender, Tafel und Regeldatei.
 *
 * WOFUER ES DIESE DATEI GIBT
 * Die Regeldatei (installer/firebase-rtdb-rules.json), der Sender (bridge/src/cloud.js) und die
 * Tafel-Funktionen (bridge/src/tafel.js) muessen ueber JEDES Feld einer Meinung sein. Sind sie es
 * nicht, lehnt die Datenbank ab — und weil ein Mehrpfad-PATCH ATOMAR ist, faellt mit einem einzigen
 * strittigen Feld der GANZE Koerper: die Vitalwerte kommen nicht an, die Antwort lautet
 * "HTTP 401: Permission denied", CloudPublisher._istKonfigFehler (cloud.js:273) erkennt darin einen
 * Konfigurationsfehler und cloud.js:1091 schaltet nach DREI Treffern die Fern-Uebertragung dauerhaft
 * ab. Drei Takte sind weniger als eine Minute, und es gilt fuer JEDE ausgelieferte Praxis
 * gleichzeitig.
 *
 * Bisher wurde diese Uebereinstimmung nur BEHAUPTET — in Kommentaren, und von Menschen verglichen.
 * Genau dort sass der toedliche Befund dieser Runde: zwei Felder trugen im echten Datensatz OBJEKTE
 * und standen unter einer Regel, die nur Text, Zahl oder Wahrheitswert erlaubte. Kein Kommentar
 * konnte das sehen, weil kein Kommentar rechnet.
 *
 * WAS DIESE DATEI ANDERS MACHT ALS tools/regeln-test.js
 * regeln-test.js prueft die Regeln als STRUKTUR ("steht hier eine Grenze?", "ist der Bestandsblock
 * wortgleich?") und haelt einen VON HAND GEBAUTEN Musterpatienten dagegen. Diese Datei geht den
 * anderen Weg und ist damit die Gegenprobe, nicht die Wiederholung:
 *   1. Der Datensatz ist ECHT. Er entsteht aus bridge/src/registry.js mit dem Simulator-Adapter,
 *      laeuft durch model.normalizeFrame und matching.mergePatients und wird von der ECHTEN
 *      _buildSnapshot/_pfade/_delta/_protokollPfade des CloudPublishers in Schreibpfade zerlegt.
 *      Niemand tippt hier ein Feld von Hand ab; wer cloud.js ein Feld hinzufuegt, hat es sofort
 *      auch hier drin.
 *   2. Die Regeln werden AUSGEWERTET, nicht gemustert. Unten steht ein kleiner Auswerter fuer die
 *      Regelsprache (Zerleger, Parser, Rechner). Er versteht die Formen, die in DIESER Regeldatei
 *      wirklich vorkommen — und wirft bei allem anderen, statt zu raten. Was er nicht auswerten
 *      kann, steht am Ende AUSDRUECKLICH unter "NICHT GEPRUEFT". Eine stille Luecke waere
 *      schlimmer als eine gemeldete: sie sieht aus wie ein bestandener Test.
 *
 * WAS GEPRUEFT WIRD, in der Reihenfolge der Ausgabe
 *   A  Der Auswerter selbst (sonst prueft der Rest nichts).
 *   B  Der echte Datensatz entsteht und enthaelt die interessanten LUECKEN
 *      (mit/ohne Kapnograf, mit/ohne Patienten-ID, mit/ohne Kurven, mit/ohne Alarme).
 *   C  Hinrichtung: jeder Pfad des Datensatzes gegen jedes zutreffende ".validate".
 *   D  Gegenprobe: absichtlich kaputte Datensaetze MUESSEN abgelehnt werden.
 *   E  Gegenrichtung: jedes Pflichtfeld einer Regel (hasChildren) muss im Datensatz vorkommen.
 *   F  Kappungsgrenzen: die laengsten tatsaechlich erzeugbaren Werte gegen jede Regelgrenze.
 *
 * WARUM D NICHT WEGGELASSEN WERDEN DARF
 * Ein Auswerter, der immer "erlaubt" sagt, besteht C, E und F muehelos — und meldet in einer Praxis
 * nie etwas. D ist die einzige Pruefung, die einen solchen Auswerter rot macht: neun absichtlich
 * kaputte Datensaetze muessen abgelehnt werden, jeder an einer ANDEREN Regelform. Faellt auch nur
 * eine dieser neun durch, ist das Ergebnis dieser ganzen Datei wertlos, und der Test sagt das.
 *
 * OHNE NETZ UND OHNE ECHTES FIREBASE. Der CloudPublisher wird nur GEBAUT; start() laeuft nie, es
 * wird kein Token geholt und keine Verbindung geoeffnet. Die Anmeldedatei zeigt auf einen Namen im
 * Temp-Verzeichnis, den niemand anlegt oder liest.
 *
 * OHNE SPUREN IM PROJEKT. Die Registry schreibt im Betrieb bridge/data/protokoll.json und
 * patient-akte.json. Beide Schreibwege werden hier gleich nach dem Bau stillgelegt (siehe
 * baueRegistry) — ein Test darf die Narkoseprotokolle des Anwenders nicht ueberschreiben.
 *
 * Start: node tools/regeln-vertrag-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const REGELDATEI = path.join(WURZEL, 'installer', 'firebase-rtdb-rules.json');
// Der eigene Quelltext — gebraucht fuer die Selbstpruefung 'holt diese Datei die echten Koerper?'.
const eigenerQuelltext = fs.readFileSync(__filename, 'utf8');

// Feste Praxis-Kennung und feste Stationskennung. Beides sind Pfadsegmente, an denen Regeln haengen
// ($praxis, $station) — sie muessen deshalb hier stehen und nicht zufaellig entstehen.
const UID = 'praxisAbc123';
const SID = 'st0123456789ab';

let pass = 0, fail = 0;
const OFFEN = [];        // "NICHT GEPRUEFT" — wird am Ende vollstaendig ausgegeben
const BEFUNDE = [];      // Widersprueche im Klartext, fuer die Zusammenfassung

function ok(name, bedingung, gefahr, extra) {
  if (bedingung) { pass++; console.log('  ✓ ' + name); return; }
  fail++;
  console.log('  ✗ ' + name);
  console.log('      GEFAHR: ' + gefahr);
  if (extra) console.log('      gefunden: ' + extra);
  BEFUNDE.push(name + (extra ? ' — ' + String(extra).split('\n')[0] : ''));
}
function offen(text) { OFFEN.push(text); }
function abschnitt(t) { console.log('\n' + t); }

/* ==========================================================================================
 * TEIL 0 — Regeldatei laden
 * ========================================================================================== */

/*
 * Die Firebase-Konsole nimmt Kommentare in den Regeln an, JSON.parse nicht. Der Entferner muss
 * zeichenkettenbewusst sein: in den Regelausdruecken stehen Schraegstriche (.matches(/^[0-3]$/)),
 * und ein naiver Entferner machte daraus einen Zeilenkommentar und verstuemmelte die Regel.
 * Wortgleich zu tools/regeln-test.js:137 — zwei verschiedene Entferner waeren zwei verschiedene
 * Meinungen darueber, was in der Datei steht.
 */
function ohneKommentare(text) {
  let out = '', i = 0, inStr = false;
  while (i < text.length) {
    const c = text[i], d = text[i + 1];
    if (inStr) {
      if (c === '\\') { out += c + (d === undefined ? '' : d); i += 2; continue; }
      if (c === '"') inStr = false;
      out += c; i++; continue;
    }
    if (c === '"') { inStr = true; out += c; i++; continue; }
    if (c === '/' && d === '/') { while (i < text.length && text[i] !== '\n') i++; continue; }
    if (c === '/' && d === '*') {
      i += 2;
      while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++;
      i += 2; continue;
    }
    out += c; i++;
  }
  return out;
}

let REGELN = null, ladeFehler = null;
try {
  REGELN = JSON.parse(ohneKommentare(fs.readFileSync(REGELDATEI, 'utf8'))).rules;
} catch (e) { ladeFehler = e.message; }

/* ==========================================================================================
 * TEIL 1 — Auswerter fuer die Regelsprache
 *
 * ABSICHTLICH KEIN VOLLSTAENDIGER AUSWERTER. Er versteht die Formen, die in dieser Regeldatei
 * tatsaechlich benutzt werden: isString/isNumber/isBoolean/exists/hasChildren/hasChild/child/val,
 * .length, .matches, die Vergleiche, && || ! und den Fragezeichen-Operator. Alles andere wirft
 * NichtAuswertbar — und wird gemeldet, statt fuer "erlaubt" gehalten zu werden. Ein Auswerter, der
 * bei Unverstandenem "true" liefert, verwandelt jede kuenftige Regelverschaerfung in einen still
 * bestandenen Test.
 * ========================================================================================== */

class NichtAuswertbar extends Error {}

/*
 * Zerleger. Ein '/' beginnt hier IMMER ein regulaeres Ausdrucksliteral (.matches(/^st[0-9a-f]+$/)) —
 * in der ganzen Regelsprache gibt es keine Division, deshalb ist das eindeutig. Kaeme je eine
 * Division hinein, wuerde daraus ein unbeendetes Literal und der Auswerter meldete "nicht
 * auswertbar", statt still etwas Falsches zu rechnen.
 */
function zerlege(s) {
  const t = [];
  let i = 0;
  const DREI = ['===', '!=='];
  const ZWEI = ['==', '!=', '<=', '>=', '&&', '||'];
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) { i++; continue; }
    if (c === "'" || c === '"') {
      let j = i + 1, wert = '';
      while (j < s.length && s[j] !== c) {
        if (s[j] === '\\') { wert += s[j + 1]; j += 2; continue; }
        wert += s[j]; j++;
      }
      if (j >= s.length) throw new NichtAuswertbar('unbeendete Zeichenkette');
      t.push({ a: 'txt', v: wert }); i = j + 1; continue;
    }
    if (c === '/') {
      let j = i + 1, quelle = '';
      while (j < s.length && s[j] !== '/') {
        if (s[j] === '\\') { quelle += s[j] + s[j + 1]; j += 2; continue; }
        quelle += s[j]; j++;
      }
      if (j >= s.length) throw new NichtAuswertbar('unbeendetes Ausdrucksliteral');
      j++;
      let flags = '';
      while (j < s.length && /[a-z]/.test(s[j])) { flags += s[j]; j++; }
      t.push({ a: 'regex', v: quelle, f: flags }); i = j; continue;
    }
    if (/[0-9]/.test(c)) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      t.push({ a: 'zahl', v: Number(s.slice(i, j)) }); i = j; continue;
    }
    if (/[A-Za-z_$]/.test(c)) {
      let j = i;
      while (j < s.length && /[A-Za-z0-9_$]/.test(s[j])) j++;
      t.push({ a: 'wort', v: s.slice(i, j) }); i = j; continue;
    }
    const d3 = s.substr(i, 3), d2 = s.substr(i, 2);
    if (DREI.indexOf(d3) >= 0) { t.push({ a: 'op', v: d3 }); i += 3; continue; }
    if (ZWEI.indexOf(d2) >= 0) { t.push({ a: 'op', v: d2 }); i += 2; continue; }
    if ('!<>?:.,()[]+-'.indexOf(c) >= 0) { t.push({ a: 'op', v: c }); i++; continue; }
    throw new NichtAuswertbar('unbekanntes Zeichen "' + c + '"');
  }
  return t;
}

// Parser: Fragezeichen > || > && > Vergleich > +- > ! > Nachsatz (.name, .name(...)) > Grundwert.
function parse(tokens) {
  let p = 0;
  const schau = () => tokens[p];
  const istOp = (v) => tokens[p] && tokens[p].a === 'op' && tokens[p].v === v;
  const nimm = (v) => { if (!istOp(v)) throw new NichtAuswertbar('erwartet "' + v + '"'); p++; };

  function ternaer() {
    const c = oder();
    if (!istOp('?')) return c;
    p++;
    const a = ternaer(); nimm(':');
    const b = ternaer();
    return { t: 'tern', c: c, a: a, b: b };
  }
  function oder() { let l = und(); while (istOp('||')) { p++; l = { t: 'bin', op: '||', l: l, r: und() }; } return l; }
  function und() { let l = vergleich(); while (istOp('&&')) { p++; l = { t: 'bin', op: '&&', l: l, r: vergleich() }; } return l; }
  function vergleich() {
    let l = summe();
    while (tokens[p] && tokens[p].a === 'op' && ['===', '!==', '==', '!=', '<=', '>=', '<', '>'].indexOf(tokens[p].v) >= 0) {
      const op = tokens[p].v; p++;
      l = { t: 'bin', op: op, l: l, r: summe() };
    }
    return l;
  }
  function summe() {
    let l = einstellig();
    while (tokens[p] && tokens[p].a === 'op' && (tokens[p].v === '+' || tokens[p].v === '-')) {
      const op = tokens[p].v; p++;
      l = { t: 'bin', op: op, l: l, r: einstellig() };
    }
    return l;
  }
  function einstellig() {
    if (istOp('!')) { p++; return { t: 'nicht', a: einstellig() }; }
    if (istOp('-')) { p++; return { t: 'bin', op: '-', l: { t: 'lit', v: 0 }, r: einstellig() }; }
    return nachsatz();
  }
  function nachsatz() {
    let z = grundwert();
    for (;;) {
      if (!istOp('.')) break;
      p++;
      const w = schau();
      if (!w || w.a !== 'wort') throw new NichtAuswertbar('Name nach "." erwartet');
      p++;
      if (istOp('(')) {
        p++;
        const args = [];
        while (!istOp(')')) { args.push(ternaer()); if (istOp(',')) p++; }
        nimm(')');
        z = { t: 'ruf', ziel: z, name: w.v, args: args };
      } else {
        z = { t: 'feld', ziel: z, name: w.v };
      }
    }
    return z;
  }
  function grundwert() {
    const w = schau();
    if (!w) throw new NichtAuswertbar('Ausdruck bricht ab');
    if (w.a === 'zahl') { p++; return { t: 'lit', v: w.v }; }
    if (w.a === 'txt') { p++; return { t: 'lit', v: w.v }; }
    if (w.a === 'regex') { p++; return { t: 'lit', v: new RegExp(w.v, w.f) }; }
    if (w.a === 'wort') {
      p++;
      if (w.v === 'true') return { t: 'lit', v: true };
      if (w.v === 'false') return { t: 'lit', v: false };
      if (w.v === 'null') return { t: 'lit', v: null };
      return { t: 'name', v: w.v };
    }
    if (istOp('(')) { p++; const e = ternaer(); nimm(')'); return e; }
    if (istOp('[')) {
      p++;
      const items = [];
      while (!istOp(']')) { items.push(ternaer()); if (istOp(',')) p++; }
      nimm(']');
      return { t: 'liste', items: items };
    }
    throw new NichtAuswertbar('unerwartetes Zeichen "' + (w.v) + '"');
  }

  const baum = ternaer();
  if (p !== tokens.length) throw new NichtAuswertbar('Rest nach dem Ausdruck: "' + tokens.slice(p).map((x) => x.v).join(' ') + '"');
  return baum;
}

/*
 * Ein Datenknoten so, wie ihn die Regelsprache sieht. undefined heisst "nicht vorhanden";
 * in der Realtime Database ist das derselbe Zustand wie null (ein null LOESCHT den Schluessel,
 * cloud.js:790-805 benutzt genau das) — deshalb behandelt exists() beides gleich.
 */
function knoten(wert) { return { __rtdb: true, wert: wert }; }
function istKnoten(x) { return !!x && typeof x === 'object' && x.__rtdb === true; }
function hatKinder(w) { return !!w && typeof w === 'object' && !(w instanceof RegExp); }

function rechne(n, umg) {
  switch (n.t) {
    case 'lit': return n.v;
    case 'liste': return n.items.map((x) => rechne(x, umg));
    case 'nicht': return !wahrheit(rechne(n.a, umg));
    case 'tern': return wahrheit(rechne(n.c, umg)) ? rechne(n.a, umg) : rechne(n.b, umg);
    case 'bin': {
      if (n.op === '&&') return wahrheit(rechne(n.l, umg)) ? wahrheit(rechne(n.r, umg)) : false;
      if (n.op === '||') return wahrheit(rechne(n.l, umg)) ? true : wahrheit(rechne(n.r, umg));
      const a = rechne(n.l, umg), b = rechne(n.r, umg);
      /*
       * Ein ganzer Knoten laesst sich nicht vergleichen — in der Regelsprache muesste dort .val()
       * stehen. Was hier zu raten waere ("vermutlich meinte jemand den Wert"), koennte still das
       * Gegenteil des Richtigen ergeben, deshalb wird es gemeldet.
       * "auth != null" ist KEIN Fall davon: auth ist ein gewoehnliches Objekt, kein Knoten.
       */
      if (istKnoten(a) || istKnoten(b)) throw new NichtAuswertbar('Vergleich auf einem ganzen Knoten (fehlt ein .val()?)');
      switch (n.op) {
        case '===': return a === b;
        case '!==': return a !== b;
        /* eslint-disable eqeqeq */
        case '==': return a == b;
        case '!=': return a != b;
        /* eslint-enable eqeqeq */
        case '<=': return a <= b;
        case '>=': return a >= b;
        case '<': return a < b;
        case '>': return a > b;
        case '+': return a + b;
        case '-': return a - b;
        default: throw new NichtAuswertbar('unbekannter Vergleich "' + n.op + '"');
      }
    }
    case 'name': {
      if (n.v === 'newData') return knoten(umg.neu);
      if (n.v === 'data') return knoten(umg.alt);
      if (n.v === 'now') return umg.now;
      if (n.v === 'auth') return umg.auth;
      if (n.v[0] === '$') {
        if (!Object.prototype.hasOwnProperty.call(umg.bindungen, n.v)) {
          throw new NichtAuswertbar('Platzhalter ' + n.v + ' ist an dieser Stelle nicht gebunden');
        }
        return umg.bindungen[n.v];
      }
      // root, Snapshot.parent(), Funktionen aus anderen Zweigen: bewusst nicht geraten.
      throw new NichtAuswertbar('unbekannter Name "' + n.v + '"');
    }
    case 'feld': {
      const z = rechne(n.ziel, umg);
      if (n.name === 'length') {
        if (typeof z === 'string') return z.length;
        if (Array.isArray(z)) return z.length;
        throw new NichtAuswertbar('.length auf etwas, das kein Text ist');
      }
      if (istKnoten(z)) throw new NichtAuswertbar('Feldzugriff ".' + n.name + '" auf einem Knoten');
      if (z && typeof z === 'object' && n.name in z) return z[n.name];   // auth.uid
      if (z == null) throw new NichtAuswertbar('Feldzugriff ".' + n.name + '" auf null');
      throw new NichtAuswertbar('unbekanntes Feld ".' + n.name + '"');
    }
    case 'ruf': {
      const z = rechne(n.ziel, umg);
      const args = n.args.map((x) => rechne(x, umg));
      if (istKnoten(z)) {
        const w = z.wert;
        switch (n.name) {
          case 'val': return hatKinder(w) ? w : (w === undefined ? null : w);
          case 'exists': return w !== undefined && w !== null;
          case 'isString': return typeof w === 'string';
          case 'isNumber': return typeof w === 'number';
          case 'isBoolean': return typeof w === 'boolean';
          case 'hasChild': return hatKinder(w) && w[args[0]] !== undefined && w[args[0]] !== null;
          case 'hasChildren': {
            if (!hatKinder(w)) return false;
            const liste = args.length ? args[0] : null;
            if (liste == null) return Object.keys(w).length > 0;
            if (!Array.isArray(liste)) throw new NichtAuswertbar('hasChildren ohne Liste');
            return liste.every((k) => w[k] !== undefined && w[k] !== null);
          }
          case 'child': {
            let cur = w;
            String(args[0]).split('/').forEach((teil) => {
              cur = hatKinder(cur) ? cur[teil] : undefined;
            });
            return knoten(cur);
          }
          case 'getPriority': case 'parent': case 'hasChildrenCount':
            throw new NichtAuswertbar('Regelfunktion "' + n.name + '" wird hier nicht ausgewertet');
          default: throw new NichtAuswertbar('unbekannte Knotenfunktion "' + n.name + '"');
        }
      }
      if (typeof z === 'string') {
        switch (n.name) {
          case 'matches': {
            if (!(args[0] instanceof RegExp)) throw new NichtAuswertbar('matches ohne Ausdrucksliteral');
            return args[0].test(z);
          }
          case 'contains': return z.indexOf(String(args[0])) >= 0;
          case 'beginsWith': return z.indexOf(String(args[0])) === 0;
          case 'endsWith': return z.lastIndexOf(String(args[0])) === z.length - String(args[0]).length;
          case 'toLowerCase': return z.toLowerCase();
          case 'toUpperCase': return z.toUpperCase();
          case 'replace': return z.split(String(args[0])).join(String(args[1]));
          default: throw new NichtAuswertbar('unbekannte Textfunktion "' + n.name + '"');
        }
      }
      throw new NichtAuswertbar('Aufruf ".' + n.name + '()" auf einem Wert, der das nicht kann');
    }
    default: throw new NichtAuswertbar('unbekannter Knoten "' + n.t + '"');
  }
}
function wahrheit(x) {
  if (istKnoten(x)) throw new NichtAuswertbar('ein ganzer Knoten als Wahrheitswert');
  return !!x;
}

const PARSE_SPEICHER = new Map();
/*
 * werte(ausdruck, umgebung) -> { ergebnis: true|false|null, grund }
 * ergebnis === null bedeutet AUSDRUECKLICH "nicht auswertbar" und wird nie als "erlaubt" gezaehlt.
 */
function werte(ausdruck, umg) {
  let baum = PARSE_SPEICHER.get(ausdruck);
  if (baum === undefined) {
    try { baum = parse(zerlege(ausdruck)); } catch (e) { baum = { fehler: e.message }; }
    PARSE_SPEICHER.set(ausdruck, baum);
  }
  if (baum && baum.fehler) return { ergebnis: null, grund: baum.fehler };
  try { return { ergebnis: wahrheit(rechne(baum, umg)), grund: null }; }
  catch (e) {
    if (e instanceof NichtAuswertbar) return { ergebnis: null, grund: e.message };
    return { ergebnis: null, grund: 'Auswerterfehler: ' + e.message };
  }
}

/* ==========================================================================================
 * TEIL 2 — Regelbaum begehen
 * ========================================================================================== */

/*
 * regelTreffer(pfadSegmente) — ALLE Regelknoten, die auf diesen Datenpfad passen.
 *
 * WARUM ALLE UND NICHT NUR EINER: ob Firebase bei einem namentlich genannten Kind ZUSAETZLICH die
 * $-Platzhalter-Regel des Geschwisters auswertet, ist im Projekt ungemessen (siehe Schritt 0 des
 * Plans, offene Semantikfrage). Diese Datei rechnet mit der SCHLECHTEREN Annahme: beide Regeln
 * gelten, und eine Ablehnung durch eine von beiden ist eine Ablehnung. Das kann hoechstens zu viel
 * melden, nie zu wenig — und der Ausgabetext sagt, welche der beiden es war.
 */
function regelTreffer(knotenR, segmente, bindungen, out) {
  if (!knotenR || typeof knotenR !== 'object') return out;
  if (!segmente.length) { out.push({ knoten: knotenR, bindungen: bindungen }); return out; }
  const s = segmente[0], rest = segmente.slice(1);
  if (s[0] !== '.' && knotenR[s] && typeof knotenR[s] === 'object') {
    regelTreffer(knotenR[s], rest, bindungen, out);
  }
  Object.keys(knotenR).forEach((k) => {
    if (k[0] !== '$') return;
    const b = Object.assign({}, bindungen);
    b[k] = s;
    regelTreffer(knotenR[k], rest, b, out);
  });
  return out;
}
function trefferFuer(segmente) { return regelTreffer(REGELN, segmente, {}, []); }

/*
 * regelPfad(segmente) — derselbe Pfad, aber mit den NAMEN AUS DER REGELDATEI ($praxis, $station,
 * $key, $geraet, $i ...). Nur so lassen sich Befunde zusammenfassen: ohne diese Umschrift stuende
 * derselbe Mangel viermal da, einmal je Patientenschluessel, und die eigentliche Aussage
 * ("akte/$feld ist ungedeckelt") ginge in der Aufzaehlung unter.
 * Bevorzugt wird der namentliche Zweig — er ist der, unter dem der Mangel in der Datei zu beheben ist.
 *
 * INSTANZ traegt die Segmente, die eine EINZELNE Sache benennen (dieser Patient, dieses Geraet,
 * dieser Zeitpunkt). Sie wird weiter unten AUS DEM DATENSATZ gefuellt, nicht geraten — nur so kann
 * auch dort zusammengefasst werden, wo der Regelbaum aufhoert (unter der flachen Ebene gibt es keine
 * Kindregeln mehr).
 */
const INSTANZ = new Map([[UID, '$praxis'], [SID, '$station']]);
function regelPfad(segmente) {
  let n = REGELN;
  const out = [];
  for (const s of segmente) {
    if (n && typeof n === 'object') {
      if (s[0] !== '.' && n[s] && typeof n[s] === 'object') { out.push(s); n = n[s]; continue; }
      const pv = Object.keys(n).find((k) => k[0] === '$');
      if (pv) { out.push(pv); n = n[pv]; continue; }
      n = null;
    }
    if (/^\d+$/.test(s)) { out.push('$i'); continue; }
    out.push(INSTANZ.get(s) || s);
  }
  return out.join('/');
}

/*
 * DIE ALTE FLACHE EBENE. meta/, patients/ und protokoll/ sind die Kompatibilitaetsschicht, die JEDE
 * ausgelieferte Station 1.0.3 heute beschreibt. Die Regeldatei sagt fuer Etappe 1 ausdruecklich
 * "NUR ADDITIV. NICHTS VERSCHARFEN": eine neue Laengengrenze dort wirkt in der SEKUNDE des
 * Veroeffentlichens auf jede Praxis im Feld, und eine Ablehnung nimmt dort binnen drei Takten die
 * Fern-Uebertragung. Fehlende Grenzen auf dieser Ebene sind deshalb eine getragene Entscheidung und
 * kein Mangel dieses Bausteins — sie werden vollstaendig AUFGEZAEHLT, aber nicht rot gemacht.
 * Fuer die NEUEN Zweige gilt das Gegenteil: dort schreibt heute noch niemand, jede Grenze ist
 * gefahrlos nachtragbar, und eine Luecke waere eine bewusst offen gelassene.
 */
const FLACHE_EBENE = ['meta', 'patients', 'protokoll'];
function istFlach(segs) { return segs.length > 2 && FLACHE_EBENE.indexOf(segs[2]) >= 0; }

/* ==========================================================================================
 * TEIL 3 — Ein Datenbaum, der sich wie die Realtime Database verhaelt
 * ========================================================================================== */

/*
 * rtdbWert(x) — was von einem JSON-Wert in der Datenbank WIRKLICH ankommt.
 *  • null und undefined loeschen den Schluessel (es gibt kein "leeres Feld").
 *  • Ein Objekt oder eine Liste OHNE ueberlebende Kinder ist danach selbst nichts mehr.
 *  • Eine Liste wird zu Kindern "0","1",... — genau so liest die Regelsprache sie.
 * Das ist kein Beiwerk: cloud.js schreibt vitals-Felder ausdruecklich als null (cloud.js:842) und
 * liefert leere Listen (alarms:[], kurvenNamen:[]). Wer die als vorhandene Felder mitzaehlt, prueft
 * hasChildren gegen Daten, die es in der Datenbank nie gibt.
 */
function rtdbWert(x) {
  if (x === null || x === undefined) return undefined;
  if (typeof x === 'number') return Number.isFinite(x) ? x : undefined;
  if (typeof x === 'string' || typeof x === 'boolean') return x;
  if (typeof x !== 'object') return undefined;
  const out = {};
  let n = 0;
  Object.keys(x).forEach((k) => {
    const v = rtdbWert(x[k]);
    if (v !== undefined) { out[String(k)] = v; n++; }
  });
  return n ? out : undefined;
}
function hole(baum, segmente) {
  let cur = baum;
  for (const s of segmente) {
    if (!hatKinder(cur)) return undefined;
    cur = cur[s];
  }
  return cur;
}
function setze(baum, segmente, wert) {
  let cur = baum;
  for (let i = 0; i < segmente.length - 1; i++) {
    const s = segmente[i];
    if (!hatKinder(cur[s])) cur[s] = {};
    cur = cur[s];
  }
  const letzt = segmente[segmente.length - 1];
  if (wert === undefined) delete cur[letzt];
  else cur[letzt] = wert;
}
function tiefKopie(x) { return x === undefined ? undefined : JSON.parse(JSON.stringify(x)); }

/*
 * Serverplatzhalter aufloesen. {".sv":"timestamp"} ist kein Wert, sondern ein Auftrag an den
 * Server — er wird VOR der Regelauswertung durch die Serverzeit ersetzt. Dass das so herum
 * geschieht, ist im Bestand belegt (die heutige Regel "sv": newData.isNumber() geht durch), aber
 * NICHT gemessen; deshalb steht es unten unter "NICHT GEPRUEFT".
 */
let PLATZHALTER_AUFGELOEST = 0;
function svAufloesen(x, jetzt) {
  if (!hatKinder(x)) return x;
  if (!Array.isArray(x) && x['.sv'] === 'timestamp') { PLATZHALTER_AUFGELOEST++; return jetzt; }
  const out = Array.isArray(x) ? [] : {};
  Object.keys(x).forEach((k) => { out[k] = svAufloesen(x[k], jetzt); });
  return out;
}

/*
 * schreibe(db, koerper, jetzt, uid) — EIN Mehrpfad-PATCH auf /live/<uid>, so bewertet, wie ihn die
 * Datenbank bewerten wuerde. Zurueck kommt { neu, ablehnungen, unklar, geprueft }.
 *
 * WELCHE KNOTEN GEPRUEFT WERDEN:
 *   • jeder Knoten INNERHALB der geschriebenen Werte (dort ist newData der neue Wert),
 *   • und jeder VORFAHRE bis zur Wurzel (dort ist newData der ZUSAMMENGEFUEHRTE Baum).
 * Ob Firebase die Vorfahren wirklich mitprueft, ist ungemessen. Der Plan ist auf die schlechtere
 * Annahme gebaut ("Vorfahren-.validate wird ausgewertet"), also prueft diese Datei sie mit. Eine
 * Meldung, die nur unter der schlechteren Annahme entsteht, wird als solche gekennzeichnet.
 *
 * LOESCHUNGEN (Wert null) bekommen KEIN .validate — das ist in Firebase so und im Plan ausdruecklich
 * als getragenes Restrisiko benannt. Der VORFAHRE wird trotzdem geprueft, denn er hat danach ein
 * Kind weniger: genau daran haengt hasChildren.
 */
function schreibe(db, koerper, jetzt, uid, authUid) {
  const neu = tiefKopie(db) || {};
  const basis = ['live', uid];
  const zuPruefen = new Map();     // pfadText -> segmente
  const geschrieben = new Set();   // Pfade, die im Koerper wirklich vorkommen (samt Inhalt)
  const ziele = [];                // die Zielpfade selbst, fuer die Schreibrechtspruefung
  const merke = (segs) => { zuPruefen.set(segs.join('/'), segs); };

  Object.keys(koerper).forEach((schluesselPfad) => {
    const rel = String(schluesselPfad).split('/').filter((x) => x !== '');
    const ziel = basis.concat(rel);
    const wert = rtdbWert(svAufloesen(koerper[schluesselPfad], jetzt));
    setze(neu, ziel, wert);
    ziele.push(ziel);
    // Vorfahren (einschliesslich des Ziels selbst)
    for (let i = 1; i <= ziel.length; i++) merke(ziel.slice(0, i));
    geschrieben.add(ziel.join('/'));
    // Alles innerhalb des geschriebenen Wertes
    (function tiefer(segs, w) {
      if (!hatKinder(w)) return;
      Object.keys(w).forEach((k) => {
        const s = segs.concat([k]);
        merke(s); geschrieben.add(s.join('/')); tiefer(s, w[k]);
      });
    })(ziel, wert);
  });

  const ablehnungen = [], unklar = [];
  let geprueft = 0;
  const pfade = Array.from(zuPruefen.values())
    .sort((a, b) => a.length - b.length || a.join('/').localeCompare(b.join('/')));

  /*
   * SCHREIBRECHT. In Firebase kaskadiert ein erteiltes ".write" nach unten und laesst sich weiter
   * unten NICHT mehr entziehen (Befund A1-2/B1-7/C1-6, im Plan als Grund fuer den Umbau in Etappe 2
   * genannt). Geprueft wird deshalb je ZIELPFAD, ob IRGENDEIN Knoten auf dem Weg von der Wurzel bis
   * dorthin das Recht erteilt. Nur so faellt auch ein Zielpfad auf, der ausserhalb des erlaubten
   * Baumes liegt — ein Test, der nur /live/<uid> fragt, wuerde jeden Pfaddurchbruch fuer erlaubt
   * halten, solange er nur unter derselben Praxis beginnt.
   */
  let schreibrecht = true;
  const ohneRecht = [];
  ziele.forEach((ziel) => {
    let erlaubt = false;
    for (let i = 1; i <= ziel.length && !erlaubt; i++) {
      const segs = ziel.slice(0, i);
      trefferFuer(segs).forEach((tr) => {
        const a = tr.knoten['.write'];
        if (typeof a !== 'string' || erlaubt) return;
        const r = werte(a, { neu: hole(neu, segs), alt: hole(db, segs), now: jetzt,
          auth: { uid: authUid }, bindungen: tr.bindungen });
        if (r.ergebnis === true) erlaubt = true;
        else if (r.ergebnis === null) unklar.push({ pfad: segs.join('/'), regel: a, grund: r.grund });
      });
    }
    if (!erlaubt) { schreibrecht = false; ohneRecht.push(ziel.join('/')); }
  });

  pfade.forEach((segs) => {
    const neuWert = hole(neu, segs);
    const altWert = hole(db, segs);
    // VORFAHR = ein Knoten, den der Koerper gar nicht benennt und der auch nicht im geschriebenen
    // Wert steckt. Nur fuer ihn haengt das Ergebnis an der ungemessenen Annahme, dass Firebase
    // Vorfahren-.validate mitauswertet — deshalb wird die Meldung getrennt gekennzeichnet.
    const istVorfahr = !geschrieben.has(segs.join('/'));
    trefferFuer(segs).forEach((tr) => {
      const ausdruck = tr.knoten['.validate'];
      if (ausdruck === undefined) return;                 // keine Regel = in Firebase erlaubt
      if (ausdruck === true) { geprueft++; return; }
      if (typeof ausdruck !== 'string') return;
      if (neuWert === undefined) return;                  // Loeschung: kein .validate
      geprueft++;
      const r = werte(ausdruck, {
        neu: neuWert, alt: altWert, now: jetzt,
        auth: { uid: authUid }, bindungen: tr.bindungen,
      });
      if (r.ergebnis === false) {
        ablehnungen.push({
          pfad: segs.join('/'),
          feld: segs[segs.length - 1],
          typ: typBezeichnung(neuWert),
          wert: kurz(neuWert),
          regel: ausdruck,
          vorfahr: istVorfahr,
        });
      } else if (r.ergebnis === null) {
        unklar.push({ pfad: segs.join('/'), regel: ausdruck, grund: r.grund });
      }
    });
  });

  return { neu: neu, ablehnungen: ablehnungen, unklar: unklar, geprueft: geprueft,
    ohneRecht: ohneRecht, schreibrecht: schreibrecht };
}
function typBezeichnung(w) {
  if (w === undefined) return 'nicht vorhanden';
  if (w === null) return 'null';
  if (Array.isArray(w)) return 'Liste';
  if (typeof w === 'object') return 'Objekt';
  return typeof w === 'string' ? 'Text(' + w.length + ')' : typeof w;
}
function kurz(w) {
  const s = typeof w === 'string' ? w : JSON.stringify(w);
  if (s == null) return String(w);
  return s.length > 70 ? s.slice(0, 70) + '…' : s;
}

/* ==========================================================================================
 * ABSCHNITT A — Der Auswerter selbst
 *
 * WELCHE FALSCHE UMSETZUNG BESTEHT DAS HIER NICHT: einer, der immer true liefert (die FALSCH-Faelle
 * fallen durch), einer, der immer false liefert (die WAHR-Faelle fallen durch), einer ohne
 * Kurzschluss im Fragezeichen-Operator (Fall 12 wirft dann auf .length einer Zahl), und einer, der
 * Unverstandenes still fuer erlaubt haelt (Fall 15 muesste dann true statt null liefern).
 * ========================================================================================== */
console.log('\n=== VERTRAG: Regeldatei <-> Sender <-> Tafel =================================\n');
abschnitt('A) Der Regelauswerter (ohne ihn prueft der Rest nichts)');

ok('installer/firebase-rtdb-rules.json ist als JSON lesbar', !!REGELN,
  'Ohne geladene Regeln kann diese Datei GAR NICHTS pruefen und waere gruen, weil sie nichts zu tun '
  + 'haette. Die Datei muss ausserdem in der Firebase-Konsole einfuegbar bleiben.', ladeFehler);

const U = { neu: undefined, alt: undefined, now: 1000000, auth: { uid: UID }, bindungen: { $station: SID, $praxis: UID } };
function mitWert(w, alt) { return Object.assign({}, U, { neu: w, alt: alt }); }
const SELBST = [
  ['true', U, true],
  ['false', U, false],
  ['newData.isString()', mitWert('abc'), true],
  ['newData.isString()', mitWert(7), false],
  ['newData.isNumber()', mitWert(7), true],
  ['newData.isNumber()', mitWert('7'), false],
  ['newData.isBoolean()', mitWert(true), true],
  ['!newData.isString()', mitWert({ a: 1 }), true],
  ['!newData.isString()', mitWert('x'), false],
  ["newData.hasChildren(['sid'])", mitWert({ sid: SID }), true],
  ["newData.hasChildren(['sid'])", mitWert({ name: 'x' }), false],
  ['newData.isString() ? newData.val().length <= 4 : true', mitWert(12345), true],
  ['newData.isString() ? newData.val().length <= 4 : true', mitWert('abcde'), false],
  ['newData.isString() ? newData.val().length <= 4 : true', mitWert('abcd'), true],
  ['root.child("x").val() === 1', U, null],
  ["newData.child('sid').val() === $station", mitWert({ sid: SID }), true],
  ["newData.child('sid').val() === $station", mitWert({ sid: 'stffffffffffff' }), false],
  ['newData.isNumber() && newData.val() <= now && newData.val() > now - 60000', mitWert(1000000), true],
  ['newData.isNumber() && newData.val() <= now && newData.val() > now - 60000', mitWert(900000), false],
  ['newData.isNumber() && newData.val() <= now && newData.val() > now - 60000', mitWert(1000001), false],
  ['!data.exists() && newData.hasChildren([\'ts\'])', mitWert({ ts: 5 }, undefined), true],
  ['!data.exists() && newData.hasChildren([\'ts\'])', mitWert({ ts: 5 }, { ts: 5 }), false],
  ['auth != null && auth.uid === $praxis', U, true],
  ['$station.length <= 24 && !newData.isString()', mitWert({ a: 1 }), true],
  ['newData.val() === $station', mitWert('stffffffffffff'), false],
  ['newData.isString() && newData.val().length <= 120', mitWert('x'.repeat(121)), false],
  ['newData.isString() && newData.val().length <= 120', mitWert('x'.repeat(120)), true],
  ["newData.val().matches(/^st[0-9a-f]{12}$/)", mitWert(SID), true],
  ["newData.val().matches(/^st[0-9a-f]{12}$/)", mitWert('nein'), false],
];
let selbstFehler = [];
SELBST.forEach(([a, umg, erwartet]) => {
  const r = werte(a, umg);
  if (r.ergebnis !== erwartet) selbstFehler.push(a + ' -> ' + r.ergebnis + ' (erwartet ' + erwartet + (r.grund ? ', ' + r.grund : '') + ')');
});
ok('der Auswerter rechnet ' + SELBST.length + ' bekannte Ausdruecke richtig — WAHR und FALSCH',
  selbstFehler.length === 0,
  'Ein Auswerter, der sich hier irrt, macht jede folgende Pruefung wertlos: er meldet entweder '
  + 'Ablehnungen, die es nicht gibt, oder — schlimmer — er meldet keine, obwohl die Datenbank '
  + 'ablehnen wuerde.', selbstFehler.join('\n                '));
ok('Unverstandenes liefert AUSDRUECKLICH "nicht auswertbar", nie "erlaubt"',
  werte('root.child("x").val() === 1', U).ergebnis === null
  && werte('newData.val().irgendwas()', mitWert('a')).ergebnis === null,
  'Wer Unverstandenes fuer erlaubt haelt, verwandelt jede kuenftige Regelverschaerfung in einen '
  + 'still bestandenen Test — und genau daran ist der toedliche Befund dieser Runde vorbeigelaufen.');

// Jeder Ausdruck der Regeldatei muss vom Auswerter wenigstens ZERLEGT werden koennen.
const ALLE_AUSDRUECKE = [];
(function sammle(n, p) {
  if (!n || typeof n !== 'object') return;
  ['.validate', '.write', '.read'].forEach((k) => {
    if (typeof n[k] === 'string') ALLE_AUSDRUECKE.push({ pfad: p, art: k, a: n[k] });
  });
  Object.keys(n).forEach((k) => { if (k[0] !== '.') sammle(n[k], p + '/' + k); });
})(REGELN, '');
const unparsbar = ALLE_AUSDRUECKE.filter((x) => { try { parse(zerlege(x.a)); return false; } catch (_) { return true; } });
ok('alle ' + ALLE_AUSDRUECKE.length + ' Regelausdruecke der Datei lassen sich zerlegen',
  unparsbar.length === 0,
  'Ein Ausdruck, den dieser Test nicht lesen kann, wird von ihm auch nicht geprueft. Er ist dann '
  + 'genau so ungeprueft wie vor diesem Test — nur sieht es nicht mehr so aus.',
  unparsbar.map((x) => x.pfad + ' ' + x.art).join(' | '));
unparsbar.forEach((x) => offen('Regelausdruck nicht zerlegbar: ' + x.pfad + ' ' + x.art + ' = ' + x.a));

/* ==========================================================================================
 * ABSCHNITT B — Der echte Datensatz
 * ========================================================================================== */
abschnitt('B) Der echte Datensatz (Registry + Simulator-Adapter, ohne Netz)');

const still = { info() {}, warn() {}, error() {} };
let Registry = null, SimulatorAdapter = null, CloudPublisher = null, tafel = null, ladefehler = [];
try { Registry = require(path.join(WURZEL, 'bridge', 'src', 'registry.js')).Registry; } catch (e) { ladefehler.push('registry.js: ' + e.message); }
try { SimulatorAdapter = require(path.join(WURZEL, 'bridge', 'src', 'adapters', 'simulator.js')).SimulatorAdapter; } catch (e) { ladefehler.push('simulator.js: ' + e.message); }
try { CloudPublisher = require(path.join(WURZEL, 'bridge', 'src', 'cloud.js')).CloudPublisher; } catch (e) { ladefehler.push('cloud.js: ' + e.message); }
try { tafel = require(path.join(WURZEL, 'bridge', 'src', 'tafel.js')); } catch (e) { ladefehler.push('tafel.js: ' + e.message); }

ok('registry.js, simulator.js, cloud.js und tafel.js sind ladbar',
  !!(Registry && SimulatorAdapter && CloudPublisher && tafel),
  'Ohne die echten Module bliebe nur ein von Hand abgetippter Musterdatensatz — und der stimmt genau '
  + 'so lange mit dem Sender ueberein, wie jemand daran denkt, ihn nachzuziehen.', ladefehler.join(' | '));

/*
 * baueRegistry() — eine Registry, die NICHTS auf die Platte schreibt.
 * Im Betrieb fuehrt sie bridge/data/protokoll.json und patient-akte.json. Ein Test, der die
 * Narkoseprotokolle des Anwenders ueberschreibt, richtet mehr Schaden an als er findet. Deshalb
 * werden beide Schreibwege sofort stillgelegt und der Speichertakt abgeschaltet; der geladene
 * Bestand wird geleert, damit die Pruefung nur mit den hier erzeugten Zeilen rechnet.
 */
function baueRegistry() {
  const reg = new Registry({ log: still });
  reg._protokollSpeichern = function () { /* Test schreibt nie in bridge/data */ };
  reg._akteSpeichern = function () { /* Test schreibt nie in bridge/data */ };
  if (reg._protokollTimer) clearInterval(reg._protokollTimer);
  reg.protokoll = {}; reg.protokollKopf = {}; reg.akteStore = {};
  return reg;
}

function bauePublisher(stationsName) {
  return new CloudPublisher({
    enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: 'http://127.0.0.1:1/',
    station: stationsName, stammdaten: true, rohwerte: true, kurven: true,
    minIntervalMs: 200,
    authFile: path.join(os.tmpdir(), 'vetstation-vertrag-test-nie-geschrieben-' + process.pid + '.json'),
    archiv: { enabled: false },
  }, { log: still });
}

// Ein echter Kurvenstreifen, wie ihn das LifeVet liefert (256 Hz EKG, 40 Hz CO2). model.js kappt
// selbst auf 4 Kanaele und 512 Werte — genau das soll hier auch gemessen werden.
function streifen(code, name, hz, laenge) {
  const s = new Array(laenge);
  for (let i = 0; i < laenge; i++) s[i] = Math.sin(i / 9) * 900 + Math.sin(i / 1.7) * 60;
  return { code: code, name: name, hz: hz, skala: 1, samples: s };
}

/*
 * datensatz(fuellText) — die vier Faelle, auf die es ankommt. DIE LUECKEN SIND DER INTERESSANTE
 * TEIL: ein Feld, das immer da ist, faellt niemandem auf; eines, das manchmal fehlt, reisst den
 * atomaren Koerper, sobald eine Regel es verlangt.
 *
 *   A  Hund, MIT Patienten-ID, MIT Kapnograf, MIT Kurven, MIT Alarmen, MIT Rohwerten und Akte
 *   B  Katze, OHNE Patienten-ID (Ersatzschluessel sw_katze_4), OHNE Kapnograf, OHNE Kurven, OHNE Alarme
 *   C  Kaninchen, MIT Patienten-ID, MIT Kapnograf, OHNE Kurven, MIT Alarm
 *   D  Reptil, OHNE Patienten-ID, OHNE Kapnograf, OHNE alles Weitere — der kargste Fall
 *
 * DER SIMULATOR IST DIE QUELLE, nicht ein abgetipptes Objekt: SimulatorAdapter._tick() baut die
 * Rahmen, sie gehen durch registry.ingest -> model.normalizeFrame -> matching.mergePatients. Was
 * der Simulator NICHT kennt (Alarme, Kurvenstreifen, Rohwerte, Patientenakte — er ist ein reiner
 * Vitalwertgeber), wird beim Durchreichen an den Rahmen gehaengt, und zwar in genau der Form, die
 * bridge/src/adapters/hl7.js:629 (Alarme) bzw. model.js:164-184 (roh, kurven, kurvenDaten) am
 * echten Geraet erzeugen. Der Kapnograf-Rahmen wird fuer B und D WEGGELASSEN — das ist die
 * ehrliche Nachbildung von "in diesem Saal haengt kein Kapnograf".
 *
 * fuellText=true schreibt in JEDES Textfeld 5000 Zeichen. Das ist die Messgrundlage fuer Abschnitt F:
 * so wird sichtbar, was der Code TATSAECHLICH kappt, statt es aus Kommentaren abzulesen.
 */
function datensatz(fuellText) {
  const lang = 'y'.repeat(5000);
  const T = (s) => (fuellText ? lang : s);
  const reg = baueRegistry();
  const vorgabe = [
    { devId: 'SIM-MON-1', patientId: 'A-102', species: 'hund', weightKg: 22, scenarioId: 'normal',
      monModel: T('uMEC12 Vet (Sim)'), capModel: T('Veta 5 Plus (Sim)') },
    { devId: 'SIM-MON-2', patientId: '', species: 'katze', weightKg: 4.2, scenarioId: 'hypoxie',
      monModel: T('LifeVet 10C (Sim)'), capModel: T('LifeVet 10C Kapno (Sim)') },
    { devId: 'SIM-MON-3', patientId: 'K-210', species: 'kaninchen', weightKg: 2.5, scenarioId: 'normal',
      monModel: T('uMEC12 Vet (Sim)'), capModel: T('Veta 5 Plus (Sim)') },
    { devId: 'SIM-MON-4', patientId: '', species: 'reptil', weightKg: 0.4, scenarioId: 'normal',
      monModel: T('LifeVet 10C (Sim)'), capModel: T('LifeVet 10C Kapno (Sim)') },
  ];
  // ohneKapno: fuer diese Geraete-Wurzeln wird der Narkose-/Kapnorahmen verworfen.
  const ohneKapno = { 'SIM-MON-2': 1, 'SIM-MON-4': 1 };
  const mitKurven = { 'SIM-MON-1': 1 };
  const mitAlarm = { 'SIM-MON-1': 1, 'SIM-MON-3': 1 };
  const mitAkte = { 'SIM-MON-1': 1 };

  const ctx = {
    log: still,
    emit: function (rahmen) {
      const wurzel = String(rahmen.deviceId || '').replace('CAP', 'MON');
      if (rahmen.deviceRole !== 'monitor' && ohneKapno[wurzel]) return;   // kein Kapnograf im Saal
      if (rahmen.deviceRole === 'monitor') {
        if (mitAlarm[wurzel]) {
          rahmen.alarms = [{ text: T('SpO2 unter Grenzwert'), quelle: 'geraet' },
            { text: T('EKG-Ableitung ab'), quelle: 'geraet' }];
        }
        if (mitKurven[wurzel]) {
          rahmen.kurvenDaten = [
            streifen('MDC_ECG_ELEC_POTL_II', T('EKG II'), 256, 512),
            streifen('MDC_CO2', T('Kapnogramm'), 40, 80),
          ];
        }
        if (mitAkte[wurzel]) {
          rahmen.patientName = T('Bello');
          rahmen.gebDatum = T('2019-05-01');
          rahmen.geschlecht = T('m');
          rahmen.akte = { besitzer: T('Frau Meier'), tierarzt: T('Dr. Klein'), rasse: T('Labrador') };
          rahmen.herkunft = { species: 'geraet', weightKg: 'konfig' };
          /*
           * DIE FELDER, DIE NUR DIE GEMEINSAME KAPPUNG BEGRENZT (Nachbesserung N9).
           * patientName, akte, alarms und roh kappt der Snapshotbau selbst auf 200 Zeichen —
           * ekgAnalyse, ventParams und die Textfelder in vitals gingen bis zum 30.07.2026
           * UNGEPRUEFT durch und werden erst von cloud.js:_kappeFeld() begrenzt. Ohne sie im
           * Fuellfall misst Abschnitt F genau die Kappung nicht, um die es N9 geht: nachgemessen
           * blieb der Test gruen, als die gemeinsame Kappung versuchsweise ausgebaut wurde.
           */
          rahmen.ekgAnalyse = { befund: T('Sinusrhythmus, keine Ektopie'), qrsMs: 80, st: T('isoelektrisch') };
          rahmen.ventParams = { modus: T('VCV'), Vt: 220, hinweis: T('Handbeatmung') };
          rahmen.vitals = Object.assign({}, rahmen.vitals, { ekgRhythm: T('sinus') });
          rahmen._meta = {
            roh: [{ code: '2301', label: T('Herzfrequenz'), wert: 96, einheit: T('bpm') },
              { code: '2302', label: T('SpO2'), wert: 97, einheit: T('%') }],
            kurven: [T('EKG II'), T('Kapnogramm')],
          };
        }
        rahmen.deviceIp = '192.168.0.51';
        rahmen.devicePort = 3502;
        rahmen.transport = 'tcp';
      }
      reg.ingest(rahmen);
    },
  };
  // rateMs sehr gross: der Zeitgeber des Simulators soll nicht mitlaufen, _tick() wird von Hand
  // gerufen. Ein Test, der auf einen Zeitgeber wartet, misst die Uhr statt die Regeln.
  const sim = new SimulatorAdapter({ rateMs: 3600000, patients: vorgabe }, ctx);
  sim._tick();
  sim.dispose();

  /*
   * DER SAALNAME GEHOERT IN DEN FUELLFALL. Er kommt aus bridge/config/devices.json (cfg.station,
   * cloud.js:156) — also aus einer Datei, die ein Mensch tippt und die niemand pruefen kann. Er
   * landet unveraendert in meta/station der flachen Ebene, und dort steht mit 120 Zeichen die
   * NIEDRIGSTE Grenze der ganzen Regeldatei. Waere er hier fest kurz, bliebe genau diese Grenze
   * ungemessen — und ein zu langer Saalname ist der billigste denkbare Weg, die Uebertragung einer
   * Praxis dauerhaft abzuschalten.
   */
  const stationsName = T('Praxis OP 1');
  const pub = bauePublisher(stationsName);
  const patients = reg.getPatients();
  const devices = reg.getDevices();
  reg.protokollSchritt(patients, (p) => pub.befundTitel(p));
  return { reg: reg, pub: pub, patients: patients, devices: devices, stationsName: stationsName,
    protokoll: reg.protokollFuerCloud(), snapshot: pub._buildSnapshot(patients, devices) };
}

let D = null, dFehler = null;
try { D = datensatz(false); } catch (e) { dFehler = e.message + '\n' + e.stack; }
// Die Einzelbenennungen des Datensatzes eintragen, damit regelPfad() auch unterhalb des Regelbaums
// zusammenfassen kann (die flache Ebene hat dort keine Kindregeln mehr).
if (D) {
  // NIE ueberschreiben: derselbe Schluessel ist einmal Patientenschluessel und einmal Protokollname
  // (sw_katze_4 entsteht aus beidem). Die erste Zuordnung gewinnt, sonst haengt der ausgegebene
  // Pfadname von der Reihenfolge dieser Schleifen ab und dieselbe Meldung sieht zweimal anders aus.
  const merke = (roh, name) => {
    const s = String(roh).replace(/[^A-Za-z0-9_-]/g, '_');
    if (s && !INSTANZ.has(s)) INSTANZ.set(s, name);
  };
  D.patients.forEach((p) => {
    if (p.patientKey) merke(p.patientKey, '$key');
    (p.devices || []).forEach((g) => { if (g.deviceId) merke(g.deviceId, '$geraet'); });
    (p.kurvenDaten || []).forEach((k) => { if (k.code) merke(k.code, '$kanal'); });
  });
  D.devices.forEach((g) => { if (g.deviceId) merke(g.deviceId, '$geraet'); });
  Object.keys(D.protokoll || {}).forEach((pid) => {
    merke(pid, '$patient');
    (D.protokoll[pid] || []).forEach((e) => merke(e.ts, '$zeitpunkt'));
  });
}
ok('der echte Datensatz entsteht aus der ganzen Kette (Simulator -> Registry -> Zusammenfuehrung -> Snapshot)',
  !!(D && D.snapshot && Object.keys(D.snapshot.patients).length >= 4),
  'Ohne Datensatz prueft diese Datei nichts und waere nur deshalb gruen.',
  dFehler || (D ? Object.keys(D.snapshot.patients).length + ' Patienten' : ''));

if (D) {
  const keys = Object.keys(D.snapshot.patients);
  const mitId = keys.filter((k) => k.indexOf('id_') === 0);
  const ohneId = keys.filter((k) => k.indexOf('sw_') === 0);
  ok('der Datensatz enthaelt Patienten MIT und OHNE Patienten-ID',
    mitId.length >= 2 && ohneId.length >= 2,
    'Der Ersatzschluessel sw_<art>_<kg> ist der Fall, in dem zwei 22-kg-Hunde denselben Schluessel '
    + 'bekommen — er MUSS in der Probe stecken, sonst prueft der Test nur den bequemen Fall.',
    'mit ID: ' + mitId.join(',') + ' / ohne ID: ' + ohneId.join(','));

  const mitKapno = keys.filter((k) => D.snapshot.patients[k].vitals.etco2 != null);
  const ohneKapno = keys.filter((k) => D.snapshot.patients[k].vitals.etco2 == null);
  ok('der Datensatz enthaelt Saele MIT und OHNE Kapnograf', mitKapno.length >= 1 && ohneKapno.length >= 1,
    'Ohne Kapnograf fehlen etco2/fico2 und ventParams. Genau solche LUECKEN reissen einen atomaren '
    + 'Koerper, sobald eine Regel ein Pflichtfeld verlangt — ein voller Datensatz findet das nie.',
    'mit: ' + mitKapno.length + ' / ohne: ' + ohneKapno.length);

  const mitKurven = keys.filter((k) => D.snapshot.patients[k].kurven);
  ok('der Datensatz enthaelt Patienten MIT und OHNE Kurvenstreifen',
    mitKurven.length >= 1 && mitKurven.length < keys.length,
    'kurven/<kanal>/b64 ist das mit Abstand groesste Blatt des ganzen Baumes und traegt die einzige '
    + '12000er-Grenze. Ohne einen echten Streifen in der Probe wird sie nie gemessen.',
    'mit Kurven: ' + mitKurven.join(','));

  const mitAlarm = keys.filter((k) => (D.snapshot.patients[k].alarms || []).length > 0);
  ok('der Datensatz enthaelt Patienten MIT und OHNE Alarme',
    mitAlarm.length >= 1 && mitAlarm.length < keys.length,
    'alarms ist eine LISTE VON OBJEKTEN — in der Datenbank also alarms/<i>/<feld>. Genau diese Form '
    + '(Objekt, wo eine Regel einen Einzelwert erwartet) war der toedliche Befund dieser Runde.',
    'mit Alarm: ' + mitAlarm.join(','));

  const protKeys = Object.keys(D.protokoll || {});
  ok('das Narkoseprotokoll traegt Zeilen fuer mehrere Patienten', protKeys.length >= 2,
    'Ohne Protokollzeilen bleibt der zweite Schreibweg (Weg P) ungeprueft — und der ist der einzige, '
    + 'dessen Regel etwas UNVERAENDERLICH macht.', protKeys.join(','));
}

/* ==========================================================================================
 * ABSCHNITT C — Hinrichtung: jeder Pfad gegen jede zutreffende Regel
 * ========================================================================================== */
abschnitt('C) Jeder Pfad des echten Datensatzes gegen jedes zutreffende ".validate"');

const JETZT = 1785400000000;   // feste Serverzeit: eine Regel mit "now" darf nicht von der Uhr abhaengen
const SV = { '.sv': 'timestamp' };

/*
 * koerperFolge(D) — die Schreibkoerper in der Reihenfolge, in der sie eine Station wirklich sendet.
 *
 * SEIT DEM 30.07.2026 BAUT cloud.js DIE NEUEN ZWEIGE SELBST. Diese Funktion baut deshalb NICHTS
 * mehr nach: sie haengt sich an _write() des echten Publishers und ruft die echten Schreibwege auf.
 * Solange hier eine Nachbildung stand, war sie eine ZWEITE Meinung darueber, wie ein Datenbankpfad
 * heisst — und zwei Meinungen ueber einen Pfad sind genau die Fehlerklasse, die dieser Test
 * verhindern soll. Gebaut werden also:
 *   Weg L  cloud.js:_pfade() + _delta()      saele/<sid>/patients/<key>/<feld>
 *   Weg T  cloud.js:_tafelSchreiben()        tafel/<sid>/{meta,uebersicht,geraete}
 *   Weg S  cloud.js:_spiegelSchreiben()      meta/* + patients/s<sid6>__<key>/<feld>
 *   Weg P  cloud.js:_protokollSchreiben()    saele/<sid>/protokoll/<pid>/<ts> (+ flach in F2-solo)
 *
 * DIE ATTRAPPE FUER DIE STATIONSKENNUNG ist kein Nachbau des Datenmodells, sondern der Ersatz fuer
 * eine Datei und einen Registry-Zugriff: stationsid.js hat eigene Pruefungen
 * (tools/stationsid-test.js). Was hier zaehlt, ist der KOERPER, den cloud.js daraus baut.
 */
function koerperFolge(d) {
  const folge = [];
  const snap = d.snapshot;
  const pub = d.pub;
  const ziel = '/live/' + UID + '.json?auth=T';

  // Alles, was der Publisher schreiben will, hier auffangen statt ins Netz schicken.
  const gefangen = [];
  const echtesWrite = pub._write;
  pub._write = function (methode, wohin, koerper) {
    gefangen.push({ methode: methode, ziel: wohin, koerper: koerper });
    return Promise.resolve({});
  };
  // Attrappe der Stationskennung (siehe oben).
  pub.stationsid = {
    instanz: 'a1b2c3d4e5f60718',
    sid: function () { return SID; },
    kollisionsstand: function () { return 'ausgeschlossen'; },
    kollisionVermerk: function () { return null; },
    darfPatientendatenSchreiben: function () { return true; },
    kollisionAusgeschlossen: function () { return true; },
  };
  pub.localId = UID;

  // --- 1) Weg L, erster Takt: das VOLLBILD als tiefe Pfade (kein Knoten 'patients' mehr, N7)
  const wurzel = 'saele/' + SID + '/patients/';
  const neu = pub._pfade(snap, SID);
  const keys = new Set(Object.keys(snap.patients || {}));
  folge.push({ was: 'neu: Weg L Vollbild (cloud.js:_delta())',
    koerper: pub._delta(neu, null, wurzel, keys, true, null) });

  // --- 2) Weg L, zweiter Takt: das Delta gegen den gemerkten Stand
  const stand = pub._alsStand(neu);
  const zweit = pub._buildSnapshot(d.patients, d.devices);
  const neu2 = pub._pfade(zweit, SID);
  folge.push({ was: 'neu: Weg L Delta (cloud.js:_delta())',
    koerper: pub._delta(neu2, stand, wurzel, new Set(Object.keys(zweit.patients || {})), false, null) });

  // --- 3) Weg T: Herzschlag und Kacheln, aus der ECHTEN Methode
  gefangen.length = 0;
  pub._tafelSchreiben({ patients: d.patients, devices: d.devices, jetzt: JETZT, ziel: ziel, sid: SID, darf: true });
  gefangen.forEach((g) => folge.push({ was: 'neu: Weg T Tafel (cloud.js:_tafelSchreiben())', koerper: g.koerper }));

  // --- 4) Weg S: der Kompatibilitaetsspiegel. F2-solo, also der VOLLE Spiegel mit Kurven — der
  //        groesste Koerper, den dieser Weg erzeugen kann.
  gefangen.length = 0;
  pub._flachGelesen = true; pub._tafelGelesen = true; pub._tafelEintraege = {}; pub._flachMeta = null;
  pub._spiegelSchreiben({ snapshot: snap, jetzt: JETZT, now: Date.now(), ziel: ziel, sid: SID, darf: true });
  gefangen.forEach((g) => folge.push({ was: 'neu: Weg S Spiegel (cloud.js:_spiegelSchreiben())', koerper: g.koerper }));

  // --- 5) Weg P: das Narkoseprotokoll in einem EIGENEN Koerper, mit BEIDEN Zielen (F2-solo)
  gefangen.length = 0;
  const protPfade = pub._protokollPfade(d.protokoll);
  pub._modus = 'F2-solo';
  pub.protokollInFlight = false;
  pub._protokollSchreiben(protPfade, 'T', SID);
  gefangen.forEach((g) => folge.push({ was: 'neu: Weg P Protokoll (cloud.js:_protokollSchreiben())',
    koerper: g.koerper, protokoll: true }));

  // --- 6) Der Deckelfall: eine Kachel verschwindet und muss ausdruecklich auf null gehen (N7).
  gefangen.length = 0;
  const wenigerPatienten = d.patients.slice(1);
  pub.tafelInFlight = false;
  pub._tafelSchreiben({ patients: wenigerPatienten, devices: d.devices, jetzt: JETZT, ziel: ziel, sid: SID, darf: true });
  gefangen.forEach((g) => folge.push({ was: 'neu: Kachel verschwindet -> Loeschung per null (N7)', koerper: g.koerper }));

  pub._write = echtesWrite;
  return folge;
}

let FOLGE = null, folgeFehler = null;
try { FOLGE = D ? koerperFolge(D) : null; } catch (e) { folgeFehler = e.message + '\n' + e.stack; }
ok('die Schreibkoerper lassen sich aus den ECHTEN Funktionen bauen', !!(FOLGE && FOLGE.length >= 5),
  'Ohne Schreibkoerper wird keine einzige Regel auf echte Daten angewandt.', folgeFehler);

/*
 * Die Gegenrichtung zur Umstellung oben: cloud.js MUSS die neuen Zweige selbst bauen, und diese
 * Datei muss sie von dort holen. Faellt eines von beidem weg, prueft der Test wieder eine
 * Nachbildung statt des Senders — und ein Test, der nicht den Sender prueft, prueft den Sender
 * nicht. Beide Seiten werden am Quelltext nachgesehen, damit die Zeile nicht nur eine Behauptung
 * ist.
 */
if (D) {
  const cloudQuelle = fs.readFileSync(path.join(WURZEL, 'bridge', 'src', 'cloud.js'), 'utf8');
  const baut = /'saele\/' \+/.test(cloudQuelle) && /tafel\.tafelPfade\s*\(/.test(cloudQuelle);
  const holtEcht = /pub\._tafelSchreiben\s*\(/.test(eigenerQuelltext)
    && /pub\._spiegelSchreiben\s*\(/.test(eigenerQuelltext);
  ok('cloud.js baut die saele-/tafel-Pfade selbst UND diese Datei holt sie von dort', baut && holtEcht,
    'Solange die Pfade hier nachgebaut werden, ist diese Datei eine zweite Meinung darueber, wie ein '
    + 'Datenbankpfad heisst. Genau daran ist der toedliche Befund dieser Runde vorbeigelaufen.',
    'cloud.js baut selbst: ' + baut + ', dieser Test holt die echten Koerper: ' + holtEcht);
}

const ABLEHNUNGEN = [], UNKLAR = [];
let GEPRUEFT_GESAMT = 0;
let DB = {};
if (FOLGE) {
  FOLGE.forEach((schritt) => {
    const r = schreibe(DB, schritt.koerper, JETZT, UID, UID);
    GEPRUEFT_GESAMT += r.geprueft;
    r.ablehnungen.forEach((a) => ABLEHNUNGEN.push(Object.assign({ schritt: schritt.was }, a)));
    r.unklar.forEach((u) => UNKLAR.push(Object.assign({ schritt: schritt.was }, u)));
    r.ohneRecht.forEach((p) => ABLEHNUNGEN.push({ schritt: schritt.was, pfad: p,
      feld: '(kein Schreibrecht auf diesem Weg)', typ: '-', wert: '-', regel: '.write', vorfahr: false }));
    DB = r.neu;
  });
}

ok('es wurden ueberhaupt Regeln auf echte Daten angewandt (' + GEPRUEFT_GESAMT + ' Auswertungen)',
  GEPRUEFT_GESAMT >= 200,
  'Bei zu wenigen Auswertungen bedeutet "keine Ablehnung" nichts. Diese Untergrenze ist die '
  + 'Versicherung dagegen, dass eine spaetere Aenderung den Datensatz oder die Pfadbildung leerlaufen '
  + 'laesst und der Test trotzdem gruen bleibt.');

const echt = ABLEHNUNGEN.filter((a) => !a.vorfahr);
const nurVorfahr = ABLEHNUNGEN.filter((a) => a.vorfahr);
ok('kein Pfad des echten Datensatzes wird von einer Regel ABGELEHNT', ABLEHNUNGEN.length === 0,
  'Ein Mehrpfad-PATCH ist ATOMAR. Ein einziges abgelehntes Feld nimmt den GANZEN Koerper mit — die '
  + 'Vitalwerte kommen nicht an, die Datenbank antwortet "Permission denied", cloud.js zaehlt das als '
  + 'Konfigfehler und schaltet nach DREI Takten die Fern-Uebertragung dauerhaft ab. Das gilt ab der '
  + 'Sekunde der Veroeffentlichung fuer JEDE ausgelieferte Praxis gleichzeitig.',
  ABLEHNUNGEN.map((a) => '[' + a.schritt + '] ' + a.pfad + '  Feld "' + a.feld + '" ist ' + a.typ
    + ' = ' + a.wert + (a.vorfahr ? '  (nur unter der schlechteren Annahme: Vorfahren-.validate)' : '')
    + '\n                    Regel: ' + a.regel).join('\n                '));
if (echt.length) {
  BEFUNDE.push('ABLEHNUNG (unmittelbar): ' + echt.map((a) => a.pfad + ' [' + a.typ + '] gegen ' + a.regel).join(' ; '));
}
if (nurVorfahr.length) {
  BEFUNDE.push('ABLEHNUNG (nur unter Vorfahren-Annahme): ' + nurVorfahr.map((a) => a.pfad + ' gegen ' + a.regel).join(' ; '));
}

UNKLAR.forEach((u) => offen('nicht auswertbar: ' + u.pfad + ' — Regel "' + u.regel + '" (' + u.grund + ')'));
ok('jede angewandte Regel liess sich auch AUSRECHNEN', UNKLAR.length === 0,
  'Eine Regel, die dieser Test nicht ausrechnen kann, ist ungeprueft. Sie steht unten unter '
  + '"NICHT GEPRUEFT" — aber sie schuetzt hier niemanden.',
  UNKLAR.slice(0, 6).map((u) => u.pfad + ': ' + u.grund).join(' | '));

/*
 * Ein Blatt OHNE Regel ist in Firebase ERLAUBT und damit UNGEDECKELT. Das kostet keine Ueberwachung,
 * aber es ist die Stelle, an der ein sehr langer Text in den Zweig mit der groessten Datenmenge
 * landet — geladen von jeder offenen Web-Ansicht bei jedem Delta.
 * Getrennt gefuehrt nach flacher Ebene (getragene Entscheidung, siehe FLACHE_EBENE) und neuen
 * Zweigen (dort ist eine Luecke ein Mangel).
 */
const ohneRegelNeu = new Set(), ohneRegelFlach = new Set();
(function sammleOhneRegel(baum, segs) {
  if (!hatKinder(baum)) {
    if (typeof baum === 'string' && segs.length > 2
      && !trefferFuer(segs).some((t) => t.knoten['.validate'] !== undefined)) {
      (istFlach(segs) ? ohneRegelFlach : ohneRegelNeu).add(regelPfad(segs));
    }
    return;
  }
  Object.keys(baum).forEach((k) => sammleOhneRegel(baum[k], segs.concat([k])));
})(DB, []);
ok('in den NEUEN Zweigen (tafel/, saele/) faellt jedes Textblatt unter irgendeine Laengengrenze',
  ohneRegelNeu.size === 0,
  'Ein Feld ohne Regel kann nichts abweisen — aber es ist auch durch nichts begrenzt (Nachbesserung '
  + 'N9). In den neuen Zweigen schreibt heute noch keine ausgelieferte Station: eine Grenze laesst '
  + 'sich dort gefahrlos nachtragen, entweder namentlich oder indem die $sonst-Auffangkette eine '
  + 'Stufe tiefer gefuehrt wird. Wer das jetzt nicht tut, kann es spaeter nur noch als Verschaerfung '
  + 'gegen bereits ausgelieferte 1.1.0-Stationen tun.',
  Array.from(ohneRegelNeu).slice(0, 15).join(' | '));
if (ohneRegelFlach.size) {
  offen('Auf der alten flachen Ebene stehen ' + ohneRegelFlach.size + ' Textfeldarten ohne jede '
    + 'Laengengrenze: ' + Array.from(ohneRegelFlach).sort().join(', ') + '. Das ist KEIN Versehen, sondern '
    + 'die Etappe-1-Entscheidung "nur additiv, nichts verschaerfen" — eine Grenze dort wirkt sofort '
    + 'auf jede ausgelieferte 1.0.3. Nachtragbar ist sie erst, wenn keine 1.0.3 mehr im Feld steht.');
}

/* ==========================================================================================
 * ABSCHNITT D — Gegenprobe: kaputte Datensaetze MUESSEN abgelehnt werden
 *
 * OHNE DIESEN ABSCHNITT IST DER GANZE TEST WERTLOS. Neun absichtlich kaputte Faelle, jeder an einer
 * ANDEREN Regelform. Ein Auswerter, der sie nicht faengt, faengt auch keine echte Abweichung.
 * ========================================================================================== */
abschnitt('D) Gegenprobe — absichtlich kaputte Datensaetze muessen ABGELEHNT werden');

function wirdAbgelehnt(koerper, vorbelegung, authUid) {
  const basis = vorbelegung ? tiefKopie(vorbelegung) : {};
  const r = schreibe(basis, koerper, JETZT, UID, authUid === undefined ? UID : authUid);
  return { abgelehnt: r.ablehnungen.length > 0 || !r.schreibrecht, r: r };
}
// Der Tafelkoerper aus der echten Methode — gesucht am Namen, nicht an einer Position:
// wie viele Koerper ein Weg erzeugt, entscheidet cloud.js, nicht dieser Test.
function koerperVon(teil) {
  const f = (FOLGE || []).find((x) => x.was.indexOf(teil) >= 0);
  return f ? f.koerper : {};
}
const gutTafel = koerperVon('Weg T Tafel');
const KAPUTT = [
  ['Tafelkopf mit FREMDER Stationskennung',
    { ['tafel/' + SID + '/meta']: { sid: 'stffffffffffff', v: 4, ts: JETZT, sv: SV } }, null,
    'newData.child(\'sid\').val() === $station'],
  ['flaches meta/station laenger als 120 Zeichen',
    { meta: { station: 'x'.repeat(121), ts: JETZT, sv: SV } }, null, 'length <= 120'],
  ['flaches meta OHNE das Pflichtkind "station"',
    { meta: { ts: JETZT, sv: SV } }, null, "hasChildren(['station','ts'])"],
  ['Tafel-sv als SELBST gerechnete Zahl (90 s alt) statt Serverplatzhalter',
    { ['tafel/' + SID + '/meta']: { sid: SID, v: 4, ts: JETZT, sv: JETZT - 90000 } }, null,
    'sv-Fenster von 60 s'],
  ['ein Vitalwert ist ein OBJEKT statt Zahl/Text/Wahrheitswert',
    { ['saele/' + SID + '/patients/id_A-102/vitals']: { hr: { wert: 96, einheit: 'bpm' } } }, null,
    'isNumber() || isBoolean()'],
  ['eine Protokollzeile OHNE ts',
    { ['saele/' + SID + '/protokoll/A-102/' + JETZT]: { hr: 96 } }, null, "hasChildren(['ts'])"],
  ['eine Protokollzeile wird ein ZWEITES Mal geschrieben',
    { ['saele/' + SID + '/protokoll/A-102/' + JETZT]: { ts: JETZT, hr: 97 } },
    { live: { [UID]: { saele: { [SID]: { protokoll: { 'A-102': { [JETZT]: { ts: JETZT, hr: 96 } } } } } } } },
    '!data.exists()'],
  ['ein Tafeltext laenger als die 400er-Grenze',
    { ['tafel/' + SID + '/uebersicht/id_A-102']: { n: 'x'.repeat(401), al: 0, dev: 1 } }, null,
    'length <= 400'],
  ['eine FREMDE Praxis schreibt in diesen Baum', gutTafel, null, 'auth.uid === $praxis'],
];
const nichtGefangen = [];
KAPUTT.forEach(([name, koerper, vorbelegung, welche], i) => {
  const authUid = (i === KAPUTT.length - 1) ? 'fremdeUid' : UID;
  let e = null;
  try { e = wirdAbgelehnt(koerper, vorbelegung, authUid); } catch (err) { e = { abgelehnt: false, fehler: err.message }; }
  if (!e.abgelehnt) nichtGefangen.push(name + '  (erwartet an: ' + welche + ')' + (e.fehler ? ' [' + e.fehler + ']' : ''));
});
ok('alle ' + KAPUTT.length + ' absichtlich kaputten Datensaetze werden abgelehnt', nichtGefangen.length === 0,
  'Was hier nicht auffaellt, faellt auch in der Praxis nicht auf. Solange auch nur einer dieser '
  + 'Faelle durchgeht, sagt ein gruener Abschnitt C NICHTS aus — er hiesse nur, dass dieser Test '
  + 'nichts sehen kann.', nichtGefangen.join('\n                '));

// Und die Gegenrichtung der Gegenprobe: der GUTE Koerper darf NICHT abgelehnt werden. Ohne diese
// Zeile bestuende Abschnitt D auch ein Auswerter, der alles ablehnt.
if (FOLGE) {
  const gut = wirdAbgelehnt(gutTafel, null, UID);
  ok('der unveraenderte Tafel-/Saal-Koerper wird NICHT abgelehnt', gut.abgelehnt === (ABLEHNUNGEN.length > 0),
    'Ein Auswerter, der alles ablehnt, bestuende die neun Faelle oben muehelos. Diese Zeile ist die '
    + 'Gegenrichtung dazu.',
    gut.r.ablehnungen.map((a) => a.pfad + ' gegen ' + a.regel).join(' | '));
}

/* ==========================================================================================
 * ABSCHNITT E — Gegenrichtung: jedes Pflichtfeld einer Regel muss im Datensatz vorkommen
 * ========================================================================================== */
abschnitt('E) Gegenrichtung — jedes Pflichtfeld (hasChildren) der Regeln steht im Datensatz');

/*
 * Alle hasChildren-Forderungen aus der Regeldatei einsammeln — nicht aus einer Liste im Kopf einer
 * Quelldatei, sondern aus dem Regeltext selbst. Wer die Regel verschaerft, wird hier rot, ohne dass
 * jemand eine Liste nachziehen muss. (tafel.js fuehrt in PFLICHTFELDER dieselbe Aussage als
 * KOMMENTAR — unten wird beides gegeneinander gehalten.)
 */
const PFLICHT = [], BEDINGT = [];
ALLE_AUSDRUECKE.filter((x) => x.art === '.validate').forEach((x) => {
  const re = /hasChildren\(\s*\[([^\]]*)\]\s*\)/g;
  let m;
  const treffer = [];
  while ((m = re.exec(x.a)) !== null) {
    const felder = m[1].split(',').map((s) => s.trim().replace(/^['"]|['"]$/g, '')).filter((s) => s);
    if (felder.length) treffer.push(felder);
  }
  if (!treffer.length) return;
  /*
   * EIN hasChildren HINTER EINEM "oder" IST KEIN PFLICHTFELD. /live/$praxis lautet
   * "hasChildren(['meta']) || hasChildren(['tafel']) || hasChildren(['saele']) ||
   * hasChildren(['verbund'])" — verlangt wird EINES von vieren, nicht alle vier. Wer diese Form
   * als Pflichtliste liest, meldet "verbund fehlt" fuer jeden gesunden Schreibvorgang und macht
   * damit genau die Sorte Fehlalarm, an der ein Test aufhoert, ernst genommen zu werden.
   * Diese Ausdruecke werden nicht uebersprungen: sie sind in Abschnitt C ohnehin ausgewertet
   * worden — dort als GANZER Ausdruck, was der einzige richtige Weg ist.
   */
  if (x.a.indexOf('||') >= 0) { BEDINGT.push({ pfad: x.pfad, regel: x.a }); return; }
  treffer.forEach((felder) => PFLICHT.push({ pfad: x.pfad, felder: felder, regel: x.a }));
});
BEDINGT.forEach((b) => offen('bedingte Kindforderung (hinter "oder", deshalb keine Pflichtliste — '
  + 'als ganzer Ausdruck in Abschnitt C ausgewertet): ' + b.pfad + ' = ' + b.regel));
ok('die Pflichtfelder liessen sich aus der Regeldatei ablesen', PFLICHT.length >= 3,
  'Ohne diese Liste ist die Gegenrichtung nicht pruefbar, und ein neu eingefuehrtes Pflichtfeld faellt '
  + 'erst in der Praxis auf — dort dann als Totalausfall der Uebertragung.',
  PFLICHT.map((p) => p.pfad + ' -> ' + p.felder.join('+')).join(' | '));

// Alle Datenpfade des am Ende entstandenen Baumes, mit $-Segmenten normalisiert.
function alleDatenPfade(baum, segs, out) {
  out.push(segs);
  if (!hatKinder(baum)) return out;
  Object.keys(baum).forEach((k) => alleDatenPfade(baum[k], segs.concat([k]), out));
  return out;
}
const DATENPFADE = DB ? alleDatenPfade(DB, [], []) : [];
const pflichtFehlt = [], pflichtUnbelegt = [];
PFLICHT.forEach((p) => {
  const segRegel = p.pfad.split('/').filter((x) => x);
  let belegt = 0;
  DATENPFADE.forEach((segs) => {
    if (segs.length !== segRegel.length) return;
    const passt = segs.every((s, i) => segRegel[i][0] === '$' || segRegel[i] === s);
    if (!passt) return;
    const wert = hole(DB, segs);
    if (wert === undefined) return;
    belegt++;
    p.felder.forEach((f) => {
      if (!hatKinder(wert) || wert[f] === undefined || wert[f] === null) {
        pflichtFehlt.push(segs.join('/') + ': Pflichtfeld "' + f + '" fehlt (Regel ' + p.pfad + ')');
      }
    });
  });
  if (!belegt) pflichtUnbelegt.push(p.pfad + ' (' + p.felder.join('+') + ')');
});
ok('jedes Pflichtfeld ist im echten Datensatz auch WIRKLICH gesetzt', pflichtFehlt.length === 0,
  'Ein Feld, das die Regel verlangt und der Code weglaesst, kostet nicht dieses Feld, sondern den '
  + 'ganzen atomaren Koerper samt Vitalwerten — und nach drei Takten die Fern-Uebertragung. In der '
  + 'Realtime Database ist ein null kein leeres Feld, sondern eine Loeschung: "gesetzt" heisst hier '
  + 'ausdruecklich "ungleich null".', pflichtFehlt.join('\n                '));
/*
 * Eine Pflichtfeldregel, die KEIN Pfad des Datensatzes trifft, ist oben nur deshalb gruen, weil
 * nichts sie gepruefte hat. Genau EIN Grund ist dafuer zulaessig: der Zweig wird von keiner Zeile
 * Code geschrieben (verbund/, Stufe 2 des Plans). Jeder andere unbelegte Fall ist eine Luecke im
 * Datensatz dieses Tests und macht ihn rot — sonst waechst die Liste der stillschweigend
 * ungeprueften Regeln mit jeder Erweiterung der Regeldatei.
 */
const NOCH_NICHT_GESCHRIEBEN = ['verbund'];
const unbelegtErklaert = [], unbelegtUnerklaert = [];
pflichtUnbelegt.forEach((x) => {
  const zweig = x.split('/').filter((s) => s)[2] || '';
  (NOCH_NICHT_GESCHRIEBEN.indexOf(zweig) >= 0 ? unbelegtErklaert : unbelegtUnerklaert).push(x);
});
unbelegtErklaert.forEach((x) => offen('Pflichtfeldregel nicht gegen echte Daten geprueft, weil kein '
  + 'Code diesen Zweig heute schreibt (Stufe 2): ' + x));
ok('jede Pflichtfeldregel wird entweder vom Datensatz BERUEHRT oder gehoert zu einem Zweig, den heute '
  + 'noch kein Code schreibt', unbelegtUnerklaert.length === 0,
  'Eine unbelegte Pflichtfeldregel ist in dieser Datei gruen, ohne etwas geprueft zu haben. Zulaessig '
  + 'ist das nur fuer ' + NOCH_NICHT_GESCHRIEBEN.join('/') + ' — dort schreibt Stufe 2 noch nichts. '
  + 'Alles andere gehoert in den Datensatz von datensatz(), sonst waechst hier still eine Liste '
  + 'ungeprueft geltender Regeln.', unbelegtUnerklaert.join(' | '));

// Und der Abgleich mit dem, was tafel.js in PFLICHTFELDER BEHAUPTET. Ein Kommentar, der etwas
// anderes sagt als die Regel, ist schlimmer als kein Kommentar.
if (tafel && tafel.PFLICHTFELDER) {
  const ausRegel = {};
  PFLICHT.forEach((p) => { ausRegel[p.pfad] = p.felder.slice().sort(); });
  const paare = [
    ['flachMeta', '/live/$praxis/meta'],
    ['tafelMeta', '/live/$praxis/tafel/$station/meta'],
    ['uebersicht', '/live/$praxis/tafel/$station/uebersicht/$key'],
    ['geraete', '/live/$praxis/tafel/$station/geraete/$geraet'],
  ];
  const abweichung = [];
  paare.forEach(([name, pfad]) => {
    const soll = (ausRegel[pfad] || []).join(',');
    const ist = (tafel.PFLICHTFELDER[name] || []).slice().sort().join(',');
    if (soll !== ist) abweichung.push(name + ': tafel.js sagt [' + ist + '], die Regel verlangt [' + soll + '] (' + pfad + ')');
  });
  ok('tafel.PFLICHTFELDER stimmt Feld fuer Feld mit der Regeldatei ueberein', abweichung.length === 0,
    'tafel.js behauptet in PFLICHTFELDER, WELCHE Felder die Regel erzwingt, und laesst alle anderen '
    + 'bei Bedarf weg. Stimmt diese Behauptung nicht mehr, laesst tafel.js ein Feld weg, das die Regel '
    + 'verlangt — und der 1-Hz-Koerper faellt samt Vitalwerten.', abweichung.join('\n                '));
}

/* ==========================================================================================
 * ABSCHNITT F — Kappungsgrenzen: gemessen, nicht abgelesen
 * ========================================================================================== */
abschnitt('F) Kappungsgrenzen — das laengste tatsaechlich erzeugbare Feld gegen jede Regelgrenze');

/*
 * WIE GEMESSEN WIRD: derselbe Datensatz wird ein zweites Mal gebaut, diesmal mit 5000 Zeichen in
 * JEDEM Textfeld des Geraets. Was danach in einem Schreibkoerper steht, ist das, was der Code
 * TATSAECHLICH erzeugen kann — unabhaengig davon, was ein Kommentar ueber die Kappung sagt. Dann
 * wird jede Textlaenge gegen die Grenze der Regel gehalten, die diesen Pfad trifft.
 *
 * WELCHE FALSCHE UMSETZUNG BESTEHT DAS NICHT: eine ohne Kappung (5000 kommen durch), eine mit einer
 * Kappung ueber der Regelgrenze, und eine, die nur einige Felder kappt. Eine Kappung, die nur im
 * Kommentar steht, besteht sie ebenfalls nicht — gemessen wird der Wert, nicht der Text.
 */
function grenzeAn(segs) {
  let g = null;
  trefferFuer(segs).forEach((tr) => {
    const a = tr.knoten['.validate'];
    if (typeof a !== 'string') return;
    const re = /newData\.val\(\)\.length\s*<=\s*(\d+)/g;
    let m;
    while ((m = re.exec(a)) !== null) { const n = Number(m[1]); if (g === null || n < g) g = n; }
  });
  return g;
}

let DF = null, dfFehler = null;
try { DF = datensatz(true); } catch (e) { dfFehler = e.message; }
ok('der Fuellfall (5000 Zeichen je Textfeld) laesst sich durch dieselbe Kette bauen', !!DF,
  'Ohne den Fuellfall wird keine einzige Kappung GEMESSEN — sie werden dann nur aus Kommentaren '
  + 'abgelesen, und genau das war der Zustand vor diesem Test.', dfFehler);

const KAPP = [];      // { pfad, gemessen, grenze }
if (DF) {
  let folgeF = null;
  try { folgeF = koerperFolge(DF); } catch (e) { folgeF = null; dfFehler = e.message; }
  if (folgeF) {
    /*
     * GEMESSEN WIRD AN DEN GESENDETEN KOERPERN, NICHT AM ENDZUSTAND DES BAUMES.
     * Ein Wert, der in einem spaeteren Takt wieder geloescht wird (etwa die Kachel eines Patienten,
     * der den Saal verlaesst), stand trotzdem einmal in einem Schreibvorgang — und genau dieser eine
     * Schreibvorgang haette den ganzen atomaren Koerper gerissen. Die erste Fassung dieser Messung
     * las den Endzustand und hat deshalb die Felder des zuletzt geloeschten Patienten (n, top)
     * ueberhaupt nicht gesehen.
     */
    folgeF.forEach((s) => {
      Object.keys(s.koerper).forEach((schluesselPfad) => {
        const ziel = ['live', UID].concat(String(schluesselPfad).split('/').filter((x) => x !== ''));
        (function messe(wert, segs) {
          if (typeof wert === 'string') {
            KAPP.push({ pfad: regelPfad(segs), gemessen: wert.length, grenze: grenzeAn(segs), flach: istFlach(segs) });
            return;
          }
          if (!hatKinder(wert)) return;
          Object.keys(wert).forEach((k) => messe(wert[k], segs.concat([k])));
        })(rtdbWert(svAufloesen(s.koerper[schluesselPfad], JETZT)), ziel);
      });
    });
  }
}
// Je Regelpfad nur der LAENGSTE gemessene Wert: dieselbe Aussage einmal je Patient zu wiederholen,
// verdeckt sie. Was zaehlt, ist "was kann an dieser Stelle hoechstens entstehen".
const JE_PFAD = new Map();
KAPP.forEach((k) => {
  const v = JE_PFAD.get(k.pfad);
  if (!v || k.gemessen > v.gemessen) JE_PFAD.set(k.pfad, k);
});
const KAPP_MAX = Array.from(JE_PFAD.values()).sort((a, b) => a.pfad.localeCompare(b.pfad));
const zuLang = KAPP_MAX.filter((k) => k.grenze !== null && k.gemessen > k.grenze);
const ungedeckelt = KAPP_MAX.filter((k) => k.grenze === null && k.gemessen >= 5000 && !k.flach);
ok('kein tatsaechlich erzeugbarer Wert ist LAENGER als die Grenze seiner Regel', zuLang.length === 0,
  'Liegt die Regelgrenze UNTER dem, was der Code erzeugen kann, ist sie keine Sperre, sondern eine '
  + 'FALLE: der Code schreibt dann etwas, das die Datenbank ablehnt — und nimmt den ganzen atomaren '
  + 'Koerper samt Vitalwerten mit. Die Datenports nehmen jede Gegenstelle an (probe.js bindet ohne '
  + 'Host-Argument, Firewall auf -Profile Any), ein langer Text ist also von aussen setzbar. '
  + 'Zu beheben ist es im CODE (gemeinsame Kappung, Nachbesserung N9), nicht durch Hochsetzen der '
  + 'Regelgrenze — die Grenze schuetzt das Kontingent ALLER Praxen.',
  zuLang.map((k) => k.pfad + ': erzeugbar ' + k.gemessen + ' Zeichen, Regel erlaubt ' + k.grenze).join('\n                '));
if (zuLang.length) {
  BEFUNDE.push('KAPPUNG (Code kappt nicht, Regel begrenzt — jeder dieser Werte lehnt den ganzen '
    + 'atomaren Koerper ab): ' + zuLang.map((k) => k.pfad + ' ' + k.gemessen + ' > ' + k.grenze).join(' ; '));
}
ok('in den NEUEN Zweigen steht kein tatsaechlich erzeugbarer Wert voellig UNGEDECKELT',
  ungedeckelt.length === 0,
  'Ein Feld ohne Regel UND ohne Kappung im Code ist die Stelle, an der ein sehr langer Text in den '
  + 'Zweig mit der groessten Datenmenge kommt — geladen von jeder offenen Web-Ansicht bei jedem Delta.',
  ungedeckelt.map((k) => k.pfad + ': ' + k.gemessen + ' Zeichen, keine Regelgrenze').join('\n                '));
// Die Messwerte in voller Laenge — ohne sie waere "bestanden" eine Behauptung ohne Zahlen.
const mitGrenze = KAPP_MAX.filter((k) => k.grenze !== null);
console.log('      gemessen: ' + mitGrenze.length + ' Regelgrenzen von echten Daten beruehrt, '
  + 'laengster erzeugbarer Wert je Grenze:');
mitGrenze.forEach((k) => console.log('        ' + (k.gemessen > k.grenze ? 'FALLE ' : '  ok  ')
  + String(k.gemessen).padStart(6) + ' / ' + String(k.grenze).padEnd(6) + ' ' + k.pfad));

/*
 * Die Kappungen von tafel.js zusaetzlich UNMITTELBAR messen — es sind die einzigen, die heute schon
 * greifen, und sie muessen auch dann gegen die Regel stehen, wenn der Datensatz eine Stelle gerade
 * nicht beruehrt.
 *
 * ZUR GRENZE AUF DEM SCHLUESSEL: "$key.length <= 400" begrenzt den SCHLUESSEL, nicht den Wert. Beide
 * getrennt zu lesen ist nicht Pedanterie — eine fruehere Fassung dieser Pruefung nahm die
 * Schluesselgrenze fuer eine Wertgrenze und hielt damit ein Blatt fuer gedeckelt, dessen Wert
 * unbegrenzt war.
 *
 * WICHTIG: findet der Test an einem Pfad GAR KEINE Grenze, ist das ein FEHLER und kein "bestanden".
 * Genau so entsteht eine Pruefung, die nie durchfallen kann.
 */
function schluesselGrenzeAn(segs) {
  let g = null;
  trefferFuer(segs).forEach((tr) => {
    const a = tr.knoten['.validate'];
    if (typeof a !== 'string') return;
    const m = /\$\w+\.length\s*<=\s*(\d+)/.exec(a);
    if (m) { const n = Number(m[1]); if (g === null || n < g) g = n; }
  });
  return g;
}
if (tafel) {
  const lang = 'y'.repeat(5000);
  const P = (p) => ('live/' + UID + '/' + p).replace('$station', SID).split('/');
  const messungen = [
    ['tafel/$station/meta/name (Wert)', tafel.text(lang, tafel.GRENZEN.tafelText).length, grenzeAn(P('tafel/$station/meta/name'))],
    ['tafel/$station/geraete/$geraet/ip (Wert)', tafel.text(lang, tafel.GRENZEN.adresse).length, grenzeAn(P('tafel/$station/geraete/x/ip'))],
    ['tafel/$station/uebersicht/$key (SCHLUESSEL)', tafel.schluessel(lang).length, schluesselGrenzeAn(P('tafel/$station/uebersicht/x'))],
    ['tafel/$station (SCHLUESSEL, Stationskennung)', tafel.GRENZEN.sid, schluesselGrenzeAn(P('tafel/x'))],
    ['saele/$station/patients/$key (SCHLUESSEL)', tafel.schluessel(lang).length, schluesselGrenzeAn(P('saele/$station/patients/x'))],
    ['meta/station (Wert, GRENZEN.spiegelStation)', tafel.GRENZEN.spiegelStation, grenzeAn(P('meta/station'))],
    ['gemeinsame Kappung tafel.kappe() (Wert)', String(tafel.kappe(lang)).length, grenzeAn(P('saele/$station/patients/x/species'))],
  ];
  const ohneGrenze = messungen.filter(([, , g]) => g === null);
  ok('zu jeder gemessenen Kappung liess sich die zugehoerige Regelgrenze auch FINDEN',
    ohneGrenze.length === 0,
    'Wo keine Grenze gefunden wird, vergleicht die naechste Zeile nichts und ist nur deshalb gruen. '
    + 'Entweder ist der Pfad falsch geschrieben oder die Regel hat die Grenze verloren — beides muss '
    + 'auffallen.', ohneGrenze.map(([p]) => p).join(' | '));
  const zuGross = messungen.filter(([, n, g]) => g !== null && n > g);
  ok('die GEMESSENEN Kappungen von tafel.js liegen unter den Grenzen der Regeldatei', zuGross.length === 0,
    'tafel.js ist die einzige Datei, die heute schon kappt. Waere eine ihrer Kappungen groesser als '
    + 'die Regelgrenze, faellt der 1-Hz-Herzschlag samt Vitalwerten — und zwar nur bei dem einen '
    + 'Patienten mit dem langen Namen, also unvorhersehbar und ohne Muster.',
    zuGross.map(([p, n, g]) => p + ': Code erzeugt ' + n + ', Regel erlaubt ' + g).join('\n                '));
  messungen.forEach(([p, n, g]) => console.log('        ' + (g !== null && n > g ? 'FALLE ' : '  ok  ')
    + String(n).padStart(6) + ' / ' + String(g === null ? '?' : g).padEnd(6) + ' ' + p));
  ok('tafel.kappe() kappt ueberhaupt (5000 Zeichen kommen nicht durch)',
    String(tafel.kappe(lang)).length < 5000 && tafel.text(lang, 40).length <= 40
    && tafel.schluessel(lang).length < 5000,
    'Eine Kappungsfunktion, die nichts kappt, ist die gefaehrlichste Form: jeder Aufrufer verlaesst '
    + 'sich darauf, und niemand sieht es. Diese Zeile ist die Gegenrichtung zur Pruefung darueber — '
    + 'ohne sie bestuende sie auch eine Kappung, die einfach null zurueckgibt.',
    'kappe -> ' + String(tafel.kappe(lang)).length + ', text(40) -> ' + tafel.text(lang, 40).length
    + ', schluessel -> ' + tafel.schluessel(lang).length);
}

/* ==========================================================================================
 * WAS DIESER TEST NICHT GEPRUEFT HAT — vollstaendig und ausdruecklich
 * ========================================================================================== */
offen('Wie Firebase ".sv"-Platzhalter zur Auswertungszeit behandelt, ist ungemessen. Dieser Test setzt '
  + 'sie VOR der Regelauswertung auf die Serverzeit (' + PLATZHALTER_AUFGELOEST + ' Aufloesungen). '
  + 'Belegt ist die Richtung nur indirekt: die heutige Regel "sv": newData.isNumber() geht im Feld '
  + 'durch. Gemessen wird es erst von tools/regel-messung.js gegen ein Wegwerf-Konto.');
offen('Ob Firebase das ".validate" eines VORFAHREN bei einem tiefen Schreibvorgang mitauswertet, ist '
  + 'ungemessen. Dieser Test rechnet mit der schlechteren Annahme (ja) und kennzeichnet Meldungen, '
  + 'die nur daraus entstehen.');
offen('Ob bei einem namentlich genannten Kind ZUSAETZLICH die $-Platzhalter-Regel des Geschwisters '
  + 'gilt, ist ungemessen. Dieser Test wertet BEIDE aus (schlechtere Annahme).');
offen('Loeschungen (Wert null) werden von ".validate" nicht erfasst — so steht es in Firebase und so '
  + 'rechnet dieser Test. Dass eine Station im selben Konto den Zweig eines Nachbarn per DELETE '
  + 'entfernen kann, ist ein im Plan getragenes Restrisiko und hier NICHT geprueft.');
offen('Die Koerper der Wege L, T, S und P kommen seit dem 30.07.2026 aus den ECHTEN Methoden von '
  + 'cloud.js. Was diese Datei dabei NICHT prueft, ist die Reihenfolge und der Takt, in dem sie '
  + 'gesendet werden — nur ihr Inhalt gegen die Regeln. Takt und Trennung der Ziele prueft '
  + 'tools/cloud-test.js gegen einen nachgebauten Firebase-Endpunkt.');
offen('Die Stationskennung ist hier eine Attrappe (feste sid, feste Instanz). Ihre Erzeugung, ihre '
  + 'Formatsperre und die Erkennung einer doppelten Kennung prueft tools/stationsid-test.js.');
offen('verbund/lan/$station wird von keiner Zeile Code gebaut (Stufe 2) und ist deshalb nur als Regel '
  + 'vorhanden, nicht gegen echte Daten geprueft.');
offen('Der Firestore-Verlauf (installer/firestore-rules.txt) ist nicht Gegenstand dieser Datei — '
  + 'dafuer ist tools/regeln-test.js zustaendig.');
offen('Geprueft wird die Regeldatei im Arbeitsstand, NICHT die im Firebase-Projekt veroeffentlichte. '
  + 'Dass beide gleich sind, kann ohne Netz niemand feststellen.');

console.log('\n--- NICHT GEPRUEFT (' + OFFEN.length + ') ------------------------------------------------');
OFFEN.forEach((t) => console.log('  • ' + t));

console.log('\n===============================================================================');
if (BEFUNDE.length) {
  console.log('  WIDERSPRUECHE ZWISCHEN CODE UND REGELDATEI:');
  BEFUNDE.forEach((b) => console.log('   - ' + b));
  console.log('');
}
if (fail) {
  console.log('  ERGEBNIS: ' + fail + ' von ' + (pass + fail) + ' Pruefungen FEHLGESCHLAGEN (' + pass + ' OK).');
  console.log('  Ein Widerspruch hier ist im Feld der Ausfall der Fern-Uebertragung ALLER Praxen.');
} else {
  console.log('  ALLE ' + pass + ' PRUEFUNGEN BESTANDEN — ' + GEPRUEFT_GESAMT + ' Regelauswertungen auf echten Daten.');
}
console.log('===============================================================================\n');
process.exit(fail ? 1 : 0);
