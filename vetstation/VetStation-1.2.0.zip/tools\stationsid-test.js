'use strict';
/*
 * stationsid-test.js — sichert die STATIONSKENNUNG ab (ab 1.1.0, mehrere OP-Saele im selben Konto).
 *
 * ZWEI PRUEFGRUPPEN SIND HIER AM 30.07.2026 ERSATZLOS GESTRICHEN. Wer sie "wiederherstellt",
 * stellt genau die zwei Bauformen wieder her, die die Gegenpruefung verworfen hat:
 *   • eindeutigMachen/sidMitSuffix/warDoppelt (automatische Selbstumbenennung). Grund: das
 *     Erkennungsmerkmal war unerfuellbar, und eine Station, die sich mitten in einer Narkose
 *     selbst umbenennt, verschwindet fuer die Fern-Ansicht als Saal, taucht als neuer, leerer Saal
 *     auf und zerschneidet ihr unveraenderliches Narkoseprotokoll. Umbenennen darf nur ein MENSCH
 *     (umbenennen(), unten geprueft).
 *   • lanGeheim/brauchtRotation/vorgaengerGueltig/vorbereiteterWechsel (gemeinsames Geheimnis mit
 *     Rotation). Grund: das Geheimnis muesste im Kontobaum liegen, und diesen Baum abonniert JEDE
 *     Fern-Ansicht dauerhaft im Browser — jedes Handy mit offener Praxis-Ansicht haette damit den
 *     Schluessel zum Nachbar-Port im Praxisnetz. Ersetzt durch ein Ed25519-Paar, von dem nur der
 *     oeffentliche Teil veroeffentlicht wird (unten geprueft).
 *
 * EINE PRUEFUNG IST AM 30.07.2026 ERSETZT WORDEN, weil sie einen Irrtum festschrieb: sie forderte,
 * dass nach einem Neustart wieder Patientendaten erlaubt sind, und nannte das "ein Fehlalarm darf
 * keine Praxis dauerhaft abschneiden". Das war richtig gemeint und falsch geprueft: im Betrieb
 * schnappte die Sperre beim ersten Rueckleseweg desselben Starts erneut zu, weil die eigene Instanz
 * des VORHERIGEN Prozesses als Zwilling galt. Geprueft wird jetzt die Ursache (unten, Befund B1).
 *
 * Was hier NIE wieder passieren darf:
 *   • Zwei Praxis-PCs bekommen dieselbe Kennung und schreiben Patientendaten in denselben Zweig —
 *     dann mischen sich die Werte zweier Saele Feld fuer Feld, und ein ausgefallener Saal kann
 *     frisch aussehen.
 *   • Eine Einzelstation OHNE jeden Zwilling sperrt sich selbst von der Fern-Ansicht aus, weil sie
 *     die eigene Instanz ihres vorherigen Starts fuer einen Zwilling haelt (Befund B1).
 *   • Die Sperre startet offen, so dass zwei geklonte PCs von der ersten Sekunde an mischen
 *     (Befund B2) — oder sie startet zu und findet keinen Weg mehr heraus.
 *   • Ein Formatfehler im zurueckgelesenen Wert gilt als Beweis fuer einen zweiten Rechner
 *     (Befund B3).
 *   • Der private Schluessel liegt in einem aufzaehlbaren Feld und faellt aus einem res.json()
 *     heraus (Befund B4).
 *   • Dieselbe Maschine bekommt bei jedem Start eine NEUE Kennung — dann bleibt bei jedem
 *     Neustart ein verwaister Saal in der Fern-Ansicht stehen.
 *   • Eine schon erzeugte station-id.json wird verworfen, weil ihr ein Feld fehlt (genau das tat
 *     das alte istBrauchbar() mit jedem Datensatz ohne lanGeheim).
 *   • Ein Wert, der nicht der festen Form entspricht, landet in einem Datenbankpfad.
 *   • Der Rechnername steht im Klartext in der Datenbank (verraet Praxis-/Personennamen).
 *
 * Laeuft ohne Netz und ohne Registry-Zugriff: geprueft werden die reinen Funktionen und die
 * Datei-Mechanik in einem temporaeren Ordner; die Registry-Abfrage wird als Funktion untergeschoben.
 * Wo Fristen im Spiel sind, wird die UHR GESTELLT (opts.jetzt) — ein Test, der echte Sekunden
 * abwartet, wird irgendwann uebersprungen und ist dann kein Test mehr.
 *
 * Start: node tools/stationsid-test.js      (laeuft auch in `node tools/alle-tests.js`)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const S = require('../bridge/src/stationsid');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

const still = { info() {}, warn() {}, error() {} };
/* Ein Log, das nur zaehlt. Gebraucht wird es fuer die Drosseln (Befund A3): eine Warnung, die im
 * 1-Hz-Takt einer Narkose je Sekunde erscheint, verdeckt die klinischen Warnungen daneben — und
 * das laesst sich nur pruefen, indem man die Zeilen zaehlt statt sie wegzuwerfen. */
function zaehlLog() {
  const z = { info: 0, warn: 0, error: 0, letzte: null };
  z.log = {
    info() { z.info++; },
    warn(_b, t) { z.warn++; z.letzte = t; },
    error() { z.error++; },
  };
  return z;
}
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'vetstation-sid-'));
function datei(n) { return path.join(TMP, n); }
/* Enthaelt ein Objekt irgendwo diese Zeichenkette? Funktionen und Zyklen ergeben '' statt einer
 * Ausnahme — geprueft werden soll der Schluessel, nicht die Robustheit von JSON.stringify. */
function textVon(v) { try { const s = JSON.stringify(v); return s === undefined ? '' : s; } catch (e) { return ''; } }

/* Die Registry wird nie angefasst: statt reg.exe liefert eine Funktion einen festen Wert.
 * gelesen zaehlt mit, damit "die Datei gewinnt immer" nachweisbar ist. */
const GUID = '11111111-2222-3333-4444-555555555555';
let gelesen = 0;
function guidFest() { gelesen++; return Promise.resolve(GUID); }
function guidNichtLesbar() { gelesen++; return Promise.resolve(null); }
function guidLehntAb() { gelesen++; return Promise.reject(new Error('Zeitablauf bei der Registry-Abfrage')); }

console.log('VetStation — Stationskennung (mehrere OP-Saele im selben Praxis-Konto)\n');

/* ---------------- 1) Form: was in einen Pfad darf ---------------- */
console.log('Nur die feste Form darf in einen Datenbankpfad:');
ok('gueltig ohne Suffix', S.pruefeSid('st7f3a91c2b45d'));
ok('gueltig mit Suffix (Altbestand einer aelteren Fassung)', S.pruefeSid('st7f3a91c2b45d-9c1f'));
ok('zu kurz wird abgelehnt', !S.pruefeSid('st7f3a91c2b4'));
ok('Grossbuchstaben werden abgelehnt', !S.pruefeSid('ST7F3A91C2B45D'));
ok('fehlendes Praefix wird abgelehnt', !S.pruefeSid('7f3a91c2b45d'));
ok('Pfadtrenner wird abgelehnt', !S.pruefeSid('st7f3a91c2b45d/meta'));
ok('Punkt wird abgelehnt', !S.pruefeSid('st7f3a91c2b45d.'));
ok('Verzeichnissprung wird abgelehnt', !S.pruefeSid('../fremd') && !S.pruefeSid('st7f3a91c2b45d/../x'));
ok('leer/undefined wird abgelehnt', !S.pruefeSid('') && !S.pruefeSid(undefined) && !S.pruefeSid(null));
ok('Objekt wird abgelehnt', !S.pruefeSid({ toString() { return 'st7f3a91c2b45d'; } }));

/* Befund B7: die Zusage "Laenge <= 24" aus dem Plan darf nicht daran haengen, dass SID_FORM den
 * Suffix zufaellig mit '?' und nicht mit '*' quantifiziert. Geprueft wird deshalb die INVARIANTE
 * gegen einen systematisch gebauten Kandidatensatz, nicht ein Literal.
 * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Eine, die SID_FORM auf '(-[0-9a-f]{4})*' oder '{0,3}'
 * lockert (naheliegend, wenn spaeter mehrere Suffixe erlaubt werden sollen) UND die ausdrueckliche
 * Laengenpruefung in pruefeSid() nicht mitzieht: dann nimmt pruefeSid einen 29 Zeichen langen Wert
 * an und die Schleife wird rot. Die heutige Fassung besteht sie zweifach (Regex UND Laenge). */
console.log('\nDie Laengengrenze aus dem Plan ist eine Pruefung, nicht ein Zufall:');
const kandidaten = ['st7f3a91c2b45d'];
for (let n = 1; n <= 4; n++) kandidaten.push('st7f3a91c2b45d' + '-9c1f'.repeat(n));
kandidaten.push('st' + 'a'.repeat(12) + '-0000-1111-2222');
kandidaten.push('st' + 'a'.repeat(12) + '-' + 'b'.repeat(40));
let ueberlang = 0, ueberlangAkzeptiert = 0;
for (const k of kandidaten) {
  if (k.length > S.SID_MAX) ueberlang++;
  if (k.length > S.SID_MAX && S.pruefeSid(k)) ueberlangAkzeptiert++;
}
ok('der Kandidatensatz enthaelt ueberhaupt Werte ueber 24 Zeichen (sonst pruefte die Schleife nichts)',
  ueberlang >= 3, 'ueberlange Kandidaten: ' + ueberlang);
ok('kein von pruefeSid akzeptierter Wert ist laenger als ' + S.SID_MAX + ' Zeichen',
  ueberlangAkzeptiert === 0, 'akzeptiert: ' + ueberlangAkzeptiert);
ok('die laengste heute zulaessige Kennung ist die Suffixform mit 19 Zeichen',
  S.pruefeSid('st7f3a91c2b45d-9c1f') && 'st7f3a91c2b45d-9c1f'.length === 19 && S.frischeSid().length === 14);

console.log('\nFormatsperre AUCH beim Einsetzen in einen Pfad:');
ok('gueltige Kennung kommt kodiert und unveraendert durch', S.sidPfad('st7f3a91c2b45d') === 'st7f3a91c2b45d');
ok('"../fremd" ergibt keinen Pfadteil, sondern null', S.sidPfad('../fremd') === null);
ok('"a/b" ergibt keinen Pfadteil', S.sidPfad('st7f3a91c2b45d/x') === null);
ok('encodeURIComponent wuerde einen Sprung entschaerfen — geprueft wird trotzdem die Form',
  encodeURIComponent('../fremd') === '..%2Ffremd');

/* ---------------- 2) Ableitung: gleich bleibt gleich, verschieden bleibt verschieden ---------------- */
console.log('\nAbleitung — der Kern der Sache:');
const a1 = S.sidAus(GUID, 'OP-PC-1');
const a2 = S.sidAus(GUID, 'OP-PC-1');
const b1 = S.sidAus(GUID, 'OP-PC-2');
const c1 = S.sidAus('99999999-8888-7777-6666-555555555555', 'OP-PC-1');
ok('dieselbe Maschine ergibt dieselbe Kennung', a1 === a2, a1 + ' / ' + a2);
ok('anderer Rechnername ergibt eine andere Kennung', a1 !== b1);
ok('andere Geraete-ID ergibt eine andere Kennung', a1 !== c1);
ok('abgeleitete Kennung hat die gueltige Form', S.pruefeSid(a1), a1);
ok('leere Quelle ergibt trotzdem eine formgueltige Kennung', S.pruefeSid(S.sidAus('', '')));
ok('Kurzform sind 6 Hexzeichen ohne Praefix', /^[0-9a-f]{6}$/.test(S.sidKurz(a1)) && S.sidKurz(a1) === a1.slice(2, 8));
ok('Rechnername steht NICHT im Klartext in der Kennung', a1.indexOf('OP-PC') < 0 && a1.indexOf('op-pc') < 0);
/* Befund B9: der Plan schreibt hostHash:"<8 hex>". Eine falsche Fassung mit 12 Zeichen faellt hier durch. */
ok('Rechnername wird nur als Fingerabdruck gespeichert, 8 Hexzeichen wie im Plan',
  /^[0-9a-f]{8}$/.test(S.hostHash('OP-PC-1')) && S.hostHash('OP-PC-1') !== S.hostHash('OP-PC-2'),
  S.hostHash('OP-PC-1'));
ok('eine gewuerfelte Kennung ist formgueltig und jedes Mal anders',
  S.pruefeSid(S.frischeSid()) && S.frischeSid() !== S.frischeSid());

/* Befund B8: der Schluessel des Kompatibilitaetsspiegels ist s<sid6>__<key>. Fielen Suffixform und
 * Grundform auf denselben Kurzwert, mischten sich auf der flachen Ebene wieder zwei Saele Feld fuer
 * Feld — und genau diese Wertepaarung ist die einzige, bei der es darauf ankommt, weil der Suffix in
 * der verworfenen Bauform GENAU DANN entstand, wenn zwei Stationen dieselben 12 Hexzeichen hatten.
 * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? sidKurz = sid.slice(2,8) ohne Sonderfall. */
console.log('\nDie Kurzform muss ueber die ganze akzeptierte Form eindeutig sein:');
ok('Suffixform und ihre Grundform ergeben NICHT denselben Spiegelschluessel',
  S.sidKurz('st7f3a91c2b45d-9c1f') !== S.sidKurz('st7f3a91c2b45d'),
  S.sidKurz('st7f3a91c2b45d-9c1f') + ' / ' + S.sidKurz('st7f3a91c2b45d'));
ok('beide Kurzformen sind trotzdem 6 Hexzeichen (der Spiegelschluessel darf nicht laenger werden)',
  /^[0-9a-f]{6}$/.test(S.sidKurz('st7f3a91c2b45d-9c1f')) && /^[0-9a-f]{6}$/.test(S.sidKurz('st7f3a91c2b45d')));
ok('fuer jede Kennung, die dieses Modul erzeugt, bleibt die Kurzform <sid6> aus dem Plan',
  S.sidKurz(S.frischeSid()).length === 6 && S.sidKurz(a1) === a1.slice(2, 8));
ok('zwei verschiedene Kennungen ergeben verschiedene Kurzformen', S.sidKurz(a1) !== S.sidKurz(b1));

/* ---------------- 3) Schluesselpaar statt gemeinsamem Geheimnis ---------------- */
console.log('\nEd25519-Paar — nur der oeffentliche Teil darf in den Kontobaum:');
const p1 = S.ed25519Paar();
const p2 = S.ed25519Paar();
ok('privater Teil ist PKCS8 DER in base64 (64 Zeichen)', /^[A-Za-z0-9+/=]{64}$/.test(p1.priv), String(p1.priv));
ok('oeffentlicher Teil ist SPKI DER in base64 (60 Zeichen)', /^[A-Za-z0-9+/=]{60}$/.test(p1.pub), String(p1.pub));
ok('Fingerabdruck sind 16 Hexzeichen', /^[0-9a-f]{16}$/.test(p1.fp), String(p1.fp));
ok('Fingerabdruck ist aus dem OEFFENTLICHEN Teil nachrechenbar', p1.fp === S.fingerabdruck(p1.pub));
ok('zwei Paare sind verschieden', p1.priv !== p2.priv && p1.pub !== p2.pub && p1.fp !== p2.fp);
ok('der Fingerabdruck passt zum Regelmass (<= 32 Zeichen)', p1.fp.length <= 32);

// Die Zeichenkette des Nachbar-Handschlags, wortgetreu aus der Vorgabe.
const NACHRICHT = 'vetstation-verbund-2|3f8a1c02|' + 'a'.repeat(32) + '|' + 'b'.repeat(32)
  + '|st7f3a91c2b45d|stbb11cc22dd33|epkA|epkB';
const sig1 = S.signiereMit(p1.priv, NACHRICHT);
ok('Signatur ist base64 mit 88 Zeichen', typeof sig1 === 'string' && sig1.length === 88, String(sig1 && sig1.length));
ok('die eigene Signatur wird angenommen', S.pruefeSignatur(p1.pub, NACHRICHT, sig1) === true);
ok('eine geaenderte Nachricht wird abgelehnt', S.pruefeSignatur(p1.pub, NACHRICHT + 'x', sig1) === false);
ok('ein FREMDER oeffentlicher Schluessel lehnt ab', S.pruefeSignatur(p2.pub, NACHRICHT, sig1) === false);
/* Das erste Zeichen wird gegen ein GARANTIERT anderes getauscht. Vorher stand hier fest 'A' —
 * beginnt die gueltige Signatur zufaellig selbst mit 'A', verstuemmelt das gar nichts, und die
 * Pruefung bestand, ohne etwas zu pruefen. Bei 88 base64-Zeichen passiert das in etwa jedem
 * 64. Lauf: eine Pruefung, die selten grundlos gruen ist, faellt nie auf. */
ok('eine verstuemmelte Signatur wird abgelehnt',
  S.pruefeSignatur(p1.pub, NACHRICHT, (sig1[0] === 'A' ? 'B' : 'A') + sig1.slice(1)) === false);
ok('eine Signatur mit vertauschten fluechtigen Schluesseln passt nicht mehr',
  S.pruefeSignatur(p1.pub, NACHRICHT.replace('|epkA|epkB', '|epkB|epkA'), sig1) === false);
ok('Muell wirft keine Ausnahme, sondern ergibt false',
  S.pruefeSignatur('kein-schluessel', NACHRICHT, sig1) === false
  && S.pruefeSignatur(p1.pub, NACHRICHT, 'kein-base64!!') === false
  && S.pruefeSignatur(null, NACHRICHT, null) === false);
ok('mit unbrauchbarem privaten Teil wird nicht unterschrieben, aber auch nicht geworfen',
  S.signiereMit('kaputt', NACHRICHT) === null);
ok('hatPaar erkennt ein vollstaendiges Paar', S.hatPaar(p1));
ok('hatPaar lehnt einen gefaelschten Fingerabdruck ab',
  !S.hatPaar({ priv: p1.priv, pub: p1.pub, fp: p2.fp }));
ok('hatPaar lehnt ein halbes Paar ab',
  !S.hatPaar({ pub: p1.pub, fp: p1.fp }) && !S.hatPaar({ priv: p1.priv }) && !S.hatPaar(null));

console.log('\nDas gemeinsame Geheimnis ist WEG und darf nicht zurueckkommen:');
ok('kein neuesGeheim/brauchtRotation/vorgaengerGueltig mehr im Modul',
  S.neuesGeheim === undefined && S.brauchtRotation === undefined && S.vorgaengerGueltig === undefined);
ok('keine Rotationsfristen mehr im Modul', S.ROTATION_MS === undefined && S.VORGAENGER_MS === undefined);
ok('keine automatische Umbenennung mehr im Modul',
  S.sidMitSuffix === undefined && typeof S.Stationsid.prototype.eindeutigMachen !== 'function'
  && typeof S.Stationsid.prototype.warDoppelt !== 'function');

/* ---------------- 4) Brauchbarkeit gelesener Dateien ---------------- */
console.log('\nWas als gelesene Datei gilt — und was nicht:');
ok('eine Kennung allein genuegt (das Paar wird nachgezogen)', S.istBrauchbar({ sid: 'st7f3a91c2b45d' }));
ok('ein Datensatz OHNE Schluesselfeld wird NICHT verworfen (sonst neue Kennung bei jedem Start)',
  S.istBrauchbar({ sid: 'st7f3a91c2b45d', quelle: 'machineguid' }));
ok('ohne Kennung unbrauchbar', !S.istBrauchbar({ pub: p1.pub }));
ok('falsche Kennungsform unbrauchbar', !S.istBrauchbar({ sid: '../fremd', pub: p1.pub }));
ok('Grossbuchstaben in der Kennung unbrauchbar', !S.istBrauchbar({ sid: 'ST7F3A91C2B45D' }));
ok('null unbrauchbar', !S.istBrauchbar(null) && !S.istBrauchbar('text'));

/* ---------------- 5) Datei-Mechanik, Migration, Kollision, Umbenennung ---------------- */
(async () => {
  console.log('\nDatei-Mechanik (temporaerer Ordner, keine Registry noetig):');

  const d1 = datei('a.json');
  const s1 = new S.Stationsid({ log: still, datei: d1, hostname: 'OP-PC-1', machineGuid: guidFest });
  await s1.laden();
  ok('Kennung nach dem ersten Start vorhanden und formgueltig', S.pruefeSid(s1.sid()), String(s1.sid()));
  ok('Kennung ist genau die abgeleitete', s1.sid() === S.sidAus(GUID, 'OP-PC-1'));
  ok('Datei wurde angelegt', fs.existsSync(d1));
  ok('Instanz ist 16 Hexzeichen', S.INSTANZ_FORM.test(s1.instanz), s1.instanz);
  ok('Schluesselpaar liegt vor und der Fingerabdruck passt', s1.fp() === S.fingerabdruck(s1.pub()));
  ok('die Station kann unterschreiben, und ihr eigener pub prueft es',
    S.Stationsid.pruefeSignatur(s1.pub(), NACHRICHT, s1.signiere(NACHRICHT)) === true);
  ok('Pfadteil ist die kodierte Kennung', s1.pfadTeil() === encodeURIComponent(s1.sid()));

  /* Befund B2: N1 verlangt die Sperre, SOLANGE die Kollision nicht ausgeschlossen ist.
   * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Genau die vorherige: nurTafelSchreiben = false im
   * Konstruktor, also von der ersten Sekunde an Patientendaten in den Kontobaum — bei zwei geklonten
   * PCs sofort Feld fuer Feld gemischt. */
  ok('B2: frisch geladen und ohne Rueckmeldung schreibt die Station KEINE Patientendaten',
    s1.darfPatientendatenSchreiben() === false && s1.nurTafelSchreiben === true);
  ok('B2: und der Zustand heisst "unbekannt", nicht "ausgeschlossen"', s1.kollisionsstand() === 'unbekannt');
  /* nurTafelSchreiben war bis zu dieser Nachbesserung ein beschreibbares Feld. Ein Aufrufer, der die
   * alte Bauform noch benutzt, darf keinen TypeError bekommen (in 'use strict' bei einer Eigenschaft
   * ohne Setzer) — das waere ein Prozessende im 1-Hz-Takt einer laufenden Narkose. Und er darf die
   * Sperre auch nicht heimlich verstellen koennen. */
  let zuweisungGeworfen = null;
  try { s1.nurTafelSchreiben = false; } catch (e) { zuweisungGeworfen = e; }
  ok('eine Zuweisung an nurTafelSchreiben wirft nicht und aendert nichts',
    zuweisungGeworfen === null && s1.nurTafelSchreiben === true && s1.darfPatientendatenSchreiben() === false,
    String(zuweisungGeworfen && zuweisungGeworfen.message));

  const gespeichert = JSON.parse(fs.readFileSync(d1, 'utf8'));
  ok('Rechnername steht NICHT in der Datei',
    JSON.stringify(gespeichert).indexOf('OP-PC-1') < 0, JSON.stringify(gespeichert).slice(0, 120));
  ok('Ableitungsversion steht in der Datei', gespeichert.ableitung === S.ABLEITUNG_V);
  ok('kein lanGeheim in der Datei', gespeichert.lanGeheim === undefined && gespeichert.lanGeheimTs === undefined);
  ok('privater Teil liegt NUR in der Datei auf diesem PC, oeffentlicher Teil ist getrennt',
    typeof gespeichert.priv === 'string' && gespeichert.priv !== gespeichert.pub);
  /* Befund B9: der Plan schreibt erzeugt:<ISO>. Eine Millisekundenzahl faellt hier durch. */
  ok('B9: erzeugt steht als ISO-Zeichenkette in der Datei, nicht als Millisekundenzahl',
    typeof gespeichert.erzeugt === 'string' && /^\d{4}-\d\d-\d\dT/.test(gespeichert.erzeugt),
    String(gespeichert.erzeugt));
  ok('B9: hostHash in der Datei sind 8 Hexzeichen', /^[0-9a-f]{8}$/.test(gespeichert.hostHash), String(gespeichert.hostHash));

  /* ---------------- Befund B4: der private Schluessel darf nicht aus dem Objekt fallen ---------------- */
  console.log('\nDer private Schluessel liegt in keinem aufzaehlbaren Feld:');
  const PRIV = gespeichert.priv;
  ok('Vorbedingung der folgenden Pruefungen: der private Teil steht wirklich in der Datei',
    typeof PRIV === 'string' && PRIV.length >= 40);
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? this.daten.priv (die vorherige Fassung) und ebenso
   * this.priv als oeffentliches Feld — beides landet in JSON.stringify und damit in einem
   * res.json(stationsid) oder einem Objektabwurf in /api/diag. Die alte Pruefung sah nur nach, ob
   * es KEINE Methode priv() gibt; das bestand jede dieser Bauformen. */
  ok('B4: JSON.stringify(station) enthaelt den privaten Schluessel NICHT',
    textVon(s1).indexOf(PRIV) < 0);
  ok('B4: JSON.stringify(station.daten) enthaelt ihn NICHT', textVon(s1.daten).indexOf(PRIV) < 0);
  ok('B4: kein einziges aufzaehlbares Feld der Station enthaelt ihn',
    Object.keys(s1).filter((k) => textVon(s1[k]).indexOf(PRIV) >= 0).length === 0,
    Object.keys(s1).join(','));
  ok('B4: daten.priv gibt es nicht', s1.daten.priv === undefined);
  ok('B4: es gibt keinen Weg, den privaten Schluessel abzufragen',
    typeof S.Stationsid.prototype.priv !== 'function' && typeof S.Stationsid.prototype.geheim !== 'function');
  ok('B4: der tote Zwischenspeicher _privKey ist weg', !('_privKey' in s1));
  ok('B4: trotzdem kann die Station unterschreiben (der Schluessel ist da, nur nicht aufzaehlbar)',
    S.Stationsid.pruefeSignatur(s1.pub(), NACHRICHT, s1.signiere(NACHRICHT)) === true);

  const vorGelesen = gelesen;
  const s1b = new S.Stationsid({ log: still, datei: d1, hostname: 'OP-PC-1', machineGuid: guidNichtLesbar });
  await s1b.laden();
  ok('zweiter Start liefert DIESELBE Kennung', s1b.sid() === s1.sid(), s1.sid() + ' / ' + s1b.sid());
  ok('DIE DATEI GEWINNT: die Geraete-ID wird gar nicht mehr gelesen', gelesen === vorGelesen);
  ok('zweiter Start liefert eine ANDERE Instanz', s1b.instanz !== s1.instanz);
  ok('das Schluesselpaar ueberlebt den Neustart', s1b.pub() === s1.pub() && s1b.fp() === s1.fp());
  ok('auch nach dem Neustart faellt der private Schluessel nicht aus dem Objekt',
    textVon(s1b).indexOf(PRIV) < 0 && s1b.signiere(NACHRICHT) !== null);

  // Verschiedene Rechnernamen -> verschiedene Kennungen, auch mit derselben Geraete-ID.
  const s2 = new S.Stationsid({ log: still, datei: datei('b.json'), hostname: 'OP-PC-2', machineGuid: guidFest });
  await s2.laden();
  ok('zweiter PC bekommt eine ANDERE Kennung', s2.sid() !== s1.sid(), s1.sid() + ' / ' + s2.sid());
  ok('zweiter PC bekommt ein ANDERES Schluesselpaar', s2.pub() !== s1.pub());

  /* ---------------- Befund B1: der eigene Vorgaenger ist kein Zwilling ---------------- */
  console.log('\nNeustart einer EINZELSTATION: der eigene Vorgaenger darf nicht als Zwilling gelten:');
  const dN = datei('neustart.json');
  const n1 = new S.Stationsid({ log: still, datei: dN, hostname: 'OP-PC-N', machineGuid: guidFest });
  await n1.laden();
  const instanz1 = n1.instanz;
  /* So weit ist es der Ablauf aus dem Befund: Prozess 1 hat instanz1 nach tafel/<sid>/meta.instanz
   * geschrieben, die Station wird abends beendet, morgens startet Prozess 2 mit derselben Datei. */
  const n2 = new S.Stationsid({ log: still, datei: dN, hostname: 'OP-PC-N', machineGuid: guidFest });
  await n2.laden();
  ok('Prozess 2 hat eine andere Instanz als Prozess 1', n2.instanz !== instanz1);
  ok('die Instanz von Prozess 1 steht in der Datei (das ist die Voraussetzung)',
    JSON.parse(fs.readFileSync(dN, 'utf8')).instanzen.indexOf(instanz1) >= 0,
    JSON.stringify(JSON.parse(fs.readFileSync(dN, 'utf8')).instanzen));
  ok('die eigene, aktuelle Instanz steht dort an erster Stelle',
    JSON.parse(fs.readFileSync(dN, 'utf8')).instanzen[0] === n2.instanz);
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Jede, die "irgendein Wert != meiner aktuellen Instanz"
   * als Beweis nimmt — also genau die vorherige. Sie machte aus einem gewoehnlichen Neustart eine
   * dauerhafte Sperre, aus der nur eine Umbenennung des Saals herausfuehrte. */
  ok('B1: der zurueckgelesene Wert von Prozess 1 ist KEIN Beweis fuer einen zweiten Rechner',
    n2.kollisionGemeldet(instanz1) === false && n2.kollisionsstand() !== 'bewiesen');
  ok('B1: er ENTLASTET sogar — die Sperre oeffnet beim ersten Rueckleseweg, ohne Umbenennung',
    n2.kollisionAusgeschlossen(instanz1) === true && n2.darfPatientendatenSchreiben() === true);
  ok('B1: und es steht kein Kollisionsvermerk in der Datei',
    n2.kollisionBekannt() === false && JSON.parse(fs.readFileSync(dN, 'utf8')).kollision === null);

  // Die Liste bleibt kurz: nur die letzten paar Starts, neueste zuerst, ohne Doppelte.
  let letzte = null;
  for (let i = 0; i < 7; i++) {
    letzte = new S.Stationsid({ log: still, datei: dN, hostname: 'OP-PC-N', machineGuid: guidFest });
    await letzte.laden();
  }
  const liste = JSON.parse(fs.readFileSync(dN, 'utf8')).instanzen;
  ok('die Liste eigener Instanzen ist auf ' + S.INSTANZEN_MERKEN + ' gedeckelt (sie soll nicht wachsen)',
    liste.length === S.INSTANZEN_MERKEN, 'Laenge ' + liste.length);
  ok('sie enthaelt keine Doppelten und beginnt mit der laufenden Instanz',
    liste[0] === letzte.instanz && new Set(liste).size === liste.length);
  ok('jeder Eintrag hat die Instanzform', liste.every((x) => S.INSTANZ_FORM.test(x)));
  ok('alle Eintraege der Liste entlasten, nicht nur der erste',
    liste.every((x) => letzte.kollisionGemeldet(x) === false));

  /* Und der Fall, in dem die Liste NICHT dauerhaft sein kann: data\ nicht schreibbar. Dann traegt
   * das zweite Merkmal — "ein toter Vorgaenger kann uns nicht mehr ueberschreiben". */
  console.log('\nAuch ohne schreibbare Datei sperrt sich eine Einzelstation nicht selbst aus:');
  const sperrdatei = datei('sperre');
  fs.writeFileSync(sperrdatei, 'ich bin eine Datei, kein Ordner', 'utf8');
  const sU = new S.Stationsid({
    log: still, datei: path.join(sperrdatei, 'station-id.json'), hostname: 'OP-PC-U', machineGuid: guidFest,
  });
  await sU.laden();
  const FREMD = 'abcdef0123456789';
  ok('nicht schreibbare Datei: die Station startet trotzdem mit gueltiger Kennung', S.pruefeSid(sU.sid()), String(sU.sid()));
  ok('die Instanzliste ist in diesem Fall nicht dauerhaft (Vorbedingung der naechsten Pruefung)',
    fs.existsSync(sU.datei) === false && sU.eigeneInstanzen().length === 1);
  ok('B1: ein EINZELNER fremder Wert ist ohne dauerhafte Liste kein Beweis — er koennte der eigene '
    + 'Vorgaenger sein', sU.kollisionGemeldet(FREMD) === false && sU.kollisionsstand() !== 'bewiesen');
  ok('B1: erst wenn die eigene Instanz schon einmal im Knoten stand, beweist ein fremder Wert einen '
    + 'LEBENDEN Zwilling', sU.kollisionAusgeschlossen(sU.instanz) === true
    && sU.kollisionGemeldet(FREMD) === true && sU.darfPatientendatenSchreiben() === false);

  /* ---------------- Befund B2: Polaritaet und Anlauffrist ---------------- */
  console.log('\nDie Sperre startet zu (N1) — und bleibt es nicht fuer immer:');
  let uhrA = 1785000000000;
  const sA = new S.Stationsid({
    log: still, datei: datei('anlauf.json'), hostname: 'OP-PC-A', machineGuid: guidFest, jetzt: () => uhrA,
  });
  await sA.laden();
  ok('B2: ohne jede Rueckmeldung: keine Patientendaten', sA.darfPatientendatenSchreiben() === false);
  uhrA += S.ANLAUF_MS - 1;
  ok('B2: kurz vor Ablauf der Anlauffrist gilt die Sperre noch', sA.darfPatientendatenSchreiben() === false);
  uhrA += 2;
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Eine reine fail-closed-Fassung ohne Ausweg: eine
   * Station, deren Rueckleseweg klemmt (Kontingent, Leseregel, Backoff), verlaesse die Sperre nie
   * und verlöre ihre Patientendaten in der Fern-Ansicht dauerhaft — ohne Zwilling. */
  ok('B2: nach der Anlauffrist oeffnet die Sperre von selbst, damit sich niemand aussperrt',
    sA.darfPatientendatenSchreiben() === true && sA.kollisionsstand() === 'unbekannt');
  ok('B2: die Anlauffrist ist deutlich kuerzer als die Minute, nach der ein Saal als still gilt',
    S.ANLAUF_MS < 60000, String(S.ANLAUF_MS));
  ok('B2: ein spaeter doch gemeldeter Zwilling sperrt auch nach der Anlauffrist noch',
    sA.kollisionAusgeschlossen(sA.instanz) === true
    && sA.kollisionGemeldet('1111222233334444') === true
    && sA.darfPatientendatenSchreiben() === false);

  /* Der Ersatzbeweis, wenn die eigene Instanz nie im Knoten auftaucht (ein Zwilling, der uns in
   * jedem Takt ueberschreibt, bevor wir lesen). */
  console.log('\nEin Zwilling, der uns nie zum Zug kommen laesst, wird ueber die Ausdauer bewiesen:');
  let uhrB = 1785010000000;
  const sB = new S.Stationsid({
    log: still, datei: datei('ausdauer.json'), hostname: 'OP-PC-B', machineGuid: guidFest, jetzt: () => uhrB,
  });
  await sB.laden();
  const ZWILLING = 'aaaa1111bbbb2222';
  ok('die erste Meldung allein beweist nichts', sB.kollisionGemeldet(ZWILLING) === false);
  uhrB += 3000;
  ok('die zweite nach 3 s auch nicht', sB.kollisionGemeldet(ZWILLING) === false);
  uhrB += 3000;
  ok('die dritte nach mehr als ' + S.BEWEIS_DAUER_MS + ' ms ist der Beweis: der Wert haelt sich, '
    + 'obwohl wir jeden Takt unsere eigene Instanz hineinschreiben',
    sB.kollisionGemeldet(ZWILLING) === true && sB.darfPatientendatenSchreiben() === false);
  ok('der Ersatzbeweis kommt VOR dem Ablauf der Anlauffrist an (sonst waere er wertlos)',
    S.BEWEIS_DAUER_MS < S.ANLAUF_MS);

  let uhrC = 1785020000000;
  const sC = new S.Stationsid({
    log: still, datei: datei('ausdauer2.json'), hostname: 'OP-PC-C', machineGuid: guidFest, jetzt: () => uhrC,
  });
  await sC.laden();
  ok('drei Meldungen binnen einer Sekunde beweisen NICHT (es fehlt die Dauer)',
    sC.kollisionGemeldet(ZWILLING) === false && sC.kollisionGemeldet(ZWILLING) === false
    && sC.kollisionGemeldet(ZWILLING) === false);
  ok('ein Wechsel des fremden Wertes setzt die Ausdauer zurueck',
    sC.kollisionGemeldet('9999888877776666') === false && sC.kollisionsstand() !== 'bewiesen');
  uhrC += 12 * 3600 * 1000;
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Eine, die auf die WIEDERHOLUNG verzichtet und nur die
   * Dauer prueft. Dann waere die zweite Meldung nach 12 Stunden ein "Beweis" — und genau so sieht
   * ein TOTER Rueckleseweg aus: ein Wert wird einmal gelesen, dann sehr lange nichts. Eine
   * Einzelstation waere damit wieder ausgesperrt. */
  ok('zwei Meldungen mit 12 Stunden Abstand sind keine Ausdauer, sondern zwei Zufaelle',
    sC.kollisionGemeldet('9999888877776666') === false && sC.kollisionsstand() !== 'bewiesen');
  ok('erst die dritte Meldung desselben Wertes ist der Beweis (Gegenprobe: der Weg ist nicht zu)',
    sC.kollisionGemeldet('9999888877776666') === true && sC.darfPatientendatenSchreiben() === false);

  /* ---------------- Befund B3: Form pruefen, nicht saeubern ---------------- */
  console.log('\nFormmuell im Kennungsknoten ist kein Beweis und keine Entwarnung:');
  const dG = datei('muell.json');
  const sG = new S.Stationsid({ log: still, datei: dG, hostname: 'OP-PC-G', machineGuid: guidFest });
  await sG.laden();
  /* WICHTIG fuer die Aussagekraft: die eigene Instanz stand schon im Knoten. Damit wuerde ein
   * FORMGUELTIGER fremder Wert an dieser Stelle SOFORT sperren (unten als Gegenprobe belegt) — nur
   * deshalb beweist die Schleife etwas ueber die Formpruefung und nicht bloss darueber, dass hier
   * gerade ueberhaupt nichts sperren kann. */
  ok('Vorbedingung: die eigene Instanz stand im Knoten, ein fremder Wert wuerde ab jetzt sofort sperren',
    sG.kollisionAusgeschlossen(sG.instanz) === true && sG.kollisionsstand() === 'ausgeschlossen');
  /* Genau die Eingaben, die die Gegenpruefung nachgemessen hat — jede ergab in der vorherigen
   * Fassung true und eine dauerhafte Sperre: aus true wurde 'e', aus 5 wurde '5', aus 'unbekannt'
   * wurde 'bea', aus {} wurde 'becbec', aus '1.0.3' wurde '103'. */
  const MUELL = [true, false, 5, 0, 'unbekannt', {}, [], '1.0.3', 'ABCDEF1234567890',
    '9c1f4ab27e0d3f5', '9c1f4ab27e0d3f56x', '9c1f-4ab2-7e0d-3f56', '', null, undefined,
    'e', 'zzzzzzzzzzzzzzzz'];
  const durchgelassen = MUELL.filter((m) => sG.kollisionGemeldet(m) !== false);
  ok('B3: keine dieser ' + MUELL.length + ' Eingaben gilt als Beweis', durchgelassen.length === 0,
    JSON.stringify(durchgelassen));
  ok('B3: nichts davon sperrt', sG.darfPatientendatenSchreiben() === true && sG.kollisionsstand() === 'ausgeschlossen');
  ok('B3: nichts davon hinterlaesst einen Vermerk (die Web-App markiert sonst dauerhaft '
    + '"Kennung doppelt")', sG.kollisionBekannt() === false
    && JSON.parse(fs.readFileSync(dG, 'utf8')).kollision === null);
  ok('B3 Gegenprobe: ein FORMGUELTIGER fremder Wert sperrt an genau dieser Stelle sofort',
    sG.kollisionGemeldet('0123456789abcdef') === true && sG.darfPatientendatenSchreiben() === false);
  const sG2 = new S.Stationsid({ log: still, datei: datei('muell2.json'), hostname: 'OP-PC-G2', machineGuid: guidFest });
  await sG2.laden();
  ok('B3: Formmuell entlastet auch nicht — der Zustand bleibt "unbekannt"',
    sG2.kollisionAusgeschlossen('1.0.3') === false && sG2.kollisionAusgeschlossen(42) === false
    && sG2.kollisionsstand() === 'unbekannt');
  ok('B3: Grossbuchstaben werden nicht verstuemmelt, sondern abgelehnt (sonst stuende im Vermerk ein '
    + 'Wert, der den Zwilling nicht mehr identifiziert)',
    sG2.kollisionGemeldet('ABCDEF1234567890') === false && sG2.kollisionBekannt() === false);

  /* ---------------- Kollisionssperre statt Selbstumbenennung ---------------- */
  console.log('\nGeklonter PC: bewiesene Kollision sperrt, benennt aber NICHT um:');
  const dK = datei('k.json');
  const sK = new S.Stationsid({ log: still, datei: dK, hostname: 'OP-PC-K', machineGuid: guidFest });
  await sK.laden();
  const sidVorher = sK.sid();
  ok('ein leerer Kennungsknoten schliesst die Kollision aus',
    sK.kollisionAusgeschlossen(null) === true && sK.darfPatientendatenSchreiben() === true);
  ok('die eigene Instanz im Knoten schliesst sie ebenfalls aus',
    sK.kollisionAusgeschlossen(sK.instanz) === true && sK.kollisionsstand() === 'ausgeschlossen');
  ok('die EIGENE Instanz ist kein Beweis', sK.kollisionGemeldet(sK.instanz) === false && sK.darfPatientendatenSchreiben());
  ok('eine fremde Instanz, die uns NACH unserem eigenen Schreibvorgang ueberschreibt, ist ein Beweis',
    sK.kollisionGemeldet('9c1f4ab27e0d3f56') === true);
  ok('danach werden KEINE Patientendaten mehr geschrieben',
    sK.nurTafelSchreiben === true && sK.darfPatientendatenSchreiben() === false
    && sK.kollisionsstand() === 'bewiesen');
  ok('die Kennung bleibt dieselbe — keine Selbstumbenennung', sK.sid() === sidVorher, sidVorher + ' / ' + sK.sid());
  ok('die Kollision ist vermerkt', sK.kollisionBekannt()
    && JSON.parse(fs.readFileSync(dK, 'utf8')).kollision.instanz === '9c1f4ab27e0d3f56');
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Eine, in der die Entwarnung auch eine BEWIESENE
   * Kollision aufhebt. Bei laufendem Zwilling steht im Knoten abwechselnd die eigene und die fremde
   * Instanz — die Sperre klappte dann im Sekundentakt auf und zu und liesse genau die Vermischung zu,
   * die sie verhindern soll. */
  ok('eine bewiesene Kollision wird NICHT durch die naechste eigene Instanz im Knoten entwarnt',
    sK.kollisionAusgeschlossen(sK.instanz) === false && sK.darfPatientendatenSchreiben() === false
    && sK.kollisionAusgeschlossen(null) === false);
  const dKvorher = fs.readFileSync(dK, 'utf8');
  sK.kollisionGemeldet('9c1f4ab27e0d3f56');
  ok('mehrfache Meldung zaehlt mit, aendert aber nichts an der Kennung',
    sK.kollisionVermerk().anzahl === 2 && sK.sid() === sidVorher);
  ok('dieselbe Meldung schreibt die Datei NICHT jede Sekunde neu',
    fs.readFileSync(dK, 'utf8') === dKvorher);
  sK.kollisionGemeldet('aaaa1111bbbb2222');
  ok('ein ANDERER Zwilling wird sofort festgehalten',
    JSON.parse(fs.readFileSync(dK, 'utf8')).kollision.instanz === 'aaaa1111bbbb2222');

  /* ---------------- Befund A1: DER EINE EINSTIEG muss allein tragen ---------------- */
  console.log('\nDer Weg, den cloud.js in JEDEM Takt geht — nur kollisionAusgeschlossen(), sonst nichts:');
  /* WARUM DIESE GRUPPE EXISTIERT (Befund A1, nachgemessen per Mutation): bis hierher hat keine
   * einzige Pruefung kollisionAusgeschlossen() jemals einen FREMDEN, formgueltigen Wert gegeben —
   * gefuettert wurden nur die eigene Instanz, der eigene Vorgaenger, null und Formmuell. Entfernt
   * man in stationsid.js die Zeile 'this.kollisionGemeldet(gelesenerWert);' aus
   * kollisionAusgeschlossen(), so dass ein fremder Wert dort nur noch 'return false' ergibt,
   * bestehen alle 172 vorherigen Pruefungen unveraendert. Im Betrieb waere das genau der Zustand,
   * den dieses Modul laut seinem Kopfkommentar verhindern soll: cloud.js benutzt ausschliesslich
   * diesen einen Einstieg, ein Zwilling schreibt seine Instanz nach tafel/<sid>/meta.instanz, jeder
   * Rueckleseweg liefert sie — der Zustand bliebe fuer immer 'unbekannt', nach ANLAUF_MS oeffnet die
   * Anlauffrist, und BEIDE geklonten Stationen schreiben Patientendaten in denselben
   * saele/<sid>-Zweig: zwei Narkosen, Feld fuer Feld gemischt.
   * DIESE GRUPPE RUFT kollisionGemeldet() KEIN EINZIGES MAL SELBST AUF — Sperre und Vermerk muessen
   * allein ueber kollisionAusgeschlossen() entstehen. */
  const dE1 = datei('einstieg-ueberschrieben.json');
  let uhrE1 = 1785300000000;
  const sE1 = new S.Stationsid({
    log: still, datei: dE1, hostname: 'OP-PC-E1', machineGuid: guidFest, jetzt: () => uhrE1,
  });
  await sE1.laden();
  const ZWILLING_E1 = '5a5a6b6b7c7c8d8d';
  ok('A1 Vorbedingung: die eigene Instanz ist einmal zurueckgelesen worden, die Sperre ist offen',
    sE1.kollisionAusgeschlossen(sE1.instanz) === true && sE1.kollisionsstand() === 'ausgeschlossen'
    && sE1.darfPatientendatenSchreiben() === true);
  uhrE1 += 1000;
  ok('A1: der naechste Takt liest einen FREMDEN formgueltigen Wert zurueck — das schliesst nichts aus',
    sE1.kollisionAusgeschlossen(ZWILLING_E1) === false);
  ok('A1: und die Sperre greift wirklich — keine Patientendaten mehr',
    sE1.darfPatientendatenSchreiben() === false && sE1.nurTafelSchreiben === true);
  ok('A1: der Zustand heisst "bewiesen", nicht bloss "unbekannt" (nur "bewiesen" haelt die Sperre '
    + 'ueber die Anlauffrist hinaus)', sE1.kollisionsstand() === 'bewiesen', sE1.kollisionsstand());
  ok('A1: der Vermerk entsteht wirklich — im Speicher UND in der Datei, mit genau dieser Instanz',
    sE1.kollisionBekannt() === true && sE1.kollisionVermerk().instanz === ZWILLING_E1
    && JSON.parse(fs.readFileSync(dE1, 'utf8')).kollision.instanz === ZWILLING_E1,
    JSON.stringify(sE1.kollisionVermerk()));
  uhrE1 += S.ANLAUF_MS + 1000;
  ok('A1: auch nach Ablauf der Anlauffrist bleibt die Sperre zu (sonst waere der Beweis wertlos)',
    sE1.darfPatientendatenSchreiben() === false);
  /* Der Takt laeuft weiter: bei laufendem Zwilling steht im Knoten abwechselnd die eigene und die
   * fremde Instanz. Beides darf die Sperre nicht mehr oeffnen, und der Zaehler muss mitwachsen. */
  for (let i = 0; i < 30; i++) { sE1.kollisionAusgeschlossen(ZWILLING_E1); uhrE1 += 1000; }
  ok('A1: 30 weitere Takte aendern nichts an der Sperre, zaehlen aber mit',
    sE1.darfPatientendatenSchreiben() === false && sE1.kollisionVermerk().anzahl === 31,
    'anzahl: ' + sE1.kollisionVermerk().anzahl);
  ok('A1: auch die eigene Instanz im Knoten oeffnet die bewiesene Sperre nicht wieder',
    sE1.kollisionAusgeschlossen(sE1.instanz) === false && sE1.kollisionsstand() === 'bewiesen');

  /* Der zweite Weg durch dieselbe Zeile: ein Zwilling, der uns in jedem Takt ueberschreibt, bevor
   * wir lesen — unsere eigene Instanz taucht im Knoten NIE auf. Dann traegt der Ersatzbeweis ueber
   * die Ausdauer, und auch der muss ueber kollisionAusgeschlossen() erreichbar sein: cloud.js hat
   * keinen anderen Weg. */
  const dE2 = datei('einstieg-ausdauer.json');
  let uhrE2 = 1785400000000;
  const sE2 = new S.Stationsid({
    log: still, datei: dE2, hostname: 'OP-PC-E2', machineGuid: guidFest, jetzt: () => uhrE2,
  });
  await sE2.laden();
  const ZWILLING_E2 = '4444333322221111';
  ok('A1: der erste Takt mit fremdem Wert entlastet nicht und beweist noch nichts',
    sE2.kollisionAusgeschlossen(ZWILLING_E2) === false && sE2.kollisionsstand() === 'unbekannt');
  uhrE2 += 3000;
  ok('A1: der zweite Takt nach 3 s ebenfalls nicht',
    sE2.kollisionAusgeschlossen(ZWILLING_E2) === false && sE2.kollisionsstand() === 'unbekannt');
  uhrE2 += 3000;
  ok('A1: der dritte Takt nach mehr als ' + S.BEWEIS_DAUER_MS + ' ms ist der Beweis — allein ueber '
    + 'kollisionAusgeschlossen()', sE2.kollisionAusgeschlossen(ZWILLING_E2) === false
    && sE2.kollisionsstand() === 'bewiesen' && sE2.darfPatientendatenSchreiben() === false);
  ok('A1: und auch auf diesem Weg steht der Vermerk in der Datei',
    JSON.parse(fs.readFileSync(dE2, 'utf8')).kollision.instanz === ZWILLING_E2);

  /* Und die Zusage im Kommentar von kollisionAusgeschlossen() woertlich: der fremde Wert wird
   * INTERN weitergereicht. Gezaehlt wird an der Instanz — der Test selbst ruft kollisionGemeldet()
   * hier nirgends auf, jeder gezaehlte Aufruf kommt also aus dem Modul. */
  const dE3 = datei('einstieg-weitergabe.json');
  const sE3 = new S.Stationsid({ log: still, datei: dE3, hostname: 'OP-PC-E3', machineGuid: guidFest });
  await sE3.laden();
  const echtesMelden = sE3.kollisionGemeldet.bind(sE3);
  let weitergereicht = 0;
  sE3.kollisionGemeldet = function (w) { weitergereicht++; return echtesMelden(w); };
  sE3.kollisionAusgeschlossen(null);            // leer -> keine Weitergabe
  sE3.kollisionAusgeschlossen(sE3.instanz);     // eigene Instanz -> keine Weitergabe
  sE3.kollisionAusgeschlossen('0f0f0f0f0f0f0f0f');
  ok('A1: genau der fremde formgueltige Wert wird intern an kollisionGemeldet() weitergereicht, '
    + 'leerer Knoten und eigene Instanz nicht', weitergereicht === 1, 'gezaehlt: ' + weitergereicht);

  /* ---------------- Befund B6: die Drosselung muss gegen den letzten SCHREIBVORGANG messen ------- */
  console.log('\nBei laufendem Zwilling muss der Vermerk mitwachsen, nicht bei Sekunde 0 stehenbleiben:');
  const dB6 = datei('drossel.json');
  let uhr6 = 1785200000000;
  const s6 = new S.Stationsid({
    log: still, datei: dB6, hostname: 'OP-PC-D', machineGuid: guidFest, jetzt: () => uhr6,
  });
  await s6.laden();
  s6.kollisionAusgeschlossen(s6.instanz);     // eigene Instanz gesehen -> der Beweis greift sofort
  const echtesSpeichern = s6._speichern.bind(s6);
  let schreibvorgaenge = 0;
  s6._speichern = function () { schreibvorgaenge++; return echtesSpeichern(); };
  for (let i = 0; i < 400; i++) { s6.kollisionGemeldet('cccc3333dddd4444'); uhr6 += 1000; }
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Die vorherige: sie verglich gegen den im SPEICHER
   * gesetzten Zeitpunkt der letzten Meldung und schrieb deshalb GENAU EINMAL — Admin-Bereich und
   * diagnose.js zeigten nach acht Stunden Zwillingsbetrieb "Kollision 1x, vor 8 Stunden". */
  ok('B6: in 400 Sekunden wird etwa jede Minute geschrieben (erwartet 7)',
    schreibvorgaenge === 7, 'Schreibvorgaenge: ' + schreibvorgaenge);
  ok('B6: der Zaehler in der DATEI waechst mit',
    JSON.parse(fs.readFileSync(dB6, 'utf8')).kollision.anzahl === 361,
    'in der Datei: ' + JSON.parse(fs.readFileSync(dB6, 'utf8')).kollision.anzahl);
  ok('B6: im Speicher stehen alle 400 Meldungen', s6.kollisionVermerk().anzahl === 400,
    String(s6.kollisionVermerk().anzahl));
  ok('B6: der Zeitpunkt in der Datei ist der des letzten Schreibvorgangs, nicht der von Sekunde 0',
    JSON.parse(fs.readFileSync(dB6, 'utf8')).kollision.am === 1785200000000 + 360 * 1000,
    String(JSON.parse(fs.readFileSync(dB6, 'utf8')).kollision.am));

  /* ---------------- Migration einer schon erzeugten Datei ---------------- */
  console.log('\nMigration: eine schon erzeugte station-id.json muss WEITER GELTEN:');
  const dAlt = datei('alt.json');
  const ALT_SID = 'st7f3a91c2b45d';
  fs.writeFileSync(dAlt, JSON.stringify({
    sid: ALT_SID, ableitung: S.ABLEITUNG_V, quelle: 'machineguid', erzeugt: 1785312345678,
    hostHash: S.hostHash('OP-PC-ALT'), suffix: null, suffixGrund: null, vorher: [],
    lanGeheim: 'Z'.repeat(44), lanGeheimVor: null, lanGeheimTs: 1785312345678,
  }), 'utf8');
  const sAlt = new S.Stationsid({ log: still, datei: dAlt, hostname: 'OP-PC-ALT', machineGuid: guidNichtLesbar });
  await sAlt.laden();
  const nachMigration = JSON.parse(fs.readFileSync(dAlt, 'utf8'));
  ok('die alte Kennung bleibt UNVERAENDERT', sAlt.sid() === ALT_SID, String(sAlt.sid()));
  ok('die Datei wurde NICHT beiseitegelegt', !fs.existsSync(datei('alt.ungueltig.json')));
  ok('das Schluesselpaar ist einmalig nachgezogen', S.hatPaar(nachMigration) && sAlt.fp() === S.fingerabdruck(sAlt.pub()));
  ok('lanGeheim ist aus der Datei entfernt',
    nachMigration.lanGeheim === undefined && nachMigration.lanGeheimVor === undefined
    && nachMigration.lanGeheimTs === undefined);
  ok('die Felder der alten Selbstumbenennung sind entfernt',
    nachMigration.suffix === undefined && nachMigration.vorher === undefined);
  ok('nach der Migration kann die Station unterschreiben',
    S.Stationsid.pruefeSignatur(sAlt.pub(), NACHRICHT, sAlt.signiere(NACHRICHT)) === true);
  ok('auch bei einer migrierten Datei liegt der private Schluessel nicht in daten',
    sAlt.daten.priv === undefined && textVon(sAlt.daten).indexOf(nachMigration.priv) < 0);
  ok('die Liste eigener Instanzen wird bei der Migration angelegt',
    Array.isArray(nachMigration.instanzen) && nachMigration.instanzen[0] === sAlt.instanz);
  /* Befund B9: eine Millisekundenzahl aus einem Vorabstand wird auf die ISO-Form gezogen, damit im
   * Feld erzeugt nicht je nach Alter der Datei zwei verschiedene Formen stehen. */
  ok('B9: eine Millisekundenzahl in erzeugt wird auf ISO gezogen',
    nachMigration.erzeugt === new Date(1785312345678).toISOString(), String(nachMigration.erzeugt));
  const sAlt2 = new S.Stationsid({ log: still, datei: dAlt, hostname: 'OP-PC-ALT', machineGuid: guidNichtLesbar });
  await sAlt2.laden();
  ok('beim naechsten Start wird das Paar NICHT erneut erzeugt',
    sAlt2.pub() === sAlt.pub(), 'pub muss gleich bleiben');
  ok('und die Kennung bleibt auch beim zweiten Start dieselbe',
    S.pruefeSid(sAlt2.sid()) && sAlt2.sid() === ALT_SID);
  /* Nachsicht gegen einen 1.1.0-Vorabstand, der eine Kennung MIT Suffix geschrieben hat: sie bleibt
   * gueltig. Wuerde sie verworfen, hiesse der Saal in der Fern-Ansicht anders als in seinem
   * unveraenderlichen Protokoll — genau der Schaden, den dieses Modul verhindert. */
  const dSuf = datei('suffix.json');
  fs.writeFileSync(dSuf, JSON.stringify({ sid: 'st7f3a91c2b45d-9c1f', ableitung: S.ABLEITUNG_V }), 'utf8');
  const sSuf = new S.Stationsid({ log: still, datei: dSuf, hostname: 'OP-PC-S', machineGuid: guidFest });
  await sSuf.laden();
  ok('eine Kennung mit altem Suffix behaelt ihre Kennung und bekommt einen eigenen Spiegelschluessel',
    sSuf.sid() === 'st7f3a91c2b45d-9c1f' && sSuf.kurz() !== S.sidKurz('st7f3a91c2b45d'),
    String(sSuf.sid()) + ' -> ' + sSuf.kurz());

  /* ---------------- Umbenennen von Hand ---------------- */
  console.log('\nUmbenennen macht nur ein Mensch:');
  const sK2 = new S.Stationsid({ log: still, datei: dK, hostname: 'OP-PC-K', machineGuid: guidFest });
  await sK2.laden();
  ok('nach dem Neustart ist der Vermerk noch da (fuer Admin und Diagnose)', sK2.kollisionBekannt());
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Eine, die die Sperre in der DATEI merkt: dann bliebe
   * eine Praxis nach einem Fehlalarm dauerhaft abgeschnitten. Und ebenso eine, die aus dem alten
   * Vermerk direkt wieder eine Sperre macht. Entschieden wird nach dem Neustart NEU. */
  ok('der Vermerk allein sperrt NICHT — nach dem Neustart entscheidet der Rueckleseweg neu',
    sK2.kollisionsstand() === 'unbekannt' && sK2.kollisionAusgeschlossen(sK2.instanz) === true
    && sK2.darfPatientendatenSchreiben() === true);
  /* Der Zwilling steht noch: die Kollision beweist sich binnen Sekunden erneut. NUR SO ist die
   * Pruefung "mit dem neuen Namen ist der Konflikt erledigt" ueberhaupt eine Aussage — bei einer
   * ohnehin offenen Sperre wuerde sie auch eine Fassung bestehen, die beim Umbenennen nichts
   * zurueckstellt. */
  ok('der noch laufende Zwilling sperrt nach dem Neustart erneut',
    sK2.kollisionGemeldet('9c1f4ab27e0d3f56') === true && sK2.darfPatientendatenSchreiben() === false
    && sK2.kollisionsstand() === 'bewiesen');
  const neu = sK2.umbenennen(null);
  ok('eine frische Kennung wird gewuerfelt und ist formgueltig', S.pruefeSid(neu) && neu !== sidVorher, String(neu));
  ok('die alte Kennung ist vermerkt', sK2.umbenanntVon().indexOf(sidVorher) >= 0);
  ok('der Zeitpunkt der Umbenennung steht in der Datei',
    typeof JSON.parse(fs.readFileSync(dK, 'utf8')).umbenanntAm === 'number');
  ok('das Schluesselpaar bleibt (es beweist die Maschine, nicht den Namen)',
    sK2.pub() === JSON.parse(fs.readFileSync(dK, 'utf8')).pub && S.hatPaar(JSON.parse(fs.readFileSync(dK, 'utf8'))));
  ok('mit dem neuen Namen ist der Konflikt erledigt: Vermerk weg UND Sperre offen',
    !sK2.kollisionBekannt() && sK2.darfPatientendatenSchreiben() === true
    && sK2.kollisionsstand() === 'ausgeschlossen');
  /* Nach dem Umbenennen darf ein Beweis nicht auf einer Beobachtung am ALTEN Namen ruhen: unter dem
   * neuen Namen hat noch nie eine eigene Instanz im Knoten gestanden. */
  ok('unter dem neuen Namen faengt die Beweisfuehrung von vorn an',
    sK2.kollisionGemeldet('7777666655554444') === false && sK2.darfPatientendatenSchreiben() === true);
  const sK3 = new S.Stationsid({ log: still, datei: dK, hostname: 'OP-PC-K', machineGuid: guidFest });
  await sK3.laden();
  ok('die neue Kennung ueberlebt den Neustart', sK3.sid() === neu, String(sK3.sid()));
  ok('ein zweites Umbenennen ergibt wieder eine formgueltige Kennung (kein Suffix-Anhaengen)',
    S.pruefeSid(sK3.umbenennen(null)) && sK3.sid().length <= S.SID_MAX);
  ok('zwei alte Kennungen sind vermerkt', sK3.umbenanntVon().length === 2);
  const vorAbgelehnt = sK3.sid();
  ok('eine Umbenennung auf "../fremd" wird abgelehnt', sK3.umbenennen('../fremd') === null && sK3.sid() === vorAbgelehnt);
  ok('eine Umbenennung auf Grossbuchstaben wird abgelehnt', sK3.umbenennen('ST7F3A91C2B45D') === null);
  ok('eine Umbenennung auf denselben Namen ist kein Vorgang',
    sK3.umbenennen(vorAbgelehnt) === vorAbgelehnt && sK3.umbenanntVon().length === 2);
  ok('eine Umbenennung auf einen von Hand gesetzten gueltigen Namen geht',
    sK3.umbenennen('stabcdef012345') === 'stabcdef012345' && sK3.sid() === 'stabcdef012345');

  /* ---------------- Kaputte und halbe Dateien ---------------- */
  console.log('\nEine kaputte Datei darf den Start nicht verhindern:');
  const d3 = datei('c.json');
  fs.writeFileSync(d3, '{ das ist kein json', 'utf8');
  const s3 = new S.Stationsid({ log: still, datei: d3, hostname: 'OP-PC-3', machineGuid: guidFest });
  await s3.laden();
  ok('kaputte Datei: Station startet trotzdem mit gueltiger Kennung', S.pruefeSid(s3.sid()), String(s3.sid()));
  /* Befund B9: der Plan nennt die beiseitegelegte Datei station-id.ungueltig.json. */
  ok('B9: die kaputte Datei liegt als *.ungueltig.json daneben, nicht als *.unbrauchbar',
    fs.existsSync(datei('c.ungueltig.json')) && !fs.existsSync(d3 + '.unbrauchbar'),
    fs.readdirSync(TMP).filter((f) => f.indexOf('c.') === 0).join(','));

  const d4 = datei('d.json');
  fs.writeFileSync(d4, JSON.stringify({ sid: 'ST-GROSS/../x', pub: p1.pub }), 'utf8');
  const s4 = new S.Stationsid({ log: still, datei: d4, hostname: 'OP-PC-4', machineGuid: guidFest });
  await s4.laden();
  ok('eine Kennung mit Pfadsprung wird verworfen und neu abgeleitet',
    S.pruefeSid(s4.sid()) && s4.sid() === S.sidAus(GUID, 'OP-PC-4'), String(s4.sid()));
  ok('die verbastelte Datei liegt daneben', fs.existsSync(datei('d.ungueltig.json')));

  // Ausweichkette: keine Geraete-ID lesbar UND keine Datei -> es gibt trotzdem eine Kennung.
  const s6b = new S.Stationsid({ log: still, datei: datei('f.json'), hostname: 'OP-PC-6', machineGuid: guidNichtLesbar });
  await s6b.laden();
  ok('ohne Geraete-ID und ohne Datei greift die Ausweichkette', S.pruefeSid(s6b.sid()), String(s6b.sid()));

  /* Befund B10: laden() sagt im Kommentar "Wirft NICHT". opts.machineGuid ist eine ausdrueckliche
   * Naht; ein Aufrufer, der die Registry-Abfrage mit einer eigenen Frist umwickelt, lehnt ab.
   * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Die vorherige mit dem ungesicherten await: sie gab
   * eine abgelehnte Zusage zurueck — beim Start ein unhandledRejection. */
  let geworfen = null;
  const sW = new S.Stationsid({ log: still, datei: datei('w.json'), hostname: 'OP-PC-W', machineGuid: guidLehntAb });
  try { await sW.laden(); } catch (e) { geworfen = e; }
  ok('B10: eine abgelehnte Registry-Abfrage kommt nicht aus laden() heraus', geworfen === null,
    String(geworfen && geworfen.message));
  ok('B10: und die Station hat trotzdem eine formgueltige Kennung und ein Schluesselpaar',
    S.pruefeSid(sW.sid()) && sW.signiere(NACHRICHT) !== null, String(sW.sid()));

  /* Befund A2: dieselbe Zusage ("Wirft NICHT"), zwei bis dahin ungesicherte Stellen. Geprueft war
   * bisher nur eine Datei mit kaputtem JSON und eine mit kaputter sid — also genau die zwei Felder,
   * die laden() ueberhaupt prueft. istBrauchbar() sieht AUSSCHLIESSLICH auf sid; jedes andere Feld
   * einer fremden Datei geht ungeprueft in die Migration.
   * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Die vorherige mit
   * 'if (typeof d.erzeugt === "number" && isFinite(d.erzeugt)) d.erzeugt = new Date(d.erzeugt).toISOString()':
   * isFinite() laesst jede Zahl bis knapp unter Unendlich durch, der Datumsbereich endet aber bei
   * 8.64e15 — bei erzeugt:1e20 kam ein RangeError AUS laden() HERAUS. Beim Start ist das ohne
   * Plan-Schritt 5 ein unhandledRejection, also ein Prozessende mitten in einer Narkose. */
  console.log('\nEine Datei, die istBrauchbar() besteht und in einem UNGEPRUEFTEN Feld Muell traegt:');
  const dZ = datei('zeit.json');
  fs.writeFileSync(dZ, JSON.stringify({ sid: 'st7f3a91c2b45d', erzeugt: 1e20 }), 'utf8');
  let geworfenZ = null;
  const sZ = new S.Stationsid({ log: still, datei: dZ, hostname: 'OP-PC-Z', machineGuid: guidFest });
  try { await sZ.laden(); } catch (e) { geworfenZ = e; }
  ok('A2: erzeugt=1e20 laesst laden() NICHT ablehnen', geworfenZ === null,
    String(geworfenZ && geworfenZ.message));
  ok('A2: und die Kennung aus der Datei gilt unveraendert weiter',
    sZ.sid() === 'st7f3a91c2b45d' && !fs.existsSync(datei('zeit.ungueltig.json')), String(sZ.sid()));
  ok('A2: das unbrauchbare Feld ist geleert, es steht keine zweite Form in der Datei',
    JSON.parse(fs.readFileSync(dZ, 'utf8')).erzeugt === null,
    String(JSON.parse(fs.readFileSync(dZ, 'utf8')).erzeugt));
  ok('A2: die Station laeuft danach normal weiter (Schluessel nachgezogen, Instanzliste angelegt)',
    sZ.signiere(NACHRICHT) !== null && sZ.eigeneInstanzen()[0] === sZ.instanz);

  /* Die zweite Stelle: die Uhr-Naht. opts.jetzt ist genauso ausdruecklich angeboten wie
   * opts.machineGuid, auf das sich B10 stuetzte — ein Aufrufer, der dort etwas Unbrauchbares
   * liefert, darf den Start nicht beenden. */
  let geworfenU = null;
  const sUhr = new S.Stationsid({
    log: still, datei: datei('uhr-kaputt.json'), hostname: 'OP-PC-UZ', machineGuid: guidFest,
    jetzt: () => NaN,
  });
  try { await sUhr.laden(); } catch (e) { geworfenU = e; }
  ok('A2: eine Uhr, die NaN liefert, kommt ebenfalls nicht aus laden() heraus', geworfenU === null,
    String(geworfenU && geworfenU.message));
  ok('A2: die Station hat trotzdem eine formgueltige Kennung und ein Schluesselpaar',
    S.pruefeSid(sUhr.sid()) && sUhr.signiere(NACHRICHT) !== null, String(sUhr.sid()));

  /* Die Plausibilitaetsgrenze, die dabei mit abfaellt: eine Vorabdatei mit MIKROsekunden ergaebe
   * ein Datum im Jahr 58544 ('+058544-04-18T…'). JavaScript schreibt solche Jahre mit Vorzeichen —
   * das ist kein Zeitpunkt, den je eine Fassung gemeint hat, sondern ein Lesefehler, und es hat in
   * einem Feld nichts zu suchen, das ein Mensch im Klartext lesen soll. */
  const dMikro = datei('mikro.json');
  fs.writeFileSync(dMikro, JSON.stringify({ sid: 'stbb11cc22dd33', erzeugt: 1785312345678000 }), 'utf8');
  const sMikro = new S.Stationsid({ log: still, datei: dMikro, hostname: 'OP-PC-MY', machineGuid: guidFest });
  await sMikro.laden();
  ok('A2: aus einer Mikrosekundenzahl wird kein Datum im Jahr 58544 in der Datei',
    JSON.parse(fs.readFileSync(dMikro, 'utf8')).erzeugt === null && sMikro.sid() === 'stbb11cc22dd33',
    String(JSON.parse(fs.readFileSync(dMikro, 'utf8')).erzeugt));
  ok('A2: die Umrechnung selbst wirft bei keiner dieser Zahlen, sondern liefert null',
    [1e20, -1e20, NaN, Infinity, -Infinity, 8.64e15 + 1, 1785312345678000, '1785312345678', null,
      undefined, {}].every((v) => S.isoZeit(v) === null));
  ok('A2: eine gewoehnliche Millisekundenzahl wird weiterhin auf ISO gezogen',
    S.isoZeit(1785312345678) === new Date(1785312345678).toISOString()
    && S.isoZeit(0) === '1970-01-01T00:00:00.000Z');
  /* Die Grenze liegt dort, wo JavaScript aufhoert, ein vierstelliges Jahr zu schreiben — genau die
   * Form, die der Plan mit erzeugt:<ISO> meint und die jeder Datumsleser annimmt. */
  ok('A2: die Grenze ist das letzte vierstellige Jahr, nicht der halbe Datumsbereich',
    S.isoZeit(253402300799999) === '9999-12-31T23:59:59.999Z'
    && S.isoZeit(253402300800000) === null, String(S.isoZeit(253402300800000)));

  /* ---------------- Befund A3: die zwei Logausgaenge ohne Drossel ---------------- */
  console.log('\nKeine Warnzeile je Sekunde ins Log, in dem die klinischen Warnungen stehen:');
  let uhrL = 1785500000000;
  const zl = zaehlLog();
  const sL = new S.Stationsid({
    log: zl.log, datei: datei('drossel-log.json'), hostname: 'OP-PC-L', machineGuid: guidFest,
    jetzt: () => uhrL,
  });
  await sL.laden();
  /* WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Die vorherige: der Setzer schrieb bei JEDER Zuweisung
   * eine Zeile. Er existiert ausschliesslich als Netz fuer einen Aufrufer aus der alten Bauform —
   * und genau der weist im 1-Hz-Takt zu, also 3600 gleichlautende Zeilen je Stunde. */
  const warnVorher = zl.warn;
  /* 100 Zuweisungen im 1-Hz-Takt, also 100 Sekunden. Bei WARN_TAKT_MS = 60 s sind das GENAU ZWEI
   * Zeilen (bei 0 s und bei 60 s) — nicht 100, und nicht null: die Drossel ist keine Abschaltung,
   * ein Aufrufer aus der alten Bauform soll im Log stehen. Der Getter wird in dieser Schleife
   * absichtlich nicht angefasst, sonst kaeme die Anlaufwarnung dazwischen und die Zahl waere
   * nicht mehr scharf. */
  for (let i = 0; i < 100; i++) { sL.nurTafelSchreiben = true; uhrL += 1000; }
  ok('A3: 100 Zuweisungen an nurTafelSchreiben ergeben 2 Warnzeilen, nicht 100',
    zl.warn - warnVorher === 2, 'Warnzeilen: ' + (zl.warn - warnVorher));
  ok('A3: die Zuweisung bleibt trotzdem wirkungslos — gedrosselt ist nur das Reden darueber',
    sL.kollisionsstand() === 'unbekannt');

  /* Die zweite Sorte: die Drossel in _formMuell verglich nur gegen den ZULETZT gesehenen Wert. Ein
   * Zwilling einer Geschwisterfassung, der etwa einen Zeitstempel statt einer Instanzkennung in den
   * Knoten schreibt, aendert den Wert in jedem Takt und lief an ihr vorbei.
   * WELCHE FALSCHE FASSUNG FAELLT HIER DURCH? Genau diese reine Wertdrossel: 100 verschiedene
   * Muellwerte ergaben 100 Warnzeilen. */
  let uhrM = 1785600000000;
  const zm = zaehlLog();
  const sM = new S.Stationsid({
    log: zm.log, datei: datei('drossel-muell.json'), hostname: 'OP-PC-M', machineGuid: guidFest,
    jetzt: () => uhrM,
  });
  await sM.laden();
  const warnM = zm.warn;
  for (let i = 0; i < 100; i++) { sM.kollisionAusgeschlossen('2026-07-30T10:00:' + i); uhrM += 1000; }
  ok('A3: 100 Takte mit je einem NEUEN Muellwert ergeben 2 Warnzeilen, nicht 100',
    zm.warn - warnM === 2, 'Warnzeilen: ' + (zm.warn - warnM));
  /* Und die Gegenrichtung, damit die Drossel keine Abschaltung wird: ein Wert, der waehrend der
   * Frist auftaucht und dann stehen bleibt, muss GENAU EINMAL im Log landen — sonst stuende im
   * Knoten dauerhaft etwas, das nie jemand liest. */
  const warnM2 = zm.warn;
  for (let i = 0; i < 90; i++) { sM.kollisionAusgeschlossen('immer-derselbe-muell'); uhrM += 1000; }
  ok('A3: ein stehenbleibender Wert wird genau einmal gemeldet, nicht 90-mal und nicht nie',
    zm.warn - warnM2 === 1, 'Warnzeilen: ' + (zm.warn - warnM2));
  ok('A3: und der Muell hat weder entlastet noch bewiesen (die Drossel darf nichts entscheiden)',
    sM.kollisionsstand() === 'unbekannt' && sM.kollisionBekannt() === false);

  // Nicht vorhandener Ordner darf nicht zum Absturz fuehren
  const s5 = new S.Stationsid({
    log: still, datei: path.join(TMP, 'nicht', 'da', 'x', 'e.json'), hostname: 'OP-PC-5', machineGuid: guidFest,
  });
  await s5.laden();
  ok('Kennung auch dann, wenn der Ordner erst angelegt werden muss', S.pruefeSid(s5.sid()));

  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) {}

  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
})();
