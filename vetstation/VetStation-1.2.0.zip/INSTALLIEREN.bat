@echo off
title VetStation - installieren / aktualisieren
REM EIN Doppelklick fuer BEIDES: Neuinstallation UND Update eines vorhandenen PCs.
REM Der Installer holt sich die Adminrechte selbst (UAC-Abfrage bestaetigen).
REM
REM Er beendet zuerst die laufende Station (sonst bliebe nach dem Update der ALTE Code im
REM Speicher - genau das ist am 21.07.2026 passiert), kopiert, startet neu und PRUEFT NACH,
REM ob wirklich der neue Stand laeuft. Die Konfiguration bridge\config\devices.json bleibt erhalten.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\Install-VetStation.ps1"
if errorlevel 1 (
  echo.
  echo *** Die Installation ist nicht sauber durchgelaufen - Meldung oben lesen. ***
  echo.
)
pause
