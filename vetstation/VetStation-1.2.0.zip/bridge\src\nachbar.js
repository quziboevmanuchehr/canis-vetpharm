'use strict';
/*
 * nachbar.js — STUFE 2: der direkte Weg zwischen zwei Praxis-PCs im selben Haus, OHNE Internet.
 *
 * WOZU: Stufe 1 laesst zwei OP-Saele einander ueber Firebase sehen. Das genuegt fachlich, kostet
 * aber Freikontingent und faellt mit der Internetleitung aus. Dieser Weg ist der zweite: TCP 8771
 * von Station zu Station, im eigenen Haus, ohne Anbieter dazwischen. Er bringt NICHT Tempo (alle
 * drei Entwuerfe haben nachgerechnet, dass LAN bei diesen Takten nicht schneller ist), sondern
 * Unabhaengigkeit.
 *
 * WAS HIER NICHT DURCHGEHT — und warum diese Datei so misstrauisch ist:
 * 13 der geprueften Sicherheitsbefunde haengen ausschliesslich an diesem Weg. Er oeffnet als
 * einziger Baustein des Programms einen Port im Praxisnetz. Deshalb gilt hier durchgehend:
 * erst zaehlen, dann pruefen, dann rechnen — jede Krypto-Arbeit steht HINTER den Deckeln.
 *
 * ------------------------------------------------------------------------------------------
 * DIE VIER ENTSCHEIDUNGEN, DIE MAN NICHT MEHR ANFASSEN DARF
 * ------------------------------------------------------------------------------------------
 * 1) BINDUNG JE ADRESSE, NIE listen(8771) ALLEIN (Befund C1-11).
 *    probe.js:67 bindet ohne Host-Argument und nimmt damit JEDE Karte an — auch den VPN- oder
 *    Overlay-Adapter, den die VIRTUELL-Regex von netscan.js nicht kennt. Ein solcher Adapter
 *    traegt den Endpunkt ins Internet. Hier wird deshalb je NICHT-virtueller RFC1918-Adresse ein
 *    eigener Server mit server.listen(port, ip) gestartet, und JEDE Anfrage muss zusaetzlich aus
 *    dem /24 GENAU DIESER gebundenen Adresse kommen (netscan.subnetOf). Zwei Sperren, weil die
 *    erste (die Adressliste) sich mit einem neuen Adaptertyp aendern kann, die zweite nicht.
 *
 * 2) DIE SIGNATUR BINDET BEIDE FLUECHTIGEN SCHLUESSEL (Befund B1-1, toedlich).
 *    Signiert wird genau
 *      'vetstation-verbund-2|' + uid8 + '|' + nonceA + '|' + nonceB + '|' + sidA + '|' + sidB
 *                             + '|' + epkA + '|' + epkB
 *    Der frueher geplante Handschlag (die antwortende Seite signiert sofort, ohne fluechtige
 *    Schluessel) war ein SIGNIER-ORAKEL: ein Angreifer laesst sich vom echten Nachbarn genau die
 *    Bytes unterschreiben, die eine dritte Station sehen will, und braucht dafuer kein einziges
 *    Zugangsdatum. Mit beiden epk IN der Signatur scheitert das an einer Zwickmuehle: reicht er
 *    die Signatur unveraendert weiter, kennt er den daraus abgeleiteten Sitzungsschluessel nicht
 *    (er hat keinen der beiden privaten fluechtigen Teile); tauscht er einen epk gegen seinen
 *    eigenen, passt die Signatur nicht mehr zu den Bytes. Deshalb ist der Sitzungsschluessel
 *    nicht Beiwerk, sondern der zweite Haelfte des Beweises — und deshalb wird nach dem
 *    Handschlag AUSSCHLIESSLICH in box-Rahmen gesprochen.
 *
 * 3) OHNE GUELTIGE sigA GIBT ES 404, NICHT 401 (Befund A1-7/C1-12).
 *    Ein 401 sagt "hier ist etwas, das eine Anmeldung will". Der Port soll fuer jeden, der ihn
 *    ohne gueltigen Beweis anspricht, aussehen wie ein Port, an dem nichts ist. Das gilt
 *    ausdruecklich auch fuer alle Deckel- und Formfehler. Die EINZIGE Ausnahme ist 405 fuer
 *    nicht-GET, weil der Plan sie namentlich verlangt.
 *
 * 4) ES GIBT KEIN /nachbar/protokoll UND KEINE KURVEN UEBER LAN.
 *    Das Narkoseprotokoll ist heute der einzige Patientenweg mit Ortspruefung
 *    (server.js:196-198, 233-234) und bleibt es. Ueber LAN geht genau die kleine Uebersicht, die
 *    auch unter tafel/<sid> steht — nicht mehr.
 *
 * ------------------------------------------------------------------------------------------
 * WARUM DIESES MODUL WEDER registry NOCH matching NOCH EINEN ADAPTER LAEDT
 * ------------------------------------------------------------------------------------------
 * Fremde Daten duerfen registry.ingest nie erreichen: daran haengt die halbe Fehlerliste
 * (kollidierende deviceIds, vergiftete manual/meta-Tabellen, patient-akte.json, Haltepuffer mit
 * fremden Uhren). Es genuegt nicht, das nicht zu TUN — es darf gar nicht erreichbar sein.
 * tools/nachbar-test.js liest den Quelltext und erzwingt es. Aus demselben Grund gibt es hier
 * kein dgram: im ganzen Projekt existiert keins, ein UDP-Beacon braeuchte eine zweite
 * Firewallregel und koennte ohnehin nichts beweisen (geprueft wird erst im TCP-Handschlag).
 *
 * ------------------------------------------------------------------------------------------
 * DER VERTRAUENSANKER LIEGT IN DER CLOUD, NICHT IM NETZ
 * ------------------------------------------------------------------------------------------
 * Der oeffentliche Schluessel eines Nachbarn kommt aus verbund/lan/<sid>.pub — also ueber TLS von
 * Google, aus einem Knoten, den nur dieses Praxis-Konto beschreiben kann. Im LAN wird eine
 * behauptete sid NIE geglaubt. Beim ERSTEN Sehen wird der Schluessel in bridge/data/nachbarn.json
 * GEPINNT; eine spaetere Aenderung wird nie still uebernommen (Befunde A1-3/B1-6/C1-3). Ohne
 * einen Online-Moment gibt es im LAN keinen Anker — das ist ein bewusst getragenes Restrisiko
 * (Plan, "Bewusst getragene Restrisiken", Punkt 6).
 *
 * WARUM DER WEG TROTZDEM OHNE INTERNET TRAEGT: die uid und die gepinnten Nachbarn liegen auf der
 * Platte (data/cloud-auth.json bzw. bridge/data/nachbarn.json). Eine Station, die einmal
 * angemeldet war, kann den Handschlag also auch bei gezogenem Internetkabel fuehren. Eine
 * Station, die NIE angemeldet war, kann es nicht — und das ist richtig so: sie hat keinen Beleg,
 * zu welcher Praxis sie gehoert.
 *
 * ------------------------------------------------------------------------------------------
 * DREI ABWEICHUNGEN VOM PLANTEXT, ALLE MIT GRUND
 * ------------------------------------------------------------------------------------------
 * (a) DIE RAHMEN TRAGEN sitzung UND n. Der Plan schreibt {"typ":"box","iv":..,"tag":..,"c":..}.
 *     Der Transport ist hier HTTP/GET (so verlangt es der Plan: "NUR GET, kein Upgrade-Handler"),
 *     und ein GET traegt keinen Rumpf — die Anfrage-Rahmen stehen deshalb in der Kopfzeile X-VS,
 *     die Antwort-Rahmen als Zeilen im Rumpf. Damit ist jede Anfrage fuer sich allein stehend,
 *     und der Server muss die Sitzung wiederfinden koennen: dafuer sitzung. n ist ein je Richtung
 *     streng steigender Zaehler und liegt MIT im AAD des GCM — ohne ihn waere ein
 *     mitgeschnittener Rahmen beliebig oft wiedereinspielbar, und genau das war Befund C1-4.
 *     Die Alternative (ein langlebiger Duplex-Strom ueber einen GET-Rumpf) waere ohne sitzung
 *     ausgekommen, haette aber einen GET mit Rumpf gebraucht — das ist kein GET mehr, das jede
 *     Zwischenstelle so weiterreicht, und der Plan nennt GET ausdruecklich.
 * (b) hallo2 traegt uid8 als HINWEIS. Geprueft wird IMMER gegen das EIGENE uid8 (es steht in der
 *     signierten Zeichenkette); der Wert auf der Leitung entscheidet nichts. Er dient allein
 *     dazu, dem Menschen den richtigen Satz zu zeigen: "Diese Station gehoert zu einem anderen
 *     Praxis-Konto" statt "Signatur passt nicht" (Befund B1-13).
 * (c) EINE GEAENDERTE ips-LISTE STOPPT DEN LAN-WEG NICHT, EIN GEAENDERTER pub SCHON.
 *     Der Plan fasst beides in einem Satz zusammen. Uebernommen wird auch hier NICHTS still —
 *     beides landet in status().wartet und braucht bestaetigeSchluessel(). Der Unterschied ist
 *     die Folge: bei geaendertem pub faellt der Saal sofort auf die Cloud zurueck (die Identitaet
 *     ist offen), bei nur geaenderten Adressen laeuft er auf den GEPINNTEN Adressen weiter (die
 *     Identitaet ist unveraendert bewiesen — an einer neuen Adresse kann niemand sigB erzeugen,
 *     ohne den privaten Schluessel zu haben). Der Grund gegen die einheitliche Behandlung: eine
 *     Praxis mit DHCP haette sonst nach jedem Routerneustart einen toten LAN-Weg und einen
 *     Klartextsatz, der von einem Schluessel spricht, der sich gar nicht geaendert hat.
 */
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const netscan = require('./netscan');
const stationsid = require('./stationsid');

// ------------------------------------------------------------------ Zahlen, alle an EINER Stelle

const PORT = 8771;
const TAKT_MS = 250;

/* Die harten Deckel aus dem Plan. Sie greifen VOR jeder Krypto-Arbeit — das ist der ganze Punkt:
 * ein Angreifer im selben /24 darf diesen Prozess nicht dazu bringen, fuer ihn zu rechnen. */
const VERBINDUNGEN_MAX = 8;      // gleichzeitige Sockets UND gleichzeitige Sitzungen
const JE_ADRESSE_MAX = 2;        // beides zusaetzlich je Absenderadresse
const HANDSCHLAG_MS = 2000;      // von hallo bis beweis; danach ist die Sitzung weg
const ZEILE_MAX = 64 * 1024;     // eine Kopfzeile X-VS bzw. eine Antwortzeile
const SITZUNG_MAX_MS = 15 * 60 * 1000;   // bis zur Neuauthentisierung
const SOCKET_TIMEOUT_MS = 15000;

/* Ein gepinnter Nachbar verfaellt nach 30 Tagen (Plan, WIDERRUF). Ein ausgemusterter PC verliert
 * damit den Zugang, sobald die Praxis das Passwort aendert und jede Station einmal neu startet. */
const VERFALL_MS = 30 * 24 * 3600 * 1000;

/* Notnagel-Anklopfen: hoechstens 1x/60 s, 350 ms je Adresse, 48 gleichzeitig (~1,9 s fuer ein /24
 * — dieselben Zahlen wie netscan.scan, damit nicht zwei Stellen dasselbe verschieden dosieren). */
const KNOCK_TAKT_MS = 60000;
const KNOCK_MS = 350;
const KNOCK_GLEICHZEITIG = 48;

const VS = 1;
const INFO = 'vetstation-verbund-2';
const PRAEFIX = INFO + '|';

/* Die Weissliste der Wege. Was hier nicht steht, gibt es nicht — insbesondere gibt es
 * /nachbar/protokoll NICHT, und das ist eine Zusage, kein Versehen. */
const WEG_HALLO = '/nachbar/hallo';
const WEG_TAFEL = '/nachbar/tafel';
const WEGE = [WEG_HALLO, WEG_TAFEL];

/* Die Weissliste der Nachrichtentypen. Alles andere faellt, bevor irgendetwas ausgepackt wird. */
const TYPEN_ANFRAGE = ['hallo', 'beweis', 'box'];
const TYPEN_IM_BOX = ['tafel'];

const NACHBARN_MAX = 8;          // gefuehrte Saele (wie tafel.GRENZEN.saele — hier ohne require)
const IPS_MAX = 4;               // Adressen je Nachbar (Plan: verbund/lan/<sid>.ips, max 4)
const ANFRAGE_FRIST_MS = 4000;   // eigene Frist je ausgehender Anfrage
const SPERRE_START_MS = 2000;    // Backoff je Nachbar nach einem Fehlversuch
const SPERRE_MAX_MS = 60000;
const FEHLER_BIS_CLOUD = 3;      // ab hier gilt dieser Saal als "nicht ueber LAN erreichbar"
const MELDE_TAKT_MS = 60000;     // hoechstens eine gleichartige Logzeile je Minute

const NONCE_BYTES = 16;          // -> 32 Hexzeichen, wie im Plan
const HEX32 = /^[0-9a-f]{32}$/;
const HEX16 = /^[0-9a-f]{16}$/;
const B64_FORM = /^[A-Za-z0-9+/]+={0,2}$/;

// ------------------------------------------------------------------ reine Funktionen

function sha256hex(s) { return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex'); }

function ganz(x) { const n = Number(x); return Number.isFinite(n) ? Math.floor(n) : null; }

/*
 * uid8 — die ersten 8 Hexzeichen von sha256(uid). Sie stehen in der signierten Zeichenkette und
 * beantworten die Frage "gehoeren wir beide zur selben Praxis?", ohne die Kontokennung selbst auf
 * die Leitung zu legen. Weicht sie ab, bricht die Verbindung ab (Befund B1-13: sonst kann eine
 * Handkopplung zwei Praxen verbinden — und dann stehen die Vitalwerte eines fremden Tieres unter
 * dem Namen eines eigenen Saals).
 * null heisst "diese Station ist keinem Konto zugeordnet". Ohne uid8 gibt es keinen Handschlag.
 */
function uid8Aus(uid) {
  if (typeof uid !== 'string' || !uid) return null;
  return sha256hex(uid).slice(0, 8);
}

/*
 * DIE signierte Zeichenkette. Wortgetreu aus dem Plan, und die Reihenfolge ist Teil des Vertrags:
 * beide Seiten muessen dieselben Bytes bilden, sonst gibt es keinen Handschlag.
 *
 * NULL BEI UNBRAUCHBAREN FELDERN, und das ist keine Kosmetik: das Trennzeichen ist '|'. Ein Feld,
 * das selbst ein '|' enthaelt, verschiebt die Feldgrenzen — dann liesse sich ein Wert so waehlen,
 * dass die GLEICHE Bytefolge zu zwei verschiedenen Aussagen passt. Deshalb faellt hier alles
 * durch, was leer ist oder ein '|' traegt, statt dass es "irgendwie" mitsigniert wird.
 */
function signierZeichenkette(teile) {
  const t = teile || {};
  const felder = ['uid8', 'nonceA', 'nonceB', 'sidA', 'sidB', 'epkA', 'epkB'];
  const werte = [];
  for (let i = 0; i < felder.length; i++) {
    const w = t[felder[i]];
    if (typeof w !== 'string' || !w || w.indexOf('|') >= 0) return null;
    werte.push(w);
  }
  return PRAEFIX + werte.join('|');
}

/*
 * Nur Adressen aus den privaten Bereichen (RFC1918) werden gebunden und angesprochen. Eine
 * oeffentliche Adresse an einer nicht als virtuell erkannten Karte waere genau der Weg, auf dem
 * Befund C1-11 diesen Port ins Internet traegt.
 * ABSICHTLICH KEIN 169.254.x (APIPA): das ist die Adresse, die Windows vergibt, wenn KEIN Netz da
 * ist — zwei PCs ohne DHCP saehen sich dort zwar, aber die Praxisanleitung (docs/LAN-SETUP.md)
 * vergibt feste 192.168er-Adressen; ein APIPA-Netz ist immer ein Fehlerbild, kein Betriebsfall.
 */
function istRfc1918(ip) {
  const s = String(ip || '');
  if (!/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(s)) return false;
  const t = s.split('.').map(Number);
  if (t.some((x) => !Number.isFinite(x) || x < 0 || x > 255)) return false;
  if (t[0] === 10) return true;
  if (t[0] === 172 && t[1] >= 16 && t[1] <= 31) return true;
  if (t[0] === 192 && t[1] === 168) return true;
  return false;
}

/* Aus '::ffff:192.168.0.5' oder 'fe80::1%eth0' die blanke Adresse machen. Node liefert bei einem
 * auf IPv4 gebundenen Server zwar meist schon die blanke Form — aber "meist" ist bei einer
 * Zugangspruefung zu wenig. */
function ipRein(roh) {
  let s = String(roh == null ? '' : roh).trim();
  if (!s) return null;
  const p = s.indexOf('%');
  if (p >= 0) s = s.slice(0, p);
  s = s.replace(/^\[|\]$/g, '');
  if (/^::ffff:/i.test(s)) s = s.slice(7);
  return s || null;
}

/*
 * Liegen zwei Adressen im selben /24? Gerechnet wird ueber netscan.subnetOf — dieselbe Funktion,
 * die auch die Geraetesuche benutzt, damit "eigenes Netz" im ganzen Programm dasselbe heisst.
 * subnetOf() prueft die Form nur locker (es zaehlt Bits einer Maske), deshalb steht die
 * Formpruefung hier davor: '1.2.3.4.5' waere sonst durchgegangen.
 */
function imSelbenNetz(a, b) {
  const x = ipRein(a), y = ipRein(b);
  const form = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (!x || !y || !form.test(x) || !form.test(y)) return false;
  if (x.split('.').some((o) => Number(o) > 255) || y.split('.').some((o) => Number(o) > 255)) return false;
  const sx = netscan.subnetOf({ address: x, netmask: '255.255.255.0' });
  const sy = netscan.subnetOf({ address: y, netmask: '255.255.255.0' });
  if (!sx || !sy) return false;
  return sx.base === sy.base;
}

/* Ein fluechtiges X25519-Paar. Es lebt genau eine Sitzung lang und wird nie gespeichert — daran
 * haengt, dass ein spaeter erbeuteter Ed25519-Schluessel einen ALTEN Mitschnitt nicht mehr
 * aufschliesst. */
function epkPaar() {
  const p = crypto.generateKeyPairSync('x25519');
  return { priv: p.privateKey, pub: p.publicKey.export({ type: 'spki', format: 'der' }).toString('base64') };
}

/*
 * Der Sitzungsschluessel: X25519 -> HKDF-SHA256 -> 32 Byte fuer AES-256-GCM.
 *
 * Das Salz ist nonceA+nonceB (beide Seiten bringen also Zufall mit — der Server haelt keinen
 * Vorrat, den jemand erschoepfen koennte, Befund C1-10), der Info-Anteil ist die feste
 * Verwendungszeichenkette. WIRFT NIE: ein untergeschobener Ed25519-Schluessel statt eines X25519
 * laesst diffieHellman werfen, und ein werfender Handschlag waere ein Prozessende mitten in einer
 * Narkose. null heisst "kein Schluessel" und beendet die Verbindung geordnet.
 */
function sitzungsschluessel(eigenerPrivat, fremdesEpk, nonceA, nonceB) {
  try {
    if (!eigenerPrivat) return null;
    const roh = Buffer.from(String(fremdesEpk || ''), 'base64');
    if (!roh.length) return null;
    const pub = crypto.createPublicKey({ key: roh, format: 'der', type: 'spki' });
    const gemeinsam = crypto.diffieHellman({ privateKey: eigenerPrivat, publicKey: pub });
    return Buffer.from(crypto.hkdfSync('sha256', gemeinsam, String(nonceA) + String(nonceB), INFO, 32));
  } catch (e) { return null; }
}

/*
 * Aus der Rohliste (verbund/lan bzw. nachbarn.json) die Saele machen, mit denen ueberhaupt
 * gesprochen werden darf.
 *
 * DIE DREI SPERREN HIER SIND BEFUND A2-8 (toedlich): docs/LAN-SETUP.md schreibt JEDEM Praxis-PC
 * 192.168.0.99 vor. Ohne diese Filter spricht eine Station mit sich selbst und beschriftet das
 * Ergebnis als Nachbarsaal — der Tierarzt saehe dann die Werte SEINES Tieres unter dem Namen des
 * anderen Saals und haette keine Moeglichkeit, den Irrtum zu bemerken.
 *   (1) die eigene sid faellt heraus,
 *   (2) jede eigene Adresse faellt aus der Adressliste,
 *   (3) ein Saal ohne verbleibende Adresse oder ohne oeffentlichen Schluessel faellt ganz heraus.
 * Die dritte Sperre (gelieferte sid == erwartete sid UND instanz != eigene instanz) sitzt nicht
 * hier, sondern im Handschlag — sie braucht die Antwort der Gegenseite.
 */
function kandidaten(liste, opts) {
  const o = opts || {};
  const eigene = typeof o.eigeneSid === 'string' ? o.eigeneSid : null;
  const meine = Object.create(null);
  (Array.isArray(o.eigeneAdressen) ? o.eigeneAdressen : []).forEach((ip) => {
    const r = ipRein(ip); if (r) meine[r] = true;
  });
  const portVorgabe = ganz(o.port) || PORT;
  const max = ganz(o.max) || NACHBARN_MAX;
  const ipsMax = ganz(o.ipsMax) || IPS_MAX;
  const loopback = o.loopback === true;
  const gesehen = Object.create(null);
  const out = [];
  (Array.isArray(liste) ? liste : []).forEach((e) => {
    if (out.length >= max) return;
    if (!e || typeof e !== 'object') return;
    const sid = typeof e.sid === 'string' ? e.sid : null;
    if (!stationsid.pruefeSid(sid)) return;
    if (eigene && sid === eigene) return;
    if (gesehen[sid]) return;
    const pub = (typeof e.pub === 'string' && e.pub.length >= 40 && B64_FORM.test(e.pub)) ? e.pub : null;
    if (!pub) return;
    const ips = [];
    (Array.isArray(e.ips) ? e.ips : []).forEach((roh) => {
      if (ips.length >= ipsMax) return;
      const ip = ipRein(roh);
      if (!ip) return;
      if (!istRfc1918(ip) && !(loopback && /^127\./.test(ip))) return;
      if (meine[ip]) return;
      if (ips.indexOf(ip) >= 0) return;
      ips.push(ip);
    });
    if (!ips.length) return;
    gesehen[sid] = true;
    out.push({
      sid: sid,
      pub: pub,
      ips: ips,
      port: ganz(e.port) || portVorgabe,
      name: typeof e.name === 'string' ? e.name : null,
      quelle: e.quelle === 'pin' ? 'pin' : 'cloud',
    });
  });
  return out;
}

/* Zwei Adresslisten als Text vergleichen — sortiert, damit die REIHENFOLGE keinen Alarm ausloest.
 * Die Reihenfolge in verbund/lan haengt daran, welche Karte Windows gerade zuerst nennt. */
function ipsGleich(a, b) {
  const x = (Array.isArray(a) ? a : []).map((s) => ipRein(s)).filter(Boolean).sort().join(',');
  const y = (Array.isArray(b) ? b : []).map((s) => ipRein(s)).filter(Boolean).sort().join(',');
  return x === y;
}

/*
 * pinPruefung — die eine Stelle, an der entschieden wird, ob einem gelieferten Nachbarn geglaubt
 * wird. gepinnt = der Eintrag aus bridge/data/nachbarn.json (oder null), neu = das, was gerade
 * aus verbund/lan kam.
 *
 * Rueckgabe: { lage, pub, ips, port, nurCloud, feld, meldung, neuePub, neueIps }
 *   lage 'neu'         — noch nie gesehen: pinnen und benutzen (Vertrauen auf erstes Sehen, der
 *                        Anker ist der TLS-Weg zu Google, nicht das LAN),
 *   lage 'gleich'      — unveraendert: benutzen,
 *   lage 'verfallen'   — aelter als 30 Tage: der alte Pin zaehlt nicht mehr, es wird neu gepinnt
 *                        (WIDERRUF im Plan — ein ausgemusterter PC soll nach einem Passwortwechsel
 *                        nicht ewig weiterreden),
 *   lage 'geaendert'   — NIE still uebernehmen. pub/ips bleiben die GEPINNTEN Werte, die neuen
 *                        stehen in neuePub/neueIps und warten auf bestaetigeSchluessel(),
 *   lage 'unbrauchbar' — Form kaputt.
 *
 * WARUM nurCloud NUR BEI GEAENDERTEM pub: siehe Abweichung (c) im Kopfkommentar.
 */
function pinPruefung(gepinnt, neu, jetzt, verfallMs) {
  const leer = { lage: 'unbrauchbar', pub: null, ips: [], port: PORT, nurCloud: true, feld: null, meldung: null, neuePub: null, neueIps: [] };
  const n = (neu && typeof neu === 'object') ? neu : null;
  if (!n || !stationsid.pruefeSid(n.sid)) return leer;
  if (typeof n.pub !== 'string' || n.pub.length < 40) return leer;
  const ipsNeu = (Array.isArray(n.ips) ? n.ips : []).map((s) => ipRein(s)).filter(Boolean).slice(0, IPS_MAX);
  const portNeu = ganz(n.port) || PORT;
  const saal = (typeof n.name === 'string' && n.name) ? n.name : ('Saal ' + stationsid.sidKurz(n.sid));

  const g = (gepinnt && typeof gepinnt === 'object' && typeof gepinnt.pub === 'string') ? gepinnt : null;
  if (!g) {
    return { lage: 'neu', pub: n.pub, ips: ipsNeu, port: portNeu, nurCloud: false, feld: null, meldung: null, neuePub: null, neueIps: [] };
  }
  const t = Number(jetzt);
  const vf = (Number(verfallMs) > 0) ? Number(verfallMs) : VERFALL_MS;
  const gesehenAm = Number(g.gesehenAm);
  if (Number.isFinite(t) && Number.isFinite(gesehenAm) && (t - gesehenAm) > vf) {
    return { lage: 'verfallen', pub: n.pub, ips: ipsNeu, port: portNeu, nurCloud: false, feld: null, meldung: null, neuePub: null, neueIps: [] };
  }
  const pubAnders = g.pub !== n.pub;
  const ipsAnders = !ipsGleich(g.ips, ipsNeu);
  if (!pubAnders && !ipsAnders) {
    return { lage: 'gleich', pub: g.pub, ips: ipsNeu, port: portNeu, nurCloud: false, feld: null, meldung: null, neuePub: null, neueIps: [] };
  }
  const feld = pubAnders ? (ipsAnders ? 'pub+ips' : 'pub') : 'ips';
  const meldung = pubAnders
    ? ('Der Schluessel von ' + saal + ' hat sich geaendert — im Admin-Bereich bestaetigen')
    : ('Die Netzwerkadressen von ' + saal + ' haben sich geaendert — im Admin-Bereich bestaetigen');
  return {
    lage: 'geaendert',
    pub: g.pub,
    ips: (Array.isArray(g.ips) ? g.ips : []).map((s) => ipRein(s)).filter(Boolean),
    port: ganz(g.port) || portNeu,
    nurCloud: pubAnders,
    feld: feld,
    meldung: meldung,
    neuePub: n.pub,
    neueIps: ipsNeu,
  };
}

// ------------------------------------------------------------------ Rahmen ein- und auspacken

/*
 * AES-256-GCM. Der zusaetzlich authentisierte Anteil (AAD) traegt Sitzung, Richtung und Zaehler:
 *   - die SITZUNG, damit ein Rahmen nicht in eine andere Sitzung passt,
 *   - die RICHTUNG ('a' = Anfrage, 'b' = Antwort), damit ein Rahmen nicht zurueckgespiegelt
 *     werden kann (beide Seiten benutzen denselben Schluessel),
 *   - der ZAEHLER, damit ein mitgeschnittener Rahmen nicht erneut gilt (Befund C1-4).
 * Der Empfaenger verlangt einen STRENG steigenden Zaehler; das ist billiger und sicherer als ein
 * Gedaechtnis gesehener Rahmen (das haette wieder einen Vorrat, den jemand erschoepfen kann).
 */
function verpacke(key, sitzung, richtung, n, nutz) {
  try {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', key, iv);
    c.setAAD(Buffer.from(String(sitzung) + '|' + richtung + '|' + String(n), 'utf8'));
    const roh = Buffer.concat([c.update(Buffer.from(JSON.stringify(nutz), 'utf8')), c.final()]);
    return { vs: VS, typ: 'box', sitzung: sitzung, n: n, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), c: roh.toString('base64') };
  } catch (e) { return null; }
}

function packeAus(key, sitzung, richtung, rahmen) {
  try {
    if (!rahmen || rahmen.typ !== 'box') return null;
    const n = ganz(rahmen.n);
    if (n == null || n < 0) return null;
    const iv = Buffer.from(String(rahmen.iv || ''), 'base64');
    const tag = Buffer.from(String(rahmen.tag || ''), 'base64');
    const c = Buffer.from(String(rahmen.c || ''), 'base64');
    if (iv.length !== 12 || tag.length !== 16 || !c.length) return null;
    const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
    d.setAAD(Buffer.from(String(sitzung) + '|' + richtung + '|' + String(n), 'utf8'));
    d.setAuthTag(tag);
    const klar = Buffer.concat([d.update(c), d.final()]).toString('utf8');
    if (klar.length > ZEILE_MAX) return null;
    const obj = JSON.parse(klar);
    if (!obj || typeof obj !== 'object') return null;
    return { n: n, nutz: obj };
  } catch (e) { return null; }
}

/* Einen Anfrage-Rahmen aus der Kopfzeile X-VS lesen. 64 KB Deckel VOR dem Zerlegen — eine
 * 10-MB-Kopfzeile darf keinen JSON-Zerleger beschaeftigen. (Node begrenzt Kopfzeilen ohnehin auf
 * 16 KB; diese Zeile haengt nicht an dieser Voreinstellung.) */
function rahmenAusKopf(wert) {
  if (typeof wert !== 'string' || !wert) return null;
  if (wert.length > ZEILE_MAX) return null;
  try {
    const txt = Buffer.from(wert, 'base64').toString('utf8');
    if (txt.length > ZEILE_MAX) return null;
    const o = JSON.parse(txt);
    if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
    if (ganz(o.vs) !== VS) return null;
    if (TYPEN_ANFRAGE.indexOf(o.typ) < 0) return null;
    return o;
  } catch (e) { return null; }
}

function kopfAusRahmen(obj) { return Buffer.from(JSON.stringify(obj), 'utf8').toString('base64'); }

/* Aus einem Tafel-Satz Kennung und Instanz holen — der Satz kommt als ganzer Knoten
 * ({meta:{...},uebersicht,geraete}) ODER als flacher Satz aus tafel.tafelSatz(). Beide Formen
 * werden vom Aufrufer geliefert, und dieses Modul darf sich nicht darauf verlassen, welche. */
function kopfAus(satz) {
  if (!satz || typeof satz !== 'object') return { sid: null, instanz: null };
  const m = (satz.meta && typeof satz.meta === 'object') ? satz.meta : satz;
  return {
    sid: typeof m.sid === 'string' ? m.sid : null,
    instanz: typeof m.instanz === 'string' ? m.instanz : null,
  };
}

// ------------------------------------------------------------------ die Station im Netz

class Nachbar {
  /*
   * Alles, was von aussen kommt, kommt als Naht herein — sonst braeuchte der Test zwei PCs, ein
   * Firebase-Konto und Geduld:
   *   log         info/warn/error
   *   stationsid  die Stationskennung (sid(), pub(), signiere(), instanz) — PFLICHT
   *   tafelQuelle () => der eigene Tafel-Satz (identisch zum Inhalt von tafel/<sid>)
   *   uidQuelle   () => die uid des angemeldeten Praxis-Kontos oder null
   *   cfg         { enabled, port, taktMs, datei, jetzt, tafelAnzahl, geraeteAdressen,
   *                 adapterQuelle, knock, loopbackFuerTest, verfallMs, ... }
   *
   * cfg.tafelAnzahl und cfg.geraeteAdressen sind Funktionen, KEINE Module: sie beantworten
   * "wie viele Tafeleintraege gibt es" und "welche Geraeteadressen sind bekannt" — beides
   * Bedingungen fuer das Notnagel-Anklopfen (Befund B2-10). Als require waeren das genau die
   * Abhaengigkeiten auf registry, die dieses Modul nicht haben darf.
   */
  constructor(opts) {
    const o = opts || {};
    const c = (o.cfg && typeof o.cfg === 'object') ? o.cfg : {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    this.stationsid = o.stationsid || null;
    this._tafelQuelle = typeof o.tafelQuelle === 'function' ? o.tafelQuelle : null;
    this._uidQuelle = typeof o.uidQuelle === 'function' ? o.uidQuelle : null;

    this.cfg = {
      enabled: c.enabled !== false,
      port: ganz(c.port) || PORT,
      taktMs: Math.max(10, ganz(c.taktMs) || TAKT_MS),
      datei: c.datei || path.join(__dirname, '..', 'data', 'nachbarn.json'),
      verfallMs: ganz(c.verfallMs) || VERFALL_MS,
      handschlagMs: Math.max(50, ganz(c.handschlagMs) || HANDSCHLAG_MS),
      sitzungMaxMs: Math.max(1000, ganz(c.sitzungMaxMs) || SITZUNG_MAX_MS),
      anfrageFristMs: Math.max(50, ganz(c.anfrageFristMs) || ANFRAGE_FRIST_MS),
      verbindungenMax: Math.max(1, ganz(c.verbindungenMax) || VERBINDUNGEN_MAX),
      jeAdresseMax: Math.max(1, ganz(c.jeAdresseMax) || JE_ADRESSE_MAX),
      knockTaktMs: Math.max(1000, ganz(c.knockTaktMs) || KNOCK_TAKT_MS),
      /* AUSSCHLIESSLICH fuer tools/nachbar-test.js: erlaubt zusaetzlich die Bindung auf 127.0.0.1
       * und Kandidaten unter 127.x. Im Betrieb steht das nie an — deshalb meldet start() es im
       * Klartext, wenn es doch einmal gesetzt sein sollte. Die /24-Pruefung je Anfrage gilt
       * unveraendert weiter, dieser Schalter haengt sie NICHT aus. */
      loopbackFuerTest: c.loopbackFuerTest === true,
    };
    this._jetzt = typeof c.jetzt === 'function' ? c.jetzt : Date.now;
    this._adapterQuelle = typeof c.adapterQuelle === 'function' ? c.adapterQuelle : (() => netscan.localAdapters());
    this._knock = typeof c.knock === 'function' ? c.knock : netscan.knock;
    this._tafelAnzahl = typeof c.tafelAnzahl === 'function' ? c.tafelAnzahl : (() => 0);
    this._geraeteAdressen = typeof c.geraeteAdressen === 'function' ? c.geraeteAdressen : (() => []);

    this._gestoppt = true;
    this._lauscher = [];             // [{ ip, server }] — je gebundener Adresse einer
    this._sockets = new Set();
    this._jeAdresse = Object.create(null);   // ip -> offene Sockets
    this._sitzungen = new Map();     // sitzung -> Satz (Serverseite)
    this._roh = [];                  // zuletzt uebergebene Liste aus verbund/lan
    this._nachbarn = new Map();      // sid -> { sid, pub, ips, port, name, quelle }
    this._wartet = new Map();        // sid -> { sid, feld, meldung, neuePub, neueIps, seit }
    this._verb = new Map();          // sid -> Client-Zustand
    this._pin = { v: 1, eintraege: Object.create(null) };
    this._pinGeladen = false;
    this._offen = null;              // die EINE offene Anfrage ueber ALLE Nachbarn (Befund C2-10)
    this._reiheIdx = 0;
    this._takt = null;
    this._aufraeumTakt = null;
    this._aufTafel = [];
    this._knockAm = 0;
    this._knockLaeuft = false;
    this._knockFunde = [];
    this._gemeldet = Object.create(null);
    this._z = {
      anfragen: 0, hallo: 0, hallo2: 0, beweisGut: 0, beweisFalsch: 0, tafelRaus: 0, tafelRein: 0,
      abgewiesen: Object.create(null), deckelGesamt: 0, deckelAdresse: 0, fremdesNetz: 0,
      fremdesKonto: 0, gegendruck: 0, verworfen: 0, knockLaeufe: 0, selbstgespraech: 0,
    };
  }

  // ---------------------------------------------------------------- Ein und Aus

  start() {
    if (!this._gestoppt) return;
    if (!this.cfg.enabled) { this.log.info('nachbar', 'Der LAN-Weg zu den Nachbarsaelen ist ausgeschaltet.'); return; }
    if (!this.stationsid || typeof this.stationsid.sid !== 'function' || !this.stationsid.sid()) {
      this.log.warn('nachbar', 'Der LAN-Weg bleibt aus: diese Station hat noch keine gueltige '
        + 'Stationskennung. Ohne sie kann kein Nachbar pruefen, mit wem er spricht.');
      return;
    }
    this._gestoppt = false;
    this._pinLaden();
    this._binde();
    if (this.cfg.loopbackFuerTest) {
      this.log.warn('nachbar', 'loopbackFuerTest ist eingeschaltet — das gehoert in den Test, '
        + 'nicht in eine Praxis. Bitte in der Konfiguration entfernen.');
    }
    this._takt = setInterval(() => this._taktSchritt(), this.cfg.taktMs);
    this._aufraeumTakt = setInterval(() => this._sitzungenAufraeumen(), 1000);
    this.log.info('nachbar', 'LAN-Weg zu den Nachbarsaelen an, Port ' + this.cfg.port + ' auf '
      + (this._lauscher.length ? this._lauscher.map((l) => l.ip).join(', ') : '(keiner Karte)') + '.');
  }

  /* stop() muss wirklich alles loswerden — ein liegengebliebener Zeitgeber oder Socket haelt den
   * Prozess am Leben, den index.js gerade ordentlich beenden will. */
  stop() {
    this._gestoppt = true;
    if (this._takt) { clearInterval(this._takt); this._takt = null; }
    if (this._aufraeumTakt) { clearInterval(this._aufraeumTakt); this._aufraeumTakt = null; }
    // destroy() und nicht abort(): abort() ist seit Node 14 abgekuendigt und laesst den Socket in
    // manchen Faellen offen — genau das, was stop() beseitigen soll.
    if (this._offen) { try { this._offen.destroy(); } catch (e) { /* schon zu */ } this._offen = null; }
    this._sitzungen.clear();
    this._sockets.forEach((s) => { try { s.destroy(); } catch (e) { /* schon zu */ } });
    this._sockets.clear();
    this._jeAdresse = Object.create(null);
    this._lauscher.forEach((l) => { try { l.server.close(); } catch (e) { /* schon zu */ } });
    this._lauscher = [];
    this._verb.forEach((v) => { v.stand = 'zu'; v.sitzung = null; v.key = null; });
  }

  laeuft() { return !this._gestoppt; }

  // ---------------------------------------------------------------- Bindung

  /*
   * JE NICHT-VIRTUELLER RFC1918-ADRESSE EIN EIGENER SERVER. Ausdruecklich NICHT listen(port)
   * allein: das bindet 0.0.0.0 und damit auch VPN- und Overlay-Karten (Befund C1-11). Ein
   * Bindungsfehler auf EINER Karte darf die anderen nicht mitnehmen — deshalb je Adresse ein
   * eigener Server und ein eigener Fehlerzweig.
   */
  _binde() {
    let liste = [];
    try { liste = this._adapterQuelle() || []; } catch (e) { liste = []; }
    const adressen = [];
    liste.forEach((a) => {
      if (!a || a.virtuell) return;
      const ip = ipRein(a.address);
      if (!ip || !istRfc1918(ip)) return;
      if (adressen.indexOf(ip) < 0) adressen.push(ip);
    });
    /* netscan.localAdapters() laesst interne Karten aus, 127.0.0.1 steht dort also nie. Fuer den
     * Test wird sie ausdruecklich dazugelegt — im Betrieb ist der Schalter aus. */
    if (this.cfg.loopbackFuerTest && adressen.indexOf('127.0.0.1') < 0) adressen.push('127.0.0.1');
    if (!adressen.length) {
      this.log.warn('nachbar', 'Keine Netzwerkkarte mit einer Hausnetz-Adresse (192.168.x, 10.x, '
        + '172.16-31.x) gefunden — der LAN-Weg lauscht nirgends. Die Fern-Ansicht ueber die Cloud '
        + 'ist davon nicht betroffen.');
      return;
    }
    adressen.forEach((ip) => this._bindeEine(ip));
  }

  _bindeEine(ip) {
    const server = http.createServer((req, res) => this._anfrage(ip, req, res));
    /* KEIN server.on('upgrade'). Ohne Zuhoerer verwirft Node eine Upgrade-Anfrage selbst — es
     * gibt hier also keine WebSocket-Tuer und keinen zweiten Rahmenzerleger. */
    server.on('connection', (sock) => this._socketAn(ip, sock));
    server.on('clientError', (err, sock) => { try { sock.destroy(); } catch (e) { /* schon zu */ } });
    server.on('error', (e) => {
      /* Der Eintrag muss WIEDER RAUS, nicht nur eine Logzeile bekommen: status().gebunden ist die
       * Antwort auf "wo lauscht diese Station" — sie wird im Admin-Bereich angezeigt und in die
       * Cloud geschrieben (verbund/lan/<sid>.ips). Eine Adresse, auf der die Bindung gescheitert
       * ist, wuerde dort stehen und jeden Nachbarn ins Leere laufen lassen. */
      this._lauscher = this._lauscher.filter((l) => l.server !== server);
      this.log.warn('nachbar', 'Port ' + this.cfg.port + ' auf ' + ip + ' laesst sich nicht binden ('
        + (e && e.code ? e.code : e && e.message) + '). Dieser Netzzugang bleibt aus; die anderen '
        + 'laufen weiter.');
    });
    try { server.listen(this.cfg.port, ip); } catch (e) { return; }
    this._lauscher.push({ ip: ip, server: server });
  }

  /*
   * DER ERSTE DECKEL SITZT AUF DEM SOCKET, nicht auf der Anfrage — und damit vor allem, was
   * Rechenzeit kostet: vor dem Zerlegen der Kopfzeilen, vor jedem JSON, vor jeder Krypto.
   */
  _socketAn(bind, sock) {
    const von = ipRein(sock.remoteAddress);
    const zu = () => { try { sock.destroy(); } catch (e) { /* schon zu */ } };
    if (!von || !imSelbenNetz(von, bind)) { this._z.fremdesNetz++; return zu(); }
    if (this._sockets.size >= this.cfg.verbindungenMax) { this._z.deckelGesamt++; return zu(); }
    if ((this._jeAdresse[von] || 0) >= this.cfg.jeAdresseMax) { this._z.deckelAdresse++; return zu(); }
    this._sockets.add(sock);
    this._jeAdresse[von] = (this._jeAdresse[von] || 0) + 1;
    sock.setTimeout(SOCKET_TIMEOUT_MS, () => zu());
    const weg = () => {
      if (!this._sockets.has(sock)) return;
      this._sockets.delete(sock);
      this._jeAdresse[von] = Math.max(0, (this._jeAdresse[von] || 1) - 1);
      if (!this._jeAdresse[von]) delete this._jeAdresse[von];
    };
    sock.once('close', weg);
    sock.once('error', weg);
  }

  // ---------------------------------------------------------------- Serverseite

  _anfrage(bind, req, res) {
    this._z.anfragen++;
    this._sitzungenAufraeumen();

    // (1) NUR GET. 405 ist die einzige Antwort, die diesen Port ueberhaupt verraet — der Plan
    //     verlangt sie namentlich, damit ein Fehlaufruf im Haus erklaerbar bleibt.
    if (req.method !== 'GET') return this._abweisen(res, 405, 'methode');

    // (2) Weissliste der Wege. /nachbar/protokoll steht nicht darin und wird es nie.
    const weg = String(req.url || '').split('?')[0];
    if (WEGE.indexOf(weg) < 0) return this._abweisen(res, 404, 'weg');

    // (3) Absenderadresse im /24 GENAU DER gebundenen Adresse (Befund C1-11).
    const von = ipRein(req.socket && req.socket.remoteAddress);
    if (!von || !imSelbenNetz(von, bind)) { this._z.fremdesNetz++; return this._abweisen(res, 404, 'netz'); }

    // (4) Rahmen aus der Kopfzeile, mit 64-KB-Deckel VOR dem Zerlegen.
    const rahmen = rahmenAusKopf(req.headers['x-vs']);
    if (!rahmen) return this._abweisen(res, 404, 'rahmen');

    if (weg === WEG_HALLO && rahmen.typ === 'hallo') return this._hallo(von, rahmen, res);
    if (weg === WEG_HALLO && rahmen.typ === 'beweis') return this._beweis(von, rahmen, res);
    if (weg === WEG_TAFEL && rahmen.typ === 'box') return this._tafelAnfrage(von, rahmen, res);
    return this._abweisen(res, 404, 'typ');
  }

  /*
   * hallo -> hallo2. HIER ENTSTEHT DIE EINZIGE KRYPTO-ARBEIT, DIE EIN FREMDER AUSLOESEN KANN
   * (ein X25519-Paar und eine Ed25519-Signatur). Deshalb stehen ALLE Deckel und alle Formpruefungen
   * davor, in dieser Reihenfolge — und deshalb ist die Handschlagfrist 2 s: eine Sitzung, die nicht
   * binnen 2 s ihren Beweis bringt, belegt keinen der acht Plaetze mehr.
   */
  _hallo(von, r, res) {
    if (this._sitzungen.size >= this.cfg.verbindungenMax) { this._z.deckelGesamt++; return this._abweisen(res, 404, 'deckel'); }
    if (this._sitzungenVon(von) >= this.cfg.jeAdresseMax) { this._z.deckelAdresse++; return this._abweisen(res, 404, 'deckelIp'); }

    if (!stationsid.pruefeSid(r.sid)) return this._abweisen(res, 404, 'form');
    if (typeof r.nonceA !== 'string' || !HEX32.test(r.nonceA)) return this._abweisen(res, 404, 'form');
    if (typeof r.epkA !== 'string' || r.epkA.length < 40 || r.epkA.length > 200 || !B64_FORM.test(r.epkA)) return this._abweisen(res, 404, 'form');

    const meinUid8 = uid8Aus(this._uid());
    if (!meinUid8) {
      this._melde('info', 'keinKonto', 'Ein Nachbar (' + von + ') hat angeklopft, aber diese Station '
        + 'ist keinem Praxis-Konto zugeordnet. Ohne Konto gibt es keinen Beleg, zu welcher Praxis '
        + 'wir gehoeren — der Handschlag wird abgelehnt.');
      return this._abweisen(res, 404, 'keinKonto');
    }
    if (typeof r.uid8 !== 'string' || r.uid8 !== meinUid8) {
      this._z.fremdesKonto++;
      this._melde('warn', 'fremdesKonto', 'Diese Station gehoert zu einem anderen Praxis-Konto — '
        + 'die Anfrage von ' + von + ' wurde abgelehnt. Zwei Praxen duerfen sich nicht ueber das '
        + 'Hausnetz verbinden.');
      return this._abweisen(res, 404, 'konto');
    }
    const eigeneSid = this.stationsid.sid();
    if (r.sid === eigeneSid) {
      /* Der Gegenpart zu Befund A2-8 auf der Serverseite: wer unsere eigene Kennung behauptet,
       * ist entweder wir selbst (falsch verdrahtete Kandidatenliste) oder jemand, der sich als
       * wir ausgibt. Beides ist kein Nachbar. */
      this._z.selbstgespraech++;
      return this._abweisen(res, 404, 'eigeneSid');
    }

    const paar = epkPaar();
    const nonceB = crypto.randomBytes(NONCE_BYTES).toString('hex');
    const text = signierZeichenkette({
      uid8: meinUid8, nonceA: r.nonceA, nonceB: nonceB,
      sidA: r.sid, sidB: eigeneSid, epkA: r.epkA, epkB: paar.pub,
    });
    if (!text) return this._abweisen(res, 404, 'form');
    const sigB = this.stationsid.signiere(text);
    if (!sigB) return this._abweisen(res, 404, 'ohneSchluessel');

    const jetzt = this._jetzt();
    const sitzung = crypto.randomBytes(16).toString('hex');
    this._sitzungen.set(sitzung, {
      sitzung: sitzung, ip: von, sidA: r.sid, uid8: meinUid8,
      epkPriv: paar.priv, epkA: r.epkA, epkB: paar.pub,
      nonceA: r.nonceA, nonceB: nonceB, text: text,
      key: null, geprueft: false,
      erstelltAm: jetzt, ablaufAm: jetzt + this.cfg.handschlagMs,
      nEin: 0, nAus: 0,
    });
    this._z.hallo++;
    this._z.hallo2++;
    /* uid8 geht als HINWEIS mit — die Gegenseite prueft trotzdem gegen ihr EIGENES uid8 (es steht
     * in der signierten Zeichenkette). Der Wert dient allein dem Klartextsatz fuer den Menschen. */
    return this._antwort(res, {
      vs: VS, typ: 'hallo2', sid: eigeneSid, uid8: meinUid8,
      nonceB: nonceB, epkB: paar.pub, sigB: sigB, sitzung: sitzung,
    });
  }

  /*
   * beweis. OHNE GUELTIGE sigA GIBT ES 404 — nicht 401, nicht 403, keine Begruendung im Rumpf.
   * Wer hier scheitert, soll nicht einmal erfahren, dass es diesen Dienst gibt.
   */
  _beweis(von, r, res) {
    const s = this._sitzungen.get(String(r.sitzung || ''));
    if (!s || s.ip !== von || s.geprueft) return this._abweisen(res, 404, 'sitzung');
    if (this._jetzt() > s.ablaufAm) { this._sitzungen.delete(s.sitzung); return this._abweisen(res, 404, 'frist'); }
    if (typeof r.sigA !== 'string' || r.sigA.length < 40 || r.sigA.length > 200) return this._abweisen(res, 404, 'form');

    /* Der oeffentliche Schluessel der Gegenseite kommt AUSSCHLIESSLICH aus dem eigenen
     * Nachbarverzeichnis (verbund/lan ueber TLS bzw. der Pin auf der Platte) — nie aus der
     * Leitung. Kennen wir die sid nicht, gibt es keinen Handschlag: eine unbekannte Station ist
     * kein Nachbar, sondern ein Fremder im Netz. */
    const n = this._nachbarn.get(s.sidA);
    if (!n || !n.pub) return this._abweisen(res, 404, 'unbekannt');
    if (!stationsid.pruefeSignatur(n.pub, s.text, r.sigA)) {
      this._z.beweisFalsch++;
      this._sitzungen.delete(s.sitzung);
      return this._abweisen(res, 404, 'sigA');
    }
    const key = sitzungsschluessel(s.epkPriv, s.epkA, s.nonceA, s.nonceB);
    if (!key) { this._sitzungen.delete(s.sitzung); return this._abweisen(res, 404, 'schluessel'); }

    s.key = key;
    s.geprueft = true;
    s.epkPriv = null;                                  // der fluechtige Teil wird nicht aufbewahrt
    s.ablaufAm = this._jetzt() + this.cfg.sitzungMaxMs;  // 15 min bis zur Neuauthentisierung
    this._z.beweisGut++;
    const box = verpacke(key, s.sitzung, 'b', ++s.nAus, {
      typ: 'ok', sid: this.stationsid.sid(), instanz: this._eigeneInstanz(),
    });
    if (!box) return this._abweisen(res, 404, 'box');
    return this._antwort(res, box);
  }

  /* Der einzige Weg, ueber den Daten dieses Saals das Haus durchqueren: die kleine Uebersicht,
   * identisch zum Inhalt von tafel/<sid>. Keine Kurven, kein Protokoll, keine Rohwerte. */
  _tafelAnfrage(von, r, res) {
    const s = this._sitzungen.get(String(r.sitzung || ''));
    if (!s || s.ip !== von || !s.geprueft || !s.key) return this._abweisen(res, 404, 'sitzung');
    if (this._jetzt() > s.ablaufAm) { this._sitzungen.delete(s.sitzung); return this._abweisen(res, 404, 'abgelaufen'); }
    const auf = packeAus(s.key, s.sitzung, 'a', r);
    if (!auf) return this._abweisen(res, 404, 'box');
    if (auf.n <= s.nEin) return this._abweisen(res, 404, 'wiederholt');   // Befund C1-4
    s.nEin = auf.n;
    if (TYPEN_IM_BOX.indexOf(auf.nutz.typ) < 0) return this._abweisen(res, 404, 'innentyp');

    let satz = null;
    try { satz = this._tafelQuelle ? this._tafelQuelle() : null; } catch (e) { satz = null; }
    if (!satz || typeof satz !== 'object') return this._abweisen(res, 404, 'ohneTafel');
    const box = verpacke(s.key, s.sitzung, 'b', ++s.nAus, {
      typ: 'tafel', sid: this.stationsid.sid(), instanz: this._eigeneInstanz(), satz: satz,
    });
    if (!box) return this._abweisen(res, 404, 'box');
    this._z.tafelRaus++;
    return this._antwort(res, box);
  }

  /*
   * Eine Antwortzeile senden. ZWEI Deckel:
   *   - laenger als 64 KB: gar nicht erst senden (ein aufgeblaehter Tafel-Satz darf keinen
   *     Nachbarn beschaeftigen),
   *   - Gegendruck: liegt schon mehr als eine Zeile im Ausgangspuffer, wird der Rahmen VERWORFEN
   *     statt gepuffert. Ein Nachbar, der nicht liest, darf nicht den Speicher dieser Station
   *     fuellen — der naechste Takt bringt ohnehin frischere Zahlen als der zurueckgehaltene
   *     Rahmen (A1-8, A2-11, B1-9, B2-11).
   */
  _antwort(res, obj) {
    let zeile;
    try { zeile = JSON.stringify(obj) + '\n'; } catch (e) { return this._abweisen(res, 404, 'serialisierung'); }
    if (Buffer.byteLength(zeile) > ZEILE_MAX) { this._z.verworfen++; return this._abweisen(res, 404, 'zuLang'); }
    if (res.writableEnded || res.destroyed) { this._z.verworfen++; return; }
    if (Number(res.writableLength) > ZEILE_MAX) { this._z.gegendruck++; this._z.verworfen++; try { res.destroy(); } catch (e) { /* schon zu */ } return; }
    try {
      // KEINE CORS-Kopfzeile. Dieser Port ist kein Web-Dienst und darf von keiner Seite im
      // Browser erreichbar sein — eine Access-Control-Kopfzeile waere genau die Erlaubnis dazu.
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
      });
      const ok = res.write(zeile);
      if (!ok) this._z.gegendruck++;
      res.end();
    } catch (e) { this._z.verworfen++; }
  }

  _abweisen(res, code, grund) {
    this._z.abgewiesen[grund] = (this._z.abgewiesen[grund] || 0) + 1;
    try {
      const kopf = { 'Content-Type': 'text/plain; charset=utf-8', 'Content-Length': '0', 'Cache-Control': 'no-store' };
      if (code === 405) kopf.Allow = 'GET';
      res.writeHead(code, kopf);
      res.end();
    } catch (e) { /* die Gegenseite ist schon weg */ }
  }

  _sitzungenVon(ip) {
    let n = 0;
    this._sitzungen.forEach((s) => { if (s.ip === ip) n++; });
    return n;
  }

  _sitzungenAufraeumen() {
    const jetzt = this._jetzt();
    const weg = [];
    this._sitzungen.forEach((s, k) => { if (jetzt > s.ablaufAm) weg.push(k); });
    weg.forEach((k) => this._sitzungen.delete(k));
  }

  _eigeneInstanz() {
    const i = this.stationsid && this.stationsid.instanz;
    return (typeof i === 'string' && HEX16.test(i)) ? i : null;
  }

  _uid() {
    try { const u = this._uidQuelle ? this._uidQuelle() : null; return typeof u === 'string' ? u : null; }
    catch (e) { return null; }
  }

  // ---------------------------------------------------------------- Nachbarverzeichnis und Pin

  /*
   * setzeNachbarn(liste) — die Liste aus verbund/lan: [{ sid, pub, ips[], port }].
   * Sie geht durch kandidaten() (eigene sid und eigene Adressen fallen heraus, Befund A2-8) und
   * danach Eintrag fuer Eintrag durch pinPruefung(). Was sich geaendert hat, wird NICHT
   * uebernommen, sondern gemeldet und in status().wartet gestellt.
   */
  setzeNachbarn(liste) {
    this._pinLaden();
    this._roh = Array.isArray(liste) ? liste.slice(0, NACHBARN_MAX * 4) : [];
    const eigeneSid = this.stationsid && typeof this.stationsid.sid === 'function' ? this.stationsid.sid() : null;
    const roh = kandidaten(this._roh, {
      eigeneSid: eigeneSid,
      eigeneAdressen: this.eigeneAdressen(),
      port: this.cfg.port,
      loopback: this.cfg.loopbackFuerTest,
    });
    const jetzt = this._jetzt();
    const neu = new Map();
    let pinGeaendert = false;
    roh.forEach((k) => {
      const p = pinPruefung(this._pin.eintraege[k.sid], k, jetzt, this.cfg.verfallMs);
      if (p.lage === 'unbrauchbar') return;
      if (p.lage === 'neu' || p.lage === 'verfallen' || p.lage === 'gleich') {
        this._wartet.delete(k.sid);
        this._pin.eintraege[k.sid] = {
          pub: p.pub, fp: stationsid.fingerabdruck(p.pub), ips: p.ips, port: p.port,
          name: k.name || null, gesehenAm: jetzt,
          bestaetigtAm: (this._pin.eintraege[k.sid] && this._pin.eintraege[k.sid].bestaetigtAm) || null,
        };
        pinGeaendert = true;
        if (p.lage === 'neu') {
          this.log.info('nachbar', 'Neuer Nachbarsaal ' + stationsid.sidKurz(k.sid) + ' gemerkt '
            + '(Fingerabdruck ' + stationsid.fingerabdruck(p.pub) + ', Adressen ' + p.ips.join(', ') + ').');
        }
      } else if (p.lage === 'geaendert') {
        const vorher = this._wartet.get(k.sid);
        this._wartet.set(k.sid, {
          sid: k.sid, feld: p.feld, meldung: p.meldung,
          neuePub: p.neuePub, neueIps: p.neueIps, nurCloud: p.nurCloud,
          seit: vorher ? vorher.seit : jetzt,
        });
        if (!vorher || vorher.feld !== p.feld) this.log.warn('nachbar', p.meldung + '.');
        if (p.nurCloud) {
          /* Quelle zurueck auf Cloud: dieser Saal wird ueber LAN gar nicht mehr angesprochen,
           * bis ein Mensch bestaetigt hat. Ein geaenderter Schluessel ist eine Frage der
           * IDENTITAET, und die darf keine Station allein beantworten. */
          this._verbWeg(k.sid);
          return;
        }
      }
      neu.set(k.sid, { sid: k.sid, pub: p.pub, ips: p.ips, port: p.port, name: k.name || null, quelle: 'cloud' });
    });

    /* Was die Cloud gerade nicht nennt (Internet weg), kommt aus dem Pin — genau dafuer ist er da.
     *
     * DER DECKEL MUSS HIER NOCH EINMAL STEHEN (Gegenpruefung 31.07.2026, nachgemessen): kandidaten()
     * deckelt nur die EINE Liste, die es gerade bekommt, und dieser Zweig ruft es je Eintrag mit
     * einer EINELEMENTIGEN Liste auf — der Deckel greift dort also nie. _pin.eintraege sammelt
     * dagegen jede sid, die in 30 Tagen einmal in verbund/lan stand (Neuinstallation, getauschter
     * PC, Umbenennung). Gemessen: 30 gepinnte Saele ergaben bei schweigender Cloud 30 Nachbarn
     * statt 8. Folgen waeren, dass der Rundlauf (EINE offene Anfrage, 250 ms) jeden Saal nur noch
     * alle 7,5 s statt alle 2 s erreicht und ueber LAN mehr Saele hereinkommen, als Tafel und
     * Streifen ueberhaupt zeigen (N17). Sortiert wird NICHT: die Reihenfolge in _pin.eintraege ist
     * die Reihenfolge des ersten Sehens und damit stabil — ein Sortieren nach Alter liesse die
     * Auswahl bei jedem Takt kippen. */
    Object.keys(this._pin.eintraege).forEach((sid) => {
      if (neu.size >= NACHBARN_MAX) return;
      if (neu.has(sid)) return;
      if (this._wartet.has(sid) && this._wartet.get(sid).nurCloud) return;
      const e = this._pin.eintraege[sid];
      if (!e || !e.pub) return;
      if (Number.isFinite(Number(e.gesehenAm)) && (jetzt - Number(e.gesehenAm)) > this.cfg.verfallMs) return;
      const k = kandidaten([{ sid: sid, pub: e.pub, ips: e.ips, port: e.port, name: e.name, quelle: 'pin' }], {
        eigeneSid: eigeneSid, eigeneAdressen: this.eigeneAdressen(),
        port: this.cfg.port, loopback: this.cfg.loopbackFuerTest,
      })[0];
      if (k) neu.set(sid, k);
    });

    this._nachbarn = neu;
    this._verb.forEach((v, sid) => { if (!neu.has(sid)) this._verbWeg(sid); });
    if (pinGeaendert) this._pinSpeichern();
    return this.nachbarn();
  }

  nachbarn() { return Array.from(this._nachbarn.values()).map((n) => ({ sid: n.sid, ips: n.ips.slice(), port: n.port, quelle: n.quelle })); }

  /*
   * bestaetigeSchluessel(sid) — der Knopf im Admin-Bereich. Erst hier wird eine Aenderung von pub
   * oder ips uebernommen, und nur hier. Rueckgabe: true, wenn wirklich etwas bestaetigt wurde.
   */
  bestaetigeSchluessel(sid) {
    const w = this._wartet.get(String(sid || ''));
    if (!w) return false;
    this._pinLaden();
    const jetzt = this._jetzt();
    const alt = this._pin.eintraege[w.sid] || {};
    this._pin.eintraege[w.sid] = {
      pub: w.neuePub || alt.pub,
      fp: stationsid.fingerabdruck(w.neuePub || alt.pub),
      ips: (w.neueIps && w.neueIps.length) ? w.neueIps.slice() : (alt.ips || []),
      port: alt.port || this.cfg.port,
      name: alt.name || null,
      gesehenAm: jetzt,
      bestaetigtAm: jetzt,
    };
    this._wartet.delete(w.sid);
    this._verbWeg(w.sid);
    this._pinSpeichern();
    this.log.info('nachbar', 'Der Schluessel von Saal ' + stationsid.sidKurz(w.sid) + ' wurde von '
      + 'Hand bestaetigt (Fingerabdruck ' + this._pin.eintraege[w.sid].fp + ').');
    this.setzeNachbarn(this._roh);
    return true;
  }

  /*
   * Die eigenen Adressen — sie muessen aus JEDER Kandidatenliste heraus (Befund A2-8).
   *
   * DIE LOOPBACK-AUSNAHME GILT NUR IM TEST und ist dort nicht Bequemlichkeit, sondern
   * Voraussetzung: 127.0.0.1 ist die eigene UND die fremde Adresse, wenn beide Stationen im selben
   * Prozess laufen. Unterschieden werden sie dann ueber den Port. Im Betrieb ist der Schalter aus,
   * und dann faellt 127.0.0.1 wie jede andere eigene Adresse heraus.
   */
  eigeneAdressen() {
    let liste = [];
    try { liste = this._adapterQuelle() || []; } catch (e) { liste = []; }
    const out = [];
    const nimm = (ip) => {
      if (!ip || out.indexOf(ip) >= 0) return;
      if (this.cfg.loopbackFuerTest && /^127\./.test(ip)) return;
      out.push(ip);
    };
    liste.forEach((a) => nimm(a && ipRein(a.address)));
    this._lauscher.forEach((l) => nimm(l.ip));
    return out;
  }

  /* bridge/data/nachbarn.json — laden, mit Verfall. WIRFT NIE: eine kaputte Datei darf den LAN-Weg
   * kosten, nie den Start der Station. */
  _pinLaden() {
    if (this._pinGeladen) return;
    this._pinGeladen = true;
    let roh = null;
    try { if (fs.existsSync(this.cfg.datei)) roh = JSON.parse(fs.readFileSync(this.cfg.datei, 'utf8')); }
    catch (e) {
      this.log.warn('nachbar', 'bridge/data/nachbarn.json ist nicht lesbar (' + (e && e.message)
        + ') — die gemerkten Nachbarn gelten als unbekannt und werden aus der Cloud neu geholt.');
      roh = null;
    }
    const jetzt = this._jetzt();
    const eintraege = Object.create(null);
    const quelle = (roh && roh.eintraege && typeof roh.eintraege === 'object') ? roh.eintraege : {};
    Object.keys(quelle).forEach((sid) => {
      if (!stationsid.pruefeSid(sid)) return;
      const e = quelle[sid];
      if (!e || typeof e !== 'object' || typeof e.pub !== 'string' || e.pub.length < 40) return;
      const gesehenAm = Number(e.gesehenAm);
      if (!Number.isFinite(gesehenAm)) return;
      if ((jetzt - gesehenAm) > this.cfg.verfallMs) return;      // 30 Tage, dann verfaellt er
      eintraege[sid] = {
        pub: e.pub, fp: stationsid.fingerabdruck(e.pub),
        ips: (Array.isArray(e.ips) ? e.ips : []).map((s) => ipRein(s)).filter(Boolean).slice(0, IPS_MAX),
        port: ganz(e.port) || this.cfg.port,
        name: typeof e.name === 'string' ? e.name : null,
        gesehenAm: gesehenAm,
        bestaetigtAm: Number.isFinite(Number(e.bestaetigtAm)) ? Number(e.bestaetigtAm) : null,
      };
    });
    this._pin = { v: 1, eintraege: eintraege };
  }

  _pinSpeichern() {
    try {
      const ordner = path.dirname(this.cfg.datei);
      if (!fs.existsSync(ordner)) fs.mkdirSync(ordner, { recursive: true });
      fs.writeFileSync(this.cfg.datei, JSON.stringify({ v: 1, eintraege: this._pin.eintraege }, null, 2), 'utf8');
      return true;
    } catch (e) {
      this._melde('warn', 'pinSchreiben', 'bridge/data/nachbarn.json laesst sich nicht schreiben ('
        + (e && e.message) + '). Der LAN-Weg laeuft weiter, merkt sich die Nachbarn aber nur bis '
        + 'zum naechsten Neustart.');
      return false;
    }
  }

  // ---------------------------------------------------------------- Clientseite

  /* aufTafel(cb) — cb(sid, satz, 'lan'). So fuettert dieser Weg spaeter fremdstore. Ein werfender
   * Rueckruf darf den Takt nicht anhalten: fremde Daten duerfen den eigenen Saal nie beruehren. */
  aufTafel(cb) { if (typeof cb === 'function') this._aufTafel.push(cb); }

  _liefere(sid, satz) {
    this._z.tafelRein++;
    this._aufTafel.forEach((cb) => {
      try { cb(sid, satz, 'lan'); }
      catch (e) { this._melde('warn', 'rueckruf', 'Ein Empfaenger der Nachbardaten hat einen Fehler geworfen (' + (e && e.message) + ').'); }
    });
  }

  _verbFuer(k) {
    let v = this._verb.get(k.sid);
    if (!v) {
      v = { sid: k.sid, stand: 'zu', ip: null, ipIdx: 0, sitzung: null, key: null, nAus: 0, nEin: 0,
        nonceA: null, nonceB: null, epkPriv: null, epkA: null, epkB: null, text: null,
        authAb: 0, fehler: 0, sperreBis: 0, letzterSatzAm: 0, grund: null };
      this._verb.set(k.sid, v);
    }
    return v;
  }

  _verbWeg(sid) { this._verb.delete(sid); }

  /*
   * DER TAKT. 250 ms, und genau EINE offene Anfrage ueber ALLE Nachbarn gleichzeitig (Befund
   * C2-10): mehr gleichzeitige Anfragen haetten bei acht Saelen acht gleichzeitige
   * Krypto-Handschlaege ergeben, und die liegen auf demselben Prozess wie der 350-ms-Rundruf des
   * EIGENEN Saals. Randbedingung 6 sagt dazu: der eigene Saal wird durch nichts langsamer.
   */
  _taktSchritt() {
    if (this._gestoppt) return;
    if (this._offen) return;
    const jetzt = this._jetzt();
    const liste = Array.from(this._nachbarn.values());
    if (!liste.length) { this._knockVielleicht(); return; }
    for (let i = 0; i < liste.length; i++) {
      const k = liste[(this._reiheIdx + i) % liste.length];
      const v = this._verbFuer(k);
      if (jetzt < v.sperreBis) continue;
      this._reiheIdx = (this._reiheIdx + i + 1) % liste.length;
      if (v.stand === 'offen' && jetzt > v.authAb) { v.stand = 'zu'; v.sitzung = null; v.key = null; }
      if (v.stand === 'zu') return this._schrittHallo(k, v);
      if (v.stand === 'hallo') return this._schrittBeweis(k, v);
      return this._schrittTafel(k, v);
    }
    this._knockVielleicht();
  }

  _adresseFuer(k, v) {
    const ips = k.ips.concat(this._knockFunde.filter((ip) => k.ips.indexOf(ip) < 0));
    if (!ips.length) return null;
    return ips[v.ipIdx % ips.length];
  }

  _schrittHallo(k, v) {
    const eigeneSid = this.stationsid.sid();
    const meinUid8 = uid8Aus(this._uid());
    if (!meinUid8) { this._fehlschlag(v, 'kein Praxis-Konto angemeldet'); return; }
    const ip = this._adresseFuer(k, v);
    if (!ip) { this._fehlschlag(v, 'keine Adresse'); return; }
    const paar = epkPaar();
    const nonceA = crypto.randomBytes(NONCE_BYTES).toString('hex');
    v.ip = ip; v.nonceA = nonceA; v.epkPriv = paar.priv; v.epkA = paar.pub;
    this._sende(ip, k.port, WEG_HALLO, { vs: VS, typ: 'hallo', sid: eigeneSid, uid8: meinUid8, nonceA: nonceA, epkA: paar.pub },
      (fehler, antwort) => {
        if (fehler || !antwort || antwort.typ !== 'hallo2') return this._fehlschlag(v, fehler || 'keine Antwort auf hallo');
        /* BEFUND A2-8, erste Haelfte: die gelieferte sid MUSS die erwartete sein, und sie darf
         * nicht die eigene sein. docs/LAN-SETUP.md schreibt JEDEM Praxis-PC 192.168.0.99 vor —
         * ohne diese zwei Zeilen spricht eine Station mit sich selbst und nennt das Ergebnis
         * "Nachbarsaal". */
        if (antwort.sid !== k.sid) return this._fehlschlag(v, 'fremde Stationskennung geantwortet');
        if (antwort.sid === eigeneSid) { this._z.selbstgespraech++; return this._fehlschlag(v, 'die Station hat sich selbst erreicht'); }
        if (typeof antwort.uid8 === 'string' && antwort.uid8 !== meinUid8) {
          this._z.fremdesKonto++;
          this._melde('warn', 'fremdesKonto', 'Diese Station gehoert zu einem anderen Praxis-Konto — '
            + 'die Verbindung zu ' + ip + ' wurde abgebrochen.');
          return this._fehlschlag(v, 'anderes Praxis-Konto', SPERRE_MAX_MS);
        }
        if (typeof antwort.nonceB !== 'string' || !HEX32.test(antwort.nonceB)) return this._fehlschlag(v, 'unbrauchbare Zufallszahl');
        const text = signierZeichenkette({
          uid8: meinUid8, nonceA: nonceA, nonceB: antwort.nonceB,
          sidA: eigeneSid, sidB: k.sid, epkA: paar.pub, epkB: antwort.epkB,
        });
        if (!text) return this._fehlschlag(v, 'unbrauchbare Handschlagfelder');
        /* Geprueft wird gegen den GEPINNTEN Schluessel, nie gegen etwas aus der Leitung. */
        if (!stationsid.pruefeSignatur(k.pub, text, antwort.sigB)) return this._fehlschlag(v, 'Unterschrift des Nachbarn passt nicht');
        const key = sitzungsschluessel(paar.priv, antwort.epkB, nonceA, antwort.nonceB);
        if (!key) return this._fehlschlag(v, 'kein Sitzungsschluessel');
        v.nonceB = antwort.nonceB; v.epkB = antwort.epkB; v.text = text; v.key = key;
        v.sitzung = String(antwort.sitzung || ''); v.stand = 'hallo'; v.nAus = 0; v.nEin = 0;
        v.epkPriv = null;
      });
  }

  _schrittBeweis(k, v) {
    const sigA = this.stationsid.signiere(v.text);
    if (!sigA) return this._fehlschlag(v, 'diese Station kann nicht unterschreiben');
    this._sende(v.ip, k.port, WEG_HALLO, { vs: VS, typ: 'beweis', sitzung: v.sitzung, sigA: sigA },
      (fehler, antwort) => {
        if (fehler || !antwort) return this._fehlschlag(v, fehler || 'keine Antwort auf beweis');
        const auf = packeAus(v.key, v.sitzung, 'b', antwort);
        if (!auf || auf.n <= v.nEin) return this._fehlschlag(v, 'Antwort nicht entschluesselbar');
        v.nEin = auf.n;
        if (auf.nutz.typ !== 'ok') return this._fehlschlag(v, 'unerwartete Antwort');
        const pruefung = this._vorDerNutzung(k, auf.nutz);
        if (pruefung) return this._fehlschlag(v, pruefung);
        v.stand = 'offen';
        v.authAb = this._jetzt() + this.cfg.sitzungMaxMs;
        v.fehler = 0; v.sperreBis = 0; v.grund = null;
      });
  }

  _schrittTafel(k, v) {
    const box = verpacke(v.key, v.sitzung, 'a', ++v.nAus, { typ: 'tafel' });
    if (!box) return this._fehlschlag(v, 'Rahmen liess sich nicht verpacken');
    this._sende(v.ip, k.port, WEG_TAFEL, box, (fehler, antwort) => {
      if (fehler || !antwort) return this._fehlschlag(v, fehler || 'keine Antwort auf tafel');
      const auf = packeAus(v.key, v.sitzung, 'b', antwort);
      if (!auf || auf.n <= v.nEin) return this._fehlschlag(v, 'Antwort nicht entschluesselbar');
      v.nEin = auf.n;
      if (auf.nutz.typ !== 'tafel') return this._fehlschlag(v, 'unerwartete Antwort');
      const pruefung = this._vorDerNutzung(k, auf.nutz);
      if (pruefung) return this._fehlschlag(v, pruefung);
      const satz = auf.nutz.satz;
      if (!satz || typeof satz !== 'object') return this._fehlschlag(v, 'leerer Tafel-Satz');
      const kopf = kopfAus(satz);
      if (kopf.sid && kopf.sid !== k.sid) return this._fehlschlag(v, 'der Tafel-Satz traegt eine fremde Kennung');
      v.fehler = 0; v.sperreBis = 0; v.grund = null;
      v.letzterSatzAm = this._jetzt();
      this._liefere(k.sid, satz);
    });
  }

  /*
   * DIE DREI PRUEFUNGEN VOR DER ERSTEN NUTZUNG (Befund A2-8, toedlich). Sie stehen hier zusammen,
   * damit keine davon an einer Stelle vergessen wird:
   *   gelieferte sid == erwartete sid, sid != eigene sid, instanz != eigene instanz.
   * Die dritte ist die, die den Doppelstart auf DEMSELBEN PC faengt: dieselbe Kennung, dieselbe
   * Adresse, aber ein anderer Prozess — ohne sie stuende der eigene Saal als Nachbarsaal im
   * Streifen, und der Tierarzt saehe die Werte SEINES Tieres zweimal, einmal falsch beschriftet.
   */
  _vorDerNutzung(k, nutz) {
    const eigeneSid = this.stationsid.sid();
    if (nutz.sid !== k.sid) return 'fremde Stationskennung in der Antwort';
    if (nutz.sid === eigeneSid) { this._z.selbstgespraech++; return 'die Station hat sich selbst erreicht'; }
    const eigene = this._eigeneInstanz();
    if (eigene && typeof nutz.instanz === 'string' && nutz.instanz === eigene) {
      this._z.selbstgespraech++;
      return 'die Antwort kommt vom eigenen Prozess';
    }
    return null;
  }

  _fehlschlag(v, grund, mindestens) {
    v.fehler++;
    v.stand = 'zu'; v.sitzung = null; v.key = null; v.epkPriv = null;
    v.ipIdx++;                                        // beim naechsten Mal die naechste Adresse
    v.grund = grund;
    const stufe = Math.min(SPERRE_MAX_MS, SPERRE_START_MS * Math.pow(2, Math.min(5, v.fehler - 1)));
    v.sperreBis = this._jetzt() + Math.max(stufe, ganz(mindestens) || 0);
    if (v.fehler === FEHLER_BIS_CLOUD) {
      this._melde('info', 'lanAus:' + v.sid, 'Saal ' + stationsid.sidKurz(v.sid) + ' ist ueber das '
        + 'Hausnetz nicht erreichbar (' + grund + '). Er wird weiter ueber die Cloud gezeigt.');
    }
  }

  /*
   * EINE ausgehende Anfrage. Sie ist der einzige Ort, an dem dieses Modul ins Netz greift, und sie
   * haelt den Platz "die EINE offene Anfrage" besetzt, bis sie fertig ist — auch im Fehlerfall.
   * Der Rahmen steht in der Kopfzeile X-VS (GET traegt keinen Rumpf), die Antwort ist eine Zeile.
   */
  _sende(ip, port, weg, rahmen, fertig) {
    if (this._offen) return;
    let kopf;
    try { kopf = kopfAusRahmen(rahmen); } catch (e) { return fertig('Rahmen unbrauchbar'); }
    if (kopf.length > ZEILE_MAX) return fertig('Rahmen zu gross');
    let erledigt = false;
    const schluss = (fehler, antwort) => {
      if (erledigt) return;
      erledigt = true;
      this._offen = null;
      try { fertig(fehler, antwort); } catch (e) {
        this._melde('warn', 'auswertung', 'Beim Auswerten einer Nachbarantwort ist ein Fehler aufgetreten (' + (e && e.message) + ').');
      }
    };
    let req;
    try {
      req = http.request({
        host: ip, port: port, path: weg, method: 'GET',
        headers: { 'X-VS': kopf, Accept: 'application/json', Connection: 'close' },
        // Kein gemeinsamer Agent: es gibt ohnehin nur EINE offene Anfrage, und ein
        // Verbindungspool haette die Deckel der Gegenseite (2 je Adresse) still ausgereizt.
        agent: false,
      });
    } catch (e) { return schluss('Anfrage nicht moeglich (' + (e && e.message) + ')'); }
    this._offen = req;
    req.setTimeout(this.cfg.anfrageFristMs, () => { try { req.destroy(); } catch (e) { /* schon zu */ } schluss('Zeitueberschreitung'); });
    req.once('error', (e) => schluss('Netzfehler (' + (e && e.code ? e.code : e && e.message) + ')'));
    req.once('response', (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        return schluss('Antwort ' + res.statusCode + (res.statusCode === 404 ? ' (der Nachbar kennt uns nicht oder weist uns ab)' : ''));
      }
      let text = '';
      let zuViel = false;
      res.setEncoding('utf8');
      res.on('data', (s) => {
        if (zuViel) return;
        text += s;
        if (text.length > ZEILE_MAX) { zuViel = true; text = ''; try { res.destroy(); } catch (e) { /* schon zu */ } schluss('Antwort laenger als 64 KB'); }
      });
      res.once('end', () => {
        if (zuViel) return;
        const zeile = text.split('\n')[0];
        if (!zeile) return schluss('leere Antwort');
        let obj = null;
        try { obj = JSON.parse(zeile); } catch (e) { return schluss('Antwort ist kein gueltiges JSON'); }
        if (!obj || typeof obj !== 'object' || ganz(obj.vs) !== VS) return schluss('Antwort in unbekanntem Format');
        schluss(null, obj);
      });
      res.once('error', (e) => schluss('Lesefehler (' + (e && e.message) + ')'));
    });
    try { req.end(); } catch (e) { schluss('Anfrage liess sich nicht senden'); }
  }

  // ---------------------------------------------------------------- Notnagel: Anklopfen

  /*
   * DRITTER ERKENNUNGSWEG, und ausdruecklich der letzte (Befund B2-10). Er laeuft NUR, wenn
   *   - es mehr als EINEN Tafeleintrag gibt (also ueberhaupt ein zweiter Saal existiert),
   *   - im eigenen /24 KEINE bekannte Geraeteadresse liegt (sonst klopft eine Einzelplatz-Praxis
   *     jahrelang ihre eigenen Monitore an — das ist genau der Fehler, den B2-10 benennt),
   *   - hoechstens 1x/60 s,
   *   - und kein Nachbar gerade ueber eine bekannte Adresse antwortet.
   * Gefundene Adressen werden NICHT zu Nachbarn: sie sind nur zusaetzliche ADRESSEN fuer bereits
   * bekannte sid. Die Identitaet entscheidet weiterhin allein der Handschlag.
   * KEIN UDP, kein dgram — siehe Kopfkommentar.
   */
  _knockVielleicht() {
    if (this._knockLaeuft || this._gestoppt) return;
    const jetzt = this._jetzt();
    if (jetzt - this._knockAm < this.cfg.knockTaktMs) return;
    let tafeln = 0;
    try { tafeln = ganz(this._tafelAnzahl()) || 0; } catch (e) { tafeln = 0; }
    if (tafeln <= 1) return;
    const eigen = this._lauscher.length ? this._lauscher[0].ip : null;
    if (!eigen) return;
    let geraete = [];
    try { geraete = this._geraeteAdressen() || []; } catch (e) { geraete = []; }
    if (geraete.some((ip) => imSelbenNetz(ip, eigen))) return;
    if (Array.from(this._verb.values()).some((v) => v.stand === 'offen')) return;
    this._knockAm = jetzt;
    this._knockLaeuft = true;
    this._z.knockLaeufe++;
    const sub = netscan.subnetOf({ address: eigen, netmask: '255.255.255.0' });
    if (!sub) { this._knockLaeuft = false; return; }
    const meine = this.eigeneAdressen();
    const alle = [];
    for (let i = 1; i <= 254; i++) {
      const ip = sub.base + i;
      if (meine.indexOf(ip) < 0) alle.push(ip);
    }
    const funde = [];
    netscan.pool(alle, async (ip) => {
      const r = await this._knock(ip, this.cfg.port, KNOCK_MS);
      if (r && r.offen) funde.push(ip);
    }, KNOCK_GLEICHZEITIG).then(() => {
      this._knockLaeuft = false;
      this._knockFunde = funde.slice(0, NACHBARN_MAX * IPS_MAX);
      if (funde.length) {
        this._melde('info', 'knock', 'Im eigenen Netz antworten ' + funde.length + ' Adressen auf '
          + 'Port ' + this.cfg.port + ' (' + funde.join(', ') + '). Sie werden als ZUSATZadressen '
          + 'bekannter Saele versucht — wer dort steht, muss sich trotzdem ausweisen.');
      }
    }).catch(() => { this._knockLaeuft = false; });
  }

  // ---------------------------------------------------------------- Auskunft

  status() {
    const jetzt = this._jetzt();
    const nachbarn = [];
    this._nachbarn.forEach((k, sid) => {
      const v = this._verb.get(sid);
      nachbarn.push({
        sid: sid,
        kurz: stationsid.sidKurz(sid),
        name: k.name || null,
        fp: stationsid.fingerabdruck(k.pub),
        ips: k.ips.slice(),
        port: k.port,
        quelle: k.quelle,
        stand: v ? v.stand : 'zu',
        adresse: v ? v.ip : null,
        fehler: v ? v.fehler : 0,
        grund: v ? v.grund : null,
        letzterSatzVorMs: (v && v.letzterSatzAm) ? Math.max(0, jetzt - v.letzterSatzAm) : null,
        ueberLan: !!(v && v.stand === 'offen' && v.letzterSatzAm),
      });
    });
    const wartet = [];
    this._wartet.forEach((w) => wartet.push({ sid: w.sid, kurz: stationsid.sidKurz(w.sid), feld: w.feld, meldung: w.meldung, nurCloud: w.nurCloud, seit: w.seit }));
    return {
      laeuft: !this._gestoppt,
      port: this.cfg.port,
      gebunden: this._lauscher.map((l) => l.ip),
      sockets: this._sockets.size,
      sitzungen: this._sitzungen.size,
      nachbarn: nachbarn,
      wartet: wartet,
      offeneAnfrage: !!this._offen,
      knock: { letztAm: this._knockAm || null, laeuft: this._knockLaeuft, funde: this._knockFunde.slice() },
      deckel: {
        verbindungenMax: this.cfg.verbindungenMax, jeAdresseMax: this.cfg.jeAdresseMax,
        handschlagMs: this.cfg.handschlagMs, zeileMax: ZEILE_MAX,
        sitzungMaxMs: this.cfg.sitzungMaxMs, socketTimeoutMs: SOCKET_TIMEOUT_MS,
      },
      zaehler: this._z,
    };
  }

  /* Logdrossel. Der Takt ist 250 ms — ohne sie stuenden 14400 gleiche Zeilen je Stunde in dem Log,
   * in dem waehrend einer Narkose die klinischen Warnungen stehen. */
  _melde(stufe, schluessel, text) {
    const jetzt = this._jetzt();
    const alt = this._gemeldet[schluessel];
    if (alt && alt.text === text && (jetzt - alt.am) < MELDE_TAKT_MS) return;
    this._gemeldet[schluessel] = { text: text, am: jetzt };
    (this.log[stufe] || this.log.info).call(this.log, 'nachbar', text);
  }
}

module.exports = {
  Nachbar,
  // reine Funktionen, getrennt pruefbar (ohne Netz, ohne Uhr)
  signierZeichenkette, sitzungsschluessel, istRfc1918, imSelbenNetz,
  kandidaten, pinPruefung, uid8Aus,
  // Beiwerk, das der Test ebenfalls einzeln fassen koennen muss
  ipRein, ipsGleich, epkPaar, verpacke, packeAus, rahmenAusKopf, kopfAusRahmen, kopfAus,
  // Zahlen
  PORT, TAKT_MS, VERBINDUNGEN_MAX, JE_ADRESSE_MAX, HANDSCHLAG_MS, ZEILE_MAX,
  SITZUNG_MAX_MS, SOCKET_TIMEOUT_MS, VERFALL_MS, KNOCK_TAKT_MS, IPS_MAX, NACHBARN_MAX,
  INFO, PRAEFIX, WEG_HALLO, WEG_TAFEL, WEGE, TYPEN_ANFRAGE, TYPEN_IM_BOX,
};
