'use strict';
/*
 * logger.js — Lokales Diagnose-Log (Technik/Verbindung, §14.4).
 * Schreibt anonymisierte Ereignisse in data/diag.log (lokal, keine Cloud) und haelt
 * einen Ringpuffer der letzten Ereignisse fuer den Admin-Bereich vor. Wird zusaetzlich
 * ueber den WebSocket als MSG.DIAG an die UI gesendet.
 *
 * WIEDERHOLUNGEN WERDEN ZUSAMMENGEFASST (Befund 2.2/2.3, 21.07.2026):
 * Bei nicht erreichbarer Cloud schrieb der Publisher ~2 Fehlerzeilen pro Sekunde, der HL7-Client
 * bei abwesendem Geraet ~40 pro Minute. Der Ringpuffer fasst 500 Zeilen — nach gut vier Minuten
 * war er voll und SAEMTLICHE Verbindungsmeldungen daraus verdraengt. Ausgerechnet das Log, das
 * bei der Inbetriebnahme helfen soll, enthielt nur noch Dauerfehler.
 * Deshalb: identische Meldungen erzeugen KEINE neue Zeile mehr, sondern zaehlen die vorhandene
 * hoch. Sobald etwas anderes passiert, wird die Wiederholung als EINE Zeile abgeschlossen.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = path.join(DATA_DIR, 'diag.log');
const MAX_RING = 500;
const DEDUP_MS = 5 * 60 * 1000;   // laenger als jede sinnvolle Wiederholrate

const ring = [];
let sink = null;          // Funktion, die Ereignisse an die UI weiterreicht (MSG.DIAG)
let letzte = null;        // zuletzt ausgegebenes Ereignis (fuer die Zusammenfassung)
let wiederholt = 0;       // wie oft es seither identisch wiederkam
const einmalig = new Set();

function ensureDir() {
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (_) {}
}

function setSink(fn) { sink = fn; }

function schluessel(level, source, msg) { return level + '|' + source + '|' + msg; }

function ausgeben(ev) {
  const line = new Date(ev.ts).toISOString() + ' [' + ev.level + '] ' + ev.source + ': ' + ev.msg;
  if (ev.level === 'error') console.error(line); else console.log(line);
  try { ensureDir(); fs.appendFile(LOG_FILE, line + '\n', () => {}); } catch (_) {}
  if (sink) { try { sink(ev); } catch (_) {} }
}

// Schliesst eine laufende Wiederholungsserie mit EINER zusammenfassenden Zeile ab.
function serieAbschliessen() {
  if (!wiederholt || !letzte) { wiederholt = 0; return; }
  const ev = {
    ts: Date.now(), level: letzte.level, source: letzte.source,
    msg: '(vorige Meldung ' + wiederholt + '× wiederholt)', wiederholungen: wiederholt,
  };
  ring.push(ev);
  if (ring.length > MAX_RING) ring.shift();
  ausgeben(ev);
  wiederholt = 0;
}

function log(level, source, msg, extra) {
  const text = String(msg);
  const k = schluessel(level, source, text);
  const now = Date.now();

  // Identisch zur letzten Meldung und noch im Zeitfenster -> nur hochzaehlen, keine neue Zeile.
  if (letzte && letzte._k === k && (now - letzte.ts) < DEDUP_MS) {
    wiederholt++;
    letzte.ts = now;
    letzte.wiederholungen = wiederholt;
    return letzte;
  }

  serieAbschliessen();

  const ev = { ts: now, level: level, source: source, msg: text };
  if (extra !== undefined) ev.extra = extra;
  Object.defineProperty(ev, '_k', { value: k, enumerable: false, writable: true });
  ring.push(ev);
  if (ring.length > MAX_RING) ring.shift();
  letzte = ev;
  ausgeben(ev);
  return ev;
}

module.exports = {
  setSink,
  recent(n) { return ring.slice(-(n || 100)); },
  info: (s, m, e) => log('info', s, m, e),
  warn: (s, m, e) => log('warn', s, m, e),
  error: (s, m, e) => log('error', s, m, e),
  // Meldungen, die pro Programmlauf HOECHSTENS EINMAL erscheinen sollen (z.B. Einrichtungshinweise).
  once(key, level, source, msg) {
    if (einmalig.has(key)) return null;
    einmalig.add(key);
    return log(level || 'info', source, msg);
  },
  // Nur fuer Tests: Zustand zuruecksetzen.
  _reset() { ring.length = 0; letzte = null; wiederholt = 0; einmalig.clear(); },
};
