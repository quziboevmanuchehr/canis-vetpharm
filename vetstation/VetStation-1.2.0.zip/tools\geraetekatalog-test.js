'use strict';
/*
 * geraetekatalog-test.js — der Katalog muss stimmen, BEVOR ihn jemand liest.
 *
 * WAS DIESER TEST FESTHAELT:
 * Der Katalog (bridge/src/geraetekatalog.js) ist ab 1.2.0 die einzige Quelle fuer
 *   - die Ports, auf denen gelauscht wird,
 *   - die MAC-Praefixe, an denen ein Medizingeraet erkannt wird,
 *   - die Menuepfade, die einem Tierarzt im OP angezeigt werden.
 * Ein Tippfehler darin ist deshalb kein Schoenheitsfehler: ein falscher Port heisst, dass ein
 * Geraet sendet und niemand zuhoert (genau das war am 31.07.2026 mit Port 5510 der Fall, ohne
 * eine einzige Logzeile), und ein falscher Menuepfad schickt jemanden mitten im OP-Betrieb auf
 * eine Suche, die nicht enden kann.
 *
 * Ebenso wichtig: KEIN Eintrag ohne Quelle. Ein Eintrag ohne Quelle ist ein Geruecht, und
 * Geruechte gehoeren nicht in eine Narkosestation.
 *
 * Start: node tools/geraetekatalog-test.js      (laeuft auch in tools/alle-tests.js)
 */
const k = require('../bridge/src/geraetekatalog');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

console.log('VetStation — Geraetekatalog\n');

console.log('Selbstpruefung der Daten:');
const fehler = k.pruefe();
ok('kein einziger Formfehler im Katalog', fehler.length === 0, fehler.join(' | '));
ok('mindestens die bekannten Geraete sind drin', k.alle().length >= 6, 'nur ' + k.alle().length);

console.log('\nNachschlagen:');
ok('nachId findet das LifeVet 10C', !!k.nachId('eickemeyer-lifevet-10c'));
ok('nachId auf Unbekanntes gibt null (kein Absturz)', k.nachId('gibtsnicht') === null);
ok('weg() findet einen Weg des LifeVet 10C', !!k.weg('eickemeyer-lifevet-10c', 'hl7-push-8830'));

console.log('\nSuche (so, wie ein Tierarzt tippt):');
ok('"lifevet" findet die LifeVet-Geraete', k.suche('lifevet').length >= 2);
ok('"LifeVet 10 C" findet trotz Leerzeichen', k.suche('LifeVet 10 C').some((g) => g.id === 'eickemeyer-lifevet-10c'));
ok('"umec 12" findet das uMEC12 Vet', k.suche('umec 12').some((g) => g.id === 'mindray-umec12-vet'));
ok('"ePM 10" findet das LifeVet 10C ueber den Alias', k.suche('ePM 10').some((g) => g.id === 'eickemeyer-lifevet-10c'));
ok('leere Suche gibt alles zurueck', k.suche('').length === k.alle().length);
ok('Unsinn findet nichts (statt irgendetwas)', k.suche('traktor').length === 0);

console.log('\nAbgeleitete Portliste:');
const ports = k.datenPorts();
ok('Ports sind Zahlen, keine Zeichenketten', ports.every((p) => typeof p === 'number'));
ok('keine doppelten Ports', ports.length === new Set(ports).size, ports.join(','));
ok('3502 steht zuerst (Werkseinstellung des uMEC12 — Reihenfolge zaehlt)', ports[0] === 3502, ports.join(','));
ok('8830 ist dabei (Standardziel des LifeVet 10C)', ports.indexOf(8830) >= 0, ports.join(','));
ok('5510 ist dabei (Server-Port des LifeVet M)', ports.indexOf(5510) >= 0, ports.join(','));
ok('4601 ist dabei (HL7-Abfrage)', ports.indexOf(4601) >= 0, ports.join(','));
ok('8771 ist NICHT dabei — das ist der Nachbar-Port, kein Geraeteport', ports.indexOf(8771) < 0);
ok('8770 ist NICHT dabei — das ist die eigene Oberflaeche', ports.indexOf(8770) < 0);
ok('geraeteAufPort(8830) nennt das LifeVet 10C', k.geraeteAufPort(8830).some((g) => g.id === 'eickemeyer-lifevet-10c'));

console.log('\nMAC-Praefixe:');
const oui = k.ouiListe();
ok('98cce4 (Mindray) ist dabei', oui.indexOf('98cce4') >= 0, oui.join(','));
ok('000f14 (Mindray/Eickemeyer) ist dabei', oui.indexOf('000f14') >= 0, oui.join(','));
ok('alle OUI sind genau 6 Zeichen', oui.every((o) => /^[0-9a-f]{6}$/.test(o)), oui.join(','));
ok('istMedizinMac erkennt 98-CC-E4-00-D5-EB (das echte uMEC12)', k.istMedizinMac('98-CC-E4-00-D5-EB'));
ok('istMedizinMac erkennt 00:0f:14:2b:10:52 (das echte LifeVet)', k.istMedizinMac('00:0f:14:2b:10:52'));
ok('istMedizinMac verwirft eine Handy-MAC', !k.istMedizinMac('2c-9c-58-28-4a-59'));
ok('istMedizinMac verwirft Unsinn ohne Absturz', !k.istMedizinMac('') && !k.istMedizinMac(null) && !k.istMedizinMac('xy'));
ok('herstellerVonMac nennt Mindray', /Mindray|Eickemeyer/.test(k.herstellerVonMac('98cce400d5eb') || ''));
ok('geraeteMitOui(98cce4) liefert mehrere Modelle', k.geraeteMitOui('98cce400d5eb').length >= 2);

console.log('\nEhrlichkeit der Eintraege:');
k.alle().forEach((g) => {
  ok('„' + g.modell + '“ hat eine Quelle', (g.quellen || []).length > 0);
});
// Der Veta 5 ist der wichtigste Ehrlichkeitsfall: er DARF nicht als anbindbar erscheinen.
const veta = k.nachId('mindray-veta-5');
ok('Veta 5: kein Weg behauptet lesbare Werte', veta && !(veta.wege || []).some((w) => w.vorlage && w.adapter === 'hl7'));
ok('Veta 5: der Fallstrick nennt MD2 beim Namen', veta && /MD2/.test(veta.fallstricke || ''));
const umec = k.nachId('mindray-umec12-vet');
ok('uMEC12: es wird nicht behauptet, dass laufende Zahlenwerte kommen', umec && /KEINE laufenden Zahlenwerte/.test(umec.fallstricke || ''));

console.log('\n---');
console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
console.log('OK (' + pass + ' Pruefungen)');
