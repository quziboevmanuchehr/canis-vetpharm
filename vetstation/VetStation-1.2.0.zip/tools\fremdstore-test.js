'use strict';
/*
 * fremdstore-test.js — sichert das Gedaechtnis fuer FREMDE OP-Saele ab (bridge/src/fremdstore.js).
 *
 * Was hier NIE wieder passieren darf:
 *   • Ein toter OP-Saal sieht brandaktuell aus. Ein Saal, dessen Uhr vorgeht, ergibt sonst ein
 *     Alter von 0 ms — gruen, live, mit seinen letzten Vitalwerten neben einer laufenden Narkose.
 *     Negatives Alter MUSS "Alter unbekannt" ergeben, niemals 0 (Nachbesserung N16).
 *   • Ein OP-Saal steht nach 60 s Stille weiter mit Zahlen da. Ab 'offline' werden die Zahlen
 *     ERSETZT, nicht nur eingefaerbt.
 *   • Ein OP-Saal verschwindet lautlos, weil der Deckel greift. Der Deckel muss als ZAHL und als
 *     Klartext im Ergebnis stehen (Nachbesserung N17).
 *   • Der LAN-Weg ueberholt die Wahrheit statt nur die Laufzeit. Bei Widerspruch gilt IMMER die
 *     Cloud, und der Saal traegt es sichtbar.
 *   • Ein hakender LAN-Weg friert die Anzeige ein. Nach 3 Fehlversuchen oder 3 s Stille gilt die
 *     Cloud.
 *   • Zwei Tiere werden zu einem. Verlegung ausschliesslich ueber gleiche, NICHT LEERE pid — bei
 *     zwei 22-kg-Hunden ist der patientKey in beiden Saelen 'sw_hund_22'.
 *   • Dasselbe Geraet sendet an zwei Stationen und niemand merkt es. Erkannt wird das ueber die
 *     vollstaendige Geraeteliste (N13), nicht ueber das gekuerzte Kachelfeld dv.
 *   • Die Station fuehrt sich selbst als Nachbarsaal (gleiche sid oder gleiche instanz).
 *   • Fremde Daten erreichen registry/matching/cloud/einen Adapter.
 *
 * Laeuft OHNE Netz und OHNE echte Uhr: jede Alterung entsteht unten durch RECHNEN mit einer
 * uebergebenen Zahl, nicht durch Warten. Geprueft wird das nicht nur am Quelltext, sondern am
 * Verhalten — ohne uebergebene Uhr darf keine Funktion eine Dauer erfinden.
 *
 * Start: node tools/fremdstore-test.js
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const F = require('../bridge/src/fremdstore');
const tafel = require('../bridge/src/tafel');
const tafelabo = require('../bridge/src/tafelabo');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

// Feste Uhr. Alle Alterungen entstehen durch Rechnen mit T0, nie durch Date.now().
const T0 = 1800000000000;
const SID_A = 'st7f3a91c2b45d';
const SID_B = 'stb1c2d3e4f506';
const SID_C = 'stc0ffee123456';
const SID_EIGEN = 'st0000000000ee';
const INST_A = 'aaaabbbbccccdddd';
const INST_B = '1111222233334444';
const INST_EIGEN = 'eeeeffff00001111';

const stillesLog = { info() {}, warn() {}, error() {} };

/* Ein Tafelknoten, wie ihn die Datenbank unter tafel/<sid> fuehrt. */
function knoten(sid, name, o) {
  const a = o || {};
  const meta = {
    sid: sid, name: name, v: 4, bv: '1.1.0',
    instanz: a.instanz || INST_A,
    ts: a.ts != null ? a.ts : a.sv,
    count: a.count != null ? a.count : 1,
  };
  if (a.sv != null) meta.sv = a.sv;
  return { meta: meta, uebersicht: a.uebersicht || {}, geraete: a.geraete || {} };
}

/* Eine Kachel, wie tafel.uebersichtSatz sie baut (kurze Feldnamen). */
function kachel(o) {
  return Object.assign({ pid: '', n: 'Bello', a: 'hund', g: 22, hr: 96, sp: 97, et: 38,
    af: 14, sys: 112, dia: 64, map: 78, t: 37.8, rh: 'sinus', pri: 2, top: 'MAP grenzwertig',
    al: 0, dev: 1, ts: T0, altMs: 1000 }, o || {});
}

/* Ein frischer Speicher mit einer eigenen Kennung, die zu keinem Testsaal passt. */
function neu(o) {
  return new F.Fremdstore(Object.assign({
    log: stillesLog, eigeneSid: SID_EIGEN, eigeneInstanz: INST_EIGEN,
  }, o || {}));
}

function saalMit(liste, sid) { return liste.filter((s) => s.sid === sid)[0] || null; }

console.log('VetStation — Fremdstore (Gedaechtnis fuer fremde OP-Saele)\n');

/* ---------------- 1) Abhaengigkeiten: fremde Daten erreichen den eigenen Messweg nie ---------------- */
console.log('1) keine Abhaengigkeit auf registry, matching, cloud oder einen Adapter:');
{
  const quelle = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'fremdstore.js'), 'utf8');
  const code = quelle.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\n)[ \t]*\/\/[^\n]*/g, '$1');

  const module = [];
  const re = /require\(['"]([^'"]+)['"]\)/g;
  let m;
  while ((m = re.exec(quelle)) !== null) module.push(m[1]);
  ok('geladen wird ausschliesslich ./tafel', module.join(',') === './tafel', module.join(','));
  ok('kein require auf registry/matching/cloud/adapter im Quelltext',
    !/require\([^)]*(registry|matching|cloud|adapters|server|wsserver|model)/.test(code));

  /*
   * Die Gegenprobe zur Laufzeit ist die staerkere: ein eigener Prozess laedt NUR fremdstore.js und
   * zeigt, was dabei wirklich in den Modulspeicher gekommen ist. Ein indirekter Weg
   * (fremdstore -> irgendetwas -> registry) faellt hier auf, im Quelltext nicht.
   */
  const p = path.join(__dirname, '..', 'bridge', 'src', 'fremdstore.js').replace(/\\/g, '/');
  /*
   * Das Trennzeichen kommt aus String.fromCharCode(10) und NICHT als '\n' in der Zeichenkette:
   * ein '\n' waere hier schon in DIESER Datei ein echter Zeilenumbruch und damit im Kindprozess ein
   * unbeendetes Textliteral — der Kindprozess stuerbe mit einem Syntaxfehler, die Ausgabe waere
   * leer, und die Pruefung meldete "kein verbotenes Modul geladen", ohne dass ueberhaupt etwas
   * geladen wurde. Eine Pruefung, die bei einem kaputten Werkzeug gruen bleibt, ist keine.
   */
  const r = spawnSync(process.execPath, ['-e',
    "require('" + p + "'); console.log(Object.keys(require.cache).join(String.fromCharCode(10)));"],
    { encoding: 'utf8' });
  ok('der Kindprozess hat wirklich geladen (sonst prueft dieser Block nichts)',
    r.status === 0 && String(r.stdout || '').indexOf('fremdstore.js') >= 0,
    String(r.status) + ' ' + String(r.stderr || '').slice(0, 200));
  const geladen = String(r.stdout || '').split('\n').map((s) => s.trim()).filter(Boolean);
  const verboten = geladen.filter((f) => /(registry|matching|adapters[\\/]|cloud|server|wsserver|model)\.js$/i.test(f));
  ok('zur Laufzeit wird keines dieser Module geladen', verboten.length === 0, verboten.join(', '));
  ok('geladen sind wirklich nur fremdstore und tafel',
    geladen.filter((f) => /bridge/.test(f)).length === 2, geladen.filter((f) => /bridge/.test(f)).join(', '));

  ok('fremdstore.js fragt nie selbst die Uhr ab', !/Date\s*\.\s*now/.test(code));
  ok('fremdstore.js benutzt keinen Zufall', !/Math\s*\.\s*random/.test(code));
  ok('fremdstore.js erfindet keine eigenen Alterungsschwellen',
    code.indexOf('12000') < 0 && code.indexOf('43200000') < 0
    && /STUFE_LIVE_MS/.test(code) && /STUFE_WEG_MS/.test(code));
  ok('altersStufe ist DIESELBE Funktion wie in tafel.js, keine zweite Fassung',
    F.altersStufe === tafel.altersStufe);
}

/* ---------------- 2) Ohne uebergebene Uhr wird keine Dauer erfunden ---------------- */
console.log('\n2) ohne uebergebene Uhr erfindet keine Funktion eine Dauer:');
{
  const fsx = neu();
  fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } }), T0);
  const liste = fsx.saele(undefined);
  ok('der Saal bleibt sichtbar', liste.length === 1, JSON.stringify(liste.map((s) => s.sid)));
  ok('sein Alter ist unbekannt, nicht 0', liste[0].uebertragungMs === null && liste[0].stufe === 'unbekannt',
    String(liste[0].uebertragungMs));
  ok('auch die Kachel erfindet kein Alter', liste[0].patients[0].altMs === undefined,
    JSON.stringify(liste[0].patients[0]));
  ok('und der Speicher wird durch einen Aufruf ohne Uhr NICHT geleert',
    fsx.status().saele === 1, JSON.stringify(fsx.status().zaehler));
  ok('ersatzText ohne Zahl sagt "Alter unbekannt"', F.ersatzText(null) === F.TEXT_UNBEKANNT);
  ok('hinweisText fuer "unbekannt" sagt dasselbe', F.hinweisText('unbekannt', null) === F.TEXT_UNBEKANNT);
}

/* ---------------- 3) Alterung in drei Stufen, mit uebergebener Uhr ---------------- */
console.log('\n3) Alterung 12 s / 60 s / 12 h als Zustandswechsel bei uebergebener Uhr:');
{
  const fsx = neu();
  const setz = () => fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } }), T0);
  const stufeBei = (dt) => { setz(); return fsx.saele(T0 + dt)[0]; };

  ok('0 ms nach dem Schreiben: live', stufeBei(0).stufe === 'live');
  ok('11999 ms: noch live', stufeBei(11999).stufe === 'live');
  ok('12000 ms: Stufe wechselt auf "alt"', stufeBei(12000).stufe === 'alt');
  ok('und der Klartext lautet "keine neuen Daten (12s)"',
    stufeBei(12000).hinweis === 'keine neuen Daten (12s)', stufeBei(12000).hinweis);
  ok('59999 ms: weiter "alt"', stufeBei(59999).stufe === 'alt');
  ok('60000 ms: Stufe wechselt auf "offline"', stufeBei(60000).stufe === 'offline');
  ok('und der Klartext lautet "offline seit 1 min"',
    stufeBei(60000).hinweis === 'offline seit 1 min', stufeBei(60000).hinweis);
  ok('12 h minus 1 ms: immer noch offline, aber vorhanden',
    stufeBei(tafel.STUFE_WEG_MS - 1).stufe === 'offline');

  setz();
  const nach12h = fsx.saele(T0 + tafel.STUFE_WEG_MS);
  ok('12 h: der Saal faellt ERSATZLOS raus', nach12h.length === 0, JSON.stringify(nach12h));
  ok('und er ist wirklich aus dem Speicher, nicht nur ausgeblendet', fsx.status().saele === 0);
  ok('das Herausfallen wird gezaehlt', fsx.status().zaehler.gealtert === 1,
    JSON.stringify(fsx.status().zaehler));

  // Bis 12 s gelten die Zahlen, danach bleiben sie stehen — ersetzt werden sie erst ab 'offline'.
  setz();
  const alt = fsx.saele(T0 + 30000)[0];
  ok('zwischen 12 s und 60 s bleiben die Zahlen stehen', alt.patients[0].hr === 96 && alt.ersetzt === false);
  ok('das Kachelalter waechst mit der Uebertragung mit',
    alt.patients[0].altMs === 1000 + 30000, String(alt.patients[0].altMs));
}

/* ---------------- 4) Ab "offline" werden die Zahlen ERSETZT ---------------- */
console.log('\n4) ab "offline" werden die Zahlen ersetzt statt gezeigt:');
{
  const fsx = neu();
  fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({ pid: 'p1' }) } }), T0);
  const s = fsx.saele(T0 + 185000)[0];
  const p = s.patients[0];
  ok('der Saal ist offline', s.stufe === 'offline' && s.ersetzt === true);
  ok('an die Stelle der Zahlen tritt "Stand vor 3 min"', p.ersatz === 'Stand vor 3 min', p.ersatz);
  ok('kein Messwert steht mehr da',
    p.hr === undefined && p.sp === undefined && p.et === undefined && p.map === undefined
    && p.t === undefined && p.rh === undefined, JSON.stringify(p));
  ok('auch die abgeleitete Prioritaet und die Alarmzahl fallen weg',
    p.pri === undefined && p.al === undefined && p.top === undefined, JSON.stringify(p));
  ok('die Identitaet des Tiers bleibt stehen',
    p.pid === 'p1' && p.n === 'Bello' && p.a === 'hund' && p.g === 22, JSON.stringify(p));
  ok('und das Alter bleibt eine Zahl', p.altMs === 1000 + 185000, String(p.altMs));
  ok('der Saal traegt den Ersatztext auch selbst', s.ersatz === 'Stand vor 3 min');
}

/* ---------------- 5) Negatives Alter: nie 0, immer "Alter unbekannt" ---------------- */
console.log('\n5) negatives Alter (die Uhr des Nachbarn laeuft vor) ergibt nie 0:');
{
  const fsx = neu();
  fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0 + 120000, uebersicht: { k1: kachel({}) } }), T0);
  const s = fsx.saele(T0)[0];
  ok('der Saal bleibt sichtbar', !!s);
  ok('sein Alter ist null, nicht 0', s.uebertragungMs === null, String(s.uebertragungMs));
  ok('die Stufe heisst "unbekannt", nicht "live"', s.stufe === 'unbekannt');
  ok('der Klartext lautet "Alter unbekannt"', s.hinweis === F.TEXT_UNBEKANNT);
  ok('die Zahlen der Kachel bleiben stehen (ersetzt wird nur bei offline)', s.patients[0].hr === 96);
  ok('aber ihr Alter ist unbekannt statt 0', s.patients[0].altMs === undefined,
    JSON.stringify(s.patients[0]));
  ok('tafel.altersStufe stimmt zu', tafel.altersStufe(tafel.alterMs(T0 + 120000, T0)) === 'unbekannt');

  // Mehr als 12 h in der Zukunft ist kein Gangfehler mehr, sondern Unsinn.
  const fsy = neu();
  fsy.ausCloud(SID_B, knoten(SID_B, 'OP 2', { sv: T0 + tafel.UHR_TOLERANZ_MS + 1000 }), T0);
  ok('mehr als 12 h in der Zukunft faellt heraus', fsy.saele(T0).length === 0);
}

/* ---------------- 6) quellenwahl als reine Funktion ---------------- */
console.log('\n6) quellenwahl — LAN bevorzugt, aber mit Sicherungsschalter:');
{
  const grund = (o) => F.quellenwahl(Object.assign({ lanDa: true, cloudDa: true, lanStilleMs: 0, lanFehler: 0 }, o));
  ok('frischer LAN-Weg gewinnt', grund({}).quelle === 'lan');
  ok('drei Fehlversuche schalten auf Cloud', grund({ lanFehler: 3 }).quelle === 'cloud');
  ok('zwei Fehlversuche noch nicht', grund({ lanFehler: 2 }).quelle === 'lan');
  ok('und der Grund steht im Klartext', grund({ lanFehler: 3 }).grund === 'lan-fehlversuche');
  ok('genau 3 s Stille sind noch erlaubt', grund({ lanStilleMs: 3000 }).quelle === 'lan');
  ok('3001 ms Stille schalten auf Cloud', grund({ lanStilleMs: 3001 }).quelle === 'cloud');
  ok('mit dem Grund "lan-stille"', grund({ lanStilleMs: 3001 }).grund === 'lan-stille');
  ok('unbekannte Stille zaehlt wie Stille', grund({ lanStilleMs: null }).quelle === 'cloud');
  ok('Widerspruch schlaegt alles andere', grund({ widerspruch: true }).quelle === 'cloud');
  ok('und traegt den Grund "widerspruch"', grund({ widerspruch: true }).grund === 'widerspruch');
  ok('ohne Cloud bleibt selbst ein alter LAN-Weg die Quelle',
    F.quellenwahl({ lanDa: true, cloudDa: false, lanStilleMs: 99999, lanFehler: 9 }).quelle === 'lan');
  ok('ohne beides ist die Quelle "aus"',
    F.quellenwahl({ lanDa: false, cloudDa: false }).quelle === 'aus');
  ok('eine gesperrte LAN-Quelle erholt sich sichtbar',
    grund({ lanGesperrt: true }).grund === 'lan-erholt-sich');
  ok('die Schwellen sind einstellbar, nicht eingebaut',
    F.quellenwahl({ lanDa: true, cloudDa: true, lanStilleMs: 4000, lanFehler: 0, stilleMaxMs: 5000 }).quelle === 'lan');
  ok('die Werkeinstellung steht als Konstante bereit',
    F.LAN_FEHLER_MAX === 3 && F.LAN_STILLE_MS === 3000);
}

/* ---------------- 7) LAN-Ausfall nach 3 Fehlversuchen, am ganzen Speicher ---------------- */
console.log('\n7) LAN-Ausfall nach 3 Fehlversuchen — und die Rueckkehr:');
{
  const fsx = neu();
  const beide = (t) => {
    fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: t, uebersicht: { k1: kachel({ hr: 96 }) } }), t);
    fsx.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: t, uebersicht: { k1: kachel({ hr: 96 }) } }), t);
  };
  beide(T0);
  ok('zuerst gilt der LAN-Weg', fsx.saele(T0)[0].quelle === 'lan');

  fsx.lanFehler(SID_A, 'Verbindung abgelehnt');
  fsx.lanFehler(SID_A, 'Verbindung abgelehnt');
  ok('nach zwei Fehlversuchen gilt weiter LAN', fsx.saele(T0)[0].quelle === 'lan');
  fsx.lanFehler(SID_A, 'Verbindung abgelehnt');
  const nach3 = fsx.saele(T0)[0];
  ok('nach dem dritten Fehlversuch gilt die Cloud', nach3.quelle === 'cloud', nach3.grund);
  ok('und der Grund ist benannt', nach3.grund === 'lan-fehlversuche');
  ok('der Fehlergrund steht im Klartext im Zustand',
    fsx.status().quellen[0].lanFehlerGrund === 'Verbindung abgelehnt',
    JSON.stringify(fsx.status().quellen[0]));
  ok('der Sicherungsschalter ist als ausgeloest ausgewiesen', fsx.status().quellen[0].lanGesperrt === true);

  // Rueckkehr: EIN geglueckter Satz genuegt nicht, sonst flattert die Anzeige im Sekundentakt.
  fsx.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } }), T0);
  ok('ein einzelner geglueckter Satz holt den LAN-Weg NICHT zurueck', fsx.saele(T0)[0].quelle === 'cloud');
  ok('der Zaehler der Fehlversuche ist trotzdem zurueckgesetzt', fsx.status().quellen[0].lanFehler === 0);
  ok('und der Grund heisst jetzt "lan-erholt-sich"', fsx.saele(T0)[0].grund === 'lan-erholt-sich');
  fsx.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } }), T0);
  fsx.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } }), T0);
  ok('nach drei Saetzen in Folge gilt wieder LAN', fsx.saele(T0)[0].quelle === 'lan');

  // 3 s Stille wirken ohne jeden Fehlversuch.
  const fsy = neu();
  fsy.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0 }), T0);
  fsy.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0 }), T0);
  ok('bei 3000 ms Stille gilt noch LAN', fsy.saele(T0 + 3000)[0].quelle === 'lan');
  ok('bei 3001 ms Stille gilt die Cloud', fsy.saele(T0 + 3001)[0].quelle === 'cloud');
  ok('ein Fehler fuer eine unbekannte Kennung legt keinen Saal an',
    fsy.lanFehler(SID_C, 'egal') === false && fsy.status().saele === 1);
}

/* ---------------- 8) Widerspruch: die Cloud gewinnt IMMER ---------------- */
console.log('\n8) bei Widerspruch gewinnt die Cloud — LAN ueberholt nur die Laufzeit:');
{
  const bau = (lanKachel, cloudKachel, tCloud) => {
    const fsx = neu();
    fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: tCloud == null ? T0 : tCloud, uebersicht: { k1: kachel(cloudKachel) } }), T0);
    fsx.ausLan(SID_A, knoten(SID_A, 'OP 1', { uebersicht: { k1: kachel(lanKachel) } }), T0);
    return fsx.saele(T0)[0];
  };

  const gleich = bau({ hr: 96 }, { hr: 96 });
  ok('gleiche Werte: kein Widerspruch, LAN gilt', gleich.quelle === 'lan' && gleich.widerspruch === false);

  const knapp = bau({ hr: 96 }, { hr: 106 });
  ok('HF-Abweichung von genau 10 ist noch kein Widerspruch', knapp.widerspruch === false && knapp.quelle === 'lan');

  const hr = bau({ hr: 96 }, { hr: 107 });
  ok('HF-Abweichung von 11 ist ein Widerspruch', hr.widerspruch === true);
  ok('und die Quelle wechselt auf die Cloud', hr.quelle === 'cloud');
  ok('der Saal traegt das Feld "Quellen widersprechen sich"',
    hr.widerspruchText === 'Quellen widersprechen sich', String(hr.widerspruchText));
  ok('und die gezeigten Zahlen sind die der CLOUD', hr.patients[0].hr === 107, String(hr.patients[0].hr));
  ok('der Grund ist im Klartext genannt', hr.widerspruchGruende.length === 1 && /HF/.test(hr.widerspruchGruende[0]),
    JSON.stringify(hr.widerspruchGruende));

  ok('SpO2-Abweichung von 3 ist noch keiner', bau({ sp: 97 }, { sp: 100 }).widerspruch === false);
  ok('SpO2-Abweichung von 4 ist einer', bau({ sp: 97 }, { sp: 101 }).widerspruch === true);
  ok('EtCO2-Abweichung von 5 ist noch keiner', bau({ et: 38 }, { et: 43 }).widerspruch === false);
  ok('EtCO2-Abweichung von 6 ist einer', bau({ et: 38 }, { et: 44 }).widerspruch === true);

  // altMs wird als WIRKSAMES Alter verglichen (Kachelalter + Uebertragungsalter).
  const altOk = bau({ altMs: 1000 }, { altMs: 1000 }, T0 - 2000);
  ok('2 s Laufzeitunterschied allein sind kein Widerspruch', altOk.widerspruch === false,
    JSON.stringify(altOk.widerspruchGruende));
  const altBoese = bau({ altMs: 1000 }, { altMs: 9000 }, T0);
  ok('8 s Unterschied im wirksamen Alter sind einer', altBoese.widerspruch === true);
  ok('und auch dann gilt die Cloud', altBoese.quelle === 'cloud');

  // Ein Schluessel, den nur eine Seite fuehrt, ist ein Wettlauf, kein Widerspruch.
  const fsz = neu();
  fsz.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}), k2: kachel({}) } }), T0);
  fsz.ausLan(SID_A, knoten(SID_A, 'OP 1', { uebersicht: { k1: kachel({}) } }), T0);
  ok('ein Patient, den nur eine Seite kennt, ist kein Widerspruch', fsz.saele(T0)[0].widerspruch === false);
  ok('er wird aber als unvergleichbar gezaehlt',
    F.widerspruchAus({ kacheln: [{ k: 'k1', w: {} }], uebertragungMs: 0 },
      { kacheln: [{ k: 'k1', w: {} }, { k: 'k2', w: {} }], uebertragungMs: 0 }).unvergleichbar === 1);

  // Zwei vollstaendig disjunkte Listen sind kein Wettlauf mehr.
  const fsd = neu();
  fsd.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { kx: kachel({}) } }), T0);
  fsd.ausLan(SID_A, knoten(SID_A, 'OP 1', { uebersicht: { ky: kachel({}) } }), T0);
  const disj = fsd.saele(T0)[0];
  ok('zwei vollstaendig disjunkte Patientenlisten sind ein Widerspruch', disj.widerspruch === true);
  ok('und die Cloud gewinnt auch hier', disj.quelle === 'cloud' && disj.patients[0].key === 'kx');

  ok('ohne Cloud-Sicht gibt es keinen Widerspruch',
    F.widerspruchAus({ kacheln: [{ k: 'k1', w: { hr: 10 } }], uebertragungMs: 0 }, null).widerspruch === false);
}

/* ---------------- 9) Verlegung: ausschliesslich ueber gleiche, NICHT LEERE pid ---------------- */
console.log('\n9) Verlegung nur ueber gleiche, nicht leere pid:');
{
  const fsx = neu();
  // Zwei 22-kg-Hunde: derselbe patientKey in beiden Saelen, aber verschiedene Patienten-IDs.
  fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { sw_hund_22: kachel({ pid: '12345', n: 'Bello' }) } }), T0);
  fsx.ausCloud(SID_B, knoten(SID_B, 'OP 2', { instanz: INST_B, sv: T0, uebersicht: { sw_hund_22: kachel({ pid: '67890', n: 'Rex' }) } }), T0);
  ok('gleicher patientKey, verschiedene pid: KEINE Verlegung', fsx.verlegungen(T0).length === 0,
    JSON.stringify(fsx.verlegungen(T0)));

  // Derselbe Patient, in zwei Saelen gefuehrt.
  fsx.ausCloud(SID_B, knoten(SID_B, 'OP 2', { instanz: INST_B, sv: T0, uebersicht: { sw_hund_22: kachel({ pid: '12345', n: 'Bello' }) } }), T0);
  const v = fsx.verlegungen(T0);
  ok('gleiche, nicht leere pid in zwei Saelen: eine Verlegung', v.length === 1, JSON.stringify(v));
  ok('sie nennt beide Stationskennungen', v[0].saele.join(',') === SID_A + ',' + SID_B, v[0].saele.join(','));
  ok('und die pid unveraendert', v[0].pid === '12345');
  const liste = fsx.saele(T0);
  ok('es bleiben ZWEI Eintraege, nichts wird verschmolzen',
    liste.length === 2 && liste[0].patients.length === 1 && liste[1].patients.length === 1);
  ok('die Kachel in OP 1 traegt die Marke "auch in OP 2"',
    (saalMit(liste, SID_A).patients[0].auch || []).join(',') === 'OP 2',
    JSON.stringify(saalMit(liste, SID_A).patients[0].auch));
  ok('und die Kachel in OP 2 die Marke "auch in OP 1"',
    (saalMit(liste, SID_B).patients[0].auch || []).join(',') === 'OP 1');

  // Leere pid darf NIE zwei Patienten verschmelzen.
  const leer = [
    { sid: SID_A, name: 'OP 1', patients: [{ key: 'sw_hund_22', pid: '' }] },
    { sid: SID_B, name: 'OP 2', patients: [{ key: 'sw_hund_22', pid: '' }] },
  ];
  ok('zwei leere pid verschmelzen nicht', F.verlegungenAus(leer).length === 0);
  const fehlt = [
    { sid: SID_A, name: 'OP 1', patients: [{ key: 'sw_hund_22' }] },
    { sid: SID_B, name: 'OP 2', patients: [{ key: 'sw_hund_22' }] },
  ];
  ok('eine fehlende pid ebenso wenig', F.verlegungenAus(fehlt).length === 0);
  const blank = [
    { sid: SID_A, name: 'OP 1', patients: [{ pid: '   ' }] },
    { sid: SID_B, name: 'OP 2', patients: [{ pid: '  ' }] },
  ];
  ok('und eine pid aus Leerzeichen auch nicht', F.verlegungenAus(blank).length === 0);
  const gross = [
    { sid: SID_A, name: 'OP 1', patients: [{ pid: 'ab12' }] },
    { sid: SID_B, name: 'OP 2', patients: [{ pid: 'AB12' }] },
  ];
  ok('verschiedene Schreibweisen sind zwei Patienten', F.verlegungenAus(gross).length === 0);
  const zweimal = [{ sid: SID_A, name: 'OP 1', patients: [{ pid: 'x1' }, { pid: 'x1' }] }];
  ok('dieselbe pid zweimal im SELBEN Saal ist keine Verlegung', F.verlegungenAus(zweimal).length === 0);
  const drei = [
    { sid: SID_A, name: 'OP 1', patients: [{ pid: 'x1' }] },
    { sid: SID_B, name: 'OP 2', patients: [{ pid: 'x1' }] },
    { sid: SID_C, name: 'OP 3', patients: [{ pid: 'x1' }] },
  ];
  ok('drei Saele mit derselben pid ergeben eine Verlegung mit drei Kennungen',
    F.verlegungenAus(drei).length === 1 && F.verlegungenAus(drei)[0].saele.length === 3);
}

/* ---------------- 10) Doppelempfang ueber die vollstaendige Geraeteliste (N13) ---------------- */
console.log('\n10) Doppelempfang ueber die Geraeteliste, nicht ueber dv:');
{
  const geraet = (o) => Object.assign({ model: 'LifeVet', role: 'monitor', status: 'active',
    ip: '192.168.0.51', port: 3502, transport: 'tcp', taktMs: 1000, werteAnzahl: 7, altMs: 500 }, o || {});
  const fsx = neu();
  fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, geraete: { lifevet1: geraet({}) } }), T0);
  fsx.ausCloud(SID_B, knoten(SID_B, 'OP 2', { instanz: INST_B, sv: T0, geraete: { lifevet1: geraet({}) } }), T0);
  const d = F.doppelempfang(fsx.saele(T0));
  ok('dasselbe Geraet in zwei Saelen wird erkannt', d.length === 1, JSON.stringify(d));
  ok('die Meldung nennt beide OP-Saele', /OP 1/.test(d[0].text) && /OP 2/.test(d[0].text), d[0].text);
  ok('und sie steht im Klartext im Rundruf',
    fsx.rundruf(T0).hinweise.filter((h) => /sendet gleichzeitig/.test(h)).length === 1,
    JSON.stringify(fsx.rundruf(T0).hinweise));

  const fsy = neu();
  fsy.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, geraete: { lifevet1: geraet({}) } }), T0);
  fsy.ausCloud(SID_B, knoten(SID_B, 'OP 2', { instanz: INST_B, sv: T0, geraete: { lifevet1: geraet({ status: 'offline' }) } }), T0);
  ok('ein OFFLINE gefuehrtes Geraet zaehlt nicht mit', F.doppelempfang(fsy.saele(T0)).length === 0);

  const fsz = neu();
  fsz.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, geraete: { lifevet1: geraet({}) } }), T0);
  fsz.ausCloud(SID_B, knoten(SID_B, 'OP 2', { instanz: INST_B, sv: T0, geraete: { lifevet1: geraet({ status: 'standby' }) } }), T0);
  ok('ein umgestelltes Geraet im Standby ebenso wenig', F.doppelempfang(fsz.saele(T0)).length === 0);

  ok('empfaengt() entscheidet ohne status ueber das Alter',
    F.empfaengt({ altMs: 500 }) === true && F.empfaengt({ altMs: tafel.STUFE_LIVE_MS }) === false);
  ok('ein Geraet in nur EINEM Saal ist kein Doppelempfang',
    F.doppelempfang([{ sid: SID_A, name: 'OP 1', geraete: [{ id: 'x', status: 'active' }] }]).length === 0);
  ok('dasselbe Geraet zweimal im selben Saal auch nicht',
    F.doppelempfang([{ sid: SID_A, name: 'OP 1', geraete: [{ id: 'x', status: 'active' }, { id: 'x', status: 'active' }] }]).length === 0);

  // dv wird ausdruecklich NICHT weitergereicht, damit niemand die Erkennung darauf baut.
  const mitDv = neu();
  mitDv.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({ dv: ['lifevet@192.168.0.51'] }) } }), T0);
  ok('das Kachelfeld dv erreicht den Rundruf nicht',
    mitDv.saele(T0)[0].patients[0].dv === undefined, JSON.stringify(mitDv.saele(T0)[0].patients[0]));
}

/* ---------------- 11) Harte Deckel, sichtbar statt still (N17) ---------------- */
console.log('\n11) Deckel bei 9 Saelen und 13 Kacheln — als Zahl UND als Klartext:');
{
  const fsx = neu();
  for (let i = 1; i <= 9; i++) {
    const sid = 'st' + String(i).padStart(12, '0');
    fsx.ausCloud(sid, knoten(sid, 'Saal ' + String(i).padStart(2, '0'),
      { instanz: String(i).padStart(16, '0'), sv: T0 }), T0);
  }
  const r = fsx.rundruf(T0);
  ok('von neun Saelen werden acht gefuehrt', r.saele.length === 8, String(r.saele.length));
  ok('der Deckel steht als ZAHL im Ergebnis', r.mehr === 1, String(r.mehr));
  ok('und als Klartext nach N17',
    r.hinweise.indexOf('1 weitere OP-Saele werden nicht angezeigt — Deckel erreicht') >= 0,
    JSON.stringify(r.hinweise));
  ok('gekappt wird NACH dem Sortieren — der letzte Name faellt weg',
    r.saele[0].name === 'Saal 01' && r.saele[7].name === 'Saal 08', r.saele.map((s) => s.name).join(','));
  ok('alle neun bleiben im Speicher, nur die Anzeige ist gedeckelt', fsx.status().saele === 9);

  const kacheln = {};
  for (let i = 1; i <= 13; i++) kacheln['k' + String(i).padStart(2, '0')] = kachel({ pid: 'p' + i });
  const fsy = neu();
  fsy.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: kacheln }), T0);
  const s = fsy.saele(T0)[0];
  ok('von 13 Kacheln werden 12 gefuehrt', s.patients.length === 12, String(s.patients.length));
  ok('der Kacheldeckel steht als Zahl im Saal', s.mehr === 1, String(s.mehr));
  ok('und als Klartext im Rundruf',
    fsy.rundruf(T0).hinweise.indexOf('OP 1: 1 weitere Patienten werden nicht angezeigt — Deckel erreicht') >= 0,
    JSON.stringify(fsy.rundruf(T0).hinweise));
  ok('gekappt wird stabil nach Schluessel', s.patients[0].key === 'k01' && s.patients[11].key === 'k12',
    s.patients.map((p) => p.key).join(','));

  // Der Deckel der Vorstufe (tafelabo hat schon gekappt) darf auf dem Weg nicht verlorengehen.
  const fsz = neu();
  fsz.ausCloud(SID_A, {
    sid: SID_A, name: 'OP 1', meta: { sid: SID_A, name: 'OP 1', instanz: INST_A, sv: T0 },
    kacheln: [{ schluessel: 'k1', werte: kachel({}) }], weitereKacheln: 5,
    geraete: [], weitereGeraete: 2,
  }, T0);
  const vs = fsz.saele(T0)[0];
  ok('der Satz aus tafelabo.saele() wird angenommen', vs && vs.patients.length === 1);
  ok('und sein eigener Deckel wird mitgezaehlt', vs.mehr === 5, String(vs.mehr));
  ok('dasselbe fuer die Geraetezeilen', vs.mehrGeraete === 2, String(vs.mehrGeraete));

  ok('kappeSaele meldet ohne Ueberhang keinen Hinweis',
    F.kappeSaele([{ sid: SID_A }], 8).mehr === 0 && F.kappeSaele([{ sid: SID_A }], 8).hinweis === null);
  ok('kappeSaele nennt die verdraengten Saele namentlich',
    F.kappeSaele([{ sid: SID_A, name: 'a' }, { sid: SID_B, name: 'b' }], 1).weitereListe[0].name === 'b');
}

/* ---------------- 12) Die eigene Station wird nie als Nachbarsaal gefuehrt ---------------- */
console.log('\n12) eigene sid und eigene instanz werden gefiltert:');
{
  const fsx = neu();
  ok('die eigene sid wird abgewiesen',
    fsx.ausCloud(SID_EIGEN, knoten(SID_EIGEN, 'Ich selbst', { sv: T0 }), T0) === false);
  ok('auch ueber den LAN-Weg',
    fsx.ausLan(SID_EIGEN, knoten(SID_EIGEN, 'Ich selbst', { sv: T0 }), T0) === false);
  ok('eine fremde sid mit der EIGENEN Instanz ebenfalls (Rueckweg auf den eigenen PC)',
    fsx.ausCloud(SID_A, knoten(SID_A, 'Angeblich OP 1', { instanz: INST_EIGEN, sv: T0 }), T0) === false);
  ok('beides wird gezaehlt', fsx.status().verworfen.eigen === 3, JSON.stringify(fsx.status().verworfen));
  ok('und der Speicher bleibt leer', fsx.saele(T0).length === 0);

  // Die eigene Kennung steht beim ersten Takt oft noch nicht fest.
  let meine = null;
  const fsy = new F.Fremdstore({ log: stillesLog, eigeneSid: () => meine });
  ok('vor dem Feststehen der Kennung wird der Saal aufgenommen',
    fsy.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0 }), T0) === true);
  meine = SID_A;
  ok('sobald die Kennung feststeht, faellt er heraus', fsy.saele(T0).length === 0);
  ok('und ist auch aus dem Speicher verschwunden', fsy.status().saele === 0);

  ok('eine unbrauchbare Stationskennung wird abgewiesen',
    fsx.ausCloud('../x', knoten('../x', 'boese', { sv: T0 }), T0) === false
    && fsx.status().verworfen.sid === 1);
  ok('ein leerer Satz ebenso', fsx.ausCloud(SID_B, null, T0) === false && fsx.status().verworfen.leer === 1);
}

/* ---------------- 13) Die Schnittstelle, so wie sie verdrahtet wird ---------------- */
console.log('\n13) Schnittstelle: saele / rundruf / verlegungen / status / entferne:');
{
  const fsx = neu();
  fsx.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0 - 500, uebersicht: { k1: kachel({ pid: 'p1' }) } }), T0);
  const s = fsx.saele(T0)[0];
  ['sid', 'name', 'quelle', 'uebertragungMs', 'meta', 'patients', 'geraete'].forEach((f) => {
    ok('der Saalsatz traegt das Feld ' + f, Object.prototype.hasOwnProperty.call(s, f));
  });
  ok('uebertragungMs ist die Dauer seit dem Schreiben', s.uebertragungMs === 500, String(s.uebertragungMs));
  ok('die Quelle heisst "cloud"', s.quelle === 'cloud');

  const r = fsx.rundruf(T0);
  ok('rundruf traegt ts, saele, mehr und hinweise',
    r.ts === T0 && Array.isArray(r.saele) && typeof r.mehr === 'number' && Array.isArray(r.hinweise),
    JSON.stringify(Object.keys(r)));

  const p = s.patients[0];
  ['key', 'pid', 'n', 'a', 'g', 'hr', 'sp', 'et', 'af', 'sys', 'dia', 'map', 't', 'rh', 'pri', 'top', 'al', 'altMs']
    .forEach((f) => { ok('der Rundruf-Satz je Patient traegt ' + f, p[f] !== undefined, JSON.stringify(p)); });

  const st = fsx.status();
  ok('status nennt Saalzahl und Deckel', st.saele === 1 && st.saeleMax === 8 && st.kachelnMax === 12);
  ok('status nennt je Saal die zuletzt gewaehlte Quelle', st.quellen[0].quelle === 'cloud');
  ok('status rechnet KEIN Alter (sie bekommt keine Uhr)',
    JSON.stringify(st).indexOf('uebertragungMs') < 0, JSON.stringify(st.quellen[0]));
  ok('entferne(sid) raeumt den Saal weg', fsx.entferne(SID_A) === true && fsx.status().saele === 0);
  ok('und ein zweites Mal entfernen meldet false', fsx.entferne(SID_A) === false);
}

/* ---------------- 14) Vertraege gegen tafel.js und tafelabo.js ---------------- */
console.log('\n14) Vertraege gegen die Nachbardateien — damit nichts auseinanderlaeuft:');
{
  /*
   * kopfSatz() nennt jedes Feld einzeln. Das ist die sichere Bauform, hat aber eine Schwachstelle:
   * ein neues Feld in tafel.tafelSatz() kaeme hier nie an. Dieser Vertrag schliesst sie.
   */
  const kopf = tafel.tafelSatz({
    sid: SID_A, name: 'OP 1', v: 4, bv: '1.1.0', instanz: INST_A, jetzt: T0,
    sv: { '.sv': 'timestamp' }, taktMs: 200, kurven: true, sq: 12, dop: true, aus: T0,
    uebersicht: { k1: kachel({}) }, geraete: {},
  });
  const durch = F.kopfSatz(kopf);
  const fehlend = Object.keys(kopf).filter((k) => k !== 'sv' && durch[k] === undefined);
  ok('jedes Feld aus tafel.tafelSatz() ueberlebt kopfSatz()', fehlend.length === 0, fehlend.join(','));
  ok('der Serverplatzhalter sv wird NICHT durchgereicht', durch.sv === undefined, JSON.stringify(durch.sv));
  ok('ein numerisches sv dagegen schon', F.kopfSatz({ sv: T0 }).sv === T0);

  // Dieselbe Sortierregel wie tafelabo.js — nachgerechnet statt behauptet.
  const roh = [
    { sid: SID_B, name: 'OP 2' }, { sid: SID_A, name: 'OP 1' },
    { sid: SID_C, name: 'OP 1' }, { sid: 'stffffffffffff', name: null },
  ];
  const meine = F.sortiereSaele(roh).map((s) => s.sid).join(',');
  const seine = tafelabo.sortiereSaele(roh.slice()).map((s) => s.sid).join(',');
  ok('sortiereSaele ordnet wie tafelabo.sortiereSaele', meine === seine, meine + ' vs ' + seine);
  ok('und laesst die uebergebene Liste unveraendert', roh[0].sid === SID_B);

  // Die Rohform des Datenbankknotens und die fertige Form aus tafelabo ergeben dasselbe.
  const rohSatz = knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } });
  const aboSatz = {
    sid: SID_A, name: 'OP 1', meta: rohSatz.meta,
    kacheln: [{ schluessel: 'k1', werte: kachel({}) }], weitereKacheln: 0,
    geraete: [], weitereGeraete: 0,
  };
  const a1 = neu(); a1.ausCloud(SID_A, rohSatz, T0);
  const a2 = neu(); a2.ausCloud(SID_A, aboSatz, T0);
  ok('beide Lieferformen ergeben denselben Saalsatz',
    JSON.stringify(a1.saele(T0)) === JSON.stringify(a2.saele(T0)));

  // Zwei Rohschluessel, die nach der Kappung gleich heissen: es gewinnt immer derselbe.
  const p1 = F.paare({ 'sw/hund': { hr: 1 }, 'sw:hund': { hr: 2 } });
  ok('kollidierende Schluessel werden gefaltet, nicht vertauscht',
    p1.liste.length === 1 && p1.liste[0].k === 'sw_hund' && p1.liste[0].w.hr === 1 && p1.doppelt === 1,
    JSON.stringify(p1));
  ok('mehr als KINDER_MAX Kinder werden gezaehlt, nicht behalten',
    (function () {
      const o = {};
      for (let i = 0; i < F.KINDER_MAX + 5; i++) o['k' + String(i).padStart(4, '0')] = {};
      const p = F.paare(o);
      return p.liste.length === F.KINDER_MAX && p.mehr === 5;
    })());

  ok('Textfelder werden gekuerzt und von Markup befreit',
    F.patientSatz('k1', { n: '<b>Bello</b>' }, 0, false).n === 'bBello/b',
    F.patientSatz('k1', { n: '<b>Bello</b>' }, 0, false).n);
  ok('geraeteZeile benutzt die Feldnamen aus tafel.geraeteSatz',
    (function () {
      const z = F.geraeteZeile('d1', { model: 'X', role: 'monitor', status: 'active', ip: '10.0.0.1',
        port: 3502, transport: 'tcp', taktMs: 1000, werteAnzahl: 7, patientKey: 'sw_hund_22', altMs: 500 }, 250);
      return z.id === 'd1' && z.model === 'X' && z.role === 'monitor' && z.status === 'active'
        && z.ip === '10.0.0.1' && z.port === 3502 && z.transport === 'tcp' && z.taktMs === 1000
        && z.werteAnzahl === 7 && z.patientKey === 'sw_hund_22' && z.altMs === 750;
    })());
}

/* ============================================================================
 * 15) ZWEI SCHWERE BEFUNDE DER GEGENPRUEFUNG (31.07.2026) — beide waren gruen
 *     durch alle 179 Pruefungen dieser Datei gelaufen.
 * ========================================================================== */
{
  console.log('\n15) Was die Gegenpruefung gefunden hat');

  /*
   * (1) EINE STEHENGEBLIEBENE CLOUD DARF DEN LEBENDEN LAN-WEG NICHT VERDRAENGEN.
   *
   * Der Fall ist der Normalfall eines Internetausfalls — also genau der, fuer den Stufe 2 gebaut
   * ist: die letzte Cloud-Momentaufnahme friert ein, der LAN-Weg liefert weiter live. Vorher war
   * der Altersunterschied allein schon ein "Widerspruch", und "bei Widerspruch gewinnt die Cloud"
   * schaltete ohne Ausnahme auf die eingefrorene Fassung. Der Nachbarsaal erschien als
   * "offline seit X min" mit ersetzten Zahlen, obwohl live gemessen wurde.
   */
  const fs1 = new F.Fremdstore({ log: stillesLog, eigeneSid: SID_EIGEN, eigeneInstanz: INST_EIGEN });
  fs1.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0 - 300000, uebersicht: { k1: kachel({ hr: 96 }) } }), T0 - 300000);
  fs1.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({ hr: 96 }) } }), T0);
  const s1 = fs1.saele(T0)[0];
  ok('Internet weg, LAN lebt: die Quelle bleibt LAN', s1 && s1.quelle === 'lan',
    s1 ? s1.quelle + ' / ' + (s1.widerspruchGruende || []).join('; ') : 'kein Saal');
  ok('und ein blosser Altersunterschied gilt nicht als Widerspruch', s1 && s1.widerspruch === false,
    s1 ? JSON.stringify(s1.widerspruchGruende) : '');
  ok('der Saal steht damit als live da, nicht als offline', s1 && s1.stufe === 'live', s1 ? s1.stufe : '');
  ok('und seine Zahlen bleiben stehen (kein "Stand vor X min")',
    s1 && s1.patients[0] && s1.patients[0].hr === 96 && !s1.patients[0].ersetzt,
    s1 ? JSON.stringify(s1.patients[0]) : '');

  /* Die Gegenprobe MUSS weiterhin greifen: abweichende MESSWERTE bei zwei frischen Quellen sind
   * sehr wohl ein Widerspruch, und dann gewinnt die Cloud. Ohne diese Pruefung waere die
   * Reparatur oben eine Abschaffung der Regel. */
  const fs2 = new F.Fremdstore({ log: stillesLog, eigeneSid: SID_EIGEN, eigeneInstanz: INST_EIGEN });
  fs2.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({ hr: 60 }) } }), T0);
  fs2.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({ hr: 150 }) } }), T0);
  const s2 = fs2.saele(T0)[0];
  ok('zwei FRISCHE Quellen mit verschiedener HF sind weiterhin ein Widerspruch',
    s2 && s2.widerspruch === true, s2 ? JSON.stringify(s2.widerspruchGruende) : '');
  ok('und dann gewinnt die Cloud', s2 && s2.quelle === 'cloud', s2 ? s2.quelle : '');
  ok('die angezeigte HF ist die der Cloud', s2 && s2.patients[0] && s2.patients[0].hr === 60,
    s2 ? String(s2.patients[0] && s2.patients[0].hr) : '');

  /*
   * (2) DIE STUFE 'weg' MUSS ERSETZEN. Sie ist erreichbar, ohne dass der Saal herausfaellt:
   * _istWeg verwirft nur, wenn das JUENGSTE Quellenalter ueber 12 h liegt, die Stufe rechnet aus
   * der GEWAEHLTEN Quelle. Cloud 13 h alt + LAN frisch = Saal bleibt, Stufe 'weg'.
   */
  ok('die Stufe "weg" bekommt einen Klartextsatz', typeof F.hinweisText('weg', 13 * 3600000) === 'string'
    && F.hinweisText('weg', 13 * 3600000).length > 0, String(F.hinweisText('weg', 13 * 3600000)));
  const wegSatz = F.patientSatz('k1', kachel({}), 13 * 3600000, true);
  ok('in der Stufe "weg" werden die Messwerte ERSETZT statt gezeigt',
    wegSatz.hr === undefined && wegSatz.ersetzt === true && typeof wegSatz.ersatz === 'string',
    JSON.stringify(wegSatz));
  ok('die Identitaet des Tiers bleibt dabei stehen',
    wegSatz.n === 'Bello' && wegSatz.a === 'hund' && wegSatz.g === 22, JSON.stringify(wegSatz));
  /* Die Entscheidung selbst, an der Quelle: _saalSatz muss 'weg' genauso behandeln wie 'offline'. */
  const quelle = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'fremdstore.js'), 'utf8');
  ok('_saalSatz ersetzt bei "offline" UND bei "weg"',
    /const ersetzt = stufe === 'offline' \|\| stufe === 'weg';/.test(quelle));

  /*
   * (3) EIN SAAL MIT PATIENTEN DARF NICHT ALS LEER ERSCHEINEN. Fuehrte der LAN-Weg null Kacheln
   * (neu gestarteter Nachbar, abgeschnittene Antwort), gewann er die Quellenwahl kommentarlos.
   */
  const fs3 = new F.Fremdstore({ log: stillesLog, eigeneSid: SID_EIGEN, eigeneInstanz: INST_EIGEN });
  fs3.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, count: 2,
    uebersicht: { k1: kachel({ pid: 'p1' }), k2: kachel({ pid: 'p2' }) } }), T0);
  fs3.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0, count: 0, uebersicht: {} }), T0);
  const s3 = fs3.saele(T0)[0];
  ok('eine LEERE LAN-Liste gegen eine gefuellte Cloud ist ein Widerspruch',
    s3 && s3.widerspruch === true, s3 ? JSON.stringify(s3.widerspruchGruende) : 'kein Saal');
  ok('und der Saal zeigt deshalb die Patienten der Cloud, nicht "leer"',
    s3 && s3.patients.length === 2, s3 ? String(s3.patients.length) : '');

  /*
   * (4) DIE ERHOLUNG DES LAN-WEGS IST "IN FOLGE". Eine wacklige Leitung, die abwechselnd liefert
   * und scheitert, darf die drei Schritte nicht einsammeln — sonst flattert die Quellenangabe.
   */
  const fs4 = new F.Fremdstore({ log: stillesLog, eigeneSid: SID_EIGEN, eigeneInstanz: INST_EIGEN });
  const satzL = () => fs4.ausLan(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } }), T0);
  fs4.ausCloud(SID_A, knoten(SID_A, 'OP 1', { sv: T0, uebersicht: { k1: kachel({}) } }), T0);
  satzL();
  for (let i = 0; i < F.LAN_FEHLER_MAX; i++) fs4.lanFehler(SID_A, 'Zeitablauf');
  ok('nach genug Fehlversuchen liest der Saal ueber die Cloud',
    fs4.saele(T0)[0].quelle === 'cloud', fs4.saele(T0)[0].quelle);
  for (let i = 0; i < F.LAN_ERHOLUNG_ANZAHL - 1; i++) { satzL(); fs4.lanFehler(SID_A, 'Zeitablauf'); }
  satzL();
  ok('abwechselnd Satz und Fehlversuch sammelt KEINE Erholung ein',
    fs4.saele(T0)[0].quelle === 'cloud', fs4.saele(T0)[0].quelle);
  for (let i = 0; i < F.LAN_ERHOLUNG_ANZAHL; i++) satzL();
  ok('erst LAN_ERHOLUNG_ANZAHL Saetze IN FOLGE schalten zurueck auf LAN',
    fs4.saele(T0)[0].quelle === 'lan', fs4.saele(T0)[0].quelle);
}

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
