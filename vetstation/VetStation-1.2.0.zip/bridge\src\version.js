'use strict';
/*
 * version.js — EINE Quelle der Wahrheit fuer die Versionsnummer.
 *
 * WARUM (Befund 2.4, 21.07.2026): /api/version meldete hartnaeckig 0.1.0, weil die Bridge
 * bridge/package.json einlas statt der Wurzel-package.json. In updater/version.json stand eine
 * DRITTE Nummer. Folge: nach einem Update war nicht feststellbar, ob es angekommen ist — und die
 * Update-Pruefung verglich gegen die falsche Zahl.
 *
 * Ab jetzt gilt ausschliesslich die Wurzel-package.json. bridge/package.json und
 * updater/version.json muessen dazu passen; tools/version-test.js erzwingt das.
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..', '..');

function lies(rel) {
  try { return JSON.parse(fs.readFileSync(path.join(ROOT, rel), 'utf8')); } catch (_) { return null; }
}

// DIE Version. Alles andere hat sich danach zu richten.
function appVersion() {
  const pkg = lies('package.json');
  return (pkg && pkg.version) || '0.0.0';
}

// Meldet Abweichungen zwischen den drei Stellen, an denen eine Versionsnummer steht.
function pruefe() {
  const app = appVersion();
  const bridge = lies('bridge/package.json');
  const upd = lies('updater/version.json');
  const abweichungen = [];
  if (bridge && bridge.version !== app) abweichungen.push({ datei: 'bridge/package.json', wert: bridge.version });
  if (upd && upd.app !== app) abweichungen.push({ datei: 'updater/version.json', wert: upd.app });
  return { version: app, stimmig: abweichungen.length === 0, abweichungen: abweichungen };
}

module.exports = { appVersion, pruefe, ROOT };
