'use strict';
/*
 * verbindungsberater.js — WAS muss ich tun, damit GENAU DIESES Geraet Werte liefert?
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 01.08.2026, woertlich):
 * "Wenn das automatisch das oder andere Geraet sich nicht verbindet, muss das App Empfehlungen und
 *  Einstellungen von Geraet geben, damit das Benutzer Netzwerk und alles einstellen kann, damit das
 *  App die Daten von ein oder andere Geraet lesen kann."
 *
 * ABGRENZUNG ZU diagnose.js — die beiden sind bewusst getrennt:
 *   diagnose.js  beantwortet "stimmt an diesem PC und in diesem Netz etwas nicht?"  (geraeteblind)
 *   diese Datei  beantwortet "was ist an DIESEM Modell einzustellen?"               (modellbezogen)
 * Zusammengelegt waeren beide unbrauchbar: die Netzdiagnose gilt fuer alle Geraete gleichzeitig,
 * die Anleitung immer nur fuer eines. Der Admin-Bereich zeigt beides untereinander.
 *
 * DIE REGEL, DIE HIER AM MEISTEN WERT IST: der Berater sagt auch, wenn es NICHT GEHT.
 * Am Veta 5 Plus wurden ueber Tage Menues durchsucht, Ports getauscht und Adressen geaendert — das
 * Geraet hat schlicht keinen offenen Datenausgang. Eine Anleitung, die so tut, als muesste man nur
 * lange genug suchen, ist schaedlicher als ein klares "dieses Modell gibt nichts heraus; hier ist
 * der Weg, der stattdessen funktioniert".
 *
 * PURE FUNKTION (kein Netz, keine Dateien, keine Uhr) -> vollstaendig testbar:
 * tools/verbindungsberater-test.js
 */

const katalog = require('./geraetekatalog');

/* Schwere wie in diagnose.js, damit die Oberflaeche beides gleich einfaerben kann:
 * 3 = so kommt sicher nichts an · 2 = wahrscheinliche Ursache · 1 = Hinweis */
function befund(code, schwere, titel, warum, tun) {
  return { code: code, schwere: schwere, titel: titel, warum: warum, tun: tun || [] };
}

/* ------------------------------------------------------------------ *
 * 1) Die Anleitung: was ist am Geraet einzustellen?
 * ------------------------------------------------------------------ */

/*
 * anleitung(geraetId, wegId, lage) -> { geraet, weg, schritte[], hinweise[], machbar }
 *
 * Die Schritte kommen aus dem Katalog und werden hier mit den ECHTEN Zahlen dieses PCs gefuellt.
 * Genau das ist der Unterschied zu einer Anleitung im Handbuch: dort steht "PC-Adresse eintragen",
 * hier steht die Adresse.
 *
 * lage = { pcIp, pcIps[], router, geraetIp, lauschPorts[] }
 */
function anleitung(geraetId, wegId, lage) {
  const l = lage || {};
  const g = katalog.nachId(geraetId);
  if (!g) return { fehler: 'Dieses Modell steht nicht im Katalog.', machbar: false, schritte: [], hinweise: [] };

  const wege = g.wege || [];
  const w = (wegId ? wege.filter((x) => x.id === wegId)[0] : null) || wege[0];
  if (!w) return { fehler: 'Fuer dieses Modell ist kein Anbindungsweg hinterlegt.', machbar: false, schritte: [], hinweise: [] };

  const pcIp = l.pcIp || (l.pcIps || [])[0] || null;

  /* Platzhalter fuellen. Bewusst nur zwei: mehr Automatik in einem Anleitungstext heisst, dass
   * niemand mehr sieht, was dort eigentlich steht. */
  const fuellen = (t) => String(t)
    .replace(/\bdie PC-Adresse\b/g, pcIp ? 'die PC-Adresse ' + pcIp : 'die PC-Adresse (steht im Reiter „Netzwerk & Geräte“)')
    .replace(/<IP des Veta>/g, l.geraetIp || '<IP des Geraets>');

  const schritte = (w.schritte || []).map((t, i) => ({ nr: i + 1, text: fuellen(t) }));
  const hinweise = [];

  /* Der Weg ist nur dann wirklich machbar, wenn die Station auf seinem Port ueberhaupt zuhoert
   * (bei einem Geraet, das VON SICH AUS sendet). Fehlt der Port, ist die schoenste Anleitung
   * wirkungslos — und zwar LAUTLOS, weil nie ein Byte ankommt. Genau dieser Fall ist am
   * 31.07.2026 mit Port 5510 passiert. */
  let machbar = true;
  if ((w.richtung === 'geraet_sendet' || w.richtung === 'beides') && w.port) {
    const lausch = (l.lauschPorts || []).map(Number);
    if (lausch.length && lausch.indexOf(Number(w.port)) < 0) {
      machbar = false;
      hinweise.push('Die Station hoert derzeit NICHT auf Port ' + w.port + '. Solange das so ist, kann das ' +
        'Geraet senden, ohne dass jemand zuhoert — und im Log steht nichts, weil nie ein Byte ankommt. ' +
        'Der Port wird beim Einrichten automatisch ergaenzt.');
    }
  }

  if (w.richtung === 'pc_fragt_ab') {
    hinweise.push('Bei diesem Weg ruft der PC das Geraet an. Am Geraet ist meist nichts einzustellen — ' +
      'es muss nur im selben Netz erreichbar sein. Wichtig: die meisten Monitore lassen nur EIN ' +
      'abfragendes Programm gleichzeitig zu. Laeuft nebenher VSCapture, bleibt dieser Weg tot.');
  }
  if (w.lizenz && /^ja/i.test(w.lizenz)) {
    hinweise.push('Dieser Weg braucht eine Freischaltung durch den Haendler: ' + w.lizenz);
  }
  if (w.lizenz && /^unklar/i.test(w.lizenz)) {
    hinweise.push('Ob dieser Weg ohne Freischaltung funktioniert, ist nicht gesichert: ' + w.lizenz);
  }
  if (w.vertrauen !== 'belegt') {
    hinweise.push('Diese Angaben sind ' + (w.vertrauen === 'wahrscheinlich' ? 'gut begruendet, aber nicht an einem echten Geraet nachgemessen'
      : 'ein Hinweis aus zweiter Hand und nicht bestaetigt') + '. Weicht das Menue ab, bitte melden — der Katalog wird nachgefuehrt.');
  }
  if (g.fallstricke) hinweise.push(g.fallstricke);

  return {
    geraet: { id: g.id, hersteller: g.hersteller, modell: g.modell, kategorie: g.kategorie, vertrauen: g.vertrauen, quellen: g.quellen || [] },
    weg: { id: w.id, name: w.name, adapter: w.adapter, transport: w.transport, richtung: w.richtung, port: w.port || null, liefert: w.liefert, vertrauen: w.vertrauen },
    schritte: schritte,
    hinweise: hinweise,
    machbar: machbar,
    /* Der fertige Eintrag fuer bridge/config/devices.json — null heisst: es ist keiner noetig
     * (der Verbindungs-Assistent nimmt das Geraet ohnehin entgegen). */
    vorlage: w.vorlage || null,
  };
}

/* ------------------------------------------------------------------ *
 * 2) Die Beratung: es ist eingerichtet, es kommt trotzdem nichts
 * ------------------------------------------------------------------ */

/*
 * berate(lage) -> { urteil, kurz, befunde[] }
 *
 * lage = {
 *   geraetId, wegId          das gewaehlte Modell (oder null = kein Modell gewaehlt)
 *   pcIps[]                  die echten Adressen dieses PCs
 *   geraetImNetz             true/false/null — hat die Suche das Geraet gefunden?
 *   geraetIp                 wo es gefunden wurde
 *   gleichesNetz             true/false/null — liegt es im selben Subnetz wie der PC?
 *   lauschPorts[]            worauf die Station derzeit hoert
 *   firewallFehlend[]        Ports ohne Firewall-Freigabe
 *   portBelegt[]             Ports, die ein FREMDES Programm haelt
 *   empfangBytes             wie viel schon angekommen ist (0 = nichts)
 *   empfangProtokoll         Ergebnis von geraeteerkennung.protokollAusBytes(...)
 *   werteKommen              true, wenn schon Zahlenwerte im Registry stehen
 * }
 *
 * Urteil: 'ok' | 'problem' | 'unklar'.
 */
function berate(lage) {
  const l = lage || {};
  const g = l.geraetId ? katalog.nachId(l.geraetId) : null;
  const w = g ? ((g.wege || []).filter((x) => x.id === l.wegId)[0] || (g.wege || [])[0]) : null;
  const b = [];

  /* --- Der beste Fall zuerst: es laeuft. --- */
  if (l.werteKommen) {
    return {
      urteil: 'ok',
      kurz: g ? ('Vom ' + g.hersteller + ' ' + g.modell + ' kommen Werte an.') : 'Es kommen Werte an.',
      befunde: [],
    };
  }

  /* --- 1) Gibt dieses Modell ueberhaupt etwas heraus? Diese Frage kommt VOR jeder Netzfrage.
   *
   * Der Katalog markiert solche Wege ausdruecklich mit keinAusgang:true. Das ist kein Randfall:
   * die Mehrheit der Veterinaer-Narkosegeraete (Matrx VMS, Moduflex, Hallowell 2002, Vetland ...)
   * ist rein mechanisch-pneumatisch und hat ueberhaupt keine Buchse; und der Veta 5 Plus hat drei
   * Buchsen, von denen keine Messwerte ausgibt. Wer das nicht sagt, laesst jemanden im OP-Alltag
   * an einer Stelle suchen, an der es nichts zu finden gibt. --- */
  if (g && w && (w.keinAusgang === true ||
      (w.vorlage === null && w.adapter === 'probe' && /NICHT nutzbar|MD2/i.test(w.name + ' ' + (w.liefert || ''))))) {
    b.push(befund('MODELL_OHNE_AUSGANG', 3,
      g.hersteller + ' ' + g.modell + ': dieser Weg gibt keine lesbaren Daten heraus',
      (w.liefert || '') + ' ' + (g.fallstricke || ''),
      ['Nicht weitersuchen — an diesem Weg liegt es nicht am Netz und nicht an der Station.',
       'Beim Haendler nach einer Freischaltung der offenen Datenschnittstelle fragen.',
       'Bis dahin: die Werte dieses Geraets im virtuellen Geraet von Hand fuehren; der Beatmungs-Berater ' +
         'arbeitet mit den ECHTEN Monitorwerten weiter.']));
  }

  /* --- 2) Hoert die Station auf dem richtigen Port? --- */
  if (w && w.port && (w.richtung === 'geraet_sendet' || w.richtung === 'beides')) {
    const lausch = (l.lauschPorts || []).map(Number);
    if (lausch.length && lausch.indexOf(Number(w.port)) < 0) {
      b.push(befund('PORT_NICHT_BELAUSCHT', 3,
        'Die Station hoert nicht auf Port ' + w.port,
        'Der Weg „' + w.name + '“ laeuft ueber Port ' + w.port + '. Die Station lauscht derzeit auf ' +
        (lausch.join(', ') || 'keinem Port') + '. Ein Geraet kann dann senden, ohne dass jemand zuhoert — ' +
        'und es steht nichts im Log, weil nie ein Byte ankommt.',
        ['Im Reiter „Geräte“ das Modell einrichten — der Port wird dabei ergaenzt.',
         'Danach FIREWALL-FREIGEBEN.bat doppelklicken und die Station neu starten.']));
    }
  }

  /* --- 3) Belegt ein anderes Programm den Port? --- */
  const belegt = (l.portBelegt || []).map(Number);
  if (w && w.port && belegt.indexOf(Number(w.port)) >= 0) {
    b.push(befund('PORT_FREMD_BELEGT', 3,
      'Port ' + w.port + ' ist von einem anderen Programm belegt',
      'Die Daten des Geraets landen dann in diesem anderen Programm, und VetStation sieht nichts.',
      ['Laeuft VetStation vielleicht doppelt? Dann NEUSTART.bat doppelklicken.',
       'Laeuft VSCapture? Es belegt denselben Port und die Geraeteverbindung exklusiv.']));
  } else if (belegt.length) {
    b.push(befund('PORT_FREMD_BELEGT_ANDERE', 2,
      'Andere Datenports sind fremd belegt: ' + belegt.join(', '),
      'Fuer das gewaehlte Modell ist das ohne Belang, fuer ein zweites Geraet kann es die Ursache sein.',
      ['Pruefen, ob VetStation doppelt laeuft oder VSCapture mitlaeuft.']));
  }

  /* --- 4) Firewall. --- */
  const fw = (l.firewallFehlend || []).map(Number);
  if (w && w.port && fw.indexOf(Number(w.port)) >= 0) {
    b.push(befund('FIREWALL_ZU', 3,
      'Die Windows-Firewall blockiert Port ' + w.port,
      'Ankommende Vitaldaten werden LAUTLOS verworfen. Am Geraet sieht alles richtig aus, hier kommt nichts an.',
      ['FIREWALL-FREIGEBEN.bat doppelklicken (holt sich die Adminrechte selbst).']));
  } else if (fw.length) {
    b.push(befund('FIREWALL_TEILWEISE', 1,
      'Nicht alle Datenports sind freigegeben: ' + fw.join(', '),
      'Fuer das gewaehlte Modell reicht die vorhandene Freigabe. Ein weiteres Geraet auf einem der ' +
      'genannten Ports kaeme aber nicht durch.',
      ['FIREWALL-FREIGEBEN.bat doppelklicken.']));
  }

  /* --- 5) Wurde das Geraet ueberhaupt im Netz gesehen? --- */
  if (l.geraetImNetz === false) {
    b.push(befund('GERAET_NICHT_IM_NETZ', 3,
      'Im Netz dieses PCs antwortet kein passendes Geraet',
      'Die Suche hat ' + ((l.pcIps || []).join(', ') || 'das eigene Netz') + ' abgesucht und nichts gefunden. ' +
      'Ein Geraet, das nur SENDET, muss dabei allerdings nicht auffallen — es lauscht ja nicht.',
      ['Am Geraet selbst nachsehen: LAN-Buchse steckt, Lampe leuchtet, Geraet ist NICHT im Standby, ' +
        'die Parameter sind nicht rot durchgestrichen.',
       'Am Geraet die eingestellte IP ablesen und pruefen, ob sie im selben Netz liegt wie dieser PC.',
       'Danach im Reiter „Netzwerk & Geräte“ die Suche erneut starten.']));
  } else if (l.gleichesNetz === false && l.geraetIp) {
    b.push(befund('ANDERES_NETZ', 3,
      'Das Geraet (' + l.geraetIp + ') liegt in einem anderen Netz als dieser PC',
      'Zwei verschiedene Netze sehen einander nicht, egal wie richtig alles andere eingestellt ist. ' +
      'PC: ' + ((l.pcIps || []).join(', ') || 'unbekannt') + '.',
      ['Entweder am Geraet eine Adresse aus dem Netz des PCs eintragen,',
       'oder am PC NETZWERK-EINRICHTEN.bat doppelklicken.']));
  }

  /* --- 6) Es kommt etwas an, aber es ist nicht lesbar. --- */
  const prot = l.empfangProtokoll || null;
  if (l.empfangBytes > 0 && prot && prot.lesbar === false) {
    b.push(befund('PROTOKOLL_UNLESBAR', 2,
      'Es kommen Daten an, aber in einer Sprache, die die Station nicht liest (' + prot.name + ')',
      'Die Leitung steht also — Kabel, Adresse, Port und Firewall sind in Ordnung. Das Geraet spricht ' +
      'nur ein anderes Protokoll. Geraten wird hier nichts: ein erfundener Wert am narkotisierten Tier ' +
      'waere gefaehrlicher als eine leere Anzeige.',
      ['Am Geraet nach einem Schalter fuer HL7 bzw. „Datenexport“ suchen (siehe Anleitung oben).',
       'Sonst beim Haendler nach der offenen Datenschnittstelle fragen — der Mitschnitt liegt in bridge/data/.']));
  }

  /* --- 7) Alles steht, es kommt aber schlicht nichts. Der haeufigste Fall. --- */
  if (!b.length && l.empfangBytes === 0) {
    const schritte = w && (w.schritte || []).length
      ? w.schritte.slice()
      : ['Am Geraet die Datenausgabe einschalten und als Ziel die PC-Adresse eintragen.'];
    b.push(befund('GERAET_SENDET_NICHT', 2,
      'Auf der Seite des PCs ist alles in Ordnung — das Geraet sendet nichts',
      'Port, Firewall und Netz stimmen. Es fehlt der Schalter AM GERAET' +
      (g ? ' (' + g.hersteller + ' ' + g.modell + ')' : '') + '. ' +
      'Zweitens sendet ein Monitor Messwerte erst, wenn die Sensoren am Patienten liegen und er misst.',
      schritte));
  }

  b.sort((x, y) => y.schwere - x.schwere);
  const schwerste = b.length ? b[0].schwere : 0;
  return {
    urteil: schwerste >= 3 ? 'problem' : (b.length ? 'unklar' : 'ok'),
    kurz: b.length ? b[0].titel : 'Keine Auffaelligkeit gefunden.',
    befunde: b,
  };
}

/* ------------------------------------------------------------------ *
 * 3) Welcher Weg passt zu dieser Praxis?
 * ------------------------------------------------------------------ */

/*
 * empfehleWeg(geraetId, lage) — von mehreren Wegen eines Geraets den, der hier am ehesten traegt.
 *
 * Regel, in dieser Reihenfolge:
 *   1. Ein Weg, der KEINE Freischaltung braucht, schlaegt einen, der eine braucht.
 *   2. Ein belegter Weg schlaegt einen wahrscheinlichen.
 *   3. Ist das Geraet im Netz gefunden und hat einen offenen Port, schlaegt "der PC fragt ab" —
 *      dann muss am Geraet niemand ein Menue suchen.
 *   4. Sonst der erste (der Katalog fuehrt sie bereits in sinnvoller Reihenfolge).
 */
function empfehleWeg(geraetId, lage) {
  const l = lage || {};
  const g = katalog.nachId(geraetId);
  if (!g || !(g.wege || []).length) return null;
  const offene = (l.offenePorts || []).map(Number);

  const punkte = (w) => {
    let p = 0;
    if (!w.lizenz || /^keine/i.test(w.lizenz)) p += 40;
    else if (/^unklar/i.test(w.lizenz)) p += 10;
    if (w.vertrauen === 'belegt') p += 30;
    else if (w.vertrauen === 'wahrscheinlich') p += 15;
    if (w.richtung === 'pc_fragt_ab' && w.port && offene.indexOf(Number(w.port)) >= 0) p += 25;
    if (w.keinAusgang === true) p -= 100;
    if (w.vorlage === null && w.adapter === 'probe' && /NICHT nutzbar/i.test(w.name)) p -= 100;
    return p;
  };

  return g.wege.slice().sort((a, c) => punkte(c) - punkte(a))[0];
}

module.exports = { anleitung, berate, empfehleWeg, befund };
