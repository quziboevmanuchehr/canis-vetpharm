'use strict';
/*
 * server.js — Ein Prozess, ein Port: liefert die Kiosk-UI (statisch) UND den lokalen WebSocket
 * (Schicht 2 wird von Schicht 1 gefuettert). Plus kleine JSON-API fuer Diagnose/Updater.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { createWsServer } = require('./wsserver');
const { MSG } = require('./model');
const { listScenarios } = require('./scenarios');
const logger = require('./logger');
const updater = require('../../updater/updater');
const netscan = require('./netscan');
const firewall = require('./firewall');
const { diagnose } = require('./diagnose');
const { fuerRundruf } = require('./matching');
/* stationsName ist DIE EINE Quelle fuer den Namen dieses OP-Saals (Nachbesserung N10). Hier wird
 * sie nur gerufen, nie nachgebaut: eine zweite Namensberechnung im Server hiesse, dass derselbe
 * Saal im Admin-Bereich anders heisst als in der Tafel und in der Fern-Ansicht — und der
 * Admin-Bereich ist genau die Stelle, an der ein Mensch nachsieht, ob sein Name angekommen ist. */
const { Stationsid, stationsName, NAME_MAX } = require('./stationsid');
/* Die Station sucht nach der Installation von selbst nach Geraeten und weiteren Praxis-PCs
 * (Wunsch 31.07.2026). Warum das Modul getrennt ist und was es ausdruecklich NICHT tut, steht in
 * seinem Kopfkommentar. */
/* darfSuchen kommt mit herein, weil ab 01.08.2026 AUCH der Suchlauf aus dem Admin-Bereich
 * dagegen prueft — vorher galt die Narkose-Sperre nur fuer die Automatik. */
const { Erstsuche, darfSuchen } = require('./erstsuche');
/* Die drei Bausteine der Nachbarsaele. Sie haengen NICHT aneinander: tafelabo liest, nachbar
 * liest direkt im Haus, fremdstore fuehrt beides zu EINER Sicht je Saal zusammen. Faellt einer
 * aus, laufen die anderen weiter — und der eigene Saal ist von allen dreien unabhaengig. */
const { Tafelabo } = require('./tafelabo');
const { Fremdstore } = require('./fremdstore');
const { Nachbar } = require('./nachbar');
/* Der Geraetekatalog und was daran haengt (Wunsch 01.08.2026: "je nach Narkosegeraet oder
 * Monitorgeraet muss das App erkennen oder muss der Benutzer das Modell eingeben koennen").
 * Drei getrennte Bausteine mit drei getrennten Aufgaben — zusammengelegt waeren sie unpruefbar:
 *   katalog        WAS es gibt (reine Daten, eine Quelle fuer Ports, MAC-Praefixe, Menuepfade)
 *   erkennung      WELCHES Geraet da haengt (rein, raet nie, nennt Kandidaten mit Begruendung)
 *   berater        WAS zu tun ist (rein, sagt auch, wenn ein Modell gar nichts herausgibt)
 *   einrichtung    TUT es dann (schreibt devices.json, ergaenzt den Lauschport, startet sofort) */
const katalog = require('./geraetekatalog');
const erkennung = require('./geraeteerkennung');
const berater = require('./verbindungsberater');
const { Geraeteeinrichtung } = require('./geraeteeinrichtung');

const UI_DIR = path.join(__dirname, '..', '..', 'ui');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.map': 'application/json',
};

/*
 * Nur der Praxis-PC selbst — als eigene, REINE Funktion auf Modulebene, damit ein Test sie ohne
 * Netz und ohne Socket pruefen kann (tools/saalname-test.js).
 *
 * Sie ist die einzige Sperre zwischen dem Praxis- oder Gast-WLAN und dem Namen bzw. der Kennung
 * eines laufenden OP-Saals. Eine Sperre, die sich nur ueber einen aufgebauten Netzweg pruefen
 * laesst, wird irgendwann nicht mehr geprueft — und dann faellt ihre Aufhebung erst im Feld auf.
 *
 * DIE LISTE IST ABSCHLIESSEND UND KEIN PRAEFIXVERGLEICH: '127.' als Anfang zu akzeptieren waere
 * bequem und falsch — '127.0.0.1.beispiel.invalid' beginnt ebenso damit. Verglichen wird die
 * Adresse des SOCKETS; jede Angabe aus der Anfrage selbst (Host, X-Forwarded-For) kann der
 * Absender frei setzen und beweist nichts.
 */
function istLokaleAdresse(a) {
  return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
}

function startServer({ port, host, registry, version, cloud, stationsid, adapterStarten, erstsucheCfg, nachbarnCfg }) {
  // Wann dieser Prozess angefangen hat. Wird ueber /healthz herausgegeben, damit ein zweiter Start
  // im Klartext sagen kann, seit wann die bereits laufende Station arbeitet.
  const startZeit = Date.now();

  /*
   * DIE STATIONSKENNUNG UND DER SAALNAME (Nachbesserung N10).
   *
   * WOHER DIE INSTANZ KOMMT: bevorzugt aus dem Aufrufer (opts.stationsid). Das ist die Naht fuer
   * bridge/src/index.js, sobald dort die Kennung fuer cloud.js erzeugt wird — es darf im ganzen
   * Prozess nur EINE Stationsid geben, denn jede erzeugt beim Start eine eigene Instanzkennung und
   * schreibt dieselbe data/station-id.json. Zwei Instanzen wuerden ihre Instanzlisten gegenseitig
   * ueberschreiben, und die Kollisionserkennung haette danach einen "fremden" Wert vor sich, der
   * in Wahrheit der eigene zweite Prozessteil ist.
   * Uebergibt niemand eine — der heutige Stand, index.js ist nicht Teil dieses Bausteins —, legt
   * der Server eine an. Sonst gaebe es den Saalnamen ueberhaupt nicht, und jede ausgelieferte
   * Station hiesse weiter 'Praxis OP 1'.
   *
   * WARUM NICHT AUF laden() GEWARTET WIRD (Randbedingung 5): laden() fragt im schlechtesten Fall
   * die Windows-Registry ab (execFile mit 6 s Zeitgrenze). Der Geraeteempfang, das Narkoseprotokoll
   * und die Anzeige des eigenen Saals duerfen darauf keine Sekunde warten. Die Endpunkte unten
   * antworten deshalb ehrlich mit bereit:false, solange nichts geladen ist — das ist ein Zustand
   * von Sekundenbruchteilen und er blockiert nichts.
   */
  const station = stationsid || new Stationsid({ log: logger });
  if (!stationsid) {
    /* laden() sagt im Kopfkommentar zu, nicht zu werfen. Der Fang steht trotzdem da: eine
     * abgelehnte Zusage waere hier eine unbehandelte Ablehnung — und die beendet den Prozess,
     * moeglicherweise mitten in einer Narkose. */
    Promise.resolve().then(() => station.laden()).catch((e) => {
      logger.warn('station', 'Die Stationskennung liess sich nicht laden (' + (e && e.message)
        + '). Die Station laeuft normal weiter; der Saalname kann erst nach einem Neustart '
        + 'gesetzt werden.');
    });
  }

  /*
   * DIE VORBELEGUNG DES SAALNAMENS — cfg.station, und AUSSCHLIESSLICH als Vorbelegung (N10).
   *
   * Sie kommt aus bridge/config/devices.json ueber cloud.cfg. Der Server liest cfg nicht selbst:
   * er bekommt keine, und ein zweiter Lesepfad in dieselbe Datei waere schon wieder eine zweite
   * Quelle. Fehlt cloud (Fassungen ohne Fern-Live), ist die Vorbelegung schlicht null — dann
   * fragt die Station nach einem Namen, was ohne devices.json ohnehin der Normalfall ist.
   */
  function vorbelegung() { return (cloud && cloud.cfg) ? cloud.cfg.station : null; }

  // --- Selbsttest des Netzwerks (§ "die App prueft ihr Netz selbst") ---
  // Ein Suchlauf dauert ~30-60 s. Er laeuft deshalb im Hintergrund; die Oberflaeche fragt den
  // Fortschritt ab, statt auf eine einzelne, minutenlange HTTP-Antwort zu warten.
  const netz = { laufend: false, fortschritt: null, ergebnis: null, firewall: null, internet: null, diagnose: null, ts: 0 };

  // Woran erkennt die Station, dass wirklich Werte ankommen? An echten Geraeten, die zuletzt
  // gesendet haben. Das ist die Tatsache, die vorher NIRGENDS stand (Kernbefund).
  function empfangslage() {
    const devs = registry.getDevices().filter((d) => d.status !== 'offline');
    const letzte = devs.reduce((m, d) => Math.max(m, d.lastTs || 0), 0);
    return {
      aktiv: devs.length > 0,
      geraete: devs.length,
      letzteDatenVorMs: letzte ? (Date.now() - letzte) : null,
    };
  }

  // Datenports, die ein FREMDES Programm belegt (der Verbindungs-Assistent merkt sich das).
  function fremdBelegt() {
    const out = [];
    (registry.adapters || []).forEach((a) => {
      (a && a.belegt ? a.belegt : []).forEach((p) => { if (out.indexOf(p) < 0) out.push(p); });
    });
    return out;
  }

  // Welche Geraete-Adressen stehen in devices.json? Nur so kann die Diagnose sagen "eingetragen
  // ist .50, gefunden wurde .51" — der Fall, der am 22.07.2026 zwei Stunden Suche gekostet hat.
  function konfigHosts() {
    const out = [];
    (registry.adapters || []).forEach((a) => {
      const h = a && a.cfg && a.cfg.host;
      if (h && out.indexOf(h) < 0) out.push(h);
    });
    return out;
  }

  function lageOhneScan() {
    return diagnose({
      scan: netz.ergebnis, firewall: netz.firewall, empfang: empfangslage(),
      cloud: cloud ? cloud.status() : null, fremdBelegt: fremdBelegt(),
      /* Der Zustand des Saalzweigs kommt FERTIG ENTSCHIEDEN aus stationsid.js. diagnose.js leitet
       * ihn ausdruecklich nicht selbst her: eine zweite Herleitung waere eine zweite Wahrheit,
       * und dieser Befund entscheidet darueber, ob Patientendaten gesendet werden. */
      saal: { sid: station.sid(), sperre: station.kollisionsstand() },
      konfigHosts: konfigHosts(), internet: netz.internet,
      /* GEMESSEN statt geschlossen: auf diesen Ports ist wirklich schon eine Verbindung
       * angekommen. diagnose.js nimmt sie ernster als jede Firewall-Regelliste. */
      empfangenePorts: empfangenePorts(),
    });
  }

  /* Alle Ports, auf denen ein Adapter jemals eine Verbindung angenommen hat. */
  function empfangenePorts() {
    const out = [];
    (registry.adapters || []).forEach((a) => {
      if (!a || typeof a.empfangenePorts !== 'function') return;
      (a.empfangenePorts() || []).forEach((p) => { if (out.indexOf(p) < 0) out.push(p); });
    });
    return out;
  }

  /*
   * scanLauf() — DER Suchlauf, und zwar genau einer.
   *
   * Er hat zwei Auftraggeber: den Menschen im Admin-Bereich (starteScan, unveraendert) und die
   * automatische Erstsuche (bridge/src/erstsuche.js). Deshalb gibt er ab jetzt eine Zusage
   * zurueck statt nur zu laufen — sonst muesste die Erstsuche den Fortschritt pollen oder einen
   * ZWEITEN netscan.scan() starten, und zwei gleichzeitige Suchlaeufe klopfen dieselben 254
   * Adressen doppelt an. Die Sperre netz.laufend bleibt die einzige Stelle, die das verhindert.
   */
  function scanLauf() {
    if (netz.laufend) return Promise.resolve(netz.ergebnis);
    netz.laufend = true;
    netz.fortschritt = { phase: 'start', getan: 0, gesamt: 1, text: 'Suche wird gestartet …' };
    logger.info('netz', 'Netzwerksuche gestartet (aktive Suche .1-.254 + Portscan).');
    return Promise.resolve()
      .then(() => netscan.scan({ onProgress: (p) => { netz.fortschritt = p; } }))
      .then((erg) => { netz.ergebnis = erg; return firewall.pruefe().catch(() => null); })
      .then((fw) => {
        netz.firewall = fw;
        // Zusaetzlich pruefen, ob dieser PC ueberhaupt ins Internet kommt (Update/Fern-Live).
        // Schlaegt die Pruefung fehl, bleibt netz.internet null = "nicht geprueft" statt "in Ordnung".
        return netscan.internetLage().catch(() => null);
      })
      .then((inet) => {
        netz.internet = inet;
        netz.diagnose = lageOhneScan();
        netz.ts = Date.now();
        const e = netz.ergebnis;
        logger.info('netz', 'Netzwerksuche fertig: ' + e.hosts.length + ' Teilnehmer, ' +
          e.geraete.length + ' sicheres/sichere Geraet(e), Urteil: ' + netz.diagnose.kurz);
      })
      .catch((e) => { logger.error('netz', 'Netzwerksuche fehlgeschlagen: ' + e.message); })
      .then(() => { netz.laufend = false; return netz.ergebnis; });
  }

  /*
   * starteScan() — der Suchlauf aus dem Admin-Bereich.
   *
   * DIE NARKOSE-SPERRE GALT HIER NICHT (Befund 01.08.2026). erstsuche.darfSuchen() wurde
   * ausschliesslich von der Automatik gerufen; ein Klick auf "Netzwerk jetzt durchsuchen" startete
   * den Lauf ungeprueft — auch mitten in einer laufenden Narkose. Der Kopfkommentar von
   * erstsuche.js:96 behauptete ausdruecklich das Gegenteil ("Dieselbe Sperre gilt laut Plan-Schritt 3
   * auch fuer den Suchlauf aus dem Admin-Bereich"). Eine Zusage, die der Code nicht haelt, ist
   * schlimmer als keine: sie beendet das Nachdenken.
   *
   * Ein Suchlauf oeffnet in kurzer Folge rund 250 TCP-Verbindungen. Auf dem Kiosk-i3 konkurriert
   * das mit dem Empfang der Vitalwerte — genau in dem Moment, in dem ein Tier an der Maschine haengt.
   *
   * Rueckgabe jetzt: { gestartet, grund } statt nichts. Wer "nein" sagt, muss auch sagen, warum,
   * sonst klickt der Anwender im OP-Betrieb dreimal auf einen Knopf, der stumm nichts tut.
   */
  function starteScan() {
    const darf = erstsuche ? darfSuchen(erstsuche.lage()) : { ok: true };
    if (!darf.ok) {
      logger.info('netz', 'Suchlauf abgelehnt: ' + darf.grund);
      return { gestartet: false, grund: darf.grund };
    }
    scanLauf();
    return { gestartet: true, grund: null };
  }

  /*
   * DIE AUTOMATISCHE ERSTSUCHE (Wunsch 31.07.2026: die Station soll nach der Installation von
   * selbst finden, was im Netz haengt — Geraete UND weitere Praxis-PCs).
   *
   * Sie sitzt hier und nicht in index.js, weil sie den Suchlauf oben mitbenutzen MUSS (siehe
   * scanLauf). Was sie nicht selbst haben kann, ist das Wissen, wie man aus einem Konfigurations-
   * eintrag einen laufenden Adapter macht — das weiss nur index.js. Deshalb kommt genau dieses
   * eine Stueck als Rueckruf herein (opts.adapterStarten). Fehlt es, traegt die Erstsuche gefundene
   * Geraete zwar ein, sie werden aber erst beim naechsten Start wirksam; sie sagt das dann auch.
   */
  const erstsuche = new Erstsuche({
    log: logger,
    registry: registry,
    scan: scanLauf,
    adapterStarten: adapterStarten || null,
    enabled: !(erstsucheCfg && erstsucheCfg.enabled === false),
  });
  erstsuche.start();

  /*
   * DAS EINRICHTEN AUS DEM KATALOG (Wunsch 01.08.2026).
   *
   * Es benutzt DENSELBEN Rueckruf wie die automatische Erstsuche, damit es im ganzen Programm
   * genau einen Weg gibt, aus einem Konfigurationseintrag einen laufenden Adapter zu machen.
   * Zwei Wege hiessen zwei Verhaltensweisen, und die zweite faellt erst im Feld auf.
   */
  const einrichtung = new Geraeteeinrichtung({
    log: logger, registry: registry, adapterStarten: adapterStarten || null,
  });

  /*
   * geraeteLage() — der gemessene Zustand, mit dem Anleitung und Beratung gefuellt werden.
   * Sie rechnet NICHTS selbst aus: jede Zahl kommt aus der Stelle, die sie ohnehin fuehrt
   * (netscan, firewall, registry, der laufende Verbindungs-Assistent). Eine zweite Herleitung
   * waere eine zweite Wahrheit — und der Admin-Bereich ist genau die Stelle, an der ein Mensch
   * nachsieht, ob das, was die Station sagt, mit dem uebereinstimmt, was sie tut.
   */
  function geraeteLage(geraetId, wegId) {
    const karten = netscan.localAdapters().filter((k) => !k.virtuell);
    const pcIps = karten.map((k) => k.address);
    const e = netz.ergebnis;
    const g = geraetId ? katalog.nachId(geraetId) : null;

    /* Wo haengt das gewaehlte Geraet? Bevorzugt der Fund mit passendem MAC-Praefix aus dem letzten
     * Suchlauf — das ist die einzige Stelle, an der die Station eine ADRESSE wirklich gemessen hat. */
    let geraetIp = null;
    if (e && g && (g.oui || []).length) {
      const treffer = (e.hosts || []).filter((h) => h.mac && (g.oui || []).some((o) => String(h.mac).indexOf(katalog.normMac(o)) === 0))[0];
      if (treffer) geraetIp = treffer.ip;
    }
    const gleichesNetz = geraetIp
      ? pcIps.some((ip) => ip.split('.').slice(0, 3).join('.') === geraetIp.split('.').slice(0, 3).join('.'))
      : null;

    const devs = registry.getDevices();
    return {
      geraetId: geraetId || null,
      wegId: wegId || null,
      pcIp: pcIps[0] || null,
      pcIps: pcIps,
      geraetIp: geraetIp,
      geraetImNetz: e ? ((e.geraete || []).length > 0 || !!geraetIp) : null,
      gleichesNetz: gleichesNetz,
      lauschPorts: einrichtung.lauschPorts(),
      firewallFehlend: (netz.firewall && netz.firewall.fehlend) || [],
      portBelegt: fremdBelegt(),
      offenePorts: e ? [].concat.apply([], (e.geraete || []).map((h) => h.datenPorts || [])) : [],
      empfangBytes: devs.some((d) => d.lastTs) ? 1 : 0,
      werteKommen: devs.some((d) => d.status === 'active' || d.status === 'connected'),
    };
  }

  /* ================================================================
   * DIE NACHBARSAELE
   * ================================================================
   *
   * Drei Bausteine, EINE Regel: sie duerfen den eigenen Saal nicht behindern. Deshalb sitzen sie
   * hinter einer Lastbremse (unten), sie schreiben ausschliesslich in fremdstore, und keiner von
   * ihnen fasst registry, matching oder einen Adapter an. Der eigene Bildschirm zeigt die eigenen
   * Patienten auch dann unveraendert, wenn hier alles gleichzeitig ausfaellt.
   */
  const verbund = {
    /* Der Zusammenfuehrer. Er filtert die eigene Station selbst heraus — ohne das wuerde eine
     * Station sich ueber die Cloud selbst als "Nachbarsaal" anzeigen. */
    store: new Fremdstore({
      log: logger,
      eigeneSid: () => station.sid(),
      /* instanz ist ein FELD, keine Funktion — sie wird beim Prozessstart einmal gezogen und
       * aendert sich nie. Genau deshalb ist sie der zweite, unabhaengige Beweis "das bin ich":
       * bei geklonten Platten sind die Kennungen gleich, die Instanzen nie. */
      eigeneInstanz: () => station.instanz,
    }),
    abo: null,
    lan: null,
    takt: null,
    bremse: false,
    letzterEigenerTakt: 0,
  };

  /*
   * DER LESEWEG UEBER DAS PRAXIS-KONTO — der Hauptweg. Er braucht kein Netz im Haus, keine
   * Portfreigabe und keine Adressen: beide Stationen melden sich am selben Konto an, fertig.
   *
   * Er bekommt seine Anmeldung ueber Nahtfunktionen aus cloud.js statt einer eigenen Anmeldung:
   * ein zweiter Anmeldeweg waere ein zweiter Ort, an dem ein Erneuerungs-Token liegt, und der
   * erste Fehler dort wuerde als "Praxis nicht angemeldet" erscheinen, obwohl sie es ist.
   * Wichtig ist die Richtung: dieser LESEweg kann den SCHREIBweg nicht anhalten und nicht
   * abschalten (eigener Backoff, eigenes Fehlerkonto) — das war die Vorgabe.
   */
  if (cloud && cloud.cfg && cloud.cfg.enabled && cloud.cfg.dbUrl) {
    verbund.abo = new Tafelabo({
      log: logger,
      dbUrl: cloud.cfg.dbUrl,
      uid: () => cloud.localId || null,
      sid: () => station.sid(),
      stationsid: station,
      token: (erneuern) => (erneuern ? cloud._refresh() : cloud._ensureAuth()),
      versatzMs: () => (cloud.serverVersatzMs ? cloud.serverVersatzMs() : 0),
    });
    verbund.abo.start();
  }

  /*
   * DER DIREKTE WEG IM HAUS (Stufe 2, Port 8771). Ausdruecklich NACH dem Weg ueber das Konto:
   * er ist bei diesen Takten nicht schneller, und praktisch jeder Sicherheitsbefund der
   * Vorpruefung haengt an ihm. Sein echter Nutzen ist Unabhaengigkeit — kein Internet, kein
   * Freikontingent.
   *
   * Er liefert dieselbe Tafel wie die Cloud in fremdstore; welche Quelle je Saal gilt, entscheidet
   * dort die Quellenwahl (LAN bevorzugt, aber bei Widerspruch gewinnt die Cloud).
   */
  verbund.lan = new Nachbar({
    log: logger,
    stationsid: station,
    /* Was dieser Saal herausgibt: GENAU der Inhalt von tafel/<sid>, den auch die Cloud bekommt —
     * nicht mehr. Ueber diesen Weg gibt es kein Narkoseprotokoll und keine Kurven. */
    tafelQuelle: () => (cloud && cloud.tafelSatz ? cloud.tafelSatz() : null),
    uidQuelle: () => (cloud ? cloud.localId : null) || null,
    /* GELESEN WIRD DER BLOCK "nachbarn" VON DER OBERSTEN EBENE der devices.json.
     * Hier wurde er frueher aus dem Fern-Live-Block geholt, waehrend die Vorlage ihn oben fuehrt:
     * jede Einstellung dort waere wirkungslos geblieben, und zwar lautlos — ein nicht gelesener
     * Konfigurationsblock meldet sich nie. Gefunden beim Einrichten am Praxis-PC 31.07.2026,
     * nicht durch einen Test; deshalb prueft tools/paket-test.js jetzt, dass Vorlage und Leseweg
     * denselben Ort meinen. */
    cfg: Object.assign({}, nachbarnCfg || {}, {
      /* Der Notnagel-Suchlauf darf nur laufen, wenn es ueberhaupt mehr als einen Saal gibt und im
       * Subnetz kein Geraet steht — sonst klopft eine Einzelplatz-Praxis jahrelang ihre eigenen
       * Monitore an (Befund B2-10). Beide Angaben kann nur der Server liefern. */
      tafelAnzahl: () => (verbund.abo ? verbund.abo.saele().length : 0),
      geraeteAdressen: () => konfigHosts().filter((h) => h && h !== 'auto'),
    }),
  });
  verbund.lan.aufTafel((sid, satz) => { verbund.store.ausLan(sid, satz, Date.now()); });

  /*
   * ERST STARTEN, WENN DIE KENNUNG DA IST — und das ist kein Schoenheitsfehler.
   *
   * NACHGEMESSEN am 31.07.2026 im Startlauf: nachbar.start() lief 62 ms VOR der Zeile
   * "Stationskennung st95b90647dcce" und meldete "Der LAN-Weg bleibt aus: diese Station hat noch
   * keine gueltige Stationskennung". Danach versucht es nichts mehr — der direkte Weg im Haus
   * waere bei JEDEM Start dauerhaft tot gewesen, und zwar lautlos: im Log steht ein plausibler
   * Satz, die Saele sehen einander trotzdem (ueber das Praxis-Konto), und niemand merkt, dass
   * Stufe 2 gar nie gelaufen ist.
   *
   * Warum nicht einfach auf laden() warten: es fragt im schlechtesten Fall die Windows-Registry ab.
   * Der Geraeteempfang darf darauf keine Sekunde warten (Randbedingung 5) — deshalb wird
   * NACHGESEHEN statt gewartet. Nach 30 s ohne Kennung wird es einmal im Klartext gesagt und
   * aufgehoert; dann stimmt etwas Grundsaetzliches nicht, und stilles Weiterprobieren wuerde es
   * nur verdecken.
   */
  (function starteLanSobaldBereit() {
    let versuche = 0;
    const probieren = () => {
      if (station.sid()) { verbund.lan.start(); return; }
      if (++versuche > 15) {
        logger.warn('nachbar', 'Der direkte Weg im Haus (Port 8771) bleibt aus: die Stationskennung '
          + 'liess sich in 30 s nicht laden. Die Nachbarsaele laufen weiter ueber das Praxis-Konto. '
          + 'Naeheres im Admin-Bereich unter "OP-Saal".');
        return;
      }
      const t = setTimeout(probieren, 2000);
      if (t.unref) t.unref();
    };
    probieren();
  })();

  /*
   * ================================================================
   * DAS FEHLENDE STUECK DES DIREKTEN HAUSWEGS (ergaenzt 01.08.2026)
   * ================================================================
   *
   * BEFUND: nachbar.js war vollstaendig gebaut, mit 162 eigenen Pruefungen abgesichert — und
   * konnte trotzdem NIE funktionieren. `nachbar.setzeNachbarn()` hatte ausserhalb der Tests
   * keinen einzigen Aufrufer. Damit blieb das Nachbarverzeichnis fuer immer leer: der Client
   * sagte nie "hallo", und der Server wies jeden eingehenden Handschlag als "unbekannt" ab.
   * Es gab keine Fehlermeldung — der Weg war still tot, und im Admin-Bereich sah es aus, als
   * warte er nur auf einen Nachbarn.
   *
   * DAS HIER SCHLIESST IHN: die eigene Adresse und der eigene oeffentliche Schluessel gehen in
   * das Praxis-Konto (verbund/lan/<sid>), die Anker der anderen Saele kommen von dort zurueck
   * und werden dem Nachbar-Modul uebergeben.
   *
   * WARUM UEBER DAS KONTO UND NICHT DIREKT IM NETZ: der Schluessel muss aus einer Quelle kommen,
   * die ein Fremder im selben WLAN nicht faelschen kann. Das Konto ist ueber TLS erreichbar, nur
   * mit Anmeldung les- und schreibbar, und jeder Saal schreibt allein unter seiner eigenen
   * Kennung. Wuerde man den Schluessel im LAN selbst verteilen, koennte sich jemand dazwischen
   * schieben — und der ganze Handschlag waere wertlos.
   *
   * DAS EINMALIGE INTERNET IST KEIN WIDERSPRUCH ZUM ZWECK "ohne Internet": ausgetauscht wird nur
   * EINMAL der Schluessel. Danach laeuft der Datenweg vollstaendig im Haus — auch wenn die
   * Internetleitung ausfaellt, denn der gepinnte Schluessel liegt in bridge/data/nachbarn.json.
   *
   * TAKT: alle 60 s. Der Anker aendert sich fast nie (nur bei Adresswechsel oder Neustart), und
   * jede Abfrage kostet Kontingent, das die Vitalwerte brauchen.
   */
  const LAN_ANKER_MS = 60 * 1000;
  let lanAnkerTimer = null;
  function lanAnkerAbgleichen() {
    if (!cloud || !verbund.lan || !verbund.lan.laeuft()) return;
    if (!cloud.angemeldet || !cloud.angemeldet()) return;
    let ips = [];
    try { ips = verbund.lan.eigeneAdressen() || []; } catch (_) { ips = []; }
    /* Der oeffentliche Schluessel gehoert der STATION, nicht dem Nachbar-Modul: er steht in
     * data/station-id.json und ueberdauert damit jeden Neustart. Wuerde ihn das Nachbar-Modul
     * fuehren, bekaeme jeder Prozessstart einen neuen — und jeder Nachbar muesste die Aenderung
     * von Hand bestaetigen, weil sie von einer Kaperung nicht zu unterscheiden waere. */
    const pub = (station.daten && station.daten.pub) || null;
    if (!pub || !ips.length) return;

    Promise.resolve()
      .then(() => cloud.lanAnkerSchreiben({
        pub: pub, ips: ips,
        port: (nachbarnCfg && nachbarnCfg.port) || 8771,
        name: stationsName(station, vorbelegung()),
      }))
      .then(() => cloud.lanAnkerLesen())
      .then((liste) => {
        if (!Array.isArray(liste)) return;
        /* setzeNachbarn ersetzt die Liste vollstaendig — ein Saal, der aus dem Konto verschwindet,
         * verschwindet damit auch hier. Das ist gewollt: ein ausgemusterter PC soll nicht ewig
         * angeklopft werden. Die GEPINNTEN Schluessel bleiben davon unberuehrt (nachbar.js). */
        verbund.lan.setzeNachbarn(liste);
        if (liste.length && !lanAnkerAbgleichen._gemeldet) {
          lanAnkerAbgleichen._gemeldet = true;
          logger.info('nachbar', 'Direkter Hausweg: ' + liste.length + ' Nachbarsaal' +
            (liste.length === 1 ? '' : 'saele') + ' aus dem Praxis-Konto uebernommen (' +
            liste.map((n) => (n.name || n.sid) + ' @ ' + n.ips.join('/')).join(', ') + '). ' +
            'Ab jetzt laeuft der Datenweg zwischen den Saelen im Haus — auch ohne Internet.');
        }
      })
      .catch(() => { /* Zusatzweg: er darf scheitern, ohne den eigenen Saal zu beruehren. */ });
  }
  lanAnkerTimer = setInterval(lanAnkerAbgleichen, LAN_ANKER_MS);
  if (lanAnkerTimer.unref) lanAnkerTimer.unref();
  /* Einmal frueh versuchen, damit zwei gleichzeitig gestartete Saele einander in der ersten
   * halben Minute finden statt erst nach einer vollen. */
  setTimeout(lanAnkerAbgleichen, 12 * 1000).unref?.();

  const httpServer = http.createServer(handleHttp);
  const ws = createWsServer(httpServer, { path: '/ws', onConnect, onMessage });

  // Diagnose-Ereignisse an alle UIs weiterreichen (Admin-Bereich).
  logger.setSink((ev) => ws.broadcast({ type: MSG.DIAG, event: ev }));

  // Broadcast-Takt: Geraeteliste + zusammengefuehrte Patienten (UI animiert Kurven lokal).
  // Dieselben zusammengefuehrten Patienten gehen (throttled) auch an die Cloud (Fern-Live).
  // 350 ms statt 500 (Befund 23.07.2026): schnellere, fluessigere Live-Anzeige von HF/SpO2/EKG-Analyse
  // und Haemodynamik. Der Rundruf ist bewusst schlank (fuerRundruf streift Kurven/Rohwerte ab), daher
  // ist der hoehere Takt auch auf dem Kiosk-i3 unproblematisch. GROESSTER Faktor bleibt aber der
  // Sendetakt AM GERAET (Data Interval): kleiner stellen = schnellere Werte.
  const BROADCAST_MS = 350;
  // Der Befundtitel fuer das Protokoll kommt aus derselben Brain-Bewertung wie die Fern-Ansicht.
  const befund = cloud ? (p) => cloud.befundTitel(p) : null;
  const timer = setInterval(() => {
    const patients = registry.getPatients();
    /*
     * Protokollschritt GENAU HIER — einmal je Runde. Nicht in registry.getPatients() und nicht im
     * Cloud-Zeitgeber unten: getPatients() laeuft pro Runde mehrfach, das Protokoll wuerde sonst
     * doppelt zaehlen und die 12-Sekunden-Schwelle waere wirkungslos.
     */
    try { registry.protokollSchritt(patients, befund); } catch (e) { logger.warn('protokoll', e.message); }
    if (cloud) {
      try { cloud.publish(patients, registry.getDevices(), registry.protokollFuerCloud()); }
      catch (e) { logger.warn('cloud', 'publish: ' + e.message); }
    }
    /*
     * DIE LASTBREMSE (Plan, oberflaechen: "verpasst der eigene 350-ms-Rundruf EINEN Takt").
     *
     * Gemessen wird der EIGENE Takt, nicht die Auslastung des PCs — die sagt nichts darueber, ob
     * die Vitalwerte noch fluessig ankommen. Bleibt dieser Zeitgeber um mehr als einen ganzen
     * Takt zurueck, ist die Ereignisschleife belegt, und dann sind die Nachbarn das Erste, was
     * weichen muss: sie sind Ansicht, der eigene Saal ist Betrieb. Abgeschaltet wird SOFORT und
     * nicht erst nach fuenf Sekunden Ruckeln — und mit einer Begruendung im Log, damit hinterher
     * niemand raetselt, warum der Streifen leer ist.
     */
    const jetztTakt = Date.now();
    if (verbund.letzterEigenerTakt) {
      const abstand = jetztTakt - verbund.letzterEigenerTakt;
      if (abstand > BROADCAST_MS * 2 && !verbund.bremse) {
        verbund.bremse = true;
        verbund.bremseSeit = jetztTakt;
        logger.warn('verbund', 'Der eigene Rundruf hat einen Takt verpasst (' + abstand + ' ms statt '
          + BROADCAST_MS + ' ms). Die Nachbarsaele werden abgeschaltet, damit der EIGENE Saal '
          + 'fluessig bleibt. Sie kommen von selbst zurueck, sobald der Takt wieder steht.');
      } else if (abstand <= BROADCAST_MS * 1.5 && verbund.bremse
                 && jetztTakt - (verbund.bremseSeit || 0) > 10000) {
        /* Zurueck erst nach zehn ruhigen Sekunden. Sofort zurueckzuschalten hiesse, bei einer
         * dauerhaft knappen Maschine im Sekundentakt zwischen an und aus zu flattern — und jedes
         * Anschalten kostet genau die Arbeit, wegen der abgeschaltet wurde. */
        verbund.bremse = false;
        logger.info('verbund', 'Der eigene Rundruf laeuft wieder rund — die Nachbarsaele sind zurueck.');
      }
    }
    verbund.letzterEigenerTakt = jetztTakt;

    if (!ws.clients.size) return;
    ws.broadcast({ type: MSG.DEVICES, devices: registry.getDevices() });
    // fuerRundruf() streift roh[] und kurvenDaten[] ab - sie werden hier nie gelesen und waeren
    // ueber 100 KB/s bei drei Patienten (gemessen 22.07.2026). Abruf stattdessen ueber /api/geraet.
    ws.broadcast({ type: MSG.PATIENTS, patients: fuerRundruf(patients), ts: Date.now() });
  }, BROADCAST_MS);

  /*
   * DER EIGENE 1-HZ-TAKT DER NACHBARSAELE — ausdruecklich NICHT im 350-ms-Rundruf.
   *
   * Zwei Gruende. Erstens die Menge: acht Saele mit je zwoelf Kacheln waeren dreimal je Sekunde
   * eine erhebliche Nachricht fuer eine Anzeige, die sich langsam aendert. Zweitens die Trennung:
   * haengt der Nachbarzweig am selben Zeitgeber wie die eigenen Patienten, kostet jede
   * Verzoegerung hier auch dort einen Takt — und der eigene Saal soll von den Nachbarn nichts
   * merken. Ein eigener Zeitgeber laesst sich ausserdem einzeln abschalten (Lastbremse oben).
   */
  const FREMD_MS = 1000;
  const fremdTimer = setInterval(() => {
    if (!ws.clients.size) return;
    if (verbund.bremse) return;
    const jetzt = Date.now();
    try {
      /* Erst den Leseweg einsammeln. nachbarn() liefert bereits sortiert, gedeckelt und ohne den
       * eigenen Saal; fremdstore prueft die eigene Kennung trotzdem noch einmal — zwei Sperren
       * gegen dasselbe Selbstgespraech, weil eine davon irgendwann jemand herausnimmt. */
      if (verbund.abo) {
        verbund.abo.nachbarn().forEach((s) => { verbund.store.ausCloud(s.sid, s, jetzt); });
      }
      const r = verbund.store.rundruf(jetzt);
      ws.broadcast(Object.assign({ type: MSG.FREMD }, r));
    } catch (e) {
      /* Ein Fehler hier darf NUR diesen Zweig treffen. Er laeuft im selben Prozess wie das
       * Narkoseprotokoll — eine unbehandelte Ausnahme wuerde ihn mitnehmen. */
      logger.warn('verbund', 'Nachbarsaele konnten nicht gesendet werden: ' + (e && e.message)
        + ' — der eigene Saal ist davon unberuehrt.');
    }
  }, FREMD_MS);

  /*
   * EIGENER, SCHNELLERER TAKT FUER DIE FERN-UEBERTRAGUNG (27.07.2026).
   * Die Fern-Ansicht haengt bisher am 350-ms-Rundruf der lokalen Oberflaeche - sie konnte also nie
   * schneller sein als diese, obwohl sie inzwischen nur noch Deltas (wenige hundert Byte) schreibt.
   * Deshalb bekommt sie einen eigenen Takt aus cloud.minIntervalMs. Er laeuft mit der halben
   * Periode, weil cloud.publish() selbst noch einmal auf minIntervalMs drosselt: bei gleichem Takt
   * wuerde jeder zweite Durchlauf durch Zeitjitter verworfen und die tatsaechliche Rate halbiert.
   * Die lokale Anzeige bleibt bei 350 ms - sie braucht nicht mehr und der Kiosk-i3 auch nicht.
   */
  let cloudTimer = null;
  /*
   * Bedingung bewusst NICHT an cloud.started: seit der Einfuehrung der Praxis-Konten steht beim
   * Start noch nicht fest, ob eine Anmeldung vorliegt — sie kann jederzeit im Admin-Bereich
   * nachgeholt werden. Waere der Zeitgeber an started gebunden, liefe die Fern-Uebertragung nach
   * einer solchen Anmeldung bis zum naechsten Neustart nur im langsamen 350-ms-Rundruf.
   * cloud.publish() prueft Anmeldung und Takt ohnehin selbst.
   */
  /*
   * DIE BEDINGUNG "cloud.minInterval < BROADCAST_MS" IST AM 01.08.2026 ENTFALLEN — sie war seit
   * dem 30.07.2026 stillschweigend falsch.
   *
   * Gedacht war: "wer langsamer sendet als der lokale Rundruf, braucht keinen eigenen Zeitgeber".
   * Das stimmt aber nur, wenn beide Takte zueinander passen. Der lokale Rundruf laeuft alle 350 ms,
   * der Fern-Takt steht seit dem 30.07.2026 ab Werk auf 500 ms. Damit galt 500 < 350 = falsch, es
   * gab keinen eigenen Zeitgeber, und cloud.publish() wurde nur noch vom 350-ms-Rundruf gerufen.
   * Dessen erster Takt nach 500 ms liegt aber bei 700 ms — jeder zweite Rundruf fiel in die
   * Mindestpause und verwarf sich selbst. GEMESSEN heisst das: die Werte gingen effektiv alle
   * ~700 ms hinaus statt alle 500 ms, also 40 % langsamer als eingestellt und dokumentiert.
   * Auffallen konnte das nicht: es gab keine Fehlermeldung, nur eine gedehnte Zahl in der
   * Fern-Ansicht.
   *
   * Jetzt bekommt jede eingeschaltete Fern-Uebertragung ihren eigenen Zeitgeber mit dem halben
   * Wunschtakt. Das ist gefahrlos: cloud.publish() prueft Anmeldung UND Mindestabstand selbst
   * (deshalb reicht "haeufiger fragen als noetig"), und bei einem langsam gestellten Takt
   * (z. B. 5 s) fragt der Zeitgeber eben alle 2,5 s — das kostet nichts, weil publish() dann
   * sofort zurueckkehrt. tools/cloud-test.js haelt die Rechnung fest.
   */
  if (cloud && cloud.cfg && cloud.cfg.enabled) {
    const CLOUD_MS = Math.max(50, Math.round(cloud.minInterval / 2));
    cloudTimer = setInterval(() => {
      try { cloud.publish(registry.getPatients(), registry.getDevices(), registry.protokollFuerCloud()); }
      catch (e) { logger.warn('cloud', 'publish: ' + e.message); }
    }, CLOUD_MS);
    logger.info('cloud', 'Fern-Takt: alle ' + cloud.minInterval + ' ms (eigener Zeitgeber, unabhaengig vom lokalen Rundruf).');
  }

  httpServer.listen(port, host, () => {
    logger.info('server', 'VetStation UI+Bridge: http://' + host + ':' + port + '  (WebSocket /ws)');
  });

  /*
   * WENN DER PORT SCHON BELEGT IST — und warum das hier so umstaendlich aussieht.
   *
   * Bis 1.0.3 stand hier eine einzige Zeile: der Fehler wurde protokolliert, und der Prozess lief
   * WEITER. Vollstaendig weiter: er nahm Geraetedaten an, fuehrte das Narkoseprotokoll und sendete
   * in die Fern-Ansicht — nur ohne Oberflaeche. Zwei solche Prozesse schreiben dieselbe
   * bridge/data/protokoll.json alle 5 s im Wechsel (der letzte gewinnt, Eintraege gehen verloren)
   * und senden in denselben Datenknoten. Das ist der gefaehrlichste stille Zustand, den dieses
   * Programm kennt.
   *
   * Die naheliegende Loesung — sofort beenden — ist aber GENAUSO falsch. Der Kiosk-PC startet
   * VetStation ueber den Autostart bei der Anmeldung. Beendet sich der Prozess, weil beim
   * Neustart der alte noch ein paar Sekunden am Port haengt, startet nichts mehr nach; der
   * Bildschirm bliebe leer, moeglicherweise mitten in einer Narkose.
   *
   * Deshalb wird GEFRAGT statt geraten:
   *   - Antwortet auf /healthz eine VetStation, ist es ein echter Doppelstart. Dann beenden, mit
   *     einer Meldung, die den Grund nennt. Der bereits laufende Prozess bedient die Praxis weiter.
   *   - Antwortet niemand, haelt ein FREMDES Programm den Port. Dann laeuft diese Station ohne
   *     Oberflaeche weiter (Geraete und Fern-Live sind wichtiger als der Bildschirm), versucht es
   *     dreimal erneut und sagt im Klartext, was zu tun ist.
   */
  let bindeVersuche = 0;
  httpServer.on('error', (e) => {
    if (e.code !== 'EADDRINUSE') { logger.error('server', 'HTTP-Fehler: ' + e.message); return; }
    wemGehoertDerPort(host, port, (andere) => {
      if (andere) {
        logger.error('server', 'VetStation laeuft auf diesem PC bereits (seit ' +
          new Date(andere.seit).toLocaleTimeString() + ', Fassung ' + (andere.version || '?') + '). ' +
          'Dieser zweite Start beendet sich, damit nicht zwei Programme dasselbe Narkoseprotokoll ' +
          'schreiben und in denselben Datenknoten senden. Die laufende VetStation ist unter ' +
          'http://' + host + ':' + port + ' erreichbar.');
        /* Kurz warten, damit die Zeile noch ins Diagnose-Log kommt, bevor der Prozess endet. */
        setTimeout(() => process.exit(1), 300);
        return;
      }
      if (++bindeVersuche <= 3) {
        logger.warn('server', 'Port ' + port + ' ist belegt, aber dort antwortet keine VetStation — ' +
          'Versuch ' + bindeVersuche + ' von 3 in 2 s.');
        setTimeout(() => { try { httpServer.listen(port, host); } catch (x) {} }, 2000);
        return;
      }
      logger.error('server', 'Port ' + port + ' ist dauerhaft von einem ANDEREN Programm belegt. ' +
        'Die Oberflaeche bleibt deshalb zu — Geraeteempfang, Narkoseprotokoll und Fern-Live laufen ' +
        'weiter. Welches Programm es ist, zeigt in der Eingabeaufforderung: netstat -ano | findstr :' + port);
    });
  });

  /*
   * Fragt den Port, wer dort sitzt. Kurze Zeitgrenze: das hier steht zwischen dem Start und der
   * ersten Anzeige, und ein haengender Aufruf waere schlimmer als eine unbeantwortete Frage.
   * Im Zweifel lautet die Antwort "keine VetStation" — dann wird NICHT beendet.
   */
  function wemGehoertDerPort(h, p, fertig) {
    const req = http.request({ host: h, port: p, path: '/healthz', method: 'GET', timeout: 1500 }, (r) => {
      let s = '';
      r.on('data', (c) => { s += c; });
      r.on('end', () => {
        let j = null; try { j = JSON.parse(s); } catch (_) {}
        fertig(j && j.vetstation === true && j.pid !== process.pid ? j : null);
      });
    });
    req.on('error', () => fertig(null));
    req.on('timeout', () => { req.destroy(); fertig(null); });
    req.end();
  }

  function onConnect(client) {
    client.sendJSON({ type: MSG.HELLO, bridgeVersion: version, ts: Date.now(), scenarios: listScenarios() });
    client.sendJSON({ type: MSG.DEVICES, devices: registry.getDevices() });
    client.sendJSON({ type: MSG.PATIENTS, patients: fuerRundruf(registry.getPatients()), ts: Date.now() });
    logger.recent(50).forEach((ev) => client.sendJSON({ type: MSG.DIAG, event: ev }));
  }

  function onMessage(client, text) {
    let m; try { m = JSON.parse(text); } catch (_) { return; }
    switch (m.type) {
      case MSG.PAIR: registry.pair(m.deviceIds, m.patientKey); ack(client, m, true); break;
      case MSG.UNPAIR: registry.unpair(m.patientKey); ack(client, m, true); break;
      case MSG.SET_META: registry.setMeta(m.deviceId, m.meta); ack(client, m, true); break;
      case MSG.SCENARIO: ack(client, m, registry.setScenario(m.patientId, m.scenarioId)); break;
      default: break;
    }
  }
  function ack(client, m, ok) { client.sendJSON({ type: MSG.ACK, of: m.type, ok: ok !== false }); }

  function handleHttp(req, res) {
    const u = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
    const pathname = decodeURIComponent(u.pathname);

    /*
     * --- PRAXIS-ANMELDUNG (nur vom Praxis-PC selbst) ---
     *
     * Diese Endpunkte tragen Zugangsdaten und den Anmeldezustand. Sie duerfen deshalb NICHT ueber
     * json() gehen: dieser Helfer setzt pauschal "Access-Control-Allow-Origin: *", womit JEDE
     * beliebige Webseite, die im Browser des Praxis-PCs geoeffnet ist, die Antwort auslesen
     * koennte. jsonPrivat() setzt diese Kopfzeile nicht und beantwortet ausserdem nur Anfragen
     * von 127.0.0.1 — ein Rechner im Praxisnetz kommt hier nicht heran.
     */
    /*
     * /healthz — die eine Frage: "laeuft hier schon eine VetStation?"
     *
     * Gebraucht wird sie von einem ZWEITEN Start dieses Programms. Der Port allein beantwortet die
     * Frage naemlich nicht: er sagt nur, dass IRGENDETWAS auf 8770 hoert. Ohne diese Auskunft
     * muesste der zweite Start raten — und beide moeglichen Fehlentscheidungen sind schlecht
     * (siehe die Begruendung bei httpServer.on('error') weiter unten).
     *
     * Nur von 127.0.0.1 und ohne "Access-Control-Allow-Origin": die Antwort nennt eine
     * Prozesskennung, das gehoert nicht ins Netz und schon gar nicht in eine fremde Webseite.
     */
    if (pathname === '/healthz') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      return jsonPrivat(res, { vetstation: true, pid: process.pid, version: version, seit: startZeit, port: port });
    }

    if (pathname === '/api/praxis' || pathname === '/api/praxis/anmelden'
      || pathname === '/api/praxis/abmelden' || pathname === '/api/praxis/token') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      if (!cloud) return jsonPrivat(res, { fehler: 'Fern-Live ist in dieser Fassung nicht verfuegbar.' });

      if (pathname === '/api/praxis') return jsonPrivat(res, cloud.status(true));

      if (pathname === '/api/praxis/abmelden') {
        if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
        try { return jsonPrivat(res, { ok: true, status: cloud.abmelden() }); }
        catch (e) { return jsonPrivat(res, { ok: false, fehler: e.message }); }
      }

      // Anmelden: Zugangsdaten ausschliesslich im Koerper, NIE in der Adresszeile — sonst stuenden
      // sie im Browserverlauf und in jedem Server-Log. Gilt auch fuer den Google-Token.
      if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
      const mitToken = (pathname === '/api/praxis/token');
      let roh = '';
      let zuGross = false;
      req.on('data', (c) => {
        roh += c;
        // Ein Google-Erneuerungs-Token ist deutlich laenger als ein Passwort.
        if (roh.length > (mitToken ? 8192 : 4096)) { zuGross = true; req.destroy(); }
      });
      req.on('end', () => {
        if (zuGross) return;
        let m; try { m = JSON.parse(roh); } catch (_) { return jsonPrivat(res, { ok: false, fehler: 'Ungueltige Anfrage.' }); }
        const p = mitToken
          ? cloud.anmeldenMitToken(m && m.refreshToken, m && m.uid, m && m.email)
          : cloud.anmelden(m && m.email, m && m.passwort);
        p.then((st) => jsonPrivat(res, { ok: true, status: st }))
          .catch((e) => jsonPrivat(res, { ok: false, fehler: klartextFehler(e && e.message) }));
      });
      return;
    }

    /*
     * --- OP-SAAL: NAME UND STATIONSKENNUNG (nur vom Praxis-PC selbst) ---
     *
     * Nachbesserung N10. Bis hierher gab es KEINEN Schreibweg fuer den Saalnamen: er stand allein
     * in bridge/config/devices.json, und diese Datei existiert im Auslieferstand nicht
     * (Install-VetStation.ps1:92 schliesst sie per robocopy /XF aus, und keine Zeile im Quellcode
     * schreibt sie). Alle ausgelieferten Stationen heissen deshalb 'Praxis OP 1' — zwei OP-Saele
     * mit demselben Namen sind fuer den Tierarzt in der Fern-Ansicht und auf jedem anderen
     * Bildschirm des Hauses nicht unterscheidbar. Genau diese Verwechslung soll der Umbau
     * beseitigen. (Auf dem AUSDRUCK stand nie ein Saalname und steht bis heute keiner — der
     * PDF-Kopf in ui/vetstation-live.js traegt 'VetStation'. Hier stand frueher das Gegenteil.)
     *
     * DIESELBE ABSICHERUNG WIE /api/praxis, und aus denselben Gruenden:
     *   istLokal    — nur 127.0.0.1. Ein Rechner im Praxis- oder Gast-WLAN darf einem laufenden
     *                 OP-Saal weder den Namen noch die Kennung aendern. Der Name steht in diesem
     *                 Moment ueber den Zahlen des narkotisierten Tiers, auf jedem Bildschirm des
     *                 Hauses und in jeder geoeffneten Fern-Ansicht.
     *   jsonPrivat  — kein "Access-Control-Allow-Origin: *". Sonst koennte JEDE im Browser des
     *                 Praxis-PCs geoeffnete Webseite die Antwort auslesen; sie nennt die
     *                 Stationskennung und den Schluessel-Fingerabdruck.
     *   POST        — ein Zustandswechsel gehoert nicht in ein GET, das ein Vorschau-Abruf oder
     *                 ein Browserverlauf wiederholen kann.
     *
     * NOCH OFFEN, ausdruecklich benannt statt halb gebaut: N10 nennt zusaetzlich ein
     * Einmal-Kennwort. Das gibt es im ganzen Server heute nicht — es wird in Schritt 2 der
     * Reihenfolge ("Lokale Loecher schliessen") EINMAL fuer alle schreibenden Wege eingefuehrt
     * (PAIR/UNPAIR/SET_META/SCENARIO, /api/update/apply, /api/netscan/start). Hier jetzt ein
     * eigenes, zweites Verfahren zu erfinden hiesse, dass es danach zwei gibt. Wer Schritt 2 baut,
     * nimmt DIESE ZWEI Wege mit in die Liste.
     */
    if (pathname === '/api/station' || pathname === '/api/station/name'
      || pathname === '/api/station/kennung/neu') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }

      if (pathname === '/api/station') return jsonPrivat(res, stationsAuskunft());

      if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
      /* Solange laden() laeuft, gibt es keinen Datensatz, in den etwas geschrieben werden koennte.
       * Das dauert Sekundenbruchteile und wird im Klartext beantwortet statt still verworfen. */
      if (!station.daten) {
        return jsonPrivat(res, { ok: false, bereit: false,
          fehler: 'Die Stationskennung wird gerade geladen. Bitte in einem Moment erneut versuchen.' });
      }

      /*
       * NEUE KENNUNG — der EINZIGE Ausweg aus einer doppelten Stationskennung, und ausdruecklich
       * nur von Hand. Zwei geklonte PCs schreiben sonst Feld fuer Feld in denselben Saalzweig.
       *
       * WARUM DAS KEIN AUTOMATISMUS SEIN DARF: eine Station, die sich selbst umbenennt,
       * verschwindet fuer die Fern-Ansicht als lebender Saal und taucht als neuer, leerer auf, und
       * ihr unveraenderliches Narkoseprotokoll zerfaellt in zwei Teile, die niemand mehr
       * zusammenfuehrt. Vier Befunde der Vorrunde (A2-7, B2-7, C2-4, C2-11) beschreiben je einen
       * Weg dorthin. Deshalb: ein Mensch, an diesem PC, mit einem Knopf.
       * Der SAALNAME bleibt dabei stehen — umbenennen() fasst ihn nicht an. Der Saal heisst
       * weiter "OP 2", er hat nur eine andere Kennung.
       *
       * WAS DABEI IN DER DATENBANK PASSIERT, steht vollstaendig und GEMESSEN im Kommentar von
       * stationsid.umbenennen(). Die Kurzform, weil sie hier in zwei Rueckfragen und einem Absatz
       * des Admin-Bereichs wortgleich wiederkehren muss: die Live-Werte der alten Kennung werden
       * im naechsten Sendetakt entfernt (sie laufen unter der neuen weiter), das Narkoseprotokoll
       * bleibt vollstaendig und wird an dieser Stelle in zwei Zweige geteilt, die Kachel des alten
       * Saals bleibt stehen und altert aus. Die frueher hier wie dort behauptete Zusage "geloescht
       * wird nichts" war falsch.
       */
      if (pathname === '/api/station/kennung/neu') {
        const alt = station.sid();
        const neu = station.umbenennen(null);
        if (!neu || neu === alt) {
          return jsonPrivat(res, { ok: false, fehler: 'Die Kennung liess sich nicht neu vergeben.',
            auskunft: stationsAuskunft() });
        }
        return jsonPrivat(res, { ok: true, alt: alt, sid: neu, auskunft: stationsAuskunft() });
      }

      // /api/station/name
      leseKoerper(req, 2048, (k) => {
        /* JEDER FALL BEKOMMT SEINEN EIGENEN SATZ. Ein gemeinsames "Ungueltige Anfrage." waere
         * bequem und falsch: der Tierarzt soll aus der Meldung ablesen koennen, was er anders
         * machen muss — kuerzer tippen, es noch einmal versuchen, oder den Namen ueberhaupt erst
         * eingeben. */
        if (k && k.zuGross) {
          return jsonPrivat(res, { ok: false, auskunft: stationsAuskunft(),
            fehler: 'Die Anfrage war zu lang (mehr als 2048 Zeichen) und wurde nicht gespeichert. '
              + 'Ein Saalname darf hoechstens ' + NAME_MAX + ' Zeichen haben.' });
        }
        if (k && k.zeitablauf) {
          return jsonPrivat(res, { ok: false, auskunft: stationsAuskunft(),
            fehler: 'Die Anfrage kam nicht vollstaendig an. Bitte noch einmal versuchen.' });
        }
        let m = null;
        try { m = JSON.parse((k && k.text) || '{}'); } catch (_) { m = null; }
        if (!m || typeof m !== 'object') {
          return jsonPrivat(res, { ok: false, fehler: 'Ungueltige Anfrage.' });
        }
        const gesetzt = station.setzeName(m.name);
        if (gesetzt === null) {
          return jsonPrivat(res, { ok: false, auskunft: stationsAuskunft(),
            fehler: 'Bitte einen Saalnamen eingeben (Buchstaben oder Ziffern, hoechstens '
              + NAME_MAX + ' Zeichen). Die Zeichen < > & " \' \\ ` sind nicht erlaubt, weil der '
              + 'Name auf dem Bildschirm eines anderen OP-Saals angezeigt wird.' });
        }
        return jsonPrivat(res, { ok: true, name: gesetzt, auskunft: stationsAuskunft() });
      });
      return;
    }

    // Protokoll eines Patienten (fuer den PDF-Export). Nur lokal.
    if (pathname === '/api/protokoll') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      const pid = u.searchParams.get('id');
      return jsonPrivat(res, pid ? registry.protokollVon(pid) : { liste: registry.protokollListe() });
    }

    // --- kleine JSON-API ---
    if (pathname === '/api/state') return json(res, { devices: registry.getDevices(), patients: registry.getPatients() });
    /*
     * /api/geraet?id=<deviceId> — ALLE Rohwerte EINES Geraets, auf Abruf.
     *
     * Bewusst NICHT im 500-ms-Rundruf: 60 Eintraege je Geraet zweimal pro Sekunde zu verschicken
     * waere Verschwendung, und die staendig wechselnden Daten wuerden den Koppel-Dialog dauernd
     * neu bauen (Fokusverlust beim Tippen). Auf Klick geholt ist es genau einmal noetig.
     * Rein lesend.
     */
    if (pathname === '/api/geraet') {
      const id = u.searchParams.get('id') || '';
      const dev = registry.getDevices().find((d) => d.deviceId === id) || null;
      return json(res, { geraet: dev, roh: id ? registry.getRoh(id) : [] });
    }
    /*
     * /api/kurven?key=<patientKey> — die ECHTEN Abtastwerte (EKG/CO2 ...) EINES Patienten, auf Abruf.
     * Wie /api/geraet bewusst NICHT im 500-ms-Rundruf (zu gross). Die Oberflaeche holt sie nur, wenn
     * die kompakte kurvenSig (aus fuerRundruf) sich aendert - also wenn ein neuer Streifen ankommt.
     * Rein lesend.
     */
    if (pathname === '/api/kurven') {
      const key = u.searchParams.get('key') || '';
      const pat = registry.getPatients().find((p) => p.patientKey === key) || null;
      return json(res, { kurven: pat ? (pat.kurvenDaten || []) : [] });
    }
    // Die letzten unveraenderten HL7-Nachrichten (Speicher-Ringpuffer) - fuer die Fehlersuche,
    // um zu belegen, in welchen Feldern das Geraet die Stammdaten sendet. Nur lokal (127.0.0.1).
    if (pathname === '/api/rohnachrichten') {
      return json(res, { nachrichten: registry.getRohNachrichten ? registry.getRohNachrichten() : [] });
    }
    if (pathname === '/api/diag') return json(res, { events: logger.recent(200) });
    if (pathname === '/api/scenarios') return json(res, { scenarios: listScenarios() });
    if (pathname === '/api/cloud') return json(res, cloud ? cloud.status() : { enabled: false });
    // --- Netzwerk-Selbsttest: suchen, Zustand abfragen ---
    if (pathname === '/api/netscan/start') {
      const r = starteScan();
      return json(res, { gestartet: r.gestartet, grund: r.grund, laufend: netz.laufend });
    }
    if (pathname === '/api/netscan') {
      return json(res, {
        laufend: netz.laufend, fortschritt: netz.fortschritt, ts: netz.ts,
        ergebnis: netz.ergebnis, firewall: netz.firewall,
        // Die Diagnose immer FRISCH rechnen: die Empfangslage aendert sich sekuendlich, auch
        // wenn der letzte Suchlauf schon eine Weile her ist.
        diagnose: lageOhneScan(),
      });
    }
    /*
     * Was hat die Station VON SELBST gefunden? (Wunsch 31.07.2026)
     * Ueber jsonPrivat, wie alle Auskuenfte mit Netz- und Geraeteangaben: die Antwort nennt
     * Adressen im Praxisnetz und die Vermutung, wo weitere Praxis-PCs stehen. Das gehoert nicht
     * in eine fremde Webseite, die im Browser des Praxis-PCs offen ist.
     */
    if (pathname === '/api/erstsuche') return jsonPrivat(res, erstsuche.status());

    /* ================================================================
     * GERAETEKATALOG — Modell suchen, Anleitung lesen, einrichten
     * (Wunsch 01.08.2026)
     *
     * ALLES ueber jsonPrivat und, wo geschrieben wird, zusaetzlich nur lokal. Hier stehen
     * Adressen von Medizingeraeten im Praxisnetz; sie gehoeren nicht in eine fremde Webseite,
     * die im Browser des Praxis-PCs offen ist (derselbe Grund wie bei /api/nachbarn).
     * ================================================================ */

    /* Die Modell-Liste fuer die Auswahl. Bewusst GEKUERZT: die vollstaendigen Menuepfade und
     * Quellen kommen erst beim Anklicken eines Modells — sonst waere die Antwort bei sechzig
     * Geraeten mehrere hundert Kilobyte gross, bei jedem Tastendruck im Suchfeld. */
    if (pathname === '/api/katalog') {
      const q = u.searchParams.get('q') || '';
      const treffer = katalog.suche(q).map((g) => ({
        id: g.id, hersteller: g.hersteller, modell: g.modell, kategorie: g.kategorie,
        einsatz: g.einsatz, vertrauen: g.vertrauen,
        /* Ob ein Modell ueberhaupt etwas herausgibt, entscheidet in der Liste ueber Farbe und
         * Reihenfolge — es ist die Angabe, die ein Tierarzt zuerst wissen will. */
        anbindbar: (g.wege || []).some((w) => w.vorlage || w.richtung === 'geraet_sendet'),
        wege: (g.wege || []).map((w) => ({ id: w.id, name: w.name, transport: w.transport,
          richtung: w.richtung, port: w.port || null, lizenz: w.lizenz || null, vertrauen: w.vertrauen })),
      }));
      return jsonPrivat(res, { anzahl: treffer.length, gesamt: katalog.alle().length, geraete: treffer });
    }

    /* Ein Modell vollstaendig — Anleitung mit den ECHTEN Zahlen dieses PCs, Hinweise, Quellen. */
    if (pathname === '/api/katalog/geraet') {
      const id = u.searchParams.get('id') || '';
      const g = katalog.nachId(id);
      if (!g) return jsonPrivat(res, { fehler: 'Dieses Modell steht nicht im Katalog.' });
      const wegId = u.searchParams.get('weg') || null;
      const lage = geraeteLage(id, wegId);
      const empfohlen = berater.empfehleWeg(id, lage);
      return jsonPrivat(res, {
        geraet: g,
        empfohlenerWeg: empfohlen ? empfohlen.id : null,
        anleitung: berater.anleitung(id, wegId || (empfohlen && empfohlen.id), lage),
        beratung: berater.berate(Object.assign({}, lage, { geraetId: id, wegId: wegId || (empfohlen && empfohlen.id) })),
        lage: lage,
      });
    }

    /* Was ist eingerichtet, und liefert es etwas? */
    if (pathname === '/api/geraete') {
      return jsonPrivat(res, {
        eingerichtet: einrichtung.liste(),
        lauschPorts: einrichtung.lauschPorts(),
        katalogPorts: katalog.datenPorts(),
        firewallFehlend: (netz.firewall && netz.firewall.fehlend) || [],
        portBelegt: fremdBelegt(),
      });
    }

    /*
     * Was haengt da? — die automatische Erkennung ueber den letzten Suchlauf.
     *
     * Sie liefert je Teilnehmer KANDIDATEN mit Begruendung, nie ein Modell als Tatsache. Die
     * Oberflaeche fragt nach, wenn es nicht eindeutig ist; siehe geraeteerkennung.js. Am Beispiel
     * Mindray ist das keine Vorsicht, sondern Notwendigkeit: MAC-Praefix und Port 4601 sehen beim
     * uMEC12 Vet und beim Veta 5 Plus identisch aus, und das eine liefert Werte, das andere nichts.
     */
    if (pathname === '/api/geraete/erkennung') {
      const e = netz.ergebnis;
      const hosts = (e && e.hosts ? e.hosts : []).filter((h) => h.stufe === 'sicher' || h.stufe === 'moeglich');
      const funde = hosts.map((h) => {
        const r = erkennung.ausNetscanHost(h);
        return { ip: h.ip, mac: h.mac || null, stufe: h.stufe, offenePorts: h.offenePorts || [],
          eindeutig: r.eindeutig, satz: r.satz, kandidaten: r.kandidaten };
      });
      return jsonPrivat(res, {
        geprueft: !!e, ts: netz.ts || null, funde: funde,
        hinweis: e ? null : 'Es liegt noch kein Suchlauf vor. Im Reiter „Netzwerk & Geräte“ die Suche starten.',
      });
    }

    /* Einrichten. POST und nur lokal — es schreibt bridge/config/devices.json und nimmt einen
     * Adapter in Betrieb. Ein GET waere aus jedem Link heraus wiederholbar. */
    if (pathname === '/api/geraete/einrichten') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
      return leseKoerper(req, 4096, (k) => {
        let b = null; try { b = JSON.parse((k && k.text) || '{}'); } catch (_) {}
        if (!b || !b.geraetId) return jsonPrivat(res, { ok: false, fehler: 'Es fehlt die Modellkennung.' });
        const bericht = einrichtung.einrichten({
          geraetId: String(b.geraetId),
          wegId: b.wegId ? String(b.wegId) : null,
          host: b.host ? String(b.host) : null,
          /* Die Felder werden NICHT hier gefiltert, sondern in geraeteeinrichtung.felderPruefen —
           * an EINER Stelle, damit die Sperre nicht am API-Rand haengt und beim naechsten
           * Aufrufer fehlt. */
          felder: (b.felder && typeof b.felder === 'object') ? b.felder : null,
        });
        return jsonPrivat(res, bericht);
      });
    }

    /* Abschalten (nicht loeschen) eines selbst eingerichteten Eintrags. */
    if (pathname === '/api/geraete/abschalten') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
      return leseKoerper(req, 2048, (k) => {
        let b = null; try { b = JSON.parse((k && k.text) || '{}'); } catch (_) {}
        if (!b || !b.id) return jsonPrivat(res, { ok: false, fehler: 'Es fehlt die Kennung des Eintrags.' });
        return jsonPrivat(res, einrichtung.entfernen(String(b.id)));
      });
    }

    /*
     * DIE NACHBARSAELE — Auskunft fuer den Admin-Bereich und die Fehlersuche.
     *
     * Ueber jsonPrivat und nur lokal: hier stehen Patientenkacheln fremder Saele, Adressen im
     * Praxisnetz und Schluesselfingerabdruecke. Nichts davon gehoert in eine Webseite, die im
     * Browser des Praxis-PCs offen ist.
     *
     * Es gibt hier bewusst KEINEN Schreibweg. Fremde Saele sind Ansicht — das ist die Zusage, und
     * sie ist nur so viel wert, wie es Wege gibt, sie zu brechen.
     */
    if (pathname === '/api/nachbarn') {
      return jsonPrivat(res, {
        ts: Date.now(),
        bremse: verbund.bremse,
        saele: verbund.store.saele(Date.now()),
        verlegungen: verbund.store.verlegungen(Date.now()),
        store: verbund.store.status(),
        leser: verbund.abo ? verbund.abo.status() : { aus: true, grund: 'Fern-Live ist nicht eingerichtet' },
        lan: verbund.lan ? verbund.lan.status() : { aus: true },
      });
    }
    if (pathname.indexOf('/api/nachbarn/') === 0) {
      const sid = decodeURIComponent(pathname.slice('/api/nachbarn/'.length));
      const einer = verbund.store.saele(Date.now()).filter((s) => s.sid === sid)[0] || null;
      return jsonPrivat(res, { sid: sid, saal: einer });
    }
    /*
     * Einen geaenderten Nachbarschluessel BESTAETIGEN — der EINZIGE Schreibweg im ganzen Verbund.
     *
     * Gleiche Absicherung wie die Umbenennung oben und aus demselben Grund gleich: istLokal
     * (nur dieser PC), POST (kein wiederholbares GET), jsonPrivat (keine fremde Webseite liest
     * mit). Das Einmal-Kennwort aus N10 fehlt hier ebenso wie dort — es wird in Schritt 2 der
     * Reihenfolge EINMAL fuer alle schreibenden Wege eingefuehrt, und dieser hier gehoert dann
     * mit in die Liste. Ein eigenes zweites Verfahren zu erfinden hiesse, dass es danach zwei gibt.
     *
     * Was hier NICHT passiert: der Schluessel wird nicht von selbst uebernommen. Ein Mensch muss
     * an diesem PC bestaetigen, dass die Aenderung erwartet war — sonst waere die Pinnung wertlos.
     */
    if (pathname === '/api/nachbarn/schluessel/bestaetigen') {
      if (!istLokal(req)) { res.writeHead(403); return res.end('nur lokal'); }
      if (req.method !== 'POST') { res.writeHead(405); return res.end('POST noetig'); }
      return leseKoerper(req, 2048, (k) => {
        let b = null; try { b = JSON.parse((k && k.text) || '{}'); } catch (_) {}
        if (!b || !b.sid) return jsonPrivat(res, { ok: false, fehler: 'Es fehlt die Stationskennung.' });
        if (!verbund.lan) return jsonPrivat(res, { ok: false, fehler: 'Der direkte Weg im Haus ist ausgeschaltet.' });
        return jsonPrivat(res, verbund.lan.bestaetigeSchluessel(String(b.sid)));
      });
    }
    // In-App-Update (§13): Status prüfen bzw. anwenden/stagen. Nur lokal erreichbar (Kiosk).
    if (pathname === '/api/update/check') { updater.check().then((r) => json(res, r)).catch((e) => json(res, { error: e.message })); return; }
    if (pathname === '/api/update/apply') { logger.info('update', 'Update angefordert (Admin).'); updater.apply().then((r) => { logger.info('update', r.msg || (r.ok ? 'ok' : 'fehlgeschlagen')); json(res, r); }).catch((e) => json(res, { ok: false, msg: e.message })); return; }
    if (pathname === '/api/version') return json(res, { version });
    if (pathname === '/healthz') return json(res, { ok: true, ts: Date.now() });

    // --- statische UI ---
    let rel = pathname === '/' ? '/index.html' : pathname;
    const filePath = path.normalize(path.join(UI_DIR, rel));
    if (!filePath.startsWith(UI_DIR)) { res.writeHead(403); return res.end('403'); }
    fs.readFile(filePath, (err, data) => {
      if (err) {
        // SPA-Fallback auf index.html
        if (path.extname(filePath) === '') {
          return fs.readFile(path.join(UI_DIR, 'index.html'), (e2, d2) => {
            if (e2) { res.writeHead(404); return res.end('404'); }
            res.writeHead(200, { 'Content-Type': MIME['.html'] }); res.end(d2);
          });
        }
        res.writeHead(404); return res.end('404 ' + rel);
      }
      const ext = path.extname(filePath).toLowerCase();
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(data);
    });
  }

  function json(res, obj) {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(obj));
  }

  /*
   * jsonPrivat — fuer alles, was Zugangsdaten, Anmeldezustand oder Patientenprotokolle enthaelt.
   *
   * Unterschied zu json(): KEIN "Access-Control-Allow-Origin: *". Diese Kopfzeile erlaubt jeder
   * fremden Webseite, die im Browser des Praxis-PCs offen ist, die Antwort dieser Adresse zu lesen
   * (fetch('http://127.0.0.1:8770/...')). Fuer die Geraeteanzeige ist das harmlos, fuer die
   * Anmeldung waere es ein Ausleseweg. Zusaetzlich verbietet no-store das Zwischenspeichern.
   */
  function jsonPrivat(res, obj) {
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(JSON.stringify(obj));
  }

  // Nur der Praxis-PC selbst. IPv6-Schreibweise von localhost (::1 bzw. ::ffff:127.0.0.1) mitdenken.
  function istLokal(req) {
    const a = (req.socket && (req.socket.remoteAddress || '')) || '';
    return istLokaleAdresse(a);
  }

  /*
   * DER GESAMTE ZUSTAND DES OP-SAALS IN EINER ANTWORT — fuer /api/station und als Nachtrag zu
   * jeder Aenderung, damit der Admin-Bereich nie aus einer eigenen Rechnung heraus etwas anderes
   * anzeigt als die Station wirklich weiss.
   *
   * 'name' kommt aus stationsName() und NUR daher (N10: genau EINE Namensquelle). null heisst
   * "kein Name" und ist ein gueltiger Zustand — die Oberflaeche macht daraus den sichtbaren
   * Hinweis der Erstinbetriebnahme, nicht einen erfundenen Namen.
   *
   * 'fern' IST NEU UND KEINE DREINGABE (Befund C2 der Gegenpruefung). Der Admin-Bereich sagte
   * bisher pauschal, der Name "erscheint in der Fern-Ansicht". Das stimmt nur, wenn Fern-Live
   * eingeschaltet UND das Praxis-Konto angemeldet ist; ohne beides verlaesst der Name diesen PC
   * nicht. Eine Bedingung, die nur im Kleingedruckten steht, liest im OP niemand — deshalb geht
   * der ZUSTAND dieser Bedingung mit heraus, und die Oberflaeche schreibt hin, was gerade gilt.
   * Gelesen wird ausschliesslich cloud.status(); der Server rechnet nichts nach, sonst gaebe es
   * ueber "sendet die Station?" wieder zwei Meinungen. Fehlt cloud (Fassungen ohne Fern-Live),
   * steht ueberall false — das ist die Wahrheit fuer diesen Fall.
   *
   * WAS HIER BEWUSST NICHT DRINSTEHT: der Rechnername (er verraet oft Praxis oder Tierarzt) und
   * alles, was mit dem privaten Schluessel zu tun hat — stationsid.js haelt ihn ausserhalb von
   * .daten, damit genau so eine Antwort ihn nicht versehentlich abwerfen kann. Und nichts aus
   * cloud.status() ausser den drei Wahrheitswerten: dort stehen Anmeldename und Freigabe-Adresse.
   */
  function fernLage() {
    let s = null;
    /* cloud kommt von aussen und ist in Tests ein Stellvertreter: ein fehlendes oder werfendes
     * status() darf die Auskunft ueber den eigenen Saal nicht kosten. Sie ist der Weg, auf dem ein
     * Mensch seinen Saalnamen ueberhaupt erst setzt. */
    try { if (cloud && typeof cloud.status === 'function') s = cloud.status(); } catch (_) { s = null; }
    if (!s || typeof s !== 'object') return { eingeschaltet: false, angemeldet: false, sendet: false };
    return { eingeschaltet: !!s.enabled, angemeldet: !!s.angemeldet, sendet: !!(s.enabled && s.started && s.angemeldet) };
  }

  function stationsAuskunft() {
    return {
      bereit: !!station.daten,
      sid: station.sid(),
      kurz: station.kurz(),
      fp: station.fp(),
      name: stationsName(station, vorbelegung()),
      gesetzt: station.hatNamen(),
      nameAm: station.nameGesetztAm(),
      nameMax: NAME_MAX,
      // Die Vorbelegung wird MITGESCHICKT, nicht heimlich benutzt: der Tierarzt soll sehen, woher
      // ein Vorschlag im Eingabefeld kommt.
      vorbelegung: typeof vorbelegung() === 'string' ? vorbelegung() : null,
      stand: station.kollisionsstand(),
      kollision: station.kollisionVermerk(),
      umbenanntVon: station.umbenanntVon(),
      fern: fernLage(),
    };
  }

  /*
   * Den Koerper einer POST-Anfrage einsammeln, gedeckelt.
   *
   * WARUM DIE VERBINDUNG BEI UEBERLAENGE NICHT WEGGERISSEN WIRD: ein req.destroy() ohne Antwort
   * laesst den Admin-Bereich in einem haengenden fetch stehen — der Tierarzt sieht dann einen
   * Knopf, der nichts tut und nichts sagt. Statt dessen wird ab dem Deckel nichts mehr gesammelt
   * (der Speicher ist damit begrenzt) und am Ende ehrlich mit einer Fehlermeldung geantwortet.
   * Auf 127.0.0.1 ist das die richtige Abwaegung.
   *
   * DER GRUND FUER DIE ZWEI FELDER STATT EINES null (Befund C4): frueher gab diese Funktion bei
   * Ueberlaenge null zurueck, der Aufrufer machte daraus JSON.parse(null || '{}') = {} — also
   * KEIN Formfehler — und der Tierarzt las "Bitte einen Saalnamen eingeben". Er hatte einen
   * eingegeben; er war nur zu lang. Die naechste Handlung nach so einer Meldung ist, denselben
   * Namen noch einmal einzutippen. Deshalb sagt der Rueckgabewert jetzt, WELCHER Fall vorliegt,
   * und der Aufrufer nennt den Grund. Die Zusage im Absatz darueber ("am Ende ehrlich mit einer
   * Fehlermeldung geantwortet") stimmt damit zum ersten Mal.
   *
   * UND EINE FRIST (derselbe Befund): ohne sie laesst eine POST-Verbindung, die 'end' nie sendet,
   * den Handler ohne Antwort stehen — der Knopf im Admin-Bereich bliebe fuer immer auf
   * "speichere…". Erreichbar ist das nur von 127.0.0.1, aber ein halboffener Socket entsteht auch
   * ohne boesen Willen (eingeschlafener Kiosk-Browser, abgebrochene Netzkarte). 10 s sind fuer
   * hoechstens 2048 Byte ueber die Rueckschleife reichlich; abgebaut wird die Frist in JEDEM Weg
   * hier heraus, damit kein Zeitgeber den Prozess am Leben haelt.
   */
  function leseKoerper(req, max, fertig) {
    let roh = '', zuGross = false, erledigt = false;
    const frist = setTimeout(() => einmal({ text: null, zuGross: false, zeitablauf: true }), 10000);
    /* unref(): ein wartender Zeitgeber darf das Programmende nicht aufhalten. */
    if (typeof frist.unref === 'function') frist.unref();
    function einmal(wert) {
      if (erledigt) return;
      erledigt = true;
      clearTimeout(frist);
      fertig(wert);
    }
    req.on('data', (c) => {
      if (zuGross) return;
      roh += c;
      if (roh.length > max) { zuGross = true; roh = ''; }
    });
    req.on('end', () => einmal({ text: zuGross ? null : roh, zuGross: zuGross, zeitablauf: false }));
    req.on('error', () => einmal({ text: null, zuGross: false, zeitablauf: false }));
  }

  /*
   * Firebase antwortet auf Anmeldefehler mit Kuerzeln wie INVALID_LOGIN_CREDENTIALS. Die haben auf
   * dem Bildschirm eines Tierarztes nichts verloren — hier steht, was zu tun ist.
   */
  function klartextFehler(msg) {
    const s = String(msg || '');
    if (/EMAIL_NOT_FOUND|INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD/i.test(s)) {
      return 'E-Mail oder Passwort stimmt nicht. Gross-/Kleinschreibung beim Passwort beachten.';
    }
    if (/USER_DISABLED/i.test(s)) return 'Dieses Praxis-Konto ist gesperrt.';
    if (/TOO_MANY_ATTEMPTS|RESET_PASSWORD/i.test(s)) return 'Zu viele Fehlversuche. Bitte einige Minuten warten.';
    if (/MISSING_PASSWORD|MISSING_EMAIL/i.test(s)) return 'Bitte E-Mail und Passwort eingeben.';
    if (/ENOTFOUND|EAI_AGAIN|Zeitueberschreitung/i.test(s)) return 'Keine Internetverbindung zum Anmeldedienst.';
    if (/apiKey/i.test(s)) return s;
    return s;
  }

  return {
    httpServer, ws, erstsuche, verbund,
    stop() {
      clearInterval(timer);
      if (cloudTimer) clearInterval(cloudTimer);
      clearInterval(fremdTimer);
      erstsuche.stop();
      /* Jeder Verbundbaustein einzeln und jeder in seinem eigenen Fang: ein Leser, der beim
       * Beenden wirft, darf den Port 8771 nicht offen und den Prozess nicht am Leben lassen. */
      if (verbund.abo) { try { verbund.abo.stop(); } catch (_) {} }
      if (verbund.lan) { try { verbund.lan.stop(); } catch (_) {} }
      ws.close();
      try { httpServer.close(); } catch (_) {}
    },
  };
}

// istLokaleAdresse ist mit ausgefuehrt, damit tools/saalname-test.js die Sperre gegen fremde
// Adressen ohne Netz pruefen kann — siehe die Begruendung dort oben.
module.exports = { startServer, istLokaleAdresse };
