'use strict';
/*
 * binaer-analyse.js — Reverse-Engineering-Hilfe fuer einen PROPRIETAEREN (nicht-HL7) Mindray-Datenstrom.
 *
 * HINTERGRUND (verifiziert 23.07.2026): Mindrays offene Schnittstellen (PDS/eGateway/A-Serie) sind
 * allesamt HL7 v2.3.1 ueber MLLP — Rahmen BEGINNT mit 0x0B (VT), ENDET mit 0x1C 0x0D (FS CR). Ein
 * Mitschnitt, der stattdessen mit 0x02 (STX) beginnt und das Sync-Wort 0xA5 0x5A traegt, ist KEIN
 * HL7, sondern das proprietaere Binaerprotokoll (Monitor <-> CentralStation/CMS). Dafuer existiert
 * KEIN oeffentlicher Decoder. Dieses Werkzeug zerlegt einen Mitschnitt in Rahmen und zeigt, welche
 * Byte-Positionen sich aendern (= moegliche Datenfelder) — die Grundlage fuers Reverse Engineering.
 *
 * SICHERHEIT: Dieses Werkzeug ordnet NIEMALS Bytes zu Vitalwerten (HF/SpO2/...) zu. In einem
 * Narkose-Monitor waere ein geratener Messwert gefaehrlicher als gar keiner. Es beschreibt nur die
 * STRUKTUR. Eine echte Feldzuordnung braucht einen VARIIERENDEN Mitschnitt (Werte am Geraet aendern)
 * und eine belastbare, gegen bekannte Referenzwerte gepruefte Ableitung.
 *
 * Aufruf:
 *   node tools/binaer-analyse.js [pfad-zum-mitschnitt]
 *   (ohne Pfad: neueste bridge/data/probe-*.log)
 */
const fs = require('fs');
const path = require('path');

const VT = 0x0b, STX = 0x02;

function neuesteProbeDatei() {
  const dir = path.join(__dirname, '..', 'bridge', 'data');
  let dateien = [];
  try {
    dateien = fs.readdirSync(dir)
      .filter((n) => /^probe-\d+\.log$/.test(n) || /^roh-\d+\.log$/.test(n) || /^hl7-raw\.log$/.test(n))
      .map((n) => ({ n, p: path.join(dir, n), t: fs.statSync(path.join(dir, n)).mtimeMs }))
      .sort((a, b) => b.t - a.t);
  } catch (_) {}
  return dateien.length ? dateien[0].p : null;
}

function hex(b) { return Buffer.from(b).toString('hex').replace(/(..)/g, '$1 ').trim(); }

// Modalwert (haeufigster) einer Zahlenliste.
function modal(list) {
  const c = {};
  list.forEach((x) => { c[x] = (c[x] || 0) + 1; });
  let best = null, bestN = 0;
  Object.keys(c).forEach((k) => { if (c[k] > bestN) { bestN = c[k]; best = Number(k); } });
  return { wert: best, anzahl: bestN };
}

function offsetsVon(buf, byteWert) {
  const out = [];
  for (let i = 0; i < buf.length; i++) if (buf[i] === byteWert) out.push(i);
  return out;
}

function analysiere(buf) {
  console.log('== Mitschnitt: ' + buf.length + ' Byte ==\n');
  if (!buf.length) { console.log('Leer.'); return; }

  // 1) HL7? Ein EINZELNES 0x0B reicht NICHT — ein Binaerstrom kann 0x0B als Datenbyte enthalten.
  // Echtes MLLP hat 0x0B DIREKT gefolgt von "MSH". Wir verlangen daher "MSH|" (roh) oder VT+MSH.
  const hatMSH = buf.indexOf(Buffer.from('MSH|')) >= 0;
  let mllp = false;
  for (let idx = buf.indexOf(VT); idx >= 0 && !mllp; idx = buf.indexOf(VT, idx + 1)) {
    if (buf.slice(idx + 1, idx + 4).toString('latin1') === 'MSH') mllp = true;
  }
  if (mllp || hatMSH) {
    console.log('BEFUND: Das sieht nach HL7 aus' + (mllp ? ' (MLLP: 0x0B direkt gefolgt von MSH)' : ' (Klartext "MSH|" gefunden)') + '.');
    console.log('-> Kein Binaer-Reverse-Engineering noetig. VetStation liest HL7 direkt (probe/hl7-Adapter).');
    console.log('   Erste 48 Byte: ' + hex(buf.slice(0, 48)));
    return;
  }

  // 2) Binaerstrom. Framing ueber STX (0x02) und/oder Sync-Wort 0xA5 0x5A bestimmen.
  const stx = offsetsVon(buf, STX);
  const syncOffsets = [];
  for (let i = 0; i + 1 < buf.length; i++) if (buf[i] === 0xa5 && buf[i + 1] === 0x5a) syncOffsets.push(i);

  console.log('BEFUND: KEIN HL7 (kein 0x0B, kein "MSH|"). Proprietaerer Binaerstrom.');
  console.log('  Startbyte 0x02 (STX) an ' + stx.length + ' Stellen; Sync-Wort A5 5A an ' + syncOffsets.length + ' Stellen.');
  console.log('  Erste 48 Byte: ' + hex(buf.slice(0, 48)) + '\n');

  // Rahmenlaenge robust bestimmen. Wichtig: STX (0x02) taucht oft AUCH in der Nutzlast auf und ist
  // daher als Anker unzuverlaessig. Deshalb in dieser Reihenfolge:
  //   (a) Abstand aufeinanderfolgender Sync-Woerter A5 5A (starker, seltener Anker),
  //   (b) Autokorrelation (kleinste Periode P mit buf[i]==buf[i+P] fuer fast alle i),
  //   (c) STX-Abstaende als letzter Rueckfall.
  function gapModal(offsets) {
    if (offsets.length < 3) return null;
    const gaps = [];
    for (let i = 1; i < offsets.length; i++) gaps.push(offsets[i] - offsets[i - 1]);
    const m = modal(gaps);
    return m.wert ? { len: m.wert, frac: m.anzahl / gaps.length } : null;
  }
  function bestePeriode(maxP) {
    let best = null, bestScore = 0;
    for (let p = 1; p <= maxP && p < buf.length; p++) {
      let match = 0, tot = 0;
      for (let i = 0; i + p < buf.length; i++) { tot++; if (buf[i] === buf[i + p]) match++; }
      const score = tot ? match / tot : 0;
      if (score > bestScore + 1e-9) { bestScore = score; best = p; }   // strikt > : kleinste Periode gewinnt
    }
    return best ? { len: best, score: bestScore } : null;
  }

  let frameLen = null, quelle = '';
  const sync = gapModal(syncOffsets);
  if (sync && sync.frac >= 0.6) { frameLen = sync.len; quelle = 'Sync-Wort-Abstand'; }
  if (!frameLen) { const ac = bestePeriode(Math.min(256, buf.length >> 1)); if (ac && ac.score >= 0.85) { frameLen = ac.len; quelle = 'Autokorrelation (Wiederholung ' + Math.round(ac.score * 100) + '%)'; } }
  if (!frameLen) { const s = gapModal(stx); if (s && s.frac >= 0.6) { frameLen = s.len; quelle = 'STX-Abstand'; } }

  if (!frameLen || frameLen < 2) {
    console.log('Keine regelmaessige Rahmenlaenge erkennbar. Vermutlich variable Rahmen oder zu wenig Daten.');
    console.log('-> Groesseren Mitschnitt aufnehmen (mehrere Sekunden Live-Betrieb) und erneut analysieren.');
    return;
  }

  // Beste Ausrichtung im Fenster [0, frameLen): jene, bei der die meisten Byte-Positionen ueber alle
  // Rahmen KONSTANT sind (ein Fixformat-Rahmen hat konstante Rahmen-/Framing-Bytes). Gleichstand:
  // Start bevorzugen, dessen erstes Byte 0x02 (STX) ist.
  function konstanteStellen(start) {
    const fr = [];
    for (let i = start; i + frameLen <= buf.length; i += frameLen) fr.push(buf.slice(i, i + frameLen));
    if (fr.length < 2) return -1;
    let k = 0;
    for (let off = 0; off < frameLen; off++) { let konst = true; for (let j = 1; j < fr.length; j++) if (fr[j][off] !== fr[0][off]) { konst = false; break; } if (konst) k++; }
    return k;
  }
  let startBei = 0, bestK = -1;
  for (let s = 0; s < frameLen; s++) { const k = konstanteStellen(s); if (k > bestK || (k === bestK && buf[s] === STX && buf[startBei] !== STX)) { bestK = k; startBei = s; } }

  const frames = [];
  for (let i = startBei; i + frameLen <= buf.length; i += frameLen) frames.push(buf.slice(i, i + frameLen));
  console.log('Rahmenlaenge (' + quelle + '): ' + frameLen + ' Byte  ->  ' + frames.length + ' Rahmen ab Offset ' + startBei + '.\n');

  // Verschiedene Rahmen zaehlen.
  const distinct = {};
  frames.forEach((f) => { const h = f.toString('hex'); distinct[h] = (distinct[h] || 0) + 1; });
  const distinctKeys = Object.keys(distinct);
  console.log('Verschiedene Rahmen: ' + distinctKeys.length + ' (von ' + frames.length + ').');
  distinctKeys.slice(0, 8).sort((a, b) => distinct[b] - distinct[a]).forEach((h) => {
    console.log('   ×' + distinct[h] + '  ' + hex(Buffer.from(h, 'hex')));
  });
  console.log('');

  // Pro Byte-Position: wie viele verschiedene Werte? (variabel = moegliches Datenfeld)
  const variabel = [];
  for (let off = 0; off < frameLen; off++) {
    const werte = new Set();
    frames.forEach((f) => werte.add(f[off]));
    if (werte.size > 1) variabel.push({ off, n: werte.size, beispiele: Array.from(werte).slice(0, 6) });
  }

  if (distinctKeys.length === 1) {
    console.log('URTEIL: Alle ' + frames.length + ' Rahmen sind IDENTISCH.');
    console.log('  Das ist ein konstantes Keepalive/Handshake/Sync — es enthaelt KEINE Vitaldaten.');
    console.log('  -> Fuer echte Werte den Datenstrom AM PORT 8830 waehrend laufender Messung mitschneiden');
    console.log('     (Sensoren am Patienten, Werte am Monitor sichtbar). Erst ein VARIIERENDER Mitschnitt');
    console.log('     laesst Datenfelder erkennen.');
    return;
  }

  console.log('URTEIL: Rahmen VARIIEREN — es steckt Nutzlast drin.');
  console.log('  Veraenderliche Byte-Positionen (Kandidaten fuer Datenfelder):');
  variabel.forEach((v) => {
    console.log('   Offset ' + String(v.off).padStart(2, '0') + ': ' + v.n + ' verschiedene Werte  z.B. ' +
      v.beispiele.map((x) => x.toString(16).padStart(2, '0')).join(' '));
  });
  console.log('');
  console.log('NAECHSTER SCHRITT (Reverse Engineering, sicher):');
  console.log('  1. Am Geraet EINEN Wert gezielt aendern (z.B. HF ueber SpO2-Simulator) und dabei mitschneiden.');
  console.log('  2. Pruefen, an welchem Offset sich der Zahlenwert genau mitbewegt (Little-/Big-Endian, 1/2 Byte).');
  console.log('  3. Erst wenn die Zuordnung gegen bekannte Referenzwerte belegt ist, in einen Adapter giessen.');
  console.log('  VetStation zeigt NIE einen geratenen Messwert an — lieber eine ehrliche Luecke.');
}

const ziel = process.argv[2] || neuesteProbeDatei();
if (!ziel) { console.log('Kein Mitschnitt gefunden. Aufruf: node tools/binaer-analyse.js <datei>'); process.exit(1); }
console.log('Analysiere: ' + ziel + '\n');
let buf;
try { buf = fs.readFileSync(ziel); } catch (e) { console.log('Kann Datei nicht lesen: ' + e.message); process.exit(1); }
analysiere(buf);
