'use strict';
/*
 * doppelstart-test.js — was passiert, wenn VetStation ein ZWEITES Mal gestartet wird?
 *
 * WOFUER: Bis 1.0.3 stand dafuer eine einzige Zeile im Code — der Fehler wurde protokolliert und
 * der Prozess lief WEITER. Vollstaendig weiter: er nahm Geraetedaten an, fuehrte das
 * Narkoseprotokoll und sendete in die Fern-Ansicht, nur ohne Oberflaeche. Zwei solche Prozesse
 * schreiben dieselbe bridge/data/protokoll.json alle 5 s im Wechsel — der letzte gewinnt, Eintraege
 * gehen verloren — und senden in denselben Datenknoten. Der haeufigste Weg dorthin ist ganz
 * gewoehnlich: der Autostart hat die Station schon geoeffnet, und jemand klickt zusaetzlich auf
 * START-VetStation.bat.
 *
 * Die naheliegende Loesung waere, sich beim belegten Port sofort zu beenden. Die ist GENAUSO falsch:
 * der Kiosk-PC startet VetStation ueber den Autostart bei der Anmeldung. Beendete sich der Prozess,
 * weil beim Neustart der alte noch ein paar Sekunden am Port haengt, startete nichts mehr nach —
 * moeglicherweise mitten in einer Narkose.
 *
 * DESHALB PRUEFT DIESER TEST BEIDE RICHTUNGEN, und beide muessen stimmen:
 *   1. Echter Doppelstart (eine VetStation antwortet auf /healthz) -> der zweite beendet sich,
 *      der erste laeuft unbeschadet weiter.
 *   2. Ein FREMDES Programm haelt den Port -> die Station beendet sich NICHT, sondern arbeitet
 *      ohne Oberflaeche weiter und sagt im Klartext, was zu tun ist.
 *
 * Start: node tools/doppelstart-test.js      (laeuft auch in `node tools/alle-tests.js`)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');

const ROOT = path.join(__dirname, '..');
const NODE = process.execPath;
const INDEX = path.join(ROOT, 'bridge', 'src', 'index.js');
const CFG = path.join(ROOT, 'bridge', 'config', 'devices.json');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

/*
 * SICHERHEITSHALT: dieser Test legt eine devices.json an. Existiert dort schon eine, gehoert sie
 * dem Kunden — dann wird NICHT getestet. Eine ueberschriebene Geraetekonfiguration waere ein
 * Schaden, der jeden Testnutzen uebersteigt.
 */
if (fs.existsSync(CFG)) {
  console.log('VetStation — Doppelstart\n');
  console.log('  ⚠ bridge/config/devices.json existiert bereits — dieser Test legt keine an und');
  console.log('    ueberschreibt nichts. Zum Pruefen die Datei kurz beiseitelegen.');
  process.exit(0);
}

const kinder = [];
function aufraeumen() {
  kinder.forEach((k) => { try { k.kill(); } catch (_) {} });
  try { if (fs.existsSync(CFG)) fs.unlinkSync(CFG); } catch (_) {}
}
['exit', 'SIGINT', 'SIGTERM', 'SIGHUP'].forEach((s) => process.on(s, () => { aufraeumen(); if (s !== 'exit') process.exit(1); }));

function warte(ms) { return new Promise((r) => setTimeout(r, ms)); }

function frage(port, pfad) {
  return new Promise((resolve) => {
    const req = http.request({ host: '127.0.0.1', port: port, path: pfad, timeout: 1500 }, (r) => {
      let s = ''; r.on('data', (c) => { s += c; });
      r.on('end', () => resolve({ code: r.statusCode, text: s, kopf: r.headers }));
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
    req.end();
  });
}

function starteStation(port, log) {
  fs.writeFileSync(CFG, JSON.stringify({
    port: port, host: '127.0.0.1',
    _hinweis: 'von tools/doppelstart-test.js angelegt, wird am Ende geloescht',
    cloud: { enabled: false },
    adapters: [{ type: 'simulator', id: 'sim', enabled: true, rateMs: 1000 }],
  }), 'utf8');
  const k = spawn(NODE, [INDEX], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'] });
  kinder.push(k);
  k.stdout.on('data', (d) => log.push(String(d)));
  k.stderr.on('data', (d) => log.push(String(d)));
  k.beendetMit = null;
  k.on('exit', (c) => { k.beendetMit = c; });
  return k;
}

/* Auf eine Bedingung warten statt fest zu schlafen — sonst haengt der Test an der Tagesform des PCs. */
async function bisMax(ms, pruefe) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { if (await pruefe()) return true; await warte(200); }
  return false;
}

(async () => {
  console.log('VetStation — Doppelstart (zwei Programme, ein Narkoseprotokoll)\n');

  // Zwei Ports, die niemand sonst benutzt: die Station selbst haengt auf 8770.
  const P1 = 8791, P2 = 8792;

  /* ---------------- 1) Echter Doppelstart ---------------- */
  console.log('Ein zweiter Start derselben Station:');
  const log1 = [];
  const erste = starteStation(P1, log1);
  const da = await bisMax(15000, async () => !!(await frage(P1, '/healthz')));
  ok('die erste Station laeuft und beantwortet /healthz', da, log1.join('').slice(-200));

  const gesund = await frage(P1, '/healthz');
  let j = null; try { j = JSON.parse(gesund.text); } catch (_) {}
  ok('/healthz sagt, dass hier eine VetStation sitzt', !!(j && j.vetstation === true), gesund && gesund.text);
  ok('/healthz nennt Prozesskennung und Startzeit', !!(j && j.pid && j.seit), gesund && gesund.text);
  /* Ohne diese Kopfzeile kann keine fremde Webseite im Praxis-Browser die Antwort auslesen —
   * sie nennt eine Prozesskennung und den Betriebsstand. */
  ok('/healthz traegt KEIN "Access-Control-Allow-Origin"',
    !(gesund.kopf && gesund.kopf['access-control-allow-origin']),
    String(gesund.kopf && gesund.kopf['access-control-allow-origin']));

  const log2 = [];
  const zweite = starteStation(P1, log2);
  const beendet = await bisMax(20000, async () => zweite.beendetMit !== null);
  ok('der zweite Start beendet sich', beendet, 'Rueckgabewert: ' + zweite.beendetMit);
  ok('und zwar mit einem Fehler-Rueckgabewert (nicht stillschweigend)', zweite.beendetMit === 1,
    String(zweite.beendetMit));
  ok('er sagt im Klartext, dass VetStation bereits laeuft',
    /bereits/i.test(log2.join('')), log2.join('').slice(-220));
  ok('er nennt die Adresse der laufenden Station',
    log2.join('').indexOf('127.0.0.1:' + P1) >= 0, log2.join('').slice(-220));
  /*
   * Die wichtigste Pruefung dieses Abschnitts: der BEREITS LAUFENDE Prozess darf vom zweiten Start
   * nichts abbekommen. Wuerde er mit beendet, haette die Praxis mitten in der Narkose keinen
   * Bildschirm mehr — und der Doppelstart waere schlimmer als das Problem, das er loesen soll.
   */
  const nochDa = await frage(P1, '/api/state');
  ok('die ERSTE Station laeuft unbeschadet weiter', !!(nochDa && nochDa.code === 200),
    nochDa ? String(nochDa.code) : 'keine Antwort');
  ok('die erste Station wurde nicht mit beendet', erste.beendetMit === null, String(erste.beendetMit));

  try { erste.kill(); } catch (_) {}
  await warte(600);

  /* ---------------- 2) Ein FREMDES Programm haelt den Port ---------------- */
  console.log('\nEin fremdes Programm haelt den Port:');
  const fremd = http.createServer((q, r) => { r.writeHead(200); r.end('ich bin nicht VetStation'); });
  await new Promise((r) => fremd.listen(P2, '127.0.0.1', r));

  const log3 = [];
  const dritte = starteStation(P2, log3);
  /* Drei Versuche im Abstand von 2 s, dann die Klartextmeldung — also nach gut 8 s entschieden. */
  const gemeldet = await bisMax(25000, async () => /dauerhaft von einem ANDEREN Programm/i.test(log3.join('')));
  ok('die Station meldet den fremden Belegtstand im Klartext', gemeldet, log3.join('').slice(-260));
  ok('sie versucht es vorher mehrfach', (log3.join('').match(/Versuch \d von 3/g) || []).length >= 2,
    String((log3.join('').match(/Versuch \d von 3/g) || []).length));
  ok('sie nennt den Weg zur Ursache (netstat)', /netstat/i.test(log3.join('')));
  /*
   * Und hier NICHT beenden: der Geraeteempfang und die Fern-Uebertragung sind wichtiger als der
   * Bildschirm. Beendete sich die Station, weil irgendein Programm den Port belegt, stuende die
   * Praxis ohne Ueberwachung da.
   */
  ok('die Station beendet sich NICHT (Geraete und Fern-Live laufen weiter)', dritte.beendetMit === null,
    'Rueckgabewert: ' + dritte.beendetMit);

  try { dritte.kill(); } catch (_) {}
  await new Promise((r) => fremd.close(r));
  aufraeumen();

  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
})().catch((e) => { console.error('TESTFEHLER: ' + e.message); aufraeumen(); process.exit(1); });
