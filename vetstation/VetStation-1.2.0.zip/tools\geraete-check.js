'use strict';
/*
 * geraete-check.js — VERBINDUNGS-CHECK fuer die Praxis (an den ECHTEN Geraeten).
 *
 * Beantwortet die Frage: "Warum kommen keine Werte an — und was mache ich jetzt?"
 *
 * Er benutzt GENAU DIESELBEN Bausteine wie die laufende Station, damit Check und App nie
 * Verschiedenes behaupten koennen:
 *   bridge/src/netscan.js    aktive Suche .1-.254 + Portscan + Einstufung MIT BEGRUENDUNG
 *   bridge/src/firewall.js   Zustand der Windows-Firewall AUSLESEN (nicht nur empfehlen)
 *   bridge/src/diagnose.js   rangierte Ursachen im Klartext + konkreter naechster Schritt
 *
 * Ablauf:
 *   1. Dieser PC im Netz (welche Adresse traegt man am Geraet ein?)
 *   2. Aktive Suche im gesamten Netz — jede Adresse wird angesprochen
 *   3. Windows-Firewall: je Port ausgelesen (frei / FEHLT / unklar — nie geraten)
 *   4. Lauschphase: faengt Geraete, die von sich aus senden
 *   5. ERGEBNIS: wo das Problem liegt, in der Reihenfolge der Wahrscheinlichkeit
 *
 * STRIKT READ-ONLY: es wird nur angeklopft und gelauscht, nie etwas am Geraet verstellt.
 *
 * Start am PRAXIS-PC:  GERAETE-PRUEFEN.bat doppelklicken (Ordner C:\VetStation oder Startmenue).
 *                      Mit IP:  GERAETE-PRUEFEN.bat 192.168.0.50
 *                      Dort gibt es kein npm und kein node in PATH - nur node\node.exe.
 */
const net = require('net');
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const netscan = require('../bridge/src/netscan');
const firewall = require('../bridge/src/firewall');
const { diagnose, ZIEL } = require('../bridge/src/diagnose');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
const PORTS = netscan.DATA_PORTS;
const LISTEN_SECONDS = 20;

function line(c) { console.log((c || '-').repeat(74)); }
function h(t) { console.log('\n' + t); line(); }
function mllp(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }

/*
 * Sendet QRY^R02 (reine DATEN-ABFRAGE, keine Steuerung) und prueft die Antwort.
 *
 * WARUM HIER EINE HARTE FRIST STEHT (Praxis-Befund 22.07.2026):
 * Am Praxis-PC blieb der Check bei "HL7-Abfrage auf Port 4601 ..." stehen und gab NIE ein
 * Ergebnis aus. Ursache: s.setTimeout() ist eine LEERLAUF-Frist. Schickt ein Geraet dauernd
 * Daten, die kein "MSH" enthalten - genau das tut ein Mindray-Geraet, das auf diesem Port sein
 * proprietaeres MD2 spricht -, wird der Leerlauf-Timer bei jedem Paket zurueckgesetzt. Das
 * 'timeout'-Ereignis kam damit nie, fin() wurde nie aufgerufen, und das Versprechen loeste sich
 * nie auf. Fuer den Anwender sah das aus wie ein Absturz.
 *
 * Jetzt: eine Frist, die UNABHAENGIG vom Datenverkehr laeuft. Und wenn Daten kommen, die kein
 * HL7 sind, ist das keine Zeitueberschreitung, sondern ein WERTVOLLER BEFUND - er wird als
 * solcher gemeldet (samt der ersten Bytes), statt verschluckt zu werden.
 */
function pdsHandshake(host, port, ms) {
  const frist = ms || 6000;
  return new Promise((resolve) => {
    const s = new net.Socket(); let buf = Buffer.alloc(0); let done = false;
    let bytes = 0, verbunden = false;
    const fin = (r) => {
      if (done) return; done = true;
      clearTimeout(hart);
      try { s.destroy(); } catch (_) {}
      resolve(r);
    };
    // HARTE Obergrenze: loest IMMER auf, egal was auf der Leitung passiert.
    const hart = setTimeout(() => {
      if (bytes > 0) {
        fin({
          ok: false, antwortet: true, keinHl7: true,
          grund: 'antwortet, aber KEIN HL7 (' + bytes + ' Bytes empfangen, Anfang: ' +
                 buf.slice(0, 12).toString('hex') + ') — vermutlich ein proprietaeres Protokoll (z. B. Mindray MD2)',
        });
      } else if (verbunden) {
        fin({ ok: false, antwortet: true, grund: 'Verbindung steht, aber das Geraet sendet nichts (Datenausgabe am Geraet aus?)' });
      } else {
        fin({ ok: false, grund: 'keine Antwort (Zeitueberschreitung nach ' + Math.round(frist / 1000) + ' s)' });
      }
    }, frist);

    s.setTimeout(frist);
    s.once('error', () => fin({ ok: false, grund: 'Verbindung abgelehnt' }));
    s.once('timeout', () => fin({ ok: false, grund: 'keine Antwort (Zeitueberschreitung)' }));
    s.connect(port, host, () => {
      verbunden = true;
      try { s.write(mllp('MSH|^~\\&|VetStation|||||' + new Date().toISOString().replace(/\D/g, '').slice(0, 14) + '||QRY^R02|1|P|2.3.1')); } catch (_) {}
    });
    s.on('data', (c) => {
      bytes += c.length;
      if (buf.length < 65536) buf = Buffer.concat([buf, c]);   // Speicher begrenzen
      const txt = buf.toString('latin1');
      if (txt.indexOf('MSH') < 0) return;                       // die harte Frist faengt das jetzt ab
      const start = buf.indexOf(VT), end = buf.indexOf(FS);
      const payload = (start >= 0 && end > start) ? buf.slice(start + 1, end).toString('latin1') : txt;
      let frame = null; try { frame = parseHL7Message(payload, { deviceId: 'check', model: host }); } catch (_) {}
      const v = (frame && frame.vitals) || {};
      const werte = ['hr', 'spo2', 'etco2', 'af', 'temp'].filter((k) => v[k] != null).map((k) => k.toUpperCase() + '=' + v[k]);
      if (v.nibp && v.nibp.sys != null) werte.push('NIBP=' + v.nibp.sys + '/' + v.nibp.dia);
      fin({ ok: true, hl7: true, werte: werte });
    });
  });
}

// Lauscht auf allen Kandidaten-Ports: faengt Geraete, die VON SICH AUS senden.
function listenPhase(seconds) {
  return new Promise((resolve) => {
    const hits = []; const servers = []; const belegt = [];
    PORTS.forEach((port) => {
      const srv = net.createServer((sock) => {
        const ip = (sock.remoteAddress || '').replace('::ffff:', '');
        let buf = Buffer.alloc(0);
        sock.on('error', () => {});
        sock.on('data', (c) => {
          buf = Buffer.concat([buf, c]);
          const txt = buf.toString('latin1');
          if (txt.indexOf('MSH') >= 0 && !hits.some((x) => x.ip === ip && x.port === port)) {
            const start = buf.indexOf(VT), end = buf.indexOf(FS);
            const payload = (start >= 0 && end > start) ? buf.slice(start + 1, end).toString('latin1') : txt;
            let frame = null; try { frame = parseHL7Message(payload, { deviceId: 'x', model: ip }); } catch (_) {}
            const v = (frame && frame.vitals) || {};
            hits.push({ ip: ip, port: port, hl7: true, werte: ['hr', 'spo2', 'etco2', 'af'].filter((k) => v[k] != null).map((k) => k.toUpperCase() + '=' + v[k]) });
          } else if (buf.length > 8 && !hits.some((x) => x.ip === ip && x.port === port)) {
            hits.push({ ip: ip, port: port, hl7: false, roh: buf.slice(0, 16).toString('hex') });
          }
        });
      });
      srv.on('error', (e) => { if (e.code === 'EADDRINUSE') belegt.push(port); });
      try { srv.listen(port); servers.push(srv); } catch (_) {}
    });
    setTimeout(() => { servers.forEach((s) => { try { s.close(); } catch (_) {} }); resolve({ hits: hits, belegt: belegt }); }, seconds * 1000);
  });
}

const ZEICHEN = { sicher: '✓', moeglich: '?', unwahrscheinlich: '·', selbst: '▣' };
const STUFENTEXT = { sicher: 'SICHER ein Geraet', moeglich: 'moeglich', unwahrscheinlich: 'unwahrscheinlich', selbst: 'dieser PC' };

async function run() {
  const argHosts = process.argv.slice(2).filter((a) => /^\d+\.\d+\.\d+\.\d+$/.test(a));
  console.log('\n==============================================================================');
  console.log('  VetStation - VERBINDUNGS-CHECK');
  console.log('  Sucht die Geraete selbst und sagt, WO das Problem liegt.');
  console.log('  Nur lesend - es wird nichts am Geraet verstellt.');
  console.log('==============================================================================');

  /* ---------------- 1) Dieser PC ---------------- */
  h('1) Dieser PC im Netzwerk');
  const ips = netscan.localAdapters();
  if (!ips.length) console.log('  ! KEINE Netzwerkverbindung gefunden. LAN-Kabel/Switch pruefen!');
  ips.forEach((i) => console.log('  - ' + i.name + ': IP ' + i.address + '  (Maske ' + i.netmask + ', MAC ' + i.mac + ')'
    + (i.virtuell ? '   <- virtuell/VPN, NICHT verwenden' : '')));
  const empfohlen = ips.find((i) => !i.virtuell) || ips[0];
  console.log('\n  -> DIESE IP traegst du am Geraet als "Serveradresse"/"Server IP" ein:  '
    + (empfohlen ? empfohlen.address : '(keine IP!)'));

  /* ---------------- 2) Aktive Suche ---------------- */
  h('2) Aktive Suche im Netz (jede Adresse wird angesprochen)');
  console.log('  Das dauert je nach Netz einige Sekunden bis etwa eine Minute. Frueher wurde nur die');
  console.log('  ARP-Tabelle gelesen - ein FRISCH angestecktes Geraet steht dort noch gar nicht drin.\n');
  let letzteZeile = '';
  const scan = await netscan.scan({
    onProgress: (p) => {
      if (p.text === letzteZeile) return;
      letzteZeile = p.text;
      process.stdout.write('\r  ' + p.text.padEnd(60));
    },
  });
  process.stdout.write('\r' + ' '.repeat(66) + '\r');
  console.log('  Fertig in ' + Math.round(scan.dauerMs / 1000) + ' s.\n');

  if (!scan.hosts.length) {
    console.log('  Kein Geraet im Netz gefunden - es hat KEINE einzige Adresse geantwortet.');
  } else {
    scan.hosts.forEach((x) => {
      console.log('  ' + (ZEICHEN[x.stufe] || '?') + ' ' + x.ip.padEnd(16) + STUFENTEXT[x.stufe]);
      (x.gruende || []).forEach((g) => console.log('      ' + g));
    });
  }
  if (!scan.arpOk) console.log('\n  (Hinweis: die MAC-Tabelle war nicht lesbar - Herstellerangaben fehlen deshalb.)');

  // Was trage ich am GERAET bei Gateway und DNS ein? Diese Frage stellt sich bei jeder
  // Inbetriebnahme - die Antwort haengt allein davon ab, ob ein Router im Netz haengt.
  // Deshalb beantwortet der Check sie hier selbst, statt sie offenzulassen.
  const router = scan.hosts.find((x) => x.istGateway);
  console.log('\n  -> Am GERAET bei "Gateway" und "Bevorzugter DNS-Server" eintragen:');
  if (router) {
    console.log('     Gateway ' + router.ip + '  ·  DNS ' + router.ip + '   (ein Router antwortet auf ' + router.ip + ')');
  } else {
    console.log('     Gateway 0.0.0.0  ·  DNS 0.0.0.0   (kein Router im Netz - eigener Switch)');
    console.log('     Beides ist fuer die Datenverbindung ohnehin ohne Bedeutung: VetStation wird');
    console.log('     ueber die ZAHL ' + (empfohlen ? empfohlen.address : 'der PC-IP') + ' angesprochen, nicht ueber einen Namen.');
  }

  /* ---------------- 3) Firewall ---------------- */
  h('3) Windows-Firewall (ohne Freigabe verwirft Windows die Daten LAUTLOS)');
  const fw = await firewall.pruefe().catch(() => null);
  if (!fw) {
    console.log('  ? Zustand nicht lesbar. Zur Sicherheit FIREWALL-FREIGEBEN.bat doppelklicken.');
  } else {
    fw.ports.forEach((p) => {
      const t = p.zustand === 'frei'
        ? '✓ freigegeben' + (p.anzahl > 1 ? '  (' + p.anzahl + ' Regeln - doppelter Altbestand)' : '')
        : (p.zustand === 'fehlt' ? '✗ FEHLT' : '? unklar (nicht lesbar - das heisst NICHT "in Ordnung")');
      console.log('  TCP ' + String(p.port).padEnd(6) + t);
    });
    if (fw.fehlend.length || fw.doppelt.length) console.log('\n  -> Reparieren: FIREWALL-FREIGEBEN.bat doppelklicken.');
  }

  /* ---------------- 4) Geraete direkt befragen ---------------- */
  const kandidaten = scan.hosts.filter((x) => x.stufe === 'sicher').map((x) => x.ip);
  argHosts.forEach((a) => { if (kandidaten.indexOf(a) < 0) kandidaten.push(a); });
  const ergebnisse = [];
  const proprietaer = [];   // Geraete, die antworten, aber kein HL7 sprechen (z. B. Mindray MD2)
  if (kandidaten.length) {
    h('4) HL7-Abfrage je Geraet');
    for (const host of kandidaten) {
      console.log('\n  > Geraet ' + host);
      const treffer = scan.hosts.find((x) => x.ip === host);
      const offen = (treffer && treffer.datenPorts) || [];
      const zuPruefen = offen.length ? offen : PORTS;
      console.log('    Offene Datenports: ' + (offen.length ? offen.join(', ') : '- keiner von ' + PORTS.join('/')));
      let hl7 = null;
      for (const p of zuPruefen) {
        process.stdout.write('    HL7-Abfrage auf Port ' + p + ' ... ');
        const r = await pdsHandshake(host, p, offen.length ? 6000 : 1500);
        if (r.ok && r.hl7) {
          console.log('✓ HL7 ERKANNT' + (r.werte.length ? '  [' + r.werte.join(' ') + ']' : ' (Nachricht ohne Messwerte)'));
          hl7 = { port: p, werte: r.werte }; break;
        }
        console.log('✗ ' + (r.grund || 'kein HL7'));
        if (r.keinHl7) proprietaer.push({ ip: host, port: p });
      }
      ergebnisse.push({ host: host, offen: offen, hl7: hl7 });
    }
  }

  /* ---------------- 5) Lauschphase ---------------- */
  h('5) Lauschphase (' + LISTEN_SECONDS + ' s) - Geraete, die von sich aus senden');
  console.log('  Jetzt am Geraet die Datenuebertragung einschalten');
  console.log('  (Serveradresse = ' + (empfohlen ? empfohlen.address : 'PC-IP') + ', Port ' + ZIEL.port + ').');
  // Sichtbarer Fortschritt: ohne ihn sieht eine 20-Sekunden-Wartezeit aus wie ein Absturz -
  // und genau so wurde sie am Praxis-PC gedeutet.
  let restSek = LISTEN_SECONDS;
  const ticker = setInterval(() => {
    restSek--;
    if (restSek >= 0) process.stdout.write('\r  Lausche ... noch ' + restSek + ' s   ');
  }, 1000);
  const { hits, belegt } = await listenPhase(LISTEN_SECONDS);
  clearInterval(ticker);
  process.stdout.write('\r' + ' '.repeat(40) + '\r');
  if (belegt.length) console.log('  ! Ports von einem anderen Programm belegt: ' + belegt.join(', ') +
    '\n    (Laeuft VetStation gerade? Dann ist das NORMAL - die Station hoert dort selbst zu.)');
  if (hits.length) hits.forEach((x) => console.log('  ✓ ' + x.ip + ' sendet auf Port ' + x.port +
    (x.hl7 ? '  -> HL7 ERKANNT [' + x.werte.join(' ') + ']' : '  -> unbekanntes Format (hex ' + x.roh + ')')));
  else console.log('  - kein Geraet hat von sich aus gesendet.');

  /* ---------------- 6) Urteil ---------------- */
  const empfaengt = ergebnisse.some((e) => e.hl7) || hits.some((x) => x.hl7);
  const lage = diagnose({
    scan: scan,
    firewall: fw,
    empfang: { aktiv: empfaengt, geraete: ergebnisse.filter((e) => e.hl7).length + hits.filter((x) => x.hl7).length, letzteDatenVorMs: empfaengt ? 0 : null },
    // Belegte Ports sind hier KEIN Fehler: meist hoert die eigene Station schon zu.
    fremdBelegt: [],
    proprietaer: proprietaer,
  });

  h('6) ERGEBNIS');
  console.log('  ' + (lage.urteil === 'ok' ? '[OK]     ' : lage.urteil === 'problem' ? '[PROBLEM]' : '[UNKLAR] ') + ' ' + lage.kurz + '\n');

  const zeigen = lage.befunde.filter((x) => x.code !== 'EMPFANG_OK');
  if (!zeigen.length) {
    console.log('  Nichts weiter zu tun.');
  } else {
    console.log('  Wo das Problem liegen kann - wahrscheinlichste Ursache zuerst:\n');
    zeigen.forEach((x, i) => {
      const marke = x.schwere >= 3 ? 'BLOCKIERT   ' : (x.schwere === 2 ? 'WAHRSCHEINL.' : 'Hinweis     ');
      console.log('  ' + (i + 1) + '. [' + marke + '] ' + x.titel);
      console.log('     ' + x.warum.replace(/\s+/g, ' '));
      x.tun.forEach((t) => console.log('     -> ' + t));
      console.log('');
    });
  }

  console.log('  Dasselbe jederzeit IN der App: Admin -> "Netzwerk & Geraete" -> "Netzwerk jetzt durchsuchen".');
  console.log('  Rohdaten-Mitschnitt fuer die Analyse: in devices.json beim Adapter "rawLog": true');
  console.log('  -> schreibt data/hl7-raw.log. Details: docs/MINDRAY-HL7.md\n');
  process.exit(lage.urteil === 'ok' ? 0 : 1);
}

run().catch((e) => { console.error('Fehler im Check:', e.message); process.exit(1); });
