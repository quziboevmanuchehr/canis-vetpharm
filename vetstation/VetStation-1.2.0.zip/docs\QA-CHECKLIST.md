# Qualitätssicherung (§12)

## Automatischer Klinik-Selbsttest (Praxis-PC: C:\VetStation)
Prüft die wiederverwendete Brain-Logik headless. **Aktueller Stand: 17/17 OK.**

Für diesen Selbsttest gibt es **keine** Doppelklick-Datei. Er muss getippt werden – deshalb
PowerShell öffnen (normal, **keine** Adminrechte nötig) und den Befehl **mit vollständigem Pfad
in Anführungszeichen** eingeben:

```powershell
& "C:\VetStation\node\node.exe" "C:\VetStation\tools\smoke-test.js"
```

- Der Befehl funktioniert aus **jedem** Startverzeichnis (PowerShell startet in `C:\WINDOWS\system32`).
- **Kein `npm`, kein `node` ohne Pfad** – auf dem Praxis-PC gibt es nur `C:\VetStation\node\node.exe`.

Ob die **Geräte** Daten senden, prüft dagegen die vorhandene Doppelklick-Datei
**GERAETE-PRUEFEN.bat** in `C:\VetStation` (auch im Startmenü unter „VetStation") – nichts tippen.

| Test (aus §12) | Erwartung | Status |
|---|---|---|
| Datenbasis lädt | `window.ANAES` in Node, 8 Arten, 43 Medis | ✅ |
| Normal (Hund) | keine kritische Kreuz-Analyse | ✅ |
| MAP 50 bei hohem Iso | „Iso senken" / Hypotonie | ✅ |
| Bradykardie + tief | „Bradykardie bei zu tiefer Narkose → Iso zuerst senken" | ✅ |
| VES + SpO₂↓ | **erst O₂/Beatmung** (nicht antiarrhythmisch zuerst) | ✅ |
| VES isoliert | Lidocain (Hund) nach Sicherung | ✅ |
| Apnoe | Inzident Apnoe (AF/EtCO₂ = 0) → IPPV | ✅ |
| Hypoventilation | Inzident Hypoventilation (EtCO₂ hoch) | ✅ |
| Bronchospasmus (Katze) | Kapno-Haifischflosse → Atemweg (R6 live) | ✅ |
| Kammerflimmern | **CPR + DEFIBRILLIEREN** (sev 5) | ✅ |
| Asystolie (Katze) | CPR (sev 5) | ✅ |
| Hyperthermie / Hypothermie | Inzident Temp hoch/niedrig (mehrere Arten) | ✅ |
| AV-Block III (Reptil 0.4 kg) | Brain läuft artspezifisch, kein Crash | ✅ |
| Injektion mL | Asystolie/Katze: Adrenalin liefert mL; Bradykardie/Hund: Atropin | ✅ |
| Artspezifische Dosis | Atropin Hund ≠ Kaninchen (mg/kg) | ✅ |

## Live-Verifikation (Browser, gegen die laufende Bridge)
Bereits geprüft (Simulator):
- **Auto-Discovery:** 4 Geräte erkannt (2× Monitor, 2× Kapno), Status „active".
- **Matching:** Monitor+Kapno gleicher ID → 1 Patient; zwei Patienten (Hund + Katze) getrennt.
- **Split-View-Priorität:** VFlimmern-Hund (sev 5) steht über Hypotonie-Katze (sev 3).
- **Brain live:** VF → „Kammerflimmern → CPR/DEFIB" + mL (Adrenalin 0.22, Vasopressin 0.88 …);
  Hypotonie → „Verdampfer senken" + **Iso-Soll [OFF]** (3.6 vs 1.5–2.5).
- **Alarme:** Kacheln färben sich rot bei Grenzwertverletzung.
- **Waveforms:** EKG/Pleth/Kapno zeichnen (Canvas 423×234, Herzschlag läuft).
- **Live-Datenpull:** UI zeigt „📚 Live-Daten" (Pull vom canis-vetpharm erfolgreich).
- **Admin (PIN 1234):** 4 Reiter, Geräte-/Fehlerliste, Feedback, Export.

## Manuell zu prüfen (mit echten Geräten / vor Praxiseinsatz)
- [ ] Jedes der 3 Geräte im Standby wird erkannt, richtig benannt, Werte = Gerätewerte
      (erst nach Einbau der Protokoll-Parser, siehe DEVICE-ADAPTERS.md).
      Voraussetzung – verbindliche Adressen: PC (VetStation) **192.168.0.99**,
      uMEC12 Vet Monitor **192.168.0.50** (Adresstyp MANUELL, nicht DHCP),
      LifeVet / 2. Gerät **192.168.0.51**, jeweils Maske 255.255.255.0 **ohne** Gateway;
      Ziel im Monitor (Gateway-Kommunikationseinstellung) **192.168.0.99 : 3502**.
      Die feste IP am PC setzt die Doppelklick-Datei **NETZWERK-EINRICHTEN.bat** in `C:\VetStation`
      (auch im Startmenü unter „VetStation") – sie holt sich die Adminrechte selbst, UAC bestätigen.
      Geräte-Menüweg: Hauptmenü → Wartung → Benutzer-Wartung (Passwort 888888) → Netzwerk.
- [ ] Matching-Test mit echten Patienten-IDs (gleich → zusammengeführt; unterschiedlich → getrennt).
- [ ] Performance auf i3/8 GB: 3 Streams + 2 Fenster flüssig, RAM stabil (mehrere Stunden).
- [ ] Kiosk: bootet direkt in die App, kein Desktop, Watchdog startet nach Absturz neu.
- [ ] Win10 **und** Win11: identisches Verhalten (Kiosk, WebView2, DPI-Skalierung, Touch).
- [ ] DPI/Touchscreen: Layout responsiv, große Zahlen lesbar, Maus **und** Touch bedienbar.

## Mehrere OP-Säle (ab 1.1.0)

Braucht **zwei** Praxis-PCs mit VetStation 1.1.0 und **ein** gemeinsames Praxis-Konto.
Anleitung: [docs/MEHRERE-SAELE.md](MEHRERE-SAELE.md).

**Einrichten und Grundfall**
- [ ] Beide Stationen bekommen beim ersten Start den Balken „Dieser OP-Saal hat noch keinen Namen",
      und ein gesetzter Name überlebt einen Neustart (`data\station-id.json`).
- [ ] Beide am **selben** Konto angemeldet → jeder Kiosk zeigt den anderen Saal im Streifen unten,
      die Fern-Ansicht zeigt **zwei** Karten.
- [ ] Verschiedene Konten → die Säle sehen einander **nicht** (Mandantentrennung).
- [ ] Der Streifen ist beim ersten Öffnen **eingeklappt**, sein Zustand überlebt ein Neuladen.
- [ ] **Die Höhe des Streifens ändert sich nur beim Klick.** Während im Nachbarsaal Werte
      eintreffen, brechen die eigenen Patienten-Fenster **nicht** um. (Der Grund, warum das eine
      eigene Prüfung ist: `#vsxGrid` ist `position:fixed` mit `grid-auto-rows:1fr`.)

**Die Zusage „nur Ansicht"**
- [ ] Im Koppel-Dialog (🔌 Geräte) taucht **kein** fremdes Gerät auf.
- [ ] Der Streifen hat keine Eingabefelder, keinen „setzen"-Knopf und keine Kurven.
- [ ] „OP 2 öffnen" öffnet **kein** Patientenfenster auf diesem PC.
- [ ] Das PDF-Protokoll enthält **nur** eigene Patienten; im Kopf stehen Saalname **und**
      Kennungs-Kurzform.

**Alter und Ausfall — der gefährlichste Teil**
- [ ] Nachbar-PC vom Netz trennen: nach ~12 s gelb „keine neuen Daten", nach ~60 s
      „offline seit X min" **und die Zahlen werden durch „Stand vor X min" ersetzt** (nicht nur
      eingefärbt — eine eingefrorene Zahl, die aussieht wie eine lebende, ist das Risiko).
- [ ] Uhr des Nachbar-PCs 2 min **vorstellen**: es steht „Alter unbekannt", nie „0 s".
- [ ] Nur das Gerät im Nachbarsaal abziehen (PC läuft weiter): „Übertragung" bleibt frisch,
      „Gerätedaten" altert. Beide Zahlen müssen getrennt sichtbar sein.

**Zwei gleiche Tiere, zwei Säle — Befund B2-1**
- [ ] In beiden Sälen einen 22-kg-Hund führen. In der Fern-Ansicht den Saal wechseln:
      es wird **zurückgefragt und beide Tiere werden genannt**.
- [ ] Nach dem Wechsel stehen **keine** Istwerte des ersten Tiers mehr da (EtCO₂, Temperatur, AF
      besonders prüfen — sie werden nur bei nicht-leeren Werten überschrieben).
- [ ] Saalname, Tierart und Gewicht stehen in **jedem** rechnenden Bereich (Dosis, Beatmung,
      Vorfall), nicht nur in der Kopfleiste.
- [ ] Ein Alarm im nicht geführten Saal lässt dessen Karte pulsieren, schaltet aber **nicht** um.

**Gleiche Namen, gleiche Kennung**
- [ ] Beide Säle gleich benennen → Warnzeile in Tafel und Streifen, Kennung auf jeder Karte.
- [ ] Geklonten PC nachstellen (`data\station-id.json` kopieren) → Meldung „doppelte
      Stationskennung", die Station sendet **nur noch ihren Herzschlag**, keine Patientendaten.
      Ausweg ausschließlich über Admin → 🏥 OP-Saal → „Diese Station bekommt eine NEUE Kennung".

**Alte Fassung daneben (Kompatibilität)**
- [ ] Eine 1.0.3-Station im selben Konto mitlaufen lassen: die 1.1.0 meldet F1 im Klartext und
      spiegelt **nichts** flach. Die ausgelieferte Web-App zeigt weiterhin die 1.0.3.
- [ ] 1.0.3 abschalten → nach ~60 s Stille geht die 1.1.0 zurück auf F2 und spiegelt wieder.

**Direkter Weg im Haus (Stufe 2, Port 8771)**
- [ ] `FIREWALL-FREIGEBEN.bat` legt die Regel „VetStation Nachbarsaal TCP 8771" an — **nur**
      Profil Privat/Domäne, **nur** LocalSubnet.
- [ ] Internet trennen, Hausnetz behalten: die Säle sehen einander weiter.
- [ ] Beide PCs auf dieselbe IP setzen (der klassische Fehler, `LAN-SETUP.md` schreibt allen
      `192.168.0.99` vor) → die Station führt sich **nicht** selbst als Nachbarsaal.
- [ ] `bridge\data\nachbarn.json` von Hand verfälschen (anderer Schlüssel) → „Der Schlüssel von
      … hat sich geändert", Rückfall auf den Weg über das Konto, **keine** stille Übernahme.

**Automatische Suche**
- [ ] Frisch installierte Station ohne `devices.json`: nach ~20 s steht im Log, was gefunden wurde;
      ein lauschendes Gerät ist eingetragen und liefert Werte **ohne Neustart**.
- [ ] Während eine Narkose läuft (Gerät „aktiv"): im Log steht „verschoben", **kein** Suchlauf.
- [ ] Ein Gerät, das auf einem Datenport antwortet, aber kein HL7 spricht (Veta 5 auf 4601):
      nach 90 s abgeschaltet, Grund im Log, Adresse gesperrt.

---

## Nur Entwickler-PC (D:\VetStation)
Die folgenden Befehle gelten **ausschließlich** auf dem Entwickler-PC, wo das Projekt unter
`D:\VetStation` liegt und `npm`/`node` im PATH stehen. **Nicht** auf dem Praxis-PC eintippen –
dort gibt es kein npm; dafür gilt der Abschnitt „Automatischer Klinik-Selbsttest" oben.

```powershell
cd D:\VetStation
node tools/smoke-test.js     # Klinik-Selbsttest, 17 Prüfungen (identisch zu: npm run smoke)
npm test                     # alle Testskripte nacheinander
```

### Hinweis zu Screenshots im Test (Entwickler-PC)
Die UI läuft dauerhaft mit `requestAnimationFrame` (Monitor-Kurven). Automatische Screenshots können
dabei hängen; **DOM/JS-Inspektion** (read_page / console) ist verlässlicher. In einem **sichtbaren**
Vollbildfenster laufen die Kurven normal (rAF wird nur bei versteckten Tabs pausiert).
