@echo off
title VetStation - Internet einrichten (Update + Fern-Live)
REM Traegt Standardgateway und DNS nach, OHNE die feste Geraete-IP zu aendern.
REM Noetig, wenn der PC ueber einen Verstaerker/Switch am Praxis- oder Hausnetz haengt:
REM dann laufen die Geraetedaten zwar, aber Update, Fern-Live und die klinischen Daten
REM kommen nicht ins Internet - ohne dass irgendwo ein Fehler erscheint.
REM Im ISOLIERTEN Geraetenetz (eigener Switch, kein Router) wird diese Datei NICHT gebraucht.
REM Einfach DOPPELKLICKEN. Adminrechte holt sich das Skript selbst (UAC bestaetigen).
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-internet.ps1"
