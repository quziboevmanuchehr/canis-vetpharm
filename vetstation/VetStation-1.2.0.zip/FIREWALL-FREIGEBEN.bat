@echo off
title VetStation - Firewall freigeben
REM Gibt die Geraete-Datenports frei und raeumt doppelte Altregeln frueherer Installationen auf.
REM Mehrfaches Ausfuehren schadet nicht - das Ergebnis ist immer genau eine Regel je Port.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\set-firewall.ps1"
pause
