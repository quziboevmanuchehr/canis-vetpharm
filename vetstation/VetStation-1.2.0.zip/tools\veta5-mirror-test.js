'use strict';
/*
 * veta5-mirror-test.js — sichert, dass die Narkosegeraet-Beatmungseinstellungen
 * (Modus + Frischgasfluss + Beatmungsparameter Vt/AF/PEEP/...) durch die Pipeline
 * bis zum Patienten durchgereicht werden, damit das virtuelle Geraet sie spiegeln kann
 * ("uebernehmen und genau so zeigen"). Fehlt alles (MD2 -> keine lesbaren Daten), darf
 * nichts abstuerzen und die Felder bleiben null (App faellt auf Handbedienung zurueck).
 * Start: node tools/veta5-mirror-test.js
 */
const fs = require('fs');
const path = require('path');
const { normalizeFrame } = require('../bridge/src/model');
const { mergePatients } = require('../bridge/src/matching');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

console.log('Veta-5-Spiegelung (Beatmungsmodus/-parameter live) — Selbsttest\n');

// 1) model.normalizeFrame reicht die neuen Felder durch
const raw = {
  deviceId: 'CAP-9', deviceModel: 'Veta 5 Plus', deviceRole: 'anesthesia',
  patientId: 'V-1', species: 'hund', weightKg: 20, ts: Date.now(),
  vitals: { etco2: 40, af: 12 },
  isoPct: 2.2, ventMode: 'SIMV', o2Flow: 0.9,
  ventParams: { vt: 200, af: 12, ie: '1:2', peep: 3, tinsp: 1.0, psupp: 8, trigger: 'Auto' },
};
const nf = normalizeFrame(raw).frame;
ok('normalizeFrame: ventMode erhalten (SIMV)', nf.ventMode === 'SIMV', 'ventMode=' + nf.ventMode);
ok('normalizeFrame: o2Flow erhalten (0.9)', nf.o2Flow === 0.9, 'o2Flow=' + nf.o2Flow);
ok('normalizeFrame: ventParams-Objekt erhalten', nf.ventParams && nf.ventParams.vt === 200 && nf.ventParams.peep === 3, 'vp=' + JSON.stringify(nf.ventParams));

// 2) mergePatients reicht sie zum Patienten durch (Monitor am selben Patienten daneben)
const mon = normalizeFrame({
  deviceId: 'MON-9', deviceModel: 'uMEC12 Vet', deviceRole: 'monitor',
  patientId: 'V-1', species: 'hund', weightKg: 20, ts: Date.now() + 1,
  vitals: { hr: 90, spo2: 98, nibp: { sys: 110, dia: 70 }, temp: 38 },
}).frame;
const patients = mergePatients([{ deviceId: 'CAP-9', frame: nf }, { deviceId: 'MON-9', frame: mon }], {});
ok('mergePatients: genau 1 Patient (gleiche ID)', patients.length === 1, 'n=' + patients.length);
const p = patients[0] || {};
ok('Patient: ventMode = SIMV', p.ventMode === 'SIMV', 'ventMode=' + p.ventMode);
ok('Patient: o2Flow = 0.9', p.o2Flow === 0.9, 'o2Flow=' + p.o2Flow);
ok('Patient: ventParams durchgereicht (vt 200, peep 3, trigger Auto)',
  p.ventParams && p.ventParams.vt === 200 && p.ventParams.peep === 3 && p.ventParams.trigger === 'Auto', 'vp=' + JSON.stringify(p.ventParams));
ok('Patient: isoPct = 2.2 (unveraendert)', p.isoPct === 2.2, 'iso=' + p.isoPct);

// 3) Fehlen die Beatmungsdaten (Alltag: MD2), darf nichts abstuerzen und Felder sind null
const leer = normalizeFrame({
  deviceId: 'CAP-0', deviceModel: 'Veta 5 Plus', deviceRole: 'anesthesia',
  patientId: 'V-2', species: 'katze', weightKg: 4, ts: Date.now(), vitals: { etco2: 38, af: 20 },
}).frame;
const p2 = mergePatients([{ deviceId: 'CAP-0', frame: leer }], {})[0] || {};
ok('ohne Beatmungsdaten: ventParams = null (kein Absturz)', p2.ventParams == null, 'vp=' + JSON.stringify(p2.ventParams));
ok('ohne Beatmungsdaten: o2Flow = null', p2.o2Flow == null, 'o2Flow=' + p2.o2Flow);

// 4) Shell-Spiegellogik + Modus-Namensuebersetzung vorhanden (Browserdatei -> Quellcheck)
const shell = fs.readFileSync(path.join(__dirname, '..', 'ui', 'vetstation-live.js'), 'utf8');
ok('vetstation-live.js: ventModeIdFromName vorhanden', /function\s+ventModeIdFromName/.test(shell));
ok('vetstation-live.js: spiegelt ventParams flankengetrieben', /p\.ventParams/.test(shell) && /d\.__last/.test(shell));
ok('vetstation-live.js: Namensmap kennt simv/pcv/vcv/psv', /simv/.test(shell) && /pcv/.test(shell) && /vcv/.test(shell) && /psv/.test(shell));

// 5) Simulator liefert die Felder (damit sich die Spiegelung ohne echtes Geraet zeigen laesst)
const simSrc = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'adapters', 'simulator.js'), 'utf8');
ok('simulator.js: emittiert ventParams + o2Flow', /ventParams/.test(simSrc) && /o2Flow/.test(simSrc));

// 6) Die App legt die Bruecken ans window (sonst laeuft der Spiegel-Code der Shell ins Leere) —
//    die App ist eine IIFE, ohne diese Zeilen sind state/render nicht erreichbar (latenter Bug!).
const appSrc = fs.readFileSync(path.join(__dirname, '..', 'ui', 'app', 'index.html'), 'utf8');
ok('index.html: window.state fuer die Shell freigegeben', /window\.state\s*=\s*state/.test(appSrc));
ok('index.html: Render-Funktionen fuer die Spiegelung freigegeben',
  /window\.renderMachine\s*=/.test(appSrc) && /window\.renderVentPanel\s*=/.test(appSrc) && /window\.renderVentModes\s*=/.test(appSrc));

console.log('\n' + (fail ? ('FEHLER: ' + fail + ' Test(s) fehlgeschlagen, ' + pass + ' ok') : ('ALLE ' + pass + ' Tests bestanden')));
process.exit(fail ? 1 : 0);
