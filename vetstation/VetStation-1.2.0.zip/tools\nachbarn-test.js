'use strict';
/*
 * nachbarn-test.js — sichert das BAND der fremden OP-Saele ab (ui/vetstation-nachbarn.js).
 *
 * Was hier NIE wieder passieren darf:
 *   • Das Band aendert seine Hoehe, weil Daten eintreffen. #vsxGrid ist position:fixed mit
 *     bottom:0 und grid-auto-rows:1fr — jede Hoehenaenderung bricht ALLE Patienten-iframes neu um,
 *     und ein neu umgebrochenes iframe laedt die Anaesthesie-App mitten in der Narkose neu
 *     (Befund C2-9).
 *   • Ein toter Nachbarsaal steht dauerhaft als "live" auf dem Bildschirm. Das ist der gefaehrliche
 *     Fall: unsere Bridge schickt weiter im Sekundentakt, die Werte aendern sich nicht mehr, also
 *     bleibt die Signatur gleich — und ohne Nachziehen der Zeiten rechnete das Band ewig mit dem
 *     Uebertragungsalter der ERSTEN Nachricht.
 *   • Zahlen eines offline gegangenen Saals bleiben stehen. Ein Blutdruck von 112/64 ist eine
 *     Aussage ueber JETZT; zwei Minuten alt ist sie falsch, und Grau macht sie nicht richtiger.
 *   • Ein negatives Alter wird zu 0. Ein Saal, dessen Zeitstempel vor unserer Uhr liegt, waere
 *     sonst dauerhaft brandaktuell — gruen, mit seinen letzten Vitalwerten (Nachbesserung N16).
 *   • Der Streifen wird bei JEDER Nachricht neu gebaut. Dann flackert er, die Bildlaufstelle geht
 *     verloren, und der eigene Saal verliert Rechenzeit an einen fremden.
 *   • Ein fremder Patient bekommt ein iframe, ein Eingabefeld oder einen "setzen"-Knopf. Das Band
 *     ist reine Ansicht; die Geraete haengen an einem anderen PC.
 *   • Ein OP-Saal verschwindet lautlos, weil ein Deckel greift (Nachbesserung N17).
 *   • Zwei gleichnamige Saele stehen ohne Warnung nebeneinander.
 *   • Das Band navigiert selbst irgendwohin, statt nur den Rueckruf des Einbetters auszuloesen.
 *
 * Laeuft OHNE Browser, OHNE Netz und OHNE echte Uhr: die Datei wird in einem eigenen
 * vm-Zusammenhang mit einem winzigen Schein-DOM ausgefuehrt, die Uhr ist opts.jetzt, und der
 * Zeitgeber wird von Hand getaktet. Jede Alterung entsteht durch RECHNEN, nicht durch Warten.
 *
 * Start: node tools/nachbarn-test.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

const WURZEL = path.join(__dirname, '..');
const DATEI = path.join(WURZEL, 'ui', 'vetstation-nachbarn.js');
const QUELLE = fs.readFileSync(DATEI, 'utf8');

// Feste Uhr. T0 ist derselbe Bezugspunkt wie in tools/tafel-test.js.
const T0 = 1800000000000;

// ---------------------------------------------------------------- Schein-DOM

/*
 * Ein DOM in 90 Zeilen. Es kann genau das, was das Band benutzt: createElement, appendChild,
 * removeChild, firstChild, textContent, className/classList, setAttribute, title, scrollLeft,
 * onclick. Mehr braucht das Modul nicht — und genau das ist die Aussage: wer hier etwas ergaenzen
 * muss, hat dem Band eine Faehigkeit gegeben, die es nicht haben sollte (querySelector waere der
 * erste Schritt zurueck zu innerHTML).
 */
function macheDom() {
  function TextKnoten(t) { this.nodeType = 3; this._t = String(t == null ? '' : t); this.parentNode = null; }
  Object.defineProperty(TextKnoten.prototype, 'textContent', {
    get() { return this._t; },
    set(v) { this._t = String(v == null ? '' : v); },
  });

  function Knoten(tag) {
    this.nodeType = 1;
    this.tagName = String(tag).toUpperCase();
    this.childNodes = [];
    this.parentNode = null;
    this._klassen = [];
    this.attrs = Object.create(null);
    this.scrollLeft = 0;
    this.title = '';
    this.id = '';
    this.onclick = null;
    const selbst = this;
    this.classList = {
      add() { for (const c of arguments) if (selbst._klassen.indexOf(c) < 0) selbst._klassen.push(c); },
      remove() { for (const c of arguments) { const i = selbst._klassen.indexOf(c); if (i >= 0) selbst._klassen.splice(i, 1); } },
      contains(c) { return selbst._klassen.indexOf(c) >= 0; },
      toggle(c, an) { const soll = (an === undefined) ? !this.contains(c) : !!an; if (soll) this.add(c); else this.remove(c); return soll; },
    };
  }
  Object.defineProperty(Knoten.prototype, 'className', {
    get() { return this._klassen.join(' '); },
    set(v) { this._klassen = String(v == null ? '' : v).split(/\s+/).filter(Boolean); },
  });
  Object.defineProperty(Knoten.prototype, 'firstChild', {
    get() { return this.childNodes.length ? this.childNodes[0] : null; },
  });
  Object.defineProperty(Knoten.prototype, 'textContent', {
    get() { return this.childNodes.map((k) => k.textContent).join(''); },
    set(v) { this.childNodes.forEach((k) => { k.parentNode = null; }); this.childNodes = [new TextKnoten(v)]; this.childNodes[0].parentNode = this; },
  });
  Knoten.prototype.appendChild = function (k) {
    if (k.parentNode && k.parentNode.removeChild) k.parentNode.removeChild(k);
    k.parentNode = this; this.childNodes.push(k); return k;
  };
  Knoten.prototype.removeChild = function (k) {
    const i = this.childNodes.indexOf(k);
    if (i >= 0) { this.childNodes.splice(i, 1); k.parentNode = null; }
    return k;
  };
  Knoten.prototype.setAttribute = function (n, w) { this.attrs[n] = String(w); };
  Knoten.prototype.getAttribute = function (n) { return Object.prototype.hasOwnProperty.call(this.attrs, n) ? this.attrs[n] : null; };

  const doc = {
    createElement(t) { return new Knoten(t); },
    head: new Knoten('head'),
    documentElement: new Knoten('html'),
    getElementById(id) {
      const suche = (k) => {
        if (k.id === id) return k;
        for (const kind of k.childNodes) { if (kind.nodeType !== 1) continue; const t = suche(kind); if (t) return t; }
        return null;
      };
      return suche(doc.head) || suche(doc.documentElement);
    },
  };
  return { doc, Knoten };
}

// Alle Knoten mit einer Klasse einsammeln (nur fuer den Test — das Modul selbst sucht nie).
function sammle(k, klasse, raus) {
  raus = raus || [];
  if (!k) return raus;
  if (k.nodeType === 1) {
    if (k.classList.contains(klasse)) raus.push(k);
    for (const kind of k.childNodes) sammle(kind, klasse, raus);
  }
  return raus;
}
function tags(k, raus) {
  raus = raus || [];
  if (!k || k.nodeType !== 1) return raus;
  raus.push(k.tagName);
  for (const kind of k.childNodes) tags(kind, raus);
  return raus;
}

// ---------------------------------------------------------------- Modul laden

/*
 * Ein frischer Zusammenhang je Pruefblock. Das Modul haelt seinen Zustand in Modulvariablen
 * (Band, Zeiger, Zeitgeber); zwei Pruefungen im selben Zusammenhang wuerden sich beeinflussen,
 * und dann prueft der Test nicht mehr das Modul, sondern die Reihenfolge seiner eigenen Zeilen.
 */
function lade() {
  const { doc } = macheDom();
  const speicher = Object.create(null);
  const takte = [];
  const sandkasten = {
    document: doc,
    localStorage: {
      getItem(k) { return Object.prototype.hasOwnProperty.call(speicher, k) ? speicher[k] : null; },
      setItem(k, w) { speicher[k] = String(w); },
    },
    setInterval(fn, ms) { takte.push({ fn, ms }); return takte.length; },
    clearInterval(id) { if (takte[id - 1]) takte[id - 1].gestoppt = true; },
    console,
  };
  sandkasten.window = sandkasten;
  vm.createContext(sandkasten);
  vm.runInContext(QUELLE, sandkasten, { filename: 'vetstation-nachbarn.js' });
  return { sandkasten, doc, speicher, takte, VN: sandkasten.VetNachbarn };
}

// Ein Behaelter, wie ihn ui/index.html liefert (#vsxNachbarn).
function behaelterVon(doc) { const b = doc.createElement('div'); b.id = 'vsxNachbarn'; doc.documentElement.appendChild(b); return b; }

// ---------------------------------------------------------------- Beispieldaten

function kachel(zusatz) {
  return Object.assign({
    key: 'sw_hund_22', pid: 'P1', n: 'Bello', a: 'Hund', g: 22,
    hr: 88, sp: 97, et: 38, af: 12, sys: 112, dia: 64, map: 81, t: 37.4,
    pri: 2, top: '', al: 0, altMs: 1200,
  }, zusatz || {});
}
function geraet(zusatz) {
  return Object.assign({
    id: 'mon1', model: 'uMEC12', role: 'monitor', status: 'active',
    ip: '192.168.1.50', port: 3502, transport: 'hl7', altMs: 900,
  }, zusatz || {});
}
function saal(zusatz) {
  return Object.assign({
    sid: 'st7f3a91c2b45d', name: 'OP 2', quelle: 'lan', uebertragungMs: 800,
    count: 1, patients: [kachel()], geraete: [geraet()], stufe: 'live', widerspruch: false,
  }, zusatz || {});
}
function botschaft(saele, zusatz) {
  return Object.assign({ type: 'fremd', ts: T0, saele: saele, mehr: 0, hinweise: [] }, zusatz || {});
}

// ================================================================ 1. reine Alterung
console.log('\n1) Alterung — dieselben Stufen wie bridge/src/tafel.js');
{
  const P = lade().VN.pur;
  ok('0 ms ist live', P.altersStufe(0) === 'live');
  ok('11999 ms ist live', P.altersStufe(11999) === 'live');
  ok('12000 ms ist alt', P.altersStufe(12000) === 'alt');
  ok('59999 ms ist alt', P.altersStufe(59999) === 'alt');
  ok('60000 ms ist offline', P.altersStufe(60000) === 'offline');
  ok('12 h ist weg', P.altersStufe(12 * 3600 * 1000) === 'weg');
  ok('null ist unbekannt', P.altersStufe(null) === 'unbekannt');

  // Der Kern von N16: NIE 0, sondern "Alter unbekannt".
  ok('negatives Alter ist unbekannt, nicht live', P.altersStufe(-1) === 'unbekannt');
  ok('negatives Alter ergibt nie eine Zahl',
    P.alterText(P.altersStufe(-5000), -5000, 'OP 2') === 'Alter unbekannt',
    P.alterText(P.altersStufe(-5000), -5000, 'OP 2'));
  ok('negatives Alter ergibt kein "Stand vor 0 min"',
    P.ersatzText(-5000) === 'Alter unbekannt', P.ersatzText(-5000));

  ok('12-60 s nennt die Sekunden', P.alterText('alt', 30000, 'OP 2') === 'keine neuen Daten (30s)', P.alterText('alt', 30000, 'OP 2'));
  ok('ueber 60 s nennt den Saal', P.alterText('offline', 125000, 'OP 2') === 'OP 2 offline seit 2 min', P.alterText('offline', 125000, 'OP 2'));
  ok('61 s ergibt "Stand vor 1 min"', P.ersatzText(61000) === 'Stand vor 1 min', P.ersatzText(61000));
  ok('nie "Stand vor 0 min"', P.ersatzText(1000) === 'Stand vor 1 min', P.ersatzText(1000));
  ok('unbekannte Dauer wird nicht erfunden', P.dauerKurz(null) === '?' && P.dauerKurz(-1) === '?');

  /*
   * 31.07.2026, Gegenpruefung: Number('') ist 0. Ein leeres Feld darf trotzdem NIE zu einer 0
   * werden — weder zu 'HF 0' auf einer Kachel noch zu einem Uebertragungsalter von 0, das einen
   * Saal ohne jede Altersangabe gruen und 'live' gemacht haette.
   */
  ok('eine leere Zeichenkette ist kein Alter von 0', P.altersStufe('') === 'unbekannt', P.altersStufe(''));
  ok('auch Leerraum ist kein Alter von 0', P.altersStufe('   ') === 'unbekannt');
  ok('eine leere Zeichenkette ist keine Dauer', P.dauerKurz('') === '?' && P.ersatzText('') === P.TEXT_UNBEKANNT);
  ok('eine Zahl als Zeichenkette bleibt eine Zahl', P.altersStufe('30000') === 'alt' && P.dauerKurz('90000') === '2 min');
  ok('zuschlag laesst unbekannt unbekannt', P.zuschlag(null, 5000) === null && P.zuschlag(-1, 5000) === null);
  ok('zuschlag rechnet lokal weiter', P.zuschlag(1200, 5000) === 6200);
}

// ================================================================ 2. Schwellen gegen tafel.js
console.log('\n2) Schwellen und Deckel stehen nirgends zweimal verschieden');
{
  const P = lade().VN.pur;
  const tafel = require(path.join(WURZEL, 'bridge', 'src', 'tafel.js'));
  ok('STUFE_LIVE_MS wie in tafel.js', P.STUFE_LIVE_MS === tafel.STUFE_LIVE_MS, P.STUFE_LIVE_MS + ' vs ' + tafel.STUFE_LIVE_MS);
  ok('STUFE_OFFLINE_MS wie in tafel.js', P.STUFE_OFFLINE_MS === tafel.STUFE_OFFLINE_MS);
  ok('STUFE_WEG_MS wie in tafel.js', P.STUFE_WEG_MS === tafel.STUFE_WEG_MS);
  ok('Saal-Deckel wie GRENZEN.saele (N17)', P.DECKEL_SAELE === tafel.GRENZEN.saele, P.DECKEL_SAELE + ' vs ' + tafel.GRENZEN.saele);
  ok('Kachel-Deckel wie GRENZEN.kacheln (N17)', P.DECKEL_KACHELN === tafel.GRENZEN.kacheln);
  ok('Geraete-Deckel wie GRENZEN.geraete (N13/N17)', P.DECKEL_GERAETE === tafel.GRENZEN.geraete);
  ok('Kurzform wie stationsid.sidKurz', P.sidKurz('st7f3a91c2b45d') === '7f3a91', P.sidKurz('st7f3a91c2b45d'));
  ok('unbekannte Form ergibt keine erfundene Kurzform',
    P.sidKurz('st7f3a91c2b45d-0042') === 'st7f3a91c2b45d-0042');
}

// ================================================================ 3. Quelltext
console.log('\n3) Quelltext — was diese Datei nicht tun darf');
{
  // Kommentare weg, sonst schlaegt jede Begruendung als Treffer an.
  const ohne = QUELLE.replace(/\/\*[\s\S]*?\*\//g, ' ').split('\n').map((z) => z.replace(/([^:'"])\/\/.*$/, '$1')).join('\n');
  ok('kein innerHTML', ohne.indexOf('innerHTML') < 0);
  ok('kein outerHTML/insertAdjacentHTML', ohne.indexOf('outerHTML') < 0 && ohne.indexOf('insertAdjacent') < 0);
  ok('kein fetch', ohne.indexOf('fetch(') < 0);
  ok('kein XMLHttpRequest', ohne.indexOf('XMLHttpRequest') < 0);
  ok('kein WebSocket (die Nachricht kommt von aussen)', ohne.indexOf('WebSocket') < 0);
  ok('kein api/kurven fuer fremde Schluessel', ohne.indexOf('api/kurven') < 0);
  ok('kein iframe', ohne.toLowerCase().indexOf('iframe') < 0);
  ok('kein location/navigation', ohne.indexOf('location') < 0 && ohne.indexOf('window.open') < 0);
  ok('kein querySelector (der Zeitgeber haelt Zeiger)', ohne.indexOf('querySelector') < 0);
  ok('kein style-Attribut je Knoten (alles CSS im einen Stilblatt)', ohne.indexOf('.style.') < 0);
  ok('keine Umlaute im Quelltext', !/[äöüÄÖÜß]/.test(QUELLE),
    (QUELLE.match(/[äöüÄÖÜß]/g) || []).slice(0, 5).join(''));
  ok('setzt window.VetNachbarn', /VetNachbarn\s*=/.test(ohne));
  ok('genau ein Stilblatt', (ohne.match(/createElement\('style'\)/g) || []).length === 1);
}

// ================================================================ 4. Nachricht annehmen
console.log('\n4) Nachricht annehmen, kappen, zaehlen');
{
  const P = lade().VN.pur;
  const leer = P.nimm(null);
  ok('Muell ergibt einen leeren Stand', leer.saele.length === 0 && leer.mehr === 0);
  ok('Muell wirft nicht', P.nimm({ saele: 'nein', hinweise: 7 }).saele.length === 0);

  const ohneSid = P.nimm(botschaft([saal({ sid: '' })]));
  ok('ein Saal ohne Kennung bekommt keine Karte', ohneSid.saele.length === 0);

  // N17: Deckel sichtbar. Neun Saele -> acht Karten UND eine Zeile.
  const neun = [];
  for (let i = 0; i < 9; i++) neun.push(saal({ sid: 'st00000000000' + i, name: 'OP ' + i }));
  const g = P.nimm(botschaft(neun));
  ok('hoechstens 8 Saele', g.saele.length === 8, String(g.saele.length));
  ok('der neunte Saal wird gezaehlt', g.mehr === 1);
  ok('der Deckel sagt es im Klartext',
    g.hinweise.join(' ').indexOf('weitere OP-Saele werden nicht angezeigt — Deckel erreicht') >= 0,
    g.hinweise.join(' | '));

  const viele = [];
  for (let i = 0; i < 15; i++) viele.push(kachel({ key: 'k' + i }));
  const k = P.nimm(botschaft([saal({ patients: viele })]));
  ok('hoechstens 12 Kacheln je Saal', k.saele[0].patients.length === 12, String(k.saele[0].patients.length));
  ok('die drei uebrigen Kacheln werden gezaehlt', k.saele[0].mehr === 3, String(k.saele[0].mehr));

  const vorstufe = P.nimm(botschaft([saal({ mehr: 4, mehrGeraete: 2 })]));
  ok('der Deckel der Vorstufe geht nicht verloren', vorstufe.saele[0].mehr === 4 && vorstufe.saele[0].mehrGeraete === 2);

  const fremd = P.nimm(botschaft([saal({ quelle: 'nasenwasser' })]));
  ok('eine unbekannte Quelle gilt als "aus"', fremd.saele[0].quelle === 'aus');

  const lang = P.nimm(botschaft([saal({ patients: [kachel({ n: 'B'.repeat(400) })] })]));
  ok('Namen werden gekappt', lang.saele[0].patients[0].n.length === 40, String(lang.saele[0].patients[0].n.length));
  const steuer = P.nimm(botschaft([saal({ name: 'OP\u00002\u001b' })]));
  ok('Steuerzeichen fallen weg', steuer.saele[0].name.indexOf('\u0000') < 0 && steuer.saele[0].name.indexOf('\u001b') < 0);
}

// ================================================================ 5. Messwerte
console.log('\n5) Messwerte — nichts erfinden');
{
  const P = lade().VN.pur;
  const voll = P.werteText(kachel());
  ok('alle Werte stehen da', /HF 88/.test(voll) && /SpO2 97/.test(voll) && /EtCO2 38/.test(voll)
    && /RR 112\/64 \(81\)/.test(voll) && /T 37,4/.test(voll), voll);
  ok('Dezimalkomma statt Punkt', voll.indexOf('37.4') < 0 && voll.indexOf('37,4') >= 0, voll);
  const ohne = P.werteText({ hr: 88 });
  ok('ein fehlender Wert wird nicht durch 0 ersetzt', ohne.indexOf('EtCO2') < 0 && ohne.indexOf('SpO2') < 0, ohne);
  ok('gar kein Wert sagt genau das', P.werteText({}) === 'keine Messwerte');
  // 31.07.2026, Gegenpruefung: hier stand vorher 'HF 0' — die 0, die diese Funktion nie schreiben soll.
  ok('ein leeres Feld wird nicht durch 0 ersetzt', P.werteText({ hr: '' }) === 'keine Messwerte', P.werteText({ hr: '' }));
  ok('ein leeres Feld neben einem echten Wert verschwindet',
    P.werteText({ hr: 88, et: '', t: ' ' }) === 'HF 88', P.werteText({ hr: 88, et: '', t: ' ' }));
  ok('eine leere Prioritaet ist Grau, nicht Gruen', P.priKlasse('') === 'p-', P.priKlasse(''));
  ok('ohne Prioritaet gibt es Grau, nicht Gruen', P.priKlasse(null) === 'p-' && P.priKlasse(0) === 'p0');
  ok('CPR faerbt rot', P.priKlasse(5) === 'p5' && P.priKlasse(4) === 'p4' && P.priKlasse(3) === 'p3');
  ok('Geraetezeile nennt Modell, Rolle und Adresse (N13)',
    P.geraeteText(geraet()) === 'uMEC12 · monitor · 192.168.1.50:3502', P.geraeteText(geraet()));
  ok('ein Geraet ohne Modell bleibt benennbar', P.geraeteText({ id: 'mon9' }) === 'mon9');
  ok('Status wird uebersetzt, nicht gerechnet',
    P.statusText('active') === 'sendet' && P.statusText('standby') === 'still' && P.statusText('offline') === 'offline');
  ok('Alarm einer Kachel laesst den Saal pulsieren',
    P.hatAlarm({ patients: [kachel({ al: 1 })] }) === true);
  ok('hohe Prioritaet ebenfalls', P.hatAlarm({ patients: [kachel({ pri: 4 })] }) === true);
  ok('ruhiger Saal pulsiert nicht', P.hatAlarm({ patients: [kachel()] }) === false);
}

// ================================================================ 6. Signatur
console.log('\n6) Signatur — neu gezeichnet wird nur bei geaendertem BILD');
{
  const P = lade().VN.pur;
  const a = P.nimm(botschaft([saal()]));
  const gleich = P.nimm(botschaft([saal()], { ts: T0 + 60000 }));
  ok('dieselben Daten ergeben dieselbe Signatur', P.signatur(a) === P.signatur(gleich));

  const andereZeit = P.nimm(botschaft([saal({ uebertragungMs: 45000 })], { ts: T0 + 5000 }));
  ok('uebertragungMs steht NICHT in der Signatur', P.signatur(a) === P.signatur(andereZeit));
  const anderesAlter = P.nimm(botschaft([saal({ patients: [kachel({ altMs: 99000 })] })]));
  ok('altMs einer Kachel steht NICHT in der Signatur', P.signatur(a) === P.signatur(anderesAlter));
  const andererHinweis = P.nimm(botschaft([saal()], { hinweise: ['OP 2 offline seit 3 min'] }));
  ok('hinweise stehen NICHT in der Signatur', P.signatur(a) === P.signatur(andererHinweis));
  const geraeteAlter = P.nimm(botschaft([saal({ geraete: [geraet({ altMs: 90000 })] })]));
  ok('altMs einer Geraetezeile steht NICHT in der Signatur', P.signatur(a) === P.signatur(geraeteAlter));

  ok('ein geaenderter Messwert AENDERT die Signatur',
    P.signatur(a) !== P.signatur(P.nimm(botschaft([saal({ patients: [kachel({ hr: 140 })] })]))));
  ok('ein geaenderter Saalname AENDERT die Signatur',
    P.signatur(a) !== P.signatur(P.nimm(botschaft([saal({ name: 'OP 3' })]))));
  ok('eine andere Quelle AENDERT die Signatur',
    P.signatur(a) !== P.signatur(P.nimm(botschaft([saal({ quelle: 'cloud' })]))));
  ok('ein weiterer Saal AENDERT die Signatur',
    P.signatur(a) !== P.signatur(P.nimm(botschaft([saal(), saal({ sid: 'stb1c2d3e4f506', name: 'OP 3' })]))));
  ok('ein Statuswechsel eines Geraets AENDERT die Signatur (N13)',
    P.signatur(a) !== P.signatur(P.nimm(botschaft([saal({ geraete: [geraet({ status: 'offline' })] })]))));
  // Zwei Staende duerfen nie durch Zusammenkleben derselben Zeichenkette gleich werden.
  ok('Feldgrenzen sind nicht verschiebbar',
    P.signatur(P.nimm(botschaft([saal({ name: 'OP', patients: [] })])))
    !== P.signatur(P.nimm(botschaft([saal({ name: 'O', patients: [] })]))));
}

// ================================================================ 7. gleiche Saalnamen
console.log('\n7) zwei Saele mit demselben Namen');
{
  const P = lade().VN.pur;
  const d = P.doppelteNamen([
    { sid: 'st7f3a91c2b45d', kurz: '7f3a91', name: 'OP 1' },
    { sid: 'stb1c2d3e4f506', kurz: 'b1c2d3', name: 'OP 1' },
    { sid: 'stc0ffee000000', kurz: 'c0ffee', name: 'OP 9' },
  ]);
  ok('doppelter Name wird gemeldet', d.zeilen.length === 1, JSON.stringify(d.zeilen));
  ok('die Meldung nennt beide Kurzformen', /7f3a91/.test(d.zeilen[0]) && /b1c2d3/.test(d.zeilen[0]), d.zeilen[0]);
  ok('die betroffenen Karten sind markierbar', d.betroffen['#OP 1'] === true && !d.betroffen['#OP 9']);
  ok('leere Namen zaehlen nicht als doppelt',
    P.doppelteNamen([{ sid: 'a', name: '' }, { sid: 'b', name: '' }]).zeilen.length === 0);
  ok('ein Saal namens constructor bricht die Zaehlung nicht',
    P.doppelteNamen([{ sid: 'a', name: 'constructor' }]).zeilen.length === 0);

  const w = P.warnzeile(P.nimm(botschaft([saal()], { hinweise: ['zweitens', 'drittens'] })), d);
  ok('die eigene Warnung steht vorn', w.kurz.indexOf('heissen gleich') > 0, w.kurz);
  ok('der Rest wird gezaehlt', /\+2 weitere/.test(w.kurz), w.kurz);
  ok('der Tooltip traegt alles', w.voll.split('\n').length === 3, w.voll);
  ok('ohne Warnung bleibt die Zeile leer', P.warnzeile(P.nimm(botschaft([saal()])), { zeilen: [], betroffen: {} }).kurz === '');
}

// ================================================================ 8. Montieren und Zeichnen
console.log('\n8) Band montieren — eingeklappt, feste Hoehe, reine Ansicht');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  let jetzt = T0;
  L.VN.montiere(b, { jetzt: () => jetzt });
  const band = b.childNodes[0];
  ok('das Band haengt im Behaelter', !!band && band.classList.contains('vsn'));
  ok('der Behaelter ist der Overlay-Halter', b.classList.contains('vsn-halter'));
  ok('standardmaessig EINGEKLAPPT', !band.classList.contains('auf'));
  ok('ohne Nachbarn ist das Band unsichtbar', band.classList.contains('leer'));
  ok('genau ein Stilblatt im Kopf', L.doc.head.childNodes.filter((k) => k.tagName === 'STYLE').length === 1);
  const css = L.doc.head.childNodes[0].textContent;
  ok('genau zwei Hoehen im Stilblatt',
    css.indexOf('height:' + L.VN.pur.HOEHE_ZU + 'px') > 0 && css.indexOf('height:' + L.VN.pur.HOEHE_AUF + 'px') > 0);
  ok('ein Zeitgeber laeuft', L.takte.length === 1 && L.takte[0].ms === L.VN.pur.TAKT_MS);

  L.VN.setze(botschaft([saal(), saal({ sid: 'stb1c2d3e4f506', name: 'OP 3' })]));
  ok('jetzt ist das Band sichtbar', !band.classList.contains('leer'));
  const karten = sammle(band, 'vsn-karte');
  ok('eine Karte je Saal', karten.length === 2, String(karten.length));
  ok('trotz Daten weiterhin eingeklappt (Hoehe aendert sich NIE durch Daten)', !band.classList.contains('auf'));

  // Saalname UND sid-Kurzform auf JEDER Karte.
  const namen = sammle(band, 'vsn-kname').map((k) => k.textContent);
  const kurz = sammle(band, 'vsn-ksid').map((k) => k.textContent);
  ok('jede Karte nennt den Saalnamen', namen.join('|') === 'OP 2|OP 3', namen.join('|'));
  ok('jede Karte nennt die sid-Kurzform', kurz.length === 2 && kurz[0] === '· 7f3a91' && kurz[1] === '· b1c2d3', kurz.join('|'));

  // Schloss und Satz.
  const sperr = sammle(band, 'vsn-sperr').map((k) => k.textContent);
  ok('Schloss-Zeichen auf jeder Karte', sperr.every((t) => t.indexOf('🔒') === 0), sperr.join(' | '));
  ok('der Satz "Nur Ansicht" nennt den Saal',
    sperr[0] === '🔒 Nur Ansicht — dieser Patient haengt am PC in OP 2', sperr[0]);

  // Reine Ansicht: kein iframe, kein Eingabefeld, keine Zeichenflaeche.
  const alle = tags(band);
  ok('kein IFRAME im Band', alle.indexOf('IFRAME') < 0);
  ok('kein Eingabefeld im Band', alle.indexOf('INPUT') < 0 && alle.indexOf('TEXTAREA') < 0 && alle.indexOf('SELECT') < 0);
  ok('keine Kurve im Band', alle.indexOf('CANVAS') < 0 && alle.indexOf('SVG') < 0);
  ok('nur Klapp-, Geraete- und Oeffnen-Knoepfe',
    alle.filter((t) => t === 'BUTTON').length === 1 + 2 * 2, String(alle.filter((t) => t === 'BUTTON').length));
}

// ================================================================ 9. Neuzeichnen nur bei Aenderung
console.log('\n9) Neu gezeichnet wird nur bei geaenderter Signatur');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  let jetzt = T0;
  L.VN.montiere(b, { jetzt: () => jetzt });
  L.VN.setze(botschaft([saal()]));
  const erste = sammle(b, 'vsn-karte')[0];

  for (let i = 1; i <= 20; i++) {
    jetzt = T0 + i * 1000;
    L.VN.setze(botschaft([saal({ uebertragungMs: 700 + i })], { ts: T0 + i * 1000 }));
  }
  ok('20 Nachrichten mit gleichen Werten bauen die Karte NICHT neu', sammle(b, 'vsn-karte')[0] === erste);

  jetzt = T0 + 21000;
  L.VN.setze(botschaft([saal({ patients: [kachel({ hr: 140 })] })]));
  const zweite = sammle(b, 'vsn-karte')[0];
  ok('ein geaenderter Messwert baut neu', zweite !== erste);
  ok('und der neue Wert steht da', sammle(b, 'vsn-werte')[0].textContent.indexOf('HF 140') === 0,
    sammle(b, 'vsn-werte')[0].textContent);
}

// ================================================================ 10. Alterung im Band
console.log('\n10) das sekuendliche Alter kommt aus dem eigenen Zeitgeber');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  let jetzt = T0;
  L.VN.montiere(b, { jetzt: () => jetzt });
  const tick = () => L.takte[0].fn();

  L.VN.setze(botschaft([saal({ uebertragungMs: 800 })]));
  const karte = sammle(b, 'vsn-karte')[0];
  const alter = sammle(b, 'vsn-alter')[0];
  ok('frisch ist live', karte.classList.contains('s-live') && alter.textContent === 'live', alter.textContent);

  // KEINE neue Nachricht — nur die Uhr laeuft weiter. Genau so verhaelt sich ein Abriss.
  jetzt = T0 + 20000; tick();
  ok('nach 20 s Stille: gelb', karte.classList.contains('s-alt') && !karte.classList.contains('s-live'));
  ok('und der Text nennt die Sekunden', /keine neuen Daten \(2[01]s\)/.test(alter.textContent), alter.textContent);
  ok('die Karte ist dieselbe geblieben (kein Neuzeichnen)', sammle(b, 'vsn-karte')[0] === karte);
  ok('die Zahlen stehen in dieser Stufe noch da', sammle(b, 'vsn-werte')[0].textContent.indexOf('HF 88') === 0);

  jetzt = T0 + 125000; tick();
  ok('nach ueber 60 s: offline', karte.classList.contains('s-offline'));
  ok('und der Text nennt den Saal', alter.textContent === 'OP 2 offline seit 2 min', alter.textContent);
  ok('die Zahlen werden ERSETZT, nicht nur eingefaerbt',
    sammle(b, 'vsn-ersatz')[0].textContent === 'Stand vor 2 min', sammle(b, 'vsn-ersatz')[0].textContent);
  ok('das Stilblatt blendet die Zahlen in dieser Stufe aus',
    L.doc.head.childNodes[0].textContent.indexOf('.vsn-karte.s-offline .vsn-werte') >= 0);
  ok('immer noch dieselbe Karte', sammle(b, 'vsn-karte')[0] === karte);

  /*
   * 31.07.2026, Gegenpruefung: die Sekundenzahl in "keine neuen Daten (Xs)" wurde von keiner
   * Pruefung beim WEITERLAUFEN erwischt — sie wurde nur einmal je Stufe gelesen. Eine Fassung, die
   * den Text ausschliesslich beim Stufenwechsel schreibt, kam ungestraft durch die ganze Reihe.
   * Deshalb zwei Takte INNERHALB derselben Stufe.
   */
  jetzt = T0 + 30000; tick();
  const beiDreissig = alter.textContent;
  jetzt = T0 + 45000; tick();
  ok('die Sekundenzahl laeuft INNERHALB der gelben Stufe weiter',
    karte.classList.contains('s-alt') && alter.textContent !== beiDreissig
    && /keine neuen Daten \(4[56]s\)/.test(alter.textContent), beiDreissig + ' -> ' + alter.textContent);

  /*
   * Ueber 12 h. fremdstore.js wirft solche Saele aus der Liste, aber der oertliche Zeitgeber
   * rechnet weiter, waehrend die Nachricht steht — und fremdstore.js:1007 setzt 'ersetzt' NUR bei
   * der Stufe 'offline', schickt einen 13-h-Saal (Cloud gewinnt bei Widerspruch gegen frisches
   * LAN) also MIT Vitalwerten. Ohne eigene Regeln fuer 'weg' kamen die eingefrorenen Zahlen wieder
   * zum Vorschein, und die Altersmarke fiel auf ihre gruene Grundfarbe zurueck.
   */
  jetzt = T0 + 13 * 3600 * 1000; tick();
  const cssW = L.doc.head.childNodes[0].textContent;
  ok('nach 12 h ist die Stufe weg', karte.classList.contains('s-weg'), karte.className);
  ok('die Zahlen bleiben auch dann ersetzt', cssW.indexOf('.vsn-karte.s-weg .vsn-werte') >= 0);
  ok('der Ersatztext bleibt sichtbar', cssW.indexOf('.vsn-karte.s-weg .vsn-ersatz{display:block;}') >= 0);
  ok('und die Altersmarke faellt nicht auf Gruen zurueck',
    cssW.indexOf('.vsn-karte.s-weg .vsn-alter{') >= 0);
  ok('der Text nennt weiterhin den Saal', /^OP 2 offline seit \d+ min$/.test(alter.textContent), alter.textContent);

  // Ein Ruecksprung der eigenen Uhr darf das Band nicht altern lassen.
  jetzt = T0 - 500000; tick();
  ok('ein Uhrenruecksprung altert das Band nicht', karte.classList.contains('s-live'), karte.className);
}

// ================================================================ 11. der toedliche Fall
console.log('\n11) toter Saal, weiterlaufende Bridge — der Fall, der niemandem auffaellt');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  let jetzt = T0;
  L.VN.montiere(b, { jetzt: () => jetzt });

  /*
   * Der Nachbar verstummt, unsere Bridge schickt weiter im Sekundentakt DIESELBEN (eingefrorenen)
   * Werte, nur uebertragungMs waechst. Die Signatur bleibt gleich, also wird nicht neu gezeichnet.
   * Das Band MUSS trotzdem altern — sonst steht ein toter OP-Saal dauerhaft als "live" da.
   */
  L.VN.setze(botschaft([saal({ uebertragungMs: 800 })]));
  const karte = sammle(b, 'vsn-karte')[0];
  for (let i = 1; i <= 130; i++) {
    jetzt = T0 + i * 1000;
    L.VN.setze(botschaft([saal({ uebertragungMs: 800 + i * 1000 })], { ts: T0 + i * 1000 }));
  }
  ok('die Karte wurde nie neu gebaut', sammle(b, 'vsn-karte')[0] === karte);
  ok('der tote Saal steht als offline da', karte.classList.contains('s-offline'), karte.className);
  ok('und seine Zahlen sind ersetzt',
    sammle(b, 'vsn-ersatz')[0].textContent.indexOf('Stand vor ') === 0, sammle(b, 'vsn-ersatz')[0].textContent);
}

// ================================================================ 12. Alarm
console.log('\n12) Alarm im Nachbarsaal');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  let jetzt = T0;
  L.VN.montiere(b, { jetzt: () => jetzt });
  L.VN.setze(botschaft([saal({ patients: [kachel({ pri: 5, al: 2, top: 'Bradykardie' })] })]));
  const karte = sammle(b, 'vsn-karte')[0];
  ok('die Karte pulsiert', karte.classList.contains('alarm'));
  ok('die Kachel traegt die CPR-Farbe', sammle(b, 'vsn-kachel')[0].classList.contains('p5'));
  ok('der Befund steht daneben', sammle(b, 'vsn-top')[0].textContent === 'Bradykardie · 2 Alarm',
    sammle(b, 'vsn-top')[0].textContent);
  ok('das Pulsieren steht im Stilblatt, nicht am Knoten',
    L.doc.head.childNodes[0].textContent.indexOf('@keyframes vsn-puls') > 0);

  jetzt = T0 + 200000; L.takte[0].fn();
  ok('ein Alarm aus einem offline gegangenen Saal pulsiert NICHT mehr', !karte.classList.contains('alarm'));

  const ruhig = lade();
  const b2 = behaelterVon(ruhig.doc);
  ruhig.VN.montiere(b2, { jetzt: () => T0 });
  ruhig.VN.setze(botschaft([saal()]));
  ok('ein ruhiger Saal pulsiert nicht', !sammle(b2, 'vsn-karte')[0].classList.contains('alarm'));
}

// ================================================================ 13. Knoepfe
console.log('\n13) Klicks — Hoehe, Geraetezeile, "OP 2 oeffnen"');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  let jetzt = T0;
  const gerufen = [];
  L.VN.montiere(b, { jetzt: () => jetzt, beimOeffnen: (sid, s) => gerufen.push([sid, s && s.name]) });
  L.VN.setze(botschaft([saal()]));
  const band = b.childNodes[0];
  const klapp = sammle(band, 'vsn-klapp')[0];

  ok('der Klapp-Knopf zaehlt die Saele', klapp.textContent.indexOf('Nachbarsaele (1)') > 0, klapp.textContent);
  ok('vor dem Klick eingeklappt', !band.classList.contains('auf'));
  klapp.onclick();
  ok('EIN KLICK aendert die Hoehe', band.classList.contains('auf'));
  ok('und der Zustand liegt in localStorage', L.speicher[L.VN.pur.SPEICHER] === 'auf');
  L.VN.setze(botschaft([saal({ patients: [kachel({ hr: 150 })] })]));
  ok('eintreffende Daten aendern die Hoehe NICHT zurueck', band.classList.contains('auf'));
  klapp.onclick();
  ok('ein zweiter Klick klappt wieder ein', !band.classList.contains('auf'));
  ok('auch das wird gemerkt', L.speicher[L.VN.pur.SPEICHER] === 'zu');

  // Der gemerkte Zustand gilt beim naechsten Start.
  const wieder = lade();
  wieder.speicher[wieder.VN.pur.SPEICHER] = 'auf';
  const b2 = behaelterVon(wieder.doc);
  wieder.VN.montiere(b2, { jetzt: () => T0 });
  ok('der gemerkte Zustand gilt nach dem Neustart', b2.childNodes[0].classList.contains('auf'));

  // Geraetezeile: ausklappbar, reine Ansicht (N13).
  const karte = sammle(b, 'vsn-karte')[0];
  const gKnopf = sammle(band, 'vsn-kbtn')[0];
  ok('der Geraete-Knopf zaehlt die Geraete', gKnopf.textContent === 'Geraete (1)', gKnopf.textContent);
  ok('die Geraetezeile ist zunaechst zu', !karte.classList.contains('gauf'));
  gKnopf.onclick();
  ok('ein Klick klappt sie aus', karte.classList.contains('gauf'));
  const gtext = sammle(band, 'vsn-gtext')[0].textContent;
  ok('sie nennt Modell, Rolle und Adresse', gtext === 'uMEC12 · monitor · 192.168.1.50:3502', gtext);
  ok('sie nennt den Status', sammle(band, 'vsn-gstatus')[0].textContent === 'sendet');
  ok('sie nennt ein Alter', sammle(band, 'vsn-galter')[0].textContent.length > 0);
  ok('die Geraetezeile liegt als Overlay ueber der Karte (keine Hoehenaenderung)',
    L.doc.head.childNodes[0].textContent.indexOf('.vsn-gpanel{display:none;position:absolute') >= 0);
  gKnopf.onclick();
  ok('ein zweiter Klick klappt sie wieder ein', !karte.classList.contains('gauf'));

  // "OP 2 oeffnen" loest NUR den Rueckruf aus.
  const oKnopf = sammle(band, 'vsn-kbtn')[1];
  ok('der Knopf heisst nach dem Saal', oKnopf.textContent === 'OP 2 oeffnen', oKnopf.textContent);
  oKnopf.onclick();
  ok('er ruft den Einbetter mit sid und Saal', gerufen.length === 1
    && gerufen[0][0] === 'st7f3a91c2b45d' && gerufen[0][1] === 'OP 2', JSON.stringify(gerufen));

  // Ohne Rueckruf darf nichts passieren und nichts werfen.
  const stumm = lade();
  const b3 = behaelterVon(stumm.doc);
  const meldungen = [];
  stumm.VN.montiere(b3, { jetzt: () => T0, log: (m) => meldungen.push(m) });
  stumm.VN.setze(botschaft([saal()]));
  sammle(b3, 'vsn-kbtn')[1].onclick();
  ok('ohne beimOeffnen passiert nichts ausser einer Logzeile',
    meldungen.some((m) => /bleibt ohne Wirkung/.test(m)), meldungen.join(' | '));
}

// ================================================================ 14. Deckel und Warnzeile im Band
console.log('\n14) Deckel und Warnungen stehen im Band (N17)');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  L.VN.montiere(b, { jetzt: () => T0 });
  const neun = [];
  for (let i = 0; i < 9; i++) neun.push(saal({ sid: 'st00000000000' + i, name: 'OP ' + i }));
  L.VN.setze(botschaft(neun));
  ok('nur 8 Karten', sammle(b, 'vsn-karte').length === 8, String(sammle(b, 'vsn-karte').length));
  const warn = sammle(b, 'vsn-warn')[0];
  ok('der Deckel steht in der Kopfzeile',
    /Deckel erreicht/.test(warn.textContent), warn.textContent);
  ok('der Klapp-Knopf nennt die verdraengten Saele',
    /\(8\+1\)/.test(sammle(b, 'vsn-klapp')[0].textContent), sammle(b, 'vsn-klapp')[0].textContent);

  const L2 = lade();
  const b2 = behaelterVon(L2.doc);
  L2.VN.montiere(b2, { jetzt: () => T0 });
  const viele = [];
  for (let i = 0; i < 15; i++) viele.push(kachel({ key: 'k' + i, n: 'Tier ' + i }));
  L2.VN.setze(botschaft([saal({ patients: viele })]));
  ok('nur 12 Kacheln', sammle(b2, 'vsn-kachel').length === 12, String(sammle(b2, 'vsn-kachel').length));
  ok('die verdraengten Kacheln stehen als Zeile in der Karte',
    sammle(b2, 'vsn-mehr').some((k) => /3 weitere Patienten werden nicht angezeigt — Deckel erreicht/.test(k.textContent)),
    sammle(b2, 'vsn-mehr').map((k) => k.textContent).join(' | '));

  const L3 = lade();
  const b3 = behaelterVon(L3.doc);
  L3.VN.montiere(b3, { jetzt: () => T0 });
  L3.VN.setze(botschaft([saal({ name: 'OP 1' }), saal({ sid: 'stb1c2d3e4f506', name: 'OP 1' })]));
  ok('doppelter Saalname erzeugt eine Warnzeile',
    /heissen gleich/.test(sammle(b3, 'vsn-warn')[0].textContent), sammle(b3, 'vsn-warn')[0].textContent);
  ok('beide Karten sind markiert', sammle(b3, 'vsn-karte').every((k) => k.classList.contains('dop')));
  /*
   * 31.07.2026, Gegenpruefung: hier stand 'typeof ... === "string"' — das ist IMMER wahr, auch bei
   * einem leeren Tooltip. Eine Fassung, die den Tooltip gar nicht mehr fuellt, kam ungestraft durch
   * die ganze Reihe. Geprueft wird jetzt der Inhalt, denn die Kopfzeile zeigt nur die ERSTE Warnung
   * im Klartext; alles andere ist ausschliesslich im Tooltip zu lesen.
   */
  const L3b = lade();
  const b3b = behaelterVon(L3b.doc);
  L3b.VN.montiere(b3b, { jetzt: () => T0 });
  L3b.VN.setze(botschaft([saal({ name: 'OP 1' }), saal({ sid: 'stb1c2d3e4f506', name: 'OP 1' })],
    { hinweise: ['2 weitere OP-Saele werden nicht angezeigt — Deckel erreicht'] }));
  const tip = sammle(b3b, 'vsn-warn')[0].title;
  ok('die Hinweise der Bridge landen im Tooltip', /Deckel erreicht/.test(tip), JSON.stringify(tip));
  ok('und die eigene Warnung steht dort ebenfalls', /heissen gleich/.test(tip), JSON.stringify(tip));

  const L4 = lade();
  const b4 = behaelterVon(L4.doc);
  L4.VN.montiere(b4, { jetzt: () => T0 });
  L4.VN.setze(botschaft([saal({ widerspruch: true, blind: true, name: '' })]));
  const marken = sammle(b4, 'vsn-marke').map((k) => k.textContent);
  ok('ein Widerspruch ist sichtbar', marken.indexOf('Widerspruch') >= 0, marken.join('|'));
  ok('ein eigener Leseausfall wird nicht dem Nachbarn angelastet',
    marken.indexOf('eigener Leseweg') >= 0, marken.join('|'));
  ok('ein Saal ohne Namen heisst wie in tafel.js',
    sammle(b4, 'vsn-kname')[0].textContent === L4.VN.pur.NAME_UNBENANNT, sammle(b4, 'vsn-kname')[0].textContent);
}

// ================================================================ 15. aus()
console.log('\n15) aus() — Band leer, Zeitgeber gestoppt');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  L.VN.montiere(b, { jetzt: () => T0 });
  L.VN.setze(botschaft([saal()]));
  ok('vorher steht etwas da', b.childNodes.length === 1 && sammle(b, 'vsn-karte').length === 1);
  L.VN.aus();
  ok('der Behaelter ist leer', b.childNodes.length === 0);
  ok('die Halter-Klasse ist weg', !b.classList.contains('vsn-halter'));
  ok('der Zeitgeber ist gestoppt', L.takte[0].gestoppt === true);
  L.VN.setze(botschaft([saal()]));
  ok('setze nach aus() tut nichts und wirft nicht', b.childNodes.length === 0);
  L.VN.montiere(b, { jetzt: () => T0 });
  L.VN.setze(botschaft([saal()]));
  ok('erneutes Montieren funktioniert', sammle(b, 'vsn-karte').length === 1);
  ok('das Stilblatt wurde nicht doppelt eingehaengt',
    L.doc.head.childNodes.filter((k) => k.tagName === 'STYLE').length === 1);
}

// ================================================================ 16. Robustheit
console.log('\n16) das Band darf an keiner Nachricht zerbrechen');
{
  const L = lade();
  const b = behaelterVon(L.doc);
  L.VN.montiere(b, { jetzt: () => T0 });
  const muell = [
    null, undefined, 42, 'fremd', [], {},
    { type: 'patients' },
    { type: 'fremd' },
    { type: 'fremd', saele: null },
    { type: 'fremd', saele: [null, 7, 'x', {}] },
    { type: 'fremd', saele: [{ sid: 'st7f3a91c2b45d', patients: 'nein', geraete: 5 }] },
    { type: 'fremd', saele: [{ sid: 'st7f3a91c2b45d', patients: [null], geraete: [null] }] },
    { type: 'fremd', saele: [{ sid: 'st7f3a91c2b45d', uebertragungMs: 'bald' }], hinweise: 'nein' },
    { type: 'fremd', saele: [{ sid: 'st7f3a91c2b45d', uebertragungMs: NaN, patients: [{ hr: Infinity }] }] },
  ];
  let geworfen = null;
  try {
    muell.forEach((m) => { L.VN.setze(m); L.takte[0].fn(); });
  } catch (e) { geworfen = e; }
  ok('keine Nachricht wirft', !geworfen, geworfen && geworfen.message);
  ok('eine Nachricht ohne type wird gar nicht erst angenommen',
    (function () { const P = L.VN.pur; return P.nimm({ saele: [saal()] }).saele.length === 1; }()));
  ok('NaN wird nie als Zahl angezeigt',
    sammle(b, 'vsn-werte').every((k) => k.textContent.indexOf('NaN') < 0));
  ok('Infinity wird nie als Zahl angezeigt',
    sammle(b, 'vsn-werte').every((k) => k.textContent.indexOf('Infinity') < 0));
}

// ================================================================
console.log('\n' + (fail ? '✗ ' : '✓ ') + pass + ' Pruefungen OK, ' + fail + ' Fehler');
process.exit(fail ? 1 : 0);
