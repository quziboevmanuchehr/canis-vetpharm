'use strict';
/*
 * seriell-pruefen.js — MISST, ob ein serielles Geraet erreichbar ist. Es vermutet nichts.
 *
 * WOFUER: Geraete ohne Netzwerkbuchse (Draeger MEDIBUS, Datex-Ohmeda/GE S/5, aeltere Monitore)
 * geben ihre Werte ueber RS-232 heraus. Bevor irgendein Adapter darauf gebaut wird, muss belegt
 * sein, DASS dort Bytes ankommen und WIE sie aussehen. Genau diese Reihenfolge hat sich in diesem
 * Projekt bewaehrt: erst den echten Datenstrom ansehen, dann den Parser bauen — nie umgekehrt.
 *
 * Aufruf:
 *   node tools/seriell-pruefen.js                          nur auflisten, was der PC kennt
 *   node tools/seriell-pruefen.js --com COM3 [--baud 9600] 30 s mitlesen und Rohbytes zeigen
 *   node tools/seriell-pruefen.js --host 192.168.0.60 --port 4001    dasselbe ueber Geraeteserver
 *
 * STRIKT READ-ONLY: es wird nur gelesen. An kein Geraet geht ein Byte.
 */
const s = require('../bridge/src/seriell');
const erk = require('../bridge/src/geraeteerkennung');

const arg = process.argv.slice(2);
function wert(n) { const i = arg.indexOf(n); return i >= 0 ? arg[i + 1] : null; }

const com = wert('--com');
const host = wert('--host');
const port = wert('--port');
const baud = Number(wert('--baud')) || 9600;
const sekunden = Number(wert('--sekunden')) || 30;

const log = {
  info: (a, b) => console.log('  ' + b),
  warn: (a, b) => console.log('  ! ' + b),
  error: (a, b) => console.log('  X ' + b),
};

console.log('VetStation — serielle Schnittstelle pruefen\n');

s.schnittstellen().then((r) => {
  console.log('Serielle Anschluesse dieses PCs:');
  if (!r.ok) console.log('  ' + r.grund);
  else if (!r.liste.length) console.log('  keiner. ' + (r.grund || ''));
  else r.liste.forEach((x) => console.log('  • ' + x.name + '   (' + x.geraet + ')'));

  if (!com && !host) {
    console.log('\nZum Mitlesen:');
    console.log('  node tools/seriell-pruefen.js --com COM3 --baud 9600');
    console.log('  node tools/seriell-pruefen.js --host <Geraeteserver> --port 4001');
    console.log('\nEMPFEHLUNG: Ein Geraeteserver (RS-232 auf LAN, z. B. Moxa NPort oder USR-TCP232,');
    console.log('etwa 30-80 EUR) ist der zuverlaessigere Weg — VetStation liest ihn ueber ihren');
    console.log('erprobten Netzweg, es braucht keinen Treiber, und das Geraet darf stehen bleiben,');
    console.log('wo es steht.');
    return;
  }

  const cfg = com ? { art: 'com', port: com, baud: baud } : { art: 'tcp', host: host, tcpPort: Number(port) };
  const v = new s.SerielleVerbindung(cfg, { log: log });
  let puffer = Buffer.alloc(0);
  let pakete = 0;

  console.log('\nVerbinde …');
  v.beiDaten((d) => {
    pakete++;
    if (puffer.length < 4096) puffer = Buffer.concat([puffer, d]);
    process.stdout.write('.');
  });
  v.oeffnen().then(() => {
    console.log('Verbunden. Lese ' + sekunden + ' s mit (rein lesend) …');
    setTimeout(() => {
      v.schliessen();
      console.log('\n\nErgebnis:');
      console.log('  Pakete: ' + pakete + '   Bytes: ' + v.gelesen);
      if (!v.gelesen) {
        console.log('  ES KAM NICHTS AN. Das heisst NICHT, dass die Station schuld ist. Der Reihe nach pruefen:');
        console.log('   1. Sendet das Geraet ueberhaupt? Viele Monitore geben erst Daten heraus, wenn im');
        console.log('      Menue ein Datenexport eingeschaltet ist — und erst, wenn Sensoren wirklich messen.');
        console.log('   2. Stimmt die Baudrate? Steht im Handbuch des Geraets.');
        console.log('   3. Ist es das richtige Kabel? Viele Geraete brauchen ein NULLMODEM-Kabel (gekreuzt).');
        console.log('   4. Verlangt das Protokoll eine Anfrage? MEDIBUS zum Beispiel schweigt, bis der PC fragt.');
        return;
      }
      console.log('  Erste Bytes (hex): ' + puffer.slice(0, 48).toString('hex'));
      console.log('  Erste Bytes (Text): ' + JSON.stringify(puffer.slice(0, 96).toString('latin1')));
      const p = erk.protokollAusBytes(puffer);
      console.log('  Erkanntes Protokoll: ' + p.name + (p.lesbar ? '  (VetStation kann das lesen)' : '  (dafuer gibt es hier noch keinen Leser)'));
      console.log('\n  Diesen Mitschnitt aufheben — daraus laesst sich jedes Feld BELEGEN, statt es zu vermuten.');
    }, sekunden * 1000);
  }).catch((e) => {
    console.log('  Verbindung nicht moeglich: ' + e.message);
    process.exitCode = 1;
  });
});
