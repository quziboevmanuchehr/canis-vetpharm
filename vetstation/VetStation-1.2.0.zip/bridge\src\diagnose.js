'use strict';
/*
 * diagnose.js — sagt im KLARTEXT, WO das Problem liegt.
 *
 * WARUM ES DIESE DATEI GIBT (Kernbefund 21.07.2026):
 * "Die App war nicht schuld, dass keine Werte ankamen — aber sie hat es VERSCHWIEGEN."
 * Empfang, Auswertung und Patientenbildung funktionierten nachweislich; was fehlte, war jede
 * brauchbare Information darueber, WARUM nichts ankommt. Der Anwender suchte am falschen Ende.
 *
 * Diese Datei nimmt die Messwerte der Umgebung (Netzsuche, Firewall, Empfangslage) und leitet
 * daraus eine RANGIERTE Ursachenliste ab — jede mit Begruendung ("warum") und konkretem
 * naechsten Schritt ("tun"). Sie behauptet nie etwas, das sie nicht geprueft hat: was unklar
 * ist, heisst 'unklar'.
 *
 * PURE FUNKTION (kein Netz, keine Dateien) -> vollstaendig testbar: tools/diagnose-test.js
 */

const ZIEL = { ip: '192.168.0.99', port: 3502, netz: '192.168.0.', monitor: '192.168.0.50' };

// Erkennt ein Medizingeraet an der MAC, auch wenn es (wegen eines Adresskonflikts) sonst
// falsch eingestuft waere. 98:CC:E4 / 00:0F:14 = Mindray bzw. Mindray/Eickemeyer.
function istMedizin(h) { return !!(h && h.mac && /^(98cce4|000f14)/.test(h.mac)); }

// schwere 3 = es kann NICHTS ankommen · 2 = wahrscheinliche Ursache · 1 = Hinweis/Aufraeumen
function befund(code, schwere, titel, warum, tun) {
  return { code: code, schwere: schwere, titel: titel, warum: warum, tun: tun || [] };
}

/*
 * diagnose(lage) -> { urteil, kurz, befunde[] }
 *
 * lage = {
 *   scan:      netscan.scan()-Ergebnis oder null,
 *   firewall:  firewall.pruefe()-Ergebnis oder null,
 *   empfang:   { aktiv:bool, geraete:n, letzteDatenVorMs:number|null },
 *   cloud:     cloud.status() oder null,
 *   fremdBelegt: [{port, }] Datenports, die ein FREMDER Prozess belegt,
 *   ziel:      { ip, port } (Default 192.168.0.99:3502)
 * }
 */
function diagnose(lage) {
  lage = lage || {};
  const ziel = Object.assign({}, ZIEL, lage.ziel || {});
  const scan = lage.scan || null;
  const fw = lage.firewall || null;
  const empfang = lage.empfang || { aktiv: false, geraete: 0, letzteDatenVorMs: null };
  const b = [];

  const adapters = (scan && scan.adapters) || [];
  const echte = adapters.filter((a) => !a.virtuell);
  const hosts = (scan && scan.hosts) || [];
  const sichere = hosts.filter((h) => h.stufe === 'sicher');
  const mitDatenport = sichere.filter((h) => (h.datenPorts || []).length > 0);
  const ohneDatenport = sichere.filter((h) => !(h.datenPorts || []).length);

  /* ---------------- 1) Der PC selbst ---------------- */
  if (scan && !adapters.length) {
    b.push(befund('KEIN_NETZ', 3,
      'Dieser PC hat gar keine Netzwerkverbindung',
      'Windows meldet keine einzige aktive Netzwerkkarte. Ohne Netz kann kein Geraet Daten liefern.',
      ['LAN-Kabel am PC und am Switch pruefen (beide Stecker muessen klicken).',
       'Leuchtet die Buchse am PC nicht, ist das Kabel oder der Switch die Ursache — nicht die Software.']));
  } else if (scan && !echte.length && adapters.length) {
    b.push(befund('NUR_VIRTUELL', 3,
      'Es gibt nur virtuelle Netzwerkkarten (VPN/Hyper-V)',
      'Gefunden: ' + adapters.map((a) => a.name).join(', ') + '. Ueber eine virtuelle Karte erreicht der Monitor den PC nicht.',
      ['LAN-Kabel einstecken.',
       'Danach NETZWERK-EINRICHTEN.bat doppelklicken (setzt die feste IP ' + ziel.ip + ').']));
  } else if (scan && echte.length) {
    /*
     * DAS ZIELNETZ WIRD SEIT 01.08.2026 AUS DER TATSAECHLICHEN LAGE ABGELEITET.
     *
     * WAS HIER FALSCH WAR: 192.168.0.x stand als Konstante im Code, weil die erste Praxis so
     * verkabelt war. Jede Praxis, die sauber auf 10.0.0.x, 192.168.1.x oder 172.16.x laeuft,
     * bekam damit dauerhaft den Befund FALSCHES_NETZ mit der Schwere 3 ("es kann nichts
     * ankommen") — und die Handlungsanweisung riet ihr, ihr FUNKTIONIERENDES Netz umzustellen.
     * Ein Fehlalarm der schwersten Stufe, der bei jedem Blick in die Diagnose oben stand.
     *
     * DIE RICHTIGE FRAGE IST EINE ANDERE. Nicht "ist der PC im Netz 192.168.0.x", sondern:
     * "liegen PC und Geraet im SELBEN Netz?" Das laesst sich messen — beide Adressen sind
     * bekannt. Das Netz des PCs ist damit das Zielnetz, egal welches es ist. Der frueher fest
     * eingetragene Wert bleibt nur noch als Rueckfall fuer den Fall, dass gar nichts gemessen
     * werden konnte.
     */
    const eigeneNetze = echte.map((a) => String(a.address).split('.').slice(0, 3).join('.') + '.');
    const geraeteImNetz = sichere.filter((h) => eigeneNetze.some((n) => String(h.ip).indexOf(n) === 0));
    const geraeteAusserhalb = sichere.filter((h) => !eigeneNetze.some((n) => String(h.ip).indexOf(n) === 0));

    if (geraeteAusserhalb.length && !geraeteImNetz.length) {
      /* Der einzige Fall, in dem "falsches Netz" wirklich stimmt: es wurde ein Geraet gefunden,
       * und es liegt nachweislich in einem anderen Netz als jede Karte dieses PCs. */
      b.push(befund('ANDERES_NETZ_GEMESSEN', 3,
        'Geraet und PC liegen in verschiedenen Netzen',
        'Der PC ist in ' + eigeneNetze.map((n) => n + 'x').join(' und ') + ' (' +
        echte.map((a) => a.address).join(', ') + '), das gefundene Geraet in ' +
        geraeteAusserhalb.map((h) => h.ip).join(', ') + '. Zwei verschiedene Netze sehen einander ' +
        'nicht, egal wie richtig alles andere eingestellt ist.',
        ['Am Geraet eine Adresse aus dem Netz dieses PCs eintragen (' + eigeneNetze[0] + 'x) — das ist ' +
          'der kuerzere Weg, weil am PC nichts umgestellt werden muss.',
         'Oder den PC in das Netz des Geraets holen: NETZWERK-EINRICHTEN.bat doppelklicken.']));
    } else if (ziel.strikt) {
      /*
       * Nur wenn ausdruecklich ein Ziel vorgegeben ist (Praxis mit fest dokumentierter Adresse),
       * wird noch dagegen geprueft. Ohne Vorgabe gilt: das Netz, in dem der PC steht, IST das
       * richtige — und der Anwender bekommt statt einer Ruege die Adresse genannt, die er am
       * Geraet eintragen soll.
       */
      const hatZiel = echte.some((a) => a.address === ziel.ip);
      const imNetz = echte.some((a) => a.address.indexOf(ziel.netz) === 0);
      if (!imNetz) {
        b.push(befund('FALSCHES_NETZ', 3,
          'Der PC ist nicht im vorgegebenen Netz ' + ziel.netz + 'x',
          'PC-Adresse: ' + echte.map((a) => a.address).join(', ') + '. Vorgegeben ist ' +
          ziel.ip + ':' + ziel.port + '.',
          ['NETZWERK-EINRICHTEN.bat doppelklicken — setzt den PC auf ' + ziel.ip + '.',
           'Oder am Geraet die oben gezeigte tatsaechliche PC-Adresse eintragen.']));
      } else if (!hatZiel) {
        b.push(befund('ANDERE_PC_IP', 2,
          'Der PC hat nicht die vorgegebene Adresse',
          'Der PC ist im vorgegebenen Netz, hat aber ' +
          echte.filter((a) => a.address.indexOf(ziel.netz) === 0).map((a) => a.address).join(', ') +
          ' statt ' + ziel.ip + '.',
          ['Entweder NETZWERK-EINRICHTEN.bat doppelklicken (setzt ' + ziel.ip + '),',
           'oder am Geraet das Ziel auf die tatsaechliche PC-Adresse aendern.']));
      }
    }

    /*
     * UND DER SATZ, DEN EIN TIERARZT WIRKLICH BRAUCHT: welche Adresse traegt er am Geraet ein?
     * Bisher stand die nur dann irgendwo, wenn etwas nicht stimmte. Jetzt steht sie immer —
     * als Hinweis, nicht als Fehler. Bei zwei Netzwerkkarten wird die genannt, in deren Netz
     * tatsaechlich ein Geraet gefunden wurde; nur ohne Fund die bestbewertete.
     */
    /* Nur solange sie gebraucht wird. Kommen bereits Werte an, ist die Adresse eingetragen und
     * der Hinweis waere genau die Sorte Rauschen, die den Blick von echten Befunden abzieht. */
    const laeuftBereits = empfang.aktiv && empfang.letzteDatenVorMs != null && empfang.letzteDatenVorMs < 60000;
    const karteMitGeraet = geraeteImNetz.length
      ? echte.filter((a) => String(geraeteImNetz[0].ip).indexOf(String(a.address).split('.').slice(0, 3).join('.') + '.') === 0)[0]
      : null;
    const pcAdresse = (karteMitGeraet || echte[0]).address;
    if (!laeuftBereits) b.push(befund('PC_ADRESSE', 1,
      'Am Geraet als Ziel eintragen: ' + pcAdresse,
      (echte.length > 1
        ? 'Dieser PC hat mehrere Netzwerkkarten (' + echte.map((a) => a.address).join(', ') + '). ' +
          (karteMitGeraet
            ? 'Genannt ist die Karte, in deren Netz das Geraet gefunden wurde — die andere waere die falsche.'
            : 'Es wurde noch kein Geraet gefunden; genannt ist die wahrscheinlichste Karte. Nach einem ' +
              'Suchlauf steht hier die richtige.')
        : 'Das ist die Adresse, unter der die Station erreichbar ist.'),
      ['Am Geraet im Netzwerk-/HL7-Menue als Server- bzw. Zieladresse ' + pcAdresse + ' eintragen.',
       'Den Port so lassen, wie er am Geraet steht — die Station hoert auf allen ueblichen mit.']));
  }

  /* ---------------- 1b) Ist die Zieladresse ueberhaupt frei? ----------------
   * Am 21.07.2026 im Praxisnetz gemessen: 192.168.0.99 antwortete, obwohl der PC .233 hatte —
   * die Adresse, auf die der PC gesetzt werden soll, war also schon von einem ANDEREN Geraet
   * belegt. Wer jetzt NETZWERK-EINRICHTEN.bat ausfuehrt, baut sich einen Adresskonflikt, und
   * die Verbindung faellt danach sporadisch aus. Genau dieser Fall muss VORHER gesagt werden.
   */
  if (scan && hosts.length && echte.length) {
    const zielHost = hosts.find((h) => h.ip === ziel.ip);
    if (zielHost && !zielHost.selbst && !echte.some((a) => a.address === ziel.ip)) {
      b.push(befund('ZIEL_IP_BESETZT', 2,
        'Die Adresse ' + ziel.ip + ' ist schon von einem anderen Geraet belegt',
        'Der Monitor sendet an ' + ziel.ip + ' — dort antwortet aber bereits ein fremder Teilnehmer' +
        (zielHost.mac ? ' (MAC ' + zielHost.mac + ')' : '') + ', nicht dieser PC. ' +
        'Diesen PC jetzt einfach auf ' + ziel.ip + ' zu setzen, erzeugt einen Adresskonflikt: ' +
        'beide Geraete streiten sich um dieselbe Adresse und die Verbindung faellt sporadisch aus.',
        ['Erst klaeren, was auf ' + ziel.ip + ' liegt — meist hat der Router die Adresse per DHCP vergeben.',
         'Im Router ' + ziel.ip + ' (und .50/.51) aus dem DHCP-Bereich ausnehmen, dann dieses Geraet neu verbinden lassen.',
         'Alternativ am Monitor ein anderes, sicher freies Ziel eintragen und den PC darauf setzen.']));
    }
  }

  /* ---------------- 1c) Ein Medizingeraet auf der Router-Adresse ----------------
   * In der Praxis gemessen (22.07.2026): das LifeVet 10C stand auf 192.168.0.1 - der ueblichen
   * Router-Adresse. Das Geraet meldete selbst "LAN1-IP-Adressenkonflikt", und die Netzsuche fand
   * es ueberhaupt nicht mehr. Wer nur auf den PC schaut, sucht in so einem Fall ewig.
   */
  if (scan && hosts.length) {
    const aufGateway = hosts.filter((h) => h.istGateway && (h.stufe === 'sicher' || istMedizin(h)));
    if (aufGateway.length) {
      b.push(befund('GERAET_AUF_GATEWAY', 3,
        'Ein Geraet benutzt die Adresse des Routers',
        aufGateway.map((h) => h.ip).join(', ') + ' ist ueblicherweise die Router-Adresse — dort haengt ' +
        'aber ein Medizingeraet. Zwei Teilnehmer mit derselben Adresse stoeren sich gegenseitig: ' +
        'das Geraet meldet einen Adresskonflikt und verschwindet zeitweise ganz aus dem Netz.',
        ['Am Geraet eine freie feste Adresse eintragen, z. B. ' + ziel.monitor + ' oder 192.168.0.51.',
         'Menueweg LifeVet 10C: Wartung -> Netzwerk-Setup -> LAN1 -> IP-Adresse.',
         'Danach das Geraet kurz aus- und wieder einschalten und die Suche erneut starten.']));
    }
  }

  /* ---------------- 1d) Laeuft im Netz eine ZWEITE VetStation? ----------------
   * Beobachtet am 22.07.2026: ein zweiter PC antwortete auf ALLE sechs Datenports - das tut nur
   * der Verbindungs-Assistent von VetStation. Das ist an sich harmlos, aber es erklaert eine
   * haeufige Verwirrung: ein Geraet sendet immer nur an EINE eingetragene Zieladresse. Steht dort
   * die Adresse des anderen PCs, kommen HIER nie Werte an - egal wie richtig sonst alles ist.
   */
  if (scan && echte.length) {
    const zweite = hosts.filter((h) => h.zweiteStation);
    if (zweite.length && !empfang.aktiv) {
      const meineIp = (echte[0] && echte[0].address) || ziel.ip;
      /*
       * NEU FORMULIERT AM 31.07.2026 — der alte Text war ab 1.1.0 schlicht falsch.
       *
       * Er lautete "Zwei Stationen duerfen dasselbe Geraet nicht gleichzeitig empfangen" und las
       * sich wie "zwei VetStations in einer Praxis sind ein Fehler". Seit 1.1.0 sind MEHRERE
       * OP-SAELE im selben Praxis-Konto ausdruecklich vorgesehen — ein zweiter PC im Netz ist der
       * NORMALFALL, nicht der Stoerfall. Ein Befund, der den gewuenschten Zustand als Problem
       * meldet, kostet einen Anruf beim Support und, schlimmer, Vertrauen in alle anderen Befunde.
       *
       * WAS TATSAECHLICH NICHT GEHT, bleibt bestehen und ist der ganze Inhalt dieses Befundes:
       * DASSELBE GERAET kann nicht an zwei Stationen senden. Es kennt genau EINE Zieladresse.
       * Deshalb ist dieser Befund auch weiterhin an "hier kommt nichts an" gebunden
       * (empfang.aktiv === false) — laeuft der eigene Empfang, ist der Nachbar-PC kein Thema.
       */
      b.push(befund('ZWEITE_STATION', 2,
        'Im Netz laeuft noch eine VetStation (' + zweite.map((h) => h.ip).join(', ') + ')',
        'Das ist an sich in Ordnung: mehrere OP-Saele in einer Praxis sind vorgesehen, und sie ' +
        'sehen einander, sobald beide am selben Praxis-Konto angemeldet sind (docs/MEHRERE-SAELE.md). ' +
        'Was NICHT geht, ist dasselbe Geraet an zwei Stationen: es sendet seine Werte immer nur an ' +
        'die EINE Adresse, die bei ihm eingetragen ist. Dieser PC hat ' + meineIp + '. Steht am ' +
        'Geraet ' + zweite[0].ip + ', landen die Werte auf dem anderen PC — hier bleibt es leer, ' +
        'obwohl alles richtig eingerichtet ist.',
        ['Am Geraet nachsehen, welche Ziel-IP eingetragen ist, und sie auf ' + meineIp + ' setzen.',
         'Oder umgekehrt: an dem PC weiterarbeiten, dessen Adresse am Geraet steht.',
         'Jeder OP-Saal braucht seine EIGENEN Geraete — geteilt wird die Ansicht, nicht das Geraet.']));
    }
  }

  /* ---------------- 1d2) DOPPELTE STATIONSKENNUNG (ab 1.1.0) ----------------
   *
   * Der einzige Zustand im Mehrsaalbetrieb, der WIRKLICH ein Fehler ist — und der einzige, bei dem
   * die Station von sich aus aufhoert, Patientendaten zu senden. Er entsteht, wenn eine Windows-
   * Installation geklont wird: beide PCs tragen dann dieselbe Kennung und schreiben Feld fuer Feld
   * in denselben Saalzweig. Bei zwei 22-kg-Hunden landen beide unter demselben Schluessel, und
   * niemand sieht es an den Zahlen.
   *
   * Er steht hier oben bei den Netzbefunden und nicht unter "Sonstiges", weil er die schwerste
   * Stufe hat: solange er ansteht, fehlen in der Fern-Ansicht die Patienten dieses Saals. Das ist
   * gewollt (lieber gar nichts als vermischte Werte) — aber es MUSS jemand erfahren.
   *
   * Der Zustand kommt fertig entschieden aus bridge/src/stationsid.js (kollisionsstand()); hier
   * wird er nicht neu hergeleitet. Er wird BEWIESEN, nicht vermutet: ein fremder Schreibvorgang
   * unter der eigenen Kennung, mit fremder Instanzkennung.
   */
  const saal = lage.saal || null;
  if (saal && saal.sperre === 'bewiesen') {
    b.push(befund('STATIONSKENNUNG_DOPPELT', 3,
      'Zwei Stationen benutzen dieselbe Kennung',
      'Eine ANDERE VetStation schreibt unter genau der Kennung dieses Saals' +
      (saal.sid ? ' (' + saal.sid + ')' : '') + '. Fast immer war eine geklonte Windows-Installation ' +
      'die Ursache. Beide wuerden ihre Werte Feld fuer Feld in denselben Saalzweig schreiben — bei ' +
      'zwei gleich schweren Tieren derselben Art waere das an den Zahlen nicht zu erkennen. ' +
      'Deshalb sendet diese Station VORERST KEINE Patientendaten mehr, nur noch ihren Herzschlag. ' +
      'Vor Ort aendert sich nichts: Geraeteempfang, Ueberwachung und Narkoseprotokoll laufen ' +
      'unveraendert weiter.',
      ['An EINEM der beiden PCs eine neue Kennung vergeben: Admin -> OP-Saal -> ' +
       '"Diese Station bekommt eine NEUE Kennung". NICHT waehrend einer Narkose.',
       'Umbenannt wird nie von selbst — eine Station, die das taete, wuerde ihr unveraenderliches ' +
       'Narkoseprotokoll in zwei Teile schneiden.',
       'Einzelheiten: docs/MEHRERE-SAELE.md, Abschnitt "Was passiert, wenn ein PC geklont wurde".']));
  }

  /* ---------------- 1e) Das Geraet liegt woanders als in der Konfiguration ----------------
   * AM PRAXIS-PC GEMESSEN (22.07.2026): in devices.json stand fest 192.168.0.50, das Geraet hing
   * aber auf 192.168.0.51 (Mindray-MAC 00:0f:14, antwortet auf Ping). Im Log stand deshalb
   * gleichzeitig "Geraet gefunden: .51" UND "Geraet .50 antwortet nicht" — beides richtig, und
   * zusammen ergaben sie den falschen Eindruck, das Geraet sei kaputt oder nicht erreichbar.
   * Ursache in aller Regel: der Monitor stand auf DHCP und hat vom Router eine andere Adresse
   * bekommen. Das muss die Station benennen, statt es den Anwender aus zwei Logzeilen schliessen
   * zu lassen.
   */
  const konfigHosts = (lage.konfigHosts || []).filter((h) => h && h !== 'auto');
  if (konfigHosts.length && sichere.length) {
    const gefundene = sichere.map((h) => h.ip);
    const verwaist = konfigHosts.filter((h) => gefundene.indexOf(h) < 0);
    const unbekannt = gefundene.filter((ip) => konfigHosts.indexOf(ip) < 0);
    if (verwaist.length && unbekannt.length) {
      b.push(befund('GERAET_ANDERE_IP', 2,
        'Das Geraet hat eine andere Adresse als in der Konfiguration steht',
        'Eingetragen ist ' + verwaist.join(', ') + ' — dort antwortet niemand. Gefunden wurde das ' +
        'Geraet aber unter ' + unbekannt.join(', ') + '. Die Station fragt also eine tote Adresse ab, ' +
        'waehrend das Geraet daneben im Netz steht. Typische Ursache: der Monitor stand auf DHCP und ' +
        'hat vom Router eine andere Adresse bekommen.',
        ['Dauerhafte Loesung (empfohlen): in bridge\\config\\devices.json bei "host" das Wort "auto" ' +
         'eintragen — dann folgt die Station dem Geraet selbst, egal welche Adresse es bekommt.',
         'Oder am Monitor die feste Adresse wieder eintragen: Wartung -> Benutzer-Wartung (888888) -> ' +
         'Netzwerk -> Adresstyp MANUELL, IP ' + verwaist[0] + '.',
         'Danach NEUSTART.bat doppelklicken.']));
    }
  }

  /* ---------------- 1f) Kein Weg ins Internet: Updates und Fern-Live sind tot ----------------
   * AM PRAXIS-PC GEMESSEN (22.07.2026): 192.168.0.99/24 OHNE Standardgateway und ohne DNS, obwohl
   * unter 192.168.0.1 ein Router antwortet (der PC haengt ueber einen TP-Link-Verstaerker am
   * Hausnetz). Fuer die GERAETEDATEN ist das egal — sie laufen im selben Netz. Aber:
   *   • Admin -> Aktualisieren kann kein Update laden,
   *   • Fern-Live kann nichts senden,
   *   • die klinischen Daten koennen sich nicht mehr aktualisieren.
   * Das sieht man dem PC nicht an, und es wurde bisher nirgends gesagt.
   */
  const inet = lage.internet || null;

  /* Nur IPv6 — funktioniert, steht aber auf einem Bein.
   * AM PRAXIS-PC GEMESSEN (22.07.2026): kein IPv4-Standardgateway, aber der Kabelrouter lieferte
   * per Router Advertisement eine vollstaendige IPv6-Verbindung mit DNS. Update-Manifest und
   * klinische Daten waren darueber erreichbar (HTTP 200) - die Station lief also, ohne dass
   * jemand wusste, WORUEBER. Fuer eine Narkose-Station ist das ein Zustand, den man kennen muss:
   * jeder Dienst ohne AAAA-Eintrag ist unerreichbar, und schaltet der Router IPv6 ab, faellt
   * alles auf einmal aus - ohne Fehlermeldung. */
  if (inet && inet.nurV6) {
    b.push(befund('NUR_IPV6', 1,
      'Der PC kommt nur ueber IPv6 ins Internet — das funktioniert, ist aber fragil',
      'Ein IPv4-Standardgateway ist nicht eingetragen' +
      (inet.routerImNetz ? ' (obwohl unter ' + inet.router + ' ein Router antwortet)' : '') +
      '. Ueber IPv6 besteht dagegen eine vollstaendige Verbindung — daher laufen Update und ' +
      'klinische Daten derzeit. Zwei Haken: Dienste ohne IPv6-Adresse (AAAA) sind gar nicht ' +
      'erreichbar, und schaltet der Router IPv6 ab, faellt alles gleichzeitig aus, ohne dass ' +
      'irgendwo ein Fehler erscheint. Die GERAETEDATEN sind davon NICHT betroffen.',
      inet.routerImNetz
        ? ['INTERNET-EINRICHTEN.bat doppelklicken — traegt zusaetzlich das IPv4-Gateway ' + inet.router +
           ' und DNS ein. Die feste IP und damit die Geraeteverbindung bleiben unveraendert.',
           'Danach steht die Station auf beiden Beinen (IPv4 und IPv6).']
        : ['Kein Handlungsbedarf, solange Update und klinische Daten laden.',
           'Faellt beides ploetzlich aus, zuerst hier nachsehen: dann hat der Router IPv6 abgeschaltet.']));
  }

  if (inet && inet.erreichbar === false) {
    const routerDa = !!inet.routerImNetz;
    b.push(befund('KEIN_INTERNET', 1,
      'Dieser PC kommt nicht ins Internet — Updates und Fern-Live koennen nicht funktionieren',
      (inet.gateway
        ? 'Eingetragenes Standardgateway: ' + inet.gateway + ', erreichbar ist es trotzdem nicht.'
        : 'Es ist kein Standardgateway eingetragen (die feste IP wurde fuer ein ISOLIERTES Geraetenetz gesetzt).') +
      (routerDa
        ? ' Im selben Netz antwortet aber ein Router (' + inet.router + '). Der PC koennte also ins Internet, ' +
          'er hat nur keinen Weg dorthin eingetragen.'
        : ' Im Netz antwortet auch kein Router.') +
      ' Die GERAETEDATEN sind davon NICHT betroffen — Monitor und PC liegen im selben Netz.',
      routerDa
        ? ['INTERNET-EINRICHTEN.bat doppelklicken — traegt Gateway ' + inet.router + ' und DNS nach, ' +
           'ohne die feste IP zu aendern (die Geraeteverbindung bleibt also, wie sie ist).',
           'Danach laufen Admin -> Aktualisieren, Fern-Live und die klinischen Daten wieder.']
        : ['Nur noetig, wenn Updates/Fern-Live gewuenscht sind: den PC zusaetzlich ans Praxisnetz haengen.',
           'Fuer den reinen Geraetebetrieb ist das isolierte Netz ohne Gateway die sicherere Variante.']));
  }

  /* ---------------- 2) Netzform ---------------- */
  if (scan && scan.routerNetz) {
    b.push(befund('ROUTER_NETZ', 2,
      'Der PC haengt am Router-Netz, nicht an einem eigenen Geraete-Switch',
      'Neben dem Router antworten mehrere Fremdgeraete (Handys, Drucker, andere PCs). Das funktioniert — ' +
      'aber der Router kann per DHCP ausgerechnet ' + ziel.monitor + ' an ein Handy vergeben. Dann kollidiert ' +
      'die Adresse mit dem Monitor und die Verbindung faellt sporadisch aus.',
      ['Sauber: PC, Monitor und Narkosegeraet allein an einen eigenen Switch haengen.',
       'Sonst im Router die Adressen .50, .51 und .99 aus dem DHCP-Bereich ausnehmen.']));
  }

  /* ---------------- 3) Ist ueberhaupt ein Geraet da? ---------------- */
  if (scan && scan.netz) {
    if (!hosts.length) {
      b.push(befund('NIEMAND_IM_NETZ', 3,
        'Kein einziger Teilnehmer im Netz gefunden',
        'Alle Adressen ' + scan.netz.base + '1 bis ' + scan.netz.base + '254 wurden aktiv angesprochen — ' +
        'niemand hat geantwortet. Der PC haengt also allein am Kabel.',
        ['Ist der Monitor eingeschaltet und das LAN-Kabel gesteckt?',
         'Haengen PC und Monitor am SELBEN Switch?',
         'Am Monitor pruefen: Wartung -> Benutzer-Wartung (888888) -> Netzwerk. Steht dort 0.0.0.0, hat das Geraet keine Adresse — auf MANUELL stellen und ' + ziel.monitor + ' eintragen.']));
    } else if (!sichere.length) {
      const fremde = hosts.filter((h) => h.stufe === 'unwahrscheinlich').length;
      const moegliche = hosts.filter((h) => h.stufe === 'moeglich').length;
      b.push(befund('KEIN_GERAET', 3,
        'Teilnehmer im Netz gefunden, aber kein Medizingeraet darunter',
        hosts.length + ' Teilnehmer antworten (' + fremde + ' erkennbar Buero-PC/Drucker/Router, ' +
        moegliche + ' unbestimmt). Keiner davon hat einen Datenport offen oder eine Geraete-MAC.',
        ['Monitor einschalten und Netzwerkkabel pruefen.',
         'Am Monitor die feste Adresse ' + ziel.monitor + ' setzen (Wartung -> Benutzer-Wartung 888888 -> Netzwerk -> MANUELL).',
         'Danach diese Pruefung noch einmal starten.']));
    }
  }

  /* ---------------- 4) Geraet da, aber still ---------------- */
  if (ohneDatenport.length && !empfang.aktiv) {
    // Die eigene Adresse dieses PCs nennen - genau sie muss am Geraet als Ziel stehen.
    const meineIp = (echte[0] && echte[0].address) || ziel.ip;
    b.push(befund('GERAET_GEFUNDEN_STILL', 3,
      'Geraet gefunden (' + ohneDatenport.map((h) => h.ip).join(', ') + ') — es kommen aber keine Werte an',
      'Die Adresse antwortet und die MAC weist ein Medizingeraet aus. Dass dort kein Datenport offen ' +
      'ist, ist KEIN Fehler: ein Monitor, der seine Werte von sich aus sendet, lauscht nicht — er ruft ' +
      'den PC an. Es fehlt also nicht die Erreichbarkeit, sondern das Ziel oder der Sendeschalter.',
      ['Am Geraet pruefen, ob als Ziel GENAU die Adresse dieses PCs steht: ' + meineIp + '.',
       'LifeVet 10C: Wartung -> Netzwerk-Setup -> HL7-Konfiguration -> "Daten + Kurven": Ziel-IP ' + meineIp +
       ', "Daten senden" EIN, Datenintervall auf den kleinsten Wert (30 s sind fuer eine Narkose zu traege).',
       'uMEC12 Vet: Wartung -> Benutzer-Wartung (888888) -> Netzwerk -> Gateway-Kommunikationseinst.: Ziel ' +
       meineIp + ', Port ' + ziel.port + ', "Real Data Send" EIN.',
       'Steht unter Netzwerk-Setup "CMS auswaehlen: Aus", diesen Punkt einschalten.',
       'Danach NEUSTART.bat doppelklicken und erneut pruefen.']));
  }

  if (mitDatenport.length && !empfang.aktiv) {
    b.push(befund('GERAET_OK_ABER_STILL', 3,
      'Das Geraet antwortet auf dem Datenport — es kommen trotzdem keine Werte an',
      'Erreichbar: ' + mitDatenport.map((h) => h.ip + ' (Port ' + h.datenPorts.join('/') + ')').join(', ') +
      '. Die Leitung steht also. Bleibt: die Windows-Firewall verwirft die Pakete lautlos, oder am ' +
      'Geraet ist die Datenausgabe zwar vorbereitet, aber nicht eingeschaltet.',
      ['Firewall pruefen (siehe unten in dieser Liste).',
       'Am Monitor "Real Data Send" bzw. "CMS auswaehlen" einschalten.',
       'VetStation neu starten: NEUSTART.bat doppelklicken.']));
  }

  /* ---------------- 4b) Geraet spricht, aber eine andere Sprache ----------------
   * Am Praxis-PC (22.07.2026) antwortete 192.168.0.50 auf Port 4601 - schickte aber kein HL7.
   * Mindray-Geraete sprechen dort ihr proprietaeres MD2 zur eigenen CentralStation. Das ist ein
   * voellig anderer Fall als "keine Verbindung": die Leitung steht, nur das Format passt nicht.
   * Frueher blieb der Check an dieser Stelle wortlos haengen.
   */
  const proprietaer = lage.proprietaer || [];
  if (proprietaer.length && !empfang.aktiv) {
    b.push(befund('GERAET_SPRICHT_ANDERS', 3,
      'Das Geraet antwortet, spricht aber kein HL7',
      'Auf ' + proprietaer.map((x) => x.ip + ':' + x.port).join(', ') + ' kommen Daten an, die kein ' +
      'HL7 sind. Mindray-Geraete benutzen dort ihr eigenes Protokoll (MD2), das nur die hauseigene ' +
      'CentralStation versteht. Die Netzverbindung ist also in Ordnung — nur das Datenformat passt nicht.',
      ['Am Geraet die HL7-Ausgabe einschalten statt der CentralStation-Kopplung: ' +
       'Wartung -> Netzwerk-Setup -> HL7-Konfiguration, dort Ziel-IP = ' + ziel.ip + ' und "Daten senden" EIN.',
       'Beim uMEC12 Vet heisst der Weg: Benutzer-Wartung (888888) -> Netzwerk -> Gateway-Kommunikationseinst., Ziel ' + ziel.ip + ':' + ziel.port + '.',
       'Bietet das Geraet gar kein HL7 an, hilft der Fallback VSCapture: PowerShell ALS ADMINISTRATOR, dann ' +
       'powershell -ExecutionPolicy Bypass -File "C:\\VetStation\\installer\\setup-vscapture-fallback.ps1"']));
  }

  /* ---------------- 5) Firewall ---------------- */
  if (fw) {
    /*
     * EINE REGEL, DIE ES GIBT UND DIE NICHT WIRKT (neu 01.08.2026).
     * Der gefaehrlichste der drei Zustaende: bis hierher zaehlte allein der Regelname, also galt
     * eine ABGESCHALTETE oder auf BLOCKIEREN stehende Regel als "freigegeben" — gruener Haken,
     * und die Vitaldaten wurden trotzdem lautlos verworfen. Steht deshalb VOR dem fehlenden Port:
     * wer hier sucht, hat die Freigabe schon einmal gesetzt und wuerde sie kein zweites Mal setzen.
     */
    if (fw.unwirksam && fw.unwirksam.length) {
      b.push(befund('FIREWALL_UNWIRKSAM', 3,
        'Es gibt eine Firewall-Regel, aber sie wirkt nicht',
        fw.unwirksam.map((u) => 'Port ' + u.port + ': ' + (u.grund || 'unwirksam')).join(' · ') +
        '. Das sieht in der Firewall-Liste aus wie eine Freigabe, ist aber keine — Windows verwirft ' +
        'die ankommenden Vitaldaten weiterhin LAUTLOS. Genau dieser Zustand war bis 01.08.2026 auch ' +
        'fuer die Station unsichtbar.',
        ['FIREWALL-FREIGEBEN.bat doppelklicken — es setzt die Regel neu und schaltet sie ein.',
         'Wurde die Regel von Hand oder durch eine Gruppenrichtlinie abgeschaltet, muss sie dort wieder erlaubt werden.']));
    }

    /*
     * MESSUNG SCHLAEGT REGELWERK (neu 01.08.2026). Kam auf einem Port nachweislich schon eine
     * Verbindung an, dann ist er offen — egal, was in der Regelliste steht. Frueher behauptete die
     * Station in genau diesem Fall "WINDOWS-FIREWALL BLOCKIERT Port X" und schickte den Anwender
     * auf die Suche nach einem Problem, das er nicht hatte (der Port war z. B. durch eine
     * programmbasierte Regel fuer node.exe offen — am Praxis-PC am 31.07.2026 tatsaechlich so).
     */
    const empfangen = (lage.empfangenePorts || []).map(Number);
    const wirklichZu = (fw.fehlend || []).filter((p) => empfangen.indexOf(Number(p)) < 0);
    const trotzdemOffen = (fw.fehlend || []).filter((p) => empfangen.indexOf(Number(p)) >= 0);

    if (trotzdemOffen.length) {
      b.push(befund('FIREWALL_OHNE_REGEL_OFFEN', 1,
        'Auf Port ' + trotzdemOffen.join(', ') + ' kommen Daten an, obwohl keine eigene Regel existiert',
        'Der Port ist also offen — vermutlich durch eine programmbasierte Windows-Regel fuer node.exe ' +
        'oder eine andere Freigabe. Das ist kein Fehler; die Verbindung funktioniert.',
        ['Nichts zu tun. Wer es sauber haben will, kann FIREWALL-FREIGEBEN.bat doppelklicken — ' +
          'dann steht die Freigabe ausdruecklich da und ueberlebt einen Wechsel der node.exe.']));
    }

    if (wirklichZu.length) {
      b.push(befund('FIREWALL_FEHLT', 3,
        'Windows-Firewall blockiert ' + (wirklichZu.length === 1 ? 'einen Datenport' : wirklichZu.length + ' Datenports'),
        'Fuer Port ' + wirklichZu.join(', ') + ' gibt es keine Freigabe, und dort ist auch noch nie ' +
        'etwas angekommen. Windows verwirft ankommende Vitaldaten dann LAUTLOS: das Geraet meldet ' +
        '"sendet", der PC zeigt nichts, und nirgends steht eine Fehlermeldung.',
        ['FIREWALL-FREIGEBEN.bat doppelklicken (holt sich die Adminrechte selbst).',
         'Alternativ INSTALLIEREN.bat erneut ausfuehren — das legt die Regeln ebenfalls an.']));
    }
    if (fw.doppelt && fw.doppelt.length) {
      b.push(befund('FIREWALL_DOPPELT', 1,
        'Mehrfache Firewall-Regeln (Altbestand frueherer Installationen)',
        fw.doppelt.map((d) => 'Port ' + d.port + ': ' + d.anzahl + ' Regeln').join(', ') +
        '. Nicht gefaehrlich, aber die Firewall-Liste wird unlesbar und die Fehlersuche schwerer.',
        ['FIREWALL-FREIGEBEN.bat doppelklicken — es raeumt Altbestaende mit auf und legt genau eine Regel je Port an.']));
    }
    if (fw.unklar && fw.unklar.length) {
      b.push(befund('FIREWALL_UNKLAR', 1,
        'Firewall-Zustand nicht eindeutig lesbar',
        'Fuer Port ' + fw.unklar.join(', ') + ' liess sich der Zustand nicht ermitteln (' +
        'netsh nicht verfuegbar oder keine Rechte). Das heisst NICHT "in Ordnung" — es heisst "unbekannt".',
        ['Zur Sicherheit FIREWALL-FREIGEBEN.bat doppelklicken. Bereits vorhandene Regeln werden dabei nur erneuert.']));
    }
    /* Wurde nur der Regelname verglichen (PowerShell nicht verfuegbar), ist ein "frei" nicht
     * bewiesen — dann kann eine abgeschaltete Regel weiterhin als Freigabe durchgehen. Das gehoert
     * hingeschrieben, statt es als gruenen Haken zu verkaufen. */
    if (fw.genau === false) {
      b.push(befund('FIREWALL_NUR_NAME', 1,
        'Die Firewall konnte nur ungenau gelesen werden',
        'Geprueft wurde ausschliesslich, OB eine Regel mit dem passenden Namen existiert — nicht, ' +
        'ob sie eingeschaltet ist und ob sie zulaesst. Eine abgeschaltete Regel wuerde hier als ' +
        'freigegeben erscheinen. (Der genaue Weg braucht PowerShell.)',
        ['Kommen keine Werte an, obwohl alles freigegeben aussieht: FIREWALL-FREIGEBEN.bat doppelklicken.']));
    }
  } else {
    b.push(befund('FIREWALL_UNGEPRUEFT', 1,
      'Firewall wurde nicht geprueft',
      'Diese Pruefung lief ohne Firewall-Abfrage. Eine fehlende Freigabe waere unsichtbar.',
      ['GERAETE-PRUEFEN.bat doppelklicken — dort wird jeder Port ausgelesen.']));
  }

  /* ---------------- 6) Port von fremdem Programm belegt ---------------- */
  const fremdBelegt = lage.fremdBelegt || [];
  if (fremdBelegt.length) {
    b.push(befund('PORT_FREMD_BELEGT', 2,
      'Ein anderes Programm belegt ' + (fremdBelegt.length === 1 ? 'einen Datenport' : 'Datenports'),
      'Port ' + fremdBelegt.join(', ') + ' ist bereits vergeben. VetStation kann dort nicht zuhoeren — ' +
      'die Daten des Monitors landen im falschen Programm.',
      ['Laeuft VetStation vielleicht doppelt? Dann NEUSTART.bat doppelklicken (beendet alle Instanzen und startet eine).',
       'Sonst das fremde Programm beenden (haeufig: eine noch laufende VSCapture-Instanz).']));
  }

  /* ---------------- 7) Fern-Live (kein Geraeteproblem!) ---------------- */
  const cloud = lage.cloud;
  if (cloud && cloud.enabled && cloud.lastError) {
    const db404 = /HTTP 404/.test(String(cloud.lastError));
    b.push(befund('FERNLIVE_FEHLER', 1,
      'Fern-Live meldet einen Fehler — das betrifft NICHT die Geraeteverbindung',
      db404
        ? 'Die Cloud-Datenbank antwortet mit HTTP 404: sie ist in der Firebase-Konsole noch nicht angelegt. ' +
          'Das ist eine Konfigurationsaufgabe, kein Softwarefehler.'
        : 'Letzter Fehler: ' + cloud.lastError,
      db404
        ? ['Entweder Fern-Live in bridge\\config\\devices.json auf enabled:false lassen (Standard),',
           'oder die Realtime Database anlegen — Anleitung: docs\\FERN-LIVE.md.']
        : ['Internetverbindung und den cloud-Block in bridge\\config\\devices.json pruefen (docs\\FERN-LIVE.md).']));
  }

  /* ---------------- 8) Alles gut ---------------- */
  if (empfang.aktiv) {
    b.unshift(befund('EMPFANG_OK', 0,
      'Es kommen Werte an',
      empfang.geraete + ' Geraet(e) liefern gerade Daten' +
      (empfang.letzteDatenVorMs != null ? ' (zuletzt vor ' + Math.round(empfang.letzteDatenVorMs / 1000) + ' s)' : '') + '.',
      []));
  }

  b.sort((x, y) => y.schwere - x.schwere);

  const blocker = b.filter((x) => x.schwere >= 2);
  let urteil, kurz;
  if (empfang.aktiv && !b.some((x) => x.schwere === 3)) {
    urteil = 'ok';
    kurz = 'Datenverbindung steht — ' + empfang.geraete + ' Geraet(e) liefern Werte.';
  } else if (!scan) {
    urteil = 'unklar';
    kurz = 'Noch nicht geprueft. Netzwerksuche starten, dann steht hier das Ergebnis.';
  } else if (blocker.length) {
    urteil = 'problem';
    kurz = blocker[0].titel;
  } else {
    urteil = 'unklar';
    kurz = 'Kein eindeutiger Fehler gefunden — und es kommen trotzdem keine Werte an.';
    b.push(befund('UNGEKLAERT', 1,
      'Kein eindeutiger Fehler gefunden',
      'Netz, Firewall und Geraetesuche zeigen nichts Auffaelliges, es kommen aber keine Werte an. ' +
      'Damit bleiben die Einstellungen AM GERAET die wahrscheinlichste Ursache.',
      ['Am Monitor: "CMS auswaehlen" einschalten (Netzwerk-Setup).',
       'Am Monitor: "Real Data Send" auf EIN (Gateway-Kommunikationseinst.).',
       'Bietet das Geraet HL7 gar nicht an (Firmware/Lizenz), gibt es den Fallback VSCapture: ' +
       'PowerShell ALS ADMINISTRATOR oeffnen und eingeben: powershell -ExecutionPolicy Bypass -File "C:\\VetStation\\installer\\setup-vscapture-fallback.ps1"',
       'Bleibt es dabei, beim Haendler (Eickemeyer) die Freischaltung/Lizenz fuer die Datenausgabe erfragen.']));
  }

  return { urteil: urteil, kurz: kurz, befunde: b, ts: Date.now() };
}

module.exports = { diagnose, ZIEL, befund };
