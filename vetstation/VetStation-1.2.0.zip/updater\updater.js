'use strict';
/*
 * updater.js — In-App-Update-Kern (§13). Wiederverwendbar von der Bridge (/api/update/*) UND der CLI.
 * Zwei Ebenen:
 *  (1) Klinische Daten (Medikamente/Logik) aktualisieren sich bereits ZUR LAUFZEIT (Pull vom Live-Site).
 *  (2) App-Shell (Bridge/Adapter/UI-Code) über ein Versions-Manifest:
 *      - Git-Checkout  -> git pull --ff-only
 *      - sonst         -> signierte/geprüfte Zip: herunterladen, sha256 prüfen, STAGEN;
 *                         die Anwendung erfolgt beim nächsten Start (launch-kiosk.ps1),
 *                         damit keine laufenden Dateien überschrieben werden.
 * NULL npm-Dependencies (Node-Bordmittel; Entpacken via Windows Expand-Archive beim Start).
 */
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const { execSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const VERSION_FILE = path.join(__dirname, 'version.json');
const DATA_DIR = path.join(ROOT, 'data');

function local() { return JSON.parse(fs.readFileSync(VERSION_FILE, 'utf8')); }

function cmp(a, b) { // semver-ish (major.minor.patch)
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0); }
  return 0;
}

function fetchText(url, redirs) {
  redirs = redirs || 0;
  return new Promise((resolve, reject) => {
    if (redirs > 4) return reject(new Error('zu viele Weiterleitungen'));
    const lib = url.startsWith('http:') ? http : https;
    lib.get(url, { headers: { 'cache-control': 'no-store' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(fetchText(res.headers.location, redirs + 1)); }
      let d = ''; res.on('data', (c) => d += c); res.on('end', () => resolve({ status: res.statusCode, body: d }));
    }).on('error', reject);
  });
}
function fetchBinary(url, redirs) {
  redirs = redirs || 0;
  return new Promise((resolve, reject) => {
    if (redirs > 4) return reject(new Error('zu viele Weiterleitungen'));
    const lib = url.startsWith('http:') ? http : https;
    lib.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(fetchBinary(res.headers.location, redirs + 1)); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

// Prüft das Remote-Manifest und meldet, ob ein App-Shell-Update vorliegt.
async function check() {
  const L = local();
  const out = {
    current: L.app, channel: L.channel || 'stable',
    clinicalDataLive: L.clinicalDataLive || null, clinicalAutoUpdate: true,
    manifestUrl: L.manifestUrl || null,
    reachable: false, latest: null, updateAvailable: false, notes: null, zipUrl: null, sha256: null,
    isGit: istGitCheckout(),
    pending: pendingUpdate(),
  };
  if (!L.manifestUrl) { out.msg = 'Kein Manifest konfiguriert (nur Laufzeit-Datenupdate aktiv).'; return out; }
  try {
    const r = await fetchText(L.manifestUrl);
    if (r.status === 200) {
      const m = JSON.parse(r.body);
      out.reachable = true; out.latest = m.app || null; out.notes = m.notes || null;
      out.zipUrl = m.zipUrl || null; out.sha256 = m.sha256 || null;
      out.updateAvailable = out.latest ? cmp(out.latest, L.app) > 0 : false;
    } else { out.msg = 'Manifest nicht gefunden (HTTP ' + r.status + ').'; }
  } catch (e) { out.msg = 'Manifest nicht erreichbar: ' + e.message; }
  return out;
}

/*
 * istGitCheckout() — laeuft die Station aus einem ECHTEN Git-Arbeitsverzeichnis?
 *
 * WARUM SO GENAU (Befund 27.07.2026, echter Ausfall beim Kunden-Update):
 * Vorher stand hier schlicht fs.existsSync('.git'). Auf der Praxis-Station lag aber eine
 * ".git"-DATEI (kein Ordner) mit dem Inhalt "gitdir: C:/…/worktrees/…" — ein Ueberbleibsel aus
 * einem Git-Arbeitsbaum, das beim Kopieren mitgewandert war und dessen Ziel es laengst nicht
 * mehr gab. existsSync sagte trotzdem "ja", der Updater rief "git pull" auf, und der Tierarzt
 * bekam die voellig unverstaendliche Meldung
 *     "git pull fehlgeschlagen: fatal: not a git repository: (NULL)".
 * Der Zip-Weg — der einzige, der auf einer Station ueberhaupt vorgesehen ist — wurde dabei nie
 * erreicht. Das Update war damit unmoeglich, ohne dass irgendwo stand, warum.
 *
 * Jetzt wird dreifach geprueft: .git muss ein ORDNER sein, git muss ueberhaupt aufrufbar sein,
 * und das Verzeichnis muss sich als Arbeitsbaum melden. Faellt eines davon aus, gilt die
 * Installation als Zip-Installation — und genau das ist auf einem Praxis-PC der Normalfall.
 */
function istGitCheckout() {
  try {
    const st = fs.statSync(path.join(ROOT, '.git'));
    if (!st.isDirectory()) return false;
  } catch (_) { return false; }
  try {
    const r = execSync('git rev-parse --is-inside-work-tree', { cwd: ROOT, stdio: ['ignore', 'pipe', 'ignore'] });
    return String(r).trim() === 'true';
  } catch (_) { return false; }
}

function pendingUpdate() {
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'update-pending.json'), 'utf8')); } catch (_) { return null; }
}

// Wendet ein Update an (Git) bzw. STAGT eine geprüfte Zip für den nächsten Start.
async function apply() {
  const info = await check();
  if (!info.updateAvailable) return { ok: false, msg: info.msg || 'Kein Update verfügbar.', info };

  if (info.isGit) {
    try {
      const outLog = execSync('git pull --ff-only', { cwd: ROOT }).toString();
      return { ok: true, method: 'git', restart: true, msg: 'Per git pull auf ' + info.latest + ' aktualisiert. Bitte Station neu starten.', log: outLog.trim() };
    } catch (e) { return { ok: false, msg: 'git pull fehlgeschlagen: ' + e.message }; }
  }

  if (info.zipUrl) {
    try {
      const buf = await fetchBinary(info.zipUrl);
      if (info.sha256) {
        const h = crypto.createHash('sha256').update(buf).digest('hex');
        if (h.toLowerCase() !== String(info.sha256).toLowerCase()) return { ok: false, msg: 'Prüfsumme (sha256) stimmt NICHT — Update abgebrochen (Sicherheit).' };
      }
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const zipPath = path.join(DATA_DIR, 'update-staged.zip');
      fs.writeFileSync(zipPath, buf);
      fs.writeFileSync(path.join(DATA_DIR, 'update-pending.json'), JSON.stringify({ version: info.latest, zip: 'update-staged.zip', sha256: info.sha256 || null, ts: Date.now() }, null, 2));
      return { ok: true, method: 'zip', restart: true, staged: true,
        msg: 'Update ' + info.latest + ' geladen und geprüft (' + Math.round(buf.length / 1024) + ' KB). Wird beim nächsten Neustart der Station angewendet.' };
    } catch (e) { return { ok: false, msg: 'Download/Prüfung fehlgeschlagen: ' + e.message }; }
  }
  return { ok: false, msg: 'Kein automatischer Update-Pfad (kein Git-Checkout und kein zipUrl im Manifest).' };
}

module.exports = { check, apply, cmp, local, pendingUpdate };
