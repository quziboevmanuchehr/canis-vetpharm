# Mehrere OP-Säle

Ab **VetStation 1.1.0** kann eine Praxis mehrere OP-Säle betreiben. Jeder Saal hat seinen eigenen
PC mit seinen eigenen Geräten; alle melden sich mit **demselben Praxis-Konto** an. Danach sieht
jeder Saal die anderen — am Kiosk als Streifen unten am Bildschirm, in der Fern-Ansicht als
Tafel mit einer Karte je Saal.

> **Der wichtigste Satz vorweg:** fremde Säle sind **reine Ansicht**. Es gibt keinen Knopf, mit dem
> man von hier aus einen Patienten im Nachbarsaal koppelt, ein Gerät setzt oder etwas verstellt.
> Der Patient hängt an einem anderen PC, an dem ein anderer Mensch steht.

---

## 1. Einrichten — was wirklich zu tun ist

Auf **jedem** Praxis-PC:

1. **VetStation installieren** (`VetStation-Setup.exe`, Doppelklick, Weiter).
2. **Starten.** Die Station sucht ~20 s später von selbst im Netz nach Monitoren und
   Narkosegeräten und trägt sie ein — siehe Abschnitt 6.
3. **Saalnamen setzen.** Beim ersten Start steht oben ein Balken „Dieser OP-Saal hat noch keinen
   Namen“. Draufklicken, Namen eingeben („OP 1“, „Zahn-OP“, „Sono“), fertig. Der Name landet in
   `data\station-id.json` und überlebt Update und Neuinstallation.
4. **Am Praxis-Konto anmelden**: Admin → 📡 Fern-Live → E-Mail und Passwort der Praxis
   (oder Google/Microsoft). **Dasselbe Konto auf jedem PC.**

Mehr nicht. Es gibt **keinen** Server, **keine** IP-Liste, **keine** Portfreigabe nach außen und
keine Reihenfolge, in der die Säle starten müssten. Jeder Saal schreibt seinen eigenen Zweig und
liest die der anderen.

### Was passiert, wenn zwei Säle denselben Namen haben

Nichts Schlimmes, aber es wird gemeldet: in der Tafel und im Kiosk-Streifen erscheint eine
Warnzeile, und auf jeder Karte steht neben dem Namen die **Kurzform der Stationskennung**
(z. B. `st3f9a12c4e7b0`). Zwei Säle sind daran immer auseinanderzuhalten — auch auf dem
ausgedruckten Narkoseprotokoll, in dessen Kopf ab 1.1.0 beides steht.

### Was passiert, wenn ein PC geklont wurde

Zwei geklonte Windows-Installationen können dieselbe Stationskennung tragen. Dann würden beide in
denselben Saalzweig schreiben. Die Station **erkennt** das (sie sieht fremde Schreibvorgänge unter
ihrer eigenen Kennung), sagt es im Klartext und **schreibt bis zur Klärung keine Patientendaten
mehr** — nur noch ihren Herzschlag. Der Ausweg ist ein Knopf, den ein Mensch drückt:
Admin → 🏥 OP-Saal → **„Diese Station bekommt eine NEUE Kennung“**.

Umbenannt wird **nie automatisch**. Eine Station, die sich selbst umbenennt, verschwindet für die
Fern-Ansicht als lebender Saal, taucht als neuer, leerer wieder auf, und ihr unveränderliches
Narkoseprotokoll zerfällt in zwei Teile, die niemand mehr zusammenführt.

---

## 2. Was man sieht

### Am Kiosk: der Streifen unten

Standardmäßig **eingeklappt** — ein Klick auf die Leiste öffnet ihn, ein zweiter schließt ihn.
Seine Höhe ändert sich **nur durch diesen Klick**, nie durch eintreffende Daten: darüber liegen
die Patienten-Fenster des eigenen Saals, und die sollen nicht jedes Mal umbrechen, wenn im
Nachbarsaal ein Wert eintrifft.

Je Saal eine Karte mit Saalname, Kennung, Verbindungszustand, Alter und einer Kachel je Patient
(HF, SpO₂, EtCO₂, AF, MAP, Temp, Prioritätsfarbe). Eine ausklappbare Zeile zeigt die **Geräte**
dieses Saals (Modell, Rolle, Zustand, Adresse). Keine Kurven — das Rechen- und Fensterbudget
gehört dem eigenen Saal.

Ein Alarm im Nachbarsaal lässt dessen Karte **pulsieren**. Er schaltet nichts um: der eigene
Bildschirm bleibt beim eigenen Patienten.

### In der Fern-Ansicht: die Tafel

Dauerhaft sichtbar, eine Karte je Saal, feste Reihenfolge **nach Saalnamen** (nie nach
Priorität — sonst springen die Karten, während man hinsieht).

**Genau ein Saal wird geführt.** Die Narkose-App darunter — Dosisrechner, Beatmungsberater,
Vorfall-Protokolle — rechnet immer für den ausgewählten Saal, und Saalname, Tierart und Gewicht
stehen in jedem dieser Bereiche. Beim Wechsel wird **zurückgefragt und beide Tiere genannt**, und
alle gemessenen Istwerte werden zurückgesetzt, bevor die neuen kommen. Ohne dieses Zurücksetzen
könnten EtCO₂, Temperatur und Atemfrequenz des Tiers aus OP 1 unter dem Namen des Tiers in OP 2
stehen — ausgewiesen als gemessene Werte.

### Zwei Altersangaben, und warum es zwei sind

| Angabe | Bedeutung |
|---|---|
| **Übertragung** | Wie alt ist die Nachricht aus diesem Saal? |
| **Gerätedaten** | Wie alt ist der Messwert, der darin steht? |

Ein Saal kann tadellos senden und trotzdem seit fünf Minuten keinen Wert vom Monitor bekommen
haben. Eine einzige Zahl könnte das nicht ausdrücken.

Schwellen (nur die **Übertragung** darf Zahlen verstecken):

- **unter 12 s** — live, Zahlen gelten.
- **12–60 s** — gelb, „keine neuen Daten (X s)“. Zahlen bleiben stehen.
- **über 60 s** — „OP 1 offline seit X min“, und die Zahlen werden durch **„Stand vor X min“
  ersetzt**. Eine eingefrorene Zahl, die aussieht wie eine lebende, ist gefährlicher als gar keine.
- **nach 12 h** verschwindet der Saal aus der Liste.

Läuft die Uhr des anderen PCs vor, steht **„Alter unbekannt“** — nie „0 s“.

### Deckel

Angezeigt werden **8 Säle** und **12 Patienten je Saal**. Wird mehr geliefert, steht dort eine
Zeile „X weitere OP-Säle werden nicht angezeigt — Deckel erreicht“. Stillschweigend abgeschnitten
wird nichts.

---

## 3. Verlegung: derselbe Patient in zwei Sälen

Wird ein Tier von OP 1 nach OP 2 gebracht, erkennt die Fern-Ansicht das an der **gleichen,
nicht leeren Patienten-ID** in beiden Sälen und bietet **„Verlauf beider Säle drucken“**: eine
Tabelle nach Uhrzeit sortiert, mit führender Spalte „Saal“ und der Kopfzeile „aus zwei OP-Sälen
zusammengestellt“.

Zusammengeführt wird ausschließlich das **Papier** — nie ein Datensatz. Die Protokolle beider
Säle bleiben getrennt, unverändert und unveränderlich.

Zwei verschiedene Tiere mit gleichem Gewicht und gleicher Art (zwei 22-kg-Hunde) werden **nie**
verwechselt: sie hängen an ihrer Stationskennung, nicht an ihren Werten. Ein Patient **ohne**
Patienten-ID wird grundsätzlich nicht als Verlegung gewertet.

---

## 4. Was das kostet (Datenmenge)

Gemessen (`tools/fern-durchsatz-test.js`), je Saal:

| Zustand | Menge |
|---|---|
| Herzschlag ohne Patient (Ruhetakt 5 s) | ~340 Byte je Takt ≈ **170 MB/Monat** |
| Laufende Narkose, ohne Kurven | ≈ **2,6 GB/Monat** bei 24/7 |
| Laufende Narkose, mit Kurven, 8 h/Tag | ≈ **3,3 GB/Monat** |

Das Firebase-Freikontingent von 10 GB/Monat gilt für **alle Praxen zusammen**. Deshalb:

- Der Vitalwert-Takt steht ab 1.1.0 auf **500 ms** (vorher 200 ms).
- Die Tafel — der Herzschlag — läuft mit **2 s**, im leeren Saal mit **5 s**.
- `cloud.budgetMbMonat` in `bridge/config/devices.json` setzt eine Obergrenze. Wird sie erreicht,
  geht der **Lesetakt der Nachbarn** auf 5 s und es steht im Klartext im Log. Der eigene
  **Schreibweg wird nie gedrosselt** — der eigene Saal hat immer Vorrang.

Wer die Tafel langsamer als 5 s stellt, lässt gesunde Säle als offline erscheinen.

---

## 5. Der direkte Weg im Haus (Port 8771)

Zusätzlich zum Weg über das Praxis-Konto können sich die Stationen **direkt im Hausnetz**
erreichen. Nutzen: kein Internet nötig, kein Freikontingent, schnellerer Takt.

- Ein **GET-only**-Zugang auf **TCP 8771**, gebunden **nur an private Adressen**
  (192.168.x, 10.x, 172.16–31.x) — nicht an VPN- oder Overlay-Karten.
- Beide Seiten weisen sich mit einem **Ed25519-Schlüsselpaar** aus. Der öffentliche Schlüssel
  steht im Praxis-Konto, der private verlässt den PC nie. Danach ist alles verschlüsselt
  (X25519 + HKDF + AES-256-GCM).
- Der Schlüssel wird beim **ersten Sehen gepinnt** (`bridge\data\nachbarn.json`). Ändert er sich
  später, wird das **nie still übernommen**: die Quelle fällt zurück auf den Weg über das Konto und
  im Klartext steht „Der Schlüssel von OP 1 hat sich geändert — im Admin-Bereich bestätigen“.
- Über diesen Weg geht **nur die Tafel**. Kein Narkoseprotokoll, keine Kurven.
- **Bei Widerspruch gewinnt das Praxis-Konto.** Weichen die Zahlen beider Wege ab, gilt die
  Cloud-Fassung und im Streifen steht „Quellen widersprechen sich“. Der direkte Weg darf die
  Laufzeit überholen, nie die Wahrheit.

**Freigeben:** `FIREWALL-FREIGEBEN.bat` doppelklicken. Die Regel heißt „VetStation Nachbarsaal
TCP 8771“ und gilt nur für **Privat/Domäne** und nur für das **lokale Subnetz**.

**Wichtig:** die Stationen müssen im **Hausnetz** liegen, nicht im isolierten Gerätenetz. Und
`docs/LAN-SETUP.md` schreibt jedem Praxis-PC dieselbe Adresse `192.168.0.99` vor — bei zwei
Stationen muss die zweite eine **andere** bekommen, sonst reden sie mit sich selbst.

**Zugang entziehen:** Praxis-Passwort ändern und jede Station einmal neu starten. Ein
ausgemusterter PC verliert damit den Zugang; Einträge in `nachbarn.json` verfallen ohnehin nach
30 Tagen.

---

## 6. Die Station sucht von selbst (ab 1.1.0)

Etwa **20 Sekunden nach dem Start** sieht die Station einmal im eigenen Netz nach — ohne dass
jemand klickt, ohne dass jemand eine IP kennen muss.

**Geräte.** Jeder Fund geht in das gemeinsame Gerätegedächtnis, dem jeder Adapter mit
`"host": "auto"` sofort folgt. Antwortet ein Gerät zusätzlich auf einem **Datenport** (es
lauscht also und wartet auf die Abfrage des PCs), wird es **selbst in
`bridge\config\devices.json` eingetragen und sofort in Betrieb genommen** — ohne Neustart.
Geräte, die von sich aus zum PC **senden**, bekommen ausdrücklich **keinen** zweiten Eintrag: der
Verbindungs-Assistent nimmt sie bereits entgegen, und ein zweiter Eintrag würde dasselbe Gerät
doppelt anzeigen.

**Die Bewährungsprobe.** Ein offener Port beweist nur, dass dort jemand antwortet — nicht, dass er
HL7 spricht. Der Veta 5 Plus antwortet auf 4601 und sendet dort Mindray-MD2. Liefert ein selbst
eingetragener Adapter binnen **90 Sekunden** nichts Lesbares, wird er **wieder abgeschaltet**, der
Grund vermerkt und die Adresse gesperrt. Lieber ein ehrliches „gefunden, spricht aber kein HL7“
als ein Gerät, das ohne Werte in der Liste steht.

**Weitere Praxis-PCs** werden erkannt (viele Datenports gleichzeitig, oder Port 8770/8771 offen)
und im Klartext gemeldet, samt dem Hinweis, dass beide Säle einander sehen, sobald beide am
**selben Praxis-Konto** angemeldet sind. Die Adresse wird als Kandidat für den direkten Weg
vermerkt — sie stellt **kein Vertrauen** her. Wer wirklich dort sitzt, weist erst der signierte
Handschlag nach.

**Grenzen, bewusst gesetzt:**

- **Während einer laufenden Narkose wird nie gesucht.** Der Suchlauf öffnet in kurzer Folge
  hunderte TCP-Verbindungen; das konkurriert auf einem Kiosk-i3 mit dem Empfang der Vitalwerte.
- Wiederholt wird in wachsenden Abständen (2 min → 10 min → 30 min), und **gar nicht mehr**,
  sobald Werte ankommen.
- Höchstens 4 neue Einträge je Lauf. Die übrigen Funde bleiben mit Begründung im Log stehen.
- Abschalten: `"erstsuche": { "enabled": false }` in `bridge\config\devices.json`.

Nachsehen, was gefunden wurde: Admin → Netzwerk & Geräte, oder `http://127.0.0.1:8770/api/erstsuche`.

---

## 7. Wenn etwas nicht stimmt

| Beobachtung | Ursache und Abhilfe |
|---|---|
| Der Nachbarsaal erscheint gar nicht | Beide PCs am **selben** Praxis-Konto angemeldet? Admin → 📡 Fern-Live auf **beiden**. Verschiedene Konten = getrennte Praxen, das ist so gewollt. |
| „OP 1 offline seit X min“, obwohl der PC läuft | Dort Internet weg, oder VetStation beendet. Der Herzschlag ist das Erste, was ausbleibt. |
| Beide Säle heißen gleich | Saalnamen setzen: Admin → 🏥 OP-Saal. Die Kennung darunter unterscheidet sie schon jetzt. |
| „Doppelte Stationskennung“ | Geklonter PC. Admin → 🏥 OP-Saal → **Diese Station bekommt eine NEUE Kennung**. Bis dahin sendet die Station nur ihren Herzschlag — absichtlich. |
| „Quellen widersprechen sich“ | Direkter Weg und Praxis-Konto liefern verschiedene Zahlen. Angezeigt wird die Fassung aus dem Konto. Meist eine hängengebliebene Verbindung; klärt sich beim nächsten Takt. |
| „Der Schlüssel von OP 1 hat sich geändert“ | Dort wurde neu installiert oder die Kennung erneuert. Im Admin-Bereich bestätigen — **nicht** ungeprüft, wenn dort niemand etwas gemacht hat. |
| Streifen bleibt leer, Tafel zeigt Säle | Der Streifen wurde eingeklappt (Zustand wird gemerkt). Auf die Leiste klicken. |
| „X weitere OP-Säle werden nicht angezeigt“ | Deckel bei 8 Sälen erreicht. Kein Fehler — nur die Ansage, dass mehr da ist. |

---

## Verwandte Dokumente

- `docs/FERN-LIVE.md` — die Fern-Übertragung im Einzelnen (Datenbaum, Rechte, Messwerte).
- `docs/PLAN-MEHRERE-SAELE.md` — die geprüfte Vorgabe, aus der dieser Umbau entstanden ist,
  einschließlich der Befunde, die einzelne Entwürfe verworfen haben.
- `docs/LAN-SETUP.md` — Netzadressen, Firewall, Gerätenetz gegen Hausnetz.
- `docs/GERAETE-EINSTELLEN.md` — was am Monitor und am Narkosegerät eingestellt sein muss.
