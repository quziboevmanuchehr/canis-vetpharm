'use strict';
/*
 * cloud-integration-test.js — Ende-zu-Ende: ECHTE Bridge (Simulator) -> Cloud-Publisher -> Mock-Firebase.
 * Beweist, dass server.js die zusammengefuehrten Patienten (registry.getPatients) tatsaechlich
 * ~1x/s an die Cloud sendet, inkl. Brain-Enrichment. Legt temporaer eine devices.json an
 * (Simulator + cloud.enabled) und raeumt sie am Ende wieder weg.  Start: node tools/cloud-integration-test.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CFG = path.join(__dirname, '..', 'bridge', 'config', 'devices.json');
const AUTH_FILE = path.join(require('os').tmpdir(), 'vetstation-integ-auth-' + process.pid + '.json');
/*
 * Die Stationskennung dieses Testlaufs — bewusst im Temp-Verzeichnis und mit fester sid.
 * Ohne diese Vorgabe legte der gestartete Prozess data/station-id.json IM PROJEKT an (das ist im
 * Betrieb richtig, in einem Test aber eine Spur), und der erwartete Saalzweig haenge von der
 * Windows-Geraete-ID des Rechners ab, auf dem der Test gerade laeuft.
 */
const STATION_FILE = path.join(require('os').tmpdir(), 'vetstation-integ-station-' + process.pid + '.json');
const SID = 'stbeef00000001';
let pass = 0, fail = 0, child = null, hadCfgBefore = fs.existsSync(CFG);
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? ' -> ' + e : '')); } }

const captured = { puts: [], urls: [], signups: 0, refreshes: 0 };
const mock = http.createServer((req, res) => {
  let body = ''; req.on('data', c => body += c); req.on('end', () => {
    if (req.url.startsWith('/identity')) { captured.signups++; return j(res, { idToken: 'ID', refreshToken: 'RT', localId: 'u1', expiresIn: '3600' }); }
    if (req.url.startsWith('/token')) { captured.refreshes++; return j(res, { id_token: 'ID', refresh_token: 'RT', user_id: 'u1', expires_in: '3600' }); }
    /*
     * LESEN. Die Station liest ab 1.1.0 ihren eigenen Tafelkopf zurueck (steht dort ein Zwilling?)
     * und das flache meta (schreibt hier eine 1.0.3?). Ein leeres Konto antwortet mit null — und
     * genau das ist hier der Fall. Ohne diese Antwort bliebe die Station in der Anlaufsperre und
     * wuerde ueberhaupt keine Patientendaten senden; der Test saehe einen Fehler, den es nicht gibt.
     */
    if (req.method === 'GET' && req.url.indexOf('/live/') >= 0) return j(res, null);
    if ((req.method === 'PATCH' || req.method === 'PUT') && req.url.indexOf('/live/') >= 0) {
      let p = null; try { p = JSON.parse(body); } catch (_) {}
      captured.puts.push(p); captured.urls.push(req.url);
      return j(res, p);
    }
    res.writeHead(404); res.end();
  });
});
function j(res, o) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); }

let cleaned = false;
function cleanup() {
  if (cleaned) return; cleaned = true;
  try { if (child) child.kill(); } catch (_) {}
  // KERNPUNKT (23.07.2026): Diese temporaere devices.json aktiviert den Simulator + Cloud-Code
  // "integ-test". Bleibt sie liegen, laedt JEDER spaetere Start sie und zeigt simulierte Patienten
  // statt der echten Geraete — genau der Befund "haengt nur beim Hund, uebernimmt keine Daten".
  // Deshalb wird sie hier IMMER entfernt, wenn der Test sie selbst angelegt hat.
  try { if (!hadCfgBefore) fs.unlinkSync(CFG); } catch (_) {}
  try { fs.unlinkSync(AUTH_FILE); } catch (_) {}
  try { fs.unlinkSync(STATION_FILE); } catch (_) {}
  try { mock.close(); } catch (_) {}
}
// Absturz-/Abbruchsicher: Strg-C, kill und regulaeres Ende raeumen die Test-Konfig ebenfalls weg.
// Ohne diese Handler blieb bei Strg-C nach dem writeFileSync die Simulator-devices.json zurueck.
['SIGINT', 'SIGTERM', 'SIGHUP'].forEach((sig) => process.on(sig, () => { cleanup(); process.exit(1); }));
process.on('exit', cleanup);

async function run() {
  if (hadCfgBefore) { console.log('devices.json existiert bereits — Test uebersprungen (nicht ueberschreiben).'); process.exit(0); }
  await new Promise(r => mock.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + mock.address().port;
  console.log('Integrationstest: Bridge -> Cloud -> Mock (' + base + ')');

  /*
   * Gespeicherte Anmeldung VOR dem Start hinlegen. Das ist genau der Fall, der in der Praxis
   * zaehlt: nach Stromausfall oder Update startet der PC neu, und die Uebertragung muss von
   * selbst wieder anlaufen — ohne dass jemand ein Passwort eintippt. Das Passwort steht
   * bewusst nirgends in dieser Datei.
   */
  fs.writeFileSync(AUTH_FILE, JSON.stringify({ refreshToken: 'RT', localId: 'u1', email: 'integ@test.de' }));
  fs.writeFileSync(STATION_FILE, JSON.stringify({ sid: SID, quelle: 'test', instanzen: [] }));

  fs.writeFileSync(CFG, JSON.stringify({
    port: 8779, host: '127.0.0.1',
    cloud: { enabled: true, provider: 'firebase', apiKey: 'K', dbUrl: base,
      station: 'Integ-OP', minIntervalMs: 600, identityUrl: base + '/identity', tokenUrl: base + '/token',
      authFile: AUTH_FILE, stationDatei: STATION_FILE, tafelTaktMs: 800, archiv: { enabled: false } },
    adapters: [{ type: 'simulator', id: 'sim', enabled: true, rateMs: 500 }],
  }, null, 2));

  child = spawn(process.execPath, [path.join(__dirname, '..', 'bridge', 'src', 'index.js')], { stdio: 'ignore' });

  // Bis zu 8 s auf einen Koerper MIT PATIENTENDATEN warten. Der erste Takt einer Station traegt
  // nur ihren Tafelkopf: solange nicht zurueckgelesen wurde, ist eine doppelte Stationskennung
  // weder bewiesen noch ausgeschlossen, und dann gehen ausdruecklich keine Patientendaten raus
  // (Nachbesserung N1). Das ist ein Takt, kein Zustand — hier wird er abgewartet.
  const wurzel = 'saele/' + SID + '/patients/';
  const mitPatienten = () => captured.puts.filter((p) => Object.keys(p || {}).some((k) => k.indexOf(wurzel) === 0));
  const t0 = Date.now();
  while (mitPatienten().length < 1 && Date.now() - t0 < 8000) await wait(150);
  while (captured.puts.length < 3 && Date.now() - t0 < 9000) await wait(150);

  ok('startet mit gespeicherter Anmeldung (Erneuerung, KEINE Passworteingabe)',
    captured.refreshes >= 1 && captured.signups === 0, 'signups=' + captured.signups + ' refreshes=' + captured.refreshes);
  ok('mindestens 2 Snapshots gesendet', captured.puts.length >= 2, 'puts=' + captured.puts.length);
  ok('geschrieben wird unter der Praxis-Kennung, mit Token',
    captured.urls.every((u) => u.indexOf('/live/u1.json') >= 0 && u.indexOf('auth=') >= 0),
    captured.urls[0]);

  /*
   * UMBAU 30.07.2026: es gibt keinen Knoten 'patients' mehr. Der Datenstand des eigenen Saals
   * liegt als TIEFE Pfade unter saele/<sid>/patients/<key>/<feld> — auch das Vollbild. Ein
   * Vollbild mit dem ganzen Knoten haette in einem Konto mit zwei Saelen die Spiegelschluessel
   * des Nachbarn geloescht (Nachbesserung N7). Alles darunter Gepruefte ist dasselbe geblieben.
   */
  const alleFelder = {};                    // <key> -> { feld: wert } aus allen Koerpern
  captured.puts.forEach((p) => Object.keys(p || {}).forEach((k) => {
    if (k.indexOf(wurzel) !== 0) return;
    const rest = k.slice(wurzel.length).split('/');
    if (rest.length !== 2) return;
    (alleFelder[rest[0]] || (alleFelder[rest[0]] = {}))[rest[1]] = p[k];
  }));
  const keys = Object.keys(alleFelder);
  ok('geschrieben wird in den EIGENEN Saal-Zweig (saele/<sid>/patients/...)', keys.length > 0,
    Object.keys(captured.puts[0] || {}).slice(0, 3).join(', '));
  /*
   * Der erste Wert-Koerper ist das Vollbild, alles danach ein Delta. Waere der letzte wieder ein
   * Vollbild, waere die Delta-Ersparnis kaputt und der schnelle Takt unbezahlbar. Gemessen wird an
   * der Zahl der Pfade — das Vollbild traegt jedes Feld jedes Patienten, ein Delta nur das, was
   * sich bewegt hat.
   */
  const wertKoerper = mitPatienten();
  ok('spaetere Wert-Koerper sind Deltas (deutlich weniger Pfade als das Vollbild)',
    wertKoerper.length < 2
    || Object.keys(wertKoerper[wertKoerper.length - 1]).length < Object.keys(wertKoerper[0]).length,
    wertKoerper.map((p) => Object.keys(p).length).join(' -> ') + ' Pfade');
  ok('kein Koerper traegt den Top-Level-Schluessel "patients" oder "meta" (N7)',
    !captured.puts.some((p) => Object.keys(p || {}).some((k) => k === 'patients' || k === 'meta')),
    captured.puts.map((p) => Object.keys(p || {})[0]).join(' | '));
  ok('der Saalname steht im Tafelkopf dieses Saals',
    captured.puts.some((p) => p && p['tafel/' + SID + '/meta'] && p['tafel/' + SID + '/meta'].name === 'Integ-OP'),
    JSON.stringify((captured.puts.find((p) => p && p['tafel/' + SID + '/meta']) || {})['tafel/' + SID + '/meta'] || {}).slice(0, 120));
  ok('mehrere zusammengefuehrte Patienten (Simulator-Standard = 4)', keys.length === 4, 'keys=' + keys.length);
  const specs = keys.map(k => alleFelder[k].species);
  ok('Art-Vielfalt end-to-end (Kaninchen + Reptil in der Cloud)', specs.indexOf('kaninchen') >= 0 && specs.indexOf('reptil') >= 0, specs.join(','));

  const anyVitals = keys.some(k => alleFelder[k].vitals && alleFelder[k].vitals.hr != null);
  ok('echte Vitalwerte enthalten (hr)', anyVitals);
  const anyEnriched = keys.some(k => typeof alleFelder[k].pri === 'number');
  ok('Brain-Enrichment vorhanden (pri)', anyEnriched);
  const anySpecies = keys.every(k => !!alleFelder[k].species);
  ok('jede Spezies gesetzt', anySpecies);

  cleanup();
  console.log('\nErgebnis: ' + pass + ' OK, ' + fail + ' Fehler.');
  process.exit(fail ? 1 : 0);
}
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }
process.on('uncaughtException', e => { console.error('FEHLER', e); cleanup(); process.exit(1); });
run().catch(e => { console.error('TESTFEHLER', e); cleanup(); process.exit(1); });
