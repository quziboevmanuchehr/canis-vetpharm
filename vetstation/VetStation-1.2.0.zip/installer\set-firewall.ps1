<#
  set-firewall.ps1 - Gibt die Geraete-Datenports in der Windows-Firewall frei.
  EINE gemeinsame, WIEDERHOLBARE Stelle fuer beide Installationswege (Install-VetStation.ps1
  UND vetstation-setup.iss) - plus zum Reparieren per Doppelklick (FIREWALL-FREIGEBEN.bat).

  WARUM DIESE DATEI EXISTIERT (Befund 1.3 / 2.5, 21.07.2026):
  Auf dem Praxis-PC standen 10 statt 5 Regeln. Ursache: das Inno-Setup legte die Regeln OHNE
  vorheriges Loeschen an, Install-VetStation.ps1 zusaetzlich - pro Neuinstallation kam ein
  weiterer Satz dazu. Nicht gefaehrlich, aber die Firewall-Liste wird unlesbar und die
  Fehlersuche schwerer.

  WARUM ES UEBERHAUPT NOETIG IST (Befund 2.6):
  Fehlt eine Freigabe, verwirft Windows die Vitaldaten LAUTLOS. Das Geraet meldet "sendet",
  der PC zeigt nichts, und nirgends steht eine Fehlermeldung.

  IDEMPOTENT: erst ALLE gleichnamigen Altregeln entfernen, dann GENAU EINE je Port anlegen.
  Mehrfaches Ausfuehren aendert das Ergebnis nicht.

  Aufruf:  powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-firewall.ps1"
  Pruefen: -Pruefen   (aendert nichts, meldet nur den Zustand)
  Entfernen: -Entfernen
#>
param(
  [switch]$Pruefen,
  [switch]$Entfernen,
  [switch]$Leise
)

# 3502 = Mindray Gateway-Kommunikation (Standard-Ziel im uMEC12-Vet-Netzwerkmenue)
# 4601 = HL7/VSCapture
# 8830 = Standardziel der HL7-Konfiguration im Eickemeyer LifeVet 10C (Daten+Kurven UND Alarme)
# 5510 = Server-Port des Eickemeyer LifeVet M (EDAN-Bauart)
# 5000/24105/2575 = weitere HL7-Kandidatenports; 24105 ist zugleich der Philips-Data-Export-Port
# 2528 = Werks-Zielport des Midmark Multiparameter Monitor (8019/8020)
#
# DIESE LISTE MUSS MIT bridge/src/netscan.js DATA_PORTS UEBEREINSTIMMEN.
# tools/paket-test.js erzwingt das und schlaegt fehl, wenn hier eine Zahl fehlt - PowerShell kann
# den Geraetekatalog nicht lesen, deshalb ist dies die eine Stelle, die von Hand nachgezogen wird.
# Woher die Zahlen kommen, steht je Geraet in bridge/src/geraetekatalog.js.
$PORTS = @(3502, 4601, 8830, 5000, 5510, 24105, 2575, 2528)
$PREFIX = 'VetStation Geraetedaten TCP '

# --- Zweiter Regelsatz ab 1.1.0: der Nachbar-Port zwischen zwei OP-Saelen -----
#
# 8771 = direkter Weg zwischen zwei VetStation-PCs im selben Haus (Stufe 2, ohne Internet).
#
# ER WIRD BEWUSST ENGER FREIGEGEBEN ALS DIE GERAETEPORTS, und das ist der Grund fuer den zweiten
# Satz: die Geraeteregeln lassen einen Monitor an den PC, diese hier laesst einen ZWEITEN PC heran.
#   -Profile Private,Domain   nicht Any. Im Profil "Oeffentlich" haengt der Rechner an einem Netz,
#                             in dem keine Praxisgeraete stehen - dort hat der Port nichts zu suchen.
#   -RemoteAddress LocalSubnet  nur das eigene Netz. Ohne diese Grenze waere der Port ueber jede
#                             geroutete Verbindung erreichbar, auch ueber ein VPN.
# Beides erzwingt tools/paket-test.js: eine Regel mit -Profile Any oder ohne -RemoteAddress faellt
# dort durch. Der Handschlag am Port ist signiert und verschluesselt - aber eine Freigabe, die
# breiter ist als noetig, ist trotzdem eine Freigabe, die breiter ist als noetig.
$STATION_PORTS = @(8771)
$STATION_PREFIX = 'VetStation Nachbarsaal TCP '

function Regelname([int]$p) { return ($PREFIX + $p) }
function StationsRegelname([int]$p) { return ($STATION_PREFIX + $p) }

# --- Adminrechte sicherstellen (Firewall-Regeln brauchen sie zwingend) ---------
if (-not $Pruefen) {
  $__id = [Security.Principal.WindowsIdentity]::GetCurrent()
  if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
    # NICHT $args benennen - das ist eine automatische PowerShell-Variable.
    $argListe = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'))
    if ($Entfernen) { $argListe += '-Entfernen' }
    if ($Leise) { $argListe += '-Leise' }
    try { Start-Process powershell.exe -Verb RunAs -ArgumentList $argListe }
    catch {
      Write-Warning "Adminrechte noetig. Bitte FIREWALL-FREIGEBEN.bat rechtsklicken -> 'Als Administrator ausfuehren'."
      Start-Sleep 6
    }
    exit
  }
}

# Zaehlt vorhandene Regeln je Port. Sprachunabhaengig: gesucht wird unser EIGENER Regelname,
# der in jeder Windows-Sprache woertlich so in der Ausgabe steht.
function Zaehle([int]$p) {
  $name = Regelname $p
  $n = 0
  try {
    $r = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue
    if ($r) { $n = @($r).Count }
    return $n
  } catch { }
  # Fallback fuer Systeme ohne NetSecurity-Modul
  try {
    $out = & netsh advfirewall firewall show rule name="$name" 2>$null
    if ($out) { $n = @($out | Where-Object { $_ -like ('*' + $name + '*') }).Count }
  } catch { }
  return $n
}

# Dieselben drei Handgriffe fuer den Nachbar-Port. Bewusst eigene Funktionen statt eines
# Parameters an den vorhandenen: die Regel wird ANDERS gesetzt (Profil + RemoteAddress), und ein
# gemeinsamer Weg mit Sonderfall waere genau die Stelle, an der die Einschraenkung eines Tages
# still herausfaellt.
function ZaehleStation([int]$p) {
  $name = StationsRegelname $p
  $n = 0
  try {
    $r = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue
    if ($r) { $n = @($r).Count }
    return $n
  } catch { }
  try {
    $out = & netsh advfirewall firewall show rule name="$name" 2>$null
    if ($out) { $n = @($out | Where-Object { $_ -like ('*' + $name + '*') }).Count }
  } catch { }
  return $n
}

function EntferneAlleStation([int]$p) {
  $name = StationsRegelname $p
  try { Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue } catch { }
  try { & netsh advfirewall firewall delete rule name="$name" | Out-Null } catch { }
}

function LegeStation([int]$p) {
  $name = StationsRegelname $p
  try {
    New-NetFirewallRule -DisplayName $name -Direction Inbound -Action Allow -Protocol TCP `
      -LocalPort $p -Profile Private,Domain -RemoteAddress LocalSubnet `
      -Description "VetStation: Nachbarsaal-Verbund zwischen zwei Praxis-PCs (nur lesend, signiert und verschluesselt)" -ErrorAction Stop | Out-Null
    return $true
  } catch { }
  # Rueckfall ohne NetSecurity-Modul. localsubnet ist in netsh dasselbe wie -RemoteAddress
  # LocalSubnet; die Profileinschraenkung heisst dort profile=private,domain.
  try {
    & netsh advfirewall firewall add rule name="$name" dir=in action=allow protocol=TCP localport=$p profile=private,domain remoteip=localsubnet | Out-Null
    return $true
  } catch { }
  return $false
}

function EntferneAlle([int]$p) {
  $name = Regelname $p
  try { Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue } catch { }
  # netsh loescht ALLE gleichnamigen auf einmal - genau das brauchen wir zum Aufraeumen.
  # Kein 2>&1: in PowerShell 5.1 wuerde das jede stderr-Zeile eines nativen Programms in einen
  # ErrorRecord verwandeln und $? auf $false setzen, obwohl netsh erfolgreich war.
  try { & netsh advfirewall firewall delete rule name="$name" | Out-Null } catch { }
}

function Lege([int]$p) {
  $name = Regelname $p
  try {
    New-NetFirewallRule -DisplayName $name -Direction Inbound -Action Allow -Protocol TCP `
      -LocalPort $p -Profile Any `
      -Description "VetStation: Vitaldaten von Narkose-/Patientenmonitoren (nur lesend)" -ErrorAction Stop | Out-Null
    return $true
  } catch { }
  try {
    & netsh advfirewall firewall add rule name="$name" dir=in action=allow protocol=TCP localport=$p | Out-Null
    return $true
  } catch { }
  return $false
}

if (-not $Leise) {
  Write-Host ""
  Write-Host "== VetStation - Windows-Firewall fuer die Geraeteports =="
}

# --- Nur pruefen -------------------------------------------------------------
if ($Pruefen) {
  $fehlend = @(); $doppelt = @()
  foreach ($p in $PORTS) {
    $n = Zaehle $p
    if ($n -eq 0) { $fehlend += $p; Write-Host ("  TCP {0}: FEHLT - Windows verwirft die Daten lautlos" -f $p) }
    elseif ($n -gt 1) { $doppelt += $p; Write-Host ("  TCP {0}: freigegeben, aber {1} Regeln (Altbestand)" -f $p, $n) }
    else { Write-Host ("  TCP {0}: freigegeben" -f $p) }
  }
  # Der Nachbar-Port ist KEIN Grund fuer Exitcode 1: eine Praxis mit einem einzigen OP-Saal
  # braucht ihn nicht, und ein roter Zustand, der niemanden etwas angeht, wird bald ignoriert.
  foreach ($p in $STATION_PORTS) {
    $n = ZaehleStation $p
    if ($n -eq 0) { Write-Host ("  TCP {0}: nicht freigegeben - nur noetig fuer MEHRERE OP-Saele im Haus" -f $p) }
    elseif ($n -gt 1) { Write-Host ("  TCP {0}: freigegeben, aber {1} Regeln (Altbestand)" -f $p, $n) }
    else { Write-Host ("  TCP {0}: freigegeben (Nachbarsaal, nur eigenes Netz)" -f $p) }
  }
  if ($fehlend.Count -or $doppelt.Count) {
    Write-Host ""
    Write-Host "  -> Reparieren: FIREWALL-FREIGEBEN.bat doppelklicken."
    exit 1
  }
  Write-Host "  Alles in Ordnung (genau eine Regel je Port)."
  exit 0
}

# --- Entfernen ---------------------------------------------------------------
if ($Entfernen) {
  foreach ($p in $PORTS) { EntferneAlle $p }
  foreach ($p in $STATION_PORTS) { EntferneAlleStation $p }
  if (-not $Leise) { Write-Host "Alle VetStation-Firewallregeln entfernt." }
  exit 0
}

# --- Setzen (idempotent) -----------------------------------------------------
$ok = 0; $nichtOk = @(); $aufgeraeumt = 0
foreach ($p in $PORTS) {
  $vorher = Zaehle $p
  if ($vorher -gt 1) { $aufgeraeumt += ($vorher - 1) }
  EntferneAlle $p
  if (Lege $p) { $ok++ } else { $nichtOk += $p }
}

$stationOk = 0; $stationNichtOk = @()
foreach ($p in $STATION_PORTS) {
  EntferneAlleStation $p
  if (LegeStation $p) { $stationOk++ } else { $stationNichtOk += $p }
}

if (-not $Leise) {
  Write-Host ("  {0} von {1} Ports freigegeben (genau eine Regel je Port)." -f $ok, $PORTS.Count)
  if ($stationOk -gt 0) {
    Write-Host ("  Nachbarsaal-Port TCP {0} freigegeben (nur Profil Privat/Domaene, nur eigenes Netz)." -f ($STATION_PORTS -join ', '))
  }
  if ($stationNichtOk.Count -gt 0) {
    Write-Host ("  Hinweis: Nachbarsaal-Port TCP " + ($stationNichtOk -join ', ') + " nicht freigegeben. Bei EINEM OP-Saal ohne Belang.")
  }
  if ($aufgeraeumt -gt 0) { Write-Host ("  {0} doppelte Altregel(n) aufgeraeumt." -f $aufgeraeumt) }
  if ($nichtOk.Count -gt 0) {
    Write-Warning ("Nicht freigegeben: TCP " + ($nichtOk -join ', ') + ". Bitte in der Windows-Firewall von Hand pruefen.")
  } else {
    Write-Host "  Fertig. Ankommende Vitaldaten werden nicht mehr blockiert."
  }
  Write-Host ""
}
if ($nichtOk.Count -gt 0) { exit 1 }
exit 0
