'use strict';
/*
 * check-haengt-nicht-test.js — der Verbindungs-Check muss IMMER ein Ergebnis liefern.
 *
 * WAS PASSIERT WAR (Praxis-PC, 22.07.2026):
 * Der Check blieb bei "HL7-Abfrage auf Port 4601 ..." stehen und gab NIE ein Ergebnis aus.
 * Ursache: die Frist war eine LEERLAUF-Frist (socket.setTimeout). Ein Geraet, das dauernd
 * Daten schickt, die kein "MSH" enthalten — genau das tut ein Mindray-Geraet, das auf diesem
 * Port sein proprietaeres MD2 spricht —, setzt den Leerlauf-Timer bei jedem Paket zurueck.
 * Das 'timeout'-Ereignis kam nie, das Versprechen loeste sich nie auf.
 * Fuer den Tierarzt sah das aus wie ein Absturz, und er erfuhr NICHTS ueber sein Geraet.
 *
 * Hier wird das mit ECHTEN Sockets nachgestellt: drei Geraete-Attrappen, die sich genau so
 * verhalten wie die drei Faelle in der Praxis.
 *
 * Start: node tools/check-haengt-nicht-test.js      (laeuft auch in `npm test`)
 */
const net = require('net');
const path = require('path');
const { spawn } = require('child_process');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

// pdsHandshake ist nicht exportiert (bewusst: das Werkzeug ist ein Programm, keine Bibliothek).
// Deshalb wird die Datei hier gelesen und die Funktion isoliert ausgewertet - so testen wir
// GENAU den ausgelieferten Code, nicht eine Kopie davon.
function ladePdsHandshake() {
  const fs = require('fs');
  const src = fs.readFileSync(path.join(__dirname, 'geraete-check.js'), 'utf8');
  const start = src.indexOf('function pdsHandshake');
  if (start < 0) throw new Error('pdsHandshake nicht gefunden');
  // Bis zur naechsten Funktion auf oberster Ebene lesen.
  const rest = src.slice(start);
  const ende = rest.indexOf('\n// Lauscht auf allen');
  const body = rest.slice(0, ende > 0 ? ende : rest.length);
  const VT = 0x0b, FS = 0x1c, CR = 0x0d;
  const mllp = (t) => Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]);
  const { parseHL7Message } = require('../bridge/src/adapters/hl7');
  // eslint-disable-next-line no-new-func
  const f = new Function('net', 'VT', 'FS', 'CR', 'mllp', 'parseHL7Message',
    body + '\nreturn pdsHandshake;');
  return f(net, VT, FS, CR, mllp, parseHL7Message);
}

function attrappe(verhalten) {
  return new Promise((resolve) => {
    const srv = net.createServer((sock) => {
      sock.on('error', () => {});
      verhalten(sock);
    });
    srv.listen(0, '127.0.0.1', () => resolve({ srv: srv, port: srv.address().port }));
  });
}

async function run() {
  console.log('VetStation — der Verbindungs-Check haengt nie (Praxis-Befund 22.07.2026)\n');
  const pdsHandshake = ladePdsHandshake();

  /* --- Fall 1: DER Fall vom Praxis-PC. Geraet plaudert dauernd, aber kein HL7. --- */
  console.log('Geraet antwortet dauernd, spricht aber kein HL7 (Mindray MD2):');
  const a = await attrappe((sock) => {
    // Alle 100 ms ein Haeppchen Binaerdaten - so wird der Leerlauf-Timer nie wirksam.
    const t = setInterval(() => { try { sock.write(Buffer.from([0x02, 0x7e, 0x00, 0x41, 0x13])); } catch (_) {} }, 100);
    sock.on('close', () => clearInterval(t));
  });
  const t0 = Date.now();
  const r1 = await pdsHandshake('127.0.0.1', a.port, 1500);
  const dauer1 = Date.now() - t0;
  a.srv.close();
  ok('die Pruefung liefert ueberhaupt ein Ergebnis (haengt nicht)', !!r1, 'kein Ergebnis');
  ok('sie haelt die Frist ein (unter 4 s bei 1,5 s Vorgabe)', dauer1 < 4000, dauer1 + ' ms');
  ok('sie meldet NICHT faelschlich "HL7 erkannt"', !(r1 && r1.ok));
  ok('sie erkennt "antwortet, aber kein HL7"', !!(r1 && r1.keinHl7), JSON.stringify(r1));
  ok('sie nennt das vermutete Protokoll im Klartext', /MD2|proprietaer/i.test((r1 && r1.grund) || ''), (r1 && r1.grund) || '');
  ok('sie zeigt die ersten Bytes zur Analyse', /[0-9a-f]{6,}/.test((r1 && r1.grund) || ''));

  /* --- Fall 2: Verbindung steht, Geraet schweigt (Datenausgabe aus) --- */
  console.log('\nGeraet nimmt die Verbindung an, sendet aber nichts:');
  const b = await attrappe(() => { /* absichtlich still */ });
  const t1 = Date.now();
  const r2 = await pdsHandshake('127.0.0.1', b.port, 1200);
  const dauer2 = Date.now() - t1;
  b.srv.close();
  ok('auch hier kommt ein Ergebnis', !!r2);
  ok('innerhalb der Frist', dauer2 < 4000, dauer2 + ' ms');
  ok('der Befund unterscheidet sich vom Fall "kein HL7"', !(r2 && r2.keinHl7));
  ok('er nennt die wahrscheinliche Ursache am Geraet',
    /sendet nichts|Datenausgabe|Zeitueberschreitung/i.test((r2 && r2.grund) || ''), (r2 && r2.grund) || '');

  /* --- Fall 3: echtes HL7 - es muss weiterhin erkannt werden (keine Regression) --- */
  console.log('\nEchtes HL7 wird weiterhin erkannt (keine Regression):');
  const VT = 0x0b, FS = 0x1c, CR = 0x0d;
  const oru = 'MSH|^~\\&|uMEC12Vet|||||20260722070000||ORU^R01|1|P|2.3.1\r' +
    'PID|||OP-9\rOBR|1||||uMEC12Vet\r' +
    ['OBX|1|NM|101^HR||88', 'OBX|2|NM|160^SpO2||97', 'OBX|3|NM|220^CO2||38'].join('\r');
  const c = await attrappe((sock) => {
    sock.on('data', () => {
      try { sock.write(Buffer.concat([Buffer.from([VT]), Buffer.from(oru, 'latin1'), Buffer.from([FS, CR])])); } catch (_) {}
    });
  });
  const r3 = await pdsHandshake('127.0.0.1', c.port, 3000);
  c.srv.close();
  ok('HL7 wird erkannt', !!(r3 && r3.ok && r3.hl7), JSON.stringify(r3));
  ok('die Messwerte werden gelesen', !!(r3 && r3.werte && r3.werte.length >= 3), JSON.stringify(r3 && r3.werte));
  ok('HF 88 korrekt', !!(r3 && (r3.werte || []).indexOf('HR=88') >= 0));

  /* --- Fall 4: niemand da --- */
  console.log('\nNiemand an der Adresse:');
  const t2 = Date.now();
  const r4 = await pdsHandshake('127.0.0.1', 1, 1000);   // Port 1 nimmt niemand an
  ok('auch hier kommt ein Ergebnis', !!r4);
  ok('schnell (abgelehnt statt Frist abwarten)', Date.now() - t2 < 2500, (Date.now() - t2) + ' ms');
  ok('mit verstaendlichem Grund', /abgelehnt|Antwort/i.test((r4 && r4.grund) || ''), (r4 && r4.grund) || '');

  /* --- Der Code selbst: die harte Frist muss drinbleiben --- */
  console.log('\nDie Absicherung im Quelltext:');
  const src = require('fs').readFileSync(path.join(__dirname, 'geraete-check.js'), 'utf8');
  ok('es gibt eine Frist unabhaengig vom Datenverkehr', /const hart = setTimeout\(/.test(src));
  ok('sie wird bei Erfolg wieder aufgeraeumt', /clearTimeout\(hart\)/.test(src));
  ok('der Empfangspuffer ist begrenzt', /buf\.length < 65536/.test(src));
  ok('die Lauschphase zeigt sichtbaren Fortschritt', /Lausche \.\.\. noch/.test(src));
  ok('der Befund wird an die Diagnose weitergereicht', /proprietaer: proprietaer/.test(src));

  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
}

run().catch((e) => { console.error('Testfehler:', e); process.exit(1); });
