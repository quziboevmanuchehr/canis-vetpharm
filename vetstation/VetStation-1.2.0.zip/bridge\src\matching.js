'use strict';
/*
 * matching.js — Patienten-Zuordnung (§6). Fuehrt Geraete, die zum selben Patienten gehoeren,
 * zu EINEM Datensatz zusammen: Monitor (Kreislauf/EKG) + Kapno/Narkose (Atmung/EtCO2/Iso).
 * Schluessel = patientId, sonst Tierart+Gewicht-Bucket; manuelles Koppeln ueberschreibt.
 */
const { patientKey } = require('./model');

// roleWeight: monitor liefert bevorzugt Kreislauf, anesthesia/capno bevorzugt Atmung.
function roleWeightFor(role, field) {
  const cardio = { hr: 3, spo2: 3, pleth: 3, sys: 3, dia: 3, map: 3, ekgRhythm: 3, temp: 2 };
  const resp = { etco2: 3, fico2: 3, af: 3, capnoShape: 3, paw: 3 };
  if (role === 'monitor') return cardio[field] || 1;
  if (role === 'anesthesia' || role === 'capno') return resp[field] || 1;
  return 2; // combo
}

/*
 * mergePatients(deviceRecords, manual) -> patients[]
 * deviceRecords: [{ deviceId, model, role, frame(normalized), status }]
 * manual: { deviceId -> patientKey }  (manuelles Koppeln)
 */
function mergePatients(deviceRecords, manual) {
  manual = manual || {};
  const groups = new Map();

  for (const d of deviceRecords) {
    if (!d.frame) continue;
    const key = manual[d.deviceId] || patientKey(d.frame);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(d);
  }

  const patients = [];
  for (const [key, devs] of groups) {
    // neueste zuerst
    devs.sort((a, b) => (b.frame.ts || 0) - (a.frame.ts || 0));
    const vit = { __w: {} };
    let species = null, weightKg = null, patientId = null, ts = 0, isoPct = null, ventMode = null;
    let o2Flow = null, ventParams = null;   // Narkosegeraet: Frischgasfluss + Beatmungsparameter (Vt/AF/PEEP...)
    let afSource = null;                     // woher die Atemfrequenz kommt: 'kapnograph' | 'monitor'
    let patientName = null, herkunft = null, gebDatum = null, geschlecht = null;
    let ekgAnalyse = null;   // EKG-Auswertung (QRS/Rhythmus/ST) - vom Geraet, das ein EKG liefert
    const akte = {};   // Stammdaten des Geraets, feldweise zusammengetragen
    const alarms = [];
    const roh = [];      // Rohwerte ALLER beteiligten Geraete (Ansicht "Alle Werte vom Geraet")
    const kurvenDaten = [];  // echte Abtastwerte je Kanal (EKG, CO2, Atmung)
    const kurven = [];
    for (const d of devs) {
      const f = d.frame;
      // Rollengewichtete Zusammenfuehrung der Vitalwerte.
      const v = f.vitals;
      const wrap = {};
      ['hr','spo2','pleth','etco2','fico2','paw','temp','ekgRhythm','capnoShape'].forEach(fld => {
        if (v[fld] != null) applyField(vit, fld, v[fld], roleWeightFor(f.deviceRole, fld));
      });
      // AF (Atemfrequenz) mit QUELLEN-PRIORITAET: der Kapnograph/das Narkosegeraet zaehlt die
      // Atemzuege direkt aus der CO2-Wellenform -> genauer/sicherer als die Impedanz-Atmung des
      // Monitors. Ein Geraet, das CO2 misst (etco2/fico2/capnoShape) ODER role anesthesia/capno hat,
      // gewinnt daher fuer AF; der Monitor liefert AF nur als Rueckfall ("erst Monitor, aber der
      // Kapnograf hat Prioritaet"). Bonus +3 hebt jede Kapno-Quelle ueber jede Nicht-Kapno-Quelle.
      if (v.af != null) {
        const capno = (f.deviceRole === 'anesthesia' || f.deviceRole === 'capno'
          || v.etco2 != null || v.fico2 != null || v.capnoShape != null);
        const w = roleWeightFor(f.deviceRole, 'af') + (capno ? 3 : 0);
        const cur = vit.__w.af || 0;
        if (vit.af == null || w > cur) { vit.af = v.af; vit.__w.af = w; afSource = capno ? 'kapnograph' : 'monitor'; }
      }
      if (v.nibp) {
        ['sys','dia','map'].forEach(fld => {
          if (v.nibp[fld] != null) applyField(vit, fld, v.nibp[fld], roleWeightFor(f.deviceRole, fld));
        });
      }
      if (!species && f.species) species = f.species;
      if (!weightKg && f.weightKg) weightKg = f.weightKg;
      if (!patientId && f.patientId) patientId = f.patientId;
      if (!patientName && f.patientName) patientName = f.patientName;
      if (!herkunft && f.herkunft) herkunft = f.herkunft;
      // Akte feldweise zusammentragen: das Geraet schickt die Stammdaten oft nur EINMAL beim
      // Bestaetigen des Patientendialogs, danach nur noch Kurven. Wer sie ueberschreibt, sobald
      // eine Kurvennachricht ohne Stammdaten kommt, verliert sie sofort wieder.
      if (f.akte) Object.keys(f.akte).forEach((k) => { if (akte[k] == null && f.akte[k] != null) akte[k] = f.akte[k]; });
      if (!gebDatum && f.gebDatum) gebDatum = f.gebDatum;
      if (!geschlecht && f.geschlecht) geschlecht = f.geschlecht;
      if (isoPct == null && f.isoPct != null) isoPct = f.isoPct;
      if (!ventMode && f.ventMode) ventMode = f.ventMode;
      if (o2Flow == null && f.o2Flow != null) o2Flow = f.o2Flow;
      // Beatmungsparameter feldweise zusammentragen (juengstes Geraet zuerst -> nicht ueberschreiben).
      if (f.ventParams && typeof f.ventParams === 'object') {
        if (!ventParams) ventParams = {};
        Object.keys(f.ventParams).forEach((k) => { if (ventParams[k] == null && f.ventParams[k] != null) ventParams[k] = f.ventParams[k]; });
      }
      // EKG-Auswertung vom Geraet uebernehmen, das eine EKG-Kurve liefert (der Monitor, nicht das
      // Narkosegeraet). Die juengste gewinnt (devs ist nach ts absteigend sortiert).
      if (!ekgAnalyse && f.ekgAnalyse) ekgAnalyse = f.ekgAnalyse;
      if (f.ts > ts) ts = f.ts;
      (f.alarms || []).forEach(a => alarms.push(a));
      // Rohwerte je Geraet kennzeichnen: bei zwei Geraeten am selben Patienten muss erkennbar
      // bleiben, WELCHES den Wert geliefert hat (Monitor oder Narkosegeraet).
      (f.roh || []).forEach((x) => roh.push(Object.assign({ von: d.deviceId, modell: f.deviceModel }, x)));
      (f.kurven || []).forEach((k) => { if (kurven.indexOf(k) < 0) kurven.push(k); });
      // Echte Kurven: je Kanal nur die NEUESTE behalten (devs ist nach ts absteigend sortiert),
      // sonst wachsen die Daten mit jedem Geraet weiter an.
      (f.kurvenDaten || []).forEach((k) => {
        if (!kurvenDaten.some((x) => x.code === k.code)) kurvenDaten.push(Object.assign({ von: d.deviceId }, k));
      });
    }
    delete vit.__w;
    patients.push({
      patientKey: key,
      patientId: patientId || null,
      patientName: patientName || null,
      gebDatum: gebDatum || null,
      geschlecht: geschlecht || null,
      akte: Object.keys(akte).length ? akte : null,
      species: species || null,
      weightKg: weightKg || null,
      herkunft: herkunft || null,
      devices: devs.map(d => ({
        deviceId: d.deviceId, model: d.frame.deviceModel, role: d.frame.deviceRole,
        ip: d.frame.deviceIp || null, port: d.frame.devicePort || null,
      })),
      vitals: vit,
      isoPct, ventMode, o2Flow, ventParams,
      afSource,
      ekgAnalyse,
      alarms,
      roh, kurven, kurvenDaten,
      ts,
      manual: devs.some(d => manual[d.deviceId]),
    });
  }
  // Aeltere/leere Patienten hinten.
  patients.sort((a, b) => (b.ts || 0) - (a.ts || 0));
  return patients;
}

// interner Helfer mit Gewichtsvergleich
function applyField(vit, field, val, weight) {
  const cur = vit.__w[field] || 0;
  if (vit[field] == null || weight > cur) { vit[field] = val; vit.__w[field] = weight; }
}

/*
 * fuerRundruf(patients) — was zweimal pro Sekunde an JEDES offene Fenster geht.
 *
 * WARUM ES DIESE FUNKTION GIBT (gemessen 22.07.2026): Seit die Station ALLE Werte des Geraets
 * mitfuehrt, haengen an jedem Patienten roh[] (jeder Einzelwert) und kurvenDaten[] (Abtastwerte).
 * Zusammen sind das rund 17 KB je Patient - und der Rundruf laeuft 2x pro Sekunde. Bei drei
 * Patienten waeren das ueber 100 KB/s an Daten, die die Oberflaeche im Rundruf KEIN EINZIGES MAL
 * liest: die Rohwerte holt sie auf Klick ueber /api/geraet, die Kurven zeichnet sie aus dem
 * eigenen Kanal. Das ist verschenkte Bandbreite, Speicher und JSON-Zeit im Kiosk-Browser.
 *
 * Die Namensliste kurven[] bleibt drin - sie ist wenige Bytes und steht im Geraete-Menue.
 */
// Billiger Hash ueber ein paar Stuetzstellen eines Kurvenstreifens: die Signatur aendert sich, sobald
// ein NEUER Streifen kommt, bleibt aber winzig (statt 512 Zahlen zu uebertragen).
function kurvenChecksum(samples) {
  if (!samples || !samples.length) return 0;
  const n = samples.length;
  const a = samples[0] || 0, b = samples[n - 1] || 0, c = samples[n >> 1] || 0;
  return (((a * 31 + b) * 31 + c) | 0);
}

function fuerRundruf(patients) {
  return (patients || []).map((p) => {
    const k = Object.assign({}, p);
    /*
     * ECHTE KURVEN: die Abtastwerte (kurvenDaten) bleiben weiterhin aus dem 500-ms-Rundruf DRAUSSEN
     * (sie waeren zu gross). Stattdessen wandert nur eine kompakte SIGNATUR mit - aendert sie sich,
     * holt die Oberflaeche den neuen Streifen einmalig ueber /api/kurven und zeichnet ihn ECHT.
     * So bleibt der Rundruf klein UND der virtuelle Monitor zeigt die echte Kurve statt der Nachbildung.
     */
    k.kurvenSig = (p.kurvenDaten || [])
      .map((kd) => (kd.code || '') + ':' + (kd.hz || '') + ':' + (kd.samples ? kd.samples.length : 0) + ':' + kurvenChecksum(kd.samples))
      .join('|') || null;
    delete k.roh;
    delete k.kurvenDaten;
    return k;
  });
}

module.exports = { mergePatients, fuerRundruf };
