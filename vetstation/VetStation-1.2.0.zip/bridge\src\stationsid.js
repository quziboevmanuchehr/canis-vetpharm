'use strict';
/*
 * stationsid.js — die Kennung DIESES Praxis-PCs innerhalb einer Praxis.
 *
 * WOFUER: Ab 1.1.0 koennen mehrere Praxis-PCs im SELBEN Praxis-Konto angemeldet sein — zwei OP-Saele,
 * jeder mit eigenen Geraeten, und beide sollen sich gegenseitig live sehen. Bis 1.0.3 schrieb jede
 * Station in denselben Knoten /live/<Konto-Kennung>. Zwei Stationen haetten sich dort gegenseitig
 * ueberschrieben, und — schlimmer — sie haetten sich einen einzigen Frische-Zeitstempel geteilt: der
 * laufende Saal haette den ausgefallenen frisch aussehen lassen. Am narkotisierten Patienten waere
 * das die gefaehrlichste Verwechslung, die dieses Programm anrichten kann. Deshalb bekommt jeder PC
 * einen eigenen Zweig, und dieser Zweig braucht einen Namen: die STATIONSKENNUNG (sid).
 *
 * WORAUS SIE ABGELEITET WIRD — und warum nicht gewuerfelt (BEWUSSTE ABWEICHUNG VON N1, Befund B5):
 * N1 verlangt "sid beim ERSTEN Lauf aus crypto.randomBytes, MachineGuid nur als Rueckfall wenn die
 * Datei fehlt". Umgesetzt ist die Ableitung aus MachineGuid + Rechnername. Die Begruendung, die hier
 * frueher stand ("gewuerfelt waere die Kennung bei JEDEM Aufsetzen neu"), war SACHLICH FALSCH und ist
 * damit hiermit zurueckgezogen: auf-usb-kopieren.ps1:64 schliesst (Join-Path $Root 'data') vom Stick
 * aus, und Install-VetStation.ps1:91 kopiert mit robocopy /E (nicht /MIR) und loescht im Ziel
 * nichts — eine einmal erzeugte data\station-id.json UEBERLEBT also jedes Aufsetzen und jedes Update.
 * Die tragende Begruendung ist eine andere und sie gilt:
 *   Gewuerfelt ist die Kennung NUR so lange erhalten, wie die Datei erhalten ist. Geht data\ verloren
 *   (Plattenreparatur, ein Aufraeumen von Hand, eine Sicherung, die data\ nicht enthielt), heisst der
 *   Saal danach anders — und ein Saal, der anders heisst, ist in der Fern-Ansicht ein NEUER, leerer
 *   Saal, waehrend sein Narkoseprotokoll unter dem alten Namen liegen bleibt. Genau dieses
 *   Zerschneiden ist der Schaden, den dieses Modul an jeder anderen Stelle verhindert (siehe
 *   umbenennen()). Abgeleitet ist die Kennung nach so einem Verlust WIEDERHERSTELLBAR.
 * Der Preis: gleiches Windows-Abbild + gleicher Rechnername ergibt dieselbe Kennung. Dagegen steht
 * die Kollisionserkennung weiter unten. Fairnesshalber, damit hier keine Werbung steht: gegen einen
 * VOLLEN Plattenklon hilft randomBytes ebenfalls nicht, weil station-id.json mitkopiert wird —
 * randomBytes gewinnt nur im Fall "Golden Image OHNE VetStation, danach auf beiden PCs installiert".
 * DAS IST EINE NUTZERENTSCHEIDUNG und keine Entscheidung dieses Bausteins: wer den Klonfall hoeher
 * gewichtet als den Datenverlustfall, ersetzt in laden() sidAus(quellwert, this.hostname) durch
 * frischeSid() und traegt das in die Vorgabe nach. Solange die Entscheidung nicht gefallen ist, gilt
 * hier der Weg, der keinen Saal umbenennt.
 *
 * WO SIE LIEGT — und warum nicht unter bridge\data:
 * data\station-id.json im WURZEL-Ordner data. Nachgesehen: installer/auf-usb-kopieren.ps1:64
 * schliesst per /XD NUR (Join-Path $Root 'data') aus, bridge\data NICHT; make-dist.ps1:44 schliesst
 * beide aus. Laege die Kennung unter bridge\data, wuerde sie bei der USB-Auslieferung MITKOPIERT —
 * und der neu aufgesetzte PC haette dieselbe Kennung wie der PC, von dem der Stick gezogen wurde.
 * Genau die Kollision, die dieser Umbau verhindern soll. Der Plantext nennt an einer Stelle
 * bridge/data — das ist ein Fehler im Entwurf und hier bewusst nicht uebernommen.
 *
 * WAS SIE UEBERSTEHT: Neustart (Datei bleibt; und ohne Datei liefert die Ableitung dasselbe),
 * neue IP oder neues Subnetz (in der Kennung steckt keine Adresse — Adressen stehen nur in
 * verbund/lan/<sid>.ips und werden laufend nachgezogen), Programm-Update und Neuaufsetzen: KEIN
 * Auslieferungsweg loescht data\ — make-dist.ps1:44 nimmt data\ und bridge\data nicht ins Paket,
 * Install-VetStation.ps1:91 kopiert mit robocopy /E und loescht im Ziel nichts, und der Git-Weg des
 * Updaters (updater/updater.js:119, 'git pull --ff-only') fasst unversionierte Dateien nicht an.
 *
 * WAS SIE NICHT IST: ein Geheimnis und kein Beweis. Wer im Praxisnetz eine sid behauptet, hat damit
 * nichts bewiesen. Geglaubt wird ausschliesslich, was mit dem PRIVATEN Ed25519-Schluessel dieser
 * Station unterschrieben ist; geprueft wird gegen den OEFFENTLICHEN Teil aus verbund/lan/<sid>.pub.
 *
 * WARUM SCHLUESSELPAAR UND KEIN GEMEINSAMES GEHEIMNIS (der Kern dieses Umbaus):
 * Ein gemeinsames Geheimnis muesste dort liegen, wo beide Seiten es lesen koennen — also im
 * Kontobaum. Diesen Baum abonniert JEDE Fern-Ansicht dauerhaft im Browser (Praxis-Tafel). Damit
 * haette jedes Handy und jedes Tablet, auf dem die Praxis-Ansicht offen ist, den Schluessel zum
 * Nachbar-Port im Praxisnetz — ein Vorfall am Privathandy waere ein Zugang ins Hausnetz. Beim
 * Schluesselpaar geht nur der OEFFENTLICHE Teil in den Baum.
 *
 * WO DER PRIVATE SCHLUESSEL LIEGT (Befund B4): NICHT in this.daten und in keinem aufzaehlbaren Feld.
 * this.daten ist das, was der Admin-Bereich und diagnose.js anzeigen duerfen und was ein
 * res.json(...) versehentlich abwerfen koennte; der private Teil liegt daneben in einer nicht
 * aufzaehlbaren Eigenschaft (_priv) und wird erst beim Schreiben der Datei wieder dazugelegt. Damit
 * enthaelt weder JSON.stringify(stationsid) noch JSON.stringify(stationsid.daten) den Schluessel.
 * Es gibt absichtlich kein priv(): wer etwas beweisen muss, laesst hier unterschreiben.
 *
 * ZWEI PCs MIT DERSELBEN KENNUNG (geklonter Rechner, kopiertes Windows-Abbild, Doppelstart) sind
 * moeglich: MachineGuid wird beim Klonen mitkopiert. Deshalb gibt es die INSTANZ — 16 Hexzeichen,
 * neu je Prozessstart, die jeder Schreibvorgang mitfuehrt (tafel/<sid>/meta.instanz).
 *
 * WARUM DIE ERKENNUNG DREI ZUSTAENDE HAT UND NICHT ZWEI (Befunde B1 und B2):
 *   'unbekannt'      — es ist noch nichts zurueckgelesen worden. N1 verlangt hier die Sperre
 *                      ("solange eine Kollision nicht ausgeschlossen ist"), also FAIL-CLOSED.
 *   'ausgeschlossen' — der eigene Kennungsknoten war leer oder trug eine EIGENE Instanz.
 *   'bewiesen'       — dort stand eine fremde, formgueltige Instanz, und sie kann nicht von einem
 *                      frueheren eigenen Prozess stammen.
 * Der frueher gebaute Zweizustand war in BEIDE Richtungen falsch:
 *   (a) Er hielt die eigene Instanz des VORHERIGEN Prozesses fuer einen Zwilling. Eine ganz normale
 *       Einzelstation sperrte sich damit nach jedem Neustart selbst von der Fern-Ansicht aus. Dagegen
 *       stehen jetzt zwei Merkmale, die verschiedene Aufgaben haben:
 *         - die LISTE der letzten eigenen Instanzen in der Datei (daten.instanzen). Sie erkennt den
 *           eigenen Vorgaenger sofort beim ersten Rueckleseweg und entsperrt damit ohne Umweg.
 *         - "die eigene Instanz stand schon einmal in dem Knoten" (_eigeneGesehen). Ein TOTER
 *           Vorgaenger kann uns nicht mehr ueberschreiben; wer nach uns dort steht, LEBT. Dieses
 *           Merkmal braucht keine Datei und traegt deshalb auch dann, wenn data\ nicht schreibbar
 *           ist und die Liste verloren geht.
 *   (b) Die Polaritaet war umgedreht: gesperrt wurde erst, SOBALD die Kollision bewiesen war, nicht
 *       solange sie unbewiesen war. Jetzt startet die Sperre geschlossen.
 * ANLAUFFRIST — die eine bewusste Abweichung von N1, mit Begruendung: fail-closed OHNE Ausweg heisst,
 * dass eine Station, deren Rueckleseweg ausfaellt (Kontingent erschoepft, Leseregel verweigert,
 * Backoff), ihre Patientendaten in der Fern-Ansicht DAUERHAFT verliert — ohne Zwilling, ohne
 * Ausweg. Das ist schlimmer als der Fehler, den die Sperre verhindern soll. Deshalb gilt die Sperre
 * im Zustand 'unbekannt' nur ANLAUF_MS lang; danach oeffnet sie mit einer Logzeile im Klartext.
 * ANLAUF_MS ist bewusst kleiner als eine Minute, damit keine Station beim Start eine Minute blind
 * ist. Der Preis dieser Abweichung ist benannt und nicht kaschiert: ein Zwilling, dessen
 * Rueckleseweg ganz ausfaellt, bleibt unentdeckt. Was ihn dann noch sichtbar macht, ist die
 * LESESEITE — beide schreiben tafel/<sid>/meta.instanz, der Wert dort springt zwischen zwei
 * Instanzen, und genau darauf schaut die Fern-Ansicht (Plan, DOPPELTE KENNUNG Punkt 4).
 *
 * REAKTION AUF EINEN BEWIESENEN ZWILLING: KEINE Selbstumbenennung. Eine Station, die sich mitten in
 * einer Narkose umbenennt, verschwindet fuer die Fern-Ansicht als Saal und taucht als neuer, leerer
 * Saal auf, und ihr unveraenderliches Narkoseprotokoll zerfaellt in zwei Teile. Statt dessen:
 * Klartext ins Log, harte Sperre auf "nur Tafel schreiben, keine Patientendaten", und die
 * Umbenennung macht ein MENSCH im Admin-Bereich (umbenennen()). Aus 'bewiesen' fuehrt deshalb
 * ausdruecklich KEIN automatischer Weg zurueck: bei laufendem Zwilling zeigt der Knoten abwechselnd
 * die eigene und die fremde Instanz, eine automatische Entwarnung wuerde die Sperre im Sekundentakt
 * auf- und zuklappen und damit gerade die Vermischung erlauben, die sie verhindert.
 *
 * ABLAGEFORM der Datei (Abweichungen vom Plantext sind hier benannt, Befund B9):
 *   sid, ableitung, quelle, erzeugt (ISO — wie im Plan), hostHash (8 Hex — wie im Plan),
 *   name, nameAm (NEU, Nachbesserung N10: der SAALNAME. Er liegt hier und nicht in
 *   bridge/config/devices.json, weil diese Datei im Auslieferstand gar nicht existiert und von
 *   niemandem geschrieben wird — Begruendung ausfuehrlich bei NAME_MAX weiter unten),
 *   pub, fp, instanzen[] (NEU, nicht im Plan: die Liste der letzten eigenen Instanzen, sie ist die
 *   Voraussetzung dafuer, dass sich eine Einzelstation nach einem Neustart nicht selbst aussperrt),
 *   umbenanntVon[], umbenanntAm, kollision, priv (nur in der DATEI, nicht in daten).
 * Eine unbrauchbare Datei wird nach station-id.ungueltig.json umbenannt — so nennt sie der Plan.
 *
 * NAME UND KENNUNG SIND ZWEI VERSCHIEDENE DINGE, und das Modul haelt sie auseinander:
 *   sid  = IDENTITAET. Sie steht in jedem Datenbankpfad und im unveraenderlichen Fern-Protokoll.
 *          Sie zu aendern (umbenennen()) laesst den Saal unter der alten Kennung erstarren und
 *          einen neuen, leeren erscheinen, raeumt die Live-Werte der alten Kennung weg und teilt
 *          das Narkoseprotokoll in zwei Zweige (die vollstaendige, gemessene Folge steht bei
 *          umbenennen()) — deshalb tut das nur ein Mensch, und nur als Ausweg aus einer
 *          Doppelkennung.
 *   name = ANZEIGE. Ihn zu aendern (setzeName()) kostet nichts: derselbe Saal heisst danach
 *          anders, sein Protokoll bleibt zusammen. Deshalb darf ihn ein Mensch jederzeit setzen.
 */
const os = require('os');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const netscan = require('./netscan');

/* Nur diese Form darf je in einen Datenbankpfad geraten. Geprueft wird VOR jeder Verwendung —
 * eine verbastelte station-id.json darf keinen Pfad erfinden koennen.
 * WORTGENAU wie im Plan und wie in tafel.js:90 und installer/firebase-rtdb-rules.json — drei
 * Stellen, die sich nicht widersprechen duerfen. Der Suffixzweig stammt aus der verworfenen
 * Selbstumbenennung; erzeugt wird er von niemandem mehr, gelesen wird er nur noch aus Nachsicht
 * gegen eine Datei aus einem 1.1.0-Vorabstand. */
const SID_FORM = /^st[0-9a-f]{12}(-[0-9a-f]{4})?$/;

/* Die Laengengrenze aus dem Plan ("Laenge <= 24") als AUSDRUECKLICHE Pruefung, nicht als Zufall.
 * Sie ist heute nicht erreichbar: was SID_FORM annimmt, ist 14 oder 19 Zeichen lang. Sie steht hier
 * fuer den Fall, dass jemand SID_FORM spaeter lockert (Befund B7: aus '?' wird '*' oder '{0,3}',
 * wenn jemand mehrere Suffixe zulassen will) — dann faengt diese Zeile die Ueberlaenge, ohne dass
 * die Zusage aus dem Plan still verloren geht. */
const SID_MAX = 24;

/* Die Instanz ist 16 Hexzeichen — genau das, was crypto.randomBytes(8).toString('hex') liefert.
 * GEPRUEFT wird die Form, GESAEUBERT wird nichts (Befund B3): eine Saeuberung machte aus jedem Wert,
 * der irgendwo ein Zeichen aus [0-9a-f] enthaelt, einen "Beweis" — aus true wurde 'e', aus '1.0.3'
 * wurde '103', und die Station sperrte sich wegen eines Formatfehlers aus. */
const INSTANZ_FORM = /^[0-9a-f]{16}$/;

/* Wie viele eigene Instanzen gemerkt werden. Sie dienen nur dazu, den eigenen Vorgaenger im
 * Kennungsknoten wiederzuerkennen; dafuer genuegen die letzten paar. Kurz gehalten, damit nach
 * einem Klon die vor dem Klonen gemeinsame Vorgeschichte schnell herausfaellt (sonst koennte ein
 * Zwilling, der eine ALTE gemeinsame Instanz zeigt, faelschlich als eigener Vorgaenger gelten). */
const INSTANZEN_MERKEN = 5;

/* Wie viele FREMDE Instanzen sich dieser Prozess merkt, um "schon einmal gemeldet" zu beantworten.
 * Nur dafuer — sie sind kein Vermerk und stehen in keiner Datei. Acht: bei mehr als acht geklonten
 * Stationen ist die Zahl der Zwillinge nicht mehr die Frage, sondern das Windows-Abbild. */
const ZWILLINGE_MERKEN = 8;

/* Anlauffrist der Sperre im Zustand 'unbekannt' (siehe Kopfkommentar). 15 s: der Tafeltakt ist 1 Hz,
 * ein gesunder Rueckleseweg antwortet also lange vorher; und 15 s sind deutlich weniger als die
 * Minute, nach der die Fern-Ansicht einen Saal als still ansieht. */
const ANLAUF_MS = 15000;

/* Ersatzbeweis, wenn die eigene Instanz nie im Knoten auftaucht (ein Zwilling, der uns in jedem
 * Takt ueberschreibt, bevor wir lesen). Dann gilt: derselbe fremde Wert steht dort ueber mehr als
 * BEWEIS_DAUER_MS und in mindestens BEWEIS_MELDUNGEN Rueckleseweg — obwohl wir jeden Takt unsere
 * eigene Instanz hineinschreiben. Ein TOTER Vorgaenger kann das nicht, sein Wert waere nach dem
 * ersten eigenen Schreibvorgang weg. Die Zaehlung der Meldungen ist wichtig: ohne sie wuerde eine
 * EINZIGE alte Meldung nach 5 s Wartezeit zum Beweis, und ein Rueckleseweg, der nach dem ersten
 * Versuch ausfaellt, haette die Einzelstation wieder ausgesperrt. Beide Werte liegen unter
 * ANLAUF_MS, damit der Beweis vor dem Oeffnen der Sperre ankommt. */
const BEWEIS_DAUER_MS = 5000;
const BEWEIS_MELDUNGEN = 3;

/* Wie oft der Kollisionsvermerk hoechstens in die Datei geschrieben wird. */
const VERMERK_TAKT_MS = 60000;

/* Wie oft dieselbe WIEDERKEHRENDE Warnung hoechstens ins Log geht (Befund A3). Bewusst eine eigene
 * Zahl neben VERMERK_TAKT_MS und nicht dieselbe Konstante: die eine drosselt Schreibvorgaenge in
 * eine Datei, diese hier drosselt Zeilen in dasselbe Log, in dem waehrend einer Narkose die
 * klinischen Warnungen stehen. Der Tafeltakt ist 1 Hz — ohne Drossel sind das 3600 Zeilen je
 * Stunde, und die eine klinische Warnung dazwischen findet niemand mehr. */
const WARN_TAKT_MS = 60000;

/* Der Datumsbereich von JavaScript endet bei ±8.64e15 ms (rund ±273790 Jahre um 1970). Darueber
 * hinaus WIRFT new Date(x).toISOString() einen RangeError — und isFinite() faengt das NICHT, es
 * laesst jede Zahl bis knapp unter Unendlich durch. Genau daran hat laden() geworfen (Befund A2),
 * obwohl es das Gegenteil zusagt. */
const ZEIT_MAX_MS = 8.64e15;

/* Die Ableitung ist versioniert. Muesste die Formel je geaendert werden, aendert sich mit der
 * Version JEDE Kennung — dann darf das nicht stillschweigend passieren, sondern nur mit einem
 * Umzug der alten Zweige. Die Version steht deshalb sichtbar hier und in der Datei. */
const ABLEITUNG_V = 'VetStation-Stationskennung-v1';

/* ------------------------------------------------------------------ DER SAALNAME (N10)
 *
 * WARUM DER NAME HIER LIEGT UND NICHT IN bridge/config/devices.json:
 * devices.json EXISTIERT im Auslieferstand nicht. Nachgesehen: Install-VetStation.ps1:92
 * schliesst sie per robocopy /XF ausdruecklich aus, bridge/config/ enthaelt nur
 * devices.example.json, und im ganzen Quellcode gibt es KEINE Stelle, die devices.json schreibt.
 * Jede ausgelieferte Station traegt deshalb den Vorlagewert 'Praxis OP 1' — alle gleich. Genau
 * die daraus folgende Verwechslung (zwei Saele, ein Name, zwei narkotisierte Tiere) soll dieser
 * Umbau beseitigen, und der Umbenennungsknopf aus dem Plan waere ohne Schreibweg nicht baubar.
 * data/station-id.json dagegen wird von diesem Modul ohnehin geschrieben und ueberlebt Update,
 * USB-Auslieferung und Neuaufsetzen (Begruendung im Kopfkommentar).
 */

/* DIE LAENGENGRENZE DES SAALNAMENS — abgelesen, nicht gewaehlt.
 *
 * Der Name geht an zwei Stellen in die Datenbank, und die Regeldatei zieht an jeder eine eigene
 * Grenze (installer/firebase-rtdb-rules.json, Fassung 30.07.2026, beide Zeilen nachgelesen):
 *   meta/station           ".validate": "newData.isString() && newData.val().length <= 120"
 *   tafel/<sid>/meta/name  ".validate": "newData.isString() ? newData.val().length <= 400 : true"
 * Es entscheidet die NIEDRIGERE: ein Name mit 121 Zeichen laesst die Datenbank den ganzen
 * atomaren 1-Hz-Koerper abweisen — samt Vitalwerten, nicht nur den Namen. Deshalb 120 und nicht
 * 400. Dieselbe Zahl steht als GRENZEN.spiegelStation in bridge/src/tafel.js und als
 * BINDUNG-Kommentar in der Regeldatei; tools/saalname-test.js LIEST die Regeldatei und haelt sie
 * gegen diese Zahl, damit die Stellen nicht auseinanderlaufen koennen.
 *
 * DASS DIE TAFEL SPAETER auf 40 Zeichen kuerzt (GRENZEN.tafelText), ist kein Widerspruch: das ist
 * die Kuerzung fuer eine Kachel von ~230 Byte. Der GESPEICHERTE Name darf davon nicht abhaengen —
 * in meta/station des Kompatibilitaetsspiegels und im Firestore-Verlauf steht der volle Name.
 * (Frueher stand hier zusaetzlich "im Druckkopf des Narkoseprotokolls". Das war falsch: der
 * Ausdruck traegt heute keinen Saalnamen, siehe stationsName() weiter unten.) */
const NAME_MAX = 120;

/* Der Vorlagewert aus bridge/config/devices.example.json:12.
 *
 * Er ist kein Saalname, sondern der Text, der in der BEISPIELdatei zeigt, wo der Name hingehoert.
 * Als VORBELEGUNG zaehlt er deshalb nicht: stationsName() geht darueber hinweg, die Station gilt
 * als unbenannt und fragt sichtbar nach. Tippt ein Mensch ihn im Admin-Bereich ausdruecklich ein,
 * wird er angenommen — dann ist er eine Entscheidung und keine Vorlage, und gegen zwei gleich
 * benannte Saele steht das angehaengte '· <sid6>' der Ansicht. */
const NAME_VORLAGE = 'Praxis OP 1';

/* Ein Wert, den es in keiner JSON-Datei geben kann — der Startwert der beiden Ein-Eintrag-
 * Gedaechtnisse fuer den Saalnamen (stationsName() und name(), Begruendung dort). null, undefined
 * oder '' taugen dafuer nicht: sie sind selbst gueltige Rohwerte, und der erste Aufruf haette dann
 * ein Ergebnis geliefert, das nie berechnet wurde. Ein Symbol ist mit === nur mit sich selbst
 * gleich, also kann kein Dateiinhalt es je treffen. */
const SENTINEL = Symbol('noch nie geprueft');

// ------------------------------------------------------------------ reine Funktionen

function sha256hex(s) { return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex'); }

function pruefeSid(s) { return typeof s === 'string' && s.length <= SID_MAX && SID_FORM.test(s); }

/* Die Ableitung selbst — absichtlich eine reine Funktion, damit ein Test beweisen kann, dass
 * dieselbe Maschine dieselbe Kennung ergibt und zwei Maschinen verschiedene. */
function sidAus(quellwert, hostname) {
  return 'st' + sha256hex(ABLEITUNG_V + '|' + String(quellwert || '') + '|' + String(hostname || '')).slice(0, 12);
}

/* Millisekunden -> ISO-Zeichenkette, oder null, wenn daraus kein lesbares Datum wird.
 * WIRFT NIE — und das ist der ganze Zweck: beide Aufrufstellen liegen in laden(), und laden() sagt
 * zu, nicht zu werfen. Vorher stand an beiden Stellen new Date(x).toISOString() hinter einem
 * isFinite(), das den Datumsbereich nicht kennt (Befund A2): eine station-id.json aus einem
 * Vorabstand mit erzeugt:1e20 besteht istBrauchbar(), geht in die Migration und beendete den
 * Prozess mit einem RangeError AUS laden() heraus — beim Start, also moeglicherweise mitten in
 * einer Narkose, und ausgeloest von einer Datei, deren Ueberleben dieses Modul sonst ueberall
 * absichert.
 * Zwei Huerden, und die zweite ist nicht kosmetisch: Jahre ausserhalb 0000..9999 schreibt
 * JavaScript mit Vorzeichen ('+058544-04-18T08:01:18.000Z'). Genau das entsteht, wenn in einer
 * Vorabdatei MIKROsekunden statt Millisekunden stehen. Ein Datum im Jahr 58544 hat keine Fassung
 * je gemeint; es ist kein Zeitpunkt, sondern ein Lesefehler, und es gehoert nicht in ein Feld,
 * das ein Mensch im Klartext lesen soll. */
function isoZeit(ms) {
  if (typeof ms !== 'number' || !isFinite(ms) || Math.abs(ms) > ZEIT_MAX_MS) return null;
  let s = null;
  /* Der Bereichsvergleich oben sollte genuegen. Das try steht daneben, damit die Zusage "wirft nie"
   * nicht an der Vollstaendigkeit dieser einen Zeile haengt — sie wird von laden() gebraucht. */
  try { s = new Date(ms).toISOString(); } catch (e) { return null; }
  return /^\d{4}-/.test(s) ? s : null;
}

/* Der Rechnername selbst gehoert NICHT in die Datenbank: er verraet oft den Namen der Praxis oder
 * des Tierarztes, und in der Datenbank steht schon der frei gewaehlte Saalname. Gespeichert wird
 * nur sein Fingerabdruck — er genuegt, um zu erkennen, dass die Datei zu diesem PC gehoert.
 * 8 Hexzeichen, wortgetreu wie im Plan (hostHash:"<8 hex>"). */
function hostHash(hostname) { return sha256hex(hostname || '').slice(0, 8); }

/* nameSauber(roh) — die EINE Formpruefung des Saalnamens: entschaerft, gekappt, oder null.
 *
 * WARUM ENTSCHAERFT UND NICHT NUR GEKAPPT: dieser Name wird auf dem Bildschirm eines FREMDEN
 * OP-Saals angezeigt, neben einer laufenden Narkose, und er steht in der Fern-Ansicht jedes
 * Handys, auf dem die Praxis-Ansicht offen ist. Es fallen dieselben Zeichen weg wie in tafel.js
 * text() (< > & " ' \ ` und alle Steuerzeichen). Das ist keine Doppelung von tafel.js, sondern die
 * Sperre an der QUELLE: tafel.js kuerzt fuer die Kachel auf 40 Zeichen, der VOLLE Name geht an
 * tafel.js vorbei in meta/station des Spiegels und in den Firestore-Verlauf.
 *
 * NULL HEISST "KEIN NAME", und das ist ein gueltiger Zustand, kein Fehler. tafel.js kennt ihn
 * (SPIEGEL_NAME_UNBENANNT), und die Regeldatei laesst tafel/<sid>/meta ohne 'name' ausdruecklich
 * zu — nur 'sid' ist dort Pflicht. Ein Saal ohne Namen wird vollstaendig weiter ueberwacht und
 * vollstaendig weiter uebertragen; er wird nur sichtbar angemahnt (N10: "Es darf NICHTS
 * blockieren").
 *
 * GEKAPPT WIRD NACH dem Zusammenziehen der Leerzeichen, nicht davor: sonst entschiede die Zahl
 * der Leerzeichen darueber, wie viel vom Namen uebrig bleibt. */
function nameSauber(roh) {
  if (typeof roh !== 'string') return null;
  let t = roh.replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ');
  t = t.replace(/[<>&"'\\`]/g, '');
  t = t.replace(/\s+/g, ' ').trim();
  if (!t) return null;
  return t.length > NAME_MAX ? t.slice(0, NAME_MAX).trim() : t;
}

/* stationsName(station, vorbelegung) — DIE EINE QUELLE fuer den Namen dieses OP-Saals.
 *
 * WER HIER WIRKLICH FRAGT — nachgezaehlt am 30.07.2026 (grep ueber bridge/, ui/, kiosk/), nicht
 * angenommen. Hier stand zwei Nachbesserungen lang eine Aufzaehlung von fuenf Lesern, und es war
 * genau EINER; das ist der Fehler, den Projektregel 1 meint, und er stand ausgerechnet an der
 * Stelle, an der der naechste Baumeister ihn glauben soll:
 *   bridge/src/server.js — GET /api/station. Ein Aufruf je Anfrage; davon leben der Admin-Bereich
 *                          und der Balken der Erstinbetriebnahme.
 *   bridge/src/cloud.js  — in JEDEM Sendetakt, und nur wenn Fern-Live eingeschaltet UND das
 *                          Praxis-Konto angemeldet ist. Von dort geht der Name an vier Stellen in
 *                          die Datenbank:
 *                            tafel/<sid>/meta.name  — der Kopf DIESES Saals (tafel.js kuerzt ihn
 *                                                     fuer die Kachel auf 40 Zeichen),
 *                            meta/station           — der Kompatibilitaetsspiegel der
 *                                                     ausgelieferten Web-App 1.0.3, aber NUR
 *                                                     solange dieser Saal allein im Konto ist;
 *                                                     ab dem zweiten Saal steht dort die feste
 *                                                     Zeichenkette SPIEGEL_NAME_MEHRSAAL,
 *                            patientId + ' · <Name>' — im Mehrsaalbetrieb; DAS ist das Feld, mit
 *                                                     dem die alte Web-App beantwortet, welches
 *                                                     Tier in welchem Saal liegt,
 *                            station                — im Firestore-Verlauf.
 * WER NICHT FRAGT, obwohl es hier behauptet stand: der PDF-DRUCKKOPF. ui/vetstation-live.js
 * schreibt in den Kopf des ausgedruckten Narkoseprotokolls 'VetStation' und darunter
 * 'Anaesthesie- / Narkoseueberwachungsprotokoll' — ein Saalname kommt dort nicht vor. Wer ihn
 * dort haben will, baut ihn dort ein; bis dahin darf ihn weder ein Kommentar noch eine
 * Oberflaeche versprechen.
 *
 * Der Grund fuer die EINE Quelle ist nicht Ordnungsliebe: haette die Tafel eine eigene Quelle
 * (der Plantext schlug os.hostname() vor) und der flache Spiegel eine zweite (cfg.station), dann
 * hiesse DERSELBE OP-Saal in der Tafel und in der alten Fern-Ansicht verschieden — und niemand
 * kann mehr entscheiden, welche Zahlen zu welchem Tier gehoeren. Das ist derselbe Fehler wie A3
 * der Vorrunde und der Kern von N10.
 *
 * DREI STUFEN, und die dritte ist eine bewusste Abweichung vom Plantext:
 *   1. der in data/station-id.json gesetzte Name. Er gewinnt IMMER — ihn hat ein Mensch AN
 *      DIESER Station eingetippt, und er ueberlebt Update, USB-Auslieferung und Neuaufsetzen.
 *   2. cfg.station aus bridge/config/devices.json, nur noch als VORBELEGUNG; der Vorlagewert
 *      'Praxis OP 1' zaehlt dabei nicht (siehe NAME_VORLAGE).
 *   3. null = "dieser Saal hat noch keinen Namen". KEIN Rueckfall auf os.hostname(), obwohl der
 *      Plantext (Abschnitt SAALNAME) ihn nennt: der Rechnername verraet in der Praxis regelmaessig
 *      den Namen der Praxis oder des Tierarztes, und dieser Name landet in einem Knoten, den JEDE
 *      Fern-Ansicht dauerhaft in den Browser laedt. Genau das ist bei hostHash() weiter oben schon
 *      entschieden ("Der Rechnername selbst gehoert NICHT in die Datenbank") und in
 *      tools/stationsid-test.js als Pruefung festgeschrieben ("Rechnername steht NICHT in der
 *      Datei"). Ein stiller Rueckfall haette diese Entscheidung an der Hintertuer aufgehoben.
 *      null ist ausserdem der ehrlichere Zustand: er ist der Grund, warum die Station sichtbar
 *      nach einem Namen fragt, statt einen erfundenen anzuzeigen.
 *
 * WIRFT NIE — und seit dieser Nachbesserung stimmt das auch (GEMESSEN, nicht angenommen):
 * die alte Fassung rief station.name() nackt auf. Ein Aufrufer, der irgendein Objekt mit einem
 * name() uebergibt, das wirft, riss die Ausnahme bis in den Sendetakt hoch — nachgemessen mit
 * { name() { throw ... } }: die alte Fassung warf, diese liefert null. Seit cloud.js hier in
 * JEDEM Takt fragt, ist das kein Gedankenspiel mehr: die Ausnahme entstuende mitten im Aufbau
 * des Spiegelkoerpers, also mitten in der Uebertragung einer laufenden Narkose. null heisst dann
 * "kein Name" — der Saal wird weiter vollstaendig uebertragen und nur ohne Namen angezeigt.
 *
 * UND SIE MUSS BILLIG SEIN, aus demselben Grund. Gemessen am 30.07.2026 auf dem Praxis-PC-Node:
 *   gewoehnlicher Name (21 Zeichen)          0,39 us je Aufruf,
 *   von Hand eingetragener 5000-Zeichen-Wert 16 us je Aufruf,
 *   Vorbelegung mit 200000 Zeichen           615 us je Aufruf.
 * Der erste Wert ist neben einem 1-Hz-Takt nichts. Die beiden anderen sind keine Erfindung: beide
 * Werte stehen in Dateien, die ein Mensch mit dem Editor aendert (data/station-id.json und
 * bridge/config/devices.json), und sie werden bei JEDEM Takt neu durch drei regulaere Ausdruecke
 * gezogen, obwohl sie sich nie aendern. Deshalb merken sich beide Wege ihren letzten ROHwert und
 * das Ergebnis dazu (name() unten, hier die Vorbelegung). Das Gedaechtnis vergleicht den Rohwert
 * und nicht einen Zeitpunkt — aendert jemand die Datei im laufenden Betrieb, ist der Rohwert ein
 * anderer und es wird neu geprueft. Die Zusage aus name() ("auch beim LESEN durch nameSauber")
 * bleibt damit unveraendert gueltig. */
let vorbelegungRoh = SENTINEL;   // der zuletzt gepruefte Rohwert der Vorbelegung
let vorbelegungRein = null;      // und sein Ergebnis
function stationsName(station, vorbelegung) {
  let gesetzt = null;
  /* Das try umschliesst auch den typeof-Zugriff: station.name kann ein Zugriffsmerkmal (getter)
   * sein, und auch das kann werfen. Ein Fehler hier darf hoechstens "kein Name" bedeuten. */
  try {
    if (station && typeof station.name === 'function') gesetzt = station.name();
  } catch (e) { gesetzt = null; }
  /* Nur eine ZEICHENKETTE gilt. Frueher genuegte "wahrheitswertig": ein fremdes Objekt aus einem
   * fehlgebauten Aufrufer waere so unveraendert in den Datenbankkoerper gewandert und haette ihn
   * samt Vitalwerten abweisen lassen (tafel/<sid>/meta.name laesst nur Zeichenketten zu). */
  if (typeof gesetzt === 'string' && gesetzt) return gesetzt;
  let vor;
  if (vorbelegung === vorbelegungRoh) vor = vorbelegungRein;
  else { vor = nameSauber(vorbelegung); vorbelegungRoh = vorbelegung; vorbelegungRein = vor; }
  if (vor && vor !== NAME_VORLAGE) return vor;
  return null;
}

/* Kurzform fuer die Anzeige und fuer die Schluessel des Kompatibilitaetsspiegels (s<sid6>__<key>).
 * 6 Hex-Zeichen: kurz genug zum Vorlesen am Telefon, lang genug, dass zwei Saele einer Praxis nicht
 * zusammenfallen.
 * ZWEI ZWEIGE, und der zweite ist der Grund (Befund B8): fuer die Grundform sind es die ersten 6
 * Hexzeichen der sid — genau das, was der Plan als <sid6> definiert und was Web-App und Kiosk an
 * gleichnamige Saele anhaengen. Die SUFFIXFORM einer Datei aus einem Vorabstand haette damit
 * DENSELBEN Kurzwert wie ihre Grundform — und der Suffix entstand in der verworfenen Bauform genau
 * dann, wenn zwei Stationen dieselben 12 Hexzeichen hatten. Grundform und Suffixform im selben Konto
 * haetten sich also auf der flachen Ebene wieder Feld fuer Feld gemischt. Deshalb bekommt die
 * Suffixform einen ABGELEITETEN Kurzwert. Dieser Zweig ist fuer jede sid, die dieses Modul selbst
 * erzeugt, unerreichbar — er ist nur die Absicherung der Nachsicht in SID_FORM. */
function sidKurz(sid) {
  const s = String(sid || '');
  if (s.indexOf('-') < 0) return s.slice(2, 8);
  return sha256hex(s).slice(0, 6);
}

/* Eine frische Kennung ohne jeden Bezug zur Maschine — NUR fuer die Umbenennung von Hand.
 * Kein Suffix an die alte Kennung: ein Suffix waere beim zweiten Mal nicht mehr anhaengbar, ohne
 * die Formatsperre zu reissen. Eine ganz neue Kennung kann beliebig oft erzeugt werden. */
function frischeSid() { return 'st' + crypto.randomBytes(6).toString('hex'); }

/* Formatsperre AUCH beim Einsetzen in einen Pfad. Grund: new URL() loest '..' im Pfad auf, ein
 * durchgereichtes '../fremd' waere also ein Verzeichnis hoeher — im Kontobaum ein fremder Saal.
 * Doppelt gesichert: Form pruefen UND encodeURIComponent. Wer null zurueckbekommt, darf keinen
 * Pfad bauen. */
function sidPfad(sid) { return pruefeSid(sid) ? encodeURIComponent(sid) : null; }

/* Das Schluesselpaar dieser Station. Rein und exportiert, damit ein Test Signieren und Pruefen
 * ohne Datei und ohne Netz nachvollziehen kann.
 *   priv = PKCS8 DER base64 (64 Zeichen) — bleibt auf DIESEM PC,
 *   pub  = SPKI  DER base64 (60 Zeichen) — darf veroeffentlicht werden,
 *   fp   = 16 Hex aus sha256(pub) — zum Vorlesen und Vergleichen am Telefon. */
function ed25519Paar() {
  const p = crypto.generateKeyPairSync('ed25519');
  const priv = p.privateKey.export({ type: 'pkcs8', format: 'der' }).toString('base64');
  const pub = p.publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
  return { priv: priv, pub: pub, fp: fingerabdruck(pub) };
}

/* Gehasht wird die base64-ZEICHENKETTE, also genau das, was im Kontobaum steht. Damit kann jeder,
 * der pub sieht, den Fingerabdruck nachrechnen, ohne wissen zu muessen, wie wir kodieren. */
function fingerabdruck(pubBase64) { return sha256hex(String(pubBase64 || '')).slice(0, 16); }

/* Ed25519 ohne Vorhash: crypto.sign(null, ...). Wirft nie — eine kaputte Schluesselangabe darf
 * keinen Schreibvorgang und keinen Handschlag abbrechen, sie darf nur "nicht unterschrieben"
 * bedeuten. */
function signiereMit(privBase64, nachricht) {
  try {
    const k = crypto.createPrivateKey({ key: Buffer.from(String(privBase64), 'base64'), format: 'der', type: 'pkcs8' });
    return crypto.sign(null, Buffer.from(String(nachricht), 'utf8'), k).toString('base64');
  } catch (e) { return null; }
}

/* Prueft eine Signatur gegen einen FREMDEN oeffentlichen Schluessel. Alles, was nicht nachweislich
 * stimmt, ist falsch: ungueltige base64, fremdes Verfahren, verstuemmelte Signatur — jeder Fehler
 * ergibt false, nie eine Ausnahme. Sonst koennte ein Nachbar mit Muell den eigenen Prozess
 * beenden, und das darf im OP nicht passieren. */
function pruefeSignatur(pubBase64, nachricht, sigBase64) {
  try {
    if (!pubBase64 || !sigBase64) return false;
    const k = crypto.createPublicKey({ key: Buffer.from(String(pubBase64), 'base64'), format: 'der', type: 'spki' });
    return crypto.verify(null, Buffer.from(String(nachricht), 'utf8'),
      k, Buffer.from(String(sigBase64), 'base64'));
  } catch (e) { return false; }
}

/* Ein gelesener Datensatz ist brauchbar, wenn die KENNUNG formal stimmt — und nur dann.
 * AUSDRUECKLICH NICHT MEHR GEFORDERT: ein Schluesselfeld. Frueher verlangte istBrauchbar() ein
 * lanGeheim; ein Datensatz ohne dieses Feld waere bei JEDEM Start beiseitegelegt und die Kennung
 * neu abgeleitet worden — die Station haette ihren Saal bei jedem Start umbenannt. Ein fehlendes
 * oder unbrauchbares Schluesselpaar wird nicht verworfen, sondern in laden() nachgezogen
 * (Migration einer schon erzeugten station-id.json). */
function istBrauchbar(d) {
  if (!d || typeof d !== 'object') return false;
  if (!pruefeSid(d.sid)) return false;
  return true;
}

/* Ist das Schluesselpaar vollstaendig und passt der Fingerabdruck zum oeffentlichen Teil?
 * Der Fingerabdruck wird nachgerechnet und nicht geglaubt: er wird am Telefon vorgelesen, um einen
 * Nachbarn zu bestaetigen — stimmte er nicht mit pub ueberein, waere die Bestaetigung wertlos.
 * Geprueft wird ein PLATTES Objekt {priv,pub,fp}, also das, was in der DATEI steht. In der Station
 * liegt priv getrennt (Befund B4), deshalb setzt _hatEigenesPaar() das Objekt dort zusammen. */
function hatPaar(d) {
  if (!d || typeof d !== 'object') return false;
  if (typeof d.priv !== 'string' || d.priv.length < 40) return false;
  if (typeof d.pub !== 'string' || d.pub.length < 40) return false;
  return d.fp === fingerabdruck(d.pub);
}

// ------------------------------------------------------------------ Herkunft der Quellwerte

/* MachineGuid nur LESEN — dieselbe Form wie netscan.arpTable() (netscan.js:145) und
 * firewall.js: execFile mit Zeitgrenze und windowsHide, kein Fremdpaket, keine Adminrechte.
 * Es wird ausdruecklich NICHT in die Registry geschrieben. */
function machineGuid() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve(null);
    execFile('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
      { timeout: 6000, windowsHide: true }, (err, stdout) => {
        if (err && !stdout) return resolve(null);
        const m = /MachineGuid\s+REG_SZ\s+([0-9a-fA-F-]{16,})/.exec(String(stdout || ''));
        resolve(m ? m[1].toLowerCase() : null);
      });
  });
}

/* Ausweichweg 1: die MAC der ersten NICHT virtuellen Karte. netscan.localAdapters() sortiert
 * VPN, Hyper-V, VMware, WSL, Tailscale und Bluetooth ueber die VIRTUELL-Regex aus (netscan.js:58) —
 * genau die Karten, deren Adressen sich aendern oder auf mehreren PCs gleich sind. */
function ersteEchteMac() {
  try {
    const echte = netscan.localAdapters().filter((a) => !a.virtuell && a.mac && a.mac !== '00:00:00:00:00:00');
    return echte.length ? echte[0].mac.replace(/[^0-9a-f]/gi, '').toLowerCase() : null;
  } catch (e) { return null; }
}

// ------------------------------------------------------------------ die Station selbst

class Stationsid {
  constructor(opts) {
    const o = opts || {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    // Neben cloud-auth.json, NICHT neben patient-akte.json: das ist eine Eigenschaft dieses
    // RECHNERS, keine Patientendaten. Wurzel-data\ ist von USB-Auslieferung UND Update-Paket
    // ausgeschlossen — siehe Kopfkommentar, bridge\data waere es nur halb.
    this.datei = o.datei || path.join(__dirname, '..', '..', 'data', 'station-id.json');
    this.hostname = o.hostname || os.hostname();
    /* Uhr als Naht, damit der Test die Drosselung und die Anlauffrist mit gestellter Zeit pruefen
     * kann, statt Sekunden lang zu warten. Im Betrieb steht hier immer Date.now. */
    this._jetzt = typeof o.jetzt === 'function' ? o.jetzt : Date.now;
    /* Die Instanz ist keine Identitaet, sondern der Nachweis "hier laeuft genau EIN Prozess".
     * Neu bei jedem Start — sonst koennte ein geklonter PC nicht erkannt werden. */
    this.instanz = crypto.randomBytes(8).toString('hex');
    this._startAm = this._jetzt();

    /* EINZIGE WAHRHEIT ueber die Sperre — 'unbekannt' | 'ausgeschlossen' | 'bewiesen'.
     * Startwert 'unbekannt' und damit GESCHLOSSEN (N1: "solange eine Kollision nicht ausgeschlossen
     * ist, nur tafel/<sid>/meta schreiben, keine Patientendaten"). Es gibt bewusst kein zweites
     * Merkfeld daneben: nurTafelSchreiben ist unten ein Nur-Lese-Zugriff auf genau diesen Zustand,
     * damit nicht zwei Felder auseinanderlaufen koennen. */
    this._stand = 'unbekannt';
    /* Stand die EIGENE, aktuelle Instanz schon einmal im eigenen Kennungsknoten? Wenn ja, kann ein
     * danach dort auftauchender fremder Wert nur von einem LEBENDEN Zwilling kommen. */
    this._eigeneGesehen = false;
    this._fremdWert = null;        // der fremde Wert, um den es geht
    this._fremdSeit = 0;           // seit wann er dort steht
    this._fremdAnzahl = 0;         // wie viele Ruecklesewege ihn gemeldet haben
    this._kollisionGeschriebenAm = null;  // wann der Vermerk WIRKLICH in die Datei ging (Befund B6)
    this._zwillingeGesehen = [];   // fremde Instanzen, die dieser Prozess schon gemeldet hat
    this._anlaufGemeldet = false;
    /* Drosseln fuer die zwei Logausgaenge, die im 1-Hz-Takt getroffen werden koennen (Befund A3).
     * Beide messen die ZEIT; der zuletzt gesehene Wert allein genuegt nicht, siehe _formMuell(). */
    this._formMuellZuletzt = null;
    this._formMuellGemeldetAm = null;
    this._setzerGemeldetAm = null;

    /* Nur fuer den Test: die Registry-Abfrage ist austauschbar, damit tools/stationsid-test.js
     * ohne Registry-Zugriff laufen kann. Im Betrieb steht hier immer machineGuid(). */
    this._guidLesen = typeof o.machineGuid === 'function' ? o.machineGuid : machineGuid;
    this.daten = null;
    /* Der private Schluessel: eigenes Feld, aber NICHT aufzaehlbar (Befund B4). Damit taucht er
     * weder in Object.keys(station) noch in JSON.stringify(station) auf — ein res.json(stationsid)
     * oder ein Objektabwurf in /api/diag kann ihn nicht mehr versehentlich ausliefern. */
    Object.defineProperty(this, '_priv', { value: null, writable: true, enumerable: false, configurable: false });
    /* Das Ein-Eintrag-Gedaechtnis des Saalnamens (Begruendung bei name()). NICHT aufzaehlbar aus
     * demselben Grund wie _priv: this.daten ist das, was der Admin-Bereich und diagnose.js
     * anzeigen duerfen — ein Zwischenspeicher gehoert dort nicht hinein und soll auch in keinem
     * JSON.stringify(stationsid) auftauchen. */
    Object.defineProperty(this, '_nameRoh', { value: SENTINEL, writable: true, enumerable: false, configurable: false });
    Object.defineProperty(this, '_nameRein', { value: null, writable: true, enumerable: false, configurable: false });
  }

  /* Einmal beim Start. Danach liefert sid() ohne Seiteneffekt.
   * WIRFT NICHT — eine kaputte oder unlesbare Datei darf die Station nicht am Start hindern, die
   * Anzeige des eigenen Saals haengt nicht an der Fern-Uebertragung. Diese Zusage stand hier zwei
   * Nachbesserungen lang, waehrend der Code sie brach; deshalb steht jetzt daneben, WORAUF sie sich
   * stuetzt, damit die naechste Aenderung sie nicht wieder unbemerkt aushebelt (Befund A2):
   *   - unlesbare Datei / kaputtes JSON      -> try/catch um readFileSync+JSON.parse (unten),
   *   - ablehnende Registry-Abfrage          -> try/catch um den await auf _guidLesen (Befund B10),
   *   - jede Umrechnung nach ISO             -> ausschliesslich ueber isoZeit(), das nie wirft.
   *     Betroffen sind zwei Naehte: das Feld erzeugt einer FREMDEN Datei (in _migriere) und die
   *     gestellte Uhr opts.jetzt (unten beim Neuanlegen),
   *   - _migriere() als Ganzes               -> try/catch, weil dort ein Datensatz verarbeitet
   *     wird, dessen Felder ausser sid NIEMAND geprueft hat; die Aufzaehlung oben darf nicht die
   *     einzige Absicherung sein.
   * Der Grund fuer den Aufwand: eine abgelehnte Zusage beim Start ist ohne Plan-Schritt 5
   * (unhandledRejection am Leben lassen) ein Prozessende mitten in einer Narkose. */
  async laden() {
    let vorhanden = null;
    try {
      if (fs.existsSync(this.datei)) vorhanden = JSON.parse(fs.readFileSync(this.datei, 'utf8'));
    } catch (e) {
      this.log.warn('station', 'station-id.json ist nicht lesbar (' + e.message + ') — die Kennung wird neu abgeleitet.');
      this._beiseite();
    }

    if (istBrauchbar(vorhanden)) {
      /* priv wandert aus dem gelesenen Datensatz heraus, BEVOR er this.daten wird. */
      this._priv = typeof vorhanden.priv === 'string' ? vorhanden.priv : null;
      delete vorhanden.priv;
      this.daten = vorhanden;
      // Kein Registry-Zugriff mehr, wenn die Datei gilt: DIE DATEI GEWINNT IMMER. Eine gesperrte
      // reg.exe (Gruppenrichtlinie) oder ein getauschtes Netzwerkkabel darf die Kennung nicht
      // aendern — und eine von Hand umbenannte Kennung darf nicht ueberschrieben werden.
      /* Das Netz zur Zusage im Kopf dieser Funktion (Befund A2). Die einzelnen gefaehrlichen
       * Stellen in _migriere() sind abgesichert; dieses try faengt, was in einer fremden Datei
       * sonst noch stecken koennte. Die Kennung steht zu diesem Zeitpunkt schon fest und ist
       * geprueft — eine halb durchgelaufene Migration kostet hoechstens eine Aufraeumarbeit, ein
       * Prozessende beim Start kostet die Narkoseueberwachung. */
      try { this._migriere(); }
      catch (e) {
        this.log.error('station', 'Beim Nachziehen der station-id.json ist ein Fehler aufgetreten ('
          + (e && e.message) + '). Die Kennung ' + (this.daten.sid || '?') + ' gilt unveraendert '
          + 'weiter; die Station laeuft normal. Bitte die Datei bei Gelegenheit ansehen.');
      }
      this._instanzMerken();
      if (!this._speichern()) this._instanzlisteFluechtig();
      this.log.info('station', 'Stationskennung ' + this.sid() + ' (aus ' + (this.daten.quelle || 'Datei') + ', gemerkt)');
      return this.daten;
    }
    if (vorhanden) {
      this.log.warn('station', 'station-id.json ist unbrauchbar — die Kennung wird neu abgeleitet.');
      this._beiseite();
    }

    /* Befund B10: der await ist abgesichert. _guidLesen ist eine ausdrueckliche Naht (opts.machineGuid);
     * ein Aufrufer, der die Registry-Abfrage z.B. mit einer eigenen Gesamtfrist umwickelt, wuerde
     * hier ablehnen — und laden() darf laut Zusage im Kommentar oben NICHT werfen. Eine abgelehnte
     * Zusage beim Start waere ohne Plan-Schritt 5 (unhandledRejection am Leben lassen) ein
     * Prozessende mitten in einer Narkose. */
    let guid = null;
    try { guid = await this._guidLesen(); }
    catch (e) {
      this.log.warn('station', 'Die Windows-Geraete-ID liess sich nicht abfragen (' + (e && e.message)
        + ') — es greift die Ausweichkette.');
    }
    let quelle = 'machineguid', quellwert = guid;
    if (!quellwert) { quellwert = ersteEchteMac(); quelle = 'mac'; }
    if (!quellwert) {
      /* Letzter Ausweg. Er ist bewusst der letzte: eine Zufallskennung ist verloren, sobald data\
       * verloren geht — und dann heisst der Saal in der Fern-Ansicht anders als sein Protokoll. */
      quellwert = crypto.randomBytes(6).toString('hex'); quelle = 'zufall';
      this.log.warn('station', 'Weder Windows-Geraete-ID noch eine echte Netzwerkkarte lesbar — '
        + 'die Stationskennung ist gewuerfelt. Sie bleibt in data\\station-id.json erhalten, '
        + 'geht aber verloren, wenn dieser Ordner nicht mitkopiert wird.');
    }

    const paar = this._paarErzeugen();
    this._priv = paar.priv;
    this.daten = {
      sid: sidAus(quellwert, this.hostname),
      ableitung: ABLEITUNG_V,
      quelle: quelle,
      /* ISO-Zeichenkette, wortgetreu wie im Plan (erzeugt:<ISO>). Gelesen wird sie von niemandem,
       * sie steht fuer den Menschen in der Datei — und eine Millisekundenzahl kann kein Mensch
       * lesen. Ueber isoZeit() statt direkt, weil this._jetzt() eine ausdrueckliche Naht ist
       * (opts.jetzt, siehe Konstruktor): eine Uhr, die NaN oder eine unmoegliche Zahl liefert,
       * haette hier einen RangeError aus laden() geworfen (Befund A2). null heisst dann schlicht
       * "der Zeitpunkt ist nicht bekannt" — das Feld traegt keine Entscheidung. */
      erzeugt: isoZeit(this._jetzt()),
      hostHash: hostHash(this.hostname),
      /* Der Saalname beginnt AUSDRUECKLICH leer (N10, Erstinbetriebnahme). Kein Vorlagewert und
       * kein Rechnername: solange hier null steht, gilt die Station als unbenannt und fragt
       * sichtbar nach. Das Feld steht trotzdem von Anfang an in der Datei, damit ein Mensch, der
       * sie im Editor oeffnet, sieht, wo der Name hingehoert. */
      name: null,
      nameAm: null,
      pub: paar.pub,
      fp: paar.fp,
      instanzen: [],
      umbenanntVon: [],
      umbenanntAm: null,
      kollision: null,
    };
    this._instanzMerken();
    if (!this._speichern()) this._instanzlisteFluechtig();
    this.log.info('station', 'Stationskennung ' + this.sid() + ' neu abgeleitet (aus ' + quelle
      + '), Schluessel-Fingerabdruck ' + this.fp() + '.');
    return this.daten;
  }

  /* MIGRATION einer schon erzeugten Datei. Ein 1.1.0-Vorabstand hat sid UND lanGeheim, aber kein
   * Schluesselpaar geschrieben. Die sid MUSS bleiben — sie ist der Name des Saals in der
   * Fern-Ansicht und steht im unveraenderlichen Fern-Protokoll. Nachgezogen wird nur das Paar,
   * und lanGeheim* fliegt raus, damit das gemeinsame Geheimnis nicht als Altlast liegen bleibt.
   * SPEICHERT NICHT SELBST: laden() schreibt danach genau einmal (mit der Instanzliste zusammen). */
  _migriere() {
    const d = this.daten;

    if (d.lanGeheim !== undefined || d.lanGeheimVor !== undefined || d.lanGeheimTs !== undefined) {
      delete d.lanGeheim; delete d.lanGeheimVor; delete d.lanGeheimTs;
      this.log.info('station', 'Der frueher gemerkte gemeinsame LAN-Schluessel wurde entfernt — '
        + 'der Nachbarweg arbeitet ab 1.1.0 mit einem Schluesselpaar, dessen oeffentlicher Teil '
        + 'veroeffentlicht werden darf.');
    }
    /* Felder der verworfenen Selbstumbenennung. Sie werden nur entfernt, nie ausgewertet: waere
     * suffix noch wirksam, hiesse der Saal in der Fern-Ansicht anders als in seinem Protokoll. */
    if (d.suffix !== undefined || d.suffixGrund !== undefined || d.vorher !== undefined) {
      if (d.suffix) {
        this.log.warn('station', 'Diese Kennung wurde von einer aelteren Fassung automatisch '
          + 'umbenannt. Die Kennung bleibt wie sie ist (' + d.sid + '); umbenannt wird ab jetzt '
          + 'nur von Hand im Admin-Bereich.');
      }
      delete d.suffix; delete d.suffixGrund; delete d.vorher;
    }
    if (!this._hatEigenesPaar()) {
      const paar = this._paarErzeugen();
      this._priv = paar.priv; d.pub = paar.pub; d.fp = paar.fp;
      this.log.info('station', 'Stationskennung ' + d.sid + ' behalten, Schluesselpaar einmalig '
        + 'nachgezogen (Fingerabdruck ' + d.fp + ').');
    }
    /* Eine Millisekundenzahl aus einem Vorabstand wird auf die ISO-Form gezogen (Befund B9): sonst
     * stehen im Feld erzeugt je nach Alter der Datei zwei verschiedene Formen.
     * DIE ZAHL IST UNGEPRUEFT (Befund A2): istBrauchbar() sieht ausschliesslich auf sid, alles
     * andere in dieser Datei kann beliebig sein. Frueher stand hier isFinite() und danach ein
     * nacktes new Date(x).toISOString() — bei erzeugt:1e20 ein RangeError aus laden() heraus.
     * isoZeit() liefert statt dessen null, und null ist hier die ehrliche Antwort: eine Zahl, aus
     * der kein lesbares Datum wird, ist kein Zeitpunkt. Sie stehen zu lassen hiesse, genau die
     * zwei Formen im Feld zu behalten, die B9 beseitigt hat. */
    if (typeof d.erzeugt === 'number') {
      const iso = isoZeit(d.erzeugt);
      if (iso === null) {
        this.log.warn('station', 'Im Feld "erzeugt" der station-id.json stand die Zahl ' + d.erzeugt
          + ', aus der sich kein Datum lesen laesst. Das Feld wird geleert. Die Kennung ' + d.sid
          + ' bleibt unveraendert — sie haengt an diesem Feld nicht.');
      }
      d.erzeugt = iso;
    }
    /* DER SAALNAME AUS EINER FREMDEN DATEI (N10). data/station-id.json liegt auf einer
     * Windows-Platte und laesst sich mit dem Editor oeffnen — hier kann alles stehen: eine Zahl,
     * ein Objekt, 5000 Zeichen, ein '<'. Ungeprueft geriete das in den atomaren 1-Hz-Koerper und
     * liesse ihn samt aller Vitalwerte abweisen. Deshalb wird der Wert EINMAL beim Laden auf die
     * gespeicherte Form gezogen; gelesen wird er in name() zusaetzlich jedes Mal durch dieselbe
     * Funktion, damit auch eine Aenderung im laufenden Betrieb nicht durchschlaegt.
     * Ein unbrauchbarer Wert wird ENTFERNT, nicht auf einen Ersatznamen gesetzt: ein erfundener
     * Name waere in der Fern-Ansicht nicht von einem echten zu unterscheiden. */
    if (d.name !== undefined && d.name !== null) {
      const n = nameSauber(d.name);
      if (n === null) {
        this.log.warn('station', 'Im Feld "name" der station-id.json stand kein brauchbarer '
          + 'Saalname. Das Feld wird geleert; die Station gilt als unbenannt und fragt danach. '
          + 'Die Kennung ' + d.sid + ' bleibt unveraendert.');
        d.name = null;
      } else if (n !== d.name) {
        this.log.info('station', 'Der Saalname aus der station-id.json wurde auf die gespeicherte '
          + 'Form gezogen (hoechstens ' + NAME_MAX + ' Zeichen, ohne Sonderzeichen): "' + n + '".');
        d.name = n;
      }
    }
    if (d.name === undefined) d.name = null;
    if (d.nameAm === undefined) d.nameAm = null;
    if (!Array.isArray(d.instanzen)) d.instanzen = [];
    if (!Array.isArray(d.umbenanntVon)) d.umbenanntVon = [];
    if (d.umbenanntAm === undefined) d.umbenanntAm = null;
    if (d.kollision === undefined) d.kollision = null;
    if (!d.ableitung) d.ableitung = ABLEITUNG_V;
    /* Sollte in einer Vorabdatei doch ein hostHash mit 12 Zeichen stehen: nicht anfassen. Er wird
     * nirgends geprueft, und ein Neuberechnen brauchte den Rechnernamen von damals. */
  }

  _paarErzeugen() {
    try { return ed25519Paar(); }
    catch (e) {
      /* Ohne Paar laeuft die Station weiter — sie kann dann nur nichts unterschreiben, und der
       * Nachbarweg (Stufe 2) bleibt zu. Der eigene Saal und die Fern-Uebertragung haengen nicht
       * daran, und ein Start-Abbruch mitten in einer Narkose waere der groessere Schaden. */
      this.log.error('station', 'Es liess sich kein Schluesselpaar erzeugen (' + e.message
        + '). Der direkte Nachbarweg bleibt geschlossen; die Fern-Uebertragung laeuft weiter.');
      return { priv: null, pub: null, fp: null };
    }
  }

  /* Das Paar dieser Station — priv liegt getrennt, deshalb hier zusammengesetzt geprueft. */
  _hatEigenesPaar() {
    return hatPaar({ priv: this._priv, pub: this.daten ? this.daten.pub : null, fp: this.daten ? this.daten.fp : null });
  }

  /* DIE LISTE DER EIGENEN INSTANZEN (Befund B1). Sie muss in die Datei, und sie muss dort stehen,
   * BEVOR die Instanz zum ersten Mal in den Kontobaum geschrieben wird — sonst liest der naechste
   * Prozess einen Wert zurueck, den er nicht als seinen eigenen erkennt, und eine Einzelstation
   * ohne jeden Zwilling sperrt sich selbst von der Fern-Ansicht aus. Deshalb steht der Aufruf in
   * laden() und nicht irgendwo im Takt. Neueste zuerst, damit slice() die aeltesten verliert. */
  _instanzMerken() {
    const d = this.daten;
    const alt = Array.isArray(d.instanzen)
      ? d.instanzen.filter((x) => typeof x === 'string' && INSTANZ_FORM.test(x) && x !== this.instanz)
      : [];
    d.instanzen = [this.instanz].concat(alt).slice(0, INSTANZEN_MERKEN);
  }

  /* Konnte die Liste nicht in die Datei? Das hat eine EIGENE Folge, die die allgemeine Warnung aus
   * _speichern() nicht nennt — deshalb steht sie hier im Klartext und nicht nur als Merkfeld. */
  _instanzlisteFluechtig() {
    this.log.warn('station', 'Die Liste der eigenen Instanzen konnte nicht gespeichert werden. '
      + 'Folge: nach dem naechsten Neustart erkennt diese Station ihren eigenen Vorgaenger im '
      + 'Kennungsknoten nicht sofort wieder. Sie sperrt sich deswegen nicht aus — die '
      + 'Fern-Uebertragung nimmt Patientendaten dann aber erst mit, wenn die eigene Instanz einmal '
      + 'zurueckgelesen wurde oder die Anlauffrist abgelaufen ist.');
  }

  /* Ist dieser Wert einer von uns — jetzt oder in einem frueheren Prozess? */
  _istEigeneInstanz(f) {
    if (f === this.instanz) return true;
    const l = (this.daten && Array.isArray(this.daten.instanzen)) ? this.daten.instanzen : [];
    return l.indexOf(f) >= 0;
  }

  eigeneInstanzen() {
    return (this.daten && Array.isArray(this.daten.instanzen)) ? this.daten.instanzen.slice() : [this.instanz];
  }

  sid() {
    if (!this.daten) return null;
    return pruefeSid(this.daten.sid) ? this.daten.sid : null;
  }
  kurz() { return sidKurz(this.sid()); }
  /* Fuer jeden Pfadbau: nur diese Form, und zusaetzlich kodiert. */
  pfadTeil() { return sidPfad(this.sid()); }
  pub() { return this.daten ? (this.daten.pub || null) : null; }
  fp() { return this.daten ? (this.daten.fp || null) : null; }

  // ---------------------------------------------------------------- Saalname (N10)
  /*
   * DER GESETZTE NAME — immer durch nameSauber(), auch beim LESEN.
   *
   * Warum nicht einmal beim Laden genuegt: data/station-id.json ist eine gewoehnliche Datei auf
   * der Platte des Praxis-PCs. Wer sie im laufenden Betrieb mit dem Editor aendert (das ist die
   * Art, wie in diesem Projekt Konfiguration bisher gesetzt wurde), umgeht sonst jede Pruefung.
   * Der Preis waere ein Regex-Lauf je Sendetakt — gemessen an einem abgewiesenen 1-Hz-Koerper samt
   * Vitalwerten ist das nichts; mit dem Gedaechtnis unten ist es beim unveraenderten Wert gar
   * nichts mehr.
   *
   * Rueckgabe: der Name, oder null fuer "dieser Saal hat keinen Namen". Nie eine Ersatzzeichenkette
   * — welcher Ersatz angezeigt wird, entscheidet die Anzeige (tafel.js SPIEGEL_NAME_UNBENANNT),
   * nicht dieses Modul.
   *
   * DAS EIN-EINTRAG-GEDAECHTNIS aendert an dieser Zusage NICHTS, und genau deshalb steht es hier
   * und nicht an einem Zeitgeber: verglichen wird der ROHWERT aus der Datei. Ist er derselbe wie
   * beim letzten Mal, kann das Ergebnis kein anderes sein — ist er ein anderer (jemand hat die
   * Datei im laufenden Betrieb geaendert), wird neu geprueft. Der Grund ist der Sendetakt: seit
   * cloud.js in JEDEM Takt fragt, liefe ein von Hand eingetragener 5000-Zeichen-Wert sonst
   * sekuendlich durch drei regulaere Ausdruecke (gemessen 16 us je Aufruf gegen 0,39 us bei einem
   * gewoehnlichen Namen). Der haeufigste Fall kostet danach gar nichts mehr: eine unbenannte
   * Station hat null in der Datei, und null === null trifft das Gedaechtnis sofort.
   */
  name() {
    if (!this.daten) return null;
    const roh = this.daten.name;
    if (roh === this._nameRoh) return this._nameRein;
    const rein = nameSauber(roh);
    this._nameRoh = roh;
    this._nameRein = rein;
    return rein;
  }

  /* Hat DIESE Station einen eigenen Namen? Das ist die Frage der Erstinbetriebnahme. Sie sieht
   * ausdruecklich NICHT auf die Vorbelegung aus devices.json: die ist in jeder ausgelieferten
   * Station dieselbe und beantwortet die Frage "sind diese beiden Saele unterscheidbar?" mit
   * einem falschen Ja. */
  hatNamen() { return this.name() !== null; }

  /*
   * NAMEN SETZEN — der Schreibweg aus N10. Gerufen wird er von POST /api/station/name, also von
   * einem Menschen an diesem PC.
   *
   * Rueckgabe: der GESPEICHERTE Name (also die gekappte, entschaerfte Form) oder null, wenn aus
   * der Eingabe kein brauchbarer Name wird.
   *
   * EIN ABGELEHNTER NAME LAESST DEN BISHERIGEN STEHEN, und das ist Absicht: eine versehentlich
   * leere Eingabe oder ein verrutschter Klick darf einem laufenden OP-Saal nicht mitten in der
   * Narkose seinen Namen nehmen — er steht in diesem Moment (bei eingeschaltetem, angemeldetem
   * Fern-Live) auf jedem anderen Bildschirm des Hauses und in jeder geoeffneten Fern-Ansicht ueber
   * den Zahlen dieses Patienten. Wer den Namen wirklich loswerden will, setzt einen anderen.
   *
   * GESPEICHERT WIRD SOFORT: der Name ist die Zusage, an der die Unterscheidbarkeit der Saele
   * haengt. Geht der PC danach aus, muss er dennoch da sein. _speichern() wirft nicht; schlaegt
   * es fehl, gilt der Name fuer diesen Prozesslauf trotzdem, und _speichern() sagt im Klartext,
   * dass die Datei nicht schreibbar ist.
   */
  setzeName(roh) {
    if (!this.daten) return null;
    const neu = nameSauber(roh);
    if (neu === null) {
      this.log.warn('station', 'Der eingegebene Saalname ist unbrauchbar (leer oder nur '
        + 'Sonderzeichen) und wurde NICHT uebernommen. Der bisherige Name bleibt stehen: '
        + (this.name() === null ? '(noch keiner)' : '"' + this.name() + '"') + '.');
      return null;
    }
    const alt = this.name();
    if (neu === alt) return neu;
    this.daten.name = neu;
    this.daten.nameAm = this._jetzt();
    this._speichern();
    this.log.info('station', 'Dieser OP-Saal heisst jetzt "' + neu + '"'
      + (alt === null ? ' (vorher unbenannt).' : ' (vorher "' + alt + '").')
      /* WAS HIER FRUEHER STAND UND FALSCH WAR: "Der Name erscheint in der Tafel, in der
       * Fern-Ansicht, im Nachbarstreifen und im Kopf des Narkoseprotokolls." Auf dem Ausdruck
       * steht er bis heute nicht (ui/vetstation-live.js schreibt dort 'VetStation'), und alles
       * Uebrige gilt nur mit eingeschaltetem und angemeldetem Fern-Live. Ein Logbuch, das mehr
       * zusagt als der Code haelt, ist die Spur, der jemand im Fehlerfall folgt. */
      + ' Er geht ab dem naechsten Sendetakt in die Fern-Ansicht (Kopf dieses Saals; bei mehreren '
      + 'Saelen zusaetzlich an jedem Patienten dieses Saals in der alten Web-Ansicht) — das gilt '
      + 'nur, solange Fern-Live eingeschaltet und das Praxis-Konto angemeldet ist. Auf dem '
      + 'ausgedruckten Narkoseprotokoll steht er NICHT. Die Stationskennung ' + this.sid()
      + ' aendert sich dadurch nicht — ein umbenannter Saal bleibt derselbe Saal, und sein '
      + 'Protokoll bleibt zusammen.');
    return neu;
  }
  /* Wann der Name zuletzt gesetzt wurde (ms). Nur fuer die Anzeige im Admin-Bereich. */
  nameGesetztAm() { return (this.daten && typeof this.daten.nameAm === 'number') ? this.daten.nameAm : null; }
  /* Es gibt absichtlich KEIN priv(): der private Schluessel verlaesst dieses Objekt nicht. Wer
   * etwas beweisen muss, laesst hier unterschreiben. */
  signiere(nachricht) {
    if (!this._priv) return null;
    return signiereMit(this._priv, nachricht);
  }
  /* Die Gegenseite pruefen — statisch, weil dafuer die eigene Kennung nichts beitraegt. */
  static pruefeSignatur(pubBase64, nachricht, sigBase64) {
    return pruefeSignatur(pubBase64, nachricht, sigBase64);
  }

  // ---------------------------------------------------------------- Doppelte Kennung
  /*
   * DER EINE EINSTIEG FUER cloud.js: jeden zurueckgelesenen Wert von tafel/<sid>/meta.instanz hier
   * hereingeben — auch null, auch Muell. Die Funktion entscheidet selbst, ob das eine Entwarnung
   * ist, ein Beweis (dann meldet sie ihn ueber kollisionGemeldet() weiter) oder nichts von beidem.
   * Ein Aufrufer kann dadurch nicht die halbe Logik erwischen.
   * Rueckgabe: true = Kollision ausgeschlossen (Sperre offen), false = nicht ausgeschlossen.
   */
  kollisionAusgeschlossen(gelesenerWert) {
    /* Aus 'bewiesen' fuehrt kein automatischer Weg zurueck — Begruendung im Kopfkommentar (bei
     * laufendem Zwilling zeigt der Knoten abwechselnd beide Instanzen, die Sperre wuerde im
     * Sekundentakt klappern). Deshalb steht diese Abfrage vor jeder ENTWARNUNG.
     * Sie stand frueher ganz oben und beendete die Funktion sofort. Das war eine Zeile zu frueh:
     * cloud.js kennt nur diesen einen Einstieg, also kam nach dem Beweis nie wieder eine Meldung in
     * kollisionGemeldet() an — der Vermerk blieb bei "1x" und beim Zeitpunkt der ersten Sekunde
     * stehen, und ein ZWEITER, anderer Zwilling wurde nie festgehalten. Genau das beschreibt der
     * Kommentar bei kollisionGemeldet() (Befund B6) als den Fehler, den er behebt; ueber den echten
     * Weg war die Behebung nicht erreichbar. Gemeldet wird jetzt weiter, entwarnt nie. */
    const bewiesen = this._stand === 'bewiesen';

    if (gelesenerWert === null || gelesenerWert === undefined || gelesenerWert === '') {
      /* Leerer Knoten: es steht niemand darin, also behauptet niemand sonst diese Kennung. Das ist
       * der normale Zustand beim allerersten Start, VOR dem ersten eigenen Schreibvorgang. Schreibt
       * ein Zwilling eine Millisekunde spaeter, faellt es beim naechsten Rueckleseweg auf. */
      if (bewiesen) return false;
      this._entwarnen('der eigene Kennungsknoten ist leer');
      return true;
    }
    if (typeof gelesenerWert === 'string' && INSTANZ_FORM.test(gelesenerWert)) {
      if (this._istEigeneInstanz(gelesenerWert)) {
        /* Genau der Fall, an dem sich die alte Fassung selbst ausgesperrt hat: der Wert ist die
         * eigene Instanz — die aktuelle oder die eines frueheren eigenen Prozesses. */
        if (bewiesen) return false;
        if (gelesenerWert === this.instanz) this._eigeneGesehen = true;
        this._entwarnen(gelesenerWert === this.instanz
          ? 'im eigenen Kennungsknoten steht die eigene Instanz'
          : 'im eigenen Kennungsknoten steht die Instanz des vorherigen eigenen Starts');
        return true;
      }
      this.kollisionGemeldet(gelesenerWert);
      return false;
    }
    /* Formmuell entlastet NICHT (er koennte von einem Zwilling einer anderen Fassung stammen) und
     * beweist NICHTS (Befund B3). Der Zustand bleibt 'unbekannt'. */
    this._formMuell(gelesenerWert);
    return false;
  }

  _entwarnen(grund) {
    if (this._stand !== 'ausgeschlossen') {
      this._stand = 'ausgeschlossen';
      this.log.info('station', 'Doppelte Stationskennung ist ausgeschlossen (' + grund
        + ') — die Fern-Uebertragung nimmt Patientendaten mit.');
    }
    this._fremdWert = null; this._fremdSeit = 0; this._fremdAnzahl = 0;
  }

  /* ZWEI DROSSELN, und die zweite ist die tragende (Befund A3). Die Wertdrossel allein war leer:
   * sie vergleicht nur gegen den ZULETZT gesehenen Wert. Ein Zwilling einer Geschwisterfassung, der
   * in den Kennungsknoten etwa einen Zeitstempel statt einer Instanzkennung schreibt, aendert den
   * Wert in JEDEM Takt und lief damit an ihr vorbei — eine Warnzeile je Sekunde, dauerhaft, in
   * dasselbe Log, in dem waehrend einer Narkose die klinischen Warnungen stehen. Deshalb zusaetzlich
   * eine Zeitdrossel: hoechstens eine Zeile je WARN_TAKT_MS, unabhaengig vom Wert.
   * Zusammen heisst die Regel: NIE zweimal hintereinander derselbe Wert, und HOECHSTENS eine Zeile
   * je WARN_TAKT_MS. Verglichen wird gegen den zuletzt GEMELDETEN Wert, nicht gegen den zuletzt
   * gesehenen — sonst verschwaende ein Wert, der waehrend der Frist auftaucht und danach stehen
   * bleibt, fuer immer aus dem Log, und im Knoten stuende dauerhaft etwas, das nie jemand liest. */
  _formMuell(wert) {
    const kurz = String(wert === null || wert === undefined ? '' : wert).slice(0, 40);
    if (this._formMuellZuletzt === kurz) return;   // nicht im 1-Hz-Takt dasselbe ins Log
    const jetzt = this._jetzt();
    if (this._formMuellGemeldetAm !== null && (jetzt - this._formMuellGemeldetAm) < WARN_TAKT_MS) return;
    this._formMuellGemeldetAm = jetzt;
    this._formMuellZuletzt = kurz;
    this.log.warn('station', 'Im eigenen Kennungsknoten stand "' + kurz + '" — das ist keine '
      + 'Instanzkennung (erwartet werden 16 Hexzeichen). Der Wert wird ignoriert: er beweist keinen '
      + 'zweiten Rechner und schliesst auch keinen aus.');
  }

  /* MELDUNG EINES FREMDEN WERTES aus dem eigenen Kennungsknoten. Rueckgabe true heisst: Kollision
   * BEWIESEN und Sperre zu. Zwei Huerden, und beide sind noetig:
   *   1) FORM (Befund B3): genau 16 Hexzeichen. Nichts wird gesaeubert.
   *   2) HERKUNFT (Befund B1): der Wert darf nicht von uns selbst stammen — weder die aktuelle noch
   *      eine frueher eigene Instanz. Und selbst dann gilt er erst als Beweis, wenn er von einem
   *      LEBENDEN Schreiber kommen muss: entweder weil unsere eigene Instanz schon einmal in dem
   *      Knoten stand (dann hat uns jemand DANACH ueberschrieben), oder weil derselbe fremde Wert
   *      ueber BEWEIS_DAUER_MS in mindestens BEWEIS_MELDUNGEN Ruecklesewegen stehen bleibt, obwohl
   *      wir jeden Takt unsere eigene Instanz hineinschreiben. Ein toter Vorgaenger kann beides
   *      nicht. Diese zweite Huerde traegt auch dann, wenn data\ nicht schreibbar ist und die
   *      Instanzliste deshalb verloren geht. */
  kollisionGemeldet(fremdeInstanz) {
    if (typeof fremdeInstanz !== 'string' || !INSTANZ_FORM.test(fremdeInstanz)) {
      this._formMuell(fremdeInstanz);
      return false;
    }
    if (this._istEigeneInstanz(fremdeInstanz)) return false;

    const jetzt = this._jetzt();
    if (this._fremdWert !== fremdeInstanz) { this._fremdWert = fremdeInstanz; this._fremdSeit = jetzt; this._fremdAnzahl = 0; }
    this._fremdAnzahl += 1;

    const durchUeberschreiben = this._eigeneGesehen;
    const durchAusdauer = this._fremdAnzahl >= BEWEIS_MELDUNGEN && (jetzt - this._fremdSeit) >= BEWEIS_DAUER_MS;
    if (this._stand !== 'bewiesen' && !durchUeberschreiben && !durchAusdauer) {
      /* Noch kein Beweis, also wird der Zustand NICHT angefasst. Was das heisst, haengt davon ab,
       * wo wir stehen — und beides ist gewollt:
       *   'unbekannt'      -> die Sperre bleibt zu (die Polaritaet aus N1), es muss hier also
       *                       nichts zusaetzlich passieren.
       *   'ausgeschlossen' -> die Sperre bleibt OFFEN, bis der Beweis reift. Das Fenster ist auf
       *                       BEWEIS_DAUER_MS begrenzt und deckt sich mit der Toleranz, die schon
       *                       der Plan der Erkennung zugestanden hat ("mehr als 5 s"). Sofort zu
       *                       machen waere falsch: ein einzelner fremder Wert kann der eigene
       *                       Vorgaenger sein, und darauf hin zu sperren ist genau Befund B1. */
      return false;
    }

    const zuvorBewiesen = this._stand === 'bewiesen';
    this._stand = 'bewiesen';
    if (this.daten) {
      const alt = this.daten.kollision || { anzahl: 0 };
      this.daten.kollision = { instanz: fremdeInstanz, am: jetzt, anzahl: (alt.anzahl || 0) + 1 };
      /* Gezaehlt wird jede Meldung, GESCHRIEBEN wird sie hoechstens jede Minute. Verglichen wird
       * gegen den Zeitpunkt des letzten wirklichen SCHREIBVORGANGS (Befund B6) und nicht gegen den
       * Zeitpunkt der letzten Meldung — sonst wird bei laufendem Zwilling genau EINMAL geschrieben
       * und danach nie wieder, und Admin-Bereich und diagnose.js zeigen nach acht Stunden Konflikt
       * "1x, vor 8 Stunden". Der Zeitpunkt wird auch bei einem fehlgeschlagenen Schreibvorgang
       * gesetzt: eine nicht schreibbare Datei darf keine Warnung je Sekunde ins Log spuelen.
       * Ein NEUER Zwilling wird sofort festgehalten — "neu" heisst: in DIESEM Prozess noch nie
       * gemeldet. Frueher stand hier der Vergleich mit dem zuletzt vermerkten Wert; das genuegte,
       * solange nach dem Beweis ohnehin keine Meldung mehr ankam. Seit kollisionAusgeschlossen()
       * auch danach weitermeldet, wuerden DREI geklonte Stationen die Datei im Sekundentakt
       * beschreiben: im Knoten stuenden abwechselnd zwei fremde Instanzen, und jeder Wechsel waere
       * ein "neuer" Zwilling. _speichern() ist synchron und liegt damit im 1-Hz-Takt der Anzeige.
       * Mit der Liste wird jeder Zwilling genau einmal sofort festgehalten, danach greift der
       * Minutentakt. Die Liste ist kurz: sie beantwortet nur "schon gesehen?". */
      const neuerZwilling = this._zwillingeGesehen.indexOf(fremdeInstanz) < 0;
      if (neuerZwilling) {
        this._zwillingeGesehen = [fremdeInstanz].concat(this._zwillingeGesehen).slice(0, ZWILLINGE_MERKEN);
      }
      if (neuerZwilling || this._kollisionGeschriebenAm === null
        || (jetzt - this._kollisionGeschriebenAm) >= VERMERK_TAKT_MS) {
        this._speichern();
        this._kollisionGeschriebenAm = jetzt;
      }
    }
    if (!zuvorBewiesen) {
      this.log.error('station', 'ACHTUNG: Ein zweiter Rechner benutzt dieselbe Stationskennung '
        + this.sid() + ' (fremde Instanz ' + fremdeInstanz + '). Das passiert bei einem geklonten PC oder einem '
        + 'kopierten Windows-Abbild. Diese Station sendet ab jetzt NUR NOCH die kleine Uebersicht '
        + 'und KEINE Patientendaten mehr in die Fern-Ansicht, weil sich sonst die Werte beider '
        + 'Saele untereinandermischen. Bitte eine der beiden Stationen im Admin-Bereich umbenennen.');
    }
    return true;
  }

  kollisionBekannt() { return !!(this.daten && this.daten.kollision); }
  /* Der Vermerk im Klartext fuer Admin-Bereich und diagnose.js — nie der private Schluessel. */
  kollisionVermerk() {
    if (!this.daten || !this.daten.kollision) return null;
    const k = this.daten.kollision;
    return { instanz: k.instanz, am: k.am, anzahl: k.anzahl };
  }
  /* Fuer diagnose.js und den Admin-Bereich: welcher der drei Zustaende gilt gerade? */
  kollisionsstand() { return this._stand; }

  /* Fuer cloud.js: darf dieser Takt Patientendaten mitnehmen?
   * 'bewiesen'       -> nein, und nur umbenennen() von Hand aendert das.
   * 'ausgeschlossen' -> ja.
   * 'unbekannt'      -> nein, aber nur ANLAUF_MS lang (Anlauffrist, Begruendung im Kopfkommentar:
   *                     eine Station, deren Rueckleseweg ausfaellt, darf sich nicht selbst
   *                     dauerhaft aussperren). Danach ja, mit einer Logzeile im Klartext.
   * ES WIRD NICHT NACHGESPANNT: eine einmal erteilte Entwarnung wird nicht nach 60 s stiller
   * Ruecklesewege widerrufen. Das waere folgenlos — der Zustand waere wieder 'unbekannt', und dort
   * oeffnet die Anlauffrist ohnehin — und es waere gefaehrlich, weil es genau die Station trifft,
   * deren Leseweg gerade klemmt. */
  darfPatientendatenSchreiben() {
    if (this._stand === 'bewiesen') return false;
    if (this._stand === 'ausgeschlossen') return true;
    if ((this._jetzt() - this._startAm) < ANLAUF_MS) return false;
    if (!this._anlaufGemeldet) {
      this._anlaufGemeldet = true;
      this.log.warn('station', 'Seit dem Start ist aus dem eigenen Kennungsknoten nichts '
        + 'zurueckgelesen worden; eine doppelte Stationskennung ist damit weder bewiesen noch '
        + 'ausgeschlossen. Die Fern-Uebertragung nimmt Patientendaten trotzdem wieder mit, weil '
        + 'eine Station sonst wegen eines klemmenden Leseweges dauerhaft ohne Fern-Ansicht bliebe. '
        + 'Sobald ein Rueckleseweg antwortet, wird neu entschieden.');
    }
    return true;
  }

  /* Die Kehrseite von darfPatientendatenSchreiben() — derselbe Zustand, kein zweiter Merker, damit
   * beide nicht auseinanderlaufen koennen. Nur lesbar; wer die Sperre setzen oder aufheben will,
   * benutzt kollisionGemeldet(), kollisionAusgeschlossen() oder umbenennen(). */
  get nurTafelSchreiben() { return !this.darfPatientendatenSchreiben(); }
  /* Der Setzer nimmt nichts an und wirft auch nicht. Grund: bis zu dieser Nachbesserung war
   * nurTafelSchreiben ein beschreibbares Feld. Ein Aufrufer, der noch 'stationsid.nurTafelSchreiben
   * = true' schreibt, bekaeme ohne diesen Setzer in 'use strict' einen TypeError — und das mitten im
   * 1-Hz-Takt einer laufenden Narkose. Lieber eine Logzeile im Klartext als ein Prozessende.
   * UND DESHALB GEDROSSELT (Befund A3): derselbe Aufrufer aus der alten Bauform weist in JEDEM Takt
   * zu, also einmal je Sekunde. Ohne Drossel stuenden 3600 gleichlautende Warnzeilen je Stunde in
   * dem Log, in dem waehrend einer Narkose die klinischen Warnungen stehen — die Begruendung dieses
   * Setzers nennt den 1-Hz-Takt selbst, sie darf ihn nicht gleichzeitig ignorieren. Eine Zeile je
   * WARN_TAKT_MS genuegt: sie sagt jedes Mal dasselbe. Die Zuweisung wird IMMER verworfen, gedrosselt
   * wird nur das Reden darueber. */
  set nurTafelSchreiben(_wert) {
    const jetzt = this._jetzt();
    if (this._setzerGemeldetAm !== null && (jetzt - this._setzerGemeldetAm) < WARN_TAKT_MS) return;
    this._setzerGemeldetAm = jetzt;
    this.log.warn('station', 'nurTafelSchreiben laesst sich nicht von aussen setzen — der Zustand '
      + 'ergibt sich aus kollisionGemeldet() / kollisionAusgeschlossen() / umbenennen(). Die '
      + 'Zuweisung wurde ignoriert; die Sperre steht weiter auf "' + this._stand + '".');
  }

  /* UMBENENNEN VON HAND — der einzige Weg aus einer Doppelkennung. Nur ein Mensch im
   * Admin-Bereich ruft das auf, nie das Programm selbst: die Kennung ist der Name des Saals in
   * der Fern-Ansicht und im unveraenderlichen Fern-Protokoll. Eine Umbenennung mitten in einer
   * Narkose laesst den Saal verschwinden und einen neuen, leeren erscheinen — das darf niemals
   * nebenbei passieren.
   * neueSid = null bedeutet "eine frische Kennung wuerfeln"; ein Suffix wird nicht angehaengt,
   * damit die Formatsperre bei der zweiten Umbenennung nicht reisst.
   * Das Schluesselpaar BLEIBT: es beweist die Maschine, nicht den Namen.
   *
   * WAS EIN KENNUNGSWECHSEL IN DER DATENBANK WIRKLICH ANRICHTET — GEMESSEN am 30.07.2026 mit den
   * echten Modulen (Stationsid + CloudPublicher._pfade/_delta), nicht vermutet. Hier stand vorher
   * "geloescht wird nichts, damit kein Narkoseprotokoll verloren geht", und dieselbe Zusage stand
   * in beiden Rueckfragen des Admin-Bereichs. Sie war falsch, und sie stand an der Stelle, an der
   * ein Tierarzt sie glaubt, waehrend er auf den Knopf drueckt:
   *
   *   WEG:     die LIVE-Werte des alten Saals. cloud.js merkt sich die zuletzt geschriebenen
   *            Pfade samt Kennung; nach dem Wechsel steht kein alter Pfad mehr unter der neuen
   *            Wurzel, und der naechste Takt setzt jeden davon auf null (nachgemessen: aus
   *            saele/<alt>/patients/p1 gingen patientId, hr, spo2 und ts als null raus; im
   *            Kompatibilitaetsspiegel faellt der ganze Schluessel s<altKurz>__p1 weg).
   *            DAS IST SO GEWOLLT und deshalb hier nicht "repariert": diese Werte laufen unter
   *            der neuen Kennung unveraendert weiter. Bleiben sie zusaetzlich stehen, zeigt die
   *            Fern-Ansicht denselben Patienten zweimal — einmal lebendig und einmal mit
   *            eingefrorenen Vitalwerten. Genau diese Karteileiche ist der Schaden aus N7.
   *   BLEIBT:  das NARKOSEPROTOKOLL. Es wird nie geloescht und nie ueberschrieben (die Regel macht
   *            jede Zeile unveraenderlich). Es wird aber GETEILT: Zeilen bis zum Wechsel liegen
   *            unter saele/<alt>/protokoll, spaetere unter saele/<neu>/protokoll — nachgemessen an
   *            _protokollZiele(). Der Ausdruck auf DIESEM PC bleibt davon unberuehrt und
   *            vollstaendig; er kommt aus der Registry und nicht aus der Datenbank.
   *   BLEIBT:  die Kachel des alten Saals (tafel/<alt>). Sie wird von niemandem geloescht, friert
   *            mit ihren letzten Werten ein, gilt nach einer Minute als "offline"
   *            (tafel.STUFE_OFFLINE_MS) und faellt nach 12 Stunden aus der Saalliste
   *            (tafel.STUFE_WEG_MS).
   *
   * WER DAS JE AENDERT (z.B. cloud.js beim Kennungswechsel sein Gedaechtnis zuruecksetzen laesst,
   * damit der alte Zweig unberuehrt ausaltert), MUSS DIE TEXTE MITAENDERN: die zwei Rueckfragen in
   * ui/views/admin.js wireSaal, den Absatz darunter und diesen Kommentar. tools/saalname-test.js
   * misst genau diese Folge und wird dann rot — das ist die Absicht. */
  umbenennen(neueSid) {
    if (!this.daten) return null;
    const alt = this.sid();
    const neu = (neueSid === null || neueSid === undefined) ? frischeSid() : String(neueSid);
    if (!pruefeSid(neu)) {
      this.log.warn('station', 'Umbenennung abgelehnt: "' + neu + '" hat nicht die Form '
        + 'st + 12 Hexzeichen. Ein anderer Wert koennte einen fremden Pfad in der Datenbank treffen.');
      return null;
    }
    if (neu === alt) return alt;

    this.daten.umbenanntVon = (this.daten.umbenanntVon || []).concat([alt]).slice(-5);
    this.daten.umbenanntAm = this._jetzt();
    this.daten.sid = neu;
    /* Der Konflikt ist mit dem neuen Namen erledigt — Sperre und Vermerk fallen weg. Der NEUE
     * Kennungsknoten ist unbeschrieben, also ist die Kollision dort ausgeschlossen; deshalb
     * 'ausgeschlossen' und nicht 'unbekannt', denn der Mensch, der gerade umbenannt hat, soll seine
     * Patientendaten sofort und nicht erst nach der Anlauffrist wiedersehen.
     * _eigeneGesehen faellt auf false: unter dem neuen Namen hat noch nie eine eigene Instanz in
     * dem Knoten gestanden, und ein Beweis darf sich nicht auf eine Beobachtung am alten Namen
     * stuetzen. Steht der Zwilling noch, meldet sich die Kollision dort binnen Sekunden erneut,
     * dann aber fuer die andere Station. */
    this.daten.kollision = null;
    this._kollisionGeschriebenAm = null;
    this._eigeneGesehen = false;
    this._stand = 'ausgeschlossen';
    this._fremdWert = null; this._fremdSeit = 0; this._fremdAnzahl = 0;
    /* Auch die Liste der schon gemeldeten Zwillinge faellt weg: taucht derselbe Rechner unter dem
     * NEUEN Namen wieder auf, ist das eine neue Nachricht und gehoert sofort in die Datei. */
    this._zwillingeGesehen = [];
    this._speichern();
    this.log.warn('station', 'Diese Station heisst jetzt ' + neu + ' (vorher ' + alt + '). '
      + 'Ab dem naechsten Sendetakt wird alles unter der neuen Kennung geschrieben. Die LIVE-Werte '
      + 'des alten Saals werden dabei entfernt — sie laufen unter der neuen Kennung weiter, und '
      + 'zweimal derselbe Patient (einmal lebendig, einmal eingefroren) waere die gefaehrlichere '
      + 'Anzeige. Das Narkoseprotokoll bleibt vollstaendig erhalten, wird aber an dieser Stelle '
      + 'geteilt: die bisherigen Zeilen liegen unter ' + alt + ', die weiteren unter ' + neu
      + '. Die Kachel des alten Saals bleibt stehen und altert aus (nach einer Minute "offline", '
      + 'nach 12 Stunden nicht mehr in der Saalliste). Der Ausdruck auf diesem PC ist davon nicht '
      + 'betroffen.');
    return neu;
  }
  umbenanntVon() { return (this.daten && this.daten.umbenanntVon) ? this.daten.umbenanntVon.slice() : []; }

  /* Schreiben ueber eine Zwischendatei und umbenennen. Ein Stromausfall mitten im Schreiben wuerde
   * sonst eine halbe Datei hinterlassen — und die Station wuerde beim naechsten Start ihre Kennung
   * neu ableiten und ihren privaten Schluessel verlieren (womit jeder gepinnte Nachbar sie fuer
   * einen Fremden haelt).
   * Der private Teil wird hier — und NUR hier — wieder zu den Daten gelegt: in der Datei auf diesem
   * PC muss er stehen, sonst ueberlebt er keinen Neustart; in this.daten darf er nicht stehen
   * (Befund B4). Rueckgabe: hat es geklappt? laden() haengt daran die Klartextfolge fuer die
   * Instanzliste (_instanzlisteFluechtig). */
  _speichern() {
    try {
      const ordner = path.dirname(this.datei);
      if (!fs.existsSync(ordner)) fs.mkdirSync(ordner, { recursive: true });
      const tmp = this.datei + '.tmp';
      const inhalt = Object.assign({}, this.daten, { priv: this._priv || null });
      fs.writeFileSync(tmp, JSON.stringify(inhalt, null, 2), 'utf8');
      fs.renameSync(tmp, this.datei);
      return true;
    } catch (e) {
      this.log.warn('station', 'Stationskennung konnte nicht gespeichert werden (' + e.message
        + '). Sie wird bei jedem Start neu abgeleitet — das ist in Ordnung, solange die '
        + 'Windows-Geraete-ID lesbar bleibt; der Nachbarweg braucht dann aber jedes Mal eine '
        + 'neue Bestaetigung des Fingerabdrucks.');
      return false;
    }
  }
  /* Beiseitegelegt heisst station-id.ungueltig.json — so nennt sie der Plan (Befund B9). Umbenannt
   * statt geloescht, weil in der unbrauchbaren Datei der private Schluessel und moeglicherweise die
   * alte Kennung stehen; beides kann ein Mensch noch brauchen. Lag dort schon eine
   * station-id.ungueltig.json, wird sie dabei ueberschrieben — aufbewahrt wird immer nur die
   * ZULETZT beiseitegelegte. */
  _ungueltigName() { return this.datei.replace(/\.json$/i, '') + '.ungueltig.json'; }
  _beiseite() {
    try { if (fs.existsSync(this.datei)) fs.renameSync(this.datei, this._ungueltigName()); }
    catch (e) { /* dann eben nicht — ueberschrieben wird sie ohnehin */ }
  }
}

module.exports = {
  Stationsid,
  // reine Funktionen, getrennt pruefbar
  SID_FORM, SID_MAX, INSTANZ_FORM, ABLEITUNG_V,
  ANLAUF_MS, BEWEIS_DAUER_MS, BEWEIS_MELDUNGEN, VERMERK_TAKT_MS, INSTANZEN_MERKEN,
  WARN_TAKT_MS, ZEIT_MAX_MS, ZWILLINGE_MERKEN,
  NAME_MAX, NAME_VORLAGE, nameSauber, stationsName,
  pruefeSid, sidAus, hostHash, sidKurz, frischeSid, sidPfad, isoZeit,
  ed25519Paar, fingerabdruck, signiereMit, pruefeSignatur,
  istBrauchbar, hatPaar,
  machineGuid, ersteEchteMac,
};
