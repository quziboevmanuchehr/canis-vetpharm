# Plan: mehrere OP-Saele im selben Praxis-Konto

> Erzeugt am 30.07.2026 aus dem geprueften Entwurf (18 Agenten: 4 Leser, 3 Entwuerfe,
> 6 Gegenpruefungen, 1 Nachpruefung, 2 Angriffe auf den fertigen Plan, 1 Freigabe).
> Urteil der Freigabe: **umsetzbar-nach-nachbesserung**. Diese Datei ist die Vorgabe fuer die Umsetzung.

## Entscheidungen des Nutzers (verbindlich)

- Saalname: die Station FRAGT beim ersten Start danach.
- Kompatibilitaetsspiegel fuer die ausgelieferte Web-App: DAUERHAFT an.
- Nachbar-Port: lauscht auf ALLEN nicht virtuellen Karten (Kabel + WLAN).
- Ausbau: mehr Saele, aber im Freikontingent bleiben -> gedrosselter Takt, LAN als Hauptweg im Haus.

## Vor allem anderen

1. QUELLSTAND FESTSCHREIBEN. Der Plan ist gegen einen Stand geschrieben, der sich seither ZWEIMAL bewegt hat, in beide Richtungen. (a) Commit 4b32fad 'Stationskennung: jeder Praxis-PC bekommt einen eigenen Namen im Praxis-Konto' hat bridge/src/stationsid.js (15075 Byte) und tools/stationsid-test.js (10414 Byte) bereits angelegt — mit eindeutigMachen() ab Zeile 228 (automatische Selbstumbenennung) und lanGeheim = crypto.randomBytes(32) in Zeile 87/204 (gemeinsames Geheimnis), also GENAU den zwei Bauformen, die der Plan ausdruecklich verwirft. Der Plan nennt beide Dateien 'NEU'. (b) bridge/src/cloud.js (11:31) und registry.js (11:32) tragen unfestgeschriebene Aenderungen, die Schritt 7 BEREITS VOLLSTAENDIG umsetzen: _protokollSchreiben als eigener Weg, protokollFehlerZahl als eigenes Konto, prozessStart-Sprung in cloud.js:661, und der Kommentar bei Zeile 538 sagt woertlich 'HIER STAND FRUEHER Object.assign(body, protPfade) — und genau das war der Fehler'. Der als 'bestaetigt' vorgelegte Altfehler ist also behoben. Vor der ersten Zeile Code: je Schritt feststellen, was schon da ist. Sonst wird Vorhandenes doppelt gebaut oder Verworfenes still ausgeliefert.

2. ENTSCHEIDUNG stationsid.js. tools/alle-tests.js:24 fuehrt stationsid-test.js als PFLICHTTEST. Der Test schreibt lanGeheim als Pflichtfeld und eindeutigMachen positiv fest. Wer Schritt 9 nach Plan baut, macht node tools/alle-tests.js rot, und alle-tests.js:91 sagt dann 'Es sollte KEIN Setup gebaut werden, solange das so ist.' Wer den Test gruen laesst, liefert das verworfene Modell aus. Beides ist inakzeptabel — die Entscheidung gehoert vor jede Umsetzung, nicht in sie hinein. Zusatzbefund: stationsid.js wird von KEINEM Produktivmodul per require geladen und fehlt in dist/VetStation/bridge/src/ — es ist derzeit toter Code, der Umbau ist also billig.

3. REIHENFOLGE DREHEN: Fehlerentkopplung (Plan-Schritt 6) MUSS vor die Regelveroeffentlichung (Plan-Schritt 1). cloud.js:273 lautet _istKonfigFehler = /HTTP 40[01349]|ENOTFOUND|EAI_AGAIN|URL ungueltig|PERMISSION_DENIED/i, und cloud.js:1021-1022 schaltet nach drei Treffern _selbstAbschalten. Eine Regelablehnung antwortet als 'HTTP 401: Permission denied' und erfuellt diesen Ausdruck zweifach. Werden die strengeren Regeln zuerst veroeffentlicht, nimmt eine einzige Regelabweichung binnen einer Minute ALLEN ausgelieferten Praxen die Fern-Uebertragung, jede erst durch einen Vor-Ort-Neustart zurueckholbar. Der Plan ordnet die Entkopplung nach der Veroeffentlichung ein — das ist die gefaehrlichste Einzelstelle des ganzen Ablaufs.

4. TARIF ENTSCHEIDEN (offene Frage 1) vor Schritt 15. Der Budgetwaechter und der Lesetakt werden danach gebaut; ohne Entscheidung ist cloud.budgetMbMonat ein geratener Wert, und die Frage entscheidet mit, ob der Nachbarstreifen ab 4 Saelen ueberhaupt laufen darf.

5. SAALNAME-SCHREIBWEG entscheiden (offene Frage 7). bridge/config/devices.json existiert NICHT, Install-VetStation.ps1:92 schliesst sie per robocopy /XF ausdruecklich aus, und im ganzen Quellcode gibt es keine Stelle, die sie schreibt. Damit heisst jede ausgelieferte Station 'Praxis OP 1', und der Umbenennungsknopf — laut Plan der EINZIGE Ausweg aus einer doppelten Stationskennung — ist nicht baubar. Ohne diese Entscheidung ist die Zusage 'Saele bleiben unterscheidbar' nicht einloesbar.

## Nachbesserungen, die die Freigabe verlangt

### N1 Kollisionserkennung auf das instanz-Feld umstellen und probe ersatzlos streichen. Zusaetzlich: sid beim ERSTEN Lauf aus crypto.randomBytes, MachineGuid nur als Rueckfall wenn die Datei fehlt. Und eine harte Sperre: solange eine Kollision nicht ausgeschlossen ist, nur tafel/<sid>/meta schreiben, keine Patientendaten.

**Warum:** Das geplante Kriterium ('ueber mehr als 5 s FORTLAUFEND ein fremder probe-Wert') ist strukturell unerfuellbar: beide Stationen schreiben selbst jede Sekunde, also liefert jeder Lesevorgang abwechselnd den eigenen und den fremden Wert. Die zweite Bedingung prueft verbund/lan/<sid>.ips, einen Knoten, den es in Stufe 1 nicht gibt. Folge: zwei Stationen mit gleicher sid mischen Feld fuer Feld unter saele/<sid>/patients/<key> — bei zwei 22-kg-Hunden beide unter sw_hund_22 — und NICHTS meldet einen Konflikt. Das ist genau der Zustand, den der Umbau beseitigen soll. instanz traegt jeder fremde Schreibvorgang ohnehin, es braucht kein 'fortlaufend'. Und die Ableitung aus MachineGuid macht einen Plattenklon per Konstruktion zur Doppelkennung.

**Wo:** bridge/src/stationsid.js, bridge/src/cloud.js

### N2 bridge/src/stationsid.js als UMBAU einer vorhandenen Datei fuehren, nicht als Neuanlage: lanGeheim/lanGeheimVor/lanGeheimTs/neuesGeheim/brauchtRotation/vorgaengerGueltig/vorbereiteterWechsel/bestaetigeWechsel und eindeutigMachen/sidMitSuffix/warDoppelt entfernen, priv/pub/fp (Ed25519) ergaenzen, istBrauchbar() umschreiben, Kopfkommentar Zeile 23-24 und 28-29 korrigieren. Migration fuer bereits erzeugte data/station-id.json: sid bleibt, Ed25519-Paar wird einmalig nachgezogen. tools/stationsid-test.js umschreiben und die Pruefungen zu eindeutigMachen und lanGeheim mit Begruendung streichen.

**Warum:** Beide Dateien existieren (Commit 4b32fad) und setzen die zwei Bauformen um, die der Plan verwirft. istBrauchbar() in Zeile 108-113 verwirft jeden Datensatz OHNE lanGeheim — ein nach Plan erzeugter Datensatz wuerde also bei jedem Start als unbrauchbar beiseitegelegt und die Kennung neu abgeleitet. Der Kopfkommentar nennt als Ablageort tafel/<sid>/lan.ips und sagt, das Geheimnis liege 'nur im Praxis-Konto' — also in dem Knoten, den laut Plan JEDE Web-Ansicht per Dauerabonnement in den Browser laedt. Ohne diesen Umbau sind zwei Sicherheitsentscheidungen des Plans unbemerkt aufgehoben.

**Wo:** bridge/src/stationsid.js, tools/stationsid-test.js

### N3 Die sv-Regel tolerant fassen: "newData.val() <= now && newData.val() > now - 60000" statt "newData.val() === now". Und die Regeln nicht in einem Schritt umstellen, sondern zuerst NUR die neuen Teilbaeume (tafel/saele/verbund) ergaenzen, die Verscharfungen an meta und protokoll erst nach der Messung.

**Warum:** Schritt 1 veroeffentlicht vor jeder Stationsaenderung und gilt sofort fuer alle ausgelieferten 1.0.3-Stationen, die meta.sv in JEDEM Schreibvorgang als {'.sv':'timestamp'} schreiben. Der neue 1-Hz-Koerper enthaelt ZWEI Serverplatzhalter in einem Mehrpfad-PATCH; ob beide auf denselben Wert aufgeloest werden, den 'now' in der Regelauswertung sieht, steht nicht unter den vier Fragen von Schritt 0. Die Pruefung von Schritt 1 prueft nur die Gegenrichtung, und der Regel-Simulator kann {'.sv':'timestamp'} gar nicht aufloesen — der Positivfall ist dort nicht pruefbar. Gilt die Gleichheit nicht exakt, lehnt die Datenbank ab dem Moment der Veroeffentlichung jeden Schreibvorgang jeder Praxis ab. Die tolerante Fassung schliesst 'toter Saal sieht fuer immer frisch aus' genauso, ohne auf millisekundengenaue Gleichheit zu wetten. Hinweis aus dem Bestand: die heutige Regel "sv": newData.isNumber() geht durch, der Platzhalter wird also vor der Validierung aufgeloest — das stuetzt die Richtung, beweist die Gleichheit aber nicht.

**Wo:** installer/firebase-rtdb-rules.json, tools/regel-messung.js

### N4 F1 jederzeit wieder betretbar machen: sobald ein fremder Schreibvorgang auf der flachen Ebene bewiesen ist, sofort nach F1; erst 60 s Stille fuehren zurueck nach F2. Der Latch darf nur das Flattern innerhalb dieser 60 s verhindern, nicht den Zustandswechsel. In tools/altbestand-test.js den Ablauf 'neue Station laeuft, DANN startet die 1.0.3' pruefen.

**Warum:** Der Plan sagt 'Der Wechsel F0->F1/F2 ist einmalig je Prozesslauf', es gibt also keinen Uebergang F2->F1. cloud.js:531-532 belegt: das Vollbild einer 1.0.3 ist { meta: ..., patients: snapshot.patients } und ERSETZT beide Knoten vollstaendig. Eine spaeter eingeschaltete 1.0.3 loescht damit alle s<sid6>__-Spiegelschluessel — alle 30 s erneut (vollbildMs, cloud.js:170) — und die neuen Stationen bemerken es nicht, weil ihr Delta-Gedaechtnis nur gegen den eigenen letzten Stand vergleicht. Der Plan behauptet fuer genau diesen Fall das Gegenteil ('vollstaendig, richtig, ohne Flackern'). Der geplante Test prueft nur die umgekehrte Startreihenfolge.

**Wo:** bridge/src/cloud.js, tools/altbestand-test.js

### N5 meta/q durch meta/qs/<sid> = <ts> ersetzen (ein Kind je Station) und die Fassungsunterscheidung allein an der Anwesenheit von qs/<sid> festmachen, nicht an meta/v. Ueberall 'FRISCHE Tafeleintraege' (meta.sv juenger als 60 s) zaehlen, an allen Stellen, an denen der Zustand entschieden wird.

**Warum:** Ein gemeinsames Einzelfeld kann nicht anzeigen, WER geschrieben hat: laeuft Station A in F2 und schreibt jede Sekunde meta/q, sind fuer die spaeter startende Station B beide F1-Kriterien ('frischer ts und KEIN q') nicht erfuellt — B spiegelt, obwohl eine 1.0.3 im Konto schreibt. Derselbe Kontobaum fuehrt je nach Startzeitpunkt zu F1 oder F2. Zusaetzlich laesst der Plan meta/v konstant bei 3 (cloud.js:81 FORMAT_V = 3, benutzt in Zeile 888), das Merkmal 'v <= 3 ohne q' unterscheidet also nichts. Und 'genau EIN Tafeleintrag' ist nicht definiert: ein ausgemusterter PC hinterlaesst seinen Knoten (geloescht wird nur per Admin-Knopf), womit eine Einzelplatzpraxis dauerhaft in F2-multi haengt und Kurven und Verlauf in der alten Ansicht verliert.

**Wo:** bridge/src/cloud.js

### N6 Den 1-Hz-Tafelkoerper VOR der Sparregel behandeln: er IST der Herzschlag und wird geschrieben, sobald tafelTaktMs abgelaufen ist, unabhaengig vom saele-Delta. Sparregel auf die neue Lage umstellen (keine Patienten in keinem Saal -> Tafeltakt 5 s). In tools/fern-durchsatz-test.js den Ruhezustand (kein Geraet, kein Patient, 60 s) als eigene Messgroesse aufnehmen.

**Warum:** cloud.js:502 lautet nurHerzschlag = keys.every(k => k === 'meta/ts') — die Schutzregel ist an diese LITERALE Zeichenkette gebunden. Der Plan nimmt meta/ts aus dem 200-ms-Delta (flache Ebene nur 1x/s, in F1 nie) und setzt damit die Schutzregel still ausser Kraft: zwischen zwei Geraeteframes ist keys.length === 0, der Schreibvorgang entfaellt, und tafel/<sid>/meta.sv steht bis zu 30 s still, weil das LifeVet ab Werk nur alle ~30 s sendet. Der Leser meldet dann nach 12 s gelb und nach 60 s 'offline' fuer einen gesunden Saal und ERSETZT die Zahlen durch 'Stand vor X min'. Der heutige Bestand hat die Sparregel bereits als herzschlagMs=2000 geloest (cloud.js:204) — dieser Mechanismus darf nicht verloren gehen.

**Wo:** bridge/src/cloud.js, tools/fern-durchsatz-test.js

### N7 Das Sicherheits-Vollbild als PUT auf genau saele/<sid>/patients.json und PUT auf tafel/<sid>/uebersicht.json schreiben. bridge/data/fern-keys.json entfaellt ersatzlos.

**Warum:** Die geplante Schluesselliste deckt nur die saele-Ebene; fuer tafel/<sid>/uebersicht gibt es keine Muellabfuhr. Wechselt der patientKey (Ersatzschluessel sw_hund_22 -> id_12345, sobald die Patienten-ID nachgetragen wird) oder startet die Station neu, setzt niemand die alte Kachel auf null. Der Leser urteilt ueber die Frische am SAAL (meta.sv), und altMs ist im alten Objekt eingefroren — die Karteileiche erscheint dauerhaft als 1,2 s alt, mit plausiblen unveraenderlichen Vitalwerten, in der Tafel jeder Web-Ansicht und im Nachbarstreifen. Unter saele/<sid>/ sind patients und protokoll GESCHWISTER, ein PUT trifft das Protokoll also nicht; die Schluesselliste war nur wegen der alten Nachbarschaft noetig. Nebengewinn: der Plan fuehrt bridge/data/fern-keys.json in einer Dateiliste wie eine Quelldatei, obwohl data/ von Auslieferung und Update ausgeschlossen ist.

**Wo:** bridge/src/cloud.js

### N8 Im Spiegel pri und top NICHT mitschreiben. Saalnamen zusaetzlich in patientId spiegeln.

**Warum:** Der Spiegel liefert der AUSGELIEFERTEN Web-App erstmals eine Mehr-Saal-Patientenliste. Endet in OP 1 die Narkose, greift index.html:3395-3398 und waehlt den Patienten mit dem hoechsten pri — ueber alle Saele hinweg. applyLive setzt state.monMode='ist' bedingungslos und uebernimmt in sv() nur nicht-leere Werte, iv.nibp faellt auf den alten Wert zurueck. Hat OP 2 keine Kapnografie und keine Temperatursonde, stehen EtCO2, Temp, AF und NIBP des Tiers aus OP 1 unter dem Namen des Tiers in OP 2, ausgewiesen als gemessene Istwerte, und gehen in Dosis- und Beatmungsempfehlung ein. Denselben Mechanismus bewertet der Plan fuer die NEUE App als toedlich und ruestet dort ein Ruecksetzen nach — fuer die alte App fehlt der Punkt. Ohne pri bleibt die Auswahl bei keys[0] und springt nicht quer durch die Praxis.

**Wo:** bridge/src/cloud.js

### N9 Eine gemeinsame Kappungsfunktion in cloud.js (jeder String <= 200 Zeichen, jedes Objekt <= 40 Felder, jede Liste <= 80 Eintraege) auf JEDEN Snapshotwert anwenden, nicht nur auf die Tafel. Dazu eine Auffangregel "$sonst" unter saele/$station/patients/$key und ein Test, der die Kappungen im Code gegen die Grenzen in der Regeldatei prueft.

**Warum:** Der neue Regelsatz zieht Laengengrenzen nur fuer die kleine Tafel; saele/$station/patients/$key hat ausser kurven/$kanal/b64 KEINE Blattregel, und die flache Ebene behaelt "patients": {".validate": true}. cloud.js kappt heute nur roh[].label auf 60 und Kurvennamen auf 40 — vitals, ventParams und akte gehen ungeprueft durch. probe.js bindet die Datenports ohne Host-Argument und nimmt jede Gegenstelle an, die Firewallregeln stehen auf -Profile Any. Ein Notebook im Gast-WLAN kann damit einen sehr langen Text in den Zweig mit der GROESSTEN Datenmenge setzen, den jede Web-Ansicht und jede andere Station bei jedem Delta erneut laedt. Punkt 4 der Regelaenderung wollte genau diese Klasse schliessen und laesst sie fuer den groessten Zweig offen. Zusaetzlich: die Ed25519-Signatur aus Stufe 2 ist base64 88 Zeichen und reisst die geplante $sonst-Grenze von 64 in tafel/meta — sie gehoert namentlich mit eigener Grenze schon in Schritt 1, sonst scheitert der atomare 1-Hz-Koerper samt Vitalwerten.

**Wo:** bridge/src/cloud.js, installer/firebase-rtdb-rules.json, tools/regeln-test.js

### N10 Einen Schreibweg fuer den Saalnamen bauen: POST /api/station/name und POST /api/station/kennung/neu ueber jsonPrivat + istLokal + Einmal-Kennwort, die nach data/station-id.json schreiben (nicht nach devices.json). cfg.station nur noch als Vorbelegung lesen. Genau EINE Funktion stationsName(), die von Tafel, flachem Spiegel, PDF, Firestore-Verlauf und Admin-Bereich benutzt wird. Erstinbetriebnahme, die den Namen erzwingt.

**Warum:** bridge/config/devices.json existiert nicht, Install-VetStation.ps1:92 schliesst sie per /XF aus, und keine Stelle im Quellcode schreibt sie. Alle Stationen heissen also 'Praxis OP 1'. Der Plan haengt an diesem Namen: gespiegelter patientName, Druckkopf, Firestore-Verlauf, jeder rechnende Bereich der Web-App. Bei gleichem Namen bleibt nur '· <sid6> anhaengen', und auf dem Narkoseprotokoll steht fuer beide Tiere derselbe Saal. Der Umbenennungsknopf — laut Plan der einzige Ausweg aus einer doppelten Kennung — ist ohne Schreibweg nicht baubar. Zusaetzlich hat der Plan zwei Namensquellen fuer denselben Saal (Tafel: os.hostname() beim Vorlagewert; flacher Spiegel: cfg.station), womit derselbe OP-Saal in Tafel, alter Fern-Ansicht und auf Papier verschieden heisst.

**Wo:** bridge/src/server.js, bridge/src/stationsid.js, ui/index.html, docs/MEHRERE-SAELE.md

### N11 Version 1.1.0 gleichzeitig in allen vier Stellen setzen (package.json, bridge/package.json, updater/version.json app, installer/vetstation-setup.iss #define AppVersion) und einen Schritt 'Manifest veroeffentlichen' mit zipUrl + sha256 aufnehmen. FORMAT_V bleibt 3 fuer die flache Ebene, neue Konstante TAFEL_V = 4 fuer tafel/<sid>/meta.v.

**Warum:** Der Plan schreibt bv:'1.1.0' und tafel-meta v:4, bumpt aber keine Versionsstelle — geprueft: alle vier stehen auf 1.0.3. Bleibt das so und wird das Manifest nicht veroeffentlicht, meldet jede Station im Feld 'kein Update gefunden'. Dann gehen Regeln und Web-App live, die Stationen bleiben 1.0.3, und weil eine laufende 1.0.3 laut Plan den Spiegel aller neuen Stationen abschaltet, zeigt die alte Fern-Ansicht dauerhaft nur den einen alten Saal — ohne dass jemand ein Update angeboten bekommt. Randbedingung 4 ist damit auf der Auslieferseite nicht erfuellt. tools/version-test.js erzwingt die Gleichheit aller vier Stellen, ein halber Bump macht die Testreihe rot und alle-tests.js:90-91 verbietet dann den Setup-Bau. Hinweis: tools/cloud-test.js prueft snap.meta.v === 3 — dieser Test muss ausdruecklich auf die FLACHE Ebene bezogen bleiben.

**Wo:** package.json, bridge/package.json, updater/version.json, installer/vetstation-setup.iss, bridge/src/cloud.js

### N12 Schritt 7 auf 'Restluecke schliessen' umschreiben: die Behandlung 'HTTP 401/403 gilt als stand-schon-da' auf Antworten einengen, die PERMISSION_DENIED bzw. 'Permission denied' im Rumpf tragen; Protokollzeilen einzeln schreiben (PUT je Pfad, hoechstens N je Takt) statt als atomarer Mehrpfad-Koerper; in registry.protokollSchritt einen belegten ts um 1 ms weiterschieben.

**Warum:** Schritt 7 ist im Arbeitsstand BEREITS umgesetzt (eigener Weg, eigenes Fehlerkonto, prozessStart-Sprung in cloud.js:661) — als Neubau wuerde er Vorhandenes zerstoeren. Offen bleiben zwei Dinge: cloud.js:593 behandelt HTTP 401/403 pauschal als 'stand schon da', womit ein echter Anmeldefehler oder eine Zeitueberschreitung Protokollzeilen ENDGUELTIG verliert, da die Zeilen per Regel unveraenderlich sind. Und in F2-solo enthaelt der Koerper zwei Pfade je Zeile; RTDB nennt den abgelehnten Pfad nicht, ein Uhrensprung beim Hochfahren (NTP nach leerer CMOS-Batterie) erzeugt kollidierende ts, und der atomare PATCH nimmt die noch nicht vorhandene saele-Zeile mit ab. Einzelne Schreibvorgaenge machen jede Antwort eindeutig zuordenbar.

**Wo:** bridge/src/cloud.js, bridge/src/registry.js

### N13 Einen zweiten Tafelzweig tafel/<sid>/geraete/<deviceId> aus registry.getDevices() festlegen (Modell, Rolle, status, ip, port, transport, altMs aus seitMs, taktMs, werteAnzahl, patientKey), Regelblock mit Laengengrenzen ergaenzen, geraeteSatz() in tafel.js plus Test, und je Saal eine ausklappbare Geraetezeile in Nachbarstreifen und Web-App-Tafelkarte — reine Ansicht. Doppelempfangserkennung auf die vollstaendige Geraeteliste statt auf dv umstellen.

**Warum:** Der Auftrag verlangt woertlich und zweimal im selben Satz 'Alle Geraete, die in diesem Konto angeschlossen sind, in beiden oder mehreren OP-Saelen sehen koennen'. Die geplante Tafel traegt PATIENTEN: sie entsteht aus getPatients(), und registry.js:553 filtert mit .filter(r => this._status(r, now) !== 'offline') jedes Geraet heraus, das seit 90 s stumm ist (STANDBY_MS, registry.js:17). Ein abgerissener Kapnograph senkt nur dev von 2 auf 1 und verschwindet lautlos; ein eingeschalteter Monitor ohne Patienten faellt nach 90 s ganz heraus. Der Tierarzt in Saal 1 kann nicht unterscheiden zwischen 'in Saal 2 haengt kein Kapnograph' und 'in Saal 2 ist der Kapnograph abgerissen' — obwohl getDevices() (registry.js:509, 527) genau diese Angaben lokal liefert und der Koppel-Dialog sie zeigt. Der haeufigste Praxisfehler ist fern nicht diagnostizierbar.

**Wo:** bridge/src/tafel.js, bridge/src/cloud.js, installer/firebase-rtdb-rules.json, ui/vetstation-nachbarn.js, canis-anaesthesie/index.html

### N14 Bei EADDRINUSE nicht sofort beenden: zuerst http://127.0.0.1:<port>/healthz abfragen. Antwortet dort eine VetStation, ist es ein echter Doppelstart -> exit(1) mit Klartext. Antwortet niemand, dreimal mit 2 s Abstand erneut binden. Einzelinstanz-Sperre zusaetzlich ueber data/station.lock mit PID.

**Warum:** server.js:162 protokolliert heute nur (bestaetigt: httpServer.on('error', e => logger.error(...))), der Prozess laeuft weiter, empfaengt Geraetedaten, fuehrt das Protokoll und sendet fern — nur die Oberflaeche fehlt. Das geplante process.exit(1) macht daraus einen Totalausfall: startet NEUSTART.bat neu, waehrend der alte Prozess noch beendet wird, beendet sich der neue sofort, und der Autostart haengt laut vetstation-setup.iss:65-66 am Anmeldevorgang — auf einem durchlaufenden Kiosk-PC startet danach nichts mehr. Moeglicherweise mitten in einer Narkose. Das verletzt Randbedingung 6 haerter als der Zustand, den die Aenderung verhindern soll. Der Port sagt ohnehin nicht, WER ihn haelt.

**Wo:** bridge/src/server.js, bridge/src/index.js

### N15 Pruefbarkeit der Web-App herstellen: startDemo auf zwei Saele erweitern (?livedemo=2, je ein Patient, einer OHNE Temperatursonde, beide mit patientKey sw_hund_22, plus Schalter zum Anhalten EINES Saals) als eigener Schritt VOR dem Umbau; dazu ein kopfloser tools/webapp-fern-test.js, der den letzten script-Block als Text prueft (kein handleSnapshot mehr, kein 'lastRecv =' ohne sid-Index, jedes data-k und data-sid durch esc(), jedes onValue-Ergebnis in einer Variablen fuer off()).

**Warum:** Schritt 19 ist die groesste Einzelaenderung und hat als Pruefung ausschliesslich Handarbeit 'mit zwei Demo-Saelen'. Der Demo-Modus belegt aber genau EINEN Saal: index.html:3424 setzt meta = {station:'DEMO (lokal)', ...} als ein Objekt, und lastRecv ist ein einzelner Skalar (index.html:2610). Kein Schritt erweitert startDemo. Kein Test im Projekt fasst die Web-App an. Der Entwickler kann Schritt 19 ohne zwei echte PCs und ein echtes Firebase-Konto nicht ausprobieren und liefert auf Sicht aus — und zwar genau den Ablauf, den der Plan selbst als toedlich bezeichnet (Messwerte des Tiers aus Saal 1 unter dem Namen des Tiers in Saal 2, eingehend in Dosis und Beatmung). Es sind 25 onValue-Aufrufe zu entflechten.

**Wo:** canis-anaesthesie/index.html, tools/webapp-fern-test.js, tools/alle-tests.js

### N16 Drei Pruefungen ergaenzen, alle ohne Netz: tools/fremdstore-test.js (Alterung 12 s / 60 s / 12 h als Zustandswechsel bei uebergebener Uhr, LAN-Ausfall -> Cloud nach 3 Fehlversuchen, bei Widerspruch gewinnt die Cloud); in tools/tafel-test.js Nachbar-sv 120 s in Zukunft und Vergangenheit (negatives Alter muss 'Alter unbekannt' ergeben, nie 0); tools/eigener-takt-test.js (fuenf simulierte Nachbarn, Abstand der MSG.PATIENTS-Nachrichten unter 400 ms, nach Blockade verschwindet MSG.FREMD).

**Warum:** Die drei Zusagen, die am Patienten zaehlen — ein toter Saal wird als tot erkannt, der eigene Saal wird nie langsamer, eine fremde Uhr verfaelscht das Alter nicht — waeren nach der Umsetzung nur durch Lesen des Codes belegt. Fuer fremdstore.js nennt der Plan als Pruefung nur, dass es registry/matching nicht laedt; die Lastbremse aus Schritt 17 erscheint in keiner Testdatei. Eine spaetere Aenderung kann sie still aufheben, und tools/alle-tests.js bleibt gruen. Das sind genau die Mechanismen, die Randbedingung 6 tragen.

**Wo:** tools/fremdstore-test.js, tools/tafel-test.js, tools/eigener-takt-test.js, tools/alle-tests.js

### N17 Die Deckel als sichtbares Verhalten festlegen: Saele stabil nach Saalname sortieren, die ersten 8 zeigen, bei mehr eine Zeile 'X weitere OP-Saele werden nicht angezeigt — Deckel erreicht' in Tafel, Kiosk-Streifen und Log; dasselbe fuer die 12 Kacheln je Saal. tools/zwei-stationen-test.js um einen dritten und vierten Prozess erweitern.

**Warum:** Der Auftrag nennt ausdruecklich 'in beiden oder mehreren OP-Saelen' und 'auch wenn mehrere PC in diesem Account eingeloggt sind'. Was beim neunten Saal passiert, steht nirgends — welcher verworfen wird, ob der Tierarzt es sieht, ob die Auswahl stabil ist. Im schlechtesten Fall verschwindet ein OP-Saal lautlos aus der Tafel, was genau die Verwechslungsgefahr ist, die der Umbau beseitigen soll. Geplant und getestet ist nur N=2.

**Wo:** bridge/src/tafelabo.js, canis-anaesthesie/index.html, tools/zwei-stationen-test.js

### N18 Auslieferungs-Anschluss: pruefe(ports, prefix) wirklich um den Prefix erweitern und regelName(port, prefix) mitziehen, in index.js zwei Aufrufe (Datenports mit altem Prefix, 8771 mit 'VetStation Nachbarsaal TCP '); in set-firewall.ps1 auch den Zweig -Pruefen um $STATION_PORTS erweitern; tools/update-paket-test.js um bridge/src/stationsid.js, tafel.js, tafelabo.js, fremdstore.js, nachbar.js erweitern; zum Abschluss make-dist.ps1 ausfuehren und alle-tests.js plus update-paket-test.js laufen lassen.

**Warum:** firewall.js:61 nimmt bereits pruefe(ports) — offen ist nur REGEL_PREFIX (Zeile 18, fest 'VetStation Geraetedaten TCP '). pruefe([8771]) sucht damit nach 'VetStation Geraetedaten TCP 8771', waehrend set-firewall.ps1 die Regel 'VetStation Nachbarsaal TCP 8771' anlegt — die Startpruefung meldet dann dauerhaft 'Firewall blockiert Port 8771', obwohl die Regel existiert. Die Pflichtdateiliste in update-paket-test.js:88-100 ist die einzige Stelle, die ein fehlendes Modul im Paket bemerken wuerde; faellt eines aus, bricht die Station nach dem Update beim require. Und dist/VetStation/bridge/src/ ist bereits jetzt veraltet (16 Dateien, stationsid.js fehlt) — die im Plan tragende Aussage 'dist ist byte-gleich, das Feldverhalten ist also gesichert' stimmt schon heute nicht mehr.

**Wo:** bridge/src/firewall.js, bridge/src/index.js, installer/set-firewall.ps1, tools/update-paket-test.js

### N19 docs/FERN-LIVE.md auf den neuen Baum umschreiben (tafel/, saele/, verbund/lan/, flache Ebene als Kompatibilitaetsschicht mit F0/F1/F2 und einem Abschnitt 'was 1.0.3 schreibt und warum es stehen bleibt'); README.md um den Verweis auf MEHRERE-SAELE.md; docs/QA-CHECKLIST.md um einen Block 'Mehrere OP-Saele'. docs/MEHRERE-SAELE.md in die Dateiliste von tools/paket-test.js aufnehmen. Und die Frage 'andere Dienste' beantworten — als Absage mit Begruendung oder als Ausbaustufe mit schmaler Schnittstelle (anmelden, patch, lese).

**Warum:** docs/FERN-LIVE.md ist die EINZIGE Datei, die den heutigen RTDB-Baum beschreibt (bestaetigt: der Treffer auf /live/ liegt nur dort), und kein Schritt aktualisiert sie — nach dem Umbau widerspricht die einzige Anleitung der Software in genau den Pfaden, deren Verwechslung der Plan als toedlich beschreibt. docs/QA-CHECKLIST.md hat zu fern, cloud und saal NULL Treffer, es gibt also keine Handabnahme fuer die Fern-Ansicht, obwohl der Plan sich fuer drei Schritte auf Handpruefung verlaesst. Und der Auftragssatz 'ueber Firebase oder andere Dienste' kommt im ganzen Plan nicht vor, auch nicht als 'bewusst nicht' — bei der Abnahme wird danach gefragt, und der Umbau erhoeht die Anbieterbindung erheblich.

**Wo:** docs/FERN-LIVE.md, README.md, docs/QA-CHECKLIST.md, docs/MEHRERE-SAELE.md, tools/paket-test.js

## Bewusst getragene Restrisiken

- Innerhalb EINES Praxiskontos kann keine Regel einen Schreiber an eine sid binden. Eine kopierte data/cloud-auth.json ist dauerhaft eine vollwertige Station und kann fremde Saalzweige beschreiben oder loeschen. Gegenmittel waeren Stationskonten oder ein Server-Anteil — beides schliesst die Vorgabe 'eine Praxis, ein Konto' aus. Abgemildert durch sid-Bindung im Datensatz, gepinnte Nachbarschluessel und die signierte tafel-meta in Stufe 2.
- '.validate' wird bei Loeschungen nicht ausgewertet. Fuer das Protokoll loest der Umbau das ueber '!data.exists() && newData.exists()' im .write; fuer alles andere bleibt es: eine Station im Konto kann den Zweig eines Nachbarn per DELETE entfernen. Nachweisbar ist es nur, nicht verhinderbar.
- Die ausgelieferte Web-App kann den Ausfall eines EINZELNEN Saals nicht erkennen — lastRecv ist ein einzelner Skalar (index.html:2610) — und zeigt im Mehr-Saal-Betrieb keinen Verlauf und keine Kurven. Reparierbar nur durch Neuladen der Seite.
- Solange eine 1.0.3-Station im Konto laeuft, zeigt die alte Fern-Ansicht nur diesen einen Saal. Unvollstaendig, aber nicht falsch — das ist die Grenze, die mit einer nicht aktualisierbaren Ansicht erreichbar ist.
- Eine im Feld stehende 1.0.3-Station behaelt ihre Fehler, bis sie aktualisiert wird. Ob sie ueberhaupt ein Update angeboten bekommt, haengt an der noch nicht gesetzten Version und am noch nicht veroeffentlichten Manifest.
- Der Kontingentdeckel des gemeinsamen Firebase-Projekts bleibt ein Verfuegbarkeitsrisiko fuer ALLE Praxen (1 GB Speicher, ~100 gleichzeitige Verbindungen, 10 GB/Monat). Ab 3-4 Saelen im Dauerbetrieb reisst es nach der eigenen Rechnung des Plans. Abgemildert durch Groessengrenzen, Budgetwaechter und die Regel, dass Kontingentfehler nie zur Selbstabschaltung fuehren — geloest ist es nicht.
- Ohne einen Online-Moment gibt es im LAN keinen Vertrauensanker; dann bleibt nur die Handbestaetigung der Fingerabdruecke. Und Stufe 2 oeffnet erstmals einen Port im Praxisnetz.
- bridge/data/protokoll.json und patient-akte.json bleiben je PC lokal. Ein verlegter Patient hat seine Papierspur auf zwei Rechnern; zusammengefuehrt wird nur das Druckblatt, nie ein Knoten.
- Das Fern-Protokoll unter saele/<sid>/protokoll waechst und wird nie aufgeraeumt (die Zeilen sind absichtlich unveraenderlich). Bei fuenf Saelen etwa 30 MB im Monat, die 1-GB-Grenze in etwa 32 Monaten. Ohne Vorgabe des Nutzers passiert nichts.
- Der Firestore-Verlauf unter praxen/<uid>/verlauf ist fuer die bereits vorhandene Historie keinem Saal zuordenbar — sid und saal kommen erst ab der neuen Fassung mit. Rueckwirkend bleibt 'station' Freitext, und der lautet ueberall 'Praxis OP 1'.
- Die Geraeteports 3502/4601/8830/5000/24105/2575 bleiben auf -Profile Any ohne Adressgrenze, und probe.js bindet ohne Host-Argument. Jedes Geraet im Praxis- oder Gast-WLAN kann gefaelschte Vitalwerte in die Registry einspeisen. Die Einengung liegt allein in set-firewall.ps1, kann aber eine Praxis lahmlegen, deren Monitore in einem anderen Netz haengen — offene Frage 3, Entscheidung des Nutzers.
- Jede offene Web-Sitzung des Praxiskontos — Privathandy, Tablet am Empfang — hat volles SCHREIBrecht auf alle Saele und alle Protokolle. Ein zweites, nur lesendes Konto wuerde das loesen und kostet je Praxis eine Anmeldung mehr (offene Frage 5, unentschieden).
- Bei github.io teilen alle Repositorien eines Kontos denselben Browser-Ursprung — dort gibt der Tierarzt Praxis-Mail und Passwort ein. Der Umzug auf einen eigenen Ursprung ist im Code vorgesehen, aber der veroeffentlichte Link aendert sich (offene Frage 2, unentschieden).
- Die vier Semantikfragen aus Schritt 0 bleiben ungemessen, wenn kein Wegwerf-Konto verfuegbar ist. Dann gilt die vorsichtigste Annahme — Vorfahren-.validate wird ausgewertet, .validate greift bei Loeschungen nicht — und genau darauf ist der Plan gebaut. Das ist tragbar, aber es ist eine Annahme, kein Messwert.

## Reihenfolge (Freigabe)

1. 0. Bestandsaufnahme und Entscheidungen: je Planschritt feststellen, was im Arbeitsstand schon umgesetzt ist (Schritt 7 ist fertig, stationsid.js existiert mit verworfener Bauform). Tarif Spark/Blaze entscheiden, Saalname-Schreibweg entscheiden, 'andere Dienste' als Absage oder Ausbaustufe festschreiben.
2. 1. Fehlerentkopplung in cloud.js (alter Schritt 6) — Regelablehnung am Antworttext erkennen, nie Konfigfehler, nie Tokenverwurf, nie Selbstabschaltung; getrennte Fehlerkonten; Gesamtfrist je Anfrage. MUSS vor den Regeln liegen.
3. 2. Lokale Loecher schliessen (alter Schritt 3): Origin-Weissliste im WS-Upgrade, Einmal-Kennwort fuer PAIR/UNPAIR/SET_META/SCENARIO, jsonPrivat mit same-origin und X-VetStation, ACAO:* entfernen, /api/update/apply und /api/netscan/start absichern. Dazu tools/lokal-sicherheit-test.js.
4. 3. Prozess-Ueberleben (alter Schritt 5) mit healthz-Pruefung statt sofortigem exit(1); Auffangnetz fuer uncaughtException und unhandledRejection.
5. 4. Regeln in ZWEI Etappen: erst die neuen Teilbaeume tafel/saele/verbund ergaenzen (rein additiv, nichts kann brechen), dann nach der Messung die Verscharfungen an meta und protokoll — sv als tolerantes Fenster, .write je Teilbaum, Laengengrenzen einschliesslich Signaturfeld. Dazu tools/regeln-test.js und tools/regel-messung.js.
6. 5. Version 1.1.0 in allen vier Stellen, TAFEL_V getrennt, version-test.js gruen.
7. 6. stationsid.js UMBAUEN (Ed25519 statt lanGeheim, keine Auto-Umbenennung, Migration vorhandener Dateien) und tools/stationsid-test.js umschreiben. Danach muss alle-tests.js gruen sein.
8. 7. Saalname-Schreibweg und Erstinbetriebnahme (POST /api/station/name, stationsName() als einzige Quelle, Umbenennungsknopf).
9. 8. tafel.js mit uebersichtSatz() UND geraeteSatz(), gemeinsame Kappungsfunktion, tools/tafel-test.js einschliesslich Uhrenversatz.
10. 9. cloud.js Schreibweg: Weg L mit tiefen saele-Pfaden, Tafelkoerper VOR der Sparregel, Vollbild als PUT auf saele/<sid>/patients und tafel/<sid>/uebersicht, Kollisionserkennung ueber instanz, Restluecke im Protokollweg.
11. 10. cloud.js Spiegel F0/F1/F2 mit jederzeit betretbarem F1, meta/qs/<sid>, ohne pri und top, kein automatisches Aufraeumen.
12. 11. tools/zwei-stationen-test.js und tools/altbestand-test.js — beide Startreihenfolgen, drei bis vier Prozesse, sichtbare Deckel.
13. 12. tafelabo.js und fremdstore.js mit Serverzeit aus dem Date-Kopf, Deckeln und Budgetwaechter; tools/fremdstore-test.js.
14. 13. server.js: MSG.FREMD aus eigenem 1-Hz-Zeitgeber, /api/nachbarn, Lastbremse; tools/eigener-takt-test.js.
15. 14. Zwei-Saal-Demomodus in der Web-App, dann Schritt 19 (Web-App-Umbau), dann tools/webapp-fern-test.js.
16. 15. ui/vetstation-nachbarn.js mit fester Hoehe, Geraetezeile je Saal, nur Ansicht.
17. 16. Firestore-Verlauf um sid und saal, diagnose.js, devices.example.json.
18. 17. Dokumentation: FERN-LIVE.md umschreiben, MEHRERE-SAELE.md neu, README.md und QA-CHECKLIST.md ergaenzen.
19. 18. Erst danach Stufe 2 (LAN, Port 8771) mit Adresspruefung ueber verbund/lan statt ueber das /24 der gebundenen Karte, Firewall mit Prefix, tools/nachbar-test.js.
20. 19. Abschluss: update-paket-test.js Pflichtliste erweitern, make-dist.ps1 ausfuehren, alle-tests.js und update-paket-test.js gruen, dann Setup bauen.

---

# Der Plan

## empfehlung

Grundlage ist Entwurf C ("Tafel und Saal"), weil er als einziger ohne Anfuehrer, Pacht oder Wahl arbeitet — und genau diese Koordinationsmechanismen wurden in A (Spiegelwahl, Besitzer-Anspruch) und B (Sprecher-Pacht) von den Pruefern gebrochen. Aus A uebernehme ich die getrennten Fehlerkonten, das Verbot des Top-Level-Schluessels 'patients', die persistente Schluesselliste zum Aufraeumen und die Serverzeit aus der HTTP-Date-Kopfzeile; aus B die Ed25519-Identitaet mit oeffentlichem Schluessel im Baum und privatem Schluessel auf dem PC. Zusaetzlich streiche ich jede Rollenverteilung: die alte flache Ebene wird von JEDER neuen Station mit ausschliesslich eigenen, praefixierten Schluesseln und identischen Konstantfeldern bespielt, wodurch Spiegelwahl, Sprecher, Pacht und Modus-Umschaltung samt ihrer neun Befunde ersatzlos entfallen.

## begruendung

ENTWURF C ALS GRUNDLAGE, drei Gruende: (1) Er hat keinen gemeinsam beschriebenen Verwaltungsknoten. A's Besitzer-Anspruch (stationen/<sid>/besitzer) und A's Spiegelwahl (kleinste sid mit frischem sv) sowie B's verbund/sprecher sind alle drei aus dem Konto heraus faelschbar — die Pruefer haben je einen toedlichen/schweren Befund daran belegt (A1-4 Fernabschaltung durch fremdes inst, A1-5 Spiegeluebernahme durch tafel/aaaaaaaaaaaa, B1-8 Pacht per Kind-Schreibvorgang umgangen, B2-8 Zwillinge halten beide die Pacht). Ein Mechanismus, den man ersatzlos streichen kann, ist besser als einer, den man haerten muss. (2) C's Trennung tafel/ (klein, 1 Hz) und saele/ (voll, 5 Hz) ist die einzige Bauform, in der die gemessenen 4 KB/s je Station nicht mit N^2 in das Freikontingent laufen; A hat dieselbe Trennung, aber mit Feld-fuer-Feld-Schreibvorgaengen in die Tafel, was C's Pruefer als teurer nachgerechnet hat. (3) C schreibt Tafel und flache meta in EINEM atomaren PATCH — das entschaerft die gefaehrlichste Regelfalle (".validate": "newData.hasChildren(['meta'])" auf /live/$praxis, firebase-rtdb-rules.json:48) unabhaengig davon, wie Firebase Vorfahren-.validate auswertet. Genau diese Frage ist in allen drei Entwuerfen ungemessen; A2-6 und B-Schwaeche-1 belegen, dass ein falscher Griff dort die Fern-Uebertragung der ganzen Praxis abschaltet.

WAS AUS A KOMMT: die getrennten Fehlerkonten nach dem Muster des Archivs (cloud.js:812-823); die Regel "der Top-Level-Schluessel 'patients' verschwindet ersatzlos aus dem Code" (cloud.js:465-466, bestaetigt gelesen — er ersetzt den ganzen Knoten); die Erkenntnis, dass damit die Muellabfuhr wegfaellt und eine PERSISTENTE Schluesselliste braucht (A2-1); die Serverzeit ohne SDK aus der Date-Kopfzeile (loest B2-6, wo Nachbarn ohne LAN gegen die rohe fremde Uhr gerechnet wurden).

WAS AUS B KOMMT: Ed25519 statt gemeinsamem Geheimnis. A's LAN-Schluessel lag in tafel/<sid>/lan.geheim, also in dem Knoten, den JEDE Web-Ansicht per Dauerabonnement herunterlaedt (A1-3) — ein Vorfall am Privathandy waere ein Leseschluessel fuer das Praxisnetz geworden. Ein oeffentlicher Ed25519-Schluessel im Baum ist kein Geheimnis; der private verlaesst den PC nie.

WAS ICH GEGEN ALLE DREI ENTSCHEIDE: (a) Die Regeln bekommen '.write' NICHT mehr auf /live/$praxis. Zwei Pruefer haben unabhaengig belegt, dass .validate bei Loeschungen nicht ausgewertet wird und ein oben erteiltes .write unten nicht entziehbar ist — die Unveraenderlichkeit des Narkoseprotokolls existiert damit HEUTE nicht (A1-2, B1-7, C1-6). Ich lese in installer/firebase-rtdb-rules.json:62-68 genau das: der Schutz besteht allein aus .validate. Das ist der einzige Punkt, an dem ich die Regeln strukturell umbaue. (b) Keine automatische Umbenennung einer Stationskennung. A2-7, B2-7, C2-4 und C2-11 sind vier verschiedene Wege, auf denen eine Selbstumbenennung ein Narkoseprotokoll in zwei unveraenderliche Teile zerschneidet oder einen Geistersaal hinterlaesst. Umbenennen ist ab jetzt eine Handlung eines Menschen. (c) Alter wird als DAUER an der Quelle gemessen (registry.js:496 seitMs, gelesen und bestaetigt), nicht als Zeitstempel — das schliesst C2-2, C2-3, A2-3 und B2-6 mit einer Groesse. (d) Der LAN-Weg wird als Stufe 2 nach hinten geschoben: 8 von 12 Sicherheitsbefunden gegen A und 5 gegen B/C haengen an ihm, und alle drei Entwuerfe rechnen selbst nach, dass er bei diesen Takten NICHT schneller ist als Firebase. Stufe 1 erfuellt den Auftrag "beide OP-Saele live sehen" vollstaendig; Stufe 2 bringt Unabhaengigkeit vom Internet und vom Freikontingent.

## datenmodell

ALLE PFADE WORTGENAU. <uid> = Firebase-localId der Praxis, <sid> = Stationskennung (Format ^st[0-9a-f]{12}(-[0-9a-f]{4})?$), <sid6> = erste 6 Zeichen von <sid> ohne 'st', <key> = sanitizeKey(patientKey) unveraendert (cloud.js:83-86, 594), <pid> = sanitizeKey(patientId || patientKey) unveraendert (registry.js:124).

1) TAFEL — klein, 1 Hz, von allen gelesen
/live/<uid>/tafel/<sid>/meta = {
  sid:"st7f3a91c2b45d", name:"Praxis OP 1", v:4, bv:"1.1.0",
  instanz:"9c1f4ab27e0d3f56",            // 16 hex, NEU bei jedem Prozessstart
  ts:<lokale Uhr, nur Anzeige>, sv:{".sv":"timestamp"},
  count:<eigene Patientenzahl>, taktMs:200, kurven:true,
  sq:<Zaehler erfolgreicher Schreibvorgaenge MIT saele-Schluesseln>,
  aus:<ts|null>                          // beim geordneten Beenden gesetzt
}
/live/<uid>/tafel/<sid>/uebersicht/<key> = {
  pid:"12345", n:"Bello", a:"hund", g:22,
  hr:96, sp:97, et:38, fi:0, af:14, sys:112, dia:64, map:78, t:37.8, rh:"sinus",
  pri:2, top:"MAP grenzwertig", al:1, dev:2,
  dv:["lifevet@192.168.0.51"],           // max 2 Eintraege, je <=40 Zeichen (Doppelempfang erkennen)
  ts:<lokale Uhr>, altMs:<Date.now()-rec.lastTs>   // DAUER, nicht Zeitpunkt
}
Wird als GANZES Objekt je Patient geschrieben (ein Pfad, ~230 Byte). Verschwundener Patient: Pfad = null.

2) SAAL — voller Strom, 5 Hz, nur der gewaehlte Saal wird gelesen
/live/<uid>/saele/<sid>/patients/<key>/<feld>   Feldsatz UNVERAENDERT zu cloud.js:615-710
/live/<uid>/saele/<sid>/protokoll/<pid>/<ts>    Feldsatz UNVERAENDERT zu registry.js:139-148

3) LAN-VERZEICHNIS (Stufe 2) — von der Web-App NIE abonniert
/live/<uid>/verbund/lan/<sid> = { sid, pub:"<Ed25519 SPKI DER base64, 60 Z.>", fp:"<sha256(pub) 16 hex>",
  port:8771, ips:{"0":"192.168.0.99","1":"10.0.5.12"}, sv:{".sv":"timestamp"} }
(hoechstens die Schluessel "0".."3")

4) ALTE FLACHE EBENE — Format unveraendert, aber neue Schreibregeln
/live/<uid>/meta/{station,ts,sv,v,q,taktMs,kurven}   q = <sid> des letzten neuen Schreibers (NEU)
/live/<uid>/patients/s<sid6>__<key>/<feld>           IMMER praefixiert, IMMER tiefe Pfade
/live/<uid>/protokoll/<pid>/<ts>                     nur im Zustand F2-solo (siehe altbestand)
Der Top-Level-Schluessel "patients" wird von einer neuen Station NIE MEHR geschrieben.

SCHREIBWEGE (genau zwei Anfragen, beide PATCH auf /live/<uid>.json):
 Weg L (Live, Takt 200 ms): Koerper enthaelt immer die saele-Schluessel
   {"saele/<sid>/patients/<key>/vitals":{...}, "saele/<sid>/patients/<key>":null, ...}
   und auf jedem 5. Takt (1 Hz) zusaetzlich ATOMAR im SELBEN Koerper
   {"tafel/<sid>/meta":{...mit sv und sq...}, "tafel/<sid>/uebersicht/<key>":{...},
    "meta/station":..., "meta/ts":..., "meta/sv":{".sv":"timestamp"}, "meta/q":"<sid>",
    "patients/s<sid6>__<key>/<feld>":...}
   Begruendung: Herzschlag und Nutzlast duerfen nie getrennt scheitern (Befund A2-2).
 Weg P (Protokoll, eigene Anfrage, eigenes Fehlerkonto, zaehlt NIE auf die Selbstabschaltung):
   {"saele/<sid>/protokoll/<pid>/<ts>":{...}, ["protokoll/<pid>/<ts>":{...} nur in F2-solo]}

LESEN: Station -> GET/SSE nur /live/<uid>/tafel.json und /live/<uid>/meta.json. Eine Station liest NIE
saele/<fremd>. Web-App -> tafel (alle Saele) + saele/<gewaehlt>/patients + saele/<gewaehlt>/protokoll/<pid>
+ .info/serverTimeOffset + flache Ebene nur zur Erkennung einer 1.0.3-Station.

SCHLUESSELWAHL, ausdruecklich: patientKey (model.js:223-229) bleibt UNVERAENDERT. Zwei 22-kg-Hunde ergeben
weiter beide 'sw_hund_22', liegen aber unter tafel/<sidA>/... und tafel/<sidB>/... Der Primaerschluessel des
Systems ist ab jetzt das Paar (sid, patientKey). Deshalb muss weder matching.js noch model.js noch
bridge/data/protokoll.json noch patient-akte.json angetastet werden.

## stationsidentitaet

DATEI: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/stationsid.js (NEU, nur os/fs/crypto/child_process).
ABLAGE: bridge/data/station-id.json = { sid, quelle:"machineguid"|"mac"|"zufall", erzeugt:<ISO>,
  hostHash:"<8 hex>", priv:"<Ed25519 PKCS8 DER base64>", pub:"<SPKI DER base64>", fp:"<16 hex>",
  umbenanntVon:[<alte sid>], umbenanntAm:<ts|null> }

HERKUNFT beim ersten Lauf: sid = 'st' + sha256('VetStation-Stationskennung-v1|' + MachineGuid + '|' +
os.hostname()).hex.slice(0,12). MachineGuid read-only per
execFile('reg',['query','HKLM\\SOFTWARE\\Microsoft\\Cryptography','/v','MachineGuid']) — dasselbe
execFile-Muster wie netscan.js:145 und firewall.js. Ausweichkette: MachineGuid -> erste nicht-virtuelle MAC
aus netscan.localAdapters() -> crypto.randomBytes(6). Ed25519-Paar ueber crypto.generateKeyPairSync('ed25519').

DIE DATEI GEWINNT IMMER. Existiert station-id.json, wird die Registry gar nicht mehr gelesen. Damit ist der
Befund A2-7/B2-7 geschlossen: eine nicht lesbare MachineGuid (Gruppenrichtlinie, gesperrtes reg.exe) und ein
gewechseltes Netzwerkkabel koennen die Kennung nicht mehr aendern. Ist die MachineGuid nicht lesbar UND die
Datei fehlt, wird die Ausweichkette benutzt und im Log im Klartext benannt.

DREI ANFORDERUNGEN, je mit Begruendung:
 - NEUSTART: Datei in data/; zusaetzlich liefert dieselbe Registry denselben Hash, falls die Datei fehlt.
 - NEUE IP: in der Kennung kommt keine Adresse vor. Adressen stehen nur in verbund/lan/<sid>.ips.
 - UPDATE/USB: installer/auf-usb-kopieren.ps1:64 schliesst data/ per robocopy /XD aus, der Updater ist ein
   'git pull --ff-only'. Deshalb ist die Ableitung aus der MachineGuid noetig: ein rein dateibasierter
   Zufallsschluessel waere bei jeder USB-Auslieferung verloren.

FORMATSPERRE (Befund A1-12, Pfaddurchbruch): beim Laden wird /^st[0-9a-f]{12}(-[0-9a-f]{4})?$/ und Laenge <= 24
geprueft; schlaegt das fehl, wird die Datei nach station-id.ungueltig.json umbenannt und neu erzeugt. Im Pfad
wird zusaetzlich encodeURIComponent(sid) benutzt (new URL() loest '..' sonst auf — nachgemessen belegt).

DOPPELTE KENNUNG (geklonter PC, Windows-Abbild, Doppelstart):
 1) EINZELINSTANZ-SPERRE zuerst. bridge/src/server.js:162 macht aus EADDRINUSE auf 8770 heute NUR eine
    Logzeile (gelesen und bestaetigt) — der zweite Prozess laeuft vollstaendig weiter. Neu: bei EADDRINUSE
    process.exit(1) mit Klartextmeldung. Damit ist der haeufigste Kollisionsfall (Autostart + Handstart,
    Befund C2-4) vor jedem Schreibvorgang erledigt.
 2) ERKENNUNG mit positivem Beweis, nie auf Verdacht: die Station schreibt mit jedem 1-Hz-Takt
    tafel/<sid>/meta/probe = <8 hex, je Takt neu> und liest es zurueck. Erst wenn ueber mehr als 5 s
    fortlaufend ein FREMDER probe-Wert dort steht UND verbund/lan/<sid>.ips keine unserer eigenen Adressen
    enthaelt (schliesst den zweiten Prozess auf demselben PC aus), gilt die Kollision als bewiesen.
 3) REAKTION: KEINE automatische Umbenennung. Es wird weitergeschrieben (der eigene Saal bleibt fern
    sichtbar), im Log und im Admin-Bereich erscheint Klartext, diagnose.js liefert den neuen Befund
    STATIONSKENNUNG_DOPPELT, und die Web-App markiert die Karte mit "Kennung doppelt — bitte eine der beiden
    Stationen im Admin-Bereich umbenennen". Der Knopf "Diese Station umbenennen" erzeugt eine frische
    Zufalls-sid (kein Suffix-Anhaengen, deshalb kann die 24-Zeichen-Grenze nie reissen), traegt die alte in
    umbenanntVon[] und loescht NICHTS. Begruendung: A2-7, B2-7, C2-4, C2-11 sind vier verschiedene Wege, auf
    denen eine automatische Umbenennung ein unveraenderliches Protokoll zerschneidet oder einen Geistersaal
    mit echten Werten hinterlaesst. Ein sichtbarer Konflikt ist besser als eine stille Selbstheilung.
 4) VERWAISTE KNOTEN: der Leser blendet jeden Saal aus, dessen meta.sv seit 60 s nicht gewandert ist ODER
    dessen meta kein instanz-Feld hat; nach 12 h verschwindet die Karte. Aufraeumen nur per Admin-Knopf.

WARUM KEIN FREMDER DIE KENNUNG SETZEN KANN: der einzige Schreibweg in den Baum ist eine Anmeldung als dieses
Praxis-Konto (cloud.js:918/931 nehmen localId ausschliesslich aus der Google-Antwort). Die Regel
tafel/$station/meta erzwingt zusaetzlich sid === $station. Im LAN wird eine behauptete sid nie geglaubt,
sondern gegen den gepinnten oeffentlichen Schluessel geprueft.

SAALNAME: name = cfg.station. Fehlt er oder steht dort der Vorlagewert 'Praxis OP 1'
(bridge/config/devices.example.json:12 — und es existiert KEINE devices.json), wird os.hostname() benutzt und
im Admin-Bereich rot verlangt, einen echten Namen zu setzen. Tragen zwei Tafeleintraege denselben name, haengen
Web-App UND Kiosk bei BEIDEN '· <sid6>' an und zeigen eine Warnzeile. Der Name ist Anzeige, die sid ist Identitaet.

## lanWeg

STUFE 2, ausdruecklich NACH dem Firebase-Weg. Begruendung: alle drei Entwuerfe rechnen selbst nach, dass LAN
bei diesen Takten nicht schneller ist (A: 65 ms von 270; B: im Mittel langsamer; C: 505 gegen 564 ms), und 8 von
12 Sicherheitsbefunden gegen A haengen ausschliesslich am LAN-Weg. Sein echter Nutzen ist: kein Firebase-Kontingent,
kein Internet noetig, und ein schnellerer Takt, den man sich in der Cloud nicht leisten kann.

ERKENNUNG, drei Wege, KEIN UDP (im ganzen Projekt existiert kein dgram; das bleibt so — ein Beacon braeuchte
eine UDP-Firewallregel und koennte nichts beweisen):
 1) Treffpunkt ueber den Baum: /live/<uid>/verbund/lan/<sid> mit ips (max 4) und port. Deckt verschiedene
    Teilnetze, gesperrten Broadcast, Client-Isolation und den Fall Kabel+WLAN gleichzeitig — anders als
    netscan.scan(), das nur echte[0], also EINE Karte, benutzt (netscan.js:348-349).
 2) Letzte bekannte Adressen aus bridge/data/nachbarn.json (traegt ueber Internetausfall).
 3) Notnagel: netscan.knock(ip,8771,350) mit netscan.pool(...,48) ueber das eigene /24, ~1,9 s, hoechstens
    1x/60 s, und NUR wenn mehr als ein Tafeleintrag existiert und das Subnetz keine bekannte Geraeteadresse
    enthaelt (Befund B2-10: sonst scannt eine Einzelplatz-Praxis jahrelang ihre Monitore an).

TRANSPORT: bridge/src/nachbar.js (NEU), eigener HTTP-Server auf TCP 8771, NUR GET, kein Upgrade-Handler, keine
CORS-Kopfzeile. Bindung je nicht-virtueller IPv4 mit server.listen(8771, ip) — ausdruecklich nicht
listen(8771) wie probe.js:67, das alle Karten inklusive VPN bindet. ZUSAETZLICH: nur RFC1918-Adressen binden und
je Anfrage pruefen, dass req.socket.remoteAddress im /24 der gebundenen Adresse liegt (netscan.subnetOf) —
das schliesst den Befund C1-11 (Overlay-Adapter, den die VIRTUELL-Regex nicht kennt, traegt den Endpunkt ins
Internet). Das Modul laedt weder registry noch matching noch einen Adapter; ein Test erzwingt das.

AUTHENTISIERUNG — beidseitig, mit Sitzungsschluessel, ohne Geheimnis auf der Leitung:
  A->B  {"vs":1,"typ":"hallo","sid":"<A>","uid8":"<8 hex>","nonceA":"<32 hex>","epkA":"<X25519 SPKI b64>"}
  B->A  {"vs":1,"typ":"hallo2","sid":"<B>","nonceB":"<32 hex>","epkB":"<X25519 SPKI b64>","sigB":"<b64>"}
  A->B  {"vs":1,"typ":"beweis","sigA":"<b64>"}
  danach ausschliesslich {"typ":"box","iv":"<b64>","tag":"<b64>","c":"<b64>"}
Signiert wird (Ed25519, crypto.sign(null,...)) genau die Zeichenkette
  'vetstation-verbund-2|' + uid8 + '|' + nonceA + '|' + nonceB + '|' + sidA + '|' + sidB + '|' + epkA + '|' + epkB
Sitzungsschluessel: crypto.diffieHellman(epkA,epkB) -> crypto.hkdfSync('sha256', gemeinsam, nonceA+nonceB,
'vetstation-verbund-2', 32) -> AES-256-GCM (createCipheriv).
WARUM DAS DEN SIGNIER-ORAKEL-ANGRIFF SCHLIESST (Befund B1-1, toedlich): der Angreifer kann sich weiterhin
Signaturen erschleichen, aber jede Signatur bindet BEIDE fluechtigen Schluessel. Reicht er sie unveraendert
weiter, kennt er den Sitzungsschluessel nicht; tauscht er sie, passt die Signatur nicht. Damit sind gleichzeitig
erledigt: Mitlesen (A1-11, B1-5, C1-5 — Patientendaten waren im Klartext), Wiedereinspielen (C1-4: A bringt
seine EIGENE Zufallszahl mit, es gibt keinen Nonce-Vorrat mehr und damit auch keine Erschoepfung, Befund C1-10),
und Koerperfaelschung.
VERTRAUENSANKER: der oeffentliche Schluessel kommt aus verbund/lan/<sid>.pub, also ueber TLS von Google aus
einem Knoten, den nur dieses Konto beschreiben kann. Er wird beim ERSTEN Sehen in bridge/data/nachbarn.json
GEPINNT; eine spaetere Aenderung von pub oder ips fuer eine bekannte sid wird NIE still uebernommen, sondern
setzt die Quelle auf Cloud zurueck und meldet im Klartext "Der Schluessel von OP 1 hat sich geaendert — im
Admin-Bereich bestaetigen" (Befund A1-3/B1-6/C1-3). uid8 = sha256(uid).slice(0,8) steht in der signierten
Zeichenkette; weicht es ab, bricht die Verbindung mit "Diese Station gehoert zu einem anderen Praxis-Konto"
ab (Befund B1-13: sonst kann eine Handkopplung zwei Praxen verbinden).
WIDERRUF: der Ed25519-Schluessel bleibt, aber der Eintrag in verbund/lan wird bei jeder An- und Abmeldung und
bei jedem Token-Fehler (TOKEN_EXPIRED, USER_DISABLED, INVALID_REFRESH_TOKEN) neu geschrieben; nachbarn.json-
Eintraege verfallen nach 30 Tagen. Ein ausgemusterter PC verliert damit den Zugang, sobald die Praxis das
Passwort aendert und jede Station einmal neu startet — der Satz steht in docs/MEHRERE-SAELE.md.

WEGE: GET /nachbar/hallo (nur der Handschlag oben; ohne gueltige sigA gibt es 404, nicht 401 — der Port ist
dann nicht als VetStation erkennbar, Befund A1-7/C1-12), GET /nachbar/tafel (verschluesselte Uebersicht,
IDENTISCH zum Inhalt von tafel/<sid>). ES GIBT KEIN /nachbar/protokoll und keine Kurven ueber LAN: das
Narkoseprotokoll ist heute der einzige Patientenweg mit Ortspruefung (server.js:196-198, 233-234) und bleibt es.

TAKT 250 ms, genau EINE offene Anfrage ueber ALLE Nachbarn gleichzeitig (Befund C2-10). Harte Deckel VOR jeder
Krypto-Arbeit: 8 Verbindungen gesamt, 2 je Absenderadresse, 2 s Handschlagfrist, 64 KB je Zeile, 15 min bis zur
Neuauthentisierung, res.write()===false -> Rahmen VERWERFEN statt puffern, socket.setTimeout(15000)
(Befunde A1-8, A2-11, B1-9, B2-11).

QUELLENWAHL: je Saal genau EINE Quelle, LAN bevorzugt, Umschalten erst nach 3 Fehlversuchen bzw. 3 s Stille.
ABER: LAN darf nur die Laufzeit ueberholen, nie die Wahrheit. Weichen LAN- und Cloud-Uebersicht derselben sid
in HF/SpO2/EtCO2 oder altMs deutlich ab, gilt die CLOUD und im Band steht "Quellen widersprechen sich"
(Befund A1-1/C1-3). Vor der ersten Nutzung wird geprueft: gelieferte sid == erwartete sid UND instanz != eigene
instanz UND sid != eigene sid, und eigene Adressen werden aus der Kandidatenliste entfernt — sonst spricht eine
Station mit sich selbst und beschriftet es als Nachbarsaal (Befund A2-8, toedlich: docs/LAN-SETUP.md schreibt
JEDEM Praxis-PC 192.168.0.99 vor). In docs/LAN-SETUP.md kommt die Zeile, dass die Stationskennung im HAUSNETZ
liegen muss, nicht im isolierten Geraetenetz.

## sicherheit

RTDB-REGELN, installer/firebase-rtdb-rules.json, neue Fassung im Wortlaut (Kopfkommentar bleibt):

{
  "rules": {
    ".read": false, ".write": false,
    "live": { "$praxis": {
      ".read": "auth != null && auth.uid === $praxis",
      ".validate": "newData.hasChildren(['meta']) || newData.hasChildren(['tafel']) || newData.hasChildren(['saele'])",

      "meta": {
        ".write": "auth != null && auth.uid === $praxis && newData.exists()",
        ".validate": "newData.hasChildren(['station','ts'])",
        "station": { ".validate": "newData.isString() && newData.val().length <= 120" },
        "ts": { ".validate": "newData.isNumber()" },
        "sv": { ".validate": "newData.val() === now" },
        "q":  { ".validate": "newData.isString() && newData.val().length <= 24" },
        "$sonst": { ".validate": "newData.isString() ? newData.val().length <= 200 : (newData.isNumber() || newData.isBoolean())" }
      },
      "patients": { ".write": "auth != null && auth.uid === $praxis", ".validate": true },
      "protokoll": { "$patient": { "$zeitpunkt": {
        ".write": "auth != null && auth.uid === $praxis && !data.exists() && newData.exists()",
        ".validate": "newData.hasChildren(['ts']) && newData.child('ts').isNumber()" } } },

      "tafel": { "$station": {
        ".write": "auth != null && auth.uid === $praxis",
        ".validate": "$station.length <= 24",
        "meta": {
          ".validate": "newData.hasChildren(['sid','name','ts']) && newData.child('sid').val() === $station",
          "sid":  { ".validate": "newData.isString() && newData.val() === $station" },
          "name": { ".validate": "newData.isString() && newData.val().length <= 120" },
          "ts":   { ".validate": "newData.isNumber()" },
          "sv":   { ".validate": "newData.val() === now" },
          "instanz": { ".validate": "newData.isString() && newData.val().length <= 32" },
          "$sonst": { ".validate": "newData.isString() ? newData.val().length <= 64 : (newData.isNumber() || newData.isBoolean())" }
        },
        "uebersicht": { "$key": {
          ".validate": "$key.length <= 200 && newData.hasChildren(['ts','altMs'])",
          "n":   { ".validate": "newData.isString() && newData.val().length <= 60" },
          "a":   { ".validate": "newData.isString() && newData.val().length <= 24" },
          "rh":  { ".validate": "newData.isString() && newData.val().length <= 24" },
          "top": { ".validate": "newData.isString() && newData.val().length <= 80" },
          "pid": { ".validate": "newData.isString() && newData.val().length <= 64" },
          "dv":  { "$i": { ".validate": "$i.matches(/^[01]$/) && newData.isString() && newData.val().length <= 40" } },
          "$sonst": { ".validate": "newData.isNumber() || newData.isBoolean()" }
        } }
      } },

      "saele": { "$station": {
        ".write": "auth != null && auth.uid === $praxis",
        ".validate": "$station.length <= 24",
        "patients": { "$key": { ".validate": "$key.length <= 200",
          "kurven": { "$kanal": { "b64": { ".validate": "newData.isString() && newData.val().length <= 12000" } } } } },
        "protokoll": { "$patient": { "$zeitpunkt": {
          ".write": "auth != null && auth.uid === $praxis && !data.exists() && newData.exists()",
          ".validate": "newData.hasChildren(['ts']) && newData.child('ts').isNumber()" } } }
      } },

      "verbund": { "lan": { "$station": {
        ".write": "auth != null && auth.uid === $praxis",
        ".validate": "newData.hasChildren(['sid','pub','port']) && newData.child('sid').val() === $station",
        "pub":  { ".validate": "newData.isString() && newData.val().length <= 120" },
        "fp":   { ".validate": "newData.isString() && newData.val().length <= 32" },
        "port": { ".validate": "newData.isNumber() && newData.val() > 1024 && newData.val() < 65536" },
        "ips":  { "$i": { ".validate": "$i.matches(/^[0-3]$/) && newData.isString() && newData.val().length <= 45" } },
        "sv":   { ".validate": "newData.val() === now" },
        "$sonst": { ".validate": "newData.isNumber() || (newData.isString() && newData.val().length <= 45)" }
      } } }
    } }
  }
}

DIE VIER AENDERUNGEN, jede mit Grund:
 1) '.write' STEHT NICHT MEHR AUF $praxis, sondern je Teilbaum. Nur so wirkt
    "!data.exists() && newData.exists()" auf dem Protokollblatt: .validate wird bei Loeschungen NICHT
    ausgewertet, und ein oben erteiltes .write ist unten nicht entziehbar. Bis heute ist jede Protokollzeile
    mit einem DELETE loeschbar und danach neu schreibbar (A1-2, B1-7, C1-6). Nebenwirkung, absichtlich: es gibt
    kein .write auf /live/<uid>/saele und /live/<uid>/tafel selbst, ein {"saele":null} ist damit abgewiesen.
 2) "sv": "newData.val() === now" erzwingt den Serverplatzhalter. Ohne das laesst ein einziger Schreibvorgang
    einen toten OP-Saal fuer immer frisch aussehen (C1-2). 1.0.3 schreibt sv bereits als {'.sv':'timestamp'}
    (cloud.js:457, gelesen) und bleibt kompatibel.
 3) meta bekommt "&& newData.exists()": {"meta":null} ist abgewiesen, {"meta/count":null} bleibt erlaubt.
    Sonst laeuft jede ausgelieferte Web-App dauerhaft leer und meldet sich dabei als 'live' (C1-13).
 4) Laengengrenzen auf JEDEM neuen String-Blatt und b64 <= 12000. Die Firestore-Seite hat diese Klasse schon
    geschlossen (istVerlauf, firestore-rules.txt:52-58), die RTDB-Seite hatte sie nirgends — ein einziger
    5-MB-String im Tafelknoten haette das projektweite Kontingent aller Praxen leergezogen (A1-10, C1-7).

FIRESTORE, installer/firestore-rules.txt: istVerlauf() bekommt zwei Pflichtfelder,
 d.sid is string && d.sid.size() < 32 && d.saal is string && d.saal.size() < 120
Der Pfad praxen/<uid>/verlauf bleibt (Aendern wuerde die vorhandene Historie abschneiden). cloud.js:782-791
schreibt sid und saal mit. Grund: der Verlauf war einem OP-Saal bisher nicht zuordenbar, weil 'station'
Freitext ist und ohne devices.json auf jedem PC 'Praxis OP 1' lautet (C1-14).

LOKALE LOECHER, die vor dem ersten offenen Port geschlossen werden MUESSEN:
 a) bridge/src/wsserver.js:51-59 (gelesen) prueft beim Upgrade nur Pfad und Sec-WebSocket-Key. Neu:
    Anfrage verwerfen, wenn eine Origin-Kopfzeile vorhanden ist und nicht http://127.0.0.1:8770 bzw.
    http://localhost:8770 lautet; zusaetzlich muessen die vier schreibenden Nachrichten (PAIR, UNPAIR,
    SET_META, SCENARIO, server.js:171-180) ein je Prozessstart erzeugtes Einmal-Kennwort tragen, das
    server.js beim Ausliefern in ui/index.html einsetzt. Ohne das faelscht JEDE im Browser des Praxis-PCs
    geoeffnete Webseite Tierart und Gewicht des laufenden Patienten und persistiert es in
    bridge/data/patient-akte.json (registry.js:551-559) — WebSocket unterliegt nicht CORS (B1-3, C1-1, C2-12).
 b) jsonPrivat() lehnt zusaetzlich jede Anfrage ab, deren Origin bzw. Sec-Fetch-Site nicht same-origin ist,
    und verlangt die Kopfzeile 'X-VetStation: 1'. Ohne das meldet eine beliebige Webseite die Station per
    POST /api/praxis/token in ein FREMDES Firebase-Konto um und leitet den ganzen Datenstrom dorthin (B1-2).
 c) /api/state, /api/geraet, /api/kurven, /api/rohnachrichten, /api/diag verlieren
    'Access-Control-Allow-Origin: *' (server.js:311-314).
 d) /api/update/apply (server.js:286) und /api/netscan/start werden POST + istLokal + jsonPrivat und
    verweigern den Suchlauf, solange ein Geraet den Status 'active' hat (A2-13).

EHRLICHE GRENZE, ausdruecklich getragen: alle Stationen einer Praxis melden sich mit DERSELBEN uid an. Keine
Regel kann verhindern, dass eine kompromittierte oder kopierte Station den Zweig eines Nachbarn beschreibt
oder loescht. Es bleiben drei schwaechere Saeulen: sid === $station bindet den Datensatz an den Pfad (faengt
Versehen, kopierte Konfiguration, Tippfehler), die Station kennt nur ihre eigene sid, und
tools/zwei-stationen-test.js beweist es fuer den Auslieferstand. In Stufe 2 kommt eine Ed25519-Signatur auf
tafel/<sid>/meta hinzu (ueber sid|ts|instanz|sha256(uebersicht)); Leser markieren unsignierte oder falsch
signierte Saele als "Herkunft nicht bestaetigt". Zwischen PRAXEN bleibt die Trennung unveraendert hart — ich
habe keinen Weg gefunden, sie zu brechen, und die neuen Knoten liegen alle unter /live/$praxis.

## oberflaechen

WEB-APP (C:/Users/akhme/Desktop/Manu/canis-vetpharm/canis-anaesthesie/index.html, letzter script-Block
Z.2582-3522, ES5, keine Build-Kette). BEIDES, mit klarer Aufgabenteilung:
 - TAFEL, dauerhaft sichtbar, eine Karte je Saal, FESTE Reihenfolge nach Saalname (nie nach Prioritaet):
   Saalname, eigenes Verbindungsabzeichen, eigene Laufzeit, Patientenzahl, je Patient eine Zeile mit
   HF/SpO2/EtCO2/AF/MAP/Temp, Prioritaetsfarbe, top und zwei Alterszahlen. Aus dem einen Abonnement
   onValue('live/<uid>/tafel').
 - GENAU EIN GEFUEHRTER SAAL treibt die Narkose-App. Das ist keine Bequemlichkeit: applyLive schreibt in den
   EINEN globalen state (Z.1963-2013), __setRealWave bedient EINEN Monitor (Z.1205).
 - Zustand: saele = {sid:{meta,uebersicht}}, selSaal, patientsSaal, sel; aus den Skalaren lastRecv,
   laufzeit, laufzeitMin, laufzeitMax werden Abbildungen JE SID. Damit kann ein weiterlaufender Saal keinen
   ausgefallenen frisch erscheinen lassen und ein schwaches WLAN in OP 2 die Laufzeitanzeige von OP 1 nicht
   auf 1200 ms treiben.
 - waehleSaal(sid): alte Abos mit off() abbauen (die Rueckgabewerte von onValue werden ab jetzt
   festgehalten), dann saele/<sid>/patients abonnieren, kurvenSigGezeigt=null, applySelected().
 - SAALWECHSEL SETZT ZURUECK. Vor applyLive werden alle ueberwachten state.istVals auf null gesetzt,
   __liveSig=null, __liveAlarmSig=null, state.dev.mirror={}. Grund: sv() in applyLive (Z.1972) weist nur
   nicht-leere Werte zu, iv.nibp faellt auf iv.nibp||0 zurueck (Z.1975), und __liveSig ist bei zwei
   22-kg-Hunden identisch — ohne Ruecksetzen stehen EtCO2, Temp und RR des Tiers aus OP 1 unter dem Namen des
   Tiers in OP 2, ausgewiesen als gemessene Istwerte (B2-1, toedlich). Zusaetzlich fragt der Wechsel zurueck
   und nennt BEIDE Tiere, und Saalname + Tierart + Gewicht stehen ab jetzt in JEDEM rechnenden Bereich
   (Dosis, Beatmung, Vorfall), nicht nur in der Leiste (C2-8).
 - KEIN automatisches Umschalten ueber Saalgrenzen. Die pri-Automatik (Z.3395-3398) waehlt nur INNERHALB des
   gewaehlten Saals; ein Alarm im Nachbarsaal laesst dessen Karte pulsieren und bietet "OP 2 oeffnen".
 - ZWEI ALTERSANZEIGEN je Saal, mit verschiedenen Texten: "Uebertragung" aus jetzt - sv (jetzt = Date.now() +
   uhrVersatz aus .info/serverTimeOffset, Z.3326) und "Geraetedaten" aus altMs + (jetzt - sv). Nur die
   Uebertragungsschwelle darf Zahlen verstecken: < 12 s live, 12-60 s gelb "keine neuen Daten (Xs)", > 60 s
   "OP 1 offline seit X min" und die Zahlen werden durch "Stand vor X min" ERSETZT. Ein negatives Alter wird
   nie auf 0 geklemmt, sondern als "Alter unbekannt" gezeigt.
 - protokoll[sid+'|'+pid], protAbos[sid+'|'+pid] speichert die Abmeldefunktion und wird beim Verschwinden
   eines Saals/Patienten und beim Abmelden aufgerufen. Behebt zugleich den heutigen Fehler, dass protAbos nie
   abgebaut wird und das Protokoll nach erneutem Anmelden dauerhaft leer bleibt (Z.3300-3307, 3415-3416).
 - Druckkopf: saele[selSaal].meta.name + '· <sid6>' statt des einen meta.station (Z.2964). Bei erkannter
   Verlegung (gleiche, nicht leere pid in zwei Saelen) zusaetzlich "Verlauf beider Saele drucken": eine
   Tabelle, nach ts sortiert, mit fuehrender Spalte "Saal" und der Kopfzeile "aus zwei OP-Saelen
   zusammengestellt". Zusammengefuehrt wird nur das Papier, nie ein Knoten. Das Einfrieren des Blatts bleibt.
 - handleSnapshot (Z.2701-2717) wird GELOESCHT (toter Code, zweite ungepflegte Zuordnungslogik).
 - JEDER Datenbankstring geht durch esc(), auch data-k und data-sid — heute wird data-k ohne esc()
   interpoliert (Z.279).

STATIONS-OBERFLAECHE: fremde Saele erscheinen als ZUSATZ, nie im eigenen Arbeitsbereich.
 - Neue Datei ui/vetstation-nachbarn.js, ein script-Tag in ui/index.html, neuer Behaelter #vsxNachbarn.
   Sie schreibt ausschliesslich state.fremd. state.devices und state.patients bleiben AUSSCHLIESSLICH eigen —
   deshalb bleiben refresh(), drive(), renderBar(), renderPairing(), updateDeviceBtn(), updateTestBanner(),
   logSnapshot() und doExportPDF() unveraendert, und fremde Geraete koennen im Koppel-Dialog gar nicht
   angeboten werden. Genau das ist die Zusage "nur Ansicht" und die Zusage "der eigene Saal leidet nicht".
 - Speisung: NEUE WS-Nachricht MSG.FREMD = 'fremd' aus einem EIGENEN 1-Hz-Zeitgeber in server.js, nicht aus
   dem 350-ms-Rundruf (Z.114-131). {type:'fremd', ts, saele:[{sid,name,quelle:'lan'|'cloud'|'aus',
   uebertragungMs, count, patients:[{key,pid,n,a,g,hr,sp,et,af,sys,dia,map,t,rh,pri,top,al,altMs}]}]}
 - Der Streifen hat eine FESTE Hoehe (bzw. liegt als Overlay), ist standardmaessig eingeklappt, und seine
   Hoehe aendert sich ausschliesslich nach einem Klick — nie durch eintreffende Daten. Grund: #vsxGrid ist
   position:fixed mit bottom:0 und grid-auto-rows:1fr; jede Hoehenaenderung bricht alle Patienten-iframes neu
   um (C2-9). Neu gezeichnet wird nur bei geaenderter Signatur (Muster host.__sig aus renderBar Z.277-279);
   das sekuendliche Alter kommt aus einem eigenen Zeitgeber ueber CSS-Klassen, nicht per innerHTML.
 - Reines DOM mit textContent, keine iframes, keine Eingabefelder, kein 'setzen'-Knopf, Schloss und
   "Nur Ansicht — dieser Patient haengt am PC in OP 2". Keine Kurven: das iframe- und CPU-Budget gehoert dem
   eigenen Saal (devices.example.json:109 nennt 3-4 fluessige Fenster auf einem i3).
 - Kein fetch('api/kurven?key=...') fuer fremde Schluessel (heute liefe das still auf {kurven:[]} und wuerde
   die Signatur trotzdem merken).
 - LASTBREMSE: verpasst der eigene 350-ms-Rundruf EINEN Takt, werden Nachbarabfragen und MSG.FREMD sofort
   abgeschaltet und im Log begruendet — nicht erst nach 5 s Ruckeln (C2-10).
 - Admin-Bereich "Verbund": eigener Saalname, sid-Kurzform, Fingerabdruck in vier Paaren, Nachbarliste mit
   Quelle/Zustand/Alter, Knopf "Diese Station umbenennen", Knopf "Verwaisten Saalzweig entfernen".
 - doExportPDF: station() ist heute die harte Konstante 'VetStation' (Z.839) und liest ab jetzt Saalname +
   sid-Kurzform. Fremde Patienten kommen NIE ins eigene PDF.

WIE SAELE UNTERSCHEIDBAR BLEIBEN: Saalname UND sid-Kurzform auf jeder Karte und in jedem Fensterkopf; bei
doppeltem Namen zusaetzlich eine Warnzeile in Tafel und Kiosk; Saalname im gespiegelten patientName
("OP 1 · Bello"); Saalname im Druckkopf und im Firestore-Verlauf; Saalname in jedem rechnenden Bereich der
Web-App.

## altbestand

GRUNDLAGE, gelesen und bestaetigt: eine 1.0.3-Station nennt in ihrem PATCH ausschliesslich die Top-Level-
Schluessel 'meta', 'patients' und 'protokoll/...' (cloud.js:465-468). Geschwisterknoten 'tafel', 'saele' und
'verbund' beruehrt sie NIE, auch nicht mit ihrem 30-s-Vollbild. dist/VetStation/bridge/src/cloud.js ist
byte-gleich, das Feldverhalten ist also gesichert.

DER SPIEGEL OHNE ROLLEN — das ist die entscheidende Abweichung von A und C. Es gibt keinen Sprecher, keine
Wahl, keine Pacht und keine Modus-Umschaltung mit Vorgeschichte. Jede neue Station bespielt die flache Ebene
selbst, ausschliesslich mit EIGENEN Patienten, IMMER unter praefixierten Schluesseln
patients/s<sid6>__<key>/<feld> und IMMER als tiefe Pfade. Der Top-Level-Schluessel 'patients' wird nie mehr
geschrieben. Damit koennen zwei neue Stationen sich auf der flachen Ebene nicht mehr loeschen — die Befunde
A1-5 (Spiegeluebernahme), A2-12 (Spiegel kennt fremde Saele nur als Uebersicht), C2-5 (M1-Start loescht die
anderen) und C2-13 (M1->M3 loescht den Patienten der 1.0.3-Station) entfallen konstruktiv.
Die Felder, in denen zwei Stationen sich unvermeidlich treffen, werden zu IDENTISCHEN KONSTANTEN gemacht:
  meta/station = cfg.station          solange nur ein Tafeleintrag existiert
  meta/station = "Praxis — mehrere OP-Saele (Web-Ansicht neu laden)"   sobald mehr als einer existiert
  meta/v = 3, meta/taktMs = 1000, meta/kurven = false (im Mehr-Saal-Fall), meta/q = <eigene sid>
  meta/count wird im Mehr-Saal-Fall NICHT geschrieben (die alte Web-App liest es nicht; ein aus der eigenen
  Sicht gerechneter Summenwert wuerde flackern, C2-14)
Nur ts und sv unterscheiden sich, und dort ist "letzter Schreibvorgang gewinnt" genau richtig. meta/station
ist konstant und kurz — die 120-Zeichen-Grenze kann nie reissen (B1-14).

DREI ZUSTAENDE, EINMALIG UND SICHER LATCHEND:
 F0 "unbekannt" (die ersten 10 s nach dem Start, bevor die Tafel gelesen ist): es wird NICHTS flach
    geschrieben. Grund: cloud.start() setzt _gesendet=null (cloud.js:255), der erste Schreibvorgang ist
    zwingend ein Vollbild, und der Schreib-Zeitgeber feuert nach 100 ms, also lange vor dem ersten
    Tafel-Ereignis. Wer in dieser Luecke "1.0.3-treu" schreibt, loescht die anderen (C2-5).
 F1 "1.0.3 im Konto": flaches meta hat einen frischen ts (< 60 s) und KEIN q, oder v <= 3 ohne q. Dann
    gehoert die flache Ebene einem fremden Schreiber: es wird gar nichts flach geschrieben, es wird NIE ein
    null auf einen unpraefixierten Schluessel geschrieben, und Log plus Admin-Banner sagen im Klartext:
    "Eine Station in dieser Praxis hat noch Fassung 1.0.3. Solange sie laeuft, zeigt die alte Fern-Ansicht
    nur diesen einen Saal. Bitte diese Station aktualisieren."
 F2 "wir spiegeln": meta-Konstanten wie oben plus patients/s<sid6>__<key>/<feld>. Unterfall F2-solo (genau
    EIN Tafeleintrag und meta/q ist unser): zusaetzlich die Kurven im Spiegel und protokoll/<pid>/<ts> mit
    UNVERAENDERTER pid — damit bleibt eine Einzelplatz-Praxis mit der alten Web-App vollstaendig wie heute,
    inklusive Verlauf und echter Kurve, und der Protokollpfad wird nicht umbenannt (B2-13). Kommt ein zweiter
    Saal hinzu, hoert diese Station auf, flache Protokollzeilen ANZUFUEGEN; die vorhandenen bleiben stehen und
    sind korrekt, weil sie zu ihrem eigenen Patienten gehoeren. Kein Loeschen, keine Vermischung.
Der Wechsel F0->F1/F2 ist einmalig je Prozesslauf; ein Ruecksprung F2-multi -> F2-solo braucht 60 s Stille
UND laesst vorhandene Spiegelschluessel unberuehrt.
EINMALIGES AUFRAEUMEN: unpraefixierte flache Schluessel aus einer 1.0.3-Vorgeschichte DIESER Station werden
genau einmal auf null gesetzt — und nur, wenn meta/q unsere sid ist oder das flache meta seit > 60 s steht.
Nie in F1.

DIE VIER FAELLE:
 1) 1.0.3 + neue Station + NEUE Web-App: disjunkte Datenbestaende, kein gegenseitiges Loeschen. Die neue
    Web-App zeigt die flache Ebene als Pseudo-Saal '__flach' (Name aus flachem meta.station, Zusatz
    "Fassung 1.0.3", Vorbehalt "Alterserkennung eingeschraenkt"), gebaut aus allen flachen patients-
    Schluesseln OHNE 's'-Praefix; Kurven und Protokoll dieser Karte funktionieren voll.
 2) 1.0.3 + neue Station + ALTE Web-App: die alte Ansicht zeigt genau den 1.0.3-Saal — vollstaendig, richtig,
    ohne Flackern, weil dort nur ein Schreiber ist. Der neue Saal fehlt ihr. Unvollstaendig, aber nicht
    falsch. Das ist die Grenze, die mit einer nicht aktualisierbaren Ansicht erreichbar ist.
 3) Nur neue Stationen + ALTE Web-App: alle Patienten aller Saele erscheinen mit Saalnamen im patientName
    ("OP 1 · Bello"), kollisionsfrei durch das sid-Praefix, Live-Werte und Chips funktionieren, meta/kurven
    sagt ehrlich false, der Verlauf bleibt leer. Ausdruecklich getragen.
 4) Neue Station allein + ALTE Web-App: identisch zu heute (F2-solo).

REIHENFOLGE DER AUSLIEFERUNG, zwingend: (1) Regeln, (2) Web-App, (3) Stationen in beliebiger Reihenfolge. Die
Regeln zuerst, weil sonst das neue Protokoll nicht unveraenderlich ist; die Web-App vor den Stationen, weil sie
die neue Ebene lesen koennen muss. Die Regeln sind rueckwaertskompatibel: 1.0.3 erfuellt den linken Zweig des
ODER und alle heutigen Prueffelder unveraendert.

DAUERHAFTE INVARIANTE: der ERSTE Schreibvorgang einer Station enthaelt immer ihr eigenes tafel/<sid>/meta
(mit sid, name, ts) UND die flachen meta-Felder. Damit ist hasChildren(['meta']) unter jeder Auslegung der
Vorfahren-.validate erfuellt.

## Schritte

### 0. Regel-Semantik mit einem Wegwerf-Konto messen und das Ergebnis als Kommentar in installer/firebase-rtdb-rules.json festhalten: (a) Wird .validate eines VORFAHREN bei einem Schreibvorgang auf einen tiefen Pfad ausgewertet? (b) Wird .validate bei einem null-Wert ausgewertet? (c) Laesst sich eine Protokollzeile mit DELETE entfernen, solange .write auf $praxis steht? (d) Wird ein .write, das auf $praxis erteilt ist, durch eine tiefere Regel entzogen?

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/installer/firebase-rtdb-rules.json, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/regel-messung.js

Warum: Alle drei Entwuerfe bauen auf ungemessenen Annahmen. Ein Fehlgriff hier fuehrt zu HTTP 400 bei jedem Schreibvorgang, und drei davon schalten heute die Fern-Uebertragung der ganzen Praxis ab (cloud.js:231-233, 851-870).

Pruefung: Vier Antworten stehen als Kommentar in der Regeldatei, jede mit dem beobachteten HTTP-Code. Ergibt (c) 'loeschbar', ist Schritt 1 zwingend vor jeder anderen Aenderung.

### 1. Neue RTDB-Regeln veroeffentlichen (Wortlaut siehe Feld sicherheit): .write von $praxis herunter je Teilbaum, Protokollblatt mit '!data.exists() && newData.exists()' im .write, sv === now, meta mit newData.exists(), Bloecke tafel/$station und saele/$station und verbund/lan/$station, Laengengrenzen ueberall, $praxis-.validate um '|| tafel || saele' erweitert.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/installer/firebase-rtdb-rules.json

Warum: Die Unveraenderlichkeit des Narkoseprotokolls existiert heute nicht, und ohne die neuen Bloecke waere alles unterhalb einer Saalebene vollstaendig unvalidiert.

Pruefung: Im Regel-Simulator der Firebase-Konsole: ein 1.0.3-Beispiel-PATCH {meta,patients,'protokoll/x/1'} geht durch; ein DELETE auf eine bestehende protokoll-Zeile wird abgewiesen; {'saele':null} wird abgewiesen; {'meta':null} wird abgewiesen; ein meta/sv mit einer festen Zahl wird abgewiesen.

### 2. tools/regeln-test.js (NEU) und Eintrag in tools/alle-tests.js: prueft als Text/JSON, dass unter $praxis KEIN .write steht, dass BEIDE Protokolltiefen ein '!data.exists()' im .write haben, dass jedes sv-Blatt '=== now' fordert, dass kein neues String-Blatt ohne Laengengrenze existiert und dass die Wurzel fail-closed bleibt. Dazu firestore-rules.txt auf sid/saal in istVerlauf.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/regeln-test.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/alle-tests.js

Warum: Heute prueft KEIN Test die Regeldateien; der einzige Treffer im Projekt ist ein Hinweistext in tools/fern-messen.js:126.

Pruefung: node tools/alle-tests.js regeln-test endet mit 0 Fehlern; ein absichtlich eingefuegtes '.write' auf $praxis laesst den Test rot werden.

### 3. Lokale Loecher schliessen, BEVOR ein Port aufgeht: Origin-Weissliste im upgrade-Handler; Einmal-Kennwort fuer PAIR/UNPAIR/SET_META/SCENARIO; jsonPrivat verlangt same-origin und 'X-VetStation: 1'; ACAO:* von /api/state, /api/geraet, /api/kurven, /api/rohnachrichten, /api/diag entfernen; /api/update/apply und /api/netscan/start auf POST + istLokal + Kennwort und Suchlauf verweigern, solange ein Geraet 'active' ist.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/wsserver.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/server.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/ui/index.html

Warum: Der WebSocket auf 8770 ist heute ein SCHREIBweg ohne jede Herkunftspruefung (wsserver.js:51-59 gelesen) und /api/praxis/token ist per CSRF ansprechbar — beides faelscht bzw. entfuehrt den EIGENEN laufenden Patienten.

Pruefung: tools/lokal-sicherheit-test.js (Schritt 4) ist gruen; von Hand: eine Seite auf http://example.invalid im Kiosk-Browser bekommt beim new WebSocket keinen 101, und ein setMeta ohne Kennwort wird mit ack ok:false abgelehnt.

### 4. tools/lokal-sicherheit-test.js (NEU) + Eintrag in alle-tests.js: WS-Upgrade mit fremder Origin scheitert, mit fehlender Origin gelingt; setMeta ohne Kennwort wirkungslos (registry.meta bleibt leer); GET auf die fuenf Patienten-Endpunkte enthaelt keine ACAO-Kopfzeile; GET /api/update/apply gibt 405; POST /api/praxis/token ohne X-VetStation gibt 403.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/lokal-sicherheit-test.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/alle-tests.js

Warum: Diese vier Sperren sind die Voraussetzung dafuer, dass ueberhaupt ein Netzport geoeffnet werden darf.

Pruefung: 5 von 5 Pruefungen OK, Exitcode 0.

### 5. Prozess-Ueberleben: process.on('uncaughtException') und ('unhandledRejection') in index.js, die protokollieren und den Prozess AM LEBEN lassen; EADDRINUSE auf 8770 wird process.exit(1) statt nur einer Logzeile (server.js:162); jeder neue Server/Socket/Zeitgeber der Nachbarmodule bekommt einen eigenen Fehlerhandler, der NUR sein Modul abschaltet.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/index.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/server.js

Warum: Es gibt im ganzen bridge/ keinen Auffangnetz-Handler. Ein listen()-Fehler auf einer weggefallenen WLAN-Adresse wuerde die Bridge mitten in der Narkose beenden, und der Autostart laeuft nur bei der Anmeldung.

Pruefung: Ein Testschalter erzeugt absichtlich einen listen-Fehler auf einer nicht vorhandenen Adresse; der Prozess laeuft weiter und MSG.PATIENTS kommt ununterbrochen.

### 6. cloud.js Fehlerbehandlung entkoppeln: _fehler(e,{quelle:'live'|'protokoll'|'tafel'|'spiegel'|'lan'}); nur quelle==='live' darf _gesendet, backoffMs und naechsterVersuch anfassen; _istKonfigFehler zaehlt nur noch 401/403/404 und 'URL ungueltig'; HTTP 400 und PERMISSION_DENIED erzwingen ein Vollbild und zaehlen NICHT; 402/429/'quota' bekommen einen eigenen, wahren Text und zaehlen nie. Getrennte Agents: AGENT_SCHREIBEN (maxSockets 4) und AGENT_LESEN (maxSockets 2). Gesamtfrist per setTimeout+destroy um jede Anfrage. inFlight-Wachhund: laenger als 3x Frist gesetzt -> abbrechen, zuruecksetzen, _fehler. status() bekommt sekundenSeitLetztemErfolg.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/cloud.js

Warum: Dieser Block ist der Verstaerker hinter sieben Befunden: ein abgelehnter Nebenschreibvorgang bremst heute den eigenen Vitalstrom bis 60 s, eine Regel-Feinheit schaltet die Praxis dauerhaft ab, und eine in der Agent-Warteschlange haengende Anfrage hat gar keine Frist (timeout ist eine SOCKET-Frist).

Pruefung: Im Mock-Firebase: ein dauerhaft mit 400 antwortender tafel-Pfad laesst den saele-Strom unveraendert weiterlaufen und started bleibt true; vier Sockets kuenstlich belegen -> der Live-PATCH bricht nach der Gesamtfrist ab und inFlight ist wieder false; /api/cloud zeigt sekundenSeitLetztemErfolg.

### 7. Protokoll aus dem atomaren Live-Koerper herausziehen (Weg P, eigene Anfrage, quelle 'protokoll'); in _protokollPfade jeden Eintrag mit e.ts < this.prozessStart einmalig als gesendet vermerken und ueberspringen; nur ein HTTP-Fehler, dessen Antworttext PERMISSION_DENIED enthaelt, gilt als 'stand schon da' und dann nur fuer den genannten Pfad, jeder andere Fehler laesst _protokollGesendet UNBERUEHRT.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/cloud.js

Warum: Behebt den nachgeprueften Altfehler (Protokoll-Nachsendung nach Neustart schaltet die Station binnen 30 s dauerhaft ab) und gleichzeitig den Befund, dass die Regel 'abgelehnt = stand schon da' bei 401/503/Zeitueberschreitung Protokollzeilen ENDGUELTIG verliert.

Pruefung: Neuer Test in tools/cloud-test.js neben Block 13: ein Publisher mit vorhandener bridge/data/protokoll.json schreibt im ERSTEN Schreibvorgang keinen einzigen protokoll-Pfad; ein mit 503 abgelehnter Protokollstapel wird im naechsten Takt erneut versucht; ein mit PERMISSION_DENIED abgelehnter nicht.

### 8. Kurvensignatur erst nach Erfolg merken: this._kurvenSigGesendet[key]=sig aus cloud.js:699 in _merken() verschieben und in _fehler() zusaetzlich this._kurvenSigGesendet={} setzen.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/cloud.js

Warum: Heute wird die Signatur VOR dem Schreibvorgang gemerkt (Zeile 699 gelesen). Nach einem Fehler steht kurvenSig=NEU neben kurven=ALT, und die Web-App zeichnet einen alten EKG-Streifen als aktuellen Rhythmus — durch den Wegfall des ersetzenden Vollbilds wird aus einem sichtbaren Fehler ein unsichtbarer.

Pruefung: Mock-Firebase antwortet einmal mit 500; der naechste erfolgreiche Schreibvorgang enthaelt patients/<key>/kurven mit b64 erneut.

### 9. bridge/src/stationsid.js (NEU) mit reinen, exportierten Teilfunktionen: sidAus(guid,host), formatOk(sid), ed25519Paar(), laden/erzeugen nach bridge/data/station-id.json, instanz je Prozessstart, Regelwerk 'die Datei gewinnt immer', keine automatische Umbenennung, umbenennenVonHand().

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/stationsid.js

Warum: Die sid ist die Grundlage aller Pfade. Sie muss Neustart, IP-Wechsel und Update ueberleben, ohne dass eine unlesbare Registry oder ein gewechseltes Kabel sie aendert.

Pruefung: tools/stationsid-test.js (Schritt 10) gruen.

### 10. tools/stationsid-test.js (NEU) + alle-tests.js: gleiche Eingabe -> gleiche sid; Format ^st[0-9a-f]{12}(-[0-9a-f]{4})?$ und Laenge <= 24; eine sid mit '..', '/' oder Grossbuchstaben in der Datei fuehrt zur Neuerzeugung; nicht lesbare MachineGuid bei vorhandener Datei aendert NICHTS; Ed25519-Signatur/Pruefung ueber die Verbundzeichenkette funktioniert; encodeURIComponent im Pfad macht aus '../x' kein Verzeichnis hoeher.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/stationsid-test.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/alle-tests.js

Warum: Ohne Netz pruefbar, nach dem Muster von tools/netscan-test.js.

Pruefung: Alle Pruefungen OK; der Pfaddurchbruch-Fall ist ausdruecklich dabei.

### 11. bridge/src/tafel.js (NEU, pur): uebersichtSatz(patient, geraeteliste, bewertung) -> {pid,n,a,g,hr,sp,et,fi,af,sys,dia,map,t,rh,pri,top,al,dev,dv,ts,altMs} mit altMs aus seitMs (registry.js:496) und dv aus hoechstens zwei '<deviceId>@<ip>'; tafelPfade(sid, saetze, meta, vorher) -> flache PATCH-Schluessel inkl. null fuer verschwundene Patienten.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/tafel.js

Warum: altMs ist eine DAUER und damit gegen jeden Uhrenversatz immun; dv ist das Einzige, womit sich 'dasselbe Geraet in zwei Saelen' ueberhaupt erkennen laesst.

Pruefung: tools/tafel-test.js: ein Patient mit lastTs vor 42 s ergibt altMs ~42000; ein verschwundener Patient ergibt genau einen null-Pfad; jedes Textfeld ist gekuerzt und enthaelt keine der Zeichen <>&".

### 12. cloud.js Schreibweg umbauen: EIN Weg L auf /live/<uid>.json mit tiefen Schluesseln 'saele/<sid>/patients/...' im 200-ms-Takt und ATOMAR auf jedem 5. Takt zusaetzlich 'tafel/<sid>/meta' (mit sv, sq, probe) und 'tafel/<sid>/uebersicht/<key>'; das Sicherheits-Vollbild alle 30 s ausschliesslich als tiefe Pfade plus ausdrueckliche nulls aus bridge/data/fern-keys.json; der Top-Level-Schluessel 'patients' verschwindet ersatzlos; _fehler() loescht fern-keys.json NICHT.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/cloud.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/data/fern-keys.json

Warum: Das ersetzende Vollbild war gleichzeitig die einzige Muellabfuhr. Ohne persistente Schluesselliste bleibt ein Patient nach einem Neustart fuer immer als scheinbar frischer Datensatz stehen. Und Herzschlag und Nutzlast muessen im selben Koerper stehen, sonst meldet die Tafel 'live', waehrend die Werte stehen.

Pruefung: tools/zwei-stationen-test.js (Schritt 14): in keinem PATCH-Koerper kommt je der Schluessel 'patients' auf oberster Ebene vor; nach Neustart mit geaendertem Patientenbestand enthaelt das erste Vollbild einen null-Pfad fuer den verschwundenen Schluessel; ein 1-Hz-Koerper enthaelt tafel-meta UND saele-Schluessel.

### 13. cloud.js Spiegel F0/F1/F2 nach dem Feld altbestand: F0 die ersten 10 s nichts flach; F1 nichts flach plus Klartextmeldung; F2 meta-Konstanten und patients/s<sid6>__<key>/<feld>; F2-solo zusaetzlich Kurven und protokoll/<pid>/<ts> mit unveraenderter pid; einmaliges, doppelt abgesichertes Aufraeumen eigener unpraefixierter Altschluessel; zwei getrennte Delta-Gedaechtnisse _gesendetSaal und _gesendetFlach.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/cloud.js

Warum: Ohne Spiegel laeuft jeder noch geladene alte Browser-Tab dauerhaft leer und meldet sich dabei als 'live' — der schlechtestmoegliche Ausgang. Mit Rollen oder Modus-Umschaltung entstuenden neun der geprueften Befunde.

Pruefung: tools/altbestand-test.js (Schritt 14): eine simulierte 1.0.3-Station schreibt flaches meta -> die neue Station schreibt danach keinen einzigen flachen Pfad; ohne 1.0.3 sind alle flachen patients-Schluessel praefixiert; es wird nie ein null auf einen unpraefixierten Schluessel geschrieben, waehrend flaches meta fremd und frisch ist; das Vollbild der simulierten 1.0.3-Station laesst tafel/ und saele/ unberuehrt.

### 14. tools/zwei-stationen-test.js und tools/altbestand-test.js (NEU, Muster tools/cloud-integration-test.js) + alle-tests.js: zwei echte Bridge-Prozesse mit eigener temporaerer devices.json, DERSELBEN localId im Mock-Token und verschiedenen sid gegen das Mock-Firebase aus tools/cloud-test.js. Geprueft: kein PATCH-Pfad enthaelt eine fremde sid; kein Top-Level-'patients'; nach 90 s (drei Vollbilder) sind BEIDE Saele vollstaendig vorhanden; zwei Patienten mit demselben patientKey 'sw_hund_22' bleiben getrennt; eine abgelehnte Protokollzeile laesst die Vitalwerte durch und schaltet nichts ab; eine doppelt vergebene sid fuehrt zu einer Warnung, aber NICHT zu einer Umbenennung und nicht zu einem Schreibstopp; ein Neustart sendet keine alten Protokollzeilen.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/zwei-stationen-test.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/altbestand-test.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/alle-tests.js

Warum: Kein heutiger Test startet zwei Stationen gegen dieselbe Kennung. Das ist die Absicherung, ohne die die ganze Aenderung nicht nachweisbar ist.

Pruefung: node tools/alle-tests.js endet gruen; wird in cloud.js absichtlich der Top-Level-Schluessel 'patients' wiederhergestellt, schlaegt der Test fehl.

### 15. bridge/src/tafelabo.js (NEU): Leser fuer /live/<uid>/tafel.json und /live/<uid>/meta.json, standardmaessig EIN SSE-Strom auf AGENT_LESEN, alternativ Abruf im 2-s-Takt (Konfigschluessel nachbarn.leseart); Behandlung von put/patch/keep-alive/auth_revoked mit dem bestehenden _refresh-Weg; eigener Backoff 2 s..60 s, der den Schreibweg NIE beruehrt; Serverzeitversatz aus dem HTTP-Date-Kopf (Median der letzten 10 Antworten); harte Deckel VOR jeder Weitergabe: 8 Saele, 12 Kacheln je Saal, Zahlen durch Number(), Texte auf 40 Zeichen und ohne <>&"; Budgetwaechter, der oberhalb eines konfigurierten Monatsvolumens auf 5-s-Takt geht und es im Klartext meldet.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/tafelabo.js

Warum: Ohne Serverzeit auf der Station wird das Alter eines nur ueber die Cloud sichtbaren Saals gegen die ROHE fremde Uhr gerechnet; ohne Deckel wird ein fehlerhafter Nachbar zur Last und zum XSS-Weg auf dem eigenen Kiosk.

Pruefung: Mock-Firebase liefert eine Uebersicht mit 40 Patienten und einem Namen mit Markup: es kommen genau 12 Kacheln an, der Name ist gekuerzt und enthaelt keine Sonderzeichen; ein Lesefehler laesst _gesendet und backoffMs des Schreibwegs unveraendert.

### 16. bridge/src/fremdstore.js (NEU): Map sid -> {name, quelle, uebertragungMs, meta, patients[]}; Alterung 12 s / 60 s / 12 h; Quellenvorrang LAN vor Cloud mit Sicherungsschalter (3 Fehlversuche oder 3 s) und der Regel 'bei Widerspruch gewinnt die Cloud'; Verlegungserkennung ausschliesslich ueber gleiche, nicht leere pid; Doppelempfangserkennung ueber dv; keine Abhaengigkeit auf registry oder matching.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/fremdstore.js

Warum: Fremde Daten duerfen registry.ingest nie erreichen — daran haengt die halbe Fehlerliste (kollidierende deviceIds, vergiftete manual/meta-Tabellen, patient-akte.json, Halte-Puffer mit fremden Uhren).

Pruefung: Ein Test erzwingt, dass fremdstore.js und nachbar.js weder registry noch matching noch einen Adapter per require laden; ein Patient mit gleicher pid in zwei Saelen erzeugt zwei Eintraege plus die Marke 'auch in OP 2'.

### 17. server.js: MSG.FREMD = 'fremd' in model.js ergaenzen, eigener 1-Hz-Zeitgeber fuer ws.broadcast (nur bei ws.clients.size > 0) aus fremdstore; neue lokale Endpunkte GET /api/nachbarn und GET /api/nachbarn/<sid> ueber jsonPrivat + istLokal; Lastbremse, die beim ERSTEN verpassten eigenen Rundruf-Takt alle Nachbarfunktionen abschaltet.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/server.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/model.js

Warum: Der 350-ms-Rundruf des eigenen Saals darf durch fremde Daten nie verzoegert werden; ein eigener Zeitgeber und eine sofort greifende Bremse sind die Zusage aus Randbedingung 6.

Pruefung: Mit fuenf simulierten Nachbarn bleibt der Abstand der MSG.PATIENTS-Nachrichten unter 400 ms; wird kuenstlich blockiert, verschwindet MSG.FREMD und im Log steht die Begruendung.

### 18. ui/vetstation-nachbarn.js (NEU) und ui/index.html: Behaelter #vsxNachbarn mit FESTER Hoehe, standardmaessig eingeklappt (Zustand in localStorage), reines DOM mit textContent, Neuzeichnen nur bei geaenderter Signatur, Alter ueber eine eigene Sekundenschleife per CSS-Klasse, Schloss und 'Nur Ansicht', keine Eingabeelemente, keine iframes, keine Kurven. In ui/vetstation-live.js nur die Weitergabe des neuen WS-Zweigs und state.fremd; PDF-station() von der Konstante 'VetStation' auf Saalname + sid-Kurzform.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/ui/vetstation-nachbarn.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/ui/index.html, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/ui/vetstation-live.js

Warum: #vsxGrid ist position:fixed mit bottom:0 und grid-auto-rows:1fr — jede von fremden Daten ausgeloeste Hoehenaenderung bricht alle Patienten-iframes neu um.

Pruefung: Von Hand: erscheint und verschwindet ein Nachbarsaal, aendert sich die Groesse der eigenen Fenster NICHT; die Kachelreihe wird bei unveraenderten Werten nicht neu gebaut (Zaehler im Diagnoselog).

### 19. Web-App umbauen (Feld oberflaechen im Wortlaut): saele/selSaal/patientsSaal, Abbildungen je sid fuer lastRecv und Laufzeit, Tafel-Abo, waehleSaal() mit off(), Ruecksetzen von istVals/__liveSig/__liveAlarmSig/mirror beim Wechsel samt Rueckfrage mit beiden Tieren, Saalname in jedem rechnenden Bereich, keine saaluebergreifende pri-Automatik, zwei Altersanzeigen mit 12/60-s-Schwellen und 'Stand vor X min', protokoll[sid|pid] mit echtem Abbau, Druckkopf je Saal, Zwei-Saal-Verlauf bei Verlegung, Pseudo-Saal '__flach' fuer 1.0.3, handleSnapshot loeschen, esc() auch fuer data-k und data-sid, CSS .vetlive-saele/.vetlive-saal.

Dateien: C:/Users/akhme/Desktop/Manu/canis-vetpharm/canis-anaesthesie/index.html

Warum: Ohne das Ruecksetzen beim Saalwechsel stehen Messwerte des Tiers aus OP 1 unter dem Namen des Tiers in OP 2 und gehen in Dosis und Beatmungsempfehlung ein; ohne Abbildungen je sid haelt ein laufender Saal einen ausgefallenen frisch.

Pruefung: Mit zwei Demo-Saelen: nach dem Wechsel von einem Patienten mit Temperatursonde auf einen ohne steht bei Temp ein '–' und keine Zahl; wird der Datenstrom eines Saals gestoppt, meldet NUR dessen Karte nach 12 s gelb und nach 60 s 'offline', der andere bleibt live.

### 20. Firestore-Verlauf um sid und saal erweitern (cloud.js:782-791) und istVerlauf() in installer/firestore-rules.txt um beide Pflichtfelder mit Groessengrenze ergaenzen. Dazu diagnose.js: ZWEITE_STATION (Z.129-148) neu formulieren ('zwei Stationen im selben Konto sind vorgesehen — nur DASSELBE Geraet darf nicht an zwei Stationen senden') und neuer Befund STATIONSKENNUNG_DOPPELT. devices.example.json: Block nachbarn {enabled, port:8771, taktMs:250, leseart:'sse'}, cloud.tafelTaktMs (1000), cloud.spiegel (true), cloud.budgetMbMonat, und der ausdrueckliche Hinweis, dass cloud.station je PC verschieden sein MUSS.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/cloud.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/installer/firestore-rules.txt, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/diagnose.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/config/devices.example.json

Warum: Der Verlauf ist heute keinem Saal zuordenbar (station ist Freitext und lautet ueberall 'Praxis OP 1'), und der heutige Diagnosetext erklaert den gewuenschten Mehrplatzbetrieb zum Fehler.

Pruefung: tools/regeln-test.js prueft die beiden neuen Pflichtfelder; ein Archiv-POST ohne sid wird von der Regel abgewiesen; tools/paket-test.js findet den neuen Konfigblock in der Vorlage.

### 21. STUFE 2, LAN: bridge/src/nachbar.js (NEU) mit GET-only-Server auf 8771, Bindung je RFC1918-Adresse, Pruefung der Absenderadresse gegen das gebundene /24, Handschlag hallo/hallo2/beweis mit Ed25519 ueber 'vetstation-verbund-2|uid8|nonceA|nonceB|sidA|sidB|epkA|epkB' und X25519+HKDF+AES-256-GCM fuer alle folgenden Rahmen, Weissliste der Nachrichtentypen, harte Deckel (8 Verbindungen, 2 je IP, 2 s Handschlagfrist, 64 KB je Zeile, 15 min bis zur Neuauthentisierung, Rahmen bei Gegendruck verwerfen), 404 ohne gueltige Signatur; Client-Seite mit genau EINER offenen Anfrage ueber alle Nachbarn, Pinning in bridge/data/nachbarn.json, Pruefung sid/instanz und Filtern eigener Adressen; verbund/lan/<sid> schreiben und lesen; Ed25519-Signatur auf tafel/<sid>/meta.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/nachbar.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/cloud.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/data/nachbarn.json

Warum: LAN bringt Unabhaengigkeit von Internet und Freikontingent. Er kommt zuletzt, weil 13 der geprueften Befunde ausschliesslich an ihm haengen und der Firebase-Weg den Auftrag allein erfuellt.

Pruefung: tools/nachbar-test.js (Schritt 22) gruen; von Hand mit zwei PCs: der Streifen zeigt 'ueber LAN', und beim Ziehen des Internetkabels bleibt er es.

### 22. Firewall und Abschluss: installer/set-firewall.ps1 bekommt $STATION_PORTS = @(8771) mit dem Regelnamen 'VetStation Nachbarsaal TCP 8771', angelegt mit -Profile Private,Domain -RemoteAddress LocalSubnet, idempotent und im Zweig -Entfernen mitgeraeumt; bridge/src/firewall.js wird auf pruefe(ports, prefix) parametrisiert und die Startpruefung in index.js:143-154 nimmt 8771 auf; tools/paket-test.js:161-188 bleibt fuer DATA_PORTS unveraendert und bekommt einen ZWEITEN Block, der erzwingt, dass 8771 NICHT in netscan.DATA_PORTS steht und dass keine Regel mit -Profile Any oder ohne -RemoteAddress angelegt wird; tools/nachbar-test.js (NEU); docs/MEHRERE-SAELE.md (NEU) und docs/LAN-SETUP.md um Port 8771 und den Satz zum Hausnetz erweitern.

Dateien: C:/Users/akhme/Desktop/Manu/VetStation/quellcode/installer/set-firewall.ps1, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/bridge/src/firewall.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/paket-test.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/tools/nachbar-test.js, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/docs/MEHRERE-SAELE.md, C:/Users/akhme/Desktop/Manu/VetStation/quellcode/docs/LAN-SETUP.md

Warum: set-firewall.ps1 ist die einzige Stelle, die alle Installationswege benutzen und die bei der Deinstallation aufraeumt; eine fehlende Freigabe laesst Windows die Daten LAUTLOS verwerfen. Ohne die Anpassung von paket-test.js schlaegt die Testreihe fehl und es darf laut alle-tests.js:90 kein Setup gebaut werden.

Pruefung: node tools/alle-tests.js endet mit 0 Fehlern; FIREWALL-FREIGEBEN.bat zweimal ausgefuehrt ergibt genau eine Regel je Port; die 8771-Regel zeigt in Get-NetFirewallRule Profile Private,Domain und RemoteAddress LocalSubnet.

## Tests

- tools/regeln-test.js (NEU) — schliesst die heute vollstaendig ungepruefte Regeldatei: kein .write auf $praxis, '!data.exists()' im .write BEIDER Protokolltiefen, sv === now, Laengengrenze auf jedem neuen String-Blatt, Wurzel fail-closed, sid/saal als Pflichtfelder in istVerlauf().
- tools/regel-messung.js (NEU, einmalig, gegen ein Wegwerf-Konto) — beantwortet die vier ungemessenen Semantikfragen (Vorfahren-.validate, .validate bei null, DELETE auf eine Protokollzeile, Entziehbarkeit eines oben erteilten .write) und schreibt das Ergebnis als Kommentar in die Regeldatei.
- tools/lokal-sicherheit-test.js (NEU) — WS-Upgrade mit fremder Origin scheitert; setMeta ohne Einmal-Kennwort bleibt wirkungslos; die fuenf Patienten-Endpunkte tragen keine ACAO-Kopfzeile; GET /api/update/apply gibt 405; POST /api/praxis/token ohne X-VetStation gibt 403.
- tools/stationsid-test.js (NEU) — Stabilitaet der sid, Formatsperre einschliesslich '..' und '/', 'die Datei gewinnt' bei nicht lesbarer MachineGuid, Ed25519-Signatur ueber die Verbundzeichenkette, encodeURIComponent im Pfad.
- tools/tafel-test.js (NEU, pur) — altMs als Dauer aus seitMs, genau ein null-Pfad je verschwundenem Patienten, Kuerzung und Zeichenfilter jedes Textfelds, dv mit hoechstens zwei Eintraegen.
- tools/zwei-stationen-test.js (NEU) — zwei echte Bridge-Prozesse, dieselbe localId, verschiedene sid: kein Pfad mit fremder sid, nie ein Top-Level-'patients', beide Saele nach drei Vollbildern vollstaendig, gleicher patientKey bleibt getrennt, abgelehnte Protokollzeile laesst Vitalwerte durch und schaltet nichts ab, doppelte sid warnt ohne Umbenennung und ohne Schreibstopp, Neustart sendet keine alten Protokollzeilen.
- tools/altbestand-test.js (NEU) — simulierte 1.0.3-Station: die neue Station schreibt daraufhin nichts flach; ohne sie sind alle flachen patients-Schluessel praefixiert; nie ein null auf einen unpraefixierten Schluessel bei fremdem frischem meta; das Vollbild der 1.0.3-Station laesst tafel/ und saele/ unberuehrt.
- tools/nachbar-test.js (NEU) — Handschlag gut/falsch/wiederabgespielt/an eine dritte Station weitergereicht (muss scheitern, weil beide fluechtigen Schluessel mitsigniert sind), 405 fuer alles ausser GET, 404 ohne Signatur, kein Upgrade-Handler, Bindung nicht auf 0.0.0.0, Absenderadresse ausserhalb des gebundenen /24 abgewiesen, alle Deckel greifen, und nachbar.js/fremdstore.js laden weder registry noch matching noch einen Adapter.
- tools/cloud-test.js (ERWEITERT) — neuer Block: Publisher mit vorhandener protokoll.json sendet im ERSTEN Schreibvorgang keinen protokoll-Pfad; ein mit 503 abgelehnter Protokollstapel wird erneut versucht, ein mit PERMISSION_DENIED abgelehnter nicht; nach einem Schreibfehler enthaelt der naechste erfolgreiche Schreibvorgang die Kurve erneut; ein dauerhaft mit 400 antwortender Nebenpfad laesst started true und den saele-Strom unberuehrt.
- tools/paket-test.js (ERWEITERT) — zweiter Block fuer $STATION_PORTS: 8771 ist NICHT in netscan.DATA_PORTS, die 8771-Regel wird mit -Profile Private,Domain -RemoteAddress LocalSubnet angelegt, und keine Regel wird ohne RemoteAddress mit -Profile Any erzeugt.
- tools/fern-durchsatz-test.js (ERWEITERT) — misst die neuen Groessen getrennt: Bytes je Sekunde fuer saele, tafel und Spiegel, damit die Kontingentrechnung nachpruefbar bleibt statt geschaetzt.

## Offene Fragen

- Firebase-Tarif: Bleiben wir im kostenlosen Spark-Tarif oder wechseln wir auf Blaze mit einer festen Budgetgrenze? Rechnung: 2 Saele mit offener Fern-Ansicht ~1,2 GB/Monat von 10 GB — unproblematisch. 5 Saele, bei denen sich die Stationen ueber die Cloud gegenseitig sehen, landen bei etwa 10-14 GB und reissen das Kontingent; im Dauerbetrieb schon bei 3-4 Saelen. Dazu zwei projektweite Grenzen, die ALLE Praxen gemeinsam treffen: 1 GB Speicher und rund 100 gleichzeitige Datenbankverbindungen. Ohne Blaze gilt: entweder der LAN-Weg (Stufe 2) traegt den Stations-zu-Stations-Verkehr, oder der Nachbarstreifen auf dem Kiosk bleibt bei mehr als vier Saelen aus. Mit Blaze und Budgetdeckel kostet ein Ueberschreiten Geld statt Verfuegbarkeit.
- Adresse der Fern-Ansicht: Soll sie von quziboevmanuchehr.github.io auf einen EIGENEN Ursprung (vet-station.web.app) umziehen? Bei github.io teilen alle Repositorien eines Kontos denselben Browser-Ursprung — dort tippt der Tierarzt Praxis-Mail und Passwort ein, und die Anmeldung hat Schreibrecht auf den ganzen Live-Baum. Die Umschaltung ist im Code bereits vorgesehen (index.html:2601-2603), aber der veroeffentlichte Link aendert sich, und cloud.js:237-239 muss mit.
- Geraeteports 3502/4601/8830/5000/24105/2575: Sollen ihre Firewallregeln von -Profile Any (auch oeffentliches Profil, ohne Adressgrenze) auf -Profile Private,Domain mit -RemoteAddress auf das Geraetesubnetz eingeengt werden? Heute kann jedes Geraet im Praxis- oder Gast-WLAN gefaelschte Vitalwerte in die Registry einspeisen. Die Aenderung liegt ausschliesslich in installer/set-firewall.ps1, beruehrt also keinen Adapter — sie kann aber eine bestehende Praxis lahmlegen, deren Monitore in einem anderen Netz haengen. Deshalb Ihre Entscheidung.
- Zeitplan LAN: Wird Stufe 2 (Port 8771 mit verschluesseltem Handschlag) direkt nach Stufe 1 gebaut, oder erst nachdem der Firebase-Weg einige Wochen in echten Praxen gelaufen ist? Stufe 1 erfuellt den Auftrag 'beide OP-Saele live sehen' vollstaendig; Stufe 2 bringt Betrieb ohne Internet und ohne Kontingentverbrauch, oeffnet aber erstmals einen Port im Praxisnetz.
- Zweites, NUR LESENDES Praxiskonto fuer die Fern-Ansicht: Soll der Tierarzt zu Hause mit einem eigenen Konto schauen, das kein Schreibrecht hat (Regel '.read' zusaetzlich fuer uids unter live/$praxis/leser/<uid>, '.write' unveraendert nur fuer auth.uid === $praxis)? Heute hat jede offene Web-Sitzung — Privathandy, Tablet am Empfang — volles Schreibrecht auf alle Saele und alle Protokolle. Das kostet je Praxis ein zweites Konto und eine Anmeldung mehr.
- Aufraeumen des Fern-Protokolls: saele/<sid>/protokoll waechst mit etwa 30 MB pro Monat bei fuenf Saelen und wird nie geloescht (die Zeilen sind absichtlich unveraenderlich). Ab welchem Alter darf eine abgeschlossene Narkose aus der Live-Datenbank verschwinden — und ist das Firestore-Archiv (loeschfest per Regel) damit das rechtlich fuehrende Dokument? Ohne Ihre Vorgabe passiert nichts, und die 1-GB-Grenze wird in etwa 32 Monaten erreicht.
- Saalnamen: Reicht es, wenn eine Station ohne eigenen Namen automatisch ihren Rechnernamen benutzt und im Admin-Bereich rot nach einem echten Namen fragt — oder soll sie ihre Daten erst dann fern veroeffentlichen, wenn ein Mensch den Saal benannt hat? Heute existiert keine devices.json, also heisst JEDE ausgelieferte Station 'Praxis OP 1'.

## Verworfen

- Aus A: der Besitzer-Anspruch per ETag/if-match auf stationen/<sid>/besitzer. Ein fremdes 'inst' in diesem Knoten — schreibbar von jedem Kontomitglied, also auch von einem ausgemusterten PC mit kopierter data/cloud-auth.json — zwingt die rechtmaessige Station zur Selbstumbenennung und zum Schreibstopp, und zwar unsichtbar, weil der Kiosk vor Ort normal weiterlaeuft. Ersetzt durch: Einzelinstanz-Sperre, positiver Kollisionsbeweis ueber ein selbst geschriebenes probe-Feld, und Umbenennen ausschliesslich von Hand.
- Aus A: die Spiegelwahl 'kleinste sid mit frischem tafel-sv'. Wer tafel/aaaaaaaaaaaa mit frischem sv schreibt, wird alleiniger Schreiber der alten flachen Ebene, und JEDE echte Station schaltet ihren Spiegel korrekt ab, ohne etwas zu bemerken. Ersetzt durch: kein Spiegel-Besitzer, jede Station spiegelt nur ihre eigenen Patienten unter praefixierten Schluesseln und schreibt identische Konstanten in die gemeinsamen meta-Felder.
- Aus A: den LAN-Schluessel als gemeinsames Geheimnis in tafel/<sid>/lan.geheim. Er liegt damit in genau dem Knoten, den jede Web-Ansicht per Dauerabonnement in den Browser laedt — ein Vorfall am Privathandy waere ein bis 24 h gueltiger Lesezugang in das Praxisnetz geworden, den ein Passwortwechsel nicht beseitigt. Ersetzt durch Ed25519: der oeffentliche Schluessel darf im Baum stehen, der private verlaesst den PC nie, und die LAN-Adressen liegen unter verbund/lan, das die Web-App gar nicht abonniert.
- Aus A: das relative Feld 'age' (Alter in Millisekunden) im Delta-Speicher. In einem Delta-Verfahren friert eine solche Zahl ein, sobald sich am Patienten nichts mehr aendert, und ein Uhrensprung macht sie negativ oder minutenalt. Ersetzt durch: altMs wird zusammen mit dem ganzen Uebersichtsobjekt jede Sekunde neu geschrieben, und der Leser rechnet altMs + (Serverzeit - sv).
- Aus B: die Sprecher-Pacht in /live/<uid>/verbund/sprecher mit der Frist in .validate. Sie ist kein serverseitiges Vergleiche-und-Setze: wer statt des Knotens nur dessen Kinder schreibt, umgeht die Bedingung, und zwei Zwillinge mit derselben sid duerfen beide erneuern, weil die Regel nur die sid vergleicht. Das Ergebnis waere genau das Ueberschreib- und Flackerproblem, dessen Beseitigung der Umbau bezweckt, nur eine Ebene hoeher. Ersetzt durch: es gibt keine Rolle, die verteilt werden muesste.
- Aus B: der UDP-Beacon auf Broadcast und Multicast 239.255.77.71. Er braeuchte eine neue UDP-Firewallregel, das Projekt enthaelt bis heute kein dgram, er kann nichts beweisen (geprueft wird ohnehin erst im TCP-Handschlag), und er wuerde auf dem isolierten Geraetenetz dauerhaft an Monitor und LifeVet vorbeisenden — in einer Einzelplatz-Praxis fuer immer und ohne jeden Nutzen. Ersetzt durch: Treffpunkt ueber den Kontobaum, gemerkte Adressen, und ein gezieltes Anklopfen nur bei mehr als einem Tafeleintrag.
- Aus B: die Signaturfolge hallo/hallo2 mit sofortiger Signatur der antwortenden Seite. Sie ist ein Signier-Orakel: der Angreifer laesst sich vom echten Nachbarn genau die Bytes signieren, die eine dritte Station sehen will, und braucht dafuer kein einziges Zugangsdatum. Ersetzt durch: fluechtige X25519-Schluessel beider Seiten IN der Signatur und AES-256-GCM fuer alle folgenden Rahmen — ein Weiterreicher kann dann keinen gemeinsamen Schluessel erzeugen.
- Aus B: saalKurz als Praefix der Spiegelschluessel. Es ist aus dem Freitext cloud.station abgeleitet, und weil keine devices.json existiert, ergaeben zwei frische Installationen beide 'op1' — die Kollision, die der Umbau beseitigen soll, kaeme im unveraenderlichen flachen Protokoll zurueck. Ersetzt durch das Praefix s<sid6> aus der Stationskennung; der Saalname bleibt reine Anzeige im patientName.
- Aus C: die drei Spiegelmodi M1/M2/M3 mit Hysterese. M1 schreibt 'exakt wie 1.0.3', also mit dem Top-Level-Schluessel 'patients' — und weil beim Start noch kein Tafel-Ereignis gelesen ist, gilt M1 in genau der Sekunde, in der er die Spiegeleintraege aller anderen Saele loescht. Der Uebergang M1->M3 setzte zusaetzlich ein null auf einen unpraefixierten Schluessel, den eine 1.0.3-Station teilen kann. Ersetzt durch: F0 schreibt gar nichts flach, es wird immer praefixiert geschrieben, und der Top-Level-Schluessel 'patients' verschwindet ersatzlos aus dem Code.
- Aus C: die Alterserkennung 'eigenes letztes sv minus fremdes sv'. Steht der eigene Schreibweg (Backoff bis 60 s), waechst die Differenz nicht mehr, und ein toter OP-Saal steht mit seinen letzten Vitalwerten als 'vor 0 s' auf jedem anderen Bildschirm. Ersetzt durch die Serverzeit aus dem HTTP-Date-Kopf bzw. .info/serverTimeOffset — sie haengt an keiner Schreibleitung.
- Aus C: die Zufallszahl vom Server im LAN-Handschlag samt Nonce-Vorrat. Der Client kann damit keine Frische pruefen (die Zahl kommt von dem, den er pruefen will), ein Mitschnitt ist beliebig oft wiedereinspielbar, und der Vorrat von 200 Eintraegen laesst sich von jedem im Netz ohne Anmeldung erschoepfen. Ersetzt durch: der Client bringt seine eigene Zufallszahl mit, der Server haelt keinen Zustand.
- Aus C: die automatische Selbstumbenennung bei erkannter Kollision samt Loeschen des alten Tafelknotens. Sie hat vier belegte Fehlwege — Doppelstart, fremdschreibbares instanz-Feld, Wettlauf mit Geistersaal, und ein in zwei unveraenderliche Zweige zerschnittenes Narkoseprotokoll. Ersetzt durch: warnen, weiterschreiben, und einen Knopf fuer den Menschen.
- Aus allen drei Entwuerfen: das Beibehalten von '.write' auf /live/$praxis. Es kaskadiert nach unten und ist tiefer nicht entziehbar, und .validate wird bei Loeschungen nicht ausgewertet — die Unveraenderlichkeit des Narkoseprotokolls, auf die sich alle drei Entwuerfe an mehreren Stellen ausdruecklich berufen, existiert damit nicht. Ersetzt durch Schreibrechte je Teilbaum und '!data.exists() && newData.exists()' im .write beider Protokolltiefen.
- Bewusst getragene Restrisiken, ausdruecklich benannt und nicht geloest: (1) Innerhalb EINES Praxiskontos kann keine Regel einen Schreiber an eine sid binden — eine kopierte data/cloud-auth.json ist dauerhaft eine vollwertige Station und kann fremde Saalzweige beschreiben oder loeschen; Gegenmittel waeren Stationskonten oder ein Server-Anteil, beides schliesst die Vorgabe 'eine Praxis, ein Konto' aus. Abgemildert durch sid-Bindung im Datensatz, gepinnte Nachbarschluessel und die signierte tafel-meta in Stufe 2. (2) Die ausgelieferte Web-App kann den Ausfall eines EINZELNEN Saals nicht erkennen (ein gemeinsames lastRecv) und zeigt im Mehr-Saal-Betrieb keinen Verlauf und keine Kurven; reparierbar nur durch ein Neuladen der Seite. (3) Eine im Feld stehende 1.0.3-Station behaelt den nachgeprueften Protokoll-Nachsende-Fehler, bis sie aktualisiert wird. (4) Solange eine 1.0.3-Station im Konto laeuft, zeigt die alte Fern-Ansicht nur diesen einen Saal. (5) Der Kontingentdeckel des gemeinsamen Firebase-Projekts bleibt ein Verfuegbarkeitsrisiko fuer alle Praxen; abgemildert durch Groessengrenzen in den Regeln, den Budgetwaechter und die Regel, dass Kontingentfehler nie zur Selbstabschaltung fuehren. (6) Ohne einen Online-Moment gibt es im LAN keinen Vertrauensanker; dann bleibt nur die Handbestaetigung der Fingerabdruecke. (7) bridge/data/protokoll.json und patient-akte.json bleiben je PC lokal; ein verlegter Patient hat seine Papierspur auf zwei Rechnern, zusammengefuehrt wird nur das Druckblatt.
