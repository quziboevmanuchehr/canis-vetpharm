/*
 * brain.js — DAS "Brain" (Kreuz-Analyse), 1:1 portiert aus der Web-App (renderAssess, monAlarms).
 * Bekommt einen zusammengefuehrten Patienten mit LIVE-Vitalwerten und liefert priorisierte
 * Zwischenfaelle (Sofortmassnahme + Geraete-Korrektur + verknuepfter Zwischenfall fuer die Injektion).
 * Quelle: D:\canis-public\canis-anaesthesie\index.html (renderAssess ~Z.931, monAlarms ~Z.875).
 * Regeln R1..R6 exakt wie im Original; nur die Datenquelle ist live statt manuell.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./device-target'));
  else { root.VS = root.VS || {}; root.VS.brain = factory(root.VS.deviceTarget); }
})(typeof self !== 'undefined' ? self : this, function (deviceTarget) {
  'use strict';

  var BRADY_RHYTHMS = ['sinusbrady', 'avb2a', 'avb2b', 'avb3'];

  function bandsFor(ANAES, sp) {
    return (ANAES.vitals && (ANAES.vitals[sp] || ANAES.vitals.hund)) || {
      hr: [60, 140], rr: [8, 20], spo2: [95, 100], etco2: [30, 55],
      map: [70, 120], nibp: [90, 160], dia: [55, 100], temp: [37.5, 39.2],
    };
  }
  function ekgFlags(ANAES, id) {
    var e = (ANAES.ekg || []).find(function (r) { return r.id === id; });
    return (e && e.w) || {};
  }

  /*
   * Einzelwert-Scan (Teil A): welche Parameter liegen ausserhalb des artspezifischen Normbands.
   *
   * fehlt[] ERGAENZT 22.07.2026: Bisher wurde ein fehlender Messwert einfach uebersprungen. Von
   * aussen war danach nicht mehr unterscheidbar, ob ein Wert IM NORMBEREICH lag oder ob er GAR
   * NICHT VORLAG - beides ergab "keine Auffaelligkeit". Am Praxis-PC fuehrte genau das dazu, dass
   * ein Patient ohne einen einzigen Messwert gruen als "stabil" ausgewiesen wurde. Wer fehlt,
   * wird jetzt benannt; die Bewertung selbst bleibt unveraendert.
   */
  function singleScan(ANAES, patient, v, fehltOut) {
    var wgt = { spo2: 6, etco2: 5, nibp: 5, hr: 4, rr: 3, temp: 2 };
    var params = (ANAES.monitor && ANAES.monitor.params) || [];
    var out = [];
    var fehlt = fehltOut || [];
    params.forEach(function (p) {
      var band = v[p.vital];
      if (!band) return;
      var x = p.id === 'nibp' ? patient.map : (p.id === 'rr' ? patient.af : patient[p.id]);
      if (x == null) { fehlt.push({ id: p.id, name: p.name || p.id }); return; }
      var dir = null, inc = null, far = 0;
      if ((p.id === 'hr' || p.id === 'nibp') && x <= 0) { dir = 'crit'; inc = p.id === 'hr' ? 'asystolie' : p.lowInc; far = 1; }
      else if (x < band[0]) { dir = 'low'; inc = p.lowInc; far = (band[0] - x) / (band[0] || 1); }
      else if (x > band[1]) { dir = 'high'; inc = p.highInc; far = (x - band[1]) / (band[1] || 1); }
      else return;
      out.push({
        id: p.id, abbr: p.abbr || p.id, name: p.name || p.id, unit: p.unit || '',
        value: x, band: band, dir: dir, incident: inc || null,
        score: (wgt[p.id] || 1) * (1 + far),
      });
    });
    out.sort(function (a, b) { return b.score - a.score; });
    return out;
  }

  // Kreuz-Analyse (Teil B): Regeln R1..R6.
  function crossScan(ANAES, patient, v, sp, wt, iso) {
    var cross = [];
    function xc(sev, color, title, tag, cause, fix, inc) { cross.push({ sev: sev, color: color, title: title, tag: tag, cause: cause, fix: fix, incident: inc }); }

    var hr = patient.hr, spo2 = patient.spo2, etco2 = patient.etco2, map = patient.map;
    var ekg = patient.ekgRhythm || 'sinus', capno = patient.capnoShape;
    var W = ekgFlags(ANAES, ekg);
    var brady = (hr > 0 && hr < v.hr[0]) || BRADY_RHYTHMS.indexOf(ekg) >= 0;
    var driven = (spo2 != null && spo2 < v.spo2[0]) || (etco2 != null && etco2 > v.etco2[1]);
    var isoHi = deviceTarget ? deviceTarget.isoHigh(ANAES, sp, wt, iso) : false;

    // R1 — Kreislaufstillstand (Asystolie / Kammerflimmern)
    if (W.flat || W.chaos) {
      xc(5, '#ff4d4d',
        W.chaos ? 'Kammerflimmern – Kreislaufstillstand' : 'Asystolie – Kreislaufstillstand', 'CPR',
        'Flaches/chaotisches EKG mit flachem Kapno & Pleth → kein Kreislauf.',
        'Verdampfer auf 0 · 100 % O₂/Flush · Thoraxkompression 100–120/min' + (W.chaos ? ' · DEFIBRILLIEREN' : ''),
        'asystolie');
    } else if (ekg === 'ves' || ekg === 'vtach') {
      // R2/R3 — ventrikulaere Ektopie
      if (driven) {
        xc(4, '#ff9d3c', (ekg === 'vtach' ? 'VT' : 'VES') + ' – hypoxie-/hyperkapniegetrieben', 'Erst O₂/Beatmung',
          'Breite QRS bei niedrigem SpO₂ / hohem EtCO₂ → zuerst ventilieren, nicht antiarrhythmisch.',
          'IPPV/Auto an, O₂ ↑/Flush; Lidocain (Hund) erst danach.', 'tachykardie');
      } else {
        xc(4, '#ff7b7b', (ekg === 'vtach' ? 'Ventrikuläre Tachykardie' : 'Ventrikuläre Extrasystolen'), 'VES/VT',
          'Breite, vorzeitige QRS ohne P. Zuerst Hypoxie/Hyperkapnie/Narkosetiefe/Elektrolyte ausschließen.',
          'Oxygenierung & Narkosetiefe sichern, dann Lidocain (Hund) langsam IV; Katze extrem vorsichtig.', 'tachykardie');
      }
    }

    // R4/R5 — Bradykardie/Hypotonie bei zu tiefer Narkose
    if (brady && isoHi && map > 0 && map < v.map[0] + 8) {
      xc(4, '#ffb03c', 'Bradykardie bei zu tiefer Narkose', 'Iso zuerst senken',
        'Niedrige HF + niedriger MAP + hoher Verdampfer → Narkose zu tief.',
        'Verdampfer Richtung Soll SENKEN – NICHT reflexartig Atropin.', 'bradykardie');
    } else if (map > 0 && map < v.map[0] && isoHi) {
      xc(3, '#ff8c3c', 'Hypotonie bei tiefer Narkose', 'MAP ↓',
        'MAP niedrig bei hohem Verdampfer → häufigste Ursache: zu tief.',
        'Verdampfer zuerst senken, dann Volumenbolus, dann Ephedrin.', 'hypotension');
    }

    // R6 — Bronchospasmus (Kapno-Haifischflosse). Nur moeglich, weil das Live-Frame capnoShape traegt.
    if (capno === 'shark') {
      xc(3, '#a3e635', 'Bronchospasmus / Obstruktion', 'Atemweg',
        'Kapno-Haifischflosse bei intaktem EKG → Problem ist der Atemweg, nicht das Herz.',
        'Tubus prüfen (Knick/Sekret), ggf. vertiefen; β2-Bronchodilatator; O₂ 100 %.', 'hypoxaemie');
    }

    cross.sort(function (a, b) { return b.sev - a.sev; });
    return cross;
  }

  // Alarme pro Kanal (fuer die Kachel-Faerbung) — aus monAlarms.
  function alarms(ANAES, patient) {
    var v = bandsFor(ANAES, patient.species);
    function o(x, b) { return x != null && (x < b[0] || x > b[1]); }
    return {
      hr: patient.hr != null && (patient.hr === 0 || o(patient.hr, v.hr)),
      spo2: patient.spo2 != null && patient.spo2 < v.spo2[0],
      etco2: patient.etco2 != null && (patient.etco2 === 0 || patient.etco2 < v.etco2[0] || patient.etco2 > v.etco2[1]),
      nibp: patient.map != null && (patient.map === 0 || patient.map < v.map[0]),
      rr: patient.af != null && (patient.af === 0 || patient.af < v.rr[0] || patient.af > v.rr[1]),
      temp: o(patient.temp, v.temp),
    };
  }

  // Hauptfunktion: vollstaendige Bewertung eines Patienten.
  function assess(ANAES, patient, opts) {
    opts = opts || {};
    /*
     * ANNAHMEN OFFENLEGEN (22.07.2026).
     * Die beiden folgenden Zeilen sind seit jeher stille Ersatzwerte: fehlt die Tierart, rechnet
     * die Station als HUND, fehlt das Gewicht, mit 10 kg. Aus dem Gewicht folgen die
     * Injektionsmengen in mL. Am Praxis-PC lieferte das Geraet weder Tierart noch Gewicht - die
     * Oberflaeche zeigte trotzdem Mengen an, ohne dass irgendwo stand, worauf sie beruhen.
     * Die Ersatzwerte BLEIBEN (sonst koennte die Regelpruefung gar nicht laufen), aber sie werden
     * ab jetzt mitgeliefert und in der Anzeige gekennzeichnet.
     */
    var sp = patient.species || 'hund';
    var wt = patient.weightKg || 10;
    var annahmen = {
      species: patient.species ? 'gemeldet' : 'ersatz',
      weightKg: patient.weightKg ? 'gemeldet' : 'ersatz',
    };
    var iso = opts.iso != null ? opts.iso : patient.isoPct;
    var v = bandsFor(ANAES, sp);
    var fehlt = [];
    var single = singleScan(ANAES, patient, v, fehlt);
    var cross = crossScan(ANAES, patient, v, sp, wt, iso);
    var al = alarms(ANAES, patient);
    var alarmCount = Object.keys(al).filter(function (k) { return al[k]; }).length;
    // Prioritaet fuer Sortierung "gefaehrlichste Warnung nach oben" (§6.4).
    var priority = cross.length ? cross[0].sev * 2 : (single.length ? Math.min(4, 1 + single[0].score / 4) : 0);
    /*
     * EMPFEHLUNG AUCH OHNE NARKOSEGERAET (Befund 22.07.2026).
     *
     * Die Kreuzregeln R4/R5 setzen isoHi voraus - also die Verdampfer-Einstellung. Die liefert ein
     * MONITOR aber gar nicht; sie kommt nur von einem Narkosegeraet oder aus der Handeingabe.
     * Haengt also - wie in der Praxis ueblich - nur der Monitor an der Station, feuerte KEINE
     * einzige Kreuzregel, und der Einzelwert-Befund trug ein leeres fix: der Tierarzt sah
     * "Blutdruck zu niedrig" und sonst nichts. Genau das war mit "es muss Empfehlungen zur
     * Stabilisierung geben" gemeint.
     *
     * Die Inhalte dafuer liegen laengst in der Wissensbasis (ANAES.incidents): machine = konkrete
     * Geraetekorrektur, steps = Sofortmassnahmen in Reihenfolge, drugs = Wirkstoffe (die mL-Menge
     * rechnet die Oberflaeche daraus mit dose.injectionsFor). Sie werden hier NUR angehaengt -
     * es wird nichts Neues erfunden und keine Schwelle veraendert.
     */
    var inc0 = single[0] && single[0].incident
      ? (ANAES.incidents || []).filter(function (i) { return i.id === single[0].incident; })[0]
      : null;
    var top = cross[0] || (single[0] ? {
      sev: 2, color: '#ff8c3c',
      title: single[0].name + ' ' + (single[0].dir === 'high' ? 'zu hoch' : single[0].dir === 'crit' ? 'kritisch' : 'zu niedrig'),
      tag: single[0].abbr, cause: 'Einzelwert ausserhalb Normbereich (' + single[0].value + ' ' + single[0].unit + ').',
      // Sofortmassnahme = erster Schritt aus der Wissensbasis; Geraete-Korrektur separat.
      fix: (inc0 && inc0.steps && inc0.steps[0]) || '',
      geraet: (inc0 && inc0.machine) || '',
      schritte: (inc0 && inc0.steps) ? inc0.steps.slice(0, 6) : [],
      incident: single[0].incident,
    } : null);
    /*
     * keineDaten: KEIN einziger ueberwachter Messwert liegt an.
     * Ohne dieses Flag ist "alles im Normbereich" von "es kommt gar nichts" nicht zu unterscheiden -
     * und die Oberflaeche meldete beides gleich: gruen, "stabil". Das ist die gefaehrlichste
     * Falschaussage, die diese Station machen kann, und sie ist genau am 22.07.2026 aufgetreten.
     */
    var vorhanden = 0;
    ['hr', 'spo2', 'etco2', 'af', 'temp', 'map'].forEach(function (k) { if (patient[k] != null) vorhanden++; });
    return {
      cross: cross, single: single, alarms: al, alarmCount: alarmCount,
      priority: priority, top: top, bands: v,
      // Neu, rein additiv - bestehende Felder bleiben unveraendert (Tests sichern sie zu).
      fehlt: fehlt, werteAnzahl: vorhanden, keineDaten: vorhanden === 0, annahmen: annahmen,
    };
  }

  return { assess: assess, alarms: alarms, singleScan: singleScan, crossScan: crossScan, bandsFor: bandsFor };
});
