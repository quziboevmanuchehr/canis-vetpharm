@echo off
title VetStation - Setup.exe bauen
REM ===================================================================================
REM  EIN DOPPELKLICK = fertige, aktuelle VetStation-Setup.exe.
REM
REM  Diese Datei laeuft auf dem ENTWICKLER-PC (dort, wo der Quellcode liegt), nicht in der
REM  Praxis. Sie macht beides hintereinander:
REM    1. installer\make-dist.ps1      -> baut dist\VetStation (App + portables Node)
REM    2. installer\make-setup-exe.ps1 -> schnuert daraus dist\VetStation-Setup.exe (IExpress)
REM
REM  IExpress steckt in jedem Windows. Inno Setup wird NICHT mehr gebraucht - vorher liess sich
REM  die Setup.exe nur damit bauen und war deshalb dauerhaft auf einer alten Version eingefroren.
REM
REM  Ergebnis danach auf USB-Stick kopieren -> am Praxis-PC DOPPELKLICKEN. Mehr ist nicht noetig.
REM ===================================================================================
cd /d "%~dp0"

echo.
echo [1/3] Selbsttests ...
if exist "%~dp0node\node.exe" (
  "%~dp0node\node.exe" tools\alle-tests.js
) else (
  node tools\alle-tests.js
)
if errorlevel 1 (
  echo.
  echo *** ABBRUCH: Die Selbsttests sind FEHLGESCHLAGEN. ***
  echo     Es wird bewusst KEIN Setup gebaut, das bekannte Fehler enthaelt.
  echo.
  pause
  exit /b 1
)

echo.
echo [2/3] Paket bauen (App + portables Node) ...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\make-dist.ps1"
if errorlevel 1 goto fehler

echo.
echo [3/3] Setup.exe schnueren (IExpress) ...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\make-setup-exe.ps1"
if errorlevel 1 goto fehler

echo.
echo [4/4] Bau-Reste aufraeumen ...
if exist "%~dp0dist\_setupbau" rmdir /s /q "%~dp0dist\_setupbau"

echo.
echo ===================================================================
echo   FERTIG. In dist\ liegen jetzt:
echo.
echo     VetStation-Setup.exe   Erstinstallation - auf USB-Stick,
echo                            am Praxis-PC DOPPELKLICKEN.
echo     VetStation-^<ver^>.zip    Update-Paket fuer den In-App-Updater
echo                            (Admin - Aktualisieren). sha256 steht oben.
echo     VetStation-Setup.zip   dasselbe als Ordner-Kopie (ohne Setup.exe)
echo ===================================================================
dir /b "%~dp0dist\*.exe" "%~dp0dist\*.zip"
echo.
pause
exit /b 0

:fehler
echo.
echo *** Der Bau ist fehlgeschlagen - Meldung oben lesen. ***
echo.
pause
exit /b 1
