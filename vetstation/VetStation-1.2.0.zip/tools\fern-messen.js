'use strict';
/*
 * fern-messen.js — Wie schnell geht die Fern-Uebertragung wirklich?
 *
 * WOFUER: "Es soll in Millisekunden ankommen" laesst sich nur beantworten, wenn man es misst.
 * Dieses Werkzeug misst die drei Abschnitte einzeln, damit man SIEHT, wo Zeit verloren geht:
 *
 *   1) Praxis-PC -> Firebase (Belgien)   = die Strecke, die dieser PC verantwortet
 *   2) Sendetakt der Station              = wie oft ueberhaupt geschrieben wird
 *   3) Firebase -> Zuhause                = steht in der Web-App unter "Verbindung & Geschwindigkeit"
 *
 * Punkt 1 und 2 misst dieses Werkzeug. Punkt 3 kann es nicht messen (es laeuft ja auf dem
 * Praxis-PC) - dafuer zeigt die Fern-Ansicht die Zahl selbst an.
 *
 * WICHTIG: Es wird NICHT in den Live-Baum geschrieben. Gemessen wird gegen einen eigenen
 * Messknoten unterhalb des eigenen Praxis-Kontos, damit weder Werte verfaelscht noch fremde
 * Daten beruehrt werden.
 *
 * Start:  GESCHWINDIGKEIT-MESSEN.bat doppelklicken
 *         node tools/fern-messen.js [--runden 20]
 */
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const runden = Math.max(3, Math.min(200, zahlArg('--runden', 15)));

function zahlArg(name, standard) {
  const i = process.argv.indexOf(name);
  if (i < 0) return standard;
  const n = parseInt(process.argv[i + 1], 10);
  return Number.isFinite(n) ? n : standard;
}

function lies(rel) {
  try { return JSON.parse(fs.readFileSync(path.join(ROOT, rel), 'utf8')); } catch (_) { return null; }
}

function req(method, urlString, body, headers) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(urlString); } catch (e) { return reject(new Error('URL ungueltig: ' + e.message)); }
    const lib = u.protocol === 'http:' ? http : https;
    const opts = {
      method, hostname: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443),
      path: u.pathname + u.search,
      headers: Object.assign({ Accept: 'application/json' }, headers || {}),
      timeout: 10000,
    };
    if (body != null) opts.headers['Content-Length'] = Buffer.byteLength(body);
    const r = lib.request(opts, (res) => {
      let d = '';
      res.on('data', (c) => { d += c; });
      res.on('end', () => {
        if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error('HTTP ' + res.statusCode + ': ' + d.slice(0, 160)));
        try { resolve(d ? JSON.parse(d) : {}); } catch (_) { resolve({ raw: d }); }
      });
    });
    r.on('error', reject);
    r.on('timeout', () => r.destroy(new Error('Zeitueberschreitung')));
    if (body != null) r.write(body);
    r.end();
  });
}

function ms(n) { return (Math.round(n * 10) / 10) + ' ms'; }
function auswerten(werte) {
  const s = werte.slice().sort((a, b) => a - b);
  return {
    schnellste: s[0], langsamste: s[s.length - 1],
    mittel: s.reduce((a, b) => a + b, 0) / s.length,
    mitte: s[Math.floor(s.length / 2)],
  };
}

(async function () {
  console.log('VetStation — Geschwindigkeit der Fern-Uebertragung\n');

  // --- Konfiguration + Anmeldung des Praxis-PCs uebernehmen -------------------------------
  const cfg = (lies('bridge/config/devices.json') || lies('bridge/config/devices.example.json') || {}).cloud || {};
  if (!cfg.apiKey || !cfg.dbUrl) {
    console.log('In bridge/config/devices.json fehlt der cloud-Block (apiKey/dbUrl). Nichts zu messen.');
    process.exit(1);
  }
  const authDatei = cfg.authFile || path.join(ROOT, 'data', 'cloud-auth.json');
  let auth = null;
  try { auth = JSON.parse(fs.readFileSync(authDatei, 'utf8')); } catch (_) { /* nicht angemeldet */ }
  if (!auth || !auth.refreshToken || !auth.localId) {
    console.log('Diese Station ist noch nicht angemeldet.');
    console.log('Erst im Admin-Bereich unter "Fern-Live" mit dem Praxis-Konto anmelden, dann erneut messen.');
    process.exit(1);
  }

  process.stdout.write('Melde an … ');
  let idToken;
  try {
    const t = await req('POST', 'https://securetoken.googleapis.com/v1/token?key=' + encodeURIComponent(cfg.apiKey),
      'grant_type=refresh_token&refresh_token=' + encodeURIComponent(auth.refreshToken),
      { 'Content-Type': 'application/x-www-form-urlencoded' });
    idToken = t.id_token;
  } catch (e) {
    console.log('\nAnmeldung fehlgeschlagen: ' + e.message);
    console.log('Im Admin-Bereich unter "Fern-Live" neu anmelden.');
    process.exit(1);
  }
  console.log('ok (Konto ' + (auth.email || auth.localId) + ')\n');

  // --- 1) Strecke Praxis-PC -> Firebase --------------------------------------------------
  // Gemessen wird ein Schreibvorgang derselben Groessenordnung wie ein echtes Delta.
  const basis = String(cfg.dbUrl).replace(/\/+$/, '');
  const messPfad = '/live/' + auth.localId + '/messung.json?auth=' + encodeURIComponent(idToken);
  const probe = { ts: 0, fuellung: 'x'.repeat(400) };

  console.log('Messe ' + runden + " Schreibvorgaenge nach Firebase (wie ein echtes Werte-Paket) …");
  const dauer = [];
  for (let i = 0; i < runden; i++) {
    probe.ts = Date.now();
    const t0 = process.hrtime.bigint();
    try {
      await req('PUT', basis + messPfad, JSON.stringify(probe), { 'Content-Type': 'application/json' });
    } catch (e) {
      console.log('  Schreibvorgang ' + (i + 1) + ' fehlgeschlagen: ' + e.message);
      if (/HTTP 401|PERMISSION_DENIED/.test(e.message)) {
        console.log('\n  -> Die Sicherheitsregeln der Datenbank sind noch nicht veroeffentlicht.');
        console.log('     Inhalt von installer/firebase-rtdb-rules.json in die Firebase-Konsole einfuegen.');
      }
      process.exit(1);
    }
    const d = Number(process.hrtime.bigint() - t0) / 1e6;
    dauer.push(d);
    process.stdout.write('  ' + String(i + 1).padStart(3) + ': ' + ms(d).padStart(9) +
      (i === 0 ? '   (erster Vorgang: hier kommt der Verbindungsaufbau dazu)' : '') + '\n');
  }
  // Messknoten wieder entfernen - er hat im Datenbestand nichts verloren.
  try { await req('DELETE', basis + messPfad, null, {}); } catch (_) {}

  const ohneErsten = dauer.length > 1 ? dauer.slice(1) : dauer;
  const a = auswerten(ohneErsten);
  console.log('\n--- Praxis-PC -> Firebase (ohne den ersten Vorgang) ---');
  console.log('  schnellste ' + ms(a.schnellste) + ' · Mitte ' + ms(a.mitte) + ' · Mittel ' + ms(a.mittel) + ' · langsamste ' + ms(a.langsamste));
  console.log('  Aufbau der ersten Verbindung: ' + ms(dauer[0]) +
    ' — dass die folgenden deutlich schneller sind, ist der Beweis, dass die Dauerverbindung greift.');

  // --- 2) Was die laufende Station tatsaechlich tut ---------------------------------------
  const port = (lies('bridge/config/devices.json') || {}).port || 8770;
  try {
    const st = await req('GET', 'http://127.0.0.1:' + port + '/api/praxis');
    console.log('\n--- laufende Station ---');
    console.log('  Sendetakt eingestellt: ' + (st.taktMs || '?') + ' ms' +
      (st.taktMs ? '  (= bis zu ' + Math.round(1000 / st.taktMs) + " Aktualisierungen je Sekunde)" : ''));
    console.log('  bisher uebertragen:    ' + (st.schreibVorgaenge || 0) + ' Pakete, ' +
      Math.round((st.bytesGesendet || 0) / 1024) + ' KB, ' + (st.protokollGesendet || 0) + ' Protokollzeilen');
    if (st.schreibVorgaenge) {
      console.log('  Durchschnitt je Paket: ' + Math.round((st.bytesGesendet || 0) / st.schreibVorgaenge) +
        ' Byte  (klein = die Delta-Uebertragung arbeitet)');
    }
    console.log('  echte Geraetekurven:   ' + (st.kurven ? 'an' : 'aus'));
    if (st.lastError) console.log('  letzter Fehler:        ' + st.lastError);
  } catch (_) {
    console.log('\n--- laufende Station ---');
    console.log('  VetStation laeuft gerade nicht (oder auf einem anderen Port) — Punkt 2 uebersprungen.');
  }

  // --- 3) Bewertung ----------------------------------------------------------------------
  console.log('\n--- Einordnung ---');
  const m = a.mitte;
  if (m < 120) console.log('  SEHR GUT: unter 120 ms zur Datenbank. Die Werte sind praktisch verzoegerungsfrei fern sichtbar.');
  else if (m < 300) console.log('  GUT: unter 300 ms. Fuer die Fern-Ueberwachung voellig ausreichend.');
  else if (m < 800) console.log('  BRAUCHBAR, aber traege. Pruefen: WLAN statt Kabel? Anderer Datenverkehr auf der Leitung?');
  else console.log('  ZU LANGSAM. Die Internetverbindung der Praxis ist der Engpass, nicht die Software.');
  console.log('\n  Die Strecke Firebase -> Zuhause steht in der Web-App unter');
  console.log('  "📡 Fern-Live" -> "Verbindung & Geschwindigkeit" -> "Laufzeit Praxis -> hier".');
  console.log('  Beide Zahlen zusammen sind die gesamte Verzoegerung.');
  console.log('\n  GROESSTER EINZELFAKTOR bleibt der Sendetakt AM GERAET: liefert der Monitor nur');
  console.log('  alle 30 Sekunden neue Werte, hilft auch die schnellste Leitung nichts.');
})().catch((e) => { console.error('Messung fehlgeschlagen: ' + e.message); process.exit(1); });
