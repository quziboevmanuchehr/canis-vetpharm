<#
  neustart-schnell.ps1 - VetStation neu starten OHNE UAC-Abfrage.

  WOFUER (Befund 23.07.2026): Der uebliche Neustart (NEUSTART.bat -> stop-kiosk.ps1) beendet die
  erhoeht laufende Station und braucht dafuer jedes Mal eine Bestaetigung der Windows-
  Benutzerkontensteuerung (UAC). In der Praxis wurde diese Abfrage oft nicht bestaetigt, und der
  Neustart - und damit ein bereitgestelltes Update - blieb aus.

  Dieser Weg kommt ohne UAC aus: er beendet nur den node-Prozess der Station. Der Watchdog bzw. die
  Autostart-Aufgabe startet die Station daraufhin von selbst neu - mit dem aktuellen Stand auf der
  Platte (ein zuvor bereitgestelltes Update ist zu diesem Zeitpunkt bereits angewendet). Kommt der
  Watchdog wider Erwarten nicht, startet dieses Skript die Bridge zur Sicherheit selbst.

  STRIKT nur lokal: es wird kein Geraet angefasst, nur der eigene node-Prozess.
#>
param([int]$Port = 8770)

$ErrorActionPreference = 'SilentlyContinue'
Write-Host "VetStation wird neu gestartet (ohne Adminabfrage)..."

# 1) Laufenden node-Prozess der Station beenden. Nur den, der aus C:\VetStation laeuft - keine
#    fremden node-Prozesse anderer Programme.
$eigene = Get-CimInstance Win32_Process -Filter "Name='node.exe'" |
  Where-Object { $_.CommandLine -match 'VetStation' -or $_.ExecutablePath -match 'VetStation' }
if (-not $eigene) { $eigene = Get-Process node -ErrorAction SilentlyContinue }
foreach ($p in $eigene) {
  try { Stop-Process -Id ($p.ProcessId ? $p.ProcessId : $p.Id) -Force -ErrorAction Stop; Write-Host "  Station beendet." }
  catch { Write-Warning "  Konnte den Prozess nicht beenden: $($_.Exception.Message)" }
}

# 2) Kurz warten, ob der Watchdog/die Autostart-Aufgabe die Station von selbst neu startet.
function Laeuft { try { (Invoke-WebRequest "http://127.0.0.1:$Port/api/version" -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200 } catch { $false } }
$ok = $false
for ($i = 0; $i -lt 8; $i++) { Start-Sleep -Seconds 2; if (Laeuft) { $ok = $true; break } }

# 3) Kam sie nicht von selbst zurueck, Bridge direkt starten (Ports > 1024, keine Adminrechte noetig).
if (-not $ok) {
  Write-Host "  Kein automatischer Neustart - starte die Station selbst ..."
  $root = Split-Path $PSScriptRoot -Parent
  $node = Join-Path $root 'node\node.exe'
  if (-not (Test-Path $node)) { $node = 'node' }
  $env:PORT = "$Port"
  Start-Process -FilePath $node -ArgumentList 'bridge\src\index.js' -WorkingDirectory $root -WindowStyle Hidden
  for ($i = 0; $i -lt 10; $i++) { Start-Sleep -Seconds 1; if (Laeuft) { $ok = $true; break } }
}

if ($ok) { Write-Host "VetStation laeuft wieder." } else { Write-Warning "VetStation antwortet noch nicht - bitte START-VetStation.bat verwenden." }
