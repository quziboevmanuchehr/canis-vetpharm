<#
  neustart-station.ps1 - VetStation sauber neu starten.

  WOFUER: Nach einem Update laeuft noch der ALTE Programmstand im Speicher, bis die Station
  einmal neu gestartet wurde. Der laufende Prozess wird ausserdem mit erhoehten Rechten
  gestartet (Autostart-Aufgabe, RunLevel "Hoechste") - er laesst sich deshalb nicht einfach
  im Task-Manager beenden. Dieses Skript erledigt beides und holt sich die noetigen Rechte
  selbst (UAC-Abfrage bestaetigen).

  Es beendet NUR VetStation-Prozesse, raeumt die Firewall-Regeln auf und startet die
  Station ueber die normale Kiosk-Aufgabe wieder. Es wird NICHTS geloescht, und die
  Konfiguration (bridge\config\devices.json, data\) bleibt unangetastet.

  EINFACHSTER WEG (nichts tippen):  im Ordner C:\VetStation die Datei
  NEUSTART.bat DOPPELKLICKEN.
#>
param([switch]$Leise)

# --- Adminrechte sicherstellen (wie set-static-ip.ps1) ------------------------
$__id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($__id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte mit Administratorrechten neu (bitte die UAC-Abfrage mit JA bestaetigen)..."
  try {
    Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'))
  } catch {
    Write-Warning "Ohne Adminrechte nicht moeglich. Bitte NEUSTART.bat rechtsklicken -> Als Administrator ausfuehren."
    Read-Host "Zum Schliessen die EINGABETASTE druecken"
  }
  exit
}

$ZIEL = 'C:\VetStation'
Write-Host "== VetStation neu starten =="
$soll = try { (Get-Content (Join-Path $ZIEL 'package.json') -Raw | ConvertFrom-Json).version } catch { $null }
if ($soll) { Write-Host "Installierter Stand auf der Festplatte: $soll" }

# --- 1) Laufende VetStation beenden -------------------------------------------
Write-Host ""
Write-Host "1) Laufende Station beenden ..."
$beendet = 0
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
  # NUR VetStation treffen - fremde Node-Programme auf dem PC bleiben unangetastet.
  if (($_.ExecutablePath -and $_.ExecutablePath -like "$ZIEL\*") -or ($_.CommandLine -and $_.CommandLine -like '*VetStation*')) {
    try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $beendet++ } catch {
      Write-Warning ("PID {0} liess sich nicht beenden: {1}" -f $_.ProcessId, $_.Exception.Message)
    }
  }
}
Start-Sleep -Seconds 2
Write-Host ("   {0} Prozess(e) beendet." -f $beendet)

$belegt = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
            Where-Object { $_.LocalPort -in 8770, 3502, 4601, 5000, 24105, 2575 })
if ($belegt.Count) {
  Write-Warning ("Diese Ports sind noch belegt: " + (($belegt.LocalPort | Sort-Object -Unique) -join ', '))
  Write-Warning "Falls der Start gleich fehlschlaegt: PC neu starten."
} else {
  Write-Host "   Alle Geraete-Ports sind frei."
}

# --- 2) Firewall-Freigaben sicherstellen --------------------------------------
Write-Host ""
Write-Host "2) Firewall-Freigaben pruefen/setzen ..."
$fw = Join-Path $ZIEL 'installer\set-firewall.ps1'
if (Test-Path $fw) { & $fw } else { Write-Warning "set-firewall.ps1 nicht gefunden - uebersprungen." }

# --- 3) Station wieder starten ------------------------------------------------
Write-Host ""
Write-Host "3) Station starten ..."
$gestartet = $false
try {
  Start-ScheduledTask -TaskName 'VetStation-Kiosk' -ErrorAction Stop
  Write-Host "   Ueber die Autostart-Aufgabe gestartet."
  $gestartet = $true
} catch {
  Write-Host "   Autostart-Aufgabe nicht verfuegbar - starte direkt."
  try { Start-Process -FilePath (Join-Path $ZIEL 'START-VetStation.bat'); $gestartet = $true } catch {
    Write-Warning "Start fehlgeschlagen: $($_.Exception.Message)"
  }
}

# --- 4) Nachpruefen statt behaupten -------------------------------------------
Write-Host ""
Write-Host "4) Nachpruefen (bis zu einer Minute) ..."
$laeuft = $null
for ($i = 0; $i -lt 30 -and $gestartet; $i++) {
  Start-Sleep -Seconds 2
  try { $laeuft = ((Invoke-WebRequest -Uri 'http://127.0.0.1:8770/api/version' -UseBasicParsing -TimeoutSec 3).Content | ConvertFrom-Json).version; break } catch { }
}

Write-Host ""
if ($laeuft -and $soll -and $laeuft -eq $soll) {
  Write-Host "FERTIG: VetStation $laeuft laeuft." -ForegroundColor Green
} elseif ($laeuft) {
  Write-Warning "Die Station meldet $laeuft, auf der Festplatte liegt aber $soll."
  Write-Host "  -> Bitte dieses Skript noch einmal ausfuehren; hilft das nicht, den PC neu starten."
} else {
  Write-Warning "Die Station antwortet noch nicht auf http://127.0.0.1:8770."
  Write-Host "  -> Meldungen oben lesen. Kommt nichts, START-VetStation.bat doppelklicken."
}

Write-Host ""
Write-Host "Geraeteverbindung danach pruefen: GERAETE-PRUEFEN.bat doppelklicken."
if (-not $Leise) { Read-Host "Zum Schliessen die EINGABETASTE druecken" }
