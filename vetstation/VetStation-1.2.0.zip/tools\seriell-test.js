'use strict';
/*
 * seriell-test.js — der serielle Weg darf NIE etwas an einem Geraet verstellen.
 *
 * WAS DIESER TEST FESTHAELT:
 * Eine serielle Leitung ist beidseitig. Manche Protokolle (Draeger MEDIBUS) verlangen, dass der PC
 * eine ANFRAGE schickt, sonst schweigt das Geraet — das ist Mitlesen und erlaubt. Alles, was am
 * Geraet etwas VERSTELLT, ist verboten (§10, nicht verhandelbar: ein verstellter Verdampfer oder
 * eine verstellte Beatmung am narkotisierten Tier ist der schlimmste denkbare Fehler dieses
 * Programms).
 * Die Sperre dafuer ist eine ausdrueckliche Erlaubnisliste. Sie ist nur so viel wert, wie es Wege
 * gibt, sie zu umgehen — deshalb wird hier von aussen versucht, an ihr vorbeizukommen.
 *
 * Ausserdem geprueft: die Zeile fuer mode.com (eine falsche Baudrate erzeugt Buchstabensalat, der
 * wie ein fremdes Protokoll AUSSIEHT) und das Auslesen der COM-Anschluesse aus der Registry.
 *
 * Start: node tools/seriell-test.js      (laeuft auch in tools/alle-tests.js)
 */
const s = require('../bridge/src/seriell');

let pass = 0, fail = 0;
function ok(n, c, x) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (x ? '  -> ' + x : '')); } }

console.log('VetStation — serieller Weg\n');

console.log('COM-Anschluesse aus der Windows-Registry lesen:');
// Echte Ausgabe von `reg query HKLM\HARDWARE\DEVICEMAP\SERIALCOMM` dieses PCs (01.08.2026).
const REG = [
  '',
  'HKEY_LOCAL_MACHINE\\HARDWARE\\DEVICEMAP\\SERIALCOMM',
  '    \\Device\\Serial0    REG_SZ    COM1',
  '    \\Device\\VCP0       REG_SZ    COM7',
  '',
].join('\r\n');
const liste = s.schnittstellenAusRegistry(REG);
ok('beide Anschluesse gefunden', liste.length === 2, JSON.stringify(liste));
ok('COM1 dabei', liste.some((x) => x.name === 'COM1'));
ok('COM7 (USB-Wandler) dabei', liste.some((x) => x.name === 'COM7'));
ok('leere Ausgabe ergibt eine leere Liste, keinen Absturz', s.schnittstellenAusRegistry('').length === 0);
ok('Unsinn ergibt eine leere Liste', s.schnittstellenAusRegistry('irgendwas\nanderes').length === 0);

console.log('\nDie Einstellzeile fuer mode.com:');
const m = s.modeBefehl('com3', { baud: 19200, paritaet: 'E', datenbits: 7, stopbits: 1 });
ok('Anschluss gross und mit Doppelpunkt', m[0] === 'COM3:', m.join(' '));
ok('Baudrate uebernommen', m.indexOf('BAUD=19200') >= 0, m.join(' '));
ok('Paritaet kleingeschrieben (mode.com verlangt das)', m.indexOf('PARITY=e') >= 0, m.join(' '));
ok('Datenbits uebernommen', m.indexOf('DATA=7') >= 0);
/* to=off ist der Unterschied zwischen "funktioniert" und "meldet dauernd Fehler": ohne diese
 * Angabe laeuft jeder Lesevorgang in eine Zeitgrenze, sobald das Geraet einmal schweigt — und
 * ein Monitor, der alle paar Sekunden sendet, schweigt die meiste Zeit. */
ok('Zeitgrenzen sind aus (to=off)', m.indexOf('to=off') >= 0, m.join(' '));
ok('Flusssteuerung ist aus', m.indexOf('xon=off') >= 0 && m.indexOf('octs=off') >= 0);
const v = s.modeBefehl('COM1', {});
ok('ohne Angaben gilt 9600/8N1', v.indexOf('BAUD=9600') >= 0 && v.indexOf('DATA=8') >= 0 && v.indexOf('PARITY=n') >= 0, v.join(' '));

console.log('\nDIE SPERRE: ohne Erlaubnisliste wird NICHTS gesendet:');
const gemeldet = [];
const ctx = { log: { info() {}, warn: (a, b) => gemeldet.push(b), error() {} } };
const ohne = new s.SerielleVerbindung({ art: 'tcp', host: 'x', tcpPort: 1 }, ctx);
ok('senden() gibt false zurueck', ohne.senden(Buffer.from([0x1b, 0x51])) === false);
ok('und sagt im Log, warum', gemeldet.some((x) => /keine Erlaubnisliste/.test(x)), JSON.stringify(gemeldet));

console.log('\nMIT Erlaubnisliste: nur das Erlaubte kommt durch:');
gemeldet.length = 0;
const ANFRAGE = Buffer.from([0x1b, 0x51, 0x30]);        // eine reine Datenanfrage
const VERSTELLEN = Buffer.from([0x1b, 0x53, 0x41]);     // etwas, das am Geraet etwas aendern wuerde
const geschrieben = [];
const mit = new s.SerielleVerbindung({ art: 'tcp', host: 'x', tcpPort: 1, erlaubteBefehle: [ANFRAGE] }, ctx);
mit._socket = { write: (b) => geschrieben.push(b.toString('hex')) };
ok('die erlaubte Anfrage geht raus', mit.senden(ANFRAGE) === true && geschrieben.length === 1);
ok('ein Verstell-Befehl wird ABGELEHNT', mit.senden(VERSTELLEN) === false);
ok('und geht auch wirklich nicht raus', geschrieben.length === 1, JSON.stringify(geschrieben));
ok('die Ablehnung steht im Log', gemeldet.some((x) => /nicht in der Erlaubnisliste/.test(x)));
ok('ein aehnlicher, aber nicht gleicher Befehl wird ebenfalls abgelehnt',
  mit.senden(Buffer.from([0x1b, 0x51, 0x31])) === false);
ok('ein laengerer Befehl mit erlaubtem Anfang wird abgelehnt (kein Praefixvergleich)',
  mit.senden(Buffer.from([0x1b, 0x51, 0x30, 0x99])) === false);
ok('nach allen Versuchen ist genau EIN Byte-Paket rausgegangen', geschrieben.length === 1);

console.log('\nFehlerhafte Angaben:');
const falsch = new s.SerielleVerbindung({ art: 'com', port: 'LPT1' }, ctx);
falsch.oeffnen().then(function () { ok('COM-Weg mit falschem Anschlussnamen', false, 'haette scheitern muessen'); ende(); },
  function (e) { ok('COM-Weg mit falschem Anschlussnamen scheitert mit Klartext', /gueltiger COM-Anschluss/.test(e.message), e.message); ende(); });

function ende() {
  const ohneZiel = new s.SerielleVerbindung({ art: 'tcp' }, ctx);
  ohneZiel.oeffnen().then(function () { ok('Geraeteserver ohne Adresse', false, 'haette scheitern muessen'); schluss(); },
    function (e) { ok('Geraeteserver ohne Adresse scheitert mit Klartext', /Adresse oder Port/.test(e.message), e.message); schluss(); });
}

function schluss() {
  console.log('\n---');
  console.log(pass + ' von ' + (pass + fail) + ' Pruefungen bestanden.');
  if (fail) { console.log('FEHLGESCHLAGEN'); process.exit(1); }
  console.log('OK (' + pass + ' Pruefungen)');
}
