'use strict';
/*
 * veta5-mitschnitt.js — schneidet mit, WAS das Narkosegeraet (Veta 5 Plus, 192.168.0.52) im Netz
 * tatsaechlich sendet, und sagt ehrlich, ob es LESBAR ist (HL7) oder NICHT (Mindray-MD2).
 *
 * WARUM (Stand 24.07.2026): Der Veta 5 antwortet auf Port 4601, spricht dort aber Mindrays
 * proprietaeres MD2-Binaerprotokoll (Rahmen 0x02/STX + Sync-Wort 0xA5 0x5A), das nur die
 * kostenpflichtige BeneVision CMS Vet versteht. VetStation liest es NICHT und darf es NICHT raten
 * (ein geratener Beatmungswert am narkotisierten Patienten waere gefaehrlich). Beim uMEC12 loeste
 * ein GERAETE-MENUE-Schalter ("HL7 Compatibility: Ein") das Problem — dann kamen echte HL7-Zahlen.
 * Dieses Werkzeug ist der Beweis-Schritt: EINMAL mitschneiden und schauen, ob der Veta 5 (per
 * Menue-Schalter/Export) doch HL7 liefern kann. Es RATET NIE Bytes zu Vitalwerten.
 *
 * ZWEI BETRIEBSARTEN:
 *   1) VERBINDEN (Standard): der PC verbindet sich zum Geraet und liest, was kommt.
 *        node tools/veta5-mitschnitt.js --host 192.168.0.52 --port 4601 --seconds 60
 *   2) ZUHOEREN: das Geraet sendet von sich aus zum PC (am Geraet Serveradresse = PC-IP,
 *      z. B. CentralStation-Verbindung/HL7-Push). Dann lauscht der PC auf dem Port:
 *        node tools/veta5-mitschnitt.js --listen --port 4601 --seconds 120
 *
 * Danach die STRUKTUR ansehen (ordnet NIE Bytes zu Messwerten zu):
 *        node tools/binaer-analyse.js bridge/data/veta5-<port>.log
 */
const net = require('net');
const fs = require('fs');
const path = require('path');

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  if (i < 0) return def;
  const v = process.argv[i + 1];
  return (v == null || v.startsWith('--')) ? true : v;   // Flag ohne Wert -> true
}

const HOST = String(arg('host', '192.168.0.52'));
const PORT = parseInt(arg('port', '4601'), 10);
const SECS = parseInt(arg('seconds', '60'), 10);
const LISTEN = arg('listen', false) === true;
const DATA_DIR = path.join(__dirname, '..', 'bridge', 'data');
const OUT = String(arg('out', path.join(DATA_DIR, 'veta5-' + PORT + '.log')));

try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (e) {}

let total = 0;
let ersteBytes = null;
let sink = null;
const startHint = Buffer.from([]);

function bewerten(buf) {
  // Rahmenkennung: 0x0B (VT) = HL7/MLLP (LESBAR). 0x02 (STX) oder Sync-Wort A5 5A = MD2 (NICHT lesbar).
  const hex = buf.slice(0, 64).toString('hex');
  const hatMLLP = buf.indexOf(0x0b) >= 0 && buf.indexOf(Buffer.from('MSH|')) >= 0;
  const hatMSH = buf.indexOf(Buffer.from('MSH|')) >= 0;
  const md2 = buf[0] === 0x02 || /a55a/.test(hex);
  if (hatMLLP || hatMSH) return { art: 'HL7', lesbar: true, note: 'HL7 erkannt (MSH-Segment) — VetStation KANN das lesen. In devices.json den Adapter "veta5" auf enabled:true stellen (Host 192.168.0.52) und NEUSTART.' };
  if (md2) return { art: 'MD2', lesbar: false, note: 'Proprietaerer Mindray-Binaerstrom (0x02/STX bzw. A5 5A). NICHT lesbar ohne BeneVision CMS/eGateway. Am Geraet nach einem HL7-/EMR-/Datenexport-Schalter suchen (wie uMEC12 "HL7 Compatibility"), sonst Haendler (Eickemeyer) nach HL7-Freischaltung fragen.' };
  return { art: 'unbekannt', lesbar: false, note: 'Kein eindeutiges HL7 und kein MD2-Marker. Rohdaten mit tools/binaer-analyse.js ansehen.' };
}

function fertig(grund) {
  try { if (sink) sink.end(); } catch (e) {}
  console.log('\n──────────────────────────────────────────────');
  console.log('Mitschnitt beendet (' + grund + ').');
  console.log('Empfangen:   ' + total + ' Byte  ->  ' + OUT);
  if (!total) {
    console.log('Ergebnis:    NICHTS empfangen.');
    console.log(LISTEN
      ? '  -> Am Geraet die Serveradresse/CentralStation-Verbindung auf die PC-IP (192.168.0.99) stellen und senden aktivieren; PC-Firewall fuer diesen Port freigeben (FIREWALL-FREIGEBEN.bat).'
      : '  -> Geraet evtl. auf 192.168.0.52 pruefen (erreichbar?), oder mit --listen arbeiten (Geraet sendet dann zum PC).');
  } else {
    const b = bewerten(ersteBytes || Buffer.alloc(0));
    console.log('Erste Bytes: ' + (ersteBytes || Buffer.alloc(0)).slice(0, 24).toString('hex').replace(/(..)/g, '$1 ').trim());
    console.log('Protokoll:   ' + b.art + (b.lesbar ? '  ✓ LESBAR' : '  ✗ nicht direkt lesbar'));
    console.log('Naechster:   ' + b.note);
    console.log('Struktur:    node tools/binaer-analyse.js ' + path.relative(path.join(__dirname, '..'), OUT).replace(/\\/g, '/'));
  }
  console.log('──────────────────────────────────────────────');
  process.exit(0);
}

function onStream(stream, quelle) {
  console.log('Datenstrom von ' + quelle + ' — schreibe nach ' + OUT + ' …');
  sink = sink || fs.createWriteStream(OUT);
  stream.on('data', (chunk) => {
    if (!ersteBytes) ersteBytes = Buffer.from(chunk);
    total += chunk.length;
    try { sink.write(chunk); } catch (e) {}
    process.stdout.write('\r  ' + total + ' Byte empfangen …   ');
  });
  stream.on('error', () => {});
  stream.on('close', () => {});
}

console.log('Veta-5-Mitschnitt  ·  ' + (LISTEN ? ('ZUHOEREN auf Port ' + PORT) : ('VERBINDEN zu ' + HOST + ':' + PORT)) + '  ·  ' + SECS + ' s');
setTimeout(() => fertig('Zeit abgelaufen'), SECS * 1000);
process.on('SIGINT', () => fertig('Abbruch'));

if (LISTEN) {
  const srv = net.createServer((sock) => onStream(sock, sock.remoteAddress || 'Geraet'));
  srv.on('error', (e) => { console.log('Kann nicht auf Port ' + PORT + ' lauschen: ' + e.message + (e.code === 'EADDRINUSE' ? ' (laeuft VetStation? Dann diesen Port zuerst freigeben.)' : '')); process.exit(1); });
  srv.listen(PORT, () => console.log('Warte auf das Geraet … (am Veta 5 Serveradresse = PC-IP setzen)'));
} else {
  const c = net.connect(PORT, HOST, () => onStream(c, HOST + ':' + PORT));
  c.on('error', (e) => { console.log('Verbindung fehlgeschlagen: ' + e.message + '  -> Geraet auf 192.168.0.52 erreichbar? Sonst --listen versuchen.'); process.exit(1); });
}
