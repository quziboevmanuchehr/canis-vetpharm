@echo off
title VetStation - auf externe Platte / USB kopieren
REM Legt Setup, Update-Paket UND den vollstaendigen Quellcode inkl. Git-Historie auf einen
REM anderen Datentraeger, damit an einem ANDEREN PC weitergearbeitet werden kann.
REM Ziel aendern:  AUF-USB-KOPIEREN.bat E:\VetStation
cd /d "%~dp0"
set ZIEL=%~1
if "%ZIEL%"=="" set ZIEL=G:\Manu\VetStation
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\auf-usb-kopieren.ps1" -Ziel "%ZIEL%"
pause
