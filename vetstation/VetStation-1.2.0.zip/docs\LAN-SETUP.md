# LAN-Aufbau — PC + Monitor + Kapnograf verbinden

> ## ⭐ ZUERST LESEN: die 3 Gründe, warum „es verbindet nicht"
> Am 21.07.2026 direkt an den Praxis-Fotos des uMEC12 Vet festgestellt:
>
> **1. Der Monitor hatte KEINE IP-Adresse.** Im Menü *Monitornetzwerk-Setup* stand
> `Adresstyp: DHCP` und `IP-Adresse 0.0.0.0`, dazu die Meldung
> **„Abrufen der Netzwerkadr. fehlgeschlagen"**. Ohne Router gibt es keinen DHCP-Server,
> der Adressen vergibt → das Gerät bleibt auf `0.0.0.0` und kann **nichts** senden.
> **Lösung:** Adresstyp auf **Manuell/Statisch** stellen (Werte unten).
>
> **2. Der Monitor sendet an Port 3502 — dort lauschte VetStation nicht.** Unter
> *Gateway-Kommunikationseinst.* steht das Ziel **`192.168.0.99 : 3502`**. VetStation
> hörte bis 0.4.0 nur auf 4601/5000/24105/2575. **Ab 0.5.0 wird 3502 zuerst gelauscht.**
>
> **3. Die Windows-Firewall blockierte eingehende Verbindungen.** Ohne Freigabe verwirft
> Windows die Gerätedaten lautlos. **Der Installer legt die Regeln jetzt automatisch an**
> (TCP 3502/4601/5000/24105/2575).
>
> ### Einstellungen, die zusammenpassen müssen
> | Wo | Einstellung | Wert |
> |---|---|---|
> | **PC** | feste IP (isoliert) | **192.168.0.99** / 255.255.255.0 |
> | **Monitor** → Monitornetzwerk-Setup | Adresstyp | **Manuell** (nicht DHCP!) |
> | **Monitor** → Monitornetzwerk-Setup | IP-Adresse | **192.168.0.50** / 255.255.255.0 |
> | **Monitor** → Gateway-Kommunikationseinst. | Ziel-IP / Port | **192.168.0.99** / **3502** |
> | 2. Gerät (LifeVet) | IP-Adresse | 192.168.0.51 (gleiches Ziel) |
>
> ### Ablauf — NICHTS tippen, nur doppelklicken
> Im Ordner **`C:\VetStation`** (bzw. über *Startmenü → VetStation*) liegen diese Dateien:
>
> | Schritt | Datei zum **Doppelklicken** | was sie tut |
> |---|---|---|
> | 1 | **`NETZWERK-EINRICHTEN.bat`** | setzt den PC auf die feste IP `192.168.0.99` (holt sich die Adminrechte selbst — UAC mit **Ja** bestätigen) |
> | 2 | *(am Monitor die 4 Werte eintragen — Tabelle oben)* | |
> | 3 | **`GERAETE-PRUEFEN.bat`** | sucht die Geräte selbst und sagt im Klartext, **wo das Problem liegt** |
> | 4 | **`FIREWALL-FREIGEBEN.bat`** | nur falls Schritt 3 eine fehlende Freigabe meldet |
> | — | **`NEUSTART.bat`** | Station beenden und neu starten (nach Update oder Konfig-Änderung) |
> | — | **`INSTALLIEREN.bat`** | Neuinstallation **und** Update in einem — beendet, aktualisiert, startet, prüft nach |
>
> Menüweg am Gerät: *Hauptmenü → Wartung → Benutzer-Wartung (Passwort **888888**) → Netzwerk*.
>
> > 💡 **Dasselbe geht auch in der App**, ohne den Ordner zu öffnen:
> > **Admin ▸ Netzwerk & Geräte ▸ „Netzwerk jetzt durchsuchen"**. Die Station klopft dann jede
> > Adresse `.1`–`.254` ab, liest die Firewall aus und zeigt oben in **einem Satz**, woran es
> > liegt — darunter die Ursachen nach Wahrscheinlichkeit sortiert, jede mit konkretem
> > nächsten Schritt.
> >
> > Beim **Hochfahren** meldet die Station außerdem von selbst, wenn ihre eigene IP nicht zum
> > Ziel im Monitor passt oder die Firewall die Datenports blockiert.
>
> > ⚠️ **Nicht von Hand mit relativem Pfad starten.** PowerShell öffnet sich in
> > `C:\Windows\System32`; `-File installer\set-static-ip.ps1` findet die Datei dort **nicht**
> > („Das Argument … ist nicht vorhanden"). Wenn es doch getippt sein muss, dann mit
> > **vollständigem** Pfad:
> > `powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-static-ip.ps1"`
> > Dieses Skript **braucht Adminrechte**: PowerShell dafür per Rechtsklick
> > **„Als Administrator ausführen"** öffnen. (Beim Doppelklick auf `NETZWERK-EINRICHTEN.bat`
> > entfällt das — die Datei holt sich die Rechte selbst.)
> >
> > ⚠️ **`npm` gibt es auf dem Praxis-PC nicht** (nur portables `node.exe`). `npm run check`
> > funktioniert **nur** auf dem Entwickler-PC — auf der Station stattdessen
> > `GERAETE-PRUEFEN.bat` doppelklicken.

Dein PC hat **nur einen LAN-Anschluss** — deshalb ist ein **kleiner LAN-Switch/Hub Pflicht**, um
3–5 Geräte zusammenzubinden. Aufbau:

```
   [uMEC12 Vet Monitor] --LAN(CS)--\
   [Veta 5 Plus]         --LAN(CS)-- >--[ kleiner Gigabit-Switch ]--LAN--[ Windows-PC: VetStation ]
   (weitere Geräte)      ----------/
```

## Was du brauchst (günstig)
- **1 kleiner Gigabit-Switch** (5–8 Ports, ~15–25 €) — ein **eigenes, isoliertes** Geräte-Netz.
- **LAN-Kabel** für jedes Gerät + den PC.
- Der **Windows-10-Pro-PC** (i3/8 GB genügt).

## Netzwerk (feste IPs — verbindliche Werte)
PC **und alle Geräte** müssen im **selben Subnetz `192.168.0.x`** stehen. Die folgenden Werte sind
verbindlich und entsprechen der ausgelieferten Software. Ältere Notizen mit `192.168.23.x` oder
`192.168.2.x` sind **veraltet** — nicht mehr verwenden.

| Gerät | IP | Maske |
|---|---|---|
| **PC (VetStation)** | `192.168.0.99` | `255.255.255.0` (/24), **kein Gateway** |
| **uMEC12 Vet Monitor** | `192.168.0.50` | /24, Adresstyp **Manuell** (nicht DHCP!) |
| **LifeVet / 2. Gerät** | `192.168.0.51` | /24 |
| Ziel im Gerät (*Gateway-Kommunikationseinst.*) | `192.168.0.99` : **3502** | — |

- **PC-IP setzen — nichts tippen:** in **`C:\VetStation`** die Datei **`NETZWERK-EINRICHTEN.bat`**
  doppelklicken (liegt auch im *Startmenü → VetStation*). Sie setzt `192.168.0.99` und holt sich die
  Adminrechte selbst — die UAC-Abfrage mit **Ja** bestätigen.
- Geräte-IP ablesen/ändern am Gerät: *Hauptmenü → Wartung → Benutzer-Wartung (Passwort **888888**)
  → Netzwerk* — „IP automatisch beziehen"/DHCP **AUS**, Adresstyp **Manuell**.

> **Wichtig — alle Geräte in EIN Netz:** Zeigt ein Gerät noch eine Adresse aus einem anderen Subnetz
> (z. B. `192.168.23.x` oder `192.168.2.x`), muss sie umgestellt werden: uMEC12 Vet auf
> **`192.168.0.50`**, LifeVet 10C auf **`192.168.0.51`** (am LifeVet: *Wartung → … → Netzwerk*),
> der PC bleibt **`192.168.0.99`**.
> Der Verbindungs-Assistent erkennt beide Mindray-Typen automatisch (MAC-Präfixe 98:CC:E4 und 00:0F:14).
- **Kein Gateway/Internet nötig** — isoliertes Netz. (Ohne Internet nutzt VetStation die **lokal
  mitgelieferte** Klinik-Datenbasis; das ist voll funktionsfähig. Updates ziehen sich nur, wenn der PC
  zusätzlich Internet hat, z. B. über WLAN.)

### Switch, Powerline-Adapter, Verstärker — und was davon wirklich etwas ändert

Die ausgelieferte Aufstellung besteht aus einem **Switch** (D-Link DGS-105GL, 5 Ports) und einem
**Powerline-Adapter** in der Steckdose. Beides sind reine Weiterleiter:

- Ein **Switch** und ein **Powerline-Adapter** bilden **kein eigenes Netz.** Was durch sie
  hindurchgeht, landet im selben Subnetz und in derselben MAC-Tabelle des PCs. Für VetStation
  ändert sich dadurch **gar nichts** — ein Gerät hinter dem Switch wird genauso gefunden wie
  eines am Kabel direkt.
- Was **wohl** etwas ändert, sind **zwei Netzwerkkarten** im PC (z. B. Kabel ins Gerätenetz +
  WLAN ins Hausnetz). Die sind zwei getrennte Netze. **Seit 1.1.0 sucht die Station in allen
  echten, privaten Netzen dieses PCs** (höchstens drei, der Rest wird im Log genannt). Bis 1.0.3
  wurde nur die *erste* Karte abgesucht — welche das war, entschied Windows, und im Log stand
  nichts davon.
- Ein **WLAN-Verstärker/Repeater** ist ebenfalls nur ein Weiterleiter — aber er ist die häufigste
  Ursache für Aussetzer. Vitalwerte im Sekundentakt vertragen keine Funklöcher. Wo es geht:
  **Kabel**.

**Was Switch und Powerline nicht heilen:** eine falsche Zieladresse im Gerät. Ein Monitor sendet
immer nur an die **eine** Adresse, die bei ihm eingetragen ist. Steht dort die alte PC-Adresse,
hilft keine Verkabelung der Welt.

### Mehrere OP-Säle: zwei Punkte, an denen diese Tabelle nicht mehr genügt

Sobald eine zweite Station dazukommt (→ [MEHRERE-SAELE.md](MEHRERE-SAELE.md)), gilt zusätzlich:

1. **`192.168.0.99` darf nur EIN PC haben.** Die Tabelle oben schreibt sie *jedem* Praxis-PC vor —
   bei zwei Stationen ist das eine Adresskollision, und schlimmer: eine Station würde ihre eigene
   Adresse für die des Nachbarn halten und sich selbst als „OP 2" anzeigen. Der zweite PC bekommt
   deshalb eine andere freie Adresse (z. B. `192.168.0.98`), und das Ziel im *dortigen* Gerät wird
   auf diese Adresse gesetzt.
2. **Die Stationen müssen im HAUSNETZ liegen, nicht im isolierten Gerätenetz.** Zwei isolierte
   Gerätenetze sehen einander nicht. Entweder hängen beide PCs zusätzlich am Praxisnetz (zweite
   Netzwerkkarte oder WLAN — dafür ist `INTERNET-EINRICHTEN.bat` da, es fasst die feste IP nicht
   an), oder sie finden einander ausschließlich über das Praxis-Konto im Internet. Beides
   funktioniert; nur „beide isoliert und trotzdem direkt verbunden" gibt es nicht.

**Port 8771 — der direkte Weg zwischen zwei Sälen.** GET-only, verschlüsselt, beidseitig signiert,
gebunden **nur** an private Adressen. Freigeben: `FIREWALL-FREIGEBEN.bat` (Regel „VetStation
Nachbarsaal TCP 8771", nur Profil Privat/Domäne, nur LocalSubnet). Er ist **kein Geräteport** und
steht bewusst nicht in der Datenport-Liste — sonst hielte die Gerätesuche den Nachbar-PC für einen
Monitor. Ohne Freigabe funktioniert alles weiter, nur eben über das Internet statt direkt.

### Sonderfall: PC und Monitor hängen an einem WLAN-Verstärker / am Hausnetz

Genau so lief es am **22.07.2026** in der Praxis (TP-Link-Verstärker, Kabelrouter unter
`192.168.0.1`). Das **funktioniert** — man muss aber zwei Dinge wissen, sonst sucht man am
falschen Ende:

1. **Die Adressen kommen jetzt vom Router (DHCP).** Der Monitor lag deshalb nicht auf `.50`,
   sondern auf **`.51`**. Die fest eingetragene Geräte-IP in `devices.json` zeigte damit ins Leere;
   im Verbindungs-Log stand gleichzeitig „Gerät gefunden: 192.168.0.51" **und** „Gerät
   192.168.0.50 antwortet nicht" — beides richtig, zusammen unverständlich.
   **Lösung (ab 0.7.2 Standard):** in `bridge\config\devices.json` bei `"host"` das Wort
   **`"auto"`** eintragen. Die Station spricht dann das Gerät an, das sie per Hersteller-MAC
   tatsächlich findet — auch nach einem Adresswechsel.
   Wer feste Adressen will: im Router `.50`, `.51` und `.99` **aus dem DHCP-Bereich ausnehmen**
   und am Gerät wieder auf *Manuell* stellen.

2. **Der PC hat kein IPv4-Standardgateway** — `NETZWERK-EINRICHTEN.bat` setzt die IP bewusst ohne,
   weil das isolierte Gerätenetz keines braucht. Am Hausnetz heißt das: **Gerätedaten laufen
   normal**, aber alles, was ins Internet muss (Update, Fern-Live, klinische Daten), hängt daran,
   ob es einen anderen Weg gibt.
   **Gemessen am 22.07.2026:** Es gab einen — der Kabelrouter lieferte per *Router Advertisement*
   eine vollständige **IPv6**-Verbindung samt DNS. Update-Manifest und klinische Daten waren
   darüber erreichbar (HTTP 200). Die Station lief also, ohne dass jemand wusste, worüber.
   Das ist **fragil**: Dienste ohne IPv6-Adresse (AAAA) sind gar nicht erreichbar, und schaltet der
   Router IPv6 ab, fällt alles gleichzeitig aus — ohne Fehlermeldung.
   Ein Doppelklick auf **`INTERNET-EINRICHTEN.bat`** trägt IPv4-Gateway + DNS nach und **lässt die
   feste IP unverändert** (die Geräteverbindung bleibt also, wie sie ist). Danach steht die Station
   auf beiden Beinen. Rückgängig:
   `powershell -ExecutionPolicy Bypass -File "C:\VetStation\installer\set-internet.ps1" -Entfernen`
   Die Station benennt diesen Zustand seit 0.7.2 selbst — beim Start im Verbindungs-Log und unter
   *Admin ▸ Netzwerk & Geräte* als Befund **„nur IPv6"**.

**Was der Verstärker NICHT kaputt macht:** Ping und Datenverbindung liefen über den Verstärker
einwandfrei. Wenn ein Gerät antwortet, aber keine Werte schickt, liegt es an den Einstellungen
**am Gerät** (Ziel-IP / „Real Data Send" / Port), nicht am Verstärker.

**Port 8830 nicht vergessen:** Das LifeVet 10C sendet ab Werk an Port **8830**. Steht der nicht in
`devices.json` unter `ports`, lehnt Windows die Verbindung ab, das Gerät meldet trotzdem „sendet"
und im Log steht kein einziger Fehler. Ab 0.7.2 ist 8830 überall enthalten
(Firewall, Assistent, Vorlage) — `tools/paket-test.js` erzwingt das.

## Verbinden & einstellen (der eigentliche Knackpunkt)
**Ehrliche Lage:** Der **LifeVet 10C** (Mindray-Monitor) hat einen **dokumentierten HL7-Menüpunkt** — er ist
der beste Weg. Der **uMEC12 Vet** sendet evtl. nur proprietäres MD2; das zeigt der **Verbindungs-Assistent**.
Vorgehen:

1. Alles verkabeln (ein Switch, ein Subnetz), PC-IP `192.168.0.99` setzen →
   **`NETZWERK-EINRICHTEN.bat` doppelklicken** (UAC mit **Ja** bestätigen).
2. **VetStation starten** — **`START-VetStation.bat` doppelklicken**. Der Verbindungs-Assistent läuft
   automatisch und lauscht **zuerst auf 3502**, zusätzlich auf 4601/5000/24105/2575.
3. **Am LifeVet 10C zuerst**: `Wartung → Benutzer-Wartung (Passwort 888888) → Netzwerk → EMR-Kommunikation`
   → **Server-IP = 192.168.0.99, Protokoll = HL7, „Real Data Send" = EIN, Port = 3502**
   (bietet das Gerät 3502 nicht an, ist **Port 4601** die Alternative — VetStation lauscht auf beiden).
   **Am uMEC12 Vet**: `… → Netzwerk → Gateway-Comm-Setup` → **Ziel-IP = 192.168.0.99, Port = 3502**. Details: [MINDRAY-HL7.md](MINDRAY-HL7.md).
4. **VetStation-Admin → „Verbindung/Fehler"** ansehen:
   - „✓ HL7 ERKANNT auf Port 3502" (bzw. 4601) → läuft, Patient erscheint. **Fertig.**
   - „KEIN HL7 erkannt" → Gerät sendet proprietär → Fallback (VSCapture/eGateway), siehe MINDRAY-HL7.md.
   - Kommt gar nichts an: **`GERAETE-PRUEFEN.bat` doppelklicken** — es zeigt im Klartext, ob Daten eintreffen.

`ping 192.168.0.50` vom PC muss klappen → physisches Netz steht.
(Eingabeaufforderung oder PowerShell öffnen, `ping 192.168.0.50` eintippen — **keine** Adminrechte nötig.)

## Sicherheit (§10)
- **Nur lesen** — VetStation sendet **nie** etwas an die Geräte (kein Verstellen von Verdampfer/Beatmung).
- **Isoliertes Geräte-Netz** (eigener Switch). Patientendaten bleiben **lokal** auf dem PC.

## Mit dem Händler klären
1. Sendet der uMEC **HL7 über LAN (Port 3502, ersatzweise 4601)** oder nur **MD2** an die BeneVision CMS Vet? Menüpfad/Port? **Freigeschaltet/Lizenz?**
2. Gibt es einen **offenen Datenausgang (HL7/eGateway)** für Monitor und/oder Veta — und was kostet die Freischaltung?
