'use strict';
/*
 * tafelabo-test.js — Selbsttest des LESEWEGS (bridge/src/tafelabo.js) OHNE Internet.
 *
 * Muster: tools/cloud-test.js baut sich sein Firebase selbst. Hier spielt ein kleiner lokaler
 * HTTP-Server den Ereignisstrom der Realtime Database nach — mit allem, was daran wehtun kann:
 * Umleitung, Abriss, entzogenes Token, eine Uhr, die 37 s vorgeht, ein Saal aus der Zukunft,
 * elf OP-Saele, vierzig Kacheln und ein Patientenname mit Markup darin.
 *
 * WAS DIESER TEST BEWEISEN MUSS (und was eine falsche Fassung ihm nicht vormachen kann):
 *   1. Ereignisse kommen an — put, patch, geloeschte Knoten, keep-alive.
 *   2. Ein Abriss ist kein Ausfall: es wird neu verbunden, und der Backoff waechst dabei.
 *   3. auth_revoked holt hoechstens EIN Token je Sperrfenster — und zwar auch dann, wenn der
 *      Nachbau sich wie die echte Datenbank verhaelt (Vollbild und keep-alive VOR dem Entzug).
 *   4. Das Alter rechnet gegen die SERVERZEIT (Date-Kopfzeile), nie gegen die fremde Uhr.
 *   5. Eine fremde Uhr aus der Zukunft ergibt "Alter unbekannt" — niemals 0 und niemals "live".
 *   6. Der Deckel greift bei 8 Saelen und 12 Kacheln, und er MELDET, was er weglaesst.
 *   7. Eine fremde Instanz im eigenen Kennungsknoten wird gemeldet — und zwar nur dann, wenn das
 *      Ereignis sie wirklich getragen hat, nicht bei jeder Kachelaenderung.
 *   8. Ein Lesefehler laesst den Schreibweg unberuehrt.
 *   9. Kein Messwert kommt unter dem Namen eines ANDEREN Feldes an, und kein Feldname aus der
 *      Datenbank erreicht den Prototyp eines gelieferten Objekts.
 *  10. Jeder Saalsatz sagt, ob unser EIGENER Leser gerade blind ist — sonst wird der Ausfall des
 *      eigenen PCs als Ausfall des Nachbarsaals angezeigt.
 *  11. Ein OP-Saal traegt in EINER Antwort genau EINEN Namen.
 *  12. Die Drossel fuer wiederkehrende Warnungen bremst wirklich, und stand().bytes zaehlt auch
 *      den Aufschlag der Verbindungen, nicht nur die Nutzdaten.
 *  13. Ein NEU aufgestellter OP-Saal bekommt Platz im Rohbaum, auch wenn der voll ist.
 *
 * DIE REIHENFOLGE DES NACHBAUS IST TEIL DER PRUEFUNG. Die Realtime Database schickt beim
 * Abonnieren IMMER zuerst ein put mit dem Vollbild und danach keep-alive; ein Nachbau, der ein
 * Ereignis als ERSTEN und EINZIGEN Rahmen schickt, prueft eine Reihenfolge, die es im Feld nicht
 * gibt. Genau daran ist Block 4 einmal vorbeigelaufen (Befund C1) — er hat eine Bremse bestaetigt,
 * die gegen die echte Datenbank nie gegriffen hat.
 *
 * Start: node tools/tafelabo-test.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const T = require('../bridge/src/tafelabo');
const tafel = require('../bridge/src/tafel');

let pass = 0, fail = 0;
function ok(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (extra ? '  -> ' + extra : '')); }
}
function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }
/*
 * Warten auf einen Zustand, OHNE zu werfen: laeuft die Frist ab, liefert bis() false und die
 * Pruefung wird als ✗ ausgewiesen. Ein abbrechender Helfer haette an derselben Stelle einen
 * Werkzeugfehler gemeldet statt der Ursache (dieselbe Ueberlegung wie in tools/cloud-test.js).
 */
function bis(pruef, ms) {
  return new Promise((res) => {
    const t0 = Date.now();
    (function p() {
      let v = false;
      try { v = !!pruef(); } catch (_) { v = false; }
      if (v) return res(true);
      if (Date.now() - t0 > (ms || 3000)) return res(false);
      setTimeout(p, 10);
    })();
  });
}

// Ein Log, das mitschreibt statt zu reden — sonst steht die Ausgabe des Tests voll Warnzeilen.
function logBuch() {
  const zeilen = [];
  const nimm = (stufe) => (bereich, text) => zeilen.push(stufe + '|' + bereich + '|' + text);
  return { zeilen: zeilen, info: nimm('info'), warn: nimm('warn'), error: nimm('error'),
    text() { return zeilen.join('\n'); } };
}

// Kennungen in der Form aus tafel.SID_FORM: 'st' + GENAU 12 Hexzeichen.
const SID_EIGEN = 'st1111aaaa0001';
const SID_B = 'st2222bbbb0002';
const SID_C = 'st3333cccc0003';
const INSTANZ_EIGEN = '0123456789abcdef';
const INSTANZ_FREMD = 'fedcba9876543210';

// ---------------------------------------------------------------- Mock: der Ereignisstrom
/*
 * Der Server ist absichtlich duemmer als eine Datenbank: er beantwortet jede Anfrage mit dem, was
 * der jeweilige Testblock in 'zustand' eingestellt hat, und haelt die Antwort offen. Alles, was
 * der Leser aus dem Strom machen soll, muss der Leser selbst machen.
 */
function starteMock() {
  const zustand = {
    offen: [],            // alle offenen Antworten (der Test schiebt Rahmen hinein)
    pfade: [],            // welche Pfade angefragt wurden
    tokens: [],           // welcher auth-Parameter dabei stand
    status: 200,          // Antwortcode fuer die naechste Verbindung
    rumpf: 'kein Zutritt', // Koerper der Fehlerantwort (Block 17 misst seinen Umfang)
    datum: null,          // Funktion, die den Date-Kopf liefert (Serverzeit)
    umleitung: null,      // Location fuer eine 307
    umleitungEinmal: true,
    beiVerbindung: null,  // Rueckruf (res, laufendeNummer)
  };
  const srv = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    zustand.pfade.push(u.pathname);
    zustand.tokens.push(u.searchParams.get('auth'));
    const kopf = { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' };
    if (zustand.datum) kopf.Date = zustand.datum();
    if (zustand.umleitung) {
      const ziel = zustand.umleitung;
      if (zustand.umleitungEinmal) zustand.umleitung = null;
      res.writeHead(307, Object.assign({ Location: ziel }, kopf.Date ? { Date: kopf.Date } : {}));
      return res.end();
    }
    if (zustand.status !== 200) {
      res.writeHead(zustand.status, kopf.Date ? { Date: kopf.Date } : {});
      return res.end(zustand.rumpf);
    }
    res.writeHead(200, kopf);
    zustand.offen.push(res);
    if (typeof zustand.beiVerbindung === 'function') zustand.beiVerbindung(res, zustand.offen.length);
    return undefined;
  });
  return new Promise((resolve) => {
    srv.listen(0, '127.0.0.1', () => {
      zustand.port = srv.address().port;
      zustand.url = 'http://127.0.0.1:' + zustand.port;
      zustand.srv = srv;
      resolve(zustand);
    });
  });
}
function sende(res, event, daten) {
  if (!res || res.writableEnded) return;
  res.write('event: ' + event + '\ndata: ' + JSON.stringify(daten) + '\n\n');
}
function allen(z, event, daten) { z.offen.forEach((r) => sende(r, event, daten)); }
function trenne(z) { z.offen.forEach((r) => { try { r.destroy(); } catch (_) {} }); z.offen.length = 0; }

// Ein Saalkopf, wie ihn tafel.tafelSatz() schreibt (nur die Felder, die der Leser anfasst).
function kopf(sid, name, instanz, sv, mehr) {
  return Object.assign({ sid: sid, name: name, v: tafel.TAFEL_V, instanz: instanz, ts: sv, sv: sv,
    count: 0, taktMs: 2000 }, mehr || {});
}

function neuesAbo(z, opt) {
  return new T.Tafelabo(Object.assign({
    dbUrl: z.url,
    uid: 'praxis1',
    sid: SID_EIGEN,
    token: async () => 'tok',
    log: opt && opt.log ? opt.log : { info() {}, warn() {}, error() {} },
    backoffStartMs: 30,
    backoffMaxMs: 200,
    stilleMaxMs: 5000,
    verbindungsFristMs: 2000,
  }, opt || {}));
}

// ================================================================ Los
(async function run() {
  console.log('\n=== tafelabo: der Leseweg (Tafel-Strom der Nachbarsaele) ===\n');

  // ---------------------------------------------------------------- 1. reine Bausteine
  console.log('1) Bausteine — ohne Netz, ohne Zustand');
  {
    const rahmen = [];
    const L = new T.Rahmenleser((ev, d) => rahmen.push([ev, d]));
    L.schub('event: put\ndata: {"path":"/","da');
    ok('ein halber Rahmen ergibt noch kein Ereignis', rahmen.length === 0);
    L.schub('ta":null}\n\n');
    ok('der zweite Teil vervollstaendigt ihn', rahmen.length === 1 && rahmen[0][0] === 'put');
    ok('und die Daten sind vollstaendig', rahmen[0][1] === '{"path":"/","data":null}', rahmen[0][1]);
    L.schub('event: keep-alive\r\ndata: null\r\n\r\nevent: patch\ndata: 1\n\n');
    ok('CRLF und zwei Rahmen in einem Schub', rahmen.length === 3
      && rahmen[1][0] === 'keep-alive' && rahmen[2][0] === 'patch', JSON.stringify(rahmen));
    L.schub(': ein Kommentar\nevent: put\ndata: 1\ndata: 2\n\n');
    ok('Kommentarzeile wird uebergangen, mehrzeilige Daten werden verbunden',
      rahmen.length === 4 && rahmen[3][1] === '1\n2', JSON.stringify(rahmen[3]));

    const eng = new T.Rahmenleser(() => { throw new Error('darf nicht kommen'); }, 64);
    eng.schub('data: ' + 'x'.repeat(200));
    ok('ein Rahmen ueber der Grenze setzt Ueberlauf statt zu wachsen', eng.ueberlauf === true);

    ok('pfadTeile("/") ist die Wurzel', T.pfadTeile('/').length === 0);
    ok('pfadTeile("/a/b") ergibt zwei Teile', T.pfadTeile('/a/b').join(',') === 'a,b');
    ok('doppelte Schraegstriche ergeben kein leeres Kind', T.pfadTeile('//a//b').join(',') === 'a,b');

    ok('Median ungerade', T.mittlererVersatz([5, 1, 3]) === 3);
    ok('Median gerade wird gerundet', T.mittlererVersatz([1, 2, 3, 4]) === 3, String(T.mittlererVersatz([1, 2, 3, 4])));
    /* Der Grund fuer den Median statt des Mittelwerts, als Pruefung: EIN Ausreisser (eine
     * Zwischenstelle mit eigener Uhr) darf den Versatz nicht dauerhaft verschieben. */
    ok('ein einzelner Ausreisser bewegt den Median nicht',
      T.mittlererVersatz([100, 101, 102, 99, 98, 3600000]) === 101, String(T.mittlererVersatz([100, 101, 102, 99, 98, 3600000])));
    ok('ohne Messung ist der Versatz 0', T.mittlererVersatz([]) === 0);

    const s = T.saeubere({ n: '<script>alert(1)</script> Bello von der langen Wiese hinterm Haus',
      hr: 96, txt: 'x'.repeat(300), ja: true, nix: null, tief: { a: { b: { c: 1 } } } });
    ok('Markup faellt aus einem fremden Namen heraus', !/[<>&"'`\\]/.test(s.n), s.n);
    ok('und der Name wird auf 40 Zeichen gekuerzt', s.n.length <= 40, String(s.n.length));
    ok('eine Zahl bleibt eine Zahl', s.hr === 96);
    ok('ein Wahrheitswert bleibt einer', s.ja === true);
    ok('ein langer Text wird gekuerzt', s.txt.length <= tafel.GRENZEN.tafelText);
    ok('Zahlen werden NICHT aus Texten gemacht', T.saeubere({ x: '96' }).x === '96');
    ok('Unendlich wird zu null', T.saeubere({ x: Infinity }).x === null);
    const viele = {}; for (let i = 0; i < 90; i++) viele['f' + String(i).padStart(2, '0')] = i;
    ok('mehr als 40 Felder werden gekappt', Object.keys(T.saeubere(viele)).length === tafel.GRENZEN.felder,
      String(Object.keys(T.saeubere(viele)).length));
    ok('und zwar stabil nach Feldnamen sortiert', Object.keys(T.saeubere(viele))[0] === 'f00');
    ok('eine lange Liste wird gekappt', T.saeubere(new Array(300).fill(1)).length === tafel.GRENZEN.liste);

    /*
     * NAMENSKOLLISION (Befund C2) — der Befund mit dem hoechsten Preis in diesem Baustein.
     * tafel.text() entfernt < > & " ' \ ` : 'hr<' und 'hr' heissen danach beide 'hr'. Weil vorher
     * sortiert wird, kam der verstuemmelte Schluessel ZULETZT und ueberschrieb den sauberen —
     * GEMESSEN ergab saeubere({'hr<':250, hr:96}) genau {"hr":250}. Auf eine Kachel uebertragen:
     * ein zweiter Schreiber im Praxiskonto setzt neben hr:96 zusaetzlich 'hr<':250, und der
     * Nachbarstreifen zeigt fuer das Tier im anderen Saal eine Herzfrequenz von 250 statt 96 —
     * ohne Kennzeichnung, ohne Eintrag in stand().verworfen. Ein Wert am falschen Platz ist der
     * eine Fehler, den saeubere() gerade verhindern soll.
     */
    const koll = { namensKollision: 0, verbotenerName: 0 };
    const kollErgebnis = T.saeubere({ 'hr<': 250, hr: 96 }, 0, koll);
    ok('bei zwei Schluesseln, die nach dem Saeubern gleich heissen, gewinnt der ERSTE',
      kollErgebnis.hr === 96, JSON.stringify(kollErgebnis));
    ok('der fremde Wert steht unter KEINEM Namen im Ergebnis',
      JSON.stringify(kollErgebnis).indexOf('250') < 0, JSON.stringify(kollErgebnis));
    ok('und die Kollision wird gezaehlt, nicht verschwiegen', koll.namensKollision === 1,
      JSON.stringify(koll));

    /*
     * '__proto__' IM WERT (Befund C4). Ein out['__proto__'] = ... ist keine Zuweisung, sondern ein
     * Prototypenwechsel: GEMESSEN sah das Ergebnis fuer JSON.stringify und Object.keys aus wie
     * {"n":"Bello"}, aber p.kaputt lieferte 1. Eine Anzeige, die werte.<name> direkt liest, zeigte
     * damit ein Feld, das ein Diagnose-Auszug desselben Objekts nicht enthaelt.
     */
    const pz = { namensKollision: 0, verbotenerName: 0 };
    const p = T.saeubere(JSON.parse('{"__proto__":{"kaputt":1},"n":"Bello"}'), 0, pz);
    ok('ein __proto__ im WERT wechselt nicht den Prototyp', p.kaputt === undefined, String(p.kaputt));
    ok('und es bleibt auch nicht als Feld stehen',
      Object.keys(p).join(',') === 'n', JSON.stringify(Object.keys(p)));
    ok('der verbotene Name wird gezaehlt', pz.verbotenerName === 1, JSON.stringify(pz));
    ok('Object.prototype selbst bleibt in jedem Fall sauber', ({}).kaputt === undefined);
    /* Auch nach dem Saeubern: 'hr<' faellt zu 'hr', '__proto__<' faellt zu '__proto__'. Geprueft
     * werden MUSS deshalb der gesaeuberte Name — sonst geht die Sperre am Angriff vorbei. */
    const pz2 = { verbotenerName: 0 };
    const p2 = T.saeubere(JSON.parse('{"__proto__<":{"kaputt":1},"n":"Bello"}'), 0, pz2);
    ok('auch ein erst durch das Saeubern entstandenes __proto__ wird abgewiesen',
      p2.kaputt === undefined && Object.keys(p2).join(',') === 'n' && pz2.verbotenerName === 1,
      JSON.stringify(Object.keys(p2)) + ' ' + JSON.stringify(pz2));
    ok('ohne Zaehlerbeutel saeubert es trotzdem und wirft nicht',
      T.saeubere({ 'hr<': 250, hr: 96 }).hr === 96);

    ok('gleiche Domaene: derselbe Rechner', T.gleicheDomaene('127.0.0.1', '127.0.0.1'));
    ok('gleiche Domaene: Namensraumserver der Datenbank',
      T.gleicheDomaene('vet-station-default-rtdb.europe-west1.firebasedatabase.app',
        's-euw1b-nss-2.europe-west1.firebasedatabase.app'));
    ok('fremde Domaene wird nicht als gleich gewertet',
      !T.gleicheDomaene('vet-station-default-rtdb.europe-west1.firebasedatabase.app', 'boese.example.com'));
    ok('ein Name ohne Punkte muss exakt stimmen', !T.gleicheDomaene('localhost', 'localhorst'));
  }

  // ---------------------------------------------------------------- 2. Ereignisse kommen an
  console.log('\n2) Ereignisse kommen an (put, patch, Loeschung, keep-alive)');
  const z = await starteMock();
  {
    const abo = neuesAbo(z);
    abo.start();
    const da = await bis(() => z.offen.length === 1);
    ok('der Leser verbindet sich', da);
    ok('und zwar auf den Tafelknoten des eigenen Kontos',
      z.pfade[0] === '/live/praxis1/tafel.json', z.pfade[0]);
    ok('mit dem Zugangstoken in der Adresse', z.tokens[0] === 'tok');

    const jetzt = Date.now();
    allen(z, 'put', { path: '/', data: {
      [SID_B]: { meta: kopf(SID_B, 'Saal Zwei', 'bbbbbbbbbbbbbbbb', jetzt) },
      [SID_C]: { meta: kopf(SID_C, 'Saal Drei', 'cccccccccccccccc', jetzt) },
    } });
    const zwei = await bis(() => abo.saele().length === 2);
    ok('das Vollbild bringt beide Saele', zwei, JSON.stringify(abo.saele().map((s) => s.sid)));
    ok('sortiert nach Saalname (Drei vor Zwei)', abo.saele().map((s) => s.name).join('|') === 'Saal Drei|Saal Zwei',
      abo.saele().map((s) => s.name).join('|'));

    allen(z, 'patch', { path: '/', data: { [SID_B + '/meta']: kopf(SID_B, 'Saal Zwei neu', 'bbbbbbbbbbbbbbbb', Date.now(), { count: 3 }) } });
    const um = await bis(() => abo.saele().some((s) => s.name === 'Saal Zwei neu'));
    ok('ein patch mit tiefem Schluessel aendert genau diesen Saal', um);
    ok('und laesst den anderen in Ruhe', abo.saele().some((s) => s.name === 'Saal Drei'));
    ok('der Kopf des geaenderten Saals traegt die neue Zahl',
      (abo.saele().find((s) => s.sid === SID_B) || {}).meta.count === 3);

    allen(z, 'put', { path: '/' + SID_B + '/uebersicht/sw_hund_22', data: { pid: '12345', n: 'Bello', hr: 96 } });
    const kachel = await bis(() => (abo.saele().find((s) => s.sid === SID_B) || { kacheln: [] }).kacheln.length === 1);
    ok('eine einzelne Kachel kommt an', kachel);
    ok('mit Schluessel und Werten',
      (abo.saele().find((s) => s.sid === SID_B) || {}).kacheln[0].schluessel === 'sw_hund_22');

    allen(z, 'put', { path: '/' + SID_B + '/uebersicht/sw_hund_22', data: null });
    const weg = await bis(() => (abo.saele().find((s) => s.sid === SID_B) || { kacheln: [1] }).kacheln.length === 0);
    ok('null loescht die Kachel wieder', weg);

    allen(z, 'put', { path: '/' + SID_C, data: null });
    const saalWeg = await bis(() => abo.saele().length === 1);
    ok('null auf einen ganzen Saal entfernt ihn', saalWeg);

    const vorher = abo.stand().ereignisse.keepAlive;
    allen(z, 'keep-alive', null);
    const ka = await bis(() => abo.stand().ereignisse.keepAlive === vorher + 1);
    ok('keep-alive wird gezaehlt', ka);
    ok('und put/patch ebenfalls', abo.stand().ereignisse.put >= 4 && abo.stand().ereignisse.patch === 1,
      JSON.stringify(abo.stand().ereignisse));

    /* Ein Schluessel, der keine Stationskennung ist, gehoert nicht in die Saalliste — er kann nur
     * ein Rest oder ein Fremdschreibvorgang sein. Verworfen wird er, aber GEZAEHLT. */
    const vorFremd = abo.stand().verworfen.fremdeSchluessel;
    allen(z, 'put', { path: '/nicht-eine-sid', data: { meta: kopf('x', 'Boes', 'dddddddddddddddd', Date.now()) } });
    const gez = await bis(() => abo.stand().verworfen.fremdeSchluessel > vorFremd);
    ok('ein Schluessel ohne Stationsform wird verworfen und gezaehlt', gez);
    ok('und er taucht in keiner Saalliste auf', !abo.saele().some((s) => s.sid === 'nicht-eine-sid'));

    /* '__proto__' ist ein erlaubter Datenbankschluessel und ein Angriff auf jeden Leser, der
     * Pfade blind in Objekte schreibt. */
    allen(z, 'put', { path: '/' + SID_B + '/__proto__/kaputt', data: 1 });
    await wait(60);
    ok('ein __proto__-Segment wird abgewiesen', abo.stand().verworfen.verboteneSegmente >= 1);
    ok('und der Prototyp bleibt sauber', ({}).kaputt === undefined);

    abo.stop();
    ok('stop() beendet die Verbindung', abo.laeuft() === false);
    trenne(z);
  }

  // ---------------------------------------------------------------- 3. Abriss und Wiederaufnahme
  console.log('\n3) Verbindungsabriss und Wiederaufnahme');
  {
    z.pfade.length = 0; z.tokens.length = 0;
    let nummer = 0;
    z.beiVerbindung = (res) => {
      nummer++;
      const n = nummer;
      sende(res, 'put', { path: '/', data: {
        [SID_B]: { meta: kopf(SID_B, 'Saal ' + n, 'bbbbbbbbbbbbbbbb', Date.now()) },
      } });
    };
    const buch = logBuch();
    const abo = neuesAbo(z, { log: buch });
    abo.start();
    const eins = await bis(() => abo.saele().length === 1 && abo.saele()[0].name === 'Saal 1');
    ok('erste Verbindung liefert das Vollbild', eins);
    ok('der Backoff steht nach einem Lebenszeichen auf 0', abo.stand().backoffMs === 0);

    trenne(z);
    const zwei = await bis(() => abo.saele().length === 1 && abo.saele()[0].name === 'Saal 2', 4000);
    ok('nach dem Abriss wird neu verbunden und neu gelesen', zwei, JSON.stringify(abo.saele()));
    ok('die Verbindung wurde wirklich zweimal aufgebaut', abo.stand().verbindungen === 2,
      String(abo.stand().verbindungen));
    ok('der Abriss steht im Log — als Lesefehler, nicht als Ausfall der Uebertragung',
      /Tafel-Strom .* unterbrochen/.test(buch.text()) && /eigene .*Uebertragung ist davon nicht betroffen/.test(buch.text()),
      buch.text().slice(0, 200));
    ok('und der Backoff ist nach dem naechsten Lebenszeichen wieder 0', abo.stand().backoffMs === 0);

    abo.stop();
    trenne(z);
    z.beiVerbindung = null;
  }

  // ---------------------------------------------------------------- 4. auth_revoked
  console.log('\n4) auth_revoked — EINMAL erneuern, und zwar gegen den ECHTEN Ereignisstrom');
  {
    /*
     * DER NACHBAU SCHICKT DIE LEBENSZEICHEN MIT, UND DAS IST DER GANZE PUNKT (Befund C1).
     *
     * Die Realtime Database schickt beim Abonnieren IMMER zuerst ein put mit dem Vollbild und
     * danach im Sekundentakt keep-alive; erst dann kann ein auth_revoked eintreffen. Der fruehere
     * Nachbau schickte auth_revoked als ERSTEN und EINZIGEN Rahmen — eine Reihenfolge, die die
     * Datenbank nicht erzeugt. Er bestand deshalb, obwohl die Bremse im Feld NIE griff: sie hing an
     * einem Merker, den jeder gelieferte Rahmen zuruecksetzte, also auch das Vollbild und jedes
     * Lebenszeichen. GEMESSEN mit dieser Reihenfolge gegen die alte Fassung: 177 Verbindungs-
     * aufbauten und 177 Tokenerneuerungen in 3021 ms, waehrend der Leser backoffMs 0 und
     * fehlerAnzahl 0 meldete. Jede Erneuerung geht an denselben Anmeldeweg, an dem der SCHREIBWEG
     * fuer die Vitalwerte haengt.
     */
    const entzug = (res) => {
      sende(res, 'put', { path: '/', data: {
        [SID_B]: { meta: kopf(SID_B, 'Saal Neu', 'bbbbbbbbbbbbbbbb', Date.now()) },
      } });
      sende(res, 'keep-alive', null);
      sende(res, 'auth_revoked', 'Auth token is expired');
    };

    // --- 4a: der EINE berechtigte Fall. Entzug, einmal erneuern, weiterlesen.
    z.tokens.length = 0;
    const geholt = [];
    const buch = logBuch();
    let nr = 0;
    z.beiVerbindung = (res) => {
      nr++;
      if (nr === 1) return entzug(res);
      return sende(res, 'put', { path: '/', data: {
        [SID_B]: { meta: kopf(SID_B, 'Saal Neu', 'bbbbbbbbbbbbbbbb', Date.now()) } } });
    };
    const abo = neuesAbo(z, {
      log: buch,
      token: async (erneuern) => { geholt.push(!!erneuern); return erneuern ? 'tok-neu' : 'tok-alt'; },
    });
    abo.start();
    const wieder = await bis(() => abo.stand().verbindungen >= 2 && abo.stand().verbunden, 4000);
    ok('nach dem Entzug laeuft der Strom wieder', wieder, JSON.stringify(abo.stand().ereignisse));
    ok('und liefert wieder Saele', abo.saele().length === 1, String(abo.saele().length));
    ok('das Token wurde GENAU EINMAL erneuert — obwohl Vollbild UND keep-alive vorher kamen',
      geholt.filter((x) => x === true).length === 1, JSON.stringify(geholt));
    ok('die Lebenszeichen kamen dabei wirklich an (sonst prueft dieser Block nichts)',
      abo.stand().ereignisse.keepAlive >= 1, JSON.stringify(abo.stand().ereignisse));
    ok('und die zweite Verbindung benutzt das NEUE Token',
      z.tokens[z.tokens.length - 1] === 'tok-neu', JSON.stringify(z.tokens));
    ok('der Entzug wurde gezaehlt', abo.stand().ereignisse.authRevoked === 1);
    ok('stand() weist die Tokenerneuerung offen aus',
      abo.stand().token.erneuert === 1 && abo.stand().token.abgelehnt === 0,
      JSON.stringify(abo.stand().token));
    ok('und im Klartext gemeldet', /Token wird einmal .*erneuert/.test(buch.text().replace(/\n/g, ' ')),
      buch.text());
    abo.stop();
    trenne(z);

    /*
     * --- 4b: DER FALL, DER IM FELD WEHTUT. Jede Verbindung liefert Vollbild, Lebenszeichen und
     * Entzug — genau die Reihenfolge der echten Datenbank, endlos. Ueber 1,5 s darf dabei GENAU
     * EINE Tokenerneuerung herauskommen. Eine Fassung, deren Bremse an "es kam etwas dazwischen"
     * haengt statt an der Uhr, kommt hier auf mehrere Dutzend.
     */
    z.beiVerbindung = entzug;
    const geholt2 = [];
    const buch2 = logBuch();
    const abo2 = neuesAbo(z, {
      log: buch2,
      token: async (erneuern) => { geholt2.push(!!erneuern); return erneuern ? 'tok-neu' : 'tok-alt'; },
      erneuernSperreMs: 30000,
      backoffStartMs: 200, backoffMaxMs: 400,
    });
    abo2.start();
    await wait(1500);
    const s2 = abo2.stand();
    ok('1,5 s Dauerentzug MIT Lebenszeichen ergeben genau EINE Tokenerneuerung',
      geholt2.filter((x) => x === true).length === 1,
      'erneuert: ' + geholt2.filter((x) => x === true).length + ' bei ' + s2.ereignisse.authRevoked + ' Entzuegen');
    ok('und die Lebenszeichen liefen dabei laufend mit — sie loesen die Sperre nicht',
      s2.ereignisse.keepAlive >= 3, JSON.stringify(s2.ereignisse));
    ok('die abgewiesenen Erneuerungen stehen namentlich in stand()',
      s2.token.abgelehnt >= 2 && s2.token.erneuert === 1, JSON.stringify(s2.token));
    ok('jede Ablehnung geht in den gewoehnlichen Fehlerweg (Wartezeit statt Wiederholung)',
      s2.fehlerAnzahl >= 2, String(s2.fehlerAnzahl));
    ok('und es entsteht kein Verbindungssturm', s2.verbindungen <= 12, String(s2.verbindungen));
    ok('im Log steht der Grund im Klartext', /erneut entzogen/.test(buch2.text()), buch2.text().slice(-300));
    abo2.stop();
    trenne(z);

    /*
     * --- 4c: die Sperre ist eine DROSSEL, kein VERBOT. Laeuft ein Token nach Stunden regulaer ab,
     * muss wieder eines geholt werden. Eine Fassung, die nach der ersten Erneuerung fuer immer
     * zumacht, liesse den Nachbarstreifen dauerhaft leer — derselbe Schaden, nur langsamer.
     */
    z.beiVerbindung = entzug;
    const geholt3 = [];
    const SPERRE = 200, DAUER = 1200;
    const abo3 = neuesAbo(z, {
      token: async (erneuern) => { geholt3.push(!!erneuern); return 'tok'; },
      erneuernSperreMs: SPERRE, backoffStartMs: 20, backoffMaxMs: 60,
    });
    abo3.start();
    await wait(DAUER);
    const e3 = geholt3.filter((x) => x === true).length;
    ok('nach Ablauf der Sperre wird wieder erneuert (Drossel, kein Verbot)', e3 >= 2, String(e3));
    ok('und hoechstens einmal je Sperrfenster', e3 <= Math.ceil(DAUER / SPERRE) + 2,
      e3 + ' Erneuerungen in ' + DAUER + ' ms bei ' + SPERRE + ' ms Sperre');
    abo3.stop();
    trenne(z);
    z.beiVerbindung = null;
  }

  // ---------------------------------------------------------------- 5. Alter ueber die Serverzeit
  console.log('\n5) Alter ueber die SERVERZEIT — nicht ueber die fremde und nicht ueber die eigene Uhr');
  const VERSATZ = 37000;                       // die Datenbank geht 37 s vor
  const serverJetzt = () => Date.now() + VERSATZ;
  {
    z.datum = () => new Date(serverJetzt()).toUTCString();
    /* Ein Lebenszeichen sofort nach dem Verbinden — genau so faengt der echte Strom an. Erst
     * dadurch gehen die Kopfzeilen (und mit ihnen der Date-Kopf) ueberhaupt auf die Leitung:
     * res.writeHead() schreibt sie noch nicht, das tut erst die erste Ausgabe. */
    z.beiVerbindung = (res) => sende(res, 'keep-alive', null);
    const abo = neuesAbo(z);
    abo.start();
    await bis(() => z.offen.length === 1);
    /* Gewartet wird auf die Sicht des LESERS, nicht auf die des Servers: z.offen zeigt an, dass
     * der Server geantwortet hat — beim Leser sind die Kopfzeilen dann noch unterwegs. */
    const gemessen = await bis(() => abo.stand().zeit.quelle === 'gemessen');
    ok('der Uhrenversatz wird aus der Date-Kopfzeile gemessen', gemessen,
      JSON.stringify(abo.stand().zeit));
    ok('und er trifft den echten Versatz auf unter eine Sekunde genau',
      Math.abs(abo.versatzMs() - VERSATZ) <= 1200, String(abo.versatzMs()));

    const S = (name, sid, alterMs) => ({ meta: kopf(sid, name, sid.slice(2) + 'aaaa', serverJetzt() - alterMs) });
    allen(z, 'put', { path: '/', data: {
      st000000000001: S('A frisch', 'st000000000001', 5000),
      st000000000002: S('B aelter', 'st000000000002', 30000),
      st000000000003: S('C offline', 'st000000000003', 70000),
      st000000000004: S('D uralt', 'st000000000004', 13 * 3600 * 1000),
      st000000000005: S('E zukunft', 'st000000000005', -120000),
      st000000000006: S('F unsinn', 'st000000000006', -13 * 3600 * 1000),
    } });
    const da = await bis(() => abo.saele().length >= 4);
    ok('die Saele kommen an', da, JSON.stringify(abo.saele().map((s) => s.name)));
    const nach = {}; abo.saele().forEach((s) => { nach[s.name] = s; });

    ok('ein 5 s alter Saal ist "live"', nach['A frisch'] && nach['A frisch'].stufe === 'live',
      nach['A frisch'] && nach['A frisch'].stufe);
    /*
     * DIE ENTSCHEIDENDE ZAHL. Die PC-Uhr geht 37 s NACH. Wer mit Date.now() rechnet, bekommt hier
     * 5000 - 37000 = -32000, also "Alter unbekannt", und meldet einen kerngesunden Saal als
     * unbestimmt. Wer mit der Serverzeit rechnet, bekommt rund 5000.
     */
    ok('und sein Alter ist rund 5 s — gerechnet gegen die Serverzeit',
      nach['A frisch'] && nach['A frisch'].altMs >= 4000 && nach['A frisch'].altMs <= 6500,
      nach['A frisch'] && String(nach['A frisch'].altMs));
    ok('ein 30 s alter Saal ist "alt"', nach['B aelter'] && nach['B aelter'].stufe === 'alt',
      nach['B aelter'] && nach['B aelter'].stufe);
    /* Der wichtigste Fall von N17 in der Alterung: ein ausgefallener Saal muss SICHTBAR bleiben —
     * als "offline", nicht als Nichts. Ein Leser, der ihn wegfiltert, laesst einen OP-Saal
     * lautlos verschwinden. */
    ok('ein 70 s alter Saal bleibt in der Liste und heisst "offline"',
      nach['C offline'] && nach['C offline'].stufe === 'offline', JSON.stringify(Object.keys(nach)));
    ok('ein 13 h alter Saal verschwindet', !nach['D uralt']);
    ok('und das wurde gezaehlt', abo.stand().verworfen.zuAlt >= 1, JSON.stringify(abo.stand().verworfen));

    /* Nachbesserung N16/N17: eine fremde Uhr aus der Zukunft darf NIE 0 ergeben und nie "live". */
    ok('ein Saal aus der Zukunft ergibt "Alter unbekannt"',
      nach['E zukunft'] && nach['E zukunft'].stufe === 'unbekannt', nach['E zukunft'] && nach['E zukunft'].stufe);
    ok('und sein Alter ist null, niemals 0', nach['E zukunft'] && nach['E zukunft'].altMs === null,
      nach['E zukunft'] && String(nach['E zukunft'].altMs));
    ok('er bleibt aber sichtbar (ein Saal verschwindet nicht wegen einer falschen Uhr)', !!nach['E zukunft']);
    ok('13 h in der Zukunft ist kein Gangunterschied mehr und faellt heraus', !nach['F unsinn']);

    /* Ein Knoten ohne instanz ist ein Rest oder ein Fremdschreibvorgang — dieselbe Regel wie
     * tafel.istZeigbar(). Er wird ausgeblendet und gezaehlt. */
    allen(z, 'put', { path: '/st000000000009', data: { meta: { sid: 'st000000000009', name: 'G ohne Instanz', sv: serverJetzt() } } });
    await wait(80);
    ok('ein Tafelknoten ohne instanz wird nicht gefuehrt', !abo.saele().some((s) => s.name === 'G ohne Instanz'));
    ok('und auch das wird gezaehlt', abo.stand().verworfen.ohneInstanz >= 1);

    abo.stop();
    trenne(z);
    z.beiVerbindung = null;
  }

  // ---------------------------------------------------------------- 6. Deckel
  console.log('\n6) Deckel (N17): 8 Saele, 12 Kacheln — gezaehlt und gemeldet, nie still');
  {
    const buch = logBuch();
    const abo = neuesAbo(z, { log: buch });
    abo.start();
    await bis(() => z.offen.length === 1);

    /*
     * ELF SAELE. Die Namen laufen absichtlich GEGEN die Reihenfolge der Kennungen: sortiert wird
     * nach SAALNAME (N17), nicht nach dem Datenbankschluessel. Eine Fassung, die nach Schluessel
     * sortiert, zeigt hier K bis D statt A bis H.
     */
    const namen = ['K', 'J', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A'];
    const baum = {};
    namen.forEach((n, i) => {
      const sid = 'st' + String(i).padStart(12, '0');
      baum[sid] = { meta: kopf(sid, 'Saal ' + n, String(i).padStart(16, 'a'), serverJetzt()) };
    });
    allen(z, 'put', { path: '/', data: baum });
    const da = await bis(() => abo.saele().length === 8);
    ok('von elf Saelen werden genau acht gefuehrt', da, String(abo.saele().length));
    ok('und zwar die ersten acht nach Saalname',
      abo.saele().map((s) => s.name).join(',') === 'Saal A,Saal B,Saal C,Saal D,Saal E,Saal F,Saal G,Saal H',
      abo.saele().map((s) => s.name).join(','));
    ok('der Rest wird gezaehlt, nicht still verworfen', abo.stand().weitere === 3, String(abo.stand().weitere));
    ok('und namentlich genannt',
      abo.stand().weitereListe.map((s) => s.name).sort().join(',') === 'Saal I,Saal J,Saal K',
      JSON.stringify(abo.stand().weitereListe));
    ok('im Log steht der Satz aus N17',
      /3 weitere OP-Saele werden nicht angezeigt — Deckel erreicht \(8\)/.test(buch.text()),
      buch.text().slice(-300));
    ok('die Reihenfolge ist stabil (zweimal gefragt, zweimal dasselbe)',
      abo.saele().map((s) => s.sid).join(',') === abo.saele().map((s) => s.sid).join(','));

    // Vierzig Kacheln in einem Saal, eine davon mit Markup im Namen.
    const uebersicht = {};
    for (let i = 0; i < 40; i++) uebersicht['k' + String(i).padStart(2, '0')] = { pid: String(i), n: 'Tier ' + i, hr: 60 + i };
    uebersicht.k00.n = '<img src=x onerror="alert(1)"> Bello von der langen Wiese hinterm Haus';
    allen(z, 'put', { path: '/st000000000010/uebersicht', data: uebersicht });
    const kachelDa = await bis(() => (abo.saele().find((s) => s.sid === 'st000000000010') || { kacheln: [] }).kacheln.length > 0);
    ok('die Kacheln kommen an', kachelDa);
    const saalA = abo.saele().find((s) => s.sid === 'st000000000010');
    ok('von vierzig Kacheln kommen genau zwoelf an', saalA.kacheln.length === tafel.GRENZEN.kacheln,
      String(saalA.kacheln.length));
    ok('und die restlichen 28 werden gezaehlt', saalA.weitereKacheln === 28, String(saalA.weitereKacheln));
    const name0 = saalA.kacheln[0].werte.n;
    ok('der Name mit Markup ist entschaerft', !/[<>&"'`\\]/.test(name0), name0);
    ok('und auf 40 Zeichen gekuerzt', name0.length <= tafel.GRENZEN.tafelText, String(name0.length));
    ok('die Zahlen der Kachel bleiben Zahlen', saalA.kacheln[1].werte.hr === 61);

    abo.stop();
    trenne(z);
  }

  // ---------------------------------------------------------------- 7. eigene doppelte Kennung
  console.log('\n7) eigene doppelte Kennung — melden, nicht entscheiden');
  {
    const gemeldet = [];
    const beruehrt = new Set();
    const stationsidRoh = {
      kollisionGemeldet(wert) { gemeldet.push(wert); return false; },
    };
    // Ein Beobachter: er haelt fest, WELCHE Eigenschaften der Leser ueberhaupt anfasst. Der Leser
    // darf die Entscheidung nicht nachbauen — also darf er auch nur diese eine Funktion kennen.
    const stationsid = new Proxy(stationsidRoh, {
      get(ziel, name) { if (typeof name === 'string') beruehrt.add(name); return ziel[name]; },
    });
    const abo = neuesAbo(z, { stationsid: stationsid });
    abo.start();
    await bis(() => z.offen.length === 1);

    allen(z, 'put', { path: '/', data: {
      [SID_EIGEN]: { meta: kopf(SID_EIGEN, 'Mein Saal', INSTANZ_FREMD, serverJetzt()) },
    } });
    const eine = await bis(() => gemeldet.length === 1);
    ok('eine fremde Instanz im EIGENEN Knoten wird gemeldet', eine, JSON.stringify(gemeldet));
    ok('und zwar UNVERAENDERT (die Entscheidung faellt in stationsid.js)', gemeldet[0] === INSTANZ_FREMD);

    /*
     * DER KERN DIESER PRUEFUNG. Eine Kachel-Aenderung TRAEGT keinen Instanzwert. Wer statt des
     * Ereignisses seinen zwischengespeicherten Stand meldet, erzeugt aus EINER Sichtung beliebig
     * viele — und stationsid.js macht aus drei Sichtungen ueber 5 s einen BEWEIS. Ein falscher
     * Beweis sperrt die Patientendaten dieser Station.
     */
    allen(z, 'put', { path: '/' + SID_EIGEN + '/uebersicht/sw_hund_22', data: { pid: '1', n: 'Bello' } });
    allen(z, 'put', { path: '/' + SID_EIGEN + '/uebersicht/sw_katze_4', data: { pid: '2', n: 'Mia' } });
    allen(z, 'patch', { path: '/' + SID_EIGEN, data: { 'uebersicht/sw_hund_22': { pid: '1', n: 'Bello', hr: 99 } } });
    await wait(120);
    ok('eine Kachel-Aenderung meldet NICHT erneut', gemeldet.length === 1, JSON.stringify(gemeldet));

    // Ein Ereignis, das den Wert wirklich traegt, meldet wieder — auf jedem der vier Wege.
    allen(z, 'put', { path: '/' + SID_EIGEN + '/meta', data: kopf(SID_EIGEN, 'Mein Saal', INSTANZ_FREMD, serverJetzt()) });
    const zwei = await bis(() => gemeldet.length === 2);
    ok('ein put auf den eigenen Kopf meldet wieder', zwei);
    allen(z, 'put', { path: '/' + SID_EIGEN + '/meta/instanz', data: INSTANZ_FREMD });
    const drei = await bis(() => gemeldet.length === 3);
    ok('ein put direkt auf meta/instanz meldet auch', drei);
    allen(z, 'patch', { path: '/', data: { [SID_EIGEN + '/meta']: kopf(SID_EIGEN, 'Mein Saal', INSTANZ_FREMD, serverJetzt()) } });
    const vier = await bis(() => gemeldet.length === 4);
    ok('und ein patch mit tiefem Schluessel ebenfalls', vier);

    // Der eigene Wert geht genauso hinein — aussortiert wird in stationsid.js, nicht hier.
    allen(z, 'put', { path: '/' + SID_EIGEN + '/meta/instanz', data: INSTANZ_EIGEN });
    const fuenf = await bis(() => gemeldet.length === 5);
    ok('auch die EIGENE Instanz wird durchgereicht (kein Vorsortieren)',
      fuenf && gemeldet[4] === INSTANZ_EIGEN, JSON.stringify(gemeldet));

    // Ein FREMDER Saal geht stationsid nichts an.
    const vorFremd = gemeldet.length;
    allen(z, 'put', { path: '/' + SID_B + '/meta', data: kopf(SID_B, 'Fremd', INSTANZ_FREMD, serverJetzt()) });
    await wait(120);
    ok('der Knoten eines ANDEREN Saals wird nie als eigene Kollision gemeldet',
      gemeldet.length === vorFremd, JSON.stringify(gemeldet));

    // Abwesenheit ist eine Entwarnung — und Entwarnen ist nicht Sache des Lesewegs.
    allen(z, 'put', { path: '/' + SID_EIGEN + '/meta/instanz', data: null });
    await wait(120);
    ok('ein FEHLENDER Wert wird nicht gemeldet (entwarnt wird nie ueber den Leseweg)',
      gemeldet.length === vorFremd, JSON.stringify(gemeldet));

    const erlaubt = [...beruehrt].filter((n) => n !== 'kollisionGemeldet' && n !== 'sid');
    ok('der Leser fasst an stationsid NUR kollisionGemeldet an', erlaubt.length === 0, JSON.stringify([...beruehrt]));
    ok('und er hat es wirklich benutzt', beruehrt.has('kollisionGemeldet'));
    ok('die Meldungen stehen im Stand', abo.stand().instanzMeldungen === gemeldet.length,
      abo.stand().instanzMeldungen + ' vs ' + gemeldet.length);

    abo.stop();
    trenne(z);
    z.datum = null;
  }

  // ---------------------------------------------------------------- 8. Lesefehler und Schreibweg
  console.log('\n8) ein Lesefehler aendert NICHTS am Schreibweg');
  {
    /*
     * Der Schreibweg, nachgebaut mit genau den Feldern, an denen es wehtut: konfigFehler zaehlt in
     * cloud.js zur Selbstabschaltung, backoffMs ist seine Zwangspause, _gesendet sein
     * Delta-Gedaechtnis. Eingefroren, damit ein Schreibversuch nicht nur unbemerkt bliebe,
     * sondern auffiele.
     */
    const schreibweg = Object.freeze({
      started: true, konfigFehler: 0, backoffMs: 0, naechsterVersuch: 0, lastError: null,
      _gesendet: Object.freeze({ ['saele/' + SID_EIGEN + '/patients/sw_hund_22/vitals']: 'sig' }),
    });
    const vorher = JSON.stringify(schreibweg);

    z.status = 500;
    const buch = logBuch();
    // Der Schreibweg wird ausdruecklich MITGEGEBEN — ein Leser, der unbekannte Optionen wegsteckt,
    // haette hier einen Weg dorthin.
    const abo = neuesAbo(z, { log: buch, schreibweg: schreibweg, backoffStartMs: 30, backoffMaxMs: 1000 });
    abo.start();
    const kaputt = await bis(() => abo.stand().fehlerAnzahl >= 3, 4000);
    ok('drei Lesefehler hintereinander sind moeglich', kaputt, JSON.stringify(abo.stand()));
    ok('der Schreibweg ist Byte fuer Byte unveraendert', JSON.stringify(schreibweg) === vorher);
    ok('der Leser haelt keinen Zugriff auf ihn fest', abo.schreibweg === undefined);
    ok('der eigene Backoff waechst dabei (2er-Potenzen ab dem Startwert)',
      abo.stand().backoffMs === 120 || abo.stand().backoffMs === 240 || abo.stand().backoffMs === 480
      || abo.stand().backoffMs === 960 || abo.stand().backoffMs === 1000, String(abo.stand().backoffMs));
    ok('und der Fehler steht im Klartext im Log', /HTTP 500/.test(buch.text()), buch.text().slice(0, 200));

    // Und er erholt sich wieder, sobald der Server antwortet.
    z.status = 200;
    z.beiVerbindung = (res) => sende(res, 'put', { path: '/', data: {
      [SID_B]: { meta: kopf(SID_B, 'Wieder da', 'bbbbbbbbbbbbbbbb', Date.now()) } } });
    const zurueck = await bis(() => abo.saele().length === 1, 5000);
    ok('nach dem Ende der Stoerung liest er wieder', zurueck);
    ok('und der Backoff ist zurueckgesetzt', abo.stand().backoffMs === 0);

    abo.stop();
    trenne(z);
    z.beiVerbindung = null;
  }

  // ---------------------------------------------------------------- 9. Umleitung (307)
  console.log('\n9) Umleitung — die Datenbank schickt den Strom auf ihren Namensraumserver');
  {
    z.umleitung = z.url + '/live/praxis1/tafel.json?auth=tok&ns=1';
    z.umleitungEinmal = true;
    const abo = neuesAbo(z);
    abo.start();
    const da = await bis(() => z.offen.length === 1, 3000);
    ok('der Leser folgt der 307 auf denselben Rechner', da);
    ok('und zaehlt die Umleitung', abo.stand().umleitungen === 1, String(abo.stand().umleitungen));
    allen(z, 'put', { path: '/', data: { [SID_B]: { meta: kopf(SID_B, 'Nach Umleitung', 'bbbbbbbbbbbbbbbb', Date.now()) } } });
    const gelesen = await bis(() => abo.saele().length === 1);
    ok('und liest danach normal weiter', gelesen);
    abo.stop();
    trenne(z);

    // Eine Umleitung auf eine FREMDE Domaene traegt den Zugangsschluessel aus dem Haus.
    z.umleitung = 'http://boese.example.com/live/praxis1/tafel.json?auth=tok';
    z.umleitungEinmal = false;
    const buch = logBuch();
    const abo2 = neuesAbo(z, { log: buch, backoffStartMs: 50, backoffMaxMs: 200 });
    abo2.start();
    const abgelehnt = await bis(() => /fremde Domaene abgelehnt/.test(buch.text()), 3000);
    ok('eine Umleitung auf eine fremde Domaene wird abgelehnt', abgelehnt, buch.text().slice(0, 300));
    ok('und der Leser folgt ihr nicht', z.offen.length === 0);
    abo2.stop();
    z.umleitung = null; z.umleitungEinmal = true;
    trenne(z);
  }

  // ---------------------------------------------------------------- 10. cancel und Stille
  console.log('\n10) cancel und Stille');
  {
    const buch = logBuch();
    const abo = neuesAbo(z, { log: buch, backoffStartMs: 30, backoffMaxMs: 400 });
    z.beiVerbindung = (res) => { if (z.offen.length === 1) sende(res, 'cancel', null); };
    abo.start();
    const abgesagt = await bis(() => abo.stand().ereignisse.cancel === 1, 3000);
    ok('eine Absage der Datenbank wird erkannt', abgesagt);
    ok('und fuehrt SOFORT auf die lange Wartezeit (ein Rechteproblem heilt nicht in 2 s)',
      abo.stand().backoffMs === 400, String(abo.stand().backoffMs));
    ok('im Log steht der Hinweis auf das Leserecht', /Leserecht/.test(buch.text()), buch.text().slice(-200));
    abo.stop();
    trenne(z);
    z.beiVerbindung = null;

    /* STILLE: eine Verbindung, die steht, aber nichts mehr sendet, ist tot. Der echte Strom
     * schickt regelmaessig keep-alive; bleibt es aus, hilft nur ein neuer Aufbau — ein haengender
     * Socket meldet sich von selbst nie wieder. Das erste Lebenszeichen kommt hier sofort (es
     * bringt zugleich die Kopfzeilen auf die Leitung), danach schweigt der Server. */
    z.beiVerbindung = (res) => sende(res, 'keep-alive', null);
    const abo2 = neuesAbo(z, { stilleMaxMs: 150, backoffStartMs: 20, backoffMaxMs: 100 });
    abo2.start();
    const neuVerbunden = await bis(() => abo2.stand().verbindungen >= 2, 3000);
    ok('ohne weitere Lebenszeichen wird die Verbindung erneuert', neuVerbunden,
      JSON.stringify(abo2.stand()));
    abo2.stop();
    trenne(z);
    z.beiVerbindung = null;

    /* Und die Gegenrichtung: eine Gegenstelle, die den Anruf ANNIMMT und dann nie antwortet,
     * darf den Leser nicht fuer immer haengen lassen. Ohne diese Frist steht der Nachbarstreifen
     * still, ohne dass irgendwo ein Fehler auftaucht. */
    const abo3 = neuesAbo(z, { verbindungsFristMs: 150, backoffStartMs: 20, backoffMaxMs: 100 });
    abo3.start();
    const frist = await bis(() => /Zeitueberschreitung beim Verbindungsaufbau/.test(String(abo3.stand().fehler)), 3000);
    ok('eine Antwort, die nie kommt, laeuft in die Verbindungsfrist', frist, String(abo3.stand().fehler));
    abo3.stop();
    trenne(z);
  }

  // ---------------------------------------------------------------- 11. Vertrag mit tafel.js
  console.log('\n11) Vertrag mit tafel.js — dieselbe Reihenfolge, dieselben Namen, dasselbe Alter');
  {
    /*
     * tafel.frischeSaele() liefert NUR frische Saele (unter 60 s); dieser Leser fuehrt auch
     * ausgefallene, damit ein OP-Saal nicht lautlos verschwindet. Damit die beiden Fassungen von
     * Sortierung, Namen und Alter trotzdem nie auseinanderlaufen, wird hier fuer eine rein
     * FRISCHE Eingabe geprueft, dass beide dasselbe errechnen.
     */
    const abo = neuesAbo(z);
    abo.start();
    await bis(() => z.offen.length === 1);
    const jetzt = Date.now();
    const baum = {};
    [['Saal Zwei', 3000], ['Saal Eins', 8000], ['Saal Eins', 1000], ['Aaa', 20000]].forEach((p, i) => {
      const sid = 'st' + String(i + 100).padStart(12, '0');
      baum[sid] = { meta: kopf(sid, p[0], String(i).padStart(16, 'b'), jetzt - p[1]) };
    });
    allen(z, 'put', { path: '/', data: baum });
    const da = await bis(() => abo.saele().length === 4);
    ok('vier frische Saele kommen an', da, String(abo.saele().length));
    const meine = abo.saele();
    const ihre = tafel.frischeSaele(baum, abo.jetzt(), { anzeige: true });
    ok('gleiche Reihenfolge wie tafel.frischeSaele()',
      meine.map((s) => s.sid).join(',') === ihre.map((s) => s.sid).join(','),
      meine.map((s) => s.sid).join(',') + '  vs  ' + ihre.map((s) => s.sid).join(','));
    ok('gleiche Namen', meine.map((s) => s.name).join(',') === ihre.map((s) => s.name).join(','));
    ok('gleiche Altersstufen', meine.map((s) => s.stufe).join(',') === ihre.map((s) => s.stufe).join(','));
    ok('gleiches Alter (auf 50 ms genau — beide fragen ihre Uhr getrennt)',
      meine.every((s, i) => Math.abs(s.altMs - ihre[i].altMs) <= 50),
      JSON.stringify(meine.map((s) => s.altMs)) + ' vs ' + JSON.stringify(ihre.map((s) => s.altMs)));
    ok('bei gleichem Namen entscheidet die Stationskennung',
      meine[1].name === 'Saal Eins' && meine[2].name === 'Saal Eins' && meine[1].sid < meine[2].sid,
      JSON.stringify(meine.map((s) => s.sid + ':' + s.name)));
    abo.stop();
    trenne(z);
  }

  // ---------------------------------------------------------------- 12. Speichergrenzen
  console.log('\n12) Speichergrenzen des Rohbaums');
  {
    const abo = neuesAbo(z);
    abo.start();
    await bis(() => z.offen.length === 1);
    const viele = {};
    for (let i = 0; i < T.ROH_SAELE_MAX + 10; i++) {
      const sid = 'st' + String(i).padStart(12, '0');
      viele[sid] = { meta: kopf(sid, 'S' + i, String(i).padStart(16, 'c'), Date.now()) };
    }
    allen(z, 'put', { path: '/', data: viele });
    const voll = await bis(() => abo.stand().verworfen.zuVieleSaele >= 10, 3000);
    ok('mehr als ' + T.ROH_SAELE_MAX + ' Saele werden abgewiesen und gezaehlt', voll,
      JSON.stringify(abo.stand().verworfen));
    ok('und die Anzeige bleibt trotzdem bei acht', abo.saele().length === 8, String(abo.saele().length));

    allen(z, 'put', { path: '/st000000000000/a/b/c/d/e/f/g/h/i', data: 1 });
    await wait(80);
    ok('ein zu tiefer Pfad wird abgewiesen', abo.stand().verworfen.zuTief >= 1);
    abo.stop();
    trenne(z);
  }

  // ---------------------------------------------------------------- 13. Abhaengigkeiten
  console.log('\n13) keine Abhaengigkeit auf registry, matching oder einen Adapter');
  {
    const quelle = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'tafelabo.js'), 'utf8');
    const module = [];
    const re = /require\(['"]([^'"]+)['"]\)/g;
    let m;
    while ((m = re.exec(quelle)) !== null) module.push(m[1]);
    ok('geladen werden nur http, https und tafel',
      module.slice().sort().join(',') === './tafel,http,https', module.join(','));

    /*
     * Und die Gegenprobe zur Laufzeit — sie ist die staerkere: ein eigener Prozess laedt NUR
     * tafelabo.js und zeigt, was dabei wirklich in den Modulspeicher gekommen ist. Ein indirekter
     * Weg (tafelabo -> irgendetwas -> registry) faellt hier auf, im Quelltext nicht.
     */
    const p = path.join(__dirname, '..', 'bridge', 'src', 'tafelabo.js').replace(/\\/g, '/');
    const r = spawnSync(process.execPath, ['-e',
      "require('" + p + "'); console.log(Object.keys(require.cache).join('\\n'));"], { encoding: 'utf8' });
    const geladen = String(r.stdout || '').split('\n').map((s) => s.trim()).filter(Boolean);
    const verboten = geladen.filter((f) => /(registry|matching|adapters[\\/]|cloud|server|wsserver|model)\.js$/i.test(f));
    ok('zur Laufzeit wird keines dieser Module geladen', verboten.length === 0, verboten.join(', '));
    ok('geladen sind wirklich nur tafelabo und tafel',
      geladen.filter((f) => /bridge/.test(f)).length === 2, geladen.filter((f) => /bridge/.test(f)).join(', '));
  }

  // ---------------------------------------------------------------- 14. der Wert am falschen Platz
  console.log('\n14) ein Messwert darf nie unter dem Namen eines ANDEREN Feldes ankommen (C2/C4)');
  {
    /*
     * Derselbe Befund wie in Block 1, aber auf dem Weg, den er im Feld nimmt: ueber den Strom in
     * eine Kachel. Ein zweiter Schreiber im Praxiskonto (Privathandy, Tablet am Empfang, kopierte
     * data/cloud-auth.json — alle drei sind im Plan als getragene Restrisiken benannt) setzt neben
     * hr:96 zusaetzlich 'hr<':250. Der Nachbarstreifen zeigte danach 250.
     */
    const buch = logBuch();
    const abo = neuesAbo(z, { log: buch });
    abo.start();
    await bis(() => z.offen.length === 1);
    allen(z, 'put', { path: '/', data: {
      [SID_B]: { meta: kopf(SID_B, 'Saal Zwei', 'bbbbbbbbbbbbbbbb', Date.now()) },
    } });
    await bis(() => abo.saele().length === 1);
    allen(z, 'put', { path: '/' + SID_B + '/uebersicht/sw_hund_22',
      data: { pid: '12345', n: 'Bello', hr: 96, 'hr<': 250 } });
    const da = await bis(() => (abo.saele()[0] || { kacheln: [] }).kacheln.length === 1);
    ok('die Kachel kommt an', da);
    const werte = abo.saele()[0].kacheln[0].werte;
    ok('die Herzfrequenz ist die ECHTE (96), nicht die untergeschobene (250)', werte.hr === 96,
      JSON.stringify(werte));
    ok('und die Kollision steht in stand().verworfen',
      abo.stand().verworfen.namensKollision >= 1, JSON.stringify(abo.stand().verworfen));
    ok('sie wird im Klartext gemeldet', /Namenskollision/.test(buch.text()), buch.text().slice(-300));

    // Und derselbe Weg mit '__proto__' im Wert einer Kachel.
    allen(z, 'put', { path: '/' + SID_B + '/uebersicht/sw_katze_4',
      data: JSON.parse('{"pid":"7","n":"Mia","__proto__":{"kaputt":1}}') });
    const zwei = await bis(() => abo.saele()[0].kacheln.length === 2);
    ok('die zweite Kachel kommt an', zwei);
    const katze = abo.saele()[0].kacheln.find((k) => k.schluessel === 'sw_katze_4').werte;
    ok('ein __proto__ aus dem Strom erreicht den Prototyp der Kachel nicht', katze.kaputt === undefined);
    ok('und jedes frische Objekt bleibt sauber', ({}).kaputt === undefined);
    abo.stop();
    trenne(z);
  }

  // ---------------------------------------------------------------- 15. blind
  console.log('\n15) der Satz sagt, wenn WIR blind sind — nicht der Nachbar (C3)');
  {
    /*
     * altMs und stufe altern aus dem sv des NACHBARN. Sie altern deshalb auch dann weiter, wenn
     * nicht der Nachbar steht, sondern unser eigener Lesestrom abgerissen ist. GEMESSEN an der
     * frueheren Fassung: Strom tot, jeder Neuversuch scheitert — stand() sagte verbunden=false,
     * saele() lieferte gleichzeitig 'OP 2, stufe=offline, altMs=200871' und reichte die
     * eingefrorene hr=96 weiter. Ein Nachbarstreifen, der nur saele() rendert, meldete dem
     * Tierarzt in OP 1 "OP 2 offline seit 3 Minuten", waehrend OP 2 einwandfrei lief.
     */
    z.status = 200;
    z.beiVerbindung = (res) => sende(res, 'put', { path: '/', data: {
      [SID_B]: { meta: kopf(SID_B, 'Saal Zwei', 'bbbbbbbbbbbbbbbb', Date.now()) } } });
    const abo = neuesAbo(z, { backoffStartMs: 30, backoffMaxMs: 120 });
    abo.start();
    const da = await bis(() => abo.saele().length === 1, 3000);
    ok('der Saal ist da', da);
    ok('und solange der Strom laeuft, ist der Satz NICHT blind', abo.saele()[0].blind === false,
      JSON.stringify(abo.saele()[0]));
    ok('der Lesestand ist dabei eine kleine Zahl, kein null',
      typeof abo.saele()[0].lesestandMs === 'number' && abo.saele()[0].lesestandMs < 2000,
      String(abo.saele()[0].lesestandMs));

    // Jetzt reisst der Strom ab und JEDER Neuversuch scheitert — der Nachbar sendet weiter.
    z.status = 500;
    trenne(z);
    const tot = await bis(() => abo.stand().verbunden === false && abo.stand().fehlerAnzahl >= 2, 3000);
    ok('der eigene Strom ist tot und der Leser weiss es', tot, JSON.stringify(abo.stand().fehler));
    const satz = abo.saele()[0];
    ok('der Saal bleibt in der Liste (er verschwindet nicht lautlos)', !!satz);
    ok('ABER der Satz sagt jetzt, dass WIR blind sind', satz.blind === true, JSON.stringify(satz));
    const l1 = abo.saele()[0].lesestandMs;
    await wait(80);
    const l2 = abo.saele()[0].lesestandMs;
    ok('und der Lesestand waechst — das ist die Zahl, gegen die man altMs lesen muss', l2 > l1,
      l1 + ' -> ' + l2);
    ok('stand() sagt dasselbe', abo.stand().blind === true && abo.stand().lesestandMs >= l1,
      JSON.stringify({ blind: abo.stand().blind, lesestandMs: abo.stand().lesestandMs }));

    // Und die Gegenrichtung: sobald wieder gelesen wird, ist blind wieder false. Ein hart
    // verdrahtetes true waere genauso falsch wie ein hart verdrahtetes false.
    z.status = 200;
    const zurueck = await bis(() => abo.saele().length === 1 && abo.saele()[0].blind === false, 4000);
    ok('nach dem Wiederverbinden ist der Satz nicht mehr blind', zurueck,
      JSON.stringify(abo.saele()[0]));
    abo.stop();
    trenne(z);
    z.beiVerbindung = null;
  }

  // ---------------------------------------------------------------- 16. ein Saal, EIN Name
  console.log('\n16) ein OP-Saal hat in einer Antwort genau EINEN Namen (C5)');
  {
    /*
     * satz.name wird auf GRENZEN.spiegelStation (120) gekuerzt, satz.meta.name ging durch
     * saeubere() und damit auf GRENZEN.tafelText (40). GEMESSEN mit einem 70 Zeichen langen Namen:
     * satz.name 70 Zeichen, satz.meta.name 40 Zeichen. Wer im Nachbarstreifen den einen und in der
     * Saalkarte den anderen nimmt, schreibt fuer DENSELBEN OP-Saal zwei verschiedene Namen auf
     * zwei Bildschirme — genau davor warnt N10.
     */
    const LANG = 'Praxis OP 1 - Kleintierchirurgie, Gebaeude B, Erdgeschoss links hinten';
    const abo = neuesAbo(z);
    abo.start();
    await bis(() => z.offen.length === 1);
    allen(z, 'put', { path: '/', data: {
      [SID_B]: { meta: kopf(SID_B, LANG, 'bbbbbbbbbbbbbbbb', Date.now()) },
    } });
    const da = await bis(() => abo.saele().length === 1);
    ok('der Saal mit dem langen Namen kommt an', da);
    const satz = abo.saele()[0];
    ok('satz.name traegt den vollen Namen (bis 120 Zeichen)', satz.name === LANG, satz.name);
    ok('und meta traegt gar keinen zweiten Namen mehr', satz.meta.name === undefined,
      JSON.stringify(satz.meta));
    ok('auch nicht als eigenen Schluessel', Object.keys(satz.meta).indexOf('name') < 0,
      JSON.stringify(Object.keys(satz.meta)));
    ok('der Rest des Kopfes bleibt aber erhalten', satz.meta.sid === SID_B && satz.meta.v === tafel.TAFEL_V,
      JSON.stringify(satz.meta));
    abo.stop();
    trenne(z);
  }

  // ---------------------------------------------------------------- 17. Drossel und Byte-Zaehlung
  console.log('\n17) die Drossel bremst wirklich (C6) und stand().bytes zaehlt den Aufschlag (C7)');
  {
    /*
     * Der Text der Grenzmeldung traegt die laufenden Zaehler — steigt einer, ist der Text neu, und
     * eine Drossel, die auf den TEXT schluesselt, greift genau dann nicht, wenn sie gebraucht wird.
     * GEMESSEN: 20 abgewiesene Ereignisse in unter einer Sekunde ergaben 20 Warnzeilen. Das ist
     * dasselbe Log, in dem waehrend einer Narkose die klinischen Warnungen stehen.
     */
    const buch = logBuch();
    const abo = neuesAbo(z, { log: buch });
    abo.start();
    await bis(() => z.offen.length === 1);
    for (let i = 0; i < 20; i++) allen(z, 'put', { path: '/kein-saal-' + i, data: { x: 1 } });
    await bis(() => abo.stand().verworfen.fremdeSchluessel >= 20, 3000);
    ok('alle zwanzig Ereignisse wurden abgewiesen und gezaehlt',
      abo.stand().verworfen.fremdeSchluessel === 20, String(abo.stand().verworfen.fremdeSchluessel));
    const warn = buch.zeilen.filter((l) => /Eintraege abgewiesen/.test(l));
    ok('sie ergeben EINE Warnzeile, nicht zwanzig', warn.length === 1, warn.length + ' Zeilen');
    abo.stop();
    trenne(z);

    /*
     * stand().bytes: die Kopfzeilen jeder Antwort und die Rumpfe der Fehlerantworten gehoeren dazu
     * (Befund C7). Ein Leser, der wegen einer stoerenden Zwischenstelle dauernd neu verbindet,
     * verbraucht genau die — und meldete vorher bytes 0. Wer den Monatsdeckel darauf stuetzt,
     * unterschaetzte den Verbrauch in der Lage, in der er am hoechsten ist.
     *
     * ZWEI GETRENNTE PRUEFUNGEN, weil es zwei getrennte Anteile sind — eine einzige Pruefung
     * "bytes > 0" waere schon durch den Fehlerrumpf allein erfuellt und liesse eine Fassung
     * durchgehen, die die Kopfzeilen weiter nicht zaehlt.
     *
     * (a) NUR KOPFZEILEN: eine 307 auf eine fremde Domaene wird abgelehnt, ihr Koerper ist leer.
     *     Was hier gezaehlt wird, KANN also nur aus den Kopfzeilen stammen.
     */
    z.umleitung = 'http://boese.example.com/live/praxis1/tafel.json?auth=tok';
    z.umleitungEinmal = false;
    const abo2 = neuesAbo(z, { backoffStartMs: 40, backoffMaxMs: 120 });
    abo2.start();
    const abgelehnt = await bis(() => abo2.stand().fehlerAnzahl >= 2, 4000);
    ok('zwei abgelehnte Umleitungen ohne jeden Koerper', abgelehnt, JSON.stringify(abo2.stand().fehler));
    ok('ihre KOPFZEILEN stehen trotzdem in stand().bytes', abo2.stand().bytes > 0,
      String(abo2.stand().bytes));
    abo2.stop();
    z.umleitung = null; z.umleitungEinmal = true;
    trenne(z);

    /* (b) DER FEHLERRUMPF: ein absichtlich grosser Koerper. Er muss in voller Laenge ankommen —
     *     eine Fassung, die nur die Kopfzeilen zaehlt, bleibt weit darunter. */
    const GROSS = 'x'.repeat(20000);
    z.rumpf = GROSS;
    z.status = 500;
    const abo3 = neuesAbo(z, { backoffStartMs: 40, backoffMaxMs: 120 });
    abo3.start();
    const fehler = await bis(() => abo3.stand().fehlerAnzahl >= 2, 4000);
    ok('zwei Fehlerantworten mit grossem Koerper', fehler, JSON.stringify(abo3.stand().fehler));
    ok('auch die Rumpfe der Fehlerantworten stehen in stand().bytes',
      abo3.stand().bytes >= 2 * GROSS.length, abo3.stand().bytes + ' bei erwarteten >= ' + (2 * GROSS.length));
    abo3.stop();
    z.status = 200;
    z.rumpf = 'kein Zutritt';
    trenne(z);
  }

  // ---------------------------------------------------------------- 18. Rohbaum-Deckel
  console.log('\n18) ein NEUER OP-Saal bekommt Platz — auch wenn der Rohbaum voll ist (C8)');
  {
    /*
     * Ausgemusterte Praxis-PCs hinterlassen ihren Tafelknoten in der Datenbank (aufgeraeumt wird
     * laut Plan nur per Admin-Knopf). Sammeln sich ROH_SAELE_MAX solcher Kennungen an, bekam ein
     * NEU aufgestellter OP-Saal keinen Platz mehr im Rohbaum und tauchte in der Tafel nie auf —
     * lautlos bis auf einen Zaehler ohne Namen. Das ist die Verwechslungsgefahr aus N17 an einer
     * Grenze, die N17 nicht betrachtet.
     */
    const abo = neuesAbo(z);
    abo.start();
    await bis(() => z.offen.length === 1);

    const jetzt = Date.now();
    const baum = {};
    /*
     * Die LEICHEN stehen ABSICHTLICH vorn UND tragen die kleinsten Kennungen. Damit faellt jede
     * Fassung durch, die nach irgendetwas anderem als dem ALTER abschneidet: nach
     * Lieferreihenfolge behaelt sie die Leichen, nach Kennung ebenso — in beiden Faellen fliegen
     * drei laufende OP-Saele heraus und drei Karteileichen bleiben.
     */
    for (let i = 0; i < 3; i++) {
      const sid = 'st' + String(i).padStart(12, '0');
      baum[sid] = { meta: kopf(sid, 'Leiche ' + i, String(i).padStart(16, 'd'), jetzt - 40 * 3600 * 1000) };
    }
    for (let i = 0; i < T.ROH_SAELE_MAX; i++) {
      const sid = 'st' + String(100 + i).padStart(12, '0');
      baum[sid] = { meta: kopf(sid, 'Frisch ' + String(i).padStart(2, '0'), String(i).padStart(16, 'e'), jetzt) };
    }
    allen(z, 'put', { path: '/', data: baum });
    const voll = await bis(() => abo.stand().verworfen.zuVieleSaele >= 3, 3000);
    ok('mehr als ' + T.ROH_SAELE_MAX + ' Saele werden gezaehlt', voll,
      JSON.stringify(abo.stand().verworfen));
    ok('weichen muessen die AELTESTEN — nicht die zuletzt gelieferten und nicht die mit der '
      + 'groessten Kennung',
      abo.stand().verdraengteListe.map((s) => s.name).sort().join(',') === 'Leiche 0,Leiche 1,Leiche 2',
      JSON.stringify(abo.stand().verdraengteListe));
    ok('alle laufenden Saele sind also noch da',
      abo.stand().verdraengteListe.every((s) => !/^Frisch/.test(String(s.name))),
      JSON.stringify(abo.stand().verdraengteListe));
    ok('und die Anzeige fuehrt weiter genau acht', abo.saele().length === 8, String(abo.saele().length));

    /*
     * Und der Fall, der im Feld eintritt: der Rohbaum ist voll, und JETZT wird ein neuer OP-Saal
     * aufgestellt. Er sortiert sich absichtlich an die erste Stelle, damit man ihn in der Anzeige
     * sieht — eine Fassung, die ihn abweist, laesst hier weiter 'Frisch 00' vorn stehen.
     */
    const neuerSid = 'st' + String(777).padStart(12, '0');
    allen(z, 'put', { path: '/' + neuerSid,
      data: { meta: kopf(neuerSid, 'AAA neu aufgestellt', 'ffffffffffffffff', jetzt) } });
    const drin = await bis(() => abo.saele()[0] && abo.saele()[0].name === 'AAA neu aufgestellt', 3000);
    ok('ein neu aufgestellter OP-Saal kommt in den Rohbaum und in die Anzeige', drin,
      JSON.stringify(abo.saele().map((s) => s.name)));
    ok('dafuer ist ein alter gewichen — gezaehlt', abo.stand().verworfen.verdraengt >= 1,
      JSON.stringify(abo.stand().verworfen));
    ok('und NAMENTLICH genannt, nicht nur als Zahl',
      abo.stand().verdraengteListe.length > 0
      && abo.stand().verdraengteListe[abo.stand().verdraengteListe.length - 1].sid !== neuerSid,
      JSON.stringify(abo.stand().verdraengteListe));
    abo.stop();
    trenne(z);
  }

  // ---------------------------------------------------------------- Ende
  trenne(z);
  z.srv.close();
  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
})().catch((e) => { console.error('TESTFEHLER:', e); process.exit(1); });
