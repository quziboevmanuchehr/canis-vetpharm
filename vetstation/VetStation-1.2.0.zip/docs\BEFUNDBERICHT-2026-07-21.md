# Befundbericht 21.07.2026 — was am PC und in der Software falsch war

> **Wofür dieser Bericht?** Er listet **jeden** gefundenen Fehler mit Ursache, Auswirkung und
> Behebung. Damit lässt sich auf **jedem weiteren PC** prüfen, ob dort dasselbe Problem
> vorliegt — und die Installation gezielt verbessern statt zu raten.
>
> Untersucht: Praxis-PC (`C:\VetStation`), Netzwerk `192.168.0.0/24`, Monitor uMEC12 Vet.
> **Behoben in Version 0.6.0.** Jeder Punkt unter §2 ist durch mindestens einen Selbsttest
> abgesichert (§5) — `npm test` bzw. `node\node.exe tools\alle-tests.js`.

---

## 0. Die Kernaussage zuerst

**Die App war nicht schuld, dass keine Werte ankamen — aber sie hat es verschwiegen.**

Nachgewiesen: Ein simuliertes uMEC12 Vet, das echtes HL7 an die laufende Station sendete, wurde
sofort erkannt und korrekt verarbeitet:

```
✓ HL7 ERKANNT auf Port 3502  →  Neues Geraet erkannt: Mindray (HL7 auto)
Patient OP-TEST-1   HF=88  SpO2=97  EtCO2=38  AF=14  T=37,6
```

Empfang, Auswertung und Patientenbildung funktionieren also einwandfrei. Was fehlte, war das
sendende Gerät — **und jede brauchbare Information darüber, warum nichts ankommt.**

**Das ist die eigentliche Änderung in 0.6.0.** Dieselbe Station sagt beim Hochfahren jetzt von
sich aus, was im Weg steht — hier auf einem PC, der nicht eingerichtet ist:

```
[warn] selbsttest: PC-Adresse ist 192.168.0.233, der Monitor sendet aber an 192.168.0.99:3502.
       Entweder NETZWERK-EINRICHTEN.bat doppelklicken oder am Monitor das Ziel auf
       192.168.0.233 aendern.
[warn] selbsttest: WINDOWS-FIREWALL BLOCKIERT Port 3502, 4601, 5000, 24105, 2575.
       Ankommende Vitaldaten werden LAUTLOS verworfen — das Geraet meldet "sendet", hier kommt
       nichts an. Beheben: FIREWALL-FREIGEBEN.bat doppelklicken.
```

Beide Sätze standen vorher **nirgends**.

---

## 1. Befunde am PC und im Netzwerk

Diese Punkte betreffen **die Einrichtung**, nicht den Programmcode. Auf einem weiteren PC bitte
einzeln durchgehen.

### 1.1 Es war überhaupt kein Monitor am Netz ⚠ Hauptbefund

Ein aktiver Scan über **alle** Adressen `192.168.0.1–254` fand 12 Teilnehmer:
einen Router, diesen PC, mehrere Handys/Laptops, einen Drucker und einen zweiten Windows-PC.
**Kein einziger** hatte einen Datenport (3502/4601/5000/24105/2575) offen, und auf
`192.168.0.50` / `.51` war nichts.

**Prüfen:** `GERAETE-PRUEFEN.bat` doppelklicken — oder in der App **Admin ▸ Netzwerk & Geräte ▸
„Netzwerk jetzt durchsuchen"**. Steht dort „Kein Gerät im Netz gefunden", ist der Monitor aus,
nicht verkabelt oder in einem anderen IP-Bereich.

### 1.2 Der PC hängt am Router-Netz, nicht am isolierten Geräte-Switch

Vorgesehen ist: **PC + Monitor + Narkosegerät allein an einem Switch.** Tatsächlich hängt der PC
im normalen Hausnetz mit Router `192.168.0.1` und einem Dutzend Fremdgeräten.

Das funktioniert zwar auch — **aber nur**, wenn der Monitor wirklich in **demselben** Netz hängt
und keine Netztrennung/VLAN dazwischenliegt. Im gemeinsamen Netz kommt außerdem ein Risiko dazu:
Vergibt der Router per DHCP die Adresse `192.168.0.50` an ein Handy, kollidiert das mit dem
Monitor. **Empfehlung:** entweder eigener Switch, oder `.50`/`.51`/`.99` im Router aus dem
DHCP-Bereich ausnehmen.

Station und Check **warnen jetzt ausdrücklich**, wenn sie ein Router-Netz erkennen.

### 1.3 Die Windows-Firewall hatte 10 statt 5 Regeln

Jede Neuinstallation legte einen weiteren Satz identischer Regeln an (Ursache siehe 2.5).
Nicht gefährlich, aber die Firewall-Liste wird unlesbar und die Fehlersuche schwerer.
**Bereinigt auf 5** — `FIREWALL-FREIGEBEN.bat` räumt Altbestände jetzt bei jedem Lauf mit auf.

### 1.4 Fern-Live: die Datenbank existiert nicht

Der Praxis-PC erreicht Firebase, bekommt aber `HTTP 404`. Die Realtime Database unter
`https://vet-station-default-rtdb.europe-west1.firebasedatabase.app` ist **nicht angelegt**.
Das ist eine Aufgabe in der Firebase-Konsole, **kein Softwarefehler** — Anleitung:
[FERN-LIVE.md](FERN-LIVE.md). Fern-Live ist deshalb **ab Werk aus**
(`devices.example.json`, mit Begründung im Feld `_warum_aus`).

### 1.5 Die Monitor-Einstellungen selbst waren korrekt ✓

Laut Foto des Gerätemenüs:

| Menü | Wert | Bewertung |
|---|---|---|
| Monitornetzwerk-Setup | LAN, **Manuell**, `192.168.0.50`, `255.255.255.0`, GW `192.168.0.1` | ✓ richtig |
| Gateway-Kommunikationseinst. | Ziel `192.168.0.99`, Port `3502` | ✓ passt exakt zum PC |
| Netzwerk-Setup | **CMS auswählen: Aus** | ⚠ siehe unten |

**Offener Punkt:** `CMS auswählen: Aus`. Für den Gateway-Weg auf Port 3502 sollte das nicht
stören. Kommen nach dem Anschließen trotzdem keine Daten, ist das die **erste Stellschraube am
Gerät** — die Diagnose nennt sie deshalb ausdrücklich.

### 1.6 Weitere Teilnehmer im Netz (zur Einordnung)

| IP | Was es ist |
|---|---|
| `192.168.0.1` | Router |
| `192.168.0.99` | dieser Praxis-PC (Soll) |
| `192.168.0.104` | Drucker |
| `192.168.0.233` | zweiter Windows-PC „MANUCHEHR" |
| weitere | Handys/Laptops (Zufalls-MAC) |

---

## 2. Fehler in der Software — alle behoben

### 2.1 Die Gerätesuche war blind 🔴 schwerwiegend

**Was war:** Gesucht wurde nur in der ARP-Tabelle, und dort galten ausschließlich zwei
MAC-Präfixe (`98:CC:E4`, `00:0F:14`).

**Warum das fatal ist:** Ein **frisch angestecktes** Gerät steht noch gar nicht in der
ARP-Tabelle. Und ein Gerät mit anderem Präfix — andere Fertigungscharge, Eickemeyer-Rebrand,
Fremdfabrikat — wurde stillschweigend verworfen. In **beiden** Fällen meldete die Station
„kein Gerät gefunden", obwohl eines am Kabel hing. Der Anwender suchte daraufhin am falschen Ende.

**Jetzt:** Aktive Suche ([netscan.js](../bridge/src/netscan.js)) — jede Adresse `.1`–`.254` wird
per TCP angesprochen (das erzwingt die ARP-Auflösung **auch bei geschlossenem Port**), danach
Portscan. Der Hersteller ist nur noch ein **Hinweis, kein Filter**. Jeder Fund wird eingestuft
und **begründet**:

```
✓ sicher            antwortet auf Datenport 3502
? möglich           antwortet im Netz, aber kein Datenport offen
· unwahrscheinlich  Windows-Dateifreigabe (SMB) offen (Port 445) — kein Medizingerät
```

### 2.2 Fern-Live machte das Diagnose-Log unbrauchbar 🔴 schwerwiegend

**Was war:** Bei nicht erreichbarer Datenbank schrieb der Publisher **~2 Fehlerzeilen pro
Sekunde**. Der Ringpuffer fasst 500 Zeilen — nach gut **vier Minuten** war er voll und
**sämtliche Verbindungsmeldungen daraus verdrängt.** Ausgerechnet das Log, das bei der
Inbetriebnahme helfen soll, enthielt nur noch Cloud-Fehler.

**Jetzt, drei Ebenen:**
1. Der Logger fasst identische Meldungen zusammen — 200 gleiche Zeilen ergeben **einen** Eintrag
   mit Zähler, abgeschlossen durch `(vorige Meldung 199× wiederholt)`.
2. Die Wartezeit verdoppelt sich (2 s → max. 60 s).
3. Nach **drei Konfigurationsfehlern** (HTTP 404/401/403 — die heilen sich nie von selbst)
   schaltet Fern-Live sich mit Klartextbegründung selbst ab und stellt dabei ausdrücklich klar:
   *„Das betrifft NICHT die Geräteverbindung."*

### 2.3 Der HL7-Client hatte denselben Fehler

Im `client`-Modus wurde fest **alle 3 Sekunden** neu verbunden, mit **zwei** Warnzeilen je
Versuch (`error` + `close`) = rund **40 Zeilen pro Minute**, solange das Gerät aus ist — also
genau im Normalzustand **vor** der Inbetriebnahme.

**Jetzt:** eine Meldung, dann wachsende Abstände (3 s → max. 60 s), Wiederholungen stumm.
Gemessen im Test: **≤ 1 Zeile** statt ~40. Erst dadurch ist der Client als dauerhaft aktiver
Rückfallweg überhaupt zumutbar.

### 2.4 Die angezeigte Version war falsch

`/api/version` meldete hartnäckig **0.1.0**, weil die Bridge `bridge/package.json` einlas statt
der Wurzel-`package.json`. Dazu stand in `updater/version.json` eine dritte Nummer.
**Folge:** Nach einem Update war nicht feststellbar, ob es angekommen ist — und die
Update-Prüfung verglich falsch.

**Jetzt:** eine einzige Quelle der Wahrheit ([version.js](../bridge/src/version.js)); die Station
warnt beim Start, falls die Nummern auseinanderlaufen. Abgesichert durch
[version-test.js](../tools/version-test.js), das auch die Inno-Setup-Version mitprüft.

### 2.5 Firewall-Regeln vermehrten sich

`vetstation-setup.iss` legte sie **ohne vorheriges Löschen** an, `Install-VetStation.ps1`
zusätzlich. Pro Neuinstallation kam ein weiterer Satz dazu.

**Jetzt:** ein gemeinsames, wiederholbares Skript
([set-firewall.ps1](../installer/set-firewall.ps1)) für **beide** Wege — es löscht erst alle
gleichnamigen Altregeln und legt dann genau eine je Port an. Mehrfaches Ausführen ändert das
Ergebnis nicht.

### 2.6 Die Firewall wurde nie geprüft, nur empfohlen

**Warum das zählt:** Fehlt eine Freigabe, verwirft Windows die Vitaldaten **lautlos**. Das Gerät
meldet „sendet", der PC zeigt nichts, und **nirgends steht eine Fehlermeldung**.

**Jetzt** liest die Station den Zustand **beim Start** und bei jeder Prüfung aus — in der App,
im `GERAETE-PRUEFEN.bat` und über `set-firewall.ps1 -Pruefen`. Ist der Zustand nicht eindeutig
lesbar, wird das als **„unklar"** gemeldet — **nicht** als „in Ordnung" behauptet.
Die Erkennung ist sprachunabhängig: gesucht wird der eigene Regelname, nicht ein übersetzter
Feldname.

### 2.7 Die Installation brach jedes Mal ab — Fragezeichen 🔴 schwerwiegend

```
IPersistFile::Save schlug fehl; Code 0x8007007B
Die Syntax für den Dateinamen ... ist falsch.
...\Start Menu\Programs\VetStation\2 Geraete pruefen (kommen Daten an?).lnk
```

**Ursache:** Der Verknüpfungsname endete auf ein **Fragezeichen**. Eine Verknüpfung wird als
`.lnk`-**Datei** gespeichert, und `\ / : * ? " < > |` sind in Windows-Dateinamen **verboten**.

**Warum besonders tückisch:** Der Abbruch kam **nach** dem Kopieren der Dateien. Die Installation
hinterließ eine halb eingerichtete Station — drei von fünf Verknüpfungen — und **setzte auf
diesem PC ein bereits installiertes 0.6.2 wieder auf 0.5.2 zurück.**

**Jetzt:** Name ohne Fragezeichen; `Install-VetStation.ps1` filtert verbotene Zeichen zusätzlich
**zur Laufzeit**; `paket-test` prüft **alle** Verknüpfungsnamen beider Installationswege gegen
die verbotenen Zeichen. Zusätzlich **warnt der Installer jetzt vor einem Rückschritt** auf eine
ältere Version und fragt nach, statt ihn stillschweigend auszuführen.

### 2.8 Startmenü-Einträge gab es nur bei der Inno-Variante

Wer über `INSTALLIEREN.bat` oder die neue Setup.exe installierte, bekam **gar keine** Einträge —
obwohl die Anleitung sie verspricht. **Jetzt** legt `Install-VetStation.ps1` sie selbst an
(sechs Einträge, inkl. der neuen Firewall- und Neustart-Dateien).

### 2.9 Nach einem Update lief weiter der alte Programmstand

`INSTALLIEREN.bat` beendete die laufende Station **nicht**. Der alte Code blieb im Speicher, und
weil der Prozess mit erhöhten Rechten läuft, ließ er sich nicht einmal im Task-Manager beenden.
Es gab **keinen vorgesehenen Weg**, die Station neu zu starten.

**Jetzt:**
- `INSTALLIEREN.bat` beendet die Station **vor** dem Kopieren, startet sie danach wieder und
  **prüft über `/api/version` nach**, ob der laufende Stand dem installierten entspricht.
  Stimmt es nicht, sagt es das deutlich.
- Die Kundenkonfiguration `bridge\config\devices.json` wird beim Kopieren **ausgenommen**.
- Zusätzlich neu: **`NEUSTART.bat`** (auch im Startmenü) für den Neustart per Doppelklick.

### 2.10 Setup.exe war nicht mehr baubar

Sie ließ sich **nur** mit Inno Setup erzeugen — das ist auf dem Praxis-PC nicht installiert und
ohne Internet auch nicht nachinstallierbar. Die ausgelieferte Setup.exe war damit **dauerhaft
auf 0.5.2 eingefroren**.

**Jetzt:** [make-setup-exe.ps1](../installer/make-setup-exe.ps1) baut sie mit **IExpress** —
in jedem Windows enthalten, kein Download nötig. Die Inno-Variante bleibt gepflegt.

> **Stolperstein, gemessen am 21.07.2026:** Mit `iexpress /N /Q` bricht der Bau **wortlos mit
> Exitcode 1** ab und erzeugt gar nichts. Mit `/N` **allein** läuft derselbe Aufbau durch — und
> zeigt trotzdem kein Fenster. Das steht als Kommentar im Skript, damit es niemand erneut sucht.

### 2.11 Veraltete Geräte-IPs in der Konfigurationsvorlage

`devices.example.json` nannte `192.168.23.240` / `.251` — Adressen, die es im Praxisnetz **nicht
gibt**. Wer die Vorlage übernahm, trug falsche Ziele ein und suchte den Fehler danach in der
Software. **Jetzt** `192.168.0.50` / `.51`; `paket-test` prüft die Vorlage mit — inklusive
Auslieferungszustand (Assistent an, Simulator aus, Fern-Live aus).

### 2.12 Zwei Tests logen

- `paket-test` scheiterte an **CRLF-Zeilenenden** statt am Inhalt — ein Fehler, der keiner war.
  Der Test normalisiert die Zeilenenden jetzt vor dem Vergleich.
- `port3502-test` meldete auf **jedem PC mit laufender Station 6 falsche Fehler**, weil der
  belegte Port nicht erkannt wurde. Auf einem Praxis-PC sah das aus, als sei die Geräteanbindung
  kaputt — dabei belegte nur die eigene Station den Port.
  **Jetzt** wird der Fall erkannt und als *übersprungen* ausgewiesen. Nachgemessen:

  ```
  ○ Port 3502 ist bereits belegt — vermutlich laeuft VetStation.
    Das ist der ERWARTETE Zustand im Betrieb, kein Defekt.
  == Ergebnis: 4 OK, 0 FAIL, 7 uebersprungen ==
  ```

### 2.13 Büro-PCs und Drucker galten als „mögliche Geräte"

Nach der Suche blieben sieben Kandidaten übrig, **keiner** davon ein Medizingerät.
**Jetzt** werden Windows-Dateifreigabe (445/139), Remotedesktop (3389), Druckerports
(9100/515/631), das Gateway und Zufalls-MACs erkannt und der Teilnehmer **mit Begründung**
herabgestuft. Ein offener HL7-Datenport oder eine Mindray-MAC schlägt diese Erkennung aber
**immer** — ein Monitor bleibt ein Monitor. Ports 80/443 gelten bewusst **nicht** als
Fremdmerkmal, weil Monitore selbst eine Web-Konfiguration mitbringen.

---

## 3. Neu in 0.6.0: die Station prüft ihr Netz selbst

Drei Stellen, dieselbe Logik — Check und App können sich nicht mehr widersprechen:

| Wo | Wann | Was |
|---|---|---|
| **Beim Start der Station** | automatisch, ~1 s | PC-Adresse gegen das Monitor-Ziel, Firewall je Port |
| **Admin ▸ Netzwerk & Geräte** | auf Klick, im Praxisnetz **7 s** gemessen | vollständige Suche `.1–.254` + Portscan + Diagnose |
| **`GERAETE-PRUEFEN.bat`** | auf Doppelklick | dasselbe im Klartext für die Konsole, plus Lauschphase |

**Am 21.07.2026 gegen das echte Netz gemessen** — 11 Teilnehmer in 7 Sekunden, jeder mit
Begründung eingestuft:

```
· 192.168.0.1     unwahrscheinlich  ist das Standardgateway (Router) — kein Medizingeraet
· 192.168.0.104   unwahrscheinlich  Drucker (LPD) offen (Port 515) | Drucker (IPP) offen (Port 631)
                                    | Drucker (RAW/JetDirect) offen (Port 9100) | kein Medizingeraet
· 192.168.0.44    unwahrscheinlich  Zufalls-MAC (Handy/Laptop mit Privatsphaere-Modus)
? 192.168.0.60    moeglich          antwortet im Netz, aber kein Datenport offen
```

Dabei fiel ein Punkt auf, den vorher **niemand** hätte sehen können: In **einem von drei**
Messläufen antwortete **`192.168.0.99`** — obwohl der PC `192.168.0.233` hat. Die Adresse, auf
die der PC gesetzt werden soll, war in diesem Moment also von einem **anderen** Gerät belegt.
Dass sie in den anderen Läufen still war, macht es nicht besser, sondern schlechter: genau so
verhält sich eine **per DHCP wandernde Adresse**. Wer in so einem Moment
`NETZWERK-EINRICHTEN.bat` ausführt, baut sich einen **Adresskonflikt**, und die Verbindung fällt
danach sporadisch aus — der schwerste Fehler zum Suchen, weil er nicht reproduzierbar ist.
Die Diagnose meldet das jetzt **vorher** (`ZIEL_IP_BESETZT`), statt den Konflikt entstehen zu
lassen. Es ist zugleich der beste Beleg für die Empfehlung aus §1.2: **eigener Geräte-Switch,
oder `.50`/`.51`/`.99` im Router aus dem DHCP-Bereich nehmen.**

Die Suche schließt außerdem eine Lücke, die reines TCP-Anklopfen offen lässt: Geräte, die Pakete
auf geschlossenen Ports **still verwerfen**, sehen im Scan wie „niemand da" aus. Auf ARP-Ebene
antworten sie aber immer — und weil das Anklopfen die ARP-Auflösung ohnehin erzwungen hat, werden
sie aus der MAC-Tabelle **nachgetragen** statt übersehen (im Messlauf betraf das 11 Adressen).

Die Oberfläche zeigt oben **einen Satz** („Datenverbindung steht" / „Windows-Firewall blockiert
5 Datenports"), darunter die **rangierten Ursachen** — jede mit *warum* und *was jetzt zu tun ist* —
und darunter jeden gefundenen Teilnehmer mit Begründung seiner Einstufung.

**Vier Regeln, die die Diagnose einhält** (durch [diagnose-test.js](../tools/diagnose-test.js)
erzwungen):

1. Jeder Befund hat eine **Begründung**.
2. Jeder Befund hat mindestens einen **konkreten nächsten Schritt**.
3. Was nicht geprüft wurde, heißt **„ungeprüft"** — nie „in Ordnung".
4. Solange keine Werte ankommen, lautet das Urteil **nie „ok"**.

---

## 4. Anleitung für einen weiteren PC

### 4.1 Neuinstallation

1. **`VetStation-Setup.exe`** (~26 MB) auf USB-Stick kopieren → am Ziel-PC **doppelklicken**.
   Der Ziel-PC braucht **nichts** weiter (portables Node ist enthalten).
2. **`NETZWERK-EINRICHTEN.bat`** → feste IP `192.168.0.99`.
3. Am Monitor: Wartung → Benutzer-Wartung (`888888`) → Netzwerk
   - Adresstyp **MANUELL**, IP `192.168.0.50`, Maske `255.255.255.0`
   - Gateway-Kommunikationseinst.: Ziel `192.168.0.99`, Port `3502`, „Real Data Send" **EIN**
4. **`GERAETE-PRUEFEN.bat`** → dauert ~1 Minute, sagt im Klartext, was fehlt.

### 4.2 Update eines vorhandenen PCs

**`INSTALLIEREN.bat` doppelklicken** — beendet die Station, aktualisiert, startet neu und prüft
nach. Die Konfiguration (`bridge\config\devices.json`) bleibt **erhalten**.

### 4.3 Prüfliste — auf jedem PC einzeln abhaken

| # | Prüfung | Soll | Womit |
|---|---|---|---|
| 1 | PC-IP | `192.168.0.99`, fest (kein DHCP) | Station sagt es beim Start |
| 2 | Firewall | **genau 5** Regeln „VetStation Geraetedaten TCP …" | `FIREWALL-FREIGEBEN.bat` bzw. Start-Meldung |
| 3 | Version Platte = Speicher | gleich | Installer prüft selbst nach |
| 4 | Monitor erreichbar | `.50` antwortet, Datenport offen | Admin ▸ Netzwerk & Geräte |
| 5 | Netzform | eigener Switch, **kein** Router-Netz | Diagnose warnt selbst |
| 6 | Fern-Live | aus, solange keine Datenbank existiert | `devices.json` |
| 7 | Selbsttests | alle grün | `node\node.exe tools\alle-tests.js` |

### 4.4 Setup neu bauen (auf jedem Windows, ohne Internet)

**`SETUP-BAUEN.bat` doppelklicken.** Es fährt erst alle Selbsttests und baut **kein** Setup,
wenn einer fehlschlägt. Danach entstehen in `dist\` **drei** Dinge:

| Datei | Wofür |
|---|---|
| `VetStation-Setup.exe` | Erstinstallation — auf USB-Stick, am Praxis-PC doppelklicken |
| `VetStation-0.6.0.zip` | **Update-Paket** für *Admin ▸ Aktualisieren* (ohne USB-Stick) |
| `VetStation-Setup.zip` | dasselbe als Ordner-Kopie |

> Das **Update-Paket war bis 0.6.0 reine Handarbeit** — und wurde prompt vergessen: es gab eine
> neue Setup.exe, aber nichts, womit eine bereits laufende Station hätte nachziehen können.
> `make-dist.ps1` erzeugt es jetzt mit, nennt die **sha256-Prüfsumme** fürs Manifest und warnt,
> falls `node\` hineingerät (das macht aus 0,7 MB einen 27-MB-Download).
> [update-paket-test.js](../tools/update-paket-test.js) prüft das Ergebnis mit.

Von Hand ginge auch:

```powershell
powershell -ExecutionPolicy Bypass -File "D:\VetStation\installer\make-dist.ps1"
powershell -ExecutionPolicy Bypass -File "D:\VetStation\installer\make-setup-exe.ps1"
```

**Nachgewiesen am 21.07.2026** — beides von Ende zu Ende geprüft, ohne etwas am System zu ändern:

- **Setup.exe:** wieder ausgepackt (`/Q /C /T:`, ohne Installationslauf) → alle drei
  Versionsstellen 0.6.0, alle neuen Bausteine vorhanden, **32 Dateien bytegleich** mit dem
  Quellstand, portables Node (67 MB) dabei — und die Station **startet aus dem ausgelieferten
  Paket** und antwortet `{"version":"0.6.0"}`.
- **Update-Weg:** eine echte 0.5.2-Station aufgebaut, das 0.6.0-Paket gestaget und
  `Apply-StagedUpdate` laufen lassen → danach 0.6.0, neue Module da, und **die
  Kundenkonfiguration `devices.json` sowie `data\` haben überlebt**. Dieser Weg war vorher nie
  nachgestellt worden.

---

## 5. Absicherung gegen Rückfälle

Damit keiner dieser Fehler unbemerkt zurückkehrt, laufen **18 Testdateien mit 486 Prüfungen**
(`npm test` bzw. `node\node.exe tools\alle-tests.js`). Neu hinzugekommen:

| Test | Sichert ab | Prüfungen |
|---|---|---|
| [netscan-test.js](../tools/netscan-test.js) | Gerätesuche, Einstufung, Fremdgeräte-Erkennung | 55 |
| [diagnose-test.js](../tools/diagnose-test.js) | „wo liegt das Problem" — inkl. der vier Ehrlichkeitsregeln | 47 |
| [version-test.js](../tools/version-test.js) | eine Quelle der Wahrheit für die Version | 11 |
| [hl7-reconnect-test.js](../tools/hl7-reconnect-test.js) | keine Log-Flutung bei abwesendem Gerät | 21 |
| [update-paket-test.js](../tools/update-paket-test.js) | Update-Paket vorhanden, ohne `node\`/`data\`, vollständig | 32 |
| [paket-test.js](../tools/paket-test.js) | Verknüpfungsnamen, Auslieferungszustand, IPs, Installer, Bauweg | 135 |
| [alle-tests.js](../tools/alle-tests.js) | fährt alles der Reihe nach, eine Ergebniszeile | — |

---

## 8. Nachtrag 22.07.2026 — erste echte Geräte am Netz (Version 0.7.0)

Die Geräte hingen erstmals wirklich am PC. Damit kamen drei neue Befunde ans Licht, die vorher
gar nicht auftreten konnten.

### 8.1 Die Oberfläche flackerte ununterbrochen und war unbedienbar 🔴 schwerwiegend

**Meldung aus der Praxis:** *„Es blinzt das App ständig und man kann gar nicht mit der App
arbeiten, wenn sie sich mit dem Monitor verbindet. Es wird auch nicht bewertet und die Daten vom
Gerät werden nicht richtig gelesen."*

**Ursache:** In `refresh()` stand `grid.appendChild(w.wrap)`, um die Patientenfenster nach
Priorität zu sortieren. Das **verschiebt** den Knoten im DOM — und ein verschobenes `<iframe>`
verliert seinen Browsing-Kontext und **lädt komplett neu**. Weil `refresh()` an jeder
Patienten-Nachricht hängt (Takt **500 ms**), wurden alle Fenster **zweimal pro Sekunde** neu
geladen. Der `load`-Handler rief danach wieder `refresh()` auf und verstärkte das Ganze.

Das erklärt alle drei Beschwerden auf einmal: das Flackern, die Unbedienbarkeit — und dass
**nichts bewertet** wurde. Denn `drive()` steigt aus, solange das Dokument im Fenster nicht
fertig geladen ist; bei einem Neuladen alle 500 ms kam die Anästhesie-App **nie so weit**, die
Werte überhaupt entgegenzunehmen.

**Behoben:** Die Reihenfolge wird jetzt über die CSS-Eigenschaft `order` gesetzt — rein visuell,
**ohne den DOM anzufassen**. Der `load`-Handler führt nur noch sein eigenes Fenster nach.

> Drei unabhängige Prüfer sollten diesen Befund **widerlegen**; keiner konnte es. Einer hat das
> Verhalten in headless Chromium nachgemessen: ein verschobenes iframe lädt neu — sogar dann,
> wenn es das **einzige** Fenster ist und sich die Position gar nicht ändert. Genau dieser Fall
> lag in der Praxis vor (nur ein Gerät gefunden). Einzige Ausnahme wäre `moveBefore()`
> (Chromium 133+); `insertBefore`/`append`/`prepend` laden alle neu.

**Nachgemessen im Browser, 4 Fenster:**

| | alter Code | jetzt |
|---|---|---|
| Neuladungen in 45 s (91 Takte) | ≈ 360 | **0** |
| Eingabe im Koppel-Dialog | beim ersten Takt weg | **erhalten** |
| Werte in der App | kamen nie an | **HF/SpO₂/EtCO₂ gesetzt, Befund berechnet** |

### 8.2 Drei weitere Stellen derselben Art — vom Prüferteam gefunden

Die adversarische Prüfung fand drei Folgefehler, die nach der ersten Korrektur **geblieben wären**:

- **Der Koppel-Dialog** (`renderPairing`) wurde ebenfalls 2×/s komplett neu geschrieben. Wer dort
  Gewicht oder Patienten-ID **tippte**, verlor Feld und Fokus sofort. Jetzt wird er nur bei
  geänderten Gerätedaten neu gebaut — und **nie**, solange der Anwender in einem Feld schreibt.
- **Fenster wurden bei jedem Aussetzer zerstört.** Fiel ein Gerät kurz aus (genau der Fall bei
  wackeliger Verbindung), verschwand der Patient sofort und das Fenster wurde neu aufgebaut.
  Jetzt gilt eine **Schonfrist von 20 s**.
- **Wechselte der Patientenschlüssel** (Gerät liefert die Patienten-ID mal mit, mal nicht),
  entstand ein neues Fenster. Jetzt wird das vorhandene Fenster **übernommen**, wenn es dieselben
  Geräte betrifft.

### 8.3 Der Verbindungs-Check blieb stehen 🔴

Am Praxis-PC endete die Prüfung wortlos bei `HL7-Abfrage auf Port 4601 ...`.

**Ursache:** Die Frist war eine **Leerlauf**-Frist. Ein Gerät, das dauernd Daten schickt, die kein
`MSH` enthalten, setzt diesen Timer bei jedem Paket zurück — das Zeitüberschreitungs-Ereignis kam
nie, und die Prüfung löste sich **nie** auf. Genau das tut ein Mindray-Gerät, das auf diesem Port
sein proprietäres **MD2** spricht.

**Behoben:** eine Frist, die **unabhängig vom Datenverkehr** läuft. Und der Fall ist jetzt kein
Hänger mehr, sondern ein **wertvoller Befund**:

```
✗ antwortet, aber KEIN HL7 (940 Bytes empfangen, Anfang: 027e0041...) —
  vermutlich ein proprietaeres Protokoll (z. B. Mindray MD2)
```

Dazu kommt sichtbarer Fortschritt während der 20-Sekunden-Lauschphase — vorher sah das Warten
wie ein Absturz aus.

### 8.4 Neue Erkenntnisse über die Geräte

| Befund | Bedeutung |
|---|---|
| LifeVet 10C stand auf **192.168.0.1** | Das ist die Router-Adresse. Das Gerät meldete selbst `LAN1-IP-Adressenkonflikt` und war für die Suche **unsichtbar** — nur ein Gerät wurde gefunden. Die Diagnose erkennt das jetzt (`GERAET_AUF_GATEWAY`). |
| LifeVet sendet HL7 an **192.168.2.16:8830** | Falsches Netz. **Port 8830** ist ab Werk eingestellt — VetStation lauscht ab 0.7.0 selbst darauf, damit am Gerät **nur die Ziel-IP** geändert werden muss. |
| LifeVet Datenintervall **30 s** | Für eine Narkose zu träge — auf den kleinsten Wert stellen. |
| Narkosegerät antwortet auf 4601, aber ohne HL7 | Es spricht dort MD2. **MD2 nicht einschalten** — VetStation versteht es nicht, und geratene Vitalwerte wären am Patienten gefährlich. Die Werte kommen vom Monitor. |

Vollständige Anleitung mit den exakten Werten: **[GERAETE-EINSTELLEN.md](GERAETE-EINSTELLEN.md)**.

---

## 6. Was noch offen ist

| Punkt | Status |
|---|---|
| Monitor anschließen | Gerät war während der Prüfung nicht am Netz |
| `CMS auswählen: Aus` am Monitor | prüfen, falls trotz allem keine Daten kommen — Diagnose nennt es |
| Fern-Live-Datenbank | in der Firebase-Konsole anlegen ([FERN-LIVE.md](FERN-LIVE.md)) |
| Eigener Geräte-Switch | empfohlen statt gemeinsamem Router-Netz |
| Inno Setup | nicht vorhanden; **nicht mehr nötig** (IExpress-Weg) |
| `make-dist.ps1` löscht sich beim Lauf selbst | **Spur gefunden — siehe §7.** Nicht mehr „unerklärlich": es liegt sehr wahrscheinlich am Virenschutz, nicht am Skript. Die Selbstheilung greift weiterhin und stellt **exakt den Stand dieses Laufs** wieder her, kann also nichts Altes zurückspielen. |

---

## 7. Der Virenschutz löscht PowerShell-Skripte — das kann auch die Installation treffen

Beim Prüfen der Setup.exe verschwanden **zwei weitere `.ps1`-Dateien** direkt nach ihrem Lauf —
in einem völlig anderen Ordner (Temp) und ohne jeden Bezug zu VetStation. Damit ist klar:
**das Problem liegt nicht in `make-dist.ps1`.** Was gemessen wurde:

| Beobachtung | Befund |
|---|---|
| Windows Defender | **Echtzeitschutz AUS**, keine einzige Erkennung in 24 h — Defender ist es nicht |
| Registrierte Schutzprogramme | **360 Total Security** (`QHSafeTray`, `360webshield` laufen), es hat Defender verdrängt |
| 360-HIPS-Protokoll `deepscan\hips_uploadlog.dat` | geschrieben **06:19:06** — genau in dem Moment, in dem eines der verschwundenen Skripte lief |
| Betroffene Skripte | die, die „installerartig" arbeiten: Dateien entpacken, Prozesse starten, aus dem Internet laden |
| Nicht betroffen | reine Lese-/Prüfskripte und `.js`-Dateien |

**Warum das für die Praxis zählt:** Läuft 360 Total Security (oder ein ähnlich aggressives
Schutzprogramm) auch auf dem Praxis-PC, kann es `Install-VetStation.ps1`, `set-firewall.ps1`
oder `launch-kiosk.ps1` **mitten im Lauf entfernen oder blockieren**. Das sieht dann exakt aus
wie „die Software ist kaputt" — ist es aber nicht.

**Empfehlung für jeden PC, auf dem VetStation läuft:**

1. Im Schutzprogramm eine **Ausnahme für den Ordner `C:\VetStation`** eintragen
   (bei 360 Total Security: *Einstellungen ▸ Weiße Liste ▸ Ordner hinzufügen*).
2. Auf dem Entwickler-PC zusätzlich `D:\VetStation`.
3. Bricht eine Installation unerklärlich ab: **zuerst prüfen, ob die `.ps1`-Datei überhaupt noch
   da ist**, bevor man den Fehler in der Software sucht.

> Ehrlich bleibt: ein Quarantäne-**Eintrag** mit Dateinamen liess sich nicht auslesen (360 legt
> ihn nicht offen ab). Die Beweiskette ist damit stark, aber **nicht** hundertprozentig
> geschlossen — deshalb steht sie hier als begründeter Verdacht, nicht als Tatsache.

### 7.1 Die Setup.exe ist nicht signiert — Windows 11 kann sie blockieren 🔴

Beim letzten Abnahmelauf ließ sich die frisch gebaute `VetStation-Setup.exe` **nicht mehr
starten**:

```
Eine Anwendungssteuerungsrichtlinie hat diese Datei blockiert.
```

Ursache gemessen: **Smart App Control** ist auf diesem Windows 11 **erzwungen**
(`VerifiedAndReputablePolicyState = 1`). Diese Funktion blockiert Programme ohne gültige
Signatur und ohne Reputation — und genau das ist eine selbst gebaute Setup.exe. Beim Bau davor
lief dieselbe Datei noch; die Prüfung ist reputationsbasiert und damit **nicht vorhersagbar**.

| | |
|---|---|
| **Betroffen** | Windows-11-PCs mit aktivem Smart App Control (nur bei Neuinstallationen ab Werk an) |
| **Nicht betroffen** | Windows 10 — dort gibt es Smart App Control nicht. Der Praxis-PC läuft auf **Win10 Pro 22H2**. |
| **Nicht betroffen** | Der Ordner-/ZIP-Weg (siehe unten) — `.bat` und `.ps1` fallen nicht darunter |

**Ausweichweg, der ohne Signatur funktioniert** (und ohne Schutzfunktionen abzuschalten):

1. `dist\VetStation-Setup.zip` auf den Ziel-PC kopieren und entpacken.
2. Im entpackten Ordner **`INSTALLIEREN.bat` doppelklicken** — macht exakt dasselbe wie die
   Setup.exe.

**Dauerhafte Lösung** wäre ein **Code-Signing-Zertifikat** (kostenpflichtig, jährlich, auf den
Praxisinhaber ausgestellt). Damit wären Setup.exe und alle Skripte signiert und weder von Smart
App Control noch von 360 Total Security angreifbar. Das ist eine **Kosten- und
Beschaffungsentscheidung** — deshalb hier nur benannt, nicht eigenmächtig veranlasst.

> **Bitte Smart App Control NICHT einfach abschalten**, nur damit das Setup läuft: es lässt sich
> danach **nicht wieder einschalten** (nur durch Neuinstallation von Windows), und es schützt
> den Rechner, auf dem Patientendaten laufen.
