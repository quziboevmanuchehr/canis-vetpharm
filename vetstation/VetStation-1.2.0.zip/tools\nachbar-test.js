'use strict';
/*
 * nachbar-test.js — sichert den LAN-Weg zwischen zwei Praxis-PCs ab (bridge/src/nachbar.js).
 *
 * Was hier NIE wieder passieren darf:
 *   • Eine Station spricht mit SICH SELBST und beschriftet das Ergebnis als Nachbarsaal. Das ist
 *     Befund A2-8 und es ist toedlich: docs/LAN-SETUP.md schreibt JEDEM Praxis-PC 192.168.0.99
 *     vor, ein Doppelstart auf demselben PC ist ohnehin moeglich — der Tierarzt saehe die Werte
 *     SEINES Tieres ein zweites Mal, unter dem Namen des anderen Saals, ohne jede Chance, den
 *     Irrtum zu bemerken. Geprueft werden alle drei Sperren: erwartete sid, eigene sid, eigene
 *     Instanz.
 *   • Der Handschlag wird zum SIGNIER-ORAKEL (Befund B1-1). Die Signatur muss BEIDE fluechtigen
 *     Schluessel binden; wer sie an eine dritte Station weiterreicht, darf damit nichts anfangen.
 *   • Der Port ist als VetStation erkennbar, ohne dass jemand etwas bewiesen hat. Ohne gueltige
 *     sigA gibt es 404, nicht 401 (Befund A1-7/C1-12).
 *   • Ein Fremder im Netz laesst diesen Prozess fuer sich rechnen. Alle Deckel stehen VOR jeder
 *     Krypto-Arbeit — das wird unten am Verhalten UND an der Reihenfolge im Quelltext geprueft.
 *   • Der Port bindet 0.0.0.0 und damit auch die VPN- oder Overlay-Karte (Befund C1-11).
 *   • Ein geaenderter oeffentlicher Schluessel wird still uebernommen (Befund A1-3/B1-6/C1-3).
 *   • Zwei Praxen werden ueber das Hausnetz verbunden (Befund B1-13).
 *   • nachbar.js laedt registry, matching oder einen Adapter — dann koennen fremde Daten
 *     registry.ingest erreichen, und daran haengt die halbe Fehlerliste.
 *   • Es gibt /nachbar/protokoll oder Kurven ueber LAN.
 *
 * OHNE NETZ, OHNE ECHTE UHR: die Zeit ist immer ein Argument (cfg.jetzt), und der einzige Socket
 * ist eine Schleife ueber 127.0.0.1 im selben Prozess. Zwei Nachbar-Instanzen sprechen dort
 * miteinander; unterschieden werden sie ueber den Port, nicht ueber die Adresse.
 *
 * Start: node tools/nachbar-test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const N = require('../bridge/src/nachbar');
const S = require('../bridge/src/stationsid');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

// Feste Uhr. Alles, was altert, altert unten durch RECHNEN, nicht durch Warten.
let uhr = 1800000000000;
const jetzt = () => uhr;

const SID_A = 'st7f3a91c2b45d';
const SID_B = 'stb1c2d3e4f506';
const SID_C = 'st0011223344ff';
const UID = 'praxisKonto0815';
const UID_FREMD = 'eineAnderePraxis';

const PORT_A = 18771;
const PORT_B = 18772;
const PORT_C = 18773;

const stille = { info() {}, warn() {}, error() {} };
const tempDateien = [];
function tempDatei(name) {
  const p = path.join(os.tmpdir(), 'vetstation-nachbar-' + process.pid + '-' + name + '.json');
  tempDateien.push(p);
  return p;
}

/* Eine Station nachbauen: Schluesselpaar aus stationsid.js, sonst nichts. Genau die vier Dinge,
 * die nachbar.js benutzt — mehr darf es nicht brauchen. */
function station(sid, instanz) {
  const paar = S.ed25519Paar();
  return {
    sid: () => sid,
    pub: () => paar.pub,
    fp: () => paar.fp,
    instanz: instanz,
    signiere: (m) => S.signiereMit(paar.priv, m),
    _pub: paar.pub,
    _priv: paar.priv,
  };
}

const warte = (ms) => new Promise((r) => setTimeout(r, ms));
async function bis(pruef, versuche) {
  for (let i = 0; i < versuche; i++) { if (pruef()) return true; await warte(5); }
  return pruef();
}

/* Eine Anfrage an den Nachbar-Port, roh — damit der Test auch die Faelle stellen kann, die die
 * Clientseite von nachbar.js gar nicht erst sendet. */
function hole(port, weg, rahmen, methode) {
  return new Promise((resolve) => {
    const kopf = {};
    if (rahmen === '') kopf['X-VS'] = '';
    else if (typeof rahmen === 'string') kopf['X-VS'] = rahmen;
    else if (rahmen) kopf['X-VS'] = Buffer.from(JSON.stringify(rahmen), 'utf8').toString('base64');
    let fertig = false;
    const ende = (r) => { if (!fertig) { fertig = true; resolve(r); } };
    const req = http.request({ host: '127.0.0.1', port: port, path: weg, method: methode || 'GET', headers: kopf, agent: false }, (res) => {
      let t = '';
      res.setEncoding('utf8');
      res.on('data', (s) => { t += s; });
      res.once('end', () => {
        let obj = null;
        try { obj = JSON.parse(t.split('\n')[0]); } catch (e) { obj = null; }
        ende({ status: res.statusCode, headers: res.headers, text: t, obj: obj });
      });
    });
    req.once('error', () => ende({ status: 0, headers: {}, text: '', obj: null }));
    req.setTimeout(1500, () => { try { req.destroy(); } catch (e) { /* schon zu */ } ende({ status: 0, headers: {}, text: '', obj: null }); });
    req.end();
  });
}

/*
 * Kommentare aus dem Quelltext entfernen — dieselbe Bauart wie in tools/tafel-test.js, aus
 * demselben Grund: der Kopfkommentar von nachbar.js nennt registry, matching, dgram, den
 * Upgrade-Handler und /nachbar/protokoll AUSDRUECKLICH beim Namen, weil dort steht, WARUM es sie
 * nicht gibt. Ein Test, der am blossen Vorkommen des Wortes rot wird, erzieht dazu, die
 * Begruendung wegzulassen — und die Begruendung ist das Wertvollste an der Datei.
 * Zeichenweise mit Texterkennung, weil ein '//' innerhalb einer Zeichenkette oder eines regulaeren
 * Ausdrucks kein Kommentar ist. Die Texterkennung wird an jedem Zeilenende zurueckgesetzt: diese
 * Datei ist kein JS-Zerleger, und ein Irrtum soll auf SEINE Zeile beschraenkt bleiben. Er wirkt
 * dann in die sichere Richtung — im Zweifel bleibt Text stehen, der Test wird eher zu Unrecht rot
 * als zu Unrecht gruen.
 */
function ohneKommentare(t) {
  const zeilen = String(t == null ? '' : t).split('\n');
  let out = '';
  let imBlock = false;
  for (let z = 0; z < zeilen.length; z++) {
    const zeile = zeilen[z];
    let i = 0;
    let marke = '';
    while (i < zeile.length) {
      const c = zeile[i];
      if (imBlock) {
        if (c === '*' && zeile[i + 1] === '/') { imBlock = false; i += 2; continue; }
        i++; continue;
      }
      if (marke) {
        if (c === '\\') { out += c + (zeile[i + 1] || ''); i += 2; continue; }
        if (c === marke) marke = '';
        out += c; i++; continue;
      }
      if (c === '"' || c === '\'' || c === '`') { marke = c; out += c; i++; continue; }
      if (c === '/' && zeile[i + 1] === '/') break;
      if (c === '/' && zeile[i + 1] === '*') { imBlock = true; i += 2; continue; }
      out += c; i++;
    }
    if (z < zeilen.length - 1) out += '\n';
  }
  return out;
}

// ============================================================ 1. Quelltext: was NICHT drin sein darf
const roh = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'nachbar.js'), 'utf8');
const quelle = ohneKommentare(roh);
const requires = (quelle.match(/require\((['"])[^'"]+\1\)/g) || []).join(' ');
console.log('\n1) Quelltext — die Abhaengigkeiten, die es nicht geben darf');
ok('nachbar.js laedt registry NICHT', requires.indexOf('registry') < 0, requires);
ok('nachbar.js laedt matching NICHT', requires.indexOf('matching') < 0, requires);
ok('nachbar.js laedt keinen Adapter', requires.indexOf('adapter') < 0, requires);
ok('nachbar.js laedt kein dgram (es gibt im ganzen Projekt keins, und das bleibt so)',
  requires.indexOf('dgram') < 0 && quelle.indexOf('dgram') < 0, requires);
ok('nachbar.js laedt nur Node-Bordmittel plus netscan/stationsid',
  /require\('http'\)/.test(requires) && /require\('\.\/netscan'\)/.test(requires)
  && /require\('\.\/stationsid'\)/.test(requires) && requires.indexOf('node_modules') < 0);
ok('keine CORS-Kopfzeile im Quelltext', !/Access-Control-Allow/i.test(quelle));
ok('kein Upgrade-Handler im Quelltext', !/on\(\s*['"]upgrade['"]/.test(quelle));
ok('jedes listen() bekommt eine Adresse mit (nie 0.0.0.0)',
  (quelle.match(/\.listen\(/g) || []).length === 1 && /\.listen\(this\.cfg\.port,\s*ip\)/.test(quelle));
ok('es gibt keinen Weg /nachbar/protokoll', quelle.indexOf('/nachbar/protokoll') < 0);
ok('die Wegliste enthaelt genau hallo und tafel',
  N.WEGE.length === 2 && N.WEGE.indexOf('/nachbar/hallo') >= 0 && N.WEGE.indexOf('/nachbar/tafel') >= 0,
  N.WEGE.join(','));
/* Gegenprobe: der Kuerzer darf keinen Code verschlucken. Gezaehlt werden die Methodenanfaenge —
 * sie stehen nur im Code, nie in einem Kommentarblock dieser Datei (der ist mit " * " eingerueckt). */
ok('ohneKommentare() verliert in nachbar.js keine einzige Funktion',
  (roh.match(/\n  _?[a-zA-Z]+\(/g) || []).length > 10
  && (roh.match(/\n  _?[a-zA-Z]+\(/g) || []).length === (quelle.match(/\n  _?[a-zA-Z]+\(/g) || []).length,
  (roh.match(/\n  _?[a-zA-Z]+\(/g) || []).length + ' vs ' + (quelle.match(/\n  _?[a-zA-Z]+\(/g) || []).length);

/* "Harte Deckel VOR jeder Krypto-Arbeit" ist eine Aussage ueber die REIHENFOLGE. Sie wird hier am
 * Quelltext geprueft, weil ein Verhaltenstest sie nur zufaellig trifft: wer die Deckel hinter die
 * Krypto schiebt, besteht jeden Verhaltenstest und hat trotzdem die Zusage gebrochen. */
const halloText = quelle.slice(quelle.indexOf('_hallo(von, r, res) {'), quelle.indexOf('_beweis(von, r, res) {'));
ok('_hallo prueft den Gesamtdeckel VOR dem fluechtigen Schluesselpaar',
  halloText.indexOf('verbindungenMax') > 0 && halloText.indexOf('verbindungenMax') < halloText.indexOf('epkPaar('));
ok('_hallo prueft den Deckel je Adresse VOR dem fluechtigen Schluesselpaar',
  halloText.indexOf('jeAdresseMax') > 0 && halloText.indexOf('jeAdresseMax') < halloText.indexOf('epkPaar('));
ok('_hallo prueft die Form VOR dem fluechtigen Schluesselpaar',
  halloText.indexOf('pruefeSid') > 0 && halloText.indexOf('pruefeSid') < halloText.indexOf('epkPaar('));
ok('_hallo prueft das Konto VOR dem Unterschreiben',
  halloText.indexOf('uid8Aus') < halloText.indexOf('signiere('));

// ============================================================ 2. die signierte Zeichenkette
console.log('\n2) Die signierte Zeichenkette — Wortlaut und Feldgrenzen');
const T = { uid8: 'a1b2c3d4', nonceA: 'a'.repeat(32), nonceB: 'b'.repeat(32), sidA: SID_A, sidB: SID_B, epkA: 'EPKA', epkB: 'EPKB' };
const z = N.signierZeichenkette(T);
ok('Wortlaut genau wie im Plan',
  z === 'vetstation-verbund-2|a1b2c3d4|' + 'a'.repeat(32) + '|' + 'b'.repeat(32) + '|' + SID_A + '|' + SID_B + '|EPKA|EPKB', z);
ok('sie beginnt mit vetstation-verbund-2|', z.indexOf(N.PRAEFIX) === 0);
ok('sie hat genau sieben Trennzeichen (eines im Praefix, sechs zwischen den sieben Feldern)',
  (z.match(/\|/g) || []).length === 7, String((z.match(/\|/g) || []).length));
ok('BEIDE fluechtigen Schluessel stehen darin', z.indexOf('EPKA') > 0 && z.indexOf('EPKB') > 0);
ok('vertauschte fluechtige Schluessel ergeben eine ANDERE Zeichenkette',
  N.signierZeichenkette(Object.assign({}, T, { epkA: 'EPKB', epkB: 'EPKA' })) !== z);
ok('ein fehlendes Feld ergibt null', N.signierZeichenkette(Object.assign({}, T, { epkB: undefined })) === null);
ok('ein leeres Feld ergibt null', N.signierZeichenkette(Object.assign({}, T, { uid8: '' })) === null);
ok('ein Feld mit | ergibt null (sonst verschieben sich die Feldgrenzen)',
  N.signierZeichenkette(Object.assign({}, T, { sidA: 'st00|00' })) === null);
ok('ohne Angabe ergibt sich null', N.signierZeichenkette(null) === null && N.signierZeichenkette({}) === null);

// ============================================================ 3. uid8
console.log('\n3) uid8 — gehoeren wir beide zur selben Praxis?');
ok('uid8 ist 8 Hexzeichen', /^[0-9a-f]{8}$/.test(N.uid8Aus(UID)));
ok('uid8 ist sha256(uid).slice(0,8)',
  N.uid8Aus(UID) === crypto.createHash('sha256').update(UID, 'utf8').digest('hex').slice(0, 8));
ok('dieselbe uid ergibt dasselbe uid8', N.uid8Aus(UID) === N.uid8Aus(UID));
ok('eine andere Praxis ergibt ein anderes uid8', N.uid8Aus(UID) !== N.uid8Aus(UID_FREMD));
ok('ohne uid gibt es kein uid8', N.uid8Aus(null) === null && N.uid8Aus('') === null && N.uid8Aus(7) === null);

// ============================================================ 4. Adressen
console.log('\n4) Adressen — nur das Hausnetz, und nur das eigene /24');
ok('192.168.0.5 ist Hausnetz', N.istRfc1918('192.168.0.5'));
ok('10.1.2.3 ist Hausnetz', N.istRfc1918('10.1.2.3'));
ok('172.16.0.1 und 172.31.255.254 sind Hausnetz', N.istRfc1918('172.16.0.1') && N.istRfc1918('172.31.255.254'));
ok('172.15.x und 172.32.x sind es NICHT', !N.istRfc1918('172.15.0.1') && !N.istRfc1918('172.32.0.1'));
ok('eine oeffentliche Adresse ist kein Hausnetz', !N.istRfc1918('8.8.8.8'));
ok('127.0.0.1 gilt nicht als Hausnetz (Loopback wird nie gebunden)', !N.istRfc1918('127.0.0.1'));
ok('169.254.x (APIPA) gilt nicht als Hausnetz', !N.istRfc1918('169.254.10.1'));
ok('Muell ist kein Hausnetz', !N.istRfc1918('999.1.1.1') && !N.istRfc1918('192.168.0') && !N.istRfc1918(null));
ok('imSelbenNetz: gleiches /24', N.imSelbenNetz('192.168.0.99', '192.168.0.20'));
ok('imSelbenNetz: anderes /24', !N.imSelbenNetz('192.168.0.99', '192.168.1.20'));
ok('imSelbenNetz: anderes /8', !N.imSelbenNetz('192.168.0.99', '10.0.0.1'));
ok('imSelbenNetz vertraegt Muell', !N.imSelbenNetz('1.2.3.4.5', '1.2.3.4') && !N.imSelbenNetz(null, '1.2.3.4'));
ok('ipRein loest die IPv4-in-IPv6-Form auf', N.ipRein('::ffff:192.168.0.5') === '192.168.0.5');
ok('ipRein schneidet die Zonenkennung ab', N.ipRein('fe80::1%eth0') === 'fe80::1');
ok('eine als IPv6 gemeldete IPv4 liegt im selben /24', N.imSelbenNetz('::ffff:192.168.0.5', '192.168.0.99'));

// ============================================================ 5. Sitzungsschluessel
console.log('\n5) Sitzungsschluessel — X25519, HKDF, AES-256-GCM');
const eA = N.epkPaar();
const eB = N.epkPaar();
const nA = 'a'.repeat(32), nB = 'b'.repeat(32);
const kA = N.sitzungsschluessel(eA.priv, eB.pub, nA, nB);
const kB = N.sitzungsschluessel(eB.priv, eA.pub, nA, nB);
ok('beide Seiten kommen auf denselben Schluessel', !!kA && !!kB && kA.equals(kB), kA && kA.toString('hex'));
ok('der Schluessel ist 32 Byte (AES-256)', kA.length === 32);
ok('ein anderes Salz ergibt einen anderen Schluessel',
  !N.sitzungsschluessel(eA.priv, eB.pub, nB, nA).equals(kA));
ok('ein DRITTER fluechtiger Schluessel ergibt einen anderen Schluessel',
  !N.sitzungsschluessel(eA.priv, N.epkPaar().pub, nA, nB).equals(kA));
ok('ein untergeschobener Ed25519-Schluessel ergibt null statt einer Ausnahme',
  N.sitzungsschluessel(eA.priv, S.ed25519Paar().pub, nA, nB) === null);
ok('Muell ergibt null', N.sitzungsschluessel(eA.priv, 'nicht base64 !!', nA, nB) === null
  && N.sitzungsschluessel(null, eB.pub, nA, nB) === null);

// ============================================================ 6. der Signier-Orakel-Angriff
console.log('\n6) Warum der Signier-Orakel-Angriff scheitert (Befund B1-1)');
const stA = station(SID_A, 'a'.repeat(16));
const stB = station(SID_B, 'b'.repeat(16));
const stC = station(SID_C, 'c'.repeat(16));
const u8 = N.uid8Aus(UID);
const echt = N.signierZeichenkette({ uid8: u8, nonceA: nA, nonceB: nB, sidA: SID_A, sidB: SID_B, epkA: eA.pub, epkB: eB.pub });
const sigB = stB.signiere(echt);
ok('die Unterschrift des Nachbarn prueft gegen seinen oeffentlichen Schluessel',
  S.pruefeSignatur(stB._pub, echt, sigB));
ok('sie prueft NICHT gegen den Schluessel einer dritten Station',
  !S.pruefeSignatur(stC._pub, echt, sigB));
const vertauscht = N.signierZeichenkette({ uid8: u8, nonceA: nA, nonceB: nB, sidA: SID_A, sidB: SID_B, epkA: eB.pub, epkB: eA.pub });
ok('vertauschte fluechtige Schluessel lassen die Unterschrift scheitern (der Weiterreicher kommt nicht durch)',
  !S.pruefeSignatur(stB._pub, vertauscht, sigB));
const dritter = N.epkPaar();
const untergeschoben = N.signierZeichenkette({ uid8: u8, nonceA: nA, nonceB: nB, sidA: SID_A, sidB: SID_B, epkA: dritter.pub, epkB: eB.pub });
ok('ein untergeschobener eigener fluechtiger Schluessel laesst sie ebenfalls scheitern',
  !S.pruefeSignatur(stB._pub, untergeschoben, sigB));
const anderesKonto = N.signierZeichenkette({ uid8: N.uid8Aus(UID_FREMD), nonceA: nA, nonceB: nB, sidA: SID_A, sidB: SID_B, epkA: eA.pub, epkB: eB.pub });
ok('ein fremdes uid8 laesst sie scheitern (Befund B1-13)', !S.pruefeSignatur(stB._pub, anderesKonto, sigB));
const andereZahl = N.signierZeichenkette({ uid8: u8, nonceA: 'c'.repeat(32), nonceB: nB, sidA: SID_A, sidB: SID_B, epkA: eA.pub, epkB: eB.pub });
ok('eine ausgetauschte Zufallszahl laesst sie scheitern (kein Wiedereinspielen)',
  !S.pruefeSignatur(stB._pub, andereZahl, sigB));
ok('eine verstuemmelte Unterschrift ergibt false statt einer Ausnahme',
  !S.pruefeSignatur(stB._pub, echt, 'xxxx') && !S.pruefeSignatur(stB._pub, echt, null));

// ============================================================ 7. Kandidaten
console.log('\n7) Kandidaten — Befund A2-8: nie mit sich selbst sprechen');
const kOpt = { eigeneSid: SID_A, eigeneAdressen: ['192.168.0.99'], port: 8771 };
const pubB = stB._pub, pubC = stC._pub;
ok('die EIGENE Stationskennung wird nie Nachbar',
  N.kandidaten([{ sid: SID_A, pub: pubB, ips: ['192.168.0.20'] }], kOpt).length === 0);
ok('die eigene Adresse faellt aus der Adressliste',
  N.kandidaten([{ sid: SID_B, pub: pubB, ips: ['192.168.0.99', '192.168.0.20'] }], kOpt)[0].ips.join(',') === '192.168.0.20');
ok('ein Saal, von dem nur die eigene Adresse bleibt, faellt ganz heraus',
  N.kandidaten([{ sid: SID_B, pub: pubB, ips: ['192.168.0.99'] }], kOpt).length === 0);
ok('ohne oeffentlichen Schluessel gibt es keinen Kandidaten',
  N.kandidaten([{ sid: SID_B, ips: ['192.168.0.20'] }], kOpt).length === 0);
ok('eine formwidrige Stationskennung faellt heraus',
  N.kandidaten([{ sid: '../fremd', pub: pubB, ips: ['192.168.0.20'] }], kOpt).length === 0);
ok('die Adressliste wird auf 4 gedeckelt',
  N.kandidaten([{ sid: SID_B, pub: pubB, ips: ['192.168.0.1', '192.168.0.2', '192.168.0.3', '192.168.0.4', '192.168.0.5'] }], kOpt)[0].ips.length === N.IPS_MAX);
ok('eine oeffentliche Adresse wird nicht angesprochen',
  N.kandidaten([{ sid: SID_B, pub: pubB, ips: ['8.8.8.8', '192.168.0.20'] }], kOpt)[0].ips.join(',') === '192.168.0.20');
ok('dieselbe Kennung zweimal ergibt einen Kandidaten',
  N.kandidaten([{ sid: SID_B, pub: pubB, ips: ['192.168.0.20'] }, { sid: SID_B, pub: pubC, ips: ['192.168.0.21'] }], kOpt).length === 1);
ok('mehr als acht Saele werden gedeckelt', (function () {
  const viele = [];
  for (let i = 0; i < 12; i++) viele.push({ sid: 'st' + String(i).padStart(12, '0'), pub: pubB, ips: ['192.168.0.' + (20 + i)] });
  return N.kandidaten(viele, kOpt).length === N.NACHBARN_MAX;
})());
ok('der Port wird uebernommen, sonst gilt die Vorgabe',
  N.kandidaten([{ sid: SID_B, pub: pubB, ips: ['192.168.0.20'], port: 9999 }], kOpt)[0].port === 9999
  && N.kandidaten([{ sid: SID_B, pub: pubB, ips: ['192.168.0.20'] }], kOpt)[0].port === 8771);
ok('eine leere oder unbrauchbare Liste ergibt eine leere Liste',
  N.kandidaten(null, kOpt).length === 0 && N.kandidaten([null, 7, 'x'], kOpt).length === 0);

// ============================================================ 8. Pinning
console.log('\n8) Pinning — ein geaenderter Schluessel wird NIE still uebernommen');
const neuB = { sid: SID_B, pub: pubB, ips: ['192.168.0.20'], port: 8771, name: 'OP 2' };
const p1 = N.pinPruefung(null, neuB, uhr);
ok('beim ersten Sehen wird gepinnt', p1.lage === 'neu' && p1.pub === pubB && !p1.nurCloud);
const gepinnt = { pub: pubB, ips: ['192.168.0.20'], port: 8771, gesehenAm: uhr };
ok('unveraendert heisst gleich', N.pinPruefung(gepinnt, neuB, uhr).lage === 'gleich');
ok('die Reihenfolge der Adressen loest keinen Alarm aus',
  N.pinPruefung({ pub: pubB, ips: ['192.168.0.21', '192.168.0.20'], gesehenAm: uhr },
    { sid: SID_B, pub: pubB, ips: ['192.168.0.20', '192.168.0.21'] }, uhr).lage === 'gleich');
const pPub = N.pinPruefung(gepinnt, { sid: SID_B, pub: pubC, ips: ['192.168.0.20'], name: 'OP 2' }, uhr);
ok('ein geaenderter oeffentlicher Schluessel ergibt "geaendert"', pPub.lage === 'geaendert' && pPub.feld === 'pub');
ok('und der NEUE Schluessel wird NICHT zurueckgegeben', pPub.pub === pubB && pPub.neuePub === pubC);
ok('und die Quelle faellt auf die Cloud zurueck', pPub.nurCloud === true);
ok('die Klartextmeldung nennt den Saal und den Admin-Bereich',
  pPub.meldung === 'Der Schluessel von OP 2 hat sich geaendert — im Admin-Bereich bestaetigen', pPub.meldung);
ok('ohne Namen steht die Kurzform der Kennung in der Meldung',
  N.pinPruefung(gepinnt, { sid: SID_B, pub: pubC, ips: ['192.168.0.20'] }, uhr).meldung
    === 'Der Schluessel von Saal ' + S.sidKurz(SID_B) + ' hat sich geaendert — im Admin-Bereich bestaetigen');
const pIps = N.pinPruefung(gepinnt, { sid: SID_B, pub: pubB, ips: ['192.168.0.77'], name: 'OP 2' }, uhr);
ok('geaenderte Adressen ergeben ebenfalls "geaendert" und werden nicht uebernommen',
  pIps.lage === 'geaendert' && pIps.feld === 'ips' && pIps.ips.join(',') === '192.168.0.20' && pIps.neueIps.join(',') === '192.168.0.77');
ok('bei nur geaenderten Adressen bleibt die Identitaet bewiesen — kein Rueckfall auf die Cloud',
  pIps.nurCloud === false);
ok('nach 30 Tagen verfaellt der Pin und wird neu gesetzt',
  N.pinPruefung(gepinnt, { sid: SID_B, pub: pubC, ips: ['192.168.0.20'] }, uhr + N.VERFALL_MS + 1).lage === 'verfallen');
ok('einen Tag vor dem Verfall gilt er noch',
  N.pinPruefung(gepinnt, { sid: SID_B, pub: pubC, ips: ['192.168.0.20'] }, uhr + N.VERFALL_MS - 86400000).lage === 'geaendert');
ok('eine unbrauchbare Angabe ergibt "unbrauchbar" und niemals Vertrauen',
  N.pinPruefung(null, { sid: 'kaputt', pub: pubB }, uhr).lage === 'unbrauchbar'
  && N.pinPruefung(null, { sid: SID_B, pub: 'kurz' }, uhr).lage === 'unbrauchbar'
  && N.pinPruefung(null, null, uhr).lage === 'unbrauchbar');

// ============================================================ 9. Rahmen
console.log('\n9) Rahmen — AES-256-GCM mit Sitzung, Richtung und Zaehler im AAD');
const key = kA;
const box = N.verpacke(key, 'sitz1', 'b', 3, { typ: 'tafel', satz: { sid: SID_B } });
ok('ein Rahmen traegt typ box, iv, tag und c', box.typ === 'box' && !!box.iv && !!box.tag && !!box.c);
ok('er laesst sich zurueckverwandeln', N.packeAus(key, 'sitz1', 'b', box).nutz.typ === 'tafel');
ok('mit der falschen Richtung nicht', N.packeAus(key, 'sitz1', 'a', box) === null);
ok('mit einer fremden Sitzung nicht', N.packeAus(key, 'sitz2', 'b', box) === null);
ok('mit einem veraenderten Zaehler nicht (kein Wiedereinspielen, Befund C1-4)',
  N.packeAus(key, 'sitz1', 'b', Object.assign({}, box, { n: 4 })) === null);
ok('mit einem fremden Schluessel nicht', N.packeAus(crypto.randomBytes(32), 'sitz1', 'b', box) === null);
ok('ein veraenderter Geheimtext faellt durch die Pruefsumme',
  N.packeAus(key, 'sitz1', 'b', Object.assign({}, box, { c: Buffer.from('anders').toString('base64') })) === null);
ok('Muell ergibt null statt einer Ausnahme',
  N.packeAus(key, 'sitz1', 'b', { typ: 'box' }) === null && N.packeAus(key, 'sitz1', 'b', null) === null);
ok('rahmenAusKopf nimmt nur die drei erlaubten Typen',
  !!N.rahmenAusKopf(N.kopfAusRahmen({ vs: 1, typ: 'hallo' }))
  && N.rahmenAusKopf(N.kopfAusRahmen({ vs: 1, typ: 'protokoll' })) === null);
ok('rahmenAusKopf lehnt eine falsche Fassung ab', N.rahmenAusKopf(N.kopfAusRahmen({ vs: 2, typ: 'hallo' })) === null);
ok('rahmenAusKopf lehnt eine Kopfzeile ueber 64 KB ab', N.rahmenAusKopf('A'.repeat(N.ZEILE_MAX + 1)) === null);
ok('rahmenAusKopf vertraegt Muell', N.rahmenAusKopf('####') === null && N.rahmenAusKopf(null) === null);
ok('die Deckel stehen fest: 8 Verbindungen, 2 je Adresse, 2 s Frist, 64 KB, 15 min, 15 s Socket',
  N.VERBINDUNGEN_MAX === 8 && N.JE_ADRESSE_MAX === 2 && N.HANDSCHLAG_MS === 2000
  && N.ZEILE_MAX === 65536 && N.SITZUNG_MAX_MS === 900000 && N.SOCKET_TIMEOUT_MS === 15000);
ok('Port 8771 und Takt 250 ms', N.PORT === 8771 && N.TAKT_MS === 250);
ok('der Verfall der gemerkten Nachbarn ist 30 Tage', N.VERFALL_MS === 30 * 24 * 3600 * 1000);

// ============================================================ 10. ohne Netz: das Verzeichnis
console.log('\n10) Nachbarverzeichnis — ohne Socket, mit gestellter Uhr');
function bau(sid, st, opt) {
  return new N.Nachbar({
    log: stille,
    stationsid: st,
    tafelQuelle: () => ({ meta: { sid: sid, instanz: st.instanz, name: 'Saal ' + sid.slice(-2) }, uebersicht: {} }),
    uidQuelle: () => UID,
    cfg: Object.assign({
      port: 0, jetzt: jetzt, datei: tempDatei(sid),
      adapterQuelle: () => [{ name: 'Ethernet', address: '192.168.0.99', netmask: '255.255.255.0', virtuell: false }],
    }, opt || {}),
  });
}
const v1 = bau(SID_A, stA);
v1.setzeNachbarn([{ sid: SID_B, pub: pubB, ips: ['192.168.0.20'], port: 8771, name: 'OP 2' }]);
ok('ein neuer Nachbar wird aufgenommen', v1.nachbarn().length === 1 && v1.nachbarn()[0].sid === SID_B);
ok('und es wartet nichts auf Bestaetigung', v1.status().wartet.length === 0);
v1.setzeNachbarn([{ sid: SID_A, pub: stA._pub, ips: ['192.168.0.30'], port: 8771 }, { sid: SID_B, pub: pubB, ips: ['192.168.0.20'], port: 8771, name: 'OP 2' }]);
ok('die eigene Kennung wird auch hier nie Nachbar', v1.nachbarn().every((n) => n.sid !== SID_A));
v1.setzeNachbarn([{ sid: SID_B, pub: pubC, ips: ['192.168.0.20'], port: 8771, name: 'OP 2' }]);
ok('ein geaenderter Schluessel nimmt den Saal SOFORT vom LAN-Weg', v1.nachbarn().length === 0);
ok('und stellt ihn in status().wartet',
  v1.status().wartet.length === 1 && v1.status().wartet[0].feld === 'pub'
  && v1.status().wartet[0].meldung.indexOf('im Admin-Bereich bestaetigen') > 0);
ok('bestaetigeSchluessel() fuer eine unbekannte Kennung tut nichts', v1.bestaetigeSchluessel('st000000000000') === false);
ok('bestaetigeSchluessel() uebernimmt den neuen Schluessel', v1.bestaetigeSchluessel(SID_B) === true
  && v1.nachbarn().length === 1 && v1.status().wartet.length === 0);
const v2 = bau(SID_A, stA, { datei: tempDatei('pin2') });
v2.setzeNachbarn([{ sid: SID_B, pub: pubB, ips: ['192.168.0.20'], port: 8771 }]);
uhr += N.VERFALL_MS + 1000;
v2._pinGeladen = false;                      // wie ein Neustart der Station nach 30 Tagen
v2.setzeNachbarn([]);
ok('ein gemerkter Nachbar verfaellt nach 30 Tagen', v2.nachbarn().length === 0);
uhr -= N.VERFALL_MS + 1000;
ok('status() nennt die Deckel im Klartext',
  v1.status().deckel.verbindungenMax === 8 && v1.status().deckel.jeAdresseMax === 2
  && v1.status().deckel.zeileMax === 65536);
ok('ohne Stationskennung startet der LAN-Weg gar nicht erst', (function () {
  const n = bau(SID_A, { sid: () => null, instanz: 'x'.repeat(16), signiere: () => null });
  n.start();
  const l = n.laeuft();
  n.stop();
  return l === false;
})());

// ============================================================ 11. mit Socket: 127.0.0.1
async function live() {
  console.log('\n11) Zwei Stationen im selben Prozess, ueber 127.0.0.1');
  /* adapterQuelle liefert hier ABSICHTLICH nichts: sonst versuchte der Test, 192.168.0.99 zu
   * binden — eine Adresse, die auf dem Rechner des Entwicklers gar nicht existiert. Gebunden wird
   * allein die Loopback-Naht. */
  const A = bau(SID_A, stA, { port: PORT_A, taktMs: 5, loopbackFuerTest: true, jeAdresseMax: 4, anfrageFristMs: 1000, adapterQuelle: () => [], datei: tempDatei('A') });
  const B = bau(SID_B, stB, { port: PORT_B, taktMs: 100000, loopbackFuerTest: true, jeAdresseMax: 4, adapterQuelle: () => [], datei: tempDatei('B') });
  const empfangen = [];
  A.aufTafel((sid, satz, quelleName) => empfangen.push({ sid: sid, satz: satz, quelle: quelleName }));
  B.start();
  A.start();
  B.setzeNachbarn([{ sid: SID_A, pub: stA._pub, ips: ['127.0.0.1'], port: PORT_A, name: 'OP 1' }]);
  A.setzeNachbarn([{ sid: SID_B, pub: stB._pub, ips: ['127.0.0.1'], port: PORT_B, name: 'OP 2' }]);

  ok('der Server bindet 127.0.0.1, nicht 0.0.0.0', B.status().gebunden.join(',') === '127.0.0.1');
  ok('der Server hat keinen Upgrade-Zuhoerer', B._lauscher[0].server.listenerCount('upgrade') === 0);
  ok('der Nachbar ist als Kandidat da (Loopback-Naht haengt die /24-Pruefung nicht aus)',
    A.nachbarn().length === 1 && A.nachbarn()[0].ips.join(',') === '127.0.0.1');

  const kam = await bis(() => empfangen.length > 0, 200);
  ok('der Handschlag gelingt und ein Tafel-Satz kommt an', kam, JSON.stringify(A.status().nachbarn[0] || {}));
  if (kam) {
    ok('er kommt unter der richtigen Stationskennung an', empfangen[0].sid === SID_B);
    ok('und mit der Quelle "lan"', empfangen[0].quelle === 'lan');
    ok('der Satz ist die Uebersicht des Nachbarn', empfangen[0].satz.meta.sid === SID_B);
    ok('der Nachbar gilt als ueber LAN erreichbar', A.status().nachbarn[0].ueberLan === true);
    ok('die Gegenseite hat den Beweis angenommen', B.status().zaehler.beweisGut >= 1);
    ok('und mindestens eine Uebersicht ausgeliefert', B.status().zaehler.tafelRaus >= 1);
  } else {
    ok('er kommt unter der richtigen Stationskennung an', false);
    ok('und mit der Quelle "lan"', false);
    ok('der Satz ist die Uebersicht des Nachbarn', false);
    ok('der Nachbar gilt als ueber LAN erreichbar', false);
    ok('die Gegenseite hat den Beweis angenommen', false);
    ok('und mindestens eine Uebersicht ausgeliefert', false);
  }
  A.stop();

  console.log('\n12) Was der Port NICHT beantwortet');
  const r405 = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo' }, 'POST');
  ok('alles ausser GET ergibt 405', r405.status === 405, String(r405.status));
  ok('und nennt GET als erlaubte Methode', String(r405.headers.allow || '') === 'GET');
  const rProt = await hole(PORT_B, '/nachbar/protokoll', { vs: 1, typ: 'hallo' });
  ok('/nachbar/protokoll gibt es nicht (404)', rProt.status === 404);
  const rKurven = await hole(PORT_B, '/nachbar/kurven', { vs: 1, typ: 'hallo' });
  ok('/nachbar/kurven gibt es auch nicht (404)', rKurven.status === 404);
  const rOhne = await hole(PORT_B, '/nachbar/hallo', null);
  ok('ohne Rahmen gibt es 404, nicht 401', rOhne.status === 404);
  const rTafelOhne = await hole(PORT_B, '/nachbar/tafel', { vs: 1, typ: 'box', sitzung: 'gibtsnicht', n: 1, iv: 'AAAA', tag: 'AAAA', c: 'AAAA' });
  ok('/nachbar/tafel ohne gueltige Sitzung gibt 404', rTafelOhne.status === 404);
  ok('keine Antwort traegt eine CORS-Kopfzeile',
    !r405.headers['access-control-allow-origin'] && !rProt.headers['access-control-allow-origin']);

  // ein Handschlag von Hand, damit auch die Fehlwege stellbar sind
  const meinEpk = N.epkPaar();
  const meinN = crypto.randomBytes(16).toString('hex');
  const rH = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: SID_A, uid8: N.uid8Aus(UID), nonceA: meinN, epkA: meinEpk.pub });
  ok('ein formgueltiges hallo wird beantwortet', rH.status === 200 && rH.obj && rH.obj.typ === 'hallo2', String(rH.status));
  ok('die Antwort nennt die Kennung des Nachbarn', rH.obj && rH.obj.sid === SID_B);
  ok('sie traegt eine Zufallszahl, einen fluechtigen Schluessel und eine Unterschrift',
    rH.obj && /^[0-9a-f]{32}$/.test(rH.obj.nonceB) && !!rH.obj.epkB && !!rH.obj.sigB);
  const rB = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'beweis', sitzung: rH.obj && rH.obj.sitzung, sigA: Buffer.from('x'.repeat(64)).toString('base64') });
  ok('OHNE GUELTIGE sigA gibt es 404 — nicht 401 und nicht 403', rB.status === 404, String(rB.status));
  ok('und die Sitzung ist danach weg (kein zweiter Versuch auf derselben)',
    (await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'beweis', sitzung: rH.obj && rH.obj.sitzung, sigA: 'AAAA' })).status === 404);

  const rFremd = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: SID_A, uid8: N.uid8Aus(UID_FREMD), nonceA: meinN, epkA: meinEpk.pub });
  ok('ein fremdes Praxis-Konto kommt nicht durch (Befund B1-13)', rFremd.status === 404);
  ok('und es wird gezaehlt', B.status().zaehler.fremdesKonto >= 1);
  const rSelbst = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: SID_B, uid8: N.uid8Aus(UID), nonceA: meinN, epkA: meinEpk.pub });
  ok('wer die EIGENE Kennung des Nachbarn behauptet, kommt nicht durch (Befund A2-8)', rSelbst.status === 404);
  const rUnbekannt = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: SID_C, uid8: N.uid8Aus(UID), nonceA: meinN, epkA: meinEpk.pub });
  const rUnbekanntB = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'beweis', sitzung: rUnbekannt.obj && rUnbekannt.obj.sitzung, sigA: stC.signiere('irgendwas') });
  ok('eine dem Nachbarn UNBEKANNTE Station kommt nicht durch (der pub kommt nur aus der Cloud)',
    rUnbekanntB.status === 404);
  const rForm = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: '../fremd', uid8: N.uid8Aus(UID), nonceA: meinN, epkA: meinEpk.pub });
  ok('eine formwidrige Kennung kommt nicht durch', rForm.status === 404);
  const rNonce = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: SID_A, uid8: N.uid8Aus(UID), nonceA: 'kurz', epkA: meinEpk.pub });
  ok('eine formwidrige Zufallszahl kommt nicht durch', rNonce.status === 404);

  console.log('\n13) Die harten Deckel');
  /* Gemessen wird die DIFFERENZ, nicht der absolute Stand: die beglaubigte Sitzung von OP 1 steht
   * noch (sie laeuft erst nach 15 min ab), und ein Test, der 0 verlangt, waere nur so lange
   * gruen, wie oben kein Handschlag gelingt. */
  const vorFrist = B.status().sitzungen;
  uhr += N.HANDSCHLAG_MS + 1;
  const rSpaet = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'beweis', sitzung: rUnbekannt.obj && rUnbekannt.obj.sitzung, sigA: 'AAAA' });
  ok('nach der 2-s-Handschlagfrist ist die Sitzung verfallen', rSpaet.status === 404);
  ok('und sie belegt keinen der acht Plaetze mehr',
    B.status().sitzungen === vorFrist - 1, vorFrist + ' -> ' + B.status().sitzungen);

  const C = bau(SID_C, stC, { port: PORT_C, taktMs: 100000, loopbackFuerTest: true, verbindungenMax: 2, jeAdresseMax: 2, adapterQuelle: () => [], datei: tempDatei('C') });
  C.start();
  C.setzeNachbarn([{ sid: SID_A, pub: stA._pub, ips: ['127.0.0.1'], port: PORT_A }]);
  const halloAn = (nr) => hole(PORT_C, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: SID_A, uid8: N.uid8Aus(UID), nonceA: crypto.randomBytes(16).toString('hex'), epkA: N.epkPaar().pub });
  const d1 = await halloAn(1), d2 = await halloAn(2), d3 = await halloAn(3);
  ok('die ersten beiden Handschlaege gehen durch', d1.status === 200 && d2.status === 200, d1.status + '/' + d2.status);
  ok('der dritte wird abgewiesen — ohne einen einzigen Krypto-Schritt', d3.status !== 200, String(d3.status));
  ok('und der Deckel wird namentlich gezaehlt',
    (C.status().zaehler.deckelGesamt + C.status().zaehler.deckelAdresse) >= 1,
    JSON.stringify(C.status().zaehler.abgewiesen));
  ok('zwei Sitzungen stehen, nicht drei', C.status().sitzungen === 2, String(C.status().sitzungen));
  const dLang = await hole(PORT_C, '/nachbar/hallo', 'A'.repeat(N.ZEILE_MAX + 10));
  ok('eine Kopfzeile ueber 64 KB wird abgewiesen', dLang.status !== 200, String(dLang.status));
  C.stop();
  ok('stop() gibt Sitzungen und Sockets wieder frei',
    C.status().sitzungen === 0 && C.status().sockets === 0 && C.status().gebunden.length === 0);

  /*
   * NACHGETRAGEN AM 31.07.2026 (Gegenpruefung, Mutationsprobe). Vier Sperren, die der Plan
   * namentlich verlangt, waren vorher NUR im Quelltext vorhanden und von keiner Pruefung gedeckt:
   * die /24-Pruefung je Anfrage, die drei Pruefungen vor der ersten Nutzung und der Zaehlerschutz
   * gegen Wiedereinspielen. Nachgemessen: jede der vier Zeilen liess sich im Quelltext auf
   * "if (false)" setzen, ohne dass eine einzige Pruefung rot wurde.
   *
   * WARUM MIT NACHGEBAUTEN req/res STATT UEBER EINEN ECHTEN SOCKET: die /24-Pruefung vergleicht die
   * ABSENDERADRESSE mit der GEBUNDENEN. Ueber die Loopback-Naht sind beide 127.0.0.1, der Fall
   * "Absender aus einem fremden Netz" ist ueber einen echten Socket also gar nicht stellbar, ohne
   * dem Testrechner eine zweite Karte zu geben. _anfrage(bind, req, res) nimmt die gebundene
   * Adresse als Argument — genau deshalb steht sie dort und nicht in einem Feld des Servers.
   */
  console.log('\n14) Die Sperren, die von aussen nicht stellbar sind');
  function stellAnfrage(inst, bind, von, weg, rahmen, methode) {
    const a = { code: 0, kopf: null };
    const req = {
      method: methode || 'GET', url: weg,
      headers: rahmen ? { 'x-vs': N.kopfAusRahmen(rahmen) } : {},
      socket: { remoteAddress: von },
    };
    const res = {
      writableLength: 0, writableEnded: false, destroyed: false,
      writeHead(c, h) { a.code = c; a.kopf = h; return res; },
      write() { return true; },
      end() { res.writableEnded = true; },
      destroy() { res.destroyed = true; },
    };
    inst._anfrage(bind, req, res);
    return a;
  }
  const halloRahmen = () => ({ vs: 1, typ: 'hallo', sid: SID_A, uid8: N.uid8Aus(UID), nonceA: crypto.randomBytes(16).toString('hex'), epkA: N.epkPaar().pub });
  ok('aus dem /24 der GEBUNDENEN Adresse wird beantwortet',
    stellAnfrage(B, '192.168.0.99', '192.168.0.20', '/nachbar/hallo', halloRahmen()).code === 200);
  const fremdesNetzVor = B.status().zaehler.fremdesNetz;
  ok('aus einem FREMDEN /24 gibt es 404, obwohl die Anfrage sonst gueltig waere (Befund C1-11)',
    stellAnfrage(B, '192.168.0.99', '10.0.0.5', '/nachbar/hallo', halloRahmen()).code === 404);
  ok('und ein anderes /24 derselben privaten Klasse ebenfalls',
    stellAnfrage(B, '192.168.0.99', '192.168.7.5', '/nachbar/hallo', halloRahmen()).code === 404);
  ok('beides wird als "fremdes Netz" gezaehlt, nicht als Formfehler',
    B.status().zaehler.fremdesNetz === fremdesNetzVor + 2,
    fremdesNetzVor + ' -> ' + B.status().zaehler.fremdesNetz);

  /* Die drei Pruefungen vor der ersten Nutzung, einzeln (Befund A2-8, toedlich). A ist gestoppt —
   * _vorDerNutzung braucht nur die eigene Stationskennung, keinen Socket. */
  const kB = { sid: SID_B, pub: stB._pub, ips: ['127.0.0.1'], port: PORT_B };
  ok('vor der Nutzung: der echte Nachbar geht durch',
    A._vorDerNutzung(kB, { sid: SID_B, instanz: stB.instanz }) === null);
  ok('vor der Nutzung: eine FREMDE Kennung in der Antwort faellt durch',
    A._vorDerNutzung(kB, { sid: SID_C, instanz: stC.instanz }) !== null);
  ok('vor der Nutzung: die EIGENE Kennung faellt durch',
    A._vorDerNutzung({ sid: SID_A, pub: stA._pub, ips: ['127.0.0.1'], port: PORT_A }, { sid: SID_A, instanz: 'z'.repeat(16) }) !== null);
  ok('vor der Nutzung: die EIGENE Instanz faellt durch (Doppelstart auf demselben PC)',
    A._vorDerNutzung(kB, { sid: SID_B, instanz: stA.instanz }) !== null);
  ok('und der Selbstgespraechs-Zaehler steht danach hoeher als 0', A.status().zaehler.selbstgespraech >= 2);

  /* Zaehlerschutz: derselbe box-Rahmen ein zweites Mal muss 404 ergeben (Befund C1-4). Dafuer wird
   * der Handschlag hier von Hand gefuehrt — die Clientseite von nachbar.js sendet nie zweimal
   * denselben Zaehler und koennte den Fall deshalb gar nicht stellen. */
  const hE = N.epkPaar();
  const hN = crypto.randomBytes(16).toString('hex');
  const h1 = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo', sid: SID_A, uid8: N.uid8Aus(UID), nonceA: hN, epkA: hE.pub });
  const hText = h1.obj && N.signierZeichenkette({
    uid8: N.uid8Aus(UID), nonceA: hN, nonceB: h1.obj.nonceB,
    sidA: SID_A, sidB: SID_B, epkA: hE.pub, epkB: h1.obj.epkB,
  });
  ok('die Unterschrift des Nachbarn prueft gegen den gepinnten Schluessel (Handschlag von Hand)',
    !!hText && S.pruefeSignatur(stB._pub, hText, h1.obj.sigB));
  const h2 = await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'beweis', sitzung: h1.obj && h1.obj.sitzung, sigA: stA.signiere(hText) });
  ok('mit GUELTIGER sigA gibt es 200 und einen box-Rahmen', h2.status === 200 && h2.obj && h2.obj.typ === 'box', String(h2.status));
  const hKey = N.sitzungsschluessel(hE.priv, h1.obj && h1.obj.epkB, hN, h1.obj && h1.obj.nonceB);
  const hAuf = hKey && N.packeAus(hKey, h1.obj.sitzung, 'b', h2.obj);
  ok('der Sitzungsschluessel beider Seiten passt und die Antwort ist "ok"',
    !!hAuf && hAuf.nutz.typ === 'ok' && hAuf.nutz.sid === SID_B);
  const tBox = N.verpacke(hKey, h1.obj.sitzung, 'a', 1, { typ: 'tafel' });
  const t1 = await hole(PORT_B, '/nachbar/tafel', tBox);
  ok('die Uebersicht kommt verschluesselt zurueck', t1.status === 200 && !!N.packeAus(hKey, h1.obj.sitzung, 'b', t1.obj), String(t1.status));
  const t2 = await hole(PORT_B, '/nachbar/tafel', tBox);
  ok('DERSELBE Rahmen ein zweites Mal ergibt 404 (kein Wiedereinspielen, Befund C1-4)',
    t2.status === 404, String(t2.status));
  const tBoxWeiter = N.verpacke(hKey, h1.obj.sitzung, 'a', 2, { typ: 'tafel' });
  ok('der naechste Zaehler geht dagegen durch',
    (await hole(PORT_B, '/nachbar/tafel', tBoxWeiter)).status === 200);
  const tFalsch = N.verpacke(hKey, h1.obj.sitzung, 'a', 3, { typ: 'protokoll' });
  ok('ein Innentyp ausserhalb der Weissliste ergibt 404 (es gibt kein Protokoll ueber LAN)',
    (await hole(PORT_B, '/nachbar/tafel', tFalsch)).status === 404);

  /* Der Deckel auf den gemerkten Nachbarn: er greift auch dann, wenn die Cloud schweigt und alles
   * aus bridge/data/nachbarn.json kommt. Gemessen am 31.07.2026: ohne ihn wurden aus 30 Pins
   * 30 Nachbarn statt 8. */
  const P = bau(SID_A, stA, { datei: tempDatei('deckel'), adapterQuelle: () => [] });
  for (let i = 0; i < 20; i++) {
    P.setzeNachbarn([{ sid: 'st' + String(i).padStart(12, '0'), pub: S.ed25519Paar().pub, ips: ['192.168.0.' + (20 + i)], port: 8771 }]);
  }
  const vorSchweigen = P.nachbarn().length;
  P.setzeNachbarn([]);
  ok('aus dem Pin kommen nie mehr Saele als der Deckel erlaubt',
    P.nachbarn().length <= N.NACHBARN_MAX, vorSchweigen + ' -> ' + P.nachbarn().length);
  ok('und es sind ueberhaupt welche da (der Pin traegt ueber den Internetausfall)',
    P.nachbarn().length > 0, String(P.nachbarn().length));

  B.stop();
  ok('nach stop() antwortet der Port nicht mehr', (await hole(PORT_B, '/nachbar/hallo', { vs: 1, typ: 'hallo' })).status === 0);
}

live().then(() => {
  tempDateien.forEach((p) => { try { if (fs.existsSync(p)) fs.unlinkSync(p); } catch (e) { /* Aufraeumen ist Kuer */ } });
  ok('mindestens 50 Pruefungen gelaufen', pass + fail >= 50, String(pass + fail));
  console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
  process.exit(fail === 0 ? 0 : 1);
}).catch((e) => {
  console.log('  ✗ der Netzteil des Tests ist abgebrochen -> ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
