'use strict';
/*
 * hl7.js — ECHTER Mindray-Live-Adapter ueber HL7 / "Patient Data Share" (PDS).
 *
 * Belegter Weg (Mindray PDS Protocol Programmer's Guide H-0010-20-43061 v14.2; VSCapture unterstuetzt
 * die uMEC-Serie gateway-frei): Der Monitor sendet HL7 v2.3.1 ORU^R01 ueber TCP mit MLLP-Framing.
 * PC = LISTENER/Server; der Monitor verbindet sich als Client zur "Serveradresse" (= PC-IP) und pusht.
 *
 * STRIKT READ-ONLY: dieser Adapter empfaengt nur. Ein optionaler HL7-ACK ist reines Protokoll-
 * Quittieren (keine Geraetesteuerung) und standardmaessig AUS -> es wird per Default NICHTS gesendet.
 *
 * OBX-Codes 1:1 aus der offiziellen PDS-Spezifikation (siehe docs/MINDRAY-HL7.md).
 *
 * Konfig: { id, listenPort=5000, model, role, species?, weightKg?, ack?:false, rawLog?:false }
 *   mode:'client' zusaetzlich { host, port=4601 }. host darf "auto" sein: dann folgt die Abfrage
 *   dem tatsaechlich im Netz gefundenen Geraet (geraetefund.js) statt einer festen IP.
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const { Adapter } = require('./base');
const geraetefund = require('../geraetefund');

const VT = 0x0b, FS = 0x1c, CR = 0x0d; // MLLP-Rahmen: <VT> ... <FS><CR>

/*
 * ZEICHENSATZ (Befund 23.07.2026 am echten LifeVet/N-Series): Das Geraet deklariert im MSH-18
 * "UNICODE UTF-8" und sendet den Patientennamen UTF-8-kodiert. Wurde der Rahmen als latin1 gelesen,
 * wurde aus "müller" ein "mÃ¼ller" - der Tierarzt sah einen verstuemmelten Namen.
 * Deshalb: sagt der Kopf UTF-8, wird als UTF-8 dekodiert; sonst latin1 (aeltere Bettmonitore).
 * ASCII ist in beiden Kodierungen identisch, darum ist die Kopf-Erkennung selbst robust.
 */
function decodePayload(buf) {
  const latin = buf.toString('latin1');
  if (/UNICODE\s*UTF-?8|\bUTF-?8\b/i.test(latin.slice(0, 600))) {
    try { return buf.toString('utf8'); } catch (_) { return latin; }
  }
  return latin;
}

// Numerischer OBX-Code -> internes Feld (Primärzuordnung).
/*
 * OBX-Code -> internes Feld. Deckt BEIDE Mindray-Dialekte ab (belegt aus dem Mindray Patient Data
 * Share Protocol Programmer's Guide v14.2 und dem mdpnp/IHE-PCD-Mapping, recherchiert 23.07.2026):
 *   • PRIVATER Bettmonitor-Dialekt: kleine, eigene Parameter-IDs (101=HR, 160=SpO2, 51=Weight ...).
 *   • MDC/IEEE-11073-Dialekt (eGateway, das LifeVet 10C sendet DIESEN): grosse Codes wie
 *     147842=MDC_ECG_HEART_RATE. Die MDC-NUMMERN sind zusaetzlich eingetragen, damit ein Wert auch
 *     dann aufloest, wenn das Label einmal fehlt - das Label-Fallback unten deckt sie ohnehin ab.
 */
const CODE_MAP = {
  // -- privater Mindray-Bettmonitor-Dialekt --
  '101': 'hr', '160': 'spo2', '161': 'hr', '173': 'hr',   // 161=SpO2-Puls, 173=NIBP-Puls (HF-Fallback)
  '170': 'sys', '171': 'dia', '172': 'map',      // NIBP
  '500': 'sys', '501': 'map', '502': 'dia',      // invasiver ART als Fallback
  '220': 'etco2', '221': 'fico2', '222': 'af', '250': 'etco2',  // Kapno (250=CO2Et laut PDS-Guide)
  '151': 'rr_imp',                               // Impedanz-Atmung (Fallback für af)
  '200': 'temp', '201': 'temp', '213': 'temp_tb', // T1 / T2 / Bluttemperatur
  '102': 'pvcs', '51': 'weightKg',
  // -- MDC/IEEE-11073-Dialekt (das LifeVet 10C nutzt diesen; belegt) --
  '147842': 'hr', '149530': 'hr', '149538': 'hr',        // MDC_ECG_HEART_RATE / PULS_OXIM_PULS_RATE
  '150456': 'spo2',                                      // MDC_PULS_OXIM_SAT_O2
  '150021': 'sys', '150022': 'dia', '150023': 'map',     // MDC_PRESS_BLD_NONINV_*
  '150301': 'sys', '150302': 'dia', '150303': 'map',     // MDC_PRESS_CUFF_*
  '151728': 'etco2', '151738': 'fico2',                  // MDC_AWAY_CO2_ET / _INSP_MIN
  '151562': 'af', '151570': 'af', '151578': 'af',        // MDC_RESP_RATE / MDC_AWAY_RESP_RATE / MDC_TTHOR_RESP_RATE (Impedanz-Atmung, am echten LifeVet belegt)
  '150344': 'temp',                                       // MDC_TEMP
  '148065': 'pvcs', '148066': 'pvcs', '352': 'pvcs', '302': 'pvcs', // MDC_ECG_V_P_C_CNT/_RATE, MNDRY VPB-/RonT-Rate (ventrikulaere Extrasystolen) — am echten uMEC/LifeVet belegt
};
// Label-Fallback (falls ein Nummerncode unbekannt ist, aber das Label sprechend). Schluessel KLEIN
// geschrieben; deckt Mindray-Kurznamen UND IEEE-11073-MDC-Nomenklatur (BeneView/BeneVision) ab.
const LABEL_MAP = {
  hr: 'hr', pr: 'hr', pulse: 'hr', nibp_pr: 'hr', mdc_ecg_heart_rate: 'hr', mdc_ecg_cardiac_rate: 'hr', mdc_puls_oxim_puls_rate: 'hr',
  spo2: 'spo2', mdc_puls_oxim_sat_o2: 'spo2',
  'nibp-sys': 'sys', sys: 'sys', 'nbp-s': 'sys', mdc_press_bld_noninv_sys: 'sys', mdc_press_cuff_sys: 'sys',
  'nibp-dia': 'dia', dia: 'dia', 'nbp-d': 'dia', mdc_press_bld_noninv_dia: 'dia', mdc_press_cuff_dia: 'dia',
  'nibp-mean': 'map', mean: 'map', 'nbp-m': 'map', mdc_press_bld_noninv_mean: 'map', mdc_press_cuff_mean: 'map',
  co2: 'etco2', etco2: 'etco2', co2et: 'etco2', mdc_co2_et: 'etco2', mdc_away_co2_et: 'etco2',
  fico2: 'fico2', insco2: 'fico2', mdc_co2_insp_min: 'fico2', mdc_away_co2_insp_min: 'fico2',
  awrr: 'af', mdc_co2_resp_rate: 'af', mdc_resp_rate: 'af', mdc_away_resp_rate: 'af', rr: 'rr_imp', resp: 'rr_imp',
  t1: 'temp', t2: 'temp', tb: 'temp_tb', temp: 'temp', mdc_temp: 'temp',
  pvcs: 'pvcs', weight: 'weightKg', mdc_body_weight: 'weightKg',
};

/*
 * OBX-Codes, die GAR KEINE Zahlenwerte sind: Kurvenpunkte, Geraete-Attribute und Alarm-/
 * Technikmeldungen der IEEE-11073-Nomenklatur.
 *
 * WARUM DIESE LISTE (Praxis-PC, 22.07.2026): Sobald das Geraet endlich sendete, schrieb die
 * Station im Sekundentakt "Unbekannter OBX-Code: 131330^MDC_ECG_ELEC_POTL_II (in hl7.js CODE_MAP
 * ergaenzen)". Das liest sich wie ein Programmfehler und wie "hier gehen Messwerte verloren" -
 * beides ist falsch: MDC_ECG_ELEC_POTL_II ist ein EKG-KURVENPUNKT, MDC_EVT_INOP eine technische
 * Alarmmeldung ("Sensor ab"). Es gibt dort schlicht keinen Vitalwert zu holen.
 * Solche Codes werden deshalb NICHT mehr als Fehlstelle gemeldet, sondern getrennt gezaehlt -
 * die Station sagt EINMAL, was das Geraet da schickt. Echte unbekannte Messwerte werden weiterhin
 * gemeldet, denn nur die gehoeren in die CODE_MAP.
 */
const KEINE_MESSWERTE = /^MDC_(ATTR_|EVT_|ECG_ELEC_POTL|CONC_AWAY_CO2$|IMPED_TTHOR|PULS_OXIM_PLETH|ECG_TIME_PD_QT)/i;
/*
 * ALARM-KONFIG-CODES des uMEC12 (belegt aus dem echten HL7-Strom 24.07.2026): der Monitor sendet mit
 * "HL7 Compatibility: Ein" auch Alarm-GRENZEN und Alarm-EINSTELLUNGEN als numerische OBX — das sind
 * KEINE Messwerte. 2002/2003 = obere/untere Alarmgrenze (mit Parameter-Sub-ID), 2013 Alarmlautstaerke,
 * 2014 Alarm-Mute, 2016 Alarm-Pause, 2027 Alarm aus, 2028 Ton-Pause, 2040/2041/2042 Alarm-Status.
 * Sie duerfen weder als Vitalwert gelten noch als "unbekannter Code" das Diagnose-Log fluten.
 */
const KONFIG_CODES = new Set(['2002', '2003', '2013', '2014', '2015', '2016', '2027', '2028', '2040', '2041', '2042']);
const KURVEN_KLARTEXT = {
  mdc_ecg_elec_potl_ii: 'EKG-Kurve (Ableitung II)',
  mdc_conc_away_co2: 'CO2-Kurve (Kapnogramm)',
  mdc_imped_tthor: 'Atemkurve (Thorax-Impedanz)',
  mdc_puls_oxim_pleth: 'Pleth-Kurve (SpO2)',
  mdc_evt_alarm: 'Alarmmeldung',
  mdc_evt_inop: 'technische Meldung (z. B. "Sensor ab")',
};

/*
 * TIERART AUS DEM GERAET (Befund 22.07.2026).
 * Im LifeVet 10C steht unter "Patientenverwaltung" die Patientenkategorie (z. B. "Hund") und das
 * Gewicht (z. B. 15,0 kg) - beides ist fuer JEDE Dosisberechnung noetig. Der Parser hat diese
 * Angaben nie gesehen, weil TEXT-Werte in OBX stillschweigend verworfen wurden (nur Zahlen zaehlten).
 * Die Station zeigte deshalb "? / ? kg" und konnte weder Normwerte noch mL-Mengen nennen.
 *
 * Bewusst tolerant gegenueber Sprache und Schreibweise, aber NIE ratend: erkannt wird nur, was
 * eindeutig einer Tierart entspricht. Alles andere bleibt null (und wird als Rohwert angezeigt).
 */
const TIERART_WORTE = [
  ['hund', /\b(hund|dog|canine|canis)\b/i],
  ['katze', /\b(katze|cat|feline|felis)\b/i],
  ['kaninchen', /\b(kaninchen|rabbit|oryctolagus)\b/i],
  ['meerschwein', /\b(meerschwein(chen)?|guinea[\s-]?pig|cavia)\b/i],
  ['chinchilla', /\bchinchilla\b/i],
  ['degu', /\bdegu\b/i],
  ['frettchen', /\b(frettchen|ferret|mustela)\b/i],
  ['reptil', /\b(reptil|reptile|schildkr|turtle|tortoise|echse|lizard|schlange|snake|bartagame|gecko|leguan)/i],
];
function erkenneTierart(text) {
  const t = String(text || '');
  if (!t) return null;
  for (const [id, re] of TIERART_WORTE) if (re.test(t)) return id;
  return null;
}

/*
 * GEWICHT AUS DEM GERAET - sicherheitskritisch, deshalb streng.
 * Aus dem Gewicht folgen die Injektionsmengen in mL. Ein falsch uebernommener Wert waere
 * gefaehrlicher als gar keiner. Deshalb: nur aus einem ausdruecklich als Gewicht bezeichneten
 * Feld, Pfund nur bei ausgewiesener Einheit umrechnen, und ein Plausibilitaetsfenster.
 * Ausserhalb 0,05-200 kg wird NICHTS uebernommen (der Tierarzt traegt es dann selbst ein).
 */
const GEWICHT_LABEL = /(weight|gewicht|\bwt\b|body_?weight|pt_?weight)/i;
function gewichtAusOBX(label, wert, einheit) {
  if (!GEWICHT_LABEL.test(String(label || ''))) return null;
  const z = parseFloat(String(wert).replace(',', '.'));
  if (!Number.isFinite(z) || z <= 0) return null;
  const e = String(einheit || '').toLowerCase();
  let kg = z;
  if (/^(lb|lbs|pound)/.test(e)) kg = z * 0.45359237;
  else if (/^g$|gram/.test(e)) kg = z / 1000;
  if (kg < 0.05 || kg > 200) return null;    // unplausibel -> lieber nichts als falsch
  return Math.round(kg * 1000) / 1000;
}

/*
 * ALARM- UND TECHNIKMELDUNGEN im Klartext.
 * Das Geraet meldet z. B. "EKG-Ableitung ab" oder "Keine CO2-Wasserfalle" - genau die Saetze, die
 * am Monitor oben stehen. Sie kamen bisher NIRGENDS an, weil es Textwerte sind. Fuer den Tierarzt
 * sind sie aber die Erklaerung, warum ein Wert fehlt.
 */
const ALARM_CODE = /^MDC_(EVT_ALARM|EVT_INOP|ATTR_ALERT)/i;

/*
 * EINHEITEN PRUEFEN STATT ANNEHMEN - sicherheitskritisch.
 *
 * Der Parser hat die Einheit (OBX-6) nie angesehen und jeden Zahlenwert so genommen, wie er kam.
 * Zwei Beispiele, die beide in der Praxis vorkommen und in der Anzeige NICHT auffallen:
 *   • Ein auf kPa gestellter Kapnograf meldet EtCO2 = 5,3. Als mmHg gelesen sind das 5 mmHg -
 *     also scheinbar ein lebensbedrohlicher Abfall, obwohl der Patient bei 40 mmHg voellig normal
 *     beatmet ist. Die Station wuerde Alarm schlagen und eine falsche Empfehlung geben.
 *   • Eine Temperatur in Fahrenheit (98,6) wuerde als 98,6 Grad Celsius uebernommen.
 *
 * Deshalb: bekannte Einheiten werden umgerechnet, unbekannte fuehren dazu, dass der Wert NICHT als
 * Messwert uebernommen wird. Er bleibt als Rohwert sichtbar und es gibt eine Klartextmeldung.
 * Nicht uebernehmen ist hier sicherer als raten - der Tierarzt sieht dann eine Luecke statt einer
 * falschen Zahl.
 */
const EINHEIT_ERWARTET = {
  etco2: 'mmHg', fico2: 'mmHg', sys: 'mmHg', dia: 'mmHg', map: 'mmHg',
  temp: 'C', hr: '/min', af: '/min', rr_imp: '/min', spo2: '%',
};
function normEinheit(e) { return String(e || '').replace(/[\[\]\s]/g, '').toLowerCase(); }

function rechneEinheit(key, wert, einheit) {
  const soll = EINHEIT_ERWARTET[key];
  if (!soll) return { wert: wert, ok: true };
  const e = normEinheit(einheit);
  if (!e) return { wert: wert, ok: true };            // keine Angabe -> Geraetestandard annehmen

  // MDC-Nomenklatur (IEEE 11073): das LifeVet/N-Series sendet Einheiten als "MDC_DIM_*" statt "%"
  // oder "/min" (Befund 23.07.2026 am echten Geraet: SpO2 kam mit MDC_DIM_PERCENT, HF mit
  // MDC_DIM_BEAT_PER_MIN). Ohne diese Zeilen verwarf die Einheitenpruefung JEDEN Messwert des
  // Monitors als "unbekannte Einheit" -> werteAnzahl=0, obwohl das Geraet sauber misst.
  if (soll === 'mmHg') {
    if (/^(mmhg|mm\(hg\)|torr|mdc_dim_mmhg)$/.test(e)) return { wert: wert, ok: true };
    if (/^(kpa|mdc_dim_kilo_pascal)$/.test(e)) return { wert: Math.round(wert * 7.50062 * 10) / 10, ok: true, umgerechnet: 'kPa' };
    if (/^(vol%|%|mdc_dim_percent)$/.test(e) && (key === 'etco2' || key === 'fico2')) {
      // Vol% bei etwa 1013 hPa: 1 Vol% entspricht rund 7,6 mmHg.
      return { wert: Math.round(wert * 7.6 * 10) / 10, ok: true, umgerechnet: 'Vol%' };
    }
    return { ok: false, grund: e };
  }
  if (soll === 'C') {
    if (/^(c|cel|degc|°c|mdc_dim_degc|mdc_dim_deg_c)$/.test(e)) return { wert: wert, ok: true };
    if (/^(f|degf|°f|mdc_dim_fahr|mdc_dim_deg_f)$/.test(e)) return { wert: Math.round(((wert - 32) * 5 / 9) * 10) / 10, ok: true, umgerechnet: 'Fahrenheit' };
    return { ok: false, grund: e };
  }
  if (soll === '/min') {
    if (/^(\/min|min-1|bpm|rpm|1\/min|puls\/min|beats\/min|mdc_dim_beat_per_min|mdc_dim_beats_per_min|mdc_dim_puls_per_min|mdc_dim_pulse_per_min|mdc_dim_resp_per_min|mdc_dim_breath_per_min|mdc_dim_breaths_per_min|mdc_dim_x_per_min)$/.test(e)) return { wert: wert, ok: true };
    return { ok: false, grund: e };
  }
  if (soll === '%') {
    if (/^(%|mdc_dim_percent)$/.test(e)) return { wert: wert, ok: true };
    return { ok: false, grund: e };
  }
  return { wert: wert, ok: true };
}

/*
 * MINDRAY-KENNZEICHEN FUER "KEIN WERT": 32767 (0x7FFF), bei 8 Bit 255.
 *
 * AM PRAXISGERAET GEMESSEN (22.07.2026): Solange die EKG-Ableitung ab war, schickte das LifeVet
 * fuer jeden Kanal 32767. Der Parser nahm das als Zahl - eine "Herzfrequenz 32767" haette die
 * Station als extreme Tachykardie bewertet und Empfehlungen dazu ausgegeben. Solche Marker
 * duerfen NIE als Messwert durchgehen.
 */
const UNGUELTIG = [32767, -32768, 65535];
function istUngueltig(z) { return !Number.isFinite(z) || UNGUELTIG.indexOf(z) >= 0; }

/*
 * KURVENBLOECKE.
 *
 * Das Geraet packt Abtastwerte einer Kurve in EIN OBX-Feld, getrennt durch "^":
 *   OBX|..|131330^MDC_ECG_ELEC_POTL_II||-12^-9^-3^40^120^..|..
 * Direkt danach folgen zwei beschreibende OBX:
 *   MDC_ATTR_SAMP_RATE   = Abtastrate in Hz (gemessen: 256 fuer EKG/Impedanz, 40 fuer CO2)
 *   MDC_ATTR_NU_MSMT_RES = Aufloesung, mit der die Rohzahlen zu multiplizieren sind
 *
 * Bisher lief das durch parseFloat und wurde zur ERSTEN Zahl des Blocks - also ein erfundener
 * Einzelmesswert. Jetzt wird der Block als Kurve erkannt, mit Abtastrate und Skalierung.
 * Damit ist die echte EKG-Kurve des Geraets darstellbar, statt sie nur aus der Herzfrequenz
 * nachzuzeichnen.
 */
const MAX_SAMPLES = 512;   // Deckel je Kurve: bei 256 Hz sind das 2 s - genug fuers Bild, wenig RAM
function istKurvenblock(roh) {
  const s = String(roh);
  if (s.indexOf('^') < 0) return false;
  const teile = s.split('^');
  if (teile.length < 4) return false;
  // Alle Teile muessen Zahlen sein, sonst ist es ein zusammengesetztes Feld (z. B. Code^Text).
  return teile.every((t) => t !== '' && Number.isFinite(Number(t)));
}
function kurveAusBlock(roh) {
  return String(roh).split('^').slice(0, MAX_SAMPLES).map((t) => {
    const z = Number(t);
    return istUngueltig(z) ? null : z;      // Luecken bleiben Luecken, sie werden nicht geglaettet
  });
}

// Alltagsnamen fuer die Meldungen - im Bild soll kein Kuerzel stehen.
const KLARNAME = {
  hr: 'Herzfrequenz', spo2: 'Sauerstoffsaettigung', etco2: 'Kohlendioxid (EtCO2)',
  fico2: 'eingeatmetes CO2', af: 'Atemfrequenz', rr_imp: 'Atemfrequenz', temp: 'Temperatur',
  sys: 'Blutdruck systolisch', dia: 'Blutdruck diastolisch', map: 'Mitteldruck',
};

function fieldsOf(seg) { return seg.split('|'); }

// HL7/PDS liefert KEINEN Rhythmus-Code direkt. Rhythmus aus PVC-Zaehler (OBX 102) + Arrhythmie-
// Alarmtexten der OBX-Segmente ableiten (gefaehrlichster zuerst). Konservativ, nur OBX-Inhalte
// (keine Geraetenamen aus MSH/OBR) -> keine Falschtreffer. Kurvenform-Feinheiten (Haiflosse) sind
// ohne Waveform-Stream nicht ableitbar und bleiben null (ehrlich).
function inferRhythm(obxText, pvcs) {
  const T = (obxText || '').toUpperCase();
  if (/ASYSTOL/.test(T)) return 'asys';
  if (/V[\s_-]?FIB|VFIB|KAMMERFLIMMERN/.test(T)) return 'vfib';
  if (/V[\s_-]?TAC|VTAC|VENT.{0,4}TACH|KAMMERTACH/.test(T)) return 'vtach';
  if (/A[\s_-]?FIB|AFIB|VORHOFFLIMMERN/.test(T)) return 'afib';
  if (/\bPVC|\bVES\b|VPB|R[\s_]?ON[\s_]?T|COUPLET|BIGEMIN/.test(T)) return 'ves';
  if (pvcs != null && pvcs > 0) return 'ves';
  return null;
}

/*
 * parseHL7Message(text, cfg) -> normalisiertes ingest-Frame (oder null).
 * Pure Funktion (auch für Tests). cfg liefert deviceId/model/role/species Defaults + unmapped-Callback.
 */
function parseHL7Message(text, cfg, onUnmapped) {
  cfg = cfg || {};
  const segs = text.split(/[\r\n]+/).map(s => s.trim()).filter(Boolean);
  if (!segs.length || segs[0].slice(0, 3) !== 'MSH') return null;

  // Kein voreiliger Ersatzname: sonst gewinnt "Mindray Monitor" gegen den Namen, den das Geraet
  // selbst meldet (MSH-3 / OBR-4) - und im Geraete-Menue stand fuer jedes Fabrikat dasselbe Wort.
  let sendingApp = null, deviceName = null;
  let patientId = null, weightFromPid = null, tsStr = null;
  let patientName = null, gebDatum = null, geschlecht = null, species = null;
  const vit = { pvcs: null };
  const obxTexts = [];   // Labels + nicht-numerische OBX-Werte (fuer Arrhythmie-Alarm-Erkennung)
  const kurven = [];     // Kurven-/Alarm-/Attributcodes: vorhanden, aber keine Vitalwerte
  const roh = [];        // JEDER OBX-Eintrag, zugeordnet oder nicht (damit nichts still verschwindet)
  const alarmTexte = []; // Klartextmeldungen des Geraets ("EKG-Ableitung ab")
  const umrechnungen = []; // nachvollziehbar machen, wenn eine Einheit umgerechnet wurde
  const kurvenDaten = []; // ECHTE Abtastwerte je Kurve (EKG, CO2, Atmung) mit Abtastrate
  let letzteKurve = null; // die zuletzt gelesene Kurve - die folgenden Attribute gehoeren zu ihr
  /*
   * PATIENTENAKTE aus dem Geraet (Foto der Patientenverwaltung, 22.07.2026):
   * Bett-Nr., ID, Nachname, Vorname, Besitzer, Arzt, Groesse(cm), Gewicht(kg), Geb.datum, Alter,
   * Patientenkategorie, Geschlecht, Pacer aktiv. Was das Geraet davon sendet, gehoert in die Akte
   * und ins Narkoseprotokoll - bisher wurde ausser ID und Name nichts davon uebernommen.
   */
  const akte = {};

  for (const seg of segs) {
    const type = seg.slice(0, 3);
    const f = fieldsOf(seg);
    if (type === 'MSH') { if (f[2]) sendingApp = f[2]; }
    else if (type === 'PID') {
      // Frueher wurde HIER NUR die Patienten-ID gelesen. Alles andere, was der Monitor unter
      // "Patientenverwaltung" fuehrt, ging verloren - obwohl es auf seinem Bildschirm steht.
      if (f[3]) patientId = f[3].split('^')[0] || null;
      if (f[5]) {
        // PID-5: Nachname^Vorname^... -> fuer die Anzeige zusammensetzen (bleibt LOKAL auf dem PC).
        // OHNE filter(Boolean) zerlegen, damit die Komponenten-POSITIONEN erhalten bleiben.
        const comp = f[5].split('^');
        const nach = (comp[0] || '').trim(), vor = (comp[1] || '').trim();
        if (nach || vor) patientName = (vor ? vor + ' ' : '') + nach;
        /*
         * BESITZER AUS PID-5 KOMPONENTE 3 (beobachtet am echten LifeVet 10C, 23.07.2026):
         * Das Geraet traegt in PID-5 "Nachname^Vorname^Besitzer" ein - im Mitschnitt stand dort
         * "müller^Muster^Musterman^^^^L" (Musterman = Besitzer aus der Patientenverwaltung).
         * Nur uebernehmen, wenn es kein einzelner Namenstyp-Code (z. B. "L"=Legal) ist. Ein echtes
         * GT1-Segment (falls vorhanden) darf spaeter gewinnen.
         */
        const c3 = (comp[2] || '').trim();
        if (c3 && c3.length > 1 && !akte.besitzer) akte.besitzer = c3;
      }
      if (f[7]) gebDatum = f[7];
      if (f[8]) geschlecht = f[8].split('^')[0] || null;
      // PID-19/PID-2: weitere Kennungen (Chipnummer, Praxisnummer) - anzeigen, nie deuten.
      if (f[19] && !akte.kennung2) akte.kennung2 = f[19].split('^')[0];
      // Manche Geraete tragen die Tierart in PID-10 (Rasse/Art) oder PID-35 ein.
      [f[10], f[35], f[22]].forEach((x) => { if (!species && x) species = erkenneTierart(x); });
    }
    else if (type === 'PV1') {
      // Patientenkategorie/Station - beim LifeVet steht die Tierart mitunter hier.
      f.forEach((x) => { if (!species && x) species = erkenneTierart(x); });
      // PV1-3 = Station/Zimmer/Bett -> am Geraet das Feld "Bett-Nr.".
      if (f[3]) { const b = f[3].split('^').filter(Boolean).join(' '); if (b) akte.bett = b; }
      // PV1-7 = behandelnder Arzt -> am Geraet das Feld "Arzt".
      if (f[7]) { const a = f[7].split('^').filter(Boolean); if (a.length) akte.arzt = (a[2] ? a[2] + ' ' : '') + (a[1] || a[0]); }
    }
    else if (type === 'GT1') {
      /*
       * GT1 = "Guarantor" - in der Tiermedizin genau der BESITZER (er haftet, nicht der Patient).
       * Das Geraet fuehrt das Feld "Besitzer" in der Patientenverwaltung; ob es gesendet wird,
       * haengt vom Geraet ab. Wird es gesendet, steht es hier - sonst bleibt es leer.
       */
      if (f[3]) { const g = f[3].split('^').filter(Boolean); if (g.length) akte.besitzer = (g[1] ? g[1] + ' ' : '') + g[0]; }
      if (f[6]) akte.telefon = f[6].split('^')[0] || null;
    }
    else if (type === 'OBR') {
      /*
       * OBR-4 ist die "Universal Service ID" - also WAS gemessen wurde, NICHT wer misst.
       * Das LifeVet traegt dort "CONTINUOUS WAVEFORM" ein. Als Geraetename uebernommen stand im
       * Geraete-Menue am 22.07.2026 tatsaechlich "CONTINUOUS WAVEFORM" statt eines Geraetenamens.
       * Der Name des sendenden Geraets steht in MSH-3 (Sending Application) - nur der zaehlt hier.
       * OBR-4 wird deshalb bewusst NICHT mehr als Modellname verwendet.
       */
      if (f[7]) tsStr = f[7];
    }
    else if (type === 'OBX') {
      // OBX|<seq>|<typ>|<code>^<label>|<subid>|<wert>|<einheit>|<refbereich>|<flag>|...|<status>|<zeit>
      const codeLabel = (f[3] || '').split('^');
      const code = codeLabel[0];
      const label = (codeLabel[1] || '').toLowerCase();
      const raw = f[5];
      // Einheit (OBX-6) kommt als "code^MDC_DIM_NAME^MDC" (z. B. "262688^MDC_DIM_PERCENT^MDC") ODER
      // als schlichtes Kurzzeichen ("%","/min"). Den MDC-Namen bevorzugen, sonst den ersten Teil.
      const einheitParts = (f[6] || '').split('^');
      const einheit = einheitParts.find((x) => /^MDC_DIM_/i.test(x)) || einheitParts[0] || null;
      const flag = f[8] || null;                 // Abnormal-Flag (H/L/HH/LL) = Geraetealarmstufe
      if (raw === undefined || raw === '') continue;

      /*
       * 1) KURVENBLOCK? Dann ist es KEIN Einzelmesswert (frueher wurde daraus die erste Zahl).
       *    Die beiden folgenden OBX (Abtastrate, Aufloesung) gehoeren zu dieser Kurve.
       */
      if (istKurvenblock(raw)) {
        const name = KURVEN_KLARTEXT[label] || codeLabel[1] || code;
        letzteKurve = { name: name, code: codeLabel[1] || code, samples: kurveAusBlock(raw), hz: null, skala: null };
        kurvenDaten.push(letzteKurve);
        if (kurven.indexOf(name) < 0) kurven.push(name);
        continue;
      }
      if (letzteKurve && /MDC_ATTR_SAMP_RATE/i.test(codeLabel[1] || '')) {
        const hz = Number(raw); if (Number.isFinite(hz) && hz > 0 && hz <= 2000) letzteKurve.hz = hz;
        continue;
      }
      if (letzteKurve && /MDC_ATTR_NU_MSMT_RES/i.test(codeLabel[1] || '')) {
        const sk = Number(raw); if (Number.isFinite(sk) && sk > 0) letzteKurve.skala = sk;
        continue;
      }

      const val0 = parseFloat(String(raw).replace(',', '.'));
      /*
       * 2) UNGUELTIG-MARKER abfangen, BEVOR daraus ein Messwert wird.
       *    32767 stand am Praxisgeraet fuer "Ableitung ab" - als Herzfrequenz gelesen waere das
       *    eine extreme Tachykardie samt falscher Empfehlung gewesen.
       */
      const val = istUngueltig(val0) ? NaN : val0;
      // Arrhythmie-Alarme stehen als Text (nicht numerisch) in OBX -> fuer inferRhythm sammeln.
      if (codeLabel[1]) obxTexts.push(codeLabel[1]);

      /*
       * ALLES MITSCHREIBEN (Kernaenderung 22.07.2026).
       * Bis hierher wurde jeder Wert verworfen, den die feste Zuordnungstabelle nicht kannte -
       * bei Textwerten sogar OHNE jede Meldung. Genau deshalb kamen Tierart, Gewicht und die
       * Klartext-Alarme des Geraets nie an, und der Tierarzt sah "liest ueberhaupt keine Daten".
       * Jetzt wandert JEDER OBX-Eintrag in roh[] und ist in der Oberflaeche sichtbar - zugeordnet
       * oder nicht. Was die Station nicht deuten kann, verschweigt sie nicht mehr, sondern zeigt
       * es unveraendert an.
       */
      roh.push({
        code: code || null,
        bezeichnung: codeLabel[1] || null,
        wert: raw,
        zahl: Number.isFinite(val) ? val : null,
        einheit: einheit,
        flag: flag || null,
      });

      // Klartext-Alarme des Geraets ("EKG-Ableitung ab", "Keine CO2-Wasserfalle").
      if (ALARM_CODE.test(codeLabel[1] || '') && !Number.isFinite(val)) {
        const txt = String(raw).trim();
        if (txt && alarmTexte.indexOf(txt) < 0) alarmTexte.push(txt);
      }

      // Tierart und Gewicht koennen in JEDEM OBX stecken - Geraete sind sich da nicht einig.
      if (!species) {
        const ausWert = Number.isFinite(val) ? null : erkenneTierart(raw);
        // Nur wenn das FELD auch nach Art/Kategorie klingt, sonst waere jeder Freitext eine Falle.
        if (ausWert && /(species|patient|categ|typ|kategorie|art|breed|rasse)/i.test(label)) species = ausWert;
      }
      if (weightFromPid == null) {
        const kg = gewichtAusOBX(label, raw, einheit);
        if (kg != null) weightFromPid = kg;
      }

      /*
       * WEITERE STAMMDATEN AUS DEM GERAET.
       * Die Patientenverwaltung des LifeVet fuehrt Groesse, Alter, Rasse und "Pacer aktiv". Wenn das
       * Geraet sie sendet, sollen sie in der Akte stehen - aber NUR, wenn das Feld auch eindeutig so
       * heisst. Ein Wert, dessen Bedeutung unklar ist, wandert nicht in die Akte, sondern bleibt
       * unter "Alle Werte vom Geraet" sichtbar. Raten waere hier so gefaehrlich wie beim Gewicht.
       */
      if (!akte.groesseCm && /(height|groesse|größe|\bhgt\b|body_?height)/i.test(label)) {
        const h = parseFloat(String(raw).replace(',', '.'));
        if (Number.isFinite(h) && h > 0 && h < 300) {
          akte.groesseCm = /^(m|meter)$/i.test(String(einheit || '')) ? Math.round(h * 100) : Math.round(h);
        }
      }
      // Achtung: "_" gilt als Wortzeichen, deshalb greift \bage\b bei MDC_ATTR_PT_AGE NICHT.
      if (!akte.alter && /(^|_)age$|(^|_)age(_|\b)|alter/i.test(label)) {
        const a = String(raw).trim();
        if (a && a.length < 24) akte.alter = a + (einheit ? ' ' + einheit : '');
      }
      if (!akte.rasse && /(breed|rasse)/i.test(label)) {
        const r = String(raw).trim();
        if (r && r.length < 40 && !Number.isFinite(Number(r))) akte.rasse = r;
      }
      // Schrittmacher: Mindray-Label ist "PACE_Switch" (Code 2303) - die alte Regex ohne "pace"
      // traf das nicht und verwarf den belegten Wert. Werte: "1^ON"/"0^Off".
      if (akte.pacer == null && /(pace|pacer|schrittmacher|paced)/i.test(label)) {
        const p = String(raw).split('^')[0].trim().toLowerCase();
        if (/^(1|ja|yes|on|true)$/.test(p)) akte.pacer = true;
        else if (/^(0|nein|no|off|false)$/.test(p)) akte.pacer = false;
      }
      // Blutgruppe (Mindray-Code 2302, "1^A") und echte Fallnummer/MRN (Code 2301) - belegt.
      if (!akte.blutgruppe && /(blood_?type|blutgruppe)/i.test(label)) {
        const bg = String(raw).split('^')[1] || String(raw).split('^')[0];
        if (bg && bg.length < 6) akte.blutgruppe = bg.trim();
      }
      if (code === '2301' && raw && String(raw).trim() && !akte.mrn) {
        // Die am Monitor eingegebene Patientennummer. PID-3 ist bei manchen Geraeten nur ein
        // bedeutungsloser GUID - dann ist DAS die echte ID. Wir merken sie und ziehen sie unten vor.
        akte.mrn = String(raw).split('^')[0].trim();
      }

      /*
       * uMEC-ALARM-/EREIGNISMELDUNGEN (Befund 23.07.2026, echtes uMEC12): der Monitor sendet Alarme
       * als OBX mit privatem Zahlencode (1/2/3/4) und dem Wert "PrioCode^Klartext", z. B.
       * "10127^***Asystole", "5^EKG Kabel Aus", "10076^**T1 zu tief", "2231^Batterie schwach".
       * So erscheinen die Geraetealarme 1:1 in der App (auch bevor Vitalwerte kommen).
       * BEWUSST nur als Anzeigemeldung — NICHT in die Rhythmus-/CPR-Logik: ein "Asystole" bei
       * abgezogenem EKG-Kabel ist ein TECHNIK-Alarm, kein Herzstillstand. Deshalb kein obxTexts.push.
       */
      if (!CODE_MAP[code] && !LABEL_MAP[label]) {
        const am = /^\d+\^(.+)$/.exec(String(raw));
        if (am) {
          const at = am[1].trim();
          if ((/\*/.test(at) || (/\s/.test(at) && at.length > 4)) && alarmTexte.indexOf(at) < 0) {
            alarmTexte.push(at);
            continue;   // als Alarm behandelt — nicht als (unbekannte) Vitalzahl weiterverarbeiten
          }
        }
      }

      if (!Number.isFinite(val)) { obxTexts.push(String(raw)); continue; }
      // LABEL vor Nummer: das MDC-Label (z. B. MDC_ECG_HEART_RATE) ist eindeutiger als die
      // Nummer und stimmt mit dem tatsaechlichen Parameter ueberein. Die Nummer ist nur der
      // Rueckfall, wenn kein Label vorhanden/bekannt ist (z. B. reiner privater Zahlencode).
      let key = LABEL_MAP[label] || CODE_MAP[code];
      if (!key) {
        // Kurven/Attribute/Alarme sind KEINE fehlende Zuordnung — nur getrennt zaehlen.
        if (KEINE_MESSWERTE.test(codeLabel[1] || '')) {
          // Reine Geraete-Attribute (Abtastrate, Aufloesung) gehoeren in KEINE Anzeige - sie sagen
          // dem Tierarzt nichts. Nur was er wiedererkennt, wird spaeter genannt; der Rest wird
          // still uebergangen (aber eben auch nicht als Fehler gemeldet).
          const klar = KURVEN_KLARTEXT[label];
          if (klar && kurven.indexOf(klar) < 0) kurven.push(klar);
          continue;
        }
        // Alarm-Grenzen/-Einstellungen des uMEC (2002/2003/2013…) sind keine Messwerte -> still uebergehen.
        if (KONFIG_CODES.has(code)) continue;
        // Beispielwert + Einheit mitgeben: nur so laesst sich ein privater Mindray-Code ("99MNDRY",
        // z. B. der uMEC sendet 2203/2213/... OHNE Label) sicher zuordnen — "2203 = 95 [%]" => SpO2.
        if (onUnmapped) onUnmapped(code + '^' + (codeLabel[1] || ''), String(raw).slice(0, 24) + (einheit ? ' [' + einheit + ']' : ''));
        continue;
      }
      if (key === 'weightKg') { const kg = gewichtAusOBX('weight', val, einheit); if (kg != null) weightFromPid = kg; continue; }

      // Einheit pruefen, bevor der Wert klinisch verwendet wird.
      const u = rechneEinheit(key, val, einheit);
      if (!u.ok) {
        const name = KLARNAME[key] || key;
        const meldung = name + ' kommt in einer unbekannten Einheit (' + einheit + ') — der Wert wird ' +
          'NICHT verwendet. Einstellung am Geraet pruefen.';
        if (alarmTexte.indexOf(meldung) < 0) alarmTexte.push(meldung);
        continue;   // lieber eine sichtbare Luecke als eine falsche Zahl
      }
      if (u.umgerechnet) {
        const hinweis = (KLARNAME[key] || key) + ' wurde von ' + u.umgerechnet + ' umgerechnet.';
        if (umrechnungen.indexOf(hinweis) < 0) umrechnungen.push(hinweis);
      }

      // Alarmstufe des Geraets (OBX-8): der Monitor hat den Wert selbst als kritisch markiert.
      if (flag && /^(H|HH|L|LL)$/i.test(String(flag).trim())) {
        const F = String(flag).trim().toUpperCase();
        const richtung = F.charAt(0) === 'H' ? 'zu hoch' : 'zu niedrig';
        const staerke = F.length > 1 ? ' (stark)' : '';
        const m = 'Geraet meldet: ' + (KLARNAME[key] || key) + ' ' + richtung + staerke;
        if (alarmTexte.indexOf(m) < 0) alarmTexte.push(m);
      }

      /*
       * HF = 0 ist praktisch immer "kein EKG-Signal" (Kabel verrauscht/ab), nicht echte Asystolie:
       * der Monitor liefert die HF dann ueber die PULSRATE (SpO2). Am echten LifeVet kam gleichzeitig
       * MDC_ECG_HEART_RATE=0 UND MDC_PULS_OXIM_PULS_RATE=72 - ohne diese Zeile ueberschriebe die 0 die
       * echte 72. Eine echte Asystolie kommt ueber Alarm/Rhythmus, nicht ueber die HF-Zahl.
       */
      if (key === 'hr' && u.wert === 0) continue;
      // uMEC12 sendet NIBP zwischen den Messungen als Platzhalter -100 (= "noch nicht gemessen",
      // belegt 24.07.2026). Ein Blutdruck <= 0 ist nie echt -> nicht uebernehmen (sonst -100/-100).
      if ((key === 'sys' || key === 'dia' || key === 'map') && u.wert <= 0) continue;
      // Mehrere OBX melden ventrikulaere Extrasystolen (PVC-Zahl, PVC-Rate, VPB-Rate, R-on-T): das
      // MAXIMUM nehmen, damit "eine davon > 0" die Arrhythmie sicher ausloest (inferRhythm -> ves).
      if (key === 'pvcs') { vit.pvcs = Math.max(vit.pvcs || 0, u.wert); continue; }
      vit[key] = u.wert;
    }
    else if (type === 'NTE') {
      // Freitext-Kommentar des Geraets - oft die Klartextmeldung zu einem Alarm.
      const txt = (f[3] || '').trim();
      if (txt) { obxTexts.push(txt); if (alarmTexte.indexOf(txt) < 0 && txt.length < 120) alarmTexte.push(txt); }
    }
  }

  // Zusammenbau ingest-Vitals (mit sinnvollen Fallbacks).
  const af = vit.af != null ? vit.af : vit.rr_imp;
  const temp = vit.temp != null ? vit.temp : vit.temp_tb;
  const role = cfg.role || (vit.etco2 != null ? 'combo' : 'monitor');

  return {
    deviceId: cfg.deviceId || cfg.id || 'hl7',
    // Reihenfolge: ausdrueckliche Konfiguration > Geraetename aus OBR-4 > sendende Anwendung
    // (MSH-3) > neutraler Ersatz. So steht im Menue "LifeVet 10C" statt eines Sammelbegriffs.
    deviceModel: cfg.model || deviceName || sendingApp || 'Gerät' + (cfg.devicePort ? ' an Port ' + cfg.devicePort : ''),
    deviceRole: role,
    // Echte Fallnummer (MRN, Code 2301) vor dem PID-3-Wert - bei Mindray ist PID-3 mitunter nur ein
    // bedeutungsloser GUID. Ist keine MRN da, gilt PID-3 (bei diesem LifeVet ist PID-3 die echte ID).
    patientId: (akte.mrn || patientId) || cfg.patientId || null,
    // Reihenfolge bewusst: was in der Konfiguration steht, schlaegt das Geraet (der Tierarzt hat
    // das letzte Wort). Sonst nimmt die Station, was das Geraet selbst meldet.
    species: cfg.species || species || null,
    weightKg: cfg.weightKg != null ? cfg.weightKg : weightFromPid,
    // Woher Tierart/Gewicht stammen - die Oberflaeche kennzeichnet damit "vom Geraet uebernommen".
    // Bei einer Dosisangabe in mL muss nachvollziehbar sein, worauf sie sich stuetzt.
    herkunft: {
      species: cfg.species ? 'konfig' : (species ? 'geraet' : null),
      weightKg: cfg.weightKg != null ? 'konfig' : (weightFromPid != null ? 'geraet' : null),
    },
    patientName: patientName,
    gebDatum: gebDatum,
    geschlecht: geschlecht,
    // Vollstaendige Akte, soweit das Geraet sie liefert (Besitzer, Arzt, Bett, Groesse, Alter,
    // Rasse, Pacer). Alles rein zur Anzeige und fuers Protokoll - nichts davon fliesst in eine
    // Dosisberechnung ein ausser dem Gewicht, das oben streng geprueft wird.
    akte: Object.keys(akte).length ? akte : null,
    // Woher physisch: fuer das Geraete-Menue ("LifeVet 10C · 192.168.0.51 · Port 8830").
    deviceIp: cfg.deviceIp || null,
    devicePort: cfg.devicePort || null,
    transport: cfg.transport || 'HL7',
    ts: Date.now(),
    vitals: {
      hr: vit.hr, spo2: vit.spo2, etco2: vit.etco2, fico2: vit.fico2, af: af, temp: temp,
      nibp: { sys: vit.sys, dia: vit.dia, map: vit.map },
      // Rhythmus aus PVC-Zaehler + Arrhythmie-Alarmtexten abgeleitet (HL7 hat keinen Rhythmus-Code).
      // capnoShape (Rueckatmung) wird zentral in model.js aus FiCO2 abgeleitet; Haiflosse braucht Waveforms.
      ekgRhythm: inferRhythm(obxTexts.join(' '), vit.pvcs),
    },
    // Klartextmeldungen des Geraets - sie erklaeren dem Tierarzt, WARUM ein Wert fehlt.
    alarms: alarmTexte.slice(0, 30).map((t) => ({ text: t, quelle: 'geraet' })),
    // Echte Kurven des Geraets. Nur Bloecke MIT Abtastrate und mit mindestens einem gueltigen Wert
    // sind darstellbar - der Rest waere eine leere Linie, die Messung vortaeuscht.
    kurvenDaten: kurvenDaten.filter((k) => k.samples.some((s) => s != null)),
    _meta: { pvcs: vit.pvcs, hl7Source: sendingApp, tsStr: tsStr, kurven: kurven, roh: roh, umrechnungen: umrechnungen },
  };
}

const QID = { n: 1 };
function ts14() { return new Date().toISOString().replace(/\D/g, '').slice(0, 14); }
function mllp(text) { return Buffer.concat([Buffer.from([VT]), Buffer.from(text, 'latin1'), Buffer.from([FS, CR])]); }

class HL7Adapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    // Modus: 'listener' (Geraet verbindet sich zum PC und pusht) ODER
    //        'client' (PC verbindet sich zum Geraet:4601, PDS Realtime, sendet QRY^R02 und empfaengt ORU).
    this.mode = cfg.mode === 'client' ? 'client' : 'listener';
    this.host = cfg.host || null;
    this.port = cfg.port || cfg.listenPort || (this.mode === 'client' ? 4601 : 5000);
    this.server = null; this.sock = null; this.qtimer = null; this.rtimer = null;
    this.unmapped = new Set();
    // Wiederverbinden mit WACHSENDEM Abstand (Befund 2.3, 21.07.2026): frueher wurde fest alle
    // 3 s neu verbunden und dabei ZWEI Warnzeilen je Versuch geschrieben (error + close) = ~40
    // Zeilen pro Minute, solange das Geraet aus ist — also genau im Normalzustand VOR der
    // Inbetriebnahme. Das Diagnose-Log war dadurch unbrauchbar.
    this.wartenMs = 3000;
    this.MAX_WARTEN = 60000;
    this.versuche = 0;
    this.letzterFehler = null;
  }

  describe() { return { id: this.id, model: this.cfg.model || 'Mindray (HL7)', role: this.cfg.role || 'monitor' }; }

  async connect() {
    if (this.mode === 'client') return this._connectClient();
    return this._listen();
  }

  _listen() {
    this.server = net.createServer((socket) => this._onClient(socket));
    this.server.on('error', (e) => this.ctx.log && this.ctx.log.error('hl7', 'Listener-Fehler: ' + e.message));
    this.server.listen(this.port, () => {
      this.connected = true;
      this.ctx.log && this.ctx.log.info('hl7', 'HL7-Listener auf Port ' + this.port + ' bereit (Monitor "Send HL7" -> Serveradresse=PC-IP, Port ' + this.port + ').');
    });
  }

  // PDS-Realtime-Client: PC verbindet sich zum Geraet und fragt Daten ab (QRY^R02 = nur Daten-Abfrage,
  // KEINE Geraetesteuerung), empfaengt ORU^R01, quittiert (ACK) als Keepalive, Reconnect bei Abbruch.
  /*
   * Welche Adresse wird JETZT angesprochen?
   *
   * "auto" (empfohlen) = der zuletzt im Netz gefundenen Medizin-MAC folgen. Am Praxis-PC stand am
   * 22.07.2026 fest "192.168.0.50" in der Konfiguration, das Geraet hing aber auf .51 (DHCP). Der
   * Adapter klopfte 60 s lang an eine tote Adresse, obwohl der Verbindungs-Assistent die richtige
   * bereits kannte. Bei jedem Verbindungsversuch neu aufgeloest — zieht das Geraet um, zieht die
   * Station mit.
   */
  _zielHost() {
    if (!this.host || this.host === 'auto') return geraetefund.beste(null);
    // Feste IP eingetragen: dabei bleiben, solange sie im Netz ist. Ist sie verschwunden und
    // steht stattdessen ein Geraet unter einer ANDEREN Adresse, dorthin wechseln statt ins Leere
    // zu laufen (der haeufigste Fall nach einem Router-/DHCP-Wechsel).
    return geraetefund.beste(this.host) || this.host;
  }

  _connectClient() {
    if (!this.host) { this.ctx.log && this.ctx.log.warn('hl7', this.id + ': client-Modus ohne "host" -> deaktiviert (Geraete-IP setzen oder "auto" eintragen).'); return; }
    const self = this;
    const open = () => {
      const ziel = self._zielHost();
      if (!ziel) {
        // "auto" und noch kein Geraet gesehen: ruhig warten statt auf gut Glueck zu verbinden.
        if (self.versuche === 0 && self.ctx.log) {
          self.ctx.log.info('hl7', self.id + ': "auto" — es ist noch kein Geraet im Netz gefunden. ' +
            'Der Verbindungs-Assistent sucht weiter; sobald ein Monitor auftaucht, wird er automatisch abgefragt.');
        }
        self.versuche++;
        self.rtimer = setTimeout(open, self.wartenMs);
        self.wartenMs = Math.min(self.wartenMs * 2, self.MAX_WARTEN);
        return;
      }
      if (ziel !== self.host) {
        self.ctx.log && self.ctx.log.info('hl7', self.id + ': Geraet jetzt auf ' + ziel +
          (self.cfg.host && self.cfg.host !== 'auto' ? ' (konfiguriert war ' + self.cfg.host + ')' : '') +
          ' — die Abfrage folgt der neuen Adresse.');
        self.host = ziel;
      }
      const sock = net.connect(self.port, self.host, () => {
        const warAus = self.versuche > 0;
        self.connected = true;
        self.wartenMs = 3000; self.versuche = 0; self.letzterFehler = null;   // Erfolg -> Abstand zuruecksetzen
        self.ctx.log && self.ctx.log.info('hl7', (warAus ? 'HL7-Client WIEDER verbunden mit ' : 'HL7-Client verbunden mit ') +
          self.host + ':' + self.port + ' (PDS Realtime). Sende QRY^R02...');
        self._sendQuery(sock);
        self.qtimer = setInterval(() => { if (!sock.destroyed) self._sendQuery(sock); }, 5000);
      });
      self.sock = sock;
      let buf = Buffer.alloc(0);
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (self.cfg.rawLog) self._rawDump(chunk);
        let start;
        while ((start = buf.indexOf(VT)) !== -1) {
          const end = buf.indexOf(FS, start + 1);
          if (end === -1) break;
          const payload = decodePayload(buf.slice(start + 1, end));
          buf = buf.slice(end + 2);
          self._handleMessage(payload, sock);
        }
        if (buf.length > 1 << 20) buf = Buffer.alloc(0);
      });
      // Der Fehler wird hier nur GEMERKT, nicht geloggt: auf jedes 'error' folgt ohnehin ein
      // 'close'. Frueher schrieben beide je eine Zeile — das war die Haelfte der Log-Flutung.
      sock.on('error', (e) => { self.letzterFehler = e && e.message ? e.message : String(e); });
      sock.on('close', () => {
        self.connected = false;
        if (self.qtimer) { clearInterval(self.qtimer); self.qtimer = null; }
        self.versuche++;
        // EINMAL erklaeren, danach still weiterprobieren. Ein ausgeschaltetes Geraet ist vor der
        // Inbetriebnahme der Normalfall und darf das Log nicht fluten.
        if (self.versuche === 1 && self.ctx.log) {
          self.ctx.log.warn('hl7', 'Geraet ' + self.host + ':' + self.port + ' antwortet nicht' +
            (self.letzterFehler ? ' (' + self.letzterFehler + ')' : '') +
            '. VetStation versucht es weiter — der Abstand waechst auf bis zu ' +
            (self.MAX_WARTEN / 1000) + ' s. Weitere gleiche Meldungen werden unterdrueckt.');
        }
        self.rtimer = setTimeout(open, self.wartenMs);
        self.wartenMs = Math.min(self.wartenMs * 2, self.MAX_WARTEN);
      });
    };
    open();
  }

  _sendQuery(sock) {
    // KORRIGIERTE Mindray-PDS-Realtime-Abfrage (Befund 25.07.2026, verifiziert aus VSCaptureMRay.dll
    // + PDS-Spec). Der fruehere Fehlversuch scheiterte NICHT am QRF, sondern an der QRD: Feld QRD-9
    // MUSS "RES" sein ("The 9th field must be RES, otherwise an error message is returned") — wir
    // hatten "MON", der Server verwarf die Query -> keine Periodik. NIBP+Alarme kommen unsolicited
    // auf einem eigenen Pfad und beweisen NICHT, dass die Query lief.
    // Format verbatim aus VSCaptureMRay.dll (liest Mindray-Periodik nachweislich): QRF SendType=1,
    // SendFreq=1s, SendAll=0 + explizite Parameter-IDs. IDs: 101=HF 151=AF 160=SpO2 161=PR
    // 170/171/172=NIBP 200/201/202=Temp 220/222=CO2/AwRR.
    const id = QID.n++;
    const segs = [
      'MSH|^~\\&|||||||QRY^R02|' + id + '|P|2.3.1',
      'QRD|' + ts14() + '|R|I|Q' + id + '|||||RES',
      'QRF|MON||||0&0^1^1^0^101&151&160&161',
      'QRF|MON||||0&0^1^1^0^170&171&172&200',
      'QRF|MON||||0&0^1^1^0^201&202&220&222',
    ];
    try { sock.write(mllp(segs.join('\r'))); } catch (_) {}
  }

  _onClient(socket) {
    const ip = socket.remoteAddress;
    this.ctx.log && this.ctx.log.info('hl7', 'Monitor verbunden: ' + ip);
    let buf = Buffer.alloc(0);
    socket.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      if (this.cfg.rawLog) this._rawDump(chunk);
      // MLLP-Rahmen extrahieren: <VT> payload <FS><CR>
      let start;
      while ((start = buf.indexOf(VT)) !== -1) {
        const end = buf.indexOf(FS, start + 1);
        if (end === -1) break;                          // Rahmen noch unvollstaendig
        const payload = decodePayload(buf.slice(start + 1, end)); // UTF-8 laut MSH-18, sonst latin1
        buf = buf.slice(end + 2);                        // FS + CR ueberspringen
        this._handleMessage(payload, socket);
      }
      if (buf.length > 1 << 20) buf = Buffer.alloc(0);   // Schutz gegen Muell
    });
    socket.on('error', (e) => this.ctx.log && this.ctx.log.warn('hl7', 'Socketfehler ' + ip + ': ' + e.message));
    socket.on('close', () => this.ctx.log && this.ctx.log.warn('hl7', 'Monitor getrennt: ' + ip));
  }

  _handleMessage(text, socket) {
    // Roh-Ringpuffer AUCH im Client-Modus (bisher nur beim probe): so sind die uMEC-Nachrichten
    // ueber /api/rohnachrichten belegbar, egal ob das Geraet pusht oder der PC abfragt.
    this.letzteRoh = this.letzteRoh || [];
    this.letzteRoh.push({ ts: Date.now(), port: this.port, text: String(text).slice(0, 8000) });
    if (this.letzteRoh.length > 40) this.letzteRoh.shift();
    let frame;
    try {
      frame = parseHL7Message(text, {
        deviceId: this.cfg.deviceId || this.id, model: this.cfg.model, role: this.cfg.role,
        species: this.cfg.species, weightKg: this.cfg.weightKg, patientId: this.cfg.patientId,
      }, (u, info) => {
        if (!this.unmapped.has(u)) { this.unmapped.add(u); this.ctx.log && this.ctx.log.warn('hl7', 'Unbekannter OBX-Code (bitte in CODE_MAP ergaenzen): ' + u + (info ? ' (Beispielwert: ' + info + ')' : '')); }
      });
    } catch (e) { this.ctx.log && this.ctx.log.warn('hl7', 'Parse-Fehler: ' + e.message); return; }
    if (frame) this.emit(frame);
    // HL7-ACK (Protokoll-Quittung, KEINE Geraetesteuerung). Im Client-Modus als Keepalive noetig.
    if (this.cfg.ack || this.mode === 'client') this._sendAck(socket, text);
  }

  _sendAck(socket, orig) {
    try {
      const msh = (orig.split(/[\r\n]+/)[0] || '').split('|');
      const ctrlId = msh[9] || '1';
      const ack = 'MSH|^~\\&|VetStation|||||' + new Date().toISOString().replace(/\D/g, '').slice(0, 14) + '||ACK^R01|' + ctrlId + '|P|2.3.1\rMSA|AA|' + ctrlId + '\r';
      socket.write(Buffer.concat([Buffer.from([VT]), Buffer.from(ack, 'latin1'), Buffer.from([FS, CR])]));
    } catch (_) {}
  }

  _rawDump(chunk) {
    try {
      const dir = path.join(__dirname, '..', '..', 'data');
      fs.mkdirSync(dir, { recursive: true });
      fs.appendFileSync(path.join(dir, 'hl7-raw.log'), chunk.toString('latin1'));
    } catch (_) {}
  }

  dispose() {
    if (this.server) { try { this.server.close(); } catch (_) {} }
    if (this.sock) { try { this.sock.destroy(); } catch (_) {} }
    if (this.qtimer) clearInterval(this.qtimer);
    if (this.rtimer) clearTimeout(this.rtimer);
    this.server = this.sock = this.qtimer = this.rtimer = null;
    this.connected = false;
  }
}

module.exports = { HL7Adapter, parseHL7Message, decodePayload };
