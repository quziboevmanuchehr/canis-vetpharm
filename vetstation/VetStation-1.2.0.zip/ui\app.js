/*
 * app.js — VetStation Kiosk-App (Schicht 2/3). Verbindet sich mit der Bridge (WebSocket),
 * fuehrt Geraete pro Patient zusammen (kommt bereits gematcht), rendert das Monitorbild +
 * die LIVE-"Brain"-Analyse (Injektion mL + Geraete-Soll) und die Zwei-Fenster-Ansicht.
 * Read-only: sendet nur Zuordnungs-/Szenario-Steuerung, nie Geraetebefehle.
 */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var VS = window.VS;
  var A = function () { return window.ANAES; };

  var SP_ICON = {}; // species id -> icon (aus ANAES.species)
  var ROLE_ICON = { monitor: '🖥️', anesthesia: '💨', capno: '🫁', combo: '🧩' };

  var state = { devices: [], patients: [], scenarios: [], solo: false };
  var cards = {};   // patientKey -> cardState
  var ws = null, wsReady = false;

  // ---------- Theme (dunkel = Cockpit-Standard) ----------
  function initTheme() {
    var t = localStorage.getItem('vp-theme') || 'dark';
    applyTheme(t);
    $('#themeBtn').onclick = function () { applyTheme(document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light'); };
  }
  function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem('vp-theme', t);
    $('#themeBtn').textContent = t === 'light' ? '☾' : '☀︎';
    var mc = document.querySelector('meta[name=theme-color]'); if (mc) mc.setAttribute('content', t === 'light' ? '#e9eef7' : '#0a0c10');
  }

  // ---------- WebSocket ----------
  function connect() {
    var proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(proto + '://' + location.host + '/ws');
    ws.onopen = function () { wsReady = true; setConn(true, 'verbunden'); };
    ws.onclose = function () { wsReady = false; setConn(false, 'getrennt – neu…'); setTimeout(connect, 1500); };
    ws.onerror = function () { setConn(false, 'Fehler'); };
    ws.onmessage = function (e) {
      var m; try { m = JSON.parse(e.data); } catch (_) { return; }
      if (m.type === 'hello') { state.scenarios = m.scenarios || []; }
      else if (m.type === 'devices') { state.devices = m.devices || []; renderDevices(); }
      else if (m.type === 'patients') { state.patients = m.patients || []; renderPatients(); }
      else if (m.type === 'diag') { if (VS.feedback) VS.feedback.diag(m.event); if (window.VSADMIN && window.VSADMIN.onDiag) window.VSADMIN.onDiag(m.event); }
    };
  }
  function send(obj) { if (wsReady) try { ws.send(JSON.stringify(obj)); } catch (_) {} }
  function setConn(ok, txt) {
    var d = $('#connDot'); d.className = 'vs-dot ' + (ok ? 'on' : 'off'); $('#connText').textContent = txt;
  }

  // ---------- Geraete-Leiste (Auto-Discovery) ----------
  function renderDevices() {
    var host = $('#devices');
    host.innerHTML = '<span class="lbl">Geräte</span>' + (state.devices.length ? '' : '<small style="color:var(--muted)">keine erkannt</small>');
    state.devices.forEach(function (d) {
      var el = document.createElement('div'); el.className = 'vs-dev';
      el.innerHTML = '<span class="st ' + d.status + '"></span><span class="role">' + (ROLE_ICON[d.role] || '📟') + '</span>' +
        '<span>' + esc(d.model) + '</span><small>' + (d.patientId ? '· ' + esc(d.patientId) : '· ' + d.role) + '</small>';
      host.appendChild(el);
    });
  }

  // ---------- Patienten-Raster ----------
  function priClass(sev) { return sev >= 5 ? 'sev5' : sev >= 4 ? 'sev4' : sev >= 3 ? 'sev3' : 'calm'; }

  function renderPatients() {
    var pats = state.patients.slice();
    // Bewertung + Sortierung: gefaehrlichste Warnung nach oben (§6.4)
    pats.forEach(function (p) { p._res = assessPatient(p); });
    pats.sort(function (a, b) { return (b._res.priority || 0) - (a._res.priority || 0); });

    $('#empty').style.display = pats.length ? 'none' : '';

    // entfernte Patienten aufraeumen
    Object.keys(cards).forEach(function (k) { if (!pats.find(function (p) { return p.patientKey === k; })) destroyCard(k); });

    // anlegen/aktualisieren
    pats.forEach(function (p) { if (!cards[p.patientKey]) createCard(p); updateCard(p, p._res); });

    // DOM-Reihenfolge = Prioritaet
    var grid = $('#grid');
    pats.forEach(function (p) { grid.appendChild(cards[p.patientKey].el); });
    grid.classList.toggle('solo', state.solo || pats.length === 1);
  }

  function assessPatient(p) {
    var cs = cards[p.patientKey];
    var iso = (cs && cs.isoOverride != null) ? cs.isoOverride : p.isoPct;
    var pat = Object.assign({ species: p.species || 'hund', weightKg: p.weightKg || 10, isoPct: p.isoPct }, p.vitals || {});
    return VS.brain.assess(A(), pat, { iso: iso });
  }

  function buildFrame(p) {
    var vit = p.vitals || {};
    var ekgId = vit.ekgRhythm || 'sinus';
    var e = (A().ekg || []).find(function (x) { return x.id === ekgId; });
    var W = (e && e.w) || {};
    var arrest = W.flat || W.chaos;
    var pleth = vit.pleth || (arrest || vit.spo2 <= 50 || !(vit.hr > 0) ? 'flat' : (vit.spo2 < 90 ? 'weak' : 'normal'));
    var capno = vit.capnoShape || (!(vit.etco2 > 0) || !(vit.af > 0) ? 'flat' : (vit.etco2 > 50 ? 'high' : (vit.etco2 < 30 ? 'low' : 'normal')));
    return { hr: vit.hr, ekgW: W, spo2: vit.spo2, etco2: vit.etco2, af: vit.af, pleth: pleth, capno: capno };
  }

  function createCard(p) {
    var el = document.createElement('section');
    el.className = 'vs-patient'; el.setAttribute('data-k', p.patientKey);
    el.innerHTML =
      '<div class="vs-pat-head" data-head></div>' +
      '<div class="vs-body">' +
        '<div class="vs-mon"><div class="vs-screen"><canvas></canvas></div><div class="vs-tiles" data-tiles></div></div>' +
        '<div class="vs-brain" data-brain></div>' +
      '</div>' +
      '<div class="vs-foot" data-foot></div>';
    $('#grid').appendChild(el);
    var canvas = el.querySelector('canvas');
    var cs = { key: p.patientKey, el: el, canvas: canvas, frame: buildFrame(p), isoOverride: null, fb: {} };
    cs.mc = new VS.waveforms.MonitorCanvas(canvas, function () { return cs.frame; });
    VS.waveforms.driver.add(cs.mc);
    cards[p.patientKey] = cs;
  }

  function destroyCard(key) {
    var cs = cards[key]; if (!cs) return;
    VS.waveforms.driver.remove(cs.mc);
    if (cs.el.parentNode) cs.el.parentNode.removeChild(cs.el);
    delete cards[key];
  }

  function updateCard(p, res) {
    var cs = cards[p.patientKey];
    cs.frame = buildFrame(p);
    var sev = res.top ? res.top.sev : 0;
    cs.el.className = 'vs-patient ' + priClass(sev);
    renderHead(cs, p, res);
    renderTiles(cs, p, res);
    renderBrain(cs, p, res);
    renderFoot(cs, p, res);
  }

  function renderHead(cs, p, res) {
    var sp = (A().species || []).find(function (s) { return s.id === p.species; }) || { icon: '🐾', name: p.species || '—' };
    var sev = res.top ? res.top.sev : 0;
    var prioTxt = sev >= 5 ? 'KRITISCH · CPR' : sev >= 4 ? 'DRINGEND' : sev >= 3 ? 'ACHTUNG' : (res.alarmCount ? res.alarmCount + ' Alarm(e)' : 'stabil');
    var devs = (p.devices || []).map(function (d) { return '<span class="vs-devchip ' + (p.manual ? 'paired' : '') + '" title="' + esc(d.model) + '">' + (ROLE_ICON[d.role] || '📟') + ' ' + esc(shortId(d.deviceId)) + '</span>'; }).join('');
    cs.el.querySelector('[data-head]').innerHTML =
      '<span class="vs-sp-ic">' + sp.icon + '</span>' +
      '<div><div class="vs-pat-id">' + esc(p.patientId || 'Patient') + '</div>' +
        '<div class="vs-pat-meta">' + esc(sp.name) + ' · ' + fmtW(p.weightKg) + ' kg' + (p.isoPct != null ? ' · Iso ' + p.isoPct + ' %' : '') + '</div></div>' +
      '<div class="vs-spacer"></div>' +
      '<div class="vs-devchips">' + devs + '</div>' +
      '<span class="vs-prio ' + priClass(sev) + '">' + prioTxt + '</span>';
  }

  var TILES = [
    { p: 'hr', ab: 'HF', u: '/min', get: function (v) { return v.hr; } },
    { p: 'spo2', ab: 'SpO₂', u: '%', get: function (v) { return v.spo2; } },
    { p: 'etco2', ab: 'EtCO₂', u: 'mmHg', get: function (v) { return v.etco2; } },
    { p: 'nibp', ab: 'NIBP', u: 'SYS/DIA (MAP)', get: function (v) { return v; } },
    { p: 'rr', ab: 'AF', u: '/min', get: function (v) { return v.af; } },
    { p: 'temp', ab: 'Temp', u: '°C', get: function (v) { return v.temp; } },
  ];
  function renderTiles(cs, p, res) {
    var v = p.vitals || {}; var al = res.alarms || {};
    cs.el.querySelector('[data-tiles]').innerHTML = TILES.map(function (t) {
      var val;
      if (t.p === 'nibp') val = (v.sys != null && v.dia != null) ? (v.sys + '/' + v.dia + ' (' + (v.map != null ? v.map : '–') + ')') : '– –';
      else { var x = t.get(v); val = (x == null) ? '–' : x; }
      return '<div class="vs-tile' + (al[t.p] ? ' alarm' : '') + '" data-p="' + t.p + '">' +
        '<div class="ab"><span>' + t.ab + '</span></div><div class="v">' + val + '</div><div class="u">' + t.u + '</div></div>';
    }).join('');
  }

  function renderBrain(cs, p, res) {
    var host = cs.el.querySelector('[data-brain]');
    var html = '<div class="vs-brain-h">Brain · Kreuz-Analyse</div>';
    if (res.cross.length) {
      res.cross.forEach(function (f, i) { html += findingHtml(f, p, i === 0); });
    } else if (res.single.length && res.top) {
      html += findingHtml(res.top, p, true);
    } else {
      html += '<div class="vs-finding calm"><div class="ft"><b>Stabil</b><span class="vs-tag">OK</span></div>' +
        '<div class="cause">Alle überwachten Werte im artspezifischen Normbereich.</div></div>';
    }
    // Geraete-Soll immer anzeigen
    html += sollHtml(p, cs);
    host.innerHTML = html;
  }

  function findingHtml(f, p, withInjections) {
    var sc = priClass(f.sev);
    var html = '<div class="vs-finding ' + sc + '"><div class="ft"><b>' + esc(f.title) + '</b>' + (f.tag ? '<span class="vs-tag">' + esc(f.tag) + '</span>' : '') + '</div>';
    if (f.cause) html += '<div class="cause">' + esc(f.cause) + '</div>';
    if (f.fix) html += '<div class="vs-fix"><b>Sofort:</b> ' + esc(f.fix) + '</div>';
    // Geraete-Korrektur und weitere Schritte aus der Wissensbasis (bei Einzelwert-Befunden waren
    // sie bisher gar nicht sichtbar - der Tierarzt sah nur, WAS falsch ist, nicht was zu tun ist).
    if (f.geraet) html += '<div class="vs-fix"><b>Gerät:</b> ' + esc(f.geraet) + '</div>';
    if (f.schritte && f.schritte.length > 1) {
      html += '<ol class="vs-steps">' + f.schritte.slice(1, 5).map(function (s) {
        return '<li>' + esc(s) + '</li>';
      }).join('') + '</ol>';
    }
    if (withInjections && f.incident) {
      /*
       * KEINE MENGEN OHNE GEWICHT (22.07.2026).
       * Hier stand "p.weightKg || 10": fehlte das Gewicht, wurden die mL-Mengen still fuer ein
       * 10-kg-Tier gerechnet und wie belegte Werte angezeigt. Bei einer Katze mit 4 kg waere das
       * mehr als das Doppelte. Ohne Gewicht gibt es jetzt keine Menge, sondern eine Aufforderung.
       */
      if (p.weightKg == null) {
        html += '<div class="vs-fix"><b>Menge:</b> Gewicht fehlt — bitte im Geräte-Menü eintragen, ' +
          'dann erscheinen hier die mL-Mengen.</div>';
        return html + '</div>';
      }
      var inj = VS.dose.injectionsFor(A(), f.incident, p.species || 'hund', p.weightKg).filter(function (x) { return x.available; });
      if (inj.length) {
        html += '<div class="vs-inject">';
        inj.forEach(function (d) {
          var ml = (d.mlLo != null) ? VS.dose.fmtRange(d.mlLo, d.mlHi) + ' mL' : '–';
          var mg = d.amtLo != null ? VS.dose.fmtRange(d.amtLo, d.amtHi) + ' ' + d.amtUnit : '';
          html += '<div class="vs-inj"><span class="ml">' + ml + '</span><span class="nm">' + (d.icon || '💉') + ' ' + esc(d.name) + '</span>' +
            '<span class="mg">' + mg + (d.conc ? ' @ ' + esc(String(d.conc)) + ' mg/mL' : '') + '</span>' +
            (d.route ? '<span class="rt">' + esc(d.route) + '</span>' : '') +
            (d.note ? '<span class="cau">ⓘ ' + esc(d.note) + '</span>' : '') +
            (d.caution ? '<span class="cau">⚠ ' + esc(d.caution) + '</span>' : '') + '</div>';
        });
        html += '</div>';
      }
    }
    return html + '</div>';
  }

  function sollHtml(p, cs) {
    var iso = (cs.isoOverride != null) ? cs.isoOverride : p.isoPct;
    var cmp = VS.deviceTarget.compare(A(), p.species || 'hund', p.weightKg || 10, { iso: iso, o2: null });
    var rows = cmp.rows.map(function (r) {
      var cls = r.value && r.value !== '–' ? (r.off ? 'off' : 'ok') : '';
      return '<div class="vs-sollrow ' + cls + '"><span>' + esc(r.name) + '</span><span class="mono">' + esc(r.value || '') + '</span><span class="tg">Soll ' + esc(r.target) + '</span></div>';
    }).join('');
    return '<div class="vs-soll"><div class="vs-brain-h" style="color:var(--cyan)">Geräte-Soll</div>' + rows + '</div>';
  }

  function renderFoot(cs, p, res) {
    var top = res.top;
    var fbKey = top ? (top.title || top.tag) : null;
    var given = fbKey && cs.fb[fbKey];
    var fb = top ?
      '<button class="vs-fbbtn good' + (given === 'helpful' ? ' done' : '') + '" data-fb="helpful">✓ hilfreich</button>' +
      '<button class="vs-fbbtn bad' + (given === 'override' ? ' done' : '') + '" data-fb="override">✗ nicht passend</button>' : '';
    var scen = '<span class="vs-scen">Szenario (Test): <select data-scen>' +
      '<option value="">—</option>' +
      state.scenarios.map(function (s) { return '<option value="' + s.id + '">' + esc(s.name) + '</option>'; }).join('') +
      '</select></span>';
    var foot = cs.el.querySelector('[data-foot]');
    foot.innerHTML = fb + scen;
    foot.querySelectorAll('[data-fb]').forEach(function (b) {
      b.onclick = function () {
        if (!top) return;
        cs.fb[fbKey] = b.getAttribute('data-fb');
        VS.feedback.feedback({ verdict: cs.fb[fbKey], incident: top.incident, title: top.title, species: p.species });
        b.parentNode.querySelectorAll('[data-fb]').forEach(function (x) { x.classList.remove('done'); });
        b.classList.add('done');
      };
    });
    var sel = foot.querySelector('[data-scen]');
    if (sel) sel.onchange = function () { if (sel.value) send({ type: 'scenario', patientId: p.patientId, scenarioId: sel.value }); };
  }

  // ---------- helpers ----------
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function fmtW(w) { return w == null ? '?' : (w < 1 ? Math.round(w * 1000) / 1000 : w < 10 ? Math.round(w * 10) / 10 : Math.round(w)); }
  function shortId(id) { return String(id).replace(/^SIM-|^PB-/, '').slice(-8); }

  // ---------- boot ----------
  function boot() {
    initTheme();
    $('#layoutBtn').onclick = function () { state.solo = !state.solo; renderPatients(); };
    $('#adminBtn').onclick = function () { if (window.VSADMIN) window.VSADMIN.open(); };
    window.VSAPP = { getDevices: function () { return state.devices; }, getPatients: function () { return state.patients; }, send: send };

    // Live-Daten nachladen (Verbesserungen aus der Web-App), dann neu bewerten.
    if (VS.clinicalData) {
      updateDataSrc();
      VS.clinicalData.pullLive(function () { updateDataSrc(); renderPatients(); });
    }
    connect();
  }
  function updateDataSrc() {
    var el = $('#dataSrc'); if (!el) return;
    var src = (VS.clinicalData && VS.clinicalData.source) || 'vendor';
    el.textContent = '📚 ' + (src === 'live' ? 'Live-Daten' : 'lokale Daten') + ' · ' + ((A().drugs || []).length) + ' Medis/' + ((A().species || []).length) + ' Arten';
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
