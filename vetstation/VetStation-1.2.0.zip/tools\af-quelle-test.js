'use strict';
/*
 * af-quelle-test.js — AF-Quellen-Prioritaet (§Atemfrequenz).
 * Regel (Nutzer 25.07.2026): das virtuelle Geraet nimmt AF ERST vom Monitor, ABER sobald der
 * Kapnograph/das Narkosegeraet AF liefert, hat DER Vorrang — er zaehlt die Atemzuege direkt aus
 * der CO2-Wellenform (genauer/sicherer) statt aus der Impedanz-Atmung des Monitors.
 * Start: node tools/af-quelle-test.js
 */
const { normalizeFrame } = require('../bridge/src/model');
const { mergePatients } = require('../bridge/src/matching');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function rec(id, raw) { return { deviceId: id, frame: normalizeFrame(raw).frame }; }
const now = Date.now();

console.log('AF-Quellen-Prioritaet (Kapnograph vor Monitor) — Selbsttest\n');

// Monitor (Impedanz-AF 20, KEIN CO2) + Kapnograph/Narkose (AF 12, MIT CO2) am selben Patienten.
const mon = rec('MON-1', { deviceId: 'MON-1', deviceModel: 'uMEC12 Vet', deviceRole: 'monitor',
  patientId: 'A-1', species: 'hund', weightKg: 20, ts: now + 1,
  vitals: { hr: 90, spo2: 98, nibp: { sys: 110, dia: 70 }, temp: 38, af: 20 } });
const cap = rec('CAP-1', { deviceId: 'CAP-1', deviceModel: 'Veta 5 Plus', deviceRole: 'anesthesia',
  patientId: 'A-1', species: 'hund', weightKg: 20, ts: now,
  vitals: { etco2: 42, fico2: 2, af: 12, capnoShape: 'normal' } });

let p = mergePatients([mon, cap], {})[0] || {};
ok('Kapnograph-AF (12) gewinnt gegen Monitor-AF (20)', p.vitals.af === 12, 'af=' + p.vitals.af);
ok('Quelle korrekt als "kapnograph" markiert', p.afSource === 'kapnograph', 'afSource=' + p.afSource);

// Reihenfolge egal (Monitor zuletzt gesehen): Kapno gewinnt trotzdem.
p = mergePatients([cap, mon], {})[0] || {};
ok('Reihenfolge egal — Kapnograph-AF gewinnt weiterhin (12)', p.vitals.af === 12, 'af=' + p.vitals.af);

// NUR Monitor -> AF vom Monitor (Rueckfall), Quelle "monitor".
p = mergePatients([mon], {})[0] || {};
ok('ohne Kapnograph: AF vom Monitor (20)', p.vitals.af === 20, 'af=' + p.vitals.af);
ok('Quelle "monitor" (Rueckfall)', p.afSource === 'monitor', 'afSource=' + p.afSource);

// Kapnograph OHNE AF, Monitor MIT AF -> Rueckfall auf Monitor.
const capNoAf = rec('CAP-2', { deviceId: 'CAP-2', deviceModel: 'Veta 5 Plus', deviceRole: 'anesthesia',
  patientId: 'A-1', species: 'hund', weightKg: 20, ts: now, vitals: { etco2: 40 } });
p = mergePatients([mon, capNoAf], {})[0] || {};
ok('Kapno ohne AF -> AF vom Monitor (20) als Rueckfall', p.vitals.af === 20, 'af=' + p.vitals.af);
ok('Quelle dann "monitor"', p.afSource === 'monitor', 'afSource=' + p.afSource);

// Ein CO2-messender "combo"-Monitor (LifeVet) zaehlt als Kapno-Quelle und schlaegt einen reinen Monitor.
const combo = rec('LV-1', { deviceId: 'LV-1', deviceModel: 'LifeVet 10C', deviceRole: 'combo',
  patientId: 'A-1', species: 'hund', weightKg: 20, ts: now, vitals: { etco2: 41, af: 18 } });
const pureMon = rec('MON-3', { deviceId: 'MON-3', deviceModel: 'Monitor', deviceRole: 'monitor',
  patientId: 'A-1', species: 'hund', weightKg: 20, ts: now + 1, vitals: { af: 26 } });
p = mergePatients([pureMon, combo], {})[0] || {};
ok('CO2-messender combo-Monitor (AF 18) schlaegt reinen Monitor (AF 26)', p.vitals.af === 18, 'af=' + p.vitals.af);
ok('Quelle "kapnograph" (weil CO2 gemessen)', p.afSource === 'kapnograph', 'afSource=' + p.afSource);

// Kein AF irgendwo -> afSource null, kein Absturz.
const nada = rec('X', { deviceId: 'X', deviceModel: 'm', deviceRole: 'monitor', patientId: 'B-9', species: 'katze', weightKg: 4, ts: now, vitals: { hr: 120 } });
p = mergePatients([nada], {})[0] || {};
ok('kein AF -> afSource null (kein Absturz)', p.afSource == null && p.vitals.af == null, 'afSource=' + p.afSource + ' af=' + p.vitals.af);

console.log('\n' + (fail ? ('FEHLER: ' + fail + ' Test(s) fehlgeschlagen, ' + pass + ' ok') : ('ALLE ' + pass + ' Tests bestanden')));
process.exit(fail ? 1 : 0);
