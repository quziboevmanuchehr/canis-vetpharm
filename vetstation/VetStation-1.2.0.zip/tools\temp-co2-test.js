'use strict';
/*
 * temp-co2-test.js — Gezielter Test: TEMPERATUR- und CO2-Kabel am Mindray/LifeVet.
 * Hintergrund (Praxis, 24.07.2026): NIBP/EKG/RESP liefen bereits, das Temperatur-Kabel und
 * die CO2-Wasserfalle waren aber noch nicht angeschlossen. Dieser Test belegt, dass der
 * gesamte Software-Pfad Temperatur und CO2 korrekt liefert, sobald die Kabel dran sind —
 * in BEIDEN Geraete-Dialekten, mit Einheiten-Umrechnung, im Kabel-ab-Zustand und bis in
 * die fertigen Vitalwerte (inkl. Rueckatmung aus FiCO2).
 *   node tools/temp-co2-test.js
 */
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const { normalizeFrame } = require('../bridge/src/model');
const { mergePatients } = require('../bridge/src/matching');

let fails = 0, passes = 0;
function ok(c, d, x) { if (c) { passes++; console.log('  ✓ ' + d); } else { fails++; console.log('  ✗ FAIL: ' + d + (x !== undefined ? '  [' + x + ']' : '')); } }
function near(a, b, eps) { return a != null && Math.abs(a - b) <= (eps || 0.15); }
function msg(lines) { return lines.join('\r'); }

console.log('== TEMPERATUR + CO2 Kabel-Test (Mindray/LifeVet) ==');

/* ---------- A) Beide Kabel verbunden, privater uMEC-Bettmonitor-Dialekt ---------- */
console.log('\nA) Temp- und CO2-Kabel verbunden (privater Dialekt, uMEC):');
const A = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100000||ORU^R01|1|P|2.3.1',
  'PID|||A-1||Bella^||20200101|M',
  'OBX||NM|101^HR||96||||||F',
  'OBX||NM|160^SpO2||97||||||F',
  'OBX||NM|250^CO2Et||41|mmHg|||||F',
  'OBX||NM|221^FiCO2||2|mmHg|||||F',
  'OBX||NM|222^AWRR||12|/min|||||F',
  'OBX||NM|201^T2||38.4|C|||||F',
]), {});
ok(A.vitals.etco2 === 41, 'CO2 (EtCO2) = 41 mmHg (privater Code 250)', A.vitals.etco2);
ok(A.vitals.fico2 === 2, 'FiCO2 = 2 mmHg (Code 221)', A.vitals.fico2);
ok(A.vitals.af === 12, 'Atemfrequenz aus CO2-Modul = 12 (Code 222 AWRR)', A.vitals.af);
ok(A.vitals.temp === 38.4, 'Temperatur = 38.4 (privater Code 201 = T2)', A.vitals.temp);
ok(A.deviceRole === 'combo', 'Rolle wird "combo", weil CO2 vorhanden ist', A.deviceRole);

/* ---------- B) MDC/IEEE-11073-Dialekt (das LifeVet nutzt diesen) + Einheiten-Umrechnung ---------- */
console.log('\nB) MDC-Dialekt, CO2 in kPa + Temp in Fahrenheit (Umrechnung):');
const B = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100100||ORU^R01|2|P|2.3.1',
  'PID|||A-1||Bella^||20200101|M',
  'OBX||NM|151728^MDC_AWAY_CO2_ET||5.3|kPa|||||F',
  'OBX||NM|150344^MDC_TEMP||101.3|degF|||||F',
]), {});
ok(near(B.vitals.etco2, 39.8, 0.3), 'CO2 5.3 kPa → ~39.8 mmHg umgerechnet', B.vitals.etco2);
ok(near(B.vitals.temp, 38.5, 0.2), 'Temp 101.3 °F → 38.5 °C umgerechnet', B.vitals.temp);
ok((B._meta.umrechnungen || []).some(function (u) { return /kPa/.test(u); }), 'Umrechnungs-Hinweis CO2 (kPa) vorhanden', JSON.stringify(B._meta.umrechnungen));
ok((B._meta.umrechnungen || []).some(function (u) { return /Fahrenheit/.test(u); }), 'Umrechnungs-Hinweis Temp (Fahrenheit) vorhanden', JSON.stringify(B._meta.umrechnungen));

/* ---------- C) CO2 in Vol% (mancher Kapnograf zeigt Vol% statt mmHg) ---------- */
console.log('\nC) CO2 in Vol% (Umrechnung):');
const C = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100200||ORU^R01|3|P|2.3.1',
  'OBX||NM|220^CO2||5.5|Vol%|||||F',
]), {});
ok(near(C.vitals.etco2, 41.8, 0.3), 'CO2 5.5 Vol% → ~41.8 mmHg umgerechnet', C.vitals.etco2);

/* ---------- D) Kabel AB: Mindray sendet 32767 -> darf NIE ein Messwert werden ---------- */
console.log('\nD) Kabel ab (Ungueltig-Marker 32767) → kein erfundener Wert:');
const D = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100300||ORU^R01|4|P|2.3.1',
  'OBX||NM|101^HR||95||||||F',
  'OBX||NM|250^CO2Et||32767|mmHg|||||F',
  'OBX||NM|200^T1||32767|C|||||F',
]), {});
ok(D.vitals.hr === 95, 'HR kommt weiter an (95)', D.vitals.hr);
ok(D.vitals.etco2 == null, 'CO2 32767 → KEIN Wert (Kabel ab)', D.vitals.etco2);
ok(D.vitals.temp == null, 'Temp 32767 → KEIN Wert (Kabel ab)', D.vitals.temp);

/* ---------- E) Falsche/unbekannte Einheit -> Wert verworfen + Klartextmeldung ---------- */
console.log('\nE) Unbekannte Einheit → Wert wird NICHT verwendet, mit Hinweis:');
const E = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100400||ORU^R01|5|P|2.3.1',
  'OBX||NM|250^CO2Et||41|bar|||||F',
  'OBX||NM|200^T1||38|K|||||F',
]), {});
ok(E.vitals.etco2 == null, 'CO2 in "bar" → nicht uebernommen (lieber Luecke als falsch)', E.vitals.etco2);
ok(E.vitals.temp == null, 'Temp in "K" → nicht uebernommen', E.vitals.temp);
ok((E.alarms || []).some(function (a) { return /Einheit/i.test(a.text); }), 'Klartext-Hinweis zur unbekannten Einheit erzeugt', JSON.stringify(E.alarms));

/* ---------- F) Geraete-Alarme zu Temp/CO2 kommen als Klartext an ---------- */
console.log('\nF) Geraete-Alarmtexte (uMEC) fuer Temp/CO2 erscheinen:');
const F = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100500||ORU^R01|6|P|2.3.1',
  'OBX||NM|1^||10076^**T1 zu tief||||||F',
  'OBX||NM|2^||5^Keine CO2 Wasserfalle||||||F',
]), {});
ok((F.alarms || []).some(function (a) { return /T1 zu tief/i.test(a.text); }), 'Alarm "T1 zu tief" erscheint', JSON.stringify(F.alarms));
ok((F.alarms || []).some(function (a) { return /CO2 Wasserfalle/i.test(a.text); }), 'Alarm "Keine CO2 Wasserfalle" erscheint', JSON.stringify(F.alarms));

/* ---------- G) Nur CO2-Kurve (Kapnogramm), kein Zahlenwert -> nichts erfinden ---------- */
console.log('\nG) CO2-Kurve ohne Zahl → kein EtCO2 erfunden, Kurve getrennt gezaehlt:');
const G = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100600||ORU^R01|7|P|2.3.1',
  'OBX||NM|151700^MDC_CONC_AWAY_CO2||3.4^3.6^3.9^4.2^4.6^5.1|mmHg',
  'OBX||NM|0^MDC_ATTR_SAMP_RATE||40|Hz',
]), {});
ok(G.vitals.etco2 == null, 'kein EtCO2 aus der Kurve erfunden', G.vitals.etco2);
ok((G.kurvenDaten || []).length >= 1, 'CO2-Kapnogramm als echte Kurve erkannt', (G.kurvenDaten || []).length);

/* ---------- H) Rueckatmung: FiCO2 hoch -> capnoShape "baseline" (Verbindung CO2 -> Kapno-Form) ---------- */
console.log('\nH) Rueckatmung: hoher FiCO2 setzt Kapno-Form "baseline" (Atemkalk erschoepft):');
const H = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100700||ORU^R01|8|P|2.3.1',
  'PID|||A-9||Rex^||20190101|M',
  'OBX||NM|250^CO2Et||48|mmHg|||||F',
  'OBX||NM|221^FiCO2||8|mmHg|||||F',
]), {});
const Hn = normalizeFrame(H).frame;
ok(Hn.vitals.etco2 === 48, 'EtCO2 48 kommt in die normalisierten Vitals', Hn.vitals.etco2);
ok(Hn.vitals.capnoShape === 'baseline', 'FiCO2 8 > 5 → Kapno-Form "baseline" (Rueckatmung erkannt)', Hn.vitals.capnoShape);

/* ---------- I) Ganzer Pfad: Temp + CO2 ueberleben normalize -> merge (wie in der App) ---------- */
console.log('\nI) Ganzer Pfad Parser → normalize → merge (Werte kommen in der App an):');
const norm = normalizeFrame(A).frame;
const pats = mergePatients([{ deviceId: 'umec12', model: 'uMEC12 Vet', role: 'combo', frame: norm }], {});
ok(pats.length === 1, 'ein Patient nach dem Matching', pats.length);
ok(pats[0].vitals.etco2 === 41, 'CO2 = 41 im fertigen Patienten', pats[0].vitals.etco2);
ok(pats[0].vitals.temp === 38.4, 'Temp = 38.4 im fertigen Patienten', pats[0].vitals.temp);
ok(pats[0].vitals.af === 12, 'Atemfrequenz = 12 im fertigen Patienten', pats[0].vitals.af);

/* ---------- J) Temp ausserhalb Plausibilitaet -> auf 46 °C begrenzt (Clamp in model.js) ---------- */
console.log('\nJ) Unplausible Temp → auf plausiblen Maximalwert begrenzt (Clamp 5–46 °C):');
const J = parseHL7Message(msg([
  'MSH|^~\\&|LifeVet||||20260724100800||ORU^R01|9|P|2.3.1',
  'OBX||NM|200^T1||200|C|||||F',
]), {});
const Jn = normalizeFrame(J).frame;
ok(Jn.vitals.temp === 46, 'Temp 200 °C → auf 46 begrenzt (zeigt nie 200; Marker 32767 wird separat verworfen)', Jn.vitals.temp);

console.log('\n== Ergebnis: ' + passes + ' OK, ' + fails + ' FAIL ==');
process.exit(fails ? 1 : 0);
