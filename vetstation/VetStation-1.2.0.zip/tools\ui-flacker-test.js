'use strict';
/*
 * ui-flacker-test.js — verhindert, dass die Oberflaeche je wieder flackert (Praxis-Befund 22.07.2026).
 *
 * WAS PASSIERT WAR:
 * In refresh() stand `grid.appendChild(w.wrap)`, um die Fenster nach Prioritaet zu sortieren.
 * Das VERSCHIEBT den Knoten im DOM — und ein verschobenes <iframe> verliert seinen
 * Browsing-Kontext und LAEDT KOMPLETT NEU. Weil refresh() an JEDER Patienten-Nachricht haengt
 * (Broadcast alle 500 ms), wurden alle Fenster zweimal pro Sekunde neu geladen. Der load-Handler
 * rief danach wieder refresh() auf -> Endlosschleife.
 *
 * Am Praxis-PC sah das so aus: die Station flackerte ununterbrochen, war nicht bedienbar, und die
 * Anaesthesie-App im Fenster kam nie so weit, ueberhaupt Werte auszuwerten. Der Tierarzt konnte
 * am narkotisierten Patienten NICHTS ablesen.
 *
 * Diese Pruefungen sind bewusst STATISCH (Quelltext), damit sie ohne Browser in `npm test` laufen.
 * Die tatsaechliche Bildschirmruhe wird zusaetzlich im Browser nachgemessen.
 *
 * Start: node tools/ui-flacker-test.js      (laeuft auch in `npm test`)
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }
function read(rel) { try { return fs.readFileSync(path.join(ROOT, rel), 'utf8').replace(/\r\n/g, '\n'); } catch (_) { return ''; } }

// Kommentare ausblenden: die Dateien BESCHREIBEN den alten Fehler ausfuehrlich und duerfen das auch.
function ohneKommentare(src) {
  return src.replace(/\/\*[\s\S]*?\*\//g, '').split('\n').filter((l) => !/^\s*\/\//.test(l)).join('\n');
}

console.log('VetStation — Oberflaeche flackert nicht (Praxis-Befund 22.07.2026)\n');

const src = read('ui/vetstation-live.js');
const code = ohneKommentare(src);
ok('ui/vetstation-live.js ist lesbar', src.length > 1000);

// --- 1) Der eigentliche Fehler: ein bereits eingehaengtes Fenster darf NIE verschoben werden ---
console.log('Fenster mit iframe werden nie im DOM verschoben:');
ok('kein grid.appendChild(w.wrap) mehr', !/grid\.appendChild\(\s*w\.wrap\s*\)/.test(code));
ok('kein insertBefore auf einem Fenster', !/insertBefore\(\s*w\.wrap/.test(code));
ok('kein prepend/append eines Fensters', !/grid\.(prepend|append)\(\s*w\.wrap/.test(code));
// Genau EIN appendChild auf das Raster ist erlaubt: das erste Einhaengen in ensureWindow().
const gridAppends = (code.match(/grid\.appendChild\(/g) || []).length;
ok('genau ein grid.appendChild (das erste Einhaengen in ensureWindow)', gridAppends === 1, gridAppends + ' gefunden');
const ensureIdx = code.indexOf('function ensureWindow');
const ensureEnde = code.indexOf('function removeWindow');
const ensureBlock = ensureIdx >= 0 && ensureEnde > ensureIdx ? code.slice(ensureIdx, ensureEnde) : '';
ok('dieses eine appendChild steht in ensureWindow', /grid\.appendChild\(/.test(ensureBlock));

// --- 2) Sortierung ueber CSS statt ueber den DOM ---
console.log('\nSortierung nach Prioritaet ohne DOM-Bewegung:');
ok('die Reihenfolge wird ueber die CSS-Eigenschaft "order" gesetzt', /\.wrap\.style\.order\s*=/.test(code));
ok('order wird nur bei echter Aenderung geschrieben', /style\.order\s*!==/.test(code));
const css = read('ui/vetstation-shell.css');
ok('#vsxGrid ist ein CSS-Grid (sonst wirkt "order" nicht)',
  /#vsxGrid\s*\{[^}]*display:\s*grid/.test(css));

// --- 3) Keine Rueckkopplung ueber den load-Handler ---
console.log('\nKeine Endlosschleife ueber das Nachladen:');
const loadIdx = code.indexOf("addEventListener('load'");
const loadBlock = loadIdx >= 0 ? code.slice(loadIdx, loadIdx + 700) : '';
ok('ein load-Handler existiert', loadIdx >= 0);
ok('der load-Handler ruft NICHT refresh() auf', !/setTimeout\(\s*refresh/.test(loadBlock) && !/[^a-zA-Z]refresh\(\)/.test(loadBlock),
  loadBlock.slice(0, 160));
ok('er fuehrt stattdessen nur DAS EINE Fenster nach', /drive\(\s*w\s*,/.test(loadBlock));
ok('und prueft vorher, ob das Fenster noch offen ist', /windows\[key\]\s*!==\s*w/.test(loadBlock));

// --- 4) Kein staendiges Neuschreiben von innerHTML im 500-ms-Takt ---
console.log('\nKein Neuaufbau von Markup bei jedem Takt:');
ok('die Fenster-Kopfzeile wird nur bei Aenderung neu geschrieben', /__headHtml\s*!==/.test(code));
ok('die Patientenleiste wird nur bei Aenderung neu geschrieben', /__sig\s*===|__sig\s*!==/.test(code));
ok('die Spaltenzahl wird nur bei Aenderung gesetzt', /__cols\s*!==/.test(code));

// --- 4b) Der Koppel-Dialog: er wird im selben Takt aufgerufen wie alles andere ---
// Wurde er dabei jedes Mal neu geschrieben, verlor der Anwender beim TIPPEN Feld und Fokus.
// Das war der Teil von "man kann gar nicht mit der App arbeiten", der nach dem iframe-Fix blieb.
console.log('\nDer Koppel-Dialog verliert keine Eingaben:');
ok('renderPairing wird aus refresh() aufgerufen (deshalb ist der Schutz noetig)',
  /if \(pairingOpen\) renderPairing\(\)/.test(code));
ok('er wird nur bei geaenderten GERAETEDATEN neu gebaut', /host\.__sig === sig/.test(code));
ok('die lokale Auswahl (Haekchen) loest KEINEN Neuaufbau aus', /Signatur kommt NUR aus den Ger/.test(src));
ok('waehrend des Tippens wird gar nicht neu gebaut',
  /document\.activeElement/.test(code) && /INPUT\|SELECT\|TEXTAREA/.test(code));

// --- 4c) Fenster duerfen nicht bei jedem Aussetzer zerstoert werden ---
console.log('\nFenster ueberleben kurze Datenluecken und Schluesselwechsel:');
ok('es gibt eine Schonfrist vor dem Schliessen', /GRACE_MS/.test(code));
ok('die Schonfrist ist spuerbar lang (>= 10 s)', /GRACE_MS\s*=\s*(1[0-9]|[2-9][0-9])\d{3}/.test(code));
ok('ein Fenster wird erst nach Ablauf der Frist entfernt', /__weg\s*>\s*GRACE_MS/.test(code));
ok('ein Patientenschluessel-Wechsel uebernimmt das vorhandene Fenster', /__devs\s*!==\s*dk/.test(code));
ok('die Geraete-Identitaet ist dafuer definiert', /function devKey/.test(code));

// --- 5) Der Takt selbst: die Bridge sendet weiterhin zuegig, das ist gewollt ---
console.log('\nTakt der Bridge (Ursache der Haeufigkeit):');
const server = read('bridge/src/server.js');
const takt = server.match(/BROADCAST_MS\s*=\s*(\d+)/);
ok('der Broadcast-Takt ist dokumentiert', !!takt, 'nicht gefunden');
if (takt) {
  const ms = Number(takt[1]);
  ok('Takt ist schnell genug fuer eine Live-Ueberwachung (<= 1 s)', ms <= 1000, ms + ' ms');
  console.log('    (Bei ' + ms + ' ms Takt haette der alte Code die Fenster ' +
    Math.round(2 * (1000 / ms)) / 2 + '× pro Sekunde neu geladen.)');
}

// --- 6) Ehrliche Anzeige: der Nutzer muss sehen, ob Werte ankommen ---
console.log('\nDer Nutzer sieht, was los ist:');
ok('es gibt eine Verbindungsanzeige', /setConn\(/.test(code));
ok('ohne Geraete steht ein Hinweis statt eines leeren Bildschirms', /warte auf Ger/.test(src));

console.log('\n' + (fail === 0 ? 'ALLE ' + pass + ' PRUEFUNGEN BESTANDEN' : fail + ' von ' + (pass + fail) + ' FEHLGESCHLAGEN'));
process.exit(fail === 0 ? 0 : 1);
