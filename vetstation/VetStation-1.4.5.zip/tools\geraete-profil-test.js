'use strict';
/*
 * geraete-profil-test.js — DAS UNIVERSELLE VIRTUELLE GERAET.
 *
 * Geprueft wird nicht "laeuft es durch", sondern die Fehler, die dieses Bild WIRKLICH gefaehrlich
 * machen wuerden. Jeder Block unten steht fuer einen Fehler, der schon einmal passiert ist oder der
 * im Browser voellig normal aussieht:
 *
 *   1  Ein Kanal im Profil, den es nicht gibt      -> leere Kachel, faellt niemandem auf
 *   2  Ein Kanal, den das ECHTE Geraet nicht hat   -> vorgetaeuschte Messung (LifeVet M ohne CO2)
 *   3  Toter Verweis in den Geraetekatalog         -> "Wie schliesse ich es an?" fuehrt ins Leere
 *   4  Reihenfolge haengt an der Auswahlreihenfolge-> das Bild sortiert sich beim Modellwechsel um
 *   5  Modellerkennung RAET                        -> blendet Kanaele aus, die das Geraet hat
 *   6  MAC des falschen Gases                      -> 2 Vol% sind Iso-Erhaltung und Des-Viertel-MAC
 *   7  Gerechnet aus unvollstaendigen Eingaben     -> erfundene Messung
 *   8  Normband haengt nicht am Gewicht            -> Vt-Alarm fuer das falsche Tier
 *   9  Die Bridge reicht die Kanaele nicht durch   -> fern unsichtbar, ohne eine einzige Logzeile
 *  10  Bestehende Zuordnung still veraendert       -> LifeVet/uMEC verlieren einen Wert
 *  11  Kurvenformel kaputt                         -> gezeichnete Linie, die nichts mehr aussagt
 *  12  App und Web-App laufen auseinander          -> fern ein anderes Bild als am Praxis-PC
 *
 * Start:  node tools/geraete-profil-test.js
 */
const fs = require('fs');
const path = require('path');

const WURZEL = path.join(__dirname, '..');
const VG = require(path.join(WURZEL, 'ui/shared/geraete-profile.js'));
const katalog = require(path.join(WURZEL, 'bridge/src/geraetekatalog.js'));
const model = require(path.join(WURZEL, 'bridge/src/model.js'));
const matching = require(path.join(WURZEL, 'bridge/src/matching.js'));

let ok = 0, fail = 0;
function pruef(name, bedingung, zusatz) {
  if (bedingung) { ok++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (zusatz ? '  -> ' + zusatz : '')); }
}
function abschnitt(t) { console.log('\n' + t); }

/* ================================================================= 1 */
abschnitt('1) Selbstpruefung des Moduls (Daten in sich stimmig)');
const fehler = VG.pruefe();
pruef('pruefe() meldet nichts', fehler.length === 0, fehler.join(' | '));
pruef('mindestens 20 Profile', VG.PROFILE.length >= 20, 'nur ' + VG.PROFILE.length);
pruef('Monitor- UND Narkoseauswahl nicht leer', VG.alle('monitor').length > 3 && VG.alle('narkose').length > 3);
pruef('jedes Profil ist ueber nachId erreichbar', VG.PROFILE.every((p) => VG.nachId(p.id) === p));

/* ================================================================= 2 */
abschnitt('2) Was ein Geraet NICHT kann, darf nicht im Bild stehen');
const lifevetM = VG.nachId('eickemeyer-lifevet-m');
pruef('LifeVet M hat KEIN EtCO2 (kein CO2-Modul verbaut, Foto 31.07.2026)', lifevetM.kanaele.indexOf('etco2') < 0);
pruef('LifeVet M hat auch keine Kapno-Kurve', lifevetM.kurven.indexOf('capno') < 0);
const veta5 = VG.nachId('mindray-veta-5-plus');
['etco2', 'fico2', 'ppeak', 'peep', 'vte', 'mv', 'rr'].forEach((k) => {
  pruef('Veta 5 Plus zeigt ' + k + ' (steht so auf dem Bildschirm)', veta5.kanaele.indexOf(k) >= 0);
});
pruef('Veta 5 Plus hat die Paw-Kurve', veta5.kurven.indexOf('paw') >= 0);
pruef('Veta 5 Plus beschriftet Ppeak als "MAX" (wie auf dem Foto)', VG.abbrFuer(VG.zusammen(null, veta5), 'ppeak') === 'MAX');
pruef('Veta 5 Plus kennt Falluhr und Insp. Hold', veta5.fallTimer === true && veta5.inspHold === true);
pruef('Veta 5 Plus hat KEIN Gasmodul (kein EtAA)', veta5.kanaele.indexOf('etAgent') < 0);
const mech = VG.nachId('mechanisch-vet-narkose');
pruef('rein mechanisches Narkosegeraet misst GAR NICHTS', mech.kanaele.length === 0 && mech.kurven.length === 0);
pruef('... hat aber trotzdem Handbeatmung', mech.ventModi.indexOf('manual') >= 0);
const kapno = VG.nachId('kapnograf-standalone');
pruef('eigenstaendiger Kapnograf ist KEIN Ventilator', kapno.ventModi.length === 0);
pruef('... steht trotzdem in der Narkose-Auswahl', VG.alle('narkose').some((p) => p.id === 'kapnograf-standalone'));

/* ================================================================= 3 */
abschnitt('3) Verweise in den Geraetekatalog sind lebendig');
VG.PROFILE.filter((p) => p.katalogId).forEach((p) => {
  pruef('katalogId "' + p.katalogId + '" (' + p.id + ') existiert', !!katalog.nachId(p.katalogId));
});
pruef('nachKatalogId findet das Veta-5-Profil', (VG.nachKatalogId('mindray-veta-5', 'narkose') || {}).id === 'mindray-veta-5-plus');

/* ================================================================= 4 */
abschnitt('4) Das Bild sortiert sich nicht um');
const a = VG.zusammen(VG.nachId('mindray-umec12-vet'), VG.nachId('mindray-veta-5-plus'));
const b = VG.zusammen(VG.nachId('mindray-umec12-vet'), VG.nachId('mindray-veta-5-plus'));
pruef('gleiche Wahl -> gleiche Reihenfolge', a.kanaele.join() === b.kanaele.join());
const rang = { kreislauf: 1, atmung: 2, beatmung: 3, gas: 4, temperatur: 5 };
let letzter = 0, sortiert = true;
a.kanaele.forEach((id) => { const r = rang[VG.kanal(id).art]; if (r < letzter) sortiert = false; letzter = r; });
pruef('Kreislauf -> Atmung -> Beatmung -> Gas -> Temperatur', sortiert, a.kanaele.join());
pruef('EtCO2 steht direkt vor FiCO2', a.kanaele.indexOf('fico2') === a.kanaele.indexOf('etco2') + 1);
const reihe = ['ekg', 'pleth', 'capno', 'paw', 'flow', 'resp'];
let kl = -1, kSort = true;
a.kurven.forEach((id) => { const i = reihe.indexOf(id); if (i < kl) kSort = false; kl = i; });
pruef('Kurvenbahnen: Herz oben, Druck unten', kSort, a.kurven.join());
pruef('kein Kanal doppelt', new Set(a.kanaele).size === a.kanaele.length);
const uni = VG.zusammen(VG.standard('monitor'), VG.standard('narkose'));
pruef('Universalgeraet zeigt JEDEN Kanal des Katalogs', uni.kanaele.length === VG.KANAELE.filter((k) => k.id !== 'o2flow' && k.id !== 'ie').length,
  uni.kanaele.length + ' von ' + VG.KANAELE.length);
pruef('Universalgeraet zeigt jede Kurvenbahn', uni.kurven.length === VG.KURVEN.length);

/* ================================================================= 5 */
abschnitt('5) Modellerkennung schlaegt vor, raet aber nie');
[['Mindray Veta 5 Plus', 'narkose', 'mindray-veta-5-plus'],
 ['uMEC12 Vet', 'monitor', 'mindray-umec12-vet'],
 ['Eickemeyer LifeVet 10C', 'monitor', 'eickemeyer-lifevet-10c'],
 ['LifeVet M', 'monitor', 'eickemeyer-lifevet-m'],
 ['WATO EX-35Vet', 'narkose', 'mindray-wato-ex35-vet'],
 ['Draeger Fabius', 'narkose', 'draeger-narkose'],
 ['BIONET BM5Vet', 'monitor', 'bionet-bm-vet'],
].forEach(([txt, rolle, erwartet]) => {
  const t = VG.erkenne(txt, rolle);
  pruef('erkenne("' + txt + '") = ' + erwartet, t && t.id === erwartet, t ? t.id : 'nichts');
});
['Blubb 3000', 'Monitor', 'X', ''].forEach((txt) => {
  pruef('erkenne("' + txt + '") raet NICHT', VG.erkenne(txt, 'monitor') === null,
    (VG.erkenne(txt, 'monitor') || {}).id);
});
/* Das LifeVet 10C darf NICHT auf das LifeVet M treffen und umgekehrt — beide heissen "LifeVet",
 * aber das eine hat ein CO2-Modul und das andere nicht. Eine Verwechslung blendet den Kapnografen
 * aus oder taeuscht einen vor. */
pruef('"LifeVet 10C" trifft nicht das LifeVet M', VG.erkenne('LifeVet 10C', 'monitor').id === 'eickemeyer-lifevet-10c');
pruef('"LifeVet M" trifft nicht das 10C', VG.erkenne('LifeVet M', 'monitor').id === 'eickemeyer-lifevet-m');

/* ================================================================= 6 */
abschnitt('6) MAC gehoert zum GAS und zur TIERART');
const spHund = { iso: { mac: 1.3 }, tvMlKg: [10, 15], rr: [8, 12], pip: 15 };
pruef('Iso-MAC kommt aus der gepflegten Artangabe', VG.macFuer('iso', 'hund', spHund) === 1.3);
const sevo = VG.macInfo('sevo', 'hund', spHund);
pruef('Sevofluran Hund 2,36 (publiziert, nicht abgeleitet)', sevo.wert === 2.36 && sevo.abgeleitet === false);
const sevoDegu = VG.macInfo('sevo', 'degu', { iso: { mac: 1.4 } });
pruef('Sevofluran Degu ist ABGELEITET und wird so gekennzeichnet', sevoDegu.abgeleitet === true);
pruef('... und liegt deutlich ueber dem Iso-MAC', sevoDegu.wert > 2);
pruef('Desfluran-Skala geht bis 18, Iso nur bis 6', VG.gas('des').max === 18 && VG.gas('iso').max === 6);
pruef('jedes Gas nennt seine Quelle', VG.GASE.every((g) => !!g.quelle));
pruef('unbekanntes Gas faellt auf Isofluran zurueck statt zu raten', VG.macFuer('xyz', 'hund', spHund) === 1.3);

/* ================================================================= 7 */
abschnitt('7) Gerechnet wird nur mit vollstaendigen Eingaben');
const ctx = { sp: 'hund', wt: 10, spSet: spHund, gas: 'iso', ie: '1:2' };
const d1 = VG.ableiten({ vte: 100, rr: 12, ppeak: 12, peep: 3, etAgent: 1.3 }, ctx);
pruef('MV = Vt x AF', d1.mv === 1.2, String(d1.mv));
pruef('Compliance = Vt / (Ppeak - PEEP)', Math.abs(d1.compl - 100 / 9) < 0.1, String(d1.compl));
pruef('Pmean aus I:E 1:2 = PEEP + (Ppeak-PEEP)/3', Math.abs(d1.pmean - 6) < 0.1, String(d1.pmean));
pruef('MAC = EtAA / MAC der Art', d1.mac === 1, String(d1.mac));
const d2 = VG.ableiten({ vte: 100 }, ctx);
pruef('ohne AF KEIN Minutenvolumen', d2.mv === undefined);
pruef('ohne Druecke KEINE Compliance', d2.compl === undefined && d2.pmean === undefined);
const d3 = VG.ableiten({ vte: 100, rr: 12, ppeak: 5, peep: 5 }, ctx);
pruef('Ppeak == PEEP -> keine Division durch Null', d3.compl === undefined);
const d4 = VG.ableiten({ etAgent: 2.4 }, { sp: 'hund', spSet: spHund, gas: 'sevo' });
pruef('MAC rechnet mit dem GEWAEHLTEN Gas (Sevo, nicht Iso)', Math.abs(d4.mac - 2.4 / 2.36) < 0.02, String(d4.mac));
const d5 = VG.ableiten({ ppeak: 12, peep: 3 }, { sp: 'hund', spSet: spHund, ie: '1:4' });
pruef('laengere Exspiration -> niedrigerer Mitteldruck', d5.pmean < d1.pmean, d5.pmean + ' vs ' + d1.pmean);

/* ================================================================= 8 */
abschnitt('8) Normbaender haengen am Patienten, nicht an einer festen Zahl');
const vitHund = { hr: [60, 140], rr: [8, 20], spo2: [95, 100], etco2: [30, 55], map: [70, 120], temp: [37.5, 39.2] };
const b10 = VG.bandFuer('vte', { sp: 'hund', wt: 10, spSet: spHund, vitals: vitHund });
const b40 = VG.bandFuer('vte', { sp: 'hund', wt: 40, spSet: spHund, vitals: vitHund });
pruef('Vt-Band skaliert mit dem Gewicht', b40[0] === b10[0] * 4 && b40[1] === b10[1] * 4, JSON.stringify([b10, b40]));
pruef('Vt-Band beginnt bei 8 ml/kg (lungenschonend)', b10[0] === 80, JSON.stringify(b10));
pruef('MV-Band = Vt-Band x AF-Band (dieselben Zahlen wie die Nachbarkacheln)',
  Math.abs(VG.bandFuer('mv', { sp: 'hund', wt: 10, spSet: spHund, vitals: vitHund })[1] - b10[1] * vitHund.rr[1] / 1000) < 0.01,
  JSON.stringify(VG.bandFuer('mv', { sp: 'hund', wt: 10, spSet: spHund, vitals: vitHund })));
pruef('HF-Band kommt aus der Tierart-Tabelle', JSON.stringify(VG.bandFuer('hr', { sp: 'hund', vitals: vitHund })) === '[60,140]');
pruef('FiCO2-Band ist eng (Rueckatmung ab ~3 mmHg)', VG.bandFuer('fico2', {})[1] <= 3);
pruef('Ppeak-Band endet beim art-/gewichtsgerechten Grenzdruck', VG.bandFuer('ppeak', { spSet: spHund })[1] === 15);
pruef('Kanal ohne Band liefert null statt einer erfundenen Norm', VG.bandFuer('fiAgent', {}) === null);

/* ================================================================= 9 */
abschnitt('9) Die Bridge reicht die neuen Kanaele durch');
const NEU = ['ppeak', 'pmean', 'peep', 'vte', 'mv', 'compl', 'fio2', 'etAgent', 'fiAgent', 'mac', 'etn2o', 'pi', 'temp2', 'ibp'];
const leer = model.emptyVitals();
NEU.forEach((k) => pruef('emptyVitals kennt ' + k, k in leer));
const norm = model.normalizeFrame({
  deviceId: 'x', deviceRole: 'anesthesia', species: 'hund', weightKg: 10,
  vitals: { etco2: 45, fico2: 8, ppeak: 12, peep: 3, vte: 100, mv: 1.2, fio2: 95, etAgent: 1.3, pi: 4, temp2: 37.5, ibp: 80 },
});
NEU.filter((k) => ['pmean', 'compl', 'mac', 'fiAgent', 'etn2o'].indexOf(k) < 0)
  .forEach((k) => pruef('normalizeFrame traegt ' + k + ' ein', norm.frame.vitals[k] != null, String(norm.frame.vitals[k])));
pruef('FiCO2 > 5 setzt weiterhin capnoShape = baseline (Rueckatmung)', norm.frame.vitals.capnoShape === 'baseline');
const mull = model.normalizeFrame({ deviceId: 'x', vitals: { ppeak: 32767, vte: -5, fio2: 400 } });
pruef('Mindrays 32767 wird NICHT als Spitzendruck uebernommen', mull.frame.vitals.ppeak === null);
pruef('negatives Volumen wird verworfen', mull.frame.vitals.vte === null);
pruef('FiO2 400 % wird verworfen', mull.frame.vitals.fio2 === null);
pruef('... und jede Verwerfung wird GEMELDET, nicht verschwiegen', mull.warnings.length >= 3, JSON.stringify(mull.warnings));

// Zusammenfuehren: das beatmende Geraet gewinnt bei den Beatmungswerten.
const zus = matching.mergePatients([
  { deviceId: 'MON', frame: model.normalizeFrame({ deviceId: 'MON', deviceRole: 'monitor', patientId: '1', species: 'hund', weightKg: 10, ts: 2, vitals: { hr: 90, ppeak: 99, vte: 999 } }).frame },
  { deviceId: 'NARK', frame: model.normalizeFrame({ deviceId: 'NARK', deviceRole: 'anesthesia', patientId: '1', species: 'hund', weightKg: 10, ts: 1, vitals: { ppeak: 12, vte: 100, etco2: 44 } }).frame },
], {});
pruef('bei zwei Quellen liefert das NARKOSEGERAET den Spitzendruck', zus[0].vitals.ppeak === 12, String(zus[0].vitals.ppeak));
pruef('... und das gemessene Atemzugvolumen', zus[0].vitals.vte === 100, String(zus[0].vitals.vte));
pruef('... der Monitor bleibt fuer die Herzfrequenz zustaendig', zus[0].vitals.hr === 90);
pruef('MERGE_FELDER ist EINE Liste (kein zweiter Ort zum Vergessen)', matching.MERGE_FELDER.length >= 20 && NEU.every((k) => matching.MERGE_FELDER.indexOf(k) >= 0));

/* ================================================================= 9b */
abschnitt('9b) Die Datenbankregel nimmt JEDEN neuen Kanal an (1.4.2)');
/*
 * WARUM DAS HIER GEPRUEFT WIRD UND NICHT NUR IN DER KONSOLE NACHGESEHEN:
 * cloud.js schaltet die Fern-Uebertragung nach DREI abgewiesenen Schreibvorgaengen dauerhaft ab.
 * Der Saal saehe fern weiter „live" aus — mit eingefrorenen Zahlen. Ein neuer Messkanal, den die
 * Regel nicht kennt, ist damit kein Schoenheitsfehler, sondern ein stiller Totalausfall der
 * Fern-Ansicht. Deshalb wird die ECHTE Regel (aus installer/firebase-rtdb-rules.json) gegen ein
 * ECHTES Wertepaket (aus cloud.js:_buildSnapshot) gerechnet — bei jedem Testlauf, nicht einmalig.
 */
{
  const regelDatei = fs.readFileSync(path.join(WURZEL, 'installer/firebase-rtdb-rules.json'), 'utf8');
  const ohneKommentar = regelDatei.replace(/^\s*\/\/.*$/gm, '');
  const mVit = /"vitals"\s*:\s*\{[^}]*?"\$feld"\s*:\s*\{\s*"\.validate"\s*:\s*"([^"]+)"/s.exec(ohneKommentar);
  pruef('die vitals-Regel ist auffindbar', !!mVit);
  if (mVit) {
    const ausdruck = mVit[1];
    pruef('sie benutzt einen PLATZHALTER ($feld), keine Namensliste', /\$feld/.test(ohneKommentar.slice(ohneKommentar.indexOf('"vitals"'), ohneKommentar.indexOf('"vitals"') + 400)));
    // Die Regelsprache nachbilden, so weit dieser eine Ausdruck sie braucht.
    const bewerte = (wert) => {
      const newData = {
        isString: () => typeof wert === 'string',
        isNumber: () => typeof wert === 'number' && Number.isFinite(wert),
        isBoolean: () => typeof wert === 'boolean',
        val: () => wert,
      };
      return new Function('newData', 'return (' + ausdruck + ');')(newData);
    };
    const { CloudPublisher } = require(path.join(WURZEL, 'bridge/src/cloud.js'));
    const f = model.normalizeFrame({
      deviceId: 'NARK', deviceModel: 'Beatmung', deviceRole: 'anesthesia', patientId: '7',
      species: 'katze', weightKg: 4.3, ts: Date.now(),
      vitals: { hr: 150, spo2: 97, etco2: 75, fico2: 8, af: 16, temp: 37.9, temp2: 36.4, pi: 3,
        ppeak: 7, pmean: 4.3, peep: 3, vte: 36, mv: 0.58, compl: 9, fio2: 95, etAgent: 1.4,
        fiAgent: 1.6, mac: 1.08, etn2o: 0, ibp: 68, nibp: { sys: 113, dia: 44 } },
      isoPct: 1.8, o2Flow: 1, ventMode: 'VCV', ventParams: { vt: 40, af: 14, ie: '1:2', peep: 3 },
    }).frame;
    const pats = matching.mergePatients([{ deviceId: 'NARK', frame: f }], {});
    const cp = new CloudPublisher({ dbUrl: 'https://x.example.com', authFile: null });
    const snap = cp._buildSnapshot(pats, [], {});
    const vit = snap.patients[Object.keys(snap.patients)[0]].vitals;
    const felder = Object.keys(vit);
    pruef('das Fern-Paket traegt alle Kanaele (>= 25 Felder)', felder.length >= 25, String(felder.length));
    NEU.forEach((k) => pruef('Regel nimmt "' + k + '" an', vit[k] === null || bewerte(vit[k]) === true, JSON.stringify(vit[k])));
    const abgewiesen = felder.filter((k) => vit[k] !== null && bewerte(vit[k]) !== true);
    pruef('KEIN einziges Feld des echten Pakets wird abgewiesen', abgewiesen.length === 0, abgewiesen.join());
    /* Gegenprobe: die Regel ist nicht einfach immer wahr — sonst waere der Test wertlos. */
    pruef('ein Objekt WIRD abgewiesen (die Regel ist scharf)', bewerte({ a: 1 }) !== true);
    pruef('ein ueberlanger Text WIRD abgewiesen', bewerte('x'.repeat(2001)) !== true);
    pruef('eine Zahl wird angenommen', bewerte(42) === true);
  }
}

/* ================================================================= 10 */
abschnitt('10) Bestehendes bleibt unveraendert (LifeVet / uMEC12)');
const hl7src = fs.readFileSync(path.join(WURZEL, 'bridge/src/adapters/hl7.js'), 'utf8');
[["'101': 'hr'", 'HF 101'], ["'160': 'spo2'", 'SpO2 160'], ["'170': 'sys'", 'NIBP 170'],
 ["'220': 'etco2'", 'EtCO2 220'], ["'221': 'fico2'", 'FiCO2 221'], ["'200': 'temp'", 'T1 200'],
].forEach(([s, n]) => pruef('CODE_MAP unveraendert: ' + n, hl7src.indexOf(s) >= 0));
pruef('t2 zeigt WEITERHIN auf temp (nicht auf temp2)', /t1: 'temp', t2: 'temp'/.test(hl7src));
pruef('temp2 gibt es trotzdem als eigenes Label', /temp2: 'temp2'/.test(hl7src));
['ppeak', 'peep', 'vte', 'mv', 'fio2', 'etAgent', 'fiAgent', 'mac', 'pi'].forEach((k) => {
  pruef('LABEL_MAP kennt ' + k, new RegExp("[: ]'" + k + "'").test(hl7src));
});
pruef('MDC-Bezeichner fuer den Atemwegsdruck eingetragen', hl7src.indexOf('mdc_press_away_insp_max') >= 0);
pruef('cmH2O wird gegen mbar und kPa geprueft', hl7src.indexOf("soll === 'cmH2O'") >= 0 && hl7src.indexOf('10.197') >= 0);
pruef('Liter werden in ml umgerechnet', hl7src.indexOf("soll === 'ml'") >= 0);
/* Der Kern der Zusage "LifeVet und uMEC nicht stoeren": es wurde KEIN privater Zahlencode
 * fuer die neuen Kanaele erfunden. Zahlen sind belegt, Bezeichner sind selbstbeschreibend. */
const codeMapBlock = hl7src.slice(hl7src.indexOf('const CODE_MAP'), hl7src.indexOf('// Label-Fallback'));
pruef('KEIN geratener Zahlencode fuer die neuen Kanaele', !/ppeak|peep|'vte'|etAgent|fio2/.test(codeMapBlock));

/* ================================================================= 11 */
abschnitt('11) Die Kurvenformeln rechnen wirklich (nicht nur vorhanden)');
const appHtml = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
function holeFunktion(name) {
  const i = appHtml.indexOf('function ' + name + '(');
  if (i < 0) return null;
  let tiefe = 0, gestartet = false;
  for (let j = i; j < appHtml.length; j++) {
    const c = appHtml[j];
    if (c === '{') { tiefe++; gestartet = true; }
    else if (c === '}') { tiefe--; if (gestartet && tiefe === 0) return appHtml.slice(i, j + 1); }
  }
  return null;
}
const srcCapno = holeFunktion('wCapno');
pruef('wCapno ist auffindbar', !!srcCapno);
if (srcCapno) {
  const wCapno = new Function('return ' + srcCapno)();
  const grund0 = wCapno(0.1, 'normal', 40, 0);
  const grund8 = wCapno(0.1, 'normal', 40, 8);
  pruef('FiCO2 8 hebt die Kapno-GRUNDLINIE an (das Bild vom Foto)', grund8 > grund0 + 0.05, grund0 + ' -> ' + grund8);
  pruef('FiCO2 0 -> Grundlinie auf der Nulllinie', Math.abs(grund0 - 0.12) < 0.001);
  const plateau40 = wCapno(0.6, 'normal', 40, 0), plateau75 = wCapno(0.6, 'normal', 75, 0);
  pruef('hoeheres EtCO2 -> hoeheres Plateau', plateau75 > plateau40);
  pruef('Plateau ist flach (Ende = Mitte)', Math.abs(wCapno(0.5, 'normal', 40, 0) - wCapno(0.9, 'normal', 40, 0)) < 0.001);
  pruef('Haifischflosse hat KEIN flaches Plateau', wCapno(0.9, 'shark', 40, 0) > wCapno(0.5, 'shark', 40, 0) + 0.05);
  pruef('flache Kurve bleibt flach', wCapno(0.1, 'flat', 40, 0) === wCapno(0.9, 'flat', 40, 0));
  pruef('Kurve bleibt in der Bahn (0..1)', [0, 0.3, 0.5, 0.95].every((p) => {
    const y = wCapno(p, 'normal', 75, 10); return y >= 0 && y <= 1;
  }));
}
const srcPaw = holeFunktion('wPaw');
pruef('wPaw ist auffindbar', !!srcPaw);
if (srcPaw) {
  const stubs = { ventVal: (k) => ({ peep: 3, ie: '1:2', pinsp: 10 }[k]), vnum: (v) => (typeof v === 'number' ? v : parseFloat(String(v)) || null) };
  function pawFuer(modus, r) {
    const state = { dev: { mode: modus } }, mon = { beatN: 0 };
    const f = new Function('state', 'mon', 'ventVal', 'vnum', 'return ' + srcPaw)(state, mon, stubs.ventVal, stubs.vnum);
    return (ph) => f(ph, r);
  }
  const rV = { peep: 3, ppeak: 12 };
  const vcv = pawFuer('vcv', rV), pcv = pawFuer('pcv', rV);
  pruef('VCV: Druck steigt als RAMPE (Mitte < Ende der Inspiration)', vcv(0.15) < vcv(0.3), vcv(0.15) + ' / ' + vcv(0.3));
  pruef('PCV: Druck steht als RECHTECK', Math.abs(pcv(0.15) - pcv(0.3)) < 0.01, pcv(0.15) + ' / ' + pcv(0.3));
  pruef('Exspiration faellt auf PEEP zurueck', vcv(0.8) < vcv(0.3));
  pruef('hoeherer Spitzendruck -> hoeherer Ausschlag', pawFuer('pcv', { peep: 3, ppeak: 20 })(0.2) > pcv(0.2));
  pruef('PEEP hebt die Grundlinie', pawFuer('pcv', { peep: 8, ppeak: 20 })(0.8) > pcv(0.8));
  pruef('Spontanmodus zeigt den Sog VOR dem Hub', pawFuer('psv', rV)(0.01) < pawFuer('psv', rV)(0.3));
  pruef('Kurve bleibt in der Bahn (0..1)', [0, 0.2, 0.5, 0.9].every((p) => { const y = vcv(p); return y >= 0 && y <= 1; }));
}
const srcFlow = holeFunktion('wFlow');
if (srcFlow) {
  const f = new Function('state', 'ventVal', 'return ' + srcFlow)({ dev: { mode: 'vcv' } }, (k) => ({ ie: '1:2' }[k]));
  pruef('Flow: Einatmung positiv, Ausatmung negativ', f(0.1, {}) > 0.5 && f(0.5, {}) < 0.5);
  pruef('Obstruktion: Ausatemfluss erreicht die Null NICHT (Air-Trapping)',
    Math.abs(f(0.95, { capno: 'shark' }) - 0.5) > Math.abs(f(0.95, { capno: 'normal' }) - 0.5));
}

/* ================================================================= 12 */
abschnitt('12) App und Fern-Web-App zeigen dasselbe');
const webWurzel = path.join(WURZEL, '..', '..', 'canis-vetpharm');
const webApp = path.join(webWurzel, 'canis-anaesthesie/index.html');
const webModul = path.join(webWurzel, 'shared/geraete-profile.js');
if (!fs.existsSync(webApp)) {
  console.log('  (uebersprungen: die Web-App liegt nicht neben diesem Ordner)');
} else {
  const web = fs.readFileSync(webApp, 'utf8');
  ['__setMesswerte', '__setGeraetProfil', 'geraete-profile.js', 'renderDevHead', 'wPaw', 'istNachziehen', 'grenzeOf']
    .forEach((s) => pruef('Web-App enthaelt ' + s, web.indexOf(s) >= 0));
  pruef('Web-App behaelt den Fern-Seam (applyLive)', web.indexOf('function applyLive(') >= 0);
  pruef('Web-App behaelt den Saalwechsel (neuerPatient)', web.indexOf('function neuerPatient(') >= 0);
  pruef('Fern-Seam speist die neuen Messwerte ein', /__setMesswerte\(mw\)/.test(web));
  /*
   * DER WICHTIGSTE PUNKT DIESES ABSCHNITTS.
   * Eine Kopie neben dem Original ist eine Zeitbombe mit Zufallszuender: bridge/src/anaes.js zog
   * jahrelang eine ANDERE anaes-data.js als der Browser, und es fiel erst auf, als vier neue
   * Tierarten in der einen Datei standen und die andere sie nicht sah. Diese Pruefung erzwingt,
   * dass die Fern-Web-App exakt dieselbe Geraetebeschreibung benutzt wie die Station.
   */
  const quellModul = fs.readFileSync(path.join(WURZEL, 'ui/shared/geraete-profile.js'), 'utf8');
  pruef('Web-App hat das Geraeteprofil-Modul', fs.existsSync(webModul));
  if (fs.existsSync(webModul)) {
    pruef('... und es ist ZEICHENGLEICH mit der Quelle', fs.readFileSync(webModul, 'utf8') === quellModul,
      'Kopie weicht ab -> Station und Fern-Ansicht zeigen verschiedene Geraete');
  }
  const quellDaten = fs.readFileSync(path.join(WURZEL, 'ui/app/anaes-data.js'), 'utf8');
  pruef('anaes-data.js ist zeichengleich', fs.readFileSync(path.join(webWurzel, 'canis-anaesthesie/anaes-data.js'), 'utf8') === quellDaten);
}

/* App-Verdrahtung: der Spiegel muss AUFRUFBAR sein, nicht nur vorhanden.
 * (Der Veta-5-Spiegel war einmal vollstaendig da und trotzdem tot, weil state/render nicht auf
 *  window lagen — seitdem wird das ausdruecklich geprueft.) */
abschnitt('12b) Die Bruecken zur Station sind nach aussen sichtbar');
['window.__setMesswerte=', 'window.__setGeraetProfil=', 'window.curGeraet=', 'window.state=']
  .forEach((s) => pruef('index.html legt ' + s.replace('window.', '').replace('=', '') + ' auf window', appHtml.indexOf(s) >= 0));
const liveJs = fs.readFileSync(path.join(WURZEL, 'ui/vetstation-live.js'), 'utf8');
pruef('vetstation-live.js speist die Messwerte ein', liveJs.indexOf('__setMesswerte') >= 0);
pruef('vetstation-live.js meldet das erkannte Modell', liveJs.indexOf('__setGeraetProfil') >= 0);
pruef('vetstation-live.js ordnet auch Paw-/Flow-Kurven einer Bahn zu', /press_away\|paw/.test(liveJs));
pruef('index.html laedt das Profilmodul', appHtml.indexOf('shared/geraete-profile.js') >= 0);

/* ================================================================= 13 */
abschnitt('13) Cockpit: eine Kurve nur, wo sie etwas aussagt (1.4.1)');
/*
 * aktiveBahnen() liegt in index.html und braucht curGeraet(). Statt die Funktion nachzubauen
 * (dann prueft der Test seine eigene Kopie), wird sie hier mit einem Stub-curGeraet aus der
 * Datei geholt und gerechnet — dieselbe Bauart wie Block 11.
 */
const srcBahnen = holeFunktion('aktiveBahnen');
pruef('aktiveBahnen ist auffindbar', !!srcBahnen);
if (srcBahnen) {
  const bahnenFuer = (mon, nark) => {
    const g = VG.zusammen(VG.nachId(mon), nark ? VG.nachId(nark) : null);
    return new Function('curGeraet', 'return ' + srcBahnen)(() => g)();
  };
  const veta = bahnenFuer('mindray-umec12-vet', 'mindray-veta-5-plus');
  pruef('uMEC12 + Veta 5: EKG, Pleth, CO2, Paw', veta.join() === 'ekg,pleth,capno,paw', veta.join());
  pruef('... KEINE Impedanz-Atemkurve neben dem Kapnogramm', veta.indexOf('resp') < 0);
  const lvm = bahnenFuer('eickemeyer-lifevet-m', null);
  pruef('LifeVet M (kein CO2-Modul): keine Kapno-Bahn', lvm.indexOf('capno') < 0, lvm.join());
  pruef('... dafuer die Impedanz-Atemkurve (einzige Atemquelle)', lvm.indexOf('resp') >= 0, lvm.join());
  const pm = bahnenFuer('petmap', null);
  pruef('petMAP (nur Blutdruck): GAR KEINE Kurve statt einer leeren schwarzen Flaeche', pm.length === 0, pm.join());
  const mech = bahnenFuer('mindray-umec12-vet', 'mechanisch-vet-narkose');
  pruef('rein mechanisches Narkosegeraet fuegt keine Druckkurve hinzu', mech.indexOf('paw') < 0, mech.join());
  const kap = bahnenFuer('mindray-umec12-vet', 'kapnograf-standalone');
  pruef('eigenstaendiger Kapnograf bringt keine Paw-Bahn mit', kap.indexOf('paw') < 0, kap.join());
}
const srcTitel = holeFunktion('geraetTitel');
pruef('geraetTitel ist auffindbar', !!srcTitel);
if (srcTitel) {
  const titelFuer = (mon, nark, slot) => {
    const g = VG.zusammen(VG.nachId(mon), nark ? VG.nachId(nark) : null);
    return new Function('curGeraet', 'VG', 'return ' + srcTitel)(() => g, VG)(slot);
  };
  /* Der Wunsch war ausdruecklich: auf dem Geraeteschild steht, WAS es ist — nicht der
   * Aufdruck eines fremden Apparats. Ein Herstellername auf einem Bild, das die Station
   * selbst zeichnet, laesst den Betrachter glauben, er sehe den echten Bildschirm. */
  pruef('Schild nennt das virtuelle Geraet, nicht den Hersteller',
    titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'mon') === 'Monitor & Kapnograph');
  pruef('Monitor ohne CO2-Modul heisst nur "Monitor"',
    titelFuer('eickemeyer-lifevet-m', null, 'mon') === 'Monitor', titelFuer('eickemeyer-lifevet-m', null, 'mon'));
  pruef('Veta 5 Plus = Narkose- & Beatmungsgeraet mit Kapnograph',
    titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'nark') === 'Narkose- & Beatmungsgerät mit Kapnograph');
  pruef('eigenstaendiger Kapnograf heisst Kapnograph, nicht Beatmungsgeraet',
    titelFuer('mindray-umec12-vet', 'kapnograf-standalone', 'nark') === 'Kapnograph',
    titelFuer('mindray-umec12-vet', 'kapnograf-standalone', 'nark'));
  pruef('rein mechanisches Geraet heisst schlicht Narkosegeraet',
    titelFuer('mindray-umec12-vet', 'mechanisch-vet-narkose', 'nark') === 'Narkosegerät',
    titelFuer('mindray-umec12-vet', 'mechanisch-vet-narkose', 'nark'));
  ['mindray', 'Mindray', 'uMEC', 'Veta', 'Draeger', 'EDAN'].forEach((h) => {
    pruef('kein "' + h + '" im Schild', [
      titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'mon'),
      titelFuer('mindray-umec12-vet', 'mindray-veta-5-plus', 'nark'),
      titelFuer('edan-im-vet', 'draeger-narkose', 'mon'),
      titelFuer('edan-im-vet', 'draeger-narkose', 'nark'),
    ].every((t) => t.indexOf(h) < 0));
  });
}

/* ================================================================= 14 */
abschnitt('14) Alarmgrenzen stellt die App selbst (1.4.1)');
const srcAnp = holeFunktion('alarmAnpassung');
pruef('alarmAnpassung ist auffindbar', !!srcAnp);
if (srcAnp) {
  const anpFuer = (alter, breed) => {
    const state = { age: alter };
    const curBreed = () => breed || null;
    return new Function('state', 'curBreed', 'VB', 'return ' + srcAnp)(state, curBreed, null)();
  };
  const leer = anpFuer('adult', null);
  pruef('erwachsenes Tier ohne Rassebefund: keine Anpassung', leer.length === 0);
  const jung = anpFuer('pediatric', null);
  pruef('Jungtier wird erkannt', jung.length === 1 && jung[0].id === 'jung');
  pruef('... Frequenzobergrenze steigt (Auswurf haengt an der Frequenz)', jung[0].hr([60, 140])[1] === 175);
  pruef('... Spitzendruck wird gedeckelt (kleine Lunge, Volutrauma)', jung[0].ppeak([6, 15])[1] === 12);
  pruef('... Temperaturalarm kommt frueher', jung[0].temp([37.5, 39.2])[0] > 37.5);
  const alt = anpFuer('senior', null);
  pruef('geriatrisch: Blutdruckuntergrenze steigt', alt[0].map([70, 120])[0] === 75);
  const boas = anpFuer('adult', { groups: ['brachy'], conditions: ['boas'] });
  pruef('brachyzephal wird ueber b.groups erkannt (nicht ueber groupsOf)', boas.length === 1 && boas[0].id === 'boas');
  pruef('... SpO2 alarmiert frueher', boas[0].spo2([95, 100])[0] === 96);
  pruef('... EtCO2-Obergrenze enger', boas[0].etco2([30, 55])[1] === 50);
  const wind = anpFuer('adult', { groups: ['sighthound'], conditions: ['sighthound'] });
  pruef('Windhund-Typ: Temperaturalarm frueher', wind.length === 1 && wind[0].temp([37.5, 39.2])[0] === 37.9);
  const hcm = anpFuer('adult', { groups: [], conditions: ['hcm-cat'] });
  pruef('HCM-Katze: Frequenzobergrenze runter (Diastole ist die Fuellzeit)', hcm[0].hr([100, 180])[1] === 160);
  pruef('... und Blutdruckuntergrenze mindestens 70', hcm[0].map([60, 120])[0] === 70);
  const beides = anpFuer('senior', { groups: ['brachy'], conditions: [] });
  pruef('mehrere Befunde greifen zusammen', beides.length === 2);
  pruef('jede Anpassung nennt ihre Begruendung im Klartext', beides.every((a) => a.regel && a.regel.length > 20));
  /* Die Grenze darf NIE weiter werden als das Normband — eine Automatik, die einen Alarm
   * spaeter ausloest als die Artnorm, ist genau das Gegenteil dessen, was hier gewollt ist. */
  const alle = ['pediatric', 'senior', 'adult'].flatMap((a) =>
    [null, { groups: ['brachy'] }, { groups: ['sighthound'] }, { conditions: ['hcm-cat'] }].map((b) => anpFuer(a, b)));
  let weiter = 0;
  alle.flat().forEach((a) => {
    ['hr', 'spo2', 'etco2', 'temp', 'map', 'ppeak'].forEach((k) => {
      if (typeof a[k] !== 'function') return;
      const basis = { hr: [60, 140], spo2: [95, 100], etco2: [30, 55], temp: [37.5, 39.2], map: [70, 120], ppeak: [6, 15] }[k];
      const neu = a[k](basis.slice());
      if (neu[0] < basis[0] || neu[1] > basis[1]) {
        // Die Frequenzobergrenze beim Jungtier ist die EINE gewollte Ausweitung: eine hohe
        // Frequenz ist dort physiologisch, ein Alarm darauf waere ein Fehlalarm im Minutentakt.
        if (!(a.id === 'jung' && k === 'hr')) weiter++;
      }
    });
  });
  pruef('keine Anpassung zieht eine Grenze WEITER als die Artnorm (ausser Jungtier-Frequenz)', weiter === 0, weiter + ' Faelle');
}
pruef('Alarmgrenzen werden NICHT mehr gespeichert (sie gehoeren zum Patienten)',
  appHtml.indexOf('grenzen:state.alarmGrenzen') < 0 && appHtml.indexOf('state.alarmGrenzen') < 0);
/* Auf die KNOPF-IDs pruefen, nicht auf die Woerter: die Begruendung, WARUM ein Knopf weg ist,
 * gehoert als Kommentar in die Datei — sonst baut ihn der naechste Leser wieder ein. */
['dbAlim', 'dbHold', 'dbFall', 'devBtns', 'alimGrid', 'renderAlim', 'renderDevBtns', 'mon._hold'].forEach((s) => {
  pruef('entfernt: ' + s, appHtml.indexOf(s) < 0);
});
pruef('die Falluhr laeuft stattdessen mit dem Datenfluss', appHtml.indexOf('__setFallLauf') >= 0);
pruef('vetstation-live.js setzt die Falluhr', liveJs.indexOf('__setFallLauf') >= 0);
pruef('Cockpit misst seine Hoehe zur Laufzeit', appHtml.indexOf('function cockpitHoehe') >= 0);
pruef('Eingabefelder verschwinden im Livebetrieb', appHtml.indexOf('liveDaten()') >= 0);
pruef('vetstation-live.js schickt ALLE Zahlenkanaele (keine feste Liste)',
  /Object\.keys\(v\)\.forEach/.test(liveJs) && liveJs.indexOf('UEBER_EINGABE') >= 0);

/* ================================================================= 14b */
abschnitt('14b) Die Zahl steht bei ihrer Kurve — und KEIN Wert faellt dabei durch (1.4.2)');
/*
 * Die Zuordnung Bahn -> Werte ist eine reine Datenregel und laesst sich hier vollstaendig
 * durchrechnen. Das Entscheidende ist nicht, dass es huebsch aussieht, sondern dass jeder Kanal
 * GENAU EINMAL im Bild steht: zweimal laedt zum Vergleichen ein und laesst einen Unterschied
 * suchen, den es nicht gibt — keinmal ist ein verschwundener Messwert.
 */
const mLane = /var LANE_WERTE=(\{[^;]*\});/.exec(appHtml);
pruef('LANE_WERTE ist auffindbar', !!mLane);
if (mLane && srcBahnen) {
  const LANE_WERTE = new Function('return ' + mLane[1])();
  VG.KURVEN.forEach((k) => pruef('Bahn "' + k.id + '" hat einen zugeordneten Wert', Array.isArray(LANE_WERTE[k.id]) && LANE_WERTE[k.id].length > 0));
  Object.keys(LANE_WERTE).forEach((b) => {
    pruef('LANE_WERTE.' + b + ' zeigt auf echte Kanaele', LANE_WERTE[b].every((id) => !!VG.kanal(id)));
    pruef('... und auf eine echte Bahn', !!VG.kurve(b));
  });
  const paare = [['mindray-umec12-vet', 'mindray-veta-5-plus'], ['eickemeyer-lifevet-10c', 'mindray-wato-ex35-vet'],
    ['eickemeyer-lifevet-m', null], ['petmap', null], ['universal-monitor', 'universal-narkose'],
    ['ge-datex-s5', 'draeger-narkose'], ['mindray-umec12-vet', 'kapnograf-standalone']];
  paare.forEach(([mon, nark]) => {
    const g = VG.zusammen(VG.nachId(mon), nark ? VG.nachId(nark) : null);
    const bahnen = new Function('curGeraet', 'return ' + srcBahnen)(() => g)();
    /* Genau die Rechnung, die renderLaneWerte macht: erster vorhandener Wert der Bahn ist der
     * Hauptwert, die weiteren sind Zweitwerte — und Zweitwerte gelten NUR als gezeigt, wenn die
     * Bahn hoch genug ist. Der Test rechnet beide Faelle durch (hohe und flache Bahn). */
    [true, false].forEach((zeigeZusatz) => {
      const inBahn = new Set();
      bahnen.forEach((b) => {
        const ids = (LANE_WERTE[b] || []).filter((i) => g.kanaele.indexOf(i) >= 0);
        if (!ids.length) return;
        inBahn.add(ids[0]);
        if (zeigeZusatz) ids.slice(1).forEach((i) => inBahn.add(i));
      });
      const kacheln = g.kanaele.filter((k) => !inBahn.has(k));
      const alle = [...inBahn, ...kacheln];
      const fehlend = g.kanaele.filter((k) => alle.indexOf(k) < 0);
      const doppelt = g.kanaele.filter((k) => inBahn.has(k) && kacheln.indexOf(k) >= 0);
      pruef(mon + (nark ? '+' + nark : '') + (zeigeZusatz ? ' (hohe Bahn)' : ' (flache Bahn)') + ': jeder Kanal genau einmal sichtbar',
        fehlend.length === 0 && doppelt.length === 0, 'fehlt: ' + fehlend.join() + ' doppelt: ' + doppelt.join());
    });
  });
  /* Ein Geraet ohne Kurven zeigt ALLES als Kachel — sonst waere die halbe Anzeige leer. */
  const pm = VG.zusammen(VG.nachId('petmap'), null);
  const pmB = new Function('curGeraet', 'return ' + srcBahnen)(() => pm)();
  pruef('ohne Kurve steht jeder Wert als Kachel', pmB.length === 0 && pm.kanaele.length > 0);
}
pruef('die Kurve endet VOR der Zahlenspalte (sonst laeuft die Linie unter die Zahl)',
  /var RESERVE=Math\.round\(\(mon\.reservePx\|\|206\)\*mon\.dpr\), WZ=/.test(appHtml) && appHtml.indexOf('i*(WZ/(b.length-1))') >= 0);
pruef('die Schriftgroesse folgt der Bahnhoehe (feste 30 px liefen ineinander)',
  /laneH\*0\.40/.test(appHtml) && appHtml.indexOf('--lane-fz') >= 0);
pruef('Alarmgrenzen sitzen absolut in der Ecke (sonst wird die Kopfzeile zweizeilig)',
  /\.mon-lane \.ml-kopf i\{position:absolute/.test(appHtml));
pruef('die feste Notfallleiste wird von der Cockpithoehe abgezogen',
  appHtml.indexOf("querySelector('.nf-dock')") >= 0 && /dockH=dr\.height/.test(appHtml));
pruef('helles Thema: Modellwahl und Erlaeuterung sind lesbar',
  /html\[data-theme="light"\] \.gwahl select\{background:#fff/.test(appHtml) && /html\[data-theme="light"\] \.gw-note b/.test(appHtml));

/* ================================================================= 14c */
abschnitt('14c) Ein Bildschirm, keine Rollbalken, eingetippt wird am Wert (1.4.3)');
pruef('die Zahlenspalte ist DECKEND (Kurve laeuft nicht darunter durch)',
  /\.mon-lanes\{[^}]*background:#05080d/.test(appHtml) && /\.mon-lane\{[^}]*background:#05080d/.test(appHtml));
pruef('die Leinwand reserviert die GEMESSENE Spaltenbreite, keine feste Zahl',
  appHtml.indexOf('mon.reservePx=host.getBoundingClientRect().width') >= 0
  && /RESERVE=Math\.round\(\(mon\.reservePx\|\|206\)\*mon\.dpr\)/.test(appHtml));
pruef('die alte Eingabezeile ist im Geraetefeld ausgeblendet',
  /\.ck-links \.mon-inputs\{display:none !important\}/.test(appHtml));
pruef('... bleibt aber im Baum — vetstation-live.js schreibt dort hinein',
  appHtml.indexOf('id="monInputs"') >= 0 && liveJs.indexOf("#monInputs input[data-p=") >= 0);
pruef('die rollende Rhythmusleiste ist ausgeblendet',
  /\.ck-links #rhythmChips\{display:none !important\}/.test(appHtml));
pruef('... und durch EIN Auswahlfeld ersetzt', appHtml.indexOf('id="rhySel"') >= 0 && appHtml.indexOf('function renderRhySel') >= 0);
pruef('... das die verborgenen Chips anklickt (der erprobte Weg bleibt)',
  /#rhythmChips \.chip\[data-r="'\+sel\.value\+'"\]/.test(appHtml));
pruef('getippt wird IN der Kachel', appHtml.indexOf("wertFeld(p, state.istVals[p.id], 'mt-in')") >= 0);
pruef('... und IN der Zahl an der Kurve', appHtml.indexOf("wertFeld(haupt, state.istVals[haupt.id], 'ml-in')") >= 0);
pruef('... und im ZWEITWERT der Bahn (sonst waere FiCO2 nicht eingebbar)',
  appHtml.indexOf("wertFeld(q, state.istVals[q.id], 'ml-in ml-zwin')") >= 0);
pruef('der Blutdruck bekommt zwei Felder (SYS/DIA), der Mitteldruck folgt daraus',
  appHtml.indexOf('function wertFeldPaar') >= 0 && /data-p="sys"[\s\S]{0,200}data-p="dia"/.test(appHtml));
pruef('die Schreibmarke ueberlebt den Neuaufbau', appHtml.indexOf('function fokusMerken') >= 0 && appHtml.indexOf('fokusZurueck(fok)') >= 0);
pruef('Getipptes wird ins verborgene Feld gespiegelt (ohne dessen Ereignis)',
  /#monInputs input\[data-p="'\+k\+'"\]/.test(appHtml) && appHtml.indexOf('h.value=roh') >= 0);
pruef('der Kopfbereich schrumpft auf dem Geraet-Reiter',
  /html\[data-view="geraet"\] \.sp-chip\{/.test(appHtml) && appHtml.indexOf("setAttribute('data-view', v)") >= 0);
/*
 * OPT_SENSOR: EINE Liste fuer Alarm UND Analyse. Zwei getrennte Listen haben genau den Fehler
 * erzeugt, den das Bildschirmfoto zeigte: "ART ↓ 0 mmHg — Hypotension" samt Ephedrin-Dosis fuer
 * ein Tier, an dem gar kein invasiver Druck gemessen wurde.
 */
{
  const mOpt = /var OPT_SENSOR=(\[[^\]]*\]);/.exec(appHtml);
  pruef('OPT_SENSOR ist auffindbar', !!mOpt);
  if (mOpt) {
    const OPT = new Function('return ' + mOpt[1])();
    ['ibp', 'pi', 'temp2', 'vte', 'ppeak', 'fio2', 'etAgent', 'peep'].forEach((k) =>
      pruef('optionaler Sensor erkannt: ' + k, OPT.indexOf(k) >= 0));
    /* Diese drei duerfen NIE darin stehen: dort ist die Null ein Befund. */
    ['hr', 'etco2', 'nibp', 'spo2'].forEach((k) =>
      pruef('bei "' + k + '" ist die Null ein BEFUND und muss alarmieren', OPT.indexOf(k) < 0));
    pruef('dieselbe Liste gilt fuer Alarm UND Analyse',
      (appHtml.match(/OPT_SENSOR\.indexOf\(p\.id\)>=0/g) || []).length >= 2);
    OPT.forEach((k) => pruef('OPT_SENSOR."' + k + '" ist ein echter Kanal', !!VG.kanal(k)));
  }
}

/* ================================================================= 14d */
abschnitt('14d) Bedienteil gross, Kurven flach und breit, Hellmodus lesbar (1.4.4)');
/*
 * Der Wunsch war deutlich: das Narkose- und Beatmungsgeraet muss GROSS sein, die Kurven duerfen
 * dafuer flacher und breiter werden. Der Grund liegt in der Bedienung — am Verdampfer wird
 * gedreht, die Modusknoepfe werden mitten in der Narkose getroffen, notfalls mit Handschuhen.
 * Eine Kurve dagegen liest man in der Waagerechten: Form, Anstieg, Plateau.
 */
pruef('die Geraetespalte ist deutlich breiter als die Analysespalte',
  /\.cockpit\{[^}]*grid-template-columns:minmax\(0,1\.9fr\) minmax\(258px,\.46fr\)/.test(appHtml));
pruef('die Kurvenflaeche darf flacher werden (min-height gesenkt)',
  /\.ck-schirm\{[^}]*min-height:140px/.test(appHtml) && /\.ck-schirm \.mon-screen\{[^}]*min-height:110px/.test(appHtml));
[['svg.flowmeter{height:142px', 'Flowmeter 142 px hoch'],
 ['svg.vaporizer{height:142px;width:142px', 'Verdampfer 142 px'],
 ['.mc-step{width:34px;height:34px', 'Schrittknoepfe 34 px (mit Handschuh treffbar)'],
 ['.mc-modes button{padding:5px 11px;font-size:12px', 'Modusknoepfe gross genug'],
 ['.mc-toggle button{height:30px', 'Manuell/Auto gross genug'],
 ['.mc-flush{height:34px', 'O2-Flush gross genug'],
].forEach(([s, n]) => pruef(n, appHtml.indexOf(s) >= 0));
/*
 * DER FLOWMETER WAR 30 PUNKTE BREIT (gemessen 05.08.2026: 30 x 96 auf dem Bildschirm).
 * Eine 30 Punkte breite Saeule trifft man mit der Maus kaum und mit dem Finger gar nicht.
 * Die Zeichnung ist deshalb von 66 auf 96 Einheiten verbreitert worden — der Test rechnet
 * nach, wie breit das AUF DEM BILDSCHIRM wird, statt nur zu pruefen, dass die Zahl da steht.
 */
{
  const mVb = /viewBox="0 0 (\d+) '\+H\+'"/.exec(appHtml);
  pruef('Flowmeter-Zeichenflaeche ist verbreitert', !!mVb && Number(mVb[1]) >= 96, mVb ? mVb[1] : 'nicht gefunden');
  if (mVb) {
    const breite = 142 * (Number(mVb[1]) / 210);   // Hoehe aus dem CSS x Seitenverhaeltnis
    pruef('… ergibt auf dem Bildschirm >= 60 px Greifbreite (vorher 30)', breite >= 60, Math.round(breite) + ' px');
  }
  pruef('die GANZE Flaeche ist Greifflaeche, nicht nur die gezeichnete Saeule',
    /<rect x="0" y="0" width="96" height="'\+H\+'" fill="transparent"\/>/.test(appHtml)
    && appHtml.indexOf('<rect x="0" y="0" width="136" height="136" fill="transparent"/>') >= 0);
  pruef('der Schwimmer ist groesser (r 11 -> 15)', /r="15" fill="#ff4d4d"/.test(appHtml));
  pruef('der Verdampferzeiger ist dicker (4,5 -> 6)', /stroke="#e23b3b" stroke-width="6"/.test(appHtml));
  pruef('Touchscreen: die Wischgeste geht an den Regler, nicht an die Seite',
    /svg\.flowmeter,\.machine svg\.vaporizer\{touch-action:none/.test(appHtml));
  pruef('beide Regler melden sich als Schieberegler (Screenreader/Tastatur)',
    (appHtml.match(/role="slider"/g) || []).length >= 2);
  pruef('die Wertekacheln passen in EINE Reihe (Hoehe fuer die Regler)',
    /grid-template-columns:repeat\(auto-fit,minmax\(86px,1fr\)\)/.test(appHtml));
  /* Der Regler steht NEBEN seiner Beschriftung statt darueber — so wird er hoeher, ohne dass
   * der ganze Block hoeher wird. Gemessen: Bedienteil 190 px trotz 142-px-Reglern. */
  pruef('Regler und Beschriftung stehen nebeneinander (mc-knob)',
    /\.ck-links \.mc-knob\{display:grid/.test(appHtml) && appHtml.indexOf('class="mc-item mc-knob"') >= 0);
}
pruef('der APL-Hinweis ist wieder da (er passt jetzt)', !/\.ck-links \.mc-hint\{display:none\}/.test(appHtml));
pruef('die Wertekacheln sind groesser geworden', /\.ck-links \.mon-tiles \.mt-v\{font-size:22px/.test(appHtml));
/*
 * HELLMODUS. Das Geraetebild bleibt in BEIDEN Schemata dunkel — ein Patientenmonitor ist
 * dunkel, und ein heller waere im OP nicht lesbar. Gemessen 05.08.2026: im hellen Schema kam
 * die Wertekachel ganz OHNE Hintergrund heraus (backgroundColor transparent), und damit stand
 * bernsteinfarbene Schrift auf weissem Grund — Kontrast 1,3 statt 10. Welche fremde Regel den
 * Grund wegnimmt, ist gleichgueltig; deshalb steht hier !important.
 */
pruef('Wertekacheln bleiben in BEIDEN Schemata dunkel', /background:linear-gradient\(90deg,color-mix[^;]*\) !important/.test(appHtml));
pruef('... auch im Alarmzustand', /\.mon-tile\.alarm\{background:rgba\(255,77,77,\.16\) !important/.test(appHtml));
pruef('die Zahlenspalte ebenfalls', /\.mon-lanes\{[^}]*background:#05080d !important/.test(appHtml));
pruef('Hellmodus: "alles im Normbereich" ist lesbar', /html\[data-theme="light"\] \.assess-ok\{color:#0a5c3a/.test(appHtml));
pruef('Hellmodus: die Vertrauens-Marken sind lesbar',
  /html\[data-theme="light"\] \.gw-v\.belegt/.test(appHtml)
  && /html\[data-theme="light"\] \.gw-v\.wahrscheinlich/.test(appHtml)
  && /html\[data-theme="light"\] \.gw-v\.unbestaetigt/.test(appHtml));
pruef('Reiterleiste und Hinweiszeile geben auf dem Geraet-Reiter Hoehe ab',
  /html\[data-view="geraet"\] \.tab\{height:30px/.test(appHtml) && /html\[data-view="geraet"\] \.disc\{padding:3px 0\}/.test(appHtml));

/* ================================================================= 15 */
abschnitt('15) Millisekunden-Takt: der Wert geht raus, sobald er da ist');
const regSrc = fs.readFileSync(path.join(WURZEL, 'bridge/src/registry.js'), 'utf8');
const srvSrc = fs.readFileSync(path.join(WURZEL, 'bridge/src/server.js'), 'utf8');
pruef('registry meldet jeden neuen Frame (onNeu)', /this\.onNeu\s*=\s*null/.test(regSrc) && /if \(this\.onNeu\)/.test(regSrc));
pruef('... und ein Fehler im Haken stoppt die Datenaufnahme nicht', /if \(this\.onNeu\) \{ try \{/.test(regSrc));
pruef('server haengt sich ein und buendelt', srvSrc.indexOf('registry.onNeu =') >= 0 && srvSrc.indexOf('MIN_ABSTAND_MS') >= 0);
pruef('Buendelung entspricht der Bildrate des Monitors (40 ms)', /MIN_ABSTAND_MS = 40/.test(srvSrc));
pruef('der 350-ms-Zeitgeber bleibt (Protokoll, Fern-Live, Lastbremse)', /BROADCAST_MS = 350/.test(srvSrc));
pruef('beim Beenden wird abgemeldet (kein Senden auf geschlossenen Socket)',
  /registry\.onNeu = null;[\s\S]{0,120}clearTimeout\(sofortTimer\)/.test(srvSrc));
// wirklich ausfuehren: ein Frame -> ein Ruf, zehn Frames -> nicht zehn Rufe
{
  const { Registry } = require(path.join(WURZEL, 'bridge/src/registry.js'));
  const r = new Registry({ log: { info() {}, warn() {}, error() {} } });
  let rufe = 0;
  r.onNeu = () => { rufe++; };
  for (let i = 0; i < 5; i++) {
    r.ingest({ deviceId: 'X', deviceModel: 'M', deviceRole: 'monitor', patientId: '1', species: 'hund', weightKg: 10, ts: Date.now(), vitals: { hr: 90 + i } });
  }
  pruef('jeder eingehende Frame meldet sich (5 Frames -> 5 Meldungen)', rufe === 5, String(rufe));
  const r2 = new Registry({ log: { info() {}, warn() {}, error() {} } });
  r2.onNeu = () => { throw new Error('absichtlich'); };
  let ueberlebt = true;
  try { r2.ingest({ deviceId: 'Y', deviceRole: 'monitor', ts: Date.now(), vitals: { hr: 80 } }); } catch (_) { ueberlebt = false; }
  pruef('ein werfender Haken bringt die Datenaufnahme NICHT um', ueberlebt);
}

console.log('\n== Ergebnis: ' + ok + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
