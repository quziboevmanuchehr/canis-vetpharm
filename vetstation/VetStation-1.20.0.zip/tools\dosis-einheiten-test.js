'use strict';
/*
 * dosis-einheiten-test.js — bewacht drei Luecken, durch die am 17.08.2026 falsche Zahlen bis
 * auf den Bildschirm und in den Ausdruck gelaufen sind, WAEHREND alle 81 Testdateien gruen waren.
 *
 * WARUM ES DIESE DATEI GIBT — die drei Luecken, jede mit ihrem gemessenen Schaden:
 *
 *   1. KEINE EINZIGE EINHEITENPRUEFUNG. In 81 Testdateien kam '.unit' nicht ein Mal vor.
 *      Deshalb fiel nicht auf, dass calc() nur mg, mcg und Einheiten kennt: 'mEq/kg' landete im
 *      mg-Zweig und wurde durch mg/mL geteilt. Bei Magnesiumsulfat steht in der Konzentration
 *      "500 mg/mL (50 %) = 4 mEq/mL" — genommen wurde die 500, richtig waere die 4 gewesen.
 *      500/4 = 125: die Spritzenmenge war bei 20 kg 0,006-0,012 mL statt 0,75-1,5 mL. 0,006 mL
 *      sind nicht aufziehbar, und die einzige Indikation des Eintrags ist die
 *      lidocain-refraktaere Kammertachykardie.
 *
 *   2. DIE DRITTE KOPIE. ui/vendor/anaes-data.js (17.07.2026) lag neben ui/app/anaes-data.js,
 *      und die Stationsschale lud die alte. Kein Test kannte sie. Folge, gemessen: die Maus
 *      hatte keine Normwerte und wurde gegen das HUNDE-Band bewertet — eine sterbende Maus mit
 *      150/min wurde als "Herzfrequenz zu hoch" gemeldet, weil 150 ueber der Hundegrenze 140
 *      liegt. Die Richtung war umgekehrt. Ein Vergleich der DATEINAMEN haette das nicht
 *      gefunden; deshalb vergleicht dieser Test Pruefsummen.
 *
 *   3. DAS LEERE HERZFREQUENZBAND. Das Diagnostik-EKG holte sein Band mit
 *      grenzeOf('hr') — einer Funktion aus einem ANDEREN Skriptblock derselben Datei (beide
 *      sind eigene IIFE), mit falschem Argumenttyp und falscher Rueckgabeform. Das Band war
 *      immer leer, und ein Streifen mit 229/min und 95 ms breitem Kammerkomplex wurde als
 *      "regelmaessig" gemeldet statt als Verdacht auf ventrikulaere Tachykardie. Kein Test sah
 *      es, weil JEDER EKG-Test sein Band selbst mitgibt (17 von 17 Aufrufen) — geprueft wurde
 *      also nie der Weg, auf dem die Anwendung es BESORGT.
 *
 * Diese Datei steht in tools/alle-tests.js. Ein Test, der nicht im Sammellauf steht, bewacht
 * nichts: er faellt beim naechsten Umbau still aus. Genau das war am 08.08.2026 schon einmal so.
 *
 * Start: node tools/dosis-einheiten-test.js
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const WURZEL = path.join(__dirname, '..');
const dose = require('../ui/engine/dose');

let pass = 0, fail = 0;
function ok(n, c, e) {
  if (c) { pass++; console.log('  ✓ ' + n); }
  else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); }
}
function laden(rel) {
  const win = {};
  (new Function('window', fs.readFileSync(path.join(WURZEL, rel), 'utf8')))(win);
  return win.ANAES;
}

console.log('VetStation — Dosiseinheiten, Datenkopien und Herzfrequenzband\n');

/* ================================================================================
 * 1) JEDE vorkommende Einheit muss von calc() WIRKLICH behandelt werden
 * ================================================================================
 * Als POSITIVLISTE, und das ist Absicht: eine Positivliste ist in diesem Projekt sonst eine
 * Loeschstelle, hier ist sie genau richtig, weil eine NEUE Einheit auffallen MUSS. Wer eine
 * Dosis in einer Einheit eintraegt, die der Rechner nicht kennt, bekommt heute stillschweigend
 * eine mg-Rechnung. Dieser Test wird dann rot statt der Praxis eine falsche Zahl zu zeigen.
 */
console.log('1) Einheiten: kennt calc() jede Einheit, die im Datensatz steht?');
const BEHANDELT = ['mg', 'mcg', 'µg', 'mEq', 'mmol', 'IU', 'U', 'units', 'unit'];
const A = laden('ui/app/anaes-data.js');
ok('ui/app/anaes-data.js geladen (' + (A ? A.drugs.length : 0) + ' Wirkstoffe)', !!(A && A.drugs && A.drugs.length));

const einheiten = {};
(A.drugs || []).forEach(function (d) {
  if (!d.species) return;
  Object.keys(d.species).forEach(function (art) {
    const s = d.species[art];
    if (!s || !s.unit) return;
    (einheiten[String(s.unit)] = einheiten[String(s.unit)] || []).push(d.id + '/' + art);
  });
});
Object.keys(einheiten).sort().forEach(function (u) {
  /* Der Mengenteil steht vor dem ersten Schraegstrich: "mEq/kg" -> "mEq", "mcg/kg/min" -> "mcg". */
  const menge = String(u).split('/')[0].trim();
  const kennt = BEHANDELT.some(function (b) { return b.toLowerCase() === menge.toLowerCase(); });
  ok('Einheit "' + u + '" (' + einheiten[u].length + 'x) ist in calc() behandelt',
    kennt, 'Mengenteil "' + menge + '" steht nicht in BEHANDELT — calc() rechnet ihn als mg. ' +
    'Betroffen: ' + einheiten[u].slice(0, 3).join(', '));
});

/* ---- mEq und mmol: richtige Zahl oder Schweigen, niemals eine erfundene ---- */
console.log('\n2) mEq/mmol: richtige mL — oder KEINE mL:');
const mgProMl = 500, meqProMl = 4;
const cHund = dose.calc({ low: 0.15, high: 0.3, unit: 'mEq/kg',
  conc: mgProMl + ' mg/mL (50 %) = ' + meqProMl + ' mEq/mL' }, 20);
ok('mEq-Dosis wird als mEq beschriftet, nicht als mg', cHund.amtUnit === 'mEq', 'amtUnit=' + cHund.amtUnit);
ok('mL kommt aus der mEq-Angabe: 3-6 mEq / ' + meqProMl + ' = 0,75-1,5 mL',
  Math.abs(cHund.mlLo - 0.75) < 1e-9 && Math.abs(cHund.mlHi - 1.5) < 1e-9,
  cHund.mlLo + '-' + cHund.mlHi);
/* Die Gegenprobe ist der eigentliche Schutz: waere hier wieder die mg-Zahl genommen, kaeme
 * 3/500 = 0,006 heraus — der Faktor 125, mit dem der Befund entstanden ist. */
ok('NICHT die mg-Zahl genommen (0,006 mL waere der 125-fache Fehler)',
  !(Math.abs(cHund.mlLo - (3 / mgProMl)) < 1e-9), 'mlLo=' + cHund.mlLo);

const cKatze = dose.calc({ low: 0.15, high: 0.3, unit: 'mEq/kg', conc: mgProMl + ' mg/mL (50 %)' }, 20);
ok('ohne passende mEq/mL-Angabe wird GESCHWIEGEN (keine mL)', cKatze.mlLo == null,
  'mlLo=' + cKatze.mlLo + ' — eine erfundene mL-Zahl geht in eine Spritze');
ok('die Menge selbst steht trotzdem da (3-6 mEq)', cKatze.amtLo === 3 && cKatze.amtHi === 6,
  cKatze.amtLo + '-' + cKatze.amtHi);

const cKcl = dose.calc({ low: 0.25, high: 0.5, unit: 'mmol/kg/h', conc: '2 mmol/mL' }, 20);
ok('mmol wird als mmol beschriftet und tragt seinen Zeitbezug', cKcl.amtUnit === 'mmol/h',
  'amtUnit=' + cKcl.amtUnit);
ok('mmol-mL richtig: 5-10 mmol / 2 = 2,5-5 mL', Math.abs(cKcl.mlLo - 2.5) < 1e-9, cKcl.mlLo);

/* ---- Raten: der Zeitbezug darf nicht verschwinden ---- */
console.log('\n3) Raten behalten "/min" bzw. "/h" (sonst sieht ein Dauertropf wie ein Bolus aus):');
const cDopa = dose.calc({ low: 2, high: 20, unit: 'mcg/kg/min', conc: '40 mg/mL' }, 20);
ok('mcg/kg/min ergibt Einheit "mcg/min"', cDopa.amtUnit === 'mcg/min', 'amtUnit=' + cDopa.amtUnit);
ok('takt wird mitgeliefert, damit auch die mL-Zahl ihn tragen kann', cDopa.takt === '/min', 'takt=' + cDopa.takt);
const cBolus = dose.calc({ low: 0.02, high: 0.04, unit: 'mg/kg', conc: '0.5 mg/mL' }, 20);
ok('Einzelgabe hat KEINEN Zeitbezug', cBolus.takt === '', 'takt=' + JSON.stringify(cBolus.takt));
ok('Einzelgabe rechnet unveraendert (0,4-0,8 mg = 0,8-1,6 mL)',
  Math.abs(cBolus.mlLo - 0.8) < 1e-9 && Math.abs(cBolus.mlHi - 1.6) < 1e-9,
  cBolus.mlLo + '-' + cBolus.mlHi);
const cIu = dose.calc({ low: 50, high: 100, unit: 'IU/kg', conc: '100 IU/mL' }, 20);
ok('IU-Praeparate unveraendert (1000-2000 U = 10-20 mL)',
  cIu.amtUnit === 'U' && Math.abs(cIu.mlLo - 10) < 1e-9, cIu.amtUnit + ' ' + cIu.mlLo);

/* ================================================================================
 * 4) Datenkopien: ALLE anaes-data.js im Baum gegen die kanonische halten
 * ================================================================================
 * Verglichen werden PRUEFSUMMEN, nicht Dateinamen. Genau daran ist der Befund vom 13.08.2026
 * hangengeblieben: die Namen stimmten, der Inhalt nicht.
 * Kanonisch ist ui/app/anaes-data.js — das sagt der Kopf von bridge/src/anaes.js.
 */
console.log('\n4) Datenkopien im Baum (Pruefsummen, nicht Dateinamen):');
function summe(p) { return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex').slice(0, 12); }
const kanonisch = path.join(WURZEL, 'ui/app/anaes-data.js');
const kSumme = summe(kanonisch);
console.log('   kanonisch: ui/app/anaes-data.js  [' + kSumme + ']');

/* dist/ ist Bauergebnis und darf abweichen; es wird beim naechsten Bau ueberschrieben. */
const gefunden = [];
(function suche(dir) {
  fs.readdirSync(dir, { withFileTypes: true }).forEach(function (e) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === 'dist' || e.name === '.git' || e.name === 'node_modules') return;
      suche(p);
    } else if (e.name === 'anaes-data.js') gefunden.push(p);
  });
})(WURZEL);

ok('mindestens die kanonische Datei gefunden', gefunden.length >= 1, gefunden.length + ' Treffer');
gefunden.forEach(function (p) {
  const rel = path.relative(WURZEL, p).replace(/\\/g, '/');
  if (p === kanonisch) return;
  const s = summe(p);
  /*
   * EINE ZWEITE KOPIE IST NICHT VERBOTEN — sie darf nur nicht ZUR LAUFZEIT GELADEN werden.
   * Deshalb prueft dieser Test nicht "es gibt keine Kopie", sondern: wird eine abweichende
   * Kopie von einer ausgelieferten Seite geladen? Das ist die Frage, an der es gehangen hat.
   */
  const abweichend = s !== kSumme;
  const geladenVon = [];
  ['ui/index.html', 'ui/app/index.html'].forEach(function (seite) {
    const html = fs.readFileSync(path.join(WURZEL, seite), 'utf8');
    const nurCode = html.replace(/<!--[\s\S]*?-->/g, ' ');
    const dateiname = path.basename(path.dirname(p)) + '/anaes-data.js';
    if (nurCode.indexOf('src="' + dateiname + '"') >= 0) geladenVon.push(seite);
  });
  ok(rel + ' [' + s + ']' + (abweichend ? ' weicht ab' : ' ist zeichengleich') +
     ' und wird von keiner Seite geladen' + (geladenVon.length ? ' (LAEDT: ' + geladenVon.join(', ') + ')' : ''),
    !(abweichend && geladenVon.length),
    'Eine ABWEICHENDE Kopie wird ausgeliefert — genau der Befund vom 17.08.2026');
});

/* ================================================================================
 * 5) Herzfrequenzband: leer heisst SCHWEIGEN, nicht "regelmaessig"
 * ================================================================================ */
console.log('\n5) Diagnostik-EKG: ohne Band keine Rhythmusaussage, mit Band die richtige:');
const win = {};
(new Function('window', 'self', fs.readFileSync(path.join(WURZEL, 'ui/shared/ekg-analyse.js'), 'utf8')))(win, win);
const ekg = win.VS && win.VS.ekg;
ok('ekg-analyse.js geladen', !!ekg);

/* Gleichmaessige Kammerkomplexe der gewuenschten Frequenz und Breite, ohne P-Welle. */
function streifen(hf, qrsMs, sek, hz) {
  const n = Math.round(sek * hz), s = new Array(n).fill(0), rr = 60 / hf, halb = (qrsMs / 1000) * hz / 2;
  for (let t = rr; t < sek; t += rr) {
    const m = Math.round(t * hz);
    for (let k = -halb; k <= halb; k++) {
      const i = m + Math.round(k);
      if (i >= 0 && i < n) s[i] = (1 - Math.abs(k) / halb) * 1.5;
    }
  }
  return s;
}
function deutung(hf, qrsMs, band) {
  const erg = ekg.analysiere({ samples: streifen(hf, qrsMs, 10, 500), hz: 500, skala: 1, einheit: 'mV' },
    { bandHr: band, einheit: 'mV', art: 'hund', filterAktiv: false });
  return ((erg.rhythmus && erg.rhythmus.name) || '') + '';
}

const mitBand = deutung(229, 95, [70, 160]);
ok('229/min + breiter Komplex MIT Band -> Verdacht auf ventrikulaere Tachykardie',
  /ventrikul/i.test(mitBand), 'gemeldet: "' + mitBand + '"');
const brady = deutung(38, 60, [70, 160]);
ok('38/min MIT Band -> als langsam benannt', /langsam/i.test(brady), 'gemeldet: "' + brady + '"');
const gesund = deutung(110, 45, [70, 160]);
ok('110/min (gesunder Hund) MIT Band -> kein Alarmbefund', !/ventrikul|langsam|schnell/i.test(gesund),
  'gemeldet: "' + gesund + '"');
/*
 * Und die Zurueckhaltung: fuer Arten OHNE belegtes Band (nur Hund, Katze und Pferd haben eines)
 * darf keine Frequenzaussage entstehen. "wir wissen es nicht" ist nicht "trifft nicht zu".
 */
const ohneBand = deutung(229, 95, null);
ok('ohne Band wird KEINE Frequenzaussage behauptet', !/ventrikul|langsam|schnell/i.test(ohneBand),
  'gemeldet: "' + ohneBand + '"');
ok('mit Band und ohne Band unterscheiden sich WIRKLICH (sonst prueft dieser Test nichts)',
  mitBand !== ohneBand, 'beide: "' + mitBand + '"');

/* ---- Die Anwendung muss ihr Band auch BESORGEN koennen ---- */
console.log('\n6) Der Weg, auf dem die Anwendung ihr Band holt:');
const appHtml = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
const ohneKommentar = appHtml.replace(/\/\*[\s\S]*?\*\//g, ' ');
ok('grenzeOf(\'hr\') kommt im CODE nicht mehr vor (falscher Block, falscher Typ, falsche Form)',
  ohneKommentar.indexOf("grenzeOf('hr')") < 0,
  'Die Funktion liegt in einem anderen IIFE und gibt {lo,hi,grund} zurueck, kein Array');
ok('das Band kommt aus normAktuell().hf', /band\s*=\s*nb\.hf/.test(ohneKommentar));
/* normAktuell MUSS im selben Skriptblock stehen wie der Aufruf, sonst ist es wieder still tot. */
const bloecke = [];
let re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi, m;
while ((m = re.exec(appHtml))) bloecke.push(m[1]);
const blockMitAufruf = bloecke.filter(function (b) { return /band\s*=\s*nb\.hf/.test(b); })[0] || '';
ok('normAktuell steht im SELBEN Skriptblock wie der Aufruf (' + bloecke.length + ' Bloecke geprueft)',
  /function\s+normAktuell\s*\(/.test(blockMitAufruf),
  'Sonst gilt derselbe IIFE-Fehler wie vorher — nur mit anderem Namen');

/* ================================================================================
 * 7) STAMMLOESUNG IST NICHT GEBRAUCHSLOESUNG
 * ================================================================================
 * Befund 18.08.2026, gemessen an allen 207 Eintraegen mit Konzentrationsangabe.
 * parseConc() nimmt die ERSTE Zahl vor "mg/mL". Bei 32 Eintraegen steht dort die fertig
 * verduennte Loesung ("0.05 mg/mL (aus 0.5 mg/mL verduennt)") — richtig. Bei 11 Eintraegen
 * steht dort die STAMMLOESUNG mit dem Auftrag, sie zu verduennen ("50 mg/mL (stark
 * verduennen)"). Dort war die ausgerechnete Milliliterzahl die Menge des KONZENTRATS.
 * Gemessener Schaden: Carprofen beim 90-g-Hamster wurde als 0,0090 mL angezeigt, waehrend
 * die eigene Warnung im selben Eintrag 0,14 mL nannte; Terbutalin/Katze 0,08 mL.
 * 0,009 mL gibt keine Spritze ab — wer es trotzdem versucht, gibt ein Vielfaches.
 * Seither: liegt NUR eine Konzentration vor UND fordert der Text eine Verduennung, wird
 * gar keine Milliliterzahl mehr gezeigt. Das folgt dem Leitsatz "im Zweifel schweigen".
 */
console.log('\n7) Stammloesung wird nicht als Gebrauchsloesung gerechnet:');
ok('"50 mg/mL (stark verduennen)" liefert KEINE mL',
  dose.calc({ low: 1, high: 2, unit: 'mg/kg', conc: '50 mg/mL (stark verduennen)' }, 10).mlLo === null,
  'Das waere die Menge des Konzentrats, nicht der Gebrauchsloesung');
ok('"0.05 mg/mL (aus 0.5 mg/mL verduennt)" liefert weiter mL (fertige Verduennung)',
  dose.calc({ low: 1, high: 2, unit: 'mg/kg', conc: '0.05 mg/mL (aus 0.5 mg/mL verduennt)' }, 10).mlLo === 200);
/* Die drei Faelle, an denen die Fassungen v1 bis v3 des Riegels der Reihe nach
 * gescheitert sind - jede an einem ECHTEN Eintrag der Datei (18.08.2026). */
ok('eine Konzentration in zwei Schreibweisen ist EINE (fentanyl/maus)',
  dose.calc({ low: 1, high: 2, unit: 'mg/kg', conc: '0,05 mg/mL (50 mcg/mL) - fuer die Maus verduennen' }, 10).mlLo === null,
  'v1 zaehlte Texttreffer und hielt das fuer eine fertige Verduennung');
ok('dieselbe Loesung in zwei EINHEITEN ist EINE (magnesiumsulfat/hund)',
  dose.calc({ low: 1, high: 2, unit: 'mg/kg', conc: '500 mg/mL (50 %) = 4 mEq/mL — VERDÜNNEN' }, 10).mlLo === null,
  'v2 rechnete Werte um; mg und mEq lassen sich ohne Molmasse nicht vergleichen');
ok('eine Herkunftsangabe mit inneren Klammern gilt (adrenalin/maus)',
  dose.calc({ low: 0.01, high: 0.1, unit: 'mg/kg', conc: '0,01 mg/mL (aus 1 mg/mL (1:1000) 1:100 verduennt)' }, 0.025).mlLo === 0.025,
  'v3 verbot Klammern im Innern und machte 25 statt 11 Eintraege stumm');
ok('"NIE unverduennt" ist keine Herkunftsangabe (kaliumchlorid)',
  dose.calc({ low: 1, high: 2, unit: 'mmol/kg', conc: '2 mmol/mL (7,45 %) — NIE unverdünnt' }, 10).mlLo === null,
  'unverduennt enthaelt verduennt - ohne Ausblenden gaelte es als Herkunft');
ok('"0.5 mg/mL" ohne Verduennungsauftrag liefert weiter mL',
  dose.calc({ low: 1, high: 2, unit: 'mg/kg', conc: '0.5 mg/mL' }, 10).mlLo === 20);
ok('"2 mmol/mL — NIE unverduennt" liefert KEINE mL',
  dose.calc({ low: 1, high: 2, unit: 'mmol/kg', conc: '2 mmol/mL — NIE unverduennt' }, 10).mlLo === null);

/* Der Riegel muss GENAU die elf Eintraege treffen — nicht mehr. Wer ihn zu weit fasst,
 * nimmt der Station stumm die Milliliterzahlen weg, und das faellt keinem auf. */
const daten7 = laden('ui/app/anaes-data.js');
let mitKonz = 0, unterdrueckt = 0;
(daten7.drugs || []).forEach(function (m) {
  Object.keys(m.species || {}).forEach(function (a) {
    const s = m.species[a];
    if (!s || !s.conc) return;
    mitKonz++;
    if (dose.calc({ low: 1, high: 1, unit: 'mg/kg', conc: s.conc }, 10).mlLo === null) unterdrueckt++;
  });
});
ok('von ' + mitKonz + ' Eintraegen mit Konzentration sind genau 16 reine Stammloesungen',
  unterdrueckt === 16, 'gezaehlt: ' + unterdrueckt);
/* Am 18.08.2026 von 11 auf 16 gestiegen, und zwar OHNE dass eine Dosis geaendert wurde:
 * fuenf Eintraege waren dem Riegel bis dahin entgangen. magnesiumsulfat/hund fuehrt die
 * Stammloesung in ZWEI Einheiten ("500 mg/mL (50 %) = 4 mEq/mL") und wurde deshalb fuer
 * eine fertige Verduennung gehalten; bei lidocain_lok/maus+ratte und fentanyl/maus+ratte
 * hatte eine alte Feldkappung das Verduennungsziel abgeschnitten. Wer diese Zahl senkt,
 * muss sagen, WELCHER Eintrag wieder rechnen darf und warum. */

/* Beide Rechenwege muessen dasselbe sagen: ui/engine/dose.js (PDF-Weg) und der Block in
 * ui/app/index.html (Bildschirm). Am 13.08.2026 lag ekg-analyse.js zweimal und die Bruecke
 * lief auf der toten Kopie — derselbe Fehler waere hier unsichtbar. */
const htmlQuelle = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
ok('index.html kennt konzentrationNurStamm()', /function\s+konzentrationNurStamm\s*\(/.test(htmlQuelle));
ok('index.html setzt mL bei Stammloesung auf null', /if\s*\(\s*nurStamm\s*\)\s*\{\s*mlLo\s*=\s*null/.test(htmlQuelle));
ok('index.html sagt dem Anwender WARUM keine Zahl kommt', htmlQuelle.indexOf('erst nach Verd') > 0);

/* ================================================================================
 * 8) OHNE GEWICHT KEINE ZAHL - AUCH AUF DEM ZWEITEN RECHENWEG
 * ================================================================================
 * Befund 18.08.2026, im laufenden Browser gemessen. Zwei Loecher in derselben Sperre:
 *
 *   a) Der Gewichtseingang setzte die Marke bedingungslos:
 *        state.wt=(v>0?v:0); state.wtGesetzt=true;
 *      Wer das Feld LEERT, um ein neues Gewicht zu tippen, hatte danach wt=0 bei gesetzter
 *      Marke. Gemessen: Propofol zeigte "0 mg, 0 mL". Eine Null ist eine Zahl, und sie ist
 *      falsch - der Leitsatz verlangt an dieser Stelle Schweigen.
 *
 *   b) Die Antagonisten-Ansicht (#injReversal) rechnet an calc() VORBEI: eigene Tabelle
 *      ANAES.reversal[].sp[art], Konzentration als blosse Zahl, eigener Rechenweg. Die
 *      Sperre aus doseLine() kannte sie deshalb gar nicht und zeigte auch ohne Gewicht
 *      Milligramm und Milliliter - fuer Atipamezol, Naloxon und Flumazenil, also genau die
 *      Mittel, die man im Zwischenfall greift.
 *
 * Diese Pruefungen sind Quelltextpruefungen, weil der zweite Rechenweg in einem IIFE-Block
 * von ui/app/index.html liegt und von aussen nicht aufrufbar ist. Blockkommentare werden
 * vorher entfernt - sonst bestaende die Pruefung an ihrer eigenen Beschreibung.
 */
console.log('\n8) Ohne Gewicht keine Zahl, auch in der Antagonisten-Ansicht:');
const htmlRoh = fs.readFileSync(path.join(WURZEL, 'ui/app/index.html'), 'utf8');
const htmlCode = htmlRoh.replace(/\/\*[\s\S]*?\*\//g, ' ');

ok('die Marke haengt an v>0, nicht am Ereignis',
  /state\.wtGesetzt\s*=\s*\(\s*v\s*>\s*0\s*\)/.test(htmlCode),
  'Sonst bleibt sie nach dem Leeren des Feldes stehen und die Karten zeigen 0 mg');
ok('das bedingungslose wtGesetzt=true kommt nicht mehr vor',
  htmlCode.indexOf('state.wtGesetzt=true; syncPatient()') < 0);
ok('die Antagonisten-Ansicht kennt die Sperre',
  /var\s+ohneG\s*=\s*!\s*state\.wtGesetzt/.test(htmlCode),
  'Sie rechnet an calc() vorbei und braucht deshalb eine eigene');
ok('und sagt statt der Zahl, was fehlt',
  /ohneG\s*\?\s*'<span class="dpill">Gewicht eintragen/.test(htmlCode));
ok('auch der Protokolltext der Antagonisten schweigt ohne Gewicht',
  /medRevText[\s\S]{0,400}?if\s*\(\s*!\s*state\.wtGesetzt\s*\)\s*return/.test(htmlCode),
  'Im Protokoll waere "0 mg" dauerhaft dokumentiert');

/* Der zweite Rechenweg darf nicht wieder unbemerkt entstehen: JEDE Stelle, die state.wt
 * multipliziert, muss im selben Ausdruck oder in derselben Funktion die Marke pruefen. */
const wtStellen = (htmlCode.match(/\bstate\.wt\b/g) || []).length;
ok('state.wt wird an ' + wtStellen + ' Stellen gelesen - jede davon ist eine Rechenstelle',
  wtStellen > 0);
const funktionenMitWt = [];
let reFn = /function\s+([A-Za-z0-9_$]+)\s*\(([^)]*)\)\s*\{/g, mFn;
while ((mFn = reFn.exec(htmlCode))) {
  const start = mFn.index, name = mFn[1];
  let tiefe = 0, k = htmlCode.indexOf('{', start), ende = k;
  for (; ende < htmlCode.length; ende++) {
    if (htmlCode[ende] === '{') tiefe++;
    else if (htmlCode[ende] === '}') { tiefe--; if (!tiefe) break; }
  }
  const rumpf = htmlCode.slice(start, ende + 1);
  if (/state\.wt\s*[*]|[*]\s*state\.wt/.test(rumpf) && !/state\.wtGesetzt/.test(rumpf)) funktionenMitWt.push(name);
}
ok('keine Funktion multipliziert mit state.wt, ohne die Marke zu pruefen',
  funktionenMitWt.length === 0,
  'ungeschuetzt: ' + funktionenMitWt.join(', '));

/* ================================================================================
 * 9) KEIN DATENFELD DARF MITTEN IM WORT ENDEN
 * ================================================================================
 * Befund 18.08.2026. 21 Felder in ui/app/anaes-data.js endeten mitten im Wort - der Schnitt
 * lag bei exakt 40 Zeichen (conc), 44 (route) und 90 (indication). Die Werte kamen bereits
 * so herein, mit Commit d4d246b (1.3.4, "Ratte, Maus, Hamster und Rennmaus als eigene
 * Tierarten"); das Importwerkzeug liegt nicht mehr im Baum.
 *
 * DAS WAR KEIN SCHOENHEITSFEHLER. adrenalin/maus trug
 *     "1 mg/mL (1:1000), fuer die Maus 1:100 ve"
 * Die Kappung hatte das Wort "verduennen" gefressen. Damit griff der Stammloesungs-Riegel
 * NICHT, und die App rechnete fuer die 25-g-Maus 0,00025 mL aus der UNVERDUENNTEN Loesung -
 * waehrend derselbe Text die Verduennung 1:100 verlangt. Eine Sicherung, die an einem
 * abgeschnittenen Wort scheitert, ist keine.
 *
 * Diese Pruefung sucht deshalb nicht nach einer festen Laenge (die naechste Kappung haette
 * eine andere), sondern nach dem Merkmal selbst: ein Textfeld, das auf einem Wortfragment
 * endet. Erkennungszeichen ist ein Feld, dessen letztes Zeichen ein Buchstabe ist UND das
 * mit einem angefangenen Klammerausdruck, Bindestrich oder Doppelpunkt endet, oder dessen
 * Klammern nicht aufgehen.
 */
console.log('\n9) Kein Datenfeld endet mitten im Wort:');
const datenRoh = fs.readFileSync(path.join(WURZEL, 'ui/app/anaes-data.js'), 'utf8');
const winD = {};
(new Function('window', datenRoh))(winD);
const felder = [];
(winD.ANAES.drugs || []).forEach(function (m) {
  Object.keys(m.species || {}).forEach(function (a) {
    const s = m.species[a];
    if (!s) return;
    ['conc', 'route', 'indication', 'notes', 'caution'].forEach(function (f) {
      if (typeof s[f] === 'string' && s[f]) felder.push({ wo: m.id + '/' + a + '.' + f, txt: s[f] });
    });
  });
});

/* a) Klammern muessen aufgehen - "5 mg/mL (0,5 %) (aus 20" faellt hier durch. */
const offeneKlammer = felder.filter(function (x) {
  let tiefe = 0;
  for (let i = 0; i < x.txt.length; i++) {
    if (x.txt[i] === '(') tiefe++;
    else if (x.txt[i] === ')') tiefe--;
    if (tiefe < 0) return true;
  }
  return tiefe !== 0;
});
ok(felder.length + ' Felder geprueft: alle Klammern gehen auf', offeneKlammer.length === 0,
  offeneKlammer.slice(0, 5).map(function (x) { return x.wo + ' "' + x.txt.slice(-40) + '"'; }).join(' | '));

/* b) Ein Feld darf nicht auf einem angefangenen Anschluss enden. "..., zur " und
 *    "... fuer die Maus 1:" und "... IV 5-" sind genau die drei Formen, die vorkamen. */
const abgeschnitten = felder.filter(function (x) { return /[-:,/]\s*$|\b(bzw|zur|auf|und|mit|aus|fuer|von|der|die|das)\s*$/i.test(x.txt); });
ok('kein Feld endet auf einem angefangenen Anschluss', abgeschnitten.length === 0,
  abgeschnitten.slice(0, 5).map(function (x) { return x.wo + ' "' + x.txt.slice(-40) + '"'; }).join(' | '));

/* c) Und die Stelle, an der es wirklich weh tat: jedes conc-Feld, das eine Verduennung
 *    verlangt, muss das Wort VOLLSTAENDIG enthalten - sonst greift der Riegel nicht. */
const halbesWort = felder.filter(function (x) {
  return x.wo.endsWith('.conc') && /\bve$|\bver$|\bverd$|\bverdu$|\bverdue$|\bverduen$/i.test(x.txt);
});
ok('kein conc-Feld endet auf einem angefangenen "verduennen"', halbesWort.length === 0,
  halbesWort.map(function (x) { return x.wo; }).join(', '));




console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
if (!fail) console.log('ALLE ' + pass + ' PRUEFUNGEN BESTANDEN');
process.exit(fail ? 1 : 0);
