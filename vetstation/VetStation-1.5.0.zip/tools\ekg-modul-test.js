'use strict';
/*
 * ekg-modul-test.js — Selbsttest des Diagnostik-EKG-Submoduls in ui/app/index.html.
 *
 * WARUM DIESER TEST SO GEBAUT IST:
 * Das Submodul laeuft im Browser und zeichnet auf eine Leinwand. In der Vorschau feuert
 * requestAnimationFrame NICHT (document.hidden), ein Bildschirmfoto beweist also nichts ueber
 * die RECHNUNG. Deshalb wird hier genauso verfahren wie in geraete-profil-test.js: die
 * Funktionen werden per Klammerzaehlung aus der HTML-Datei geholt, mit new Function gebaut und
 * dann wird MIT IHNEN GERECHNET. Ein Test, der nur nach Zeichenketten greppt, haette keinen der
 * Fehler gefunden, um die es hier geht (doppelte Element-Kennung, doppeltes dpr in der
 * Zeitbasis, falscher Startpunkt bei doc.lines, Ableitung II zweimal projiziert).
 *
 * Aufruf:  node tools/ekg-modul-test.js
 */
const fs = require('fs');
const path = require('path');

const DATEI = path.join(__dirname, '..', 'ui', 'app', 'index.html');
const src = fs.readFileSync(DATEI, 'utf8');

let gruen = 0, rot = 0;
function pruef(name, bedingung, zusatz) {
  if (bedingung) { gruen++; console.log('  ✓ ' + name); }
  else { rot++; console.log('  ✗ ' + name + (zusatz ? '   -> ' + zusatz : '')); }
}
function block(t) { console.log('\n== ' + t + ' =='); }

/* Holt eine Funktion per Klammerzaehlung heraus (vertraegt Klammern in Zeichenketten nicht
 * perfekt, reicht aber fuer diesen Quelltext und ist genau das Verfahren der uebrigen Tests). */
function holeFunktion(name) {
  const start = src.indexOf('function ' + name + '(');
  if (start < 0) return null;
  const auf = src.indexOf('{', start);
  if (auf < 0) return null;
  let tiefe = 0;
  for (let i = auf; i < src.length; i++) {
    const c = src[i];
    if (c === '{') tiefe++;
    else if (c === '}') { tiefe--; if (tiefe === 0) return src.slice(start, i + 1); }
  }
  return null;
}

// ---------------------------------------------------------------------------
block('1. Bausteine vorhanden');
const teile = ['ekgWave', 'proj', 'echtEkg', 'echtNaechster', 'advance', 'buildPDF', 'updateMeasures', 'renderSheet'];
teile.forEach((n) => pruef('Funktion ' + n + ' gefunden', !!holeFunktion(n)));
pruef('LEADS-Tabelle vorhanden', /var LEADS\s*=\s*\[/.test(src));
pruef('jsPDF wird geladen', /shared\/jspdf\.umd\.min\.js/.test(src));
pruef('ekg-analyse wird geladen', /shared\/ekg-analyse\.js/.test(src));

// ---------------------------------------------------------------------------
block('2. Element-Kennungen sind eindeutig');
/* Der Fehler, den nur der echte Klick zeigte: Knopf und Ansicht hiessen beide "ekgPdf",
 * $('#ekgPdf') traf den Knopf und die PDF-Ansicht ging nie auf. */
/* NUR die AUSZEICHNUNG zaehlen. Dieselben Kennungen stehen zusaetzlich in einer
 * JS-Zeichenkette (rebuildSide baut die Seitenleiste neu auf) — das ist zur Laufzeit
 * KEIN Duplikat, weil der Inhalt ersetzt wird. Ein Test, der beides zaehlt, meldet einen
 * Fehler, den es nicht gibt; genau das ist beim ersten Lauf passiert. */
const ohneSkript = src.replace(/<script[\s\S]*?<\/script>/g, '');
const ids = [];
const reId = /\bid="([A-Za-z0-9_-]+)"/g;
let m;
while ((m = reId.exec(ohneSkript))) ids.push(m[1]);
const doppelt = {};
ids.forEach((i) => { doppelt[i] = (doppelt[i] || 0) + 1; });
const mehrfach = Object.keys(doppelt).filter((k) => doppelt[k] > 1);
pruef('keine doppelte id in der Auszeichnung', mehrfach.length === 0, 'doppelt: ' + mehrfach.join(', '));
['ekgOverlay', 'ekgCanvas', 'ekgStripCv', 'ekgPdf', 'ekgPdfView', 'mHr', 'ekgDx'].forEach((i) =>
  pruef('id ' + i + ' genau einmal ausgezeichnet', doppelt[i] === 1, 'Anzahl ' + (doppelt[i] || 0)));
// Der Oeffnen-Knopf wird zur Laufzeit erzeugt, steht also NICHT in der Auszeichnung.
pruef('Oeffnen-Knopf wird im Skript mit fester Kennung erzeugt', /btn\.id\s*=\s*'ekgOpenBtn'/.test(src));
pruef('und vorher gegen doppeltes Einhaengen geprueft', /if\(\$\('#ekgOpenBtn'\)\)\s*return true;/.test(src));

// ---------------------------------------------------------------------------
block('3. Ableitungen nach Einthoven/Goldberger');
const LEADS = (function () {
  const s = src.indexOf('var LEADS');
  const e = src.indexOf('];', s);
  return new Function('return ' + src.slice(src.indexOf('[', s), e + 1))();
})();
const proj = new Function('return ' + holeFunktion('proj'))();
pruef('sechs Ableitungen', LEADS.length === 6, 'gefunden ' + LEADS.length);
pruef('Winkel I=0 II=60 III=120', LEADS[0].ang === 0 && LEADS[1].ang === 60 && LEADS[2].ang === 120);
pruef('Winkel aVR=-150 aVL=-30 aVF=90', LEADS[3].ang === -150 && LEADS[4].ang === -30 && LEADS[5].ang === 90);
const achse = 70;
const pII = proj(60, achse), pAVR = proj(-150, achse);
pruef('Ableitung II positiv bei Achse 70 Grad', pII > 0.9, 'pII=' + pII.toFixed(3));
pruef('aVR NEGATIV (gespiegelt) - das Kennzeichen eines richtig abgeleiteten EKG', pAVR < -0.5, 'pAVR=' + pAVR.toFixed(3));
pruef('aVR ist etwa das Gegenteil von II', Math.abs(pII + pAVR) < 0.35, 'Summe=' + (pII + pAVR).toFixed(3));

// ---------------------------------------------------------------------------
block('4. Zeitbasis - mm/s muss auf dem Papier STIMMEN');
/* Der Fehler in der ersten Fassung: pxPerSec = mp * speed * dpr, obwohl mp bereits
 * Geraetepixel je Millimeter ist (2,2*dpr). Der Vorschub war damit um den Geraetefaktor
 * zu schnell - bei dpr 2 doppelt. Aus "25 mm/s" wurden 50. */
const advSrc = holeFunktion('advance');
pruef('advance rechnet pxPerSec = mp * M.speed (ohne zusaetzliches dpr)',
  /var pxPerSec\s*=\s*mp\s*\*\s*M\.speed\s*;/.test(advSrc), 'gefunden: ' + (advSrc.match(/var pxPerSec[^;]*;/) || [''])[0]);
pruef('colT ist der Kehrwert von pxPerSec', /var colT\s*=\s*1\s*\/\s*pxPerSec\s*;/.test(advSrc));
pruef('Abtastrate wird fuer Ausdruck/Auswertung gemerkt (M.hz)', /M\.hz\s*=\s*pxPerSec/.test(advSrc));
// Gegenrechnung: 1 s Signal muss genau M.speed Millimeter breit werden.
const mmPxSrc = holeFunktion('mmPx');
const mmPx = new Function('M', 'return (' + mmPxSrc + ')();').bind(null, { dpr: 2 });
const pxProMm = mmPx();
[25, 50].forEach((sp) => {
  const pxProSek = pxProMm * sp;
  const mmProSek = pxProSek / pxProMm;
  pruef('bei ' + sp + ' mm/s ergibt 1 s genau ' + sp + ' mm', Math.abs(mmProSek - sp) < 1e-9, 'gerechnet ' + mmProSek);
});

// ---------------------------------------------------------------------------
block('5. Echtes Signal hat Vorrang und wird NICHT verfaelscht');
pruef('advance fragt zuerst echtEkg()', /var base\s*,\s*ech\s*=\s*echtEkg\(\)/.test(advSrc));
pruef('nur ohne echtes Signal wird synthetisiert', /else\s*\{[\s\S]*ekgWave\(/.test(advSrc));
pruef('Ableitung II wird bei echtem Signal NICHT projiziert',
  /if\s*\(\s*ech\s*&&\s*LEADS\[li\]\.id\s*===\s*'II'\s*\)\s*mv\s*=\s*base/.test(advSrc));
pruef('Rauschen wird einem ECHTEN Streifen nicht hinzugefuegt',
  /if\(\s*!ech\s*&&\s*!M\.musk/.test(advSrc));
pruef('Rhythmusstreifen nimmt bei echt ebenfalls den Messwert',
  /var mvII\s*=\s*ech\s*\?\s*base\s*:/.test(advSrc));

const echtNaechsterSrc = holeFunktion('echtNaechster');
pruef('unbekannte Verstaerkung => KEINE mV-Behauptung (M.kal=false)',
  /M\.kal\s*=\s*false/.test(echtNaechsterSrc));
pruef('bekannte Verstaerkung => Umrechnung uV/mV',
  /\/mv\/i\.test\(eh\)\s*\?\s*1\s*:\s*0\.001/.test(echtNaechsterSrc));
pruef('echter Streifen laeuft mit SEINER Abtastrate',
  /M\.ePos\s*=\s*\(M\.ePos\s*\+\s*hz\s*\*\s*colT\)/.test(echtNaechsterSrc));

// Rechnung: 500 uV bei skala 1, Einheit uV -> 0,5 mV
const echtNaechster = new Function('M', 'return ' + echtNaechsterSrc + ';')({ ePos: 0, echt: false, kal: false });
const M1 = { ePos: 0, echt: false, kal: false };
const fnMitM = new Function('M', 'return ' + echtNaechsterSrc + ';')(M1);
const mv = fnMitM({ samples: [500, 500, 500, 500, 500], hz: 256, skala: 1, einheit: 'uV' }, 1 / 256);
pruef('500 uV (skala 1) werden zu 0,5 mV', Math.abs(mv - 0.5) < 1e-9, 'gerechnet ' + mv);
pruef('dabei wird als kalibriert vermerkt', M1.kal === true && M1.echt === true);
const M2 = { ePos: 0, echt: false, kal: false };
const fn2 = new Function('M', 'return ' + echtNaechsterSrc + ';')(M2);
fn2({ samples: [500, 500, 500, 500, 500], norm: [0.5, 0.5, 0.5, 0.5, 0.5], hz: 256 }, 1 / 256); // ohne skala
pruef('ohne skala/einheit wird NICHT kalibriert behauptet', M2.kal === false && M2.echt === true);

// ---------------------------------------------------------------------------
block('6. PDF - massstabsgetreu und vektoriell');
const pdfSrc = holeFunktion('buildPDF');
pruef('A4 quer', /orientation:\s*'landscape'/.test(pdfSrc) && /format:\s*'a4'/.test(pdfSrc));
pruef('Einheit Millimeter (sonst ist jede Skala Zufall)', /unit:\s*'mm'/.test(pdfSrc));
pruef('Raster zeichnet 1-mm-Linien', /for\(i=0;i<=w\+0\.01;i\+=1\)/.test(pdfSrc));
pruef('Raster zeichnet 5-mm-Linien', /i\+=5/.test(pdfSrc));
pruef('Amplitude = mV * M.gain (mm)', /v\s*\*\s*M\.gain/.test(pdfSrc));
pruef('Zeitfenster folgt der Breite: n = w / speed * hz', /Math\.round\(w\/M\.speed\*hz\)/.test(pdfSrc));
pruef('doc.lines startet auf dem ERSTEN Kurvenpunkt, nicht auf der Bahnmitte',
  /doc\.lines\(pts,\s*x,\s*startY/.test(pdfSrc));
pruef('Kalibrierimpuls ist so hoch wie die Verstaerkung', /amp\s*=\s*Math\.min\(M\.gain/.test(pdfSrc));
pruef('Herkunft der Kurve steht auf dem Blatt (gemessen vs nachgebildet)',
  /NACHGEBILDET/.test(pdfSrc) && /Gemessenes Ger/.test(pdfSrc));
pruef('Latin-1-Filter wird angewendet (jsPDF kann kein Tiefgestellt)', /doc\.text=function\(\)\{[^}]*pdfSan/.test(pdfSrc));

// ---------------------------------------------------------------------------
block('7. Fern: KEIN eigener Uebertragungsweg (bewusste Entscheidung)');
/*
 * Der Ausdruck ist fern verfuegbar, weil die Web-App dasselbe Modul traegt und den Streifen
 * ueber den GEREGELTEN kurven-Pfad ohnehin bekommt. Ein eigener Zweig waere von den Regeln
 * zwar erlaubt (das .write kaskadiert, ohne .validate gilt "erlaubt") — aber voellig
 * ungedeckelt. Diese Pruefungen halten fest, dass hier nichts zurueckgebaut wird.
 */
pruef('kein Sendeknopf mehr in der Auszeichnung', !/id="pdfSendBtn"/.test(src));
pruef('keine Funktion sendePdfFern', !/function sendePdfFern/.test(src));
/* Auf den AUFRUF pruefen, nicht auf das Wort: der Pfad wird im Quelltext ausdruecklich
 * erwaehnt, um zu begruenden, warum es ihn NICHT gibt. Eine Zeichenkettensuche wuerde
 * genau diese Begruendung als Fehler melden. */
pruef('kein fetch auf einen eigenen EKG-Endpunkt', !/fetch\(\s*['"][^'"]*ekg-streifen/.test(src));
pruef('das fertige PDF wird NICHT in die Cloud geschoben',
  !/output\('datauristring'\)/.test(src));
pruef('die Entscheidung ist im Quelltext begruendet',
  /KEINE EINZIGE Groessengrenze/.test(src) && /12000/.test(src));
pruef('Hinweis fuer den Benutzer steht im PDF-Kopf', /id="pdfFernNote"/.test(src));

// ---------------------------------------------------------------------------
block('8. Das Fenster stoert den Monitor nicht');
pruef('eigener Schlagzaehler (M.beatN), nicht mon.beatN', /M\.beatN/.test(advSrc) && !/\bmon\.beatN/.test(advSrc));
pruef('ekgWave bekommt den Zaehler UEBERGEBEN', /function ekgWave\(ph,W,beatN\)/.test(src));
pruef('Zugriff auf den Monitor nur lesend ueber __ekgFeed', /window\.__ekgFeed\s*=\s*function/.test(src));
pruef('__ekgFeed reicht den echten Kanal durch', /real:\(mon\.real&&mon\.real\.ekg\)/.test(src));
pruef('Oeffnen-Knopf traegt NICHT die Klasse mon-mode (sonst ueberschreibt der Cockpit-Aufbau den Handler)',
  /btn\.className\s*=\s*'ekg-launch'/.test(src));
pruef('Knopf haengt per addEventListener, nicht per onclick', /btn\.addEventListener\('click',openEkg\)/.test(src));
pruef('Esc raeumt erst die PDF-Ansicht ab, dann das Fenster',
  /if\(\$\('#ekgPdfView'\)&&\$\('#ekgPdfView'\)\.classList\.contains\('open'\)\)\{ closePDF\(\); return; \}/.test(src));

// ---------------------------------------------------------------------------
block('9. __setRealWave fuehrt die Kalibrierung mit');
const swSrc = src.slice(src.indexOf('window.__setRealWave'), src.indexOf('window.__setDeviceAlarms'));
pruef('Rohwerte werden mitgefuehrt', /samples:ch\.samples/.test(swSrc));
pruef('skala wird mitgefuehrt', /skala:ch\.skala/.test(swSrc));
pruef('einheit wird mitgefuehrt', /einheit:ch\.einheit/.test(swSrc));
pruef('norm bleibt erhalten (realVal der Monitorbahn haengt daran)', /norm:norm/.test(swSrc));

// ---------------------------------------------------------------------------
block('10. Die Kalibrierung ueberlebt die GANZE Kette');
/*
 * Der gefaehrlichste Befund dieser Runde: die mV-Kalibrierung im EKG-Fenster war TOTER CODE.
 * ui/vetstation-live.js baute nur { hz, samples } — skala wurde abgeschnitten; und 'einheit'
 * kam in der ganzen Bridge nicht vor (model.js ist eine Positivliste). M.kal waere damit
 * IMMER false gewesen: die Kurve laeuft, sieht richtig aus, und der Ausdruck ist nie
 * kalibriert. Diese drei Pruefungen halten die Kette zusammen.
 */
const liveSrc = fs.readFileSync(path.join(__dirname, '..', 'ui', 'vetstation-live.js'), 'utf8');
const modelSrc = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'model.js'), 'utf8');
pruef('Shell reicht skala an __setRealWave weiter', /map\[lane\]\s*=\s*\{[^}]*skala:\s*kd\.skala/.test(liveSrc));
pruef('Shell reicht einheit weiter', /map\[lane\]\s*=\s*\{[^}]*einheit:\s*kd\.einheit/.test(liveSrc));
pruef('model.js fuehrt einheit am Kurvenkanal (Positivliste!)', /einheit:\s*k\.einheit\s*\?/.test(modelSrc));
pruef('model.js nimmt uV an, wenn eine Skala da ist', /\(num\(k\.skala\)\s*\?\s*'uV'\s*:\s*null\)/.test(modelSrc));
pruef('model.js deckelt weiterhin auf 4 Kanaele', /slice\(0,\s*4\)/.test(modelSrc));
pruef('model.js deckelt weiterhin auf 512 Werte', /slice\(0,\s*512\)/.test(modelSrc));

// ---------------------------------------------------------------------------
console.log('\n' + (rot === 0
  ? 'ALLE ' + gruen + ' PRUEFUNGEN BESTANDEN'
  : rot + ' FEHLGESCHLAGEN von ' + (gruen + rot)));
process.exit(rot === 0 ? 0 : 1);
