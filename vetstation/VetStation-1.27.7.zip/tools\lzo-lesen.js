'use strict';
/*
 * lzo-lesen.js — die .lzo-Protokollrollen der Mindray-Geraete auspacken.   (30.08.2026)
 *
 * ==========================================================================================
 * WARUM ES DIESE DATEI GIBT
 * ==========================================================================================
 * Der Service-Export des Veta 5 Plus enthaelt neben der aktuellen `systemLog.log` bis zu zehn
 * aeltere Abschnitte als `systemLog.log.1.lzo` ... `.10.lzo`, dazu dasselbe fuer sys.log,
 * vpmLog.log und FrontGuiOperation.log. Zusammen rund 6 MB gepackt - ein Vielfaches dessen,
 * was bisher gelesen wurde. Darin steht die Vorgeschichte des Geraets: jede fruehere
 * Kopplung, jeder Werkstattbesuch, jeder Handschlag, der geglueckt ist.
 *
 * Auf diesem Rechner gibt es KEIN lzop, kein 7z, kein lzcat (nachgesehen). Und npm-Pakete
 * sind hier ausgeschlossen (Projektregel: reines ES5/Node ohne Abhaengigkeiten, der Praxis-PC
 * hat kein npm). Also wird der Entpacker selbst gebaut.
 *
 * WAS HIER UMGESETZT IST:
 *   - Der lzop-Dateikopf (Magic 89 4c 5a 4f 00 0d 0a 1a 0a, Version, Methode, Name, Pruefsumme)
 *   - LZO1X-Dekompression. Das Verfahren ist offen dokumentiert und seit 1996 unveraendert;
 *     der Dekomprimierer ist klein und vollstaendig durch das Format bestimmt - hier wird
 *     nichts geraten.
 *
 * WAS NICHT UMGESETZT IST: Komprimieren. Wird nicht gebraucht, und was man nicht braucht,
 * baut man nicht.
 *
 * GEGENPROBE: Das lzop-Format traegt je Block die Laenge der ausgepackten Daten UND eine
 * Adler32-Pruefsumme. Beides wird geprueft. Ein Entpacker, der falsch liegt, faellt damit
 * auf, statt stillen Unsinn zu liefern - genau die Sorte Fehler, die dieses Projekt sonst
 * teuer bezahlt.
 *
 * Aufruf:
 *   node tools/lzo-lesen.js <datei.lzo> [ziel.txt]
 *   node tools/lzo-lesen.js --ordner <verzeichnis>     (alle .lzo darin, je eine .txt daneben)
 */
const fs = require('fs');
const path = require('path');

/* ------------------------------------------------------------------------------------------
 * LZO1X-Dekompression.
 *
 * Das Format arbeitet mit zwei Sorten Anweisungen: "nimm N Bytes woertlich" und "kopiere N
 * Bytes, die D Stellen weiter vorn schon einmal standen". Die Kodierung der Laengen ist
 * gestuft - kleine Werte stecken im Befehlsbyte, groessere folgen als Nullbytes plus Rest.
 *
 * Die Sonderfaelle (t < 16 am Anfang, die drei Rueckwaertsabstands-Klassen, der Zustand
 * "letzter Literallauf" der die naechste Anweisung veraendert) sind KEINE Freiheiten - sie
 * stehen so im Format. Wer einen davon weglaesst, bekommt Daten, die stellenweise richtig
 * aussehen. Deshalb die Pruefsumme.
 * ---------------------------------------------------------------------------------------- */
function lzo1xEntpacken(ein, ausLaenge) {
  /*
   * Woertliche Umsetzung des Referenzverfahrens (lzo1x_decompress). Die Sprungmarken des
   * Originals sind hier Zustaende - so bleibt die Reihenfolge nachpruefbar. Mein erster
   * Entwurf hat die Zustandsfolge selbst 'sinngemaess' nachgebaut und lieferte prompt
   * 'Rueckwaertsbezug vor den Anfang': bei einem Format mit vier Sonderfaellen ist
   * sinngemaess dasselbe wie falsch.
   */
  const aus = Buffer.alloc(ausLaenge);
  let ip = 0, op = 0, t = 0, m = 0;
  const LIT = function (n) { for (let i = 0; i < n; i++) aus[op++] = ein[ip++]; };
  const W = function () { const w = ein[ip] | (ein[ip + 1] << 8); ip += 2; return w; };
  let ziel;

  if (ein[ip] > 17) {
    t = ein[ip++] - 17;
    if (t < 4) ziel = 'match_next';
    else { LIT(t); ziel = 'first_literal_run'; }
  } else ziel = 'top';

  for (;;) {
    if (ziel === 'top') {
      t = ein[ip++];
      if (t >= 16) { ziel = 'match'; continue; }
      if (t === 0) { while (ein[ip] === 0) { t += 255; ip++; } t += 15 + ein[ip++]; }
      LIT(t + 3);
      ziel = 'first_literal_run'; continue;
    }
    if (ziel === 'first_literal_run') {
      t = ein[ip++];
      if (t >= 16) { ziel = 'match'; continue; }
      m = op - (1 + 0x0800) - (t >> 2) - (ein[ip++] << 2);
      aus[op++] = aus[m++]; aus[op++] = aus[m++]; aus[op++] = aus[m];
      ziel = 'match_done'; continue;
    }
    if (ziel === 'match') {
      if (t >= 64) {
        m = op - 1 - ((t >> 2) & 7) - (ein[ip++] << 3);
        t = (t >> 5) - 1;
      } else if (t >= 32) {
        t &= 31;
        if (t === 0) { while (ein[ip] === 0) { t += 255; ip++; } t += 31 + ein[ip++]; }
        m = op - 1 - (W() >> 2);
      } else if (t >= 16) {
        m = op - ((t & 8) << 11);
        t &= 7;
        if (t === 0) { while (ein[ip] === 0) { t += 255; ip++; } t += 7 + ein[ip++]; }
        m -= (W() >> 2);
        if (m === op) break;                 /* Endezeichen */
        m -= 0x4000;
      } else {
        m = op - 1 - (t >> 2) - (ein[ip++] << 2);
        aus[op++] = aus[m++]; aus[op++] = aus[m];
        ziel = 'match_done'; continue;
      }
      if (m < 0 || m >= op) throw new Error('Rueckwaertsbezug ausserhalb (m=' + m + ', op=' + op + ')');
      for (let i = 0; i < t + 2; i++) aus[op++] = aus[m++];
      ziel = 'match_done'; continue;
    }
    if (ziel === 'match_done') {
      t = ein[ip - 2] & 3;
      if (t === 0) { ziel = 'top'; continue; }
      ziel = 'match_next'; continue;
    }
    /* match_next */
    LIT(t);
    t = ein[ip++];
    ziel = 'match';
  }
  return aus.slice(0, op);
}

/* Adler32 - so prueft lzop den Block. */
function adler32(b) {
  let a = 1, s = 0;
  for (let i = 0; i < b.length; i++) { a = (a + b[i]) % 65521; s = (s + a) % 65521; }
  return ((s << 16) | a) >>> 0;
}

const MAGIC = Buffer.from([0x89, 0x4c, 0x5a, 0x4f, 0x00, 0x0d, 0x0a, 0x1a, 0x0a]);

function lzopLesen(pfad) {
  const b = fs.readFileSync(pfad);
  if (!b.slice(0, 9).equals(MAGIC)) throw new Error('kein lzop-Kopf');
  let p = 9;
  const version = b.readUInt16BE(p); p += 2;
  p += 2;                                   /* libVersion */
  if (version >= 0x0940) p += 2;            /* versionNeeded */
  const methode = b[p++];
  if (version >= 0x0940) p++;               /* level */
  const flags = b.readUInt32BE(p); p += 4;
  if (flags & 0x00000040) p += 4;           /* Filter */
  p += 4;                                   /* mode */
  p += 4;                                   /* mtime low */
  if (version >= 0x0940) p += 4;            /* mtime high */
  const namenLaenge = b[p++];
  p += namenLaenge;
  p += 4;                                   /* Kopf-Pruefsumme */

  const teile = [];
  let bloecke = 0;
  for (;;) {
    if (p + 4 > b.length) break;
    const roh = b.readUInt32BE(p); p += 4;
    if (roh === 0) break;                   /* Ende */
    const gepackt = b.readUInt32BE(p); p += 4;
    let pruefRoh = null, pruefGepackt = null;
    if (flags & 0x00000001) { pruefRoh = b.readUInt32BE(p); p += 4; }        /* Adler32 der Rohdaten */
    if (flags & 0x00000002) { p += 4; }                                       /* CRC32 der Rohdaten */
    if (gepackt < roh) {
      if (flags & 0x00000100) { pruefGepackt = b.readUInt32BE(p); p += 4; }   /* Adler32 gepackt */
      if (flags & 0x00000200) { p += 4; }
    }
    const stueck = b.slice(p, p + gepackt); p += gepackt;
    let aus;
    if (gepackt === roh) aus = stueck;                      /* unkomprimiert gespeichert */
    else aus = lzo1xEntpacken(stueck, roh);
    if (aus.length !== roh) throw new Error('Block ' + bloecke + ': ' + aus.length + ' statt ' + roh + ' Byte');
    if (pruefRoh != null && adler32(aus) !== pruefRoh) {
      throw new Error('Block ' + bloecke + ': Pruefsumme stimmt nicht');
    }
    teile.push(aus);
    bloecke++;
  }
  return { daten: Buffer.concat(teile), bloecke: bloecke, methode: methode };
}

function einzeln(quelle, ziel) {
  process.stdout.write(path.basename(quelle).padEnd(34));
  try {
    const r = lzopLesen(quelle);
    fs.writeFileSync(ziel, r.daten);
    console.log('OK  ' + r.bloecke + ' Bloecke, ' + r.daten.length + ' Byte  ->  ' + path.basename(ziel));
    return true;
  } catch (e) {
    console.log('FEHLER: ' + e.message);
    return false;
  }
}

const args = process.argv.slice(2);
if (args[0] === '--ordner' && args[1]) {
  const dir = args[1];
  const dateien = fs.readdirSync(dir).filter(function (f) { return /\.lzo$/i.test(f); }).sort();
  console.log('\n' + dateien.length + ' gepackte Rollen in ' + dir + '\n');
  let ok = 0;
  dateien.forEach(function (f) {
    if (einzeln(path.join(dir, f), path.join(dir, f.replace(/\.lzo$/i, '') + '.entpackt.txt'))) ok++;
  });
  console.log('\n' + ok + ' von ' + dateien.length + ' entpackt.');
} else if (args[0]) {
  einzeln(args[0], args[1] || (args[0].replace(/\.lzo$/i, '') + '.entpackt.txt'));
} else {
  console.log('Aufruf: node tools/lzo-lesen.js <datei.lzo> [ziel]   |   --ordner <verzeichnis>');
}
