'use strict';
/*
 * geraete-einrichtung-test.js — die Einrichtungs-Anleitung muss stimmig und vollstaendig sein.
 *
 * WARUM (31.08.2026): die Anleitung im Admin-Bereich nennt Passwoerter, IP-Adressen und Ports.
 * Eine falsche Zahl kostet den Tierarzt am Geraet Zeit - schlimmer als keine Anleitung. Der
 * Test haelt die Angaben gegen sich selbst und gegen den Geraetekatalog:
 *   - die PC-Adresse ist UEBERALL dieselbe (sonst schickt ein Geraet an die falsche Stelle)
 *   - jedes Geraet hat Schritte; die mit Passwort haben mindestens eins
 *   - der Port des Zweitmonitors (8830) und der Abfrageport (4601) stimmen mit
 *     bridge/src/geraetekatalog.js ueberein
 *   - der DataExportSwitch des Veta kommt vor (der eigentliche Anlass) samt Servicecode
 *   - die Datei wird von der Station geladen, aber NICHT in die oeffentliche Web-App gebaut
 *
 * Start: node tools/geraete-einrichtung-test.js
 */
const fs = require('fs');
const path = require('path');
const D = require(path.join(__dirname, '..', 'ui', 'shared', 'geraete-einrichtung.js'));

let ok = 0; const fehler = [];
function pruef(was, bed, zusatz) {
  if (bed) { ok++; console.log('  + ' + was); }
  else { fehler.push(was); console.log('  FEHLGESCHLAGEN: ' + was + (zusatz ? '  -> ' + zusatz : '')); }
}

console.log('\nVetStation - die Geraete-Einrichtung ist stimmig\n');

/* 1) Die PC-Adresse ist ueberall dieselbe. */
const pc = D.netz.pc;
pruef('die PC-Adresse ist gesetzt', /^\d+\.\d+\.\d+\.\d+$/.test(pc), pc);
const alleTexte = JSON.stringify(D);
/* Jede IP-artige Zahl im Text, die im 192.168.0-Netz liegt und auf .99 endet, muss der PC sein. */
const pcTreffer = (alleTexte.match(/192\.168\.0\.99/g) || []).length;
pruef('die PC-Adresse kommt in den Schritten mehrfach vor (Ziel der Geraete)', pcTreffer >= 3, pcTreffer + 'x');
/* Keine widersprechende zweite PC-Adresse: alle "Zieladresse/Server-IP"-Nennungen zeigen auf pc. */
const zielHinweise = (alleTexte.match(/(Zieladresse|Server-IP|Ziel = )[^"]*?(\d+\.\d+\.\d+\.\d+)/g) || []);
const falscheZiele = zielHinweise.filter(function (z) { return z.indexOf(pc) < 0; });
pruef('jede genannte Zieladresse zeigt auf den PC', falscheZiele.length === 0, falscheZiele.join(' | '));

/* 2) Jedes Geraet ist vollstaendig. */
['pc', 'monitor', 'narkose', 'zweitmonitor'].forEach(function (k) {
  const g = D[k];
  pruef(k + ': hat Namen, Adresse und Schritte', !!(g && g.name && g.schritte && g.schritte.length));
  if (g && g.passwoerter) {
    g.passwoerter.forEach(function (p) {
      pruef(k + ': Passwort "' + p.zweck + '" hat einen Code', !!(p.code && String(p.code).length >= 3), JSON.stringify(p));
    });
  }
});

/* 3) Der Anlass: der DataExportSwitch samt Servicecode. */
pruef('der DataExportSwitch des Veta kommt vor (der eigentliche Anlass)', /DataExportSwitch/.test(alleTexte));
pruef('das Servicekennwort 789789 steht dabei', /789789/.test(alleTexte));
pruef('das Systemkennwort 1234 des Veta steht dabei', /1234/.test(alleTexte));
pruef('die Monitor-Wartung 888888 steht dabei', /888888/.test(alleTexte));

/* 4) Ports stimmen mit dem Geraetekatalog ueberein. */
const kat = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'geraetekatalog.js'), 'utf8');
pruef('Port 8830 (Zweitmonitor) steht in der Anleitung UND im Katalog',
  /8830/.test(alleTexte) && /8830/.test(kat));
pruef('Port 4601 (Monitor-Abfrage) steht im Katalog', /4601/.test(kat));

/* 5) Die Station laedt die Datei, die Web-App NICHT. */
const idx = fs.readFileSync(path.join(__dirname, '..', 'ui', 'index.html'), 'utf8');
pruef('ui/index.html laedt shared/geraete-einrichtung.js', /geraete-einrichtung\.js/.test(idx));
const bau = fs.readFileSync(path.join(__dirname, 'web-app-bauen.js'), 'utf8');
pruef('web-app-bauen.js kopiert die Datei NICHT in die oeffentliche Web-App',
  bau.indexOf('geraete-einrichtung') < 0);

/* 6) admin.js zeigt den Reiter und ruft die Ansicht auf. */
const admin = fs.readFileSync(path.join(__dirname, '..', 'ui', 'views', 'admin.js'), 'utf8');
pruef('admin.js hat den Reiter "Geräte einrichten"', /Geräte einrichten/.test(admin));
pruef('admin.js ruft viewEinrichtung() auf', /viewEinrichtung\(\)/.test(admin) && /function viewEinrichtung/.test(admin));

/*
 * 7) Die uebrigen Geraete kommen AUS DEM KATALOG, nicht aus einer zweiten Abschrift.
 *
 * WARUM (31.08.2026, Wunsch "auch die anderen Monitore und Narkosegeraete"): der Katalog ist
 * die eine Quelle der Geraetefakten. Haette die Anleitung sie abgeschrieben, entstuenden zwei
 * Staende, die auseinanderlaufen, ohne dass es auffaellt - genau die Fehlerform, die dieses
 * Projekt schon dreimal getroffen hat. Der Test verlangt deshalb: die Anleitung LIEST, und
 * jedes anschliessbare Modell hat auch wirklich Schritte.
 */
const kat2 = require(path.join(__dirname, '..', 'bridge', 'src', 'geraetekatalog.js'));
const geraete = kat2.alle();
const relevant = geraete.filter(function (g) {
  return ['monitor', 'narkose', 'kombi'].indexOf(g.kategorie) >= 0;
});
pruef('der Katalog kennt Monitore UND Narkosegeraete', 
  relevant.filter(function (g) { return g.kategorie === 'monitor'; }).length >= 10 &&
  relevant.filter(function (g) { return g.kategorie === 'narkose'; }).length >= 5,
  relevant.length + ' Geraete');

/* Jedes Modell, das laut Katalog anschliessbar ist, MUSS Schritte haben - sonst zeigt die
 * Anleitung einen leeren Kasten und der Tierarzt steht am Geraet ohne Auskunft da. */
const ohneSchritte = relevant.filter(function (g) {
  const anbindbar = (g.wege || []).some(function (w) { return w.vorlage || w.richtung === 'geraet_sendet'; });
  if (!anbindbar) return false;
  return !(g.wege || []).some(function (w) { return (w.schritte || []).length > 0; });
});
pruef('jedes anschliessbare Modell hat Schritte', ohneSchritte.length === 0,
  ohneSchritte.map(function (g) { return g.id; }).join(', '));

/* Die Passwoerter stehen im KATALOG (auslesbar), nicht nur im Fliesstext. */
const mitPw = geraete.filter(function (g) { return (g.passwoerter || []).length; });
pruef('belegte Geraetepasswoerter stehen auslesbar im Katalog', mitPw.length >= 10, mitPw.length + ' Geraete');
mitPw.forEach(function (g) {
  const schlecht = (g.passwoerter || []).filter(function (p) { return !p.code || !p.zweck || String(p.code).length < 3; });
  pruef('Katalog ' + g.id + ': jedes Passwort hat Code und Zweck', schlecht.length === 0, JSON.stringify(schlecht));
});

/* Gegenprobe: die Passwoerter, die im Fliesstext der Schritte stehen, muessen auch im Feld
 * stehen - sonst ist das Feld unvollstaendig und die Anleitung zeigt weniger als das Handbuch. */
const IM_TEXT = { 'edan-im-serie': 'ABC', 'surgivet-advisor': 'ADVISOR', 'midmark-multiparameter': '2013',
  'mindray-umec12-vet': '888888', 'mindray-epm-n-serie': 'MIN888', 'mindray-wato-ex35-vet': '1234' };
Object.keys(IM_TEXT).forEach(function (id) {
  const g = kat2.nachId(id);
  const codes = ((g && g.passwoerter) || []).map(function (p) { return p.code; });
  pruef('im Text genanntes Passwort steht auch im Feld: ' + id, codes.indexOf(IM_TEXT[id]) >= 0,
    'erwartet ' + IM_TEXT[id] + ', gefunden ' + codes.join('/'));
});

/* Die Auskunftsroute reicht die Passwoerter durch - sonst zeigt die Oberflaeche nichts. */
const srv = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'src', 'server.js'), 'utf8');
pruef('/api/katalog reicht die Passwoerter durch', /passwoerter:\s*g\.passwoerter/.test(srv));

/* Die Oberflaeche liest den Katalog wirklich (statt eine Kopie zu zeigen). */
pruef('admin.js laedt den Katalog fuer die uebrigen Geraete',
  /function ladeWeitereGeraete/.test(admin) && /api\/katalog/.test(admin));
pruef('admin.js holt die Schritte je Modell vom Server (echte Zahlen dieses PCs)',
  /function zeigeSchritte/.test(admin) && /api\/katalog\/geraet/.test(admin));
pruef('die Anleitung hat einen Platz fuer die uebrigen Geraete', /vs-weitere/.test(admin));

console.log('');
if (fehler.length) {
  console.log('FEHLGESCHLAGEN (' + fehler.length + ' von ' + (ok + fehler.length) + ')');
  process.exit(1);
}
console.log('ALLE ' + ok + ' PRUEFUNGEN BESTANDEN');
