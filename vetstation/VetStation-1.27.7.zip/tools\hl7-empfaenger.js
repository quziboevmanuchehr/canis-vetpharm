'use strict';
/*
 * hl7-empfaenger.js — faengt den HL7-Datenexport des Veta 5 Plus ein, egal auf welchem Port.
 *                                                                       (31.08.2026)
 *
 * ==========================================================================================
 * WARUM ES DIESE DATEI GIBT - DIE WENDE
 * ==========================================================================================
 * Am Veta gibt es im Service-Menue unter "DatenExport Klinik" einen "DataExportSwitch". Er
 * stand die ganze Zeit AUS. Angeschaltet sendet das Geraet seine Beatmungswerte als HL7 -
 * UNVERSCHLUESSELT, nach dem oeffentlich dokumentierten Mindray A-Series Export Protocol
 * (IHE PCD-01). Das ist ein voellig anderer Weg als der verschluesselte MD2-Kanal, an dem wir
 * tagelang gescheitert sind: HL7 ueber MLLP, mit genau der Rahmung, die bridge/src/adapters/
 * hl7.js schon liest (Start 0x0B, Ende 0x1C, dann 0x0D).
 *
 * Das Geraet ist der REPORTER: es verbindet sich zu einer Server-Adresse (unserem PC) und
 * schickt unaufgefordert - wie der Monitor auf 3502. Welchen Port es dabei ansteuert, ist im
 * Veta-Menue eingestellt und uns nicht sicher bekannt. Deshalb lauscht dieser Empfaenger auf
 * VIELEN Ports zugleich: der eingehende Verbindungsaufbau verraet den Port selbst.
 *
 * WAS ER TUT:
 *   - nimmt Verbindungen an, liest MLLP-Rahmen, parst das HL7 mit dem ECHTEN Stationsparser
 *   - zeigt je Rahmen die erkannten Vitalwerte UND jede unbekannte OBX-Kennung mit ihrem
 *     Klartext-Referenznamen (OBX-3.2) - so ist ein noch nicht zugeordneter Wert nicht
 *     verloren, sondern benannt
 *   - schneidet alles roh mit (data/veta-hl7-<zeit>.log), damit man es spaeter auswerten kann
 *
 * WAS ER NICHT TUT: ein Byte an das Geraet senden. Er hoert nur zu und quittiert im
 * Client-Sinn NICHT (der Export braucht keine Quittung; eine falsche Antwort waere das
 * Einzige, was hier schaden koennte).
 *
 * Aufruf:
 *   node tools/hl7-empfaenger.js [--von 192.168.0.52] [--ports 6600,7787,5900,...] [--minuten 15]
 *
 * Die laufende VetStation belegt einige Ports (4601, 5000, 8830, 3502, 2575, 8770, 8771).
 * Steuert der Veta einen davon an, faengt die STATION den Export bereits selbst - dieser
 * Empfaenger ist dann nur zur Bestaetigung da. Fuer den ersten Versuch die Station laufen
 * lassen; kommt nichts an, sie anhalten und diesen Empfaenger die belegten Ports mit abdecken
 * lassen.
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const { parseHL7Message } = require(path.join(__dirname, '..', 'bridge', 'src', 'adapters', 'hl7.js'));

const VT = 0x0b, FS = 0x1c, CR = 0x0d;

function argw(name, ersatz) {
  const i = process.argv.indexOf('--' + name);
  return (i > 0 && process.argv[i + 1]) ? process.argv[i + 1] : ersatz;
}

const VON = argw('von', '192.168.0.52');
const MINUTEN = Number(argw('minuten', 20)) || 20;

/* Ports, die ein Mindray-Geraet fuer HL7-Export plausibel ansteuert. 6600 taucht im
 * Veta-Betriebsbuch mehrfach auf; 2575 ist der IANA-HL7-Port; 5900/6543/7787 sind gaengige
 * Konfigurationswerte. Der Nutzer kann mit --ports eine eigene Liste geben, sobald das
 * Veta-Menue den eingestellten Port zeigt. */
const STANDARD_PORTS = [6600, 2575, 3502, 5900, 6543, 7787, 4700, 8888, 9100, 24105, 5100, 5000];
const eigene = argw('ports', null);
const PORTS = eigene ? eigene.split(',').map(function (s) { return Number(s.trim()); }).filter(Boolean)
                     : STANDARD_PORTS;

const ordner = path.join(__dirname, '..', 'data');
try { fs.mkdirSync(ordner, { recursive: true }); } catch (_) {}
const stempel = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const rohDatei = path.join(ordner, 'veta-hl7-' + stempel + '.log');

let rahmen = 0, verbindungen = 0;
const unbekannt = {};

function protokoll(z) { console.log(z); try { fs.appendFileSync(rohDatei, z + '\n'); } catch (_) {} }

function verarbeite(text, quelle, lokalPort) {
  rahmen++;
  let frame;
  try {
    frame = parseHL7Message(text, { deviceId: 'veta5-hl7', model: 'Veta 5 Plus', role: 'anesthesia' },
      function (code, beispiel) { unbekannt[code] = (unbekannt[code] || 0) + 1; });
  } catch (e) { protokoll('  Parse-Fehler: ' + e.message); return; }
  const v = (frame && frame.vitals) || {};
  const zahlen = {};
  Object.keys(v).forEach(function (k) { if (typeof v[k] === 'number') zahlen[k] = v[k]; });
  protokoll('\n*** HL7 vom Veta ***  ' + quelle + ' -> lokal ' + lokalPort + '   Rahmen ' + rahmen);
  protokoll('  Werte: ' + (Object.keys(zahlen).length ? JSON.stringify(zahlen) : '(keine Zahl erkannt)'));
  /* Die erste HL7-Zeile (MSH) zeigt Typ und Fassung. */
  protokoll('  MSH:   ' + (String(text).split(/[\r\n]/)[0] || '').slice(0, 80));
  try { fs.appendFileSync(rohDatei, '  ROH: ' + Buffer.from(text, 'latin1').toString('hex') + '\n'); } catch (_) {}
}

function server(port) {
  const s = net.createServer(function (sock) {
    const von = sock.remoteAddress || '';
    if (von.indexOf(VON) < 0) { sock.destroy(); return; }   /* nur der Veta */
    verbindungen++;
    protokoll('\n=== Verbindung vom Veta auf Port ' + port + ' (von ' + von + ':' + sock.remotePort + ') ===');
    let buf = Buffer.alloc(0);
    sock.on('data', function (b) {
      buf = Buffer.concat([buf, b]);
      let start;
      while ((start = buf.indexOf(VT)) !== -1) {
        const ende = buf.indexOf(FS, start + 1);
        if (ende === -1) break;
        const nutz = buf.slice(start + 1, ende).toString('latin1');
        buf = buf.slice(ende + 2);
        verarbeite(nutz, von + ':' + sock.remotePort, port);
      }
      if (buf.length > (1 << 20)) buf = Buffer.alloc(0);
    });
    sock.on('error', function () {});
    sock.on('close', function () { protokoll('  (Verbindung auf ' + port + ' getrennt)'); });
  });
  s.on('error', function (e) {
    if (e && e.code === 'EADDRINUSE') console.log('  Port ' + port + ' belegt (VetStation?) - faellt hier weg, die Station faengt ihn ggf. selbst');
  });
  s.listen(port, '0.0.0.0', function () { console.log('  hoere auf TCP ' + port); });
  return s;
}

console.log('\nVetStation - HL7-Empfaenger fuer den Datenexport des Veta 5 Plus\n');
console.log('  erwartet von:  ' + VON);
console.log('  Ports:         ' + PORTS.join(', '));
console.log('  Laufzeit:      ' + MINUTEN + ' Minuten');
console.log('  Mitschnitt:    ' + rohDatei);
console.log('');
console.log('  Am Veta muss "DatenExport Klinik" -> DataExportSwitch auf EIN stehen,');
console.log('  und die Zieladresse/Server-IP auf 192.168.0.99. Es wird NICHTS gesendet.');
console.log('');

const server_ = PORTS.map(server);

setTimeout(function () {
  console.log('\n---------------------------------------------------------------');
  console.log('  Verbindungen vom Veta: ' + verbindungen + '   HL7-Rahmen: ' + rahmen);
  const u = Object.keys(unbekannt);
  if (u.length) {
    console.log('  Noch nicht zugeordnete OBX-Kennungen (mit Beispielhaeufigkeit):');
    u.slice(0, 40).forEach(function (k) { console.log('    ' + k + '  (' + unbekannt[k] + 'x)'); });
    console.log('  -> diese Codes gehoeren in CODE_MAP (bridge/src/adapters/hl7.js).');
  }
  if (!verbindungen) {
    console.log('\n  KEINE Verbindung vom Veta.');
    console.log('  Pruefen: DataExportSwitch EIN? Zieladresse = 192.168.0.99? Welcher Port steht');
    console.log('  im Veta-Menue? Ihn mit --ports <nummer> hier abdecken.');
  } else {
    console.log('\n  Mitschnitt: ' + rohDatei);
  }
  server_.forEach(function (s) { try { s.close(); } catch (_) {} });
  process.exit(0);
}, MINUTEN * 60000);
