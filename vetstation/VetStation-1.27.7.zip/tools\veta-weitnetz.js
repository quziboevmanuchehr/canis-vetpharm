'use strict';
/*
 * veta-weitnetz.js — faengt eine eingehende Verbindung des Veta auf BELIEBIGEM Port.
 *                                                                       (01.09.2026)
 *
 * WARUM ES DIESES WERKZEUG GIBT:
 * Der HL7-Datenexport des Veta ist ein PUSH: das Geraet verbindet sich zu uns. Welchen Port
 * es dabei ansteuert, steht in seinem Menue und war am 01.09. nicht ablesbar. tools/
 * hl7-empfaenger.js deckt zwoelf plausible Ports ab, die Station neun weitere - wenn der
 * eingestellte Port keiner davon ist, klopft das Geraet an eine geschlossene Tuer, und wir
 * sehen NICHTS. Ein geschlossener Port erzeugt keinen Eintrag, keine Meldung, keine Spur:
 * die Suche scheitert dann genau so aussagelos wie ein falsch eingestellter Schalter, und
 * beide Faelle sehen von hier aus gleich aus.
 *
 * Deshalb dieses Werkzeug: es bindet SEHR VIELE Ports gleichzeitig und meldet, sobald von der
 * Geraeteadresse irgendwo eine Verbindung eingeht - mitsamt der Portnummer. Damit ist die
 * Frage "sendet er nicht" von "wir hoeren an der falschen Stelle" sauber zu trennen.
 *
 * ES SENDET NICHTS. Es nimmt an, liest mit, schreibt roh weg. Kein Byte geht hinaus.
 *
 * Warum das gefahrlos ist: ein lauschender Port ist passiv. Das Geraet wird dadurch weder
 * angesprochen noch belastet - anders als bei einem Suchlauf mit Ping-Schwall, der am
 * 01.09.2026 zu Recht Sorge ausgeloest hat (Medizingeraete haben kleine Netzwerkstapel).
 *
 * Aufruf:
 *   node tools/veta-weitnetz.js [--von 192.168.0.52] [--minuten 20] [--bis 20000]
 */
const net = require('net');
const fs = require('fs');
const path = require('path');

function arg(name, ersatz) {
  const i = process.argv.indexOf('--' + name);
  return (i > 0 && process.argv[i + 1]) ? process.argv[i + 1] : ersatz;
}

const VON = arg('von', '192.168.0.52');
const MINUTEN = Number(arg('minuten', 20)) || 20;
const BIS = Number(arg('bis', 20000)) || 20000;
const AB = Number(arg('ab', 1024)) || 1024;

const ordner = path.join(__dirname, '..', 'data');
try { fs.mkdirSync(ordner, { recursive: true }); } catch (_) {}
const stempel = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const datei = path.join(ordner, 'veta-weitnetz-' + stempel + '.log');

/* Ports, die andere Programme schon halten (Station, Windows), lassen sich nicht binden.
 * Das ist kein Fehler - sie werden nur gezaehlt. Die Station hoert dort ohnehin selbst. */
let gebunden = 0, belegt = 0, verweigert = 0;
const server = [];
let treffer = 0;

function merke(z) {
  console.log(z);
  try { fs.appendFileSync(datei, z + '\n'); } catch (_) {}
}

function binde(port) {
  const s = net.createServer(function (sock) {
    const von = sock.remoteAddress || '';
    /* Nur das Geraet interessiert. Alles andere sofort schliessen, ohne ein Byte. */
    if (von.indexOf(VON) < 0) { sock.destroy(); return; }
    treffer++;
    merke('\n*** TREFFER *** ' + new Date().toLocaleTimeString()
      + '   Der Veta verbindet sich auf PORT ' + port + '  (von ' + von + ':' + sock.remotePort + ')');
    let roh = Buffer.alloc(0);
    sock.on('data', function (b) {
      roh = Buffer.concat([roh, b]);
      merke('   ' + b.length + ' Byte empfangen. Anfang (Text): '
        + JSON.stringify(b.slice(0, 120).toString('latin1').replace(/[\x00-\x1f\x7f]/g, '.')));
      try { fs.appendFileSync(datei, '   HEX: ' + b.toString('hex') + '\n'); } catch (_) {}
    });
    sock.on('error', function () {});
    sock.on('close', function () { merke('   (Verbindung auf ' + port + ' beendet, ' + roh.length + ' Byte gesamt)'); });
  });
  s.on('error', function (e) {
    if (e && e.code === 'EADDRINUSE') belegt++;
    else verweigert++;
  });
  s.listen(port, '0.0.0.0', function () { gebunden++; });
  server.push(s);
}

console.log('\nVetStation - Weitnetz: faengt den Veta auf BELIEBIGEM Port\n');
console.log('  erwartet von: ' + VON);
console.log('  Portbereich:  ' + AB + ' bis ' + BIS);
console.log('  Laufzeit:     ' + MINUTEN + ' Minuten');
console.log('  Mitschnitt:   ' + datei);
console.log('  Es wird NICHTS gesendet - nur zugehoert.\n');

for (let p = AB; p <= BIS; p++) binde(p);

/* Kurz warten, bis die Bindungen durch sind, dann Bilanz. */
setTimeout(function () {
  console.log('  Lausche auf ' + gebunden + ' Ports.'
    + (belegt ? '  (' + belegt + ' schon belegt - dort hoert die Station selbst)' : '')
    + (verweigert ? '  (' + verweigert + ' vom System verweigert)' : ''));
  console.log('  Warte auf den Veta ...\n');
}, 3000);

setTimeout(function () {
  console.log('\n---------------------------------------------------------------');
  if (treffer) {
    console.log('  ' + treffer + ' Verbindung(en) vom Veta. Mitschnitt: ' + datei);
  } else {
    console.log('  KEINE Verbindung vom Veta auf ' + gebunden + ' belauschten Ports.');
    console.log('  Damit ist belegt: es liegt NICHT am Port. Das Geraet sendet gar nicht.');
    console.log('  -> Im Veta-Menue pruefen: Zieladresse, INTERVALL (nicht "Off") und ob');
    console.log('     der Export einen laufenden Fall braucht.');
  }
  server.forEach(function (s) { try { s.close(); } catch (_) {} });
  process.exit(0);
}, MINUTEN * 60000);
