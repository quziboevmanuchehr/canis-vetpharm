'use strict';
/*
 * md2-client.js — MD2-Gegenstelle fuer das Veta 5 Plus: Handschlag SICHERN und (spaeter) FUEHREN.
 *                                                                       (01.09.2026)
 *
 * ==========================================================================================
 * WAS DIESES WERKZEUG IST - UND WAS ES (NOCH) NICHT KANN
 * ==========================================================================================
 * Damit der Veta seine Daten schickt, muessen ZWEI Dinge geschehen (am Geraetelog gemessen):
 *
 *   Schloss 1 - der HANDSCHLAG:  Der Veta gruesst auf TCP 6587 mit 83 Byte und wartet auf die
 *               richtige Antwort einer ZUGELASSENEN Gegenstelle. Ohne sie bleibt bMatched: 0
 *               und m_nAdmittedCMSIp: 0 - es kommt nie eine Sitzung zustande.
 *   Schloss 2 - die VERSCHLUESSELUNG: Ist die Sitzung da, sind die Nutzdaten verschluesselt
 *               (m_bIsEncrypt: 1).
 *
 * Beide Teile stecken in Mindrays MD2-Spezifikation / eGateway-Software, die wir NICHT haben.
 * Dieses Werkzeug ist deshalb ein GERUEST mit zwei klar markierten Steckplaetzen:
 *
 *   [STECKPLATZ 1] antwortAufGruss(gruss)  -> die Handschlag-Antwort. LEER, bis die
 *                  Spezifikation vorliegt. Siehe PROMPT-EGATEWAY-ENTSCHLUESSELN.md.
 *   [STECKPLATZ 2] entschluessle(bytes)    -> ruft tools/md2-decoder.js, sobald der
 *                  Schluessel bekannt ist.
 *
 * WAS ES HEUTE SCHON TUT - und das ist echter Fortschritt:
 *   Es verbindet sich zu 6587 und SICHERT DEN VOLLSTAENDIGEN GRUSS ROH (alle 83 Byte, als
 *   Binaerdatei). Bisher waren nur 48 Byte exakt bekannt; Byte 48-82 lagen verfaelscht als
 *   Text vor. Diese Datei ist die Grundlage jeder weiteren Analyse.
 *
 * SICHERHEIT: Standardmaessig wird KEIN Byte gesendet (--nur-lauschen ist Vorgabe). Erst wenn
 * die echte Handschlag-Antwort bekannt und in STECKPLATZ 1 eingetragen ist, darf mit
 * --handschlag gesendet werden - an ein Narkosegeraet nichts Unverstandenes. Diese Grenze ist
 * bewusst in den Code eingebaut, nicht nur in einen Kommentar.
 *
 * Aufruf:
 *   node tools/md2-client.js [--host 192.168.0.52] [--port 6587]      nur sichern (Vorgabe)
 *   node tools/md2-client.js --handschlag                             NUR wenn STECKPLATZ 1 gefuellt ist
 */
const net = require('net');
const fs = require('fs');
const path = require('path');

function arg(name, ersatz) { const i = process.argv.indexOf('--' + name); return (i > 0 && process.argv[i + 1] && process.argv[i + 1][0] !== '-') ? process.argv[i + 1] : ersatz; }
function hat(name) { return process.argv.indexOf('--' + name) >= 0; }

const HOST = arg('host', '192.168.0.52');
const PORT = Number(arg('port', 6587)) || 6587;
const HANDSCHLAG = hat('handschlag');   // nur mit gefuelltem STECKPLATZ 1 sinnvoll

const ordner = path.join(__dirname, '..', 'data');
try { fs.mkdirSync(ordner, { recursive: true }); } catch (_) {}
const stempel = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const rohGruss = path.join(ordner, 'veta-gruss-' + stempel + '.bin');
const mitschnitt = path.join(ordner, 'veta-md2-' + stempel + '.log');

function log(z) { console.log(z); try { fs.appendFileSync(mitschnitt, z + '\n'); } catch (_) {} }

/* ---------------------------------------------------------------- STECKPLATZ 1: HANDSCHLAG
 * Sobald die MD2-Spezifikation vorliegt (aus der eGateway-/CMS-Software, siehe Prompt):
 * hier aus dem 83-Byte-Gruss die korrekte Antwort bilden und als Buffer zurueckgeben.
 * Gibt die Funktion null zurueck, wird NICHTS gesendet (heutiger Zustand).
 */
function antwortAufGruss(gruss) {
  // BEISPIELGERUEST (noch NICHT die echte Antwort - absichtlich null):
  //   const antwort = Buffer.alloc(...);
  //   ... die Regeln aus der Spezifikation ...
  //   return antwort;
  return null;   // <- solange die Spezifikation fehlt, wird nicht gesendet
}

/* ---------------------------------------------------------------- STECKPLATZ 2: ENTSCHLUESSELN
 * Sobald der Schluessel bekannt ist: dieselbe Logik wie tools/md2-decoder.js --schluessel.
 * Hier nur der Aufruf-Hinweis, damit klar ist, wo die zweite Haelfte sitzt.
 */
function entschluessle(bytes) {
  log('  [Nutzdaten empfangen: ' + bytes.length + ' Byte. Zum Entschluesseln:');
  log('   node tools/md2-decoder.js --schluessel <hex>  gegen data/' + path.basename(rohGruss) + ']');
}

/* ---------------------------------------------------------------- Ablauf */
log('MD2-Client fuer das Veta 5 Plus   ' + new Date().toLocaleString());
log('  Ziel: ' + HOST + ':' + PORT + '   Modus: ' + (HANDSCHLAG ? 'HANDSCHLAG (sendet Antwort, falls Steckplatz 1 gefuellt)' : 'nur sichern (sendet NICHTS)'));
log('  Gruss wird roh gesichert: ' + rohGruss);
log('');

let empfangen = Buffer.alloc(0);
let grussGesichert = false;

const sock = new net.Socket();
sock.setTimeout(15000);

sock.on('connect', function () { log('  verbunden. warte auf den Gruss des Geraets ...'); });

sock.on('data', function (b) {
  empfangen = Buffer.concat([empfangen, b]);
  log('  << ' + b.length + ' Byte empfangen (gesamt ' + empfangen.length + ')');

  /* Der erste Schwung ist der Gruss (bisher 83 Byte gesehen). Vollstaendig sichern. */
  if (!grussGesichert && empfangen.length >= 83) {
    const gruss = empfangen.slice(0, 83);
    fs.writeFileSync(rohGruss, gruss);
    grussGesichert = true;
    log('');
    log('  *** GRUSS VOLLSTAENDIG GESICHERT: ' + gruss.length + ' Byte -> ' + rohGruss);
    log('  hex: ' + gruss.toString('hex'));
    log('  Byte 48-82 (bisher unbekannt): ' + gruss.slice(48).toString('hex'));
    log('');

    if (HANDSCHLAG) {
      const antwort = antwortAufGruss(gruss);
      if (antwort && antwort.length) {
        log('  >> sende Handschlag-Antwort (' + antwort.length + ' Byte): ' + antwort.toString('hex'));
        try { sock.write(antwort); } catch (e) { log('  Sendefehler: ' + e.message); }
      } else {
        log('  --handschlag verlangt, aber STECKPLATZ 1 (antwortAufGruss) ist noch LEER.');
        log('  Es wird NICHTS gesendet. Erst die MD2-Spezifikation eintragen. Siehe Prompt.');
      }
    } else {
      log('  (nur-sichern-Modus: es wird bewusst NICHTS an das Geraet gesendet.)');
    }
    return;
  }

  /* Alles nach dem Gruss (nur relevant, wenn ein Handschlag lief). */
  if (grussGesichert && empfangen.length > 83) {
    entschluessle(empfangen.slice(83));
  }
});

sock.on('timeout', function () { log('  (15 s keine weiteren Daten - der Gruss ist gesichert, das Geraet wartet auf die Antwort.)'); sock.destroy(); });
sock.on('error', function (e) { log('  Verbindungsfehler: ' + e.message); });
sock.on('close', function () {
  log('  Verbindung beendet.');
  if (grussGesichert) {
    log('');
    log('  ERGEBNIS: der vollstaendige Gruss liegt jetzt als Binaerdatei vor.');
    log('  Naechster Schritt (anderes Werkzeug, siehe PROMPT-EGATEWAY-ENTSCHLUESSELN.md):');
    log('   - aus der eGateway-Software die Handschlag-Regeln + den Schluessel gewinnen');
    log('   - Handschlag-Regeln in STECKPLATZ 1 dieser Datei eintragen');
    log('   - Schluessel mit tools/md2-decoder.js pruefen');
  } else {
    log('  Es kam kein vollstaendiger Gruss an (Geraet aus? Port zu? anderer Ablauf?).');
  }
  process.exit(0);
});

sock.connect(PORT, HOST);
