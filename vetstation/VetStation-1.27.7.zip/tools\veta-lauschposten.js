'use strict';
/*
 * veta-lauschposten.js — hoert auf ALLEN Kanaelen, die der Veta 5 Plus laut seinem EIGENEN
 * Betriebsbuch benutzt.                                              (30.08.2026)
 *
 * ==========================================================================================
 * WARUM ES DIESE DATEI GIBT: WIR HABEN VIERMAL AN DER FALSCHEN TUER GESTANDEN
 * ==========================================================================================
 * Der MD2-Weg (CentralStation) galt als erledigt. Vier Messungen, jedes Mal null:
 *     - 24 Ports abgeklopft            - 97 Ports drei Minuten offen
 *     - Verbindungswache 4 Minuten     - Verbindungswache 2x10 Minuten
 * Daraufhin stand in den Notizen "der Weg ist tot" und dem Tierarzt wurde geraten, MD2
 * auszuschalten.
 *
 * DAS WAR FALSCH. Der Veta fuehrt auf seinem USB-Service-Stick ein Betriebsbuch
 * (systemLog.log). Darin steht, dass sein MD2Packer 226-mal ein Paket fuer genau unsere
 * PC-Adresse gepackt hat - alle zehn Sekunden, stundenlang. Er hat also die ganze Zeit
 * gesendet.
 *
 * Alle vier Messungen haben ausschliesslich TCP beobachtet: Get-NetTCPConnection zaehlt
 * TCP-Verbindungen, ein net.createServer nimmt TCP-Verbindungen an. Ein UDP-Paket erzeugt
 * KEINE Verbindung und taucht in beidem nicht auf. Vier Messungen, dieselbe blinde Stelle,
 * viermal dasselbe falsche Ergebnis - und weil es viermal dasselbe war, sah es nach Gewissheit
 * aus. Das ist die teuerste Sorte Irrtum: eine Messung, die ihren eigenen blinden Fleck
 * bestaetigt.
 *
 * WAS HIER ABGEHOERT WIRD, und woher jeder Kanal stammt:
 *   UDP 4600   der Rundruf-Kanal der Monitore (selbst mitgeschnitten, 30.08.2026)
 *   UDP 4444   Absenderport dieses Rundrufs - eine Antwort kaeme hierher zurueck
 *   UDP 5500   nennt der Veta in seinem Betriebsbuch VIERMAL als Erkennungskanal.
 *              Auf keiner unserer Portlisten stand er je.
 *   UDP 5501   Nachbarport, mitgenommen weil 5500/5501 oft als Paar auftreten
 *   Gruppe 225.0.0.8  fuehrt der Veta in seiner Konfiguration (Multicast)
 *
 * Es wird NICHTS gesendet. Kein Paket geht an den Veta - schon gar kein Messwert: bei dieser
 * Kopplung ist er der NEHMENDE, ein von uns geschicktes CO2 wuerde er als Patientenwert
 * anzeigen und danach alarmieren.
 *
 * Aufruf:  node tools/veta-lauschposten.js [--minuten 10] [--von 192.168.0.52]
 */
const dgram = require('dgram');
const fs = require('fs');
const path = require('path');

function argw(name, ersatz) {
  const i = process.argv.indexOf('--' + name);
  return (i > 0 && process.argv[i + 1]) ? process.argv[i + 1] : ersatz;
}

const VETA = argw('von', '192.168.0.52');
const MINUTEN = Number(argw('minuten', 10)) || 10;
const GRUPPE = '225.0.0.8';
const PORTS = [4600, 4444, 5500, 5501];

const ordner = path.join(__dirname, '..', 'data');
try { fs.mkdirSync(ordner, { recursive: true }); } catch (_) {}
const stempel = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const datei = path.join(ordner, 'veta-udp-' + stempel + '.log');

let vomVeta = 0, fremd = 0;
const proPort = {};

function notiere(zeile) {
  console.log(zeile);
  try { fs.appendFileSync(datei, zeile + '\n'); } catch (_) {}
}

function zeigen(b) {
  const hex = b.slice(0, 32).toString('hex').replace(/(..)/g, '$1 ').trim();
  const text = b.slice(0, 64).toString('latin1').replace(/[\x00-\x1f\x7f]/g, '.');
  return '\n      hex:  ' + hex + (b.length > 32 ? ' ...' : '')
       + '\n      text: ' + JSON.stringify(text);
}

console.log('\nVetStation - Lauschposten auf den UDP-Kanaelen des Veta 5 Plus\n');
console.log('  erwartet von:  ' + VETA);
console.log('  Kanaele:       UDP ' + PORTS.join(', ') + '   + Gruppe ' + GRUPPE);
console.log('  Laufzeit:      ' + MINUTEN + ' Minuten');
console.log('  Mitschnitt:    ' + datei);
console.log('');
console.log('  Es wird NICHTS gesendet - nur zugehoert.');
console.log('');

const sockets = [];
PORTS.forEach(function (port) {
  const s = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  s.on('error', function (e) {
    console.log('  UDP ' + port + ': ' + e.code + ' (' + e.message + ') - dieser Kanal faellt aus');
  });
  s.on('message', function (b, r) {
    const vonVeta = r.address === VETA;
    if (vonVeta) vomVeta++; else fremd++;
    proPort[port] = (proPort[port] || 0) + (vonVeta ? 1 : 0);
    if (!vonVeta) return;                       /* fremde Pakete nur zaehlen, nicht ausgeben */
    notiere(new Date().toISOString().slice(11, 19) + '  *** VOM VETA ***  UDP ' + port
      + '  von ' + r.address + ':' + r.port + '  ' + b.length + ' Byte' + zeigen(b));
  });
  s.bind(port, function () {
    console.log('  hoere auf UDP ' + port);
    try { s.setBroadcast(true); } catch (_) {}
    if (port === 4600 || port === 5500) {
      /* Die Gruppe wird an den Kanaelen versucht, an denen sie laut Konfiguration des Geraets
       * in Frage kommt. Schlaegt es fehl, laeuft der Kanal ohne Gruppe weiter - ein fehlender
       * Beitritt darf den ganzen Lauschposten nicht kosten. */
      try { s.addMembership(GRUPPE); console.log('     + Gruppe ' + GRUPPE); }
      catch (e) { console.log('     (Gruppe ' + GRUPPE + ' nicht beigetreten: ' + e.code + ')'); }
    }
  });
  sockets.push(s);
});

setTimeout(function () {
  console.log('\n---------------------------------------------------------------');
  console.log('  Pakete VOM VETA (' + VETA + '): ' + vomVeta);
  PORTS.forEach(function (p) { if (proPort[p]) console.log('     UDP ' + p + ': ' + proPort[p]); });
  console.log('  Pakete von anderen Absendern (nur gezaehlt): ' + fremd);
  if (!vomVeta) {
    console.log('\n  KEIN einziges Paket vom Veta - auf KEINEM dieser Kanaele.');
    console.log('  Ist MD2 am Geraet eingeschaltet und die Serveradresse auf diesen PC gesetzt?');
    console.log('  (Sein Betriebsbuch belegt, dass er bei eingeschaltetem MD2 alle 10 s sendet.)');
  } else {
    console.log('\n  Mitschnitt liegt in: ' + datei);
  }
  sockets.forEach(function (s) { try { s.close(); } catch (_) {} });
  process.exit(0);
}, MINUTEN * 60000);
