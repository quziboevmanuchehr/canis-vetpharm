'use strict';
/*
 * md2-decoder.js — Decoder und Analyse-Werkbank fuer den MD2-Kanal des Mindray Veta 5 Plus.
 *                                                                       (31.08.2026)
 *
 * ==========================================================================================
 * WAS DIESES WERKZEUG KANN - UND WAS NICHT. Bitte zuerst lesen.
 * ==========================================================================================
 * Die Nutzdaten des MD2-Kanals sind verschluesselt (das Geraet meldet m_bIsEncrypt: 1 in
 * 56.893 von 56.893 Protokollzeilen). OHNE DEN SCHLUESSEL kann KEIN Programm sie lesen - auch
 * dieses nicht. Verschluesselung ist keine Schreibweise, die man zurueckuebersetzt; die Regel
 * steckt in einem Schluessel, der nicht mitgeschickt wird. Das ist gemessen, nicht behauptet
 * (tools/... Kryptoanalyse 30.08.: Entropie nahe Maximum, keine Periode, kein bekannter
 * Klartext auffindbar).
 *
 * WAS ES TROTZDEM TUT, und warum das nuetzlich ist:
 *
 *   1. DEN KOPF LESEN. Byte 0..12 der Begruessung sind NICHT verschluesselt (Entropie 2,97).
 *      Rahmenlaenge, Typ, die zwei Klartextzeichen "GT" - das ist ohne Schluessel lesbar und
 *      wird hier benannt.
 *
 *   2. DIE RAHMENSTRUKTUR eines MD2-Stroms zerlegen: Startmarke, Laengenfeld, Nutzteil,
 *      Pruefsumme. So wird aus einem Byte-Haufen eine Folge benannter Rahmen - unabhaengig
 *      davon, ob der Inhalt lesbar ist.
 *
 *   3. EINE SCHLUESSEL-WERKBANK. Sobald ein Schluessel bekannt ist - aus der Firmware, aus der
 *      eGateway-Software, aus einer freien Umsetzung wie VSCapture -, probiert dieses Werkzeug
 *      ihn in Sekunden gegen die gespeicherte Begruessung durch, ueber alle plausiblen
 *      Verfahren (AES, 3DES und SM4 - SM4 ist der chinesische Standard, und Mindray ist ein
 *      chinesischer Hersteller; das mitgelieferte node kann es). Ein Treffer erkennt sich
 *      daran, dass der entschluesselte Kopf wieder die bekannten Klartextanteile zeigt.
 *      DAMIT ist in dem Moment, in dem Codex einen Schluessel findet, die Arbeit hier schon
 *      getan - man haelt den Fund daneben und sieht sofort, ob er passt.
 *
 * WAS ES NIEMALS TUT: ein Byte an das Geraet senden. Es liest Dateien und rechnet.
 *
 * Aufruf:
 *   node tools/md2-decoder.js --kopf <datei-mit-hexbytes>      Kopf zerlegen
 *   node tools/md2-decoder.js --rahmen <datei.bin>             Strom in Rahmen zerlegen
 *   node tools/md2-decoder.js --schluessel <hex> [--iv <hex>]  einen Schluesselkandidaten testen
 *   node tools/md2-decoder.js --probe                          gegen die bekannte Begruessung
 */
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

/* Die 48 bekannten Byte der Begruessung von TCP 6587 (30.08.2026). Byte 48..82 fehlen noch
 * exakt - sie muessen am Geraet vollstaendig mitgeschnitten werden. */
const BEGRUESSUNG_48 = Buffer.from(
  '820211000104020 26b0000475 4a53410e86384e4df6399e8cf0a3f2668 66fbd9ea34385b10510f5c4e0117cb8e93c3e8'
    .replace(/\s/g, ''), 'hex');

function hexZuBytes(text) {
  const nur = String(text).replace(/0x/gi, ' ').replace(/[^0-9a-fA-F]/g, ' ').trim().split(/\s+/);
  /* Zwei Formen zulassen: "82 02 11" (paarweise) oder "820211" (am Stueck). */
  if (nur.every(function (t) { return t.length === 2; })) {
    return Buffer.from(nur.join(''), 'hex');
  }
  return Buffer.from(nur.join('').replace(/[^0-9a-fA-F]/g, ''), 'hex');
}

/* ------------------------------------------------------------------ Kopf */
function kopfLesen(b) {
  console.log('\nKopf der MD2-Nachricht (' + b.length + ' Byte gesamt bekannt)\n');
  const zeile = [];
  for (let i = 0; i < Math.min(16, b.length); i++) zeile.push(i + ':' + b[i].toString(16).padStart(2, '0'));
  console.log('  ' + zeile.join('  '));
  console.log('');
  console.log('  Byte 0     = 0x' + b[0].toString(16) + '   Startmarke (immer 0x82 gesehen)');
  console.log('  Byte 1     = 0x' + b[1].toString(16) + '   evtl. STX/Typ');
  console.log('  Byte 2     = 0x' + b[2].toString(16) + ' = ' + b[2] + '   evtl. Laenge eines Teilfelds');
  const gt = b.indexOf(Buffer.from('GT'));
  console.log('  "GT"       ' + (gt >= 0 ? 'bei Byte ' + gt + '  - einziger Klartext' : 'nicht gefunden'));
  /* Wo endet der lesbare Kopf? Erste Stelle, ab der es "zufaellig" wird. */
  let strukturBis = 0;
  for (let i = 0; i < b.length; i++) { if (b[i] === 0 || (b[i] >= 0x20 && b[i] < 0x80)) strukturBis = i; else if (i > strukturBis + 3) break; }
  console.log('  Struktur   bis etwa Byte ' + strukturBis + ', danach verschluesselt/gepackt.');
}

/* ------------------------------------------------------------------ Rahmen */
function rahmenZerlegen(b) {
  console.log('\nRahmen im Strom (' + b.length + ' Byte)\n');
  let i = 0, n = 0;
  while (i < b.length) {
    if (b[i] !== 0x82) { i++; continue; }          /* auf die Startmarke aufsetzen */
    /* Versuch: Byte nach der Marke ist ein Laengenhinweis. Ohne Spezifikation ist das eine
     * ANNAHME - sie wird als solche ausgewiesen und die Pruefsumme (falls erkennbar) prueft sie. */
    const restlaenge = b[i + 2] || 0;
    const ende = Math.min(b.length, i + 3 + restlaenge);
    const stueck = b.slice(i, ende);
    console.log('  Rahmen ' + (++n) + ' @ ' + i + '  ' + stueck.length + ' Byte  '
      + stueck.slice(0, 8).toString('hex') + (stueck.length > 8 ? ' ...' : ''));
    if (ende <= i) break;
    i = ende;
    if (n > 200) { console.log('  ... abgebrochen bei 200 Rahmen'); break; }
  }
  if (!n) console.log('  Keine Startmarke 0x82 gefunden.');
}

/* ------------------------------------------------------------------ Schluessel-Werkbank */
function passtKopf(entschluesselt) {
  /* Ein richtiger Schluessel macht aus dem verschluesselten Teil wieder Struktur: viele
   * Nullbytes, druckbare Zeichen, niedrige Entropie. Grob, aber genug fuer "heiss/kalt". */
  if (!entschluesselt || !entschluesselt.length) return 0;
  let druckbarOderNull = 0;
  for (const x of entschluesselt) if (x === 0 || (x >= 0x20 && x < 0x7f)) druckbarOderNull++;
  return druckbarOderNull / entschluesselt.length;
}

function schluesselTesten(schluessel, iv, geheim) {
  /* Der verschluesselte Teil beginnt hinter dem Kopf. Ohne genaue Grenze wird ab mehreren
   * plausiblen Offsets probiert. */
  const verfahren = [];
  const kl = schluessel.length;
  if (kl === 16) verfahren.push('aes-128-ecb', 'aes-128-cbc', 'sm4-ecb', 'sm4-cbc');
  if (kl === 24) verfahren.push('des-ede3-cbc');
  if (kl === 32) verfahren.push('aes-256-ecb', 'aes-256-cbc');
  if (!verfahren.length) { console.log('  Schluessellaenge ' + kl + ' passt zu keinem gaengigen Verfahren.'); return; }

  const treffer = [];
  [13, 14, 16, 0].forEach(function (off) {
    const block = geheim.slice(off);
    const nutz = block.slice(0, Math.floor(block.length / 16) * 16);
    if (nutz.length < 16) return;
    verfahren.forEach(function (v) {
      try {
        const iv2 = /ecb/.test(v) ? null : (iv || Buffer.alloc(16));
        const d = crypto.createDecipheriv(v, schluessel, iv2);
        d.setAutoPadding(false);
        const aus = Buffer.concat([d.update(nutz), d.final()]);
        const g = passtKopf(aus);
        if (g > 0.6) treffer.push({ v: v, off: off, guete: g, aus: aus });
      } catch (e) { /* Verfahren/Schluessel unpassend - weiter */ }
    });
  });
  treffer.sort(function (a, b) { return b.guete - a.guete; });
  if (!treffer.length) {
    console.log('  Kein Verfahren ergibt lesbare Struktur. Dieser Schluessel passt nicht'
      + ' - oder die Grenze des Nutzteils ist eine andere.');
    return;
  }
  console.log('  MOEGLICHER TREFFER:');
  treffer.slice(0, 3).forEach(function (t) {
    console.log('   ' + t.v + ' ab Byte ' + t.off + '  Guete ' + (t.guete * 100).toFixed(0) + ' %');
    console.log('     -> ' + t.aus.slice(0, 32).toString('hex'));
    console.log('     -> ' + JSON.stringify(t.aus.slice(0, 40).toString('latin1').replace(/[\x00-\x1f\x7f]/g, '.')));
  });
  console.log('\n  Ein Treffer hier ist ein HINWEIS, keine Gewissheit: erst der vollstaendige,'
    + '\n  wiederholbare Datenstrom mit sinnvollen Beatmungswerten beweist den Schluessel.');
}

/* ------------------------------------------------------------------ Aufruf */
const args = process.argv.slice(2);
function arg(name) { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : null; }

if (args.indexOf('--kopf') >= 0) {
  const f = arg('--kopf');
  kopfLesen(f ? hexZuBytes(fs.readFileSync(f, 'utf8')) : BEGRUESSUNG_48);
} else if (args.indexOf('--rahmen') >= 0) {
  rahmenZerlegen(fs.readFileSync(arg('--rahmen')));
} else if (args.indexOf('--schluessel') >= 0) {
  const s = Buffer.from(arg('--schluessel').replace(/[^0-9a-fA-F]/g, ''), 'hex');
  const ivh = arg('--iv');
  const iv = ivh ? Buffer.from(ivh.replace(/[^0-9a-fA-F]/g, ''), 'hex') : null;
  console.log('\nTeste Schluessel (' + s.length + ' Byte) gegen die bekannte Begruessung:');
  schluesselTesten(s, iv, BEGRUESSUNG_48);
} else if (args.indexOf('--probe') >= 0) {
  console.log('\nProbe: der Kopf der bekannten 48 Byte.');
  kopfLesen(BEGRUESSUNG_48);
  console.log('\nOhne Schluessel bleibt der Teil ab Byte ~13 unlesbar. Sobald ein Schluessel'
    + '\nvorliegt:  node tools/md2-decoder.js --schluessel <hex>');
} else {
  console.log('Aufruf:');
  console.log('  node tools/md2-decoder.js --kopf [datei]        Kopf zerlegen');
  console.log('  node tools/md2-decoder.js --rahmen <datei.bin>  Strom in Rahmen zerlegen');
  console.log('  node tools/md2-decoder.js --schluessel <hex>    Schluesselkandidat testen');
  console.log('  node tools/md2-decoder.js --probe               gegen die bekannte Begruessung');
}
