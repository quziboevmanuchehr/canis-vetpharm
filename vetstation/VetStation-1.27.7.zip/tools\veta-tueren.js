'use strict';
/*
 * veta-tueren.js — welche Tueren hat der Veta 5 Plus SELBST offen?   (30.08.2026)
 *
 * ==========================================================================================
 * WARUM DAS NOCH FEHLTE, obwohl es die naheliegendste Frage ist
 * ==========================================================================================
 * In tools/monitor-nachbau.js steht seit dem 29.08.2026 als Tatsache:
 *
 *     "24 Ports abgeklopft: KEINE offene Tuer. Er ist kein Server, er verbindet sich selbst."
 *
 * Fuer diese Messung gibt es im ganzen Bestand KEINEN Beleg - kein Werkzeug, kein Protokoll,
 * keine Ausgabe. Und eine aeltere, dokumentierte Messung vom 22.07.2026 sagt das GEGENTEIL:
 * Port 4601 des Veta antworte. Auf dieser unbelegten Zeile ruht die ganze Bauentscheidung,
 * den PC als Monitor auszugeben statt den Veta direkt zu fragen.
 *
 * Der ganze 30.08. ist damit vergangen, dass wir gelauscht haben - 97 TCP-Ports, 125
 * UDP-Kanaele, vier Wachposten, alles null. Gefragt, ob ER eine Tuer offen hat, hat in dieser
 * Zeit niemand.
 *
 * WAS DIESES WERKZEUG TUT UND WAS NICHT:
 *   - Es baut eine TCP-Verbindung auf und legt SOFORT wieder auf. Es sendet KEIN Byte.
 *   - Ein Narkosegeraet bekommt von hier keine Steuerung, keinen Messwert, keine Abfrage.
 *   - Die Anzahl gleichzeitiger Versuche ist klein (Vorgabe 12): ein Medizingeraet soll nicht
 *     mit hunderten offenen Verbindungen beschaeftigt werden, waehrend nebenan ein Tier liegt.
 *   - Antwortet eine Tuer, wird NUR vermerkt, dass sie offen ist. Was dahinter spricht, ist
 *     eine eigene Entscheidung und eine eigene Messung.
 *
 * NICHT WAEHREND EINER NARKOSE FAHREN. Auch ein blosses Anklopfen ist Verkehr an einem Geraet,
 * das gerade beatmet.
 *
 * Aufruf:  node tools/veta-tueren.js [--ziel 192.168.0.52] [--bis 10000] [--gleichzeitig 12]
 */
const net = require('net');

function argw(name, ersatz) {
  const i = process.argv.indexOf('--' + name);
  return (i > 0 && process.argv[i + 1]) ? process.argv[i + 1] : ersatz;
}

const ZIEL = argw('ziel', '192.168.0.52');
const BIS = Number(argw('bis', 10000)) || 10000;
const GLEICHZEITIG = Number(argw('gleichzeitig', 12)) || 12;
const FRIST = 900;

const offen = [];
let geprueft = 0, naechster = 1;

function klopfe(port) {
  return new Promise(function (fertig) {
    const s = new net.Socket();
    let erledigt = false;
    const schluss = function (istOffen) {
      if (erledigt) return; erledigt = true;
      try { s.destroy(); } catch (_) {}
      geprueft++;
      if (istOffen) { offen.push(port); console.log('  OFFEN: TCP ' + port); }
      fertig();
    };
    s.setTimeout(FRIST, function () { schluss(false); });
    s.on('error', function () { schluss(false); });
    /* connect + sofort auflegen. KEIN write() - hier geht kein Byte an das Geraet. */
    s.connect(port, ZIEL, function () { schluss(true); });
  });
}

async function arbeiter() {
  while (naechster <= BIS) {
    const p = naechster++;
    await klopfe(p);
    if (geprueft % 500 === 0) console.log('  ... ' + geprueft + ' von ' + BIS + ' geprueft');
  }
}

(async function () {
  console.log('\nVetStation - welche Tueren hat der Veta 5 Plus offen?\n');
  console.log('  Ziel:          ' + ZIEL);
  console.log('  Ports:         1 bis ' + BIS);
  console.log('  gleichzeitig:  ' + GLEICHZEITIG + '   (bewusst klein - es ist ein Medizingeraet)');
  console.log('');
  console.log('  Es wird KEIN Byte gesendet: verbinden, auflegen, fertig.');
  console.log('');
  const t0 = Date.now();
  await Promise.all(Array.from({ length: GLEICHZEITIG }, arbeiter));
  const dauer = Math.round((Date.now() - t0) / 1000);
  console.log('\n---------------------------------------------------------------');
  console.log('  ' + geprueft + ' Ports in ' + dauer + ' s geprueft.');
  if (offen.length) {
    console.log('  OFFENE TUEREN: ' + offen.join(', '));
    console.log('\n  Damit ist die Zeile "keine offene Tuer" widerlegt. Was hinter einer Tuer');
    console.log('  spricht, ist die NAECHSTE Frage - und eine eigene Messung.');
  } else {
    console.log('  Keine offene Tuer in diesem Bereich.');
    console.log('\n  Das belegt die bisherige Annahme - erstmals mit einer Messung, die man');
    console.log('  nachlesen kann.');
  }
  process.exit(0);
})();
