/*
 * geraete-einrichtung.js — die komplette Geraete-Einrichtung in einfachen Schritten.
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 31.08.2026):
 * Der Tierarzt richtet Monitor und Narkosegeraet selbst ein und braucht dafuer ALLE Passwoerter
 * und die genauen Netzwerkeinstellungen an EINER Stelle - so einfach erklaert, dass man nichts
 * wissen muss. Bisher lag das verstreut in docs\ und im Geraetekatalog; hier steht es
 * gebuendelt und wird im Admin-Bereich Schritt fuer Schritt angezeigt.
 *
 * DIE PASSWOERTER SIND HERSTELLER-STANDARDCODES (Mindray-Servicehandbuecher), keine Geheimnisse
 * dieser Praxis - sie stehen in jedem Servicehandbuch. Trotzdem laeuft diese Datei NUR in der
 * Station (ui\index.html laedt sie, die oeffentliche Web-App NICHT), damit sie nicht in den
 * oeffentlichen Kanal geraet. Die konkreten IP-Adressen sind die dieser Praxis; sie sind
 * RFC1918-Adressen und keine Geraetekennung.
 *
 * WER EINE ZAHL AENDERT: der Selbsttest tools\geraete-einrichtung-test.js prueft, dass die
 * PC-Adresse ueberall gleich ist und die Ports zum Geraetekatalog passen. Eine falsche Zahl
 * hier kostet den Tierarzt morgen am Geraet Zeit - deshalb ist sie belegt, nicht geraten.
 */
(function (global) {
  'use strict';

  /* Die zentralen Adressen - EINMAL definiert, ueberall verwendet, damit nichts auseinanderlaeuft. */
  var NETZ = {
    pc: '192.168.0.99',       // der Praxis-PC (die "Station"/"CMS")
    monitor: '192.168.0.50',  // uMEC12 Vet
    narkose: '192.168.0.52',  // Veta 5 Plus
    zweitmonitor: '192.168.0.51', // LifeVet 10C (optional)
    maske: '255.255.255.0',
    gateway: '192.168.0.1'
  };

  var DATEN = {
    netz: NETZ,

    /* Zuerst der PC - ohne festes Netz findet kein Geraet den PC. */
    pc: {
      name: 'Der Praxis-PC (die Station)',
      ip: NETZ.pc,
      kurz: 'Muss eine FESTE Adresse haben, sonst finden die Geraete ihn nicht.',
      passwoerter: [],
      schritte: [
        { titel: 'Feste Netzwerkadresse setzen',
          detail: 'Auf dem Desktop NETZ-DAUERHAFT-EINRICHTEN.bat mit der rechten Maustaste anklicken und "Als Administrator ausfuehren". Das setzt die Adresse ' + NETZ.pc + ' fest. Ohne das steht der PC bei jedem Neustart wieder auf einer zufaelligen Adresse und die Geraete verlieren ihn.' },
        { titel: 'Kontrolle', detail: 'MESSUNG-JETZT.bat doppelklicken. Es sagt im Klartext, ob der PC die Geraete sieht.' },
        { titel: 'Was der PC offen hat', detail: 'Die Firewall gibt die Ports 3502, 4601, 5000, 8830, 2575 und 24105 frei - das erledigt die .bat mit. Daran muss man nichts von Hand einstellen.' }
      ]
    },

    /* Der Monitor - laeuft, ist der wichtigste Datenlieferant. */
    monitor: {
      name: 'Mindray uMEC12 Vet - Patientenmonitor',
      ip: NETZ.monitor,
      kurz: 'Liefert HF, SpO2, Puls, Atmung, Temperatur, Blutdruck. Laeuft ueber HL7 auf Port 4601.',
      passwoerter: [
        { zweck: 'Benutzer-Wartung (Netzwerk einstellen)', code: '888888' },
        { zweck: 'Konfiguration verwalten', code: '315666' },
        { zweck: 'Werks-Wartung', code: '332888' },
        { zweck: 'Demo-Modus', code: '2088' }
      ],
      schritte: [
        { titel: 'Ins Wartungsmenue', detail: 'Am Monitor (Touch): Hauptmenue -> Wartung -> Benutzer-Wartung. Passwort 888888 eingeben.' },
        { titel: 'Netzwerk einstellen', detail: 'Netzwerk-Setup oeffnen. Netzwerktyp = LAN. Adresstyp = MANUELL (nicht DHCP). IP-Adresse = ' + NETZ.monitor + '. Subnetzmaske = ' + NETZ.maske + '. Gateway = ' + NETZ.gateway + '.' },
        { titel: 'Wohin die Daten gehen (nur ABLESEN!)', detail: 'Gateway-Kommunikationseinst.: dort steht Ziel = ' + NETZ.pc + ', Port 4601. NICHT AENDERN. Am 25.07.2026 hat ein Umstellen dieser Zeile den funktionierenden Blutdruckweg zerstoert. Steht es richtig, nur bestaetigen.' },
        { titel: 'Fertig', detail: 'Mehr ist nicht noetig. Sobald der Monitor im selben Netz haengt, laufen die Werte automatisch in die Station. In der Station oben muss der gruene Punkt "verbunden" stehen.' }
      ],
      hinweis: 'Die Herzfrequenz kommt aus dem EKG - dafuer muessen die EKG-Elektroden am Tier kleben. Ohne Elektroden sendet der Monitor "EKG lernen" und HF/Atmung bleiben leer (das ist kein Fehler der Station).'
    },

    /* Das Narkosegeraet - der Kern des Wunsches. */
    narkose: {
      name: 'Mindray Veta 5 Plus - Narkose- und Beatmungsgeraet',
      ip: NETZ.narkose,
      kurz: 'Soll Vt, MV, PEEP, Spitzendruck, Atemfrequenz und CO2 liefern. Der richtige Weg ist der DatenExport (HL7), NICHT die verschluesselte CentralStation.',
      passwoerter: [
        { zweck: 'Systemkennwort (Netzwerk, Monitor verbinden)', code: '1234' },
        { zweck: 'Servicekennwort (DatenExport freischalten)', code: '789789' }
      ],
      schritte: [
        { titel: 'Ins Standby', detail: 'Das Geraet muss im Standby sein (oben steht "00:00:00 Standby"). Nur dort ist das Systemmenue erreichbar.' },
        { titel: 'Netzwerk einstellen', detail: 'Setup -> System -> Systemkennwort 1234 -> Netzwerk einr.: "IP-Adresse automatisch beziehen" AUS. IP-Adresse = ' + NETZ.narkose + '. Subnetzmaske = ' + NETZ.maske + '. Standard-Gateway = ' + NETZ.gateway + '.' },
        { titel: 'CO2 vom Monitor holen', detail: 'System -> Monitor verbunden -> Aktualisieren. Der Monitor M0001 (' + NETZ.monitor + ') erscheint und das Geraet verbindet sich von selbst. Unten muss "Verbindung erfolgreich" stehen. Damit bekommt das Narkosegeraet das CO2 vom Monitor.' },
        { titel: 'DER WICHTIGE SCHALTER: DatenExport einschalten', detail: 'Ins Service-Menue: Setup -> System -> Service kennwort 789789 -> Reiter "Setup" -> links "DatenExport Klinik" -> DataExportSwitch auf EIN. DAS ist der Weg, ueber den die Beatmungswerte an die Station gehen - unverschluesselt, als HL7. War dieser Schalter aus, kam nie etwas an.' },
        { titel: 'Ziel und Kurven', detail: 'Im selben DatenExport-Menue (Pfeil hinter DataExportSwitch): Zieladresse/Server-IP = ' + NETZ.pc + ' setzen. Falls es "Send Waveforms"/"Kurven" gibt: EIN - dann kommen auch die CO2- und Druckkurven 1:1.' },
        { titel: 'CentralStation (MD2)', detail: 'System -> CentralStation Verbindung: MD2 darf EIN bleiben, Serveradresse ' + NETZ.pc + '. Dieser Weg ist verschluesselt und liefert der Station nichts - der DatenExport oben ist der richtige. MD2 schadet aber nicht.' }
      ],
      hinweis: 'Ist "Leck. System" oder "Paw zu tief" zu sehen, ist nur der Kreis offen (kein Beutel/Patient dran) - fuer die Netzverbindung egal, fuer die Beatmungswerte nicht.'
    },

    /* Der zweite Monitor - optional, liefert echte Kurven. */
    zweitmonitor: {
      name: 'Eickemeyer LifeVet 10C - zweiter Monitor (optional)',
      ip: NETZ.zweitmonitor,
      kurz: 'Liefert Zahlen UND echte Kurven (EKG 500 Hz, Pleth, Atmung, CO2). Nur noetig, wenn angeschlossen.',
      passwoerter: [
        { zweck: 'Benutzer-Wartung', code: '888888' },
        { zweck: 'Alternativ (N-Serie)', code: 'MIN888' },
        { zweck: 'Werks-Wartung', code: '332888' }
      ],
      schritte: [
        { titel: 'Netzwerk einstellen', detail: 'Wartung -> Benutzer-Wartung 888888 -> Netzwerk-Setup: Adresstyp MANUELL, IP = ' + NETZ.zweitmonitor + ', Maske = ' + NETZ.maske + ', Gateway = ' + NETZ.gateway + '.' },
        { titel: 'HL7 einschalten', detail: 'HL7-Konfiguration: Send Data, Send Waveform UND Send Alarms auf EIN. Server-IP = ' + NETZ.pc + '. Port = 8830 STEHEN LASSEN - die Station hoert dort ab Werk zu.' },
        { titel: 'In der Station freischalten', detail: 'Nur falls der LifeVet fest haengt: in der Station den Eintrag "zweitgeraet-abfrage" einschalten und neu starten (NEUSTART.bat). Meist genuegt aber der Weg oben - die Station findet ihn selbst.' }
      ]
    }
  };

  /* Kleine Fehlersuche fuer den haeufigsten Fall. */
  DATEN.fehlersuche = [
    { frage: 'Der PC sieht kein Geraet.', antwort: 'Steht der PC auf ' + NETZ.pc + '? NETZ-DAUERHAFT-EINRICHTEN.bat als Administrator laufen lassen. Haengen alle am selben Switch?' },
    { frage: 'Monitor verbunden, aber keine HF/Atmung.', antwort: 'EKG-Elektroden am Tier? Ohne Elektroden meldet der Monitor "EKG lernen" und HF bleibt leer.' },
    { frage: 'Vom Narkosegeraet kommt nichts.', antwort: 'DataExportSwitch im Service-Menue (789789) auf EIN? Zieladresse ' + NETZ.pc + '? Die verschluesselte CentralStation (MD2) liefert nichts - nur der DatenExport.' },
    { frage: 'Nach einem Neustart des PC kommt nichts mehr.', antwort: 'Das Netz steht evtl. wieder auf automatisch. NETZ-DAUERHAFT-EINRICHTEN.bat erneut laufen lassen.' }
  ];

  if (typeof module !== 'undefined' && module.exports) module.exports = DATEN;
  if (global) global.GERAETE_EINRICHTUNG = DATEN;
})(typeof window !== 'undefined' ? window : null);
