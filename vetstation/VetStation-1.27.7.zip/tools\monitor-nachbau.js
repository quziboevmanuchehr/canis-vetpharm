'use strict';
/*
 * monitor-nachbau.js — der PC gibt sich als Mindray-MONITOR aus, damit sich das
 * Narkosegeraet Veta 5 Plus zu IHM verbindet.                        (29.08.2026)
 *
 * WARUM ES DIESE DATEI GIBT
 *
 * Der Veta 5 Plus gibt seine Werte ueber das Netz nicht her — als ZENTRALSTATION erreicht man
 * ihn nicht. Das ist gemessen und abgeschlossen (28./29.08.2026):
 *   - 24 Ports abgeklopft: KEINE offene Tuer. Er ist kein Server, er verbindet sich selbst.
 *   - "MD2: Ein" + Serveradresse 192.168.0.99, mit laufendem Fall UND nach Geraeteneustart:
 *     zwei Wachposten je 10 Minuten, NULL Verbindungen.
 *   - Kein Rundruf von ihm auf UDP 4600 / 4679 / 4620 / 4678 / 5100 / 4602.
 *
 * ABER: als MONITOR erreicht man ihn. Auf seiner Seite "System -> Setup -> Monitor verbunden"
 * stand am 28.08.2026 woertlich:
 *
 *     Geraetename   IP-Adresse Monitor
 *     M0001         192.168.0.50          ->  "Verbindung erfolgreich"
 *
 * Er hat sich also von sich aus zum uMEC12 verbunden. Und der uMEC12 ruft jede Sekunde ins
 * Netz — UDP 4600, 596 Byte, MLLP-gerahmtes HL7 "MSH|^~\&|||||||ADT^A01|101|P|2.3.1", darin
 * "OBX ST 2304^MonitorName = M0001". Das ist DIESELBE Zeichenkette, die der Veta in seiner
 * Liste anzeigt. Daraus folgt die Vermutung, die dieses Werkzeug pruefen soll:
 *
 *     Der Veta findet Monitore ueber den ADT^A01-Rundruf auf UDP 4600.
 *     Wer diesen Rundruf sendet, taucht in seiner Liste auf — auch dieser PC.
 *
 * Das ist KEIN Rateversuch am Protokoll. Es ist der Kanal, von dem gemessen feststeht, dass
 * der Veta ihn benutzt.
 *
 * WORAUF GELAUSCHT WIRD, UND WARUM AUF 4601
 * Der uMEC12 hat GENAU EINE offene Tuer: TCP 4601 (24 Ports abgeklopft). Wenn der Veta sich
 * zu ihm verbunden hat, dann dorthin. Deshalb lauscht dieser Nachbau auf 4601 — und
 * zusaetzlich auf ein paar Nachbarports, falls die Annahme nicht traegt.
 *
 * EHRLICHE ERWARTUNG
 * Was der Veta dann sendet, ist mit hoher Wahrscheinlichkeit MD2 — Mindrays Binaerformat.
 * Lesbar ist es damit noch NICHT. Der Gewinn waere trotzdem gross: zum ersten Mal ein
 * echter, sich VERAENDERNDER Strom von diesem Geraet statt der 26 identischen
 * Keepalive-Rahmen vom Juli. Genau das ist die Voraussetzung, um ein Format zu entziffern.
 * Der Mitschnitt landet deshalb so auf der Platte, dass tools/binaer-analyse.js ihn
 * unmittelbar auswerten kann.
 *
 * WAS DIESES WERKZEUG NICHT TUT
 * Es sendet KEINE Messwerte und KEINE Steuerung an den Veta — es ruft nur seinen Namen und
 * hoert zu. Ein Narkosegeraet bekommt von hier nichts gesagt.
 *
 * WAS EINE FREMDE RECHERCHE ZUM VETA-5-HANDBUCH DAZU BEITRAEGT (29.08.2026)
 * Nicht selbst am Geraet nachgeprueft, aber es raeumt eine Erwartung zurecht und spart am
 * Praxis-PC womoeglich einen ganzen Anlauf:
 *
 *   a) DIE RICHTUNG. Der dokumentierte Zweck dieser Kopplung ist, dass die Veta EtCO2 VOM
 *      Monitor BEZIEHT — sie ist der Nehmende, nicht der Gebende. Es ist also gut moeglich,
 *      dass sie nach dem Verbinden vor allem abonniert und wartet, statt Beatmungswerte zu
 *      senden. Der Gewinn bleibt derselbe (erstmals ein echter Strom von diesem Geraet), aber
 *      "verbunden" heisst nicht automatisch "sie erzaehlt uns Vt und PEEP".
 *      Steht der Monitor auf Standby, kommt laut Handbuch gar kein CO2 an der Veta an.
 *   b) DAS MENUE liegt im SYSTEMBEREICH und ist nur aus dem STANDBY erreichbar, hinter dem
 *      Systemkennwort (dokumentierter Werkswert 1234; das Handbuch verlangt, es nach der
 *      Installation zu aendern). Wer den Weg im laufenden Betrieb sucht, findet ihn nicht.
 *   c) Veta und "Monitor" muessen im SELBEN Netzabschnitt liegen UND dieselbe Subnetzmaske
 *      tragen. Bei uns ist das erfuellt (192.168.0.0/24), aber es erklaert, warum der Veta
 *      im Juli nichts fand: da stand der PC noch in 192.168.2.x.
 *   d) Erfolgreich ist es erst, wenn unten "Verbunden" steht — die blosse Anzeige in der
 *      Liste ist nur der Fund, nicht die Verbindung.
 *   e) Uebernommenes, also fremdes EtCO2 kennzeichnet die Veta in Historie und Export.
 *      Fuer den Leser des USB-Exports ist das gebaut (tools/veta-export-lesen.js, co2Paar):
 *      ein gekennzeichneter Wert behaelt seine Zahl, traegt aber `co2Fremd` — und darf den
 *      Vorrang "Schlauchmessung" dann NICHT bekommen, sonst zaehlt der Monitorwert zweimal.
 *
 * NICHT UEBERNOMMEN wurde aus derselben Recherche der Rat, den Veta gar nicht anzusprechen
 * und auf eine Herstellerspezifikation zu warten, sowie der Rat, TCP 4601 am uMEC erst noch
 * zu verifizieren: das ist seit dem 28.08.2026 gemessen erledigt, und dieselbe Recherche
 * raet ausdruecklich von der Abfrage ab, die bei uns als einzige funktioniert.
 *
 * NUTZUNG (am Praxis-PC, Geraete im selben Netz)
 *   1. Die VetStation anhalten — sie belegt Port 4601 mit ihrem Verbindungs-Assistenten:
 *        powershell -ExecutionPolicy Bypass -File C:\VetStation\kiosk\stop-kiosk.ps1
 *   2. node tools/monitor-nachbau.js --name VETSTATION --minuten 10
 *   3. Am Veta, im STANDBY:  Setup -> System -> Kennwort -> "Monitor verbunden"
 *      -> "Aktualisieren". Taucht der Name aus Schritt 2 auf: auswaehlen -> "Verbinden",
 *      und auf "Verbunden" warten.
 *   4. Zusehen, was hier ankommt. Danach am Veta "Trennen", Station wieder starten.
 *
 * WENN ES NICHT KLAPPT, ist der naechste Schritt NICHT, Ports zu raten, sondern zuzusehen:
 * Veta und uMEC12 offiziell miteinander koppeln (dieser Weg ist belegt und hat am 28.08.2026
 * funktioniert) und den Verkehr an einem Switch mit Port-Spiegelung mitschneiden. Dann sieht
 * man das echte Gespraech mit einem Gegenueber, von dem feststeht, dass es passt — statt
 * eines geratenen. Ein Managed Switch ist dafuer noetig; der vorhandene kann es nicht.
 */

const dgram = require('dgram');
const net = require('net');
const fs = require('fs');
const os = require('os');
const path = require('path');

const VT = 0x0b, FS_ = 0x1c, CR = 0x0d;

/* ---------------------------------------------------------------------------------------
 * Der Rundruf.
 *
 * Aufbau und Feldbelegung sind am 28.08.2026 vom echten uMEC12 abgehoert und entschluesselt
 * worden (596 Byte, 18 Segmente). Nachgebaut werden nur die Felder, die dort belegt waren;
 * erfunden wird nichts. Die Kennziffern stammen aus demselben Mitschnitt:
 *   2304 MonitorName (ST)      2308 BedNoStr (ST)        4529 Softwarestand (ST)
 *   2305/2306/2307/4526 (CE)   4527 (ST, 24 Nullen)      2319 (ST, Merkmalsfeld)
 *   2211/4524 (NM)             4528/4530/2320 (CE)
 *
 * Die Werte der Zustandsfelder werden aus dem Mitschnitt uebernommen. Sie zu VERSTEHEN war
 * nicht noetig und waere geraten — dieses Werkzeug will nur erkannt werden, nicht behaupten,
 * ein Monitor zu sein.
 */
/*
 * ==========================================================================================
 * DER RUNDRUF WURDE AM 30.08.2026 GEGEN DAS ECHTE GERAET GEHALTEN - UND WAR AN DREI STELLEN
 * ANDERS. Der Veta hat uns nie in seiner Liste angezeigt.
 * ==========================================================================================
 * Bis heute war dieser Aufbau aus der Erinnerung an einen Mitschnitt gebaut. Jetzt liegt der
 * echte daneben, 596 Byte, dreimal identisch von 192.168.0.50:4444 empfangen:
 *
 *   MSH|^~\&|||||||ADT^A01|101|P|2.3.1
 *   EVN||00000000|
 *   PID|||<Kennung des Monitors>||^|
 *   PV1||I|^^&&&4601&&1|||||||||||||||U|4294967040||
 *   OBX||ST|2304^MonitorName||M0001||||||F
 *   OBX||CE|2305^||0^||||||F      ... (13 weitere Felder)
 *
 * DIE DREI UNTERSCHIEDE, nach Gewicht:
 *
 *  1. PV1. Echt steht dort `^^&&&4601&&1` — die VIER als Ziffernfolge ist der TCP-Port, auf
 *     den sich der Veta verbindet. Wir schrieben `PV1|1|I|VETSTATION|`, also GAR KEINEN Port.
 *     Selbst wenn der Veta uns gesehen haette, haette er nicht gewusst, wohin. Das allein
 *     erklaert den Befund.
 *  2. Die OBX-Kennungen tragen echt ein `^` am Ende (`2305^`), unsere nicht. Ob das Geraet
 *     darauf achtet, wissen wir nicht — es kostet nichts, es genauso zu machen.
 *  3. EVN trug bei uns einen Zeitstempel, echt stehen dort acht Nullen. Ebenso 2306 (echt 1,
 *     bei uns 3) und 2307 (echt 1, bei uns 2).
 *
 * WAS HIER BEWUSST ANDERS BLEIBT ALS IM ORIGINAL:
 *   - der MonitorName (sonst waeren zwei Geraete gleich benannt),
 *   - die Kennung in PID. Das Original traegt dort die MAC des Monitors rueckwaerts
 *     (98:cc:e4:xx:xx:xx -> ...<Kennung>...). Wir setzen unsere eigene ein. Die Kennung
 *     des fremden Geraets zu uebernehmen waere die eine Aenderung, die wirklich schaden kann:
 *     der Veta haette dann zwei Teilnehmer mit derselben Identitaet.
 * Alles Uebrige wird WOERTLICH uebernommen, auch die Felder, deren Bedeutung wir nicht kennen.
 * Sie zu verstehen war nicht noetig; sie zu RATEN waere der Fehler gewesen.
 */
/*
 * Das Merkmalsfeld 2319: 16 Dreiergruppen. Gruppe 1 ist '001', die Gruppen 2 bis 7 sind die
 * sechs MAC-Bytes als dreistellige Dezimalzahlen, der Rest sind Nullen. Selbst nachgerechnet
 * am Mitschnitt: die Gruppen 2 bis 7 ergaben Byte fuer Byte die MAC des Praxis-Monitors.
 * (Sie steht hier nicht - genau diese Zahlen hat der Paket-Waechter beim Bau gemeldet, und
 * zwar ZU RECHT: wir haben sie vorher woertlich mitgesendet.)
 *
 * Was die uebrigen neun Gruppen bedeuten, wissen wir nicht - sie bleiben null, wie im
 * Original. Unbekanntes wird uebernommen, nicht erfunden.
 *
 * EINE LUECKE DES WAECHTERS, hier festgehalten: in DIESER Schreibweise (dreistellige
 * Dezimalzahlen ohne Trenner) haette er die MAC NICHT gefunden - er sucht die Hex-Form
 * "98:cc:e4:...". Gefunden hat er nur den erklaerenden Kommentar. Wer kuenftig eine Kennung
 * codiert ablegt, kommt an ihm vorbei.
 */
function merkmal(macBytes) {
  const drei = function (n) { return String(n).padStart(3, '0'); };
  const sechs = (macBytes && macBytes.length === 6 ? macBytes : [0, 0, 0, 0, 0, 0]).map(drei).join('');
  return '001' + sechs + '000000000000000000000000000';
}

function rundruf(name, ipZahl, kennung, port, macBytes) {
  const seg = [
    /* Der abschliessende Strich hinter 2.3.1 steht im echten Rundruf und fehlte hier. Ein
     * leeres Feld am Ende ist in HL7 nicht dasselbe wie ein fehlendes - und an genau dieser
     * Sorte Kleinigkeit ist die PDS-Abfrage sechs Wochen gescheitert. */
    'MSH|^~\\&|||||||ADT^A01|101|P|2.3.1|',
    'EVN||00000000|',
    'PID|||' + (kennung || name) + '||^|',
    /* Die Ziffernfolge zwischen den Trennzeichen ist der Port, auf dem wir erreichbar sind. */
    'PV1||I|^^&&&' + (port || 4601) + '&&1|||||||||||||||U|4294967040||',
    'OBX||ST|2304^MonitorName||' + name + '||||||F',
    'OBX||CE|2305^||0^||||||F',
    'OBX||CE|2306^||1^||||||F',
    'OBX||CE|4526^||1^||||||F',
    'OBX||CE|2307^||1^||||||F',
    'OBX||NM|2211^||0||||||F',
    'OBX||NM|4524^||0||||||F',
    'OBX||ST|2308^BedNoStr||||||||F',
    'OBX||ST|4527^||000000000000000000000000||||||F',
    'OBX||CE|4528^||16^||||||F',
    'OBX||ST|4529^||' + ipZahl + '||||||F',
    'OBX||CE|4530^||1^||||||F',
    /*
     * 2319 TRAEGT DIE MAC - UND WIR HABEN DIE DES FREMDEN GERAETS MITGESENDET (30.08.2026).
     *
     * Die 48 Ziffern zerfallen in 16 Dreiergruppen, und die Gruppen 2 bis 7 sind die sechs
     * MAC-Bytes als dreistellige Dezimalzahlen. Beim mitgeschnittenen Original ergeben sie
     * genau die MAC des Praxis-Monitors. Wir haben das Feld woertlich uebernommen - unser
     * Rundruf kuendigte also ein Geraet an, das die Kennung eines ANDEREN traegt. Dass der
     * Veta so etwas nicht annimmt, ist richtig von ihm; sein Protokoll nennt den Grund
     * ausdruecklich (closeReason=DeviceIdMismatch).
     *
     * Jetzt stehen dort UNSERE Bytes. Der Rest des Feldes bleibt aus dem Mitschnitt: seine
     * Bedeutung ist unbekannt, und Unbekanntes wird uebernommen, nicht erfunden.
     */
    'OBX||ST|2319^||' + merkmal(macBytes) + '||||||F',
    'OBX||CE|2320^||7^||||||F',
  ];
  /* Jedes Segment mit <CR> abgeschlossen, auch das letzte. Genau daran ist die PDS-Abfrage
   * wochenlang gescheitert (siehe hl7.js, Befund 29.08.2026) — derselbe Fehler wird hier
   * nicht wiederholt. */
  const text = seg.join('\r') + '\r';
  return Buffer.concat([Buffer.from([VT]), Buffer.from(text, 'latin1'), Buffer.from([FS_, CR])]);
}

function stempel(d) {
  const t = d || new Date();
  const z = (n, b) => String(n).padStart(b || 2, '0');
  return t.getFullYear() + z(t.getMonth() + 1) + z(t.getDate()) +
    z(t.getHours()) + z(t.getMinutes()) + z(t.getSeconds());
}

/* Die eigenen IPv4-Adressen samt Rundrufadresse des jeweiligen Netzes. Der Rundruf muss in
 * DAS Netz gehen, in dem die Geraete stehen — auf diesem PC gibt es zwei (Hausnetz und
 * Geraetenetz, siehe die Notiz "zwei Netze, ein Kabel"). */
function netze() {
  const raus = [];
  const alle = os.networkInterfaces();
  Object.keys(alle).forEach(function (name) {
    (alle[name] || []).forEach(function (a) {
      if (a.family !== 'IPv4' || a.internal) return;
      const ip = a.address.split('.').map(Number);
      const mask = String(a.netmask || '255.255.255.0').split('.').map(Number);
      const rund = ip.map((o, i) => (o & mask[i]) | (~mask[i] & 255)).join('.');
      /*
       * Kennung in der Bauform des echten Geraets: dessen PID trug
       * "<Kennung des Monitors>" bei der MAC 98:cc:e4:xx:xx:xx - also die ersten
       * vier Bytes RUECKWAERTS, dann die letzten zwei rueckwaerts, dann ein fester Rest.
       * Nachgerechnet: 98 cc e4 00 -> 00e4cc98,  d5 eb -> ebd5. Passt zeichengenau.
       * Fehlt die MAC (kann bei manchen Karten vorkommen), bleibt die Kennung leer und der
       * Aufrufer setzt den Namen ein - lieber ein erkennbarer Ersatz als eine erfundene MAC.
       */
      const mac = String(a.mac || '').split(':');
      /*
       * DER HERSTELLERBLOCK MUSS MINDRAY SEIN (Befund 30.08.2026, am Geraet gemessen).
       *
       * Mit einer Kennung aus der ECHTEN PC-MAC war unser Rundruf auf der Leitung Byte fuer
       * Byte der des Monitors - und der Veta hat uns trotzdem nicht angezeigt. Das einzige,
       * was dann noch trennt, ist der Inhalt der Kennung selbst: das Original beginnt mit
       * 98:cc:e4 (Mindray), unsere PC-Karte mit einem fremden Block. Ein Narkosegeraet, das
       * nur Mindray-Monitore anbieten soll, prueft genau das.
       *
       * Deshalb: Herstellerblock 98:cc:e4 wie beim Original, die drei GERAETEBYTES aber aus
       * unserer eigenen MAC. So sind wir im richtigen Block und trotzdem eindeutig ein anderes
       * Geraet als der Monitor - die Kennung des fremden Geraets zu uebernehmen waere die eine
       * Aenderung, die wirklich Schaden anrichten kann (zwei Teilnehmer, eine Identitaet).
       *
       * Das bleibt im Praxisnetz und dient dazu, die EIGENEN Geraete miteinander zu verbinden.
       */
      const OUI = ['98', 'cc', 'e4'];
      const eigen = mac.length === 6 ? [mac[3], mac[4], mac[5]] : null;
      const kennung = eigen && eigen.join('') !== '000000'
        ? (eigen[0] + OUI[2] + OUI[1] + OUI[0] + '-' + eigen[2] + eigen[1] + '-087e-1e0d001e04004a00')
        : null;
      /*
       * Die MAC als Zahlen fuer das Merkmalsfeld 2319. Der Herstellerblock wird durch den von
       * Mindray ersetzt - aus demselben Grund wie bei der Kennung eine Zeile darueber, und mit
       * denselben eigenen Endbytes. So steht in 2319 UNSERE Kennung und nicht die des Monitors.
       */
      const macZahlen = mac.length === 6
        ? [0x98, 0xcc, 0xe4, parseInt(mac[3], 16), parseInt(mac[4], 16), parseInt(mac[5], 16)]
        : null;
      raus.push({ karte: name, ip: a.address, maske: a.netmask, rundruf: rund,
        kennung: kennung, macZahlen: macZahlen });
    });
  });
  return raus;
}

function argw(name, ersatz) {
  const i = process.argv.indexOf('--' + name);
  return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : ersatz;
}

function main() {
  if (process.argv.indexOf('--hilfe') > 0) {
    console.log('node tools/monitor-nachbau.js [--name VETSTATION] [--minuten 10] [--ordner data]');
    console.log('  Gibt den PC als Mindray-Monitor aus und schneidet mit, was sich verbindet.');
    console.log('  Sendet NUR den Namensrundruf - keine Messwerte, keine Steuerung.');
    return;
  }
  const name = argw('name', 'VETSTATION');
  const minuten = Math.max(1, Math.min(120, Number(argw('minuten', 10)) || 10));
  const ordner = argw('ordner', path.join(__dirname, '..', 'data'));
  /*
   * 3504 STEHT VORN - UND ZWAR GEMESSEN, NICHT GERATEN (30.08.2026).
   *
   * Der Veta schreibt selbst mit. In seinem USB-Service-Export liegt systemLog.log mit den
   * Klassennamen seiner eigenen Software und jedem Kopplungsereignis auf die Sekunde. Darin
   * steht in ALLEN 48 NetworkNotifyReceived-Zeilen dasselbe Ziel:
   *
   *     Session Destroy: peer=<Monitor-IP>:3504, closeReason=DeviceIdMismatch
   *                                        ^^^^
   *
   * Er verbindet sich auf 3504 - OBWOHL der Rundruf des Monitors in PV1 den Port 4601
   * ankuendigt. Wir haben den ganzen Nachmittag auf 4601 gewartet und dort auf niemanden
   * gehorcht, weil dort die VetStation sitzt. 3504 ist frei.
   *
   * Diese Quelle lag seit dem 29.08.2026 hier und ist nie benutzt worden. Vier Messreihen am
   * Netz (97 Ports, zwei Wachposten, Rundrufvergleich Byte fuer Byte) haetten sie nicht
   * ersetzt: das Geraet sagt selbst, wohin es geht.
   */
  const PORTS = [3504, 4601, 5000, 8830, 3502, 5100];
  /*
   * WELCHEN PORT DER RUNDRUF ANKUENDIGT: den, auf dem wir WIRKLICH lauschen.
   *
   * Bisher stand dort fest 4601 - abgeschrieben vom echten Monitor. Nur kann der Nachbau 4601
   * gar nicht belegen, solange die VetStation laeuft; er wich still auf einen anderen Port aus
   * und kuendigte trotzdem 4601 an. Wer dorthin kam, landete bei der Station, nicht bei uns.
   * Eine Ankuendigung, die auf eine fremde Tuer zeigt, ist schlimmer als gar keine.
   * Wird gesetzt, sobald der erste Port wirklich offen ist (unten bei listen()).
   */
  let angekuendigterPort = null;

  const netz = netze();
  console.log('=======================================================================');
  console.log(' VetStation - Monitor-Nachbau   (der PC gibt sich als Monitor aus)');
  console.log('=======================================================================');
  console.log('');
  console.log('Name im Netz:      ' + name);
  console.log('Laufzeit:          ' + minuten + ' Minuten');
  console.log('Eigene Adressen:');
  netz.forEach(function (n) {
    console.log('   ' + n.ip.padEnd(16) + ' Karte ' + n.karte + '   Rundruf an ' + n.rundruf);
  });
  if (!netz.length) {
    console.log('   KEINE - dieser PC hat keine Netzadresse. Abgebrochen.');
    process.exit(2);
  }
  console.log('');

  /* --- Mitschnitt vorbereiten. Ein Ordner, der sich nicht beschreiben laesst, faellt SOFORT
   * auf und nicht erst nach zehn Minuten Messung. --- */
  let datei = null;
  try {
    fs.mkdirSync(ordner, { recursive: true });
    const probe = path.join(ordner, '.schreibprobe-' + process.pid);
    fs.writeFileSync(probe, 'x'); fs.unlinkSync(probe);
    datei = path.join(ordner, 'veta-mitschnitt-' + stempel() + '.bin');
  } catch (e) {
    console.log('Der Ordner ' + ordner + ' laesst sich nicht beschreiben: ' + e.message);
    console.log('Abgebrochen - ohne Mitschnitt waere die Messung verloren.');
    process.exit(3);
  }
  console.log('Mitschnitt:        ' + datei);
  console.log('');

  /* --- Zuhoeren, bevor gerufen wird: sonst verpasst man eine Verbindung, die sofort kommt. */
  const server = [];
  let verbindungen = 0, bytes = 0;
  PORTS.forEach(function (p) {
    const s = net.createServer(function (sock) {
      verbindungen++;
      const wer = sock.remoteAddress + ':' + sock.remotePort;
      console.log('');
      console.log('*** ' + uhr() + '  VERBINDUNG auf Port ' + p + ' von ' + wer + ' ***');
      sock.on('data', function (b) {
        bytes += b.length;
        try { fs.appendFileSync(datei, b); } catch (_) {}
        console.log('   ' + uhr() + '  ' + String(b.length).padStart(5) + ' Byte   ' + deute(b));
      });
      sock.on('error', function () {});
      sock.on('close', function () { console.log('   ' + uhr() + '  Verbindung von ' + wer + ' beendet.'); });
    });
    s.on('error', function (e) {
      console.log('Port ' + p + ' laesst sich nicht belegen (' + e.code + ')' +
        (e.code === 'EADDRINUSE' ? ' - laeuft die VetStation noch? Sie muss dafuer angehalten werden.' : ''));
    });
    s.listen(p, function () {
      if (angekuendigterPort == null) angekuendigterPort = p;   /* der erste, der wirklich aufgeht */
      console.log('lausche auf TCP ' + p + (angekuendigterPort === p ? '   <- dieser wird angekuendigt' : ''));
    });
    server.push(s);
  });

  /* --- Der Rundruf, im Sekundentakt wie beim echten Geraet. --- */
  const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  sock.on('error', function (e) {
    if (e && e.code === 'EADDRINUSE') {
      console.log('Quellport 4444 ist belegt - es wird von einem zufaelligen Port gesendet.');
      try { sock.bind(function () { try { sock.setBroadcast(true); } catch (_) {} }); } catch (_) {}
      return;
    }
    console.log('UDP-Fehler: ' + e.message);
  });
  /*
   * VON PORT 4444 SENDEN, NICHT VON EINEM ZUFAELLIGEN (30.08.2026).
   *
   * Von der Leitung genommen und verglichen: unser Rundruf ist inzwischen Byte fuer Byte der
   * des echten Geraets - bis auf Name und Kennung, die verschieden sein MUESSEN. Ein
   * Unterschied blieb, und er stand nicht im Inhalt, sondern im Umschlag:
   *
   *     echter uMEC12   192.168.0.50:4444  -> 4600
   *     unser Nachbau   192.168.0.99:51033 -> 4600
   *
   * Ein Geraet, das sich ankuendigt, benutzt einen FESTEN Quellport; 51033 vergibt das
   * Betriebssystem bei jedem Start neu. Ob der Veta darauf achtet, wissen wir nicht - aber es
   * ist der letzte messbare Unterschied, und er kostet nichts.
   *
   * Schlaegt das Binden fehl (Port belegt), wird trotzdem gesendet: ein Rundruf vom falschen
   * Port ist besser als gar keiner, und die Meldung sagt, woran es lag.
   */
  sock.bind(4444, function () {
    try { sock.setBroadcast(true); } catch (_) {}
    console.log('');
    console.log('rufe jede Sekunde auf UDP 4600 (Quellport 4444, wie das echte Geraet) ...');
    console.log('');
    console.log('JETZT am Veta:  System -> Setup -> "Monitor verbunden" -> "Aktualisieren"');
    console.log('                Er verbindet sich VON SELBST, sobald er uns sieht -');
    console.log('                "Aktualisieren" und "Verbinden" muss niemand druecken');
    console.log('                (aus dem Protokoll des Veta, 30.08.2026).');
    console.log('');
  });

  let rufe = 0;
  /*
   * ZWEI ZAEHLER, WEIL SIE VERSCHIEDENES BEDEUTEN (30.08.2026).
   * Bis heute stand am Ende "N Rundrufe gesendet" - gezaehlt wurden aber TAKTE, nicht
   * abgeschickte Pakete, und Sendefehler verschluckte der leere Rueckruf. Die Zahl war eine
   * gruene Anzeige ohne Deckung, und an genau der Sorte ist dieses Projekt schon mehrfach
   * haengengeblieben. Jetzt zaehlt  die Pakete und  die misslungenen.
   */
  let gesendet = 0, fehler = 0;
  const takt = setInterval(function () {
    netz.forEach(function (n) {
      /*
       * Die Kennung wird aus der EIGENEN MAC gebaut, in derselben Bauform wie beim echten
       * Geraet: die ersten vier Bytes rueckwaerts, dann die letzten zwei rueckwaerts.
       * (98:cc:e4:xx:xx:xx -> <Kennung>-...). Der feste Rest stammt aus dem Mitschnitt.
       */
      const b = rundruf(name, '001013000001', n.kennung, angekuendigterPort, n.macZahlen);
      /*
       * NUR AN DIE EIGENE NETZ-RUNDRUFADRESSE - NICHT MEHR AN 255.255.255.255 (30.08.2026).
       *
       * Von der Leitung gezaehlt: es gingen VIER Rundrufe je Sekunde hinaus. Einer mit
       * Absender 192.168.0.99 (dem Netz des Veta) und DREI mit Absender 192.168.2.81, einem
       * Netz, in dem er gar nicht steht. Der Rundruf traegt seine Adresse nirgends im Text -
       * der Empfaenger kann sie nur dem Absenderfeld entnehmen. Drei von vier Meldungen
       * nannten ihm also die falsche Adresse.
       *
       * Ursache war der zweite Aufruf: bei 255.255.255.255 waehlt das Betriebssystem die
       * Quelladresse selbst, und diese Karte traegt zwei. Die gerichtete Rundrufadresse des
       * Netzes (192.168.0.255) laesst ihm diese Wahl nicht - sie fuehrt ueber genau ein Netz.
       * 255.255.255.255 bringt keinen Empfaenger dazu, der ueber die gerichtete Adresse nicht
       * ohnehin erreicht wird; es hat nur Verwirrung gestiftet.
       */
      sock.send(b, 0, b.length, 4600, n.rundruf, function (e) { if (e) fehler++; else gesendet++; });
    });
    rufe++;
  }, 1000);

  const ende = setTimeout(function () {
    clearInterval(takt);
    try { sock.close(); } catch (_) {}
    server.forEach(function (s) { try { s.close(); } catch (_) {} });
    console.log('');
    console.log('=======================================================================');
    console.log(' Fertig. ' + rufe + ' Takte, ' + gesendet + ' Pakete wirklich abgeschickt'
      + (fehler ? ', ' + fehler + ' FEHLGESCHLAGEN' : '') + '.');
    if (!verbindungen) {
      console.log('');
      console.log(' KEINE Verbindung. Der Veta hat sich nicht gemeldet.');
      console.log('');
      console.log(' WAS DAS HEISST - und was es NICHT heisst:');
      console.log('   Es heisst NICHT, dass der Weg falsch ist. Es heisst nur, dass DIESER');
      console.log('   Rundruf nicht genuegt hat. Moegliche Gruende, in dieser Reihenfolge:');
      console.log('   1. Am Veta wurde "Aktualisieren" nicht gedrueckt oder der Name stand');
      console.log('      nicht in der Liste - dann hat der Rundruf ihn nicht erreicht');
      console.log('      (falsches Netz? Firewall? "GERAETE-PRUEFEN.bat" zeigt das Netz).');
      console.log('   2. Der Name stand da, "Verbinden" schlug fehl - dann stimmt der Port');
      console.log('      nicht; dieser Nachbau lauscht auf ' + PORTS.join(', ') + '.');
      console.log('   3. Der Veta prueft mehr als den Namen (Kennung, Version, Antwort auf');
      console.log('      eine Rueckfrage). Dann braucht es einen Mitschnitt der ECHTEN');
      console.log('      Anmeldung zwischen Veta und uMEC12 - siehe "CaptureNetPackage" im');
      console.log('      Netzwerk-Setup des Monitors.');
    } else {
      console.log('');
      console.log(' ' + verbindungen + ' Verbindung(en), ' + bytes + ' Byte empfangen.');
      console.log(' Mitschnitt: ' + datei);
      console.log('');
      console.log(' NAECHSTER SCHRITT:');
      console.log('   node tools/binaer-analyse.js "' + datei + '"');
      console.log('   Sie sagt, ob es HL7 ist (dann liest VetStation es direkt) oder Binaer');
      console.log('   (dann zeigt sie, welche Byte-Stellen sich AENDERN - das sind die');
      console.log('   Kandidaten fuer Datenfelder).');
    }
    console.log('=======================================================================');
    process.exit(0);
  }, minuten * 60000);
  ende.unref && null;
}

function uhr() {
  const t = new Date();
  const z = (n) => String(n).padStart(2, '0');
  return z(t.getHours()) + ':' + z(t.getMinutes()) + ':' + z(t.getSeconds());
}

/*
 * Eine erste Einordnung des Empfangenen - mehr nicht. HL7 ueber MLLP beginnt zwingend mit
 * 0x0B; Mindrays MD2 hat den Rahmen 0x02 (STX) und das Sync-Wort A5 5A (belegt aus
 * probe-*.log, Juli 2026). Alles andere heisst "unbekannt" und wird NICHT gedeutet.
 */
function deute(b) {
  if (!b.length) return '(leer)';
  const hex = b.slice(0, 12).toString('hex').replace(/(..)/g, '$1 ').trim();
  if (b[0] === VT) return 'HL7/MLLP   ' + b.slice(1, 60).toString('latin1').replace(/[\r\n]/g, ' ');
  if (b[0] === 0x02) return 'MD2? (STX) ' + hex;
  if (b.indexOf(Buffer.from([0xa5, 0x5a])) >= 0) return 'MD2? (Sync A5 5A) ' + hex;
  if (/^MSH\|/.test(b.slice(0, 4).toString('latin1'))) return 'HL7 ohne Rahmen  ' + b.slice(0, 60).toString('latin1');
  return 'unbekannt  ' + hex;
}

if (require.main === module) main();
module.exports = { rundruf, netze, deute, stempel };
