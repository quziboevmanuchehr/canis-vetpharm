'use strict';
/*
 * erstsuche.js — DIE STATION SUCHT VON SELBST. Ohne Klick, ohne Anleitung, ohne IP-Eintrag.
 *
 * WARUM ES DIESE DATEI GIBT (Wunsch 31.07.2026, woertlich): "Das App bei der Installieren und
 * schon starten muss direkt die Andere OP Saal PC und auch die Geraete Monitor, Narkosegeraet etc
 * die direkt bei dem Netz verbunden sind automatisch finden."
 *
 * WAS VORHER WAR — und warum das nicht genuegte:
 * Alle Bausteine dafuer lagen bereits da, aber JEDER brauchte einen Menschen, der etwas anstoesst:
 *   - netscan.scan() findet Geraete zuverlaessig, wurde aber ausschliesslich aus dem Admin-Bereich
 *     gestartet (Admin -> Netzwerk & Geraete -> "Suche starten"). bridge/src/index.js sagt das im
 *     Kopfkommentar ausdruecklich: "Bewusst KEIN voller Netzwerkscan beim Start."
 *   - Der Verbindungs-Assistent (probe) nimmt Geraete entgegen, die VON SICH AUS zum PC senden.
 *     Ein Geraet, das nur LAUSCHT (offener Datenport, wartet auf die Abfrage des PCs), erreicht er
 *     nicht — dafuer braucht es einen Eintrag in bridge/config/devices.json. Die Datei existiert
 *     nach der Installation NICHT (Install-VetStation.ps1 schliesst sie per robocopy /XF aus), und
 *     im ganzen Quellcode gab es keine Stelle, die sie schreibt.
 * Ergebnis in der Praxis: ein frisch installierter zweiter OP-Saal stand da und fand nichts, obwohl
 * Monitor und Narkosegeraet im selben Netz haengen. Das behebt diese Datei.
 *
 * DIE GRENZE, DIE HIER NICHT VERSCHOBEN WIRD: gefunden wird automatisch, GERATEN wird nichts.
 * Ein Geraet, das auf einem Datenport antwortet, aber dort kein HL7 spricht (der Veta 5 Plus sendet
 * auf 4601 Mindray-MD2, siehe docs/VETA5-MITSCHNITT.md), wird nach einer Bewaehrungszeit wieder
 * abgeschaltet und ausdruecklich vermerkt — statt als "Geraet verbunden" ohne Werte stehenzubleiben.
 * Ein geratener Wert am narkotisierten Tier ist der schlimmste Fehler, den dieses Programm machen
 * kann; ein ehrliches "gefunden, spricht aber kein HL7" ist der zweitbeste Zustand nach Erfolg.
 *
 * WAS MIT DEM NACHBAR-SAAL IST — und warum hier kein zweiter Erkennungsweg entsteht:
 * Zwei Praxis-PCs finden einander ueber ihr GEMEINSAMES Praxis-Konto (tafel/<sid> und
 * verbund/lan/<sid> im selben Konto, siehe docs/PLAN-MEHRERE-SAELE.md). Das ist der Hauptweg und
 * braucht ueberhaupt keine Suche. Diese Datei ergaenzt ihn nur um das, was eine Suche beitragen
 * kann: sie SAGT im Klartext, dass auf 192.168.0.x offenbar eine zweite VetStation laeuft, und
 * traegt die Adresse als Kandidaten fuer den LAN-Weg (Port 8771) ein. Sie stellt damit KEIN
 * Vertrauen her — wer ein Nachbarsaal ist, entscheidet allein der signierte Handschlag in
 * bridge/src/nachbar.js. Eine Adresse ist ein Hinweis, kein Ausweis.
 *
 * STRIKT READ-ONLY gegenueber allen Geraeten: es wird geklopft (TCP-Verbindungsversuch) und die
 * ARP-Tabelle des PCs gelesen. An keinem Geraet wird etwas verstellt.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');

const netscan = require('./netscan');
const geraetefund = require('./geraetefund');

/* ------------------------------------------------------------------ *
 * Konstanten. Alle mit Begruendung — eine Zahl ohne Grund wird spaeter
 * von jemandem geaendert, der den Grund nicht kennt.
 * ------------------------------------------------------------------ */

/* Erster Lauf 20 s nach dem Start. Nicht sofort: der Geraeteempfang, die Oberflaeche und die
 * Fern-Anmeldung sollen zuerst stehen. Ein Suchlauf belegt ~250 kurze TCP-Versuche und wuerde
 * sonst mit dem Start konkurrieren. Nicht spaeter: wer eine Station aufstellt, steht davor und
 * wartet auf ein Lebenszeichen. */
const ERSTER_LAUF_MS = 20 * 1000;

/* Abstaende der Wiederholungen, solange NICHTS gefunden wurde. Wachsend, weil eine Praxis ohne
 * Geraete im Netz sonst jahrelang ihr eigenes Subnetz anklopft (derselbe Grund wie Befund B2-10
 * im Plan). Nach dem letzten Wert bleibt es bei 30 min. */
const ABSTAENDE_MS = [2 * 60 * 1000, 10 * 60 * 1000, 30 * 60 * 1000];

/* Wurde etwas gefunden UND liefert es Werte, hoert die Suche ganz auf. Sie ist dann fertig —
 * ein laufender Betrieb braucht keine Suche, und geraetefund.js folgt einem Adresswechsel
 * ohnehin ohne Suchlauf. */
const BEWEIS_MS = 90 * 1000;

/* Hoechstens so viele Adapter je Lauf neu eintragen. Ein Router-Netz mit vielen Teilnehmern
 * duerfte sonst die Konfiguration fluten. Vier ist eine Praxis mit Monitor, Narkosegeraet,
 * Kapnograph und einem Reservegeraet — mehr haengt an keinem OP-Tisch. */
const NEUE_ADAPTER_MAX = 4;

/* Der Nachbar-Port aus dem Plan (Stufe 2). Er steht hier NUR als Klopfziel und darf NIE in
 * netscan.DATA_PORTS wandern: ein Datenport macht einen Teilnehmer zum "sicheren Geraet", und
 * eine zweite VetStation ist kein Geraet. tools/paket-test.js erzwingt diese Trennung. */
const NACHBAR_PORT = 8771;

/* Der Oberflaechen-Port der Station. Antwortet ein FREMDER PC dort, laeuft dort sehr
 * wahrscheinlich VetStation. "Sehr wahrscheinlich" ist hier ehrlich und ausreichend: der Beweis
 * kommt aus dem signierten Handschlag, nicht aus einem offenen Port. */
const STATION_PORT = 8770;

const KLOPF_MS = 350;

/* ------------------------------------------------------------------ *
 * Reine Funktionen — einzeln pruefbar, ohne Netz, ohne Uhr, ohne Datei.
 * ------------------------------------------------------------------ */

/*
 * darfSuchen(lage) — die einzige Stelle, die "jetzt nicht" sagen darf.
 *
 * WICHTIGSTE REGEL: waehrend an einem Geraet ein Patient haengt (Status 'active') wird NICHT
 * gesucht. Der Suchlauf oeffnet in kurzer Folge hunderte TCP-Verbindungen; auf dem Kiosk-i3
 * konkurriert das mit dem Empfang der Vitalwerte. Eine Narkose hat immer Vorrang vor Bequemlichkeit.
 * Dieselbe Sperre gilt laut Plan-Schritt 3 auch fuer den Suchlauf aus dem Admin-Bereich.
 */
/*
 * WIE LANGE GILT EIN GERAET ALS "AM PATIENTEN"? (korrigiert 01.08.2026)
 *
 * Bis hierher zaehlte darfSuchen() nur Geraete mit status 'active' — und 'active' ist ein Geraet
 * laut registry.js nur 5 SEKUNDEN nach seinem letzten Paket. Ein LifeVet 10C sendet ab Werk aber
 * nur alle ~30 s. Zwischen zwei Paketen galt der laufende Fall damit als "kein Patient da", und
 * der Suchlauf durfte losklopfen — mitten in der Narkose. Die Sperre, die genau das verhindern
 * sollte, war die meiste Zeit offen.
 *
 * Massgeblich ist deshalb nicht der Status, sondern WANN ZULETZT etwas ankam. 3 Minuten decken
 * jeden ueblichen Sendetakt ab (das langsamste bekannte Geraet meldet sich alle 30 s) und sind
 * kurz genug, dass eine beendete Narkose die Suche nicht stundenlang blockiert.
 */
const PATIENT_STILL_MS = 3 * 60 * 1000;

function darfSuchen(lage) {
  const l = lage || {};
  if (l.laeuftSchon) return { ok: false, grund: 'Es laeuft bereits eine Suche.' };
  /* Die neue, belastbare Zahl: Geraete, von denen in den letzten 3 Minuten etwas kam.
   * `aktiveGeraete` bleibt als Rueckfall stehen — ein Aufrufer, der die neue Angabe nicht
   * liefert, soll nicht stillschweigend jede Sperre verlieren. */
  const belegt = Number.isFinite(l.geraeteMitDaten) ? l.geraeteMitDaten : (l.aktiveGeraete || 0);
  if (belegt > 0) {
    return { ok: false, grund: 'An diesem PC haengt gerade ein Patient am Geraet (' + belegt +
      ' Geraet' + (belegt === 1 ? '' : 'e') + ' hat in den letzten ' + Math.round(PATIENT_STILL_MS / 60000) +
      ' Minuten Werte geliefert). Der Suchlauf wartet, bis die Narkose vorbei ist — er wuerde sonst ' +
      'mit dem Empfang der Vitalwerte um dieselbe Netzkarte konkurrieren.' };
  }
  if (!l.echteKarten) {
    return { ok: false, grund: 'Dieser PC hat keine echte Netzwerkkarte (nur virtuell/VPN). ' +
      'Es gibt kein Netz, in dem gesucht werden koennte — LAN-Kabel oder WLAN pruefen.' };
  }
  return { ok: true, grund: null };
}

/*
 * abstandMs(versuche) — wie lange bis zum naechsten Lauf, wenn nichts gefunden wurde.
 * Waechst und bleibt dann stehen. Bewusst kein Zufall: der Abstand soll vorhersagbar sein,
 * damit ein Techniker vor Ort weiss, wann er wieder hinsehen muss.
 */
function abstandMs(versuche) {
  const i = Math.max(0, Number(versuche) || 0);
  return ABSTAENDE_MS[Math.min(i, ABSTAENDE_MS.length - 1)];
}

/* Deckt ein bereits eingeschalteter Adapter diese Adresse und diesen Port schon ab? */
function schonAbgedeckt(ip, port, vorhandene) {
  return (vorhandene || []).some((a) => {
    if (!a || a.enabled === false) return false;
    if (a.type !== 'hl7') return false;
    if (a.mode === 'listener') return false;
    const p = Number(a.port) || 0;
    if (p !== Number(port)) return false;
    /* "auto" folgt dem gefundenen Geraet (geraetefund.js) — es deckt jede Medizinadresse auf
     * diesem Port ab. Genau deshalb ist "auto" in devices.example.json empfohlen. */
    return a.host === 'auto' || a.host === ip;
  });
}

/*
 * adapterVorschlaege(geraete, vorhandene, gesperrt) — was muesste eingetragen werden?
 *
 * ZWEI FAELLE, und die Unterscheidung ist der ganze Witz dieser Funktion:
 *  (a) Das Geraet hat einen OFFENEN Datenport. Dann lauscht es und wartet darauf, dass der PC es
 *      abfragt. Der Verbindungs-Assistent erreicht es NIE (der lauscht selbst). Es braucht einen
 *      Client-Adapter — den tragen wir ein.
 *  (b) Das Geraet hat KEINEN offenen Datenport, ist aber an der MAC als Medizingeraet erkannt
 *      (netscan: 'sendetVermutlich'). Dann sendet es von sich aus zum PC, und der
 *      Verbindungs-Assistent nimmt es bereits entgegen. Ein zusaetzlicher Client-Adapter waere hier
 *      schaedlich: dasselbe physische Geraet erschiene zweimal, mit zwei Geraetesaetzen und zwei
 *      Patientenzeilen. Also NICHTS eintragen und das auch so begruenden.
 */
function adapterVorschlaege(geraete, vorhandene, gesperrt) {
  const aus = [];
  const sperre = gesperrt || {};
  (geraete || []).forEach((g) => {
    if (!g || !g.ip) return;
    const ports = (g.datenPorts || []).filter((p) => netscan.DATA_PORTS.indexOf(p) >= 0);
    if (!ports.length) {
      if (g.sendetVermutlich) {
        aus.push({ ip: g.ip, adapter: null,
          grund: 'sendet von sich aus zum PC — der Verbindungs-Assistent nimmt es bereits entgegen, ' +
                 'ein zweiter Eintrag wuerde dasselbe Geraet doppelt anzeigen' });
      }
      return;
    }
    ports.forEach((port) => {
      const schluessel = g.ip + ':' + port;
      if (sperre[schluessel]) {
        aus.push({ ip: g.ip, port: port, adapter: null,
          grund: 'schon einmal versucht: ' + sperre[schluessel] });
        return;
      }
      if (schonAbgedeckt(g.ip, port, vorhandene)) {
        aus.push({ ip: g.ip, port: port, adapter: null, grund: 'ein eingeschalteter Adapter deckt das bereits ab' });
        return;
      }
      aus.push({
        ip: g.ip, port: port,
        adapter: {
          type: 'hl7',
          id: 'auto-' + g.ip.split('.').join('-') + '-' + port,
          enabled: true,
          mode: 'client',
          host: g.ip,
          port: port,
          model: (g.hersteller ? g.hersteller : 'Geraet') + ' (automatisch gefunden)',
          role: 'combo',
          species: null,
          ack: true,
          _automatisch: 'Von der Station selbst eingetragen (bridge/src/erstsuche.js), weil dieser ' +
            'Teilnehmer auf Datenport ' + port + ' antwortet. Liefert er binnen ' +
            Math.round(BEWEIS_MS / 1000) + ' s kein lesbares HL7, wird der Eintrag wieder ' +
            'abgeschaltet und der Grund vermerkt.',
        },
        grund: 'antwortet auf Datenport ' + port + ' und wird von keinem eingeschalteten Adapter abgefragt',
      });
    });
  });
  /* Deckel NACH der Begruendung: die uebrigen Funde bleiben in der Liste stehen (mit Grund), nur
   * eingetragen werden hoechstens NEUE_ADAPTER_MAX. Stilles Abschneiden waere eine Luege im Log. */
  let gebaut = 0;
  return aus.map((v) => {
    if (!v.adapter) return v;
    if (++gebaut > NEUE_ADAPTER_MAX) {
      return { ip: v.ip, port: v.port, adapter: null,
        grund: 'Deckel erreicht (hoechstens ' + NEUE_ADAPTER_MAX + ' automatische Eintraege je Lauf) — ' +
               'dieser Fund wird beim naechsten Lauf beruecksichtigt' };
    }
    return v;
  });
}

/*
 * stationsVerdacht(hosts, eigeneIps) — welche Teilnehmer sind vermutlich ein ZWEITER Praxis-PC?
 *
 * Zwei unabhaengige Merkmale, beide schon vorhanden:
 *  - netscan.classifyHost setzt zweiteStation:true, wenn ein Teilnehmer auf vier oder mehr
 *    Datenports gleichzeitig antwortet. Genau so verhaelt sich der Verbindungs-Assistent; ein
 *    echter Monitor oeffnet hoechstens einen Port (beobachtet 22.07.2026 an 192.168.0.233).
 *  - der offene Oberflaechen-Port 8770 oder der Nachbar-Port 8771.
 * Die EIGENEN Adressen fliegen raus. Ohne das spricht die Station mit sich selbst und beschriftet
 * es als Nachbarsaal — im Plan der toedliche Befund A2-8, und er ist hier besonders naheliegend,
 * weil docs/LAN-SETUP.md JEDEM Praxis-PC dieselbe 192.168.0.99 vorschreibt.
 */
function stationsVerdacht(hosts, eigeneIps) {
  const eigen = {};
  (eigeneIps || []).forEach((ip) => { eigen[ip] = true; });
  const aus = [];
  (hosts || []).forEach((h) => {
    if (!h || !h.ip || eigen[h.ip] || h.selbst) return;
    const offen = h.offenePorts || [];
    const gruende = [];
    if (h.zweiteStation) gruende.push('antwortet auf mehrere Datenports gleichzeitig — so verhaelt sich der Verbindungs-Assistent von VetStation');
    if (offen.indexOf(STATION_PORT) >= 0) gruende.push('Oberflaechen-Port ' + STATION_PORT + ' offen');
    if (offen.indexOf(NACHBAR_PORT) >= 0) gruende.push('Nachbar-Port ' + NACHBAR_PORT + ' offen');
    if (!gruende.length) return;
    aus.push({
      ip: h.ip,
      nachbarPort: offen.indexOf(NACHBAR_PORT) >= 0,
      gruende: gruende,
      /* Bewusst KEIN Vertrauen, kein Name, keine sid. Wer ein Nachbarsaal ist, entscheidet der
       * signierte Handschlag in nachbar.js — eine Adresse ist ein Hinweis, kein Ausweis. */
      geprueft: false,
    });
  });
  return aus.sort((a, b) => Number(a.ip.split('.')[3]) - Number(b.ip.split('.')[3]));
}

/*
 * zusammenfassung(...) — der EINE Satz, den ein Mensch nach dem Aufstellen lesen will.
 * Er steht im Log und im Admin-Bereich. Er nennt Zahlen, keine Stimmung.
 */
function zusammenfassung(erg) {
  const e = erg || {};
  const g = (e.geraete || []).length;
  const neu = (e.eingetragen || []).length;
  const st = (e.stationen || []).length;
  const teile = [];
  teile.push(g === 0 ? 'kein Medizingeraet gefunden'
    : g + ' Medizingeraet' + (g === 1 ? '' : 'e') + ' gefunden (' + (e.geraete || []).map((x) => x.ip).join(', ') + ')');
  if (neu) teile.push(neu + ' Geraet' + (neu === 1 ? '' : 'e') + ' selbst eingetragen — kein Neustart noetig');
  teile.push(st === 0 ? 'keine zweite VetStation im Netz gesehen'
    : st + ' weitere' + (st === 1 ? 'r' : '') + ' Praxis-PC im Netz (' + (e.stationen || []).map((x) => x.ip).join(', ') + ')');
  return teile.join('; ') + '.';
}

/* ------------------------------------------------------------------ *
 * Der Ablauf.
 * ------------------------------------------------------------------ */

class Erstsuche {
  /*
   * scan()          — liefert das Ergebnis eines Netzwerkdurchlaufs (server.js reicht seinen
   *                   eigenen Suchlauf herein, damit es NIE zwei gleichzeitige Suchen gibt).
   * registry        — nur zum Nachsehen: laufen Adapter, kommen Werte an?
   * adapterStarten  — Rueckruf, der einen frisch eingetragenen Adapter SOFORT in Betrieb nimmt.
   *                   Ohne ihn waere ein Neustart noetig, und genau den soll niemand brauchen.
   */
  constructor(opts) {
    const o = opts || {};
    this.log = o.log || { info() {}, warn() {}, error() {} };
    this.registry = o.registry || null;
    this.scan = o.scan || null;
    this.adapterStarten = o.adapterStarten || null;
    this.konfigPfad = o.konfigPfad || path.join(__dirname, '..', 'config', 'devices.json');
    this.beispielPfad = o.beispielPfad || path.join(__dirname, '..', 'config', 'devices.example.json');
    this.merkPfad = o.merkPfad || path.join(__dirname, '..', 'data', 'erstsuche.json');
    this.nachbarnPfad = o.nachbarnPfad || path.join(__dirname, '..', 'data', 'nachbarn.json');
    this.aus = o.enabled === false;
    /* Die eigenen Netzkarten kommen normalerweise vom Betriebssystem. Sie sind hier trotzdem
     * uebergebbar, weil an ihnen die Sperre "die eigene Adresse ist kein Nachbarsaal" haengt —
     * und eine Sperre, die sich nur auf dem Zielrechner pruefen laesst, wird nicht geprueft. */
    this.kartenQuelle = o.kartenQuelle || (() => netscan.localAdapters().filter((k) => !k.virtuell));

    this.laeuft = false;
    this.versuche = 0;
    this.letzte = null;          // Ergebnis des letzten Laufs
    this.letzteTs = 0;
    this.fertig = false;         // nichts mehr zu tun
    this._timer = null;
    this._bewaehrung = [];       // { id, ip, port, bis }
    this._bewaehrungTimer = null;
    this.merk = this._merkLesen();
  }

  /* ---------------- Ablauf ---------------- */

  start() {
    if (this.aus) { this.log.info('erstsuche', 'Automatische Geraetesuche ist abgeschaltet (nachbarn/erstsuche in devices.json).'); return; }
    this._plane(ERSTER_LAUF_MS, 'erster Lauf nach dem Start');
  }

  stop() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (this._bewaehrungTimer) { clearInterval(this._bewaehrungTimer); this._bewaehrungTimer = null; }
  }

  _plane(ms, warum) {
    if (this._timer) clearTimeout(this._timer);
    this._timer = setTimeout(() => { this._timer = null; this.laufen().catch(() => {}); }, ms);
    if (this._timer.unref) this._timer.unref();
    this.log.info('erstsuche', 'Naechste automatische Suche in ' + Math.round(ms / 1000) + ' s (' + warum + ').');
  }

  lage() {
    const devs = this.registry ? this.registry.getDevices() : [];
    let karten = [];
    try { karten = this.kartenQuelle() || []; } catch (_) {}
    const jetzt = Date.now();
    return {
      laeuftSchon: this.laeuft,
      aktiveGeraete: devs.filter((d) => d.status === 'active').length,
      /* Siehe PATIENT_STILL_MS: der Status allein taugt nicht als Sperre, weil er nach 5 s
       * abfaellt, waehrend ein Monitor nur alle 30 s sendet. */
      geraeteMitDaten: devs.filter((d) => d.lastTs && (jetzt - d.lastTs) < PATIENT_STILL_MS).length,
      echteKarten: karten.length,
      eigeneIps: karten.map((k) => k.address),
    };
  }

  /*
   * laufen() — EIN Durchlauf. Wirft nie: alles, was hier schiefgehen kann, ist Komfort. Der
   * Geraeteempfang und das Narkoseprotokoll duerfen daran nicht haengen.
   */
  async laufen() {
    if (this.aus) return null;
    const lage = this.lage();
    const darf = darfSuchen(lage);
    if (!darf.ok) {
      this.log.info('erstsuche', 'Automatische Suche verschoben: ' + darf.grund);
      this._plane(abstandMs(this.versuche), 'Wiederholung');
      return null;
    }
    if (!this.scan) { this.log.warn('erstsuche', 'Kein Suchlauf hinterlegt — automatische Suche bleibt aus.'); return null; }

    this.laeuft = true;
    this.versuche++;
    let erg = { geraete: [], eingetragen: [], stationen: [], hinweise: [] };
    try {
      this.log.info('erstsuche', 'Automatische Suche laeuft (Lauf ' + this.versuche + '): eigenes Netz nach ' +
        'Medizingeraeten und weiteren Praxis-PCs absuchen. Das dauert etwa eine Minute und stoert nichts.');
      const netzErg = await this.scan();
      erg = await this._auswerten(netzErg, lage);
    } catch (e) {
      this.log.warn('erstsuche', 'Automatische Suche fehlgeschlagen: ' + (e && e.message) +
        '. Der Betrieb laeuft unveraendert weiter; der naechste Versuch kommt von selbst.');
    } finally {
      this.laeuft = false;
    }

    this.letzte = erg;
    this.letzteTs = Date.now();
    this.log.info('erstsuche', 'Automatische Suche fertig: ' + zusammenfassung(erg));
    (erg.hinweise || []).forEach((h) => this.log.info('erstsuche', h));

    /* Weiter suchen? Nur, solange nichts Brauchbares da ist. Sobald ein Geraet Werte liefert, ist
     * die Suche fertig — geraetefund.js folgt einem spaeteren Adresswechsel ohne Suchlauf. */
    const werte = this._liefertJemandWerte();
    if (werte) {
      this.fertig = true;
      this.log.info('erstsuche', 'Es kommen Werte an — die automatische Suche wird nicht mehr wiederholt.');
    } else {
      this._plane(abstandMs(this.versuche), 'noch kein Geraet liefert Werte');
    }
    return erg;
  }

  _liefertJemandWerte() {
    if (!this.registry) return false;
    return this.registry.getDevices().some((d) => d.status === 'active' || d.status === 'connected');
  }

  async _auswerten(netzErg, lage) {
    const hosts = (netzErg && netzErg.hosts) || [];
    const geraete = (netzErg && netzErg.geraete) || hosts.filter((h) => h.stufe === 'sicher');
    const hinweise = [];

    /* 1) Jeder Fund geht in das gemeinsame Gedaechtnis. Damit folgt JEDER Adapter mit
     *    "host": "auto" sofort der tatsaechlichen Adresse — auch ohne neuen Eintrag. */
    try { geraetefund.merke(geraete.map((g) => ({ ip: g.ip, mac: g.mac })), 'erstsuche'); } catch (_) {}

    /* 2) Adapter eintragen, wo einer fehlt. */
    const cfg = this._konfigLesen();
    const vorschlaege = adapterVorschlaege(geraete, (cfg && cfg.adapters) || [], this.merk.gesperrt || {});
    const eingetragen = [];
    vorschlaege.forEach((v) => {
      if (!v.adapter) { hinweise.push(v.ip + (v.port ? ':' + v.port : '') + ' — ' + v.grund); return; }
      if ((cfg.adapters || []).some((a) => a && a.id === v.adapter.id)) return;
      cfg.adapters = cfg.adapters || [];
      cfg.adapters.push(v.adapter);
      eingetragen.push(v.adapter);
      hinweise.push('Neu eingetragen: ' + v.adapter.id + ' -> ' + v.adapter.host + ':' + v.adapter.port +
        ' (' + v.grund + ').');
    });
    if (eingetragen.length) {
      if (this._konfigSchreiben(cfg)) {
        eingetragen.forEach((a) => this._sofortStarten(a));
      } else {
        hinweise.push('Die gefundenen Geraete konnten NICHT in bridge/config/devices.json geschrieben ' +
          'werden (Schreibrecht?). Sie laufen bis zum naechsten Neustart trotzdem.');
        eingetragen.forEach((a) => this._sofortStarten(a));
      }
    }

    /* 3) Weitere Praxis-PCs. Nur melden und vormerken — Vertrauen entsteht im Handschlag. */
    const verdacht = stationsVerdacht(hosts, lage.eigeneIps);
    const bestaetigt = await this._klopfeStationen(verdacht);
    if (bestaetigt.length) {
      bestaetigt.forEach((s) => {
        hinweise.push('Auf ' + s.ip + ' laeuft sehr wahrscheinlich eine zweite VetStation (' +
          s.gruende.join('; ') + '). Beide Saele sehen einander, sobald BEIDE mit DEMSELBEN ' +
          'Praxis-Konto angemeldet sind (Admin -> Fern-Live). Die Adresse ist als Nachbar-Kandidat ' +
          'vermerkt; wer wirklich dort sitzt, weist erst der signierte Handschlag nach.');
      });
      this._nachbarKandidaten(bestaetigt);
    }

    return { geraete: geraete.map((g) => ({ ip: g.ip, mac: g.mac, hersteller: g.hersteller, datenPorts: g.datenPorts || [] })),
      eingetragen: eingetragen, stationen: bestaetigt, hinweise: hinweise };
  }

  /*
   * Klopft gezielt an 8770 und 8771 der verdaechtigen Adressen. Der grosse Suchlauf kennt diese
   * Ports nicht und darf sie auch nicht kennen (sonst wuerde ein Praxis-PC als "sicheres Geraet"
   * eingestuft). Hier sind es hoechstens eine Handvoll Adressen — das kostet unter einer Sekunde.
   */
  async _klopfeStationen(verdacht) {
    const aus = [];
    for (const v of (verdacht || []).slice(0, 8)) {
      let trifft = v.gruende.slice();
      let nachbarPort = v.nachbarPort;
      try {
        const a = await netscan.knock(v.ip, STATION_PORT, KLOPF_MS);
        if (a && a.offen && trifft.indexOf('Oberflaechen-Port ' + STATION_PORT + ' offen') < 0) {
          trifft.push('Oberflaechen-Port ' + STATION_PORT + ' offen');
        }
        const b = await netscan.knock(v.ip, NACHBAR_PORT, KLOPF_MS);
        if (b && b.offen) { nachbarPort = true; if (trifft.indexOf('Nachbar-Port ' + NACHBAR_PORT + ' offen') < 0) trifft.push('Nachbar-Port ' + NACHBAR_PORT + ' offen'); }
      } catch (_) { /* Klopfen darf scheitern; der Verdacht bleibt dann beim Ausgangsbefund. */ }
      aus.push({ ip: v.ip, nachbarPort: nachbarPort, gruende: trifft, geprueft: true });
    }
    return aus;
  }

  /* ---------------- Dateien ---------------- */

  _konfigLesen() {
    /* Es gibt sie nach einer Installation NICHT. Dann wird sie aus dem Beispiel aufgebaut — mit
     * allen Hinweistexten, damit die Datei fuer einen Menschen lesbar bleibt. */
    for (const p of [this.konfigPfad, this.beispielPfad]) {
      try {
        const j = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (j && typeof j === 'object') { j.adapters = j.adapters || []; return j; }
      } catch (_) {}
    }
    return { port: 8770, host: '127.0.0.1', adapters: [] };
  }

  _konfigSchreiben(cfg) {
    try {
      fs.mkdirSync(path.dirname(this.konfigPfad), { recursive: true });
      /* Erst daneben schreiben, dann umbenennen: ein abgebrochener Schreibvorgang darf keine halbe
       * devices.json hinterlassen — die Station startet danach im Simulator-Rueckfall. */
      const tmp = this.konfigPfad + '.neu';
      fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2), 'utf8');
      fs.renameSync(tmp, this.konfigPfad);
      this.log.info('erstsuche', 'bridge/config/devices.json ergaenzt (die gefundenen Geraete stehen jetzt fest darin).');
      return true;
    } catch (e) {
      this.log.warn('erstsuche', 'devices.json nicht schreibbar: ' + (e && e.message));
      return false;
    }
  }

  _merkLesen() {
    try { const j = JSON.parse(fs.readFileSync(this.merkPfad, 'utf8')); return { gesperrt: j.gesperrt || {} }; }
    catch (_) { return { gesperrt: {} }; }
  }

  _merkSchreiben() {
    try {
      fs.mkdirSync(path.dirname(this.merkPfad), { recursive: true });
      fs.writeFileSync(this.merkPfad, JSON.stringify(this.merk, null, 2), 'utf8');
    } catch (_) {}
  }

  /*
   * Nachbar-Kandidaten anmerken. bridge/data/nachbarn.json gehoert bridge/src/nachbar.js —
   * hier wird ausschliesslich das Feld 'kandidaten' beschrieben und alles andere (insbesondere
   * gepinnte oeffentliche Schluessel) unangetastet uebernommen. Ein Suchlauf darf niemals einen
   * Schluessel setzen oder aendern.
   */
  _nachbarKandidaten(stationen) {
    let j = {};
    try { j = JSON.parse(fs.readFileSync(this.nachbarnPfad, 'utf8')) || {}; } catch (_) { j = {}; }
    const alt = Array.isArray(j.kandidaten) ? j.kandidaten : [];
    const nachIp = {};
    alt.forEach((k) => { if (k && k.ip) nachIp[k.ip] = k; });
    stationen.forEach((s) => {
      nachIp[s.ip] = { ip: s.ip, port: NACHBAR_PORT, gesehen: Date.now(), gruende: s.gruende, quelle: 'erstsuche' };
    });
    j.kandidaten = Object.keys(nachIp).map((ip) => nachIp[ip]).slice(0, 16);
    try {
      fs.mkdirSync(path.dirname(this.nachbarnPfad), { recursive: true });
      fs.writeFileSync(this.nachbarnPfad, JSON.stringify(j, null, 2), 'utf8');
    } catch (e) {
      this.log.warn('erstsuche', 'Nachbar-Kandidaten nicht speicherbar: ' + (e && e.message));
    }
  }

  /* ---------------- Adapter sofort in Betrieb nehmen ---------------- */

  /*
   * WARUM SOFORT UND NICHT BEIM NAECHSTEN START: wer eine Station aufstellt, steht davor. Ein
   * "bitte neu starten" ist an dieser Stelle die eine Sache, die den Eindruck 'es findet sich
   * selbst' zerstoert. Und ein Neustart mitten in einer Narkose ist ohnehin keine Option.
   */
  _sofortStarten(a) {
    if (!this.adapterStarten) return;
    let ok = false;
    try { ok = this.adapterStarten(a) !== false; }
    catch (e) { this.log.warn('erstsuche', 'Adapter ' + a.id + ' liess sich nicht starten: ' + (e && e.message)); }
    if (!ok) return;
    this.log.info('erstsuche', 'Adapter ' + a.id + ' laeuft jetzt (' + a.host + ':' + a.port + ').');
    this._bewaehrung.push({ id: a.id, ip: a.host, port: a.port, bis: Date.now() + BEWEIS_MS });
    if (!this._bewaehrungTimer) {
      this._bewaehrungTimer = setInterval(() => this._bewaehrungPruefen(), 10 * 1000);
      if (this._bewaehrungTimer.unref) this._bewaehrungTimer.unref();
    }
  }

  /*
   * DIE BEWAEHRUNGSPROBE — der Grund, warum diese Automatik nicht gefaehrlich ist.
   *
   * Ein offener Port beweist nur, dass dort JEMAND antwortet, nicht dass er HL7 spricht. Der
   * Veta 5 Plus antwortet auf 4601 und sendet dort Mindray-MD2 (Binaerprotokoll, siehe
   * docs/VETA5-MITSCHNITT.md). Ein Adapter, der daran haengt, wuerde als Geraet in der Liste
   * stehen und nie einen Wert liefern — ein stiller Zustand, und stille Zustaende sind in diesem
   * Programm das eigentliche Uebel. Deshalb: liefert ein selbst eingetragener Adapter binnen
   * 90 s nichts Lesbares, wird er wieder abgeschaltet, der Grund vermerkt und die Adresse fuer
   * kuenftige Laeufe gesperrt.
   */
  _bewaehrungPruefen() {
    if (!this._bewaehrung.length) {
      if (this._bewaehrungTimer) { clearInterval(this._bewaehrungTimer); this._bewaehrungTimer = null; }
      return;
    }
    const jetzt = Date.now();
    const devs = this.registry ? this.registry.getDevices() : [];
    const bleibt = [];
    this._bewaehrung.forEach((b) => {
      if (jetzt < b.bis) { bleibt.push(b); return; }
      const d = devs.filter((x) => x.deviceId === b.id)[0];
      const liefert = !!(d && d.status !== 'offline' && d.status !== 'error' && d.lastTs);
      if (liefert) {
        this.log.info('erstsuche', 'Bewaehrung bestanden: ' + b.id + ' liefert Werte.');
        return;
      }
      this.log.warn('erstsuche', b.ip + ':' + b.port + ' antwortet zwar, liefert aber kein lesbares HL7. ' +
        'Sehr wahrscheinlich spricht das Geraet dort ein anderes (herstellereigenes) Protokoll — der ' +
        'Veta 5 Plus tut das auf 4601. Der automatische Eintrag ' + b.id + ' wird deshalb wieder ' +
        'abgeschaltet, damit kein Geraet ohne Werte in der Liste stehen bleibt. Von Hand einschalten ' +
        'geht jederzeit in bridge/config/devices.json.');
      this.merk.gesperrt[b.ip + ':' + b.port] = 'antwortet, spricht aber kein HL7 (' + new Date(jetzt).toISOString().slice(0, 10) + ')';
      this._merkSchreiben();
      this._adapterAbschalten(b.id);
    });
    this._bewaehrung = bleibt;
  }

  _adapterAbschalten(id) {
    const cfg = this._konfigLesen();
    (cfg.adapters || []).forEach((a) => { if (a && a.id === id) a.enabled = false; });
    this._konfigSchreiben(cfg);
    if (this.registry) {
      (this.registry.adapters || []).forEach((a) => {
        if (a && a.id === id && typeof a.dispose === 'function') { try { a.dispose(); } catch (_) {} }
      });
    }
  }

  /* ---------------- Auskunft ---------------- */

  status() {
    return {
      aus: this.aus,
      laeuft: this.laeuft,
      versuche: this.versuche,
      fertig: this.fertig,
      letzteTs: this.letzteTs || null,
      zusammenfassung: this.letzte ? zusammenfassung(this.letzte) : null,
      geraete: this.letzte ? this.letzte.geraete : [],
      stationen: this.letzte ? this.letzte.stationen : [],
      eingetragen: this.letzte ? (this.letzte.eingetragen || []).map((a) => a.id) : [],
      hinweise: this.letzte ? this.letzte.hinweise : [],
      gesperrt: this.merk.gesperrt,
      bewaehrung: this._bewaehrung.map((b) => ({ id: b.id, nochMs: Math.max(0, b.bis - Date.now()) })),
    };
  }
}

module.exports = {
  Erstsuche,
  darfSuchen, abstandMs, schonAbgedeckt, adapterVorschlaege, stationsVerdacht, zusammenfassung,
  ERSTER_LAUF_MS, ABSTAENDE_MS, BEWEIS_MS, NEUE_ADAPTER_MAX, NACHBAR_PORT, STATION_PORT, PATIENT_STILL_MS,
};
