'use strict';
/*
 * probe.js — Verbindungs-Assistent / Auto-Erkennung (fuer die Erst-Inbetriebnahme am echten Geraet).
 *
 * Zweck: Du steckst das LAN-Kabel ein und traegst am Geraet als Serveradresse die PC-IP ein.
 * Der Probe lauscht auf MEHREREN Kandidaten-Ports, ERKENNT HL7 automatisch (und parst es dann
 * sofort -> Patient erscheint), und protokolliert alles Unbekannte als Rohdaten (Hex) fuer die
 * Analyse. Zusaetzlich sucht er per ARP nach Mindray-Geraeten (MAC-Prefix 98:CC:E4).
 *
 * STRIKT READ-ONLY: nur lauschen/aufzeichnen, nie senden.
 *
 * Konfig: { id, ports:[3502,4601,5000,24105,2575], species?, arpScan?:true }
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { Adapter } = require('./base');
const { parseHL7Message, decodePayload } = require('./hl7');
const geraetefund = require('../geraetefund');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
// Mindray-MAC-Praefixe (aus den Fotos): 98:CC:E4 (uMEC12 Vet / Veta 5 Plus), 00:0F:14 (LifeVet 10C).
// Massgeblich ist die Liste in geraetefund.js — hier nur noch der Rueckverweis.
const MINDRAY_OUI = geraetefund.MEDIZIN_OUI;

class ProbeAdapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    // 3502 = Mindray "Gateway-Kommunikation" (am uMEC12 Vet im Netzwerk-Menue ab Werk eingetragen,
    //        Foto der Praxis: Ziel 192.168.0.99:3502) -> ZUERST lauschen.
    // 4601 = VSCapture-/Mindray-HL7-Standardport (aus dem VSCapture-Binary bestaetigt).
    // 8830 = Standardziel der HL7-Konfiguration im Eickemeyer LifeVet 10C (Daten+Kurven UND Alarme).
    //        Damit muss am Geraet nur die Ziel-IP geaendert werden, nicht auch noch der Port.
    // 5000/24105/2575 = weitere Kandidaten.
    /* Die Vorgabe kommt aus netscan.DATA_PORTS statt aus einer zweiten, hier abgeschriebenen
     * Liste. Genau die war am 31.07.2026 das Problem: 5510 (Server-Port des LifeVet M) musste an
     * VIER Stellen nachgetragen werden, und eine vergessene Stelle heisst, dass ein Geraet sendet
     * und niemand zuhoert — ohne jede Meldung, weil nie ein Byte ankommt.
     * tools/paket-test.js erzwingt die Gleichheit ohnehin; hier ist sie jetzt bauartbedingt. */
    this.ports = cfg.ports && cfg.ports.length ? cfg.ports : require('../netscan').DATA_PORTS.slice();
    this.servers = [];
    this.detected = {};       // port -> 'hl7' | 'unbekannt'
    this.unmapped = new Set();
    this.arpTimer = null;
    this.letzterFund = null;   // damit dieselbe Fundmeldung nicht alle 30 s erneut im Log steht
    this.kurvenGemeldet = false;   // "nur Kurven, keine Zahlenwerte" wird genau EINMAL erklaert
    // Ports, die ein FREMDES Programm belegt. Wichtig fuer die Diagnose: dort landen die Daten des
    // Monitors in einem anderen Prozess, und VetStation sieht schlicht nichts (Befund PORT_FREMD_BELEGT).
    this.belegt = [];
  }

  describe() { return { id: this.id, model: 'Verbindungs-Assistent', role: 'monitor' }; }

  /*
   * empfangenePorts() — auf welchen Ports ist nachweislich schon eine Verbindung angekommen?
   *
   * WOFUER (01.08.2026): Eine MESSUNG schlaegt jede Vermutung. Kam auf Port 8830 etwas an, dann
   * ist der Port offen — egal, ob eine Firewall-Regel mit unserem Namen existiert. Bis hierher
   * behauptete die Diagnose in genau diesem Fall "WINDOWS-FIREWALL BLOCKIERT Port 8830" und
   * schickte den Anwender auf die Suche nach einem Problem, das er nicht hatte: am Praxis-PC war
   * der Port ueber eine programmbasierte Regel fuer node.exe offen (31.07.2026 nachgesehen).
   */
  empfangenePorts() { return Object.keys(this.detected).map(Number); }

  async connect() {
    this.ports.forEach((port) => this._listen(port));
    this.connected = true;
    this.ctx.log.info('probe', 'Verbindungs-Assistent aktiv. Lauscht auf Ports ' + this.ports.join(', ') +
      '. Am Geraet Serveradresse = PC-IP eintragen. Erkanntes HL7 wird automatisch verarbeitet.');
    if (this.cfg.arpScan !== false) { this._arpScan(); this.arpTimer = setInterval(() => this._arpScan(), 30000); }
  }

  /*
   * ergaenzePort(port) — einen weiteren Lauschport SOFORT dazunehmen, ohne Neustart.
   *
   * WOFUER (01.08.2026): Der Anwender waehlt im Reiter "Geräte" sein Modell aus. Spricht dieses
   * Modell auf einem Port, auf dem hier bisher niemand gelauscht hat, waere die schoenste
   * Anleitung wirkungslos — das Geraet sendet, und niemand hoert zu, ohne jede Logzeile, weil nie
   * ein Byte ankommt (genau der Verlauf mit Port 5510 am 31.07.2026). Ein "bitte neu starten" ist
   * hier keine Option: ein Neustart mitten in einer Narkose unterbricht die Ueberwachung.
   *
   * Rueckgabe: true = es wird jetzt gelauscht bzw. wurde schon. false = ging nicht (dann meldet
   * der Aufrufer ehrlich "Neustart noetig"), nie eine stille Nichtbehandlung.
   */
  ergaenzePort(port) {
    const p = Number(port);
    if (!Number.isFinite(p) || p <= 0 || p > 65535) return false;
    if (this.ports.indexOf(p) >= 0) return true;
    if (!this.connected) { this.ports.push(p); return true; }   // wird beim connect() mit aufgebaut
    try {
      this.ports.push(p);
      this._listen(p);
      this.ctx.log.info('probe', 'Zusaetzlicher Lauschport ' + p + ' aufgenommen — ohne Neustart. ' +
        'Damit Windows die Daten nicht lautlos verwirft, muss der Port noch freigegeben werden: ' +
        'FIREWALL-FREIGEBEN.bat doppelklicken.');
      return true;
    } catch (e) {
      this.ctx.log.warn('probe', 'Lauschport ' + p + ' liess sich nicht oeffnen: ' + (e && e.message));
      return false;
    }
  }

  _listen(port) {
    const server = net.createServer((socket) => this._onClient(socket, port));
    server.on('error', (e) => {
      if (e.code === 'EADDRINUSE') {
        if (this.belegt.indexOf(port) < 0) this.belegt.push(port);
        this.ctx.log.warn('probe', 'Port ' + port + ' ist von einem anderen Programm belegt — VetStation kann dort NICHT zuhoeren. ' +
          'Laeuft die Station doppelt? Dann NEUSTART.bat doppelklicken.');
      } else this.ctx.log.warn('probe', 'Port ' + port + ' Fehler: ' + e.message);
    });
    server.listen(port, () => this.ctx.log.info('probe', 'bereit auf Port ' + port));
    this.servers.push(server);
  }

  _onClient(socket, port) {
    const ip = socket.remoteAddress;
    this.ctx.log.info('probe', 'VERBINDUNG auf Port ' + port + ' von ' + ip + ' — analysiere Datenstrom...');
    let buf = Buffer.alloc(0);
    let idle = null;

    socket.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      // ROHMITSCHNITT (nur wenn in devices.json "rawLog": true gesetzt ist).
      // WOFUER: Um zu belegen, WAS ein Geraet wirklich schickt, half bisher nur Raten. Der
      // Mitschnitt schreibt den unveraenderten Datenstrom nach data\roh-<port>.log - daraus laesst
      // sich jedes Feld nachweisen, statt es zu vermuten. Standardmaessig AUS (Datensparsamkeit).
      if (this.cfg.rawLog) this._rawDump(port, chunk);
      // 1) HL7 mit MLLP-Rahmen?
      let start;
      let handled = false;
      while ((start = buf.indexOf(VT)) !== -1) {
        const end = buf.indexOf(FS, start + 1);
        if (end === -1) break;
        const payload = decodePayload(buf.slice(start + 1, end));
        buf = buf.slice(end + 2);
        this._onHL7(payload, port, ip); handled = true;
      }
      if (handled) return;
      // 2) HL7 ohne MLLP? (rohes "MSH|") — nach kurzer Ruhe parsen
      if (buf.indexOf('MSH|') !== -1) {
        clearTimeout(idle);
        idle = setTimeout(() => {
          const text = decodePayload(buf); buf = Buffer.alloc(0);
          if (text.indexOf('MSH|') !== -1) this._onHL7(text, port, ip);
        }, 400);
        return;
      }
      // 3) Unbekanntes (proprietaeres?) Protokoll -> Rohdaten sichern
      if (this.detected[port] !== 'unbekannt') {
        this.detected[port] = 'unbekannt';
        const ersteBytes = buf.slice(0, 24).toString('hex');
        // 0x02 (STX) + Sync-Wort a55a = Mindrays proprietaerer Binaerstrom (Monitor<->CentralStation),
        // NICHT HL7 (das begaenne mit 0x0b). Dafuer gibt es keinen offenen Decoder — Rohdaten sichern
        // und mit tools/binaer-analyse.js strukturieren.
        const wirktBinaer = buf[0] === 0x02 || /a55a/.test(ersteBytes);
        this.ctx.log.warn('probe', 'Port ' + port + ': KEIN HL7 erkannt' +
          (wirktBinaer ? ' — proprietaerer Binaerstrom (0x02/A5 5A, kein 0x0B)' : ' (evtl. proprietaerer CentralStation-Link)') + '. ' +
          'Erste Bytes: ' + ersteBytes + ' — Rohdaten -> data/probe-' + port + '.log. ' +
          'Analyse: node tools/binaer-analyse.js data/probe-' + port + '.log');
      }
      this._rawDump(port, chunk);
      if (buf.length > 1 << 20) buf = Buffer.alloc(0);
    });
    socket.on('error', () => {});
    socket.on('close', () => this.ctx.log.info('probe', 'Verbindung Port ' + port + ' (' + ip + ') geschlossen.'));
  }

  _onHL7(text, port, ip) {
    /*
     * ROH-RINGPUFFER IM SPEICHER (23.07.2026).
     *
     * Warum nicht der Disk-Mitschnitt (rawLog): der schreibt Patientendaten auf die Platte (§10)
     * und muss vor jeder Fehlersuche von Hand ein- und danach wieder ausgeschaltet werden - samt
     * Neustart. In der Praxis ging dabei jedes Mal Zeit verloren, und zweimal wurde der Parser auf
     * VERMUTETE HL7-Felder gebaut, weil der echte Datenstrom gerade nicht vorlag.
     * Deshalb hier: die letzten HL7-Nachrichten bleiben IM SPEICHER (nichts auf der Platte),
     * abrufbar ueber /api/geraet. Damit ist jederzeit belegbar, in welchem Feld das Geraet Name,
     * Besitzer, Gewicht schickt - ohne Konfig-Aenderung, ohne Neustart.
     */
    this.letzteRoh = this.letzteRoh || [];
    this.letzteRoh.push({ ts: Date.now(), port: port, text: String(text).slice(0, 8000) });
    // Groesser gepuffert (Befund 23.07.2026): der uMEC schickt beim Verbinden einen SCHUB Konfig-/
    // Alarmeinstellungen; bei nur 5 gepufferten Nachrichten schoben die die eigentlichen Vitaldaten
    // sofort wieder heraus. 40 deckt einen ganzen Sende-Zyklus ab, ohne den Speicher zu belasten.
    if (this.letzteRoh.length > 40) this.letzteRoh.shift();

    if (this.detected[port] !== 'hl7') {
      this.detected[port] = 'hl7';
      this.ctx.log.info('probe', '✓ HL7 ERKANNT auf Port ' + port + ' von ' + ip + ' — Werte werden jetzt automatisch gelesen!');
    }
    let frame;
    try {
      // ip/port wandern mit ins Frame: nur so kann die Oberflaeche im Geraete-Menue sagen, WELCHES
      // Geraet unter welcher Adresse gerade sendet. Bisher stand dort nur ein technischer Name.
      /*
       * GERAETE-KENNUNG JE ABSENDER, nicht je Port (Befund 22.07.2026).
       * Bisher hiess jedes Geraet an Port 8830 gleich ("assistent-8830"). Haengen Monitor UND
       * Narkosegeraet am selben Port - der Normalfall, wenn beide ab Werk dorthin senden -, dann
       * ueberschrieben sie sich in der Registry gegenseitig: es war immer nur EINES sichtbar, und
       * genau deshalb liessen sie sich auch nicht zu einem Patienten koppeln.
       * Mit der Absenderadresse in der Kennung bleiben es zwei Geraete.
       *
       * model/role werden NICHT mehr fest vorgegeben: dann traegt das Geraet seinen eigenen Namen
       * (aus OBR-4/MSH-3), und die Rolle ergibt sich aus dem, was es liefert (mit EtCO2 = Kombi).
       * Vorher wurde aus jedem "LifeVet 10C" ein "Mindray (HL7 auto)" mit Rolle "Kombi" - was die
       * Rollengewichte beim Zusammenfuehren ausser Kraft setzte.
       */
      const ipKurz = String(ip || '').replace(/^::ffff:/, '');
      frame = parseHL7Message(text, {
        deviceId: this.id + '-' + port + (ipKurz ? '-' + ipKurz : ''),
        model: this.cfg.model || null, role: this.cfg.role || null, species: this.cfg.species,
        deviceIp: ipKurz, devicePort: port, transport: 'HL7/MLLP',
      },
        (u, info) => { if (!this.unmapped.has(u)) { this.unmapped.add(u); this.ctx.log.warn('probe', 'Unbekannter OBX-Code: ' + u + (info ? ' (Beispielwert: ' + info + ')' : '') + ' (in hl7.js CODE_MAP ergaenzen)'); } });
    } catch (e) { this.ctx.log.warn('probe', 'HL7-Parsefehler: ' + e.message); return; }
    if (!frame) return;

    /*
     * EINMAL sagen, WAS da eigentlich ankommt (Befund 22.07.2026).
     * Das Geraet der Praxis schickte anfangs ausschliesslich Kurven und technische Meldungen und
     * KEINEN einzigen Zahlenwert - weil kein Patient angeschlossen war. Auf dem Bildschirm sah das
     * aus wie "verbunden, aber kaputt". Diese eine Zeile beendet das Raten: sie nennt die Kurven
     * beim Namen und sagt, dass Zahlenwerte erst mit angelegten Sensoren kommen.
     */
    const kurven = (frame._meta && frame._meta.kurven) || [];
    const v = frame.vitals || {};
    const hatZahlen = [v.hr, v.spo2, v.etco2, v.af, v.temp].some((x) => x != null) ||
      (v.nibp && [v.nibp.sys, v.nibp.dia, v.nibp.map].some((x) => x != null));
    if (kurven.length && !hatZahlen && !this.kurvenGemeldet) {
      this.kurvenGemeldet = true;
      this.ctx.log.info('probe', 'Das Geraet sendet bisher nur ' + kurven.join(', ') +
        ' — aber keine Zahlenwerte (HF, SpO2, EtCO2 ...). Das ist KEIN Fehler der Verbindung: ' +
        'ein Monitor sendet Messwerte erst, wenn die Sensoren am Patienten liegen und er misst. ' +
        'Sensor anlegen (z. B. SpO2-Clip), dann erscheinen die Werte hier von selbst.');
    }
    if (hatZahlen && this.kurvenGemeldet) {
      this.kurvenGemeldet = false;
      this.ctx.log.info('probe', 'Jetzt kommen auch Zahlenwerte an — die Kette Geraet → Station steht vollstaendig.');
    }
    this.emit(frame);
  }

  _rawDump(port, chunk) {
    try {
      const dir = path.join(__dirname, '..', '..', 'data');
      fs.mkdirSync(dir, { recursive: true });
      const datei = path.join(dir, 'probe-' + port + '.log');
      // Deckel: ohne ihn laeuft bei einem dauersendenden Geraet die Platte voll (Befund-Vorsorge).
      let gross = 0;
      try { gross = fs.statSync(datei).size; } catch (_) {}
      if (gross < 8 * 1024 * 1024) fs.appendFileSync(datei, chunk);
    } catch (_) {}
  }

  // ARP-Scan: findet Mindray-Geraete im Netz (MAC 98:CC:E4...) -> bestaetigt die physische Verbindung.
  //
  // Der Fund wird seit 22.07.2026 nicht mehr nur ins Log geschrieben, sondern in geraetefund.js
  // HINTERLEGT. Grund (am Praxis-PC gemessen): hier stand korrekt "Geraet gefunden: 192.168.0.51",
  // waehrend der Abfrage-Adapter gleichzeitig stur an der fest eingetragenen .50 klopfte und
  // "antwortet nicht" meldete. Die Station wusste die richtige Adresse und benutzte sie nicht.
  // Mit dem gemeinsamen Fundort folgt ein Adapter mit "host": "auto" dem Geraet von selbst.
  _arpScan() {
    execFile('arp', ['-a'], { timeout: 5000 }, (err, stdout) => {
      if (err || !stdout) return;
      const found = geraetefund.ausArpTabelle(stdout);
      /* Aufraeumen VOR dem Merken und AUCH ohne Fund: ein Geraet, das die Adresse gewechselt hat,
       * muss aus dem Gedaechtnis verschwinden, sonst folgt geraetefund.beste() weiter der alten
       * (Befund 01.08.2026 — das Gedaechtnis wurde nie gealtert). */
      const weg = geraetefund.aufraeumen();
      if (weg) this.ctx.log.info('probe', weg + ' nicht mehr erreichbare Geraeteadresse(n) vergessen — ' +
        'die Station folgt ab jetzt der aktuellen Adresse.');
      if (!found.length) return;
      geraetefund.merke(found, 'probe');
      const jetzt = found.map((f) => f.ip).sort().join(',');
      // Nur bei AENDERUNG protokollieren - alle 30 s dieselbe Zeile machte das Log unlesbar.
      if (jetzt !== this.letzterFund) {
        this.letzterFund = jetzt;
        this.ctx.log.info('probe', 'Mindray-Geraet(e) im Netz gefunden: ' +
          found.map((f) => f.ip + ' (' + f.mac + ')').join(', '));
      }
    });
  }

  dispose() {
    if (this.arpTimer) clearInterval(this.arpTimer);
    this.servers.forEach((s) => { try { s.close(); } catch (_) {} });
    this.servers = []; this.connected = false;
  }
}

module.exports = { ProbeAdapter };
