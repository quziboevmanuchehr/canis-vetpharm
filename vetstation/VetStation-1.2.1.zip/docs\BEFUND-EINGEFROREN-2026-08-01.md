# Befund 01.08.2026 — die Station war über zwei Stunden tot, und niemand konnte es merken

> **Wofür dieser Bericht?** Am laufenden Praxis-PC (`C:\VetStation`, Fassung 1.0.1) wurde ein
> Zustand gemessen, den die Software bis dahin nicht kannte und deshalb nicht heilen konnte:
> die Bridge lief, hielt alle Ports — und bediente nichts mehr.
> **Behoben in 1.2.1.** Abgesichert durch `tools/watchdog-test.js` (24 Prüfungen).

---

## 0. Die Kernaussage zuerst

**Die Selbstheilung kannte nur den Absturz. Das Einfrieren heilte sie nicht — sie machte es schlimmer.**

Ein Absturz ist der harmlose Fall: der Prozess ist weg, die Ports sind frei, ein Neustart genügt.
Ein Einfrieren ist der gefährliche: der Prozess **lebt**, hält Port 8770 und alle sieben
Geräteports weiter fest, nimmt TCP-Verbindungen sogar an — und antwortet nie.

Der alte Watchdog prüfte nur „antwortet `/healthz`?“ und startete bei Nein einen **zweiten**
Prozess. Der fand jeden Port belegt, konnte nichts binden und blieb als zweite Leiche stehen.
Danach lief der Watchdog in den `throw` aus `launch-kiosk.ps1`, und weil dort
`$ErrorActionPreference = 'Stop'` gilt und kein `try/catch` darum stand, **endete seine Schleife.**
Ab diesem Moment überwachte niemand mehr irgendetwas.

Und der Absturz fällt auf — der Bildschirm wird leer. Das Einfrieren fällt **nicht** auf: die
Anzeige steht mit den zuletzt empfangenen Werten da, als sei alles in Ordnung.

---

## 1. Was gemessen wurde

Zeitpunkt der Entdeckung: 01.08.2026, 17:00 Uhr. Station seit 06:45 Uhr in Betrieb.

| Messung | Ergebnis |
|---|---|
| Prozess 17332 vorhanden | ja, seit 06:45:39 |
| CPU-Zuwachs in 6 s | **0,000 s** — der Prozess rechnete nicht |
| Ports 2575, 3502, 4601, 5000, 5510, 8830, 24105, 8770 | alle von 17332 gehalten |
| TCP-Verbindung auf 8770 | wird angenommen |
| Antwort auf `GET /healthz` (roh, 6 s Wartezeit) | **kein einziges Byte** |
| `CLOSE_WAIT` auf 8770 | bleibt stehen — der Prozess räumt nicht mehr ab |
| letzte Zeile in `data/diag.log` | 12:37:44Z |
| Standby/Ruhezustand als Ursache | **ausgeschlossen**, System lief seit 31.07. 22:08 durch |
| Kiosk-Browser | lief gar nicht |

Der zweite Prozess (14440, gestartet 14:37:39) hinterließ im Log genau das erwartete Bild:

```
12:37:41Z [warn] probe: Port 3502 ist von einem anderen Programm belegt — VetStation kann dort NICHT zuhoeren.
12:37:41Z [warn] probe: Port 4601 ist von einem anderen Programm belegt — ...
12:37:41Z [error] server: HTTP-Fehler: listen EADDRINUSE: address already in use 127.0.0.1:8770
```

Das „andere Programm“ war die eigene, eingefrorene Station.

---

## 2. Die Ursache des Einfrierens ist **nicht** ermittelt

Das gehört so festgehalten. Es gab keine Fehlerzeile, keinen Absturz, keinen Standby. Der genaue
Auslöser ließ sich nachträglich nicht bestimmen — der Prozess war zum Zeitpunkt der Untersuchung
bereits stumm.

**Deshalb wirkt die Behebung bewusst unabhängig von der Ursache:** sie stellt den Dienst wieder
her, gleich woran er gescheitert ist, und hinterlässt eine Spur, dass es passiert ist. Häufen sich
die Einträge in `data/watchdog.log`, ist das der Anhaltspunkt für die eigentliche Ursachensuche.

Eine Vermutung, ausdrücklich als solche gekennzeichnet: Die Bridge wird über
`Start-Process -WindowStyle Hidden` gestartet und schreibt jede Protokollzeile mit `console.log`
in ein eigenes, unsichtbares Konsolenfenster. Schreibvorgänge dorthin sind unter Windows
blockierend. Das passt zum Bild (0 % CPU, alle Threads wartend), ist aber **nicht belegt** und
wird hier nur als Spur für später notiert.

---

## 3. Was geändert wurde

### 3.1 Der Watchdog unterscheidet jetzt vier Lagen (`kiosk/watchdog-entscheidung.ps1`)

| Lage | Entscheidung |
|---|---|
| Station antwortet | `ok` |
| antwortet nicht, aber noch nicht oft genug hintereinander | `warten` |
| antwortet nicht, **niemand** hält den Port → abgestürzt | `starten` |
| antwortet nicht, **unser** Prozess hält den Port → eingefroren | `beenden-und-starten` |
| antwortet nicht, ein **fremdes** Programm hält den Port | `fremd` (nicht anfassen, nur melden) |

Die Entscheidung steht in einer eigenen, nebenwirkungsfreien Datei. Grund: Code, der Prozesse
beendet, muss prüfbar sein, **ohne** dass beim Prüfen etwas beendet wird.

### 3.2 Drei Sicherungen gegen einen übereifrigen Watchdog

- **Schwelle:** erst nach 3 erfolglosen Prüfungen **hintereinander** (~30 s) wird eingegriffen.
  Ein einzelner Aussetzer durch Last oder Virenscanner beendet nichts.
- **Zeitgrenze 4 s** statt 2 s: eine beschäftigte Station darf nicht allein deshalb für tot
  erklärt werden, weil sie einen Moment braucht.
- **Herkunftsprüfung:** beendet wird nur ein Prozess, der `node` heißt **und** dessen Programmpfad
  im Stationsordner liegt. Ist der Pfad nicht lesbar — bei einem Prozess aus der geplanten Aufgabe
  verweigert Windows die Auskunft, am 01.08. genau so gemessen — muss er stattdessen auf der
  **Loopback-Adresse** des Stationsports horchen. Ein fremdes Programm wird nie beendet.

### 3.3 Der Watchdog kann nicht mehr sterben

Jeder Schleifendurchlauf liegt in `try/catch`, ebenso jeder Aufruf von `launch-kiosk.ps1`
(dort steht der `throw`, der ihn damals beendet hat).

### 3.4 Es gibt jetzt eine Spur

`data/watchdog.log` hält jeden Eingriff mit Zeitstempel und Begründung fest, gedeckelt auf 512 KB.
Ohne diese Datei war der Vorfall vom 01.08. von außen unsichtbar.

### 3.5 Absichtlich **nicht** eingebaut

Eine Sperre „nicht während einer Narkose neu starten“. Solange die Bridge steht, wird ohnehin
nichts aufgezeichnet und nichts angezeigt — die Daten sind in diesem Moment bereits verloren.
Gerade während einer Narkose ist der schnelle Neustart die richtige Antwort, nicht das Abwarten.

---

## 4. Absicherung

`tools/watchdog-test.js`, eingehängt in `tools/alle-tests.js`. Es wird dabei kein Prozess
angefasst und kein Port geöffnet: die Entscheidungsfunktion wird mit erfundenen Lagen aufgerufen.

Festgenagelt wird unter anderem:

- Eine eingefrorene Bridge ergibt `beenden-und-starten` — **nie** `starten`. Das war der Fehler.
- Ein fremdes Programm ergibt `fremd` — es wird nirgends beendet.
- Unterhalb der Schwelle kommt ausschließlich `warten` heraus.
- `Stop-Process` steht im Code genau **einmal**, und nur hinter der Herkunftsprüfung.
- Beide `.ps1`-Dateien sind für Windows PowerShell 5.1 syntaktisch gültig (echter Parser-Lauf) und
  enthalten kein `&&`/`||` — das wäre dort ein Parserfehler, und im versteckten Fenster sähe ihn
  niemand.
