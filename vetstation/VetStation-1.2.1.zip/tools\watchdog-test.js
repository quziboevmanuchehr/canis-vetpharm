'use strict';
/*
 * watchdog-test.js — sichert die Selbstheilung ab (kiosk/watchdog.ps1, ab 1.2.1).
 *
 * DER BEFUND, DEN DIESER TEST FESTNAGELT (01.08.2026, am laufenden Praxis-PC gemessen):
 * Die Bridge (PID 17332) hielt Port 8770 und alle sieben Geraeteports, nahm TCP-Verbindungen an
 * und beantwortete kein einziges Byte — ihre Ereignisschleife stand. Der Watchdog erkannte die
 * Unerreichbarkeit richtig und startete daraufhin einen ZWEITEN Prozess. Der fand jeden Port
 * belegt, konnte nichts binden und blieb als Leiche stehen. Anschliessend starb der Watchdog am
 * 'throw' aus launch-kiosk.ps1. Ergebnis: ueber zwei Stunden tote Station, ohne jeden Hinweis.
 *
 * Was hier NIE wieder passieren darf:
 *   • Eine EINGEFRORENE Bridge fuehrt zu 'starten' statt zu 'beenden-und-starten'. Das ist genau
 *     der Fehler von damals: neu starten, ohne die Ports freizumachen, heilt nichts und erzeugt
 *     nur eine zweite Leiche.
 *   • Ein FREMDES Programm auf dem Port wird beendet. Ein Watchdog, der fremde Prozesse toetet,
 *     ist ein Schaedling — hier muss 'fremd' herauskommen und sonst nichts.
 *   • Ein einzelner Aussetzer beendet die Station. Unterhalb der Schwelle darf ausschliesslich
 *     'warten' herauskommen; waehrend einer Narkose waere ein voreiliger Abschuss schlimmer als
 *     eine kurze Verzoegerung.
 *   • Stop-Process steht irgendwo, ohne dass vorher geprueft wurde, ob es UNSER Prozess ist.
 *   • Die Watchdog-Schleife kann wieder sterben (fehlendes try/catch) — dann ueberwacht nach dem
 *     ersten Fehlschlag niemand mehr irgendetwas, und das faellt keinem auf.
 *
 * Die Entscheidung selbst steht bewusst in einer eigenen Datei (kiosk/watchdog-entscheidung.ps1)
 * und ist nebenwirkungsfrei: dieser Test ruft sie mit erfundenen Lagen auf. Es wird dabei kein
 * einziger Prozess angefasst und kein Port geoeffnet.
 *
 * Start: node tools/watchdog-test.js      (laeuft auch in `node tools/alle-tests.js`)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const KIOSK = path.join(__dirname, '..', 'kiosk');
const ENTSCHEIDUNG = path.join(KIOSK, 'watchdog-entscheidung.ps1');
const WATCHDOG = path.join(KIOSK, 'watchdog.ps1');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

console.log('watchdog-test: Selbstheilung bei eingefrorener Station\n');

/* ------------------------------------------------------------------ *
 * 1) Die Entscheidungstabelle — ausgefuehrt, nicht nur gelesen.
 * ------------------------------------------------------------------ */

/*
 * Jede Zeile: was der Watchdog sieht -> was er tun MUSS.
 * PortInhaber === null heisst "niemand horcht auf dem Port" (abgestuerzt).
 */
const FAELLE = [
  { name: 'antwortet -> nichts tun',
    erreichbar: true, folge: 0, schwelle: 3, inhaber: null, unsere: false, erwartet: 'ok' },

  { name: 'antwortet, obwohl vorher Fehler gezaehlt wurden -> Erreichbarkeit schlaegt alles',
    erreichbar: true, folge: 99, schwelle: 3, inhaber: 1234, unsere: true, erwartet: 'ok' },

  { name: 'erster Aussetzer -> nur warten, nichts beenden',
    erreichbar: false, folge: 1, schwelle: 3, inhaber: 1234, unsere: true, erwartet: 'warten' },

  { name: 'zweiter Aussetzer -> immer noch warten',
    erreichbar: false, folge: 2, schwelle: 3, inhaber: 1234, unsere: true, erwartet: 'warten' },

  { name: 'abgestuerzt (niemand haelt den Port) -> einfach starten',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: null, unsere: false, erwartet: 'starten' },

  // Das ist der Fall vom 01.08.2026. Frueher kam hier 'starten' heraus, und nichts wurde geheilt.
  { name: 'EINGEFROREN (unser Prozess haelt den Port) -> erst beenden, dann starten',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: 17332, unsere: true, erwartet: 'beenden-und-starten' },

  { name: 'fremdes Programm auf dem Port -> NICHT anfassen',
    erreichbar: false, folge: 3, schwelle: 3, inhaber: 4711, unsere: false, erwartet: 'fremd' },

  { name: 'weit ueber der Schwelle und eingefroren -> weiterhin beenden-und-starten',
    erreichbar: false, folge: 50, schwelle: 3, inhaber: 17332, unsere: true, erwartet: 'beenden-und-starten' },

  { name: 'Schwelle 1 -> greift schon beim ersten Fehlschlag',
    erreichbar: false, folge: 1, schwelle: 1, inhaber: 17332, unsere: true, erwartet: 'beenden-und-starten' },
];

function ps(b) { return b ? '$true' : '$false'; }

const zeilen = FAELLE.map((f, i) => {
  const inh = (f.inhaber === null) ? '$null' : String(f.inhaber);
  return '$r' + i + ' = Get-WatchdogEntscheidung -Erreichbar ' + ps(f.erreichbar) +
    ' -FehlerFolge ' + f.folge + ' -Schwelle ' + f.schwelle +
    ' -PortInhaber ' + inh + ' -InhaberIstUnsere ' + ps(f.unsere) + '; ' +
    'Write-Output ("' + i + '=" + $r' + i + ')';
});

const skript = [
  '$ErrorActionPreference = "Stop"',
  '. "' + ENTSCHEIDUNG.replace(/"/g, '`"') + '"',
].concat(zeilen).join('\n');

const tmp = path.join(os.tmpdir(), 'vetstation-watchdog-test-' + process.pid + '.ps1');
let ergebnis = null, psFehler = null;
try {
  fs.writeFileSync(tmp, skript, 'utf8');
  const r = spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', tmp],
    { encoding: 'utf8', timeout: 60000 });
  if (r.error) psFehler = r.error.message;
  else if (r.status !== 0) psFehler = 'PowerShell endete mit ' + r.status + ': ' + String(r.stderr || '').slice(0, 300);
  else ergebnis = String(r.stdout || '');
} catch (e) {
  psFehler = e.message;
} finally {
  try { fs.unlinkSync(tmp); } catch (_) {}
}

if (psFehler) {
  /* Kein Ausweichen: die Station laeuft ausschliesslich auf Windows (Kiosk, netsh,
   * Get-NetFirewallRule). Laesst sich PowerShell nicht aufrufen, ist das ein Fehler. */
  ok('PowerShell laesst sich aufrufen', false, psFehler);
} else {
  const antwort = {};
  ergebnis.split('\n').forEach((z) => {
    const m = z.trim().match(/^(\d+)=(.*)$/);
    if (m) antwort[m[1]] = m[2].trim();
  });
  FAELLE.forEach((f, i) => {
    ok(f.name, antwort[i] === f.erwartet, 'kam: ' + JSON.stringify(antwort[i]) + ', erwartet: ' + f.erwartet);
  });
}

/* ------------------------------------------------------------------ *
 * 2) Der Watchdog selbst — die Eigenschaften, die man nicht "aufrufen" kann.
 * ------------------------------------------------------------------ */
const w = fs.readFileSync(WATCHDOG, 'utf8').replace(/\r\n/g, '\n');

/*
 * Fuer alle Pruefungen, die den CODE meinen, werden Kommentare entfernt. Sonst zaehlt der
 * erklaerende Text mit: die Begruendung ueber Test-IstUnsereBridge nennt "Stop-Process", und die
 * Zaehlung unten fand es prompt zweimal. Genau dieselbe Falle wie in paket-test.js — eine Datei,
 * die ihr eigenes Verhalten beschreibt, darf nicht an ihrer Beschreibung gemessen werden.
 *
 * Grenze: ein '#' INNERHALB einer Zeichenkette wuerde hier faelschlich als Kommentar gelten.
 * In dieser Datei kommt keines vor; sollte je eines dazukommen, faellt es hier als Fehlschlag auf.
 */
function ohneKommentare(t) {
  return t.replace(/<#[\s\S]*?#>/g, '').replace(/#.*$/gm, '');
}
const wCode = ohneKommentare(w);

ok('watchdog.ps1 laedt die pruefbare Entscheidung statt sie nachzubauen',
  /\.\s*\(Join-Path \$PSScriptRoot 'watchdog-entscheidung\.ps1'\)/.test(w));

ok('die Schleife faengt Fehler ab und kann nicht mehr sterben',
  /while \(\$true\) \{[\s\S]*?\n  try \{/.test(w) && /\n  \} catch \{[\s\S]*?\n  \}\n  Start-Sleep/.test(w));

ok('der Aufruf von launch-kiosk.ps1 liegt in try/catch (dort steht ein throw)',
  /try \{\s*\n\s*& \(Join-Path \$PSScriptRoot 'launch-kiosk\.ps1'\)[\s\S]{0,200}?\} catch \{/.test(w));

/* Stop-Process darf nur an EINER Stelle stehen, und nur in der Funktion, die vorher geprueft hat,
 * dass es unsere Bridge ist. Sonst waere die Sicherung umgehbar. */
const stopStellen = (wCode.match(/Stop-Process/g) || []).length;
ok('Stop-Process kommt im Code genau einmal vor', stopStellen === 1, 'gefunden: ' + stopStellen);

ok('beendet wird nur nach der Entscheidung "beenden-und-starten"',
  /if \(\$was -eq 'beenden-und-starten'\) \{ \[void\]\(Stop-EingefroreneBridge/.test(w));

ok('vor dem Beenden wird geprueft, ob der Prozess zu VetStation gehoert',
  /Test-IstUnsereBridge/.test(w) && /if \(\$null -ne \$inhaber\) \{ \$unsere = Test-IstUnsereBridge/.test(w));

ok('ein fremder Prozess wird nirgends beendet',
  !/\$was -eq 'fremd'[\s\S]{0,120}Stop-Process/.test(wCode));

ok('nach dem Beenden wird gewartet, bis der Port wirklich frei ist',
  /Get-PortInhaber \$Port\)\) \{ Schreibe "Prozess \$Kennung beendet, Port \$Port ist frei/.test(w));

ok('es gibt eine Schwelle, damit ein einzelner Aussetzer nichts beendet',
  /\[int\]\$FehlerBisEingriff = 3/.test(w));

ok('die Zeitgrenze der Pruefung ist grosszuegiger als die alten 2 s',
  /-TimeoutSec 4/.test(w));

ok('jeder Eingriff hinterlaesst eine Spur in data\\watchdog.log',
  /watchdog\.log/.test(w) && /Add-Content -Path \$LogDatei/.test(w));

ok('das Protokoll waechst nicht unbegrenzt',
  /Get-Item \$LogDatei\)\.Length -gt 524288/.test(w));

/* PowerShell 5.1: die Pipeline-Operatoren && und || gibt es dort nicht. Ein Tippfehler dieser Art
 * wuerde den Watchdog beim Start mit einem Parserfehler beenden — und niemand saehe es, weil das
 * Fenster versteckt ist. */
ok('kein && oder || (in Windows PowerShell 5.1 ein Parserfehler)',
  !/&&|\|\|/.test(wCode));

/* Der eigentliche Beweis, dass die Datei fuer PowerShell 5.1 gueltig ist. */
if (!psFehler) {
  const p = spawnSync('powershell', ['-NoProfile', '-Command',
    '$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile(' +
    "'" + WATCHDOG.replace(/'/g, "''") + "'" + ', [ref]$null, [ref]$e); ' +
    'if ($e -and $e.Count) { $e[0].Message; exit 1 } else { "ok" }'],
    { encoding: 'utf8', timeout: 60000 });
  ok('watchdog.ps1 ist syntaktisch gueltig', p.status === 0, String(p.stdout || p.stderr || '').trim().slice(0, 200));

  const p2 = spawnSync('powershell', ['-NoProfile', '-Command',
    '$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile(' +
    "'" + ENTSCHEIDUNG.replace(/'/g, "''") + "'" + ', [ref]$null, [ref]$e); ' +
    'if ($e -and $e.Count) { $e[0].Message; exit 1 } else { "ok" }'],
    { encoding: 'utf8', timeout: 60000 });
  ok('watchdog-entscheidung.ps1 ist syntaktisch gueltig', p2.status === 0, String(p2.stdout || p2.stderr || '').trim().slice(0, 200));
}

/* ------------------------------------------------------------------ *
 * 3) stop-kiosk.ps1 — raeumt es auch die LIEGENGEBLIEBENE zweite Instanz weg?
 *
 * Am 01.08.2026 lag neben der eingefrorenen Station ein zweiter node-Prozess (PID 14440), den
 * der Watchdog gestartet hatte. Er hielt keinen einzigen Port — und wurde deshalb von
 * stop-kiosk.ps1 nie gefunden. Er haette jeden "Neustart" ueberlebt.
 * ------------------------------------------------------------------ */
const STOP = path.join(KIOSK, 'stop-kiosk.ps1');
const s = ohneKommentare(fs.readFileSync(STOP, 'utf8').replace(/\r\n/g, '\n'));

ok('stop-kiosk.ps1 sucht node-Prozesse auch OHNE Port',
  /Get-CimInstance Win32_Process -Filter "Name='node\.exe'"/.test(s));

ok('dabei wird nur node aus dem Stationsordner beendet (kein fremdes node)',
  /\$pfad -like \(Join-Path \$Root '\*'\)/.test(s));

ok('ohne lesbaren Pfad wird nichts beendet',
  /if \(\$pfad -and /.test(s));

/* Der Pfad darf NICHT ueber (Get-Process).Path gelesen werden: das wirft bei unzugaenglichen
 * Prozessen, und das noetige leere catch ist in dieser Datei seit 0.5.1 verboten (paket-test.js).
 * ExecutablePath aus CIM ist einfach leer, wenn Windows nichts sagt. */
ok('der Pfad wird ohne Ausnahme gelesen (kein leeres catch noetig)',
  /\$pfad = \$_\.ExecutablePath/.test(s) && !/catch\s*\{\s*\}/.test(s));

ok('die Rueckmeldung zaehlt die Rest-Instanzen mit',
  /Rest-Instanzen: \$reste/.test(s) && /\$reste -eq 0/.test(s));

if (!psFehler) {
  const p3 = spawnSync('powershell', ['-NoProfile', '-Command',
    '$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile(' +
    "'" + STOP.replace(/'/g, "''") + "'" + ', [ref]$null, [ref]$e); ' +
    'if ($e -and $e.Count) { $e[0].Message; exit 1 } else { "ok" }'],
    { encoding: 'utf8', timeout: 60000 });
  ok('stop-kiosk.ps1 ist syntaktisch gueltig', p3.status === 0, String(p3.stdout || p3.stderr || '').trim().slice(0, 200));
}

console.log('\n' + pass + ' bestanden, ' + fail + ' fehlgeschlagen');
process.exit(fail ? 1 : 0);
