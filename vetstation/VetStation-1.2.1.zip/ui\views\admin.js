/*
 * admin.js — PIN-geschuetzter Admin-/Selbstdiagnose-Bereich (§14).
 * Zeigt priorisierte Verbesserungsvorschlaege, Verbindungs-/Fehler-Log, Feedback-Statistik,
 * Sammlung fehlender Inhalte + manuelles Team-Feedback und Ein-Klick-Export (anonymisiert).
 * Standard-PIN "1234" (localStorage 'vetstation.pin', im Betrieb aendern).
 */
(function () {
  'use strict';
  var VS = window.VS;
  var host = document.getElementById('admin');
  var PIN_KEY = 'vetstation.pin';
  var authed = false, tab = 'sug';

  function pin() { return localStorage.getItem(PIN_KEY) || '1234'; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  window.VSADMIN = {
    /* Der Reiter ist ein OPTIONALES Argument (der Balken der Erstinbetriebnahme springt damit
     * direkt auf 'saal'). Bisherige Aufrufer rufen open() ohne Argument — die bleiben, wo sie
     * waren. Bewusst NICHT an der PIN vorbei: der Balken bringt den Tierarzt zur richtigen
     * Stelle, er hebt keine Sperre auf. */
    open: function (welcher) {
      if (typeof welcher === 'string' && welcher) tab = welcher;
      host.classList.add('open'); render();
    },
    close: function () { host.classList.remove('open'); stopNetzPoll(); saalHinweisPruefen(); },
    onDiag: function () { if (authed && (tab === 'diag')) renderBody(); },
  };

  function render() { authed ? renderPanel() : renderPin(); }

  function renderPin() {
    host.innerHTML = '<div class="vs-admin-box"><div class="vs-admin-h"><h2>🔒 Admin</h2><div class="vs-spacer" style="flex:1"></div>' +
      '<button class="vs-btn" data-x>✕</button></div>' +
      '<div class="vs-pin"><div style="color:var(--muted)">PIN eingeben (Standard 1234)</div>' +
      '<input id="pinIn" type="password" inputmode="numeric" maxlength="8" autofocus>' +
      '<button class="vs-btn" data-ok>Öffnen</button><div id="pinErr" style="color:#ff8ba0;font-size:12px"></div></div></div>';
    host.querySelector('[data-x]').onclick = window.VSADMIN.close;
    var inp = host.querySelector('#pinIn');
    var go = function () { if (inp.value === pin()) { authed = true; renderPanel(); } else { host.querySelector('#pinErr').textContent = 'Falsche PIN.'; inp.value = ''; } };
    host.querySelector('[data-ok]').onclick = go;
    inp.onkeydown = function (e) { if (e.key === 'Enter') go(); };
    inp.focus();
  }

  var TABS = [['saal', '🏥 OP-Saal'], ['ger', '🩺 Geräte'], ['netz', '🌐 Netzwerk &amp; Geräte'], ['sug', '💡 Verbesserungen'], ['diag', '🔌 Verbindung/Fehler'], ['fern', '📡 Fern-Live'], ['update', '🔄 Aktualisieren'], ['fb', '📊 Feedback'], ['content', '📝 Inhalte/Notiz']];

  function renderPanel() {
    host.innerHTML = '<div class="vs-admin-box">' +
      '<div class="vs-admin-h"><h2>⚙ Admin · Selbstdiagnose</h2><div style="flex:1"></div>' +
      '<button class="vs-btn" data-exp>⬇ Bericht exportieren</button>' +
      '<button class="vs-btn warn" data-clr>Zurücksetzen</button>' +
      '<button class="vs-btn" data-x>✕</button></div>' +
      '<div class="vs-admin-tabs">' + TABS.map(function (t) { return '<button class="vs-atab' + (t[0] === tab ? ' active' : '') + '" data-t="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</div>' +
      '<div class="vs-admin-body" id="adminBody"></div></div>';
    host.querySelector('[data-x]').onclick = window.VSADMIN.close;
    host.querySelector('[data-exp]').onclick = exportReport;
    host.querySelector('[data-clr]').onclick = function () { if (confirm('Alle lokalen Feedback-/Diagnosedaten löschen?')) { VS.feedback.clear(); renderBody(); } };
    host.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { tab = b.getAttribute('data-t'); renderPanel(); }; });
    renderBody();
  }

  function renderBody() {
    var b = host.querySelector('#adminBody'); if (!b) return;
    if (tab !== 'netz') stopNetzPoll();
    if (tab === 'saal') { b.innerHTML = '<p style="color:var(--muted)">Lade Angaben zu diesem OP-Saal…</p>'; loadSaal(b); }
    else if (tab === 'ger') { b.innerHTML = '<p style="color:var(--muted)">Lade Gerätekatalog…</p>'; loadGeraete(b); }
    else if (tab === 'netz') { b.innerHTML = '<p style="color:var(--muted)">Lade Netzwerkzustand…</p>'; loadNetz(b); }
    else if (tab === 'sug') b.innerHTML = viewSuggestions();
    else if (tab === 'diag') b.innerHTML = viewDiag();
    else if (tab === 'fern') { b.innerHTML = '<p style="color:var(--muted)">Lade Fern-Live-Status…</p>'; loadFern(b); }
    else if (tab === 'update') { b.innerHTML = '<p style="color:var(--muted)">Prüfe auf Updates…</p>'; loadUpdate(b); }
    else if (tab === 'fb') b.innerHTML = viewFeedback();
    else if (tab === 'content') { b.innerHTML = viewContent(); wireContent(b); }
  }

  /* ================= OP-Saal: Name und Stationskennung (Nachbesserung N10) =================
   *
   * WOFÜR: bis 1.0.3 stand der Saalname allein in bridge/config/devices.json — einer Datei, die
   * im Auslieferstand gar nicht existiert (der Installer schließt sie ausdrücklich aus, und keine
   * Zeile im Quellcode schreibt sie). Alle ausgelieferten Stationen hießen deshalb „Praxis OP 1“.
   * Ab 1.1.0 können mehrere OP-Säle im selben Praxis-Konto arbeiten; zwei Säle mit demselben Namen
   * sind in der Fern-Ansicht und auf jedem anderen Bildschirm des Hauses nicht auseinanderzuhalten.
   * Genau diese Verwechslung beseitigt dieser Reiter.
   *
   * DER NAME KOMMT AUS GENAU EINER QUELLE. Diese Ansicht rechnet nichts selbst aus, sie zeigt
   * ausschließlich `auskunft.name` aus GET /api/station — und das kommt dort aus stationsName().
   * Ein eigener Rückfall („sonst zeig halt den Rechnernamen“) an dieser Stelle wäre genau der
   * Fehler, den N10 beseitigt: derselbe Saal hieße im Admin-Bereich anders als in der Tafel.
   *
   * JEDER SATZ HIER IST EINE ZUSAGE (Befund C2 der Gegenprüfung, Projektregel 1). Diese Ansicht
   * ist die Stelle, an der ein Tierarzt liest, was mit seinem Namen passiert, und sie hat ihm zwei
   * Nachbesserungen lang etwas versprochen, das der Code nicht tat: „Der Name erscheint in der
   * Tafel, in der Web-Ansicht, auf dem Nachbar-Bildschirm und im Kopf des Narkoseprotokolls.“
   * Nachgesehen am 30.07.2026: der PDF-Kopf (ui/vetstation-live.js) trägt „VetStation“ und keinen
   * Saalnamen — dort steht er bis heute nicht. Alles Übrige gilt nur mit eingeschaltetem und
   * angemeldetem Fern-Live. Beides sagt die Ansicht jetzt hin, und den ZUSTAND der Bedingung holt
   * sie sich aus /api/station (`auskunft.fern`), statt ihn zu unterstellen.
   */
  function loadSaal(b) {
    fetch('/api/station').then(function (r) { return r.json(); }).then(function (s) {
      b.innerHTML = viewSaal(s); wireSaal(b, s); wireVerbund(b);
    }).catch(function (e) {
      b.innerHTML = '<p style="color:#ff8ba0">Angaben zum OP-Saal nicht abrufbar: ' + esc(e.message) + '</p>';
    });
  }

  function viewSaal(s) {
    if (!s || !s.bereit) {
      return '<p style="color:var(--muted)">Die Stationskennung wird gerade geladen. ' +
        'Bitte den Reiter in einem Moment erneut öffnen. <b>Die Überwachung läuft davon unberührt weiter.</b></p>';
    }
    var h = '';

    /* 1) Der Zustand in EINEM Satz — grün, wenn der Saal einen Namen hat, sonst rot verlangt.
     *    Der rote Kasten sagt ausdrücklich, dass nichts blockiert ist: sonst sucht jemand mitten
     *    in einer Narkose nach dem Grund, warum „etwas fehlt“. */
    if (s.gesetzt) {
      h += '<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:12px;' +
        'border:1px solid rgba(53,214,154,.4);background:rgba(53,214,154,.10);margin-bottom:12px">' +
        '<span style="width:12px;height:12px;border-radius:50%;background:#35d69a;box-shadow:0 0 10px #35d69a"></span>' +
        '<b style="font-size:15px">Dieser OP-Saal heißt „' + esc(s.name) + '“.</b></div>';
    } else {
      h += '<div style="padding:12px 14px;border-radius:12px;border:1px solid rgba(255,138,160,.5);' +
        'background:rgba(255,138,160,.10);margin-bottom:12px">' +
        '<b style="font-size:15px;color:#ff8ba0">Dieser OP-Saal hat noch keinen Namen.</b>' +
        '<div style="color:var(--muted);font-size:12.5px;margin-top:6px;line-height:1.6">' +
        /* NACHGEMESSEN am 30.07.2026, Wort für Wort, statt behauptet:
         *   • Kopf dieses Saals (tafel/<sid>/meta): das Feld 'name' FEHLT — kein Name, keine
         *     Ersatzzeichenkette.
         *   • meta/station der alten Web-Ansicht: „OP-Saal (ohne Namen)“ (SPIEGEL_NAME_UNBENANNT),
         *     solange dieser Saal allein im Konto ist; ab dem zweiten Saal steht dort für ALLE
         *     dieselbe feste Zeichenkette „mehrere OP-Säle“.
         *   • am Patienten im Mehrsaalbetrieb: „Rex · OP-Saal (ohne Namen)“.
         * Deshalb der genaue Satz: OHNE eigenen Namen, und dort, wo überhaupt einer stehen muss,
         * mit der Ersatzzeichenkette. */
        'Solange kein Name gesetzt ist, erscheint dieser Saal — sobald Fern-Live eingeschaltet und ' +
        'angemeldet ist — in der Fern-Ansicht <b>ohne eigenen Namen</b>; wo dort ein Name stehen ' +
        'muss, steht <b>„OP-Saal (ohne Namen)“</b>, wie bei jeder anderen unbenannten Station der ' +
        'Praxis. Zwei unbenannte Säle sind so nicht auseinanderzuhalten.<br>' +
        '<b>Es ist nichts blockiert:</b> Geräteempfang, Überwachung, Narkoseprotokoll und ' +
        'Fern-Übertragung laufen unverändert weiter.</div></div>';
    }

    /* 2) Das Eingabefeld. Die Vorbelegung aus devices.json wird als Vorschlag angeboten und dabei
     *    benannt — der Tierarzt soll sehen, woher ein Text im Feld kommt. */
    h += '<h3 style="margin:14px 0 6px">Name dieses OP-Saals</h3>' +
      '<div style="display:flex;gap:6px;align-items:stretch;flex-wrap:wrap;max-width:520px">' +
      '<input id="saalName" class="vs-ta" maxlength="' + (s.nameMax || 120) + '" ' +
      'style="min-height:0;height:40px;flex:1;min-width:220px;font-size:13px" ' +
      'placeholder="z. B. OP 2 (Zahnbehandlung)" value="' + esc(s.name || '') + '">' +
      '<button class="vs-btn" id="saalSave">Namen speichern</button></div>' +
      '<div id="saalMsg" style="font-size:12.5px;color:var(--muted);margin-top:6px;min-height:18px"></div>' +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:4px;line-height:1.6">' +
      'Höchstens ' + esc(String(s.nameMax || 120)) + ' Zeichen. ' + wohinDerName(s) +
      (s.vorbelegung ? '<br>Vorbelegung aus <code>bridge\\config\\devices.json</code>: „' + esc(s.vorbelegung) + '“.' : '') +
      '</p>';

    /* 3) Die Kennung. Bewusst UNTER dem Namen und in ruhigen Farben: geändert wird sie fast nie. */
    h += '<h3 style="margin:18px 0 6px">Stationskennung</h3>' +
      '<div style="font-size:12.5px;line-height:1.8;color:var(--muted)">' +
      '• Kennung: <b style="color:inherit">' + esc(s.sid || '–') + '</b> (kurz <b>' + esc(s.kurz || '–') + '</b>)<br>' +
      '• Schlüssel-Fingerabdruck: <b>' + esc(s.fp || '–') + '</b><br>' +
      '• Doppelte Kennung: <b>' + esc(standText(s.stand)) + '</b>' +
      (s.umbenanntVon && s.umbenanntVon.length
        ? '<br>• frühere Kennungen: ' + esc(s.umbenanntVon.join(', '))
        : '') +
      '</div>';

    /* 4) Der Konflikt — und nur dann, wenn er bewiesen ist. Ein Dauerhinweis „könnte ja sein“
     *    würde in dem Moment ignoriert, in dem er einmal stimmt. */
    if (s.stand === 'bewiesen' || s.kollision) {
      var k = s.kollision || {};
      h += '<div style="padding:12px 14px;border-radius:12px;border:1px solid rgba(255,138,160,.5);' +
        'background:rgba(255,138,160,.10);margin-top:12px">' +
        '<b style="color:#ff8ba0">Ein zweiter Rechner benutzt dieselbe Stationskennung.</b>' +
        '<div style="color:var(--muted);font-size:12.5px;margin-top:6px;line-height:1.6">' +
        'Das passiert bei einem geklonten PC oder einem kopierten Windows-Abbild. Diese Station ' +
        'sendet deshalb nur noch die kleine Übersicht und <b>keine Patientendaten</b> mehr in die ' +
        'Fern-Ansicht — sonst mischten sich die Werte beider Säle untereinander.' +
        (k.am ? '<br>Zuletzt bemerkt: ' + esc(new Date(k.am).toLocaleString()) +
          ' (' + esc(String(k.anzahl || 1)) + '×, fremde Instanz ' + esc(k.instanz || '?') + ').' : '') +
        '<br><b>Nur EINE der beiden Stationen</b> bekommt eine neue Kennung — hier, mit dem Knopf ' +
        'unten. Am Namen des Saals ändert das nichts.</div></div>';
    }

    /* WAS EIN KENNUNGSWECHSEL WIRKLICH TUT (Befund C3). Hier stand „Gelöscht wird nichts“, und
     * dieselbe Zusage stand in beiden Rückfragen — gemessen wird beim nächsten Sendetakt jeder
     * Live-Wert des alten Saals auf null gesetzt. Die vollständige, gemessene Aufstellung steht im
     * Kommentar von stationsid.umbenennen(); dieser Absatz ist ihre Kurzform und muss mit ihr und
     * mit den beiden confirm()-Texten unten wortgleich in der Aussage bleiben. */
    h += '<div style="margin-top:12px"><button class="vs-btn warn" id="saalNeu">Diese Station bekommt eine NEUE Kennung</button>' +
      ' <span id="saalNeuMsg" style="font-size:12.5px;color:var(--muted)"></span></div>' +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:8px;line-height:1.6">' +
      'Nur bei einer doppelten Kennung nötig. <b>Nicht während einer Narkose.</b> Was dabei ' +
      'passiert:<br>' +
      '• Die <b>laufenden Werte</b> dieses Saals werden unter der alten Kennung entfernt und laufen ' +
      'unter der neuen weiter — sonst stünde derselbe Patient zweimal in der Fern-Ansicht, einmal ' +
      'lebendig und einmal mit eingefrorenen Werten.<br>' +
      '• Das <b>Narkoseprotokoll bleibt vollständig</b>, wird aber an dieser Stelle geteilt: die ' +
      'bisherigen Zeilen liegen beim alten Saal, die weiteren beim neuen. Der Ausdruck von diesem ' +
      'PC ist davon nicht betroffen.<br>' +
      '• Der <b>alte Saal bleibt als stiller Saal stehen</b> (nach einer Minute „offline“, nach ' +
      '12 Stunden nicht mehr in der Saalliste). Am Namen des Saals ändert sich nichts.</p>';

    /*
     * DER VERBUND — die anderen OP-Säle dieser Praxis (ab 1.1.0).
     *
     * Er steht in DIESEM Reiter und bekommt keinen eigenen: die Frage „welche Säle gibt es und
     * wer bin ich davon" ist eine Frage, und ein zweiter Reiter hätte die Antwort auf zwei
     * Bildschirmseiten verteilt. Der Platzhalter wird von wireVerbund() aus /api/nachbarn
     * gefüllt — nachgeladen und nicht mit /api/station zusammen, weil ein hängender Leseweg
     * sonst die Angaben zum EIGENEN Saal aufhalten würde.
     */
    h += '<h3 style="margin:22px 0 8px">Andere OP-Säle dieser Praxis</h3>' +
      '<div id="verbundListe" style="color:var(--muted);font-size:12.5px">Wird geladen…</div>';
    return h;
  }

  /*
   * Die Nachbarliste. Reine Ansicht — es gibt hier keinen Knopf, der in einem fremden Saal etwas
   * bewirkt. Der EINZIGE Schreibweg des ganzen Verbunds ist die Bestätigung eines geänderten
   * Schlüssels, und die verlangt eine ausdrückliche Rückfrage.
   */
  function wireVerbund(b) {
    var ziel = b.querySelector('#verbundListe');
    if (!ziel) return;
    fetch('/api/nachbarn', { headers: { 'X-VetStation': '1' } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var saele = (d && d.saele) || [];
        var h = '';
        if (d && d.bremse) {
          h += '<div style="color:#ffd479;margin-bottom:8px">Die Nachbarsäle sind gerade ' +
            '<b>abgeschaltet</b>, weil der eigene Rundruf einen Takt verpasst hat. Der eigene Saal ' +
            'hat Vorrang; sie kommen von selbst zurück.</div>';
        }
        if (!saele.length) {
          h += '<p>Es ist gerade kein weiterer OP-Saal zu sehen.<br>' +
            'Zwei Säle finden einander, sobald <b>beide PCs mit demselben Praxis-Konto</b> ' +
            'angemeldet sind (Reiter „📡 Fern-Live"). Mehr ist nicht einzurichten — kein Server, ' +
            'keine IP-Liste. Einzelheiten: <b>docs/MEHRERE-SAELE.md</b>.</p>';
        } else {
          h += '<table style="width:100%;border-collapse:collapse;font-size:12.5px">' +
            '<tr style="color:var(--muted);text-align:left">' +
            '<th style="padding:4px 6px">Saal</th><th style="padding:4px 6px">Kennung</th>' +
            '<th style="padding:4px 6px">Quelle</th><th style="padding:4px 6px">Zustand</th>' +
            '<th style="padding:4px 6px">Patienten</th></tr>';
          saele.forEach(function (s) {
            /* esc() um JEDEN Wert: Saalname und Kennung kommen aus der Datenbank, also von einem
             * anderen PC. Ein Saal, der „<img onerror=…>" heißt, ist der billigste Weg in diesen
             * Admin-Bereich — und dieser Bereich sieht die Zugangsdaten der Praxis. */
            h += '<tr>' +
              '<td style="padding:4px 6px"><b>' + esc(s.name || '(ohne Namen)') + '</b></td>' +
              '<td style="padding:4px 6px;font-family:monospace">' + esc(String(s.sid || '').slice(0, 8)) + '</td>' +
              '<td style="padding:4px 6px">' + esc(s.quelle === 'lan' ? 'direkt im Haus' : (s.quelle === 'cloud' ? 'Praxis-Konto' : 'aus')) + '</td>' +
              '<td style="padding:4px 6px">' + esc(s.alterText || s.stufe || '') +
              (s.widerspruch ? ' <span style="color:#ffd479">· Quellen widersprechen sich</span>' : '') + '</td>' +
              '<td style="padding:4px 6px">' + esc(String(s.count != null ? s.count : (s.patients || []).length)) + '</td>' +
              '</tr>';
          });
          h += '</table>';
        }
        var lan = (d && d.lan) || {};
        if (lan.wartet && lan.wartet.length) {
          h += '<div style="margin-top:10px;padding:10px;border-radius:10px;border:1px solid rgba(255,138,160,.5)">' +
            '<b style="color:#ff8ba0">Ein Nachbar-Schlüssel hat sich geändert.</b><br>' +
            '<span style="color:var(--muted)">Das passiert, wenn dort neu installiert oder die ' +
            'Kennung erneuert wurde. Solange es nicht bestätigt ist, läuft dieser Saal über das ' +
            'Praxis-Konto weiter — <b>still übernommen wird nichts</b>. Wenn dort niemand etwas ' +
            'gemacht hat: nicht bestätigen.</span>';
          lan.wartet.forEach(function (w) {
            h += '<div style="margin-top:6px">' + esc(w.meldung || w.sid) +
              ' <button class="vs-btn warn vsn-best" data-sid="' + esc(w.sid) + '">Bestätigen</button></div>';
          });
          h += '</div>';
        }
        ziel.innerHTML = h;
        Array.prototype.forEach.call(ziel.querySelectorAll('.vsn-best'), function (btn) {
          btn.onclick = function () {
            var sid = btn.getAttribute('data-sid');
            if (!confirm('Den geänderten Schlüssel von „' + sid + '" wirklich übernehmen?\n\n' +
              'Nur bestätigen, wenn dort tatsächlich neu installiert oder die Kennung erneuert ' +
              'wurde. Sonst könnte ein fremder Rechner als Nachbarsaal auftreten.')) return;
            fetch('/api/nachbarn/schluessel/bestaetigen', {
              method: 'POST', headers: { 'X-VetStation': '1', 'Content-Type': 'application/json' },
              body: JSON.stringify({ sid: sid }),
            }).then(function (r) { return r.json(); })
              .then(function () { wireVerbund(b); })
              .catch(function (e) { alert('Nicht möglich: ' + e.message); });
          };
        });
      })
      .catch(function (e) {
        /* Ehrlich bleiben: „nicht abrufbar" ist etwas anderes als „es gibt keine Nachbarn". */
        ziel.innerHTML = '<span style="color:#ff8ba0">Die Nachbarsäle sind gerade nicht abrufbar: ' +
          esc(e.message) + '</span>';
      });
  }

  /*
   * WOHIN DER NAME GEHT — der eine Text, der das behauptet, und deshalb die eine Stelle, an der
   * es stimmen muss (Befund C2, Projektregel 1).
   *
   * Was hier steht, ist am 30.07.2026 an den echten Modulen nachgesehen worden:
   *   • bridge/src/cloud.js holt den Namen in JEDEM Sendetakt über stationsName() und schreibt ihn
   *     nach tafel/<sid>/meta.name (Kopf dieses Saals, für die Kachel auf 40 Zeichen gekürzt),
   *     nach meta/station der alten Web-Ansicht (nur solange dieser Saal allein im Konto ist) und
   *     ab dem zweiten Saal zusätzlich an jeden Patienten dieses Saals (patientId + „ · Name“).
   *   • ui/vetstation-live.js schreibt in den PDF-Kopf „VetStation“ — KEINEN Saalnamen. Deshalb
   *     steht die Verneinung ausdrücklich da: sie ist die Zusage, die vorher falsch war, und ein
   *     Tierarzt, der sie glaubt, beschriftet zwei Ausdrucke im Vertrauen darauf.
   *
   * DIE BEDINGUNG STEHT DABEI, UND ZWAR MIT IHREM ZUSTAND. Ohne eingeschaltetes und angemeldetes
   * Fern-Live verlässt der Name diesen PC nicht — dann ist jeder Satz über „die Fern-Ansicht“
   * eine Zusage für später. Der Zustand kommt aus GET /api/station (auskunft.fern) und wird hier
   * nicht nachgerechnet; fehlt er (ältere Bridge), wird die Bedingung genannt, aber nichts über
   * ihren Zustand behauptet.
   */
  function wohinDerName(s) {
    var f = (s && s.fern) || null;
    /*
     * DIESER TEXT IST EINE ZUSAGE, UND SIE WIRD GEPRUEFT (tools/saalname-test.js).
     *
     * Bis 1.0.3 stand hier ausdruecklich, der Name stehe NICHT auf dem Ausdruck — und das war
     * damals richtig: ui/vetstation-live.js trug im PDF-Kopf die harte Konstante 'VetStation'.
     * Seit 1.1.0 liest station() dort den Saalnamen und die Kennung aus /api/station, deshalb
     * steht hier jetzt das Gegenteil. Wer eines von beiden aendert, muss das andere mitziehen;
     * der Test faellt sonst durch, und genau dafuer ist er da.
     *
     * Warum die Kennung mitgenannt wird: zwei Saele KOENNEN denselben Namen tragen. Auf einem
     * Ausdruck, den jemand Monate spaeter aus einer Akte zieht, ist die Kennung das einzige, was
     * sie dann noch unterscheidet.
     */
    var wohin = 'Der Name geht bei jedem Sendetakt in die <b>Fern-Ansicht</b>: als Name dieses ' +
      'Saals und — sobald mehrere Säle im Praxis-Konto arbeiten — zusätzlich neben jedem ' +
      'Patienten dieses Saals. Er steht außerdem im <b>Kopf des ausgedruckten ' +
      'Narkoseprotokolls</b>, zusammen mit der Kurzform der Stationskennung — damit zwei ' +
      'Ausdrucke desselben Tages aus verschiedenen Sälen auseinanderzuhalten sind. ';
    var lage;
    if (!f) {
      lage = 'Das gilt nur, solange Fern-Live eingeschaltet und das Praxis-Konto angemeldet ist.';
    } else if (f.sendet) {
      lage = '<b>Fern-Live sendet gerade</b> — der Name ist ab dem nächsten Takt draußen.';
    } else if (f.eingeschaltet && !f.angemeldet) {
      lage = '<b>Fern-Live ist noch nicht angemeldet</b> (Reiter „📡 Fern-Live“): bis dahin bleibt ' +
        'der Name auf diesem PC.';
    } else if (!f.eingeschaltet) {
      lage = '<b>Fern-Live ist ausgeschaltet</b>: der Name bleibt auf diesem PC und ist nur hier ' +
        'zu sehen.';
    } else {
      /* angemeldet, aber (noch) nicht sendend: Anlauf, Wartezeit nach einem Fehler oder
       * Selbstabschaltung. Der Reiter Fern-Live sagt, welcher Fall es ist — hier wird nicht
       * geraten. */
      lage = '<b>Fern-Live läuft gerade nicht</b> (Näheres im Reiter „📡 Fern-Live“): bis dahin ' +
        'bleibt der Name auf diesem PC.';
    }
    return wohin + lage + '<br>Gespeichert wird er in <b>data\\station-id.json</b>; er überlebt ' +
      'Update und Neuinstallation. In der Saal-Kachel der Fern-Ansicht wird er auf 40 Zeichen ' +
      'gekürzt, gespeichert und übertragen bleibt er vollständig.';
  }

  function standText(x) {
    if (x === 'bewiesen') return 'JA — bitte eine der beiden Stationen umbenennen';
    if (x === 'ausgeschlossen') return 'nein, ausgeschlossen';
    return 'noch nicht entschieden (es wurde noch nichts zurückgelesen)';
  }

  function wireSaal(b, s) {
    var msg = b.querySelector('#saalMsg');
    function sag(t, farbe) { if (msg) { msg.textContent = t; msg.style.color = farbe || 'var(--muted)'; } }

    var feld = b.querySelector('#saalName');
    var save = b.querySelector('#saalSave');
    if (save && feld) {
      var speichern = function () {
        var wert = feld.value || '';
        if (!wert.trim()) { sag('Bitte einen Namen eingeben.', '#ffb84d'); return; }
        save.disabled = true; sag('speichere…');
        fetch('/api/station/name', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: wert }),
        }).then(function (r) { return r.json(); }).then(function (res) {
          save.disabled = false;
          if (res && res.ok) {
            sag('✓ gespeichert', '#8fe3b8');
            saalHinweisPruefen();
            /* Neu zeichnen, damit oben der grüne Kasten steht und das Feld den GESPEICHERTEN
             * (also gekappten und entschärften) Namen zeigt — nicht den eingetippten. Sonst
             * glaubt der Tierarzt, sein 300-Zeichen-Name sei so übernommen worden. */
            setTimeout(function () { loadSaal(b); }, 500);
          } else { sag('✗ ' + ((res && res.fehler) || 'nicht gespeichert'), '#ff8ba0'); }
        }).catch(function (e) { save.disabled = false; sag('✗ ' + e.message, '#ff8ba0'); });
      };
      save.onclick = speichern;
      feld.addEventListener('keydown', function (e) { if (e.key === 'Enter') speichern(); });
    }

    var neu = b.querySelector('#saalNeu');
    if (neu) {
      neu.onclick = function () {
        /* ZWEIMAL fragen, und die zweite Frage nennt die Folge im Klartext. Ein einzelnes
         * „sind Sie sicher?“ klickt sich im OP-Alltag weg; dieser Schritt teilt ein laufendes
         * Narkoseprotokoll und ist nicht rückgängig zu machen.
         * BEIDE TEXTE SAGEN DASSELBE WIE DER ABSATZ OBEN UND WIE stationsid.umbenennen(). Vorher
         * versprachen sie „Gelöscht wird nichts“, während der nächste Sendetakt die Live-Werte des
         * alten Saals wegräumte (Befund C3, nachgemessen). Wer eine der drei Stellen ändert, ändert
         * alle drei — tools/saalname-test.js hält sie gegeneinander. */
        if (!confirm('Diese Station bekommt eine NEUE Stationskennung.\n\n' +
          'Nur nötig, wenn zwei PCs dieselbe Kennung benutzen.')) return;
        if (!confirm('Wirklich? NICHT während einer Narkose.\n\n' +
          'Der bisherige Saal ' + (s && s.sid ? '(' + s.sid + ') ' : '') + 'bleibt in der ' +
          'Fern-Ansicht als stiller Saal stehen und altert aus.\n' +
          'Die laufenden Werte werden dort entfernt und laufen unter der neuen Kennung weiter.\n' +
          'Das Narkoseprotokoll bleibt vollständig, wird aber an dieser Stelle geteilt.')) return;
        var m = b.querySelector('#saalNeuMsg');
        neu.disabled = true; if (m) m.textContent = 'vergebe neue Kennung…';
        fetch('/api/station/kennung/neu', { method: 'POST' })
          .then(function (r) { return r.json(); }).then(function (res) {
            if (m) {
              m.textContent = (res && res.ok) ? '✓ neue Kennung: ' + res.sid : '✗ ' + ((res && res.fehler) || 'fehlgeschlagen');
              m.style.color = (res && res.ok) ? '#8fe3b8' : '#ff8ba0';
            }
            setTimeout(function () { loadSaal(b); }, 800);
          }).catch(function (e) { neu.disabled = false; if (m) { m.textContent = '✗ ' + e.message; m.style.color = '#ff8ba0'; } });
      };
    }
  }

  /* ---- ERSTINBETRIEBNAHME: der sichtbare Hinweis, der nichts blockiert ----
   *
   * Der Nutzer hat ausdrücklich „beim ersten Start fragen“ gewählt. Gefragt wird mit einem Balken
   * am oberen Rand, NICHT mit einem Dialog vor der Überwachung: eine Narkose läuft auch ohne
   * Saalnamen weiter, und ein Pflichtdialog stünde im schlechtesten Fall zwischen dem Tierarzt
   * und einem narkotisierten Patienten.
   *
   * WARUM DIESE ZEILEN IN admin.js STEHEN: der Balken führt in den Admin-Bereich, und das ist die
   * einzige Datei, die diesen öffnen kann. Ein zweiter Abfrageweg in vetstation-live.js wäre eine
   * zweite Stelle, die /api/station auswertet.
   *
   * WIEDERHOLT WIRD NUR, SOLANGE ES NÖTIG IST: sobald ein Name steht, hört die Abfrage auf. Ein
   * dauerhafter Zeitgeber gegen einen Endpunkt, der sich nie wieder ändert, ist auf dem Kiosk-i3
   * unnötige Last neben einer laufenden Narkose.
   */
  var saalHinweisTimer = null;
  function saalHinweisPruefen() {
    var el = document.getElementById('vsxSaalHint');
    if (!el) return;
    fetch('/api/station').then(function (r) { return r.json(); }).then(function (s) {
      /* bereit:false heißt „wird noch geladen“ — das ist KEIN fehlender Name. Den Balken dann
       * schon anzuzeigen hieße, beim Start jeder benannten Station kurz eine Warnung zu zeigen. */
      var fehlt = !!(s && s.bereit && !s.gesetzt);
      el.hidden = !fehlt;
      /* Dieselbe Bauform wie beim Test-Balken (vetstation-live.js updateTestBanner): die Klasse am
       * <html> rueckt #vsxGrid und .vsx-hint um die Hoehe des Balkens nach unten. Ohne sie
       * verdeckte der Balken den oberen Rand des ersten Patientenfensters. */
      document.documentElement.classList.toggle('vsx-saal', fehlt);
      if (!fehlt && s && s.bereit && saalHinweisTimer) { clearInterval(saalHinweisTimer); saalHinweisTimer = null; }
    }).catch(function () { /* kein Netz zur eigenen Bridge: der Balken bleibt, wie er ist */ });
  }
  function saalHinweisStarten() {
    var el = document.getElementById('vsxSaalHint');
    if (!el) return;
    var btn = document.getElementById('vsxSaalHintBtn');
    if (btn) btn.onclick = function () { window.VSADMIN.open('saal'); };
    saalHinweisPruefen();
    // 30 s: deckt das Laden der Kennung beim Start ab und lässt den Balken verschwinden, wenn der
    // Name an einem anderen Bildschirm gesetzt wurde. Er endet, sobald ein Name steht.
    saalHinweisTimer = setInterval(saalHinweisPruefen, 30000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', saalHinweisStarten);
  else saalHinweisStarten();

  /* ================= Geräte: Modell wählen und einrichten =====================================
   *
   * WOFÜR (Wunsch 01.08.2026, wörtlich): „Je nach Narkosegerät oder Monitorgerät muss auch das App
   * erkennen ODER muss der Benutzer in Einstellung der Model das Gerät eingeben zu können, um zu
   * Empfehlungen für Verbindung das App geben kann. Wenn das automatisch das oder andere Gerät sich
   * nicht verbindet, muss das App Empfehlungen und Einstellungen von Gerät geben.“
   *
   * Dieser Reiter ist genau das, in dieser Reihenfolge:
   *   1. Was ist schon eingerichtet — und liefert es Werte? (Der Zustand zuerst, nie die Auswahl.)
   *   2. Was hängt im Netz? Die Station schlägt Modelle vor, mit Begründung.
   *   3. Modell selbst wählen — Suche über Hersteller, Modell und alle Schreibweisen.
   *   4. Zum gewählten Modell: die Anleitung mit den ECHTEN Zahlen dieses PCs, ein Knopf zum
   *      Einrichten und, wenn nichts ankommt, die rangierten Empfehlungen des Beraters.
   *
   * DIE OBERFLÄCHE RECHNET NICHTS SELBST AUS. Jede Zahl und jeder Satz kommt aus der Bridge
   * (/api/katalog, /api/geraete, /api/geraete/erkennung). Eine zweite Herleitung im Browser hieße,
   * dass der Admin-Bereich etwas anderes anzeigt als die Station tut — und dieser Reiter ist genau
   * die Stelle, an der ein Mensch nachsieht, ob beides zusammenpasst.
   * ========================================================================================= */

  var gerAuswahl = null;     // { geraetId, wegId } — was gerade aufgeklappt ist
  var gerSuche = '';         // Text im Suchfeld
  var gerDetail = null;      // Antwort von /api/katalog/geraet
  var gerZustand = null;     // Antwort von /api/geraete
  var gerFunde = null;       // Antwort von /api/geraete/erkennung
  var gerAutomatik = null;   // Antwort von /api/erstsuche — was die Station VON SELBST getan hat
  var gerMeldung = null;     // Ergebnis des letzten Einrichtens

  var KAT_ZEICHEN = { monitor: '🖥', narkose: '💨', beatmung: '🌬', kapnograph: '📈', kombi: '🩺' };
  var VERTRAUEN_TEXT = {
    belegt: { farbe: '#35d69a', text: 'belegt — an einem echten Gerät gemessen oder im Herstellerdokument nachgelesen' },
    wahrscheinlich: { farbe: '#ffc23c', text: 'wahrscheinlich — gut begründet, aber nicht nachgemessen' },
    unbestaetigt: { farbe: '#ff8ba0', text: 'unbestätigt — Hinweis aus zweiter Hand' }
  };

  function loadGeraete(b) {
    Promise.all([
      fetch('/api/geraete').then(function (r) { return r.json(); }).catch(function () { return null; }),
      fetch('/api/geraete/erkennung').then(function (r) { return r.json(); }).catch(function () { return null; }),
      fetch('/api/katalog?q=' + encodeURIComponent(gerSuche)).then(function (r) { return r.json(); }).catch(function () { return null; }),
      /* /api/erstsuche gab es seit 1.1.0 — und keine einzige Datei unter ui/ hat es je abgerufen
       * (Befund 01.08.2026). Was die Station von selbst gefunden, eingetragen, wieder abgeschaltet
       * oder dauerhaft gesperrt hat, stand damit ausschließlich im Log. Genau die Auskunft, die
       * jemand sucht, der wissen will, warum ein Gerät NICHT erscheint. */
      fetch('/api/erstsuche').then(function (r) { return r.json(); }).catch(function () { return null; })
    ]).then(function (a) {
      gerZustand = a[0]; gerFunde = a[1]; gerAutomatik = a[3];
      b.innerHTML = viewGeraete(a[2]);
      wireGeraete(b);
      if (gerAuswahl) ladeDetail(b);
    });
  }

  function ladeDetail(b) {
    if (!gerAuswahl) return;
    fetch('/api/katalog/geraet?id=' + encodeURIComponent(gerAuswahl.geraetId) +
      (gerAuswahl.wegId ? '&weg=' + encodeURIComponent(gerAuswahl.wegId) : ''))
      .then(function (r) { return r.json(); })
      .then(function (d) {
        gerDetail = d;
        var box = (b || host).querySelector('#gerDetail');
        if (!box) return;
        box.innerHTML = viewDetail(d);
        wireDetail(b || host);
      })
      .catch(function (e) {
        var box = (b || host).querySelector('#gerDetail');
        if (box) box.innerHTML = '<p style="color:#ff8ba0">Angaben zum Modell nicht abrufbar: ' + esc(e.message) + '</p>';
      });
  }

  function viewGeraete(kat) {
    var h = '';

    /* --- Meldung des letzten Einrichtens. Ganz oben, weil sie die Antwort auf die letzte Handlung
     *     ist — und weil dort steht, was jetzt noch zu tun bleibt. --- */
    if (gerMeldung) {
      var mf = gerMeldung.ok === false ? '#ff8ba0' : '#35d69a';
      h += '<div style="padding:12px 14px;border-radius:12px;border:1px solid ' + mf + '55;background:' + mf + '14;margin-bottom:12px">' +
        '<b style="font-size:14.5px">' + esc(gerMeldung.fehler || gerMeldung.meldung || '') + '</b>' +
        ((gerMeldung.naechsteSchritte || []).length
          ? '<div style="color:var(--muted);font-size:12.5px;margin-top:7px">Jetzt noch zu tun:</div>' +
            '<ol style="margin:5px 0 0 18px;padding:0;font-size:12.5px;line-height:1.65">' +
            gerMeldung.naechsteSchritte.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ol>'
          : '') + '</div>';
    }

    /* --- 1) Was ist eingerichtet? Der Zustand kommt vor jeder Auswahl. --- */
    h += '<h3 style="margin:2px 0 8px">Eingerichtete Geräte</h3>';
    /* Nur zeigen, was WIRKT — plus alles selbst Eingerichtete, damit man es wieder abschalten kann.
     * Die Vorlage devices.example.json enthält fünf ausgeschaltete Beispieleinträge; sie hier alle
     * aufzuführen hieße, den Zustand mit Möglichkeiten zu vermischen. Die Zahl steht trotzdem da:
     * verschwiegen wird nichts. */
    var alleEin = (gerZustand && gerZustand.eingerichtet) || [];
    var ein = alleEin.filter(function (a) { return a.enabled || a.ausKatalog; });
    var ruht = alleEin.length - ein.length;
    if (!ein.length) {
      h += '<p style="color:var(--muted);font-size:12.5px">Noch kein Gerät eingetragen. Das ist kein Fehler: ' +
        'der Verbindungs-Assistent nimmt jedes Gerät entgegen, das von sich aus zum PC sendet. ' +
        'Ein Eintrag ist nur nötig, wenn der PC das Gerät <b>abfragen</b> muss.</p>';
    } else {
      h += '<div style="display:flex;flex-direction:column;gap:6px">' + ein.map(function (a) {
        var an = a.enabled && a.laeuft;
        var liefert = a.letzteDatenVorMs != null && a.letzteDatenVorMs < 30000;
        var f = liefert ? '#35d69a' : (an ? '#ffc23c' : 'var(--muted)');
        var t = liefert ? 'liefert Werte' : (an ? 'läuft, aber es kommt nichts an' : (a.enabled ? 'eingetragen, läuft nicht' : 'abgeschaltet'));
        return '<div style="display:flex;gap:10px;align-items:center;padding:9px 11px;border-radius:9px;background:rgba(255,255,255,.035)">' +
          '<span style="width:10px;height:10px;border-radius:50%;background:' + f + '"></span>' +
          '<div style="flex:1;min-width:0">' +
          '<b>' + esc(a.model || a.id) + '</b> <span style="color:var(--muted);font-size:11.5px">' + esc(a.type) +
          (a.host ? ' · ' + esc(a.host) : '') + (a.port ? ':' + esc(a.port) : '') + '</span>' +
          '<div style="color:' + f + ';font-size:12px">' + esc(t) + '</div></div>' +
          (a.ausKatalog ? '<button class="vs-btn" data-gerab="' + esc(a.id) + '" style="font-size:11.5px">abschalten</button>' : '') +
          '</div>';
      }).join('') + '</div>';
    }
    if (ruht) {
      h += '<p style="color:var(--muted);font-size:11.5px;margin-top:6px">Dazu ' + ruht +
        ' ausgeschaltete Einträge aus der Vorlage (Beispiele für Geräte, die von Hand eingetragen werden können) — ' +
        'sie tun nichts und stören nichts.</p>';
    }

    /* Worauf die Station gerade hört — die Angabe, deren Fehlen am 31.07.2026 einen ganzen Tag
     * gekostet hat: ein Gerät sendete auf 5510, und niemand hörte dort zu. */
    if (gerZustand) {
      var lausch = gerZustand.lauschPorts || [];
      var fehlt = gerZustand.firewallFehlend || [];
      h += '<p style="color:var(--muted);font-size:11.5px;margin-top:8px">Die Station hört auf den Ports <b>' +
        esc(lausch.join(', ')) + '</b>' +
        (fehlt.length ? ' · <span style="color:#ff8ba0">in der Firewall fehlen ' + esc(fehlt.join(', ')) +
          ' — Windows verwirft dort lautlos. FIREWALL-FREIGEBEN.bat doppelklicken.</span>' : '') +
        ((gerZustand.portBelegt || []).length ? ' · <span style="color:#ffc23c">von einem anderen Programm belegt: ' +
          esc(gerZustand.portBelegt.join(', ')) + '</span>' : '') + '</p>';
    }

    /* --- 2) Was hängt im Netz? Vorschläge mit Begründung, nie eine Festlegung. --- */
    h += '<h3 style="margin:18px 0 8px">Was hängt im Netz?</h3>';
    if (!gerFunde || !gerFunde.geprueft) {
      h += '<p style="color:var(--muted);font-size:12.5px">' +
        esc((gerFunde && gerFunde.hinweis) || 'Es liegt noch kein Suchlauf vor.') +
        ' <button class="vs-btn" id="gerScan" style="margin-left:8px">🔎 Jetzt suchen</button></p>';
    } else if (!(gerFunde.funde || []).length) {
      h += '<p style="color:var(--muted);font-size:12.5px">Der letzte Suchlauf hat kein Gerät gefunden. ' +
        'Ein Gerät, das nur <b>sendet</b>, muss dabei allerdings nicht auffallen — es lauscht ja nicht. ' +
        '<button class="vs-btn" id="gerScan" style="margin-left:8px">🔎 Erneut suchen</button></p>';
    } else {
      h += '<div style="display:flex;flex-direction:column;gap:8px">' + gerFunde.funde.map(function (f) {
        var farbe = f.eindeutig ? '#35d69a' : '#ffc23c';
        var kand = (f.kandidaten || []).slice(0, 4);
        return '<div style="padding:10px 12px;border-radius:10px;border:1px solid ' + farbe + '44;background:' + farbe + '10">' +
          '<b>' + esc(f.ip) + '</b>' + (f.mac ? ' <span style="color:var(--muted);font-size:11.5px">' + esc(f.mac) + '</span>' : '') +
          '<div style="font-size:12.5px;margin-top:4px;line-height:1.6">' + esc(f.satz) + '</div>' +
          (kand.length
            ? '<div style="margin-top:7px;display:flex;flex-wrap:wrap;gap:6px">' + kand.map(function (k) {
                return '<button class="vs-btn" data-gerwahl="' + esc(k.geraetId) + '" style="font-size:11.5px">' +
                  esc(k.hersteller + ' ' + k.modell) + ' →</button>';
              }).join('') + '</div>'
            : '') + '</div>';
      }).join('') + '</div>' +
      '<p style="margin-top:8px"><button class="vs-btn" id="gerScan">🔎 Erneut suchen</button></p>';
    }

    /* --- 2b) Was die Station VON SELBST getan hat.
     *
     * Diese Auskunft gab es seit 1.1.0 unter /api/erstsuche, und keine Oberfläche hat sie je
     * abgerufen. Sie beantwortet genau die Frage, die jemand stellt, der ein Gerät vermisst:
     * „Hat die Station überhaupt gesucht — und was hat sie mit dem Fund gemacht?“ Ohne sie blieb
     * als Antwort nur das Log. --- */
    var au = gerAutomatik;
    if (au) {
      h += '<h3 style="margin:18px 0 8px">Was die Station von selbst getan hat</h3>';
      if (au.aus) {
        h += '<p style="color:var(--muted);font-size:12.5px">Die automatische Gerätesuche ist ausgeschaltet ' +
          '(<code>erstsuche.enabled</code> in bridge/config/devices.json). Geräte müssen dann von Hand eingerichtet werden.</p>';
      } else {
        var zeitTxt = au.letzteTs ? new Date(au.letzteTs).toLocaleTimeString() : null;
        h += '<div style="padding:9px 11px;border-radius:9px;background:rgba(255,255,255,.035);font-size:12.5px;line-height:1.7">' +
          '<b>' + esc(au.zusammenfassung || (au.laeuft ? 'Die Suche läuft gerade …'
            : (au.versuche ? 'Suchlauf abgeschlossen.' : 'Die erste Suche läuft etwa 20 Sekunden nach dem Start.'))) + '</b>' +
          '<div style="color:var(--muted)">' +
          (au.versuche ? au.versuche + '. Durchlauf' : 'noch kein Durchlauf') +
          (zeitTxt ? ' · zuletzt ' + esc(zeitTxt) : '') +
          (au.fertig ? ' · beendet, weil Werte ankommen' : (au.laeuft ? ' · läuft' : '')) +
          '</div></div>';
        if ((au.eingetragen || []).length) {
          h += '<p style="font-size:12.5px;margin:7px 0 0"><b>Selbst eingetragen:</b> ' +
            esc(au.eingetragen.join(', ')) + '</p>';
        }
        if ((au.bewaehrung || []).length) {
          h += '<p style="font-size:12.5px;margin:5px 0 0;color:#ffc23c">Auf Bewährung (liefert es binnen ' +
            'kurzem kein lesbares HL7, wird es wieder abgeschaltet): ' +
            esc(au.bewaehrung.map(function (x) { return x.id + ' (' + Math.round(x.nochMs / 1000) + ' s)'; }).join(', ')) + '</p>';
        }
        var gesp = Object.keys(au.gesperrt || {});
        if (gesp.length) {
          /* Das ist die wichtigste Zeile des ganzen Blocks: eine Adresse, die die Automatik
           * dauerhaft übergeht, weil dort etwas antwortet, das kein HL7 spricht. Ohne diese
           * Anzeige sucht jemand endlos nach einem Gerät, das die Station absichtlich meidet. */
          h += '<p style="font-size:12.5px;margin:7px 0 0"><b>Dauerhaft übergangen:</b></p>' +
            '<ul style="margin:3px 0 0 18px;padding:0;font-size:12.5px;line-height:1.65;color:var(--muted)">' +
            gesp.map(function (k) { return '<li><b>' + esc(k) + '</b> — ' + esc(au.gesperrt[k]) + '</li>'; }).join('') + '</ul>';
        }
        if ((au.hinweise || []).length) {
          h += '<details style="margin-top:7px"><summary style="cursor:pointer;font-size:12.5px;color:var(--muted)">' +
            au.hinweise.length + ' Einzelheiten des letzten Durchlaufs</summary>' +
            '<ul style="margin:5px 0 0 18px;padding:0;font-size:12px;line-height:1.6;color:var(--muted)">' +
            au.hinweise.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></details>';
        }
      }
    }

    /* --- 3) Modell selbst wählen. --- */
    h += '<h3 style="margin:18px 0 8px">Gerät selbst auswählen</h3>' +
      '<p style="color:var(--muted);font-size:12.5px;margin:0 0 8px">Hersteller oder Modell eingeben — Schreibweise egal. ' +
      'Auch alte Namen und Handelsnamen werden gefunden.</p>' +
      '<input id="gerQ" type="text" value="' + esc(gerSuche) + '" placeholder="z. B. LifeVet, uMEC, Dräger, WATO, Bionet …" ' +
      'style="width:100%;max-width:420px;padding:9px 11px;border-radius:9px;border:1px solid rgba(255,255,255,.18);' +
      'background:rgba(255,255,255,.05);color:inherit;font-size:13.5px">';

    var liste = (kat && kat.geraete) || [];
    h += '<p style="color:var(--muted);font-size:11.5px;margin:7px 0 8px">' + liste.length + ' von ' +
      ((kat && kat.gesamt) || liste.length) + ' Modellen</p>';
    if (!liste.length) {
      h += '<p style="color:var(--muted);font-size:12.5px">Kein Treffer. Steht das Gerät nicht im Katalog, hilft trotzdem der ' +
        'Verbindungs-Assistent: er nimmt jede Verbindung an, erkennt HL7 von selbst und schreibt alles Übrige mit.</p>';
    } else {
      h += '<div style="display:flex;flex-direction:column;gap:4px;max-height:260px;overflow:auto;padding-right:4px">' +
        liste.map(function (g) {
          var aktiv = gerAuswahl && gerAuswahl.geraetId === g.id;
          var vt = VERTRAUEN_TEXT[g.vertrauen] || VERTRAUEN_TEXT.unbestaetigt;
          return '<button class="vs-btn" data-gerwahl="' + esc(g.id) + '" style="text-align:left;justify-content:flex-start;' +
            'padding:8px 10px;font-size:12.5px' + (aktiv ? ';border-color:#23c7bb;background:rgba(35,199,187,.12)' : '') + '">' +
            (KAT_ZEICHEN[g.kategorie] || '•') + ' <b>' + esc(g.hersteller) + ' ' + esc(g.modell) + '</b>' +
            ' <span style="color:var(--muted)">· ' + esc(g.kategorie) + ' · ' + esc(g.einsatz) + '</span>' +
            ' <span style="color:' + vt.farbe + '">●</span>' +
            (g.anbindbar ? '' : ' <span style="color:#ff8ba0;font-size:11px">kein offener Datenausgang</span>') +
            '</button>';
        }).join('') + '</div>';
    }

    /* --- 4) Das gewählte Modell. --- */
    h += '<div id="gerDetail" style="margin-top:14px">' +
      (gerAuswahl ? '<p style="color:var(--muted)">Lade Angaben zum Modell…</p>' : '') + '</div>';

    h += '<p style="color:var(--muted);font-size:11.5px;margin-top:16px">Alles hier ist <b>rein lesend</b> gegenüber den Geräten: ' +
      'VetStation liest mit und verstellt an keinem Gerät je etwas.</p>';
    return h;
  }

  function viewDetail(d) {
    if (!d || d.fehler) return '<p style="color:#ff8ba0">' + esc((d && d.fehler) || 'Unbekanntes Modell.') + '</p>';
    var g = d.geraet, a = d.anleitung, ber = d.beratung;
    var vt = VERTRAUEN_TEXT[g.vertrauen] || VERTRAUEN_TEXT.unbestaetigt;
    var h = '<div style="border-top:1px solid rgba(255,255,255,.1);padding-top:14px">';

    h += '<h3 style="margin:0 0 4px">' + (KAT_ZEICHEN[g.kategorie] || '•') + ' ' + esc(g.hersteller + ' ' + g.modell) + '</h3>' +
      '<div style="color:' + vt.farbe + ';font-size:12px;margin-bottom:10px">● ' + esc(vt.text) + '</div>';

    /* Die Wege. Mehr als einer ist der Normalfall, und die Wahl macht einen Unterschied: beim einen
     * muss am Gerät ein Menü gesucht werden, beim anderen gar nichts. */
    if ((g.wege || []).length > 1) {
      h += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">' + g.wege.map(function (w) {
        var aktiv = a.weg && a.weg.id === w.id;
        return '<button class="vs-btn" data-gerweg="' + esc(w.id) + '" style="font-size:11.5px' +
          (aktiv ? ';border-color:#23c7bb;background:rgba(35,199,187,.12)' : '') + '">' + esc(w.name) +
          (w.id === d.empfohlenerWeg ? ' <span style="color:#35d69a">· empfohlen</span>' : '') + '</button>';
      }).join('') + '</div>';
    }

    if (a.weg) {
      h += '<div style="padding:10px 12px;border-radius:10px;background:rgba(35,199,187,.10);' +
        'border:1px solid rgba(35,199,187,.32);font-size:12.5px;line-height:1.65;margin-bottom:10px">' +
        '<b>' + esc(a.weg.name) + '</b><br>' +
        /* 'keiner'/'unbekannt' sind gültige Werte und kommen häufig vor — die Mehrheit der
         * Veterinär-Narkosegeräte hat gar keinen Anschluss. Sie hier durch die Fallunterscheidung
         * fallen zu lassen, hätte „beides möglich · KEINER“ ergeben: eine Zeile, die das Gegenteil
         * dessen behauptet, was der Katalog sagt. */
        (a.weg.transport === 'keiner'
          ? '<span style="color:#ff8ba0">Es gibt an diesem Gerät keinen Datenanschluss.</span>'
          : 'Richtung: ' + esc(a.weg.richtung === 'geraet_sendet' ? 'das Gerät ruft den PC an'
              : (a.weg.richtung === 'pc_fragt_ab' ? 'der PC fragt das Gerät ab'
                : (a.weg.richtung === 'beides' ? 'beides möglich' : 'nicht belegt'))) +
            (a.weg.port ? ' · Port ' + esc(a.weg.port) : '') +
            ' · ' + esc({ lan: 'LAN', wlan: 'WLAN', seriell: 'RS-232 (seriell)', usb: 'USB', datei: 'Datei' }[a.weg.transport] || a.weg.transport)) +
        '<br><span style="color:var(--muted)">Liefert: ' + esc(a.weg.liefert) + '</span></div>';
    }

    /* Die Anleitung — mit den ECHTEN Zahlen dieses PCs. */
    if ((a.schritte || []).length) {
      h += '<h4 style="margin:12px 0 6px">Am Gerät einstellen</h4>' +
        '<ol style="margin:0 0 0 18px;padding:0;font-size:13px;line-height:1.75">' +
        a.schritte.map(function (s) { return '<li>' + esc(s.text) + '</li>'; }).join('') + '</ol>';
    }
    (a.hinweise || []).forEach(function (x) {
      h += '<div style="margin-top:8px;padding:8px 10px;border-radius:8px;background:rgba(255,194,60,.10);' +
        'border:1px solid rgba(255,194,60,.3);font-size:12.5px;line-height:1.6">⚠ ' + esc(x) + '</div>';
    });

    /* Felder, die nur ein Mensch wissen kann: an welchem COM-Anschluss hängt das Gerät, welche
     * Baudrate steht dort. Sie werden hier abgefragt statt in devices.json getippt — und die
     * Bridge prüft jeden Wert (geraeteeinrichtung.felderPruefen), statt ihn zu übernehmen. */
    var wegVoll = ((g.wege || []).filter(function (w) { return a.weg && w.id === a.weg.id; })[0]) || null;
    var felder = (wegVoll && wegVoll.felder) || [];
    if (felder.length) {
      h += '<h4 style="margin:12px 0 6px">Wo hängt das Gerät?</h4>' +
        '<div style="display:flex;flex-direction:column;gap:8px;max-width:560px">' +
        felder.map(function (f) {
          var id = 'gf_' + esc(f.name);
          var eingabe = f.werte
            ? '<select id="' + id + '" data-gf="' + esc(f.name) + '" style="padding:6px 8px;border-radius:7px;' +
              'border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.05);color:inherit">' +
              f.werte.map(function (v) {
                return '<option value="' + esc(v) + '"' + (String(v) === String(f.vorgabe) ? ' selected' : '') + '>' + esc(v) + '</option>';
              }).join('') + '</select>'
            : '<input id="' + id + '" data-gf="' + esc(f.name) + '" type="text" value="' + esc(f.vorgabe == null ? '' : f.vorgabe) + '" ' +
              'style="padding:6px 8px;border-radius:7px;border:1px solid rgba(255,255,255,.18);' +
              'background:rgba(255,255,255,.05);color:inherit;width:190px">';
          return '<div style="display:flex;gap:10px;align-items:baseline;flex-wrap:wrap">' +
            '<label for="' + id + '" style="min-width:190px;font-size:12.5px">' + esc(f.text) + '</label>' + eingabe +
            (f.hilfe ? '<span style="color:var(--muted);font-size:11.5px;flex:1;min-width:200px">' + esc(f.hilfe) + '</span>' : '') +
            '</div>';
        }).join('') + '</div>';
    }

    /* Einrichten — nur, wenn dieser Weg überhaupt etwas herausgibt. */
    var blockiert = (ber.befunde || []).some(function (x) { return x.code === 'MODELL_OHNE_AUSGANG'; });
    h += '<div style="margin-top:12px">';
    if (blockiert) {
      h += '<span style="color:#ff8ba0;font-size:12.5px">Für diesen Weg gibt es nichts einzurichten — siehe unten.</span>';
    } else {
      h += '<button class="vs-btn" id="gerGo">✓ Dieses Gerät jetzt einrichten</button>' +
        '<span style="margin-left:10px;color:var(--muted);font-size:11.5px">schreibt den Eintrag, ergänzt den Port und startet sofort — ohne Neustart</span>';
    }
    h += '</div>';

    /* Die Beratung: warum kommt (noch) nichts? */
    var bef = (ber.befunde || []);
    if (bef.length) {
      h += '<h4 style="margin:16px 0 6px">Wenn keine Werte ankommen</h4>' +
        bef.map(function (x) {
          var c = x.schwere >= 3 ? '#ff8ba0' : (x.schwere === 2 ? '#ffc23c' : 'var(--muted)');
          var k = x.schwere >= 3 ? 'blockiert' : (x.schwere === 2 ? 'wahrscheinlich' : 'Hinweis');
          return '<div class="vs-sug" style="border-color:' + c + '55"><div class="k" style="color:' + c + '">' + k + '</div>' +
            '<b>' + esc(x.titel) + '</b>' +
            '<div style="color:var(--muted);font-size:12.5px;margin-top:5px">' + esc(x.warum) + '</div>' +
            ((x.tun || []).length ? '<ul style="margin:8px 0 0 18px;padding:0;font-size:12.5px;line-height:1.6">' +
              x.tun.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>' : '') + '</div>';
        }).join('');
    }

    if ((g.quellen || []).length) {
      h += '<p style="color:var(--muted);font-size:11px;margin-top:12px">Quellen: ' +
        g.quellen.map(function (q) { return esc(q); }).join(' · ') + '</p>';
    }
    return h + '</div>';
  }

  function wireGeraete(b) {
    var q = b.querySelector('#gerQ');
    if (q) {
      /* Tippen soll die Liste sofort filtern, ohne dass das Feld den Fokus verliert. Deshalb wird
       * NUR die Liste neu gebaut, nicht der ganze Reiter — genau daran ist der Koppel-Dialog
       * früher gescheitert (Fokusverlust bei jedem Buchstaben). */
      q.oninput = function () {
        gerSuche = q.value;
        fetch('/api/katalog?q=' + encodeURIComponent(gerSuche)).then(function (r) { return r.json(); }).then(function (kat) {
          var pos = q.selectionStart;
          b.innerHTML = viewGeraete(kat); wireGeraete(b);
          var q2 = b.querySelector('#gerQ');
          if (q2) { q2.focus(); try { q2.setSelectionRange(pos, pos); } catch (_) {} }
          if (gerAuswahl) ladeDetail(b);
        });
      };
    }
    b.querySelectorAll('[data-gerwahl]').forEach(function (el) {
      el.onclick = function () {
        gerAuswahl = { geraetId: el.getAttribute('data-gerwahl'), wegId: null };
        gerMeldung = null;
        var box = b.querySelector('#gerDetail');
        if (box) box.innerHTML = '<p style="color:var(--muted)">Lade Angaben zum Modell…</p>';
        ladeDetail(b);
        if (box && box.scrollIntoView) box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      };
    });
    b.querySelectorAll('[data-gerab]').forEach(function (el) {
      el.onclick = function () {
        if (!confirm('Diesen Eintrag abschalten? Er bleibt gespeichert und kann jederzeit wieder eingeschaltet werden.')) return;
        fetch('/api/geraete/abschalten', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: el.getAttribute('data-gerab') }) })
          .then(function (r) { return r.json(); })
          .then(function (a) { gerMeldung = a; loadGeraete(b); });
      };
    });
    var scan = b.querySelector('#gerScan');
    if (scan) {
      scan.onclick = function () {
        scan.disabled = true; scan.textContent = 'sucht… (bis zu einer Minute)';
        fetch('/api/netscan/start').then(function (r) { return r.json(); }).then(function (a) {
          /* Die Narkose-Sperre gilt ab 01.08.2026 AUCH hier. Wird abgelehnt, muss der Grund
           * sichtbar werden — sonst klickt jemand im OP-Betrieb dreimal auf einen Knopf, der
           * stumm nichts tut. */
          if (a && a.gestartet === false) {
            scan.disabled = false; scan.textContent = '🔎 Netzwerk jetzt durchsuchen';
            var warn = document.createElement('div');
            warn.style.cssText = 'margin-top:8px;padding:9px 11px;border-radius:9px;font-size:12.5px;' +
              'line-height:1.6;border:1px solid rgba(255,194,60,.45);background:rgba(255,194,60,.10)';
            warn.textContent = 'Die Suche wurde nicht gestartet: ' + (a.grund || 'kein Grund genannt.');
            scan.parentNode.appendChild(warn);
            return;
          }
          /* Der Suchlauf läuft in der Bridge weiter, auch wenn hier niemand hinsieht. Nachgesehen
           * wird alle 3 s; sobald er fertig ist, baut sich der Reiter neu auf. */
          var t = setInterval(function () {
            if (tab !== 'ger' || !host.classList.contains('open')) return clearInterval(t);
            fetch('/api/netscan').then(function (r) { return r.json(); }).then(function (s) {
              if (s.laufend) return;
              clearInterval(t);
              var body = host.querySelector('#adminBody'); if (body) loadGeraete(body);
            }).catch(function () { clearInterval(t); });
          }, 3000);
        });
      };
    }
    wireDetail(b);
  }

  function wireDetail(b) {
    b.querySelectorAll('[data-gerweg]').forEach(function (el) {
      el.onclick = function () {
        if (!gerAuswahl) return;
        gerAuswahl.wegId = el.getAttribute('data-gerweg');
        ladeDetail(b);
      };
    });
    var go = b.querySelector('#gerGo');
    if (go) {
      go.onclick = function () {
        if (!gerAuswahl) return;
        go.disabled = true; go.textContent = 'richtet ein…';
        var felder = {};
        b.querySelectorAll('[data-gf]').forEach(function (el) { felder[el.getAttribute('data-gf')] = el.value; });
        fetch('/api/geraete/einrichten', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ geraetId: gerAuswahl.geraetId, wegId: gerDetail && gerDetail.anleitung && gerDetail.anleitung.weg ? gerDetail.anleitung.weg.id : null, felder: felder }) })
          .then(function (r) { return r.json(); })
          .then(function (a) {
            gerMeldung = a;
            var body = host.querySelector('#adminBody'); if (body) loadGeraete(body);
          })
          .catch(function (e) { go.disabled = false; go.textContent = '✓ Dieses Gerät jetzt einrichten (' + e.message + ')'; });
      };
    }
  }

  /* ================= Netzwerk & Geräte =================
   * Die Station prüft ihr Netz SELBST und sagt im Klartext, wo das Problem liegen kann.
   * Kernbefund 21.07.2026: Empfang und Auswertung funktionierten — es fehlte jede brauchbare
   * Information darüber, WARUM nichts ankommt. Genau das steht jetzt hier.
   */
  var netzTimer = null;
  function stopNetzPoll() { if (netzTimer) { clearInterval(netzTimer); netzTimer = null; } }

  function loadNetz(b) {
    fetch('/api/netscan').then(function (r) { return r.json(); }).then(function (s) {
      b.innerHTML = viewNetz(s); wireNetz(b, s);
      if (s.laufend && !netzTimer) startNetzPoll(b);
    }).catch(function (e) {
      b.innerHTML = '<p style="color:#ff8ba0">Netzwerkzustand nicht abrufbar: ' + esc(e.message) + '</p>';
    });
  }
  function startNetzPoll(b) {
    stopNetzPoll();
    netzTimer = setInterval(function () {
      if (tab !== 'netz' || !host.classList.contains('open')) return stopNetzPoll();
      fetch('/api/netscan').then(function (r) { return r.json(); }).then(function (s) {
        var body = host.querySelector('#adminBody'); if (!body) return stopNetzPoll();
        body.innerHTML = viewNetz(s); wireNetz(body, s);
        if (!s.laufend) stopNetzPoll();
      }).catch(function () { stopNetzPoll(); });
    }, 1200);
  }

  var URTEIL_FARBE = { ok: '#35d69a', problem: '#ff8ba0', unklar: '#ffc23c' };
  var STUFE = {
    sicher: { farbe: '#35d69a', zeichen: '✓', text: 'sicher ein Gerät' },
    moeglich: { farbe: '#ffc23c', zeichen: '?', text: 'möglich' },
    unwahrscheinlich: { farbe: 'var(--muted)', zeichen: '·', text: 'unwahrscheinlich' },
    selbst: { farbe: '#7cc4ff', zeichen: '▣', text: 'dieser PC' }
  };

  function viewNetz(s) {
    var d = s.diagnose || { urteil: 'unklar', kurz: 'Noch nicht geprüft.', befunde: [] };
    var farbe = URTEIL_FARBE[d.urteil] || '#ffc23c';
    var h = '';

    // 1) Urteil in EINEM Satz — das ist die Zeile, die vorher gefehlt hat.
    h += '<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:12px;' +
      'border:1px solid ' + farbe + '55;background:' + farbe + '14;margin-bottom:12px">' +
      '<span style="width:12px;height:12px;border-radius:50%;background:' + farbe + ';box-shadow:0 0 10px ' + farbe + '"></span>' +
      '<b style="font-size:15px">' + esc(d.kurz) + '</b></div>';

    // 2) Der Knopf, um den es geht: die App sucht ihr Netz selbst ab.
    if (s.laufend) {
      var f = s.fortschritt || { getan: 0, gesamt: 1, text: 'läuft…' };
      var pct = Math.round(100 * (f.getan || 0) / Math.max(1, f.gesamt || 1));
      h += '<div style="margin-bottom:12px"><div style="color:var(--muted);font-size:12.5px;margin-bottom:5px">' + esc(f.text || 'Suche läuft…') + '</div>' +
        '<div style="height:8px;border-radius:5px;background:rgba(255,255,255,.09);overflow:hidden">' +
        '<div style="height:100%;width:' + pct + '%;background:#23c7bb;transition:width .3s"></div></div></div>';
    } else {
      h += '<button class="vs-btn" id="netzGo">🔎 Netzwerk jetzt durchsuchen</button>' +
        '<span style="margin-left:10px;color:var(--muted);font-size:12px">' +
        (s.ts ? 'zuletzt geprüft: ' + new Date(s.ts).toLocaleTimeString() : 'noch nicht geprüft') +
        ' · prüft alle Adressen .1–.254, dauert je nach Netz einige Sekunden bis etwa eine Minute</span>';
    }

    // 3) Wo das Problem liegen kann — rangiert, mit Begründung und konkretem nächsten Schritt.
    var bef = (d.befunde || []).filter(function (x) { return x.code !== 'EMPFANG_OK'; });
    if (bef.length) {
      h += '<h3 style="margin:16px 0 8px">Wo das Problem liegen kann</h3>';
      h += bef.map(function (x) {
        var c = x.schwere >= 3 ? '#ff8ba0' : (x.schwere === 2 ? '#ffc23c' : 'var(--muted)');
        var k = x.schwere >= 3 ? 'blockiert' : (x.schwere === 2 ? 'wahrscheinlich' : 'Hinweis');
        return '<div class="vs-sug" style="border-color:' + c + '55"><div class="k" style="color:' + c + '">' + k + '</div>' +
          '<b>' + esc(x.titel) + '</b>' +
          '<div style="color:var(--muted);font-size:12.5px;margin-top:5px">' + esc(x.warum) + '</div>' +
          (x.tun && x.tun.length
            ? '<ul style="margin:8px 0 0 18px;padding:0;font-size:12.5px;line-height:1.6">' +
              x.tun.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>'
            : '') + '</div>';
      }).join('');
    }

    // 4) Was die Suche gefunden hat — jeder Fund mit Begründung, nichts wird verschwiegen.
    var e = s.ergebnis;
    if (e) {
      h += '<h3 style="margin:16px 0 8px">Gefundene Teilnehmer' +
        (e.netz ? ' im Netz ' + esc(e.netz.base) + '1–254' : '') + '</h3>';
      if (!e.hosts || !e.hosts.length) {
        h += '<p style="color:var(--muted)">Kein einziger Teilnehmer hat geantwortet.</p>';
      } else {
        // Beantwortet die Frage, die sich bei jeder Inbetriebnahme stellt: was trage ich am
        // GERÄT bei Gateway und DNS ein? Das hängt allein daran, ob ein Router im Netz hängt.
        var router = null;
        for (var ri = 0; ri < e.hosts.length; ri++) { if (e.hosts[ri].istGateway) { router = e.hosts[ri]; break; } }
        var pcIp = (e.adapter && e.adapter.address) || '192.168.0.99';
        h += '<div style="padding:9px 11px;border-radius:9px;background:rgba(35,199,187,.10);' +
          'border:1px solid rgba(35,199,187,.35);margin-bottom:9px;font-size:12.5px;line-height:1.65">' +
          '<b>Am Gerät bei „Gateway" und „Bevorzugter DNS-Server" eintragen:</b><br>' +
          (router
            ? 'Gateway <b>' + esc(router.ip) + '</b> · DNS <b>' + esc(router.ip) + '</b> — auf ' + esc(router.ip) + ' antwortet ein Router.'
            : 'Gateway <b>0.0.0.0</b> · DNS <b>0.0.0.0</b> — es hängt kein Router im Netz (eigener Switch).') +
          '<br><span style="color:var(--muted)">Für die Datenverbindung ist beides ohne Bedeutung: VetStation wird über die ' +
          'Zahl <b>' + esc(pcIp) + '</b> angesprochen, nicht über einen Namen. Ein fehlender DNS-Eintrag kann die Werte ' +
          'weder verhindern noch verbessern.</span></div>';
        h += '<div style="display:flex;flex-direction:column;gap:6px">' + e.hosts.map(function (x) {
          var st = STUFE[x.stufe] || STUFE.moeglich;
          return '<div style="display:flex;gap:10px;align-items:flex-start;padding:8px 10px;border-radius:9px;background:rgba(255,255,255,.035)">' +
            '<span style="color:' + st.farbe + ';font-weight:700;min-width:14px">' + st.zeichen + '</span>' +
            '<div style="flex:1;min-width:0">' +
            '<b>' + esc(x.ip) + '</b> <span style="color:' + st.farbe + ';font-size:12px">' + st.text + '</span>' +
            (x.mac ? ' <span style="color:var(--muted);font-size:11.5px">' + esc(x.mac) + '</span>' : '') +
            '<div style="color:var(--muted);font-size:12px;margin-top:2px">' + esc((x.gruende || []).join(' · ')) + '</div>' +
            '</div></div>';
        }).join('') + '</div>';
        if (!e.arpOk) h += '<p style="color:var(--muted);font-size:11.5px;margin-top:6px">Die MAC-Tabelle (arp) war nicht lesbar — Herstellerangaben fehlen deshalb. Die Einstufung nach offenen Datenports gilt unverändert.</p>';
      }
    }

    // 5) Dieser PC + Firewall — Zustand, nicht Empfehlung.
    if (e && e.adapters) {
      h += '<h3 style="margin:16px 0 8px">Dieser PC</h3><div style="font-size:12.5px;line-height:1.7">' +
        e.adapters.map(function (a) {
          return '• <b>' + esc(a.name) + '</b>: ' + esc(a.address) + ' (Maske ' + esc(a.netmask) + ')' +
            (a.virtuell ? ' <span style="color:#ffc23c">— virtuell/VPN, nicht verwenden</span>' : '');
        }).join('<br>') + '</div>';
    }
    if (s.firewall) {
      h += '<h3 style="margin:16px 0 8px">Windows-Firewall</h3><div style="font-size:12.5px;line-height:1.7">' +
        s.firewall.ports.map(function (p) {
          var t = p.zustand === 'frei' ? '<span style="color:#8fe3b8">✓ freigegeben' + (p.anzahl > 1 ? ' (' + p.anzahl + ' Regeln — doppelt)' : '') + '</span>'
            : (p.zustand === 'fehlt' ? '<span style="color:#ff8ba0">✗ FEHLT — Windows verwirft die Daten lautlos</span>'
              : '<span style="color:#ffc23c">? unklar (nicht lesbar)</span>');
          return '• TCP ' + p.port + ': ' + t;
        }).join('<br>') + '</div>' +
        '<p style="color:var(--muted);font-size:11.5px;margin-top:6px">Reparieren mit Doppelklick: <b>C:\\VetStation\\FIREWALL-FREIGEBEN.bat</b></p>';
    }

    h += '<p style="color:var(--muted);font-size:11.5px;margin-top:14px">Die Suche ist <b>rein lesend</b>: es wird nur kurz angeklopft und sofort wieder aufgelegt — an keinem Gerät wird etwas verstellt.</p>';
    return h;
  }

  function wireNetz(b, s) {
    var go = b.querySelector('#netzGo'); if (!go) return;
    go.onclick = function () {
      go.disabled = true; go.textContent = 'startet…';
      fetch('/api/netscan/start').then(function () { startNetzPoll(b); loadNetz(b); })
        .catch(function (e) { go.disabled = false; go.textContent = '🔎 Netzwerk jetzt durchsuchen (' + e.message + ')'; });
    };
  }

  /* ================= Google-Anmeldung der Station =========================================
   * Google verlangt seine eigene Zustimmungsseite, also einen Browser. Die Station HAT einen —
   * ihre Oberfläche läuft darin. Der Browser meldet sich an, und die Bridge bekommt anschließend
   * nur noch die Erneuerungs-Kennung; das Passwort sieht sie nie.
   *
   * WEITERLEITUNG statt Popup: Der Kiosk startet Edge mit "--kiosk", dort werden neue Fenster
   * blockiert — ein Popup-Anmeldefenster bliebe unsichtbar hängen. Die Weiterleitung ist eine
   * ganz normale Navigation und funktioniert auch im Vollbild-Kiosk.
   *
   * Nach der Rückkehr ist die Seite neu geladen und der Admin-Bereich zu. Deshalb merkt sich
   * sessionStorage, dass eine Anmeldung unterwegs ist; beim Start wird das Ergebnis abgeholt.
   * ====================================================================================== */
  var FBSDK = 'https://www.gstatic.com/firebasejs/10.12.0/';
  var GOOGLE_MARKE = 'vs_google_anmeldung';

  function firebaseCfg() {
    // Dieselben öffentlichen Werte wie in der Web-App (kein Geheimnis, stehen in jeder Firebase-App).
    return {
      apiKey: 'AIzaSyBqcWNqa-X16O_Z3VAb6mOtRJZhQmGOKj0',
      authDomain: 'vet-station.firebaseapp.com',
      databaseURL: 'https://vet-station-default-rtdb.europe-west1.firebasedatabase.app',
      projectId: 'vet-station',
    };
  }
  function ladeAuth() {
    return Promise.all([import(FBSDK + 'firebase-app.js'), import(FBSDK + 'firebase-auth.js')])
      .then(function (m) {
        var app = m[0].initializeApp(firebaseCfg());
        return { A: m[1], auth: m[1].getAuth(app) };
      });
  }
  /*
   * Anmelde-Anbieter. Google hat in Firebase eine eigene Klasse, alle uebrigen laufen ueber
   * OAuthProvider mit ihrer Kennung — Microsoft/Outlook ist "microsoft.com".
   * Bei Microsoft wird bewusst KEIN "tenant" gesetzt: mit der Vorgabe "common" funktionieren
   * sowohl persoenliche Outlook-/Hotmail-Konten als auch Geschaeftskonten einer Praxis.
   */
  function anbieterObjekt(fb, id) {
    var p = (id === 'google.com') ? new fb.A.GoogleAuthProvider() : new fb.A.OAuthProvider(id);
    // Kontoauswahl erzwingen: an einem Praxis-PC melden sich sonst alle unbemerkt mit dem
    // zuletzt benutzten Konto an — und landen im falschen Datenpfad.
    p.setCustomParameters({ prompt: 'select_account' });
    return p;
  }
  function anbieterName(id) { return id === 'microsoft.com' ? 'Microsoft' : 'Google'; }

  /*
   * Ist dieser Anmeldeweg im Firebase-Projekt ueberhaupt eingerichtet? Firebase beantwortet das
   * ohne Anmeldung: ein fehlender Anbieter meldet OPERATION_NOT_ALLOWED. Die Antwort wird
   * gemerkt. Bei Netzstoerung gilt "ja" — im Zweifel probieren lassen statt sperren.
   */
  var anbieterCache = {};
  function anbieterFreigeschaltet(id, fertig) {
    if (anbieterCache[id] !== undefined) { fertig(anbieterCache[id]); return; }
    var cfg = firebaseCfg();
    fetch('https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=' + encodeURIComponent(cfg.apiKey), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ providerId: id, continueUri: location.origin + '/' }),
    }).then(function (r) { return r.json(); }).then(function (j) {
      var frei = !(j && j.error && /OPERATION_NOT_ALLOWED|CONFIGURATION_NOT_FOUND/i.test(j.error.message || ''));
      anbieterCache[id] = frei; fertig(frei);
    }).catch(function () { fertig(true); });
  }

  /*
   * EIGENES FENSTER ZUERST, WEITERLEITUNG NUR NOCH ALS AUSWEG.
   *
   * Bis 1.0.3 lief die Anmeldung der Station AUSSCHLIESSLICH ueber signInWithRedirect. Das
   * funktioniert nicht mehr: die Station laeuft auf 127.0.0.1, die Anmeldung gehoert
   * vet-station.firebaseapp.com — zwei verschiedene Adressen. Genau deren Speicher trennen
   * Chrome und Edge inzwischen voneinander. Die Weiterleitung kommt dann zwar zurueck,
   * getRedirectResult liefert aber null: kein Konto, kein Fehler, keine Meldung (nachgemessen
   * am 29.07.2026). Fuer den Tierarzt sieht das aus, als tue der Knopf nichts.
   *
   * Deshalb: erst das eigene Fenster (postMessage statt Fremdspeicher — davon unberuehrt),
   * und nur wenn der Browser das Fenster verbietet, die Weiterleitung. Der Kiosk startet Edge
   * jetzt mit erlaubten Fenstern (kiosk\launch-kiosk.ps1), damit der erste Weg auch dort traegt.
   */
  function oauthAnmeldung(id, sag) {
    ladeAuth().then(function (fb) {
      return fb.A.signInWithPopup(fb.auth, anbieterObjekt(fb, id)).then(function (res) {
        return uebergabeAnBridge(fb, res && res.user, id, sag);
      }).catch(function (e) {
        var c = (e && e.code) || '';
        if (/popup-closed-by-user|cancelled-popup|user-cancelled/i.test(c)) { if (sag) sag('Abgebrochen.'); return; }
        if (!/popup-blocked|operation-not-supported|web-storage-unsupported/i.test(c)) throw e;
        if (sag) sag('Das eigene Fenster wurde blockiert — versuche Weiterleitung…', '#ffb84d');
        try { sessionStorage.setItem(GOOGLE_MARKE, id); } catch (x) {}
        return fb.A.signInWithRedirect(fb.auth, anbieterObjekt(fb, id));
      });
    }).catch(function (e) {
      try { sessionStorage.removeItem(GOOGLE_MARKE); } catch (x) {}
      if (sag) sag('✗ ' + googleFehler(e), '#ff8ba0');
    });
  }

  /*
   * Die Bridge bekommt NUR die Erneuerungs-Kennung — nie ein Passwort. Sie glaubt der
   * mitgeschickten Konto-Kennung nicht, sondern holt sie sich selbst bei Google (cloud.js).
   */
  function uebergabeAnBridge(fb, u, id, sag) {
    if (!u) { if (sag) sag('✗ Es kam keine Anmeldung zurück.', '#ff8ba0'); return; }
    if (sag) sag('übergebe an die Station…');
    return fetch('/api/praxis/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: u.refreshToken, uid: u.uid, email: u.email }),
    }).then(function (r) { return r.json(); }).then(function (a) {
      /* Die Anmeldung des BROWSERS wird danach wieder aufgehoben: die Station braucht sie
       * nicht mehr (die Bridge hat die Kennung), und ein dauerhaft angemeldeter Kiosk-Browser
       * am Empfangstresen wäre ein unnötiges offenes Konto. */
      try { fb.A.signOut(fb.auth); } catch (e) {}
      var gut = !!(a && a.ok);
      if (sag) sag(gut ? '✓ angemeldet' : '✗ ' + ((a && a.fehler) || 'unbekannt'), gut ? '#8fe3b8' : '#ff8ba0');
      meldung(gut
        ? '✓ Praxis-Konto über ' + anbieterName(id) + ' angemeldet — Fern-Live sendet.'
        : '✗ Anmeldung fehlgeschlagen: ' + ((a && a.fehler) || 'unbekannt'), gut);
      if (gut) setTimeout(function () { var b = document.querySelector('#adminBody'); if (b) loadFern(b); }, 700);
    });
  }

  function googleFehler(e) {
    var c = (e && e.code) || '';
    if (/unauthorized-domain/i.test(c)) return 'Diese Adresse ist in Firebase nicht freigegeben (Authentication → Einstellungen → Autorisierte Domains → 127.0.0.1).';
    if (/operation-not-allowed/i.test(c)) return 'Dieser Anmeldeweg ist im Firebase-Projekt nicht freigeschaltet. Bitte Google verwenden oder das Konto mit E-Mail und Passwort anlegen.';
    if (/network-request-failed/i.test(c)) return 'Keine Internetverbindung.';
    if (/popup-blocked|cancelled-popup/i.test(c)) return 'Das Anmeldefenster wurde blockiert.';
    if (/account-exists-with-different-credential/i.test(c)) return 'Für diese E-Mail gibt es schon ein Konto mit einem anderen Anmeldeweg.';
    return (e && e.message) || String(e);
  }
  /*
   * Wird beim Laden der Oberfläche aufgerufen. Holt das Ergebnis einer laufenden Weiterleitungs-
   * Anmeldung ab. Läuft still, wenn keine unterwegs war — der normale Fall bei jedem Start.
   *
   * Kommt die Weiterleitung LEER zurück, wird das ausgesprochen statt verschwiegen: genau dieser
   * Fall (kein Konto, kein Fehler) ist der Grund, warum die Anmeldung auf dem Praxis-PC scheinbar
   * grundlos nichts tat.
   */
  function googleRueckkehrPruefen() {
    var offen = null;
    try { offen = sessionStorage.getItem(GOOGLE_MARKE); } catch (e) {}
    if (!offen) return;
    try { sessionStorage.removeItem(GOOGLE_MARKE); } catch (e) {}
    var id = (offen === '1') ? 'google.com' : offen;   // '1' = Altbestand aus 1.0.1/1.0.2
    ladeAuth().then(function (fb) {
      return fb.A.getRedirectResult(fb.auth).then(function (res) {
        var u = res && res.user;
        if (!u) {
          meldung('✗ Die Anmeldung über ' + anbieterName(id) + ' kam leer zurück — dieser Browser ' +
            'trennt den Speicher fremder Adressen. Bitte den Knopf erneut drücken (dann öffnet sich ein ' +
            'eigenes Anmeldefenster) oder sich hier mit E-Mail und Passwort anmelden — das geht immer.', false);
          return;
        }
        return uebergabeAnBridge(fb, u, id, null);
      });
    }).catch(function (e) { meldung('✗ Anmeldung: ' + googleFehler(e), false); });
  }
  // Kurze Rückmeldung, auch wenn der Admin-Bereich gerade zu ist.
  function meldung(text, gut) {
    var d = document.createElement('div');
    d.textContent = text;
    d.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:99999;' +
      'padding:10px 16px;border-radius:10px;font:600 13px system-ui,sans-serif;color:#fff;' +
      'box-shadow:0 8px 26px rgba(0,0,0,.45);background:' + (gut ? '#1f8f5f' : '#a33');
    document.body.appendChild(d);
    setTimeout(function () { d.remove(); }, 9000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', googleRueckkehrPruefen);
  else googleRueckkehrPruefen();

  // ---- Fern-Live (Werte über Internet in die Web-App, Anmeldung mit dem Praxis-Konto) ----
  // Bewusst /api/praxis statt /api/cloud: nur dieser Endpunkt liefert Anmeldename und Kennung,
  // und er ist auf den Praxis-PC selbst beschränkt (kein Access-Control-Allow-Origin).
  function loadFern(b) {
    fetch('/api/praxis').then(function (r) { return r.json(); }).then(function (c) { b.innerHTML = viewFern(c); wireFern(b, c); })
      .catch(function (e) { b.innerHTML = '<p style="color:#ff8ba0">Status nicht abrufbar: ' + esc(e.message) + '</p>'; });
  }
  function viewFern(c) {
    if (!c || !c.enabled) {
      // Vollstaendige Pfade: auf dem Praxis-PC liegt alles unter C:\VetStation, und ausgeliefert
      // wird nur devices.example.json - devices.json muss der Nutzer erst daraus erzeugen.
      return '<div class="vs-sug"><div class="k">inaktiv</div>Fern-Live ist ausgeschaltet. So aktivieren:' +
        '<br>1. Ordner <code>C:\\VetStation\\bridge\\config\\</code> öffnen.' +
        '<br>2. Ist dort noch keine <code>devices.json</code>: <code>devices.example.json</code> kopieren und die Kopie in <code>devices.json</code> umbenennen.' +
        '<br>3. Die Datei mit <b>Editor/Notepad</b> öffnen (Rechtsklick → Öffnen mit → Editor) und im <code>cloud</code>-Block <b>enabled:true</b> setzen.</div>' +
        '<p style="color:var(--muted);margin-top:10px">Schritt für Schritt: <b>C:\\VetStation\\docs\\FERN-LIVE.md</b>. Danach VetStation beenden und neu starten.</p>';
    }

    /* NICHT ANGEMELDET → Anmeldemaske. Das ist der Normalfall bei der Erstinbetriebnahme. */
    if (!c.angemeldet) {
      return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><span style="width:11px;height:11px;border-radius:50%;background:#ffc23c;box-shadow:0 0 8px #ffc23c"></span><b>Praxis-Konto anmelden</b></div>' +
        '<p style="color:var(--muted);font-size:12.5px;margin:0 0 12px;line-height:1.6">Jede Praxis hat ein <b>eigenes Konto</b>. Alle Werte, Kurven und Protokolle dieser Station ' +
        'liegen darunter und sind <b>ausschließlich für dieses Konto</b> lesbar – keine andere Praxis kommt daran. ' +
        'Zum Ansehen von zu Hause in der Web-App <b>dasselbe Konto</b> verwenden.</p>' +
        '<div style="display:grid;gap:8px;max-width:420px">' +
        '<label style="font-size:12.5px;color:var(--muted)">E-Mail der Praxis' +
        '<input id="pxMail" type="email" autocomplete="username" class="vs-ta" style="min-height:0;height:40px;width:100%;font-size:13px;margin-top:3px" value="' + esc(c.email || '') + '" placeholder="praxis@beispiel.de"></label>' +
        '<label style="font-size:12.5px;color:var(--muted)">Passwort' +
        '<input id="pxPw" type="password" autocomplete="current-password" class="vs-ta" style="min-height:0;height:40px;width:100%;font-size:13px;margin-top:3px" placeholder="••••••••"></label>' +
        '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button class="vs-btn" id="pxLogin">🔐 Anmelden</button>' +
        '<span id="pxMsg" style="font-size:12.5px;color:var(--muted)"></span></div>' +
        '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:2px">' +
        '<button class="vs-btn" data-anb="google.com" style="background:#fff;color:#3c4043;border-color:#dadce0">Mit Google anmelden</button>' +
        '<button class="vs-btn" data-anb="microsoft.com" style="background:#fff;color:#3c4043;border-color:#dadce0">Mit Microsoft / Outlook anmelden</button>' +
        '</div>' +
        '</div>' +
        '<p style="color:var(--muted);font-size:11.5px;margin-top:14px;line-height:1.6">Das Passwort wird <b>nicht gespeichert</b> – nur eine Erneuerungs-Kennung, damit die Station nach ' +
        'einem Neustart von selbst weitersendet. Noch kein Konto? In der Web-App unter ' +
        '<b>quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/</b> einmalig eines anlegen.</p>';
    }

    var stColor = c.started ? '#35d69a' : '#ffc23c';
    var stTxt = c.started ? 'aktiv &amp; angemeldet' : 'angemeldet – gestoppt';
    var last = c.lastPublish ? new Date(c.lastPublish).toLocaleTimeString() : '–';
    var kb = c.bytesGesendet ? Math.round(c.bytesGesendet / 1024) : 0;
    return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span style="width:11px;height:11px;border-radius:50%;background:' + stColor + ';box-shadow:0 0 8px ' + stColor + '"></span><b>Fern-Live ' + stTxt + '</b></div>' +
      '<div style="color:var(--muted);font-size:12.5px;margin-bottom:6px">Konto <b>' + esc(c.email || '–') + '</b> · Station <b>' + esc(c.station || '') + '</b> · zuletzt gesendet ' + last +
      (c.lastError ? ' · <span style="color:#ff8ba0">Fehler: ' + esc(c.lastError) + '</span>' : '') + '</div>' +
      '<div style="color:var(--muted);font-size:12px;margin-bottom:12px">Takt ' + esc(String(c.taktMs || '?')) + ' ms · ' +
      esc(String(c.schreibVorgaenge || 0)) + ' Übertragungen · ' + kb + ' KB gesendet · ' +
      esc(String(c.protokollGesendet || 0)) + ' Protokollzeilen' + (c.kurven ? ' · echte Kurven an' : '') + '</div>' +
      '<div style="color:var(--muted);font-size:12.5px;margin-bottom:4px">Von zu Hause öffnen und dort mit <b>demselben Konto</b> anmelden:</div>' +
      '<div style="display:flex;gap:6px;align-items:stretch"><input id="fernUrl" class="vs-ta" readonly style="min-height:0;height:40px;flex:1;font-size:12px" value="' + esc(c.url || '') + '"><button class="vs-btn" id="fernCopy">⧉ Kopieren</button></div>' +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:10px;line-height:1.6">READ-ONLY: fern kann niemand ein Gerät bedienen. ' +
      'Die Daten liegen unter der Kennung dieses Kontos und sind für kein anderes Konto lesbar.</p>' +
      '<button class="vs-btn" id="pxLogout" style="margin-top:8px">Abmelden</button> <span id="pxMsg" style="font-size:12.5px;color:var(--muted)"></span>';
  }
  // ---- In-App-Update (§13) ----
  function loadUpdate(b) {
    fetch('/api/update/check').then(function (r) { return r.json(); }).then(function (c) { b.innerHTML = viewUpdate(c); wireUpdate(b, c); })
      .catch(function (e) { b.innerHTML = '<p style="color:#ff8ba0">Update-Prüfung nicht möglich: ' + esc(e.message) + '</p>'; });
  }
  function viewUpdate(c) {
    var head = '<div style="margin-bottom:10px"><b>App-Version:</b> ' + esc(c.current || '?') + ' <span style="color:var(--muted)">(' + esc(c.channel || 'stable') + ')</span></div>' +
      '<div class="vs-sug" style="border-color:rgba(53,214,154,.35)"><div class="k">automatisch</div>Klinische Daten (Medikamente, Dosen, Logik) aktualisieren sich <b>zur Laufzeit</b> vom Live-Server – ohne Neuinstallation.</div>';
    if (c.pending) head += '<div class="vs-sug" style="border-color:rgba(255,209,102,.5)"><div class="k">bereit</div>Update <b>' + esc(c.pending.version) + '</b> ist geladen &amp; geprüft – wird beim <b>nächsten Neustart</b> angewendet.</div>';
    var body;
    if (!c.manifestUrl) body = '<p style="color:var(--muted)">Kein App-Shell-Update-Kanal konfiguriert. (Nur Laufzeit-Datenupdate aktiv.)</p>';
    else if (!c.reachable) body = '<p style="color:var(--muted)">Update-Server nicht erreichbar: ' + esc(c.msg || 'offline') + '<br><small>Manifest: ' + esc(c.manifestUrl) + '</small></p>';
    else if (c.updateAvailable) body = '<div class="vs-sug" style="border-color:#23c7bb"><div class="k">neu</div><b>Neue Version ' + esc(c.latest) + '</b> verfügbar.' + (c.notes ? '<br>' + esc(c.notes) : '') + '</div>' +
      '<button class="vs-btn" id="updApply" style="margin-top:6px">⬇ Update laden &amp; anwenden</button> <span id="updMsg" style="margin-left:8px;font-size:12.5px;color:var(--muted)"></span>';
    else body = '<p style="color:#8fe3b8">✓ App-Shell ist aktuell (' + esc(c.latest || c.current) + ').</p>';
    return head + '<h3 style="margin:12px 0 6px">App-Programm (Bridge/Adapter/Oberfläche)</h3>' + body +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:12px">Updates sind ' + (c.isGit ? 'Git-basiert (git pull)' : 'Zip-basiert (Download + sha256-Prüfung, Anwendung beim Neustart)') + '. Es werden nie automatisch klinische Dosierungen geändert – Datensatz-/Logikänderungen bleiben geprüfte Schritte.</p>';
  }
  function wireUpdate(b, c) {
    var btn = b.querySelector('#updApply'); if (!btn) return;
    btn.onclick = function () {
      var msg = b.querySelector('#updMsg'); btn.disabled = true; if (msg) msg.textContent = 'lädt & prüft…';
      fetch('/api/update/apply').then(function (r) { return r.json(); }).then(function (res) {
        if (msg) { msg.textContent = (res.ok ? '✓ ' : '✗ ') + (res.msg || ''); msg.style.color = res.ok ? '#8fe3b8' : '#ff8ba0'; }
        // WICHTIG: location.reload() wuerde nur die Browser-Seite neu laden - das Update wird
        // aber von kiosk\launch-kiosk.ps1 (Apply-StagedUpdate) VOR dem Start der Bridge
        // angewendet. Es braucht also einen echten Neustart des Programms. Bewusst KEIN
        // automatischer Neustart: die Station laeuft waehrend der OP am Patienten.
        if (res.ok && res.restart) {
          btn.remove();
          var hin = document.createElement('div');
          hin.className = 'vs-sug';
          hin.style.borderColor = 'rgba(255,209,102,.5)';
          hin.style.marginTop = '8px';
          hin.innerHTML = '<div class="k">geladen &amp; geprüft</div>Das Update liegt bereit. Es wird beim ' +
            '<b>nächsten Start von VetStation</b> automatisch angewendet — <b>nicht</b> durch Neuladen dieser Seite.' +
            '<br><br><b>Bitte erst nach der OP:</b> VetStation beenden und neu starten (oder den PC neu starten). ' +
            'Beim Hochfahren erscheint kurz „Wende bereitgestelltes App-Update an…" — danach läuft die neue Version.';
          b.appendChild(hin);
        }
      }).catch(function (e) { if (msg) { msg.textContent = '✗ ' + e.message; msg.style.color = '#ff8ba0'; } btn.disabled = false; });
    };
  }

  function wireFern(b, c) {
    var msg = b.querySelector('#pxMsg');
    function sag(t, farbe) { if (msg) { msg.textContent = t; msg.style.color = farbe || 'var(--muted)'; } }

    var login = b.querySelector('#pxLogin');
    if (login) {
      var mailEl = b.querySelector('#pxMail'), pwEl = b.querySelector('#pxPw');
      var anmelden = function () {
        var mail = (mailEl && mailEl.value || '').trim(), pw = (pwEl && pwEl.value) || '';
        if (!mail || !pw) { sag('Bitte E-Mail und Passwort eingeben.', '#ffb84d'); return; }
        login.disabled = true; sag('melde an…');
        // Zugangsdaten ausschliesslich im Koerper einer POST-Anfrage - niemals in der Adresszeile,
        // sonst stuenden sie im Browserverlauf.
        fetch('/api/praxis/anmelden', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: mail, passwort: pw }),
        }).then(function (r) { return r.json(); }).then(function (res) {
          if (pwEl) pwEl.value = '';
          if (res && res.ok) { sag('✓ angemeldet', '#8fe3b8'); setTimeout(function () { loadFern(b); }, 700); }
          else { sag('✗ ' + ((res && res.fehler) || 'Anmeldung fehlgeschlagen'), '#ff8ba0'); login.disabled = false; }
        }).catch(function (e) { sag('✗ ' + e.message, '#ff8ba0'); login.disabled = false; });
      };
      login.onclick = anmelden;
      // Enter im Passwortfeld meldet an - sonst sucht der Tierarzt den Knopf.
      if (pwEl) pwEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') anmelden(); });

      b.querySelectorAll('[data-anb]').forEach(function (btn) {
        var id = btn.getAttribute('data-anb');
        /* Nicht freigeschaltete Anbieter ehrlich beschriften, statt einen Knopf anzubieten, der
         * ins Leere laeuft. Die Auskunft ist oeffentlich und kostet einen Aufruf. */
        anbieterFreigeschaltet(id, function (frei) {
          if (frei) return;
          btn.disabled = true; btn.style.opacity = '.55'; btn.style.cursor = 'not-allowed';
          btn.textContent = btn.textContent + ' — noch nicht freigeschaltet';
          btn.title = 'Dieser Anmeldeweg ist im Firebase-Projekt noch nicht freigeschaltet.';
        });
        btn.onclick = function () {
          /* Der Knopf bleibt bedienbar: das Anmeldefenster kann geschlossen werden, und dann
           * muss ein zweiter Versuch moeglich sein, ohne die Seite neu zu laden. */
          sag('Ein eigenes Anmeldefenster von ' + anbieterName(id) + ' ist offen — bitte dort fortfahren.');
          oauthAnmeldung(id, sag);
        };
      });
    }

    var logout = b.querySelector('#pxLogout');
    if (logout) {
      logout.onclick = function () {
        logout.disabled = true; sag('melde ab…');
        fetch('/api/praxis/abmelden', { method: 'POST' }).then(function (r) { return r.json(); })
          .then(function () { loadFern(b); })
          .catch(function (e) { sag('✗ ' + e.message, '#ff8ba0'); logout.disabled = false; });
      };
    }

    var cp = b.querySelector('#fernCopy'); if (!cp) return;
    cp.onclick = function () {
      var inp = b.querySelector('#fernUrl'); if (!inp) return;
      inp.select();
      var done = function () { cp.textContent = '✓ kopiert'; setTimeout(function () { cp.textContent = '⧉ Kopieren'; }, 1500); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(inp.value).then(done, function () { try { document.execCommand('copy'); done(); } catch (e) {} });
      else { try { document.execCommand('copy'); done(); } catch (e) {} }
    };
  }

  function viewSuggestions() {
    var s = VS.feedback.suggestions();
    if (!s.length) return '<p style="color:var(--muted)">Noch keine Auffälligkeiten. Vorschläge entstehen aus überstimmten Empfehlungen, fehlenden Inhalten und Verbindungsfehlern.</p>';
    return '<p style="color:var(--muted)">Top 5 – automatisch aus Nutzung abgeleitet:</p>' + s.map(function (x) {
      return '<div class="vs-sug"><div class="k">' + esc(x.kind) + '</div>' + esc(x.text) + '</div>';
    }).join('');
  }

  function viewDiag() {
    var devs = (window.VSAPP ? window.VSAPP.getDevices() : []);
    var pats = (window.VSAPP ? window.VSAPP.getPatients() : []);
    var head = '<div style="margin-bottom:10px"><b>Geräte:</b> ' + devs.length + ' · <b>Patienten:</b> ' + pats.length + '</div>' +
      '<div class="vs-devices" style="padding:0 0 10px">' + devs.map(function (d) {
        return '<div class="vs-dev"><span class="st ' + d.status + '"></span>' + esc(d.model) + ' <small>' + d.role + '/' + d.status + '</small></div>';
      }).join('') + '</div>';
    var ev = VS.feedback.diagRecent(150);
    // Fehler/Warnungen je Quelle (Gerät/Adapter) zusammenfassen (§14 Kategorie 4).
    var counts = {};
    ev.forEach(function (e) { var s = e.source || '?'; (counts[s] = counts[s] || { e: 0, w: 0 }); if (e.level === 'error') counts[s].e++; else if (e.level === 'warn') counts[s].w++; });
    var srcKeys = Object.keys(counts).filter(function (s) { return counts[s].e || counts[s].w; }).sort(function (a, b) { return (counts[b].e + counts[b].w) - (counts[a].e + counts[a].w); });
    var summary = srcKeys.length ? '<div style="margin-bottom:10px;font-size:12px"><b>Fehler/Warnungen je Quelle:</b> ' + srcKeys.map(function (s) {
      return '<span style="display:inline-block;margin:3px 5px 0 0;padding:2px 8px;border-radius:6px;border:1px solid ' + (counts[s].e ? '#ff5470' : 'rgba(120,150,180,.3)') + ';color:' + (counts[s].e ? '#ff8ba0' : '#c8d6e5') + '">' + esc(s) + ': ' + counts[s].e + '×Fehler · ' + counts[s].w + '×Warn</span>';
    }).join('') + '</div>' : '';
    var log = ev.length ? ev.map(function (e) {
      var cls = e.level === 'error' ? 'er' : e.level === 'warn' ? 'wa' : 'in';
      return '<div class="' + cls + '">' + new Date(e.ts).toLocaleTimeString() + ' [' + e.level + '] ' + esc(e.source) + ': ' + esc(e.msg) + '</div>';
    }).join('') : '<div class="in">keine Ereignisse</div>';
    return head + summary + '<div class="vs-log">' + log + '</div>';
  }

  function viewFeedback() {
    var d = VS.feedback.all();
    var help = d.events.filter(function (e) { return e.verdict === 'helpful'; }).length;
    var over = d.events.filter(function (e) { return e.verdict === 'override'; }).length;
    var byT = {};
    d.events.filter(function (e) { return e.verdict === 'override'; }).forEach(function (e) { var k = e.title || e.incident || '?'; byT[k] = (byT[k] || 0) + 1; });
    var rows = Object.keys(byT).sort(function (a, b) { return byT[b] - byT[a]; }).map(function (k) { return '<div class="vs-sug"><b>' + byT[k] + '×</b> überstimmt: ' + esc(k) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine überstimmten Empfehlungen</p>';
    return '<p><b>' + help + '</b> hilfreich · <b>' + over + '</b> nicht passend · <b>' + d.manual.length + '</b> Notizen · <b>' + d.missing.length + '</b> fehlende Inhalte</p>' +
      '<h3 style="margin:10px 0 6px">Häufig überstimmt</h3>' + rows;
  }

  function viewContent() {
    var d = VS.feedback.all();
    var miss = d.missing.slice(-20).reverse().map(function (m) { return '<div class="vs-sug"><span class="k">' + esc(m.kind) + '</span>' + esc(m.text) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine</p>';
    var notes = d.manual.slice(-20).reverse().map(function (m) { return '<div class="vs-sug">' + esc(m.text) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine</p>';
    return '<h3 style="margin:0 0 6px">Fehlender Inhalt melden</h3>' +
      '<div style="display:flex;gap:6px;margin-bottom:6px"><select id="missKind" class="vs-btn"><option value="medikament">Medikament</option><option value="szenario">Szenario</option><option value="rhythmus">Rhythmus</option><option value="sonstiges">Sonstiges</option></select>' +
      '<input id="missText" class="vs-ta" style="min-height:0;height:36px;flex:1" placeholder="was fehlt?"><button class="vs-btn" id="missAdd">+</button></div>' + miss +
      '<h3 style="margin:14px 0 6px">Manuelles Team-Feedback</h3>' +
      '<textarea id="noteText" class="vs-ta" placeholder="Was war unklar / was fehlt / Grenzfall?"></textarea><div style="margin-top:6px"><button class="vs-btn" id="noteAdd">Notiz speichern</button></div>' + '<div style="margin-top:10px">' + notes + '</div>';
  }
  function wireContent(b) {
    b.querySelector('#missAdd').onclick = function () { var t = b.querySelector('#missText'); if (t.value.trim()) { VS.feedback.missing({ kind: b.querySelector('#missKind').value, text: t.value.trim() }); t.value = ''; renderBody(); } };
    b.querySelector('#noteAdd').onclick = function () { var t = b.querySelector('#noteText'); if (t.value.trim()) { VS.feedback.manual(t.value.trim()); t.value = ''; renderBody(); } };
  }

  function exportReport() {
    var text = VS.feedback.exportReport();
    var blob = new Blob([text], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'vetstation-bericht-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
})();
