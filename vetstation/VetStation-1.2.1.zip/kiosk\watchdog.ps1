<#
  watchdog.ps1 - Selbstheilung (Par.8): prueft periodisch, ob Bridge+UI erreichbar sind und der
  Kiosk-Browser laeuft; startet bei Absturz automatisch neu. Beendet ausschliesslich die eigene,
  nicht mehr antwortende Bridge - niemals ein fremdes Programm.

  Aufruf:  powershell -ExecutionPolicy Bypass -File kiosk\watchdog.ps1 -Port 8770

  ------------------------------------------------------------------------------------------
  WAS AM 01.08.2026 SCHIEFGING - und warum diese Datei seitdem anders aussieht:

  Die Bridge lief seit 06:45 Uhr. Irgendwann danach blieb ihre Ereignisschleife stehen: der
  Prozess lebte weiter (0 % CPU, alle Threads wartend), hielt Port 8770 und alle sieben
  Geraeteports, nahm TCP-Verbindungen sogar an - beantwortete aber kein einziges Byte. Selbst
  geschlossene Verbindungen raeumte er nicht mehr ab (CLOSE_WAIT blieb stehen).

  Der Watchdog bemerkte das um 14:37 Uhr korrekt und tat das Falsche: er startete einen ZWEITEN
  Prozess. Der fand jeden Port belegt ("Port 3502 ist von einem anderen Programm belegt"),
  konnte nichts binden und blieb selbst als Leiche stehen. Danach lief der Watchdog in den
  'throw "Bridge nicht erreichbar nach 16 s."' aus launch-kiosk.ps1 - und weil dort
  $ErrorActionPreference = 'Stop' gilt und hier kein try/catch stand, endete die Schleife.
  Ab da ueberwachte niemand mehr irgendetwas. Zustand bei der Entdeckung: ueber zwei Stunden
  tote Station, ohne dass ein einziger Hinweis irgendwo sichtbar gewesen waere.

  Drei Fehler, drei Gegenmassnahmen:
    1. Ein EINGEFRORENER Prozess wurde nie beendet.  -> wird jetzt erkannt und beendet.
    2. Der Watchdog konnte selbst sterben.           -> jeder Durchlauf liegt in try/catch.
    3. Es gab keine Spur.                            -> data\watchdog.log haelt jeden Eingriff fest.

  ABSICHTLICH NICHT EINGEBAUT: eine Sperre "nicht waehrend einer Narkose neu starten". Solange
  die Bridge steht, wird ohnehin nichts aufgezeichnet und nichts angezeigt - die Daten sind in
  diesem Moment bereits verloren. Gerade waehrend einer Narkose ist der schnelle Neustart die
  richtige Antwort, nicht das Abwarten.

  URSACHE DES EINFRIERENS: nicht ermittelt. Das ist ehrlich so festzuhalten - es gab keine
  Fehlerzeile, keinen Absturz und keinen Standby (das System lief seit 22:08 Uhr durch). Diese
  Heilung wirkt deshalb bewusst UNABHAENGIG von der Ursache: sie stellt den Dienst wieder her,
  gleich woran er gescheitert ist, und hinterlaesst im Protokoll, dass es passiert ist. Haeufen
  sich die Eintraege, ist das der Anhaltspunkt fuer die Ursachensuche.
  ------------------------------------------------------------------------------------------
#>
param(
  [int]$Port = 8770,
  [int]$IntervalSec = 10,
  # Erst nach so vielen erfolglosen Pruefungen HINTEREINANDER wird eingegriffen. Bei 3 und 10 s
  # Takt sind das rund 30 s Stille. Ein einzelner Aussetzer beendet nichts.
  [int]$FehlerBisEingriff = 3
)

# Der Watchdog darf an keiner Stelle abbrechen. 'Continue' ist hier kein Schlamperei-Schalter,
# sondern die Bedingung dafuer, dass er ueberhaupt weiterlaeuft.
$ErrorActionPreference = 'Continue'

$Root = Split-Path $PSScriptRoot -Parent
$Url = "http://127.0.0.1:$Port"
$LogDatei = Join-Path $Root 'data\watchdog.log'

. (Join-Path $PSScriptRoot 'watchdog-entscheidung.ps1')

function Schreibe {
  param([string]$Text)
  $zeile = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Text"
  try { Write-Host $zeile } catch {}
  try {
    $ordner = Split-Path $LogDatei -Parent
    if (-not (Test-Path $ordner)) { New-Item -ItemType Directory -Force -Path $ordner | Out-Null }
    # Nicht unbegrenzt wachsen lassen: ueber 512 KB die juengsten 500 Zeilen behalten.
    if ((Test-Path $LogDatei) -and ((Get-Item $LogDatei).Length -gt 524288)) {
      $rest = Get-Content $LogDatei -Tail 500
      Set-Content -Path $LogDatei -Value $rest -Encoding utf8
    }
    Add-Content -Path $LogDatei -Value $zeile -Encoding utf8
  } catch {}
}

# 4 s statt 2 s: eine beschaeftigte Station (Suchlauf, grosser Datenstrom) darf nicht allein
# deshalb fuer tot erklaert werden, weil sie einen Moment braucht.
function Test-BridgeUp {
  try { return (Invoke-WebRequest "$Url/healthz" -UseBasicParsing -TimeoutSec 4).StatusCode -eq 200 }
  catch { return $false }
}
function Test-EdgeUp { return [bool](Get-Process msedge -ErrorAction SilentlyContinue) }

# Wer horcht auf dem Port? Liefert die Prozesskennung oder $null.
function Get-PortInhaber {
  param([int]$P)
  try {
    $v = Get-NetTCPConnection -LocalPort $P -State Listen -ErrorAction Stop | Select-Object -First 1
    if ($v) { return [int]$v.OwningProcess }
  } catch {}
  return $null
}

<#
  Gehoert dieser Prozess zu UNS? Hier wird bewusst streng geprueft, denn die Antwort entscheidet
  darueber, ob gleich Stop-Process aufgerufen wird.

  Bedingung 1: Der Prozess heisst 'node'. Alles andere ist nie unsere Bridge.
  Bedingung 2: Der Programmpfad liegt im Stationsordner - WENN er lesbar ist.
               Er ist es nicht immer: stammt der Prozess aus der geplanten Aufgabe, verweigert
               Windows die Auskunft (am 01.08.2026 genau so gemessen: .Path war leer).
  Bedingung 3: Ist der Pfad nicht lesbar, muss der Prozess auf der LOOPBACK-Adresse dieses Ports
               horchen. Die Bridge bindet ausdruecklich 127.0.0.1:8770. Ein fremdes Programm,
               das zugleich 'node' heisst und auf genau dieser lokalen Adresse sitzt, gibt es
               auf einem Stations-PC nicht.
#>
function Test-IstUnsereBridge {
  param([int]$Kennung, [int]$P)
  $proz = Get-Process -Id $Kennung -ErrorAction SilentlyContinue
  if (-not $proz) { return $false }
  if ($proz.ProcessName -ne 'node') { return $false }
  $pfad = $null
  try { $pfad = $proz.Path } catch {}
  if ($pfad) { return ($pfad -like (Join-Path $Root '*')) }
  try {
    $v = Get-NetTCPConnection -LocalPort $P -State Listen -ErrorAction Stop |
         Where-Object { $_.OwningProcess -eq $Kennung }
    foreach ($e in $v) { if ($e.LocalAddress -eq '127.0.0.1' -or $e.LocalAddress -eq '::1') { return $true } }
  } catch {}
  return $false
}

# Beendet die eingefrorene Bridge und wartet, bis der Port wirklich frei ist. Ohne dieses Warten
# liefe der naechste Start in dasselbe EADDRINUSE.
function Stop-EingefroreneBridge {
  param([int]$Kennung)
  try { Stop-Process -Id $Kennung -Force -Confirm:$false -ErrorAction Stop }
  catch { Schreibe "Konnte Prozess $Kennung nicht beenden: $($_.Exception.Message)"; return $false }
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 250
    if ($null -eq (Get-PortInhaber $Port)) { Schreibe "Prozess $Kennung beendet, Port $Port ist frei."; return $true }
  }
  Schreibe "Prozess $Kennung beendet, aber Port $Port ist nach 5 s noch belegt."
  return $false
}

Schreibe "Watchdog aktiv (Port $Port, Takt ${IntervalSec}s, Eingriff nach $FehlerBisEingriff erfolglosen Pruefungen)."

$fehlerFolge = 0
while ($true) {
  # Ein Durchlauf darf niemals die Schleife beenden - das war Fehler 2.
  try {
    if (Test-BridgeUp) {
      if ($fehlerFolge -gt 0) { Schreibe "Station antwortet wieder (nach $fehlerFolge erfolglosen Pruefungen)." }
      $fehlerFolge = 0
    } else {
      $fehlerFolge++
      $inhaber = Get-PortInhaber $Port
      $unsere = $false
      if ($null -ne $inhaber) { $unsere = Test-IstUnsereBridge $inhaber $Port }

      $was = Get-WatchdogEntscheidung -Erreichbar $false -FehlerFolge $fehlerFolge `
               -Schwelle $FehlerBisEingriff -PortInhaber $inhaber -InhaberIstUnsere $unsere
      Schreibe (Get-WatchdogBegruendung -Entscheidung $was -PortInhaber $inhaber -FehlerFolge $fehlerFolge)

      if ($was -eq 'beenden-und-starten') { [void](Stop-EingefroreneBridge $inhaber) }

      if ($was -eq 'starten' -or $was -eq 'beenden-und-starten') {
        try {
          & (Join-Path $PSScriptRoot 'launch-kiosk.ps1') -Port $Port -NoKiosk
          Schreibe 'Neustart der Station angestossen.'
        } catch {
          # launch-kiosk.ps1 wirft, wenn die Bridge in 16 s nicht hochkommt. Das darf gemeldet
          # werden - beenden darf es den Watchdog nicht.
          Schreibe "Neustart fehlgeschlagen: $($_.Exception.Message) - wird beim naechsten Takt erneut versucht."
        }
        $fehlerFolge = 0
      }
    }

    if (-not (Test-EdgeUp)) {
      Schreibe 'Kiosk-Browser laeuft nicht -> wird gestartet.'
      try { & (Join-Path $PSScriptRoot 'launch-kiosk.ps1') -Port $Port | Out-Null }
      catch { Schreibe "Kiosk-Start fehlgeschlagen: $($_.Exception.Message)" }
    }
  } catch {
    Schreibe "Unerwarteter Fehler im Watchdog (wird uebergangen): $($_.Exception.Message)"
  }
  Start-Sleep -Seconds $IntervalSec
}
