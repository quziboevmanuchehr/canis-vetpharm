'use strict';
/*
 * serve.js — Minimaler statischer Server NUR fuer die UI (Entwicklungs-/Fallback-Zweck).
 * Im Normalbetrieb liefert die Bridge (bridge/src/server.js) die UI selbst aus (ein Port).
 * Aufruf:  node serve.js  [--port 8080]
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const UI_DIR = path.join(__dirname, 'ui');
const PORT = Number(process.argv.includes('--port') ? process.argv[process.argv.indexOf('--port') + 1] : (process.env.PORT || 8080));
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };

http.createServer((req, res) => {
  let rel = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(UI_DIR, rel));
  if (!file.startsWith(UI_DIR)) { res.writeHead(403); return res.end('403'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('404'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  });
}).listen(PORT, '127.0.0.1', () => console.log('VetStation UI (statisch): http://127.0.0.1:' + PORT + '  — Hinweis: ohne Bridge kein Live-Datenstrom.'));
