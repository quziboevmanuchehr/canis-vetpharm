<#
  stop-kiosk.ps1 — Kiosk sauber beenden (Wartung). Stoppt den Kiosk-Edge und die Bridge.
  Hinweis: Der PIN-Schutz liegt IN der App (Admin-Bereich). Dieses Skript ist fuer die
  Wartung am dedizierten PC gedacht (z. B. nach Anmeldung als Admin).
#>
param([int]$Port = 8770)

# Kiosk-Edge (nur die VetStation-Instanz mit eigenem Profil) beenden
Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -match 'VetStation\\EdgeProfile' } |
  ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }

# Bridge (Node auf dem Port) beenden
$c = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($c) { $c.OwningProcess | Select-Object -Unique | ForEach-Object { try { Stop-Process -Id $_ -Force } catch {} } }
Write-Host "VetStation gestoppt."
