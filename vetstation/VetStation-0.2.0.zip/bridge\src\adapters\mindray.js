'use strict';
/*
 * mindray.js — Adapter fuer Mindray-Geraete (uMEC12 Vet, Veta 5 Plus) ueber CentralStation/PDS.
 *
 * STATUS: STUB / GERUEST. Das genaue Netzprotokoll (CentralStation/CMS "PDS"/HL7/proprietaer)
 * ist geraetegebunden und muss von Eickemeyer bzw. Mindray Animal Care bezogen werden
 * (siehe docs/DEVICE-ADAPTERS.md und mindray-live-data-request-email.md).
 * Bis dahin verbindet dieser Adapter NICHT; Simulator/Playback liefern Testdaten.
 *
 * Zielprinzip (aus lan-setup-live-daten.md): die Geraete verbinden sich zum PC (PC-IP =
 * "Serveradresse"/CentralStation-Port). Dieser Adapter oeffnet also i.d.R. einen TCP-Listener
 * und parst den Mindray-Stream -> ingest-Frames. STRIKT READ-ONLY.
 *
 * Konfig: { id, model:'uMEC12 Vet'|'Veta 5 Plus', role, listenPort, sn }
 */
const net = require('net');
const { Adapter } = require('./base');

class MindrayAdapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.server = null;
  }

  describe() { return { id: this.id, model: this.cfg.model || 'Mindray', role: this.cfg.role || 'monitor' }; }

  async connect() {
    const port = this.cfg.listenPort;
    if (!port) {
      this.ctx.log && this.ctx.log.warn('mindray', 'Adapter "' + this.id + '" ohne listenPort -> deaktiviert (Protokoll ausstehend).');
      return;
    }
    // Gerüst: TCP-Listener, an den das Mindray-Geraet (CentralStation-Client) sendet.
    this.server = net.createServer((socket) => {
      this.ctx.log && this.ctx.log.info('mindray', 'Verbindung von ' + socket.remoteAddress + ' (' + this.cfg.model + ')');
      socket.on('data', (buf) => this._onData(buf, socket));
      socket.on('error', (e) => this.ctx.log && this.ctx.log.warn('mindray', 'Socketfehler: ' + e.message));
    });
    this.server.on('error', (e) => this.ctx.log && this.ctx.log.error('mindray', 'Listener-Fehler: ' + e.message));
    this.server.listen(port, () => {
      this.connected = true;
      this.ctx.log && this.ctx.log.info('mindray', this.cfg.model + ' Listener auf Port ' + port + ' (wartet auf CentralStation-Stream).');
    });
  }

  // TODO(Protokoll): Mindray-Frames dekodieren -> this.emit({... ingest ...}).
  // Erwartete Felder je nach Modell: HR, SpO2, NIBP(sys/dia/map), Temp, EtCO2/FiCO2/Paw/AF (Veta),
  // EKG-Rohdaten (fuer Rhythmusklassifikation), Alarme, Patienten-ID/Gewicht/Tierart.
  _onData(buf, socket) {
    // Platzhalter: hier den Mindray-Parser einsetzen (Protokoll von Eickemeyer/Mindray).
    this.ctx.log && this.ctx.log.warn('mindray', 'Datenframe empfangen (' + buf.length + ' B), aber Parser fehlt noch (Protokoll ausstehend).');
  }

  dispose() { if (this.server) { try { this.server.close(); } catch (_) {} } this.server = null; this.connected = false; }
}

module.exports = { MindrayAdapter };
