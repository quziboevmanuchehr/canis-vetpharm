# Roadmap

## v1 (fertig, lauffähig & verifiziert)
- ✅ Bridge (Node, read-only): abhängigkeitsfreier WebSocket, Auto-Discovery, Registry, Patienten-Matching.
- ✅ Normalisiertes ingest-Modell (§5) + Simulator (8 Tierarten, 13 Zwischenfall-Szenarien) + Playback-Adapter.
- ✅ Wiederverwendete Klinik-Engine: Brain (R1–R6 + Einzelwert-Scan), Dosis (mg/kg→mL), Geräte-Soll.
- ✅ Kiosk-UI: Live-Monitorbild, große Vitalzahlen, Brain-Analyse, Injektion mL, Split-View, Alarme.
- ✅ Admin-/Selbstdiagnose-Bereich (PIN) mit Feedback, Diagnose-Log, Top-Vorschlägen, Export (§14).
- ✅ Kiosk-Start (Edge-WebView2), Watchdog, Autostart, Assigned-Access-/Shell-Launcher-Anleitung (§8).
- ✅ Klinische Daten aktualisieren sich zur Laufzeit vom Live-canis-vetpharm (+ lokaler Fallback).
- ✅ Klinik-Selbsttest 17/17, Live-Browser-Verifikation.

## v2 (nächste Schritte)
1. **Echte Geräte-Adapter** (blockiert auf Protokoll von Eickemeyer/Mindray):
   Mindray uMEC12 Vet / Veta 5 Plus (CentralStation/PDS) und Eickemeyer LifeVet 10C.
   Gerüst + Interface stehen (`bridge/src/adapters/`), nur der Parser in `_onData()` fehlt.
   → **Aktion:** Protokoll anfragen (info@eickemeyer.de, nl.info@mindrayanimal.com), dann Parser + Playback-Gegenprobe.
2. **EKG-Rhythmus-Klassifikation aus Rohsignal:** echte Monitore liefern HR + Kurve, nicht immer ein
   Rhythmus-Label. Aus den EKG-Rohdaten `ekgRhythm` ableiten (AV-Block, VES/VT, VF, Asystolie), damit
   die Brain-Regeln R1–R3 auch ohne Geräte-Label greifen.
3. **Manuelles Koppeln — UI:** Bridge unterstützt `pair`/`unpair` bereits; eine Drag/Klick-Oberfläche
   („Monitor X ↔ Veta Y ↔ Patient") ergänzen (Fallback, wenn IDs fehlen, §6.3).
4. **Kombinations-Vorwarnung (Kombi→Zwischenfall-Matrix):** z. B. „bei α2-Agonist Bradykardie/AV-Block
   erwarten — Atropin nicht reflexartig" (aus dem Prüfbericht), im Brain als Kontext-Hinweis.
5. **Nachdosierung / CRI / TIVA live:** Einleitungsboli + Erhaltung (Propofol/Alfaxalon-TIVA, CRI) mit
   Verlaufslogik; Max-Gesamtdosis-Warnung (Lokalanästhetika) an Live-Werte koppeln.
6. **Tauri-MSI + signiertes Auto-Update** (`tauri-shell/`): benötigt Rust-Toolchain; dann 1-Klick-Appliance
   mit eingebautem Updater und Node als Sidecar.

## v3 (weiter)
- Fall-Logging (lokal, opt-in) + Wiedergabe.
- Rasse/Genetik-Warnungen (MDR1 etc.) in die Live-Empfehlung integrieren (`breed-genetics.js` liegt bereits vor).
- Trend-/Verlaufskurven je Vitalwert; NIBP-Intervalltracking.
- Weitere Geräte-Adapter (weitere Monitore/Narkosegeräte) über dasselbe Interface.
- Feedback-gestützte Logik-Verbesserung (die Lernschleife schlägt nur vor — Änderungen bleiben ein
  geprüfter Schritt gegen CliniPharm/Plumb's/BSAVA, §14).

## Bewusst offen gelassen / Grenzen
- **Read-only bleibt Read-only** — keine geschlossene Regelschleife zum Gerät (Sicherheit/Recht §10).
- Keine Cloud-Pflicht; alle Daten lokal (DSGVO).
- Kein zugelassener Monitor-Ersatz — Entscheidungs-/Trainingshilfe.
