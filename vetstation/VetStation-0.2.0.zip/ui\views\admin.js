/*
 * admin.js — PIN-geschuetzter Admin-/Selbstdiagnose-Bereich (§14).
 * Zeigt priorisierte Verbesserungsvorschlaege, Verbindungs-/Fehler-Log, Feedback-Statistik,
 * Sammlung fehlender Inhalte + manuelles Team-Feedback und Ein-Klick-Export (anonymisiert).
 * Standard-PIN "1234" (localStorage 'vetstation.pin', im Betrieb aendern).
 */
(function () {
  'use strict';
  var VS = window.VS;
  var host = document.getElementById('admin');
  var PIN_KEY = 'vetstation.pin';
  var authed = false, tab = 'sug';

  function pin() { return localStorage.getItem(PIN_KEY) || '1234'; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  window.VSADMIN = {
    open: function () { host.classList.add('open'); render(); },
    close: function () { host.classList.remove('open'); },
    onDiag: function () { if (authed && (tab === 'diag')) renderBody(); },
  };

  function render() { authed ? renderPanel() : renderPin(); }

  function renderPin() {
    host.innerHTML = '<div class="vs-admin-box"><div class="vs-admin-h"><h2>🔒 Admin</h2><div class="vs-spacer" style="flex:1"></div>' +
      '<button class="vs-btn" data-x>✕</button></div>' +
      '<div class="vs-pin"><div style="color:var(--muted)">PIN eingeben (Standard 1234)</div>' +
      '<input id="pinIn" type="password" inputmode="numeric" maxlength="8" autofocus>' +
      '<button class="vs-btn" data-ok>Öffnen</button><div id="pinErr" style="color:#ff8ba0;font-size:12px"></div></div></div>';
    host.querySelector('[data-x]').onclick = window.VSADMIN.close;
    var inp = host.querySelector('#pinIn');
    var go = function () { if (inp.value === pin()) { authed = true; renderPanel(); } else { host.querySelector('#pinErr').textContent = 'Falsche PIN.'; inp.value = ''; } };
    host.querySelector('[data-ok]').onclick = go;
    inp.onkeydown = function (e) { if (e.key === 'Enter') go(); };
    inp.focus();
  }

  var TABS = [['sug', '💡 Verbesserungen'], ['diag', '🔌 Verbindung/Fehler'], ['fern', '📡 Fern-Live'], ['update', '🔄 Aktualisieren'], ['fb', '📊 Feedback'], ['content', '📝 Inhalte/Notiz']];

  function renderPanel() {
    host.innerHTML = '<div class="vs-admin-box">' +
      '<div class="vs-admin-h"><h2>⚙ Admin · Selbstdiagnose</h2><div style="flex:1"></div>' +
      '<button class="vs-btn" data-exp>⬇ Bericht exportieren</button>' +
      '<button class="vs-btn warn" data-clr>Zurücksetzen</button>' +
      '<button class="vs-btn" data-x>✕</button></div>' +
      '<div class="vs-admin-tabs">' + TABS.map(function (t) { return '<button class="vs-atab' + (t[0] === tab ? ' active' : '') + '" data-t="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</div>' +
      '<div class="vs-admin-body" id="adminBody"></div></div>';
    host.querySelector('[data-x]').onclick = window.VSADMIN.close;
    host.querySelector('[data-exp]').onclick = exportReport;
    host.querySelector('[data-clr]').onclick = function () { if (confirm('Alle lokalen Feedback-/Diagnosedaten löschen?')) { VS.feedback.clear(); renderBody(); } };
    host.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { tab = b.getAttribute('data-t'); renderPanel(); }; });
    renderBody();
  }

  function renderBody() {
    var b = host.querySelector('#adminBody'); if (!b) return;
    if (tab === 'sug') b.innerHTML = viewSuggestions();
    else if (tab === 'diag') b.innerHTML = viewDiag();
    else if (tab === 'fern') { b.innerHTML = '<p style="color:var(--muted)">Lade Fern-Live-Status…</p>'; loadFern(b); }
    else if (tab === 'update') { b.innerHTML = '<p style="color:var(--muted)">Prüfe auf Updates…</p>'; loadUpdate(b); }
    else if (tab === 'fb') b.innerHTML = viewFeedback();
    else if (tab === 'content') { b.innerHTML = viewContent(); wireContent(b); }
  }

  // ---- Fern-Live (Werte über Internet in die Web-App) ----
  function loadFern(b) {
    fetch('/api/cloud').then(function (r) { return r.json(); }).then(function (c) { b.innerHTML = viewFern(c); wireFern(b, c); })
      .catch(function (e) { b.innerHTML = '<p style="color:#ff8ba0">Status nicht abrufbar: ' + esc(e.message) + '</p>'; });
  }
  function viewFern(c) {
    if (!c || !c.enabled) {
      return '<div class="vs-sug"><div class="k">inaktiv</div>Fern-Live ist ausgeschaltet. So aktivieren: in <code>bridge/config/devices.json</code> den <code>cloud</code>-Block auf <b>enabled:true</b> setzen und <code>apiKey</code>, <code>dbUrl</code> &amp; einen unratbaren <code>code</code> eintragen.</div>' +
        '<p style="color:var(--muted);margin-top:10px">Schritt-für-Schritt (Firebase einrichten): <b>docs/FERN-LIVE.md</b>. Danach VetStation neu starten.</p>';
    }
    var stColor = c.authed ? '#35d69a' : (c.started ? '#ffc23c' : '#ff8ba0');
    var stTxt = c.authed ? 'aktiv &amp; angemeldet' : (c.started ? 'gestartet – verbinde…' : 'gestartet');
    var last = c.lastPublish ? new Date(c.lastPublish).toLocaleTimeString() : '–';
    return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><span style="width:11px;height:11px;border-radius:50%;background:' + stColor + ';box-shadow:0 0 8px ' + stColor + '"></span><b>Fern-Live ' + stTxt + '</b></div>' +
      '<div style="color:var(--muted);font-size:12.5px;margin-bottom:12px">Station <b>' + esc(c.station || '') + '</b> · Code <b>' + esc(c.code || '') + '</b> · zuletzt gesendet ' + last + (c.lastError ? ' · <span style="color:#ff8ba0">Fehler: ' + esc(c.lastError) + '</span>' : '') + '</div>' +
      '<div style="color:var(--muted);font-size:12.5px;margin-bottom:4px">Zuschauer-Link (von zu Hause öffnen):</div>' +
      '<div style="display:flex;gap:6px;align-items:stretch"><input id="fernUrl" class="vs-ta" readonly style="min-height:0;height:40px;flex:1;font-size:12px" value="' + esc(c.url || '') + '"><button class="vs-btn" id="fernCopy">⧉ Kopieren</button></div>' +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:10px">Es werden nur Vitalwerte, Tierart/Gewicht und der Befund übertragen – keine Personendaten. Zugriff nur mit diesem Link/Code. READ-ONLY: Fern-Zuschauer können die Geräte nicht steuern.</p>';
  }
  // ---- In-App-Update (§13) ----
  function loadUpdate(b) {
    fetch('/api/update/check').then(function (r) { return r.json(); }).then(function (c) { b.innerHTML = viewUpdate(c); wireUpdate(b, c); })
      .catch(function (e) { b.innerHTML = '<p style="color:#ff8ba0">Update-Prüfung nicht möglich: ' + esc(e.message) + '</p>'; });
  }
  function viewUpdate(c) {
    var head = '<div style="margin-bottom:10px"><b>App-Version:</b> ' + esc(c.current || '?') + ' <span style="color:var(--muted)">(' + esc(c.channel || 'stable') + ')</span></div>' +
      '<div class="vs-sug" style="border-color:rgba(53,214,154,.35)"><div class="k">automatisch</div>Klinische Daten (Medikamente, Dosen, Logik) aktualisieren sich <b>zur Laufzeit</b> vom Live-Server – ohne Neuinstallation.</div>';
    if (c.pending) head += '<div class="vs-sug" style="border-color:rgba(255,209,102,.5)"><div class="k">bereit</div>Update <b>' + esc(c.pending.version) + '</b> ist geladen &amp; geprüft – wird beim <b>nächsten Neustart</b> angewendet.</div>';
    var body;
    if (!c.manifestUrl) body = '<p style="color:var(--muted)">Kein App-Shell-Update-Kanal konfiguriert. (Nur Laufzeit-Datenupdate aktiv.)</p>';
    else if (!c.reachable) body = '<p style="color:var(--muted)">Update-Server nicht erreichbar: ' + esc(c.msg || 'offline') + '<br><small>Manifest: ' + esc(c.manifestUrl) + '</small></p>';
    else if (c.updateAvailable) body = '<div class="vs-sug" style="border-color:#23c7bb"><div class="k">neu</div><b>Neue Version ' + esc(c.latest) + '</b> verfügbar.' + (c.notes ? '<br>' + esc(c.notes) : '') + '</div>' +
      '<button class="vs-btn" id="updApply" style="margin-top:6px">⬇ Update laden &amp; anwenden</button> <span id="updMsg" style="margin-left:8px;font-size:12.5px;color:var(--muted)"></span>';
    else body = '<p style="color:#8fe3b8">✓ App-Shell ist aktuell (' + esc(c.latest || c.current) + ').</p>';
    return head + '<h3 style="margin:12px 0 6px">App-Programm (Bridge/Adapter/Oberfläche)</h3>' + body +
      '<p style="color:var(--muted);font-size:11.5px;margin-top:12px">Updates sind ' + (c.isGit ? 'Git-basiert (git pull)' : 'Zip-basiert (Download + sha256-Prüfung, Anwendung beim Neustart)') + '. Es werden nie automatisch klinische Dosierungen geändert – Datensatz-/Logikänderungen bleiben geprüfte Schritte.</p>';
  }
  function wireUpdate(b, c) {
    var btn = b.querySelector('#updApply'); if (!btn) return;
    btn.onclick = function () {
      var msg = b.querySelector('#updMsg'); btn.disabled = true; if (msg) msg.textContent = 'lädt & prüft…';
      fetch('/api/update/apply').then(function (r) { return r.json(); }).then(function (res) {
        if (msg) { msg.textContent = (res.ok ? '✓ ' : '✗ ') + (res.msg || ''); msg.style.color = res.ok ? '#8fe3b8' : '#ff8ba0'; }
        if (res.ok && res.restart) { btn.textContent = '↻ Station jetzt neu starten'; btn.disabled = false; btn.onclick = function () { if (confirm('Station neu starten, um das Update anzuwenden?')) location.reload(); }; }
      }).catch(function (e) { if (msg) { msg.textContent = '✗ ' + e.message; msg.style.color = '#ff8ba0'; } btn.disabled = false; });
    };
  }

  function wireFern(b, c) {
    var cp = b.querySelector('#fernCopy'); if (!cp) return;
    cp.onclick = function () {
      var inp = b.querySelector('#fernUrl'); if (!inp) return;
      inp.select();
      var done = function () { cp.textContent = '✓ kopiert'; setTimeout(function () { cp.textContent = '⧉ Kopieren'; }, 1500); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(inp.value).then(done, function () { try { document.execCommand('copy'); done(); } catch (e) {} });
      else { try { document.execCommand('copy'); done(); } catch (e) {} }
    };
  }

  function viewSuggestions() {
    var s = VS.feedback.suggestions();
    if (!s.length) return '<p style="color:var(--muted)">Noch keine Auffälligkeiten. Vorschläge entstehen aus überstimmten Empfehlungen, fehlenden Inhalten und Verbindungsfehlern.</p>';
    return '<p style="color:var(--muted)">Top 5 – automatisch aus Nutzung abgeleitet:</p>' + s.map(function (x) {
      return '<div class="vs-sug"><div class="k">' + esc(x.kind) + '</div>' + esc(x.text) + '</div>';
    }).join('');
  }

  function viewDiag() {
    var devs = (window.VSAPP ? window.VSAPP.getDevices() : []);
    var pats = (window.VSAPP ? window.VSAPP.getPatients() : []);
    var head = '<div style="margin-bottom:10px"><b>Geräte:</b> ' + devs.length + ' · <b>Patienten:</b> ' + pats.length + '</div>' +
      '<div class="vs-devices" style="padding:0 0 10px">' + devs.map(function (d) {
        return '<div class="vs-dev"><span class="st ' + d.status + '"></span>' + esc(d.model) + ' <small>' + d.role + '/' + d.status + '</small></div>';
      }).join('') + '</div>';
    var ev = VS.feedback.diagRecent(150);
    // Fehler/Warnungen je Quelle (Gerät/Adapter) zusammenfassen (§14 Kategorie 4).
    var counts = {};
    ev.forEach(function (e) { var s = e.source || '?'; (counts[s] = counts[s] || { e: 0, w: 0 }); if (e.level === 'error') counts[s].e++; else if (e.level === 'warn') counts[s].w++; });
    var srcKeys = Object.keys(counts).filter(function (s) { return counts[s].e || counts[s].w; }).sort(function (a, b) { return (counts[b].e + counts[b].w) - (counts[a].e + counts[a].w); });
    var summary = srcKeys.length ? '<div style="margin-bottom:10px;font-size:12px"><b>Fehler/Warnungen je Quelle:</b> ' + srcKeys.map(function (s) {
      return '<span style="display:inline-block;margin:3px 5px 0 0;padding:2px 8px;border-radius:6px;border:1px solid ' + (counts[s].e ? '#ff5470' : 'rgba(120,150,180,.3)') + ';color:' + (counts[s].e ? '#ff8ba0' : '#c8d6e5') + '">' + esc(s) + ': ' + counts[s].e + '×Fehler · ' + counts[s].w + '×Warn</span>';
    }).join('') + '</div>' : '';
    var log = ev.length ? ev.map(function (e) {
      var cls = e.level === 'error' ? 'er' : e.level === 'warn' ? 'wa' : 'in';
      return '<div class="' + cls + '">' + new Date(e.ts).toLocaleTimeString() + ' [' + e.level + '] ' + esc(e.source) + ': ' + esc(e.msg) + '</div>';
    }).join('') : '<div class="in">keine Ereignisse</div>';
    return head + summary + '<div class="vs-log">' + log + '</div>';
  }

  function viewFeedback() {
    var d = VS.feedback.all();
    var help = d.events.filter(function (e) { return e.verdict === 'helpful'; }).length;
    var over = d.events.filter(function (e) { return e.verdict === 'override'; }).length;
    var byT = {};
    d.events.filter(function (e) { return e.verdict === 'override'; }).forEach(function (e) { var k = e.title || e.incident || '?'; byT[k] = (byT[k] || 0) + 1; });
    var rows = Object.keys(byT).sort(function (a, b) { return byT[b] - byT[a]; }).map(function (k) { return '<div class="vs-sug"><b>' + byT[k] + '×</b> überstimmt: ' + esc(k) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine überstimmten Empfehlungen</p>';
    return '<p><b>' + help + '</b> hilfreich · <b>' + over + '</b> nicht passend · <b>' + d.manual.length + '</b> Notizen · <b>' + d.missing.length + '</b> fehlende Inhalte</p>' +
      '<h3 style="margin:10px 0 6px">Häufig überstimmt</h3>' + rows;
  }

  function viewContent() {
    var d = VS.feedback.all();
    var miss = d.missing.slice(-20).reverse().map(function (m) { return '<div class="vs-sug"><span class="k">' + esc(m.kind) + '</span>' + esc(m.text) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine</p>';
    var notes = d.manual.slice(-20).reverse().map(function (m) { return '<div class="vs-sug">' + esc(m.text) + '</div>'; }).join('') || '<p style="color:var(--muted)">keine</p>';
    return '<h3 style="margin:0 0 6px">Fehlender Inhalt melden</h3>' +
      '<div style="display:flex;gap:6px;margin-bottom:6px"><select id="missKind" class="vs-btn"><option value="medikament">Medikament</option><option value="szenario">Szenario</option><option value="rhythmus">Rhythmus</option><option value="sonstiges">Sonstiges</option></select>' +
      '<input id="missText" class="vs-ta" style="min-height:0;height:36px;flex:1" placeholder="was fehlt?"><button class="vs-btn" id="missAdd">+</button></div>' + miss +
      '<h3 style="margin:14px 0 6px">Manuelles Team-Feedback</h3>' +
      '<textarea id="noteText" class="vs-ta" placeholder="Was war unklar / was fehlt / Grenzfall?"></textarea><div style="margin-top:6px"><button class="vs-btn" id="noteAdd">Notiz speichern</button></div>' + '<div style="margin-top:10px">' + notes + '</div>';
  }
  function wireContent(b) {
    b.querySelector('#missAdd').onclick = function () { var t = b.querySelector('#missText'); if (t.value.trim()) { VS.feedback.missing({ kind: b.querySelector('#missKind').value, text: t.value.trim() }); t.value = ''; renderBody(); } };
    b.querySelector('#noteAdd').onclick = function () { var t = b.querySelector('#noteText'); if (t.value.trim()) { VS.feedback.manual(t.value.trim()); t.value = ''; renderBody(); } };
  }

  function exportReport() {
    var text = VS.feedback.exportReport();
    var blob = new Blob([text], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'vetstation-bericht-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
})();
