'use strict';
/*
 * priority-test.js — §6.4/§12: „gefährlichste Warnung nach oben". Sichert headless ab, dass die
 * Brain-Priorität mehrere Patienten korrekt ordnet (Kreislaufstillstand > Einzelabweichung > stabil).
 * Start: node tools/priority-test.js
 */
const A = require('../bridge/src/anaes').loadAnaes();
const brain = require('../ui/engine/brain');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

function pri(p) { return brain.assess(A, p, { iso: p.isoPct }).priority; }

// Drei Hunde-Patienten unterschiedlicher Dringlichkeit.
const vfib = { species: 'hund', weightKg: 20, hr: 0, spo2: 0, etco2: 8, map: 0, af: 0, ekgRhythm: 'vfib', capnoShape: 'low' };
const hypox = { species: 'hund', weightKg: 20, hr: 120, spo2: 82, etco2: 60, map: 75, af: 8, ekgRhythm: 'sinus' };
const stable = { species: 'hund', weightKg: 20, hr: 90, spo2: 98, etco2: 42, map: 90, af: 12, ekgRhythm: 'sinus' };

console.log('Prioritäts-Sortierung (gefährlichste Warnung zuerst) — Selbsttest\n');

const pV = pri(vfib), pH = pri(hypox), pS = pri(stable);
console.log('  Prioritäten: Kammerflimmern=' + pV + '  Hypoxie/Hyperkapnie=' + pH + '  stabil=' + pS + '\n');

ok('Kammerflimmern hat höchste Priorität (Kreislaufstillstand, sev5)', pV >= 10, 'pri=' + pV);
ok('stabiler Patient hat niedrigste Priorität', pS < pH && pS < pV, 'pri=' + pS);
ok('Reihenfolge VFlimmern > Hypoxie > stabil', pV > pH && pH > pS, pV + ' > ' + pH + ' > ' + pS);

// Sortiert man eine Patientenliste nach Priorität, steht der gefährlichste oben.
const list = [stable, hypox, vfib].map(function (p, i) { return { p: p, name: ['stabil', 'hypox', 'vfib'][i], pr: pri(p) }; });
list.sort(function (a, b) { return b.pr - a.pr; });
ok('Sortierung nach Priorität → gefährlichster (vfib) steht oben', list[0].name === 'vfib', list.map(function (x) { return x.name; }).join(' > '));
ok('stabiler Patient steht unten', list[list.length - 1].name === 'stabil');

// Top-Befund des gefährlichsten Falls trägt CPR-Kennung.
const topV = brain.assess(A, vfib, {}).top;
ok('Top-Befund Kammerflimmern → Kreislaufstillstand/CPR', !!topV && topV.sev === 5 && /CPR|Kammerflimmern|Kreislaufstillstand/i.test(topV.title + ' ' + topV.tag), topV && topV.title);

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
