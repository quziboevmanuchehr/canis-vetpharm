# Kiosk-Setup (Kurzüberblick)

Die vollständige Anleitung steht in **[../kiosk/assigned-access.md](../kiosk/assigned-access.md)**.

## Sofort lauffähig (heute, ohne Rust)
```powershell
powershell -ExecutionPolicy Bypass -File kiosk\launch-kiosk.ps1        # Bridge + Edge-Vollbild-Kiosk
powershell -ExecutionPolicy Bypass -File kiosk\install-autostart.ps1   # Autostart beim Anmelden + Watchdog
```
- Nutzt die bereits installierte **Edge/WebView2-Runtime** (kein Extra-Install).
- **Watchdog** (`kiosk/watchdog.ps1`) startet Bridge/Kiosk bei Absturz automatisch neu (§8).
- **Autologin** + **Assigned Access** (Weg A) oder **Shell Launcher** (Weg B) → siehe assigned-access.md.
- **Beenden/Wartung:** Admin-PIN in der App (Standard `1234`); Kiosk-Wartung über separates Admin-Windows-Konto + `kiosk\stop-kiosk.ps1`.

## Produktions-Packaging (später, mit Rust)
**Tauri-MSI + signiertes Auto-Update** → **[../tauri-shell/README.md](../tauri-shell/README.md)**.

## Windows 10 & 11
Beide unterstützt; WebView2 ist Evergreen (identisches Verhalten, auch künftige Versionen). Layout
responsiv/DPI-fähig, Maus **und** Touch.
