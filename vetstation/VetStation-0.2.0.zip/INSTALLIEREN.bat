@echo off
REM VetStation installieren (Autostart-Kiosk). Einfach DOPPELKLICKEN ??? der Installer holt sich
REM die Adminrechte selbst (UAC-Abfrage bestaetigen). Laeuft auf Windows 10 UND Windows 11.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\Install-VetStation.ps1"
