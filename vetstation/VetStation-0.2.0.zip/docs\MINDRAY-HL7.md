# Mindray/Eickemeyer-Geräte anbinden — ehrlicher Stand & Vorgehen

Ergebnis einer gründlichen Recherche in den **Original-Handbüchern** (uMEC Operator's/Service Manual,
Veta 5 Operator's Manual, LifeVet 10C Manual) und Mindray-Produktdoku. Kurz und ehrlich vorweg:

> **Keines der Geräte hat einen öffentlich dokumentierten, offenen (HL7-)Datenausgang am Gerät.**
> Mindray-Geräte reden ihr **proprietäres „MD2"-Protokoll** mit der **BeneVision CMS Vet**
> (kostenpflichtige PC-Zentrale) bzw. einem **eGateway** — und erst der eGateway erzeugt HL7.

Das relativiert das „einfach Kabel dran und lesen" des Händlers: das **Kabel ist nötig, reicht aber
nicht** — es kommt darauf an, **was** das Gerät über das Kabel sendet (offenes HL7 vs. proprietäres MD2).

## ⭐ Bester Weg: der LifeVet 10C (hat einen DOKUMENTIERTEN HL7-Menüpunkt)
Der **LifeVet 10C** ist ein modularer **Mindray-Monitor** (BeneView-/ePM-/BeneVision-Klasse, System-SW
09.02). Diese Klasse hat HL7 **eingebaut** (kein eGateway für Numerik nötig). Dokumentierter Menüpfad:

`Hauptmenü → Wartung → Benutzer-Wartung` — **Passwort `888888`** → `Netzwerk` → **`EMR-Kommunikation`**
→ **Server-IP = PC-IP** (`192.168.23.10`), **Protokoll = HL7**, **„Real Data Send" = EIN**, **Port = 4601**.

VetStation braucht **nur die Zahlen** (Kurven zeichnet es selbst) — perfekt, denn Numerik ist bei dieser
Monitor-Klasse der zuverlässige Teil. **→ Zuerst den LifeVet so verbinden; das ist der beste Kandidat.**

**BeneLink-Bonus:** Der LifeVet kann über sein **BeneLink**-Modul externe Narkose-/Beatmungsgeräte
(Dräger, Hamilton, GE …) **einbinden** — deren Daten erscheinen am Monitor und gehen dann per HL7 **mit
raus**. So könnte ein Narkosegerät (über BeneLink + ID-Adapter + passendes Plugin) EtCO₂/Beatmung
beisteuern. (Ob es ein Plugin für den Veta gibt, mit Eickemeyer klären.)

## Zweiter Weg: der uMEC12 Vet — testen mit dem Assistenten
Beim **uMEC12 Vet** zeigt das öffentliche Handbuch **keinen** HL7-Menüpunkt (proprietäres MD2). Er *könnte*
per HL7/Port 4601 senden (VSCapture-Beleg) — das zeigt der **Verbindungs-Assistent** am echten Gerät
(lauscht auf 4601/5000/24105/2575, erkennt HL7 automatisch, protokolliert Unbekanntes, ARP-Scan).

### Schritt-für-Schritt-Test (am echten Gerät)
1. **LAN** verkabeln (Switch, PC + Geräte, IPs — siehe [LAN-SETUP.md](LAN-SETUP.md)). PC z. B. `192.168.23.10`.
2. **VetStation starten** (der Verbindungs-Assistent läuft standardmäßig).
3. **Am uMEC12 Vet** (Touch): `Hauptmenü → Wartung/Maintenance → Benutzer-Wartung` — **Passwort `888888`**
   (Werks-/Factory-Wartung: `332888`, Demo: `2088`) → `Netzwerk-Setup` →
   - **`Gateway-Comm-Setup`**: `IP-Adresse` = **PC-IP** (`192.168.23.10`), `Port` = **`4601`**, ggf. `ADT Query` EIN.
   - (Alternativ/zusätzlich, falls vorhanden, ein „HL7"- oder „Export"-Untermenü im Werks-Modus `332888`.)
4. **Im VetStation-Admin → „Verbindung/Fehler"** das Log ansehen:
   - **„✓ HL7 ERKANNT auf Port 4601"** → **es funktioniert**, die Werte laufen automatisch in VetStation. Fertig.
   - **„KEIN HL7 erkannt (evtl. proprietärer CentralStation-Link)"** → das Gerät sendet **MD2 (proprietär)**.
     Dann VetStation nicht direkt nutzbar → siehe **Fallbacks**. (Die Rohdaten liegen in `data/probe-4601.log`.)

## Fallbacks, falls kein direktes HL7
### 1. VSCapture als Empfänger (kostenlos, bewährt) — schlüsselfertig
VSCapture „spricht" das Mindray-HL7 und schreibt eine CSV; VetStation liest sie live.
- **Einmalig einrichten**: `installer\setup-vscapture-fallback.ps1` — prüft/installiert **.NET 8 Runtime**,
  lädt `VSCaptureCLIv1.008Binary.zip` und entpackt nach `C:\VetStation\vscapture`.
  (Manuell: Download von https://github.com/xeonfusion/VSCaptureCLI ; .NET 8 von https://dotnet.microsoft.com/download.)
- **Starten** (im Ordner `C:\VetStation\vscapture`):
  ```
  dotnet VSCaptureMRay.dll -mode 2 -serverport 4601 -interval 1 -export 1
  ```
  (interaktiv: `dotnet VSCaptureMRay.dll` → `2` = TCP Listener → Port `4601` → Intervall `1` = 5 s.)
  Es schreibt **`MRayDataExport.csv`** in dieses Verzeichnis (Spalte 1 `Time`, dann dynamische Parameter-Spalten).
- **VetStation** liest die CSV: in `bridge\config\devices.json` den `vscapture`-Adapter auf `"enabled": true`,
  `"file": "C:/VetStation/vscapture/MRayDataExport.csv"`. Der Adapter ordnet die Spalten über die Kopfzeile zu.
2. **Mindray eGateway** (kostenpflichtig): der dokumentierte Weg zu **echtem HL7** aus dem Mindray-Netz →
   VetStations `hl7`-Adapter liest es. Preise/Freischaltung über Eickemeyer/Mindray.
3. **BeneVision CMS Vet** (kostenpflichtige PC-Zentrale): sammelt die Daten; HL7-Export nur mit eGateway.

## Veta 5 Plus — der CS-Port liefert KEINE Daten (nur Firmware-Update)
Definitiv (Veta-5-Handbuch, Primärquelle): Der **CS-Port des Veta ist laut Hersteller ausschließlich
„Verbindung zum PC für Software-Update"** — **kein** Datenstrom, kein HL7, kein MD2. Der Veta↔Monitor-Link
fließt **hinein**: der Veta **liest EtCO₂ vom Monitor** (für die VS+-Beatmung), er sendet nichts nach außen.
Ein „Anesthesia-Plugin" für BeneLink ist nur für die **humane A-Serie** dokumentiert, nicht für den Veta.

→ **Konsequenz für die Verkabelung:** Das gelbe Kabel im Veta-CS-Port bringt VetStation **nichts**. Die
**Datenquelle ist der Monitor** (uMEC12 Vet **oder** LifeVet 10C). Dessen **Kapno-Modul liefert EtCO₂/FiCO₂/AF**
(OBX 220/221/222) — also ist alles im HL7-Strom des Monitors enthalten. **Es genügt, EINEN Monitor per HL7
anzubinden.** (Für Beatmungs-Detaildaten des Veta gäbe es nur den kostenpflichtigen Mindray-Weg Monitor→CMS.)

## Welche Werte VetStation aus HL7 liest (OBX-Codes, Mindray-PDS-Spezifikation)
`101=HF, 160=SpO₂, 170/171/172=NIBP Sys/Dia/Mean, 220=EtCO₂, 221=FiCO₂, 222=AWRR→AF, 200=T1/213=TB=Temp,
51=Gewicht, 102=PVCs`. Unbekannte Codes → automatisch ins Diagnose-Log (in `bridge/src/adapters/hl7.js`
→ `CODE_MAP` ergänzbar). Parser getestet: `node tools/hl7-test.js` (15/15), `node tools/hl7-live-test.js` (7/7).

## Zwei klare Fragen an Eickemeyer/Mindray
1. **„Sendet der uMEC12 Vet Live-Daten per HL7 über LAN (Port 4601), oder nur das proprietäre MD2 an die
   BeneVision CMS Vet? Falls HL7: welcher Menüpfad/Port, und ist es freigeschaltet (Lizenz)?"**
2. **„Gibt es für uns einen offenen Datenausgang (HL7/eGateway) für Monitor UND/ODER Veta — und was kostet die
   Freischaltung?"**

## Quellen (Primär)
- uMEC Operator's/Service Manual (kein HL7-Menü; MD2; Passwörter 888888/332888; Gateway-Comm-Setup).
- Mindray Patient Data Share Programmer's Guide (HL7 v2.3.1, MLLP, ORU^R01, OBX-Codes).
- VSCapture v1.008 (Port 4601, PC=Listener; uMEC numerik-orientiert) — sourceforge.net/projects/vscapture.
- Veta 5 / LifeVet 10C Operator's Manuals (CS=proprietär, kein offener Export).
- Mindray BeneVision CMS Vet / eGateway (proprietäres MD2 bzw. HL7 nur am Gateway).
