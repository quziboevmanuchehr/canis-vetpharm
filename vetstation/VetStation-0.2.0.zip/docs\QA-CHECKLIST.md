# Qualitätssicherung (§12)

## Automatischer Klinik-Selbsttest
```bash
node tools/smoke-test.js
```
Prüft die wiederverwendete Brain-Logik headless. **Aktueller Stand: 17/17 OK.**

| Test (aus §12) | Erwartung | Status |
|---|---|---|
| Datenbasis lädt | `window.ANAES` in Node, 8 Arten, 43 Medis | ✅ |
| Normal (Hund) | keine kritische Kreuz-Analyse | ✅ |
| MAP 50 bei hohem Iso | „Iso senken" / Hypotonie | ✅ |
| Bradykardie + tief | „Bradykardie bei zu tiefer Narkose → Iso zuerst senken" | ✅ |
| VES + SpO₂↓ | **erst O₂/Beatmung** (nicht antiarrhythmisch zuerst) | ✅ |
| VES isoliert | Lidocain (Hund) nach Sicherung | ✅ |
| Apnoe | Inzident Apnoe (AF/EtCO₂ = 0) → IPPV | ✅ |
| Hypoventilation | Inzident Hypoventilation (EtCO₂ hoch) | ✅ |
| Bronchospasmus (Katze) | Kapno-Haifischflosse → Atemweg (R6 live) | ✅ |
| Kammerflimmern | **CPR + DEFIBRILLIEREN** (sev 5) | ✅ |
| Asystolie (Katze) | CPR (sev 5) | ✅ |
| Hyperthermie / Hypothermie | Inzident Temp hoch/niedrig (mehrere Arten) | ✅ |
| AV-Block III (Reptil 0.4 kg) | Brain läuft artspezifisch, kein Crash | ✅ |
| Injektion mL | Asystolie/Katze: Adrenalin liefert mL; Bradykardie/Hund: Atropin | ✅ |
| Artspezifische Dosis | Atropin Hund ≠ Kaninchen (mg/kg) | ✅ |

## Live-Verifikation (Browser, gegen die laufende Bridge)
Bereits geprüft (Simulator):
- **Auto-Discovery:** 4 Geräte erkannt (2× Monitor, 2× Kapno), Status „active".
- **Matching:** Monitor+Kapno gleicher ID → 1 Patient; zwei Patienten (Hund + Katze) getrennt.
- **Split-View-Priorität:** VFlimmern-Hund (sev 5) steht über Hypotonie-Katze (sev 3).
- **Brain live:** VF → „Kammerflimmern → CPR/DEFIB" + mL (Adrenalin 0.22, Vasopressin 0.88 …);
  Hypotonie → „Verdampfer senken" + **Iso-Soll [OFF]** (3.6 vs 1.5–2.5).
- **Alarme:** Kacheln färben sich rot bei Grenzwertverletzung.
- **Waveforms:** EKG/Pleth/Kapno zeichnen (Canvas 423×234, Herzschlag läuft).
- **Live-Datenpull:** UI zeigt „📚 Live-Daten" (Pull vom canis-vetpharm erfolgreich).
- **Admin (PIN 1234):** 4 Reiter, Geräte-/Fehlerliste, Feedback, Export.

## Manuell zu prüfen (mit echten Geräten / vor Praxiseinsatz)
- [ ] Jedes der 3 Geräte im Standby wird erkannt, richtig benannt, Werte = Gerätewerte
      (erst nach Einbau der Protokoll-Parser, siehe DEVICE-ADAPTERS.md).
- [ ] Matching-Test mit echten Patienten-IDs (gleich → zusammengeführt; unterschiedlich → getrennt).
- [ ] Performance auf i3/8 GB: 3 Streams + 2 Fenster flüssig, RAM stabil (mehrere Stunden).
- [ ] Kiosk: bootet direkt in die App, kein Desktop, Watchdog startet nach Absturz neu.
- [ ] Win10 **und** Win11: identisches Verhalten (Kiosk, WebView2, DPI-Skalierung, Touch).
- [ ] DPI/Touchscreen: Layout responsiv, große Zahlen lesbar, Maus **und** Touch bedienbar.

## Hinweis zu Screenshots im Test
Die UI läuft dauerhaft mit `requestAnimationFrame` (Monitor-Kurven). Automatische Screenshots können
dabei hängen; **DOM/JS-Inspektion** (read_page / console) ist verlässlicher. In einem **sichtbaren**
Vollbildfenster laufen die Kurven normal (rAF wird nur bei versteckten Tabs pausiert).
