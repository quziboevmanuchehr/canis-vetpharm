'use strict';
/*
 * playback.js — Playback-Adapter (§11.1): spielt aufgezeichnete Verlaeufe ab
 * (VitalRecorder-Export / VSCapture-CSV / eigenes NDJSON) fuer realistischen Test ohne Geraete.
 *
 * Erwartetes Format (eine der beiden):
 *   - NDJSON: pro Zeile ein Frame im ingest-Format (siehe model.js).
 *   - CSV: Kopfzeile mit Spalten ts,hr,spo2,etco2,af,sys,dia,temp,ekgRhythm,capnoShape (Komma).
 * Konfig: { id, file, deviceId, deviceModel, deviceRole, patientId, species, weightKg, loop, rateMs }
 */
const fs = require('fs');
const { Adapter } = require('./base');

class PlaybackAdapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.frames = [];
    this.idx = 0;
    this.timer = null;
    this.rateMs = cfg.rateMs || 1000;
    this.loop = cfg.loop !== false;
  }

  describe() { return { id: this.id, model: this.cfg.deviceModel || 'Playback', role: this.cfg.deviceRole || 'monitor' }; }

  _parse(text) {
    const lines = text.split(/\r?\n/).filter(l => l.trim());
    if (!lines.length) return [];
    if (lines[0].trim().startsWith('{')) {
      return lines.map(l => { try { return JSON.parse(l); } catch (_) { return null; } }).filter(Boolean);
    }
    // CSV
    const cols = lines[0].split(',').map(s => s.trim());
    return lines.slice(1).map(l => {
      const cells = l.split(',');
      const row = {};
      cols.forEach((c, i) => { row[c] = cells[i]; });
      return {
        vitals: {
          hr: row.hr, spo2: row.spo2, etco2: row.etco2, af: row.af,
          nibp: { sys: row.sys, dia: row.dia }, temp: row.temp,
          ekgRhythm: row.ekgRhythm || row.rhythm, capnoShape: row.capnoShape,
        },
      };
    });
  }

  async connect() {
    try {
      const text = fs.readFileSync(this.cfg.file, 'utf8');
      this.frames = this._parse(text);
    } catch (e) {
      this.ctx.log && this.ctx.log.error('playback', 'Datei nicht lesbar: ' + this.cfg.file + ' (' + e.message + ')');
      this.frames = [];
    }
    if (!this.frames.length) { this.ctx.log && this.ctx.log.warn('playback', 'Keine Frames in ' + this.cfg.file); return; }
    this.connected = true;
    this.ctx.log && this.ctx.log.info('playback', this.frames.length + ' Frames aus ' + this.cfg.file);
    this.timer = setInterval(() => this._tick(), this.rateMs);
  }

  _tick() {
    if (this.idx >= this.frames.length) {
      if (!this.loop) { this.dispose(); return; }
      this.idx = 0;
    }
    const base = this.frames[this.idx++];
    this.emit(Object.assign({
      deviceId: this.cfg.deviceId || this.id,
      deviceModel: this.cfg.deviceModel || 'Playback',
      deviceRole: this.cfg.deviceRole || 'monitor',
      patientId: this.cfg.patientId || null,
      species: this.cfg.species || null,
      weightKg: this.cfg.weightKg || null,
      ts: Date.now(),
    }, base));
  }

  dispose() { if (this.timer) clearInterval(this.timer); this.timer = null; this.connected = false; }
}

module.exports = { PlaybackAdapter };
