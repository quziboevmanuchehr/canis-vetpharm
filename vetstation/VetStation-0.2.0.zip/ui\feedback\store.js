/*
 * store.js — Lokaler, anonymisierter Feedback-/Selbstdiagnose-Speicher (§14).
 * Sammelt klinische Rueckmeldungen (hilfreich/nicht passend), fehlende Inhalte, manuelles
 * Team-Feedback und Technik-/Verbindungs-Diagnosen. Alles in localStorage (keine Cloud).
 * Leitet Top-Verbesserungsvorschlaege ab und exportiert einen anonymisierten Bericht.
 */
(function (root) {
  'use strict';
  var VS = root.VS = root.VS || {};
  var KEY = 'vetstation.feedback.v1';

  function seed() { return { events: [], missing: [], manual: [] }; }
  function load() { try { return JSON.parse(localStorage.getItem(KEY)) || seed(); } catch (e) { return seed(); } }
  function save(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) {} }

  var data = load();
  var diagRing = []; // Technik-/Verbindungsereignisse (vom Bridge, fluechtig + Export)

  var store = {
    // Klinische Rueckmeldung am Vorschlag: verdict = 'helpful' | 'override'
    feedback: function (rec) {
      data.events.push({ ts: Date.now(), verdict: rec.verdict, incident: rec.incident || null, title: rec.title || '', species: rec.species || null });
      if (data.events.length > 3000) data.events.shift();
      save(data);
    },
    // Fehlende Inhalte (Medikament/Szenario/Rhythmus angefragt, nicht hinterlegt)
    missing: function (item) { data.missing.push({ ts: Date.now(), kind: item.kind || 'sonstiges', text: item.text || '', species: item.species || null }); save(data); },
    // Manuelles Team-Feedback
    manual: function (text) { if (!text) return; data.manual.push({ ts: Date.now(), text: String(text).slice(0, 1000) }); save(data); },
    // Technik-/Verbindungsereignisse (aus MSG.DIAG)
    diag: function (ev) { diagRing.push(ev); if (diagRing.length > 500) diagRing.shift(); },
    diagRecent: function (n) { return diagRing.slice(-(n || 100)).reverse(); },

    all: function () { return data; },

    // Priorisierte Verbesserungsvorschlaege ("Top 5, was die App klueger macht", §14).
    suggestions: function () {
      var out = [];
      // 1) Haeufig ueberstimmte Empfehlungen -> "Logik pruefen"
      var overrides = {};
      data.events.filter(function (e) { return e.verdict === 'override'; }).forEach(function (e) {
        var k = e.title || e.incident || 'unbekannt';
        overrides[k] = (overrides[k] || 0) + 1;
      });
      Object.keys(overrides).sort(function (a, b) { return overrides[b] - overrides[a]; }).slice(0, 5).forEach(function (k) {
        out.push({ prio: 5 + overrides[k], kind: 'logik', text: 'Oft ueberstimmt (' + overrides[k] + '×): „' + k + '“ – Logik/Dosis pruefen.' });
      });
      // 2) Fehlende Inhalte -> "Datensatz erweitern"
      var miss = {};
      data.missing.forEach(function (m) { var k = m.kind + ': ' + m.text; miss[k] = (miss[k] || 0) + 1; });
      Object.keys(miss).sort(function (a, b) { return miss[b] - miss[a]; }).slice(0, 5).forEach(function (k) {
        out.push({ prio: 3 + miss[k], kind: 'daten', text: 'Datensatz erweitern (' + miss[k] + '×): ' + k });
      });
      // 3) Technik: Verbindungs-/Parsingfehler haeufig?
      var errN = diagRing.filter(function (e) { return e.level === 'error'; }).length;
      var warnN = diagRing.filter(function (e) { return e.level === 'warn'; }).length;
      if (errN) out.push({ prio: 4 + Math.min(6, errN), kind: 'technik', text: errN + ' Fehler + ' + warnN + ' Warnungen im Diagnose-Log – Geraeteverbindung/Parser pruefen.' });
      out.sort(function (a, b) { return b.prio - a.prio; });
      return out.slice(0, 5);
    },

    // Ein-Klick-Export als anonymisierter Bericht (JSON-Text).
    exportReport: function () {
      var report = {
        tool: 'VetStation', generatedAt: new Date().toISOString(),
        note: 'Anonymisierter Selbstdiagnose-Bericht (lokal, keine Patientendaten).',
        counts: {
          feedback: data.events.length,
          helpful: data.events.filter(function (e) { return e.verdict === 'helpful'; }).length,
          overridden: data.events.filter(function (e) { return e.verdict === 'override'; }).length,
          missing: data.missing.length, manual: data.manual.length,
          diagWarn: diagRing.filter(function (e) { return e.level === 'warn'; }).length,
          diagError: diagRing.filter(function (e) { return e.level === 'error'; }).length,
        },
        topSuggestions: store.suggestions(),
        overrideByFinding: aggregate(data.events.filter(function (e) { return e.verdict === 'override'; }), 'title'),
        missing: data.missing, manual: data.manual,
        diagnostics: diagRing.slice(-200),
      };
      return JSON.stringify(report, null, 2);
    },

    clear: function () { data = seed(); diagRing = []; save(data); },
  };

  function aggregate(list, field) {
    var m = {}; list.forEach(function (e) { var k = e[field] || 'unbekannt'; m[k] = (m[k] || 0) + 1; }); return m;
  }

  VS.feedback = store;
})(window);
