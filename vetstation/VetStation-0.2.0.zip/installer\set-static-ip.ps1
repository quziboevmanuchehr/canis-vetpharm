<#
  set-static-ip.ps1 — Richtet die statische IP fuer das ISOLIERTE Geraete-Netz ein (§ LAN-Setup).
  Interaktiv: zeigt die Netzwerkkarten, du waehlst die Karte, die am Geraete-Switch haengt.
  Setzt standardmaessig 192.168.99.10/24 OHNE Gateway (isoliert, kein Router).

  WICHTIG: Nur die Karte auswaehlen, die zum Geraete-Switch geht — NICHT die Karte mit
  Internet/Praxisnetz. Als Administrator ausfuehren.

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\set-static-ip.ps1
  Nicht-interaktiv:  -Adapter "Ethernet 2" -IP 192.168.99.10 -Prefix 24
#>
param(
  [string]$Adapter,
  [string]$IP = '192.168.23.10',
  [int]$Prefix = 24
)

Write-Host "== Statische IP fuer das isolierte Geraete-Netz =="
Write-Host "Deine Geraete stehen laut Foto auf 192.168.23.x (z. B. Veta 192.168.23.250)."
Write-Host "-> PC am besten 192.168.23.10 (gleiche ersten 3 Zahlen wie die Geraete, andere letzte Zahl)."
Write-Host "   So musst du die Geraete-IP NICHT aendern, nur die Serveradresse am Geraet = 192.168.23.10."
Write-Host "   (Am Geraet ablesbar unter System -> Setup -> IP-Adresse.)"
Write-Host ""

$nics = Get-NetAdapter | Where-Object Status -in @('Up','Disconnected') | Sort-Object Name
if (-not $Adapter) {
  Write-Host "Verfuegbare Netzwerkkarten:"
  $i = 0; $nics | ForEach-Object { Write-Host ("  [{0}] {1}  ({2}, {3})" -f $i, $_.Name, $_.InterfaceDescription, $_.Status); $i++ }
  $sel = Read-Host "Nummer der Karte am GERAETE-Switch"
  if ($sel -notmatch '^\d+$' -or [int]$sel -ge $nics.Count) { Write-Warning "Ungueltige Auswahl."; exit 1 }
  $Adapter = $nics[[int]$sel].Name
}

Write-Host ""
Write-Host "Setze auf Karte '$Adapter':  IP $IP /$Prefix, kein Gateway (isoliert)."
$ok = Read-Host "Fortfahren? (j/N)"
if ($ok -notmatch '^(j|y)') { Write-Host "Abgebrochen."; exit 0 }

try {
  # Vorhandene statische IPs/Routen dieser Karte entfernen, dann setzen
  Get-NetIPAddress -InterfaceAlias $Adapter -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object PrefixOrigin -eq 'Manual' | Remove-NetIPAddress -Confirm:$false -ErrorAction SilentlyContinue
  New-NetIPAddress -InterfaceAlias $Adapter -IPAddress $IP -PrefixLength $Prefix -ErrorAction Stop | Out-Null
  # DNS leeren (isoliert)
  Set-DnsClientServerAddress -InterfaceAlias $Adapter -ResetServerAddresses -ErrorAction SilentlyContinue
  Write-Host "OK. '$Adapter' hat jetzt $IP/$Prefix."
  Write-Host ""
  Write-Host "NAECHSTE SCHRITTE am Geraet (mit dem Haendler):"
  Write-Host "  - Am Monitor/Veta die 'Serveradresse' / CentralStation-Server = $IP eintragen."
  Write-Host "  - Geraete-IPs z. B. Monitor 192.168.99.20, Veta 192.168.99.30 (gleiche Maske /24)."
  Write-Host "  - Details: docs\LAN-SETUP.md"
} catch {
  Write-Warning "Fehler: $($_.Exception.Message)"
  Write-Host "Alternativ manuell: Systemsteuerung -> Netzwerkadapter -> IPv4 -> feste IP $IP, Maske 255.255.255.0, kein Gateway."
}
