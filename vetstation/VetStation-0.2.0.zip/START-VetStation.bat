@echo off
REM VetStation starten (ECHTE Geraete). Fuer Dauerbetrieb: Install-VetStation.ps1 ausfuehren.
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
