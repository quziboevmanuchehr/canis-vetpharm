'use strict';
/*
 * base.js — Adapter-Interface (Schicht 1). Jeder Geraetetyp implementiert einen Adapter,
 * der sein Protokoll parst und normalisierte Roh-Frames via ctx.emit(raw) liefert.
 *
 * WICHTIG (Sicherheit/Recht §10): Adapter sind STRIKT READ-ONLY. Sie duerfen NIEMALS
 * Befehle an ein Geraet senden (kein Verstellen von Verdampfer/Beatmung). Nur lesen.
 *
 * ctx = { emit(rawFrame), log, cfg } wird vom Registry uebergeben.
 */
class Adapter {
  constructor(cfg, ctx) {
    this.cfg = cfg || {};
    this.ctx = ctx;
    this.id = this.cfg.id || 'adapter';
    this.connected = false;
  }

  // Kurzbeschreibung fuer Auto-Discovery-Anzeige.
  describe() {
    return { id: this.id, model: this.cfg.model || 'Unbekannt', role: this.cfg.role || 'monitor' };
  }

  // Verbindung aufbauen. Muss this.connected setzen und via ctx.emit(...) Frames liefern.
  async connect() { throw new Error('connect() nicht implementiert'); }

  // Sauber trennen (Timer/Sockets schliessen).
  dispose() { this.connected = false; }

  // Hilfsfunktion: Frame emittieren.
  emit(raw) {
    if (this.ctx && typeof this.ctx.emit === 'function') this.ctx.emit(raw);
  }
}

module.exports = { Adapter };
