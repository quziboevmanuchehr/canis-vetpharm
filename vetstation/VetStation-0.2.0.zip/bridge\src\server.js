'use strict';
/*
 * server.js — Ein Prozess, ein Port: liefert die Kiosk-UI (statisch) UND den lokalen WebSocket
 * (Schicht 2 wird von Schicht 1 gefuettert). Plus kleine JSON-API fuer Diagnose/Updater.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { createWsServer } = require('./wsserver');
const { MSG } = require('./model');
const { listScenarios } = require('./scenarios');
const logger = require('./logger');
const updater = require('../../updater/updater');

const UI_DIR = path.join(__dirname, '..', '..', 'ui');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.map': 'application/json',
};

function startServer({ port, host, registry, version, cloud }) {
  const httpServer = http.createServer(handleHttp);
  const ws = createWsServer(httpServer, { path: '/ws', onConnect, onMessage });

  // Diagnose-Ereignisse an alle UIs weiterreichen (Admin-Bereich).
  logger.setSink((ev) => ws.broadcast({ type: MSG.DIAG, event: ev }));

  // Broadcast-Takt: Geraeteliste + zusammengefuehrte Patienten (UI animiert Kurven lokal).
  // Dieselben zusammengefuehrten Patienten gehen (throttled) auch an die Cloud (Fern-Live).
  const BROADCAST_MS = 500;
  const timer = setInterval(() => {
    const patients = registry.getPatients();
    if (cloud) { try { cloud.publish(patients); } catch (e) { logger.warn('cloud', 'publish: ' + e.message); } }
    if (!ws.clients.size) return;
    ws.broadcast({ type: MSG.DEVICES, devices: registry.getDevices() });
    ws.broadcast({ type: MSG.PATIENTS, patients: patients, ts: Date.now() });
  }, BROADCAST_MS);

  httpServer.listen(port, host, () => {
    logger.info('server', 'VetStation UI+Bridge: http://' + host + ':' + port + '  (WebSocket /ws)');
  });
  httpServer.on('error', (e) => logger.error('server', 'HTTP-Fehler: ' + e.message));

  function onConnect(client) {
    client.sendJSON({ type: MSG.HELLO, bridgeVersion: version, ts: Date.now(), scenarios: listScenarios() });
    client.sendJSON({ type: MSG.DEVICES, devices: registry.getDevices() });
    client.sendJSON({ type: MSG.PATIENTS, patients: registry.getPatients(), ts: Date.now() });
    logger.recent(50).forEach((ev) => client.sendJSON({ type: MSG.DIAG, event: ev }));
  }

  function onMessage(client, text) {
    let m; try { m = JSON.parse(text); } catch (_) { return; }
    switch (m.type) {
      case MSG.PAIR: registry.pair(m.deviceIds, m.patientKey); ack(client, m, true); break;
      case MSG.UNPAIR: registry.unpair(m.patientKey); ack(client, m, true); break;
      case MSG.SET_META: registry.setMeta(m.deviceId, m.meta); ack(client, m, true); break;
      case MSG.SCENARIO: ack(client, m, registry.setScenario(m.patientId, m.scenarioId)); break;
      default: break;
    }
  }
  function ack(client, m, ok) { client.sendJSON({ type: MSG.ACK, of: m.type, ok: ok !== false }); }

  function handleHttp(req, res) {
    const u = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
    const pathname = decodeURIComponent(u.pathname);

    // --- kleine JSON-API ---
    if (pathname === '/api/state') return json(res, { devices: registry.getDevices(), patients: registry.getPatients() });
    if (pathname === '/api/diag') return json(res, { events: logger.recent(200) });
    if (pathname === '/api/scenarios') return json(res, { scenarios: listScenarios() });
    if (pathname === '/api/cloud') return json(res, cloud ? cloud.status() : { enabled: false });
    // In-App-Update (§13): Status prüfen bzw. anwenden/stagen. Nur lokal erreichbar (Kiosk).
    if (pathname === '/api/update/check') { updater.check().then((r) => json(res, r)).catch((e) => json(res, { error: e.message })); return; }
    if (pathname === '/api/update/apply') { logger.info('update', 'Update angefordert (Admin).'); updater.apply().then((r) => { logger.info('update', r.msg || (r.ok ? 'ok' : 'fehlgeschlagen')); json(res, r); }).catch((e) => json(res, { ok: false, msg: e.message })); return; }
    if (pathname === '/api/version') return json(res, { version });
    if (pathname === '/healthz') return json(res, { ok: true, ts: Date.now() });

    // --- statische UI ---
    let rel = pathname === '/' ? '/index.html' : pathname;
    const filePath = path.normalize(path.join(UI_DIR, rel));
    if (!filePath.startsWith(UI_DIR)) { res.writeHead(403); return res.end('403'); }
    fs.readFile(filePath, (err, data) => {
      if (err) {
        // SPA-Fallback auf index.html
        if (path.extname(filePath) === '') {
          return fs.readFile(path.join(UI_DIR, 'index.html'), (e2, d2) => {
            if (e2) { res.writeHead(404); return res.end('404'); }
            res.writeHead(200, { 'Content-Type': MIME['.html'] }); res.end(d2);
          });
        }
        res.writeHead(404); return res.end('404 ' + rel);
      }
      const ext = path.extname(filePath).toLowerCase();
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(data);
    });
  }

  function json(res, obj) {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(obj));
  }

  return { httpServer, ws, stop() { clearInterval(timer); ws.close(); try { httpServer.close(); } catch (_) {} } };
}

module.exports = { startServer };
