# Kiosk-/Appliance-Modus einrichten (Windows 10 & 11)

Ziel (§8): VetStation startet beim Hochfahren **automatisch im Vollbild**, ohne sichtbaren
Windows-Desktop/Taskleiste — wie ein IDEXX-Laborgerät. Zwei bewährte Wege; beide funktionieren
unter **Windows 10 Pro 22H2** und **Windows 11**.

## Voraussetzung: Autostart + Autologin
1. **Autostart** einrichten: `powershell -ExecutionPolicy Bypass -File kiosk\install-autostart.ps1`
   (geplante Aufgabe „VetStation-Kiosk" bei Anmeldung, inkl. Watchdog/Selbstheilung).
2. **Autologin** für den dedizierten PC:
   - `netplwiz` → Haken „Benutzer müssen … Kennwort eingeben" **entfernen** → Konto + Passwort bestätigen, **oder**
   - Registry `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon`: `AutoAdminLogon=1`, `DefaultUserName`, `DefaultPassword`.

## Weg A — Assigned Access (Zugewiesener Zugriff) — einfachster Kiosk
Startet **Microsoft Edge im Kioskmodus** automatisch. Ideal, da VetStation ohnehin über Edge/WebView2 läuft.
- Windows-Einstellungen → **Konten → Andere Benutzer → Kiosk einrichten** (bzw. „Assigned Access").
- Kiosk-Konto wählen → **Microsoft Edge** → **als Vollbild-/digital-signage/Kiosk** → URL `http://127.0.0.1:8770`.
- Wichtig: Die **Bridge muss vorher laufen** → Autostart (oben) startet sie. Der Assigned-Access-Edge zeigt dann die UI.
- Per PowerShell automatisierbar über `Set-AssignedAccess`/`Set-CimInstance MDM_AssignedAccess` (Provisioning-Paket mit dem **Windows Configuration Designer**).

## Weg B — Shell Launcher — App ersetzt explorer.exe (härtester Kiosk)
Ersetzt die Windows-Shell komplett durch VetStation; **kein Desktop/keine Taskleiste**.
- Feature aktivieren (Admin): `Enable-WindowsOptionalFeature -Online -FeatureName Client-EmbeddedShellLauncher`
- Als „custom shell" `powershell.exe -ExecutionPolicy Bypass -File <Pfad>\kiosk\launch-kiosk.ps1 -Watchdog` setzen
  (via WMI `WESL_UserSetting` / Configuration Designer). `launch-kiosk.ps1` startet Bridge **und** Edge-Kiosk und hält sich mit dem Watchdog selbst am Leben.
- Rückkehr zur Wartung: als **Admin-Konto** anmelden (dort normale Shell) — siehe unten.

## Beenden/Wartung nur mit PIN (§8)
- **In der App:** Der Admin-Bereich ist **PIN-geschützt** (Standard `1234`, ändern in `localStorage 'vetstation.pin'`
  bzw. später im Admin-UI). Dort liegen Selbstdiagnose/Feedback/Export.
- **Kiosk verlassen (Technik):** separates **Admin-Windows-Konto** ohne Kiosk anlegen; über den Anmeldebildschirm
  (Assigned Access) bzw. Shell-Launcher-Ausnahme dorthin wechseln, dann `kiosk\stop-kiosk.ps1`.
- Der reine Edge-Kioskmodus lässt sich nicht per Tastenkürzel schließen (gewollt); Wartung immer über das Admin-Konto.

## Windows 11 Hinweise
- Assigned Access und Shell Launcher sind auch unter Windows 11 verfügbar (Edition Pro/Enterprise/Education).
- WebView2 ist Evergreen (Microsoft aktualisiert automatisch) → identisches Verhalten Win10/Win11.
- DPI/Skalierung: die UI ist responsiv (relative Einheiten); bei Touchscreens funktioniert Maus **und** Touch.

## Empfehlung für diesen Aufbau
Jetzt sofort lauffähig: **Autostart + Assigned Access (Weg A)** mit dem Edge-WebView2-Kiosk.
Später, mit Rust-Toolchain: **Tauri-MSI** (`tauri-shell/`) als 1-Klick-Appliance mit signiertem Auto-Update.
