'use strict';
/*
 * scenarios.js — Skriptbare Narkose-Zwischenfaelle fuer den Simulator (Test ohne Geraete, §11.1/§12).
 * Jedes Szenario liefert Ziel-Vitalwerte + Rhythmus + Kapno-Form + gemeldete Iso% + erwarteter
 * Brain-Befund. Die Ziele sind so gewaehlt, dass die wiederverwendete Brain-Logik (R1..R6) exakt
 * die im Auftrag geforderten Empfehlungen ausloest (MAP50->"Iso senken", VES+SpO2v->O2/Beatmung,
 * Apnoe->IPPV, VFlimmern->CPR, Bronchospasmus->Atemweg ...).
 */
const { vitalsFor, mid } = require('./anaes');

// Basiszustand (stabile Narkose) fuer eine Art.
function baseline(sp, weightKg) {
  const V = vitalsFor(sp);
  const sys = mid(V.nibp), dia = mid(V.dia);
  return {
    hr: mid(V.hr),
    spo2: 98,
    etco2: Math.max(38, Math.min(46, mid(V.etco2))),
    fico2: 2,
    af: mid(V.rr),
    sys, dia, map: Math.round(dia + (sys - dia) / 3),
    temp: Math.round(mid(V.temp) * 10) / 10,
    rhythm: 'sinus',
    capnoShape: 'normal',
    pleth: 'normal',
    isoPct: 1.8,
    alarms: [],
  };
}

// Szenario-Katalog. build(base, V, sp) -> Teil-Ziel (mische mit base).
const SCENARIOS = [
  {
    id: 'normal', name: 'Stabil / normal', tags: ['baseline'],
    expect: 'Keine kritische Kreuz-Analyse; Werte im Normbereich.',
    build: () => ({}),
  },
  {
    id: 'bradykardie_tief', name: 'Bradykardie bei zu tiefer Narkose', tags: ['R4', 'Kreislauf'],
    expect: 'R4: "Bradykardie bei zu tiefer Narkose" -> Iso zuerst senken (nicht reflexartig Atropin).',
    build: (b, V) => ({ hr: Math.round(V.hr[0] * 0.75), map: V.map[0] - 6, sys: V.nibp[0] - 12, dia: V.dia[0] - 8, rhythm: 'sinusbrady', isoPct: 3.4 }),
  },
  {
    id: 'hypotension_tief', name: 'Hypotonie (MAP ~50) bei hohem Iso', tags: ['R5', 'Kreislauf'],
    expect: 'R5: "Hypotonie bei tiefer Narkose" -> Iso senken, dann Volumen, dann Ephedrin. (Klinik-Test MAP50->Iso senken)',
    build: () => ({ map: 50, sys: 78, dia: 44, isoPct: 3.6, hr: null }),
  },
  {
    id: 'hypoxie_ves', name: 'VES + SpO2 runter (hypoxie-getrieben)', tags: ['R2', 'Atmung', 'EKG'],
    expect: 'R2: ventrikulaere Ektopie hypoxie-/hyperkapniegetrieben -> ERST O2/Beatmung, Lidocain (Hund) erst danach.',
    build: (b, V) => ({ spo2: 84, etco2: V.etco2[1] + 12, rhythm: 'ves', pleth: 'weak', af: Math.max(2, V.rr[0] - 4) }),
  },
  {
    id: 'ves_isoliert', name: 'VES isoliert (oxygeniert)', tags: ['R3', 'EKG'],
    expect: 'R3: Ventrikulaere Extrasystolen -> Oxygenierung/Narkosetiefe sichern, dann Lidocain (Hund) langsam IV; Katze vorsichtig.',
    build: () => ({ rhythm: 'ves', spo2: 97, etco2: 44 }),
  },
  {
    id: 'apnoe', name: 'Apnoe (Atemstillstand)', tags: ['Atmung'],
    expect: 'Einzelwert AF=0/EtCO2=0 -> Inzident Apnoe -> IPPV/Beatmung. Kapno flach.',
    build: () => ({ af: 0, etco2: 0, capnoShape: 'flat', rhythm: 'sinus' }),
  },
  {
    id: 'hypoventilation', name: 'Hypoventilation / Rueckatmung', tags: ['Atmung'],
    expect: 'EtCO2 hoch (>60) + Kapno-Grundlinie erhoeht (Rueckatmung) -> Beatmung/Absorber pruefen.',
    build: (b, V) => ({ etco2: 68, fico2: 9, capnoShape: 'baseline', af: Math.max(3, V.rr[0] - 3) }),
  },
  {
    id: 'bronchospasmus', name: 'Bronchospasmus / Obstruktion', tags: ['R6', 'Atmung'],
    expect: 'R6: Kapno-Haifischflosse bei intaktem EKG -> Atemweg (Tubus/Sekret), vertiefen, beta2, 100% O2.',
    build: () => ({ capnoShape: 'shark', spo2: 90, etco2: 58, rhythm: 'sinus' }),
  },
  {
    id: 'vfib', name: 'Kammerflimmern', tags: ['R1', 'Reanimation'],
    expect: 'R1: Kammerflimmern -> CPR + DEFIBRILLIEREN, Verdampfer auf 0, 100% O2. (Klinik-Test VFlimmern->CPR)',
    build: () => ({ rhythm: 'vfib', spo2: 0, etco2: 8, capnoShape: 'low', pleth: 'flat', hr: 0, map: 0, sys: 0, dia: 0 }),
  },
  {
    id: 'asystolie', name: 'Asystolie', tags: ['R1', 'Reanimation'],
    expect: 'R1: Asystolie -> CPR, Verdampfer 0, 100% O2, Adrenalin. Flaches EKG/Kapno/Pleth.',
    build: () => ({ rhythm: 'asys', hr: 0, spo2: 0, etco2: 6, capnoShape: 'flat', pleth: 'flat', map: 0, sys: 0, dia: 0 }),
  },
  {
    id: 'hyperthermie', name: 'Hyperthermie', tags: ['Temperatur'],
    expect: 'Einzelwert Temp hoch -> Inzident Hyperthermie (an maligne Hyperthermie denken).',
    build: (b, V) => ({ temp: V.temp[1] + 2.0, hr: V.hr[1] + 10, etco2: 62, capnoShape: 'high' }),
  },
  {
    id: 'hypothermie', name: 'Hypothermie', tags: ['Temperatur'],
    expect: 'Einzelwert Temp niedrig -> Inzident Hypothermie -> aktiv waermen; Narkose vertieft sich.',
    build: (b, V) => ({ temp: V.temp[0] - 2.5, hr: Math.round(V.hr[0] * 0.85), rhythm: 'sinusbrady' }),
  },
  {
    id: 'avb3', name: 'AV-Block III', tags: ['EKG', 'Kreislauf'],
    expect: 'Rhythmus AV-Block III + niedrige HF -> Bradykardie-Kaskade; P und QRS unabhaengig.',
    build: (b, V) => ({ rhythm: 'avb3', hr: Math.round(V.hr[0] * 0.6), map: V.map[0] - 4 }),
  },
];

const byId = {};
SCENARIOS.forEach(s => { byId[s.id] = s; });

function listScenarios() {
  return SCENARIOS.map(s => ({ id: s.id, name: s.name, tags: s.tags, expect: s.expect }));
}

// Liefert das Ziel eines Szenarios fuer Art+Gewicht (gemischt mit baseline).
function targetFor(scenarioId, sp, weightKg) {
  const b = baseline(sp, weightKg);
  const s = byId[scenarioId] || byId.normal;
  const V = vitalsFor(sp);
  const patch = s.build(b, V, sp) || {};
  const t = Object.assign({}, b);
  for (const k in patch) if (patch[k] !== null && patch[k] !== undefined) t[k] = patch[k];
  return t;
}

module.exports = { SCENARIOS, listScenarios, targetFor, baseline, byId };
