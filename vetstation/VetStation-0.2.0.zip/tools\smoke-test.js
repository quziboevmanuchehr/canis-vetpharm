'use strict';
/*
 * smoke-test.js — Klinische Verifikation (headless) der wiederverwendeten Brain-Logik (§12).
 * Baut aus jedem Simulator-Szenario einen Live-Patienten und prueft, dass das "Brain"
 * exakt die geforderte Empfehlung liefert (MAP50->Iso senken, VES+SpO2v->O2/Beatmung,
 * Apnoe->Inzident, VFlimmern->CPR+Defib ...). Zusaetzlich: Injektions-mL nach Art/Gewicht.
 *   Aufruf:  npm run smoke   (oder: node tools/smoke-test.js)
 */
const { loadAnaes } = require('../bridge/src/anaes');
const { targetFor } = require('../bridge/src/scenarios');
const brain = require('../ui/engine/brain');
const dose = require('../ui/engine/dose');

const ANAES = loadAnaes();
let fails = 0, passes = 0;

function ok(cond, desc, detail) {
  if (cond) { passes++; console.log('  ✓ ' + desc); }
  else { fails++; console.log('  ✗ FAIL: ' + desc + (detail ? '  [' + detail + ']' : '')); }
}

function patientFrom(sp, wt, scenarioId) {
  const t = targetFor(scenarioId, sp, wt);
  return {
    species: sp, weightKg: wt,
    hr: t.hr, spo2: t.spo2, etco2: t.etco2, af: t.af,
    sys: t.sys, dia: t.dia, map: t.map, temp: t.temp,
    ekgRhythm: t.rhythm, capnoShape: t.capnoShape, pleth: t.pleth, isoPct: t.isoPct,
  };
}

console.log('== VetStation Klinik-Smoke-Test ==');
ok(!!ANAES && !!ANAES.species, 'anaes-data.js (window.ANAES) laedt in Node', ANAES ? (ANAES.species.length + ' Arten') : 'null');
if (!ANAES) { console.log('\nABBRUCH: keine Daten.'); process.exit(1); }
console.log('  Arten:', ANAES.species.map(s => s.id).join(', '));

const cases = [
  { sc: 'normal', sp: 'hund', wt: 22, desc: 'Normal (Hund): keine kritische Kreuz-Analyse',
    test: r => r.cross.length === 0 },
  { sc: 'bradykardie_tief', sp: 'hund', wt: 22, desc: 'Bradykardie bei tiefer Narkose -> "Iso zuerst senken"',
    test: r => r.cross.some(c => c.incident === 'bradykardie' && /Iso/i.test(c.tag) && /SENKEN/i.test(c.fix)) },
  { sc: 'hypotension_tief', sp: 'hund', wt: 22, desc: 'MAP 50 bei hohem Iso -> Verdampfer senken (Hypotonie)',
    test: r => r.cross.some(c => c.incident === 'hypotension' && /senken/i.test(c.fix)) },
  { sc: 'hypoxie_ves', sp: 'hund', wt: 22, desc: 'VES + SpO2 runter -> ERST O2/Beatmung (nicht antiarrhythmisch zuerst)',
    test: r => r.cross.some(c => /Erst O₂/i.test(c.tag) && /IPPV|O₂/i.test(c.fix)) },
  { sc: 'ves_isoliert', sp: 'hund', wt: 22, desc: 'VES isoliert (oxygeniert) -> Lidocain (Hund) nach Sicherung',
    test: r => r.cross.some(c => c.incident === 'tachykardie' && /Lidocain/i.test(c.fix)) },
  { sc: 'apnoe', sp: 'hund', wt: 22, desc: 'Apnoe -> Inzident apnoe (Einzelwert AF/EtCO2=0)',
    test: r => r.single.some(s => s.incident === 'apnoe') },
  { sc: 'hypoventilation', sp: 'hund', wt: 22, desc: 'Hypoventilation -> Inzident hypoventilation (EtCO2 hoch)',
    test: r => r.single.some(s => s.incident === 'hypoventilation') },
  { sc: 'bronchospasmus', sp: 'katze', wt: 4.2, desc: 'Kapno-Haifischflosse (Katze) -> Bronchospasmus/Atemweg (R6 live)',
    test: r => r.cross.some(c => /Bronchospasmus/i.test(c.title) && /β2|Tubus/i.test(c.fix)) },
  { sc: 'vfib', sp: 'hund', wt: 22, desc: 'Kammerflimmern -> CPR + DEFIBRILLIEREN (sev 5)',
    test: r => r.cross.some(c => c.sev === 5 && /Kammerflimmern/i.test(c.title) && /DEFIB/i.test(c.fix)) },
  { sc: 'asystolie', sp: 'katze', wt: 4.2, desc: 'Asystolie (Katze) -> CPR (sev 5)',
    test: r => r.cross.some(c => c.sev === 5 && /Asystolie/i.test(c.title)) },
  { sc: 'hyperthermie', sp: 'hund', wt: 22, desc: 'Temp hoch -> Inzident hyperthermie',
    test: r => r.single.some(s => s.incident === 'hyperthermie') },
  { sc: 'hypothermie', sp: 'kaninchen', wt: 2.5, desc: 'Temp niedrig (Kaninchen) -> Inzident hypothermie',
    test: r => r.single.some(s => s.incident === 'hypothermie') },
  { sc: 'avb3', sp: 'reptil', wt: 0.4, desc: 'AV-Block III (Reptil, 0.4 kg) -> Brain laeuft artspezifisch, kein Crash',
    test: r => Array.isArray(r.cross) && !!r.top },
];

console.log('\n-- Brain / Kreuz-Analyse --');
cases.forEach(c => {
  const p = patientFrom(c.sp, c.wt, c.sc);
  const r = brain.assess(ANAES, p);
  const top = r.top ? (r.top.title + ' [' + (r.top.tag || '') + ']') : (r.single[0] ? r.single[0].name : '—');
  ok(c.test(r), c.desc, 'top=' + top + ' cross=' + r.cross.length + ' single=' + r.single.length);
});

console.log('\n-- Injektionen (mL nach Art/Gewicht) --');
const inj1 = dose.injectionsFor(ANAES, 'asystolie', 'katze', 4.2);
const adr = inj1.find(x => x.id === 'adrenalin');
ok(adr && adr.mlLo > 0, 'Asystolie/Katze 4.2 kg: Adrenalin liefert mL', adr ? (dose.fmtRange(adr.mlLo, adr.mlHi) + ' mL @ ' + adr.conc + ' mg/mL') : 'fehlt');
const inj2 = dose.injectionsFor(ANAES, 'bradykardie', 'hund', 22);
const atr = inj2.find(x => x.id === 'atropin');
ok(atr && atr.mlLo > 0, 'Bradykardie/Hund 22 kg: Atropin liefert mL', atr ? (dose.fmtRange(atr.mlLo, atr.mlHi) + ' mL') : 'fehlt');
// artspezifische Dosis unterscheidet sich (Hund vs Kaninchen Atropin mg/kg)
const dHund = dose.doseFor(ANAES, 'atropin', 'hund', 10);
const dKan = dose.doseFor(ANAES, 'atropin', 'kaninchen', 10);
ok(dHund && dKan && dHund.spd.low !== dKan.spd.low, 'Artspezifische Dosis: Atropin Hund != Kaninchen (mg/kg)',
  (dHund && dKan) ? ('Hund ' + dHund.spd.low + ' vs Kaninchen ' + dKan.spd.low) : 'fehlt');

console.log('\n== Ergebnis: ' + passes + ' OK, ' + fails + ' FAIL ==');
process.exit(fails ? 1 : 0);
