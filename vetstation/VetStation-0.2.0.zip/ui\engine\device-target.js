/*
 * device-target.js — Geraete-Soll-Empfehlung (aus der Web-App: devTarget/loopPreview/renderDevCtrl).
 * Sagt fuer Art+Gewicht die Ziel-Einstellungen (O2-Fluss, Iso Vol%, Kreissystem/Nicht-Rueckatmung, APL)
 * und vergleicht sie mit der aktuell gemeldeten Einstellung ("Soll: X ✓/⚠").
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.VS = root.VS || {}; root.VS.deviceTarget = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function settings(ANAES, sp) {
    var m = ANAES.machine && ANAES.machine.settingsBySpecies;
    return (m && (m[sp] || m.hund)) || {
      rebreatheMin: 7, o2: { mlkg: [50, 100], min: 0.2 }, iso: { mac: '1.3', maint: '1.5–2.5' },
      apl: 'offen (2–3)',
    };
  }

  // devTarget(sp, wt) -> { o2:[lo,hi], iso:'x–y', isoMac, mode, apl }
  function devTarget(ANAES, sp, wt) {
    var m = settings(ANAES, sp);
    var o2 = m.o2 || { mlkg: [50, 100], min: 0.2 };
    var o2lo = Math.max(o2.min || 0.2, (o2.mlkg[0] * wt) / 1000);
    var o2hi = Math.max(o2.min || 0.2, (o2.mlkg[1] * wt) / 1000);
    return {
      o2: [o2lo, o2hi],
      iso: (m.iso && m.iso.maint) || '1.5–2.5',
      isoMac: (m.iso && m.iso.mac) || '—',
      mode: wt < (m.rebreatheMin || 7) ? 'Nicht-Rueckatmung' : 'Kreissystem',
      apl: m.apl || 'offen (2–3)',
    };
  }

  function parseRange(str) {
    if (!str) return [null, null];
    var parts = String(str).split(/[–-]/).map(function (s) { return parseFloat(s); });
    return [parts[0], parts.length > 1 ? parts[1] : null];
  }

  // Vergleich aktueller Einstellung (iso Vol%, o2 L/min) mit dem Soll.
  function compare(ANAES, sp, wt, dev) {
    var t = devTarget(ANAES, sp, wt);
    var iso = parseRange(t.iso);
    var isoLo = iso[0], isoHi = iso[1] != null ? iso[1] : iso[0];
    var rows = [];
    if (dev && dev.iso != null) {
      var isoOff = dev.iso < isoLo - 0.4 || dev.iso > isoHi + 0.6;
      rows.push({ name: 'Isofluran', value: dev.iso + ' Vol%', target: t.iso + ' Vol%', off: isoOff, hint: isoOff && dev.iso > isoHi ? 'zu hoch – senken' : (isoOff ? 'ausserhalb Soll' : 'im Soll') });
    } else {
      rows.push({ name: 'Isofluran', value: '–', target: t.iso + ' Vol%', off: false, hint: 'kein Wert gemeldet' });
    }
    if (dev && dev.o2 != null) {
      var o2Off = dev.o2 < t.o2[0] - 0.2 || dev.o2 > t.o2[1] + 1;
      rows.push({ name: 'O₂-Fluss', value: dev.o2 + ' L/min', target: fmt1(t.o2[0]) + '–' + fmt1(t.o2[1]) + ' L/min', off: o2Off });
    } else {
      rows.push({ name: 'O₂-Fluss', value: '–', target: fmt1(t.o2[0]) + '–' + fmt1(t.o2[1]) + ' L/min', off: false });
    }
    rows.push({ name: 'System', value: '', target: t.mode, off: false });
    rows.push({ name: 'APL-Ventil', value: '', target: t.apl, off: false });
    return { target: t, rows: rows, isoBand: [isoLo, isoHi] };
  }

  // isoHigh: Verdampfer deutlich ueber Soll? (fuer die Brain-Regeln R4/R5)
  function isoHigh(ANAES, sp, wt, iso) {
    if (iso == null) return false;
    var t = devTarget(ANAES, sp, wt);
    var band = parseRange(t.iso);
    var lo = band[0], hi = band[1];
    if (hi != null) return iso > hi + 0.6;
    return iso > lo + 0.8;
  }

  function fmt1(n) { return (Math.round(n * 10) / 10).toString(); }

  return { devTarget: devTarget, compare: compare, isoHigh: isoHigh, parseRange: parseRange };
});
