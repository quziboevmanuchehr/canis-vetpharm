/*
 * vetstation-live.js — VetStation Narkose-Ueberwachung (Live-Schicht ueber der Anaesthesie-App).
 * - erkennt jedes eingeschaltete/verbundene Geraet automatisch und oeffnet je Patient EIN Fenster
 *   (komplette Anaesthesie-App, live gefahren: Monitor + "Brain"-Empfehlungen + Geraete-Soll);
 * - Benutzer kann Fenster frei oeffnen/schliessen (Multifunktion);
 * - fuehrt ein OP-Protokoll und exportiert Parameter + Protokoll als PDF;
 * - blendet Fremd-Menues aus (nur Anaesthesie). Read-only: nie Geraetebefehle.
 */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var VS = window.VS || {};
  var grid = $('#vsxGrid');
  var state = { patients: [], devices: [] };
  var windows = {};          // patientKey -> { wrap, frame, head, drive, switched }
  var closed = {};           // patientKey -> true (vom Benutzer geschlossen)
  var log = {}, meta = {};   // Protokoll je Patient + Stammdaten
  var ws = null, wsReady = false;
  var pairingOpen = false, pairSel = {};   // Geräte-/Koppel-Overlay (§6)
  // Perf (§2): nicht sichtbare Fenster pausieren (rAF im iframe stoppen) via postMessage.
  var visObs = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      var w = en.target.__vsw; if (!w || !w.frame || !w.frame.contentWindow) return;
      var show = en.isIntersecting && en.intersectionRatio > 0.05;
      try { w.frame.contentWindow.postMessage({ vsMon: show ? 'resume' : 'pause' }, '*'); } catch (e) {}
    });
  }, { threshold: [0, 0.06, 0.5] }) : null;

  function A() { return window.ANAES; }

  // ---------- WebSocket ----------
  function connect() {
    var proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(proto + '://' + location.host + '/ws');
    ws.onopen = function () { wsReady = true; setConn(true, 'verbunden'); };
    ws.onclose = function () { wsReady = false; setConn(false, 'getrennt – neu…'); setTimeout(connect, 1500); };
    ws.onerror = function () { setConn(false, 'Fehler'); };
    ws.onmessage = function (e) {
      var m; try { m = JSON.parse(e.data); } catch (_) { return; }
      if (m.type === 'devices') { state.devices = m.devices || []; updateDeviceBtn(); if (pairingOpen) renderPairing(); }
      else if (m.type === 'patients') { state.patients = m.patients || []; refresh(); }
      else if (m.type === 'diag') { if (VS.feedback) VS.feedback.diag(m.event); if (window.VSADMIN && window.VSADMIN.onDiag) window.VSADMIN.onDiag(m.event); }
    };
  }
  function send(o) { if (wsReady) try { ws.send(JSON.stringify(o)); } catch (_) {} }
  function setConn(ok, t) { var d = $('#vsxDot'); if (d) d.className = 'vsx-dot ' + (ok ? 'on' : 'off'); var s = $('#vsxConn'); if (s) s.textContent = t; }

  // ---------- Bewertung ----------
  function assess(p) {
    var pat = Object.assign({ species: p.species || 'hund', weightKg: p.weightKg || 10, isoPct: p.isoPct }, p.vitals || {});
    try { return VS.brain.assess(A(), pat, { iso: p.isoPct }); } catch (e) { return { top: null, cross: [], priority: 0 }; }
  }
  function priColor(sev) { return sev >= 5 ? '#ff4d4d' : sev >= 4 ? '#ff8c3c' : sev >= 3 ? '#a3e635' : '#35d69a'; }
  function prTxt(sev) { return sev >= 5 ? 'CPR' : sev >= 4 ? 'DRINGEND' : sev >= 3 ? 'ACHTUNG' : 'stabil'; }
  function spOf(id) { return (A().species || []).find(function (s) { return s.id === id; }) || { icon: '🐾', name: id || '?' }; }

  // ---------- zentrale Aktualisierung ----------
  function refresh() {
    var pats = state.patients.slice();
    pats.forEach(function (p) { p._res = assess(p); });
    pats.sort(function (a, b) { return (b._res.priority || 0) - (a._res.priority || 0); });
    logSnapshot(pats);

    var live = {};
    pats.forEach(function (p) { live[p.patientKey] = 1; if (!closed[p.patientKey]) ensureWindow(p); });
    // Fenster verschwundener Patienten entfernen
    Object.keys(windows).forEach(function (k) { if (!live[k]) removeWindow(k); });
    // offene Fenster aktualisieren
    pats.forEach(function (p) { if (windows[p.patientKey]) { updateHead(windows[p.patientKey], p); drive(windows[p.patientKey], p); } });
    // §6.4: gefährlichste Warnung nach oben — Fenster in Prioritätsreihenfolge (pats ist sortiert) anordnen.
    pats.forEach(function (p) { var w = windows[p.patientKey]; if (w && w.wrap.parentNode === grid) grid.appendChild(w.wrap); });

    var n = Object.keys(windows).length;
    grid.style.setProperty('--cols', Math.min(3, Math.max(1, Math.ceil(Math.sqrt(n)))));
    var hint = $('#vsxHint'); if (hint) hint.style.display = n ? 'none' : '';
    updateTestBanner();
    updateDeviceBtn();
    if (pairingOpen) renderPairing();
    renderBar(pats);
  }
  function updateDeviceBtn() {
    var b = $('#vsxDevices'); if (!b) return;
    var d = state.devices || [], act = d.filter(function (x) { return x.status === 'active'; }).length;
    b.textContent = '🔌 Geräte (' + act + '/' + d.length + ')';
  }
  // Test-/Demo-Modus erkennen: Simulator-Geräte tragen "(Sim)" im Modellnamen.
  function updateTestBanner() {
    var sim = (state.devices || []).some(function (x) { return /\(Sim\)/i.test(x.model || ''); });
    var tb = $('#vsxTestBanner'); if (tb) tb.hidden = !sim;
    document.documentElement.classList.toggle('vsx-test', sim);
  }

  function renderBar(pats) {
    var host = $('#vsxPatients'); if (!host) return;
    if (!pats.length) { host.innerHTML = '<span class="lead">warte auf Geräte…</span>'; return; }
    host.innerHTML = '<span class="lead">Geräte/Patienten:</span>' + pats.map(function (p) {
      var sp = spOf(p.species), sev = p._res.top ? p._res.top.sev : 0, col = priColor(sev);
      var open = !!windows[p.patientKey];
      return '<div class="vsx-pat ' + (open ? 'open' : 'closed') + '" data-k="' + p.patientKey + '" data-sev="' + sev + '" style="--pc:' + col + '" title="' + (open ? 'Fenster schließen' : 'Fenster öffnen') + '">' +
        '<span class="ic">' + sp.icon + '</span><b>' + esc(p.patientId || 'Patient') + '</b>' +
        '<span class="muted">' + esc(sp.name) + ' ' + (p.weightKg || '?') + 'kg</span>' +
        '<span class="pr">' + prTxt(sev) + '</span></div>';
    }).join('');
    host.querySelectorAll('.vsx-pat').forEach(function (el) {
      el.onclick = function () { var k = el.getAttribute('data-k'); if (windows[k]) { closed[k] = true; removeWindow(k); } else { delete closed[k]; refresh(); } };
    });
  }

  // ---------- Fenster ----------
  function ensureWindow(p) {
    if (windows[p.patientKey]) return;
    var wrap = document.createElement('div'); wrap.className = 'vsx-win';
    var head = document.createElement('div'); head.className = 'vsx-winhead';
    var f = document.createElement('iframe'); f.src = 'app/index.html?kiosk=1'; f.title = 'Anaesthesie';
    wrap.appendChild(head); wrap.appendChild(f); grid.appendChild(wrap);
    var w = { wrap: wrap, frame: f, head: head, drive: {}, switched: false };
    f.addEventListener('load', function () { w.switched = false; injectKiosk(f); setTimeout(refresh, 700); });
    windows[p.patientKey] = w;
    wrap.__vsw = w; if (visObs) visObs.observe(wrap);
    updateHead(w, p);
  }
  function removeWindow(k) { var w = windows[k]; if (!w) return; if (visObs && w.wrap) visObs.unobserve(w.wrap); if (w.wrap.parentNode) w.wrap.parentNode.removeChild(w.wrap); delete windows[k]; }
  function updateHead(w, p) {
    var sp = spOf(p.species), top = p._res.top, sev = top ? top.sev : 0;
    w.wrap.classList.toggle('sev5', sev >= 5);
    w.head.style.setProperty('--pc', priColor(sev));
    // Klinische Rückmeldung nur, wenn eine Empfehlung vorliegt (sev>0). §14 Kategorie 1.
    var fb = top ? '<span class="fb"><button class="fbh" title="Empfehlung war hilfreich">👍</button><button class="fbo" title="Empfehlung nicht passend">👎</button></span>' : '';
    w.head.innerHTML = '<span class="ic">' + sp.icon + '</span><b>' + esc(p.patientId || 'Patient') + '</b>' +
      '<span class="muted">' + esc(sp.name) + ' · ' + (p.weightKg || '?') + ' kg' + (p.isoPct != null ? ' · Iso ' + p.isoPct + '%' : '') + '</span>' +
      '<span class="pr">' + prTxt(sev) + '</span>' + fb + '<span class="x" title="Fenster schließen">✕</span>';
    w.head.querySelector('.x').onclick = function () { closed[p.patientKey] = true; removeWindow(p.patientKey); refresh(); };
    if (top) {
      w.head.querySelector('.fbh').onclick = function (e) { e.stopPropagation(); recFeedback('helpful', p, top); };
      w.head.querySelector('.fbo').onclick = function (e) { e.stopPropagation(); recFeedback('override', p, top); };
    }
  }
  function recFeedback(verdict, p, top) {
    try { VS.feedback && VS.feedback.feedback({ verdict: verdict, incident: top && top.incident, title: top && top.title, species: p.species }); } catch (e) {}
    flashToast(verdict === 'helpful' ? '👍 Rückmeldung „hilfreich" gespeichert' : '👎 „nicht passend" gespeichert – fließt in Admin ▸ Verbesserungen');
  }
  var toastTimer = null;
  function flashToast(msg) {
    var t = $('#vsxToast'); if (!t) { t = document.createElement('div'); t.id = 'vsxToast'; document.body.appendChild(t); }
    t.textContent = msg; t.className = 'show';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = ''; }, 2200);
  }
  function injectKiosk(f) {
    try {
      var doc = f.contentDocument || f.contentWindow.document;
      var stl = doc.createElement('style');
      // Nur Anaesthesie: Fremd-Modul-Menue + Hub-Ruecklink ausblenden
      stl.textContent = 'header a[href*="index.html"],header .back{display:none!important}.vp-hamburger,.vp-nav-overlay,.vp-nav-panel,.vp-qlinks{display:none!important}';
      doc.head.appendChild(stl);
    } catch (e) {}
  }

  // ---------- die App live fahren ----------
  function ready(doc) { return !!(doc && doc.readyState === 'complete' && doc.getElementById('tabs')); }
  function fire(el, type) { try { el.dispatchEvent(new (el.ownerDocument.defaultView.Event)(type, { bubbles: true })); } catch (e) {} }
  function setInput(doc, key, val) { if (val == null) return; var inp = doc.querySelector('#monInputs input[data-p="' + key + '"]'); if (inp && parseFloat(inp.value) !== val) { inp.value = val; fire(inp, 'input'); } }
  function drive(w, p) {
    var doc; try { doc = w.frame.contentDocument || w.frame.contentWindow.document; } catch (e) { return; }
    if (!ready(doc)) return;
    var sp = p.species || 'hund';
    var chip = doc.querySelector('#spChips .sp-chip[data-sp="' + sp + '"]');
    if (chip && !chip.classList.contains('active')) chip.click();
    var wt = doc.getElementById('wt');
    if (wt && p.weightKg && parseFloat(wt.value) !== p.weightKg) { wt.value = p.weightKg; fire(wt, 'input'); }
    if (!w.switched) { var tab = doc.querySelector('#tabs .tab[data-view="geraet"]'); if (tab) { tab.click(); w.switched = true; } }
    var v = p.vitals || {};
    setInput(doc, 'hr', v.hr); setInput(doc, 'spo2', v.spo2); setInput(doc, 'etco2', v.etco2);
    setInput(doc, 'rr', v.af); setInput(doc, 'temp', v.temp); setInput(doc, 'sys', v.sys); setInput(doc, 'dia', v.dia);
    if (v.ekgRhythm && w.drive.rhythm !== v.ekgRhythm) { var rc = doc.querySelector('#rhythmChips .chip[data-r="' + v.ekgRhythm + '"]'); if (rc) { rc.click(); w.drive.rhythm = v.ekgRhythm; } }
  }

  // ---------- OP-Protokoll ----------
  function logSnapshot(pats) {
    var now = Date.now();
    pats.forEach(function (p) {
      var k = p.patientKey; meta[k] = { patientId: p.patientId, species: p.species, weightKg: p.weightKg };
      var L = log[k] || (log[k] = []);
      var top = p._res.top ? p._res.top.title : null;
      var last = L[L.length - 1];
      if (!last || now - last.ts > 12000 || (last.finding || '') !== (top || '')) {
        var v = p.vitals || {};
        L.push({ ts: now, hr: v.hr, spo2: v.spo2, etco2: v.etco2, af: v.af, map: v.map, sys: v.sys, dia: v.dia, temp: v.temp, rhythm: v.ekgRhythm, iso: p.isoPct, finding: top });
        if (L.length > 1200) L.shift();
      }
    });
  }

  // ---------- PDF-Export ----------
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hhmmss(ts) { var d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); }
  function nn(x) { return x == null ? '–' : x; }

  function exportPDF() {
    var jsPDF = window.jspdf && window.jspdf.jsPDF; if (!jsPDF) { alert('PDF-Bibliothek nicht geladen.'); return; }
    var doc = new jsPDF({ unit: 'mm', format: 'a4' });
    var W = 210, M = 14, y = M, PH = 297;
    function nl(h) { y += (h || 6); if (y > PH - M) { doc.addPage(); y = M; } }
    function text(s, x, size, style, color) { doc.setFontSize(size || 10); doc.setFont('helvetica', style || 'normal'); if (color) doc.setTextColor(color[0], color[1], color[2]); else doc.setTextColor(30, 34, 40); doc.text(String(s), x == null ? M : x, y); }
    function line() { doc.setDrawColor(200); doc.line(M, y, W - M, y); }

    // Kopf
    text('VetStation — OP-Protokoll / Narkose-Überwachung', M, 16, 'bold'); nl(7);
    text('Erstellt: ' + new Date().toLocaleString(), M, 9, 'normal', [90, 90, 90]); nl(5);
    text('Entscheidungs-/Trainingshilfe · kein zugelassener Patientenmonitor-Ersatz · read-only. Der Tierarzt entscheidet.', M, 8, 'italic', [150, 60, 60]); nl(4);
    line(); nl(6);

    var pats = state.patients.slice().sort(function (a, b) { return (assess(b).priority || 0) - (assess(a).priority || 0); });
    if (!pats.length) { text('Keine verbundenen Patienten.', M, 11); }

    pats.forEach(function (p, idx) {
      if (idx > 0) { nl(4); }
      var res = assess(p), sp = spOf(p.species), v = p.vitals || {};
      text((sp.name) + ' · ' + (p.patientId || 'Patient') + ' · ' + (p.weightKg || '?') + ' kg', M, 13, 'bold'); nl(6);
      text('Aktuelle Werte:  HF ' + nn(v.hr) + ' /min   SpO2 ' + nn(v.spo2) + ' %   EtCO2 ' + nn(v.etco2) + ' mmHg   NIBP ' + nn(v.sys) + '/' + nn(v.dia) + ' (' + nn(v.map) + ')   AF ' + nn(v.af) + '   Temp ' + nn(v.temp) + ' °C   Rhythmus ' + nn(v.ekgRhythm) + (p.isoPct != null ? '   Iso ' + p.isoPct + '%' : ''), M, 9); nl(6);

      // Befunde + Empfehlungen (Brain)
      if (res.cross && res.cross.length) {
        text('Zwischenfälle & Empfehlungen:', M, 10, 'bold'); nl(5);
        res.cross.forEach(function (f) {
          text('• ' + f.title + (f.tag ? ' [' + f.tag + ']' : ''), M + 2, 9, 'bold', priColor(f.sev).match(/\w\w/g).map(function (h) { return parseInt(h, 16); })); nl(4.5);
          if (f.fix) { doc.setTextColor(30, 34, 40); wrap('Sofort: ' + f.fix, M + 5, 9); }
          if (f.incident) {
            var inj = VS.dose.injectionsFor(A(), f.incident, p.species || 'hund', p.weightKg || 10).filter(function (x) { return x.available; });
            inj.forEach(function (d) {
              var ml = d.mlLo != null ? VS.dose.fmtRange(d.mlLo, d.mlHi) + ' mL' : '';
              wrap('Injektion: ' + d.name + '  ' + ml + (d.route ? '  ' + d.route : '') + (d.conc ? '  @ ' + d.conc + ' mg/mL' : ''), M + 5, 9);
            });
          }
        });
      } else { text('Keine kritische Kreuz-Analyse (Werte im Normbereich).', M + 2, 9, 'italic', [90, 90, 90]); nl(5); }

      // Geraete-Soll
      try {
        var cmp = VS.deviceTarget.compare(A(), p.species || 'hund', p.weightKg || 10, { iso: p.isoPct, o2: null });
        text('Geräte-Soll: ' + cmp.rows.map(function (r) { return r.name + ' ' + (r.target || ''); }).join('   ·   '), M, 8.5, 'normal', [70, 90, 110]); nl(6);
      } catch (e) {}

      // Protokoll-Zeitlinie (heruntergerechnet auf max ~50 Zeilen)
      var L = log[p.patientKey] || [];
      if (L.length) {
        text('Protokoll (Verlauf):', M, 10, 'bold'); nl(4.5);
        doc.setFont('courier', 'normal'); doc.setFontSize(8); doc.setTextColor(40, 40, 40);
        var step = Math.max(1, Math.ceil(L.length / 50));
        for (var i = 0; i < L.length; i += step) {
          var e = L[i];
          var ln = hhmmss(e.ts) + '  HF ' + nn(e.hr) + '  SpO2 ' + nn(e.spo2) + '  EtCO2 ' + nn(e.etco2) + '  MAP ' + nn(e.map) + '  AF ' + nn(e.af) + '  T ' + nn(e.temp) + '  ' + nn(e.rhythm) + (e.finding ? '  → ' + e.finding : '');
          doc.text(ln.substring(0, 110), M, y); nl(4);
        }
      }
      nl(3); line();
    });

    function wrap(s, x, size) { doc.setFontSize(size || 9); var lines = doc.splitTextToSize(String(s), W - M - x); lines.forEach(function (ln) { doc.text(ln, x, y); nl(4.3); }); }

    var name = 'VetStation-OP-Protokoll_' + new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-') + '.pdf';
    doc.save(name);
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function cssEsc(s) { return String(s).replace(/["\\]/g, '\\$&'); }

  // ---------- Geräte-Übersicht & manuelles Koppeln (§6) ----------
  function statusTxt(s) { return s === 'active' ? 'aktiv' : s === 'standby' ? 'Standby' : s === 'connected' ? 'verbunden' : s === 'error' ? 'Fehler' : 'offline'; }
  function statusCol(s) { return s === 'active' ? '#35d69a' : s === 'standby' ? '#ffc23c' : s === 'error' ? '#ff5470' : '#8ba0b6'; }
  function roleTxt(r) { return r === 'monitor' ? 'Monitor' : r === 'anesthesia' ? 'Narkose/Kapno' : r === 'capno' ? 'Kapnograf' : 'Kombi'; }
  function openPairing() { pairingOpen = true; var el = $('#pairing'); if (el) el.classList.add('open'); renderPairing(); }
  function closePairing() { pairingOpen = false; var el = $('#pairing'); if (el) el.classList.remove('open'); }

  function renderPairing() {
    var host = $('#pairing'); if (!host) return;
    var devs = state.devices || [];
    var rows = devs.map(function (d) {
      var sp = spOf(d.species), m = d.meta || {};
      var pat = d.patientId ? esc(d.patientId) : (d.species ? (sp.name + ' ' + (d.weightKg || '?') + 'kg') : '—');
      var paired = d.manualKey ? '<span class="pk">🔗 gekoppelt</span>' : '';
      return '<div class="pdev" data-id="' + esc(d.deviceId) + '">' +
        '<label class="pcheck"><input type="checkbox" data-sel="' + esc(d.deviceId) + '"' + (pairSel[d.deviceId] ? ' checked' : '') + '></label>' +
        '<span class="pstat" style="--sc:' + statusCol(d.status) + '" title="' + statusTxt(d.status) + '"></span>' +
        '<div class="pinfo"><b>' + esc(d.model || 'Gerät') + '</b> <span class="prole">' + roleTxt(d.role) + '</span> ' + paired +
        '<div class="pmuted">Patient: ' + pat + ' · ' + statusTxt(d.status) + '</div></div>' +
        '<div class="pmeta">' + spSelect(m.species || d.species) +
        '<input class="pw" type="number" step="0.1" placeholder="kg" value="' + (m.weightKg || '') + '" data-mw="' + esc(d.deviceId) + '">' +
        '<input class="pid" placeholder="Patient-ID" value="' + esc(m.patientId || '') + '" data-mid="' + esc(d.deviceId) + '">' +
        '<button class="vsx-btn pmset" data-meta="' + esc(d.deviceId) + '">✓ setzen</button></div></div>';
    }).join('') || '<p class="pmuted" style="padding:16px">Noch keine Geräte erkannt. Sobald ein Monitor/Kapnograf verbunden ist (Serveradresse am Gerät = PC-IP), erscheint er hier.</p>';
    host.innerHTML = '<div class="pbox"><div class="phead"><h2>🔌 Geräte &amp; Koppeln</h2><div style="flex:1"></div>' +
      '<button class="vsx-btn" id="pClose">✕</button></div>' +
      '<p class="pmuted" style="margin:0 0 10px">Geräte werden automatisch erkannt und pro Patient zusammengeführt. Stimmt die Zuordnung nicht (z.B. keine Patienten-ID am Gerät): Geräte ankreuzen und <b>koppeln</b> — oder Tierart/Gewicht/ID direkt setzen.</p>' +
      '<div class="plist">' + rows + '</div>' +
      '<div class="pfoot"><button class="vsx-btn" id="pMerge">🔗 Ausgewählte zu 1 Patienten koppeln</button>' +
      '<button class="vsx-btn" id="pUnmerge">✂ Kopplung aufheben</button>' +
      '<div style="flex:1"></div><button class="vsx-btn" id="pClose2">Schließen</button></div></div>';
    host.querySelector('#pClose').onclick = host.querySelector('#pClose2').onclick = closePairing;
    host.querySelectorAll('[data-sel]').forEach(function (cb) { cb.onchange = function () { pairSel[cb.getAttribute('data-sel')] = cb.checked; }; });
    host.querySelectorAll('[data-meta]').forEach(function (b) { b.onclick = function () { applyMeta(b.getAttribute('data-meta'), host); }; });
    host.querySelector('#pMerge').onclick = mergeSelected;
    host.querySelector('#pUnmerge').onclick = unmergeSelected;
  }
  function spSelect(cur) {
    var opts = (A().species || []).map(function (s) { return '<option value="' + s.id + '"' + (s.id === cur ? ' selected' : '') + '>' + s.icon + ' ' + s.name + '</option>'; }).join('');
    return '<select class="psp"><option value="">Art…</option>' + opts + '</select>';
  }
  function applyMeta(id, host) {
    var row = host.querySelector('.pdev[data-id="' + cssEsc(id) + '"]'); if (!row) return;
    var sp = row.querySelector('.psp').value || null;
    var w = parseFloat(row.querySelector('.pw').value); if (isNaN(w)) w = null;
    var pid = row.querySelector('.pid').value.trim() || null;
    send({ type: 'setMeta', deviceId: id, meta: { species: sp, weightKg: w, patientId: pid } });
    var btn = row.querySelector('.pmset'); if (btn) { btn.textContent = '✓ gesetzt'; setTimeout(function () { btn.textContent = '✓ setzen'; }, 1400); }
  }
  function selectedIds() { return Object.keys(pairSel).filter(function (k) { return pairSel[k]; }); }
  function mergeSelected() { var ids = selectedIds(); if (!ids.length) return; send({ type: 'pair', deviceIds: ids, patientKey: 'pair:' + ids[0] }); pairSel = {}; }
  function unmergeSelected() {
    var keys = {};
    (state.devices || []).forEach(function (d) { if (pairSel[d.deviceId] && d.manualKey) keys[d.manualKey] = 1; });
    Object.keys(keys).forEach(function (k) { send({ type: 'unpair', patientKey: k }); });
    pairSel = {};
  }

  // ---------- Boot ----------
  window.VSAPP = { getDevices: function () { return state.devices; }, getPatients: function () { return state.patients; }, send: send };
  var ab = $('#vsxAdmin'); if (ab) ab.onclick = function () { if (window.VSADMIN) window.VSADMIN.open(); };
  var pb = $('#vsxPdf'); if (pb) pb.onclick = exportPDF;
  var db = $('#vsxDevices'); if (db) db.onclick = openPairing;
  connect();
})();
