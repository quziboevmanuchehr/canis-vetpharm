'use strict';
/*
 * simulator.js — Simulator-Adapter (Test/Demo ohne echte Geraete, §11.1).
 * Erzeugt fuer mehrere virtuelle Patienten je einen Monitor- UND einen Kapno/Narkose-Frame
 * mit DERSELBEN patientId -> demonstriert Auto-Discovery, Patienten-Zuordnung (§6) und
 * Zwei-Fenster-Ansicht. Vitalwerte driften realistisch auf das Szenario-Ziel zu.
 *
 * READ-ONLY: es werden nur Daten erzeugt, nie an ein reales Geraet gesendet.
 */
const { Adapter } = require('./base');
const { targetFor, byId } = require('../scenarios');

function rnd(a) { return (Math.random() * 2 - 1) * a; }

// Standard-Demo-Patienten (verschiedene Arten, fuer Split-View + Matching-Test).
// Zeigt bewusst die ART-VIELFALT (nicht nur Hund): Hund, Katze, Kaninchen, Reptil.
// Weitere Arten (meerschwein/chinchilla/degu/frettchen) via devices.json cloud/adapter-'patients' setzbar.
function defaultPatients() {
  return [
    { devId: 'SIM-MON-1', patientId: 'A-102', species: 'hund', weightKg: 22, scenarioId: 'normal',
      monModel: 'uMEC12 Vet (Sim)', capModel: 'Veta 5 Plus (Sim)' },
    { devId: 'SIM-MON-2', patientId: 'C-077', species: 'katze', weightKg: 4.2, scenarioId: 'normal',
      monModel: 'LifeVet 10C (Sim)', capModel: 'LifeVet 10C Kapno (Sim)' },
    { devId: 'SIM-MON-3', patientId: 'K-210', species: 'kaninchen', weightKg: 2.5, scenarioId: 'normal',
      monModel: 'uMEC12 Vet (Sim)', capModel: 'Veta 5 Plus (Sim)' },
    { devId: 'SIM-MON-4', patientId: 'R-018', species: 'reptil', weightKg: 0.4, scenarioId: 'normal',
      monModel: 'LifeVet 10C (Sim)', capModel: 'LifeVet 10C Kapno (Sim)' },
  ];
}

class SimulatorAdapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.rateMs = cfg.rateMs || 1000;
    this.patients = (cfg.patients || defaultPatients()).map(p => this._init(p));
    this.timer = null;
  }

  _init(p) {
    const t = targetFor(p.scenarioId, p.species, p.weightKg);
    return {
      devId: p.devId, patientId: p.patientId, species: p.species, weightKg: p.weightKg,
      monModel: p.monModel || 'Monitor (Sim)', capModel: p.capModel || 'Kapno (Sim)',
      scenarioId: p.scenarioId,
      cur: Object.assign({}, t), // Startzustand = Szenario-Ziel
    };
  }

  describe() {
    return { id: this.id, model: 'VetStation Simulator', role: 'combo' };
  }

  async connect() {
    this.connected = true;
    this.ctx.log && this.ctx.log.info('simulator', 'Simulator gestartet mit ' + this.patients.length + ' Patient(en), ' + this.rateMs + ' ms.');
    this.timer = setInterval(() => this._tick(), this.rateMs);
    this._tick();
  }

  dispose() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.connected = false;
  }

  // Externe Steuerung (UI -> Bridge SCENARIO).
  setScenario(patientId, scenarioId) {
    const p = this.patients.find(x => x.patientId === patientId);
    if (!p || !byId[scenarioId]) return false;
    p.scenarioId = scenarioId;
    return true;
  }

  listPatients() {
    return this.patients.map(p => ({ patientId: p.patientId, species: p.species, weightKg: p.weightKg, scenarioId: p.scenarioId }));
  }

  _tick() {
    const now = Date.now();
    for (const p of this.patients) {
      const target = targetFor(p.scenarioId, p.species, p.weightKg);
      const c = p.cur;
      // Sanftes Einschwingen auf Zielwerte (arrest schneller).
      const ease = (p.scenarioId === 'vfib' || p.scenarioId === 'asystolie') ? 0.6 : 0.3;
      ['hr', 'spo2', 'etco2', 'fico2', 'af', 'sys', 'dia', 'map', 'temp', 'isoPct'].forEach(k => {
        if (typeof target[k] === 'number') c[k] = c[k] + (target[k] - c[k]) * ease;
      });
      // Diskrete Zustaende hart uebernehmen.
      c.rhythm = target.rhythm; c.capnoShape = target.capnoShape; c.pleth = target.pleth;

      // Messrauschen.
      const hr = Math.max(0, Math.round(c.hr + rnd(c.hr > 0 ? 2 : 0)));
      const spo2 = Math.max(0, Math.min(100, Math.round(c.spo2 + rnd(0.6))));
      const etco2 = Math.max(0, Math.round(c.etco2 + rnd(1)));
      const af = Math.max(0, Math.round(c.af + rnd(af0(c.af))));
      const sys = c.sys > 0 ? Math.round(c.sys + rnd(3)) : 0;
      const dia = c.dia > 0 ? Math.round(c.dia + rnd(2)) : 0;
      const map = sys > 0 && dia > 0 ? Math.round(dia + (sys - dia) / 3) : Math.round(c.map);
      const temp = Math.round((c.temp + rnd(0.05)) * 10) / 10;

      // --- Monitor-Frame (Kreislauf/EKG/SpO2) ---
      this.emit({
        deviceId: p.devId, deviceModel: p.monModel, deviceRole: 'monitor',
        patientId: p.patientId, species: p.species, weightKg: p.weightKg, ts: now,
        vitals: { hr, ekgRhythm: c.rhythm, spo2, pleth: c.pleth, nibp: { sys, dia, map }, temp },
        alarms: [],
      });

      // --- Kapno/Narkose-Frame (Atmung/EtCO2 + gemeldete Iso%) ---
      this.emit({
        deviceId: p.devId.replace('MON', 'CAP'), deviceModel: p.capModel, deviceRole: 'anesthesia',
        patientId: p.patientId, species: p.species, weightKg: p.weightKg, ts: now,
        vitals: { etco2, fico2: Math.max(0, Math.round(c.fico2)), af, capnoShape: c.capnoShape, ekgRhythm: c.rhythm },
        isoPct: Math.round(c.isoPct * 10) / 10, ventMode: c.isoPct > 0 ? 'Kreissystem' : null,
        alarms: [],
      });
    }
  }
}

function af0(v) { return v > 0 ? 1 : 0; }

module.exports = { SimulatorAdapter, defaultPatients };
