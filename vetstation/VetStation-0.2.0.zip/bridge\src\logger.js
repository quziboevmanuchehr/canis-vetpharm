'use strict';
/*
 * logger.js — Lokales Diagnose-Log (Technik/Verbindung, §14.4).
 * Schreibt anonymisierte Ereignisse in data/diag.log (lokal, keine Cloud) und haelt
 * einen Ringpuffer der letzten Ereignisse fuer den Admin-Bereich vor. Wird zusaetzlich
 * ueber den WebSocket als MSG.DIAG an die UI gesendet.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = path.join(DATA_DIR, 'diag.log');
const MAX_RING = 500;

const ring = [];
let sink = null; // Funktion, die Ereignisse an die UI weiterreicht (MSG.DIAG)

function ensureDir() {
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (_) {}
}

function setSink(fn) { sink = fn; }

function log(level, source, msg, extra) {
  const ev = { ts: Date.now(), level: level, source: source, msg: String(msg) };
  if (extra !== undefined) ev.extra = extra;
  ring.push(ev);
  if (ring.length > MAX_RING) ring.shift();
  const line = new Date(ev.ts).toISOString() + ' [' + level + '] ' + source + ': ' + ev.msg;
  // Konsole
  if (level === 'error') console.error(line); else console.log(line);
  // Datei (best effort, blockiert nie den Datenfluss)
  try { ensureDir(); fs.appendFile(LOG_FILE, line + '\n', () => {}); } catch (_) {}
  // UI
  if (sink) { try { sink(ev); } catch (_) {} }
  return ev;
}

module.exports = {
  setSink,
  recent(n) { return ring.slice(-(n || 100)); },
  info: (s, m, e) => log('info', s, m, e),
  warn: (s, m, e) => log('warn', s, m, e),
  error: (s, m, e) => log('error', s, m, e),
};
