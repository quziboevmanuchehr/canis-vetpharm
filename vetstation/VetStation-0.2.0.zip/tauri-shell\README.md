# VetStation — Tauri-Shell (Produktions-Packaging: signierte MSI + Auto-Update)

Dieser Ordner ist das **Gerüst** für die spätere, „appliance-artige" Auslieferung als **Tauri**-App
(WebView2, sehr RAM-schonend — ideal für den i3/8-GB-Ziel-PC), inkl. **MSI/NSIS-Installer** und
**signiertem Auto-Update**. Er ersetzt den sofort lauffähigen Edge-Kiosk (`kiosk/launch-kiosk.ps1`),
sobald die Rust-Toolchain installiert ist.

> **Status:** Gerüst. Auf diesem PC ist **kein Rust/Tauri** installiert. Solange läuft der
> **Edge-WebView2-Kiosk** (identische UI, gleiche WebView2-Runtime). Tauri ist der Weg zum
> signierten MSI + eingebautem Updater.

## Voraussetzungen (einmalig)
1. **Rust** installieren: https://rustup.rs (ca. 1–2 GB inkl. MSVC Build Tools; „Desktop development with C++").
2. **Tauri CLI**: `cargo install tauri-cli --version "^2"` (oder `npm i -g @tauri-apps/cli@^2`).
3. WebView2-Runtime: auf diesem PC bereits vorhanden (Evergreen); der Installer bündelt sie sonst mit.

## Aufbau
- `tauri.conf.json` — Fenster (Vollbild/kiosk-artig), Bundle-Targets (msi/nsis), Updater-Endpoint.
- `src/main.rs` — startet die **Bridge (Node)** als Kindprozess und öffnet dann das Vollbildfenster auf `http://127.0.0.1:8770`.
- `Cargo.toml` — Rust-Abhängigkeiten (tauri v2 + updater-Plugin).

Zwei Betriebsmodelle:
- **(A) Node als Sidecar** (empfohlen für 1 Klick): Node-Runtime mitliefern und die Bridge aus der App
  starten. Dazu Node-Binary als `externalBin`/Sidecar einbinden (siehe Tauri-Doku „Embedding External Binaries").
- **(B) Node vorausgesetzt**: Bridge separat per Autostart (`kiosk/install-autostart.ps1`), Tauri zeigt nur das Fenster.

## Bauen
```bash
# im Projektwurzelverzeichnis
cargo tauri init         # falls src-tauri noch nicht existiert; danach Inhalte hierher übernehmen
cargo tauri build        # erzeugt die MSI/NSIS in target/release/bundle/
```

## Auto-Update
1. Signaturschlüssel erzeugen: `cargo tauri signer generate -w vetstation.key`
2. Öffentlichen Schlüssel in `tauri.conf.json` → `plugins.updater.pubkey` eintragen.
3. Bei jedem Release die signierten Artefakte + `latest.json` auf den in `endpoints` genannten Ort legen
   (z. B. GitHub Pages/Releases). Der Kiosk prüft beim Start und aktualisiert sich selbst.

> Klinische Daten (Medikamente/Zwischenfälle/Logik) aktualisieren sich **unabhängig davon**
> bereits zur Laufzeit über `ui/engine/clinical-data-loader.js` (Pull vom Live-canis-vetpharm).
> Der Tauri-Updater betrifft nur die App-Shell (Bridge/Adapter/UI-Code).
