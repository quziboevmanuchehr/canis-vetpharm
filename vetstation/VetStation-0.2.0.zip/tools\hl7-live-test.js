'use strict';
/*
 * hl7-live-test.js — Live-Test des HL7-Listeners ueber echtes TCP + MLLP:
 * startet den HL7Adapter, ein "Fake-uMEC" verbindet sich und pusht eine gerahmte ORU^R01,
 * und wir pruefen, dass der Adapter ein Frame mit den richtigen Werten emittiert.
 *   node tools/hl7-live-test.js
 */
const net = require('net');
const { HL7Adapter } = require('../bridge/src/adapters/hl7');

const PORT = 5099;
const VT = 0x0b, FS = 0x1c, CR = 0x0d;
const MSG = [
  'MSH|^~\\&|Mindray|Gateway|||||ORU^R01|7|P|2.3.1|',
  'PID|||A-102||Bella^||20200101|M|||^^^^|||',
  'OBR||||Mindray Monitor|||20260706172815|',
  'OBX||NM|101^HR|2101|101||||||F',
  'OBX||NM|160^SpO2|2103|97||||||F',
  'OBX||NM|170^Sys|2105|118||||||F',
  'OBX||NM|171^Dia|2105|74||||||F',
  'OBX||NM|172^Mean|2105|89||||||F',
  'OBX||NM|220^CO2|2109|41||||||F',
  'OBX||NM|222^AWRR|2109|13||||||F',
  'OBX||NM|51^Weight||22.0||||||F',
].join('\r');
function mllp(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }

const frames = [];
const ctx = { emit: (f) => frames.push(f), log: { info: () => {}, warn: () => {}, error: () => {} } };
const adapter = new HL7Adapter({ id: 'umec12', listenPort: PORT, model: 'uMEC12 Vet', species: 'hund' }, ctx);

(async () => {
  await adapter.connect();
  const client = net.connect(PORT, '127.0.0.1', () => { client.write(mllp(MSG)); });
  client.on('error', (e) => { console.error('client err', e.message); process.exit(1); });
  setTimeout(() => {
    let fails = 0;
    const f = frames[0];
    const ok = (c, d) => { if (c) console.log('  ✓ ' + d); else { fails++; console.log('  ✗ FAIL: ' + d); } };
    console.log('== HL7 Live-TCP-Test (Port ' + PORT + ') ==');
    ok(frames.length >= 1, 'Listener empfaengt gerahmte HL7-Nachricht ueber TCP');
    ok(f && f.vitals.hr === 101, 'HR = 101');
    ok(f && f.vitals.etco2 === 41, 'EtCO2 = 41');
    ok(f && f.vitals.nibp.map === 89, 'MAP = 89');
    ok(f && f.weightKg === 22, 'Gewicht = 22 kg');
    ok(f && f.deviceModel === 'uMEC12 Vet', 'Modellname uebernommen');
    console.log('\n== ' + (frames.length ? (7 - fails) + ' OK, ' + fails + ' FAIL' : 'kein Frame') + ' ==');
    client.end(); adapter.dispose();
    process.exit(fails ? 1 : 0);
  }, 600);
})();
