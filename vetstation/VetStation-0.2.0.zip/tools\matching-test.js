'use strict';
/*
 * matching-test.js — §6/§12 Patienten-Zuordnung headless abgesichert (Audit H12).
 * Gleiche Patienten-ID an Monitor + Kapno -> EIN zusammengefuehrter Patient (rollengewichtete Vitals);
 * verschiedene IDs -> getrennte Patienten; manuelles Koppeln fuehrt zwei Geraete zusammen.
 * Start: node tools/matching-test.js
 */
const { normalizeFrame } = require('../bridge/src/model');
const { mergePatients } = require('../bridge/src/matching');

let pass = 0, fail = 0;
function ok(n, c, e) { if (c) { pass++; console.log('  ✓ ' + n); } else { fail++; console.log('  ✗ ' + n + (e ? '  -> ' + e : '')); } }

function rec(deviceId, raw) { const r = normalizeFrame(raw); return { deviceId: deviceId, frame: r.frame }; }
const now = Date.now();

// Monitor liefert Kreislauf/EKG, Kapno/Narkose liefert Atmung/EtCO2 — beide am selben Patienten (ID B-1).
const monitor = rec('MON-1', { deviceId: 'MON-1', deviceModel: 'uMEC12 Vet', deviceRole: 'monitor',
  patientId: 'B-1', species: 'hund', weightKg: 20, ts: now,
  vitals: { hr: 88, spo2: 97, nibp: { sys: 110, dia: 70 }, temp: 38.1, etco2: 999 } });
const capno = rec('CAP-1', { deviceId: 'CAP-1', deviceModel: 'Veta 5 Plus', deviceRole: 'anesthesia',
  patientId: 'B-1', species: 'hund', weightKg: 20, ts: now + 1,
  vitals: { etco2: 42, fico2: 2, af: 12, hr: 40 }, isoPct: 2.0 });

console.log('Patienten-Zuordnung (Matching) — Selbsttest\n');

// ---- 1) Gleiche ID -> EIN Patient ----
let p = mergePatients([monitor, capno], {});
ok('gleiche Patienten-ID (Monitor+Kapno) → genau 1 Patient', p.length === 1, 'length=' + p.length);
if (p.length === 1) {
  const v = p[0].vitals;
  ok('rollengewichtet: HR vom MONITOR (88, nicht Kapno 40)', v.hr === 88, 'hr=' + v.hr);
  ok('rollengewichtet: EtCO2 vom KAPNO (42)', v.etco2 === 42, 'etco2=' + v.etco2);
  ok('Atemfrequenz vom Kapno übernommen (12)', v.af === 12, 'af=' + v.af);
  ok('NIBP/MAP vom Monitor abgeleitet', v.map === Math.round(70 + (110 - 70) / 3), 'map=' + v.map);
  ok('isoPct des Narkosegeräts übernommen (2.0)', p[0].isoPct === 2.0, 'iso=' + p[0].isoPct);
  ok('beide Geräte dem Patienten zugeordnet', p[0].devices.length === 2, 'devices=' + p[0].devices.length);
}

// ---- 2) Verschiedene ID -> ZWEI Patienten ----
const capnoOther = rec('CAP-2', { deviceId: 'CAP-2', deviceModel: 'Veta 5 Plus', deviceRole: 'anesthesia',
  patientId: 'C-9', species: 'katze', weightKg: 4, ts: now, vitals: { etco2: 38, af: 20 } });
p = mergePatients([monitor, capnoOther], {});
ok('verschiedene Patienten-IDs → 2 getrennte Patienten', p.length === 2, 'length=' + p.length);

// ---- 3) Kein ID, aber gleiche Art+Gewicht-Bucket -> zusammen; anderes Gewicht -> getrennt ----
const a = rec('X1', { deviceId: 'X1', deviceModel: 'M', deviceRole: 'monitor', species: 'hund', weightKg: 10, ts: now, vitals: { hr: 90 } });
const b = rec('X2', { deviceId: 'X2', deviceModel: 'C', deviceRole: 'anesthesia', species: 'hund', weightKg: 10, ts: now, vitals: { etco2: 40 } });
const c = rec('X3', { deviceId: 'X3', deviceModel: 'C', deviceRole: 'anesthesia', species: 'hund', weightKg: 30, ts: now, vitals: { etco2: 40 } });
ok('ohne ID: gleiche Art+Gewicht → 1 Patient', mergePatients([a, b], {}).length === 1);
ok('ohne ID: anderes Gewicht → 2 Patienten', mergePatients([a, c], {}).length === 2);

// ---- 4) Manuelles Koppeln: zwei sonst getrennte Geräte auf einen Patienten ----
const m1 = rec('D1', { deviceId: 'D1', deviceModel: 'Mon', deviceRole: 'monitor', species: 'hund', weightKg: 12, ts: now, vitals: { hr: 100 } });
const m2 = rec('D2', { deviceId: 'D2', deviceModel: 'Cap', deviceRole: 'anesthesia', species: 'katze', weightKg: 5, ts: now, vitals: { etco2: 41 } });
ok('ohne Koppeln: unterschiedliche Art/Gewicht → 2 Patienten', mergePatients([m1, m2], {}).length === 2);
const manual = { D1: 'paired-1', D2: 'paired-1' };
const paired = mergePatients([m1, m2], manual);
ok('manuelles Koppeln (pair) → 1 zusammengeführter Patient', paired.length === 1, 'length=' + paired.length);
ok('gekoppelter Patient ist als manual markiert', paired[0] && paired[0].manual === true);

console.log('\n== Ergebnis: ' + pass + ' OK, ' + fail + ' FAIL ==');
process.exit(fail ? 1 : 0);
