; vetstation-setup.iss — Inno Setup Skript fuer einen echten Doppelklick-Installer VetStation-Setup.exe
; Voraussetzung: vorher `installer\make-dist.ps1` ausfuehren (erzeugt dist\VetStation inkl. portablem Node).
; Bauen: iscc installer\vetstation-setup.iss   (Inno Setup: https://jrsoftware.org/isinfo.php)

#define AppName "VetStation"
#define AppVersion "0.1.0"
#define AppPublisher "VetStation"
#define SrcDir "..\dist\VetStation"

[Setup]
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName=C:\VetStation
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputBaseFilename=VetStation-Setup
OutputDir=..\dist
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern

[Languages]
Name: "de"; MessagesFile: "compiler:Languages\German.isl"

[Files]
Source: "{#SrcDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\VetStation starten"; Filename: "{app}\START-VetStation.bat"
Name: "{group}\LAN-Anleitung"; Filename: "{app}\docs\LAN-SETUP.md"
Name: "{commondesktop}\VetStation"; Filename: "{app}\START-VetStation.bat"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Desktop-Verknuepfung"; Flags: unchecked
Name: "autostart"; Description: "Autostart-Kiosk beim Anmelden einrichten (empfohlen)"

[Run]
; Autostart-Kiosk + Watchdog registrieren
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\kiosk\install-autostart.ps1"" -Port 8770"; \
  Tasks: autostart; Flags: runhidden; StatusMsg: "Richte Autostart-Kiosk ein..."
; Direkt nach Installation einmal starten (optional)
Filename: "{app}\START-VetStation.bat"; Description: "VetStation jetzt starten"; Flags: postinstall shellexec skipifsilent

[UninstallRun]
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\kiosk\install-autostart.ps1"" -Remove"; Flags: runhidden; RunOnceId: "RemoveAutostart"
