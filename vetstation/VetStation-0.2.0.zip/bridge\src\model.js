'use strict';
/*
 * model.js — Gemeinsames normalisiertes Datenmodell (Schicht 1 -> Schicht 2/3).
 * Jeder Geraete-Adapter liefert Frames GENAU in diesem Format ("ingest"-Modell aus §5 des Auftrags).
 * Species-IDs sind identisch zur Web-App (anaes-data.js), damit die Brain-Logik 1:1 wiederverwendet wird.
 */

// Kanonische Tierart-IDs (identisch zu window.ANAES.species in der Web-App).
const SPECIES = ['hund', 'katze', 'kaninchen', 'meerschwein', 'chinchilla', 'degu', 'frettchen', 'reptil'];

// Gueltige EKG-Rhythmus-IDs (= window.ANAES.ekg[].id). Die Brain-Regeln keyen darauf.
const EKG_RHYTHMS = ['sinus', 'sinusbrady', 'sinustachy', 'avb1', 'avb2a', 'avb2b', 'avb3', 'sves', 'ves', 'vtach', 'afib', 'aflutter', 'vfib', 'asys'];

// Kapnograf-Kurvenformen (= wCapno-Typen der Web-App). 'shark'/'baseline' schalten die Bronchospasmus-/Rueckatmungs-Analyse frei.
const CAPNO_SHAPES = ['normal', 'high', 'low', 'baseline', 'shark', 'flat'];

// Pleth-Formen (SpO2-Kurve).
const PLETH_SHAPES = ['normal', 'weak', 'flat'];

// Geraeterollen.
const DEVICE_ROLES = ['monitor', 'anesthesia', 'capno', 'combo'];

// Verbindungsstatus wie an einer IDEXX-Station.
const STATUS = ['connected', 'active', 'standby', 'error', 'offline'];

// WebSocket-Nachrichtentypen (Bridge -> UI und UI -> Bridge).
const MSG = {
  HELLO: 'hello',        // Bridge -> UI: Begruessung + Version
  DEVICES: 'devices',    // Bridge -> UI: aktuelle Geraeteliste (+Status)
  PATIENTS: 'patients',  // Bridge -> UI: pro-Patient zusammengefuehrte Datensaetze
  FRAME: 'frame',        // Bridge -> UI: einzelner Roh-Frame (optional/Diagnose)
  DIAG: 'diag',          // Bridge -> UI: Diagnose-/Verbindungsereignis (fuer Admin)
  // UI -> Bridge (Steuerung — veraendert NUR die Bridge/Zuordnung, NIE die Geraete):
  PAIR: 'pair',          // manuelles Koppeln Monitor<->Kapno<->Patient
  UNPAIR: 'unpair',
  SET_META: 'setMeta',   // Tierart/Gewicht/Patient-ID nachtragen, wenn Geraet sie nicht liefert
  SCENARIO: 'scenario',  // Simulator-Szenario setzen (nur Test/Demo)
  ACK: 'ack',
};

function isSpecies(s) { return SPECIES.indexOf(s) >= 0; }

function num(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : parseFloat(String(v).replace(',', '.'));
  return Number.isFinite(n) ? n : null;
}

function clamp(v, lo, hi) {
  if (v === null) return null;
  return Math.max(lo, Math.min(hi, v));
}

function emptyVitals() {
  return {
    hr: null, ekgRhythm: null, spo2: null, pleth: null,
    etco2: null, fico2: null, paw: null, af: null,
    nibp: { sys: null, dia: null, map: null }, temp: null, capnoShape: null,
  };
}

/*
 * normalizeFrame(raw) -> { frame, warnings }
 * Vervollstaendigt Defaults, coerct Typen, plausibilisiert Werte, leitet MAP aus SYS/DIA ab.
 * warnings[] wird als Diagnose an den Admin-Bereich gemeldet (Datenqualitaet §14.5).
 */
function normalizeFrame(raw) {
  const warnings = [];
  const v = raw.vitals || {};
  const nibp = v.nibp || {};

  let sys = num(nibp.sys);
  let dia = num(nibp.dia);
  let map = num(nibp.map);
  if (map === null && sys !== null && dia !== null) {
    map = Math.round(dia + (sys - dia) / 3); // MAP ~= DIA + (SYS-DIA)/3 (wie Web-App)
  }

  let species = raw.species;
  if (species && !isSpecies(species)) {
    warnings.push('unbekannte Tierart "' + species + '" -> null');
    species = null;
  }

  let rhythm = v.ekgRhythm;
  if (rhythm && EKG_RHYTHMS.indexOf(rhythm) < 0) {
    warnings.push('unbekannter EKG-Rhythmus "' + rhythm + '"');
    rhythm = null;
  }
  let capnoShape = v.capnoShape;
  if (capnoShape && CAPNO_SHAPES.indexOf(capnoShape) < 0) {
    warnings.push('unbekannte Kapno-Form "' + capnoShape + '"');
    capnoShape = null;
  }

  // Plausibilitaet (nur warnen, Werte nicht verwerfen — der Tierarzt entscheidet).
  const spo2 = clamp(num(v.spo2), 0, 100);
  const hr = clamp(num(v.hr), 0, 400);
  const etco2 = clamp(num(v.etco2), 0, 150);
  const af = clamp(num(v.af != null ? v.af : v.rr), 0, 120);
  const temp = clamp(num(v.temp), 5, 46);
  const fico2 = clamp(num(v.fico2), 0, 60);

  // Kapno-Form aus Messwerten ableiten, wenn das Geraet keine Kurvenform liefert (echte HL7-Geraete):
  // erhoehtes eingeatmetes CO2 (FiCO2 > 5 mmHg) = RUECKATMUNG -> 'baseline' (Absorber/Frischgas pruefen).
  // 'shark' (Bronchospasmus) braucht eine Waveform-Steilheitsanalyse und bleibt daher geraeteabhaengig.
  if (capnoShape == null && fico2 != null && fico2 > 5) capnoShape = 'baseline';

  // Datenqualitaet (§14): unplausible/widerspruechliche Rohwerte melden (nur warnen, nie verwerfen).
  const rSpo2 = num(v.spo2), rHr = num(v.hr), rEt = num(v.etco2), rTemp = num(v.temp), rAf = num(v.af != null ? v.af : v.rr);
  if (rSpo2 != null && (rSpo2 < 0 || rSpo2 > 100)) warnings.push('SpO2 unplausibel (' + rSpo2 + ' %) — Sensor/Parser pruefen');
  if (rHr != null && (rHr < 0 || rHr > 400)) warnings.push('HF unplausibel (' + rHr + '/min)');
  if (rEt != null && rEt > 150) warnings.push('EtCO2 unplausibel (' + rEt + ' mmHg)');
  if (rTemp != null && (rTemp < 5 || rTemp > 46)) warnings.push('Temperatur unplausibel (' + rTemp + ' °C)');
  if (rAf != null && rAf > 120) warnings.push('Atemfrequenz unplausibel (' + rAf + '/min)');
  if ((rHr === 0 || rHr == null) && rSpo2 != null && rSpo2 > 50) warnings.push('SpO2 vorhanden trotz fehlender Pulsrate — Sensor/Bewegungsartefakt pruefen');

  const frame = {
    deviceId: String(raw.deviceId || 'unknown'),
    deviceModel: raw.deviceModel || 'Unbekannt',
    deviceRole: DEVICE_ROLES.indexOf(raw.deviceRole) >= 0 ? raw.deviceRole : 'monitor',
    patientId: raw.patientId != null ? String(raw.patientId) : null,
    species: species || null,
    weightKg: num(raw.weightKg),
    ts: num(raw.ts) || Date.now(),
    vitals: {
      hr, ekgRhythm: rhythm || null, spo2,
      pleth: PLETH_SHAPES.indexOf(v.pleth) >= 0 ? v.pleth : null,
      etco2, fico2,
      paw: num(v.paw), af,
      nibp: { sys, dia, map }, temp,
      capnoShape: capnoShape || null,
    },
    ventMode: raw.ventMode || null,
    isoPct: num(raw.isoPct),
    alarms: Array.isArray(raw.alarms) ? raw.alarms.slice(0, 12) : [],
    // waveforms werden bewusst NICHT uebertragen: die UI synthetisiert Kurven aus
    // Vitalwerten (wEkg/wCapno/wPleth), das spart Bandbreite/RAM (siehe ARCHITECTURE.md).
  };
  return { frame, warnings };
}

/*
 * patientKey(frame) — Schluessel fuer die Patienten-Zuordnung (§6).
 * 1) Patienten-ID vom Geraet (bevorzugt), sonst
 * 2) Tierart + gerundetes Gewicht (Bucket), sonst
 * 3) Geraet bleibt ungepaart (eigener Patient = deviceId).
 */
function patientKey(frame) {
  if (frame.patientId) return 'id:' + frame.patientId;
  if (frame.species && frame.weightKg) {
    return 'sw:' + frame.species + ':' + roundWeightBucket(frame.weightKg);
  }
  return 'dev:' + frame.deviceId;
}

function roundWeightBucket(w) {
  // Tolerante Buckets: kleine Tiere fein, grosse grob (Gewicht schwankt am Monitor).
  if (w < 1) return Math.round(w * 10) / 10;      // 0.1 kg Schritte
  if (w < 10) return Math.round(w * 2) / 2;       // 0.5 kg Schritte
  return Math.round(w);                            // 1 kg Schritte
}

module.exports = {
  SPECIES, EKG_RHYTHMS, CAPNO_SHAPES, PLETH_SHAPES, DEVICE_ROLES, STATUS, MSG,
  isSpecies, num, clamp, emptyVitals, normalizeFrame, patientKey, roundWeightBucket,
};
