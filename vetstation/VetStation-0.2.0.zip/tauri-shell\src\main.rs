// main.rs — Tauri-Einstieg (Gerüst). Startet die VetStation-Bridge (Node) als Kindprozess
// und öffnet dann das Vollbild-Kioskfenster auf der lokalen UI. STRIKT READ-ONLY zu Geräten.
//
// Hinweis: Dies ist ein Gerüst für den späteren Tauri-Build (benötigt Rust/Tauri v2).
// Betriebsmodell (A) Node-Sidecar oder (B) Node vorausgesetzt — siehe tauri-shell/README.md.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::process::Command;

fn start_bridge() {
    // Variante (B): setzt eine vorhandene Node-Installation voraus und startet die Bridge.
    // Für Variante (A) stattdessen die als Sidecar gebündelte Node-Runtime via tauri Shell/Command starten.
    let _ = Command::new("node")
        .arg("bridge/src/index.js")
        .env("PORT", "8770")
        .spawn();
}

fn wait_for_bridge() {
    // Einfaches Warten auf die Bridge (max ~16 s).
    for _ in 0..40 {
        if std::net::TcpStream::connect("127.0.0.1:8770").is_ok() {
            return;
        }
        std::thread::sleep(std::time::Duration::from_millis(400));
    }
}

fn main() {
    start_bridge();
    wait_for_bridge();

    tauri::Builder::default()
        .plugin(tauri_plugin_updater::Builder::new().build())
        .run(tauri::generate_context!())
        .expect("Fehler beim Start der VetStation-Tauri-Shell");
}
