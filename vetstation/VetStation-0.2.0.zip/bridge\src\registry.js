'use strict';
/*
 * registry.js — Geraete-Registry + Auto-Discovery (§6.1). Geraete "erscheinen", sobald sie
 * Frames senden (wie eine IDEXX-Station). Verwaltet Status (active/standby/offline),
 * manuelles Koppeln, Meta-Overrides und leitet die Patienten-Zusammenfuehrung an.
 */
const { normalizeFrame } = require('./model');
const { mergePatients } = require('./matching');

const ACTIVE_MS = 5000;
const STANDBY_MS = 30000;

class Registry {
  constructor({ log }) {
    this.devices = new Map(); // deviceId -> { deviceId, model, role, frame, lastTs }
    this.manual = {};         // deviceId -> patientKey (manuelles Koppeln, §6.3)
    this.meta = {};           // deviceId -> { species, weightKg, patientId } Overrides (§6.3)
    this.log = log;
    this.adapters = [];
  }

  addAdapter(adapter) { this.adapters.push(adapter); }

  async start() {
    for (const a of this.adapters) {
      try { await a.connect(); }
      catch (e) { this.log.error('registry', 'Adapter ' + a.id + ' connect fehlgeschlagen: ' + (e && e.message)); }
    }
  }

  // Roh-Frame eines Adapters aufnehmen -> normalisieren -> Geraet aktualisieren.
  ingest(raw) {
    const ov = this.meta[raw.deviceId];
    if (ov) {
      if (ov.species) raw.species = ov.species;
      if (ov.weightKg) raw.weightKg = ov.weightKg;
      if (ov.patientId) raw.patientId = ov.patientId;
    }
    const { frame, warnings } = normalizeFrame(raw);
    let rec = this.devices.get(frame.deviceId);
    const isNew = !rec;
    if (isNew) rec = { deviceId: frame.deviceId };
    rec.model = frame.deviceModel;
    rec.role = frame.deviceRole;
    rec.frame = frame;
    rec.lastTs = frame.ts;
    this.devices.set(frame.deviceId, rec);
    if (isNew) this.log.info('discovery', 'Neues Geraet erkannt: ' + frame.deviceModel + ' [' + frame.deviceId + ', ' + frame.deviceRole + ']');
    if (warnings.length) warnings.forEach(w => this.log.warn('data', frame.deviceId + ': ' + w));
    return frame;
  }

  _status(rec, now) {
    const age = now - (rec.lastTs || 0);
    if (age < ACTIVE_MS) return 'active';
    if (age < STANDBY_MS) return 'standby';
    return 'offline';
  }

  getDevices() {
    const now = Date.now();
    return [...this.devices.values()].map(r => ({
      deviceId: r.deviceId, model: r.model, role: r.role,
      status: this._status(r, now),
      patientId: r.frame && r.frame.patientId,
      species: r.frame && r.frame.species,
      weightKg: r.frame && r.frame.weightKg,
      manualKey: this.manual[r.deviceId] || null,   // manuelle Kopplung (fuer die Koppel-UI)
      meta: this.meta[r.deviceId] || null,           // Tierart/Gewicht/ID-Override
      lastTs: r.lastTs,
    }));
  }

  getPatients() {
    const now = Date.now();
    const recs = [...this.devices.values()]
      .filter(r => this._status(r, now) !== 'offline')
      .map(r => ({ deviceId: r.deviceId, model: r.model, role: r.role, frame: r.frame }));
    return mergePatients(recs, this.manual);
  }

  // ---- Steuerung (veraendert nur Bridge/Zuordnung, NIE die Geraete) ----
  pair(deviceIds, patientKey) { (deviceIds || []).forEach(id => { this.manual[id] = patientKey; }); }
  unpair(patientKey) { for (const id in this.manual) if (this.manual[id] === patientKey) delete this.manual[id]; }
  setMeta(deviceId, meta) { this.meta[deviceId] = Object.assign(this.meta[deviceId] || {}, meta || {}); }

  setScenario(patientId, scenarioId) {
    let ok = false;
    for (const a of this.adapters) if (typeof a.setScenario === 'function') ok = a.setScenario(patientId, scenarioId) || ok;
    return ok;
  }

  dispose() { this.adapters.forEach(a => a.dispose && a.dispose()); }
}

module.exports = { Registry };
