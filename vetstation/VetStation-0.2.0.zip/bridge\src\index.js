'use strict';
/*
 * index.js — Einstieg der Acquisition-Bridge (Schicht 1) + UI-Server (Schicht 2/3).
 * Laedt die Geraete-Konfiguration, startet die Adapter (Simulator by default) und den Server.
 * STRIKT READ-ONLY gegenueber allen Geraeten.
 */
const path = require('path');
const fs = require('fs');
const logger = require('./logger');
const { Registry } = require('./registry');
const { SimulatorAdapter } = require('./adapters/simulator');
const { PlaybackAdapter } = require('./adapters/playback');
const { MindrayAdapter } = require('./adapters/mindray');
const { LifeVetAdapter } = require('./adapters/lifevet');
const { HL7Adapter } = require('./adapters/hl7');
const { ProbeAdapter } = require('./adapters/probe');
const { VSCaptureAdapter } = require('./adapters/vscapture');
const { startServer } = require('./server');
const { CloudPublisher } = require('./cloud');
const pkg = require('../package.json');

const ADAPTERS = {
  simulator: SimulatorAdapter,
  playback: PlaybackAdapter,
  hl7: HL7Adapter,           // Mindray HL7/PDS (falls das Geraet HL7 sendet), PC=Listener
  probe: ProbeAdapter,       // Verbindungs-Assistent: Auto-Erkennung HL7 + Rohdaten + ARP
  vscapture: VSCaptureAdapter, // Fallback: tailt die Live-CSV von VSCapture (das spricht Mindray)
  mindray: MindrayAdapter,
  lifevet: LifeVetAdapter,
};

function loadConfig() {
  const custom = path.join(__dirname, '..', 'config', 'devices.json');
  const example = path.join(__dirname, '..', 'config', 'devices.example.json');
  const file = fs.existsSync(custom) ? custom : example;
  try {
    const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
    logger.info('config', 'Konfiguration: ' + path.basename(file));
    return cfg;
  } catch (e) {
    logger.error('config', 'Konfiguration nicht lesbar (' + e.message + ') -> Simulator-Fallback.');
    return { adapters: [{ type: 'simulator', id: 'sim' }] };
  }
}

function main() {
  const cfg = loadConfig();
  const port = Number(process.env.PORT) || cfg.port || 8770;
  const host = cfg.host || '127.0.0.1';

  const registry = new Registry({ log: logger });
  const ctx = { emit: (raw) => registry.ingest(raw), log: logger };

  const list = (cfg.adapters || []).filter((a) => a.enabled !== false);
  // TEST-MODUS: nur wenn ausdruecklich gewuenscht (START-TESTMODUS.bat) wird der Simulator zugeschaltet.
  // Standard = ECHTE Geraete (keine Simulation).
  if (process.env.VETSTATION_SIM === '1' && !list.some((a) => a.type === 'simulator')) {
    list.push({ type: 'simulator', id: 'sim-test' });
    logger.info('config', 'TEST-MODUS aktiv: Simulator zugeschaltet (VETSTATION_SIM=1).');
  }
  if (!list.length) logger.warn('config', 'Keine aktiven Adapter — warte auf echte Geraete (Verbindungs-Assistent). Fuer Demo: START-TESTMODUS.bat.');
  list.forEach((a) => {
    const Cls = ADAPTERS[a.type];
    if (!Cls) { logger.warn('config', 'Unbekannter Adapter-Typ: ' + a.type); return; }
    registry.addAdapter(new Cls(a, ctx));
    logger.info('config', 'Adapter geladen: ' + a.type + ' [' + (a.id || '?') + ']');
  });

  // FERN-LIVE: optionaler Cloud-Publisher (schreibt Live-Daten ins Internet fuer die Web-App).
  const cloud = new CloudPublisher(cfg.cloud || {}, { log: logger });
  cloud.start();

  const server = startServer({ port, host, registry, version: pkg.version, cloud });
  registry.start();

  const shutdown = () => { logger.info('bridge', 'Beende VetStation-Bridge...'); cloud.stop(); registry.dispose(); server.stop(); process.exit(0); };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main();
