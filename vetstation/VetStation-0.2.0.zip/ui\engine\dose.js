/*
 * dose.js — Dosisberechnung (mg/kg -> mL), 1:1 aus der Web-App (index.html calc/parseConc/doseLine).
 * Liefert fuer einen Zwischenfall die fertigen Injektionen inkl. mL nach Gewicht/Tierart.
 * Laeuft im Browser (VS.dose) und in Node (module.exports) fuer Tests.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.VS = root.VS || {}; root.VS.dose = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // "20 mg/ml", "5 mcg/ml", "1 g/ml", "20 IU/ml" -> mg pro mL (U/mL bleibt fuer Einheiten-Praeparate).
  function parseConc(s) {
    if (!s) return null;
    var m = String(s).replace(',', '.').match(/([0-9]*\.?[0-9]+)\s*(mg|mcg|µg|g|iu|u|units?)\s*\/\s*ml/i);
    if (!m) return null;
    var v = parseFloat(m[1]); var u = m[2].toLowerCase();
    if (u === 'g') v = v * 1000;
    if (u === 'mcg' || u === 'µg') v = v / 1000;
    return v;
  }

  // d = { low, high, unit, conc }, w = kg -> { amtLo, amtHi, amtUnit, mlLo, mlHi }
  function calc(d, w) {
    var lo = d.low, hi = (d.high != null ? d.high : d.low);
    var unit = (d.unit || 'mg/kg').toLowerCase();
    var perKg = /mcg|µg/.test(unit) ? 'mcg' : (/(^|[^a-z])(iu|u|units?)([^a-z]|$)/.test(unit) ? 'U' : 'mg');
    if (lo == null) return { amtLo: null, amtHi: null, amtUnit: perKg, mlLo: null, mlHi: null };
    var amtLo = lo * w, amtHi = hi * w;
    var conc = parseConc(d.conc);
    var mlLo = null, mlHi = null;
    if (conc) {
      var mgLo = perKg === 'mcg' ? amtLo / 1000 : amtLo;
      var mgHi = perKg === 'mcg' ? amtHi / 1000 : amtHi;
      mlLo = mgLo / conc; mlHi = mgHi / conc;
    }
    return { amtLo: amtLo, amtHi: amtHi, amtUnit: perKg, mlLo: mlLo, mlHi: mlHi };
  }

  function drugById(ANAES, id) { return (ANAES.drugs || []).find(function (d) { return d.id === id; }); }

  // Vial-Konzentration ist ARTUNABHAENGIG (Eigenschaft der Ampulle) -> aus irgendeinem
  // Arteintrag desselben Medikaments uebernehmen, damit mL auch bei fehlender Art-conc rechenbar ist.
  function anyConc(d) {
    if (!d || !d.species) return null;
    for (var k in d.species) { var s = d.species[k]; if (s && s.conc) return s.conc; }
    return null;
  }

  // Fertige Injektionen fuer einen Zwischenfall (Notfall-Medikamente), nach Art+Gewicht.
  // WICHTIG (Sicherheit): der Inzident-Ref traegt eine HUND-zentrische Notfalldosis. Fuer andere
  // Arten (z.B. Kaninchen-Atropin 0,1–0,5 statt 0,02–0,04) MUSS die artspezifische Dosis gewinnen,
  // sonst massive Unterdosierung. Der Hund behaelt die (verifizierte) inzident-spezifische Ref-Dosis.
  function injectionsFor(ANAES, incidentId, sp, wt) {
    var inc = (ANAES.incidents || []).find(function (i) { return i.id === incidentId; });
    if (!inc || !inc.drugs) return [];
    return inc.drugs.map(function (ref) {
      var d = drugById(ANAES, ref.id);
      var spd = (d && d.species && d.species[sp]) || {};
      var hasSpd = spd.low != null;
      var concFallback = spd.conc || ref.conc || anyConc(d);
      var dose, refFallback = false, speciesDose = false;
      if (sp === 'hund') {
        // Referenzart Hund: inzident-spezifische Ref-Dosis behalten (verifiziert), sonst Artdosis.
        dose = { low: ref.low != null ? ref.low : spd.low, high: ref.high != null ? ref.high : spd.high,
          unit: ref.unit || spd.unit || 'mg/kg', conc: spd.conc || ref.conc };
        speciesDose = ref.low == null && hasSpd;
      } else if (hasSpd) {
        // Andere Art MIT hinterlegter Dosis: IMMER die artspezifische Dosis (nie Hund-mg/kg).
        dose = { low: spd.low, high: spd.high != null ? spd.high : spd.low,
          unit: spd.unit || 'mg/kg', conc: concFallback };
        speciesDose = true;
      } else {
        // Andere Art OHNE hinterlegte Dosis: Hund-Referenz nur als Notbehelf – deutlich kennzeichnen.
        dose = { low: ref.low, high: ref.high, unit: ref.unit || 'mg/kg', conc: concFallback };
        refFallback = ref.low != null;
      }
      var c = calc(dose, wt);
      var caution = spd.caution || '';
      if (refFallback) caution = ('⚠ Keine artspezifische Dosis für diese Tierart hinterlegt – HUND-Referenz. Dosis am Exoten-Formulary (Carpenter/BSAVA) prüfen. ' + caution).trim();
      return {
        id: ref.id, name: d ? d.name : ref.id, icon: d ? d.icon : '💉',
        route: (speciesDose && spd.route) || ref.route || spd.route || '',
        note: ref.note || '',
        indication: spd.indication || '',
        caution: caution,
        unitPerKg: dose.unit,
        amtLo: c.amtLo, amtHi: c.amtHi, amtUnit: c.amtUnit,
        mlLo: c.mlLo, mlHi: c.mlHi,
        conc: dose.conc,
        available: dose.low != null,
        speciesDose: speciesDose,     // true = artspezifische Dosis verwendet
        refFallback: refFallback,     // true = Hund-Referenz mangels Artdaten (unbestätigt!)
      };
    });
  }

  // Einzeldosis eines Medikaments fuer Art+Gewicht (fuer Medikamenten-Nachschlag).
  function doseFor(ANAES, drugId, sp, wt) {
    var d = drugById(ANAES, drugId);
    if (!d) return null;
    var spd = d.species && d.species[sp];
    if (!spd) return { drug: d, available: false };
    // conc art-unabhaengig fallbacken, damit mL auch ohne Art-conc rechenbar ist.
    var dose = spd.conc ? spd : Object.assign({}, spd, { conc: anyConc(d) });
    var c = calc(dose, wt);
    return { drug: d, spd: spd, available: spd.low != null, calc: c };
  }

  function fmt(n) {
    if (n == null || isNaN(n)) return '–';
    if (n >= 100) return Math.round(n).toString();
    if (n >= 10) return (Math.round(n * 10) / 10).toString();
    if (n >= 1) return (Math.round(n * 100) / 100).toString();
    return (Math.round(n * 1000) / 1000).toString();
  }
  function fmtRange(a, b) { a = fmt(a); b = fmt(b); return a === b ? a : a + '–' + b; }

  return { parseConc: parseConc, calc: calc, injectionsFor: injectionsFor, doseFor: doseFor, fmt: fmt, fmtRange: fmtRange, drugById: drugById };
});
