'use strict';
/*
 * lifevet.js — Adapter fuer Eickemeyer LifeVet 10C (Monitor + Kapno, EtCO2 Seitenstrom).
 *
 * STATUS: STUB / GERUEST. Das CentralStation-Protokoll des LifeVet muss von Eickemeyer
 * bezogen werden (info@eickemeyer.de; Art. 321920; siehe docs/DEVICE-ADAPTERS.md).
 * Bis dahin verbindet dieser Adapter NICHT. STRIKT READ-ONLY.
 *
 * Konfig: { id, model:'LifeVet 10C', role:'combo', listenPort|host+port, sn }
 */
const net = require('net');
const { Adapter } = require('./base');

class LifeVetAdapter extends Adapter {
  constructor(cfg, ctx) { super(cfg, ctx); this.server = null; this.client = null; }

  describe() { return { id: this.id, model: this.cfg.model || 'LifeVet 10C', role: this.cfg.role || 'combo' }; }

  async connect() {
    if (this.cfg.host && this.cfg.port) return this._connectClient();
    if (this.cfg.listenPort) return this._listen();
    this.ctx.log && this.ctx.log.warn('lifevet', 'Adapter "' + this.id + '" ohne host/port -> deaktiviert (Protokoll ausstehend).');
  }

  _listen() {
    this.server = net.createServer((socket) => {
      this.ctx.log && this.ctx.log.info('lifevet', 'Verbindung von ' + socket.remoteAddress);
      socket.on('data', (buf) => this._onData(buf));
      socket.on('error', (e) => this.ctx.log && this.ctx.log.warn('lifevet', 'Socketfehler: ' + e.message));
    });
    this.server.listen(this.cfg.listenPort, () => {
      this.connected = true;
      this.ctx.log && this.ctx.log.info('lifevet', 'LifeVet Listener auf Port ' + this.cfg.listenPort + '.');
    });
  }

  _connectClient() {
    this.client = net.connect(this.cfg.port, this.cfg.host, () => {
      this.connected = true;
      this.ctx.log && this.ctx.log.info('lifevet', 'Verbunden mit LifeVet ' + this.cfg.host + ':' + this.cfg.port);
    });
    this.client.on('data', (buf) => this._onData(buf));
    this.client.on('error', (e) => this.ctx.log && this.ctx.log.warn('lifevet', 'Fehler: ' + e.message));
    this.client.on('close', () => { this.connected = false; this.ctx.log && this.ctx.log.warn('lifevet', 'Verbindung getrennt.'); });
  }

  // TODO(Protokoll): LifeVet-Frames dekodieren -> this.emit({... ingest ...}).
  _onData(buf) {
    this.ctx.log && this.ctx.log.warn('lifevet', 'Datenframe empfangen (' + buf.length + ' B), Parser fehlt noch (Protokoll ausstehend).');
  }

  dispose() {
    if (this.server) { try { this.server.close(); } catch (_) {} }
    if (this.client) { try { this.client.destroy(); } catch (_) {} }
    this.server = this.client = null; this.connected = false;
  }
}

module.exports = { LifeVetAdapter };
