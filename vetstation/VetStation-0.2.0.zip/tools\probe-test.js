'use strict';
/*
 * probe-test.js — Testet den Verbindungs-Assistenten: HL7 auf einem Port wird automatisch erkannt
 * und geparst; unbekannte Bytes auf einem anderen Port werden als "unbekannt" erkannt + roh gesichert.
 *   node tools/probe-test.js
 */
const net = require('net');
const { ProbeAdapter } = require('../bridge/src/adapters/probe');

const P_HL7 = 5061, P_JUNK = 5062;
const VT = 0x0b, FS = 0x1c, CR = 0x0d;
const MSG = ['MSH|^~\\&|Mindray|Gateway|||||ORU^R01|1|P|2.3.1|', 'PID|||K-9||Miez^||||F|||^^^^|||',
  'OBR||||Mindray Monitor|||20260715131917|', 'OBX||NM|101^HR|2101|138||||||F', 'OBX||NM|160^SpO2|2103|97||||||F',
  'OBX||NM|220^CO2|2109|40||||||F', 'OBX||NM|51^Weight||4.5||||||F'].join('\r');
function mllp(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }

const frames = [];
const logs = [];
const ctx = { emit: (f) => frames.push(f), log: { info: (s, m) => logs.push(m), warn: (s, m) => logs.push(m), error: (s, m) => logs.push(m) } };
const probe = new ProbeAdapter({ id: 'assistent', ports: [P_HL7, P_JUNK], arpScan: false, species: 'katze' }, ctx);

(async () => {
  await probe.connect();
  const c1 = net.connect(P_HL7, '127.0.0.1', () => c1.write(mllp(MSG)));
  const c2 = net.connect(P_JUNK, '127.0.0.1', () => c2.write(Buffer.from([0x02, 0x10, 0xff, 0xa5, 0x5a, 0x00, 0x01, 0x02, 0x03])));
  c1.on('error', () => {}); c2.on('error', () => {});
  setTimeout(() => {
    let fails = 0;
    const ok = (c, d) => { if (c) console.log('  ✓ ' + d); else { fails++; console.log('  ✗ FAIL: ' + d); } };
    console.log('== Verbindungs-Assistent-Test ==');
    ok(frames.length >= 1, 'HL7 auf Port ' + P_HL7 + ' automatisch erkannt & geparst');
    ok(frames[0] && frames[0].vitals.hr === 138 && frames[0].vitals.etco2 === 40, 'Werte korrekt (HR 138, EtCO2 40, Katze 4.5 kg)');
    ok(frames[0] && frames[0].weightKg === 4.5, 'Gewicht 4.5 kg gelesen');
    ok(logs.some((m) => /HL7 ERKANNT/.test(m)), 'Meldung "HL7 erkannt" ausgegeben');
    ok(logs.some((m) => /KEIN HL7 erkannt/.test(m)), 'Unbekanntes Protokoll auf Port ' + P_JUNK + ' als "kein HL7" erkannt');
    console.log('\n== ' + (7 - fails) + ' Prüfungen, ' + fails + ' FAIL ==');
    c1.end(); c2.end(); probe.dispose();
    process.exit(fails ? 1 : 0);
  }, 700);
})();
