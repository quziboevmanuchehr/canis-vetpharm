'use strict';
/*
 * matching.js — Patienten-Zuordnung (§6). Fuehrt Geraete, die zum selben Patienten gehoeren,
 * zu EINEM Datensatz zusammen: Monitor (Kreislauf/EKG) + Kapno/Narkose (Atmung/EtCO2/Iso).
 * Schluessel = patientId, sonst Tierart+Gewicht-Bucket; manuelles Koppeln ueberschreibt.
 */
const { patientKey } = require('./model');

// roleWeight: monitor liefert bevorzugt Kreislauf, anesthesia/capno bevorzugt Atmung.
function roleWeightFor(role, field) {
  const cardio = { hr: 3, spo2: 3, pleth: 3, sys: 3, dia: 3, map: 3, ekgRhythm: 3, temp: 2 };
  const resp = { etco2: 3, fico2: 3, af: 3, capnoShape: 3, paw: 3 };
  if (role === 'monitor') return cardio[field] || 1;
  if (role === 'anesthesia' || role === 'capno') return resp[field] || 1;
  return 2; // combo
}

/*
 * mergePatients(deviceRecords, manual) -> patients[]
 * deviceRecords: [{ deviceId, model, role, frame(normalized), status }]
 * manual: { deviceId -> patientKey }  (manuelles Koppeln)
 */
function mergePatients(deviceRecords, manual) {
  manual = manual || {};
  const groups = new Map();

  for (const d of deviceRecords) {
    if (!d.frame) continue;
    const key = manual[d.deviceId] || patientKey(d.frame);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(d);
  }

  const patients = [];
  for (const [key, devs] of groups) {
    // neueste zuerst
    devs.sort((a, b) => (b.frame.ts || 0) - (a.frame.ts || 0));
    const vit = { __w: {} };
    let species = null, weightKg = null, patientId = null, ts = 0, isoPct = null, ventMode = null;
    const alarms = [];
    for (const d of devs) {
      const f = d.frame;
      // Rollengewichtete Zusammenfuehrung der Vitalwerte.
      const v = f.vitals;
      const wrap = {};
      ['hr','spo2','pleth','etco2','fico2','af','paw','temp','ekgRhythm','capnoShape'].forEach(fld => {
        if (v[fld] != null) applyField(vit, fld, v[fld], roleWeightFor(f.deviceRole, fld));
      });
      if (v.nibp) {
        ['sys','dia','map'].forEach(fld => {
          if (v.nibp[fld] != null) applyField(vit, fld, v.nibp[fld], roleWeightFor(f.deviceRole, fld));
        });
      }
      if (!species && f.species) species = f.species;
      if (!weightKg && f.weightKg) weightKg = f.weightKg;
      if (!patientId && f.patientId) patientId = f.patientId;
      if (isoPct == null && f.isoPct != null) isoPct = f.isoPct;
      if (!ventMode && f.ventMode) ventMode = f.ventMode;
      if (f.ts > ts) ts = f.ts;
      (f.alarms || []).forEach(a => alarms.push(a));
    }
    delete vit.__w;
    patients.push({
      patientKey: key,
      patientId: patientId || null,
      species: species || null,
      weightKg: weightKg || null,
      devices: devs.map(d => ({ deviceId: d.deviceId, model: d.frame.deviceModel, role: d.frame.deviceRole })),
      vitals: vit,
      isoPct, ventMode,
      alarms,
      ts,
      manual: devs.some(d => manual[d.deviceId]),
    });
  }
  // Aeltere/leere Patienten hinten.
  patients.sort((a, b) => (b.ts || 0) - (a.ts || 0));
  return patients;
}

// interner Helfer mit Gewichtsvergleich
function applyField(vit, field, val, weight) {
  const cur = vit.__w[field] || 0;
  if (vit[field] == null || weight > cur) { vit[field] = val; vit.__w[field] = weight; }
}

module.exports = { mergePatients };
