<#
  install-autostart.ps1 — Autostart einrichten (§8): registriert eine geplante Aufgabe, die
  VetStation beim Anmelden automatisch im Kiosk startet (mit Watchdog). Fuer den dedizierten
  Praxis-PC zusaetzlich Autologin einrichten (siehe assigned-access.md).

  Aufruf (als Administrator):  powershell -ExecutionPolicy Bypass -File kiosk\install-autostart.ps1
  Entfernen:                   powershell -ExecutionPolicy Bypass -File kiosk\install-autostart.ps1 -Remove
#>
param([switch]$Remove, [int]$Port = 8770)

$TaskName = 'VetStation-Kiosk'
$Root = Split-Path $PSScriptRoot -Parent
$Launch = Join-Path $PSScriptRoot 'launch-kiosk.ps1'

if ($Remove) {
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
  Write-Host "Autostart '$TaskName' entfernt."
  return
}

$action  = New-ScheduledTaskAction -Execute 'powershell.exe' `
  -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Launch`" -Port $Port -Watchdog"
$trigger = New-ScheduledTaskTrigger -AtLogOn
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Hours 0)
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Write-Host "Autostart '$TaskName' registriert (startet beim Anmelden, mit Watchdog)."
Write-Host "Fuer echten Appliance-Betrieb zusaetzlich Autologin + Assigned Access einrichten -> kiosk\assigned-access.md"
