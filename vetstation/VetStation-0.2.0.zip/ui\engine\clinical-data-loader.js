/*
 * clinical-data-loader.js — Klinische Datenbasis aktuell halten (Nutzer-Entscheidung 2026-07-17):
 * beim Start das anaes-data.js vom LIVE canis-vetpharm (GitHub Pages) nachladen, damit
 * Verbesserungen aus der Web-App automatisch in den Kiosk fliessen. Faellt offline auf die
 * lokal mitgelieferte Kopie (ui/vendor/anaes-data.js) zurueck, die bereits synchron geladen ist.
 *
 * CORS-frei ueber <script>-Injektion: die Live-Datei setzt window.ANAES; bei Erfolg uebernehmen
 * wir sie und rendern neu. Bei Fehler bleibt die Vendor-Kopie aktiv.
 */
(function (root) {
  'use strict';
  var VS = root.VS = root.VS || {};
  var LIVE = 'https://quziboevmanuchehr.github.io/canis-vetpharm/canis-anaesthesie/anaes-data.js';

  VS.clinicalData = {
    source: (root.ANAES ? 'vendor' : 'none'),
    error: null,
    liveUrl: LIVE,

    pullLive: function (onUpdate) {
      var self = this;
      var s = document.createElement('script');
      s.src = LIVE + '?t=' + Date.now();
      s.async = true;
      s.onload = function () {
        // Die Live-Datei hat window.ANAES neu gesetzt -> validieren & uebernehmen.
        if (root.ANAES && root.ANAES.species && root.ANAES.drugs && root.ANAES.incidents) {
          self.source = 'live';
          if (onUpdate) onUpdate(root.ANAES);
        }
      };
      s.onerror = function () { self.source = 'vendor (offline)'; self.error = 'Live-Daten nicht erreichbar'; };
      document.head.appendChild(s);
    },
  };
})(window);
