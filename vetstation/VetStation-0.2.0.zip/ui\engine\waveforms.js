/*
 * waveforms.js — Kurven-Synthese (EKG/Pleth/Kapno), pure Funktionen 1:1 aus der Web-App
 * (index.html wEkg/wPleth/wCapno/monFrame). VetStation synthetisiert die Kurven LOKAL aus
 * den Live-Vitalwerten -> pro Patient eine eigene MonitorCanvas, alle von EINER rAF-Schleife
 * getrieben (RAM-/CPU-schonend fuer den i3/8-GB-Kiosk).
 */
(function (root) {
  'use strict';
  var VS = root.VS = root.VS || {};

  function gauss(x, mu, s) { var d = (x - mu) / s; return Math.exp(-0.5 * d * d); }

  // W = Wellenform-Flags (= ANAES.ekg[].w). beatN = ganzzahliger Schlagzaehler dieser Instanz.
  function wEkg(ph, W, beatN) {
    W = W || {};
    if (W.flat) return 0.5 + (Math.random() - 0.5) * 0.02;                 // Asystolie
    if (W.chaos) return 0.5 + 0.26 * Math.sin(ph * 38 + beatN) + 0.15 * Math.sin(ph * 67 + 2) + (Math.random() - 0.5) * 0.14; // VF
    var beat = beatN || 0, y = 0.5;
    var wide = (W.qrs > 1.5), hasP = (W.p && W.pq !== 'diss'), drop = false, tSign = 1, ampR = 0.42;
    if (W.drop === 'wenckebach') { var r1 = W.ratio || 4; if (beat % r1 === r1 - 1) drop = true; }
    if (W.drop === 'mobitz2') { var r2 = W.ratio || 3; if (beat % r2 === r2 - 1) drop = true; }
    if (W.ectopic && beat % 4 === 3) { if (W.ectopic === 'ves') { wide = true; hasP = false; tSign = -1; ampR = 0.5; } else { hasP = true; wide = false; } }
    var pq = (typeof W.pq === 'number') ? (W.pq - 1) * 0.05 : (W.pq === 'inc' ? (beat % (W.ratio || 4)) * 0.028 : 0);
    if (hasP) y += 0.07 * gauss(ph, 0.16 + pq * 0.3, 0.028);
    if (!drop) {
      var qc = 0.335 + pq;
      if (wide) { y += ampR * gauss(ph, qc + 0.02, 0.030) - 0.13 * gauss(ph, qc - 0.04, 0.02) - 0.16 * gauss(ph, qc + 0.08, 0.026) + 0.17 * (-tSign) * gauss(ph, 0.62, 0.05); }
      else { y += -0.05 * gauss(ph, qc - 0.03, 0.010) + ampR * gauss(ph, qc, 0.010) - 0.12 * gauss(ph, qc + 0.03, 0.012) + 0.13 * tSign * gauss(ph, 0.55, 0.045); }
    }
    if (W.flutter) y += 0.06 * (2 * ((ph * 4) % 1) - 1);
    if (W.irregular) y += (Math.random() - 0.5) * 0.03;
    if (W.pq === 'diss') y += 0.06 * gauss((ph * 2) % 1, 0.5, 0.05);
    return y;
  }

  function wPleth(ph, type) {
    if (type === 'flat') return 0.5;
    var amp = type === 'weak' ? 0.14 : 0.34;
    var pulse; if (ph < 0.10) { pulse = ph / 0.10; } else { var d = (ph - 0.10) / 0.90; pulse = Math.exp(-d * 3.2) * (1 + 0.22 * Math.cos(d * 13)); }
    pulse = Math.max(0, Math.min(1.15, pulse));
    return 0.22 + amp * pulse;
  }

  function wCapno(ph, type, etco2) {
    if (type === 'flat') return 0.12;
    var amp = Math.max(0.12, Math.min(0.86, (etco2 / 50) * 0.8));
    if (type === 'low') amp = 0.14;
    if (type === 'high') amp = Math.max(amp, 0.82);
    var base = (type === 'baseline') ? 0.34 : 0.12;
    if (type === 'shark') {
      if (ph < 0.12) return base;
      if (ph > 0.94) return base + amp * (1 - (ph - 0.94) / 0.06);
      return base + amp * ((ph - 0.12) / 0.82);
    }
    if (ph < 0.30) return base;
    if (ph < 0.37) return base + amp * ((ph - 0.30) / 0.07);
    if (ph < 0.92) return base + amp;
    return base + amp * (1 - (ph - 0.92) / 0.08);
  }

  // Mini-EKG als SVG (fuer Rhythmus-Abzeichen). beatN lokal, mutiert keine Instanz.
  function ekgSVG(W, id) {
    var pts = [], N = 42, beats = 4;
    for (var b = 0; b < beats; b++) for (var i = 0; i < N; i++) {
      var ph = i / N, y = wEkg(ph, W, b);
      pts.push(((b * N + i) / (beats * N) * 100).toFixed(1) + ',' + (55 - (y - 0.12) / 0.86 * 46).toFixed(1));
    }
    return '<svg viewBox="0 0 100 60" preserveAspectRatio="none"><polyline fill="none" stroke="#28e07a" stroke-width="1.5" points="' + pts.join(' ') + '"/></svg>';
  }

  /*
   * MonitorCanvas — ein scrollendes Monitorbild (EKG/Pleth/Kapno) pro Patient.
   * getFrame() -> { hr, ekgW, spo2, etco2, af, pleth, capno }  (aufloesende Werte)
   */
  function MonitorCanvas(canvas, getFrame) {
    this.c = canvas; this.getFrame = getFrame;
    this.phE = 0; this.phR = 0; this.beatN = 0; this.rrJit = 1; this.acc = 0;
    this.last = (root.performance ? performance.now() : Date.now());
    this.dpr = Math.min(2, root.devicePixelRatio || 1);
    this.W = 0; this.H = 0; this.buf = null;
    this.resize();
  }
  MonitorCanvas.prototype.resize = function () {
    var rect = this.c.getBoundingClientRect();
    this.W = Math.max(2, Math.floor(rect.width * this.dpr));
    this.H = Math.max(2, Math.floor(rect.height * this.dpr));
    this.c.width = this.W; this.c.height = this.H; this.buf = null;
  };
  MonitorCanvas.prototype.step = function (ts) {
    var c = this.c; if (!c || !c.isConnected) return;
    // Regelmaessig neu vermessen: Layout kann beim Anlegen noch 0 breit sein; Fenster/Split aendern sich.
    this._fc = (this._fc || 0) + 1;
    if (this._fc % 20 === 1) {
      var rect = c.getBoundingClientRect();
      var nw = Math.max(2, Math.floor(rect.width * this.dpr)), nh = Math.max(2, Math.floor(rect.height * this.dpr));
      if (nw !== this.W || nh !== this.H) { this.W = nw; this.H = nh; c.width = nw; c.height = nh; this.buf = null; }
    }
    var ctx = c.getContext('2d'); var W = this.W, H = this.H; if (!W || !H) return;
    var cols = Math.max(60, Math.floor(W));
    if (!this.buf || this.buf.ekg.length !== cols) this.buf = { ekg: new Array(cols).fill(0.5), pleth: new Array(cols).fill(0.22), capno: new Array(cols).fill(0.12) };
    var dt = (ts - this.last) / 1000; this.last = ts; if (dt > 0.08) dt = 0.033; if (dt < 0) dt = 0;
    var f = this.getFrame() || {};
    var Wr = f.ekgW || {};
    var sweep = 6.0, pxPerSec = cols / sweep; this.acc += pxPerSec * dt; var k = Math.floor(this.acc); if (k > 60) k = 60; this.acc -= k;
    var colT = 1 / pxPerSec;
    var perE = f.hr > 0 ? 60 / f.hr : 9999, perR = f.af > 0 ? 60 / f.af : 9999;
    for (var j = 0; j < k; j++) {
      var prevE = this.phE;
      this.phE = (this.phE + colT / (perE * (this.rrJit || 1))) % 1;
      if (this.phE < prevE) { this.beatN = (this.beatN || 0) + 1; this.rrJit = Wr.irregular ? (0.55 + Math.random() * 0.95) : 1; }
      this.phR = (this.phR + colT / perR) % 1;
      this.buf.ekg.push(wEkg(this.phE, Wr, this.beatN)); this.buf.ekg.shift();
      this.buf.pleth.push(wPleth(this.phE, f.pleth || 'normal')); this.buf.pleth.shift();
      this.buf.capno.push(wCapno(this.phR, f.capno || 'normal', f.etco2 || 40)); this.buf.capno.shift();
    }
    // zeichnen
    ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#05080d'; ctx.fillRect(0, 0, W, H);
    var laneH = H / 3;
    var lanes = [['ekg', '#28e07a', 'EKG II'], ['pleth', '#00d8ff', 'Pleth · SpO₂ ' + (f.spo2 != null ? f.spo2 : '–') + '%'], ['capno', '#ffd166', 'Kapno · EtCO₂ ' + (f.etco2 != null ? f.etco2 : '–')]];
    for (var li = 0; li < 3; li++) {
      var top = li * laneH, key = lanes[li][0];
      ctx.strokeStyle = 'rgba(120,150,180,.10)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0, top + laneH - 0.5); ctx.lineTo(W, top + laneH - 0.5); ctx.stroke();
      ctx.strokeStyle = lanes[li][1]; ctx.lineWidth = Math.max(1.2, 1.5 * this.dpr); ctx.beginPath();
      var bb = this.buf[key];
      for (var i = 0; i < bb.length; i++) { var x = i * (W / (bb.length - 1)); var y = top + (1 - bb[i]) * laneH * 0.82 + laneH * 0.09; if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
      ctx.stroke();
      ctx.fillStyle = lanes[li][1]; ctx.font = (11 * this.dpr) + 'px Consolas,monospace'; ctx.fillText(lanes[li][2], 8 * this.dpr, top + 14 * this.dpr);
    }
  };

  // Ein einziger rAF-Treiber fuer ALLE Monitor-Canvases (mehrere Patienten gleichzeitig).
  var driver = {
    items: new Set(), raf: null,
    add: function (mc) { this.items.add(mc); if (!this.raf) this.raf = requestAnimationFrame(this._tick.bind(this)); },
    remove: function (mc) { this.items.delete(mc); if (!this.items.size && this.raf) { cancelAnimationFrame(this.raf); this.raf = null; } },
    _tick: function (ts) {
      this.raf = requestAnimationFrame(this._tick.bind(this));
      this.items.forEach(function (mc) { try { mc.step(ts); } catch (e) {} });
    },
  };

  VS.waveforms = { wEkg: wEkg, wPleth: wPleth, wCapno: wCapno, ekgSVG: ekgSVG, MonitorCanvas: MonitorCanvas, driver: driver };
})(typeof self !== 'undefined' ? self : this);
