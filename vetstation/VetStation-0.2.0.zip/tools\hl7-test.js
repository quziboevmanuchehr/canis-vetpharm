'use strict';
/*
 * hl7-test.js — Verifiziert den Mindray-HL7/PDS-Parser gegen eine realistische ORU^R01-Nachricht
 * (Segmente/Codes exakt nach Mindray PDS Programmer's Guide). Prueft zusaetzlich MLLP-Rahmen-
 * extraktion und den Durchlauf bis ins "Brain".
 *   node tools/hl7-test.js
 */
const { parseHL7Message } = require('../bridge/src/adapters/hl7');
const { normalizeFrame } = require('../bridge/src/model');
const { mergePatients } = require('../bridge/src/matching');
const { loadAnaes } = require('../bridge/src/anaes');
const brain = require('../ui/engine/brain');

let fails = 0, passes = 0;
function ok(c, d, x) { if (c) { passes++; console.log('  ✓ ' + d); } else { fails++; console.log('  ✗ FAIL: ' + d + (x ? '  [' + x + ']' : '')); } }

// Realistische uMEC12-Vet-Nachricht (Hund 22 kg, stabil), Codes wie in der PDS-Spezifikation.
const MSG = [
  'MSH|^~\\&|Mindray|Gateway|||||ORU^R01|42|P|2.3.1|',
  'PID|||A-102||Bella^||20200101|M|||^^^^|||',
  'PV1||I|^^OP&Bed1&3232241659&0&0|||||||||||||||A||||||||||||||||||||||||||20260706172815',
  'OBR||||Mindray Monitor|||20260706172815|',
  'OBX||NM|101^HR|2101|99||||||F',
  'OBX||NM|160^SpO2|2103|98||||||F',
  'OBX||NM|170^Sys|2105|123||||||F',
  'OBX||NM|171^Dia|2105|78||||||F',
  'OBX||NM|172^Mean|2105|93||||||F',
  'OBX||NM|220^CO2|2109|42||||||F',
  'OBX||NM|222^AWRR|2109|14||||||F',
  'OBX||NM|200^T1|2104|38.0||||||F',
  'OBX||NM|102^PVCs|2101|0||||||F',
  'OBX||NM|51^Weight||22.0||||||F',
  'OBX||NM|999^UnbekannterParam|2101|5||||||F',
].join('\r');

console.log('== VetStation HL7/PDS-Parser-Test ==');

// 1) Reiner Parser
let unmapped = [];
const frame = parseHL7Message(MSG, { deviceId: 'umec12', model: 'uMEC12 Vet', species: 'hund' }, (u) => unmapped.push(u));
ok(!!frame, 'ORU^R01 wird geparst');
ok(frame.vitals.hr === 99, 'HR = 99', frame.vitals.hr);
ok(frame.vitals.spo2 === 98, 'SpO2 = 98', frame.vitals.spo2);
ok(frame.vitals.nibp.sys === 123 && frame.vitals.nibp.dia === 78 && frame.vitals.nibp.map === 93, 'NIBP 123/78 (93)', JSON.stringify(frame.vitals.nibp));
ok(frame.vitals.etco2 === 42, 'EtCO2 = 42 (Code 220^CO2)', frame.vitals.etco2);
ok(frame.vitals.af === 14, 'AF = 14 (Code 222^AWRR)', frame.vitals.af);
ok(frame.vitals.temp === 38, 'Temp = 38 (Code 200^T1)', frame.vitals.temp);
ok(frame.weightKg === 22, 'Gewicht = 22 kg (Code 51^Weight)', frame.weightKg);
ok(frame.patientId === 'A-102', 'PatientId = A-102 (PID-3)', frame.patientId);
ok(frame.deviceRole === 'combo', 'Rolle = combo (EtCO2 vorhanden)', frame.deviceRole);
ok(unmapped.length === 1 && /999/.test(unmapped[0]), 'Unbekannter OBX-Code wird gemeldet (999)', unmapped.join(','));

// 1b) Label-Fallback / IEEE-11073-MDC-Nomenklatur (BeneView/BeneVision): unbekannte Nummerncodes, MDC-Labels
const MDC = [
  'MSH|^~\\&|Mindray|Gateway|||||ORU^R01|9|P|2.3.1|',
  'OBX||NM|150456^MDC_ECG_HEART_RATE^MDC|0|72||||||F',
  'OBX||NM|150316^MDC_PULS_OXIM_SAT_O2^MDC|0|96||||||F',
  'OBX||NM|151708^MDC_CO2_ET^MDC|0|38||||||F',
].join('\r');
const fm = parseHL7Message(MDC, {});
ok(fm && fm.vitals.hr === 72 && fm.vitals.spo2 === 96 && fm.vitals.etco2 === 38,
  'MDC-Label-Fallback (BeneView): HR/SpO2/EtCO2 via MDC_* erkannt', fm ? JSON.stringify(fm.vitals) : 'null');

// 2) MLLP-Rahmenextraktion (VT ... FS CR), auch bei zwei Nachrichten in einem Chunk
const VT = 0x0b, FS = 0x1c, CR = 0x0d;
function frameMLLP(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }
let buf = Buffer.concat([frameMLLP(MSG), frameMLLP(MSG)]);
let count = 0, start;
while ((start = buf.indexOf(VT)) !== -1) { const end = buf.indexOf(FS, start + 1); if (end === -1) break; const p = buf.slice(start + 1, end).toString('latin1'); if (parseHL7Message(p, {})) count++; buf = buf.slice(end + 2); }
ok(count === 2, 'MLLP: zwei gerahmte Nachrichten aus einem Chunk extrahiert', count);

// 3) Durchlauf bis ins Brain (normalize -> merge -> assess)
const ANAES = loadAnaes();
const norm = normalizeFrame(frame).frame;
const patients = mergePatients([{ deviceId: 'umec12', model: 'uMEC12 Vet', role: 'combo', frame: norm }], {});
ok(patients.length === 1, 'Ein Patient nach Matching', patients.length);
const p = patients[0];
const pat = Object.assign({ species: p.species || 'hund', weightKg: p.weightKg, isoPct: null }, p.vitals);
const res = brain.assess(ANAES, pat);
ok(Array.isArray(res.cross) && res.top !== undefined, 'Brain bewertet den HL7-Patienten ohne Fehler', 'cross=' + res.cross.length);
ok(p.weightKg === 22 && p.vitals.hr === 99 && p.vitals.etco2 === 42, 'Merged Patient hat HL7-Werte', JSON.stringify({ w: p.weightKg, hr: p.vitals.hr, etco2: p.vitals.etco2 }));

console.log('\n== Ergebnis: ' + passes + ' OK, ' + fails + ' FAIL ==');
process.exit(fails ? 1 : 0);
