# VetStation auf dem Praxis-PC installieren (Windows 10/11 Pro)

Ziel: **einfach installieren, danach läuft es automatisch** (Vollbild-Kiosk beim Hochfahren).

## A) Paket bauen (auf DIESEM Entwickler-PC, einmalig)
```powershell
powershell -ExecutionPolicy Bypass -File installer\make-dist.ps1
```
Erzeugt `dist\VetStation\` (**inkl. portablem Node** — auf dem Ziel-PC muss nichts extra installiert
werden) und `dist\VetStation-Setup.zip`.

## B) Auf den Praxis-PC bringen
`dist\VetStation` (bzw. das Zip entpackt) per **USB-Stick** oder Netzwerk auf den Ziel-PC kopieren.

## C) Installieren (auf dem Praxis-PC)
- **`INSTALLIEREN.bat`** rechtsklicken → **„Als Administrator ausführen"**.
  Das kopiert die App nach `C:\VetStation`, richtet **Autostart + Watchdog** ein und fragt optional die
  **statische IP** fürs Geräte-Netz ab.
- Nur testen (ohne Autostart): **`START-VetStation.bat`** doppelklicken.

Danach startet VetStation beim nächsten Anmelden automatisch im Vollbild. Für den „echten" Appliance-
Modus (kein Desktop sichtbar) zusätzlich **Assigned Access / Autologin** einrichten →
[../kiosk/assigned-access.md](../kiosk/assigned-access.md).

## D) Geräte anschließen
Physischer LAN-Aufbau (Switch, IPs, Serveradresse = PC-IP) → [../docs/LAN-SETUP.md](../docs/LAN-SETUP.md).
Geräte-Adapter aktivieren → [../docs/DEVICE-ADAPTERS.md](../docs/DEVICE-ADAPTERS.md).

## Deinstallieren
```powershell
powershell -ExecutionPolicy Bypass -File C:\VetStation\kiosk\install-autostart.ps1 -Remove
# danach Ordner C:\VetStation loeschen
```

## Echte `VetStation-Setup.exe` (eine Datei zum Doppelklicken)
Fertig gebaut unter **`dist\VetStation-Setup.exe`** (~19 MB). Auf den Ziel-PC kopieren,
**doppelklicken**, UAC bestätigen → installiert nach `C:\VetStation`, Start-Menü-Eintrag, Autostart.
Deinstallation über „Apps & Features". Läuft auf Windows 10 **und** 11.

Neu bauen (nach Änderungen): erst `make-dist.ps1`, dann
```
"%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" installer\vetstation-setup.iss
```
(Inno Setup ist kostenlos: `winget install JRSoftware.InnoSetup`. Skript: `installer\vetstation-setup.iss`.)
