<#
  make-dist.ps1 — Baut auf DIESEM (Entwickler-)PC ein fertiges, kopierbares Paket
  `dist\VetStation\`, das **portables Node** enthält, sodass auf dem Ziel-PC NICHTS extra
  installiert werden muss. Das Paket auf USB-Stick/Netz kopieren und dort `Install-VetStation.ps1`
  ausführen (oder `START-VetStation.bat` doppelklicken).

  Aufruf:  powershell -ExecutionPolicy Bypass -File installer\make-dist.ps1
  Optional: -NodeVersion 20.18.1   -OutDir <pfad>
#>
param(
  [string]$NodeVersion = '20.18.1',
  [string]$OutDir = "$PSScriptRoot\..\dist"
)
$ErrorActionPreference = 'Stop'
$Root  = Split-Path $PSScriptRoot -Parent
$Stage = Join-Path $OutDir 'VetStation'

Write-Host "== VetStation-Paket bauen =="
if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Stage | Out-Null

# 1) App-Dateien kopieren (ohne .git, node_modules, data, dist)
Write-Host "Kopiere App-Dateien ..."
robocopy $Root $Stage /E /XD (Join-Path $Root '.git') (Join-Path $Root 'node_modules') (Join-Path $Root 'data') (Join-Path $Root 'dist') /XF '*.log' /NFL /NDL /NJH /NJS /NP | Out-Null

# 2) Portables Node holen und als node\node.exe ablegen
$nodeDir = Join-Path $Stage 'node'
New-Item -ItemType Directory -Force -Path $nodeDir | Out-Null
$zipName = "node-v$NodeVersion-win-x64"
$zipUrl  = "https://nodejs.org/dist/v$NodeVersion/$zipName.zip"
$zipPath = Join-Path $env:TEMP "$zipName.zip"
Write-Host "Lade portables Node $NodeVersion ..."
try {
  Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing
  $tmp = Join-Path $env:TEMP "vetstation-node"
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive -Path $zipPath -DestinationPath $tmp -Force
  Copy-Item (Join-Path $tmp "$zipName\node.exe") (Join-Path $nodeDir 'node.exe') -Force
  Write-Host "node.exe eingebettet."
} catch {
  Write-Warning "Node-Download fehlgeschlagen ($($_.Exception.Message)). Bitte node.exe manuell nach $nodeDir kopieren."
}

# 3) Doppelklick-Starter + Installer-Starter ins Paket
@"
@echo off
REM VetStation starten (ECHTE Geraete). Fuer Dauerbetrieb: Install-VetStation.ps1 ausfuehren.
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-VetStation.bat')

@"
@echo off
REM DEMO/TEST OHNE Geraete: schaltet den Simulator zu (zwei Demo-Patienten Hund+Katze).
set VETSTATION_SIM=1
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'START-TESTMODUS.bat')

@"
@echo off
REM VetStation installieren (Autostart-Kiosk). Einfach DOPPELKLICKEN — der Installer holt sich
REM die Adminrechte selbst (UAC-Abfrage bestaetigen). Laeuft auf Windows 10 UND Windows 11.
powershell -ExecutionPolicy Bypass -File "%~dp0installer\Install-VetStation.ps1"
"@ | Set-Content -Encoding ASCII (Join-Path $Stage 'INSTALLIEREN.bat')

# 4) Optional zippen
$zipOut = Join-Path $OutDir 'VetStation-Setup.zip'
if (Test-Path $zipOut) { Remove-Item $zipOut -Force }
Compress-Archive -Path $Stage -DestinationPath $zipOut
Write-Host ""
Write-Host "FERTIG:"
Write-Host "  Ordner: $Stage"
Write-Host "  Zip:    $zipOut"
Write-Host "Auf den Ziel-PC kopieren -> INSTALLIEREN.bat (als Admin) oder START-VetStation.bat (Test)."
