@echo off
REM DEMO/TEST OHNE Geraete: schaltet den Simulator zu (zwei Demo-Patienten Hund+Katze).
set VETSTATION_SIM=1
powershell -ExecutionPolicy Bypass -File "%~dp0kiosk\launch-kiosk.ps1"
