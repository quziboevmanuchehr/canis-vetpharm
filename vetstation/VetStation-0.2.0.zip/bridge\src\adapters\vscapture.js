'use strict';
/*
 * vscapture.js — Fallback-Adapter: liest die LIVE-CSV, die VSCapture (Open Source) schreibt.
 *
 * Idee: VSCapture "spricht" das Mindray-HL7/PDS-Protokoll bereits (Port 4601, PC=Listener) und
 * schreibt die Werte fortlaufend in eine CSV (z. B. MRayDataExport.csv / MRayTCPExportData.csv).
 * Falls VetStations eigener HL7-Listener am konkreten Geraet nicht direkt greift, lassen wir
 * VSCapture empfangen und "tailen" dessen CSV -> Patient erscheint trotzdem in VetStation.
 *
 * READ-ONLY. Spalten werden per Kopfzeile tolerant zugeordnet (Header ggf. an die echte
 * VSCapture-CSV anpassen; unbekannte Spalten werden protokolliert).
 *
 * Konfig: { id, file, model, role, species?, weightKg?, patientId?, pollMs?:1000 }
 */
const fs = require('fs');
const { Adapter } = require('./base');

// Normalisierter Header -> internes Feld.
function mapHeader(h) {
  const k = String(h).toLowerCase().replace(/[^a-z0-9]/g, '');
  const M = {
    hr: 'hr', pr: 'hr', pulse: 'hr', heartrate: 'hr',
    spo2: 'spo2', spo2sat: 'spo2', sato2: 'spo2',
    nibps: 'sys', nibpsys: 'sys', sys: 'sys', arts: 'sys', nbps: 'sys',
    nibpd: 'dia', nibpdia: 'dia', dia: 'dia', artd: 'dia', nbpd: 'dia',
    nibpm: 'map', nibpmean: 'map', mean: 'map', map: 'map', artm: 'map', nbpm: 'map',
    etco2: 'etco2', co2: 'etco2', etco2mmhg: 'etco2',
    fico2: 'fico2', insco2: 'fico2',
    awrr: 'af', resp: 'af', rr: 'af', co2rr: 'af', resprate: 'af',
    t1: 'temp', temp: 'temp', tb: 'temp', temp1: 'temp',
    weight: 'weightKg', weightkg: 'weightKg',
  };
  return M[k] || null;
}

class VSCaptureAdapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    this.file = cfg.file;
    this.pollMs = cfg.pollMs || 1000;
    this.offset = 0;
    this.header = null;
    this.timer = null;
    this.unmapped = new Set();
  }

  describe() { return { id: this.id, model: this.cfg.model || 'VSCapture', role: this.cfg.role || 'combo' }; }

  async connect() {
    if (!this.file) { this.ctx.log.warn('vscapture', 'kein "file" konfiguriert -> deaktiviert.'); return; }
    this.connected = true;
    this.ctx.log.info('vscapture', 'Tail der VSCapture-CSV: ' + this.file + ' (alle ' + this.pollMs + ' ms).');
    this.timer = setInterval(() => this._tick(), this.pollMs);
  }

  _tick() {
    let st;
    try { st = fs.statSync(this.file); } catch (_) { return; } // Datei noch nicht da
    if (st.size < this.offset) { this.offset = 0; this.header = null; } // Rotation/Truncate
    if (st.size === this.offset) return;
    let chunk;
    try {
      const fd = fs.openSync(this.file, 'r');
      const len = st.size - this.offset;
      const b = Buffer.alloc(len);
      fs.readSync(fd, b, 0, len, this.offset);
      fs.closeSync(fd);
      chunk = b.toString('utf8');
    } catch (e) { this.ctx.log.warn('vscapture', 'Lesefehler: ' + e.message); return; }
    this.offset = st.size;

    const lines = chunk.split(/\r?\n/).filter((l) => l.trim());
    for (const line of lines) {
      const cells = line.split(/[,;\t]/).map((s) => s.trim());
      if (!this.header) {
        // Erste (nicht-numerische) Zeile = Kopfzeile
        if (cells.some((c) => /[a-zA-Z]/.test(c))) {
          this.header = cells.map(mapHeader);
          cells.forEach((c, i) => { if (!this.header[i] && !this.unmapped.has(c) && !/time|date|ts/i.test(c)) { this.unmapped.add(c); this.ctx.log.warn('vscapture', 'Unbekannte CSV-Spalte: "' + c + '"'); } });
          continue;
        } else { this.ctx.log.warn('vscapture', 'Keine Kopfzeile gefunden — Spalten unbekannt.'); return; }
      }
      this._emitRow(cells);
    }
  }

  _emitRow(cells) {
    const v = {};
    this.header.forEach((key, i) => {
      if (!key) return;
      const n = parseFloat(String(cells[i]).replace(',', '.'));
      if (Number.isFinite(n)) v[key] = n;
    });
    if (!Object.keys(v).length) return;
    this.emit({
      deviceId: this.cfg.id, deviceModel: this.cfg.model || 'VSCapture (Mindray)', deviceRole: this.cfg.role || 'combo',
      patientId: this.cfg.patientId || null, species: this.cfg.species || null,
      weightKg: this.cfg.weightKg != null ? this.cfg.weightKg : (v.weightKg != null ? v.weightKg : null),
      ts: Date.now(),
      vitals: { hr: v.hr, spo2: v.spo2, etco2: v.etco2, fico2: v.fico2, af: v.af, temp: v.temp, nibp: { sys: v.sys, dia: v.dia, map: v.map } },
      alarms: [],
    });
  }

  dispose() { if (this.timer) clearInterval(this.timer); this.timer = null; this.connected = false; }
}

module.exports = { VSCaptureAdapter, mapHeader };
