'use strict';
/* hl7-client-test.js — prueft den PDS-Realtime-Client-Modus: der Adapter verbindet sich zum
 * (Fake-)Geraet, sendet QRY^R02, empfaengt ORU^R01 und emittiert ein Frame. */
const net = require('net');
const { HL7Adapter } = require('../bridge/src/adapters/hl7');

const VT = 0x0b, FS = 0x1c, CR = 0x0d;
function mllp(t) { return Buffer.concat([Buffer.from([VT]), Buffer.from(t, 'latin1'), Buffer.from([FS, CR])]); }
const ORU = [
  'MSH|^~\\&|Mindray|Gateway|||||ORU^R01|5|P|2.3.1|',
  'PID|||A-102||Bella^||||M|||^^^^|||',
  'OBR||||Mindray Monitor|||20260718120000|',
  'OBX||NM|101^HR|2101|88||||||F', 'OBX||NM|160^SpO2|2103|96||||||F',
  'OBX||NM|220^CO2|2109|39||||||F', 'OBX||NM|51^Weight||22||||||F',
].join('\r');

const PORT = 5071;
let gotQuery = false;
const server = net.createServer((sock) => {
  let buf = Buffer.alloc(0);
  sock.on('data', (c) => {
    buf = Buffer.concat([buf, c]); let s;
    while ((s = buf.indexOf(VT)) !== -1) { const e = buf.indexOf(FS, s + 1); if (e === -1) break; const p = buf.slice(s + 1, e).toString('latin1'); buf = buf.slice(e + 2); if (/QRY/.test(p)) { gotQuery = true; sock.write(mllp(ORU)); } }
  });
  sock.on('error', () => {});
});

const frames = [];
const ctx = { emit: (f) => frames.push(f), log: { info: () => {}, warn: () => {}, error: () => {} } };

server.listen(PORT, '127.0.0.1', () => {
  const a = new HL7Adapter({ id: 'umec', mode: 'client', host: '127.0.0.1', port: PORT, model: 'uMEC12 Vet', species: 'hund' }, ctx);
  a.connect();
  setTimeout(() => {
    let fails = 0; const ok = (c, d) => { if (c) console.log('  ✓ ' + d); else { fails++; console.log('  ✗ FAIL: ' + d); } };
    console.log('== HL7 Client-Modus-Test (PDS Realtime) ==');
    ok(gotQuery, 'Adapter sendet QRY^R02 an das Geraet');
    ok(frames.length >= 1, 'Adapter empfaengt ORU und emittiert Frame');
    ok(frames[0] && frames[0].vitals.hr === 88 && frames[0].vitals.etco2 === 39, 'Werte korrekt (HR 88, EtCO2 39)');
    ok(frames[0] && frames[0].weightKg === 22, 'Gewicht 22 kg');
    a.dispose(); server.close();
    console.log('\n== ' + (4 - fails) + ' OK, ' + fails + ' FAIL ==');
    process.exit(fails ? 1 : 0);
  }, 800);
});
