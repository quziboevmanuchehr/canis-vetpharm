'use strict';
/*
 * hl7.js — ECHTER Mindray-Live-Adapter ueber HL7 / "Patient Data Share" (PDS).
 *
 * Belegter Weg (Mindray PDS Protocol Programmer's Guide H-0010-20-43061 v14.2; VSCapture unterstuetzt
 * die uMEC-Serie gateway-frei): Der Monitor sendet HL7 v2.3.1 ORU^R01 ueber TCP mit MLLP-Framing.
 * PC = LISTENER/Server; der Monitor verbindet sich als Client zur "Serveradresse" (= PC-IP) und pusht.
 *
 * STRIKT READ-ONLY: dieser Adapter empfaengt nur. Ein optionaler HL7-ACK ist reines Protokoll-
 * Quittieren (keine Geraetesteuerung) und standardmaessig AUS -> es wird per Default NICHTS gesendet.
 *
 * OBX-Codes 1:1 aus der offiziellen PDS-Spezifikation (siehe docs/MINDRAY-HL7.md).
 *
 * Konfig: { id, listenPort=5000, model, role, species?, weightKg?, ack?:false, rawLog?:false }
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const { Adapter } = require('./base');

const VT = 0x0b, FS = 0x1c, CR = 0x0d; // MLLP-Rahmen: <VT> ... <FS><CR>

// Numerischer OBX-Code -> internes Feld (Primärzuordnung).
const CODE_MAP = {
  '101': 'hr', '160': 'spo2',
  '170': 'sys', '171': 'dia', '172': 'map',      // NIBP
  '500': 'sys', '501': 'map', '502': 'dia',      // invasiver ART als Fallback
  '220': 'etco2', '221': 'fico2', '222': 'af',   // Kapno: CO2 / InsCO2 / AWRR
  '151': 'rr_imp',                                // Impedanz-Atmung (Fallback für af)
  '200': 'temp', '213': 'temp_tb',               // T1 / Bluttemperatur
  '102': 'pvcs', '51': 'weightKg',
};
// Label-Fallback (falls ein Nummerncode unbekannt ist, aber das Label sprechend). Schluessel KLEIN
// geschrieben; deckt Mindray-Kurznamen UND IEEE-11073-MDC-Nomenklatur (BeneView/BeneVision) ab.
const LABEL_MAP = {
  hr: 'hr', pr: 'hr', pulse: 'hr', mdc_ecg_heart_rate: 'hr', mdc_ecg_cardiac_rate: 'hr', mdc_puls_oxim_puls_rate: 'hr',
  spo2: 'spo2', mdc_puls_oxim_sat_o2: 'spo2',
  'nibp-sys': 'sys', sys: 'sys', 'nbp-s': 'sys', mdc_press_bld_noninv_sys: 'sys', mdc_press_cuff_sys: 'sys',
  'nibp-dia': 'dia', dia: 'dia', 'nbp-d': 'dia', mdc_press_bld_noninv_dia: 'dia', mdc_press_cuff_dia: 'dia',
  'nibp-mean': 'map', mean: 'map', 'nbp-m': 'map', mdc_press_bld_noninv_mean: 'map', mdc_press_cuff_mean: 'map',
  co2: 'etco2', etco2: 'etco2', mdc_co2_et: 'etco2', mdc_away_co2_et: 'etco2',
  fico2: 'fico2', insco2: 'fico2', mdc_co2_insp_min: 'fico2', mdc_away_co2_insp_min: 'fico2',
  awrr: 'af', mdc_co2_resp_rate: 'af', mdc_resp_rate: 'af', rr: 'rr_imp', resp: 'rr_imp',
  t1: 'temp', tb: 'temp_tb', temp: 'temp', mdc_temp: 'temp',
  pvcs: 'pvcs', weight: 'weightKg', mdc_body_weight: 'weightKg',
};

function fieldsOf(seg) { return seg.split('|'); }

// HL7/PDS liefert KEINEN Rhythmus-Code direkt. Rhythmus aus PVC-Zaehler (OBX 102) + Arrhythmie-
// Alarmtexten der OBX-Segmente ableiten (gefaehrlichster zuerst). Konservativ, nur OBX-Inhalte
// (keine Geraetenamen aus MSH/OBR) -> keine Falschtreffer. Kurvenform-Feinheiten (Haiflosse) sind
// ohne Waveform-Stream nicht ableitbar und bleiben null (ehrlich).
function inferRhythm(obxText, pvcs) {
  const T = (obxText || '').toUpperCase();
  if (/ASYSTOL/.test(T)) return 'asys';
  if (/V[\s_-]?FIB|VFIB|KAMMERFLIMMERN/.test(T)) return 'vfib';
  if (/V[\s_-]?TAC|VTAC|VENT.{0,4}TACH|KAMMERTACH/.test(T)) return 'vtach';
  if (/A[\s_-]?FIB|AFIB|VORHOFFLIMMERN/.test(T)) return 'afib';
  if (/\bPVC|\bVES\b|VPB|R[\s_]?ON[\s_]?T|COUPLET|BIGEMIN/.test(T)) return 'ves';
  if (pvcs != null && pvcs > 0) return 'ves';
  return null;
}

/*
 * parseHL7Message(text, cfg) -> normalisiertes ingest-Frame (oder null).
 * Pure Funktion (auch für Tests). cfg liefert deviceId/model/role/species Defaults + unmapped-Callback.
 */
function parseHL7Message(text, cfg, onUnmapped) {
  cfg = cfg || {};
  const segs = text.split(/[\r\n]+/).map(s => s.trim()).filter(Boolean);
  if (!segs.length || segs[0].slice(0, 3) !== 'MSH') return null;

  let sendingApp = 'Mindray', deviceName = cfg.model || 'Mindray Monitor';
  let patientId = null, weightFromPid = null, tsStr = null;
  const vit = { pvcs: null };
  const obxTexts = [];   // Labels + nicht-numerische OBX-Werte (fuer Arrhythmie-Alarm-Erkennung)

  for (const seg of segs) {
    const type = seg.slice(0, 3);
    const f = fieldsOf(seg);
    if (type === 'MSH') { if (f[2]) sendingApp = f[2]; }
    else if (type === 'PID') { if (f[3]) patientId = f[3].split('^')[0] || null; }
    else if (type === 'OBR') { if (f[4]) deviceName = f[4]; if (f[7]) tsStr = f[7]; }
    else if (type === 'OBX') {
      // OBX|<seq>|<NM|CE>|<code>^<label>|<subid/unit>|<value>|...
      const codeLabel = (f[3] || '').split('^');
      const code = codeLabel[0];
      const label = (codeLabel[1] || '').toLowerCase();
      const raw = f[5];
      if (raw === undefined || raw === '') continue;
      const val = parseFloat(String(raw).replace(',', '.'));
      // Arrhythmie-Alarme stehen als Text (nicht numerisch) in OBX -> fuer inferRhythm sammeln.
      if (codeLabel[1]) obxTexts.push(codeLabel[1]);
      if (!Number.isFinite(val)) { obxTexts.push(String(raw)); continue; }
      let key = CODE_MAP[code] || LABEL_MAP[label];
      if (!key) { if (onUnmapped) onUnmapped(code + '^' + (codeLabel[1] || '')); continue; }
      if (key === 'weightKg') { weightFromPid = val; continue; }
      vit[key] = val;
    }
  }

  // Zusammenbau ingest-Vitals (mit sinnvollen Fallbacks).
  const af = vit.af != null ? vit.af : vit.rr_imp;
  const temp = vit.temp != null ? vit.temp : vit.temp_tb;
  const role = cfg.role || (vit.etco2 != null ? 'combo' : 'monitor');

  return {
    deviceId: cfg.deviceId || cfg.id || 'hl7',
    deviceModel: cfg.model || deviceName || sendingApp,
    deviceRole: role,
    patientId: patientId || cfg.patientId || null,
    species: cfg.species || null,
    weightKg: cfg.weightKg != null ? cfg.weightKg : weightFromPid,
    ts: Date.now(),
    vitals: {
      hr: vit.hr, spo2: vit.spo2, etco2: vit.etco2, fico2: vit.fico2, af: af, temp: temp,
      nibp: { sys: vit.sys, dia: vit.dia, map: vit.map },
      // Rhythmus aus PVC-Zaehler + Arrhythmie-Alarmtexten abgeleitet (HL7 hat keinen Rhythmus-Code).
      // capnoShape (Rueckatmung) wird zentral in model.js aus FiCO2 abgeleitet; Haiflosse braucht Waveforms.
      ekgRhythm: inferRhythm(obxTexts.join(' '), vit.pvcs),
    },
    alarms: [],
    _meta: { pvcs: vit.pvcs, hl7Source: sendingApp, tsStr: tsStr },
  };
}

const QID = { n: 1 };
function ts14() { return new Date().toISOString().replace(/\D/g, '').slice(0, 14); }
function mllp(text) { return Buffer.concat([Buffer.from([VT]), Buffer.from(text, 'latin1'), Buffer.from([FS, CR])]); }

class HL7Adapter extends Adapter {
  constructor(cfg, ctx) {
    super(cfg, ctx);
    // Modus: 'listener' (Geraet verbindet sich zum PC und pusht) ODER
    //        'client' (PC verbindet sich zum Geraet:4601, PDS Realtime, sendet QRY^R02 und empfaengt ORU).
    this.mode = cfg.mode === 'client' ? 'client' : 'listener';
    this.host = cfg.host || null;
    this.port = cfg.port || cfg.listenPort || (this.mode === 'client' ? 4601 : 5000);
    this.server = null; this.sock = null; this.qtimer = null; this.rtimer = null;
    this.unmapped = new Set();
  }

  describe() { return { id: this.id, model: this.cfg.model || 'Mindray (HL7)', role: this.cfg.role || 'monitor' }; }

  async connect() {
    if (this.mode === 'client') return this._connectClient();
    return this._listen();
  }

  _listen() {
    this.server = net.createServer((socket) => this._onClient(socket));
    this.server.on('error', (e) => this.ctx.log && this.ctx.log.error('hl7', 'Listener-Fehler: ' + e.message));
    this.server.listen(this.port, () => {
      this.connected = true;
      this.ctx.log && this.ctx.log.info('hl7', 'HL7-Listener auf Port ' + this.port + ' bereit (Monitor "Send HL7" -> Serveradresse=PC-IP, Port ' + this.port + ').');
    });
  }

  // PDS-Realtime-Client: PC verbindet sich zum Geraet und fragt Daten ab (QRY^R02 = nur Daten-Abfrage,
  // KEINE Geraetesteuerung), empfaengt ORU^R01, quittiert (ACK) als Keepalive, Reconnect bei Abbruch.
  _connectClient() {
    if (!this.host) { this.ctx.log && this.ctx.log.warn('hl7', this.id + ': client-Modus ohne "host" -> deaktiviert (Geraete-IP setzen).'); return; }
    const self = this;
    const open = () => {
      const sock = net.connect(self.port, self.host, () => {
        self.connected = true;
        self.ctx.log && self.ctx.log.info('hl7', 'HL7-Client verbunden mit ' + self.host + ':' + self.port + ' (PDS Realtime). Sende QRY^R02...');
        self._sendQuery(sock);
        self.qtimer = setInterval(() => { if (!sock.destroyed) self._sendQuery(sock); }, 5000);
      });
      self.sock = sock;
      let buf = Buffer.alloc(0);
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (self.cfg.rawLog) self._rawDump(chunk);
        let start;
        while ((start = buf.indexOf(VT)) !== -1) {
          const end = buf.indexOf(FS, start + 1);
          if (end === -1) break;
          const payload = buf.slice(start + 1, end).toString('latin1');
          buf = buf.slice(end + 2);
          self._handleMessage(payload, sock);
        }
        if (buf.length > 1 << 20) buf = Buffer.alloc(0);
      });
      sock.on('error', (e) => self.ctx.log && self.ctx.log.warn('hl7', 'Client-Fehler ' + self.host + ':' + self.port + ': ' + e.message));
      sock.on('close', () => {
        self.connected = false;
        if (self.qtimer) { clearInterval(self.qtimer); self.qtimer = null; }
        self.ctx.log && self.ctx.log.warn('hl7', 'Client getrennt ' + self.host + ':' + self.port + ' -> neuer Versuch in 3 s');
        self.rtimer = setTimeout(open, 3000);
      });
    };
    open();
  }

  _sendQuery(sock) {
    const q = 'MSH|^~\\&|VetStation|||||' + ts14() + '||QRY^R02|' + (QID.n++) + '|P|2.3.1';
    try { sock.write(mllp(q)); } catch (_) {}
  }

  _onClient(socket) {
    const ip = socket.remoteAddress;
    this.ctx.log && this.ctx.log.info('hl7', 'Monitor verbunden: ' + ip);
    let buf = Buffer.alloc(0);
    socket.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      if (this.cfg.rawLog) this._rawDump(chunk);
      // MLLP-Rahmen extrahieren: <VT> payload <FS><CR>
      let start;
      while ((start = buf.indexOf(VT)) !== -1) {
        const end = buf.indexOf(FS, start + 1);
        if (end === -1) break;                          // Rahmen noch unvollstaendig
        const payload = buf.slice(start + 1, end).toString('latin1'); // ISO-8859-1
        buf = buf.slice(end + 2);                        // FS + CR ueberspringen
        this._handleMessage(payload, socket);
      }
      if (buf.length > 1 << 20) buf = Buffer.alloc(0);   // Schutz gegen Muell
    });
    socket.on('error', (e) => this.ctx.log && this.ctx.log.warn('hl7', 'Socketfehler ' + ip + ': ' + e.message));
    socket.on('close', () => this.ctx.log && this.ctx.log.warn('hl7', 'Monitor getrennt: ' + ip));
  }

  _handleMessage(text, socket) {
    let frame;
    try {
      frame = parseHL7Message(text, {
        deviceId: this.cfg.deviceId || this.id, model: this.cfg.model, role: this.cfg.role,
        species: this.cfg.species, weightKg: this.cfg.weightKg, patientId: this.cfg.patientId,
      }, (u) => {
        if (!this.unmapped.has(u)) { this.unmapped.add(u); this.ctx.log && this.ctx.log.warn('hl7', 'Unbekannter OBX-Code (bitte in CODE_MAP ergaenzen): ' + u); }
      });
    } catch (e) { this.ctx.log && this.ctx.log.warn('hl7', 'Parse-Fehler: ' + e.message); return; }
    if (frame) this.emit(frame);
    // HL7-ACK (Protokoll-Quittung, KEINE Geraetesteuerung). Im Client-Modus als Keepalive noetig.
    if (this.cfg.ack || this.mode === 'client') this._sendAck(socket, text);
  }

  _sendAck(socket, orig) {
    try {
      const msh = (orig.split(/[\r\n]+/)[0] || '').split('|');
      const ctrlId = msh[9] || '1';
      const ack = 'MSH|^~\\&|VetStation|||||' + new Date().toISOString().replace(/\D/g, '').slice(0, 14) + '||ACK^R01|' + ctrlId + '|P|2.3.1\rMSA|AA|' + ctrlId + '\r';
      socket.write(Buffer.concat([Buffer.from([VT]), Buffer.from(ack, 'latin1'), Buffer.from([FS, CR])]));
    } catch (_) {}
  }

  _rawDump(chunk) {
    try {
      const dir = path.join(__dirname, '..', '..', 'data');
      fs.mkdirSync(dir, { recursive: true });
      fs.appendFileSync(path.join(dir, 'hl7-raw.log'), chunk.toString('latin1'));
    } catch (_) {}
  }

  dispose() {
    if (this.server) { try { this.server.close(); } catch (_) {} }
    if (this.sock) { try { this.sock.destroy(); } catch (_) {} }
    if (this.qtimer) clearInterval(this.qtimer);
    if (this.rtimer) clearTimeout(this.rtimer);
    this.server = this.sock = this.qtimer = this.rtimer = null;
    this.connected = false;
  }
}

module.exports = { HL7Adapter, parseHL7Message };
