# Architektur

VetStation ist in **drei entkoppelte Schichten** aufgebaut (§4). Der Kern-Trick: **die klinische Logik
und das Design der Web-App werden wiederverwendet** — nur die Datenquelle wechselt von manueller
Eingabe auf Live.

```
[uMEC12 Vet]  \
[Veta 5 Plus]  >-- LAN/Switch --> [ 1. Acquisition-Bridge (Node, read-only) ] --WebSocket--> [ 2. Kiosk-UI (WebView2) ]
[LifeVet 10C] /                     pro-Gerät-Adapter → normalisiert                             |  wiederverwendete Web-Logik + Design
                                                                                                 v
                                                                                    [ 3. „Brain": Live-Zwischenfall-Erkennung
                                                                                      + Injektion (mL) + Geräte-Soll ]
```

## Schicht 1 — Acquisition-Bridge (`bridge/`)
Node-Dienst, **strikt read-only**. Aufgaben:
- **Adapter** (`adapters/`) je Gerätetyp parsen ihr Protokoll → **normalisiertes Frame-Modell** (`model.js`, §5).
- **Registry** (`registry.js`): Auto-Discovery (Geräte erscheinen, sobald sie Frames senden), Status
  (active/standby/offline), manuelles Koppeln, Meta-Overrides.
- **Matching** (`matching.js`): führt Geräte mit gleicher Patienten-ID (sonst Tierart+Gewicht) zu **einem
  Patienten** zusammen — Monitor liefert Kreislauf/EKG, Kapno/Narkose liefert Atmung/EtCO₂/Iso.
- **Server** (`server.js`): ein Prozess, ein Port — liefert die UI **und** den WebSocket **und** eine kleine JSON-API.
- **wsserver.js**: abhängigkeitsfreier WebSocket-Server (RFC 6455) → **kein `npm install`** auf dem Kiosk nötig.

Broadcast-Takt: alle 500 ms sendet die Bridge `devices` + zusammengeführte `patients`. Frames selbst
sind numerisch (~1–2 Hz genügen) — **Waveforms werden nicht übertragen**.

## Schicht 2 — Kiosk-UI (`ui/`)
Vanilla-JS-SPA (kein Framework), lädt die **Design-Dateien** (`glass.css`, `vetpharm-ui.js`) und die
**klinischen Daten** (`anaes-data.js`) der Web-App. Ein WebSocket-Client (`app.js`) hält einen
Patienten-Store und rendert **pro Patient eine Karte** (Split-View), diff-basiert (die Monitor-Canvas
überlebt die 2-Hz-Updates). Die gefährlichste Warnung springt nach oben.

**Monitorbild lokal synthetisiert:** `engine/waveforms.js` portiert die reinen Funktionen
`wEkg/wPleth/wCapno` der Web-App; pro Patient eine `MonitorCanvas`, alle von **einer** rAF-Schleife
getrieben (RAM-/CPU-schonend für den i3/8-GB-Ziel-PC).

## Schicht 3 — „Brain" (`ui/engine/`)
Die wiederverwendete Kreuz-Analyse der Web-App, jetzt mit Live-Daten:
- **`brain.js`** — `assess(ANAES, patient, {iso})` → priorisierte Zwischenfälle. Portiert **1:1** aus
  `renderAssess()`/`monAlarms()` der Web-App: Einzelwert-Scan (Parameter außerhalb Normband) **plus**
  die Kreuz-Regeln **R1–R6**:
  | Regel | Auslöser | Ergebnis |
  |---|---|---|
  | R1 | flaches/chaotisches EKG | Asystolie/Kammerflimmern → **CPR** (+Defib), Verdampfer 0 |
  | R2 | VES/VT **und** SpO₂↓/EtCO₂↑ | „hypoxie-getrieben" → **erst O₂/Beatmung** |
  | R3 | VES/VT isoliert | Oxygenierung/Tiefe sichern, dann Lidocain (Hund) |
  | R4 | Bradykardie + MAP↓ + Iso hoch | „zu tiefe Narkose" → **Iso zuerst senken** (nicht Atropin) |
  | R5 | MAP↓ + Iso hoch | „Hypotonie bei tiefer Narkose" → **Verdampfer senken**, dann Volumen/Ephedrin |
  | R6 | Kapno-Haifischflosse | **Bronchospasmus/Atemweg** (Tubus, β2, 100 % O₂) |
- **`dose.js`** — `calc()`/`injectionsFor()`: Dosis mg/kg → **mL** je Tierart/Gewicht (aus `A.drugs[].species[sp]`).
- **`device-target.js`** — `devTarget()`/`compare()`: Geräte-Soll (O₂/Iso/System/APL) + `isoHigh` für R4/R5.

## Wiederverwendungs-Strategie (kein Fork der Klinik-Daten)
- **Daten** (`anaes-data.js`: Medikamente, Zwischenfälle, Schwellen, Vitalbänder, EKG-Definitionen,
  Maschinen-Settings) werden **zur Laufzeit vom Live-canis-vetpharm gepullt** (`clinical-data-loader.js`),
  mit lokaler Kopie als Fallback. So fließen Verbesserungen der Web-App automatisch in den Kiosk.
- **Nur die 6 Kreuz-Regeln + die Soll-Formel** sind portierter Code (mit Quellenverweis auf `index.html`).
  Alles andere ist datengetrieben → wenig Drift.

## Datenmodell (§5)
Siehe `bridge/src/model.js`. Ein Patient (nach Matching) hat zusammengeführte Vitalwerte
`{hr, spo2, etco2, af, sys, dia, map, temp, ekgRhythm, capnoShape, pleth}`, `species`, `weightKg`,
`isoPct`, `devices[]`, `alarms[]`.

## Warum diese Technik
- **Node-Bridge** statt schwerer Laufzeit: klein, schnell, ohne Abhängigkeiten → Appliance-tauglich.
- **WebView2** (Evergreen) statt veralteter Engines → identisch auf Win10/11 und künftig.
- **Kurven lokal synthetisiert** → minimale Bandbreite/RAM, flüssig auf i3/8 GB mit mehreren Streams.
- **UI ↔ Bridge entkoppelt** → neue Geräte/Windows-Versionen ohne Umbau ergänzbar (§13).
