'use strict';
/* vscapture-test.js — prueft den CSV-Tail-Adapter: Kopfzeile-Zuordnung + Zeilen -> Frame. */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { VSCaptureAdapter, mapHeader } = require('../bridge/src/adapters/vscapture');

let fails = 0;
const ok = (c, d) => { if (c) console.log('  ✓ ' + d); else { fails++; console.log('  ✗ FAIL: ' + d); } };

console.log('== VSCapture CSV-Tail-Test ==');
ok(mapHeader('NIBP-S') === 'sys' && mapHeader('etCO2') === 'etco2' && mapHeader('awRR') === 'af' && mapHeader('SpO2') === 'spo2', 'Spalten-Zuordnung (NIBP-S, etCO2, awRR, SpO2)');

const tmp = path.join(os.tmpdir(), 'vetstation-vsc-test-' + process.pid + '.csv');
fs.writeFileSync(tmp, 'Time,HR,SpO2,NIBP-S,NIBP-D,NIBP-M,etCO2,awRR,T1\n');
fs.appendFileSync(tmp, '2026-07-15T13:19:17,138,97,118,74,89,40,13,38.5\n');

const frames = [];
const ctx = { emit: (f) => frames.push(f), log: { info: () => {}, warn: () => {}, error: () => {} } };
const a = new VSCaptureAdapter({ id: 'vsc', file: tmp, pollMs: 150, species: 'katze' }, ctx);

(async () => {
  await a.connect();
  setTimeout(() => {
    const f = frames[0];
    ok(frames.length >= 1, 'CSV-Zeile -> Frame');
    ok(f && f.vitals.hr === 138 && f.vitals.spo2 === 97, 'HR 138 / SpO2 97');
    ok(f && f.vitals.nibp.sys === 118 && f.vitals.nibp.map === 89, 'NIBP 118/(89)');
    ok(f && f.vitals.etco2 === 40 && f.vitals.af === 13, 'EtCO2 40 / AF 13');
    ok(f && f.vitals.temp === 38.5 && f.species === 'katze', 'Temp 38.5 / Art katze');
    a.dispose(); try { fs.unlinkSync(tmp); } catch (_) {}
    console.log('\n== ' + (6 - fails) + ' OK, ' + fails + ' FAIL ==');
    process.exit(fails ? 1 : 0);
  }, 500);
})();
