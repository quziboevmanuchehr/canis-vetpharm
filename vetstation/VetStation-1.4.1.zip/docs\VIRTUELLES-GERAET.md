# Das universelle virtuelle Gerät (ab 1.4.0)

> „Es muss eine universale Monitor und kapnograph Virtuell sein, damit für alle Monitorgeräte
> und auch kapnograph und Narkosegeräte passt." — Auftrag vom 05.08.2026

## Warum

Bis 1.3.4 war das virtuelle Gerät **fest verdrahtet**: im Bild stand „mindray uMEC12 Vet" und
„mindray Veta 5 Plus", es hatte genau **sechs Kacheln** (HF, SpO₂, EtCO₂, NIBP, AF, Temp) und
genau **drei Kurvenbahnen** (EKG, Pleth, Kapno).

Zwei Folgen, beide unangenehm:

1. Wer einen Dräger, Bionet, EDAN oder SurgiVet vor sich hat, sah trotzdem ein Mindray.
2. Wer ein **Veta 5 Plus** vor sich hat, sah nur die **Hälfte** von dessen Bildschirm. Auf den
   Fotos des Praxisgeräts (30.07. und 04.08.2026) stehen: **FiCO₂**, die **Paw-Kurve**, **MAX**
   (Spitzendruck), **PEEP**, gemessenes **Vt**, **MV**, die **Alarmgrenzen neben jeder Zahl**,
   die **Falluhr** und die Knöpfe **Audio-Pause / Alarm Setup / Insp. Hold / Fall beenden**.
   Nichts davon gab es in der App.

Der zweite Punkt ist der klinisch wichtigere. Foto 2 zeigt **FiCO₂ 8 mmHg** mit dem Alarm
„FiCO₂ zu hoch" und eine Kapnokurve, deren Grundlinie nicht auf null zurückgeht — **Rückatmung**.
Ohne diesen Kanal sieht man nur ein erhöhtes EtCO₂ und beatmet stärker. Der erschöpfte Atemkalk
bleibt drin.

## Aufbau: eine Datei, drei Orte

`ui/shared/geraete-profile.js` ist reine Daten plus reine Funktionen — kein DOM, kein Netz, kein
`require`. Deshalb läuft sie identisch

* im Kiosk-Browser der Station (`ui/app/index.html`),
* in der Fern-Web-App (`canis-vetpharm/canis-anaesthesie/`),
* in der Bridge unter Node (`bridge/src/*`, über den Test).

**Genau das** ist der Grund, warum Kurven, Werte und Einstellungen überall gleich sind: es gibt
**eine** Beschreibung, nicht drei. `tools/geraete-profil-test.js` erzwingt, dass die Fassung in
der Web-App **zeichengleich** ist — eine Kopie, die man abschreibt statt kopiert, ist eine
Zeitbombe mit Zufallszünder (Befund 04.08.2026: die Bridge las jahrelang eine andere
`anaes-data.js` als der Browser).

### Vier Bausteine

| Baustein | Was es ist |
|---|---|
| `KANAELE` | 23 Messkanäle mit Kurzname, Einheit, Farbe, Normband und Erklärung |
| `KURVEN` | 6 Kurvenbahnen: EKG · Pleth · CO₂ · **Paw** · **Flow** · Resp |
| `GASE` | Isofluran · Sevofluran · Desfluran · Halothan, je mit Skala und **MAC pro Tierart** |
| `PROFILE` | 27 Geräteprofile (Monitore, Kapnografen, Narkose-/Beatmungsgeräte) |

### Neue Kanäle gegenüber 1.3.4

`fico2` · `ppeak` · `pmean` · `peep` · `vte` · `mv` · `compl` · `fio2` · `etAgent` · `fiAgent` ·
`mac` · `etn2o` · `pi` · `temp2` · `ibp`

## Die drei Regeln, an denen sich alles entscheidet

### 1. Ein Kanal, den ein Gerät nicht hat, steht nicht im Bild

Das **LifeVet M** hat laut Modulverzeichnis (`CO2(C5) = -.-`, Fotos 31.07.2026) **kein
CO₂-Modul verbaut**. Sein Profil hat deshalb weder `etco2` noch die Kapno-Bahn. Es ist keine
Einstellung — die Hardware kann es nicht. Eine EtCO₂-Kachel wäre dort eine vorgetäuschte Messung.

Umgekehrt hat der **Veta 5 Plus** kein Gasmodul: `etAgent` fehlt in seinem Profil, obwohl das
Universalprofil ihn kennt.

### 2. Gerechnet ist nicht gemessen — und gemessen schlägt gerechnet

`MV`, `Cdyn`, `Pmean` und `MAC` werden gerechnet, wenn **alle** Eingangswerte da sind. Fehlt
einer, bleibt der Wert weg — nie geschätzt. Gerechnete Werte tragen in der Kachel ein `∗`.

Liefert das Gerät den Wert **selbst**, gewinnt er. (Gemessen 05.08.2026: das Gerät meldete
MV 0,9, die Anzeige rechnete 0,85 und überschrieb es. Wer zwei Zahlen für dieselbe Größe sieht,
glaubt keiner mehr.)

### 3. MAC gehört zum Gas UND zur Tierart

2,0 Vol% sind bei **Isofluran** eine Erhaltungsdosis und bei **Desfluran** ein Viertel MAC.
Der Verdampfer wechselt deshalb mit dem Gas seine Skala (Iso 0–6, Sevo 0–8, Des 0–18) und der
Soll-Abgleich seine Zahlen.

Wo ein artspezifischer MAC publiziert ist, steht er drin (Hund, Katze, Kaninchen, Ratte, Maus,
Meerschwein). Sonst wird er aus dem **Isofluran-MAC derselben Tierart** hochgerechnet und
**als abgeleitet gekennzeichnet** — in der Oberfläche mit `∗` und dem Satz „nicht artspezifisch
belegt". Eine Größenordnung, kein Beleg.

## Das Cockpit (ab 1.4.1) — alles auf einem Bildschirm

Bis 1.4.0 war der Reiter eine lange Seite: Modellwahl, Eingabefelder, Gerätebild, Analyse,
Beatmungsmodi, EKG- und Kapno-Galerie untereinander. **Während einer Narkose zu scrollen, um den
Blutdruck zu sehen, ist keine Bedienung.**

Das Cockpit ist deshalb genau bildschirmhoch (`cockpitHoehe()` misst zur Laufzeit — die
Kopfleisten sind je nach Fensterbreite, Zoom und Schriftgröße verschieden hoch, eine feste Zahl
wäre auf der Hälfte der Bildschirme falsch):

```
┌ Modellwahl · ✍️ Ist · 🎬 Szenario · 🔕 ──────────────┬── Analyse & Soll ──┐
│ Monitor & Kapnograph 🐈 00:12:44 VCV ⚠!! …  10:25:30 │  Kreuz-Analyse     │
│ ┌── Kurven (nur nötige) ──┐ ┌ HF   140  180/100 ┐   │  Geräte-Soll       │
│ │ EKG   ∿∿∿∿∿∿           │ │ SpO₂  99  100/95  │   │  Beatmungs-Coach   │
│ │ CO₂   ▁▄██▄▁▄██▄       │ │ EtCO₂  75   55/35 │   │  Virtuelles Gerät  │
│ │ Paw   ▁▟▛▙▁▟▛▙         │ │ …                 │   │  Alarmgrenzen ⓘ    │
│ └─────────────────────────┘ └───────────────────┘   │                    │
│ Narkose- & Beatmungsgerät · O₂ · Verdampfer · Modi  │                    │
└──────────────────────────────────────────────────────┴────────────────────┘
```

Nachschlagewerke (Beatmungsmodi, EKG-Galerie, Kapno-Galerie) stehen weiterhin darunter — sie
werden **zwischen** zwei Fällen gelesen, nicht während einer.

**Kurven nur, wo sie etwas aussagen.** Eine Bahn erscheint nur, wenn es den zugehörigen Messkanal
gibt: keine EKG-Bahn ohne EKG-Kanal, keine Paw-Bahn ohne Ventilator. Die Impedanz-Atemkurve fällt
zusätzlich weg, sobald ein Kapnogramm da ist — beide zählen Atemzüge, aber die Impedanz kann
Herzschläge als Atmung fehldeuten und erkennt eine Verlegung nicht. Bleibt keine Bahn übrig
(z. B. ein reines Blutdruckgerät), **verschwindet die Leinwand ganz** und die Zahlen nehmen die
volle Breite; eine große schwarze leere Fläche kostet genau den Platz, den die Werte brauchen.

| Gerätelage | Bahnen |
|---|---|
| Monitor + Veta 5 Plus | EKG · Pleth · CO₂ · Paw |
| LifeVet M (kein CO₂-Modul) | EKG · Pleth · Resp |
| petMAP (nur Blutdruck) | *keine* — Kacheln über die volle Breite |
| Universal + Universal | EKG · Pleth · CO₂ · Paw · Flow |

**Eingabefelder und Rhythmus-Chips verschwinden im Livebetrieb.** Sobald ein Gerät liefert, sind
sie eine zweite Anzeige derselben Zahlen — und sie kosten die Höhe, die den Kurven fehlt. Ohne
Gerät stehen sie da, denn dann sind sie der einzige Weg, Werte einzutragen.

Auf Fenstern unter 1000 px Breite (Tablet/Handy) wird wieder gestapelt und normal gescrollt.

## Alarmgrenzen stellt die App selbst (ab 1.4.1)

Es gab einen Knopf „Alarm-Setup". Wer Grenzen unter Zeitdruck aus dem Kopf setzt, vergisst sie
beim nächsten Patienten. Hier steht die ganze Patientenlage ohnehin beisammen — **Tierart,
Gewicht, Alter und Rasse mit ihrer Genetik** —, also kommen die Grenzen daraus. Handeingabe gibt
es nicht mehr: zwei Wahrheiten für dieselbe Grenze sind am narkotisierten Tier schlimmer als eine,
die man begründen kann.

Grundlage ist das artspezifische Normband bzw. das gewichtsabhängige Band des Kanals. Darauf
wirken vier Anpassungen, jede **sichtbar** (Fußzeile „Alarmgrenzen · automatisch") und jede in
dieselbe Richtung: **enger**, wo Alter oder Rasse die Reserve verkleinern. Ein früherer Alarm
kostet einen Blick, ein späterer kostet Zeit, die man nicht hat.

| Befund | Anpassung | Warum |
|---|---|---|
| **Jungtier / neonatal** | HF-Obergrenze ×1,25 · Ppeak ≤ 12 · Temp-Alarm früher | Herzauswurf hängt fast nur an der Frequenz; kleine Lunge ist leicht überbläht; Wärme- und Zuckerreserve klein |
| **geriatrisch** | MAP-Untergrenze +5 · Temp-Alarm früher | weniger Kreislaufreserve, schlechtere Wärmeregulation |
| **brachyzephal (BOAS)** | SpO₂ ≥ 96 · EtCO₂ ≤ 50 | obere Atemwege eng — die Sättigung fällt schnell und ohne Vorwarnung |
| **Windhund-Typ** | Temp-Untergrenze +0,4 | wenig Körperfett, kühlt schnell aus |
| **HCM (Katze)** | HF ≤ 160 · MAP ≥ 70 | die verdickte Kammer füllt sich nur in der Diastole, und Tachykardie verkürzt genau die |

Die einzige gewollte **Ausweitung** ist die Frequenzobergrenze beim Jungtier — dort ist eine hohe
Frequenz physiologisch, ein Alarm darauf wäre ein Fehlalarm im Minutentakt. Der Test erzwingt,
dass keine andere Anpassung eine Grenze weiter zieht als die Artnorm.

**Fallstrick, an dem die erste Fassung still vorbeilief:** `VB.groupsOf()` liefert die ausgebauten
Gruppenobjekte, und die tragen ihren Schlüssel unter `key`, nicht unter `id`. Die Bulldogge war
brachyzephal, die Liste blieb leer, und die Alarmgrenze stand unverändert auf dem allgemeinen
Hundeband. Jetzt wird `b.groups` roh gelesen. Ebenso: der Blutdruck heißt als **Kanal** `nibp`,
als **Normband** aber `map` — ohne die Übersetzung blieb ausgerechnet die Blutdruckanpassung beim
alten Tier wirkungslos.

## Was der Anwender sieht

Im Reiter **🖥️ Gerät** stehen oben drei Auswahlfelder:

* **Monitor / Kapnograf** — 17 Modelle
* **Narkosegerät / Beatmung** — 10 Modelle, dazu „kein Narkosegerät"
* **Narkosegas** — die Gase, die das gewählte Gerät führen kann

Die Wahl wird pro Praxis gemerkt (`localStorage`) und von der Station **automatisch gesetzt**,
sobald ein Gerät sein Modell meldet (HL7 `MSH-3`/`OBR-4`, sonst der Katalogeintrag aus
`devices.json`). **Eine Handwahl gewinnt immer** — sonst dreht die Station die Auswahl im
Sekundentakt zurück, derselbe Fehler wie einst bei der Tierart.

Darunter das Gerätebild wie am echten Apparat:

```
🐈  00:12:44  VCV   ⚠!! EtCO₂ zu hoch          2026-08-05 10:25:30
┌──────────────────────────────────────────────┐  EtCO₂  75   55/35
│ CO₂  ▁▄██▄▁▄██▄▁▄██▄                        │  FiCO₂   0     3
│ Paw  ▁▟▛▙▁▟▛▙▁▟▛▙   (violett = Pflichthub)  │  MAX     7    15
└──────────────────────────────────────────────┘  PEEP    3     8
🔔 Audio-Pause  ⚙ Alarm-Setup  ⏸ Insp. Hold  ▶ Fall  Vt      36   65/43
```

* **Alarmgrenzen** stehen als kleine Doppelzahl neben jedem Wert. Vorgabe ist das Normband der
  Tierart; eine von Hand gesetzte Grenze schlägt es und bleibt stehen, bis sie zurückgesetzt wird.
  Bewusst **keine** Automatik, die eine Grenze im Hintergrund verschiebt.
* Das **Alarmband** nennt den Kanal beim Namen („EtCO₂ zu hoch"), nicht „3 Werte außerhalb".
* Die **Paw-Kurve** ist zweifarbig: gelb = spontaner/getriggerter Atemzug, violett = maschineller
  Pflichthub — so steht es auch auf dem Veta 5. Ihre **Form** hängt am Modus: VCV zeichnet eine
  Rampe (konstanter Fluss), PCV ein Rechteck, Spontanmodi eine Sog-Delle vor dem Hub.
* Die **Falluhr läuft mit dem Datenfluss**, nicht mit einem Knopf (ab 1.4.1). Der Fall wird am
  Narkosegerät bzw. am Monitor gestartet — sobald das geschehen ist, fließen Daten. Ein zweiter
  Schalter dafür kann nur eines: falsch stehen. Bleiben die Pakete länger als 45 s aus, bleibt die
  Uhr stehen; ohne angeschlossenes Gerät steht dort „—" statt einer erfundenen Zeit.
* **Insp. Hold gibt es nicht** (entfernt in 1.4.1). Ein Inspirationshalt ist ein Eingriff in die
  Beatmung und geht nur am echten Gerät; ein Knopf, der bloß das Bild anhält, sähe genauso aus und
  wäre etwas völlig anderes.

## Zwei neue Kreuz-Analysen

| Befund | Was die App sagt |
|---|---|
| **FiCO₂ > 3** | „Rückatmung – eingeatmetes CO₂ X mmHg". Atemkalk prüfen/wechseln · Ein-/Ausatemventil auf Klemmen prüfen · Frischgasfluss erhöhen · Totraum verkleinern. **Erst danach** die Ventilation nachstellen. |
| **Ppeak > Grenzdruck + 3** | „Spitzendruck zu hoch". Tubus freimachen · Vt auf 6–8 ml/kg · in PCV wechseln · I:E verlängern. Ein Barotrauma ist in Sekunden gemacht. |

Beide unterdrücken die allgemeinere Einzelwert-Karte desselben Kanals — sonst stand unter der
Rückatmungs-Karte noch „FiCO₂ ↑ → Narkosetiefe prüfen", ein Rat, der dem Befund widerspricht.

## Der Weg der Werte

```
Gerät ─HL7→ bridge/src/adapters/hl7.js ─→ model.js ─→ matching.js ─→ registry
                                                                        │
                        ┌───────────────────────────────────────────────┤
                        ▼                                               ▼
        ui/vetstation-live.js  drive()                    bridge/src/cloud.js
        __setMesswerte / __setGeraetProfil                        │
                        ▼                                    Firebase RTDB
              virtuelles Gerät (Kiosk)                             │
                                                                   ▼
                                              canis-anaesthesie  applyLive()
                                              __setMesswerte / __setGeraetProfil
```

Fern und lokal rufen **dieselben** Brücken auf, nicht zwei Umsetzungen. Wäre es fern nachgebaut,
wäre es beim nächsten neuen Kanal wieder auseinandergelaufen — so wie einst der Veta-5-Spiegel,
der lokal lief und fern still tot war.

**Keine feste Feldliste mehr (ab 1.4.1).** Beide Seiten geben *jeden* Zahlenwert des
zusammengeführten Patienten weiter; welcher Kanal davon angezeigt wird, entscheidet die App
anhand des Geräteprofils. Eine feste Liste müsste bei jedem neuen Kanal an einer weiteren Stelle
nachgetragen werden, und die vergessene Stelle meldet sich nie — genau daran ist im Juli 2026
der Datenport 5510 fast gescheitert.

### Millisekunden statt 350er-Raster (ab 1.4.1)

Der Rundruf an die Oberfläche lief in einem festen 350-ms-Takt. Zwischen „Wert kommt an" und
„Wert steht im Bild" lagen damit im Mittel 175 ms und schlimmstenfalls 350 ms — Zeit, die niemand
braucht, weil die Nachricht bereits fertig verarbeitet in der Hand liegt.

`registry.onNeu` meldet jetzt jeden eingegangenen Frame; `server.js` bündelt die Meldungen und
sendet höchstens alle **40 ms** (= 25 Bilder/s, genau die Rate, mit der der virtuelle Monitor
ohnehin zeichnet — schneller könnte niemand sehen). Der erste Wert nach einer Ruhephase geht
**ohne jede Verzögerung** hinaus.

Der 350-ms-Zeitgeber bleibt: er trägt das Narkoseprotokoll, die Fern-Übertragung und die
Lastbremse, und er ist der Herzschlag, an dem man erkennt, ob die Station noch läuft. Was er nicht
mehr allein bestimmt, ist die Frische der Zahlen. Ohne Bündelung ginge das nach hinten los: ein
LifeVet schickt EKG-Streifen mit 256 Hz in 1-s-Häppchen, drei Geräte an einem Patienten ergeben
in Spitzen zweistellig viele Nachrichten pro Sekunde — jede einzeln gesendet hieße, den
Kiosk-Browser mit JSON-Arbeit zu beschäftigen statt Kurven zu zeichnen.

### Was in der Bridge dazukam

* **`hl7.js`** — die neuen Kanäle **nur über das Label**, nicht über Zahlencodes. Für HF/SpO₂/NIBP
  stehen private Mindray-Nummern drin, weil sie am echten Gerät dieser Praxis **gemessen** wurden.
  Für Paw/PEEP/Vt/MV/FiO₂/Narkosegas gibt es hier keine eigene Messung — eine ausgedachte Nummer
  wäre ein Gerücht und würde stillschweigend einen fremden Parameter unter falschem Namen anzeigen.
  Die MDC-Bezeichner (IEEE 11073-10101) sind dagegen selbstbeschreibend und kommen bei genau
  diesen Geräten mit jedem OBX mit.
* **Einheitenprüfung** für cmH₂O (gegen mbar/hPa/kPa), ml (gegen Liter), L/min (gegen ml/min) und
  Vol% (gegen kPa). Ein Gerät, das den Atemwegsdruck in kPa meldet, würde sonst „1" statt „10"
  anzeigen — ein bedrohlich hoher Spitzendruck sähe aus wie eine Idealeinstellung.
* **`matching.js`** — die Beatmungswerte bekommen das Gewicht 4 für `anesthesia`/`capno`: bei zwei
  Quellen gewinnt das Gerät, das **beatmet**. `MERGE_FELDER` ist **eine** Liste, damit ein neuer
  Kanal nicht an mehreren Stellen nachgetragen werden muss.
* **`model.js`** — Plausibilitätsfenster je Kanal. Mindrays 32767 wird nicht zum Spitzendruck,
  und **jede** Verwerfung wird gemeldet statt verschwiegen.
* **`cloud.js`** — die neuen Kanäle stehen in der Liste der immer vorhandenen Felder. Fehlt der
  Schlüssel ganz, bleibt in der Fern-Ansicht der zuletzt gesehene Wert eingefroren stehen (RTDB
  `PATCH` löscht nur, was ausdrücklich auf `null` gesetzt wird).

## Ein neues Gerät eintragen

1. In `ui/shared/geraete-profile.js` ein Profil an `PROFILE` anhängen. Pflicht: `id`, `rolle`,
   `hersteller`, `typ`, `vertrauen`, `hinweis`.
2. `kanaele[]` und `kurven[]` **nur mit dem, was das Gerät wirklich kann.** Im Zweifel weglassen.
3. `katalogId` auf den passenden Eintrag in `bridge/src/geraetekatalog.js` setzen (dort steht,
   **wie** man es ansteckt — hier steht, **was** es zeigt). Der Test prüft, dass der Verweis lebt.
4. `hinweis` ist der eine Satz, der die häufigste Enttäuschung vorwegnimmt („zeigt alles, gibt
   nichts heraus", „Werkseinstellung ist VITALINK, nicht MEDIBUS", „Pin 6 führt +5 V").
5. `node tools/geraete-profil-test.js`

## Prüfen

```
node tools/geraete-profil-test.js
```

180 Prüfungen in zwölf Blöcken. Zwei davon sind ungewöhnlich und lohnen die Erwähnung:

* **Block 11** holt `wCapno`, `wPaw` und `wFlow` per Textsuche aus `index.html`, baut sie mit
  `new Function` und **rechnet** damit: hebt FiCO₂ 8 die Grundlinie? Ist VCV eine Rampe und PCV
  ein Rechteck? Erreicht der Ausatemfluss bei Obstruktion die Null nicht? Ein reiner Textabgleich
  hätte das nie gefunden — genau daran ist 2026 der Veta-5-Spiegel vorbeigelaufen, der
  vollständig vorhanden und trotzdem tot war.
* **Block 12** vergleicht die Web-App zeichenweise mit der Quelle.

Nach jeder Änderung an `ui/app/index.html`:

```
node tools/web-app-bauen.js ui/app/index.html ../../canis-vetpharm/canis-anaesthesie/index.html
```

Das Werkzeug setzt den Fern-Seam (`tools/web-fern-seam.js`) und das Fern-Modul wieder an und
kopiert `anaes-data.js` und `geraete-profile.js` zeichengleich mit.
